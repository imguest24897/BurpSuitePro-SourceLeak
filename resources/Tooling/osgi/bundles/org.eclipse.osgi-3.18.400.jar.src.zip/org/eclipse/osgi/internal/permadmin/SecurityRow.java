/*     */ package org.eclipse.osgi.internal.permadmin;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.Permission;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.service.condpermadmin.Condition;
/*     */ import org.osgi.service.condpermadmin.ConditionInfo;
/*     */ import org.osgi.service.condpermadmin.ConditionalPermissionInfo;
/*     */ import org.osgi.service.permissionadmin.PermissionInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SecurityRow
/*     */   implements ConditionalPermissionInfo
/*     */ {
/*  34 */   static final Class<?>[] conditionMethodArgs = new Class[] { Bundle.class, ConditionInfo.class };
/*  35 */   static Condition[] ABSTAIN_LIST = new Condition[0];
/*  36 */   static Condition[] SATISFIED_LIST = new Condition[0];
/*  37 */   static final Decision DECISION_ABSTAIN = new Decision(4, null, null, null);
/*  38 */   static final Decision DECISION_GRANTED = new Decision(1, null, null, null);
/*  39 */   static final Decision DECISION_DENIED = new Decision(2, null, null, null);
/*     */   
/*     */   private final SecurityAdmin securityAdmin;
/*     */   
/*     */   private final String name;
/*     */   private final ConditionInfo[] conditionInfos;
/*     */   private final PermissionInfoCollection permissionInfoCollection;
/*     */   private final boolean deny;
/*     */   final Map<BundlePermissions, Condition[]> bundleConditions;
/*  48 */   final Object bundleConditionsLock = new Object();
/*     */   
/*     */   public SecurityRow(SecurityAdmin securityAdmin, String name, ConditionInfo[] conditionInfos, PermissionInfo[] permissionInfos, String decision) {
/*  51 */     if (permissionInfos == null || permissionInfos.length == 0)
/*  52 */       throw new IllegalArgumentException("It is invalid to have empty permissionInfos"); 
/*  53 */     this.securityAdmin = securityAdmin;
/*  54 */     this.conditionInfos = (conditionInfos == null) ? new ConditionInfo[0] : conditionInfos;
/*  55 */     decision = decision.toLowerCase();
/*  56 */     boolean d = "deny".equals(decision);
/*  57 */     boolean a = "allow".equals(decision);
/*  58 */     if (!(d | a))
/*  59 */       throw new IllegalArgumentException("Invalid decision: " + decision); 
/*  60 */     this.deny = d;
/*  61 */     this.name = name;
/*  62 */     this.permissionInfoCollection = new PermissionInfoCollection(permissionInfos);
/*  63 */     if (conditionInfos == null || conditionInfos.length == 0) {
/*  64 */       this.bundleConditions = null;
/*     */     } else {
/*  66 */       this.bundleConditions = (Map)new HashMap<>();
/*     */     } 
/*     */   }
/*     */   static SecurityRowSnapShot createSecurityRowSnapShot(String encoded) {
/*  70 */     return (SecurityRowSnapShot)createConditionalPermissionInfo(null, encoded);
/*     */   }
/*     */   
/*     */   static SecurityRow createSecurityRow(SecurityAdmin securityAdmin, String encoded) {
/*  74 */     return (SecurityRow)createConditionalPermissionInfo(securityAdmin, encoded);
/*     */   }
/*     */   
/*     */   private static ConditionalPermissionInfo createConditionalPermissionInfo(SecurityAdmin securityAdmin, String encoded) {
/*  78 */     encoded = encoded.trim();
/*  79 */     if (encoded.length() == 0)
/*  80 */       throw new IllegalArgumentException("Empty encoded string is invalid"); 
/*  81 */     char[] chars = encoded.toCharArray();
/*  82 */     int end = encoded.length() - 1;
/*  83 */     char lastChar = chars[end];
/*  84 */     if (lastChar != '}' && lastChar != '"')
/*  85 */       throw new IllegalArgumentException(encoded); 
/*  86 */     String encodedName = null;
/*  87 */     if (lastChar == '"') {
/*     */       
/*  89 */       if (chars.length < 2)
/*  90 */         throw new IllegalArgumentException(encoded); 
/*  91 */       int endName = encoded.length() - 1;
/*  92 */       int startName = endName - 1;
/*  93 */       while (startName > 0) {
/*  94 */         if (chars[startName] == '"') {
/*  95 */           startName--;
/*  96 */           if (startName > 0 && chars[startName] == '\\') {
/*  97 */             startName--;
/*     */           } else {
/*  99 */             startName++;
/*     */             break;
/*     */           } 
/*     */         } 
/* 103 */         startName--;
/*     */       } 
/* 105 */       if (chars[startName] != '"')
/* 106 */         throw new IllegalArgumentException(encoded); 
/* 107 */       encodedName = unescapeString(encoded.substring(startName + 1, endName));
/* 108 */       end = encoded.lastIndexOf('}', startName);
/*     */     } 
/* 110 */     int start = encoded.indexOf('{');
/* 111 */     if (start < 0 || end < start) {
/* 112 */       throw new IllegalArgumentException(encoded);
/*     */     }
/* 114 */     String decision = encoded.substring(0, start);
/* 115 */     decision = decision.trim();
/* 116 */     if (decision.length() == 0 || (!"deny".equalsIgnoreCase(decision) && !"allow".equalsIgnoreCase(decision))) {
/* 117 */       throw new IllegalArgumentException(encoded);
/*     */     }
/* 119 */     List<ConditionInfo> condList = new ArrayList<>();
/* 120 */     List<PermissionInfo> permList = new ArrayList<>();
/* 121 */     int pos = start + 1;
/* 122 */     while (pos < end) {
/* 123 */       while (pos < end && chars[pos] != '[' && chars[pos] != '(')
/* 124 */         pos++; 
/* 125 */       if (pos == end)
/*     */         break; 
/* 127 */       int startPos = pos;
/* 128 */       char endChar = (chars[startPos] == '[') ? ']' : ')';
/* 129 */       while (pos < end && chars[pos] != endChar) {
/* 130 */         if (chars[pos] == '"') {
/* 131 */           pos++;
/* 132 */           while (chars[pos] != '"') {
/* 133 */             if (chars[pos] == '\\')
/* 134 */               pos++; 
/* 135 */             pos++;
/*     */           } 
/*     */         } 
/* 138 */         pos++;
/*     */       } 
/* 140 */       int endPos = pos;
/* 141 */       String token = new String(chars, startPos, endPos - startPos + 1);
/* 142 */       if (endChar == ']') {
/* 143 */         condList.add(new ConditionInfo(token));
/*     */       } else {
/* 145 */         permList.add(new PermissionInfo(token));
/* 146 */       }  pos++;
/*     */     } 
/* 148 */     if (permList.size() == 0)
/* 149 */       throw new IllegalArgumentException("No Permission infos: " + encoded); 
/* 150 */     ConditionInfo[] conds = condList.<ConditionInfo>toArray(new ConditionInfo[condList.size()]);
/* 151 */     PermissionInfo[] perms = permList.<PermissionInfo>toArray(new PermissionInfo[permList.size()]);
/* 152 */     if (securityAdmin == null)
/* 153 */       return new SecurityRowSnapShot(encodedName, conds, perms, decision); 
/* 154 */     return new SecurityRow(securityAdmin, encodedName, conds, perms, decision);
/*     */   }
/*     */   
/*     */   static Object cloneArray(Object[] array) {
/* 158 */     if (array == null)
/* 159 */       return null; 
/* 160 */     Object result = Array.newInstance(array.getClass().getComponentType(), array.length);
/* 161 */     System.arraycopy(array, 0, result, 0, array.length);
/* 162 */     return result;
/*     */   }
/*     */   
/*     */   private static void escapeString(String str, StringBuilder output) {
/* 166 */     int len = str.length();
/* 167 */     for (int i = 0; i < len; i++) {
/* 168 */       char c = str.charAt(i);
/* 169 */       switch (c) {
/*     */         case '"':
/*     */         case '\\':
/* 172 */           output.append('\\');
/* 173 */           output.append(c);
/*     */           break;
/*     */         case '\r':
/* 176 */           output.append("\\r");
/*     */           break;
/*     */         case '\n':
/* 179 */           output.append("\\n");
/*     */           break;
/*     */         default:
/* 182 */           output.append(c);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String unescapeString(String str) {
/* 189 */     StringBuilder output = new StringBuilder(str.length());
/* 190 */     int end = str.length();
/* 191 */     for (int i = 0; i < end; i++) {
/* 192 */       char c = str.charAt(i);
/*     */       
/* 194 */       i++;
/* 195 */       if (c == '\\' && i < end) {
/* 196 */         c = str.charAt(i);
/* 197 */         switch (c) {
/*     */           case '"':
/*     */           case '\\':
/*     */             break;
/*     */           case 'r':
/* 202 */             c = '\r';
/*     */             break;
/*     */           case 'n':
/* 205 */             c = '\n';
/*     */             break;
/*     */           default:
/* 208 */             c = '\\';
/* 209 */             i--;
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/* 214 */       output.append(c);
/*     */     } 
/*     */     
/* 217 */     return output.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 222 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConditionInfo[] getConditionInfos() {
/* 228 */     return (ConditionInfo[])cloneArray((Object[])this.conditionInfos);
/*     */   }
/*     */   
/*     */   ConditionInfo[] internalGetConditionInfos() {
/* 232 */     return this.conditionInfos;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAccessDecision() {
/* 237 */     return this.deny ? "deny" : "allow";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionInfo[] getPermissionInfos() {
/* 243 */     return (PermissionInfo[])cloneArray((Object[])this.permissionInfoCollection.getPermissionInfos());
/*     */   }
/*     */   
/*     */   PermissionInfo[] internalGetPermissionInfos() {
/* 247 */     return this.permissionInfoCollection.getPermissionInfos();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete() {
/* 255 */     this.securityAdmin.delete(this, true);
/*     */   }
/*     */   
/*     */   Condition[] getConditions(BundlePermissions bundlePermissions) {
/* 259 */     synchronized (this.bundleConditionsLock) {
/* 260 */       Condition[] conditions = null;
/* 261 */       if (this.bundleConditions != null) {
/* 262 */         conditions = this.bundleConditions.get(bundlePermissions);
/*     */       }
/* 264 */       if (conditions == null) {
/* 265 */         conditions = new Condition[this.conditionInfos.length];
/* 266 */         for (int i = 0; i < this.conditionInfos.length; i++) {
/*     */           Class<?> clazz;
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 272 */             clazz = Class.forName(this.conditionInfos[i].getType());
/* 273 */           } catch (ClassNotFoundException classNotFoundException) {
/*     */             
/* 275 */             return null;
/*     */           } 
/* 277 */           Constructor<?> constructor = null;
/* 278 */           Method method = getConditionMethod(clazz);
/* 279 */           if (method == null) {
/* 280 */             constructor = getConditionConstructor(clazz);
/* 281 */             if (constructor == null) {
/*     */               
/* 283 */               conditions[i] = Condition.FALSE;
/*     */               
/*     */               continue;
/*     */             } 
/*     */           } 
/* 288 */           Object[] args = { bundlePermissions.getBundle(), this.conditionInfos[i] };
/*     */           try {
/* 290 */             if (method != null)
/* 291 */             { conditions[i] = (Condition)method.invoke(null, args); }
/*     */             else
/* 293 */             { conditions[i] = (Condition)constructor.newInstance(args); } 
/* 294 */           } catch (Exception exception) {
/*     */             
/* 296 */             conditions[i] = Condition.FALSE;
/*     */           }  continue;
/*     */         } 
/* 299 */         if (this.bundleConditions != null) {
/* 300 */           this.bundleConditions.put(bundlePermissions, conditions);
/*     */         }
/*     */       } 
/* 303 */       return conditions;
/*     */     } 
/*     */   } private Method getConditionMethod(Class<?> clazz) { byte b;
/*     */     int i;
/*     */     Method[] arrayOfMethod;
/* 308 */     for (i = (arrayOfMethod = clazz.getMethods()).length, b = 0; b < i; ) { Method checkMethod = arrayOfMethod[b];
/* 309 */       if (checkMethod.getName().equals("getCondition") && (
/* 310 */         checkMethod.getModifiers() & 0x8) == 8 && 
/* 311 */         checkParameterTypes(checkMethod.getParameterTypes()))
/* 312 */         return checkMethod; 
/*     */       b++; }
/*     */     
/* 315 */     return null; } private Constructor<?> getConditionConstructor(Class<?> clazz) {
/*     */     byte b;
/*     */     int i;
/*     */     Constructor[] arrayOfConstructor;
/* 319 */     for (i = (arrayOfConstructor = (Constructor[])clazz.getConstructors()).length, b = 0; b < i; ) { Constructor<?> checkConstructor = arrayOfConstructor[b];
/* 320 */       if (checkParameterTypes(checkConstructor.getParameterTypes()))
/* 321 */         return checkConstructor; 
/*     */       b++; }
/*     */     
/* 324 */     return null;
/*     */   }
/*     */   
/*     */   private boolean checkParameterTypes(Class[] foundTypes) {
/* 328 */     if (foundTypes.length != conditionMethodArgs.length) {
/* 329 */       return false;
/*     */     }
/*     */     
/* 332 */     for (int i = 0; i < foundTypes.length; i++) {
/* 333 */       if (!foundTypes[i].isAssignableFrom(conditionMethodArgs[i])) {
/* 334 */         return false;
/*     */       }
/*     */     } 
/* 337 */     return true;
/*     */   }
/*     */   Decision evaluate(BundlePermissions bundlePermissions, Permission permission) {
/*     */     int j;
/* 341 */     if (this.bundleConditions == null || bundlePermissions == null)
/* 342 */       return evaluatePermission(bundlePermissions, permission); 
/* 343 */     Condition[] conditions = getConditions(bundlePermissions);
/* 344 */     if (conditions == ABSTAIN_LIST)
/* 345 */       return DECISION_ABSTAIN; 
/* 346 */     if (conditions == SATISFIED_LIST) {
/* 347 */       return evaluatePermission(bundlePermissions, permission);
/*     */     }
/* 349 */     boolean empty = true;
/* 350 */     List<Condition> postponedConditions = null;
/* 351 */     Decision postponedPermCheck = null;
/* 352 */     for (int i = 0; i < conditions.length; i++) {
/* 353 */       Condition condition = conditions[i];
/* 354 */       if (condition != null) {
/*     */         
/* 356 */         if (!isPostponed(condition)) {
/*     */           
/* 358 */           boolean mutable = condition.isMutable();
/* 359 */           if (condition.isSatisfied()) {
/* 360 */             if (!mutable)
/* 361 */               conditions[i] = null; 
/*     */           } else {
/* 363 */             if (!mutable)
/*     */             {
/* 365 */               synchronized (this.bundleConditionsLock) {
/* 366 */                 this.bundleConditions.put(bundlePermissions, ABSTAIN_LIST);
/*     */               }  } 
/* 368 */             return DECISION_ABSTAIN;
/*     */           } 
/*     */         } else {
/* 371 */           if (postponedPermCheck == null)
/*     */           {
/* 373 */             postponedPermCheck = evaluatePermission(bundlePermissions, permission); } 
/* 374 */           if (postponedPermCheck == DECISION_ABSTAIN) {
/* 375 */             return postponedPermCheck;
/*     */           }
/* 377 */           if (postponedConditions == null)
/* 378 */             postponedConditions = new ArrayList<>(1); 
/* 379 */           postponedConditions.add(condition);
/*     */         } 
/* 381 */         j = empty & ((conditions[i] == null) ? 1 : 0);
/*     */       } 
/* 383 */     }  if (j != 0) {
/* 384 */       synchronized (this.bundleConditionsLock) {
/* 385 */         this.bundleConditions.put(bundlePermissions, SATISFIED_LIST);
/*     */       } 
/*     */     }
/* 388 */     if (postponedPermCheck != null)
/* 389 */       return new Decision(postponedPermCheck.decision | 0x8, postponedConditions.<Condition>toArray(new Condition[postponedConditions.size()]), this, bundlePermissions); 
/* 390 */     return evaluatePermission(bundlePermissions, permission);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isPostponed(Condition condition) {
/* 395 */     return (condition.isPostponed() && this.securityAdmin.getSupportedSecurityManager() != null);
/*     */   }
/*     */   
/*     */   private Decision evaluatePermission(BundlePermissions bundlePermissions, Permission permission) {
/* 399 */     return this.permissionInfoCollection.implies(bundlePermissions, permission) ? (this.deny ? DECISION_DENIED : DECISION_GRANTED) : DECISION_ABSTAIN;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 404 */     return getEncoded();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getEncoded() {
/* 409 */     return getEncoded(this.name, this.conditionInfos, internalGetPermissionInfos(), this.deny);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 415 */     if (obj == this)
/* 416 */       return true; 
/* 417 */     if (!(obj instanceof ConditionalPermissionInfo)) {
/* 418 */       return false;
/*     */     }
/* 420 */     return getEncoded().equals(((ConditionalPermissionInfo)obj).getEncoded());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 425 */     return getHashCode(this.name, internalGetConditionInfos(), internalGetPermissionInfos(), getAccessDecision());
/*     */   }
/*     */   
/*     */   static int getHashCode(String name, ConditionInfo[] conds, PermissionInfo[] perms, String decision) {
/* 429 */     int h = 527 + decision.hashCode(); byte b; int i; ConditionInfo[] arrayOfConditionInfo;
/* 430 */     for (i = (arrayOfConditionInfo = conds).length, b = 0; b < i; ) { ConditionInfo cond = arrayOfConditionInfo[b];
/* 431 */       h = 31 * h + cond.hashCode(); b++; }
/*     */      PermissionInfo[] arrayOfPermissionInfo;
/* 433 */     for (i = (arrayOfPermissionInfo = perms).length, b = 0; b < i; ) { PermissionInfo perm = arrayOfPermissionInfo[b];
/* 434 */       h = 31 * h + perm.hashCode(); b++; }
/*     */     
/* 436 */     if (name != null)
/* 437 */       h = 31 * h + name.hashCode(); 
/* 438 */     return h;
/*     */   }
/*     */   
/*     */   static String getEncoded(String name, ConditionInfo[] conditionInfos, PermissionInfo[] permissionInfos, boolean deny) {
/* 442 */     StringBuilder result = new StringBuilder();
/* 443 */     if (deny) {
/* 444 */       result.append("deny");
/*     */     } else {
/* 446 */       result.append("allow");
/* 447 */     }  result.append(" { ");
/* 448 */     if (conditionInfos != null) {
/* 449 */       byte b; int i; ConditionInfo[] arrayOfConditionInfo; for (i = (arrayOfConditionInfo = conditionInfos).length, b = 0; b < i; ) { ConditionInfo conditionInfo = arrayOfConditionInfo[b];
/* 450 */         result.append(conditionInfo.getEncoded()).append(' '); b++; }
/*     */     
/* 452 */     }  if (permissionInfos != null) {
/* 453 */       byte b; int i; PermissionInfo[] arrayOfPermissionInfo; for (i = (arrayOfPermissionInfo = permissionInfos).length, b = 0; b < i; ) { PermissionInfo permissionInfo = arrayOfPermissionInfo[b];
/* 454 */         result.append(permissionInfo.getEncoded()).append(' '); b++; }
/*     */     
/* 456 */     }  result.append('}');
/* 457 */     if (name != null) {
/* 458 */       result.append(" \"");
/* 459 */       escapeString(name, result);
/* 460 */       result.append('"');
/*     */     } 
/* 462 */     return result.toString();
/*     */   }
/*     */   
/*     */   PermissionInfoCollection getPermissionInfoCollection() {
/* 466 */     return this.permissionInfoCollection;
/*     */   }
/*     */   
/*     */   void clearCaches() {
/* 470 */     this.permissionInfoCollection.clearPermissionCache();
/* 471 */     if (this.bundleConditions != null)
/* 472 */       synchronized (this.bundleConditionsLock) {
/* 473 */         this.bundleConditions.clear();
/*     */       }  
/*     */   }
/*     */   
/*     */   static class Decision {
/*     */     final int decision;
/*     */     final Condition[] postponed;
/*     */     private final SecurityRow row;
/*     */     private final BundlePermissions bundlePermissions;
/*     */     
/*     */     Decision(int decision, Condition[] postponed, SecurityRow row, BundlePermissions bundlePermissions) {
/* 484 */       this.decision = decision;
/* 485 */       this.postponed = postponed;
/* 486 */       this.row = row;
/* 487 */       this.bundlePermissions = bundlePermissions;
/*     */     }
/*     */     
/*     */     void handleImmutable(Condition condition, boolean isSatisfied, boolean mutable) {
/* 491 */       if (mutable || !condition.isPostponed())
/*     */         return; 
/* 493 */       if (isSatisfied) {
/* 494 */         synchronized (this.row.bundleConditionsLock) {
/* 495 */           int j; Condition[] rowConditions = this.row.bundleConditions.get(this.bundlePermissions);
/* 496 */           boolean isEmpty = true;
/* 497 */           for (int i = 0; i < rowConditions.length; i++) {
/* 498 */             if (rowConditions[i] == condition && 
/* 499 */               isSatisfied)
/* 500 */               rowConditions[i] = null; 
/* 501 */             j = isEmpty & ((rowConditions[i] == null) ? 1 : 0);
/*     */           } 
/* 503 */           if (j != 0)
/* 504 */             this.row.bundleConditions.put(this.bundlePermissions, SecurityRow.SATISFIED_LIST); 
/*     */         } 
/*     */       } else {
/* 507 */         synchronized (this.row.bundleConditionsLock) {
/* 508 */           this.row.bundleConditions.put(this.bundlePermissions, SecurityRow.ABSTAIN_LIST);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\permadmin\SecurityRow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */