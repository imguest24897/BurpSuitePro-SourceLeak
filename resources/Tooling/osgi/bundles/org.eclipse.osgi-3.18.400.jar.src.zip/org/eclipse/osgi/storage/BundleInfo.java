/*     */ package org.eclipse.osgi.storage;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.eclipse.osgi.container.Module;
/*     */ import org.eclipse.osgi.container.ModuleContainer;
/*     */ import org.eclipse.osgi.container.ModuleContainerAdaptor;
/*     */ import org.eclipse.osgi.container.ModuleRevision;
/*     */ import org.eclipse.osgi.container.ModuleRevisionBuilder;
/*     */ import org.eclipse.osgi.framework.internal.reliablefile.ReliableFile;
/*     */ import org.eclipse.osgi.framework.util.CaseInsensitiveDictionaryMap;
/*     */ import org.eclipse.osgi.framework.util.ThreadInfoReport;
/*     */ import org.eclipse.osgi.internal.connect.ConnectBundleFile;
/*     */ import org.eclipse.osgi.internal.container.LockSet;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.hookregistry.StorageHookFactory;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFile;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFileWrapperChain;
/*     */ import org.eclipse.osgi.storage.url.bundleentry.Handler;
/*     */ import org.eclipse.osgi.util.ManifestElement;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.framework.connect.ConnectModule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BundleInfo
/*     */ {
/*     */   public static final String OSGI_BUNDLE_MANIFEST = "META-INF/MANIFEST.MF";
/*     */   public static final String MULTI_RELEASE_HEADER = "Multi-Release";
/*     */   public static final String MULTI_RELEASE_VERSIONS = "META-INF/versions/";
/*  69 */   public static final Collection<String> MULTI_RELEASE_FILTER_PREFIXES = Collections.singleton("META-INF/"); private final Storage storage; private final long bundleId;
/*     */   private final String location;
/*     */   private long nextGenerationId;
/*     */   
/*  73 */   public final class Generation { private final Object genMonitor = new Object(); private final long generationId;
/*     */     private final Dictionary<String, String> cachedHeaders;
/*     */     private File content;
/*     */     private boolean isDirectory;
/*     */     private boolean hasPackageInfo;
/*     */     private BundleFile bundleFile;
/*     */     private Map<String, String> rawHeaders;
/*     */     private ModuleRevision revision;
/*     */     private ManifestLocalization headerLocalization;
/*     */     private ProtectionDomain domain;
/*     */     private NativeCodeFinder nativeCodeFinder;
/*     */     private List<StorageHookFactory.StorageHook<?, ?>> storageHooks;
/*     */     private long lastModified;
/*     */     private boolean isMRJar;
/*     */     private ContentProvider.Type contentType;
/*     */     
/*     */     Generation(long generationId) {
/*  90 */       this.generationId = generationId;
/*  91 */       this.cachedHeaders = new BundleInfo.CachedManifest(this, Collections.emptyMap());
/*     */     }
/*     */     
/*     */     Generation(long generationId, File content, boolean isDirectory, ContentProvider.Type contentType, boolean hasPackageInfo, Map<String, String> cached, long lastModified, boolean isMRJar) {
/*  95 */       this.generationId = generationId;
/*  96 */       this.content = content;
/*  97 */       this.isDirectory = isDirectory;
/*  98 */       this.contentType = contentType;
/*  99 */       this.hasPackageInfo = hasPackageInfo;
/* 100 */       this.cachedHeaders = new BundleInfo.CachedManifest(this, cached);
/* 101 */       this.lastModified = lastModified;
/* 102 */       this.isMRJar = isMRJar;
/*     */     }
/*     */     
/*     */     public BundleFile getBundleFile() {
/* 106 */       synchronized (this.genMonitor) {
/* 107 */         if (this.bundleFile == null) {
/* 108 */           if (BundleInfo.this.getBundleId() == 0L && this.content == null && this.contentType != ContentProvider.Type.CONNECT) {
/* 109 */             this.bundleFile = new SystemBundleFile();
/*     */           } else {
/* 111 */             this.bundleFile = BundleInfo.this.getStorage().createBundleFile(this.content, this, this.isDirectory, true);
/*     */           } 
/*     */         }
/* 114 */         return this.bundleFile;
/*     */       } 
/*     */     }
/*     */     
/*     */     public void close() {
/* 119 */       synchronized (this.genMonitor) {
/* 120 */         if (this.bundleFile != null) {
/*     */           try {
/* 122 */             this.bundleFile.close();
/* 123 */           } catch (IOException iOException) {}
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Dictionary<String, String> getHeaders() {
/* 131 */       return this.cachedHeaders;
/*     */     }
/*     */     
/*     */     Map<String, String> getRawHeaders() {
/* 135 */       synchronized (this.genMonitor) {
/* 136 */         if (this.rawHeaders == null) {
/* 137 */           BundleFile bFile = getBundleFile();
/*     */           
/* 139 */           if (this.contentType == ContentProvider.Type.CONNECT) {
/* 140 */             ConnectBundleFile connectContent = (bFile instanceof BundleFileWrapperChain) ? 
/* 141 */               (ConnectBundleFile)((BundleFileWrapperChain)bFile).getWrappedType(ConnectBundleFile.class) : 
/* 142 */               (ConnectBundleFile)bFile;
/*     */             
/* 144 */             Map<String, String> connectHeaders = connectContent.getConnectHeaders();
/* 145 */             if (connectHeaders != null) {
/* 146 */               return this.rawHeaders = connectHeaders;
/*     */             }
/*     */           } 
/*     */           
/* 150 */           BundleEntry manifest = bFile.getEntry("META-INF/MANIFEST.MF");
/* 151 */           if (manifest == null) {
/* 152 */             this.rawHeaders = Collections.emptyMap();
/*     */           } else {
/*     */             try {
/* 155 */               Map<String, String> merged = ManifestElement.parseBundleManifest(manifest.getInputStream(), (Map)new CaseInsensitiveDictionaryMap());
/*     */               
/* 157 */               if (Boolean.parseBoolean(merged.get("Multi-Release"))) {
/* 158 */                 for (int i = BundleInfo.this.getStorage().getRuntimeVersion().getMajor(); i > 8; i--) {
/* 159 */                   String versionManifest = "META-INF/versions/" + i + "/OSGI-INF/MANIFEST.MF";
/* 160 */                   BundleEntry versionEntry = getBundleFile().getEntry(versionManifest);
/* 161 */                   if (versionEntry != null) {
/* 162 */                     Map<String, String> versioned = ManifestElement.parseBundleManifest(versionEntry.getInputStream(), (Map)new CaseInsensitiveDictionaryMap());
/* 163 */                     String versionedImport = versioned.get("Import-Package");
/* 164 */                     String versionedRequireCap = versioned.get("Require-Capability");
/* 165 */                     if (versionedImport != null) {
/* 166 */                       merged.put("Import-Package", versionedImport);
/*     */                     }
/* 168 */                     if (versionedRequireCap != null) {
/* 169 */                       merged.put("Require-Capability", versionedRequireCap);
/*     */                     }
/*     */                     
/*     */                     break;
/*     */                   } 
/*     */                 } 
/*     */               }
/* 176 */               this.rawHeaders = Collections.unmodifiableMap(merged);
/* 177 */             } catch (RuntimeException e) {
/* 178 */               throw e;
/* 179 */             } catch (Exception e) {
/* 180 */               throw new RuntimeException("Error occurred getting the bundle manifest.", e);
/*     */             } 
/*     */           } 
/*     */         } 
/* 184 */         return this.rawHeaders;
/*     */       } 
/*     */     }
/*     */     
/*     */     public Dictionary<String, String> getHeaders(String locale) {
/* 189 */       ManifestLocalization current = getManifestLocalization();
/* 190 */       return current.getHeaders(locale);
/*     */     }
/*     */     
/*     */     public ResourceBundle getResourceBundle(String locale) {
/* 194 */       ManifestLocalization current = getManifestLocalization();
/* 195 */       String defaultLocale = Locale.getDefault().toString();
/* 196 */       if (locale == null) {
/* 197 */         locale = defaultLocale;
/*     */       }
/* 199 */       return current.getResourceBundle(locale, defaultLocale.equals(locale));
/*     */     }
/*     */     
/*     */     private ManifestLocalization getManifestLocalization() {
/* 203 */       synchronized (this.genMonitor) {
/* 204 */         if (this.headerLocalization == null) {
/* 205 */           this.headerLocalization = new ManifestLocalization(this, getHeaders(), BundleInfo.this.getStorage().getConfiguration().getConfiguration("equinox.root.locale", "en"));
/*     */         }
/* 207 */         return this.headerLocalization;
/*     */       } 
/*     */     }
/*     */     
/*     */     public void clearManifestCache() {
/* 212 */       synchronized (this.genMonitor) {
/* 213 */         if (this.headerLocalization != null) {
/* 214 */           this.headerLocalization.clearCache();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public long getGenerationId() {
/* 220 */       return this.generationId;
/*     */     }
/*     */     
/*     */     public long getLastModified() {
/* 224 */       return this.lastModified;
/*     */     }
/*     */     
/*     */     public boolean isDirectory() {
/* 228 */       synchronized (this.genMonitor) {
/* 229 */         return this.isDirectory;
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean hasPackageInfo() {
/* 234 */       synchronized (this.genMonitor) {
/* 235 */         return this.hasPackageInfo;
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean isMRJar() {
/* 240 */       synchronized (this.genMonitor) {
/* 241 */         return this.isMRJar;
/*     */       } 
/*     */     }
/*     */     
/*     */     public File getContent() {
/* 246 */       synchronized (this.genMonitor) {
/* 247 */         return this.content;
/*     */       } 
/*     */     }
/*     */     
/*     */     public ContentProvider.Type getContentType() {
/* 252 */       synchronized (this.genMonitor) {
/* 253 */         return this.contentType;
/*     */       } 
/*     */     }
/*     */     
/*     */     void setContent(File content, ContentProvider.Type contentType) {
/* 258 */       if (BundleInfo.this.getBundleId() == 0L) {
/*     */         
/* 260 */         ConnectModule connected = BundleInfo.this.getStorage().getEquinoxContainer().getConnectModules().connect(BundleInfo.this.getLocation());
/* 261 */         if (connected != null) {
/* 262 */           content = null;
/* 263 */           contentType = ContentProvider.Type.CONNECT;
/*     */         } 
/*     */       } 
/* 266 */       synchronized (this.genMonitor) {
/* 267 */         this.content = content;
/* 268 */         this.isDirectory = (content != null && Storage.secureAction.isDirectory(content));
/* 269 */         this.contentType = contentType;
/* 270 */         setLastModified(content);
/*     */       } 
/*     */     }
/*     */     
/*     */     private void setLastModified(File content) {
/* 275 */       if (content == null) {
/*     */         
/* 277 */         this.lastModified = 0L;
/*     */         return;
/*     */       } 
/* 280 */       if (this.isDirectory)
/* 281 */         content = new File(content, "META-INF/MANIFEST.MF"); 
/* 282 */       this.lastModified = Storage.secureAction.lastModified(content);
/*     */     }
/*     */     
/*     */     void setStorageHooks(List<StorageHookFactory.StorageHook<?, ?>> storageHooks, boolean install) {
/* 286 */       synchronized (this.genMonitor) {
/* 287 */         this.storageHooks = storageHooks;
/* 288 */         if (install) {
/* 289 */           this.hasPackageInfo = BundleInfo.hasPackageInfo(getBundleFile());
/* 290 */           this.isMRJar = Boolean.parseBoolean(getRawHeaders().get("Multi-Release"));
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public <S, L, H extends StorageHookFactory.StorageHook<S, L>> H getStorageHook(Class<? extends StorageHookFactory<S, L, H>> factoryClass) {
/* 297 */       synchronized (this.genMonitor) {
/* 298 */         if (this.storageHooks == null)
/* 299 */           return null; 
/* 300 */         for (StorageHookFactory.StorageHook<?, ?> hook : this.storageHooks) {
/* 301 */           if (hook.getFactoryClass().equals(factoryClass)) {
/* 302 */             return (H)hook;
/*     */           }
/*     */         } 
/*     */       } 
/* 306 */       return null;
/*     */     }
/*     */     
/*     */     public ModuleRevision getRevision() {
/* 310 */       synchronized (this.genMonitor) {
/* 311 */         return this.revision;
/*     */       } 
/*     */     }
/*     */     
/*     */     public void setRevision(ModuleRevision revision) {
/* 316 */       synchronized (this.genMonitor) {
/* 317 */         this.revision = revision;
/*     */       } 
/*     */     }
/*     */     
/*     */     public ProtectionDomain getDomain() {
/* 322 */       return getDomain(true);
/*     */     }
/*     */     
/*     */     public ProtectionDomain getDomain(boolean create) {
/* 326 */       if (BundleInfo.this.getBundleId() == 0L || System.getSecurityManager() == null) {
/* 327 */         return null;
/*     */       }
/* 329 */       synchronized (this.genMonitor) {
/* 330 */         if (this.domain == null && create) {
/* 331 */           if (this.revision == null) {
/* 332 */             throw new IllegalStateException("The revision is not yet set for this generation.");
/*     */           }
/* 334 */           this.domain = BundleInfo.this.getStorage().getSecurityAdmin().createProtectionDomain(this.revision.getBundle());
/*     */         } 
/* 336 */         return this.domain;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public File getExtractFile(String path) {
/* 350 */       return getExtractFile(null, path);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public File getExtractFile(String base, String path) {
/* 365 */       StringBuilder baseBuilder = new StringBuilder();
/* 366 */       baseBuilder.append(BundleInfo.this.getBundleId()).append('/').append(getGenerationId());
/* 367 */       if (base != null) {
/* 368 */         baseBuilder.append('/').append(base);
/*     */       }
/*     */       
/* 371 */       return BundleInfo.this.getStorage().getFile(baseBuilder.toString(), path, true);
/*     */     }
/*     */ 
/*     */     
/*     */     public void storeContent(File destination, InputStream in, boolean nativeCode) throws IOException {
/* 376 */       if ((BundleInfo.this.getStorage().getConfiguration().getDebug()).DEBUG_STORAGE) {
/* 377 */         Debug.println("Creating file: " + destination.getPath());
/*     */       }
/* 379 */       File dir = new File(destination.getParent());
/* 380 */       if (!dir.mkdirs() && !dir.isDirectory()) {
/* 381 */         if ((BundleInfo.this.getStorage().getConfiguration().getDebug()).DEBUG_STORAGE)
/* 382 */           Debug.println("Unable to create directory: " + dir.getPath()); 
/* 383 */         throw new IOException(NLS.bind(Msg.ADAPTOR_DIRECTORY_CREATE_EXCEPTION, dir.getAbsolutePath()));
/*     */       } 
/*     */       
/* 386 */       File tempDest = ReliableFile.createTempFile("staged", ".tmp", dir);
/* 387 */       StorageUtil.readFile(in, tempDest);
/* 388 */       if (destination.exists()) {
/*     */ 
/*     */         
/* 391 */         tempDest.delete();
/*     */       } else {
/* 393 */         StorageUtil.move(tempDest, destination, (BundleInfo.this.getStorage().getConfiguration().getDebug()).DEBUG_STORAGE);
/*     */       } 
/* 395 */       if (nativeCode) {
/* 396 */         getBundleInfo().getStorage().setPermissions(destination);
/*     */       }
/*     */     }
/*     */     
/*     */     public BundleInfo getBundleInfo() {
/* 401 */       return BundleInfo.this;
/*     */     }
/*     */     
/*     */     public void delete() {
/* 405 */       List<StorageHookFactory.StorageHook<?, ?>> hooks = getStorageHooks();
/* 406 */       if (hooks != null) {
/* 407 */         for (StorageHookFactory.StorageHook<?, ?> hook : hooks) {
/* 408 */           hook.deletingGeneration();
/*     */         }
/*     */       }
/* 411 */       synchronized (this.genMonitor) {
/*     */         
/* 413 */         if (this.bundleFile != null) {
/*     */           try {
/* 415 */             this.bundleFile.close();
/* 416 */           } catch (IOException iOException) {}
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 421 */       getBundleInfo().delete(this);
/*     */     }
/*     */     
/*     */     public URL getEntry(String path) {
/* 425 */       BundleEntry entry = getBundleFile().getEntry(path);
/* 426 */       if (entry == null) {
/* 427 */         return null;
/*     */       }
/*     */       
/* 430 */       String protocol = "bundleentry";
/* 431 */       ModuleContainer container = BundleInfo.this.getStorage().getModuleContainer();
/* 432 */       Handler handler = new Handler(container, entry);
/* 433 */       return BundleFile.createURL(protocol, BundleInfo.this.getBundleId(), container, entry, 0, path, (URLStreamHandler)handler);
/*     */     }
/*     */     
/*     */     public String findLibrary(String libname) {
/*     */       NativeCodeFinder currentFinder;
/* 438 */       synchronized (this.genMonitor) {
/* 439 */         if (this.nativeCodeFinder == null) {
/* 440 */           this.nativeCodeFinder = new NativeCodeFinder(this);
/*     */         }
/* 442 */         currentFinder = this.nativeCodeFinder;
/*     */       } 
/* 444 */       return currentFinder.findLibrary(libname);
/*     */     }
/*     */     
/*     */     List<StorageHookFactory.StorageHook<?, ?>> getStorageHooks() {
/* 448 */       synchronized (this.genMonitor) {
/* 449 */         return this.storageHooks;
/*     */       } 
/*     */     }
/*     */     
/*     */     public ModuleRevisionBuilder adaptModuleRevisionBuilder(ModuleContainerAdaptor.ModuleEvent operation, Module origin, ModuleRevisionBuilder builder) {
/* 454 */       List<StorageHookFactory.StorageHook<?, ?>> hooks = getStorageHooks();
/* 455 */       if (hooks != null) {
/* 456 */         for (StorageHookFactory.StorageHook<?, ?> hook : hooks) {
/* 457 */           ModuleRevisionBuilder hookResult = hook.adaptModuleRevisionBuilder(operation, origin, builder);
/* 458 */           if (hookResult != null) {
/* 459 */             builder = hookResult;
/*     */           }
/*     */         } 
/*     */       }
/* 463 */       return builder;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 471 */   private final Object infoMonitor = new Object();
/*     */   private LockSet<Long> generationLocks;
/*     */   
/*     */   public BundleInfo(Storage storage, long bundleId, String location, long nextGenerationId) {
/* 475 */     this.storage = storage;
/* 476 */     this.bundleId = bundleId;
/* 477 */     this.location = location;
/* 478 */     this.nextGenerationId = nextGenerationId;
/*     */   }
/*     */   
/*     */   public long getBundleId() {
/* 482 */     return this.bundleId;
/*     */   }
/*     */   
/*     */   public String getLocation() {
/* 486 */     return this.location;
/*     */   }
/*     */   
/*     */   Generation createGeneration() throws BundleException {
/* 490 */     synchronized (this.infoMonitor) {
/* 491 */       boolean lockedID; if (this.generationLocks == null) {
/* 492 */         this.generationLocks = new LockSet();
/*     */       }
/*     */       
/*     */       try {
/* 496 */         lockedID = this.generationLocks.tryLock(Long.valueOf(this.nextGenerationId), 5L, TimeUnit.SECONDS);
/* 497 */       } catch (InterruptedException e) {
/* 498 */         Thread.currentThread().interrupt();
/* 499 */         throw new BundleException("Failed to obtain id locks for generation.", 7, e);
/*     */       } 
/* 501 */       if (!lockedID) {
/* 502 */         throw new BundleException("Failed to obtain id locks for generation.", 7, new ThreadInfoReport(this.generationLocks.getLockInfo(Long.valueOf(this.nextGenerationId))));
/*     */       }
/* 504 */       return new Generation(this.nextGenerationId++);
/*     */     } 
/*     */   }
/*     */   
/*     */   void unlockGeneration(Generation generation) {
/* 509 */     synchronized (this.infoMonitor) {
/* 510 */       if (this.generationLocks == null) {
/* 511 */         throw new IllegalStateException("The generation id was not locked.");
/*     */       }
/* 513 */       this.generationLocks.unlock(Long.valueOf(generation.getGenerationId()));
/*     */     } 
/*     */   }
/*     */   
/*     */   Generation restoreGeneration(long generationId, File content, boolean isDirectory, ContentProvider.Type contentType, boolean hasPackageInfo, Map<String, String> cached, long lastModified, boolean isMRJar) {
/* 518 */     synchronized (this.infoMonitor) {
/* 519 */       return new Generation(generationId, content, isDirectory, contentType, hasPackageInfo, cached, lastModified, isMRJar);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Storage getStorage() {
/* 524 */     return this.storage;
/*     */   }
/*     */   
/*     */   public void delete() {
/*     */     try {
/* 529 */       getStorage().delete(getStorage().getFile(Long.toString(getBundleId()), false));
/* 530 */     } catch (IOException e) {
/* 531 */       this.storage.getLogServices().log("org.eclipse.osgi", 2, "Error deleting bunlde info.", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   void delete(Generation generation) {
/*     */     try {
/* 537 */       getStorage().delete(getStorage().getFile(String.valueOf(getBundleId()) + "/" + generation.getGenerationId(), false));
/* 538 */     } catch (IOException e) {
/* 539 */       this.storage.getLogServices().log("org.eclipse.osgi", 2, "Error deleting generation.", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public long getNextGenerationId() {
/* 544 */     synchronized (this.infoMonitor) {
/* 545 */       return this.nextGenerationId;
/*     */     } 
/*     */   }
/*     */   
/*     */   public File getDataFile(String path) {
/* 550 */     File dataRoot = getStorage().getFile(String.valueOf(getBundleId()) + "/" + "data", false);
/* 551 */     if (!Storage.secureAction.isDirectory(dataRoot) && (this.storage.isReadOnly() || (!Storage.secureAction.mkdirs(dataRoot) && !Storage.secureAction.isDirectory(dataRoot)))) {
/* 552 */       if ((getStorage().getConfiguration().getDebug()).DEBUG_STORAGE)
/* 553 */         Debug.println("Unable to create bundle data directory: " + dataRoot.getAbsolutePath()); 
/* 554 */       return null;
/*     */     } 
/* 556 */     return (path == null) ? dataRoot : new File(dataRoot, path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean hasPackageInfo(BundleFile bundleFile) {
/* 563 */     if (bundleFile == null) {
/* 564 */       return false;
/*     */     }
/* 566 */     BundleEntry manifest = bundleFile.getEntry("META-INF/MANIFEST.MF");
/* 567 */     if (manifest == null)
/* 568 */       return false; 
/*     */     
/* 570 */     try { Exception exception1 = null, exception2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {  }
/*     */       finally
/* 589 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 592 */     return false;
/*     */   }
/*     */   
/*     */   static class CachedManifest extends Dictionary<String, String> implements Map<String, String> {
/*     */     private final Map<String, String> cached;
/*     */     private final BundleInfo.Generation generation;
/*     */     
/*     */     CachedManifest(BundleInfo.Generation generation, Map<String, String> cached) {
/* 600 */       this.generation = generation;
/* 601 */       this.cached = cached;
/*     */     }
/*     */ 
/*     */     
/*     */     public Enumeration<String> elements() {
/* 606 */       return Collections.enumeration(this.generation.getRawHeaders().values());
/*     */     }
/*     */ 
/*     */     
/*     */     public String get(Object key) {
/* 611 */       if (this.cached.containsKey(key)) {
/* 612 */         return this.cached.get(key);
/*     */       }
/* 614 */       if (!this.cached.isEmpty() && (this.generation.getBundleInfo().getStorage().getConfiguration().getDebug()).DEBUG_CACHED_MANIFEST) {
/* 615 */         Debug.println("Header key is not cached: " + key + "; for bundle: " + this.generation.getBundleInfo().getBundleId());
/*     */       }
/* 617 */       return this.generation.getRawHeaders().get(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 622 */       return this.generation.getRawHeaders().isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public Enumeration<String> keys() {
/* 627 */       return Collections.enumeration(this.generation.getRawHeaders().keySet());
/*     */     }
/*     */ 
/*     */     
/*     */     public String put(String key, String value) {
/* 632 */       return this.generation.getRawHeaders().put(key, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public String remove(Object key) {
/* 637 */       return this.generation.getRawHeaders().remove(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 642 */       return this.generation.getRawHeaders().size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsKey(Object key) {
/* 647 */       return !(!this.cached.containsKey(key) && !this.generation.getRawHeaders().containsKey(key));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsValue(Object value) {
/* 652 */       return !(!this.cached.containsValue(value) && !this.generation.getRawHeaders().containsValue(value));
/*     */     }
/*     */ 
/*     */     
/*     */     public void putAll(Map<? extends String, ? extends String> m) {
/* 657 */       this.generation.getRawHeaders().putAll(m);
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 662 */       this.generation.getRawHeaders().clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<String> keySet() {
/* 667 */       return this.generation.getRawHeaders().keySet();
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<String> values() {
/* 672 */       return this.generation.getRawHeaders().values();
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<Map.Entry<String, String>> entrySet() {
/* 677 */       return this.generation.getRawHeaders().entrySet();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\BundleInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */