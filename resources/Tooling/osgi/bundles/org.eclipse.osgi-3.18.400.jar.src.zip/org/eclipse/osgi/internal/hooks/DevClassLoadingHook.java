/*     */ package org.eclipse.osgi.internal.hooks;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import org.eclipse.osgi.container.ModuleCapability;
/*     */ import org.eclipse.osgi.framework.util.KeyedElement;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxConfiguration;
/*     */ import org.eclipse.osgi.internal.hookregistry.ClassLoaderHook;
/*     */ import org.eclipse.osgi.internal.loader.classpath.ClasspathEntry;
/*     */ import org.eclipse.osgi.internal.loader.classpath.ClasspathManager;
/*     */ import org.eclipse.osgi.internal.loader.classpath.FragmentClasspath;
/*     */ import org.eclipse.osgi.storage.BundleInfo;
/*     */ import org.eclipse.osgi.storage.ContentProvider;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFile;
/*     */ import org.osgi.framework.wiring.BundleRevision;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DevClassLoadingHook
/*     */   extends ClassLoaderHook
/*     */   implements KeyedElement
/*     */ {
/*  35 */   public static final String KEY = DevClassLoadingHook.class.getName();
/*  36 */   public static final int HASHCODE = KEY.hashCode();
/*     */   
/*     */   private static final String FRAGMENT = "@fragment@";
/*     */   private final EquinoxConfiguration configuration;
/*     */   
/*     */   public DevClassLoadingHook(EquinoxConfiguration configuration) {
/*  42 */     this.configuration = configuration;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addClassPathEntry(ArrayList<ClasspathEntry> cpEntries, String cp, ClasspathManager hostmanager, BundleInfo.Generation sourceGeneration) {
/*  48 */     if (sourceGeneration.getContentType() == ContentProvider.Type.CONNECT) {
/*  49 */       return false;
/*     */     }
/*     */     
/*  52 */     String[] devClassPaths = !this.configuration.inDevelopmentMode() ? null : this.configuration.getDevClassPath((BundleRevision)sourceGeneration.getRevision());
/*  53 */     if (devClassPaths == null || devClassPaths.length == 0) {
/*  54 */       return false;
/*     */     }
/*  56 */     if (!cpEntries.isEmpty() && ((ClasspathEntry)cpEntries.get(0)).getUserObject(KEY) != null) {
/*  57 */       return false;
/*     */     }
/*     */     
/*  60 */     List<ModuleCapability> moduleDatas = sourceGeneration.getRevision().getModuleCapabilities("equinox.module.data");
/*     */     
/*  62 */     List<String> specifiedCP = Optional.<List<String>>ofNullable(moduleDatas.isEmpty() ? 
/*     */         
/*  64 */         null : 
/*  65 */         (List<String>)((ModuleCapability)moduleDatas.get(0)).getAttributes().get("classpath"))
/*  66 */       .orElse(Collections.singletonList("."));
/*  67 */     boolean result = false; byte b; int i; String[] arrayOfString1;
/*  68 */     for (i = (arrayOfString1 = devClassPaths).length, b = 0; b < i; ) { String devClassPath = arrayOfString1[b];
/*  69 */       if (!specifiedCP.contains(devClassPath))
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*  74 */         if (hostmanager.addClassPathEntry(cpEntries, devClassPath, hostmanager, sourceGeneration)) {
/*  75 */           result = true;
/*     */         } else {
/*  77 */           String devCP = devClassPath;
/*  78 */           boolean fromFragment = devCP.endsWith("@fragment@");
/*  79 */           if (!fromFragment && devCP.indexOf("..") >= 0) {
/*     */             
/*  81 */             File base = sourceGeneration.getBundleFile().getBaseFile();
/*  82 */             if (base != null && base.isDirectory()) {
/*     */               
/*  84 */               ClasspathEntry entry = hostmanager.getExternalClassPath((new File(base, devCP)).getAbsolutePath(), sourceGeneration);
/*  85 */               if (entry != null) {
/*  86 */                 cpEntries.add(entry);
/*  87 */                 result = true;
/*     */               }
/*     */             
/*     */             } 
/*     */           } else {
/*     */             
/*  93 */             if (fromFragment)
/*  94 */               devCP = devCP.substring(0, devCP.length() - "@fragment@".length()); 
/*  95 */             BundleInfo.Generation fragSource = findFragmentSource(sourceGeneration, devCP, hostmanager, fromFragment);
/*  96 */             if (fragSource != null) {
/*  97 */               ClasspathEntry entry = hostmanager.getExternalClassPath(devCP, fragSource);
/*  98 */               if (entry != null) {
/*  99 */                 cpEntries.add(entry);
/* 100 */                 result = true;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */       b++; }
/*     */     
/* 108 */     if (result && !cpEntries.isEmpty())
/* 109 */       ((ClasspathEntry)cpEntries.get(0)).addUserObject(this); 
/* 110 */     return result;
/*     */   }
/*     */   
/*     */   private BundleInfo.Generation findFragmentSource(BundleInfo.Generation hostGeneration, String cp, ClasspathManager manager, boolean fromFragment) {
/* 114 */     if (hostGeneration != manager.getGeneration()) {
/* 115 */       return hostGeneration;
/*     */     }
/* 117 */     File file = new File(cp);
/* 118 */     if (!file.isAbsolute())
/* 119 */       return hostGeneration; 
/* 120 */     FragmentClasspath[] fragCPs = manager.getFragmentClasspaths(); byte b; int i; FragmentClasspath[] arrayOfFragmentClasspath1;
/* 121 */     for (i = (arrayOfFragmentClasspath1 = fragCPs).length, b = 0; b < i; ) { FragmentClasspath fragCP = arrayOfFragmentClasspath1[b];
/* 122 */       BundleFile fragBase = fragCP.getGeneration().getBundleFile();
/* 123 */       File fragFile = fragBase.getBaseFile();
/* 124 */       if (fragFile != null && file.getPath().startsWith(fragFile.getPath()))
/* 125 */         return fragCP.getGeneration(); 
/*     */       b++; }
/*     */     
/* 128 */     return fromFragment ? null : hostGeneration;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean compare(KeyedElement other) {
/* 133 */     return (other.getKey() == KEY);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getKey() {
/* 138 */     return KEY;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getKeyHashCode() {
/* 143 */     return HASHCODE;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isProcessClassRecursionSupported() {
/* 148 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\hooks\DevClassLoadingHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */