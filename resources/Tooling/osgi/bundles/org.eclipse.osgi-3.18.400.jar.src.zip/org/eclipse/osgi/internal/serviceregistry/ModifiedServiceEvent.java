/*    */ package org.eclipse.osgi.internal.serviceregistry;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.osgi.framework.Filter;
/*    */ import org.osgi.framework.ServiceEvent;
/*    */ import org.osgi.framework.ServiceReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ModifiedServiceEvent
/*    */   extends ServiceEvent
/*    */ {
/*    */   private static final long serialVersionUID = -5373850978543026102L;
/*    */   private final ServiceEvent modified;
/*    */   private final ServiceEvent modifiedEndMatch;
/*    */   private final Map<String, Object> previousProperties;
/*    */   
/*    */   ModifiedServiceEvent(ServiceReference<?> reference, Map<String, Object> previousProperties) {
/* 37 */     super(2, reference);
/* 38 */     this.modified = new ServiceEvent(2, reference);
/* 39 */     this.modifiedEndMatch = new ServiceEvent(8, reference);
/* 40 */     this.previousProperties = previousProperties;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ServiceEvent getModifiedEvent() {
/* 49 */     return this.modified;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ServiceEvent getModifiedEndMatchEvent() {
/* 58 */     return this.modifiedEndMatch;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean matchPreviousProperties(Filter filter) {
/* 73 */     return filter.matches(this.previousProperties);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\serviceregistry\ModifiedServiceEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */