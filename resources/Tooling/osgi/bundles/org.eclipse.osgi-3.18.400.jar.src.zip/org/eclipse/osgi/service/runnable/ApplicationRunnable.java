package org.eclipse.osgi.service.runnable;

public interface ApplicationRunnable extends ParameterizedRunnable {
  void stop();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\runnable\ApplicationRunnable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */