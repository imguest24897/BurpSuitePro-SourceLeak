/*     */ package org.eclipse.osgi.report.resolution;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.osgi.resource.Resource;
/*     */ import org.osgi.service.resolver.ResolutionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ResolutionReport
/*     */ {
/*     */   Map<Resource, List<Entry>> getEntries();
/*     */   
/*     */   ResolutionException getResolutionException();
/*     */   
/*     */   String getResolutionReportMessage(Resource paramResource);
/*     */   
/*     */   public static interface Entry
/*     */   {
/*     */     Object getData();
/*     */     
/*     */     Type getType();
/*     */     
/*     */     public enum Type
/*     */     {
/*  94 */       FILTERED_BY_RESOLVER_HOOK,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 101 */       MISSING_CAPABILITY,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 108 */       SINGLETON_SELECTION,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 116 */       UNRESOLVED_PROVIDER,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 123 */       USES_CONSTRAINT_VIOLATION;
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface Listener {
/*     */     void handleResolutionReport(ResolutionReport param1ResolutionReport);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\report\resolution\ResolutionReport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */