/*    */ package org.eclipse.osgi.internal.provisional.service.security;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.eclipse.osgi.framework.eventmgr.EventDispatcher;
/*    */ import org.eclipse.osgi.framework.eventmgr.EventManager;
/*    */ import org.eclipse.osgi.framework.eventmgr.ListenerQueue;
/*    */ import org.eclipse.osgi.signedcontent.SignedContent;
/*    */ import org.osgi.framework.BundleContext;
/*    */ import org.osgi.util.tracker.ServiceTracker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AuthorizationEngine
/*    */ {
/* 31 */   private EventManager manager = new EventManager();
/* 32 */   private EventDispatcher<AuthorizationListener, Object, AuthorizationEvent> dispatcher = new AuthEventDispatcher();
/*    */   private final ServiceTracker<AuthorizationListener, AuthorizationListener> listenerTracker;
/*    */   
/*    */   public AuthorizationEngine(BundleContext context) {
/* 36 */     this.listenerTracker = new ServiceTracker(context, AuthorizationListener.class.getName(), null);
/* 37 */     this.listenerTracker.open();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void authorize(SignedContent content, Object context) {
/* 49 */     fireEvent(doAuthorize(content, context));
/*    */   }
/*    */   
/*    */   private void fireEvent(AuthorizationEvent event) {
/* 53 */     if (event == null)
/*    */       return; 
/* 55 */     Object[] services = this.listenerTracker.getServices();
/* 56 */     if (services == null)
/*    */       return; 
/* 58 */     Map<AuthorizationListener, Object> listeners = new HashMap<>(); byte b; int i; Object[] arrayOfObject1;
/* 59 */     for (i = (arrayOfObject1 = services).length, b = 0; b < i; ) { Object service = arrayOfObject1[b];
/* 60 */       listeners.put((AuthorizationListener)service, service); b++; }
/*    */     
/* 62 */     ListenerQueue<AuthorizationListener, Object, AuthorizationEvent> queue = new ListenerQueue(this.manager);
/* 63 */     queue.queueListeners(listeners.entrySet(), this.dispatcher);
/* 64 */     queue.dispatchEventSynchronous(0, event);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract AuthorizationEvent doAuthorize(SignedContent paramSignedContent, Object paramObject);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract int getStatus();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   class AuthEventDispatcher
/*    */     implements EventDispatcher<AuthorizationListener, Object, AuthorizationEvent>
/*    */   {
/*    */     public void dispatchEvent(AuthorizationListener eventListener, Object listenerObject, int eventAction, AuthorizationEvent eventObject) {
/* 89 */       eventListener.authorizationEvent(eventObject);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\provisional\service\security\AuthorizationEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */