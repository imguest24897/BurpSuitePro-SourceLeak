/*     */ package org.eclipse.osgi.internal.log;
/*     */ 
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.eclipse.equinox.log.Logger;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.service.log.LogLevel;
/*     */ import org.osgi.service.log.Logger;
/*     */ import org.osgi.service.log.LoggerConsumer;
/*     */ import org.osgi.service.log.admin.LoggerContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggerImpl
/*     */   implements Logger
/*     */ {
/*  24 */   static final String THIS_PACKAGE_NAME = LoggerImpl.class.getName().substring(0, LoggerImpl.class.getName().length() - LoggerImpl.class.getSimpleName().length());
/*  25 */   static final Object[] EMPTY = new Object[0];
/*     */   
/*     */   protected final ExtendedLogServiceImpl logServiceImpl;
/*     */   protected final String name;
/*  29 */   private LogLevel enabledLevel = LogLevel.TRACE;
/*     */   
/*     */   public LoggerImpl(ExtendedLogServiceImpl logServiceImpl, String name, LoggerContext loggerContext) {
/*  32 */     this.logServiceImpl = logServiceImpl;
/*  33 */     this.name = name;
/*  34 */     applyLoggerContext(loggerContext);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  39 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLoggable(int level) {
/*  44 */     return this.logServiceImpl.isLoggable(this.name, level);
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(int level, String message) {
/*  49 */     log((ServiceReference)null, level, message, (Throwable)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(int level, String message, Throwable exception) {
/*  54 */     log((ServiceReference)null, level, message, exception);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(ServiceReference<?> sr, int level, String message) {
/*  60 */     log(sr, null, level, message, sr, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(ServiceReference<?> sr, int level, String message, Throwable exception) {
/*  66 */     log(sr, null, level, message, sr, exception);
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(Object context, int level, String message) {
/*  71 */     log(context, level, message, (Throwable)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(Object context, int level, String message, Throwable exception) {
/*  76 */     log(context, null, level, message, null, exception);
/*     */   }
/*     */   
/*     */   private void log(Object context, LogLevel logLevelEnum, int level, String message, ServiceReference<?> ref, Throwable exception) {
/*  80 */     log(this.logServiceImpl.getBundle(), context, logLevelEnum, level, message, ref, exception);
/*     */   }
/*     */   
/*     */   void log(Bundle entryBundle, Object context, LogLevel logLevelEnum, int level, String message, ServiceReference<?> ref, Throwable exception) {
/*  84 */     if (logLevelEnum == null) {
/*  85 */       logLevelEnum = getLogLevel(level);
/*     */     }
/*  87 */     if (this.enabledLevel.implies(logLevelEnum)) {
/*  88 */       this.logServiceImpl.getFactory().log(entryBundle, this.name, getLocation(), context, logLevelEnum, level, message, ref, exception);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private LogLevel getLogLevel(int level) {
/*  94 */     switch (level) {
/*     */       case 4:
/*  96 */         return LogLevel.DEBUG;
/*     */       case 1:
/*  98 */         return LogLevel.ERROR;
/*     */       case 3:
/* 100 */         return LogLevel.INFO;
/*     */       case 2:
/* 102 */         return LogLevel.WARN;
/*     */     } 
/* 104 */     return LogLevel.TRACE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTraceEnabled() {
/* 110 */     return this.enabledLevel.implies(LogLevel.TRACE);
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String message) {
/* 115 */     trace(message, EMPTY);
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String format, Object arg) {
/* 120 */     trace(format, new Object[] { arg });
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String format, Object arg1, Object arg2) {
/* 125 */     trace(format, new Object[] { arg1, arg2 });
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String format, Object... arguments) {
/* 130 */     log(LogLevel.TRACE, format, arguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDebugEnabled() {
/* 135 */     return this.enabledLevel.implies(LogLevel.DEBUG);
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String message) {
/* 140 */     debug(message, EMPTY);
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String format, Object arg) {
/* 145 */     debug(format, new Object[] { arg });
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String format, Object arg1, Object arg2) {
/* 150 */     debug(format, new Object[] { arg1, arg2 });
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String format, Object... arguments) {
/* 155 */     log(LogLevel.DEBUG, format, arguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInfoEnabled() {
/* 160 */     return this.enabledLevel.implies(LogLevel.INFO);
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String message) {
/* 165 */     info(message, EMPTY);
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String format, Object arg) {
/* 170 */     info(format, new Object[] { arg });
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String format, Object arg1, Object arg2) {
/* 175 */     info(format, new Object[] { arg1, arg2 });
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String format, Object... arguments) {
/* 180 */     log(LogLevel.INFO, format, arguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWarnEnabled() {
/* 185 */     return this.enabledLevel.implies(LogLevel.WARN);
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String message) {
/* 190 */     warn(message, EMPTY);
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String format, Object arg) {
/* 195 */     warn(format, new Object[] { arg });
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String format, Object arg1, Object arg2) {
/* 200 */     warn(format, new Object[] { arg1, arg2 });
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String format, Object... arguments) {
/* 205 */     log(LogLevel.WARN, format, arguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isErrorEnabled() {
/* 210 */     return this.enabledLevel.implies(LogLevel.ERROR);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String message) {
/* 215 */     error(message, EMPTY);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String format, Object arg) {
/* 220 */     error(format, new Object[] { arg });
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String format, Object arg1, Object arg2) {
/* 225 */     error(format, new Object[] { arg1, arg2 });
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String format, Object... arguments) {
/* 230 */     log(LogLevel.ERROR, format, arguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public void audit(String message) {
/* 235 */     audit(message, EMPTY);
/*     */   }
/*     */ 
/*     */   
/*     */   public void audit(String format, Object arg) {
/* 240 */     audit(format, new Object[] { arg });
/*     */   }
/*     */ 
/*     */   
/*     */   public void audit(String format, Object arg1, Object arg2) {
/* 245 */     audit(format, new Object[] { arg1, arg2 });
/*     */   }
/*     */ 
/*     */   
/*     */   public void audit(String format, Object... arguments) {
/* 250 */     log(LogLevel.AUDIT, format, arguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Exception> void trace(LoggerConsumer<E> consumer) throws E {
/* 255 */     if (isTraceEnabled()) {
/* 256 */       consumer.accept((Logger)this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Exception> void debug(LoggerConsumer<E> consumer) throws E {
/* 262 */     if (isDebugEnabled()) {
/* 263 */       consumer.accept((Logger)this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Exception> void info(LoggerConsumer<E> consumer) throws E {
/* 269 */     if (isInfoEnabled()) {
/* 270 */       consumer.accept((Logger)this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Exception> void warn(LoggerConsumer<E> consumer) throws E {
/* 276 */     if (isWarnEnabled()) {
/* 277 */       consumer.accept((Logger)this);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Exception> void error(LoggerConsumer<E> consumer) throws E {
/* 283 */     if (isErrorEnabled()) {
/* 284 */       consumer.accept((Logger)this);
/*     */     }
/*     */   }
/*     */   
/* 288 */   private static final Pattern pattern = Pattern.compile("(\\\\?)(\\\\?)(\\{\\})");
/*     */   
/*     */   private void log(LogLevel level, String format, Object... arguments) {
/* 291 */     if (!this.enabledLevel.implies(level)) {
/*     */       return;
/*     */     }
/* 294 */     StackTraceElement location = getLocation();
/* 295 */     Arguments processedArguments = new Arguments(arguments);
/* 296 */     String message = processedArguments.isEmpty() ? format : formatMessage(format, processedArguments);
/* 297 */     this.logServiceImpl.getFactory().log(this.logServiceImpl.getBundle(), this.name, location, processedArguments.serviceReference(), level, level.ordinal(), message.toString(), processedArguments.serviceReference(), processedArguments.throwable());
/*     */   }
/*     */   
/*     */   private StackTraceElement getLocation() {
/* 301 */     if (!this.logServiceImpl.getFactory().captureLogEntryLocation()) {
/* 302 */       return null;
/*     */     }
/* 304 */     StackTraceElement[] elements = Thread.currentThread().getStackTrace();
/* 305 */     if (elements.length == 0) {
/* 306 */       return null;
/*     */     }
/* 308 */     for (int i = 1; i < elements.length; i++) {
/* 309 */       if (!elements[i].getClassName().startsWith(THIS_PACKAGE_NAME)) {
/* 310 */         return elements[i];
/*     */       }
/*     */     } 
/* 313 */     return elements[1];
/*     */   }
/*     */   
/*     */   String formatMessage(String format, Arguments processedArguments) {
/* 317 */     Matcher matcher = pattern.matcher(format);
/* 318 */     char[] chars = format.toCharArray();
/* 319 */     int offset = 0;
/* 320 */     StringBuilder message = new StringBuilder(format.length() * 2); byte b; int i; Object[] arrayOfObject;
/* 321 */     for (i = (arrayOfObject = processedArguments.arguments()).length, b = 0; b < i; ) { Object argument = arrayOfObject[b];
/*     */ 
/*     */ 
/*     */       
/* 325 */       while (matcher.find()) {
/* 326 */         if (matcher.group(2).isEmpty()) {
/* 327 */           if (matcher.group(1).isEmpty()) {
/*     */             
/* 329 */             offset = append(message, matcher, chars, offset, matcher.start(3) - offset, argument);
/*     */             
/*     */             break;
/*     */           } 
/* 333 */           offset = append(message, matcher, chars, offset, matcher.start(3) - offset - 1, matcher.group(3));
/*     */           continue;
/*     */         } 
/* 336 */         offset = append(message, matcher, chars, offset, matcher.start(3) - offset - 1, argument);
/*     */         break;
/*     */       } 
/*     */       b++; }
/*     */     
/* 341 */     message.append(chars, offset, chars.length - offset);
/* 342 */     return message.toString();
/*     */   }
/*     */   
/*     */   private static int append(StringBuilder builder, Matcher matcher, char[] chars, int offset, int length, Object argument) {
/* 346 */     builder.append(chars, offset, length);
/* 347 */     builder.append(argument);
/* 348 */     return matcher.end(3);
/*     */   }
/*     */   
/*     */   void applyLoggerContext(LoggerContext loggerContext) {
/* 352 */     this.enabledLevel = (loggerContext == null) ? LogLevel.WARN : loggerContext.getEffectiveLogLevel(this.name);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\LoggerImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */