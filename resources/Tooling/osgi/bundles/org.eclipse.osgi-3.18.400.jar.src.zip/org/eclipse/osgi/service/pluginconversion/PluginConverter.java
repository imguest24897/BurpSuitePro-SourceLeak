package org.eclipse.osgi.service.pluginconversion;

import java.io.File;
import java.util.Dictionary;

public interface PluginConverter {
  File convertManifest(File paramFile1, File paramFile2, boolean paramBoolean1, String paramString, boolean paramBoolean2, Dictionary<String, String> paramDictionary) throws PluginConversionException;
  
  Dictionary<String, String> convertManifest(File paramFile, boolean paramBoolean1, String paramString, boolean paramBoolean2, Dictionary<String, String> paramDictionary) throws PluginConversionException;
  
  void writeManifest(File paramFile, Dictionary<String, String> paramDictionary, boolean paramBoolean) throws PluginConversionException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\pluginconversion\PluginConverter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */