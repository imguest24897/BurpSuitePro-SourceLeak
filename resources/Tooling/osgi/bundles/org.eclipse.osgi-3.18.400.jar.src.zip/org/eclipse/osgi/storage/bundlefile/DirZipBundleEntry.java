/*    */ package org.eclipse.osgi.storage.bundlefile;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DirZipBundleEntry
/*    */   extends BundleEntry
/*    */ {
/*    */   private ZipBundleFile bundleFile;
/*    */   String name;
/*    */   
/*    */   public DirZipBundleEntry(ZipBundleFile bundleFile, String name) {
/* 38 */     this.name = (name.length() > 0 && name.charAt(0) == '/') ? name.substring(1) : name;
/* 39 */     this.bundleFile = bundleFile;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InputStream getInputStream() throws IOException {
/* 47 */     return new ByteArrayInputStream(new byte[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public long getSize() {
/* 52 */     return 0L;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 57 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public long getTime() {
/* 62 */     return 0L;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public URL getLocalURL() {
/*    */     try {
/* 69 */       return new URL("jar:" + this.bundleFile.basefile.toURL() + "!/" + this.name);
/* 70 */     } catch (MalformedURLException malformedURLException) {
/*    */       
/* 72 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public URL getFileURL() {
/*    */     try {
/* 80 */       return this.bundleFile.extractDirectory(this.name).toURL();
/* 81 */     } catch (MalformedURLException malformedURLException) {
/*    */       
/* 83 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\bundlefile\DirZipBundleEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */