/*     */ package org.eclipse.osgi.storage.bundlefile;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.storage.BundleInfo;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZipBundleFile
/*     */   extends CloseableBundleFile<ZipEntry>
/*     */ {
/*     */   final boolean verify;
/*     */   volatile ZipFile zipFile;
/*     */   
/*     */   public ZipBundleFile(File basefile, BundleInfo.Generation generation, MRUBundleFileList mruList, Debug debug, boolean verify) throws IOException {
/*  43 */     super(basefile, generation, mruList, debug);
/*  44 */     this.verify = verify;
/*  45 */     if (!BundleFile.secureAction.exists(basefile)) {
/*  46 */       throw new IOException(NLS.bind(Msg.ADAPTER_FILEEXIST_EXCEPTION, basefile));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void doOpen() throws IOException {
/*  51 */     this.zipFile = BundleFile.secureAction.getZipFile(this.basefile, this.verify);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ZipEntry getZipEntry(String path) {
/*  62 */     if (path.length() > 0 && path.charAt(0) == '/')
/*  63 */       path = path.substring(1); 
/*  64 */     ZipEntry entry = this.zipFile.getEntry(path);
/*  65 */     if (entry != null && entry.getSize() == 0L && !entry.isDirectory()) {
/*     */       
/*  67 */       ZipEntry dirEntry = this.zipFile.getEntry(String.valueOf(path) + '/');
/*  68 */       if (dirEntry != null)
/*  69 */         entry = dirEntry; 
/*     */     } 
/*  71 */     return entry;
/*     */   }
/*     */ 
/*     */   
/*     */   protected BundleEntry findEntry(String path) {
/*  76 */     ZipEntry zipEntry = getZipEntry(path);
/*  77 */     if (zipEntry == null) {
/*  78 */       if (path.length() == 0 || path.charAt(path.length() - 1) == '/')
/*     */       {
/*  80 */         if (containsDir(path))
/*  81 */           return new DirZipBundleEntry(this, path); 
/*     */       }
/*  83 */       return null;
/*     */     } 
/*  85 */     return new ZipBundleEntry(zipEntry, this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doClose() throws IOException {
/*  90 */     this.zipFile.close();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void postClose() {
/*  95 */     this.zipFile = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected InputStream doGetInputStream(ZipEntry entry) throws IOException {
/* 100 */     return this.zipFile.getInputStream(entry);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Iterable<String> getPaths() {
/* 105 */     return () -> {
/*     */         final Enumeration<? extends ZipEntry> entries = this.zipFile.entries();
/*     */         return new Iterator<String>()
/*     */           {
/*     */             public boolean hasNext() {
/* 110 */               return entries.hasMoreElements();
/*     */             }
/*     */ 
/*     */             
/*     */             public String next() {
/* 115 */               ZipEntry entry = entries.nextElement();
/* 116 */               return entry.getName();
/*     */             }
/*     */ 
/*     */             
/*     */             public void remove() {
/* 121 */               throw new UnsupportedOperationException();
/*     */             }
/*     */           };
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\bundlefile\ZipBundleFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */