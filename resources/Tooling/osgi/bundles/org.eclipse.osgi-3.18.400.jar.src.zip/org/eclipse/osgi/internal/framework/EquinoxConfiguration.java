/*      */ package org.eclipse.osgi.internal.framework;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.JarURLConnection;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.security.CodeSource;
/*      */ import java.security.ProtectionDomain;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Properties;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import org.eclipse.osgi.internal.container.InternalUtils;
/*      */ import org.eclipse.osgi.internal.debug.Debug;
/*      */ import org.eclipse.osgi.internal.debug.FrameworkDebugOptions;
/*      */ import org.eclipse.osgi.internal.hookregistry.HookRegistry;
/*      */ import org.eclipse.osgi.internal.location.BasicLocation;
/*      */ import org.eclipse.osgi.internal.location.EquinoxLocations;
/*      */ import org.eclipse.osgi.internal.location.LocationHelper;
/*      */ import org.eclipse.osgi.internal.log.EquinoxLogServices;
/*      */ import org.eclipse.osgi.internal.messages.Msg;
/*      */ import org.eclipse.osgi.service.datalocation.Location;
/*      */ import org.eclipse.osgi.service.debug.DebugOptions;
/*      */ import org.eclipse.osgi.service.environment.EnvironmentInfo;
/*      */ import org.eclipse.osgi.util.ManifestElement;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ import org.osgi.framework.Version;
/*      */ import org.osgi.framework.wiring.BundleRevision;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class EquinoxConfiguration
/*      */   implements EnvironmentInfo
/*      */ {
/*      */   private static final String CONFIG_FILE = "config.ini";
/*      */   private static final String INTERNAL_OS_SUNOS = "SunOS";
/*      */   private static final String INTERNAL_OS_LINUX = "Linux";
/*      */   private static final String INTERNAL_OS_MACOSX = "Mac OS";
/*      */   private static final String INTERNAL_OS_AIX = "AIX";
/*      */   private static final String INTERNAL_OS_HPUX = "HP-UX";
/*      */   private static final String INTERNAL_OS_QNX = "QNX";
/*      */   private static final String INTERNAL_OS_OS400 = "OS/400";
/*      */   private static final String INTERNAL_OS_OS390 = "OS/390";
/*      */   private static final String INTERNAL_OS_ZOS = "z/OS";
/*      */   private static final String INTERNAL_OS_FREEBSD = "FreeBSD";
/*      */   private static final String INTERNAL_ARCH_I386 = "i386";
/*      */   private static final String INTERNAL_AMD64 = "amd64";
/*      */   public static final String VARIABLE_DELIM_STRING = "$";
/*      */   public static final char VARIABLE_DELIM_CHAR = '$';
/*      */   private static final String DEV_FILE_ENTRY_VERSION_SEPARATOR = ";";
/*      */   private final ConfigValues configValues;
/*      */   private final Debug debug;
/*      */   private final DebugOptions debugOptions;
/*      */   private final HookRegistry hookRegistry;
/*  107 */   private final AliasMapper aliasMapper = new AliasMapper();
/*      */   
/*      */   private final EquinoxLocations equinoxLocations;
/*      */   
/*      */   private volatile String[] allArgs;
/*      */   
/*      */   private volatile String[] frameworkArgs;
/*      */   private volatile String[] appArgs;
/*      */   private final boolean inDevelopmentMode;
/*      */   private final File devLocation;
/*  117 */   private final Object devMonitor = new Object();
/*      */   private String[] devDefaultClasspath;
/*  119 */   private Map<String, String> devProperties = null;
/*      */   
/*  121 */   private long devLastModified = 0L;
/*      */   
/*      */   public final boolean contextBootDelegation;
/*      */   
/*      */   public final boolean compatibilityBootDelegation;
/*      */   
/*      */   public final boolean compatibilityLazyTriggerOnFailLoad;
/*      */   
/*      */   public final List<String> LIB_EXTENSIONS;
/*      */   
/*      */   public final List<String> ECLIPSE_LIB_VARIANTS;
/*      */   
/*      */   public final boolean COPY_NATIVES;
/*      */   public final List<String> ECLIPSE_NL_JAR_VARIANTS;
/*      */   public final boolean DEFINE_PACKAGE_ATTRIBUTES;
/*      */   public final boolean BUNDLE_SET_TCCL;
/*      */   public final int BSN_VERSION;
/*      */   public static final int BSN_VERSION_SINGLE = 1;
/*      */   public static final int BSN_VERSION_MULTIPLE = 2;
/*      */   public static final int BSN_VERSION_MANAGED = 3;
/*      */   public final boolean throwErrorOnFailedStart;
/*      */   public final boolean CLASS_CERTIFICATE;
/*      */   public final boolean PARALLEL_CAPABLE;
/*  144 */   private final Map<Throwable, Integer> exceptions = new LinkedHashMap<>(0);
/*      */   
/*      */   public static final String PROP_JVM_OS_ARCH = "os.arch";
/*      */   
/*      */   public static final String PROP_JVM_OS_NAME = "os.name";
/*      */   
/*      */   public static final String PROP_JVM_OS_VERSION = "os.version";
/*      */   
/*      */   public static final String PROP_JVM_SPEC_VERSION = "java.specification.version";
/*      */   
/*      */   public static final String PROP_JVM_SPEC_NAME = "java.specification.name";
/*      */   
/*      */   public static final String PROP_SETPERMS_CMD = "osgi.filepermissions.command";
/*      */   
/*      */   public static final String PROP_DEBUG = "osgi.debug";
/*      */   
/*      */   public static final String PROP_DEBUG_VERBOSE = "osgi.debug.verbose";
/*      */   
/*      */   public static final String PROP_DEV = "osgi.dev";
/*      */   
/*      */   public static final String PROP_CLEAN = "osgi.clean";
/*      */   
/*      */   public static final String PROP_USE_SYSTEM_PROPERTIES = "osgi.framework.useSystemProperties";
/*      */   
/*      */   public static final String PROP_FRAMEWORK = "osgi.framework";
/*      */   
/*      */   public static final String ECLIPSE_FRAMEWORK_VENDOR = "Eclipse";
/*      */   
/*      */   public static final String PROP_OSGI_JAVA_PROFILE = "osgi.java.profile";
/*      */   
/*      */   public static final String PROP_OSGI_JAVA_PROFILE_NAME = "osgi.java.profile.name";
/*      */   
/*      */   public static final String PROP_OSGI_JAVA_PROFILE_BOOTDELEGATION = "osgi.java.profile.bootdelegation";
/*      */   
/*      */   public static final String PROP_OSGI_BOOTDELEGATION_IGNORE = "ignore";
/*      */   
/*      */   public static final String PROP_OSGI_BOOTDELEGATION_OVERRIDE = "override";
/*      */   
/*      */   public static final String PROP_OSGI_BOOTDELEGATION_NONE = "none";
/*      */   
/*      */   public static final String PROP_CONTEXT_BOOTDELEGATION = "osgi.context.bootdelegation";
/*      */   
/*      */   public static final String PROP_COMPATIBILITY_BOOTDELEGATION = "osgi.compatibility.bootdelegation";
/*      */   
/*      */   public static final String PROP_DS_DELAYED_KEEPINSTANCES = "ds.delayed.keepInstances";
/*      */   
/*      */   public static final String PROP_COMPATIBILITY_ERROR_FAILED_START = "osgi.compatibility.errorOnFailedStart";
/*      */   
/*      */   public static final String PROP_COMPATIBILITY_START_LAZY = "osgi.compatibility.eagerStart.LazyActivation";
/*      */   
/*      */   public static final String PROP_COMPATIBILITY_START_LAZY_ON_FAIL_CLASSLOAD = "osgi.compatibility.trigger.lazyActivation.onFailedClassLoad";
/*      */   
/*      */   public static final String PROP_OSGI_OS = "osgi.os";
/*      */   
/*      */   public static final String PROP_OSGI_WS = "osgi.ws";
/*      */   
/*      */   public static final String PROP_OSGI_ARCH = "osgi.arch";
/*      */   
/*      */   public static final String PROP_OSGI_NL = "osgi.nl";
/*      */   public static final String PROP_OSGI_NL_USER = "osgi.nl.user";
/*      */   public static final String PROP_ROOT_LOCALE = "equinox.root.locale";
/*      */   public static final String PROP_PARENT_CLASSLOADER = "osgi.parentClassloader";
/*      */   public static final String PARENT_CLASSLOADER_FWK = "fwk";
/*      */   public static final String PROP_CONTEXTCLASSLOADER_PARENT = "osgi.contextClassLoaderParent";
/*      */   public static final String CONTEXTCLASSLOADER_PARENT_APP = "app";
/*      */   public static final String CONTEXTCLASSLOADER_PARENT_EXT = "ext";
/*      */   public static final String CONTEXTCLASSLOADER_PARENT_BOOT = "boot";
/*      */   public static final String CONTEXTCLASSLOADER_PARENT_FWK = "fwk";
/*      */   public static final String PROP_FRAMEWORK_LIBRARY_EXTENSIONS = "osgi.framework.library.extensions";
/*      */   public static final String PROP_COPY_NATIVES = "osgi.classloader.copy.natives";
/*      */   public static final String PROP_DEFINE_PACKAGES = "osgi.classloader.define.packages";
/*      */   public static final String PROP_BUNDLE_SETTCCL = "eclipse.bundle.setTCCL";
/*      */   public static final String PROP_EQUINOX_SECURITY = "eclipse.security";
/*      */   public static final String PROP_FILE_LIMIT = "osgi.bundlefile.limit";
/*      */   public static final String PROP_CLASS_CERTIFICATE_SUPPORT = "osgi.support.class.certificate";
/*      */   public static final String PROP_CLASS_LOADER_TYPE = "osgi.classloader.type";
/*      */   public static final String CLASS_LOADER_TYPE_PARALLEL = "parallel";
/*      */   public static final String PROP_FORCED_RESTART = "osgi.forcedRestart";
/*      */   public static final String PROP_IGNORE_USER_CONFIGURATION = "eclipse.ignoreUserConfiguration";
/*      */   public static final String PROPERTY_STRICT_BUNDLE_ENTRY_PATH = "osgi.strictBundleEntryPath";
/*      */   public static final String PROP_CHECK_CONFIGURATION = "osgi.checkConfiguration";
/*      */   private final boolean inCheckConfigurationMode;
/*      */   public static final String DEFAULT_STATE_SAVE_DELAY_INTERVAL = "30000";
/*      */   public static final String PROP_STATE_SAVE_DELAY_INTERVAL = "eclipse.stateSaveDelayInterval";
/*      */   public static final String PROP_MODULE_LOCK_TIMEOUT = "osgi.module.lock.timeout";
/*      */   public static final String PROP_MODULE_AUTO_START_ON_RESOLVE = "osgi.module.auto.start.on.resolve";
/*      */   public static final String PROP_ALLOW_RESTRICTED_PROVIDES = "osgi.equinox.allow.restricted.provides";
/*      */   public static final String PROP_LOG_HISTORY_MAX = "equinox.log.history.max";
/*      */   public static final String PROP_LOG_CAPTURE_ENTRY_LOCATION = "equinox.log.capture.entry.location";
/*      */   @Deprecated
/*      */   public static final String PROP_RESOLVER_THREAD_COUNT = "equinox.resolver.thead.count";
/*      */   public static final String PROP_EQUINOX_RESOLVER_THREAD_COUNT = "equinox.resolver.thread.count";
/*      */   public static final String PROP_EQUINOX_START_LEVEL_THREAD_COUNT = "equinox.start.level.thread.count";
/*      */   public static final String PROP_EQUINOX_START_LEVEL_RESTRICT_PARALLEL = "equinox.start.level.restrict.parallel";
/*      */   public static final String PROP_RESOLVER_REVISION_BATCH_SIZE = "equinox.resolver.revision.batch.size";
/*      */   public static final String PROP_RESOLVER_BATCH_TIMEOUT = "equinox.resolver.batch.timeout";
/*      */   public static final String PROP_SYSTEM_PROVIDE_HEADER = "equinox.system.provide.header";
/*      */   public static final String SYSTEM_PROVIDE_HEADER_ORIGINAL = "original";
/*      */   public static final String SYSTEM_PROVIDE_HEADER_SYSTEM = "system";
/*      */   public static final String SYSTEM_PROVIDE_HEADER_SYSTEM_EXTRA = "system.extra";
/*      */   public static final String PROP_DEFAULT_SUFFIX = ".default";
/*  245 */   public static final Collection<String> PROP_WITH_ECLIPSE_STARTER_DEFAULTS = Collections.unmodifiableList(Arrays.asList(new String[] { "osgi.compatibility.bootdelegation", "ds.delayed.keepInstances" }));
/*      */   
/*      */   public static final String PROP_INIT_UUID = "equinox.init.uuid";
/*      */   
/*      */   public static final String PROP_ACTIVE_THREAD_TYPE = "osgi.framework.activeThreadType";
/*      */   
/*      */   public static final String ACTIVE_THREAD_TYPE_NORMAL = "normal";
/*      */   
/*      */   public static final String PROP_GOSH_ARGS = "gosh.args";
/*      */   
/*      */   public static final String PROP_SECURE_UUID = "equinox.uuid.secure";
/*      */   
/*      */   public static final String SIGNED_BUNDLE_SUPPORT = "osgi.support.signature.verify";
/*      */   
/*      */   public static final String SIGNED_CONTENT_SUPPORT = "osgi.signedcontent.support";
/*      */   
/*      */   public static final int SIGNED_CONTENT_VERIFY_CERTIFICATE = 1;
/*      */   
/*      */   public static final int SIGNED_CONTENT_VERIFY_TRUST = 2;
/*      */   
/*      */   public static final int SIGNED_CONTENT_VERIFY_RUNTIME = 4;
/*      */   
/*      */   public static final int SIGNED_CONTENT_VERIFY_ALL = 7;
/*      */   private static final String SIGNED_CONTENT_SUPPORT_CERTIFICATE = "certificate";
/*      */   private static final String SIGNED_CONTENT_SUPPORT_TRUST = "trust";
/*      */   private static final String SIGNED_CONTENT_SUPPORT_RUNTIME = "runtime";
/*      */   private static final String SIGNED_CONTENT_SUPPORT_ALL = "all";
/*      */   private static final String SIGNED_CONTENT_SUPPORT_TRUE = "true";
/*      */   public final int supportSignedBundles;
/*      */   public final boolean runtimeVerifySignedBundles;
/*      */   
/*      */   public static final class ConfigValues
/*      */   {
/*  278 */     private static final String NULL_CONFIG = new String("org.eclipse.equinox.configuration.null.value");
/*  279 */     private static final Collection<String> populateInitConfig = Arrays.asList(new String[] { "osgi.arch", "osgi.os", "osgi.ws", "osgi.nl", "org.osgi.framework.os.name", "org.osgi.framework.os.version", "org.osgi.framework.processor", "org.osgi.framework.language" });
/*      */     
/*      */     private final boolean useSystemProperties;
/*      */     
/*      */     private final Map<String, Object> initialConfig;
/*      */     private final Properties localConfig;
/*      */     private final Map<Throwable, Integer> exceptions;
/*      */     
/*      */     public ConfigValues(Map<String, ?> initialConfiguration, Map<Throwable, Integer> exceptions) {
/*  288 */       this.exceptions = exceptions;
/*  289 */       this.initialConfig = (initialConfiguration == null) ? new HashMap<>(0) : new HashMap<>(initialConfiguration);
/*  290 */       Object useSystemPropsValue = this.initialConfig.get("osgi.framework.useSystemProperties");
/*  291 */       this.useSystemProperties = (useSystemPropsValue == null) ? false : Boolean.parseBoolean(useSystemPropsValue.toString());
/*  292 */       Properties tempConfiguration = this.useSystemProperties ? EquinoxContainer.secureAction.getProperties() : new Properties();
/*      */       
/*  294 */       for (Map.Entry<String, ?> initialEntry : this.initialConfig.entrySet()) {
/*  295 */         if (initialEntry.getValue() == null) {
/*  296 */           if (this.useSystemProperties) {
/*  297 */             tempConfiguration.remove(initialEntry.getKey()); continue;
/*      */           } 
/*  299 */           tempConfiguration.put(initialEntry.getKey(), NULL_CONFIG);
/*      */           continue;
/*      */         } 
/*  302 */         tempConfiguration.put(initialEntry.getKey(), initialEntry.getValue());
/*      */       } 
/*      */       
/*  305 */       this.localConfig = this.useSystemProperties ? null : tempConfiguration;
/*      */     }
/*      */     
/*      */     void loadConfigIni(URL configIni) {
/*  309 */       if (configIni != null) {
/*  310 */         mergeConfiguration(loadProperties(configIni));
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     void finalizeValues() {
/*  316 */       for (String initialKey : populateInitConfig) {
/*  317 */         String value = getConfiguration(initialKey);
/*  318 */         if (value != null) {
/*  319 */           this.initialConfig.put(initialKey, value);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  324 */       for (String keyWithEclipseStarterDefault : EquinoxConfiguration.PROP_WITH_ECLIPSE_STARTER_DEFAULTS) {
/*  325 */         String currentValue = getConfiguration(keyWithEclipseStarterDefault);
/*  326 */         if (currentValue == null) {
/*  327 */           String defaultValue = getConfiguration(String.valueOf(keyWithEclipseStarterDefault) + ".default");
/*  328 */           if (defaultValue != null) {
/*  329 */             setConfiguration(keyWithEclipseStarterDefault, defaultValue);
/*      */           }
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  335 */       if ("onFirstInit".equals(getConfiguration("org.osgi.framework.storage.clean"))) {
/*  336 */         setConfiguration("osgi.clean", "true");
/*      */       }
/*      */       
/*  339 */       if (getConfiguration("eclipse.stateSaveDelayInterval") == null)
/*      */       {
/*  341 */         setConfiguration("eclipse.stateSaveDelayInterval", "30000");
/*      */       }
/*      */       try {
/*  344 */         Long.parseLong(getConfiguration("eclipse.stateSaveDelayInterval"));
/*  345 */       } catch (NumberFormatException e) {
/*  346 */         this.exceptions.put(e, Integer.valueOf(4));
/*      */         
/*  348 */         setConfiguration("eclipse.stateSaveDelayInterval", "30000");
/*      */       } 
/*      */       
/*  351 */       if (getConfiguration("gosh.args") == null) {
/*  352 */         String consoleProp = getConfiguration("osgi.console");
/*  353 */         consoleProp = (consoleProp == null) ? null : consoleProp.trim();
/*  354 */         if (consoleProp == null || consoleProp.length() > 0) {
/*      */ 
/*      */           
/*  357 */           setConfiguration("gosh.args", "--nointeractive");
/*      */         } else {
/*      */           
/*  360 */           setConfiguration("gosh.args", "--noshutdown");
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     private void mergeConfiguration(Properties source) {
/*  366 */       for (Enumeration<?> e = source.keys(); e.hasMoreElements(); ) {
/*  367 */         String key = (String)e.nextElement();
/*  368 */         String value = source.getProperty(key);
/*  369 */         if (getConfiguration(key) == null) {
/*  370 */           setProperty(key, value);
/*  371 */           this.initialConfig.put(key, value); continue;
/*      */         } 
/*  373 */         this.initialConfig.put(key, getConfiguration(key));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private Properties loadProperties(URL location) {
/*  379 */       Properties result = new Properties();
/*  380 */       if (location == null)
/*  381 */         return result; 
/*      */       try {
/*  383 */         Exception exception2, exception1 = null;
/*      */       
/*      */       }
/*  386 */       catch (FileNotFoundException fileNotFoundException) {
/*      */ 
/*      */       
/*  389 */       } catch (IOException e) {
/*      */         
/*  391 */         this.exceptions.put(e, Integer.valueOf(2));
/*      */       } 
/*  393 */       return substituteVars(result);
/*      */     }
/*      */     
/*      */     private Properties substituteVars(Properties result) {
/*  397 */       if (result == null)
/*      */       {
/*  399 */         return null;
/*      */       }
/*  401 */       for (Enumeration<Object> eKeys = result.keys(); eKeys.hasMoreElements(); ) {
/*  402 */         Object key = eKeys.nextElement();
/*  403 */         if (key instanceof String) {
/*  404 */           String value = result.getProperty((String)key);
/*  405 */           if (value != null)
/*  406 */             result.put(key, substituteVars(value, true)); 
/*      */         } 
/*      */       } 
/*  409 */       return result;
/*      */     }
/*      */     
/*      */     public String substituteVars(String path, boolean preserveDelimiters) {
/*  413 */       StringBuilder buf = new StringBuilder(path.length());
/*  414 */       StringTokenizer st = new StringTokenizer(path, "$", true);
/*  415 */       boolean varStarted = false;
/*  416 */       String var = null;
/*  417 */       while (st.hasMoreElements()) {
/*  418 */         String tok = st.nextToken();
/*  419 */         if ("$".equals(tok)) {
/*  420 */           if (!varStarted) {
/*  421 */             varStarted = true;
/*  422 */             var = "";
/*      */             continue;
/*      */           } 
/*  425 */           String prop = null;
/*      */           
/*  427 */           if (var != null && var.length() > 0)
/*  428 */             prop = getProperty(var); 
/*  429 */           if (prop == null) {
/*      */             
/*      */             try {
/*  432 */               Method getenv = System.class.getMethod("getenv", new Class[] { String.class });
/*  433 */               prop = (String)getenv.invoke(null, new Object[] { var });
/*  434 */             } catch (Throwable throwable) {}
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  440 */           if (prop != null) {
/*      */             
/*  442 */             buf.append(prop);
/*      */           } else {
/*      */             
/*  445 */             if (preserveDelimiters) {
/*  446 */               buf.append('$');
/*      */             }
/*  448 */             buf.append((var == null) ? "" : var);
/*  449 */             if (preserveDelimiters) {
/*  450 */               buf.append('$');
/*      */             }
/*      */           } 
/*  453 */           varStarted = false;
/*  454 */           var = null;
/*      */           continue;
/*      */         } 
/*  457 */         if (!varStarted) {
/*  458 */           buf.append(tok); continue;
/*      */         } 
/*  460 */         var = tok;
/*      */       } 
/*      */       
/*  463 */       if (var != null)
/*      */       {
/*  465 */         buf.append('$').append(var); } 
/*  466 */       return buf.toString();
/*      */     }
/*      */ 
/*      */     
/*      */     public String getProperty(String key) {
/*  471 */       String result = internalGet(key);
/*  472 */       if (result == NULL_CONFIG) {
/*  473 */         return null;
/*      */       }
/*  475 */       return (result == null) ? EquinoxContainer.secureAction.getProperty(key) : result;
/*      */     }
/*      */     
/*      */     public String setProperty(String key, String value) {
/*  479 */       if (value == null) {
/*  480 */         return clearConfiguration(key);
/*      */       }
/*  482 */       return setConfiguration(key, value);
/*      */     }
/*      */     
/*      */     public String getConfiguration(String key) {
/*  486 */       String result = internalGet(key);
/*  487 */       return (result == NULL_CONFIG) ? null : result;
/*      */     }
/*      */     
/*      */     private String internalGet(String key) {
/*  491 */       if (this.useSystemProperties) {
/*  492 */         return EquinoxContainer.secureAction.getProperty(key);
/*      */       }
/*  494 */       return this.localConfig.getProperty(key);
/*      */     }
/*      */     
/*      */     public String getConfiguration(String key, String defaultValue) {
/*  498 */       String result = getConfiguration(key);
/*  499 */       return (result == null) ? defaultValue : result;
/*      */     }
/*      */     
/*      */     public String setConfiguration(String key, String value) {
/*  503 */       Object result = internalPut(key, value);
/*  504 */       return (result instanceof String && result != NULL_CONFIG) ? (String)result : null;
/*      */     }
/*      */     
/*      */     public String clearConfiguration(String key) {
/*  508 */       Object result = internalRemove(key);
/*  509 */       if (!this.useSystemProperties) {
/*  510 */         internalPut(key, NULL_CONFIG);
/*      */       }
/*  512 */       return (result instanceof String && result != NULL_CONFIG) ? (String)result : null;
/*      */     }
/*      */     
/*      */     private Object internalPut(String key, String value) {
/*  516 */       if (this.useSystemProperties) {
/*  517 */         return EquinoxContainer.secureAction.getProperties().put(key, value);
/*      */       }
/*  519 */       return this.localConfig.put(key, value);
/*      */     }
/*      */     
/*      */     private Object internalRemove(String key) {
/*  523 */       if (this.useSystemProperties) {
/*  524 */         return EquinoxContainer.secureAction.getProperties().remove(key);
/*      */       }
/*  526 */       return this.localConfig.remove(key);
/*      */     }
/*      */     
/*      */     public Map<String, String> getConfiguration() {
/*  530 */       Properties props = this.useSystemProperties ? EquinoxContainer.secureAction.getProperties() : this.localConfig;
/*      */       
/*  532 */       synchronized (props) {
/*  533 */         Map<String, String> result = new HashMap<>(props.size());
/*  534 */         for (Object key : props.keySet()) {
/*  535 */           if (key instanceof String) {
/*  536 */             String skey = (String)key;
/*  537 */             String sValue = props.getProperty(skey);
/*  538 */             if (sValue != NULL_CONFIG) {
/*  539 */               result.put(skey, sValue);
/*      */             }
/*      */           } 
/*      */         } 
/*  543 */         return result;
/*      */       } 
/*      */     }
/*      */     
/*      */     public Map<String, Object> getInitialConfig() {
/*  548 */       return Collections.unmodifiableMap(this.initialConfig);
/*      */     }
/*      */   }
/*      */   
/*      */   EquinoxConfiguration(Map<String, ?> initialConfiguration, HookRegistry hookRegistry) {
/*  553 */     this.hookRegistry = hookRegistry;
/*      */ 
/*      */ 
/*      */     
/*  557 */     this.configValues = new ConfigValues(initialConfiguration, this.exceptions);
/*      */ 
/*      */     
/*  560 */     initializeProperties();
/*      */ 
/*      */ 
/*      */     
/*  564 */     AtomicBoolean debugLocations = new AtomicBoolean();
/*  565 */     this.equinoxLocations = new EquinoxLocations(this.configValues, this.hookRegistry.getContainer(), debugLocations, this.exceptions);
/*  566 */     this.configValues.loadConfigIni(getConfigIni(this.equinoxLocations, false));
/*  567 */     this.configValues.loadConfigIni(getConfigIni(this.equinoxLocations, true));
/*  568 */     this.configValues.finalizeValues();
/*      */     
/*  570 */     this.debugOptions = (DebugOptions)new FrameworkDebugOptions(this);
/*  571 */     this.debug = new Debug(this.debugOptions);
/*      */     
/*  573 */     debugLocations.set(this.debug.DEBUG_LOCATION);
/*      */ 
/*      */ 
/*      */     
/*  577 */     String osgiDev = getConfiguration("osgi.dev");
/*  578 */     File f = null;
/*  579 */     boolean devMode = false;
/*  580 */     if (osgiDev != null) {
/*      */       try {
/*  582 */         devMode = true;
/*  583 */         URL location = new URL(osgiDev);
/*      */         
/*  585 */         if ("file".equals(location.getProtocol())) {
/*  586 */           f = LocationHelper.decodePath(new File(location.getPath()));
/*  587 */           this.devLastModified = f.lastModified();
/*      */         } 
/*      */ 
/*      */         
/*      */         try {
/*  592 */           loadDevProperties(LocationHelper.getStream(location));
/*  593 */           devMode = true;
/*  594 */         } catch (IOException e) {
/*  595 */           this.exceptions.put(e, Integer.valueOf(4));
/*      */         }
/*      */       
/*  598 */       } catch (MalformedURLException malformedURLException) {
/*  599 */         this.devDefaultClasspath = getArrayFromList(osgiDev);
/*      */       } 
/*      */     }
/*  602 */     this.inDevelopmentMode = devMode;
/*  603 */     this.devLocation = f;
/*      */     
/*  605 */     this.contextBootDelegation = "true".equals(getConfiguration("osgi.context.bootdelegation", "true"));
/*  606 */     this.compatibilityBootDelegation = "true".equals(getConfiguration("osgi.compatibility.bootdelegation"));
/*  607 */     this.compatibilityLazyTriggerOnFailLoad = "true".equals(getConfiguration("osgi.compatibility.trigger.lazyActivation.onFailedClassLoad"));
/*      */     
/*  609 */     this.COPY_NATIVES = Boolean.valueOf(getConfiguration("osgi.classloader.copy.natives")).booleanValue();
/*  610 */     String[] libExtensions = ManifestElement.getArrayFromList(getConfiguration("osgi.framework.library.extensions", getConfiguration("org.osgi.framework.library.extensions", getOSLibraryExtDefaults())), ",");
/*  611 */     for (int i = 0; i < libExtensions.length; i++) {
/*  612 */       if (libExtensions[i].length() > 0 && libExtensions[i].charAt(0) != '.')
/*  613 */         libExtensions[i] = String.valueOf('.') + libExtensions[i]; 
/*  614 */     }  this.LIB_EXTENSIONS = Collections.unmodifiableList(Arrays.asList(libExtensions));
/*  615 */     this.ECLIPSE_LIB_VARIANTS = buildEclipseLibraryVariants(getWS(), getOS(), getOSArch(), getNL());
/*  616 */     this.ECLIPSE_NL_JAR_VARIANTS = buildNLJarVariants(getNL());
/*  617 */     this.DEFINE_PACKAGE_ATTRIBUTES = !"noattributes".equals(getConfiguration("osgi.classloader.define.packages"));
/*      */     
/*  619 */     String bsnVersion = getConfiguration("org.osgi.framework.bsnversion");
/*  620 */     if ("single".equals(bsnVersion)) {
/*  621 */       this.BSN_VERSION = 1;
/*  622 */     } else if ("multiple".equals(bsnVersion)) {
/*  623 */       this.BSN_VERSION = 2;
/*      */     } else {
/*  625 */       this.BSN_VERSION = 3;
/*      */     } 
/*      */     
/*  628 */     this.BUNDLE_SET_TCCL = "true".equals(getConfiguration("eclipse.bundle.setTCCL", "true"));
/*      */     
/*  630 */     this.throwErrorOnFailedStart = "true".equals(getConfiguration("osgi.compatibility.errorOnFailedStart", "true"));
/*      */     
/*  632 */     this.PARALLEL_CAPABLE = "parallel".equals(getConfiguration("osgi.classloader.type"));
/*      */ 
/*      */ 
/*      */     
/*  636 */     this.inCheckConfigurationMode = Boolean.valueOf(getConfiguration("osgi.checkConfiguration", Boolean.toString(devMode))).booleanValue();
/*      */     
/*  638 */     if (this.inCheckConfigurationMode && getConfiguration("osgi.checkConfiguration") == null) {
/*  639 */       setConfiguration("osgi.checkConfiguration", "true");
/*      */     }
/*  641 */     this.supportSignedBundles = getSupportSignedBundles(this);
/*  642 */     this.CLASS_CERTIFICATE = ((this.supportSignedBundles & 0x1) != 0 && 
/*  643 */       Boolean.valueOf(getConfiguration("osgi.support.class.certificate", "true")).booleanValue());
/*  644 */     this.runtimeVerifySignedBundles = ((this.supportSignedBundles & 0x4) != 0);
/*      */   }
/*      */   
/*      */   private static int getSupportSignedBundles(EquinoxConfiguration config) {
/*  648 */     int supportSignedBundles = 0;
/*  649 */     String[] supportOptions = ManifestElement.getArrayFromList(
/*  650 */         config.getConfiguration("osgi.signedcontent.support", config.getConfiguration("osgi.support.signature.verify")), ","); byte b; int i; String[] arrayOfString1;
/*  651 */     for (i = (arrayOfString1 = supportOptions).length, b = 0; b < i; ) { String supportOption = arrayOfString1[b];
/*  652 */       if ("certificate".equals(supportOption)) {
/*  653 */         supportSignedBundles |= 0x1;
/*  654 */       } else if ("trust".equals(supportOption)) {
/*  655 */         supportSignedBundles |= 0x3;
/*  656 */       } else if ("runtime".equals(supportOption)) {
/*  657 */         supportSignedBundles |= 0x5;
/*  658 */       } else if ("true".equals(supportOption) || 
/*  659 */         "all".equals(supportOption)) {
/*  660 */         supportSignedBundles |= 0x7;
/*      */       }  b++; }
/*      */     
/*  663 */     return supportSignedBundles;
/*      */   }
/*      */   private URL getConfigIni(EquinoxLocations locations, boolean parent) {
/*      */     Location location;
/*  667 */     if (Boolean.TRUE.toString().equals(getConfiguration("eclipse.ignoreUserConfiguration")))
/*  668 */       return null; 
/*  669 */     BasicLocation basicLocation = locations.getConfigurationLocation();
/*  670 */     if (basicLocation != null && parent) {
/*  671 */       location = basicLocation.getParentLocation();
/*      */     }
/*  673 */     if (location == null) {
/*  674 */       return null;
/*      */     }
/*      */     try {
/*  677 */       return new URL(String.valueOf(location.getURL().toExternalForm()) + "config.ini");
/*  678 */     } catch (MalformedURLException malformedURLException) {
/*      */ 
/*      */       
/*  681 */       return null;
/*      */     } 
/*      */   }
/*      */   public Map<String, Object> getInitialConfig() {
/*  685 */     return this.configValues.getInitialConfig();
/*      */   }
/*      */   
/*      */   private static List<String> buildEclipseLibraryVariants(String ws, String os, String arch, String nl) {
/*  689 */     List<String> result = new ArrayList<>();
/*  690 */     result.add("ws/" + ws + "/");
/*  691 */     result.add("os/" + os + "/" + arch + "/");
/*  692 */     result.add("os/" + os + "/");
/*  693 */     nl = nl.replace('_', '/');
/*  694 */     while (nl.length() > 0) {
/*  695 */       result.add("nl/" + nl + "/");
/*  696 */       int i = nl.lastIndexOf('/');
/*  697 */       nl = (i < 0) ? "" : nl.substring(0, i);
/*      */     } 
/*  699 */     result.add("");
/*  700 */     return Collections.unmodifiableList(result);
/*      */   }
/*      */   
/*      */   private static List<String> buildNLJarVariants(String nl) {
/*  704 */     List<String> result = new ArrayList<>();
/*  705 */     nl = nl.replace('_', '/');
/*  706 */     while (nl.length() > 0) {
/*  707 */       result.add("nl/" + nl + "/");
/*  708 */       int i = nl.lastIndexOf('/');
/*  709 */       nl = (i < 0) ? "" : nl.substring(0, i);
/*      */     } 
/*  711 */     result.add("");
/*  712 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getOSLibraryExtDefaults() {
/*  719 */     String os = EquinoxContainer.secureAction.getProperty("os.name");
/*  720 */     return (os == null || !os.startsWith("Mac OS")) ? null : "dylib,jnilib";
/*      */   }
/*      */   
/*      */   public boolean inCheckConfigurationMode() {
/*  724 */     return this.inCheckConfigurationMode;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean inDevelopmentMode() {
/*  729 */     return this.inDevelopmentMode;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean inDebugMode() {
/*  734 */     return this.debugOptions.isDebugEnabled();
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getCommandLineArgs() {
/*  739 */     return this.allArgs;
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getFrameworkArgs() {
/*  744 */     return this.frameworkArgs;
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getNonFrameworkArgs() {
/*  749 */     return this.appArgs;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getOSArch() {
/*  754 */     return getConfiguration("osgi.arch");
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNL() {
/*  759 */     return getConfiguration("osgi.nl");
/*      */   }
/*      */ 
/*      */   
/*      */   public String getOS() {
/*  764 */     return getConfiguration("osgi.os");
/*      */   }
/*      */ 
/*      */   
/*      */   public String getWS() {
/*  769 */     return getConfiguration("osgi.ws");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAllArgs(String[] allArgs) {
/*  774 */     this.allArgs = allArgs;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAppArgs(String[] appArgs) {
/*  779 */     this.appArgs = appArgs;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFrameworkArgs(String[] frameworkArgs) {
/*  784 */     this.frameworkArgs = frameworkArgs;
/*      */   }
/*      */ 
/*      */   
/*      */   public static String guessWS(String osName) {
/*  789 */     if (osName.equals("win32"))
/*  790 */       return "win32"; 
/*  791 */     if (osName.equals("linux"))
/*  792 */       return "gtk"; 
/*  793 */     if (osName.equals("freebsd"))
/*  794 */       return "gtk"; 
/*  795 */     if (osName.equals("macosx"))
/*  796 */       return "cocoa"; 
/*  797 */     if (osName.equals("hpux"))
/*  798 */       return "motif"; 
/*  799 */     if (osName.equals("aix"))
/*  800 */       return "motif"; 
/*  801 */     if (osName.equals("solaris"))
/*  802 */       return "gtk"; 
/*  803 */     if (osName.equals("qnx"))
/*  804 */       return "photon"; 
/*  805 */     return "unknown";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static String guessOS(String osName) {
/*  811 */     if (osName.regionMatches(true, 0, "win32", 0, 3)) {
/*  812 */       return "win32";
/*      */     }
/*  814 */     if (osName.equalsIgnoreCase("SunOS"))
/*  815 */       return "solaris"; 
/*  816 */     if (osName.equalsIgnoreCase("Linux"))
/*  817 */       return "linux"; 
/*  818 */     if (osName.equalsIgnoreCase("QNX"))
/*  819 */       return "qnx"; 
/*  820 */     if (osName.equalsIgnoreCase("AIX"))
/*  821 */       return "aix"; 
/*  822 */     if (osName.equalsIgnoreCase("HP-UX"))
/*  823 */       return "hpux"; 
/*  824 */     if (osName.equalsIgnoreCase("OS/400"))
/*  825 */       return "os/400"; 
/*  826 */     if (osName.equalsIgnoreCase("OS/390"))
/*  827 */       return "os/390"; 
/*  828 */     if (osName.equalsIgnoreCase("z/OS"))
/*  829 */       return "z/os"; 
/*  830 */     if (osName.equalsIgnoreCase("FreeBSD")) {
/*  831 */       return "freebsd";
/*      */     }
/*  833 */     if (osName.regionMatches(true, 0, "Mac OS", 0, "Mac OS".length()))
/*  834 */       return "macosx"; 
/*  835 */     return "unknown";
/*      */   }
/*      */   
/*      */   public String getConfiguration(String key) {
/*  839 */     return this.configValues.getConfiguration(key);
/*      */   }
/*      */   
/*      */   public String getConfiguration(String key, String defaultValue) {
/*  843 */     return this.configValues.getConfiguration(key, defaultValue);
/*      */   }
/*      */   
/*      */   public String setConfiguration(String key, String value) {
/*  847 */     return this.configValues.setConfiguration(key, value);
/*      */   }
/*      */   
/*      */   public String clearConfiguration(String key) {
/*  851 */     return this.configValues.clearConfiguration(key);
/*      */   }
/*      */   
/*      */   public Map<String, String> getConfiguration() {
/*  855 */     return this.configValues.getConfiguration();
/*      */   }
/*      */   
/*      */   public Debug getDebug() {
/*  859 */     return this.debug;
/*      */   }
/*      */   
/*      */   public DebugOptions getDebugOptions() {
/*  863 */     return this.debugOptions;
/*      */   }
/*      */   
/*      */   public HookRegistry getHookRegistry() {
/*  867 */     return this.hookRegistry;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getProperty(String key) {
/*  872 */     return this.configValues.getProperty(key);
/*      */   }
/*      */ 
/*      */   
/*      */   public String setProperty(String key, String value) {
/*  877 */     return this.configValues.setProperty(key, value);
/*      */   }
/*      */   
/*      */   public AliasMapper getAliasMapper() {
/*  881 */     return this.aliasMapper;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateDevProperties() {
/*  888 */     if (this.devLocation != null && this.devLocation.lastModified() != this.devLastModified) {
/*      */       try {
/*  890 */         loadDevProperties(new FileInputStream(this.devLocation));
/*  891 */         this.devLastModified = this.devLocation.lastModified();
/*  892 */       } catch (FileNotFoundException fileNotFoundException) {}
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static String[] getDevClassPath(BundleRevision bundle, Map<String, String> properties, String[] defaultClasspath) {
/*  898 */     String[] result = null;
/*  899 */     String id = bundle.getSymbolicName();
/*  900 */     if (id != null && properties != null) {
/*  901 */       String idVersion = String.valueOf(id) + ";" + bundle.getVersion();
/*  902 */       String entry = properties.getOrDefault(idVersion, properties.get(id));
/*  903 */       if (entry != null)
/*  904 */         result = getArrayFromList(entry); 
/*      */     } 
/*  906 */     if (result == null)
/*  907 */       result = defaultClasspath; 
/*  908 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getDevClassPath(BundleRevision bundle) {
/*  917 */     synchronized (this.devMonitor) {
/*  918 */       updateDevProperties();
/*  919 */       return getDevClassPath(bundle, this.devProperties, this.devDefaultClasspath);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static String[] getArrayFromList(String prop) {
/*  924 */     return ManifestElement.getArrayFromList(prop, ",");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void loadDevProperties(InputStream input) {
/*  931 */     Properties props = new Properties(); try {
/*  932 */       Exception exception2, exception1 = null;
/*      */     }
/*  934 */     catch (IOException e) {
/*  935 */       this.exceptions.put(e, Integer.valueOf(4));
/*      */     } 
/*      */     
/*  938 */     Map<String, String> result = props;
/*  939 */     synchronized (this.devMonitor) {
/*  940 */       this.devProperties = result;
/*  941 */       this.devDefaultClasspath = getArrayFromList(this.devProperties.get("*"));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void initializeProperties() {
/*  947 */     if (getConfiguration("osgi.framework") == null || getConfiguration("osgi.install.area") == null) {
/*  948 */       ProtectionDomain pd = EquinoxConfiguration.class.getProtectionDomain();
/*  949 */       CodeSource cs = (pd == null) ? null : pd.getCodeSource();
/*  950 */       URL url = (cs == null) ? null : cs.getLocation();
/*  951 */       if (url == null) {
/*  952 */         IOException cause = null;
/*      */         
/*  954 */         URL java6Profile = EquinoxConfiguration.class.getResource("/JavaSE-1.6.profile");
/*  955 */         if (java6Profile != null && "jar".equals(java6Profile.getProtocol())) {
/*      */           try {
/*  957 */             url = ((JarURLConnection)java6Profile.openConnection()).getJarFileURL();
/*  958 */           } catch (IOException e) {
/*  959 */             cause = e;
/*      */           } 
/*      */         }
/*  962 */         if (url == null) {
/*  963 */           throw new IllegalArgumentException(NLS.bind(Msg.ECLIPSE_STARTUP_PROPS_NOT_SET, "osgi.framework, osgi.install.area"), cause);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  968 */       if (getConfiguration("osgi.framework") == null) {
/*  969 */         String externalForm = getFrameworkPath(url.toExternalForm(), false);
/*  970 */         setConfiguration("osgi.framework", externalForm);
/*      */       } 
/*  972 */       if (getConfiguration("osgi.install.area") == null) {
/*      */         String installArea;
/*  974 */         if ("file".equals(url.getProtocol())) {
/*  975 */           installArea = getFrameworkPath(url.getPath(), true);
/*      */         }
/*      */         else {
/*      */           
/*  979 */           installArea = System.getProperty("user.dir");
/*      */         } 
/*  981 */         setConfiguration("osgi.install.area", installArea);
/*      */       } 
/*      */     } 
/*      */     
/*  985 */     setConfiguration("osgi.framework", LocationHelper.decode(getConfiguration("osgi.framework"), true));
/*  986 */     setConfiguration("osgi.install.area", LocationHelper.decode(getConfiguration("osgi.install.area"), true));
/*      */     
/*  988 */     setConfiguration("org.osgi.framework.vendor", "Eclipse");
/*  989 */     String value = getConfiguration("org.osgi.framework.processor");
/*  990 */     if (value == null) {
/*  991 */       value = EquinoxContainer.secureAction.getProperty("os.arch");
/*  992 */       if (value != null) {
/*  993 */         setConfiguration("org.osgi.framework.processor", this.aliasMapper.getCanonicalProcessor(value));
/*      */       }
/*      */     } 
/*      */     
/*  997 */     value = getConfiguration("org.osgi.framework.os.name");
/*  998 */     if (value == null) {
/*  999 */       value = EquinoxContainer.secureAction.getProperty("os.name");
/* 1000 */       if (value != null) {
/* 1001 */         setConfiguration("org.osgi.framework.os.name", this.aliasMapper.getCanonicalOSName(value));
/*      */       }
/*      */     } 
/*      */     
/* 1005 */     value = getConfiguration("org.osgi.framework.os.version");
/* 1006 */     if (value == null) {
/* 1007 */       value = EquinoxContainer.secureAction.getProperty("os.version");
/* 1008 */       if (value != null) {
/*      */         
/* 1010 */         int space = value.indexOf(' ');
/* 1011 */         if (space > 0) {
/* 1012 */           value = value.substring(0, space);
/*      */         }
/*      */         
/* 1015 */         int major = 0, minor = 0, micro = 0;
/* 1016 */         String qualifier = "";
/*      */         try {
/* 1018 */           StringTokenizer st = new StringTokenizer(value, ".", true);
/* 1019 */           major = parseVersionInt(st.nextToken());
/*      */           
/* 1021 */           if (st.hasMoreTokens()) {
/* 1022 */             st.nextToken();
/* 1023 */             minor = parseVersionInt(st.nextToken());
/*      */             
/* 1025 */             if (st.hasMoreTokens()) {
/* 1026 */               st.nextToken();
/* 1027 */               micro = parseVersionInt(st.nextToken());
/*      */               
/* 1029 */               if (st.hasMoreTokens()) {
/* 1030 */                 st.nextToken();
/* 1031 */                 qualifier = st.nextToken();
/*      */               } 
/*      */             } 
/*      */           } 
/* 1035 */         } catch (NoSuchElementException noSuchElementException) {}
/*      */ 
/*      */         
/*      */         try {
/* 1039 */           value = (new Version(major, minor, micro, qualifier)).toString();
/* 1040 */         } catch (IllegalArgumentException illegalArgumentException) {
/*      */           
/* 1042 */           value = (new Version(major, minor, micro)).toString();
/*      */         } 
/* 1044 */         setConfiguration("org.osgi.framework.os.version", value);
/*      */       } 
/*      */     } 
/* 1047 */     value = getConfiguration("org.osgi.framework.language");
/* 1048 */     if (value == null)
/*      */     {
/* 1050 */       setConfiguration("org.osgi.framework.language", Locale.getDefault().getLanguage());
/*      */     }
/* 1052 */     setConfiguration("org.osgi.supports.framework.fragment", "true");
/* 1053 */     setConfiguration("org.osgi.supports.framework.requirebundle", "true");
/* 1054 */     setConfiguration("org.osgi.supports.framework.extension", "true");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1066 */     String nlValue = getConfiguration("osgi.nl");
/* 1067 */     if (nlValue != null) {
/* 1068 */       Locale userLocale = toLocale(nlValue, Locale.getDefault());
/* 1069 */       Locale.setDefault(userLocale);
/*      */       
/* 1071 */       setConfiguration("osgi.nl.user", nlValue);
/*      */     } 
/* 1073 */     nlValue = Locale.getDefault().toString();
/* 1074 */     setConfiguration("osgi.nl", nlValue);
/*      */ 
/*      */ 
/*      */     
/* 1078 */     String osValue = getConfiguration("osgi.os");
/* 1079 */     if (osValue == null) {
/* 1080 */       osValue = guessOS(EquinoxContainer.secureAction.getProperty("os.name"));
/* 1081 */       setConfiguration("osgi.os", osValue);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1086 */     String wsValue = getConfiguration("osgi.ws");
/* 1087 */     if (wsValue == null) {
/* 1088 */       wsValue = guessWS(osValue);
/* 1089 */       setConfiguration("osgi.ws", wsValue);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1094 */     String archValue = getConfiguration("osgi.arch");
/* 1095 */     if (archValue == null) {
/* 1096 */       String name = EquinoxContainer.secureAction.getProperty("os.arch");
/*      */       
/* 1098 */       if (name.equalsIgnoreCase("i386")) {
/* 1099 */         archValue = "x86";
/*      */       }
/* 1101 */       else if (name.equalsIgnoreCase("amd64")) {
/* 1102 */         archValue = "x86_64";
/*      */       } else {
/* 1104 */         archValue = name;
/* 1105 */       }  setConfiguration("osgi.arch", archValue);
/*      */     } 
/*      */     
/* 1108 */     String uuid = InternalUtils.newUUID(this);
/* 1109 */     setConfiguration("org.osgi.framework.uuid", uuid);
/*      */   }
/*      */   
/*      */   private static String getFrameworkPath(String path, boolean parent) {
/* 1113 */     if (File.separatorChar == '\\')
/*      */     {
/* 1115 */       path = path.replace('\\', '/');
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1120 */     if (path.endsWith("org.eclipse.osgi/bin/")) {
/* 1121 */       path = path.substring(0, path.length() - "bin/".length());
/*      */     }
/* 1123 */     if (parent) {
/* 1124 */       int lastSlash = path.lastIndexOf('/');
/* 1125 */       return (lastSlash == -1) ? "/" : path.substring(0, lastSlash);
/*      */     } 
/* 1127 */     return path;
/*      */   }
/*      */   
/*      */   private static int parseVersionInt(String value) {
/*      */     try {
/* 1132 */       return Integer.parseInt(value);
/* 1133 */     } catch (NumberFormatException numberFormatException) {
/*      */       
/* 1135 */       StringBuilder sb = new StringBuilder(value.length());
/* 1136 */       char[] chars = value.toCharArray(); byte b; int i; char[] arrayOfChar1;
/* 1137 */       for (i = (arrayOfChar1 = chars).length, b = 0; b < i; ) { char element = arrayOfChar1[b];
/* 1138 */         if (!Character.isDigit(element))
/*      */           break; 
/* 1140 */         sb.append(element); b++; }
/*      */       
/* 1142 */       if (sb.length() > 0)
/* 1143 */         return Integer.parseInt(sb.toString()); 
/* 1144 */       return 0;
/*      */     } 
/*      */   }
/*      */   
/*      */   public String substituteVars(String path) {
/* 1149 */     return substituteVars(path, false);
/*      */   }
/*      */   
/*      */   public String substituteVars(String path, boolean preserveDelimiters) {
/* 1153 */     return this.configValues.substituteVars(path, preserveDelimiters);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Locale toLocale(String str, Locale defaultLocale) {
/* 1185 */     if (str == null) {
/* 1186 */       System.err.println("Given locale String is null - Default Locale will be used instead.");
/* 1187 */       return defaultLocale;
/*      */     } 
/*      */     
/* 1190 */     String language = "";
/* 1191 */     String country = "";
/* 1192 */     String variant = "";
/*      */     
/* 1194 */     String[] localeParts = str.split("_");
/* 1195 */     if (localeParts.length == 0 || localeParts.length > 3 || (localeParts.length == 1 && localeParts[0].length() == 0)) {
/* 1196 */       System.err.println(NLS.bind(Msg.error_badNL, str));
/* 1197 */       return defaultLocale;
/*      */     } 
/*      */     
/* 1200 */     if (localeParts[0].length() > 0 && !localeParts[0].matches("[a-zA-Z]{2,8}")) {
/* 1201 */       System.err.println(NLS.bind(Msg.error_badNL, str));
/* 1202 */       return defaultLocale;
/*      */     } 
/*      */     
/* 1205 */     language = localeParts[0];
/*      */     
/* 1207 */     if (localeParts.length > 1) {
/* 1208 */       if (localeParts[1].length() > 0 && !localeParts[1].matches("[a-zA-Z]{2}|[0-9]{3}")) {
/* 1209 */         if (language.length() > 0) {
/* 1210 */           System.err.println(NLS.bind(Msg.error_badNL_language, str));
/* 1211 */           return new Locale(language);
/*      */         } 
/* 1213 */         System.err.println(NLS.bind(Msg.error_badNL, str));
/* 1214 */         return defaultLocale;
/*      */       } 
/*      */       
/* 1217 */       country = localeParts[1];
/*      */     } 
/*      */     
/* 1220 */     if (localeParts.length == 3) {
/* 1221 */       if (localeParts[2].length() == 0) {
/* 1222 */         System.err.println(NLS.bind(Msg.error_badNL_language_country, str));
/* 1223 */         return new Locale(language, country);
/*      */       } 
/* 1225 */       variant = localeParts[2];
/*      */     } 
/*      */     
/* 1228 */     return new Locale(language, country, variant);
/*      */   }
/*      */   
/*      */   public EquinoxLocations getEquinoxLocations() {
/* 1232 */     return this.equinoxLocations;
/*      */   }
/*      */   
/*      */   void logMessages(EquinoxLogServices logServices) {
/* 1236 */     for (Map.Entry<Throwable, Integer> exception : this.exceptions.entrySet()) {
/* 1237 */       logServices.log("org.eclipse.osgi", ((Integer)exception.getValue()).intValue(), ((Throwable)exception.getKey()).getMessage(), exception.getKey());
/*      */     }
/* 1239 */     this.exceptions.clear();
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\framework\EquinoxConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */