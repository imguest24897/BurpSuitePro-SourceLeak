/*     */ package org.eclipse.osgi.internal.log;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.equinox.log.ExtendedLogService;
/*     */ import org.eclipse.equinox.log.Logger;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.service.log.FormatterLogger;
/*     */ import org.osgi.service.log.Logger;
/*     */ import org.osgi.service.log.LoggerConsumer;
/*     */ import org.osgi.service.log.admin.LoggerContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtendedLogServiceImpl
/*     */   implements ExtendedLogService
/*     */ {
/*     */   private final ExtendedLogServiceFactory factory;
/*     */   private volatile Bundle bundle;
/*  28 */   private final Map<Class<? extends Logger>, Map<String, LoggerImpl>> loggerCache = new HashMap<>();
/*  29 */   private final String LOG_SERVICE = "LogService";
/*     */   
/*     */   public ExtendedLogServiceImpl(ExtendedLogServiceFactory factory, Bundle bundle) {
/*  32 */     this.factory = factory;
/*  33 */     this.bundle = bundle;
/*  34 */     this.loggerCache.put(Logger.class, new HashMap<>());
/*  35 */     this.loggerCache.put(FormatterLogger.class, new HashMap<>());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(int level, String message) {
/*  41 */     log((ServiceReference<?>)null, level, message, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(int level, String message, Throwable exception) {
/*  47 */     log((ServiceReference<?>)null, level, message, exception);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(ServiceReference<?> sr, int level, String message) {
/*  53 */     log(sr, level, message, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(ServiceReference<?> sr, int level, String message, Throwable exception) {
/*  59 */     getLogger((String)null).log(sr, level, message, exception);
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(Object context, int level, String message) {
/*  64 */     log(context, level, message, (Throwable)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void log(Object context, int level, String message, Throwable exception) {
/*  69 */     getLogger((String)null).log(context, level, message, exception);
/*     */   }
/*     */ 
/*     */   
/*     */   public Logger getLogger(String name) {
/*  74 */     return (Logger)getLogger(name, Logger.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public Logger getLogger(Bundle logBundle, String name) {
/*  79 */     if (logBundle == null || logBundle == this.bundle) {
/*  80 */       return getLogger(name);
/*     */     }
/*  82 */     this.factory.checkLogPermission();
/*  83 */     ExtendedLogService bundleLogService = this.factory.getLogService(logBundle);
/*  84 */     return bundleLogService.getLogger(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public <L extends Logger> L getLogger(Bundle logBundle, String name, Class<L> loggerType) {
/*  89 */     if (logBundle == null || (logBundle.getState() & 0x3) != 0) {
/*  90 */       throw new IllegalArgumentException("The bundle is not resolved: " + logBundle);
/*     */     }
/*  92 */     ExtendedLogService bundleLogService = this.factory.getLogService(logBundle);
/*  93 */     return (L)bundleLogService.getLogger(name, loggerType);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  98 */     return getLogger((String)null).getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLoggable(int level) {
/* 103 */     return getLogger((String)null).isLoggable(level);
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isLoggable(String name, int level) {
/* 108 */     return this.factory.isLoggable(this.bundle, name, level);
/*     */   }
/*     */   
/*     */   void setBundle(Bundle bundle) {
/* 112 */     this.factory.contextsLock.writeLock().lock();
/*     */     try {
/* 114 */       Bundle previous = this.bundle;
/* 115 */       this.bundle = bundle;
/* 116 */       this.factory.loggerContextTargetMap.replaceSystemBundleLogService(previous, bundle);
/*     */     } finally {
/* 118 */       this.factory.contextsLock.writeLock().unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   Bundle getBundle() {
/* 123 */     return this.bundle;
/*     */   }
/*     */   
/*     */   ExtendedLogServiceFactory getFactory() {
/* 127 */     return this.factory;
/*     */   }
/*     */ 
/*     */   
/*     */   public Logger getLogger(Class<?> clazz) {
/* 132 */     return (Logger)getLogger(clazz.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   public <L extends Logger> L getLogger(String name, Class<L> loggerType) {
/* 137 */     if (name == null) {
/* 138 */       Bundle current = this.bundle;
/* 139 */       String bsn = (current == null) ? null : current.getSymbolicName();
/* 140 */       name = (bsn == null) ? "LogService" : ("LogService." + bsn);
/*     */     } 
/* 142 */     LoggerImpl logger = null;
/* 143 */     Map<String, LoggerImpl> loggers = null;
/* 144 */     this.factory.contextsLock.readLock().lock();
/*     */     try {
/* 146 */       loggers = this.loggerCache.get(loggerType);
/* 147 */       if (loggers == null) {
/* 148 */         throw new IllegalArgumentException(loggerType.getName());
/*     */       }
/* 150 */       logger = loggers.get(name);
/*     */     } finally {
/* 152 */       this.factory.contextsLock.readLock().unlock();
/*     */     } 
/* 154 */     if (logger == null) {
/* 155 */       LoggerContext loggerContext = this.factory.loggerContextTargetMap.getEffectiveLoggerContext(this.bundle);
/* 156 */       if (loggerType == FormatterLogger.class) {
/* 157 */         logger = new FormatterLoggerImpl(this, name, loggerContext);
/* 158 */       } else if (loggerType == Logger.class) {
/* 159 */         logger = new LoggerImpl(this, name, loggerContext);
/*     */       } else {
/* 161 */         throw new IllegalArgumentException(loggerType.getName());
/*     */       } 
/* 163 */       this.factory.contextsLock.writeLock().lock();
/*     */       try {
/* 165 */         LoggerImpl existing = loggers.get(name);
/* 166 */         if (existing == null) {
/* 167 */           loggers.put(name, logger);
/*     */         } else {
/* 169 */           logger = existing;
/*     */         } 
/*     */       } finally {
/* 172 */         this.factory.contextsLock.writeLock().unlock();
/*     */       } 
/*     */     } 
/* 175 */     return loggerType.cast(logger);
/*     */   }
/*     */ 
/*     */   
/*     */   public <L extends Logger> L getLogger(Class<?> clazz, Class<L> loggerType) {
/* 180 */     return getLogger(clazz.getName(), loggerType);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTraceEnabled() {
/* 185 */     return getLogger((String)null).isTraceEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String message) {
/* 190 */     getLogger((String)null).trace(message);
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String format, Object arg) {
/* 195 */     getLogger((String)null).trace(format, arg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String format, Object arg1, Object arg2) {
/* 200 */     getLogger((String)null).trace(format, arg1, arg2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void trace(String format, Object... arguments) {
/* 205 */     getLogger((String)null).trace(format, arguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDebugEnabled() {
/* 210 */     return getLogger((String)null).isDebugEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String message) {
/* 215 */     getLogger((String)null).debug(message);
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String format, Object arg) {
/* 220 */     getLogger((String)null).debug(format, arg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String format, Object arg1, Object arg2) {
/* 225 */     getLogger((String)null).debug(format, arg1, arg2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String format, Object... arguments) {
/* 230 */     getLogger((String)null).debug(format, arguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInfoEnabled() {
/* 235 */     return getLogger((String)null).isInfoEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String message) {
/* 240 */     getLogger((String)null).info(message);
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String format, Object arg) {
/* 245 */     getLogger((String)null).info(format, arg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String format, Object arg1, Object arg2) {
/* 250 */     getLogger((String)null).info(format, arg1, arg2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String format, Object... arguments) {
/* 255 */     getLogger((String)null).info(format, arguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWarnEnabled() {
/* 260 */     return getLogger((String)null).isWarnEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String message) {
/* 265 */     getLogger((String)null).warn(message);
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String format, Object arg) {
/* 270 */     getLogger((String)null).warn(format, arg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String format, Object arg1, Object arg2) {
/* 275 */     getLogger((String)null).warn(format, arg1, arg2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void warn(String format, Object... arguments) {
/* 280 */     getLogger((String)null).warn(format, arguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isErrorEnabled() {
/* 285 */     return getLogger((String)null).isErrorEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String message) {
/* 290 */     getLogger((String)null).error(message);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String format, Object arg) {
/* 295 */     getLogger((String)null).error(format, arg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String format, Object arg1, Object arg2) {
/* 300 */     getLogger((String)null).error(format, arg1, arg2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void error(String format, Object... arguments) {
/* 305 */     getLogger((String)null).error(format, arguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public void audit(String message) {
/* 310 */     getLogger((String)null).audit(message);
/*     */   }
/*     */ 
/*     */   
/*     */   public void audit(String format, Object arg) {
/* 315 */     getLogger((String)null).audit(format, arg);
/*     */   }
/*     */ 
/*     */   
/*     */   public void audit(String format, Object arg1, Object arg2) {
/* 320 */     getLogger((String)null).audit(format, arg1, arg2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void audit(String format, Object... arguments) {
/* 325 */     getLogger((String)null).audit(format, arguments);
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Exception> void trace(LoggerConsumer<E> consumer) throws E {
/* 330 */     getLogger((String)null).trace(consumer);
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Exception> void debug(LoggerConsumer<E> consumer) throws E {
/* 335 */     getLogger((String)null).debug(consumer);
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Exception> void info(LoggerConsumer<E> consumer) throws E {
/* 340 */     getLogger((String)null).info(consumer);
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Exception> void warn(LoggerConsumer<E> consumer) throws E {
/* 345 */     getLogger((String)null).warn(consumer);
/*     */   }
/*     */ 
/*     */   
/*     */   public <E extends Exception> void error(LoggerConsumer<E> consumer) throws E {
/* 350 */     getLogger((String)null).error(consumer);
/*     */   }
/*     */   
/*     */   void applyLogLevels(ExtendedLogServiceFactory.EquinoxLoggerContext effectiveLoggerContext) {
/* 354 */     for (Map<String, LoggerImpl> loggers : this.loggerCache.values()) {
/* 355 */       for (LoggerImpl logger : loggers.values())
/* 356 */         logger.applyLoggerContext(effectiveLoggerContext); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\ExtendedLogServiceImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */