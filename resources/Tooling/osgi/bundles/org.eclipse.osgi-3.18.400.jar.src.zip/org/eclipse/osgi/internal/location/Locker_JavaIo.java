/*    */ package org.eclipse.osgi.internal.location;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.RandomAccessFile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Locker_JavaIo
/*    */   implements Locker
/*    */ {
/*    */   private File lockFile;
/*    */   private RandomAccessFile lockRAF;
/*    */   
/*    */   public Locker_JavaIo(File lockFile) {
/* 26 */     this.lockFile = lockFile;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized boolean lock() throws IOException {
/* 33 */     if (this.lockFile.exists())
/* 34 */       this.lockFile.delete(); 
/* 35 */     if (this.lockFile.exists()) {
/* 36 */       return false;
/*    */     }
/*    */     
/* 39 */     this.lockRAF = new RandomAccessFile(this.lockFile, "rw");
/*    */     try {
/* 41 */       this.lockRAF.writeByte(0);
/* 42 */     } catch (IOException e) {
/* 43 */       this.lockRAF.close();
/* 44 */       this.lockRAF = null;
/* 45 */       throw e;
/*    */     } 
/*    */     
/* 48 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void release() {
/*    */     try {
/* 54 */       if (this.lockRAF != null) {
/* 55 */         this.lockRAF.close();
/* 56 */         this.lockRAF = null;
/*    */       } 
/* 58 */     } catch (IOException iOException) {}
/*    */ 
/*    */     
/* 61 */     if (this.lockFile != null) {
/* 62 */       this.lockFile.delete();
/*    */     }
/*    */   }
/*    */   
/*    */   public synchronized boolean isLocked() throws IOException {
/* 67 */     if (this.lockRAF != null)
/* 68 */       return true; 
/*    */     try {
/* 70 */       return !lock();
/*    */     } finally {
/* 72 */       release();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\location\Locker_JavaIo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */