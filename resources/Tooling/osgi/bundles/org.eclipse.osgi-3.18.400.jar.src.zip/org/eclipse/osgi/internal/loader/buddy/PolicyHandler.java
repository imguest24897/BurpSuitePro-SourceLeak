/*     */ package org.eclipse.osgi.internal.loader.buddy;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.eclipse.osgi.container.ModuleContainerAdaptor;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxBundle;
/*     */ import org.eclipse.osgi.internal.loader.BundleLoader;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleEvent;
/*     */ import org.osgi.framework.BundleListener;
/*     */ import org.osgi.framework.SynchronousBundleListener;
/*     */ import org.osgi.framework.wiring.FrameworkWiring;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PolicyHandler
/*     */   implements SynchronousBundleListener
/*     */ {
/*     */   private static final String DEPENDENT_POLICY = "dependent";
/*     */   private static final String GLOBAL_POLICY = "global";
/*     */   private static final String REGISTERED_POLICY = "registered";
/*     */   private static final String APP_POLICY = "app";
/*     */   private static final String EXT_POLICY = "ext";
/*     */   private static final String BOOT_POLICY = "boot";
/*     */   private static final String PARENT_POLICY = "parent";
/*     */   private final BundleLoader policedLoader;
/*     */   private final List<String> originalBuddyList;
/*  46 */   private volatile Object[] policies = null;
/*     */   
/*     */   private final ThreadLocal<Set<String>> beingLoaded;
/*     */   
/*     */   private final FrameworkWiring frameworkWiring;
/*     */   
/*     */   private final ClassLoader bootLoader;
/*     */   
/*     */   public PolicyHandler(BundleLoader loader, List<String> buddyList, FrameworkWiring frameworkWiring, ClassLoader bootLoader) {
/*  55 */     this.policedLoader = loader;
/*  56 */     this.originalBuddyList = buddyList;
/*  57 */     this.policies = buddyList.toArray();
/*  58 */     this.beingLoaded = new ThreadLocal<>();
/*  59 */     this.frameworkWiring = frameworkWiring;
/*  60 */     this.bootLoader = bootLoader;
/*     */   }
/*     */   
/*     */   static Object[] getArrayFromList(String stringList) {
/*  64 */     if (stringList == null || stringList.trim().equals(""))
/*  65 */       return null; 
/*  66 */     List<Object> list = new ArrayList();
/*  67 */     StringTokenizer tokens = new StringTokenizer(stringList, ",");
/*  68 */     while (tokens.hasMoreTokens()) {
/*  69 */       String token = tokens.nextToken().trim();
/*  70 */       if (!token.equals(""))
/*  71 */         list.add(token.toLowerCase()); 
/*     */     } 
/*  73 */     return list.isEmpty() ? new Object[0] : list.<Object>toArray(new Object[list.size()]);
/*     */   }
/*     */   
/*     */   private IBuddyPolicy getPolicyImplementation(Object[] policiesSnapshot, int policyOrder) {
/*  77 */     synchronized (policiesSnapshot) {
/*  78 */       if (policyOrder >= policiesSnapshot.length)
/*  79 */         return null; 
/*  80 */       if (policiesSnapshot[policyOrder] instanceof String) {
/*  81 */         String buddyName = (String)policiesSnapshot[policyOrder];
/*     */         
/*  83 */         if ("registered".equals(buddyName)) {
/*  84 */           policiesSnapshot[policyOrder] = new RegisteredPolicy(this.policedLoader);
/*  85 */           return (IBuddyPolicy)policiesSnapshot[policyOrder];
/*     */         } 
/*  87 */         if ("boot".equals(buddyName)) {
/*  88 */           policiesSnapshot[policyOrder] = SystemPolicy.getInstance((byte)0, this.bootLoader);
/*  89 */           return (IBuddyPolicy)policiesSnapshot[policyOrder];
/*     */         } 
/*  91 */         if ("app".equals(buddyName)) {
/*  92 */           policiesSnapshot[policyOrder] = SystemPolicy.getInstance((byte)2, this.bootLoader);
/*  93 */           return (IBuddyPolicy)policiesSnapshot[policyOrder];
/*     */         } 
/*  95 */         if ("ext".equals(buddyName)) {
/*  96 */           policiesSnapshot[policyOrder] = SystemPolicy.getInstance((byte)1, this.bootLoader);
/*  97 */           return (IBuddyPolicy)policiesSnapshot[policyOrder];
/*     */         } 
/*  99 */         if ("dependent".equals(buddyName)) {
/* 100 */           policiesSnapshot[policyOrder] = new DependentPolicy(this.policedLoader);
/* 101 */           return (IBuddyPolicy)policiesSnapshot[policyOrder];
/*     */         } 
/* 103 */         if ("global".equals(buddyName)) {
/* 104 */           policiesSnapshot[policyOrder] = new GlobalPolicy(this.frameworkWiring);
/* 105 */           return (IBuddyPolicy)policiesSnapshot[policyOrder];
/*     */         } 
/* 107 */         if ("parent".equals(buddyName)) {
/* 108 */           policiesSnapshot[policyOrder] = new SystemPolicy(this.policedLoader.getParentClassLoader());
/* 109 */           return (IBuddyPolicy)policiesSnapshot[policyOrder];
/*     */         } 
/*     */         
/* 112 */         EquinoxBundle bundle = (EquinoxBundle)this.policedLoader.getModuleClassLoader().getBundle();
/* 113 */         bundle.getModule().getContainer().getAdaptor().publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, bundle.getModule(), new RuntimeException("Invalid buddy policy: " + buddyName), new org.osgi.framework.FrameworkListener[0]);
/* 114 */         policiesSnapshot[policyOrder] = null;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 141 */       return (IBuddyPolicy)policiesSnapshot[policyOrder];
/*     */     } 
/*     */   }
/*     */   
/*     */   public Class<?> doBuddyClassLoading(String name) {
/* 146 */     if (!startLoading(name)) {
/* 147 */       return null;
/*     */     }
/*     */     try {
/* 150 */       Class<?> result = null;
/* 151 */       Object[] policiesSnapshot = this.policies;
/* 152 */       int policyCount = (policiesSnapshot == null) ? 0 : policiesSnapshot.length;
/* 153 */       for (int i = 0; i < policyCount && result == null; i++) {
/* 154 */         IBuddyPolicy policy = getPolicyImplementation(policiesSnapshot, i);
/* 155 */         if (policy != null)
/* 156 */           result = policy.loadClass(name); 
/*     */       } 
/* 158 */       return result;
/*     */     } finally {
/* 160 */       stopLoading(name);
/*     */     } 
/*     */   }
/*     */   
/*     */   public URL doBuddyResourceLoading(String name) {
/* 165 */     if (!startLoading(name)) {
/* 166 */       return null;
/*     */     }
/*     */     try {
/* 169 */       URL result = null;
/* 170 */       Object[] policiesSnapshot = this.policies;
/* 171 */       int policyCount = (policiesSnapshot == null) ? 0 : policiesSnapshot.length;
/* 172 */       for (int i = 0; i < policyCount && result == null; i++) {
/* 173 */         IBuddyPolicy policy = getPolicyImplementation(policiesSnapshot, i);
/* 174 */         if (policy != null)
/* 175 */           result = policy.loadResource(name); 
/*     */       } 
/* 177 */       return result;
/*     */     } finally {
/* 179 */       stopLoading(name);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Enumeration<URL> doBuddyResourcesLoading(String name) {
/* 184 */     if (!startLoading(name)) {
/* 185 */       return null;
/*     */     }
/*     */     try {
/* 188 */       List<URL> results = null;
/* 189 */       Object[] policiesSnapshot = this.policies;
/* 190 */       int policyCount = (policiesSnapshot == null) ? 0 : policiesSnapshot.length;
/* 191 */       for (int i = 0; i < policyCount; i++) {
/* 192 */         IBuddyPolicy policy = getPolicyImplementation(policiesSnapshot, i);
/* 193 */         if (policy != null) {
/*     */           
/* 195 */           Enumeration<URL> result = policy.loadResources(name);
/* 196 */           if (result != null) {
/* 197 */             if (results == null)
/* 198 */               results = new ArrayList<>(policyCount); 
/* 199 */             while (result.hasMoreElements()) {
/* 200 */               URL url = result.nextElement();
/* 201 */               if (!results.contains(url))
/* 202 */                 results.add(url); 
/*     */             } 
/*     */           } 
/*     */         } 
/* 206 */       }  return (Enumeration)((results == null || results.isEmpty()) ? null : Collections.<T>enumeration((Collection)results));
/*     */     } finally {
/* 208 */       stopLoading(name);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void doBuddyListResourceLoading(Set<String> results, String path, String filePattern, int options) {
/* 213 */     if (!startLoading(path)) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 218 */       Object[] policiesSnapshot = this.policies;
/* 219 */       int policyCount = (policiesSnapshot == null) ? 0 : policiesSnapshot.length;
/* 220 */       for (int i = 0; i < policyCount; i++) {
/* 221 */         IBuddyPolicy policy = getPolicyImplementation(policiesSnapshot, i);
/* 222 */         if (policy != null)
/* 223 */           policy.addListResources(results, path, filePattern, options); 
/*     */       } 
/*     */     } finally {
/* 226 */       stopLoading(path);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean startLoading(String name) {
/* 231 */     Set<String> classesAndResources = this.beingLoaded.get();
/* 232 */     if (classesAndResources != null && classesAndResources.contains(name)) {
/* 233 */       return false;
/*     */     }
/* 235 */     if (classesAndResources == null) {
/* 236 */       classesAndResources = new HashSet<>(3);
/* 237 */       this.beingLoaded.set(classesAndResources);
/*     */     } 
/* 239 */     classesAndResources.add(name);
/* 240 */     return true;
/*     */   }
/*     */   
/*     */   private void stopLoading(String name) {
/* 244 */     ((Set)this.beingLoaded.get()).remove(name);
/*     */   }
/*     */   
/*     */   public void open(BundleContext context) {
/* 248 */     context.addBundleListener((BundleListener)this);
/*     */   }
/*     */   
/*     */   public void close(BundleContext context) {
/* 252 */     context.removeBundleListener((BundleListener)this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void bundleChanged(BundleEvent event) {
/* 257 */     if ((event.getType() & 0x60) == 0) {
/*     */       return;
/*     */     }
/* 260 */     this.policies = this.originalBuddyList.toArray();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\buddy\PolicyHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */