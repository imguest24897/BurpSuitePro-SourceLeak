package org.eclipse.osgi.service.resolver;

import java.util.Collection;
import java.util.Dictionary;
import java.util.List;
import java.util.Map;
import org.osgi.framework.BundleException;
import org.osgi.framework.Version;
import org.osgi.framework.hooks.resolver.ResolverHookFactory;

public interface State {
  boolean addBundle(BundleDescription paramBundleDescription);
  
  StateDelta compare(State paramState) throws BundleException;
  
  BundleDescription removeBundle(long paramLong);
  
  boolean removeBundle(BundleDescription paramBundleDescription);
  
  boolean updateBundle(BundleDescription paramBundleDescription);
  
  StateDelta getChanges();
  
  BundleDescription[] getBundles();
  
  BundleDescription getBundle(long paramLong);
  
  BundleDescription getBundle(String paramString, Version paramVersion);
  
  BundleDescription getBundleByLocation(String paramString);
  
  long getTimeStamp();
  
  void setTimeStamp(long paramLong);
  
  boolean isResolved();
  
  void resolveConstraint(VersionConstraint paramVersionConstraint, BaseDescription paramBaseDescription);
  
  void resolveBundle(BundleDescription paramBundleDescription, boolean paramBoolean, BundleDescription[] paramArrayOfBundleDescription1, ExportPackageDescription[] paramArrayOfExportPackageDescription1, BundleDescription[] paramArrayOfBundleDescription2, ExportPackageDescription[] paramArrayOfExportPackageDescription2);
  
  void resolveBundle(BundleDescription paramBundleDescription, boolean paramBoolean, BundleDescription[] paramArrayOfBundleDescription1, ExportPackageDescription[] paramArrayOfExportPackageDescription1, ExportPackageDescription[] paramArrayOfExportPackageDescription2, BundleDescription[] paramArrayOfBundleDescription2, ExportPackageDescription[] paramArrayOfExportPackageDescription3);
  
  void resolveBundle(BundleDescription paramBundleDescription, boolean paramBoolean, BundleDescription[] paramArrayOfBundleDescription1, ExportPackageDescription[] paramArrayOfExportPackageDescription1, ExportPackageDescription[] paramArrayOfExportPackageDescription2, GenericDescription[] paramArrayOfGenericDescription1, BundleDescription[] paramArrayOfBundleDescription2, ExportPackageDescription[] paramArrayOfExportPackageDescription3, GenericDescription[] paramArrayOfGenericDescription2, Map<String, List<StateWire>> paramMap);
  
  void removeBundleComplete(BundleDescription paramBundleDescription);
  
  void addResolverError(BundleDescription paramBundleDescription, int paramInt, String paramString, VersionConstraint paramVersionConstraint);
  
  void removeResolverErrors(BundleDescription paramBundleDescription);
  
  ResolverError[] getResolverErrors(BundleDescription paramBundleDescription);
  
  Resolver getResolver();
  
  void setResolver(Resolver paramResolver);
  
  StateDelta resolve(boolean paramBoolean);
  
  StateDelta resolve();
  
  StateDelta resolve(BundleDescription[] paramArrayOfBundleDescription);
  
  StateDelta resolve(BundleDescription[] paramArrayOfBundleDescription, boolean paramBoolean);
  
  void setOverrides(Object paramObject);
  
  BundleDescription[] getResolvedBundles();
  
  BundleDescription[] getRemovalPending();
  
  Collection<BundleDescription> getDependencyClosure(Collection<BundleDescription> paramCollection);
  
  boolean isEmpty();
  
  ExportPackageDescription[] getExportedPackages();
  
  BundleDescription[] getBundles(String paramString);
  
  StateObjectFactory getFactory();
  
  ExportPackageDescription linkDynamicImport(BundleDescription paramBundleDescription, String paramString);
  
  void addDynamicImportPackages(BundleDescription paramBundleDescription, ImportPackageSpecification[] paramArrayOfImportPackageSpecification);
  
  boolean setPlatformProperties(Dictionary<?, ?> paramDictionary);
  
  boolean setPlatformProperties(Dictionary<?, ?>[] paramArrayOfDictionary);
  
  Dictionary[] getPlatformProperties();
  
  ExportPackageDescription[] getSystemPackages();
  
  StateHelper getStateHelper();
  
  long getHighestBundleId();
  
  void setNativePathsInvalid(NativeCodeDescription paramNativeCodeDescription, boolean paramBoolean);
  
  BundleDescription[] getDisabledBundles();
  
  void addDisabledInfo(DisabledInfo paramDisabledInfo);
  
  void removeDisabledInfo(DisabledInfo paramDisabledInfo);
  
  DisabledInfo[] getDisabledInfos(BundleDescription paramBundleDescription);
  
  DisabledInfo getDisabledInfo(BundleDescription paramBundleDescription, String paramString);
  
  void setResolverHookFactory(ResolverHookFactory paramResolverHookFactory);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\State.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */