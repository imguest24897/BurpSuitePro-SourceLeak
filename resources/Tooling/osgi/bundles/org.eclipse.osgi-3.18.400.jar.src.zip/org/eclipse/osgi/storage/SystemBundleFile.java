/*     */ package org.eclipse.osgi.storage;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import org.eclipse.osgi.framework.util.CaseInsensitiveDictionaryMap;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFile;
/*     */ import org.eclipse.osgi.util.ManifestElement;
/*     */ import org.osgi.framework.BundleException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SystemBundleFile
/*     */   extends BundleFile
/*     */ {
/*     */   public SystemBundleFile() {
/*  31 */     super(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public File getFile(String path, boolean nativeCode) {
/*  36 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public BundleEntry getEntry(String path) {
/*  41 */     if ("META-INF/MANIFEST.MF".equals(path)) {
/*  42 */       return new BundleEntry()
/*     */         {
/*     */           public InputStream getInputStream() throws IOException
/*     */           {
/*  46 */             return SystemBundleFile.this.getManifestURL().openStream();
/*     */           }
/*     */ 
/*     */           
/*     */           public long getSize() {
/*  51 */             return 0L;
/*     */           }
/*     */ 
/*     */           
/*     */           public String getName() {
/*  56 */             return "META-INF/MANIFEST.MF";
/*     */           }
/*     */ 
/*     */           
/*     */           public long getTime() {
/*  61 */             return 0L;
/*     */           }
/*     */ 
/*     */           
/*     */           public URL getLocalURL() {
/*  66 */             return SystemBundleFile.this.getManifestURL();
/*     */           }
/*     */ 
/*     */           
/*     */           public URL getFileURL() {
/*  71 */             return null;
/*     */           }
/*     */         };
/*     */     }
/*  75 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<String> getEntryPaths(String path, boolean recurse) {
/*  80 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() throws IOException {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsDir(String dir) {
/*  95 */     return false;
/*     */   }
/*     */   
/*     */   URL getManifestURL() {
/*  99 */     ClassLoader cl = getClass().getClassLoader();
/*     */     
/*     */     try {
/* 102 */       Enumeration<URL> manifests = (cl != null) ? cl.getResources("META-INF/MANIFEST.MF") : ClassLoader.getSystemResources("META-INF/MANIFEST.MF");
/* 103 */       while (manifests.hasMoreElements()) {
/* 104 */         URL url = manifests.nextElement();
/*     */         
/*     */         try {
/* 107 */           Map<String, String> headers = ManifestElement.parseBundleManifest(url.openStream(), (Map)new CaseInsensitiveDictionaryMap());
/* 108 */           if ("true".equals(headers.get("Eclipse-SystemBundle")))
/* 109 */             return url; 
/* 110 */         } catch (BundleException bundleException) {}
/*     */       }
/*     */     
/*     */     }
/* 114 */     catch (IOException iOException) {}
/*     */ 
/*     */     
/* 117 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\SystemBundleFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */