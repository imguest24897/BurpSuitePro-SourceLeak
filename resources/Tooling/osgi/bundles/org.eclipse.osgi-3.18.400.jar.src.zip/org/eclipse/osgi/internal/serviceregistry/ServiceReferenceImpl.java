/*     */ package org.eclipse.osgi.internal.serviceregistry;
/*     */ 
/*     */ import java.security.Permission;
/*     */ import java.util.Dictionary;
/*     */ import org.eclipse.osgi.internal.framework.DTOBuilder;
/*     */ import org.osgi.framework.AdaptPermission;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.dto.ServiceReferenceDTO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServiceReferenceImpl<S>
/*     */   implements ServiceReference<S>
/*     */ {
/*     */   private final ServiceRegistrationImpl<S> registration;
/*     */   
/*     */   ServiceReferenceImpl(ServiceRegistrationImpl<S> registration) {
/*  65 */     this.registration = registration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProperty(String key) {
/*  92 */     return this.registration.getProperty(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getPropertyKeys() {
/* 117 */     return this.registration.getPropertyKeys();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bundle getBundle() {
/* 136 */     return this.registration.getBundle();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bundle[] getUsingBundles() {
/* 153 */     return this.registration.getUsingBundles();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAssignableTo(Bundle bundle, String className) {
/* 185 */     return this.registration.isAssignableTo(bundle, className, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(Object object) {
/* 215 */     ServiceRegistrationImpl<?> other = ((ServiceReferenceImpl)object).registration;
/*     */     
/* 217 */     int thisRanking = this.registration.getRanking();
/* 218 */     int otherRanking = other.getRanking();
/* 219 */     if (thisRanking != otherRanking) {
/* 220 */       if (thisRanking < otherRanking) {
/* 221 */         return -1;
/*     */       }
/* 223 */       return 1;
/*     */     } 
/* 225 */     long thisId = this.registration.getId();
/* 226 */     long otherId = other.getId();
/* 227 */     if (thisId == otherId) {
/* 228 */       return 0;
/*     */     }
/* 230 */     if (thisId < otherId) {
/* 231 */       return 1;
/*     */     }
/* 233 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 243 */     return this.registration.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 255 */     if (obj == this) {
/* 256 */       return true;
/*     */     }
/*     */     
/* 259 */     if (!(obj instanceof ServiceReferenceImpl)) {
/* 260 */       return false;
/*     */     }
/*     */     
/* 263 */     ServiceReferenceImpl<?> other = (ServiceReferenceImpl)obj;
/*     */     
/* 265 */     return (this.registration == other.registration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 275 */     return this.registration.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceRegistrationImpl<S> getRegistration() {
/* 284 */     return this.registration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String[] getClasses() {
/* 293 */     return this.registration.getClasses();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dictionary<String, Object> getProperties() {
/* 326 */     return this.registration.getPropertiesCopy();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <A> A adapt(Class<A> type) {
/* 332 */     checkAdaptPermission(type);
/* 333 */     if (ServiceReferenceDTO.class.equals(type)) {
/* 334 */       return (A)DTOBuilder.newServiceReferenceDTO(this);
/*     */     }
/* 336 */     return null;
/*     */   }
/*     */   
/*     */   private <A> void checkAdaptPermission(Class<A> adapterType) {
/* 340 */     SecurityManager sm = System.getSecurityManager();
/* 341 */     if (sm == null) {
/*     */       return;
/*     */     }
/* 344 */     sm.checkPermission((Permission)new AdaptPermission(adapterType.getName(), this.registration.getRegisteringBundle(), "adapt"));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\serviceregistry\ServiceReferenceImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */