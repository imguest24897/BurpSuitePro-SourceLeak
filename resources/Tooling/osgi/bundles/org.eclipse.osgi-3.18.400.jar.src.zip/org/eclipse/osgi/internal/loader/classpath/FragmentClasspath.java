/*    */ package org.eclipse.osgi.internal.loader.classpath;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.eclipse.osgi.container.ModuleContainerAdaptor;
/*    */ import org.eclipse.osgi.storage.BundleInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FragmentClasspath
/*    */ {
/*    */   private final BundleInfo.Generation generation;
/*    */   private final ClasspathEntry[] entries;
/*    */   
/*    */   public FragmentClasspath(BundleInfo.Generation generation, ClasspathEntry[] entries) {
/* 32 */     this.generation = generation;
/* 33 */     this.entries = entries;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BundleInfo.Generation getGeneration() {
/* 41 */     return this.generation;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ClasspathEntry[] getEntries() {
/* 49 */     return this.entries;
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() {
/*    */     byte b;
/*    */     int i;
/*    */     ClasspathEntry[] arrayOfClasspathEntry;
/* 57 */     for (i = (arrayOfClasspathEntry = this.entries).length, b = 0; b < i; ) { ClasspathEntry entry = arrayOfClasspathEntry[b];
/*    */       try {
/* 59 */         entry.close();
/* 60 */       } catch (IOException e) {
/* 61 */         this.generation.getBundleInfo().getStorage().getAdaptor().publishContainerEvent(ModuleContainerAdaptor.ContainerEvent.ERROR, this.generation.getRevision().getRevisions().getModule(), e, new org.osgi.framework.FrameworkListener[0]);
/*    */       } 
/*    */       b++; }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\classpath\FragmentClasspath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */