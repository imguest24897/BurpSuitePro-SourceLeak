/*    */ package org.eclipse.osgi.storage.bundlefile;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import org.eclipse.osgi.storage.StorageUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BundleEntry
/*    */ {
/*    */   protected static final int BUF_SIZE = 8192;
/*    */   
/*    */   public abstract InputStream getInputStream() throws IOException;
/*    */   
/*    */   public abstract long getSize();
/*    */   
/*    */   public abstract String getName();
/*    */   
/*    */   public abstract long getTime();
/*    */   
/*    */   public abstract URL getLocalURL();
/*    */   
/*    */   public abstract URL getFileURL();
/*    */   
/*    */   public String toString() {
/* 84 */     return getName();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getBytes() throws IOException {
/* 94 */     InputStream in = getInputStream();
/* 95 */     int length = (int)getSize();
/*    */ 
/*    */     
/* 98 */     return StorageUtil.getBytes(in, length, 8192);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\bundlefile\BundleEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */