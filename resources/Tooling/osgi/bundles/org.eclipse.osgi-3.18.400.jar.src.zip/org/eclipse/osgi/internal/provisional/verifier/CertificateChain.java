package org.eclipse.osgi.internal.provisional.verifier;

import java.security.cert.Certificate;
import java.util.Date;

public interface CertificateChain {
  String getChain();
  
  Certificate[] getCertificates();
  
  Certificate getSigner();
  
  Certificate getRoot();
  
  boolean isTrusted();
  
  Date getSigningTime();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\provisional\verifier\CertificateChain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */