/*    */ package org.eclipse.osgi.framework.util;
/*    */ 
/*    */ import java.lang.management.LockInfo;
/*    */ import java.lang.management.ManagementFactory;
/*    */ import java.lang.management.MonitorInfo;
/*    */ import java.lang.management.ThreadInfo;
/*    */ import java.lang.management.ThreadMXBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ThreadInfoReport
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public ThreadInfoReport(String failedMonitor) {
/* 23 */     super(getThreadDump(failedMonitor));
/*    */   }
/*    */   
/*    */   public static String getThreadDump(String failedMonitor) {
/* 27 */     long currentId = Thread.currentThread().getId();
/* 28 */     ThreadMXBean threadMXBean = ManagementFactory.getThreadMXBean();
/* 29 */     StringBuilder dump = new StringBuilder("Thread dump");
/* 30 */     ThreadInfo[] infos = threadMXBean.dumpAllThreads(threadMXBean.isObjectMonitorUsageSupported(), threadMXBean.isSynchronizerUsageSupported()); byte b; int i; ThreadInfo[] arrayOfThreadInfo1;
/* 31 */     for (i = (arrayOfThreadInfo1 = infos).length, b = 0; b < i; ) { ThreadInfo info = arrayOfThreadInfo1[b];
/* 32 */       dumpThreadIDNameState(info, dump);
/* 33 */       dumpLockInfo(currentId, failedMonitor, info, dump);
/* 34 */       dumpStackTrace(info, dump); b++; }
/*    */     
/* 36 */     return dump.toString();
/*    */   }
/*    */   
/*    */   private static void dumpThreadIDNameState(ThreadInfo info, StringBuilder dump) {
/* 40 */     dump.append('\n').append('\n');
/* 41 */     dump.append("ThreadId: ").append(info.getThreadId());
/* 42 */     dump.append(" ThreadName: ").append(info.getThreadName());
/* 43 */     dump.append(" ThreadState: ").append(info.getThreadState());
/*    */   }
/*    */   
/*    */   private static void dumpLockInfo(long currentId, String failedMonitor, ThreadInfo info, StringBuilder dump) {
/* 47 */     dump.append('\n');
/* 48 */     dump.append("  Blocked On: ");
/* 49 */     LockInfo blockedOn = info.getLockInfo();
/* 50 */     if (blockedOn == null) {
/* 51 */       if (currentId == info.getThreadId() && failedMonitor != null) {
/* 52 */         dump.append(failedMonitor);
/*    */       } else {
/* 54 */         dump.append("none");
/*    */       } 
/*    */     } else {
/* 57 */       dump.append(blockedOn.toString());
/* 58 */       dump.append(" LockOwnerId: ").append(info.getLockOwnerId());
/* 59 */       dump.append(" LockOwnerName: ").append(info.getLockOwnerName());
/*    */     } 
/* 61 */     dump.append('\n');
/*    */     
/* 63 */     dump.append("  Synchronizers Locked: ");
/* 64 */     LockInfo[] synchronizers = info.getLockedSynchronizers();
/* 65 */     if (synchronizers.length == 0) {
/* 66 */       dump.append("none");
/*    */     } else {
/* 68 */       byte b1; int j; LockInfo[] arrayOfLockInfo; for (j = (arrayOfLockInfo = synchronizers).length, b1 = 0; b1 < j; ) { LockInfo sync = arrayOfLockInfo[b1];
/* 69 */         dump.append('\n');
/* 70 */         dump.append("    ").append(sync.toString()); b1++; }
/*    */     
/*    */     } 
/* 73 */     dump.append('\n');
/*    */     
/* 75 */     dump.append("  Monitors Locked: ");
/* 76 */     MonitorInfo[] monitors = info.getLockedMonitors();
/* 77 */     if (monitors.length == 0)
/* 78 */       dump.append("none");  byte b; int i;
/*    */     MonitorInfo[] arrayOfMonitorInfo1;
/* 80 */     for (i = (arrayOfMonitorInfo1 = monitors).length, b = 0; b < i; ) { MonitorInfo monitor = arrayOfMonitorInfo1[b];
/* 81 */       dump.append('\n');
/* 82 */       dump.append("    ").append(monitor.toString()); b++; }
/*    */     
/* 84 */     dump.append('\n');
/*    */   }
/*    */   
/*    */   private static void dumpStackTrace(ThreadInfo info, StringBuilder dump) {
/* 88 */     dump.append("  Stack Trace: "); byte b; int i; StackTraceElement[] arrayOfStackTraceElement;
/* 89 */     for (i = (arrayOfStackTraceElement = info.getStackTrace()).length, b = 0; b < i; ) { StackTraceElement e = arrayOfStackTraceElement[b];
/* 90 */       dump.append('\n').append("    ").append(e);
/*    */       b++; }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\framewor\\util\ThreadInfoReport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */