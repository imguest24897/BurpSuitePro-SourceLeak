/*     */ package org.eclipse.osgi.internal.url;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.net.URLStreamHandler;
/*     */ import java.net.URLStreamHandlerFactory;
/*     */ import java.security.AccessController;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.eclipse.osgi.framework.util.SecureAction;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.storage.url.bundleentry.Handler;
/*     */ import org.eclipse.osgi.storage.url.bundleresource.Handler;
/*     */ import org.eclipse.osgi.storage.url.reference.Handler;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.service.url.URLStreamHandlerService;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class URLStreamHandlerFactoryImpl
/*     */   extends MultiplexingFactory
/*     */   implements URLStreamHandlerFactory
/*     */ {
/*     */   protected static final String URLSTREAMHANDLERCLASS = "org.osgi.service.url.URLStreamHandlerService";
/*     */   protected static final String PROTOCOL_HANDLER_PKGS = "java.protocol.handler.pkgs";
/*     */   public static final String PROTOCOL_REFERENCE = "reference";
/*  41 */   static final SecureAction secureAction = AccessController.<SecureAction>doPrivileged(SecureAction.createSecureAction());
/*     */   
/*     */   private ServiceTracker<URLStreamHandlerService, URLStreamHandlerService> handlerTracker;
/*     */   
/*  45 */   private static final List<Class<?>> ignoredClasses = Arrays.asList(new Class[] { MultiplexingURLStreamHandler.class, URLStreamHandlerFactoryImpl.class, URL.class });
/*     */   private Map<String, URLStreamHandler> proxies;
/*     */   private URLStreamHandlerFactory parentFactory;
/*  48 */   private ThreadLocal<List<String>> creatingProtocols = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URLStreamHandlerFactoryImpl(BundleContext context, EquinoxContainer container) {
/*  56 */     super(context, container);
/*     */     
/*  58 */     this.proxies = new Hashtable<>(15);
/*  59 */     this.handlerTracker = new ServiceTracker(context, "org.osgi.service.url.URLStreamHandlerService", null);
/*  60 */     this.handlerTracker.open();
/*     */   }
/*     */   
/*     */   private Class<?> getBuiltIn(String protocol, String builtInHandlers) {
/*  64 */     if (builtInHandlers == null) {
/*  65 */       return null;
/*     */     }
/*  67 */     StringTokenizer tok = new StringTokenizer(builtInHandlers, "|");
/*  68 */     while (tok.hasMoreElements()) {
/*  69 */       StringBuilder name = new StringBuilder();
/*  70 */       name.append(tok.nextToken());
/*  71 */       name.append(".");
/*  72 */       name.append(protocol);
/*  73 */       name.append(".Handler");
/*     */       try {
/*  75 */         Class<?> clazz = secureAction.loadSystemClass(name.toString());
/*  76 */         if (clazz != null)
/*  77 */           return clazz; 
/*  78 */       } catch (ClassNotFoundException classNotFoundException) {}
/*     */     } 
/*     */ 
/*     */     
/*  82 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URLStreamHandler createURLStreamHandler(String protocol) {
/*  95 */     if (isRecursive(protocol)) {
/*  96 */       return null;
/*     */     }
/*     */     try {
/*  99 */       String builtInHandlers = secureAction.getProperty("java.protocol.handler.pkgs");
/* 100 */       Class<?> clazz = getBuiltIn(protocol, builtInHandlers);
/* 101 */       if (clazz != null)
/* 102 */         return null; 
/* 103 */       URLStreamHandler result = null;
/* 104 */       if (isMultiplexing()) {
/* 105 */         URLStreamHandler authorized = findAuthorizedURLStreamHandler(protocol);
/* 106 */         if (authorized != null)
/* 107 */           result = new MultiplexingURLStreamHandler(protocol, this, authorized); 
/*     */       } else {
/* 109 */         result = createInternalURLStreamHandler(protocol);
/*     */       } 
/*     */       
/* 112 */       if (result == null && this.parentFactory != null)
/* 113 */         result = this.parentFactory.createURLStreamHandler(protocol); 
/* 114 */       return result;
/* 115 */     } catch (Throwable t) {
/* 116 */       this.container.getLogServices().log(URLStreamHandlerFactoryImpl.class.getName(), 4, "Unexpected error in factory.", t);
/* 117 */       return null;
/*     */     } finally {
/* 119 */       releaseRecursive(protocol);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isRecursive(String protocol) {
/* 124 */     List<String> protocols = this.creatingProtocols.get();
/* 125 */     if (protocols == null) {
/* 126 */       protocols = new ArrayList<>(1);
/* 127 */       this.creatingProtocols.set(protocols);
/*     */     } 
/* 129 */     if (protocols.contains(protocol))
/* 130 */       return true; 
/* 131 */     protocols.add(protocol);
/* 132 */     return false;
/*     */   }
/*     */   
/*     */   private void releaseRecursive(String protocol) {
/* 136 */     List<String> protocols = this.creatingProtocols.get();
/* 137 */     protocols.remove(protocol);
/*     */   }
/*     */   
/*     */   private URLStreamHandler getFrameworkHandler(String protocol) {
/* 141 */     if ("bundleentry".equals(protocol))
/* 142 */       return (URLStreamHandler)new Handler(this.container.getStorage().getModuleContainer(), null); 
/* 143 */     if ("bundleresource".equals(protocol))
/* 144 */       return (URLStreamHandler)new Handler(this.container.getStorage().getModuleContainer(), null); 
/* 145 */     if ("reference".equals(protocol)) {
/* 146 */       return (URLStreamHandler)new Handler(this.container.getConfiguration().getConfiguration("osgi.install.area"));
/*     */     }
/* 148 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public URLStreamHandler createInternalURLStreamHandler(String protocol) {
/* 153 */     URLStreamHandler frameworkHandler = getFrameworkHandler(protocol);
/* 154 */     if (frameworkHandler != null) {
/* 155 */       return frameworkHandler;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 160 */     URLStreamHandlerProxy handler = (URLStreamHandlerProxy)this.proxies.get(protocol);
/* 161 */     if (handler != null) {
/* 162 */       return handler;
/*     */     }
/* 164 */     ServiceReference[] serviceReferences = this.handlerTracker.getServiceReferences();
/* 165 */     if (serviceReferences == null)
/* 166 */       return null;  byte b; int i; ServiceReference[] arrayOfServiceReference1;
/* 167 */     for (i = (arrayOfServiceReference1 = serviceReferences).length, b = 0; b < i; ) { ServiceReference<URLStreamHandlerService> serviceReference = arrayOfServiceReference1[b];
/* 168 */       Object prop = serviceReference.getProperty("url.handler.protocol");
/* 169 */       if (prop instanceof String)
/* 170 */         prop = new String[] { (String)prop }; 
/* 171 */       if (!(prop instanceof String[])) {
/* 172 */         String message = NLS.bind(Msg.URL_HANDLER_INCORRECT_TYPE, new Object[] { "url.handler.protocol", "org.osgi.service.url.URLStreamHandlerService", serviceReference.getBundle() });
/* 173 */         this.container.getLogServices().log("org.eclipse.osgi", 2, message, null);
/*     */       } else {
/*     */         
/* 176 */         String[] protocols = (String[])prop; byte b1; int j; String[] arrayOfString1;
/* 177 */         for (j = (arrayOfString1 = protocols).length, b1 = 0; b1 < j; ) { String candidateProtocol = arrayOfString1[b1];
/* 178 */           if (candidateProtocol.equals(protocol)) {
/* 179 */             handler = new URLStreamHandlerProxy(protocol, serviceReference, this.context);
/* 180 */             this.proxies.put(protocol, handler);
/* 181 */             return handler;
/*     */           }  b1++; }
/*     */       
/*     */       }  b++; }
/* 185 */      return null;
/*     */   }
/*     */   
/*     */   protected URLStreamHandler findAuthorizedURLStreamHandler(String protocol) {
/* 189 */     Object factory = findAuthorizedFactory(ignoredClasses);
/* 190 */     if (factory == null) {
/* 191 */       return null;
/*     */     }
/* 193 */     if (factory == this) {
/* 194 */       return createInternalURLStreamHandler(protocol);
/*     */     }
/*     */     try {
/* 197 */       Method createInternalURLStreamHandlerMethod = factory.getClass().getMethod("createInternalURLStreamHandler", new Class[] { String.class });
/* 198 */       return (URLStreamHandler)createInternalURLStreamHandlerMethod.invoke(factory, new Object[] { protocol });
/* 199 */     } catch (Exception e) {
/* 200 */       this.container.getLogServices().log(URLStreamHandlerFactoryImpl.class.getName(), 4, "findAuthorizedURLStreamHandler-loop", e);
/* 201 */       throw new RuntimeException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getParentFactory() {
/* 207 */     return this.parentFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setParentFactory(Object parentFactory) {
/* 212 */     if (this.parentFactory == null)
/* 213 */       this.parentFactory = (URLStreamHandlerFactory)parentFactory; 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\interna\\url\URLStreamHandlerFactoryImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */