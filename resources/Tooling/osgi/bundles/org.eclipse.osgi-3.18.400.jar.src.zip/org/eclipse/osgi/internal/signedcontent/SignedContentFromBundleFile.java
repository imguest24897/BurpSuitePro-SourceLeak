/*     */ package org.eclipse.osgi.internal.signedcontent;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.security.CodeSigner;
/*     */ import java.security.Timestamp;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateExpiredException;
/*     */ import java.security.cert.CertificateNotYetValidException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.zip.ZipFile;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.signedcontent.InvalidContentException;
/*     */ import org.eclipse.osgi.signedcontent.SignedContent;
/*     */ import org.eclipse.osgi.signedcontent.SignedContentEntry;
/*     */ import org.eclipse.osgi.signedcontent.SignerInfo;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFile;
/*     */ import org.eclipse.osgi.storage.bundlefile.DirBundleFile;
/*     */ import org.eclipse.osgi.storage.bundlefile.ZipBundleFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignedContentFromBundleFile
/*     */   implements SignedContent
/*     */ {
/*     */   static abstract class BaseSignerInfo
/*     */     implements SignerInfo
/*     */   {
/*  49 */     private volatile Certificate trustAnchor = null;
/*     */     
/*     */     public Certificate getTrustAnchor() {
/*  52 */       return this.trustAnchor;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isTrusted() {
/*  57 */       return (this.trustAnchor != null);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public String getMessageDigestAlgorithm() {
/*  63 */       return "unknown";
/*     */     }
/*     */     
/*     */     void setTrustAnchor(Certificate anchor) {
/*  67 */       this.trustAnchor = anchor;
/*     */     }
/*     */   }
/*     */   
/*     */   static class TimestampSignerInfo extends BaseSignerInfo {
/*     */     private final Timestamp timestamp;
/*     */     
/*     */     public TimestampSignerInfo(Timestamp timestamp) {
/*  75 */       this.timestamp = timestamp;
/*     */     }
/*     */ 
/*     */     
/*     */     public Certificate[] getCertificateChain() {
/*  80 */       return this.timestamp.getSignerCertPath().getCertificates().<Certificate>toArray(new Certificate[0]);
/*     */     }
/*     */     
/*     */     Date getTimestamp() {
/*  84 */       return this.timestamp.getTimestamp();
/*     */     }
/*     */   }
/*     */   
/*     */   static class CodeSignerInfo extends BaseSignerInfo {
/*     */     private final CodeSigner codeSigner;
/*     */     private final SignedContentFromBundleFile.TimestampSignerInfo timestamp;
/*     */     
/*     */     public CodeSignerInfo(CodeSigner codeSigner) {
/*  93 */       this.codeSigner = codeSigner;
/*  94 */       Timestamp ts = codeSigner.getTimestamp();
/*  95 */       this.timestamp = (ts == null) ? null : new SignedContentFromBundleFile.TimestampSignerInfo(ts);
/*     */     }
/*     */ 
/*     */     
/*     */     public Certificate[] getCertificateChain() {
/* 100 */       return this.codeSigner.getSignerCertPath().getCertificates().<Certificate>toArray(new Certificate[0]);
/*     */     }
/*     */     
/*     */     SignedContentFromBundleFile.TimestampSignerInfo getTSASignerInfo() {
/* 104 */       return this.timestamp;
/*     */     }
/*     */   }
/*     */   
/*     */   static class CodeSignerEntry implements SignedContentEntry {
/*     */     private final String name;
/*     */     private final List<SignedContentFromBundleFile.CodeSignerInfo> signerInfos;
/*     */     
/*     */     public CodeSignerEntry(List<SignedContentFromBundleFile.CodeSignerInfo> signerInfos, String name) {
/* 113 */       this.name = name;
/* 114 */       this.signerInfos = signerInfos;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 119 */       return this.name;
/*     */     }
/*     */ 
/*     */     
/*     */     public SignerInfo[] getSignerInfos() {
/* 124 */       return this.signerInfos.<SignerInfo>toArray(new SignerInfo[0]);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isSigned() {
/* 129 */       return !this.signerInfos.isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public void verify() throws IOException, InvalidContentException {}
/*     */   }
/*     */ 
/*     */   
/*     */   static class CorruptEntry
/*     */     implements SignedContentEntry
/*     */   {
/*     */     final InvalidContentException verifyError;
/*     */     final String name;
/*     */     
/*     */     public String getName() {
/* 144 */       return this.name;
/*     */     }
/*     */ 
/*     */     
/*     */     public SignerInfo[] getSignerInfos() {
/* 149 */       return new SignerInfo[0];
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isSigned() {
/* 154 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void verify() throws IOException, InvalidContentException {
/* 159 */       throw this.verifyError;
/*     */     }
/*     */ 
/*     */     
/*     */     public CorruptEntry(InvalidContentException verifyError, String name) {
/* 164 */       this.verifyError = verifyError;
/* 165 */       this.name = name;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 170 */   private final List<CodeSignerInfo> signerInfos = new ArrayList<>();
/*     */   private final Map<String, SignedContentEntry> signedEntries;
/*     */   
/*     */   public SignedContentFromBundleFile(BundleFile bundleFile) throws IOException {
/* 174 */     this.signedEntries = getSignedEntries(() -> {
/*     */           try {
/*     */             return getJarInputStream(paramBundleFile);
/* 177 */           } catch (IOException e) {
/*     */             throw new UncheckedIOException(e);
/*     */           } 
/* 180 */         }() -> paramBundleFile, this.signerInfos);
/*     */   }
/*     */   
/*     */   public SignedContentFromBundleFile(File bundleFile, Debug debug) throws IOException {
/* 184 */     DirBundleFile tmpDirBundleFile = null;
/* 185 */     if (bundleFile.isDirectory()) {
/*     */       try {
/* 187 */         tmpDirBundleFile = new DirBundleFile(bundleFile, false);
/* 188 */       } catch (IOException iOException) {}
/*     */     }
/*     */ 
/*     */     
/* 192 */     DirBundleFile dirBundleFile = tmpDirBundleFile;
/* 193 */     this.signedEntries = getSignedEntries(() -> {
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/*     */             return (paramDirBundleFile != null) ? getJarInputStream((BundleFile)paramDirBundleFile) : new FileInputStream(paramFile);
/* 199 */           } catch (IOException e) {
/*     */             throw new UncheckedIOException(e);
/*     */           } 
/*     */         }() -> {
/*     */           try {
/*     */             if (paramDirBundleFile != null) {
/*     */               return (BundleFile)paramDirBundleFile;
/*     */             }
/*     */             
/*     */             ZipFile temp = SignedBundleHook.secureAction.getZipFile(paramFile, false);
/*     */             
/*     */             temp.close();
/*     */             
/*     */             return (BundleFile)new ZipBundleFile(paramFile, null, null, paramDebug, false);
/* 213 */           } catch (IOException e) {
/*     */             throw new UncheckedIOException(e);
/*     */           } 
/* 216 */         }this.signerInfos);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Map<String, SignedContentEntry> getSignedEntries(Supplier<InputStream> input, Supplier<BundleFile> bundleFile, List<CodeSignerInfo> signerInfos) throws IOException {
/* 221 */     Map<CodeSigner, CodeSignerInfo> codeSigners = new HashMap<>();
/* 222 */     Map<String, SignedContentEntry> signedEntries = new LinkedHashMap<>(); try {
/* 223 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 247 */     catch (SecurityException e) {
/* 248 */       Enumeration<String> paths = ((BundleFile)bundleFile.get()).getEntryPaths("", true);
/* 249 */       while (paths.hasMoreElements()) {
/* 250 */         String path = paths.nextElement();
/* 251 */         if (!path.endsWith("/") && !signedEntries.containsKey(path)) {
/* 252 */           signedEntries.put(path, new CorruptEntry(new InvalidContentException(path, e), path));
/*     */         }
/*     */       } 
/* 255 */     } catch (UncheckedIOException e) {
/* 256 */       throw e.getCause();
/*     */     } 
/* 258 */     signerInfos.addAll(codeSigners.values());
/* 259 */     return signedEntries;
/*     */   }
/*     */   
/*     */   private static InputStream getJarInputStream(BundleFile bundleFile) throws IOException {
/* 263 */     File f = bundleFile.getBaseFile();
/* 264 */     if (f == null || f.isDirectory()) {
/* 265 */       return new BundleToJarInputStream(bundleFile);
/*     */     }
/* 267 */     return new FileInputStream(f);
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedContentEntry[] getSignedEntries() {
/* 272 */     return (SignedContentEntry[])this.signedEntries.values().toArray((Object[])new SignedContentEntry[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public SignedContentEntry getSignedEntry(String name) {
/* 277 */     return this.signedEntries.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public SignerInfo[] getSignerInfos() {
/* 282 */     return this.signerInfos.<SignerInfo>toArray(new SignerInfo[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSigned() {
/* 287 */     return !this.signerInfos.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Date getSigningTime(SignerInfo signerInfo) {
/* 292 */     if (signerInfo instanceof CodeSignerInfo) {
/* 293 */       TimestampSignerInfo tsInfo = ((CodeSignerInfo)signerInfo).getTSASignerInfo();
/* 294 */       if (tsInfo != null) {
/* 295 */         return tsInfo.getTimestamp();
/*     */       }
/*     */     } 
/* 298 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SignerInfo getTSASignerInfo(SignerInfo signerInfo) {
/* 303 */     if (signerInfo instanceof CodeSignerInfo) {
/* 304 */       return ((CodeSignerInfo)signerInfo).getTSASignerInfo();
/*     */     }
/* 306 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkValidity(SignerInfo signerInfo) throws CertificateExpiredException, CertificateNotYetValidException {
/* 312 */     Date signingTime = getSigningTime(signerInfo);
/* 313 */     Certificate[] certs = signerInfo.getCertificateChain(); byte b; int i; Certificate[] arrayOfCertificate1;
/* 314 */     for (i = (arrayOfCertificate1 = certs).length, b = 0; b < i; ) { Certificate cert = arrayOfCertificate1[b];
/* 315 */       if (cert instanceof X509Certificate)
/*     */       {
/*     */         
/* 318 */         if (signingTime == null) {
/* 319 */           ((X509Certificate)cert).checkValidity();
/*     */         } else {
/* 321 */           ((X509Certificate)cert).checkValidity(signingTime);
/*     */         } 
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\signedcontent\SignedContentFromBundleFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */