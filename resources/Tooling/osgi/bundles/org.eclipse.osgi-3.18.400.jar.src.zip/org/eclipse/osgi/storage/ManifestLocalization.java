/*     */ package org.eclipse.osgi.storage;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.PropertyResourceBundle;
/*     */ import java.util.ResourceBundle;
/*     */ import org.eclipse.osgi.container.Module;
/*     */ import org.eclipse.osgi.container.ModuleWire;
/*     */ import org.eclipse.osgi.container.ModuleWiring;
/*     */ import org.eclipse.osgi.framework.util.CaseInsensitiveDictionaryMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ManifestLocalization
/*     */ {
/*     */   final String defaultRoot;
/*     */   private final BundleInfo.Generation generation;
/*     */   private final Dictionary<String, String> rawHeaders;
/*  46 */   private volatile Dictionary<String, String> defaultLocaleHeaders = null;
/*  47 */   private final Hashtable<String, BundleResourceBundle> cache = new Hashtable<>(5);
/*     */   
/*     */   public ManifestLocalization(BundleInfo.Generation generation, Dictionary<String, String> rawHeaders, String defaultRoot) {
/*  50 */     this.generation = generation;
/*  51 */     this.rawHeaders = rawHeaders;
/*  52 */     this.defaultRoot = defaultRoot;
/*     */   }
/*     */   
/*     */   public void clearCache() {
/*  56 */     synchronized (this.cache) {
/*  57 */       this.cache.clear();
/*  58 */       this.defaultLocaleHeaders = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   Dictionary<String, String> getHeaders(String localeString) {
/*  63 */     if (localeString == null)
/*  64 */       localeString = Locale.getDefault().toString(); 
/*  65 */     if (localeString.length() == 0)
/*  66 */       return this.rawHeaders; 
/*  67 */     boolean isDefaultLocale = localeString.equals(Locale.getDefault().toString());
/*  68 */     Dictionary<String, String> currentDefault = this.defaultLocaleHeaders;
/*  69 */     if (isDefaultLocale && currentDefault != null) {
/*  70 */       return currentDefault;
/*     */     }
/*  72 */     if (this.generation.getRevision().getRevisions().getModule().getState().equals(Module.State.UNINSTALLED)) {
/*     */       
/*  74 */       if (currentDefault != null)
/*  75 */         return currentDefault; 
/*  76 */       return this.rawHeaders;
/*     */     } 
/*  78 */     ResourceBundle localeProperties = getResourceBundle(localeString, isDefaultLocale);
/*  79 */     CaseInsensitiveDictionaryMap<String, String> localeHeaders = new CaseInsensitiveDictionaryMap(this.rawHeaders);
/*  80 */     for (Map.Entry<String, String> entry : (Iterable<Map.Entry<String, String>>)localeHeaders.entrySet()) {
/*  81 */       String value = entry.getValue();
/*  82 */       if (value.startsWith("%") && value.length() > 1) {
/*  83 */         String propertiesKey = value.substring(1);
/*     */         try {
/*  85 */           value = (localeProperties == null) ? propertiesKey : (String)localeProperties.getObject(propertiesKey);
/*  86 */         } catch (MissingResourceException missingResourceException) {
/*  87 */           value = propertiesKey;
/*     */         } 
/*  89 */         entry.setValue(value);
/*     */       } 
/*     */     } 
/*  92 */     Dictionary<String, String> result = localeHeaders.asUnmodifiableDictionary();
/*  93 */     if (isDefaultLocale) {
/*  94 */       this.defaultLocaleHeaders = result;
/*     */     }
/*  96 */     return result;
/*     */   }
/*     */   
/*     */   private String[] buildNLVariants(String nl) {
/* 100 */     List<String> result = new ArrayList<>();
/* 101 */     while (nl.length() > 0) {
/* 102 */       result.add(nl);
/* 103 */       String additional = getAdditionalSuffix(nl);
/* 104 */       if (additional != null) {
/* 105 */         result.add(additional);
/*     */       }
/* 107 */       int i = nl.lastIndexOf('_');
/* 108 */       nl = (i < 0) ? "" : nl.substring(0, i);
/*     */     } 
/* 110 */     result.add("");
/* 111 */     return result.<String>toArray(new String[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getAdditionalSuffix(String nl) {
/* 120 */     String additional = null;
/* 121 */     if (nl != null) {
/* 122 */       if ("he".equals(nl)) {
/* 123 */         additional = "iw";
/* 124 */       } else if (nl.startsWith("he_")) {
/* 125 */         additional = "iw_" + nl.substring(3);
/*     */       } 
/*     */     }
/* 128 */     return additional;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ResourceBundle getResourceBundle(String localeString, boolean isDefaultLocale) {
/* 136 */     BundleResourceBundle resourceBundle = lookupResourceBundle(localeString);
/* 137 */     if (isDefaultLocale) {
/* 138 */       return (ResourceBundle)resourceBundle;
/*     */     }
/*     */     
/* 141 */     if (resourceBundle == null || resourceBundle.isStemEmpty())
/* 142 */       return (ResourceBundle)lookupResourceBundle(Locale.getDefault().toString()); 
/* 143 */     return (ResourceBundle)resourceBundle;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private BundleResourceBundle lookupResourceBundle(String localeString) {
/* 149 */     String localizationHeader = this.rawHeaders.get("Bundle-Localization");
/* 150 */     if (localizationHeader == null) {
/* 151 */       localizationHeader = "OSGI-INF/l10n/bundle";
/*     */     }
/* 153 */     BundleResourceBundle result = this.cache.get(localeString);
/* 154 */     if (result != null) {
/* 155 */       return result.isEmpty() ? null : result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     String[] nlVarients = buildNLVariants(localeString);
/* 162 */     InputStream[] nlStreams = new InputStream[nlVarients.length];
/* 163 */     for (int i = nlVarients.length - 1; i >= 0; i--) {
/*     */       
/* 165 */       URL url = findResource(String.valueOf(localizationHeader) + (nlVarients[i].equals("") ? nlVarients[i] : (String.valueOf('_') + nlVarients[i])) + ".properties");
/* 166 */       if (url != null) {
/*     */         try {
/* 168 */           nlStreams[i] = url.openStream();
/* 169 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 175 */     synchronized (this.cache) {
/* 176 */       BundleResourceBundle parent = null;
/* 177 */       for (int j = nlVarients.length - 1; j >= 0; j--) {
/* 178 */         BundleResourceBundle varientBundle = null;
/* 179 */         InputStream varientStream = nlStreams[j];
/* 180 */         if (varientStream == null) {
/* 181 */           varientBundle = this.cache.get(nlVarients[j]);
/*     */         } else {
/*     */           try {
/* 184 */             varientBundle = new LocalizationResourceBundle(varientStream);
/* 185 */           } catch (IOException iOException) {
/*     */           
/*     */           } finally {
/* 188 */             if (varientStream != null) {
/*     */               try {
/* 190 */                 varientStream.close();
/* 191 */               } catch (IOException iOException) {}
/*     */             }
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 198 */         if (varientBundle == null) {
/* 199 */           varientBundle = new EmptyResouceBundle(nlVarients[j]);
/*     */         }
/* 201 */         if (parent != null)
/* 202 */           varientBundle.setParent((ResourceBundle)parent); 
/* 203 */         this.cache.put(nlVarients[j], varientBundle);
/* 204 */         parent = varientBundle;
/*     */       } 
/* 206 */       result = this.cache.get(localeString);
/* 207 */       return result.isEmpty() ? null : result;
/*     */     } 
/*     */   }
/*     */   
/*     */   private URL findResource(String resource) {
/* 212 */     ModuleWiring searchWiring = this.generation.getRevision().getWiring();
/* 213 */     if (searchWiring != null && (
/* 214 */       this.generation.getRevision().getTypes() & 0x1) != 0) {
/* 215 */       List<ModuleWire> hostWires = searchWiring.getRequiredModuleWires("osgi.wiring.host");
/* 216 */       searchWiring = null;
/* 217 */       Long lowestHost = Long.valueOf(Long.MAX_VALUE);
/* 218 */       if (hostWires != null)
/*     */       {
/* 220 */         for (ModuleWire hostWire : hostWires) {
/* 221 */           Long hostID = hostWire.getProvider().getRevisions().getModule().getId();
/* 222 */           if (hostID.compareTo(lowestHost) <= 0) {
/* 223 */             lowestHost = hostID;
/* 224 */             searchWiring = hostWire.getProviderWiring();
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 230 */     if (searchWiring != null) {
/* 231 */       int lastSlash = resource.lastIndexOf('/');
/* 232 */       String path = (lastSlash > 0) ? resource.substring(0, lastSlash) : "/";
/* 233 */       String fileName = (lastSlash != -1) ? resource.substring(lastSlash + 1) : resource;
/* 234 */       List<URL> result = searchWiring.findEntries(path, fileName, 0);
/* 235 */       return (result == null || result.isEmpty()) ? null : result.get(0);
/*     */     } 
/*     */     
/* 238 */     return this.generation.getEntry(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class LocalizationResourceBundle
/*     */     extends PropertyResourceBundle
/*     */     implements BundleResourceBundle
/*     */   {
/*     */     public LocalizationResourceBundle(InputStream in) throws IOException {
/* 251 */       super(in);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setParent(ResourceBundle parent) {
/* 256 */       super.setParent(parent);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 261 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isStemEmpty() {
/* 266 */       return (this.parent == null);
/*     */     }
/*     */   }
/*     */   
/*     */   class EmptyResouceBundle
/*     */     extends ResourceBundle implements BundleResourceBundle {
/*     */     private final String localeString;
/*     */     
/*     */     public EmptyResouceBundle(String locale) {
/* 275 */       this.localeString = locale;
/*     */     }
/*     */ 
/*     */     
/*     */     public Enumeration<String> getKeys() {
/* 280 */       return Collections.emptyEnumeration();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object handleGetObject(String arg0) throws MissingResourceException {
/* 285 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public void setParent(ResourceBundle parent) {
/* 290 */       super.setParent(parent);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty() {
/* 295 */       if (this.parent == null)
/* 296 */         return true; 
/* 297 */       return ((ManifestLocalization.BundleResourceBundle)this.parent).isEmpty();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isStemEmpty() {
/* 302 */       if (ManifestLocalization.this.defaultRoot.equals(this.localeString))
/* 303 */         return false; 
/* 304 */       if (this.parent == null)
/* 305 */         return true; 
/* 306 */       return ((ManifestLocalization.BundleResourceBundle)this.parent).isStemEmpty();
/*     */     }
/*     */   }
/*     */   
/*     */   private static interface BundleResourceBundle {
/*     */     void setParent(ResourceBundle param1ResourceBundle);
/*     */     
/*     */     boolean isEmpty();
/*     */     
/*     */     boolean isStemEmpty();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\ManifestLocalization.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */