/*    */ package org.eclipse.osgi.internal.weaving;
/*    */ 
/*    */ import java.security.Permission;
/*    */ import java.util.AbstractList;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.RandomAccess;
/*    */ import org.eclipse.osgi.util.ManifestElement;
/*    */ import org.osgi.framework.PackagePermission;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DynamicImportList
/*    */   extends AbstractList<String>
/*    */   implements RandomAccess
/*    */ {
/* 28 */   private final List<String> imports = new ArrayList<>(0);
/*    */   
/*    */   private final WovenClassImpl wovenClass;
/*    */   
/*    */   public DynamicImportList(WovenClassImpl wovenClass) {
/* 33 */     this.wovenClass = wovenClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public String get(int index) {
/* 38 */     return this.imports.get(index);
/*    */   }
/*    */ 
/*    */   
/*    */   public int size() {
/* 43 */     return this.imports.size();
/*    */   }
/*    */ 
/*    */   
/*    */   public String set(int index, String element) {
/* 48 */     this.wovenClass.checkPermission();
/* 49 */     validateSyntaxAndCheckPackagePermission(element);
/* 50 */     return this.imports.set(index, element);
/*    */   }
/*    */ 
/*    */   
/*    */   public void add(int index, String element) {
/* 55 */     this.wovenClass.checkPermission();
/* 56 */     validateSyntaxAndCheckPackagePermission(element);
/* 57 */     this.imports.add(index, element);
/*    */   }
/*    */ 
/*    */   
/*    */   public String remove(int index) {
/* 62 */     this.wovenClass.checkPermission();
/* 63 */     return this.imports.remove(index);
/*    */   }
/*    */ 
/*    */   
/*    */   private void validateSyntaxAndCheckPackagePermission(String dynamicImportPackageDescription) {
/*    */     ManifestElement[] clauses;
/*    */     try {
/* 70 */       clauses = ManifestElement.parseHeader("Import-Package", dynamicImportPackageDescription);
/* 71 */     } catch (Exception e) {
/* 72 */       throw new IllegalArgumentException(e);
/*    */     } 
/* 74 */     SecurityManager sm = System.getSecurityManager();
/* 75 */     if (sm == null)
/*    */       return;  byte b;
/*    */     int i;
/*    */     ManifestElement[] arrayOfManifestElement1;
/* 79 */     for (i = (arrayOfManifestElement1 = clauses).length, b = 0; b < i; ) { ManifestElement clause = arrayOfManifestElement1[b]; byte b1; int j; String[] arrayOfString;
/* 80 */       for (j = (arrayOfString = clause.getValueComponents()).length, b1 = 0; b1 < j; ) { String pkg = arrayOfString[b1];
/* 81 */         sm.checkPermission((Permission)new PackagePermission(pkg, "import"));
/*    */         b1++; }
/*    */       
/*    */       b++; }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\weaving\DynamicImportList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */