/*     */ package org.eclipse.osgi.internal.serviceregistry;
/*     */ 
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShrinkableValueCollectionMap<K, V>
/*     */   extends AbstractMap<K, Collection<V>>
/*     */   implements Map<K, Collection<V>>
/*     */ {
/*     */   final Map<? extends K, ? extends Set<? extends Map.Entry<?, ? extends V>>> map;
/*     */   Map<Object, Collection<V>> values;
/*     */   
/*     */   public ShrinkableValueCollectionMap(Map<? extends K, ? extends Set<? extends Map.Entry<?, ? extends V>>> m) {
/*  24 */     if (m == null) {
/*  25 */       throw new NullPointerException();
/*     */     }
/*  27 */     this.map = m;
/*  28 */     this.values = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/*  33 */     this.map.clear();
/*  34 */     if (this.values != null) {
/*  35 */       this.values.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/*  41 */     return this.map.containsKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/*  50 */     if (this.values == null) {
/*  51 */       return false;
/*     */     }
/*  53 */     return this.values.containsValue(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, Collection<V>>> entrySet() {
/*  58 */     return new EntrySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<V> get(Object key) {
/*  63 */     Collection<V> value = null;
/*  64 */     if (this.values != null) {
/*  65 */       value = this.values.get(key);
/*     */     }
/*  67 */     if (value == null) {
/*  68 */       Set<? extends Map.Entry<?, ? extends V>> entrySet = this.map.get(key);
/*  69 */       if (entrySet == null) {
/*  70 */         return null;
/*     */       }
/*  72 */       value = new ShrinkableEntrySetValueCollection<>(entrySet);
/*  73 */       if (this.values == null) {
/*  74 */         this.values = new HashMap<>(this.map.size());
/*     */       }
/*  76 */       this.values.put(key, value);
/*     */     } 
/*  78 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  83 */     return this.map.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<V> remove(Object key) {
/*  88 */     Set<? extends Map.Entry<?, ? extends V>> entrySet = this.map.remove(key);
/*  89 */     Collection<V> value = null;
/*  90 */     if (this.values != null) {
/*  91 */       value = this.values.remove(key);
/*     */     }
/*  93 */     if (value == null && entrySet != null) {
/*  94 */       value = new ShrinkableEntrySetValueCollection<>(entrySet);
/*     */     }
/*  96 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 101 */     return this.map.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class EntrySet
/*     */     extends AbstractSet<Map.Entry<K, Collection<V>>>
/*     */   {
/*     */     public Iterator<Map.Entry<K, Collection<V>>> iterator() {
/* 114 */       return new ShrinkableValueCollectionMap.EntryIterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public int size() {
/* 119 */       return ShrinkableValueCollectionMap.this.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final class EntryIterator
/*     */     implements Iterator<Map.Entry<K, Collection<V>>>
/*     */   {
/*     */     private final Iterator<? extends K> iter;
/*     */     private K last;
/*     */     
/*     */     EntryIterator() {
/* 131 */       this.iter = ShrinkableValueCollectionMap.this.map.keySet().iterator();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 136 */       return this.iter.hasNext();
/*     */     }
/*     */ 
/*     */     
/*     */     public Map.Entry<K, Collection<V>> next() {
/* 141 */       this.last = this.iter.next();
/* 142 */       return new ShrinkableValueCollectionMap.Entry(this.last);
/*     */     }
/*     */ 
/*     */     
/*     */     public void remove() {
/* 147 */       this.iter.remove();
/* 148 */       if (ShrinkableValueCollectionMap.this.values != null) {
/* 149 */         ShrinkableValueCollectionMap.this.values.remove(this.last);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private final class Entry
/*     */     implements Map.Entry<K, Collection<V>>
/*     */   {
/*     */     private final K key;
/*     */     private Collection<V> value;
/*     */     
/*     */     Entry(K k) {
/* 162 */       this.key = k;
/*     */     }
/*     */ 
/*     */     
/*     */     public K getKey() {
/* 167 */       return this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<V> getValue() {
/* 172 */       if (this.value == null) {
/* 173 */         this.value = ShrinkableValueCollectionMap.this.get(this.key);
/*     */       }
/* 175 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public Collection<V> setValue(Collection<V> value) {
/* 180 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 185 */       return (new StringBuilder()).append(getKey()).append("=").append(getValue()).toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 190 */       return ShrinkableValueCollectionMap.hash(getKey()) ^ ShrinkableValueCollectionMap.hash(getValue());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 195 */       if (obj == this) {
/* 196 */         return true;
/*     */       }
/* 198 */       if (!(obj instanceof Map.Entry)) {
/* 199 */         return false;
/*     */       }
/* 201 */       Map.Entry<?, ?> other = (Map.Entry<?, ?>)obj;
/* 202 */       return (ShrinkableValueCollectionMap.equality(getKey(), other.getKey()) && ShrinkableValueCollectionMap.equality(getValue(), other.getValue()));
/*     */     }
/*     */   }
/*     */   
/*     */   static int hash(Object one) {
/* 207 */     return (one == null) ? 0 : one.hashCode();
/*     */   }
/*     */   
/*     */   static boolean equality(Object one, Object two) {
/* 211 */     return (one == null) ? ((two == null)) : one.equals(two);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\serviceregistry\ShrinkableValueCollectionMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */