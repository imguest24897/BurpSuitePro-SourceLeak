/*     */ package org.eclipse.osgi.internal.url;
/*     */ 
/*     */ import java.lang.invoke.MethodHandles;
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxBundle;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.eclipse.osgi.storage.StorageUtil;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.FrameworkUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MultiplexingFactory
/*     */ {
/*     */   public static final Collection<AccessibleObject> setAccessible;
/*     */   static final Collection<ClassLoader> systemLoaders;
/*     */   protected EquinoxContainer container;
/*     */   protected BundleContext context;
/*     */   private List<Object> factories;
/*     */   
/*     */   static {
/*  58 */     Collection<AccessibleObject> result = null;
/*     */     
/*     */     try {
/*  61 */       Class<?> unsafeClass = Class.forName("sun.misc.Unsafe");
/*  62 */       Field theUnsafe = unsafeClass.getDeclaredField("theUnsafe");
/*     */ 
/*     */       
/*  65 */       theUnsafe.setAccessible(true);
/*  66 */       Object unsafe = theUnsafe.get(null);
/*     */ 
/*     */       
/*  69 */       byte[] bytes = StorageUtil.getBytes(MultiplexingFactory.class.getResource("SetAccessible.bytes").openStream(), -1, 4000);
/*     */       
/*  71 */       Class<Collection<AccessibleObject>> collectionClass = null;
/*     */       
/*     */       try {
/*  74 */         Method defineAnonymousClass = unsafeClass.getMethod("defineAnonymousClass", new Class[] { Class.class, byte[].class, 
/*  75 */               Object[].class });
/*     */         
/*  77 */         Class<Collection<AccessibleObject>> unchecked = (Class<Collection<AccessibleObject>>)defineAnonymousClass
/*  78 */           .invoke(unsafe, new Object[] { URL.class, bytes, null });
/*  79 */         collectionClass = unchecked;
/*     */       }
/*  81 */       catch (NoSuchMethodException noSuchMethodException) {
/*  82 */         long offset = ((Long)unsafeClass.getMethod("staticFieldOffset", new Class[] { Field.class }).invoke(unsafe, new Object[] {
/*  83 */               MethodHandles.Lookup.class.getDeclaredField("IMPL_LOOKUP") })).longValue();
/*  84 */         MethodHandles.Lookup lookup = (MethodHandles.Lookup)unsafeClass
/*  85 */           .getMethod("getObject", new Class[] { Object.class, long.class
/*  86 */             }).invoke(unsafe, new Object[] { MethodHandles.Lookup.class, Long.valueOf(offset) });
/*  87 */         lookup = lookup.in(URL.class);
/*  88 */         Class<?> classOption = Class.forName("java.lang.invoke.MethodHandles$Lookup$ClassOption");
/*  89 */         Object classOptions = Array.newInstance(classOption, 0);
/*  90 */         Method defineHiddenClass = MethodHandles.Lookup.class.getMethod("defineHiddenClass", new Class[] { byte[].class, boolean.class, 
/*  91 */               classOptions.getClass() });
/*  92 */         lookup = (MethodHandles.Lookup)defineHiddenClass.invoke(lookup, new Object[] { bytes, Boolean.FALSE, classOptions });
/*     */         
/*  94 */         Class<Collection<AccessibleObject>> unchecked = (Class)lookup
/*  95 */           .lookupClass();
/*  96 */         collectionClass = unchecked;
/*     */       } 
/*     */       
/*  99 */       result = collectionClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/* 100 */     } catch (Throwable t) {
/* 101 */       t.printStackTrace();
/*     */     } 
/*     */     
/* 104 */     setAccessible = result;
/*     */     
/* 106 */     Collection<ClassLoader> loaders = new ArrayList<>();
/*     */     try {
/* 108 */       ClassLoader cl = ClassLoader.getSystemClassLoader();
/* 109 */       while (cl != null) {
/* 110 */         loaders.add(cl);
/* 111 */         cl = cl.getParent();
/*     */       } 
/* 113 */     } catch (Throwable throwable) {}
/*     */ 
/*     */     
/* 116 */     systemLoaders = Collections.unmodifiableCollection(loaders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class InternalSecurityManager
/*     */     extends SecurityManager
/*     */   {
/*     */     public Class<?>[] getClassContext() {
/* 126 */       return super.getClassContext();
/*     */     }
/*     */   }
/*     */   
/* 130 */   private static InternalSecurityManager internalSecurityManager = new InternalSecurityManager();
/*     */   
/*     */   MultiplexingFactory(BundleContext context, EquinoxContainer container) {
/* 133 */     this.context = context;
/* 134 */     this.container = container;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMultiplexing() {
/* 143 */     return (getFactories() != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void register(Object factory) {
/*     */     try {
/* 149 */       Class<?> clazz = factory.getClass();
/* 150 */       Method setParentFactory = clazz.getMethod("setParentFactory", new Class[] { Object.class });
/* 151 */       setParentFactory.invoke(factory, new Object[] { getParentFactory() });
/* 152 */     } catch (Exception e) {
/* 153 */       this.container.getLogServices().log(MultiplexingFactory.class.getName(), 4, "register", e);
/*     */       
/*     */       return;
/*     */     } 
/* 157 */     addFactory(factory);
/*     */   }
/*     */   
/*     */   public void unregister(Object factory) {
/* 161 */     removeFactory(factory);
/*     */ 
/*     */     
/*     */     try {
/* 165 */       Method closeTracker = factory.getClass().getSuperclass().getDeclaredMethod("closePackageAdminTracker", null);
/* 166 */       closeTracker.setAccessible(true);
/* 167 */       closeTracker.invoke(factory, null);
/* 168 */     } catch (Exception e) {
/* 169 */       this.container.getLogServices().log(MultiplexingFactory.class.getName(), 4, "unregister", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object designateSuccessor() {
/* 175 */     List<Object> released = releaseFactories();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 184 */     if (released == null || released.isEmpty())
/* 185 */       return getParentFactory(); 
/* 186 */     Object successor = released.remove(0);
/*     */     try {
/* 188 */       Class<?> clazz = successor.getClass();
/* 189 */       Method register = clazz.getMethod("register", new Class[] { Object.class });
/* 190 */       for (Object r : released) {
/* 191 */         register.invoke(successor, new Object[] { r });
/*     */       } 
/* 193 */     } catch (Exception e) {
/* 194 */       this.container.getLogServices().log(MultiplexingFactory.class.getName(), 4, "designateSuccessor", e);
/* 195 */       throw new RuntimeException(e.getMessage(), e);
/*     */     } 
/* 197 */     closePackageAdminTracker();
/* 198 */     return successor;
/*     */   }
/*     */ 
/*     */   
/*     */   private void closePackageAdminTracker() {}
/*     */ 
/*     */   
/*     */   public Object findAuthorizedFactory(List<Class<?>> ignoredClasses) {
/* 206 */     List<Object> current = getFactories();
/* 207 */     Class[] classStack = internalSecurityManager.getClassContext(); byte b; int i; Class[] arrayOfClass1;
/* 208 */     for (i = (arrayOfClass1 = classStack).length, b = 0; b < i; ) { Class<?> clazz = arrayOfClass1[b];
/* 209 */       if (clazz != InternalSecurityManager.class && clazz != MultiplexingFactory.class && !ignoredClasses.contains(clazz) && !isSystemClass(clazz)) {
/*     */         
/* 211 */         if (hasAuthority(clazz))
/* 212 */           return this; 
/* 213 */         if (current != null)
/*     */         {
/* 215 */           for (Object factory : current) {
/*     */             try {
/* 217 */               Method hasAuthorityMethod = factory.getClass().getMethod("hasAuthority", new Class[] { Class.class });
/* 218 */               if (((Boolean)hasAuthorityMethod.invoke(factory, new Object[] { clazz })).booleanValue()) {
/* 219 */                 return factory;
/*     */               }
/* 221 */             } catch (Exception e) {
/* 222 */               this.container.getLogServices().log(MultiplexingFactory.class.getName(), 4, "findAuthorizedURLStreamHandler-loop", e);
/*     */             } 
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/*     */       b++; }
/*     */     
/* 230 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isSystemClass(final Class<?> clazz) {
/* 235 */     ClassLoader cl = AccessController.<ClassLoader>doPrivileged(new PrivilegedAction<ClassLoader>()
/*     */         {
/*     */           public ClassLoader run() {
/* 238 */             return clazz.getClassLoader();
/*     */           }
/*     */         });
/* 241 */     return !(cl != null && !systemLoaders.contains(cl));
/*     */   }
/*     */   
/*     */   public boolean hasAuthority(Class<?> clazz) {
/* 245 */     Bundle b = FrameworkUtil.getBundle(clazz);
/* 246 */     if (!(b instanceof EquinoxBundle)) {
/* 247 */       return false;
/*     */     }
/* 249 */     return (this.container.getStorage().getModuleContainer() == ((EquinoxBundle)b).getModule().getContainer());
/*     */   }
/*     */   
/*     */   private synchronized List<Object> getFactories() {
/* 253 */     return this.factories;
/*     */   }
/*     */   
/*     */   private synchronized List<Object> releaseFactories() {
/* 257 */     if (this.factories == null) {
/* 258 */       return null;
/*     */     }
/* 260 */     List<Object> released = new LinkedList(this.factories);
/* 261 */     this.factories = null;
/* 262 */     return released;
/*     */   }
/*     */   
/*     */   private synchronized void addFactory(Object factory) {
/* 266 */     List<Object> updated = (this.factories == null) ? new LinkedList() : new LinkedList(this.factories);
/* 267 */     updated.add(factory);
/* 268 */     this.factories = updated;
/*     */   }
/*     */   
/*     */   private synchronized void removeFactory(Object factory) {
/* 272 */     List<Object> updated = new LinkedList(this.factories);
/* 273 */     updated.remove(factory);
/* 274 */     this.factories = updated.isEmpty() ? null : updated;
/*     */   }
/*     */   
/*     */   static void setAccessible(AccessibleObject o) {
/* 278 */     if (setAccessible != null) {
/* 279 */       setAccessible.add(o);
/*     */     } else {
/* 281 */       o.setAccessible(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract void setParentFactory(Object paramObject);
/*     */   
/*     */   public abstract Object getParentFactory();
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\interna\\url\MultiplexingFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */