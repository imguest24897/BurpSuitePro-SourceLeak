package org.eclipse.osgi.service.debug;

import java.io.File;
import java.util.Map;

public interface DebugOptions {
  public static final String LISTENER_SYMBOLICNAME = "listener.symbolic.name";
  
  boolean getBooleanOption(String paramString, boolean paramBoolean);
  
  String getOption(String paramString);
  
  String getOption(String paramString1, String paramString2);
  
  int getIntegerOption(String paramString, int paramInt);
  
  Map<String, String> getOptions();
  
  void setOption(String paramString1, String paramString2);
  
  void setOptions(Map<String, String> paramMap);
  
  void removeOption(String paramString);
  
  boolean isDebugEnabled();
  
  void setDebugEnabled(boolean paramBoolean);
  
  void setFile(File paramFile);
  
  File getFile();
  
  DebugTrace newDebugTrace(String paramString);
  
  DebugTrace newDebugTrace(String paramString, Class<?> paramClass);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\debug\DebugOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */