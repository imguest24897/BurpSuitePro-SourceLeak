/*     */ package org.eclipse.osgi.internal.framework;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.eclipse.osgi.framework.eventmgr.CopyOnWriteIdentityMap;
/*     */ import org.eclipse.osgi.framework.eventmgr.EventDispatcher;
/*     */ import org.eclipse.osgi.framework.eventmgr.EventManager;
/*     */ import org.eclipse.osgi.framework.eventmgr.ListenerQueue;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.serviceregistry.ServiceRegistry;
/*     */ import org.eclipse.osgi.internal.serviceregistry.ShrinkableCollection;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleEvent;
/*     */ import org.osgi.framework.BundleListener;
/*     */ import org.osgi.framework.FrameworkEvent;
/*     */ import org.osgi.framework.FrameworkListener;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.framework.SynchronousBundleListener;
/*     */ import org.osgi.framework.hooks.bundle.EventHook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EquinoxEventPublisher
/*     */ {
/*     */   static final int FRAMEWORK_STOPPED_MASK = 1472;
/*     */   static final int BUNDLEEVENT = 1;
/*     */   static final int BUNDLEEVENTSYNC = 2;
/*     */   static final int FRAMEWORKEVENT = 4;
/*     */   private final EquinoxContainer container;
/*  55 */   private Object monitor = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EventManager eventManager;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   private final Map<BundleContextImpl, CopyOnWriteIdentityMap<BundleListener, BundleListener>> allBundleListeners = new LinkedHashMap<>();
/*     */ 
/*     */   
/*  69 */   private final Map<BundleContextImpl, CopyOnWriteIdentityMap<SynchronousBundleListener, SynchronousBundleListener>> allSyncBundleListeners = new LinkedHashMap<>();
/*     */ 
/*     */   
/*  72 */   private final Map<BundleContextImpl, CopyOnWriteIdentityMap<FrameworkListener, FrameworkListener>> allFrameworkListeners = new LinkedHashMap<>();
/*     */   
/*     */   public EquinoxEventPublisher(EquinoxContainer container) {
/*  75 */     this.container = container;
/*     */   }
/*     */ 
/*     */   
/*     */   void init() {
/*  80 */     resetEventManager(new EventManager("Framework Event Dispatcher: " + this.container.toString()));
/*     */   }
/*     */ 
/*     */   
/*     */   void close() {
/*  85 */     flushFrameworkEvents();
/*     */     
/*  87 */     resetEventManager(null);
/*     */     
/*  89 */     this.allBundleListeners.clear();
/*  90 */     this.allSyncBundleListeners.clear();
/*  91 */     this.allFrameworkListeners.clear();
/*     */   }
/*     */   
/*     */   private void resetEventManager(EventManager newEventManager) {
/*     */     EventManager currentEventManager;
/*  96 */     synchronized (this.monitor) {
/*  97 */       currentEventManager = this.eventManager;
/*  98 */       this.eventManager = newEventManager;
/*     */     } 
/* 100 */     if (currentEventManager != null) {
/* 101 */       currentEventManager.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public <K, V, E> ListenerQueue<K, V, E> newListenerQueue() {
/* 106 */     synchronized (this.monitor) {
/* 107 */       return new ListenerQueue(this.eventManager);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isEventManagerSet() {
/* 112 */     synchronized (this.monitor) {
/* 113 */       return (this.eventManager != null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void publishBundleEvent(int type, Bundle bundle, Bundle origin) {
/* 129 */     if (origin != null) {
/* 130 */       publishBundleEvent(new BundleEvent(type, bundle, origin));
/*     */     } else {
/* 132 */       publishBundleEvent(new BundleEvent(type, bundle));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void publishBundleEvent(BundleEvent event) {
/* 137 */     if (System.getSecurityManager() == null) {
/* 138 */       publishBundleEventPrivileged(event);
/*     */     } else {
/* 140 */       AccessController.doPrivileged(() -> {
/*     */             publishBundleEventPrivileged(paramBundleEvent);
/*     */             return null;
/*     */           });
/*     */     } 
/*     */   } void publishBundleEventPrivileged(BundleEvent event) {
/*     */     Map<BundleContextImpl, Set<Map.Entry<SynchronousBundleListener, SynchronousBundleListener>>> listenersSync;
/*     */     ShrinkableCollection shrinkableCollection;
/* 148 */     if (!isEventManagerSet()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 158 */     BundleContextImpl systemContext = null;
/* 159 */     Set<Map.Entry<SynchronousBundleListener, SynchronousBundleListener>> systemBundleListenersSync = null;
/* 160 */     synchronized (this.allSyncBundleListeners) {
/* 161 */       listenersSync = new LinkedHashMap<>(this.allSyncBundleListeners.size());
/* 162 */       for (Map.Entry<BundleContextImpl, CopyOnWriteIdentityMap<SynchronousBundleListener, SynchronousBundleListener>> entry : this.allSyncBundleListeners.entrySet()) {
/* 163 */         CopyOnWriteIdentityMap<SynchronousBundleListener, SynchronousBundleListener> listeners = entry.getValue();
/* 164 */         if (!listeners.isEmpty()) {
/* 165 */           Set<Map.Entry<SynchronousBundleListener, SynchronousBundleListener>> listenerEntries = listeners.entrySet();
/* 166 */           if (((BundleContextImpl)entry.getKey()).getBundleImpl().getBundleId() == 0L) {
/* 167 */             systemContext = entry.getKey();
/*     */ 
/*     */             
/* 170 */             systemBundleListenersSync = listenerEntries;
/*     */           } 
/* 172 */           listenersSync.put(entry.getKey(), listeners.entrySet());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 177 */     Map<BundleContextImpl, Set<Map.Entry<BundleListener, BundleListener>>> listenersAsync = null;
/* 178 */     Set<Map.Entry<BundleListener, BundleListener>> systemBundleListenersAsync = null;
/* 179 */     if ((event.getType() & 0x380) == 0) {
/* 180 */       synchronized (this.allBundleListeners) {
/* 181 */         listenersAsync = new LinkedHashMap<>(this.allBundleListeners.size());
/* 182 */         for (Map.Entry<BundleContextImpl, CopyOnWriteIdentityMap<BundleListener, BundleListener>> entry : this.allBundleListeners.entrySet()) {
/* 183 */           CopyOnWriteIdentityMap<BundleListener, BundleListener> listeners = entry.getValue();
/* 184 */           if (!listeners.isEmpty()) {
/* 185 */             Set<Map.Entry<BundleListener, BundleListener>> listenerEntries = listeners.entrySet();
/* 186 */             if (((BundleContextImpl)entry.getKey()).getBundleImpl().getBundleId() == 0L) {
/* 187 */               systemContext = entry.getKey();
/*     */ 
/*     */               
/* 190 */               systemBundleListenersAsync = listenerEntries;
/*     */             } 
/* 192 */             listenersAsync.put(entry.getKey(), listenerEntries);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 204 */     if (listenersAsync == null) {
/* 205 */       Collection<BundleContext> shrinkable = asBundleContexts(listenersSync.keySet());
/*     */     } else {
/* 207 */       shrinkableCollection = new ShrinkableCollection(asBundleContexts(listenersSync.keySet()), asBundleContexts(listenersAsync.keySet()));
/*     */     } 
/*     */     
/* 210 */     notifyEventHooksPrivileged(event, (Collection<BundleContext>)shrinkableCollection);
/*     */ 
/*     */     
/* 213 */     if (systemBundleListenersSync != null && !listenersSync.containsKey(systemContext)) {
/* 214 */       listenersSync.put(systemContext, systemBundleListenersSync);
/*     */     }
/* 216 */     if (systemBundleListenersAsync != null && !listenersAsync.containsKey(systemContext)) {
/* 217 */       listenersAsync.put(systemContext, systemBundleListenersAsync);
/*     */     }
/*     */ 
/*     */     
/* 221 */     if (!listenersSync.isEmpty()) {
/* 222 */       ListenerQueue<SynchronousBundleListener, SynchronousBundleListener, BundleEvent> queue = newListenerQueue();
/* 223 */       for (Map.Entry<BundleContextImpl, Set<Map.Entry<SynchronousBundleListener, SynchronousBundleListener>>> entry : listenersSync.entrySet()) {
/*     */         
/* 225 */         EventDispatcher<SynchronousBundleListener, SynchronousBundleListener, BundleEvent> dispatcher = entry.getKey();
/* 226 */         Set<Map.Entry<SynchronousBundleListener, SynchronousBundleListener>> listeners = entry.getValue();
/* 227 */         queue.queueListeners(listeners, dispatcher);
/*     */       } 
/* 229 */       queue.dispatchEventSynchronous(2, event);
/*     */     } 
/*     */ 
/*     */     
/* 233 */     if (listenersAsync != null && !listenersAsync.isEmpty()) {
/* 234 */       ListenerQueue<BundleListener, BundleListener, BundleEvent> queue = newListenerQueue();
/* 235 */       for (Map.Entry<BundleContextImpl, Set<Map.Entry<BundleListener, BundleListener>>> entry : listenersAsync.entrySet()) {
/*     */         
/* 237 */         EventDispatcher<BundleListener, BundleListener, BundleEvent> dispatcher = entry.getKey();
/* 238 */         Set<Map.Entry<BundleListener, BundleListener>> listeners = entry.getValue();
/* 239 */         queue.queueListeners(listeners, dispatcher);
/*     */       } 
/* 241 */       queue.dispatchEventAsynchronous(1, event);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void notifyEventHooksPrivileged(BundleEvent event, Collection<BundleContext> result) {
/* 246 */     if ((this.container.getConfiguration().getDebug()).DEBUG_HOOKS) {
/* 247 */       Debug.println("notifyBundleEventHooks(" + event.getType() + ":" + event.getBundle() + ", " + result + " )");
/*     */     }
/*     */     
/* 250 */     ServiceRegistry serviceRegistry = this.container.getServiceRegistry();
/* 251 */     if (serviceRegistry != null) {
/* 252 */       serviceRegistry.notifyHooksPrivileged(EventHook.class, "event", (hook, r) -> hook.event(paramBundleEvent, paramCollection));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void publishFrameworkEvent(int type, Bundle bundle, Throwable throwable) {
/* 267 */     publishFrameworkEvent(type, bundle, throwable, null);
/*     */   }
/*     */   
/*     */   public void publishFrameworkEvent(int type, Bundle bundle, Throwable throwable, FrameworkListener... listeners) {
/* 271 */     if (bundle == null)
/* 272 */       bundle = this.container.getStorage().getModuleContainer().getModule(0L).getBundle(); 
/* 273 */     FrameworkEvent event = new FrameworkEvent(type, bundle, throwable);
/* 274 */     if (System.getSecurityManager() == null) {
/* 275 */       publishFrameworkEventPrivileged(event, listeners);
/*     */     } else {
/* 277 */       AccessController.doPrivileged(() -> {
/*     */             publishFrameworkEventPrivileged(paramFrameworkEvent, paramArrayOfFrameworkListener);
/*     */             return null;
/*     */           });
/*     */     } 
/*     */   }
/*     */   public void publishFrameworkEventPrivileged(FrameworkEvent event, FrameworkListener... callerListeners) {
/*     */     Map<BundleContextImpl, Set<Map.Entry<FrameworkListener, FrameworkListener>>> listenerSnapshot;
/* 285 */     if (!isEventManagerSet()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 290 */     synchronized (this.allFrameworkListeners) {
/* 291 */       listenerSnapshot = new LinkedHashMap<>(this.allFrameworkListeners.size());
/* 292 */       for (Map.Entry<BundleContextImpl, CopyOnWriteIdentityMap<FrameworkListener, FrameworkListener>> entry : this.allFrameworkListeners.entrySet()) {
/* 293 */         CopyOnWriteIdentityMap<FrameworkListener, FrameworkListener> listeners = entry.getValue();
/* 294 */         if (!listeners.isEmpty()) {
/* 295 */           listenerSnapshot.put(entry.getKey(), listeners.entrySet());
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 302 */     ListenerQueue<FrameworkListener, FrameworkListener, FrameworkEvent> queue = newListenerQueue();
/*     */ 
/*     */     
/* 305 */     if (callerListeners != null && callerListeners.length > 0) {
/* 306 */       Map<FrameworkListener, FrameworkListener> listeners = new HashMap<>(); byte b; int i; FrameworkListener[] arrayOfFrameworkListener;
/* 307 */       for (i = (arrayOfFrameworkListener = callerListeners).length, b = 0; b < i; ) { FrameworkListener listener = arrayOfFrameworkListener[b];
/* 308 */         if (listener != null)
/* 309 */           listeners.put(listener, listener); 
/*     */         b++; }
/*     */       
/* 312 */       if (listeners.size() > 0) {
/* 313 */         BundleContextImpl systemContext = (BundleContextImpl)this.container.getStorage().getModuleContainer().getModule(0L).getBundle().getBundleContext();
/*     */         
/* 315 */         EventDispatcher<FrameworkListener, FrameworkListener, FrameworkEvent> dispatcher = systemContext;
/* 316 */         queue.queueListeners(listeners.entrySet(), dispatcher);
/*     */       } 
/*     */     } 
/*     */     
/* 320 */     for (Map.Entry<BundleContextImpl, Set<Map.Entry<FrameworkListener, FrameworkListener>>> entry : listenerSnapshot.entrySet()) {
/*     */       
/* 322 */       EventDispatcher<FrameworkListener, FrameworkListener, FrameworkEvent> dispatcher = entry.getKey();
/* 323 */       Set<Map.Entry<FrameworkListener, FrameworkListener>> listeners = entry.getValue();
/* 324 */       queue.queueListeners(listeners, dispatcher);
/*     */     } 
/*     */     
/* 327 */     queue.dispatchEventAsynchronous(4, event);
/*     */     
/* 329 */     if ((event.getType() & 0x5C0) != 0) {
/* 330 */       close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Collection<BundleContext> asBundleContexts(Collection<? extends BundleContext> c) {
/* 342 */     return (Collection)c;
/*     */   }
/*     */   
/*     */   void addBundleListener(BundleListener listener, BundleContextImpl context) {
/* 346 */     if (listener instanceof SynchronousBundleListener) {
/* 347 */       this.container.checkAdminPermission(context.getBundle(), "listener");
/* 348 */       synchronized (this.allSyncBundleListeners) {
/* 349 */         CopyOnWriteIdentityMap<SynchronousBundleListener, SynchronousBundleListener> listeners = this.allSyncBundleListeners.get(context);
/* 350 */         if (listeners == null) {
/* 351 */           listeners = new CopyOnWriteIdentityMap();
/* 352 */           this.allSyncBundleListeners.put(context, listeners);
/*     */         } 
/* 354 */         listeners.put(listener, listener);
/*     */       } 
/*     */     } else {
/* 357 */       synchronized (this.allBundleListeners) {
/* 358 */         CopyOnWriteIdentityMap<BundleListener, BundleListener> listeners = this.allBundleListeners.get(context);
/* 359 */         if (listeners == null) {
/* 360 */           listeners = new CopyOnWriteIdentityMap();
/* 361 */           this.allBundleListeners.put(context, listeners);
/*     */         } 
/* 363 */         listeners.put(listener, listener);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void removeBundleListener(BundleListener listener, BundleContextImpl context) {
/* 369 */     if (listener instanceof SynchronousBundleListener) {
/* 370 */       this.container.checkAdminPermission(context.getBundle(), "listener");
/* 371 */       synchronized (this.allSyncBundleListeners) {
/* 372 */         CopyOnWriteIdentityMap<SynchronousBundleListener, SynchronousBundleListener> listeners = this.allSyncBundleListeners.get(context);
/* 373 */         if (listeners != null)
/* 374 */           listeners.remove(listener); 
/*     */       } 
/*     */     } else {
/* 377 */       synchronized (this.allBundleListeners) {
/* 378 */         CopyOnWriteIdentityMap<BundleListener, BundleListener> listeners = this.allBundleListeners.get(context);
/* 379 */         if (listeners != null)
/* 380 */           listeners.remove(listener); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void addFrameworkListener(FrameworkListener listener, BundleContextImpl context) {
/* 386 */     synchronized (this.allFrameworkListeners) {
/* 387 */       CopyOnWriteIdentityMap<FrameworkListener, FrameworkListener> listeners = this.allFrameworkListeners.get(context);
/* 388 */       if (listeners == null) {
/* 389 */         listeners = new CopyOnWriteIdentityMap();
/* 390 */         this.allFrameworkListeners.put(context, listeners);
/*     */       } 
/* 392 */       listeners.put(listener, listener);
/*     */     } 
/*     */   }
/*     */   
/*     */   void removeFrameworkListener(FrameworkListener listener, BundleContextImpl context) {
/* 397 */     synchronized (this.allFrameworkListeners) {
/* 398 */       CopyOnWriteIdentityMap<FrameworkListener, FrameworkListener> listeners = this.allFrameworkListeners.get(context);
/* 399 */       if (listeners != null) {
/* 400 */         listeners.remove(listener);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   void removeAllListeners(BundleContextImpl context) {
/* 406 */     if (context.getBundleImpl().getBundleId() != 0L) {
/* 407 */       synchronized (this.allBundleListeners) {
/* 408 */         this.allBundleListeners.remove(context);
/*     */       } 
/* 410 */       synchronized (this.allSyncBundleListeners) {
/* 411 */         this.allSyncBundleListeners.remove(context);
/*     */       } 
/*     */     } 
/* 414 */     synchronized (this.allFrameworkListeners) {
/* 415 */       this.allFrameworkListeners.remove(context);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void flushFrameworkEvents() {
/* 421 */     EventDispatcher<Object, Object, CountDownLatch> dispatcher = (el, lo, ea, signal) -> signal.countDown();
/*     */     
/* 423 */     ListenerQueue<Object, Object, CountDownLatch> queue = newListenerQueue();
/* 424 */     queue.queueListeners(Collections.<EventDispatcher<Object, Object, CountDownLatch>, EventDispatcher<Object, Object, CountDownLatch>>singletonMap(dispatcher, dispatcher).entrySet(), dispatcher);
/*     */ 
/*     */     
/* 427 */     CountDownLatch flushedSignal = new CountDownLatch(1);
/* 428 */     queue.dispatchEventAsynchronous(0, flushedSignal);
/*     */ 
/*     */     
/*     */     try {
/* 432 */       flushedSignal.await(30L, TimeUnit.SECONDS);
/* 433 */     } catch (InterruptedException interruptedException) {
/*     */       
/* 435 */       Thread.currentThread().interrupt();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\framework\EquinoxEventPublisher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */