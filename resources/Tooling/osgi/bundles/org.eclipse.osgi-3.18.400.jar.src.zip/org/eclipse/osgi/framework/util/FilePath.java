/*     */ package org.eclipse.osgi.framework.util;
/*     */ 
/*     */ import java.io.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilePath
/*     */ {
/*  29 */   private static final boolean WINDOWS = (File.separatorChar == '\\');
/*     */   
/*     */   private static final String CURRENT_DIR = ".";
/*     */   
/*     */   private static final char DEVICE_SEPARATOR = ':';
/*     */   private static final byte HAS_LEADING = 1;
/*     */   private static final byte HAS_TRAILING = 4;
/*  36 */   private static final String[] NO_SEGMENTS = new String[0];
/*     */   
/*     */   private static final String PARENT_DIR = "..";
/*     */   
/*     */   private static final char SEPARATOR = '/';
/*     */   
/*     */   private static final String UNC_SLASHES = "//";
/*     */   
/*     */   private String device;
/*     */   
/*     */   private byte flags;
/*     */   
/*     */   private String[] segments;
/*     */   
/*     */   public FilePath(File location) {
/*  51 */     initialize(location.getPath());
/*  52 */     if (location.isDirectory()) {
/*  53 */       this.flags = (byte)(this.flags | 0x4);
/*     */     } else {
/*  55 */       this.flags = (byte)(this.flags & 0xFFFFFFFB);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FilePath(String original) {
/*  64 */     initialize(original);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int computeSegmentCount(String path) {
/*  71 */     int len = path.length();
/*  72 */     if (len == 0 || (len == 1 && path.charAt(0) == '/'))
/*  73 */       return 0; 
/*  74 */     int count = 1;
/*  75 */     int prev = -1;
/*     */     int i;
/*  77 */     while ((i = path.indexOf('/', prev + 1)) != -1) {
/*  78 */       if (i != prev + 1 && i != len)
/*  79 */         count++; 
/*  80 */       prev = i;
/*     */     } 
/*  82 */     if (path.charAt(len - 1) == '/')
/*  83 */       count--; 
/*  84 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] computeSegments(String path) {
/*  91 */     int maxSegmentCount = computeSegmentCount(path);
/*  92 */     if (maxSegmentCount == 0)
/*  93 */       return NO_SEGMENTS; 
/*  94 */     String[] newSegments = new String[maxSegmentCount];
/*  95 */     int len = path.length();
/*     */     
/*  97 */     int firstPosition = isAbsolute() ? 1 : 0;
/*  98 */     int lastPosition = hasTrailingSlash() ? (len - 2) : (len - 1);
/*     */ 
/*     */ 
/*     */     
/* 102 */     int next = firstPosition;
/* 103 */     int actualSegmentCount = 0;
/* 104 */     for (int i = 0; i < maxSegmentCount; i++) {
/* 105 */       int start = next;
/* 106 */       int end = path.indexOf('/', next);
/* 107 */       next = end + 1;
/* 108 */       String segment = path.substring(start, (end == -1) ? (lastPosition + 1) : end);
/* 109 */       if (!".".equals(segment))
/*     */       {
/* 111 */         if ("..".equals(segment)) {
/* 112 */           if (actualSegmentCount > 0) {
/* 113 */             actualSegmentCount--;
/*     */           }
/*     */         } else {
/* 116 */           newSegments[actualSegmentCount++] = segment;
/*     */         }  } 
/* 118 */     }  if (actualSegmentCount == newSegments.length)
/* 119 */       return newSegments; 
/* 120 */     if (actualSegmentCount == 0)
/* 121 */       return NO_SEGMENTS; 
/* 122 */     String[] actualSegments = new String[actualSegmentCount];
/* 123 */     System.arraycopy(newSegments, 0, actualSegments, 0, actualSegments.length);
/* 124 */     return actualSegments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDevice() {
/* 134 */     return this.device;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getSegments() {
/* 143 */     return (String[])this.segments.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasTrailingSlash() {
/* 152 */     return ((this.flags & 0x4) != 0);
/*     */   }
/*     */   
/*     */   private void initialize(String original) {
/* 156 */     original = (original.indexOf('\\') == -1) ? original : original.replace('\\', '/');
/* 157 */     if (WINDOWS) {
/*     */       
/* 159 */       int deviceSeparatorPos = original.indexOf(':');
/* 160 */       if (deviceSeparatorPos >= 0) {
/*     */ 
/*     */         
/* 163 */         int start = (original.charAt(0) == '/') ? 1 : 0;
/* 164 */         this.device = original.substring(start, deviceSeparatorPos + 1);
/* 165 */         original = original.substring(deviceSeparatorPos + 1, original.length());
/* 166 */       } else if (original.startsWith("//")) {
/*     */         
/* 168 */         int uncPrefixEnd = original.indexOf('/', 2);
/* 169 */         if (uncPrefixEnd >= 0)
/* 170 */           uncPrefixEnd = original.indexOf('/', uncPrefixEnd + 1); 
/* 171 */         if (uncPrefixEnd >= 0) {
/* 172 */           this.device = original.substring(0, uncPrefixEnd);
/* 173 */           original = original.substring(uncPrefixEnd, original.length());
/*     */         } else {
/*     */           
/* 176 */           throw new IllegalArgumentException("Not a valid UNC: " + original);
/*     */         } 
/*     */       } 
/*     */     } 
/* 180 */     if (original.charAt(0) == '/')
/* 181 */       this.flags = (byte)(this.flags | 0x1); 
/* 182 */     if (original.charAt(original.length() - 1) == '/')
/* 183 */       this.flags = (byte)(this.flags | 0x4); 
/* 184 */     this.segments = computeSegments(original);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAbsolute() {
/* 193 */     return ((this.flags & 0x1) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String makeRelative(FilePath base) {
/* 207 */     if (base.device != null && !base.device.equalsIgnoreCase(this.device))
/* 208 */       return base.toString(); 
/* 209 */     int baseCount = this.segments.length;
/* 210 */     int count = matchingFirstSegments(base);
/* 211 */     if (baseCount == count && count == base.segments.length)
/* 212 */       return base.hasTrailingSlash() ? "./" : "."; 
/* 213 */     StringBuilder relative = new StringBuilder();
/* 214 */     for (int j = 0; j < baseCount - count; j++)
/* 215 */       relative.append("../"); 
/* 216 */     for (int i = 0; i < base.segments.length - count; i++) {
/* 217 */       relative.append(base.segments[count + i]);
/* 218 */       relative.append('/');
/*     */     } 
/* 220 */     if (!base.hasTrailingSlash())
/* 221 */       relative.deleteCharAt(relative.length() - 1); 
/* 222 */     return relative.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int matchingFirstSegments(FilePath anotherPath) {
/* 230 */     int anotherPathLen = anotherPath.segments.length;
/* 231 */     int max = Math.min(this.segments.length, anotherPathLen);
/* 232 */     int count = 0;
/* 233 */     for (int i = 0; i < max; i++) {
/* 234 */       if (!this.segments[i].equals(anotherPath.segments[i]))
/* 235 */         return count; 
/* 236 */       count++;
/*     */     } 
/* 238 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 248 */     StringBuilder result = new StringBuilder();
/* 249 */     if (this.device != null)
/* 250 */       result.append(this.device); 
/* 251 */     if (isAbsolute())
/* 252 */       result.append('/');  byte b; int i; String[] arrayOfString;
/* 253 */     for (i = (arrayOfString = this.segments).length, b = 0; b < i; ) { String segment = arrayOfString[b];
/* 254 */       result.append(segment);
/* 255 */       result.append('/'); b++; }
/*     */     
/* 257 */     if (this.segments.length > 0 && !hasTrailingSlash())
/* 258 */       result.deleteCharAt(result.length() - 1); 
/* 259 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\framewor\\util\FilePath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */