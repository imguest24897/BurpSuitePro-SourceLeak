/*    */ package org.eclipse.osgi.container;
/*    */ 
/*    */ import org.osgi.framework.wiring.BundleCapability;
/*    */ import org.osgi.framework.wiring.BundleRequirement;
/*    */ import org.osgi.framework.wiring.BundleRevision;
/*    */ import org.osgi.framework.wiring.BundleWire;
/*    */ import org.osgi.framework.wiring.BundleWiring;
/*    */ import org.osgi.resource.Capability;
/*    */ import org.osgi.resource.Requirement;
/*    */ import org.osgi.resource.Resource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ModuleWire
/*    */   implements BundleWire
/*    */ {
/*    */   private final ModuleCapability capability;
/*    */   private final ModuleRevision hostingProvider;
/*    */   private final ModuleRequirement requirement;
/*    */   private final ModuleRevision hostingRequirer;
/*    */   private volatile boolean isValid = true;
/*    */   
/*    */   ModuleWire(ModuleCapability capability, ModuleRevision hostingProvider, ModuleRequirement requirement, ModuleRevision hostingRequirer) {
/* 33 */     this.capability = capability;
/* 34 */     this.hostingProvider = hostingProvider;
/* 35 */     this.requirement = requirement;
/* 36 */     this.hostingRequirer = hostingRequirer;
/*    */   }
/*    */ 
/*    */   
/*    */   public ModuleCapability getCapability() {
/* 41 */     return this.capability;
/*    */   }
/*    */ 
/*    */   
/*    */   public ModuleRequirement getRequirement() {
/* 46 */     return this.requirement;
/*    */   }
/*    */ 
/*    */   
/*    */   public ModuleWiring getProviderWiring() {
/* 51 */     if (!this.isValid) {
/* 52 */       return null;
/*    */     }
/* 54 */     return this.hostingProvider.getWiring();
/*    */   }
/*    */ 
/*    */   
/*    */   public ModuleWiring getRequirerWiring() {
/* 59 */     if (!this.isValid) {
/* 60 */       return null;
/*    */     }
/* 62 */     return this.hostingRequirer.getWiring();
/*    */   }
/*    */ 
/*    */   
/*    */   public ModuleRevision getProvider() {
/* 67 */     return this.hostingProvider;
/*    */   }
/*    */ 
/*    */   
/*    */   public ModuleRevision getRequirer() {
/* 72 */     return this.hostingRequirer;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 77 */     return getRequirement() + " -> " + getCapability();
/*    */   }
/*    */   
/*    */   void invalidate() {
/* 81 */     this.isValid = false;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\ModuleWire.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */