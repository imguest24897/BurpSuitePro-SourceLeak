package org.eclipse.osgi.service.resolver;

import java.util.Map;

public interface ExportPackageDescription extends BaseDescription {
  boolean isRoot();
  
  Map<String, Object> getAttributes();
  
  Map<String, Object> getDirectives();
  
  Object getDirective(String paramString);
  
  BundleDescription getExporter();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\ExportPackageDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */