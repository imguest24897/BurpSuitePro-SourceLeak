/*     */ package org.eclipse.osgi.internal.url;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.ContentHandler;
/*     */ import java.net.ContentHandlerFactory;
/*     */ import java.net.URLConnection;
/*     */ import java.util.Arrays;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentHandlerFactoryImpl
/*     */   extends MultiplexingFactory
/*     */   implements ContentHandlerFactory
/*     */ {
/*     */   private ServiceTracker<ContentHandler, ContentHandler> contentHandlerTracker;
/*     */   private static final String contentHandlerClazz = "java.net.ContentHandler";
/*     */   private static final String CONTENT_HANDLER_PKGS = "java.content.handler.pkgs";
/*     */   private static final String DEFAULT_VM_CONTENT_HANDLERS = "sun.net.www.content|sun.awt.www.content";
/*  48 */   private static final List<Class<?>> ignoredClasses = Arrays.asList(new Class[] { MultiplexingContentHandler.class, ContentHandlerFactoryImpl.class, URLConnection.class });
/*     */   
/*     */   private Map<String, ContentHandlerProxy> proxies;
/*     */   private ContentHandlerFactory parentFactory;
/*     */   
/*     */   public ContentHandlerFactoryImpl(BundleContext context, EquinoxContainer container) {
/*  54 */     super(context, container);
/*     */     
/*  56 */     this.proxies = new Hashtable<>(5);
/*     */ 
/*     */     
/*  59 */     this.contentHandlerTracker = new ServiceTracker(context, "java.net.ContentHandler", null);
/*  60 */     this.contentHandlerTracker.open();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentHandler createContentHandler(String contentType) {
/*  71 */     String builtInHandlers = URLStreamHandlerFactoryImpl.secureAction.getProperty("java.content.handler.pkgs");
/*  72 */     builtInHandlers = (builtInHandlers == null) ? "sun.net.www.content|sun.awt.www.content" : ("sun.net.www.content|sun.awt.www.content|" + builtInHandlers);
/*  73 */     Class<?> clazz = null;
/*  74 */     if (builtInHandlers != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  79 */       String convertedContentType = contentType.replace('.', '_');
/*  80 */       convertedContentType = convertedContentType.replace('/', '.');
/*  81 */       convertedContentType = convertedContentType.replace('-', '_');
/*  82 */       StringTokenizer tok = new StringTokenizer(builtInHandlers, "|");
/*  83 */       while (tok.hasMoreElements()) {
/*  84 */         StringBuilder name = new StringBuilder();
/*  85 */         name.append(tok.nextToken());
/*  86 */         name.append(".");
/*  87 */         name.append(convertedContentType);
/*     */         try {
/*  89 */           clazz = URLStreamHandlerFactoryImpl.secureAction.loadSystemClass(name.toString());
/*  90 */           if (clazz != null) {
/*  91 */             return null;
/*     */           }
/*  93 */         } catch (ClassNotFoundException classNotFoundException) {}
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  99 */     if (isMultiplexing()) {
/* 100 */       return new MultiplexingContentHandler(contentType, this);
/*     */     }
/* 102 */     return createInternalContentHandler(contentType);
/*     */   }
/*     */ 
/*     */   
/*     */   public ContentHandler createInternalContentHandler(String contentType) {
/* 107 */     ContentHandlerProxy proxy = this.proxies.get(contentType);
/* 108 */     if (proxy != null) {
/* 109 */       return proxy;
/*     */     }
/* 111 */     ServiceReference[] serviceReferences = this.contentHandlerTracker.getServiceReferences();
/* 112 */     if (serviceReferences != null) {
/* 113 */       byte b; int i; ServiceReference[] arrayOfServiceReference; for (i = (arrayOfServiceReference = serviceReferences).length, b = 0; b < i; ) { ServiceReference<ContentHandler> serviceReference = arrayOfServiceReference[b];
/* 114 */         Object prop = serviceReference.getProperty("url.content.mimetype");
/* 115 */         if (prop instanceof String)
/* 116 */           prop = new String[] { (String)prop }; 
/* 117 */         if (!(prop instanceof String[])) {
/* 118 */           String message = NLS.bind(Msg.URL_HANDLER_INCORRECT_TYPE, new Object[] { "url.content.mimetype", "java.net.ContentHandler", serviceReference.getBundle() });
/* 119 */           this.container.getLogServices().log("org.eclipse.osgi", 2, message, null);
/*     */         } else {
/*     */           
/* 122 */           String[] contentHandler = (String[])prop; byte b1; int j; String[] arrayOfString1;
/* 123 */           for (j = (arrayOfString1 = contentHandler).length, b1 = 0; b1 < j; ) { String typename = arrayOfString1[b1];
/* 124 */             if (typename.equals(contentType)) {
/* 125 */               proxy = new ContentHandlerProxy(contentType, serviceReference, this.context);
/* 126 */               this.proxies.put(contentType, proxy);
/* 127 */               return proxy;
/*     */             }  b1++; }
/*     */         
/*     */         }  b++; }
/*     */     
/*     */     } 
/* 133 */     if (this.parentFactory != null) {
/* 134 */       ContentHandler parentHandler = this.parentFactory.createContentHandler(contentType);
/* 135 */       if (parentHandler != null) {
/* 136 */         return parentHandler;
/*     */       }
/*     */     } 
/*     */     
/* 140 */     proxy = new ContentHandlerProxy(contentType, null, this.context);
/* 141 */     this.proxies.put(contentType, proxy);
/* 142 */     return proxy;
/*     */   }
/*     */   
/*     */   public synchronized ContentHandler findAuthorizedContentHandler(String contentType) {
/* 146 */     Object factory = findAuthorizedFactory(ignoredClasses);
/* 147 */     if (factory == null) {
/* 148 */       return null;
/*     */     }
/* 150 */     if (factory == this) {
/* 151 */       return createInternalContentHandler(contentType);
/*     */     }
/*     */     try {
/* 154 */       Method createInternalContentHandlerMethod = factory.getClass().getMethod("createInternalContentHandler", new Class[] { String.class });
/* 155 */       return (ContentHandler)createInternalContentHandlerMethod.invoke(factory, new Object[] { contentType });
/* 156 */     } catch (Exception e) {
/* 157 */       this.container.getLogServices().log(ContentHandlerFactoryImpl.class.getName(), 4, "findAuthorizedContentHandler-loop", e);
/* 158 */       throw new RuntimeException(e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getParentFactory() {
/* 164 */     return this.parentFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setParentFactory(Object parentFactory) {
/* 169 */     if (this.parentFactory == null)
/* 170 */       this.parentFactory = (ContentHandlerFactory)parentFactory; 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\interna\\url\ContentHandlerFactoryImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */