/*     */ package org.eclipse.osgi.util;
/*     */ 
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextProcessor
/*     */ {
/*     */   private static final String DOT = ".";
/*     */   private static final String COLON = ":";
/*     */   private static final String FILE_SEP_FSLASH = "/";
/*     */   private static final String FILE_SEP_BSLASH = "\\";
/*     */   private static final String delimiterString = ".:/\\";
/*     */   private static final char LRM = '‎';
/*     */   private static final char LRE = '‪';
/*     */   private static final char PDF = '‬';
/*     */   private static boolean IS_PROCESSING_NEEDED = false;
/*     */   private static final int INDEX_NOT_SET = 999999999;
/*     */   
/*     */   static {
/*  78 */     Locale locale = Locale.getDefault();
/*  79 */     String lang = locale.getLanguage();
/*     */     
/*  81 */     if ("iw".equals(lang) || "he".equals(lang) || "ar".equals(lang) || "fa".equals(lang) || "ur".equals(lang)) {
/*  82 */       String osName = System.getProperty("os.name").toLowerCase();
/*  83 */       if (osName.startsWith("windows") || osName.startsWith("linux") || osName.startsWith("mac") || osName.startsWith("freebsd")) {
/*  84 */         IS_PROCESSING_NEEDED = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String process(String text) {
/* 102 */     if (!IS_PROCESSING_NEEDED || text == null || text.length() <= 1)
/* 103 */       return text; 
/* 104 */     return process(text, getDefaultDelimiters());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String process(String str, String delimiter) {
/* 157 */     if (!IS_PROCESSING_NEEDED || str == null || str.length() <= 1) {
/* 158 */       return str;
/*     */     }
/*     */     
/* 161 */     if (str.charAt(0) == '‪' && str.charAt(str.length() - 1) == '‬') {
/* 162 */       return str;
/*     */     }
/*     */ 
/*     */     
/* 166 */     boolean isStringBidi = false;
/*     */     
/* 168 */     boolean isLastRTL = false;
/*     */     
/* 170 */     int delimIndex = 999999999;
/*     */     
/* 172 */     delimiter = (delimiter == null) ? getDefaultDelimiters() : delimiter;
/*     */     
/* 174 */     StringBuilder target = new StringBuilder();
/* 175 */     target.append('‪');
/*     */ 
/*     */     
/* 178 */     for (int i = 0, n = str.length(); i < n; i++) {
/* 179 */       char ch = str.charAt(i);
/* 180 */       if (delimiter.indexOf(ch) != -1) {
/*     */         
/* 182 */         if (isLastRTL) {
/* 183 */           delimIndex = target.length();
/*     */         }
/* 185 */       } else if (Character.isDigit(ch)) {
/* 186 */         if (delimIndex != 999999999) {
/*     */ 
/*     */           
/* 189 */           target.insert(delimIndex, '‎');
/* 190 */           delimIndex = 999999999;
/* 191 */           isLastRTL = false;
/*     */         } 
/* 193 */       } else if (Character.isLetter(ch)) {
/* 194 */         if (isRTL(ch)) {
/* 195 */           isStringBidi = true;
/* 196 */           if (delimIndex != 999999999) {
/*     */ 
/*     */             
/* 199 */             target.insert(delimIndex, '‎');
/* 200 */             delimIndex = 999999999;
/*     */           } 
/* 202 */           isLastRTL = true;
/*     */         } else {
/*     */           
/* 205 */           delimIndex = 999999999;
/* 206 */           isLastRTL = false;
/*     */         } 
/*     */       } 
/* 209 */       target.append(ch);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 220 */     if (isStringBidi || !Character.isLetter(str.charAt(0)) || isNeutral(str.charAt(str.length() - 1))) {
/* 221 */       target.append('‬');
/* 222 */       return target.toString();
/*     */     } 
/*     */     
/* 225 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String deprocess(String str) {
/* 240 */     if (!IS_PROCESSING_NEEDED || str == null || str.length() <= 1) {
/* 241 */       return str;
/*     */     }
/* 243 */     StringBuilder buf = new StringBuilder();
/* 244 */     for (int i = 0; i < str.length(); i++) {
/* 245 */       char c = str.charAt(i);
/* 246 */       switch (c) {
/*     */         case '‪':
/*     */         case '‬':
/*     */         case '‎':
/*     */           break;
/*     */ 
/*     */         
/*     */         default:
/* 254 */           buf.append(c);
/*     */           break;
/*     */       } 
/*     */     } 
/* 258 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getDefaultDelimiters() {
/* 268 */     return ".:/\\";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isRTL(char c) {
/* 285 */     return !((c < 'א' || c > 'ޱ') && (c < 'יִ' || c > 'ﻼ'));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isNeutral(char c) {
/* 292 */     return !(Character.isDigit(c) || Character.isLetter(c));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osg\\util\TextProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */