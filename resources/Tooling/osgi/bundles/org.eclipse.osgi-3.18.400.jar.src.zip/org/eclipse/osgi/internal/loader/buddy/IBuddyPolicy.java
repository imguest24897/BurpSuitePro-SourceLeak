package org.eclipse.osgi.internal.loader.buddy;

import java.net.URL;
import java.util.Enumeration;
import java.util.Set;

public interface IBuddyPolicy {
  Class<?> loadClass(String paramString);
  
  URL loadResource(String paramString);
  
  Enumeration<URL> loadResources(String paramString);
  
  default void addListResources(Set<String> results, String path, String filePattern, int options) {}
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\loader\buddy\IBuddyPolicy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */