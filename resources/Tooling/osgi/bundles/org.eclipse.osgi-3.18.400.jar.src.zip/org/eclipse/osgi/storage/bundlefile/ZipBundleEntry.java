/*     */ package org.eclipse.osgi.storage.bundlefile;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.zip.ZipEntry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZipBundleEntry
/*     */   extends BundleEntry
/*     */ {
/*     */   protected final ZipEntry zipEntry;
/*     */   protected final ZipBundleFile bundleFile;
/*     */   
/*     */   ZipBundleEntry(ZipEntry zipEntry, ZipBundleFile bundleFile) {
/*  45 */     this.zipEntry = zipEntry;
/*  46 */     this.bundleFile = bundleFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/*  57 */     return this.bundleFile.getInputStream(this.zipEntry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getSize() {
/*  67 */     return this.zipEntry.getSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  77 */     return this.zipEntry.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTime() {
/*  89 */     return this.zipEntry.getTime();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getLocalURL() {
/*     */     try {
/*  96 */       return new URL("jar:" + this.bundleFile.basefile.toURL() + "!/" + this.zipEntry.getName());
/*  97 */     } catch (MalformedURLException malformedURLException) {
/*     */       
/*  99 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getFileURL() {
/*     */     try {
/* 107 */       File file = this.bundleFile.getFile(this.zipEntry.getName(), false);
/* 108 */       if (file != null)
/* 109 */         return file.toURL(); 
/* 110 */     } catch (MalformedURLException malformedURLException) {}
/*     */ 
/*     */     
/* 113 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\bundlefile\ZipBundleEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */