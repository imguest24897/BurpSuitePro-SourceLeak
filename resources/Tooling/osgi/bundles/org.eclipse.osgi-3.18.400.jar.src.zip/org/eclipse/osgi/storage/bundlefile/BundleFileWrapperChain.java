/*    */ package org.eclipse.osgi.storage.bundlefile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BundleFileWrapperChain
/*    */   extends BundleFileWrapper
/*    */ {
/*    */   private final BundleFile wrapped;
/*    */   private final BundleFileWrapperChain next;
/*    */   
/*    */   public BundleFileWrapperChain(BundleFile wrapped, BundleFileWrapperChain next) {
/* 28 */     super(wrapped);
/* 29 */     this.wrapped = wrapped;
/* 30 */     this.next = next;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 35 */     return this.wrapped.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BundleFile getWrapped() {
/* 43 */     return this.wrapped;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BundleFileWrapperChain getNext() {
/* 52 */     return this.next;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> T getWrappedType(Class<T> type) {
/* 64 */     BundleFileWrapperChain current = this;
/*    */     while (true) {
/* 66 */       if (type.isInstance(current.getWrapped())) {
/* 67 */         return (T)current.getWrapped();
/*    */       }
/* 69 */       current = current.getNext();
/* 70 */       if (current == null)
/* 71 */         return null; 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\bundlefile\BundleFileWrapperChain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */