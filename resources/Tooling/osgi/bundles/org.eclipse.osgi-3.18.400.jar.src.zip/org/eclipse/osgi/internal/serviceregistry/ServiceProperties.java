/*     */ package org.eclipse.osgi.internal.serviceregistry;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.osgi.framework.util.CaseInsensitiveDictionaryMap;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ServiceProperties
/*     */   extends CaseInsensitiveDictionaryMap<String, Object>
/*     */ {
/*     */   ServiceProperties(Dictionary<String, ?> props) {
/*  38 */     this(props, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ServiceProperties(Dictionary<String, ?> props, int extra) {
/*  50 */     super(initialCapacity((props == null) ? extra : (props.size() + extra)));
/*  51 */     if (props == null) {
/*     */       return;
/*     */     }
/*  54 */     synchronized (props) {
/*  55 */       Enumeration<?> keysEnum = props.keys();
/*  56 */       while (keysEnum.hasMoreElements()) {
/*  57 */         Object key = keysEnum.nextElement();
/*  58 */         if (key instanceof String) {
/*  59 */           String header = (String)key;
/*  60 */           Object value = cloneValue(props.get(header));
/*  61 */           if (value != null && put(header, value) != null) {
/*  62 */             throw new IllegalArgumentException(NLS.bind(Msg.HEADER_DUPLICATE_KEY_EXCEPTION, key));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ServiceProperties(Map<String, ?> props) {
/*  77 */     super(initialCapacity((props == null) ? 0 : props.size()));
/*  78 */     if (props == null) {
/*     */       return;
/*     */     }
/*  81 */     synchronized (props) {
/*  82 */       for (Map.Entry<?, ?> e : props.entrySet()) {
/*  83 */         Object key = e.getKey();
/*  84 */         if (key instanceof String) {
/*  85 */           String header = (String)key;
/*  86 */           Object value = cloneValue(props.get(header));
/*  87 */           if (value != null && put(header, value) != null) {
/*  88 */             throw new IllegalArgumentException(NLS.bind(Msg.HEADER_DUPLICATE_KEY_EXCEPTION, key));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object cloneValue(Object value) {
/* 106 */     if (value == null)
/* 107 */       return null; 
/* 108 */     if (value instanceof String)
/* 109 */       return value; 
/* 110 */     if (value instanceof Number)
/* 111 */       return value; 
/* 112 */     if (value instanceof Character)
/* 113 */       return value; 
/* 114 */     if (value instanceof Boolean) {
/* 115 */       return value;
/*     */     }
/* 117 */     Class<?> clazz = value.getClass();
/* 118 */     if (clazz.isArray()) {
/*     */       
/* 120 */       Class<?> type = clazz.getComponentType();
/* 121 */       int len = Array.getLength(value);
/* 122 */       Object clonedArray = Array.newInstance(type, len);
/* 123 */       System.arraycopy(value, 0, clonedArray, 0, len);
/* 124 */       return clonedArray;
/*     */     } 
/*     */     
/* 127 */     if (value instanceof Cloneable) {
/*     */       
/*     */       try {
/* 130 */         return clazz.getMethod("clone", null).invoke(value, null);
/* 131 */       } catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */     
/* 135 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 140 */     Set<String> keys = keySet();
/*     */     
/* 142 */     StringBuilder sb = new StringBuilder(20 * keys.size());
/*     */     
/* 144 */     sb.append('{');
/*     */     
/* 146 */     int n = 0;
/* 147 */     for (String key : keys) {
/* 148 */       if (!key.equals("objectClass")) {
/* 149 */         if (n > 0) {
/* 150 */           sb.append(", ");
/*     */         }
/* 152 */         sb.append(key);
/* 153 */         sb.append('=');
/* 154 */         Object value = get(key);
/* 155 */         if (value.getClass().isArray()) {
/* 156 */           sb.append('[');
/* 157 */           int length = Array.getLength(value);
/* 158 */           for (int j = 0; j < length; j++) {
/* 159 */             if (j > 0)
/* 160 */               sb.append(','); 
/* 161 */             sb.append(Array.get(value, j));
/*     */           } 
/* 163 */           sb.append(']');
/*     */         } else {
/* 165 */           sb.append(value);
/*     */         } 
/* 167 */         n++;
/*     */       } 
/*     */     } 
/*     */     
/* 171 */     sb.append('}');
/*     */     
/* 173 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\serviceregistry\ServiceProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */