/*     */ package org.eclipse.osgi.internal.log;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import org.eclipse.equinox.log.ExtendedLogEntry;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.service.log.LogEntry;
/*     */ import org.osgi.service.log.LogLevel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtendedLogEntryImpl
/*     */   implements ExtendedLogEntry, LogEntry
/*     */ {
/*  23 */   private static long nextSequenceNumber = 1L;
/*  24 */   private static long nextThreadId = 1L;
/*  25 */   private static final Map<Thread, Long> threadIds = createThreadIdMap();
/*     */   
/*     */   private final String loggerName;
/*     */   private final Bundle bundle;
/*     */   private final int level;
/*     */   private final LogLevel logLevelEnum;
/*     */   private final String message;
/*     */   private final ServiceReference<?> ref;
/*     */   private final Throwable throwable;
/*     */   private final Object contextObject;
/*     */   private final long time;
/*     */   private final long threadId;
/*     */   private final String threadName;
/*     */   private final long sequenceNumber;
/*     */   private final StackTraceElement stackTraceElement;
/*     */   
/*     */   private static Map<Thread, Long> createThreadIdMap() {
/*     */     try {
/*  43 */       Thread.class.getMethod("getId", null);
/*  44 */     } catch (NoSuchMethodException noSuchMethodException) {
/*  45 */       return new WeakHashMap<>();
/*     */     } 
/*  47 */     return null;
/*     */   }
/*     */   
/*     */   private static long getId(Thread thread) {
/*  51 */     if (threadIds == null) {
/*  52 */       return thread.getId();
/*     */     }
/*  54 */     Long threadId = threadIds.get(thread);
/*  55 */     if (threadId == null) {
/*  56 */       threadId = Long.valueOf(nextThreadId++);
/*  57 */       threadIds.put(thread, threadId);
/*     */     } 
/*  59 */     return threadId.longValue();
/*     */   }
/*     */   
/*     */   public ExtendedLogEntryImpl(Bundle bundle, String loggerName, StackTraceElement stackTraceElement, Object contextObject, LogLevel logLevelEnum, int level, String message, ServiceReference<?> ref, Throwable throwable) {
/*  63 */     this.time = System.currentTimeMillis();
/*  64 */     this.loggerName = loggerName;
/*  65 */     this.bundle = bundle;
/*  66 */     this.level = level;
/*  67 */     this.logLevelEnum = logLevelEnum;
/*  68 */     this.message = message;
/*  69 */     this.throwable = throwable;
/*  70 */     this.ref = ref;
/*  71 */     this.contextObject = contextObject;
/*     */     
/*  73 */     Thread currentThread = Thread.currentThread();
/*  74 */     this.threadName = currentThread.getName();
/*     */     
/*  76 */     synchronized (ExtendedLogEntryImpl.class) {
/*  77 */       this.threadId = getId(currentThread);
/*  78 */       this.sequenceNumber = nextSequenceNumber++;
/*     */     } 
/*     */     
/*  81 */     this.stackTraceElement = stackTraceElement;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLoggerName() {
/*  86 */     return this.loggerName;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getSequenceNumber() {
/*  91 */     return this.sequenceNumber;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getThreadId() {
/*  96 */     return this.threadId;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getThreadName() {
/* 101 */     return this.threadName;
/*     */   }
/*     */ 
/*     */   
/*     */   public Bundle getBundle() {
/* 106 */     return this.bundle;
/*     */   }
/*     */ 
/*     */   
/*     */   public Throwable getException() {
/* 111 */     return this.throwable;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLevel() {
/* 117 */     return this.level;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 122 */     return this.message;
/*     */   }
/*     */ 
/*     */   
/*     */   public ServiceReference<?> getServiceReference() {
/* 127 */     return this.ref;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTime() {
/* 132 */     return this.time;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getContext() {
/* 137 */     return this.contextObject;
/*     */   }
/*     */ 
/*     */   
/*     */   public LogLevel getLogLevel() {
/* 142 */     return this.logLevelEnum;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getSequence() {
/* 147 */     return getSequenceNumber();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getThreadInfo() {
/* 152 */     return getThreadName();
/*     */   }
/*     */ 
/*     */   
/*     */   public StackTraceElement getLocation() {
/* 157 */     return this.stackTraceElement;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\log\ExtendedLogEntryImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */