package org.eclipse.osgi.service.resolver;

import org.osgi.framework.Filter;

public interface NativeCodeDescription extends BaseDescription, Comparable<NativeCodeDescription> {
  String[] getNativePaths();
  
  String[] getProcessors();
  
  String[] getOSNames();
  
  VersionRange[] getOSVersions();
  
  String[] getLanguages();
  
  Filter getFilter();
  
  int compareTo(NativeCodeDescription paramNativeCodeDescription);
  
  boolean hasInvalidNativePaths();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\NativeCodeDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */