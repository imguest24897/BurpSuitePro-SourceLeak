/*     */ package org.eclipse.osgi.internal.url;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Proxy;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLStreamHandler;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.service.url.URLStreamHandlerService;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ import org.osgi.util.tracker.ServiceTrackerCustomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class URLStreamHandlerProxy
/*     */   extends URLStreamHandler
/*     */   implements ServiceTrackerCustomizer<URLStreamHandlerService, ServiceReference<URLStreamHandlerService>>
/*     */ {
/*     */   protected URLStreamHandlerService realHandlerService;
/*     */   protected URLStreamHandlerSetter urlSetter;
/*     */   protected ServiceTracker<URLStreamHandlerService, ServiceReference<URLStreamHandlerService>> urlStreamHandlerServiceTracker;
/*     */   protected BundleContext context;
/*     */   protected ServiceReference<URLStreamHandlerService> urlStreamServiceReference;
/*     */   protected String protocol;
/*  50 */   protected int ranking = Integer.MIN_VALUE;
/*     */   
/*     */   public URLStreamHandlerProxy(String protocol, ServiceReference<URLStreamHandlerService> reference, BundleContext context) {
/*  53 */     this.context = context;
/*  54 */     this.protocol = protocol;
/*     */     
/*  56 */     this.urlSetter = new URLStreamHandlerSetter(this);
/*     */ 
/*     */     
/*  59 */     setNewHandler(reference, getRank(reference));
/*     */     
/*  61 */     this.urlStreamHandlerServiceTracker = new ServiceTracker(context, "org.osgi.service.url.URLStreamHandlerService", this);
/*  62 */     URLStreamHandlerFactoryImpl.secureAction.open(this.urlStreamHandlerServiceTracker);
/*     */   }
/*     */   
/*     */   private void setNewHandler(ServiceReference<URLStreamHandlerService> reference, int rank) {
/*  66 */     if (this.urlStreamServiceReference != null) {
/*  67 */       this.context.ungetService(this.urlStreamServiceReference);
/*     */     }
/*  69 */     this.urlStreamServiceReference = reference;
/*  70 */     this.ranking = rank;
/*     */     
/*  72 */     if (reference == null) {
/*  73 */       this.realHandlerService = new NullURLStreamHandlerService();
/*     */     } else {
/*  75 */       this.realHandlerService = (URLStreamHandlerService)URLStreamHandlerFactoryImpl.secureAction.getService(reference, this.context);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean equals(URL url1, URL url2) {
/*  83 */     return this.realHandlerService.equals(url1, url2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getDefaultPort() {
/*  91 */     return this.realHandlerService.getDefaultPort();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InetAddress getHostAddress(URL url) {
/*  99 */     return this.realHandlerService.getHostAddress(url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int hashCode(URL url) {
/* 107 */     return this.realHandlerService.hashCode(url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hostsEqual(URL url1, URL url2) {
/* 115 */     return this.realHandlerService.hostsEqual(url1, url2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected URLConnection openConnection(URL url) throws IOException {
/* 123 */     return this.realHandlerService.openConnection(url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseURL(URL url, String str, int start, int end) {
/* 131 */     this.realHandlerService.parseURL(this.urlSetter, url, str, start, end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean sameFile(URL url1, URL url2) {
/* 139 */     return this.realHandlerService.sameFile(url1, url2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String toExternalForm(URL url) {
/* 147 */     return this.realHandlerService.toExternalForm(url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setURL(URL u, String protocol, String host, int port, String authority, String userInfo, String file, String query, String ref) {
/* 155 */     super.setURL(u, protocol, host, port, authority, userInfo, file, query, ref);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setURL(URL url, String protocol, String host, int port, String file, String ref) {
/* 164 */     super.setURL(url, protocol, host, port, null, null, file, null, ref);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceReference<URLStreamHandlerService> addingService(ServiceReference<URLStreamHandlerService> reference) {
/* 173 */     Object prop = reference.getProperty("url.handler.protocol");
/* 174 */     if (prop instanceof String) {
/* 175 */       prop = new String[] { (String)prop };
/*     */     }
/* 177 */     if (!(prop instanceof String[])) {
/* 178 */       return null;
/*     */     }
/* 180 */     String[] protocols = (String[])prop; byte b; int i; String[] arrayOfString1;
/* 181 */     for (i = (arrayOfString1 = protocols).length, b = 0; b < i; ) { String candidateProtocol = arrayOfString1[b];
/* 182 */       if (candidateProtocol.equals(this.protocol)) {
/*     */         
/* 184 */         int newServiceRanking = getRank(reference);
/* 185 */         if (newServiceRanking > this.ranking || this.urlStreamServiceReference == null)
/* 186 */           setNewHandler(reference, newServiceRanking); 
/* 187 */         return reference;
/*     */       } 
/*     */       
/*     */       b++; }
/*     */     
/* 192 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifiedService(ServiceReference<URLStreamHandlerService> reference, ServiceReference<URLStreamHandlerService> service) {
/* 201 */     int newRank = getRank(reference);
/* 202 */     if (reference == this.urlStreamServiceReference) {
/* 203 */       if (newRank < this.ranking) {
/*     */ 
/*     */ 
/*     */         
/* 207 */         ServiceReference<URLStreamHandlerService> newReference = this.urlStreamHandlerServiceTracker.getServiceReference();
/* 208 */         if (newReference != this.urlStreamServiceReference && newReference != null) {
/* 209 */           setNewHandler(newReference, ((Integer)newReference.getProperty("service.ranking")).intValue());
/*     */         }
/*     */       } 
/* 212 */     } else if (newRank > this.ranking) {
/*     */ 
/*     */       
/* 215 */       setNewHandler(reference, newRank);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removedService(ServiceReference<URLStreamHandlerService> reference, ServiceReference<URLStreamHandlerService> service) {
/* 225 */     if (reference != this.urlStreamServiceReference) {
/*     */       return;
/*     */     }
/*     */     
/* 229 */     ServiceReference<URLStreamHandlerService> newReference = this.urlStreamHandlerServiceTracker.getServiceReference();
/*     */     
/* 231 */     setNewHandler(newReference, getRank(newReference));
/*     */   }
/*     */   
/*     */   private int getRank(ServiceReference<?> reference) {
/* 235 */     if (reference == null)
/* 236 */       return Integer.MIN_VALUE; 
/* 237 */     Object property = reference.getProperty("service.ranking");
/* 238 */     return (property instanceof Integer) ? ((Integer)property).intValue() : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected URLConnection openConnection(URL u, Proxy p) throws IOException {
/*     */     try {
/* 244 */       Method openConn = this.realHandlerService.getClass().getMethod("openConnection", new Class[] { URL.class, Proxy.class });
/* 245 */       openConn.setAccessible(true);
/* 246 */       return (URLConnection)openConn.invoke(this.realHandlerService, new Object[] { u, p });
/* 247 */     } catch (InvocationTargetException e) {
/* 248 */       if (e.getTargetException() instanceof IOException)
/* 249 */         throw (IOException)e.getTargetException(); 
/* 250 */       throw (RuntimeException)e.getTargetException();
/* 251 */     } catch (Exception e) {
/*     */       
/* 253 */       throw new UnsupportedOperationException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\interna\\url\URLStreamHandlerProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */