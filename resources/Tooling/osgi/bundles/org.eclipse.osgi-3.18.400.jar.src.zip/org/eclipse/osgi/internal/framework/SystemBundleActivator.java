/*     */ package org.eclipse.osgi.internal.framework;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import org.apache.felix.resolver.Logger;
/*     */ import org.apache.felix.resolver.ResolverImpl;
/*     */ import org.eclipse.osgi.internal.debug.FrameworkDebugOptions;
/*     */ import org.eclipse.osgi.internal.framework.legacy.PackageAdminImpl;
/*     */ import org.eclipse.osgi.internal.framework.legacy.StartLevelImpl;
/*     */ import org.eclipse.osgi.internal.location.BasicLocation;
/*     */ import org.eclipse.osgi.internal.location.EquinoxLocations;
/*     */ import org.eclipse.osgi.internal.permadmin.SecurityAdmin;
/*     */ import org.eclipse.osgi.internal.url.EquinoxFactoryManager;
/*     */ import org.eclipse.osgi.service.debug.DebugOptions;
/*     */ import org.eclipse.osgi.service.debug.DebugOptionsListener;
/*     */ import org.eclipse.osgi.service.environment.EnvironmentInfo;
/*     */ import org.eclipse.osgi.service.localization.BundleLocalization;
/*     */ import org.eclipse.osgi.service.urlconversion.URLConverter;
/*     */ import org.eclipse.osgi.storage.BundleLocalizationImpl;
/*     */ import org.eclipse.osgi.storage.url.BundleURLConverter;
/*     */ import org.osgi.framework.BundleActivator;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.service.condition.Condition;
/*     */ import org.osgi.service.condpermadmin.ConditionalPermissionAdmin;
/*     */ import org.osgi.service.packageadmin.PackageAdmin;
/*     */ import org.osgi.service.permissionadmin.PermissionAdmin;
/*     */ import org.osgi.service.resolver.Resolver;
/*     */ import org.osgi.service.startlevel.StartLevel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SystemBundleActivator
/*     */   implements BundleActivator
/*     */ {
/*     */   private EquinoxFactoryManager urlFactoryManager;
/*  59 */   private List<ServiceRegistration<?>> registrations = new ArrayList<>(10);
/*     */   
/*     */   private SecurityManager setSecurityManagner;
/*     */ 
/*     */   
/*     */   public void start(BundleContext bc) throws Exception {
/*  65 */     this.registrations.clear();
/*  66 */     EquinoxBundle bundle = (EquinoxBundle)bc.getBundle();
/*  67 */     EquinoxContainer equinoxContainer = bundle.getEquinoxContainer();
/*     */     
/*  69 */     equinoxContainer.systemStart(bc);
/*     */     
/*  71 */     EquinoxConfiguration configuration = bundle.getEquinoxContainer().getConfiguration();
/*  72 */     installSecurityManager(configuration);
/*  73 */     equinoxContainer.getLogServices().start(bc);
/*     */     
/*  75 */     this.urlFactoryManager = new EquinoxFactoryManager(equinoxContainer);
/*  76 */     this.urlFactoryManager.installHandlerFactories(bc);
/*     */     
/*  78 */     FrameworkDebugOptions dbgOptions = (FrameworkDebugOptions)configuration.getDebugOptions();
/*  79 */     dbgOptions.start(bc);
/*  80 */     Hashtable<String, Object> props = new Hashtable<>(7);
/*  81 */     props.clear();
/*     */     
/*  83 */     props.put("osgi.condition.id", "true");
/*  84 */     register(bc, Condition.class, Condition.INSTANCE, false, props);
/*     */     
/*  86 */     registerLocations(bc, equinoxContainer.getLocations());
/*  87 */     register(bc, EnvironmentInfo.class, equinoxContainer.getConfiguration(), null);
/*  88 */     PackageAdminImpl packageAdminImpl = new PackageAdminImpl(equinoxContainer, 
/*  89 */         equinoxContainer.getStorage().getModuleContainer().getFrameworkWiring());
/*  90 */     register(bc, PackageAdmin.class, packageAdminImpl, null);
/*  91 */     StartLevelImpl startLevelImpl = new StartLevelImpl(
/*  92 */         equinoxContainer.getStorage().getModuleContainer().getFrameworkStartLevel());
/*  93 */     register(bc, StartLevel.class, startLevelImpl, null);
/*     */     
/*  95 */     SecurityAdmin sa = equinoxContainer.getStorage().getSecurityAdmin();
/*  96 */     register(bc, PermissionAdmin.class, sa, null);
/*  97 */     register(bc, ConditionalPermissionAdmin.class, sa, null);
/*     */ 
/*     */     
/* 100 */     props.clear();
/* 101 */     props.put("service.ranking", Integer.valueOf(-2147483648));
/* 102 */     register(bc, Resolver.class, new ResolverImpl(new Logger(0), null), false, props);
/*     */     
/* 104 */     register(bc, DebugOptions.class, dbgOptions, null);
/*     */     
/* 106 */     ClassLoader tccl = equinoxContainer.getContextFinder();
/* 107 */     if (tccl != null) {
/* 108 */       props.clear();
/* 109 */       props.put("equinox.classloader.type", "contextClassLoader");
/* 110 */       register(bc, ClassLoader.class, tccl, props);
/*     */     } 
/*     */     
/* 113 */     props.clear();
/* 114 */     props.put("protocol", new String[] { "bundleentry", "bundleresource" });
/* 115 */     register(bc, URLConverter.class, new BundleURLConverter(), props);
/*     */     
/* 117 */     register(bc, BundleLocalization.class, new BundleLocalizationImpl(), null);
/*     */     
/* 119 */     boolean setTccl = "true".equals(bundle.getEquinoxContainer().getConfiguration().getConfiguration("eclipse.parsers.setTCCL", "true"));
/*     */     try {
/* 121 */       register(bc, "javax.xml.parsers.SAXParserFactory", new XMLParsingServiceFactory(true, setTccl), false, (Dictionary<String, Object>)null);
/* 122 */       register(bc, "javax.xml.parsers.DocumentBuilderFactory", new XMLParsingServiceFactory(false, setTccl), false, (Dictionary<String, Object>)null);
/* 123 */     } catch (NoClassDefFoundError noClassDefFoundError) {}
/*     */ 
/*     */     
/* 126 */     bundle.getEquinoxContainer().getStorage().getExtensionInstaller().startExtensionActivators(bc);
/*     */ 
/*     */ 
/*     */     
/* 130 */     props.clear();
/* 131 */     props.put("listener.symbolic.name", "org.eclipse.osgi");
/* 132 */     register(bc, DebugOptionsListener.class, bundle.getEquinoxContainer().getConfiguration().getDebug(), props);
/* 133 */     register(bc, DebugOptionsListener.class, bundle.getModule().getContainer(), props);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void installSecurityManager(EquinoxConfiguration configuration) throws BundleException {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ldc_w 'org.osgi.framework.security'
/*     */     //   4: invokevirtual getConfiguration : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   7: astore_2
/*     */     //   8: invokestatic getSecurityManager : ()Ljava/lang/SecurityManager;
/*     */     //   11: ifnull -> 36
/*     */     //   14: ldc_w 'osgi'
/*     */     //   17: aload_2
/*     */     //   18: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   21: ifeq -> 35
/*     */     //   24: new org/osgi/framework/BundleException
/*     */     //   27: dup
/*     */     //   28: ldc_w 'Cannot specify the "org.osgi.framework.security" configuration property when a security manager is already installed.'
/*     */     //   31: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   34: athrow
/*     */     //   35: return
/*     */     //   36: aload_1
/*     */     //   37: ldc_w 'eclipse.security'
/*     */     //   40: aload_1
/*     */     //   41: ldc_w 'java.security.manager'
/*     */     //   44: invokevirtual getProperty : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   47: invokevirtual getConfiguration : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   50: astore_3
/*     */     //   51: aconst_null
/*     */     //   52: astore #4
/*     */     //   54: ldc_w 'osgi'
/*     */     //   57: aload_2
/*     */     //   58: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   61: ifeq -> 76
/*     */     //   64: new org/eclipse/osgi/internal/permadmin/EquinoxSecurityManager
/*     */     //   67: dup
/*     */     //   68: invokespecial <init> : ()V
/*     */     //   71: astore #4
/*     */     //   73: goto -> 241
/*     */     //   76: aload_3
/*     */     //   77: ifnull -> 241
/*     */     //   80: aload_3
/*     */     //   81: dup
/*     */     //   82: astore #5
/*     */     //   84: invokevirtual hashCode : ()I
/*     */     //   87: lookupswitch default -> 196, 0 -> 128, 92906313 -> 142, 271239035 -> 156, 1544803905 -> 170
/*     */     //   128: aload #5
/*     */     //   130: ldc_w ''
/*     */     //   133: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   136: ifne -> 184
/*     */     //   139: goto -> 196
/*     */     //   142: aload #5
/*     */     //   144: ldc_w 'allow'
/*     */     //   147: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   150: ifne -> 241
/*     */     //   153: goto -> 196
/*     */     //   156: aload #5
/*     */     //   158: ldc_w 'disallow'
/*     */     //   161: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   164: ifne -> 241
/*     */     //   167: goto -> 196
/*     */     //   170: aload #5
/*     */     //   172: ldc_w 'default'
/*     */     //   175: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   178: ifne -> 184
/*     */     //   181: goto -> 196
/*     */     //   184: new java/lang/SecurityManager
/*     */     //   187: dup
/*     */     //   188: invokespecial <init> : ()V
/*     */     //   191: astore #4
/*     */     //   193: goto -> 241
/*     */     //   196: aload_3
/*     */     //   197: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   200: astore #6
/*     */     //   202: aload #6
/*     */     //   204: iconst_0
/*     */     //   205: anewarray java/lang/Class
/*     */     //   208: invokevirtual getConstructor : ([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
/*     */     //   211: iconst_0
/*     */     //   212: anewarray java/lang/Object
/*     */     //   215: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   218: checkcast java/lang/SecurityManager
/*     */     //   221: astore #4
/*     */     //   223: goto -> 241
/*     */     //   226: astore #6
/*     */     //   228: new org/osgi/framework/BundleException
/*     */     //   231: dup
/*     */     //   232: ldc_w 'Failed to create security manager'
/*     */     //   235: aload #6
/*     */     //   237: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   240: athrow
/*     */     //   241: aload_1
/*     */     //   242: invokevirtual getDebug : ()Lorg/eclipse/osgi/internal/debug/Debug;
/*     */     //   245: getfield DEBUG_SECURITY : Z
/*     */     //   248: ifeq -> 272
/*     */     //   251: new java/lang/StringBuilder
/*     */     //   254: dup
/*     */     //   255: ldc_w 'Setting SecurityManager to: '
/*     */     //   258: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   261: aload #4
/*     */     //   263: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   266: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   269: invokestatic println : (Ljava/lang/String;)V
/*     */     //   272: aload #4
/*     */     //   274: ifnull -> 300
/*     */     //   277: aload #4
/*     */     //   279: invokestatic setSecurityManager : (Ljava/lang/SecurityManager;)V
/*     */     //   282: goto -> 300
/*     */     //   285: astore #6
/*     */     //   287: new java/lang/UnsupportedOperationException
/*     */     //   290: dup
/*     */     //   291: ldc_w 'Setting the security manager is not allowed. The java.security.manager=allow java property must be set.'
/*     */     //   294: aload #6
/*     */     //   296: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   299: athrow
/*     */     //   300: aload_0
/*     */     //   301: aload #4
/*     */     //   303: putfield setSecurityManagner : Ljava/lang/SecurityManager;
/*     */     //   306: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #137	-> 0
/*     */     //   #139	-> 8
/*     */     //   #140	-> 14
/*     */     //   #141	-> 24
/*     */     //   #145	-> 35
/*     */     //   #148	-> 36
/*     */     //   #149	-> 40
/*     */     //   #148	-> 47
/*     */     //   #151	-> 51
/*     */     //   #152	-> 54
/*     */     //   #153	-> 64
/*     */     //   #154	-> 73
/*     */     //   #155	-> 80
/*     */     //   #163	-> 184
/*     */     //   #164	-> 193
/*     */     //   #168	-> 196
/*     */     //   #169	-> 202
/*     */     //   #170	-> 223
/*     */     //   #171	-> 228
/*     */     //   #177	-> 241
/*     */     //   #178	-> 251
/*     */     //   #180	-> 272
/*     */     //   #181	-> 277
/*     */     //   #183	-> 282
/*     */     //   #184	-> 287
/*     */     //   #185	-> 291
/*     */     //   #186	-> 294
/*     */     //   #184	-> 296
/*     */     //   #188	-> 300
/*     */     //   #189	-> 306
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	307	0	this	Lorg/eclipse/osgi/internal/framework/SystemBundleActivator;
/*     */     //   0	307	1	configuration	Lorg/eclipse/osgi/internal/framework/EquinoxConfiguration;
/*     */     //   8	299	2	frameworkSecurityProp	Ljava/lang/String;
/*     */     //   51	256	3	javaSecurityProp	Ljava/lang/String;
/*     */     //   54	253	4	toInstall	Ljava/lang/SecurityManager;
/*     */     //   202	21	6	clazz	Ljava/lang/Class;
/*     */     //   228	13	6	t	Ljava/lang/Throwable;
/*     */     //   287	13	6	e	Ljava/lang/UnsupportedOperationException;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   202	21	6	clazz	Ljava/lang/Class<*>;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   196	223	226	java/lang/Throwable
/*     */     //   272	282	285	java/lang/UnsupportedOperationException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerLocations(BundleContext bc, EquinoxLocations equinoxLocations) {
/* 192 */     registerLocation(bc, equinoxLocations.getUserLocation(), "osgi.user.area");
/* 193 */     registerLocation(bc, equinoxLocations.getInstanceLocation(), "osgi.instance.area");
/* 194 */     registerLocation(bc, equinoxLocations.getConfigurationLocation(), "osgi.configuration.area");
/* 195 */     registerLocation(bc, equinoxLocations.getInstallLocation(), "osgi.install.area");
/* 196 */     registerLocation(bc, equinoxLocations.getEclipseHomeLocation(), "eclipse.home.location");
/*     */   }
/*     */   
/*     */   private void registerLocation(BundleContext bc, BasicLocation location, String type) {
/* 200 */     if (location != null) {
/* 201 */       location.register(bc);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop(BundleContext bc) throws Exception {
/* 207 */     EquinoxBundle bundle = (EquinoxBundle)bc.getBundle();
/*     */     
/* 209 */     bundle.getEquinoxContainer().getStorage().getExtensionInstaller().stopExtensionActivators(bc);
/*     */     
/* 211 */     FrameworkDebugOptions dbgOptions = (FrameworkDebugOptions)bundle.getEquinoxContainer().getConfiguration().getDebugOptions();
/* 212 */     dbgOptions.stop(bc);
/*     */     
/* 214 */     this.urlFactoryManager.uninstallHandlerFactories();
/*     */ 
/*     */     
/* 217 */     for (ServiceRegistration<?> registration : this.registrations)
/* 218 */       registration.unregister(); 
/* 219 */     this.registrations.clear();
/* 220 */     bundle.getEquinoxContainer().getLogServices().stop(bc);
/* 221 */     unintallSecurityManager();
/* 222 */     bundle.getEquinoxContainer().systemStop(bc);
/*     */   }
/*     */   
/*     */   private void unintallSecurityManager() {
/* 226 */     if (this.setSecurityManagner != null && System.getSecurityManager() == this.setSecurityManagner)
/* 227 */       System.setSecurityManager(null); 
/* 228 */     this.setSecurityManagner = null;
/*     */   }
/*     */   
/*     */   private void register(BundleContext context, Class<?> serviceClass, Object service, Dictionary<String, Object> properties) {
/* 232 */     register(context, serviceClass.getName(), service, true, properties);
/*     */   }
/*     */   
/*     */   private void register(BundleContext context, Class<?> serviceClass, Object service, boolean setRanking, Dictionary<String, Object> properties) {
/* 236 */     register(context, serviceClass.getName(), service, setRanking, properties);
/*     */   }
/*     */   
/*     */   private void register(BundleContext context, String serviceClass, Object service, boolean setRanking, Dictionary<String, Object> properties) {
/* 240 */     if (properties == null)
/* 241 */       properties = new Hashtable<>(); 
/* 242 */     if (setRanking) {
/* 243 */       properties.put("service.ranking", Integer.valueOf(2147483647));
/*     */     }
/* 245 */     properties.put("service.pid", String.valueOf(context.getBundle().getBundleId()) + "." + service.getClass().getName());
/* 246 */     this.registrations.add(context.registerService(serviceClass, service, properties));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\framework\SystemBundleActivator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */