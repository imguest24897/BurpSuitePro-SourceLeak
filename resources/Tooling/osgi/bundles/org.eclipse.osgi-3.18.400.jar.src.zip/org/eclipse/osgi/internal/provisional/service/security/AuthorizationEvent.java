/*    */ package org.eclipse.osgi.internal.provisional.service.security;
/*    */ 
/*    */ import org.eclipse.osgi.signedcontent.SignedContent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthorizationEvent
/*    */ {
/*    */   public static final int ALLOWED = 0;
/*    */   public static final int DENIED = 1;
/*    */   private final int result;
/*    */   private final SignedContent content;
/*    */   private final Object context;
/*    */   private final int severity;
/*    */   
/*    */   public AuthorizationEvent(int result, SignedContent content, Object context, int severity) {
/* 48 */     this.result = result;
/* 49 */     this.content = content;
/* 50 */     this.context = context;
/* 51 */     this.severity = severity;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getResult() {
/* 59 */     return this.result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSeverity() {
/* 67 */     return this.severity;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SignedContent getSignedContent() {
/* 75 */     return this.content;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getContext() {
/* 83 */     return this.context;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\provisional\service\security\AuthorizationEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */