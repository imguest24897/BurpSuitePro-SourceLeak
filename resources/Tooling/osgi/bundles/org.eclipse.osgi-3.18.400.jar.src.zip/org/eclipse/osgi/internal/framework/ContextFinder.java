/*     */ package org.eclipse.osgi.internal.framework;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.osgi.internal.loader.BundleLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextFinder
/*     */   extends ClassLoader
/*     */   implements PrivilegedAction<List<ClassLoader>>
/*     */ {
/*     */   static final class Finder
/*     */     extends SecurityManager
/*     */   {
/*     */     public Class<?>[] getClassContext() {
/*  33 */       Class[] result = super.getClassContext();
/*     */       
/*  35 */       return (result == null) ? new Class[0] : result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  41 */   private static ThreadLocal<Set<String>> cycleDetector = new ThreadLocal<>();
/*     */   static ClassLoader finderClassLoader;
/*     */   
/*     */   static {
/*  45 */     AccessController.doPrivileged(new PrivilegedAction<Void>()
/*     */         {
/*     */           public Void run() {
/*  48 */             ContextFinder.finderClassLoader = ContextFinder.class.getClassLoader();
/*  49 */             ContextFinder.contextFinder = new ContextFinder.Finder();
/*  50 */             return null;
/*     */           }
/*     */         });
/*     */   }
/*     */   static Finder contextFinder;
/*  55 */   private static Class<ContextFinder> THIS = ContextFinder.class;
/*     */   
/*     */   private final ClassLoader parentContextClassLoader;
/*     */   
/*     */   public ContextFinder(ClassLoader contextClassLoader, ClassLoader bootLoader) {
/*  60 */     super(contextClassLoader);
/*  61 */     this.parentContextClassLoader = (contextClassLoader != null) ? contextClassLoader : bootLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<ClassLoader> basicFindClassLoaders() {
/*  69 */     Class[] stack = contextFinder.getClassContext();
/*  70 */     List<ClassLoader> result = new ArrayList<>(1);
/*  71 */     ClassLoader previousLoader = null;
/*  72 */     for (int i = 1; i < stack.length; i++) {
/*  73 */       ClassLoader tmp = stack[i].getClassLoader();
/*  74 */       if (stack[i] != THIS && tmp != null && tmp != this) {
/*  75 */         if (checkClassLoader(tmp) && 
/*  76 */           previousLoader != tmp) {
/*  77 */           result.add(tmp);
/*  78 */           previousLoader = tmp;
/*     */         } 
/*     */ 
/*     */         
/*  82 */         if (tmp == finderClassLoader || tmp instanceof org.eclipse.osgi.internal.loader.ModuleClassLoader)
/*     */           break; 
/*     */       } 
/*     */     } 
/*  86 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkClassLoader(ClassLoader classloader) {
/*  93 */     if (classloader == null || classloader == getParent())
/*  94 */       return false; 
/*  95 */     for (ClassLoader parent = classloader.getParent(); parent != null; parent = parent.getParent()) {
/*  96 */       if (parent == this)
/*  97 */         return false; 
/*  98 */     }  return true;
/*     */   }
/*     */   
/*     */   private List<ClassLoader> findClassLoaders() {
/* 102 */     if (System.getSecurityManager() == null)
/* 103 */       return basicFindClassLoaders(); 
/* 104 */     return AccessController.<List<ClassLoader>>doPrivileged(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<ClassLoader> run() {
/* 109 */     return basicFindClassLoaders();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean startLoading(String name) {
/* 115 */     Set<String> classesAndResources = cycleDetector.get();
/* 116 */     if (classesAndResources != null && classesAndResources.contains(name)) {
/* 117 */       return false;
/*     */     }
/* 119 */     if (classesAndResources == null) {
/* 120 */       classesAndResources = new HashSet<>(3);
/* 121 */       cycleDetector.set(classesAndResources);
/*     */     } 
/* 123 */     classesAndResources.add(name);
/* 124 */     return true;
/*     */   }
/*     */   
/*     */   private void stopLoading(String name) {
/* 128 */     ((Set)cycleDetector.get()).remove(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> loadClass(String arg0, boolean arg1) throws ClassNotFoundException {
/* 134 */     if (!startLoading(arg0)) {
/* 135 */       throw new ClassNotFoundException(arg0);
/*     */     }
/*     */     try {
/* 138 */       List<ClassLoader> toConsult = findClassLoaders();
/* 139 */       for (ClassLoader classLoader : toConsult) {
/*     */         try {
/* 141 */           return classLoader.loadClass(arg0);
/* 142 */         } catch (ClassNotFoundException classNotFoundException) {}
/*     */       } 
/*     */ 
/*     */       
/* 146 */       return this.parentContextClassLoader.loadClass(arg0);
/*     */     } finally {
/* 148 */       stopLoading(arg0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getResource(String arg0) {
/* 155 */     if (!startLoading(arg0))
/* 156 */       return null; 
/*     */     try {
/* 158 */       List<ClassLoader> toConsult = findClassLoaders();
/* 159 */       for (ClassLoader classLoader : toConsult) {
/* 160 */         URL result = classLoader.getResource(arg0);
/* 161 */         if (result != null) {
/* 162 */           return result;
/*     */         }
/*     */       } 
/* 165 */       return super.getResource(arg0);
/*     */     } finally {
/* 167 */       stopLoading(arg0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<URL> getResources(String arg0) throws IOException {
/* 174 */     if (!startLoading(arg0)) {
/* 175 */       return Collections.emptyEnumeration();
/*     */     }
/*     */     try {
/* 178 */       List<ClassLoader> toConsult = findClassLoaders();
/* 179 */       Enumeration<URL> result = null;
/* 180 */       for (ClassLoader classLoader : toConsult) {
/* 181 */         result = classLoader.getResources(arg0);
/* 182 */         if (result != null && result.hasMoreElements()) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 188 */       return BundleLoader.compoundEnumerations(result, super.getResources(arg0));
/*     */     } finally {
/* 190 */       stopLoading(arg0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\framework\ContextFinder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */