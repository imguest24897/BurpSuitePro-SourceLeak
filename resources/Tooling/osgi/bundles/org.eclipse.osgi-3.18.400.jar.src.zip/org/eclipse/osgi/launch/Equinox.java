/*     */ package org.eclipse.osgi.launch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.framework.FrameworkEvent;
/*     */ import org.osgi.framework.FrameworkListener;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.Version;
/*     */ import org.osgi.framework.connect.ModuleConnector;
/*     */ import org.osgi.framework.launch.Framework;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Equinox
/*     */   implements Framework
/*     */ {
/*     */   private final Framework systemBundle;
/*     */   
/*     */   public Equinox(Map<String, ?> configuration) {
/*  46 */     this(configuration, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Equinox(Map<String, ?> configuration, ModuleConnector moduleConnector) {
/*  53 */     EquinoxContainer container = new EquinoxContainer(configuration, moduleConnector);
/*  54 */     this.systemBundle = (Framework)container.getStorage().getModuleContainer().getModule(0L).getBundle();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getState() {
/*  59 */     return this.systemBundle.getState();
/*     */   }
/*     */ 
/*     */   
/*     */   public Dictionary<String, String> getHeaders() {
/*  64 */     return this.systemBundle.getHeaders();
/*     */   }
/*     */ 
/*     */   
/*     */   public ServiceReference<?>[] getRegisteredServices() {
/*  69 */     return (ServiceReference<?>[])this.systemBundle.getRegisteredServices();
/*     */   }
/*     */ 
/*     */   
/*     */   public ServiceReference<?>[] getServicesInUse() {
/*  74 */     return (ServiceReference<?>[])this.systemBundle.getServicesInUse();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasPermission(Object permission) {
/*  79 */     return this.systemBundle.hasPermission(permission);
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getResource(String name) {
/*  84 */     return this.systemBundle.getResource(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dictionary<String, String> getHeaders(String locale) {
/*  89 */     return this.systemBundle.getHeaders(locale);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> loadClass(String name) throws ClassNotFoundException {
/*  94 */     return this.systemBundle.loadClass(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<URL> getResources(String name) throws IOException {
/*  99 */     return this.systemBundle.getResources(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLastModified() {
/* 104 */     return this.systemBundle.getLastModified();
/*     */   }
/*     */ 
/*     */   
/*     */   public BundleContext getBundleContext() {
/* 109 */     return this.systemBundle.getBundleContext();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<X509Certificate, List<X509Certificate>> getSignerCertificates(int signersType) {
/* 114 */     return this.systemBundle.getSignerCertificates(signersType);
/*     */   }
/*     */ 
/*     */   
/*     */   public Version getVersion() {
/* 119 */     return this.systemBundle.getVersion();
/*     */   }
/*     */ 
/*     */   
/*     */   public File getDataFile(String filename) {
/* 124 */     return this.systemBundle.getDataFile(filename);
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(Bundle o) {
/* 129 */     return this.systemBundle.compareTo(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public void start(int options) throws BundleException {
/* 134 */     this.systemBundle.start(options);
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() throws BundleException {
/* 139 */     this.systemBundle.start();
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop(int options) throws BundleException {
/* 144 */     this.systemBundle.stop(options);
/*     */   }
/*     */ 
/*     */   
/*     */   public void stop() throws BundleException {
/* 149 */     this.systemBundle.stop();
/*     */   }
/*     */ 
/*     */   
/*     */   public void update(InputStream input) throws BundleException {
/* 154 */     this.systemBundle.update(input);
/*     */   }
/*     */ 
/*     */   
/*     */   public void update() throws BundleException {
/* 159 */     this.systemBundle.update();
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstall() throws BundleException {
/* 164 */     this.systemBundle.uninstall();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getBundleId() {
/* 169 */     return this.systemBundle.getBundleId();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLocation() {
/* 174 */     return this.systemBundle.getLocation();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSymbolicName() {
/* 179 */     return this.systemBundle.getSymbolicName();
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<String> getEntryPaths(String path) {
/* 184 */     return this.systemBundle.getEntryPaths(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getEntry(String path) {
/* 189 */     return this.systemBundle.getEntry(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<URL> findEntries(String path, String filePattern, boolean recurse) {
/* 194 */     return this.systemBundle.findEntries(path, filePattern, recurse);
/*     */   }
/*     */ 
/*     */   
/*     */   public <A> A adapt(Class<A> type) {
/* 199 */     return (A)this.systemBundle.adapt(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public void init() throws BundleException {
/* 204 */     this.systemBundle.init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(FrameworkListener... listeners) throws BundleException {
/* 212 */     this.systemBundle.init(listeners);
/*     */   }
/*     */ 
/*     */   
/*     */   public FrameworkEvent waitForStop(long timeout) throws InterruptedException {
/* 217 */     return this.systemBundle.waitForStop(timeout);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\launch\Equinox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */