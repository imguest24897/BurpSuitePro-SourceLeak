package org.eclipse.osgi.service.resolver;

public interface BundleDelta extends Comparable<BundleDelta> {
  public static final int ADDED = 1;
  
  public static final int REMOVED = 2;
  
  public static final int UPDATED = 4;
  
  public static final int RESOLVED = 8;
  
  public static final int UNRESOLVED = 16;
  
  public static final int LINKAGE_CHANGED = 32;
  
  public static final int OPTIONAL_LINKAGE_CHANGED = 64;
  
  public static final int REMOVAL_PENDING = 128;
  
  public static final int REMOVAL_COMPLETE = 256;
  
  BundleDescription getBundle();
  
  int getType();
  
  int compareTo(BundleDelta paramBundleDelta);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\BundleDelta.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */