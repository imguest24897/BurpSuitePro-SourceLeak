package org.eclipse.osgi.signedcontent;

import java.io.IOException;

public interface SignedContentEntry {
  String getName();
  
  SignerInfo[] getSignerInfos();
  
  boolean isSigned();
  
  void verify() throws IOException, InvalidContentException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\signedcontent\SignedContentEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */