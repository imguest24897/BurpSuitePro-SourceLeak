/*     */ package org.eclipse.osgi.framework.eventmgr;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListenerQueue<K, V, E>
/*     */ {
/*     */   protected final EventManager manager;
/*     */   private final Map<Set<Map.Entry<K, V>>, EventDispatcher<K, V, E>> queue;
/*     */   private boolean readOnly;
/*     */   
/*     */   public ListenerQueue(EventManager manager) {
/*  64 */     if (manager == null) {
/*  65 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*  68 */     this.manager = manager;
/*  69 */     this.queue = new CopyOnWriteIdentityMap<>();
/*  70 */     this.readOnly = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void queueListeners(EventListeners<K, V> listeners, EventDispatcher<K, V, E> dispatcher) {
/*  87 */     queueListeners(listeners.entrySet(), dispatcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void queueListeners(Set<Map.Entry<K, V>> listeners, EventDispatcher<K, V, E> dispatcher) {
/* 105 */     if (this.readOnly) {
/* 106 */       throw new IllegalStateException();
/*     */     }
/*     */     
/* 109 */     if (!listeners.isEmpty()) {
/* 110 */       this.queue.put(listeners, dispatcher);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispatchEventAsynchronous(int eventAction, E eventObject) {
/* 123 */     synchronized (this) {
/* 124 */       this.readOnly = true;
/*     */     } 
/* 126 */     EventManager.EventThread<K, V, E> eventThread = this.manager.getEventThread();
/* 127 */     synchronized (eventThread) {
/* 128 */       for (Map.Entry<Set<Map.Entry<K, V>>, EventDispatcher<K, V, E>> entry : this.queue.entrySet()) {
/* 129 */         eventThread.postEvent(entry.getKey(), entry.getValue(), eventAction, eventObject);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispatchEventSynchronous(int eventAction, E eventObject) {
/* 145 */     synchronized (this) {
/* 146 */       this.readOnly = true;
/*     */     } 
/*     */ 
/*     */     
/* 150 */     for (Map.Entry<Set<Map.Entry<K, V>>, EventDispatcher<K, V, E>> entry : this.queue.entrySet())
/* 151 */       EventManager.dispatchEvent(entry.getKey(), entry.getValue(), eventAction, eventObject); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\framework\eventmgr\ListenerQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */