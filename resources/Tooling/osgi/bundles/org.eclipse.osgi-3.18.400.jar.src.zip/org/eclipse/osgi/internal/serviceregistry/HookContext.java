/*    */ package org.eclipse.osgi.internal.serviceregistry;
/*    */ 
/*    */ import org.osgi.framework.ServiceRegistration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface HookContext<T>
/*    */ {
/*    */   void call(T paramT, ServiceRegistration<T> paramServiceRegistration) throws Exception;
/*    */   
/*    */   default boolean skipRegistration(ServiceRegistration<?> hookRegistration) {
/* 46 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\serviceregistry\HookContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */