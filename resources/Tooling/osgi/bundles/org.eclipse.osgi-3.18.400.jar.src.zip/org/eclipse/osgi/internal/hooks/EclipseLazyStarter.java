/*     */ package org.eclipse.osgi.internal.hooks;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Deque;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import org.eclipse.osgi.container.Module;
/*     */ import org.eclipse.osgi.container.ModuleCapability;
/*     */ import org.eclipse.osgi.container.ModuleRevision;
/*     */ import org.eclipse.osgi.framework.util.SecureAction;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxContainer;
/*     */ import org.eclipse.osgi.internal.hookregistry.ClassLoaderHook;
/*     */ import org.eclipse.osgi.internal.loader.classpath.ClasspathManager;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EclipseLazyStarter
/*     */   extends ClassLoaderHook
/*     */ {
/*  44 */   private static final EnumSet<Module.State> alreadyActive = EnumSet.of(Module.State.ACTIVE, Module.State.STOPPING, Module.State.UNINSTALLED);
/*  45 */   private static final SecureAction secureAction = AccessController.<SecureAction>doPrivileged(SecureAction.createSecureAction());
/*     */ 
/*     */   
/*  48 */   private final ThreadLocal<String> initiatingClassName = new ThreadLocal<>();
/*     */   
/*  50 */   private final ThreadLocal<Deque<ClasspathManager>> activationStack = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */   
/*  54 */   private final Map<ClasspathManager, ClassNotFoundException> errors = Collections.synchronizedMap(new WeakHashMap<>());
/*     */   
/*     */   private final EquinoxContainer container;
/*     */   
/*     */   public EclipseLazyStarter(EquinoxContainer container) {
/*  59 */     this.container = container;
/*     */   }
/*     */ 
/*     */   
/*     */   public void preFindLocalClass(String name, ClasspathManager manager) throws ClassNotFoundException {
/*  64 */     if (this.initiatingClassName.get() == null) {
/*  65 */       this.initiatingClassName.set(name);
/*     */     }
/*  67 */     ModuleRevision revision = manager.getGeneration().getRevision();
/*  68 */     Module module = revision.getRevisions().getModule();
/*     */ 
/*     */     
/*  71 */     if (alreadyActive.contains(module.getState())) {
/*     */       return;
/*     */     }
/*  74 */     if (!shouldActivateFor(name, module, revision, manager))
/*     */       return; 
/*  76 */     Deque<ClasspathManager> stack = this.activationStack.get();
/*  77 */     if (stack == null) {
/*  78 */       stack = new ArrayDeque<>(6);
/*  79 */       this.activationStack.set(stack);
/*     */     } 
/*     */ 
/*     */     
/*  83 */     if (!stack.contains(manager))
/*     */     {
/*  85 */       stack.addFirst(manager);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void postFindLocalClass(String name, Class<?> clazz, ClasspathManager manager) throws ClassNotFoundException {
/*  91 */     if (this.initiatingClassName.get() != name)
/*     */       return; 
/*  93 */     this.initiatingClassName.set(null);
/*  94 */     Deque<ClasspathManager> stack = this.activationStack.get();
/*  95 */     if (stack == null || stack.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/*  99 */     List<ClasspathManager> managers = new ArrayList<>(stack);
/* 100 */     stack.clear();
/* 101 */     if (clazz == null)
/*     */       return; 
/* 103 */     for (ClasspathManager managerElement : managers) {
/* 104 */       if (this.errors.get(managerElement) != null) {
/* 105 */         if ((this.container.getConfiguration()).throwErrorOnFailedStart) {
/* 106 */           throw (ClassNotFoundException)this.errors.get(managerElement);
/*     */         }
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 113 */       long startTime = System.currentTimeMillis();
/* 114 */       Module m = managerElement.getGeneration().getRevision().getRevisions().getModule();
/*     */       
/*     */       try {
/* 117 */         secureAction.start(m, new Module.StartOptions[] { Module.StartOptions.LAZY_TRIGGER });
/* 118 */       } catch (BundleException e) {
/* 119 */         Bundle bundle = managerElement.getGeneration().getRevision().getBundle();
/* 120 */         if (e.getType() == 7) {
/* 121 */           String str = NLS.bind(Msg.ECLIPSE_CLASSLOADER_CONCURRENT_STARTUP, new Object[] { Thread.currentThread(), name, m.getStateChangeOwner(), bundle, Long.valueOf(System.currentTimeMillis() - startTime) });
/* 122 */           this.container.getLogServices().log("org.eclipse.osgi", 2, str, (Throwable)e);
/*     */           continue;
/*     */         } 
/* 125 */         String message = NLS.bind(Msg.ECLIPSE_CLASSLOADER_ACTIVATION, bundle.getSymbolicName(), Long.toString(bundle.getBundleId()));
/* 126 */         ClassNotFoundException error = new ClassNotFoundException(message, (Throwable)e);
/* 127 */         this.errors.put(managerElement, error);
/* 128 */         if ((this.container.getConfiguration()).throwErrorOnFailedStart) {
/* 129 */           this.container.getLogServices().log("org.eclipse.osgi", 4, message, (Throwable)e, null);
/* 130 */           throw error;
/*     */         } 
/* 132 */         this.container.getEventPublisher().publishFrameworkEvent(2, bundle, (Throwable)new BundleException(message, (Throwable)e));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean shouldActivateFor(String className, Module module, ModuleRevision revision, ClasspathManager manager) throws ClassNotFoundException {
/* 138 */     Module.State state = module.getState();
/* 139 */     if (!Module.State.LAZY_STARTING.equals(state)) {
/* 140 */       if (Module.State.STARTING.equals(state) && manager.getClassLoader().getBundleLoader().isTriggerSet())
/*     */       {
/* 142 */         return true;
/*     */       }
/*     */       
/* 145 */       if (Module.State.RESOLVED.equals(module.getState())) {
/*     */         
/* 147 */         if ((this.container.getConfiguration()).throwErrorOnFailedStart) {
/* 148 */           ClassNotFoundException error = this.errors.get(manager);
/* 149 */           if (error != null) {
/* 150 */             throw error;
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 157 */         return (module.isPersistentlyStarted() && isLazyStartable(className, revision));
/*     */       } 
/* 159 */       return false;
/*     */     } 
/*     */     
/* 162 */     return isLazyStartable(className, revision);
/*     */   }
/*     */   
/*     */   private boolean isLazyStartable(String className, ModuleRevision revision) {
/* 166 */     if (!revision.hasLazyActivatePolicy()) {
/* 167 */       return false;
/*     */     }
/* 169 */     List<ModuleCapability> moduleDatas = revision.getModuleCapabilities("equinox.module.data");
/* 170 */     if (moduleDatas.isEmpty()) {
/* 171 */       return false;
/*     */     }
/*     */     
/* 174 */     Map<String, Object> moduleDataAttrs = ((ModuleCapability)moduleDatas.get(0)).getAttributes();
/*     */     
/* 176 */     List<String> excludes = (List<String>)moduleDataAttrs.get("lazy.exclude");
/*     */     
/* 178 */     List<String> includes = (List<String>)moduleDataAttrs.get("lazy.include");
/*     */     
/* 180 */     if (excludes == null && includes == null) {
/* 181 */       return true;
/*     */     }
/* 183 */     int dotPosition = className.lastIndexOf('.');
/*     */     
/* 185 */     if (dotPosition == -1)
/* 186 */       return true; 
/* 187 */     String packageName = className.substring(0, dotPosition);
/* 188 */     return ((includes == null || includes.contains(packageName)) && (excludes == null || !excludes.contains(packageName)));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isProcessClassRecursionSupported() {
/* 193 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\hooks\EclipseLazyStarter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */