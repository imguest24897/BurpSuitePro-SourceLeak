/*     */ package org.eclipse.osgi.framework.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayMap<K, V>
/*     */   implements Collection<K>
/*     */ {
/*     */   final List<K> keys;
/*     */   final List<V> values;
/*     */   
/*     */   public ArrayMap(int initialCapacity) {
/*  30 */     this.keys = new ArrayList<>(initialCapacity);
/*  31 */     this.values = new ArrayList<>(initialCapacity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayMap(List<K> keys, List<V> values) {
/*  41 */     if (keys.size() != values.size())
/*  42 */       throw new IllegalArgumentException("Keys and values size must be equal."); 
/*  43 */     this.keys = keys;
/*  44 */     this.values = values;
/*     */   }
/*     */   
/*     */   public V get(K key) {
/*  48 */     int index = this.keys.indexOf(key);
/*  49 */     if (index < 0)
/*  50 */       return null; 
/*  51 */     return this.values.get(index);
/*     */   }
/*     */   
/*     */   public void put(K key, V value) {
/*  55 */     int index = this.keys.indexOf(key);
/*  56 */     if (index > 0) {
/*  57 */       this.values.set(index, value);
/*     */     } else {
/*  59 */       this.keys.add(key);
/*  60 */       this.values.add(value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean remove(Object key) {
/*  66 */     int index = this.keys.indexOf(key);
/*  67 */     if (index < 0)
/*  68 */       return false; 
/*  69 */     this.keys.remove(index);
/*  70 */     this.values.remove(index);
/*  71 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/*  76 */     this.keys.clear();
/*  77 */     this.values.clear();
/*     */   }
/*     */   
/*     */   public List<K> getKeys() {
/*  81 */     return new ArrayList<>(this.keys);
/*     */   }
/*     */   
/*     */   public List<V> getValues() {
/*  85 */     return new ArrayList<>(this.values);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  90 */     return this.keys.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  95 */     return this.keys.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object o) {
/* 100 */     return this.keys.contains(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<K> iterator() {
/* 105 */     final Iterator<K> keyIter = this.keys.iterator();
/* 106 */     final Iterator<V> valueIter = this.values.iterator();
/*     */     
/* 108 */     return new Iterator<K>()
/*     */       {
/*     */         public boolean hasNext() {
/* 111 */           return keyIter.hasNext();
/*     */         }
/*     */ 
/*     */         
/*     */         public K next() {
/* 116 */           valueIter.next();
/* 117 */           return keyIter.next();
/*     */         }
/*     */ 
/*     */         
/*     */         public void remove() {
/* 122 */           valueIter.remove();
/* 123 */           keyIter.remove();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] toArray() {
/* 130 */     return this.keys.toArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T[] toArray(Object[] a) {
/* 135 */     return this.keys.toArray((T[])a);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(K o) {
/* 140 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsAll(Collection<?> c) {
/* 145 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends K> c) {
/* 150 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean removeAll(Collection<?> c) {
/* 155 */     boolean result = false;
/* 156 */     for (Object key : c)
/* 157 */       result |= remove(key); 
/* 158 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean retainAll(Collection<?> c) {
/* 163 */     boolean result = false;
/* 164 */     Object[] keyArray = this.keys.toArray(); byte b; int i; Object[] arrayOfObject1;
/* 165 */     for (i = (arrayOfObject1 = keyArray).length, b = 0; b < i; ) { Object key = arrayOfObject1[b];
/* 166 */       if (!c.contains(key))
/* 167 */         result |= remove(key);  b++; }
/*     */     
/* 169 */     return result;
/*     */   }
/*     */   
/*     */   public K getKey(int index) {
/* 173 */     return this.keys.get(index);
/*     */   }
/*     */   
/*     */   public V getValue(int index) {
/* 177 */     return this.values.get(index);
/*     */   }
/*     */   
/*     */   public void sort(Comparator<K> comparator) {
/* 181 */     List<K> sortedKeys = new ArrayList<>(this.keys);
/* 182 */     Collections.sort(sortedKeys, comparator);
/* 183 */     List<V> sortedValues = new ArrayList<>(sortedKeys.size());
/* 184 */     for (K key : sortedKeys) {
/* 185 */       sortedValues.add(getByIdentity(key));
/*     */     }
/* 187 */     clear();
/* 188 */     for (int i = 0; i < sortedKeys.size(); i++) {
/* 189 */       put(sortedKeys.get(i), sortedValues.get(i));
/*     */     }
/*     */   }
/*     */   
/*     */   private V getByIdentity(K key) {
/* 194 */     int index = 0;
/* 195 */     for (K existing : this.keys) {
/* 196 */       if (existing == key)
/* 197 */         return getValue(index); 
/* 198 */       index++;
/*     */     } 
/* 200 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\framewor\\util\ArrayMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */