/*    */ package org.eclipse.osgi.storage.url.bundleresource;
/*    */ 
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import org.eclipse.osgi.container.Module;
/*    */ import org.eclipse.osgi.container.ModuleContainer;
/*    */ import org.eclipse.osgi.container.ModuleRevision;
/*    */ import org.eclipse.osgi.container.ModuleWiring;
/*    */ import org.eclipse.osgi.internal.loader.ModuleClassLoader;
/*    */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*    */ import org.eclipse.osgi.storage.url.BundleResourceHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Handler
/*    */   extends BundleResourceHandler
/*    */ {
/*    */   public Handler(ModuleContainer container, BundleEntry bundleEntry) {
/* 35 */     super(container, bundleEntry);
/*    */   }
/*    */ 
/*    */   
/*    */   protected BundleEntry findBundleEntry(URL url, Module module) throws IOException {
/* 40 */     ModuleRevision current = module.getCurrentRevision();
/* 41 */     ModuleWiring wiring = (current == null) ? null : current.getWiring();
/* 42 */     ModuleClassLoader classloader = (current == null) ? null : (ModuleClassLoader)wiring.getClassLoader();
/* 43 */     if (classloader == null)
/* 44 */       throw new FileNotFoundException(url.getPath()); 
/* 45 */     BundleEntry entry = classloader.getClasspathManager().findLocalEntry(url.getPath(), url.getPort());
/* 46 */     if (entry == null)
/*    */     {
/* 48 */       entry = classloader.getClasspathManager().findLocalEntry(url.getPath());
/*    */     }
/* 50 */     if (entry == null) {
/* 51 */       throw new FileNotFoundException(url.getPath());
/*    */     }
/* 53 */     return entry;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storag\\url\bundleresource\Handler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */