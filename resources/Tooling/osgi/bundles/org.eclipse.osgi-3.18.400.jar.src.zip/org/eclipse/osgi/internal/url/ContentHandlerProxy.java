/*     */ package org.eclipse.osgi.internal.url;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.ContentHandler;
/*     */ import java.net.URLConnection;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ import org.osgi.util.tracker.ServiceTrackerCustomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentHandlerProxy
/*     */   extends ContentHandler
/*     */   implements ServiceTrackerCustomizer<ContentHandler, ServiceReference<ContentHandler>>
/*     */ {
/*     */   protected ContentHandler realHandler;
/*     */   protected ServiceTracker<ContentHandler, ServiceReference<ContentHandler>> contentHandlerServiceTracker;
/*     */   protected BundleContext context;
/*     */   protected ServiceReference<ContentHandler> contentHandlerServiceReference;
/*     */   protected String contentType;
/*  44 */   protected int ranking = Integer.MIN_VALUE;
/*     */   
/*     */   public ContentHandlerProxy(String contentType, ServiceReference<ContentHandler> reference, BundleContext context) {
/*  47 */     this.context = context;
/*  48 */     this.contentType = contentType;
/*     */ 
/*     */ 
/*     */     
/*  52 */     setNewHandler(reference, getRank(reference));
/*     */     
/*  54 */     this.contentHandlerServiceTracker = new ServiceTracker(context, ContentHandler.class.getName(), this);
/*  55 */     URLStreamHandlerFactoryImpl.secureAction.open(this.contentHandlerServiceTracker);
/*     */   }
/*     */   
/*     */   private void setNewHandler(ServiceReference<ContentHandler> reference, int rank) {
/*  59 */     if (this.contentHandlerServiceReference != null) {
/*  60 */       this.context.ungetService(this.contentHandlerServiceReference);
/*     */     }
/*  62 */     this.contentHandlerServiceReference = reference;
/*  63 */     this.ranking = rank;
/*     */     
/*  65 */     if (reference == null) {
/*  66 */       this.realHandler = new DefaultContentHandler();
/*     */     } else {
/*  68 */       this.realHandler = (ContentHandler)URLStreamHandlerFactoryImpl.secureAction.getService(reference, this.context);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceReference<ContentHandler> addingService(ServiceReference<ContentHandler> reference) {
/*  77 */     Object prop = reference.getProperty("url.content.mimetype");
/*  78 */     if (prop instanceof String) {
/*  79 */       prop = new String[] { (String)prop };
/*     */     }
/*  81 */     if (!(prop instanceof String[])) {
/*  82 */       return null;
/*     */     }
/*  84 */     String[] contentTypes = (String[])prop; byte b; int i; String[] arrayOfString1;
/*  85 */     for (i = (arrayOfString1 = contentTypes).length, b = 0; b < i; ) { String candidateContentType = arrayOfString1[b];
/*  86 */       if (candidateContentType.equals(this.contentType)) {
/*     */         
/*  88 */         int newServiceRanking = getRank(reference);
/*  89 */         if (newServiceRanking > this.ranking || this.contentHandlerServiceReference == null)
/*  90 */           setNewHandler(reference, newServiceRanking); 
/*  91 */         return reference;
/*     */       } 
/*     */       
/*     */       b++; }
/*     */     
/*  96 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifiedService(ServiceReference<ContentHandler> reference, ServiceReference<ContentHandler> service) {
/* 105 */     int newrank = getRank(reference);
/* 106 */     if (reference == this.contentHandlerServiceReference) {
/* 107 */       if (newrank < this.ranking) {
/*     */ 
/*     */ 
/*     */         
/* 111 */         ServiceReference<ContentHandler> newReference = this.contentHandlerServiceTracker.getServiceReference();
/* 112 */         if (newReference != this.contentHandlerServiceReference && newReference != null) {
/* 113 */           setNewHandler(newReference, ((Integer)newReference.getProperty("service.ranking")).intValue());
/*     */         }
/*     */       } 
/* 116 */     } else if (newrank > this.ranking) {
/*     */ 
/*     */       
/* 119 */       setNewHandler(reference, newrank);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removedService(ServiceReference<ContentHandler> reference, ServiceReference<ContentHandler> service) {
/* 129 */     if (reference != this.contentHandlerServiceReference) {
/*     */       return;
/*     */     }
/*     */     
/* 133 */     ServiceReference<ContentHandler> newReference = this.contentHandlerServiceTracker.getServiceReference();
/*     */     
/* 135 */     setNewHandler(newReference, getRank(newReference));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getContent(URLConnection uConn) throws IOException {
/* 144 */     return this.realHandler.getContent(uConn);
/*     */   }
/*     */   
/*     */   private int getRank(ServiceReference<?> reference) {
/* 148 */     if (reference == null)
/* 149 */       return Integer.MIN_VALUE; 
/* 150 */     Object property = reference.getProperty("service.ranking");
/* 151 */     return (property instanceof Integer) ? ((Integer)property).intValue() : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class DefaultContentHandler
/*     */     extends ContentHandler
/*     */   {
/*     */     public Object getContent(URLConnection uConn) throws IOException {
/* 161 */       return uConn.getInputStream();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\interna\\url\ContentHandlerProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */