/*    */ package org.eclipse.osgi.internal.connect;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import java.net.URLConnection;
/*    */ import org.eclipse.osgi.storage.ContentProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConnectInputStream
/*    */   extends InputStream
/*    */   implements ContentProvider
/*    */ {
/* 23 */   static final ConnectInputStream INSTANCE = new ConnectInputStream();
/* 24 */   static final URLConnection URL_CONNECTION_INSTANCE = new URLConnection(null)
/*    */     {
/*    */       public void connect() throws IOException {
/* 27 */         this.connected = true;
/*    */       }
/*    */ 
/*    */       
/*    */       public InputStream getInputStream() throws IOException {
/* 32 */         return ConnectInputStream.INSTANCE;
/*    */       }
/*    */     };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int read() throws IOException {
/* 43 */     throw new IOException();
/*    */   }
/*    */   
/*    */   public File getContent() {
/* 47 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public ContentProvider.Type getType() {
/* 52 */     return ContentProvider.Type.CONNECT;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\connect\ConnectInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */