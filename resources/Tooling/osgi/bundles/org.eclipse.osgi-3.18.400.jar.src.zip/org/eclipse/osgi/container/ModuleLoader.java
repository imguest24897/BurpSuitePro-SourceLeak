package org.eclipse.osgi.container;

import java.net.URL;
import java.util.Collection;
import java.util.List;

public abstract class ModuleLoader {
  protected abstract List<URL> findEntries(String paramString1, String paramString2, int paramInt);
  
  protected abstract Collection<String> listResources(String paramString1, String paramString2, int paramInt);
  
  protected abstract ClassLoader getClassLoader();
  
  protected abstract boolean getAndSetTrigger();
  
  public abstract boolean isTriggerSet();
  
  protected abstract void loadFragments(Collection<ModuleRevision> paramCollection);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\ModuleLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */