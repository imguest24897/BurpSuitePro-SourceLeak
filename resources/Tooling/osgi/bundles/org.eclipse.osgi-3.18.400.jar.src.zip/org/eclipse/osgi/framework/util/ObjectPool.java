/*    */ package org.eclipse.osgi.framework.util;
/*    */ 
/*    */ import java.lang.ref.WeakReference;
/*    */ import java.util.Map;
/*    */ import java.util.WeakHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectPool
/*    */ {
/*    */   private static final boolean DEBUG_OBJECTPOOL_ADDS = false;
/*    */   private static final boolean DEBUG_OBJECTPOOL_DUPS = false;
/* 27 */   private static Map<Object, WeakReference<Object>> objectCache = new WeakHashMap<>();
/*    */ 
/*    */   
/*    */   public static <T> T intern(T obj) {
/* 31 */     synchronized (objectCache) {
/* 32 */       WeakReference<Object> ref = objectCache.get(obj);
/* 33 */       if (ref != null) {
/* 34 */         Object refValue = ref.get();
/* 35 */         if (refValue != null) {
/* 36 */           obj = (T)refValue;
/*    */         }
/*    */       }
/*    */       else {
/*    */         
/* 41 */         objectCache.put(obj, new WeakReference(obj));
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 46 */     return obj;
/*    */   }
/*    */   
/*    */   private static String getObjectString(Object obj) {
/* 50 */     return "[(" + obj.getClass().getName() + ") " + obj.toString() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\framewor\\util\ObjectPool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */