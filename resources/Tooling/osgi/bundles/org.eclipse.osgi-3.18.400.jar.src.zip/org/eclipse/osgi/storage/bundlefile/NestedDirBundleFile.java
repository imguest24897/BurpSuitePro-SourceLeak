/*     */ package org.eclipse.osgi.storage.bundlefile;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NestedDirBundleFile
/*     */   extends BundleFile
/*     */ {
/*     */   private final BundleFile baseBundleFile;
/*     */   private final String nestedDirName;
/*     */   private final Collection<String> filterPrefixes;
/*     */   
/*     */   public NestedDirBundleFile(BundleFile baseBundlefile, String nestedDirName) {
/*  45 */     this(baseBundlefile, nestedDirName, Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NestedDirBundleFile(BundleFile baseBundlefile, String nestedDirName, Collection<String> filterPrefixes) {
/*  55 */     super(baseBundlefile.getBaseFile());
/*  56 */     this.baseBundleFile = baseBundlefile;
/*  57 */     if (nestedDirName.charAt(nestedDirName.length() - 1) != '/') {
/*  58 */       nestedDirName = String.valueOf(nestedDirName) + '/';
/*     */     }
/*  60 */     this.nestedDirName = nestedDirName;
/*  61 */     this.filterPrefixes = filterPrefixes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */ 
/*     */   
/*     */   private boolean filterPath(String path) {
/*  70 */     if (path.length() > 0 && path.charAt(0) == '/')
/*  71 */       path = path.substring(1); 
/*  72 */     for (String prefix : this.filterPrefixes) {
/*  73 */       if (path.startsWith(prefix)) {
/*  74 */         return true;
/*     */       }
/*     */     } 
/*  77 */     return false;
/*     */   }
/*     */   
/*     */   private boolean filterDir(String path) {
/*  81 */     if (this.filterPrefixes.isEmpty()) {
/*  82 */       return false;
/*     */     }
/*  84 */     if (path.length() > 0 && path.charAt(path.length() - 1) != '/') {
/*  85 */       path = String.valueOf(path) + '/';
/*     */     }
/*  87 */     return filterPath(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public BundleEntry getEntry(String path) {
/*  92 */     if (filterPath(path)) {
/*  93 */       return null;
/*     */     }
/*  95 */     return this.baseBundleFile.getEntry(prependNestedDir(path));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsDir(String dir) {
/* 100 */     if (dir == null)
/* 101 */       return false; 
/* 102 */     if (filterPath(dir)) {
/* 103 */       return false;
/*     */     }
/* 105 */     return this.baseBundleFile.containsDir(prependNestedDir(dir));
/*     */   }
/*     */   
/*     */   private String prependNestedDir(String path) {
/* 109 */     if (path.length() > 0 && path.charAt(0) == '/')
/* 110 */       path = path.substring(1); 
/* 111 */     return this.nestedDirName + path;
/*     */   }
/*     */ 
/*     */   
/*     */   public Enumeration<String> getEntryPaths(String path, boolean recurse) {
/* 116 */     if (filterDir(path)) {
/* 117 */       return null;
/*     */     }
/* 119 */     final Enumeration<String> basePaths = this.baseBundleFile.getEntryPaths(prependNestedDir(path), recurse);
/* 120 */     final int cpLength = this.nestedDirName.length();
/* 121 */     if (basePaths == null)
/* 122 */       return null; 
/* 123 */     return new Enumeration<String>()
/*     */       {
/*     */         public boolean hasMoreElements()
/*     */         {
/* 127 */           return basePaths.hasMoreElements();
/*     */         }
/*     */ 
/*     */         
/*     */         public String nextElement() {
/* 132 */           String next = basePaths.nextElement();
/* 133 */           return next.substring(cpLength);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getFile(String entry, boolean nativeCode) {
/* 142 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 155 */     return String.valueOf(super.toString()) + '[' + this.nestedDirName + ']';
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\bundlefile\NestedDirBundleFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */