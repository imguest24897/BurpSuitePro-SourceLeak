/*    */ package org.eclipse.osgi.launch;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.osgi.framework.connect.ConnectFrameworkFactory;
/*    */ import org.osgi.framework.connect.ModuleConnector;
/*    */ import org.osgi.framework.launch.Framework;
/*    */ import org.osgi.framework.launch.FrameworkFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EquinoxFactory
/*    */   implements FrameworkFactory, ConnectFrameworkFactory
/*    */ {
/*    */   public Framework newFramework(Map<String, String> configuration) {
/* 30 */     return newFramework(configuration, null);
/*    */   }
/*    */ 
/*    */   
/*    */   public Framework newFramework(Map<String, String> configuration, ModuleConnector moduleConnector) {
/* 35 */     return new Equinox(configuration, moduleConnector);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\launch\EquinoxFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */