/*     */ package org.eclipse.osgi.service.security;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.cert.Certificate;
/*     */ import org.eclipse.osgi.internal.signedcontent.TrustEngineListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TrustEngine
/*     */ {
/*     */   private volatile TrustEngineListener trustEngineListener;
/*     */   
/*     */   public abstract Certificate findTrustAnchor(Certificate[] paramArrayOfCertificate) throws IOException;
/*     */   
/*     */   public String addTrustAnchor(Certificate anchor, String alias) throws IOException, GeneralSecurityException {
/*  53 */     String storedAlias = doAddTrustAnchor(anchor, alias);
/*  54 */     TrustEngineListener listener = this.trustEngineListener;
/*  55 */     if (listener != null)
/*  56 */       listener.addedTrustAnchor(anchor); 
/*  57 */     return storedAlias;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String doAddTrustAnchor(Certificate paramCertificate, String paramString) throws IOException, GeneralSecurityException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void removeTrustAnchor(Certificate anchor) throws IOException, GeneralSecurityException {
/*  81 */     doRemoveTrustAnchor(anchor);
/*  82 */     TrustEngineListener listener = this.trustEngineListener;
/*  83 */     if (listener != null) {
/*  84 */       listener.removedTrustAnchor(anchor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void doRemoveTrustAnchor(Certificate paramCertificate) throws IOException, GeneralSecurityException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeTrustAnchor(String alias) throws IOException, GeneralSecurityException {
/* 102 */     Certificate existing = getTrustAnchor(alias);
/* 103 */     doRemoveTrustAnchor(alias);
/* 104 */     if (existing != null) {
/* 105 */       TrustEngineListener listener = this.trustEngineListener;
/* 106 */       if (listener != null)
/* 107 */         listener.removedTrustAnchor(existing); 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected abstract void doRemoveTrustAnchor(String paramString) throws IOException, GeneralSecurityException;
/*     */   
/*     */   public abstract Certificate getTrustAnchor(String paramString) throws IOException, GeneralSecurityException;
/*     */   
/*     */   public abstract String[] getAliases() throws IOException, GeneralSecurityException;
/*     */   
/*     */   public abstract boolean isReadOnly();
/*     */   
/*     */   public abstract String getName();
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\security\TrustEngine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */