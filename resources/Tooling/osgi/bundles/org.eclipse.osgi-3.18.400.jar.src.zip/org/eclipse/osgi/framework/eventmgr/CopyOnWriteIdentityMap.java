/*     */ package org.eclipse.osgi.framework.eventmgr;
/*     */ 
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CopyOnWriteIdentityMap<K, V>
/*     */   implements Map<K, V>
/*     */ {
/*  43 */   private static final Entry[] emptyArray = new Entry[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile Entry<K, V>[] entries;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CopyOnWriteIdentityMap() {
/*  56 */     this.entries = empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CopyOnWriteIdentityMap(CopyOnWriteIdentityMap<? extends K, ? extends V> source) {
/*  66 */     Entry[] toCopy = (Entry[])source.entries();
/*  67 */     this.entries = (Entry<K, V>[])toCopy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized V put(K key, V value) {
/*  86 */     Objects.requireNonNull(key);
/*     */     
/*  88 */     int size = this.entries.length;
/*  89 */     for (int i = 0; i < size; i++) {
/*  90 */       if ((this.entries[i]).key == key) {
/*  91 */         V v = (this.entries[i]).value;
/*  92 */         if (v == value) {
/*  93 */           return v;
/*     */         }
/*     */         
/*  96 */         Entry[] arrayOfEntry = new Entry[size];
/*  97 */         System.arraycopy(this.entries, 0, arrayOfEntry, 0, size);
/*  98 */         arrayOfEntry[i] = new Entry<>(key, value);
/*  99 */         this.entries = (Entry<K, V>[])arrayOfEntry;
/* 100 */         return v;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 105 */     Entry[] newEntries = new Entry[size + 1];
/* 106 */     if (size > 0) {
/* 107 */       System.arraycopy(this.entries, 0, newEntries, 0, size);
/*     */     }
/* 109 */     newEntries[size] = new Entry<>(key, value);
/* 110 */     this.entries = (Entry<K, V>[])newEntries;
/* 111 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> source) {
/* 121 */     int sourceSize = source.size();
/* 122 */     if (sourceSize == 0) {
/*     */       return;
/*     */     }
/* 125 */     if (source instanceof CopyOnWriteIdentityMap) {
/* 126 */       putAll((Entry<? extends K, ? extends V>[])((CopyOnWriteIdentityMap)source).entries());
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 131 */     Entry[] toCopy = new Entry[sourceSize];
/* 132 */     Iterator<? extends Map.Entry<? extends K, ? extends V>> iter = source.entrySet().iterator();
/* 133 */     for (int i = 0; i < sourceSize; i++) {
/* 134 */       Map.Entry<? extends K, ? extends V> mapEntry = iter.next();
/* 135 */       toCopy[i] = new Entry<>(mapEntry.getKey(), mapEntry.getValue());
/*     */     } 
/* 137 */     putAll((Entry<? extends K, ? extends V>[])toCopy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <L extends K> void putAll(Object[] keys) {
/* 147 */     int sourceSize = keys.length;
/* 148 */     if (sourceSize == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 152 */     Entry[] toCopy = new Entry[sourceSize];
/* 153 */     for (int i = 0; i < sourceSize; i++) {
/* 154 */       toCopy[i] = new Entry<>(keys[i], null);
/*     */     }
/* 156 */     putAll((Entry<? extends K, ? extends V>[])toCopy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void putAll(Entry[] toCopy) {
/* 165 */     int sourceSize = toCopy.length;
/* 166 */     int size = this.entries.length;
/*     */     
/* 168 */     Entry[] newEntries = new Entry[size + sourceSize];
/* 169 */     System.arraycopy(this.entries, 0, newEntries, 0, size);
/* 170 */     for (int n = 0; n < sourceSize; n++) {
/*     */       
/* 172 */       Entry<K, V> copy = toCopy[n];
/* 173 */       int i = 0; while (true) { if (i >= size)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */           
/* 179 */           newEntries[size] = copy;
/* 180 */           size++; break; }  if ((newEntries[i]).key == copy.key) { newEntries[i] = copy; break; }  i++; }
/*     */     
/* 182 */     }  if (size == newEntries.length) {
/* 183 */       this.entries = (Entry<K, V>[])newEntries;
/*     */       
/*     */       return;
/*     */     } 
/* 187 */     Entry[] e = new Entry[size];
/* 188 */     System.arraycopy(newEntries, 0, e, 0, size);
/* 189 */     this.entries = (Entry<K, V>[])e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized V remove(Object key) {
/* 203 */     Objects.requireNonNull(key);
/*     */     
/* 205 */     int size = this.entries.length;
/* 206 */     for (int i = 0; i < size; i++) {
/* 207 */       if ((this.entries[i]).key == key) {
/* 208 */         V v = (this.entries[i]).value;
/* 209 */         this.entries = removeEntry(this.entries, i);
/* 210 */         return v;
/*     */       } 
/*     */     } 
/* 213 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <K, V> Entry<K, V>[] removeEntry(Entry[] entries, int i) {
/* 220 */     int size = entries.length;
/* 221 */     if (size == 1) {
/* 222 */       return empty();
/*     */     }
/*     */     
/* 225 */     Entry[] newEntries = new Entry[size - 1];
/* 226 */     if (i > 0) {
/* 227 */       System.arraycopy(entries, 0, newEntries, 0, i);
/*     */     }
/* 229 */     int next = size - 1 - i;
/* 230 */     if (next > 0) {
/* 231 */       System.arraycopy(entries, i + 1, newEntries, i, next);
/*     */     }
/* 233 */     return (Entry<K, V>[])newEntries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void clear() {
/* 242 */     this.entries = empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Entry<K, V>[] entries() {
/* 253 */     return this.entries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <K, V> Entry<K, V>[] empty() {
/* 262 */     return (Entry<K, V>[])emptyArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 272 */     return (size() == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 282 */     return (entries()).length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V get(Object key) {
/* 295 */     Objects.requireNonNull(key); byte b; int i;
/*     */     Entry[] arrayOfEntry;
/* 297 */     for (i = (arrayOfEntry = (Entry[])entries()).length, b = 0; b < i; ) { Entry<K, V> entry = arrayOfEntry[b];
/* 298 */       if (entry.key == key)
/* 299 */         return entry.value; 
/*     */       b++; }
/*     */     
/* 302 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/* 315 */     Objects.requireNonNull(key); byte b; int i;
/*     */     Entry[] arrayOfEntry;
/* 317 */     for (i = (arrayOfEntry = (Entry[])entries()).length, b = 0; b < i; ) { Entry<K, V> entry = arrayOfEntry[b];
/* 318 */       if (entry.key == key)
/* 319 */         return true; 
/*     */       b++; }
/*     */     
/* 322 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/*     */     byte b;
/*     */     int i;
/*     */     Entry[] arrayOfEntry;
/* 334 */     for (i = (arrayOfEntry = (Entry[])entries()).length, b = 0; b < i; ) { Entry<K, V> entry = arrayOfEntry[b];
/* 335 */       if (entry.value == value)
/* 336 */         return true; 
/*     */       b++; }
/*     */     
/* 339 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/* 351 */     return (new Snapshot<>(entries())).entrySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<K> keySet() {
/* 362 */     return (new Snapshot<>((Entry<K, ?>[])entries())).keySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<V> values() {
/* 373 */     return (new Snapshot<>((Entry<?, V>[])entries())).values();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Entry<K, V>
/*     */     implements Map.Entry<K, V>
/*     */   {
/*     */     final K key;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final V value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Entry(K key, V value) {
/* 399 */       this.key = Objects.requireNonNull(key);
/* 400 */       this.value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public K getKey() {
/* 405 */       return this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     public V getValue() {
/* 410 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public V setValue(V value) {
/* 415 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 420 */       return (new StringBuilder()).append(this.key).append("=").append(this.value).toString();
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 425 */       return System.identityHashCode(this.key) ^ System.identityHashCode(this.value);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 430 */       if (obj == this) {
/* 431 */         return true;
/*     */       }
/*     */       
/* 434 */       if (!(obj instanceof Map.Entry)) {
/* 435 */         return false;
/*     */       }
/*     */       
/* 438 */       Map.Entry<?, ?> e = (Map.Entry<?, ?>)obj;
/* 439 */       return (this.key == e.getKey() && this.value == e.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Snapshot<K, V>
/*     */   {
/*     */     volatile CopyOnWriteIdentityMap.Entry<K, V>[] entries;
/*     */ 
/*     */ 
/*     */     
/*     */     Snapshot(CopyOnWriteIdentityMap.Entry[] e) {
/* 453 */       this.entries = (CopyOnWriteIdentityMap.Entry<K, V>[])e;
/*     */     }
/*     */     
/*     */     CopyOnWriteIdentityMap.Entry<K, V>[] entries() {
/* 457 */       return this.entries;
/*     */     }
/*     */     
/*     */     synchronized void removeEntry(int i) {
/* 461 */       this.entries = CopyOnWriteIdentityMap.removeEntry(this.entries, i);
/*     */     }
/*     */     
/*     */     synchronized void clearEntries() {
/* 465 */       this.entries = CopyOnWriteIdentityMap.empty();
/*     */     }
/*     */     
/*     */     Set<Map.Entry<K, V>> entrySet() {
/* 469 */       return new EntrySet();
/*     */     }
/*     */     
/*     */     Set<K> keySet() {
/* 473 */       return new KeySet();
/*     */     }
/*     */     
/*     */     Collection<V> values() {
/* 477 */       return new ValueCollection();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final class EntrySet
/*     */       extends AbstractSet<Map.Entry<K, V>>
/*     */     {
/*     */       public Iterator<Map.Entry<K, V>> iterator() {
/* 490 */         return new CopyOnWriteIdentityMap.Snapshot.EntryIterator();
/*     */       }
/*     */ 
/*     */       
/*     */       public int size() {
/* 495 */         return (CopyOnWriteIdentityMap.Snapshot.this.entries()).length;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean remove(Object o) {
/* 500 */         Objects.requireNonNull(o);
/*     */         
/* 502 */         synchronized (CopyOnWriteIdentityMap.Snapshot.this) {
/* 503 */           int size = CopyOnWriteIdentityMap.Snapshot.this.entries.length;
/* 504 */           for (int i = 0; i < size; i++) {
/* 505 */             if (CopyOnWriteIdentityMap.Snapshot.this.entries[i].equals(o)) {
/* 506 */               CopyOnWriteIdentityMap.Snapshot.this.removeEntry(i);
/* 507 */               return true;
/*     */             } 
/*     */           } 
/*     */         } 
/* 511 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       public void clear() {
/* 516 */         CopyOnWriteIdentityMap.Snapshot.this.clearEntries();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final class EntryIterator
/*     */       extends SnapshotIterator<Map.Entry<K, V>>
/*     */     {
/*     */       public Map.Entry<K, V> next() {
/* 530 */         return nextEntry();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final class KeySet
/*     */       extends AbstractSet<K>
/*     */     {
/*     */       public Iterator<K> iterator() {
/* 544 */         return new CopyOnWriteIdentityMap.Snapshot.KeyIterator();
/*     */       }
/*     */ 
/*     */       
/*     */       public int size() {
/* 549 */         return (CopyOnWriteIdentityMap.Snapshot.this.entries()).length;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean remove(Object o) {
/* 554 */         Objects.requireNonNull(o);
/*     */         
/* 556 */         synchronized (CopyOnWriteIdentityMap.Snapshot.this) {
/* 557 */           int size = CopyOnWriteIdentityMap.Snapshot.this.entries.length;
/* 558 */           for (int i = 0; i < size; i++) {
/* 559 */             if ((CopyOnWriteIdentityMap.Snapshot.this.entries[i]).key == o) {
/* 560 */               CopyOnWriteIdentityMap.Snapshot.this.removeEntry(i);
/* 561 */               return true;
/*     */             } 
/*     */           } 
/*     */         } 
/* 565 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       public void clear() {
/* 570 */         CopyOnWriteIdentityMap.Snapshot.this.clearEntries();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final class KeyIterator
/*     */       extends SnapshotIterator<K>
/*     */     {
/*     */       public K next() {
/* 584 */         return (nextEntry()).key;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final class ValueCollection
/*     */       extends AbstractCollection<V>
/*     */     {
/*     */       public Iterator<V> iterator() {
/* 598 */         return new CopyOnWriteIdentityMap.Snapshot.ValueIterator();
/*     */       }
/*     */ 
/*     */       
/*     */       public int size() {
/* 603 */         return (CopyOnWriteIdentityMap.Snapshot.this.entries()).length;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean remove(Object o) {
/* 608 */         Objects.requireNonNull(o);
/*     */         
/* 610 */         synchronized (CopyOnWriteIdentityMap.Snapshot.this) {
/* 611 */           int size = CopyOnWriteIdentityMap.Snapshot.this.entries.length;
/* 612 */           for (int i = 0; i < size; i++) {
/* 613 */             if ((CopyOnWriteIdentityMap.Snapshot.this.entries[i]).value == o) {
/* 614 */               CopyOnWriteIdentityMap.Snapshot.this.removeEntry(i);
/* 615 */               return true;
/*     */             } 
/*     */           } 
/*     */         } 
/* 619 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       public void clear() {
/* 624 */         CopyOnWriteIdentityMap.Snapshot.this.clearEntries();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final class ValueIterator
/*     */       extends SnapshotIterator<V>
/*     */     {
/*     */       public V next() {
/* 638 */         return (nextEntry()).value;
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     private abstract class SnapshotIterator<E>
/*     */       implements Iterator<E>
/*     */     {
/*     */       private int length;
/*     */       private int cursor;
/*     */       
/*     */       SnapshotIterator() {
/* 650 */         this.length = (CopyOnWriteIdentityMap.Snapshot.this.entries()).length;
/* 651 */         this.cursor = 0;
/*     */       }
/*     */ 
/*     */       
/*     */       public final boolean hasNext() {
/* 656 */         return (this.cursor < this.length);
/*     */       }
/*     */       
/*     */       protected final CopyOnWriteIdentityMap.Entry<K, V> nextEntry() {
/* 660 */         CopyOnWriteIdentityMap.Entry[] e = CopyOnWriteIdentityMap.Snapshot.this.entries();
/* 661 */         if (this.length != e.length) {
/* 662 */           throw new ConcurrentModificationException();
/*     */         }
/* 664 */         if (this.cursor == this.length) {
/* 665 */           throw new NoSuchElementException();
/*     */         }
/* 667 */         return e[this.cursor++];
/*     */       }
/*     */ 
/*     */       
/*     */       public final void remove() {
/* 672 */         if (this.length != (CopyOnWriteIdentityMap.Snapshot.this.entries()).length) {
/* 673 */           throw new ConcurrentModificationException();
/*     */         }
/* 675 */         if (this.cursor == 0) {
/* 676 */           throw new IllegalStateException();
/*     */         }
/* 678 */         this.cursor--;
/* 679 */         CopyOnWriteIdentityMap.Snapshot.this.removeEntry(this.cursor);
/* 680 */         this.length = (CopyOnWriteIdentityMap.Snapshot.this.entries()).length;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\framework\eventmgr\CopyOnWriteIdentityMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */