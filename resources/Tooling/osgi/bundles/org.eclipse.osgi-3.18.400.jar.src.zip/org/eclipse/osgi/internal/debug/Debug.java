/*     */ package org.eclipse.osgi.internal.debug;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import org.eclipse.osgi.internal.util.SupplementDebug;
/*     */ import org.eclipse.osgi.service.debug.DebugOptions;
/*     */ import org.eclipse.osgi.service.debug.DebugOptionsListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Debug
/*     */   implements DebugOptionsListener
/*     */ {
/*     */   public static final String ECLIPSE_OSGI = "org.eclipse.osgi";
/*     */   public static final String OPTION_DEBUG_GENERAL = "org.eclipse.osgi/debug";
/*     */   public static final String OPTION_DEBUG_BUNDLE_TIME = "org.eclipse.osgi/debug/bundleTime";
/*     */   public static final String OPTION_DEBUG_BUNDLE_START_TIME = "org.eclipse.osgi/debug/bundleStartTime";
/*     */   public static final String OPTION_DEBUG_LOADER = "org.eclipse.osgi/debug/loader";
/*     */   public static final String OPTION_DEBUG_STORAGE = "org.eclipse.osgi/debug/storage";
/*     */   public static final String OPTION_DEBUG_EVENTS = "org.eclipse.osgi/debug/events";
/*     */   public static final String OPTION_DEBUG_SERVICES = "org.eclipse.osgi/debug/services";
/*     */   public static final String OPTION_DEBUG_HOOKS = "org.eclipse.osgi/debug/hooks";
/*     */   public static final String OPTION_DEBUG_MANIFEST = "org.eclipse.osgi/debug/manifest";
/*     */   public static final String OPTION_DEBUG_FILTER = "org.eclipse.osgi/debug/filter";
/*     */   public static final String OPTION_DEBUG_SECURITY = "org.eclipse.osgi/debug/security";
/*     */   public static final String OPTION_DEBUG_STARTLEVEL = "org.eclipse.osgi/debug/startlevel";
/*     */   public static final String OPTION_DEBUG_PACKAGEADMIN = "org.eclipse.osgi/debug/packageadmin";
/*     */   public static final String OPTION_DEBUG_PACKAGEADMIN_TIMING = "org.eclipse.osgi/debug/packageadmin/timing";
/*     */   public static final String OPTION_MONITOR_ACTIVATION = "org.eclipse.osgi/monitor/activation";
/*     */   public static final String OPTION_MONITOR_LAZY = "org.eclipse.osgi/monitor/lazy";
/*     */   public static final String OPTION_DEBUG_MESSAGE_BUNDLES = "org.eclipse.osgi/debug/messageBundles";
/*     */   public static final String OPTION_DEBUG_LOCATION = "org.eclipse.osgi/debug/location";
/*     */   public static final String OPTION_CACHED_MANIFEST = "org.eclipse.osgi/debug/cachedmanifest";
/*     */   public static final String OPTION_DEBUG_SYSTEM_BUNDLE = "org.eclipse.osgi/debug/systemBundle";
/*     */   public static final String OPTION_DEBUG_BUNDLE_FILE = "org.eclipse.osgi/debug/bundleFile";
/*     */   public static final String OPTION_DEBUG_BUNDLE_FILE_OPEN = "org.eclipse.osgi/debug/bundleFile/open";
/*     */   public static final String OPTION_DEBUG_BUNDLE_FILE_CLOSE = "org.eclipse.osgi/debug/bundleFile/close";
/*     */   public boolean DEBUG_GENERAL = false;
/*     */   public boolean DEBUG_BUNDLE_TIME = false;
/*     */   public boolean DEBUG_LOADER = false;
/*     */   public boolean DEBUG_STORAGE = false;
/*     */   public boolean DEBUG_EVENTS = false;
/*     */   public boolean DEBUG_SERVICES = false;
/*     */   public boolean DEBUG_HOOKS = false;
/*     */   public boolean DEBUG_MANIFEST = false;
/*     */   public boolean DEBUG_FILTER = false;
/*     */   public boolean DEBUG_SECURITY = false;
/*     */   public boolean DEBUG_STARTLEVEL = false;
/*     */   public boolean DEBUG_PACKAGEADMIN = false;
/*     */   public boolean DEBUG_PACKAGEADMIN_TIMING = false;
/*     */   public boolean DEBUG_MESSAGE_BUNDLES = false;
/*     */   public boolean MONITOR_ACTIVATION = false;
/*     */   public boolean DEBUG_LOCATION = false;
/*     */   public boolean DEBUG_CACHED_MANIFEST = false;
/*     */   public boolean DEBUG_SYSTEM_BUNDLE = false;
/*     */   public boolean DEBUG_BUNDLE_FILE = false;
/*     */   public boolean DEBUG_BUNDLE_FILE_OPEN = false;
/*     */   public boolean DEBUG_BUNDLE_FILE_CLOSE = false;
/*     */   
/*     */   public Debug(DebugOptions dbgOptions) {
/* 192 */     optionsChanged(dbgOptions);
/*     */   }
/*     */ 
/*     */   
/*     */   public void optionsChanged(DebugOptions dbgOptions) {
/* 197 */     this.DEBUG_GENERAL = dbgOptions.getBooleanOption("org.eclipse.osgi/debug", false);
/* 198 */     this.DEBUG_BUNDLE_TIME = !(!dbgOptions.getBooleanOption("org.eclipse.osgi/debug/bundleTime", false) && !dbgOptions.getBooleanOption("org.eclipse.core.runtime/timing/startup", false));
/* 199 */     this.DEBUG_LOADER = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/loader", false);
/* 200 */     this.DEBUG_STORAGE = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/storage", false);
/* 201 */     this.DEBUG_EVENTS = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/events", false);
/* 202 */     this.DEBUG_SERVICES = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/services", false);
/* 203 */     this.DEBUG_HOOKS = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/hooks", false);
/* 204 */     this.DEBUG_MANIFEST = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/manifest", false);
/* 205 */     SupplementDebug.STATIC_DEBUG_MANIFEST = this.DEBUG_MANIFEST;
/* 206 */     this.DEBUG_FILTER = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/filter", false);
/* 207 */     this.DEBUG_SECURITY = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/security", false);
/* 208 */     this.DEBUG_STARTLEVEL = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/startlevel", false);
/* 209 */     this.DEBUG_PACKAGEADMIN = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/packageadmin", false);
/* 210 */     this.DEBUG_PACKAGEADMIN_TIMING = !(!dbgOptions.getBooleanOption("org.eclipse.osgi/debug/packageadmin/timing", false) && !dbgOptions.getBooleanOption("org.eclipse.core.runtime/debug", false));
/* 211 */     this.DEBUG_MESSAGE_BUNDLES = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/messageBundles", false);
/* 212 */     SupplementDebug.STATIC_DEBUG_MESSAGE_BUNDLES = this.DEBUG_MESSAGE_BUNDLES;
/* 213 */     this.MONITOR_ACTIVATION = dbgOptions.getBooleanOption("org.eclipse.osgi/monitor/activation", false);
/* 214 */     this.DEBUG_LOCATION = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/location", false);
/* 215 */     this.DEBUG_CACHED_MANIFEST = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/cachedmanifest", false);
/* 216 */     this.DEBUG_SYSTEM_BUNDLE = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/systemBundle", false);
/* 217 */     this.DEBUG_BUNDLE_FILE = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/bundleFile", false);
/* 218 */     this.DEBUG_BUNDLE_FILE_OPEN = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/bundleFile/open", false);
/* 219 */     this.DEBUG_BUNDLE_FILE_CLOSE = dbgOptions.getBooleanOption("org.eclipse.osgi/debug/bundleFile/close", false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   public static PrintStream out = System.out;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void print(boolean x) {
/* 232 */     out.print(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void print(char x) {
/* 240 */     out.print(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void print(int x) {
/* 248 */     out.print(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void print(long x) {
/* 256 */     out.print(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void print(float x) {
/* 264 */     out.print(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void print(double x) {
/* 272 */     out.print(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void print(char[] x) {
/* 280 */     out.print(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void print(String x) {
/* 288 */     out.print(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void print(Object x) {
/* 296 */     out.print(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void println(boolean x) {
/* 304 */     out.println(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void println(char x) {
/* 312 */     out.println(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void println(int x) {
/* 320 */     out.println(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void println(long x) {
/* 328 */     out.println(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void println(float x) {
/* 336 */     out.println(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void println(double x) {
/* 344 */     out.println(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void println(char[] x) {
/* 352 */     out.println(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void println(String x) {
/* 360 */     out.println(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void println(Object x) {
/* 368 */     out.println(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printStackTrace(Throwable t) {
/* 376 */     if (t == null)
/*     */       return; 
/* 378 */     t.printStackTrace(out);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\debug\Debug.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */