/*     */ package org.eclipse.osgi.storage.bundlefile;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileBundleEntry
/*     */   extends BundleEntry
/*     */ {
/*     */   private final File file;
/*     */   private final String name;
/*     */   
/*     */   public FileBundleEntry(File file, String name) {
/*  41 */     this.file = file;
/*  42 */     boolean endsInSlash = (name.length() > 0 && name.charAt(name.length() - 1) == '/');
/*  43 */     if (BundleFile.secureAction.isDirectory(file)) {
/*  44 */       if (!endsInSlash)
/*  45 */         name = String.valueOf(name) + '/'; 
/*  46 */     } else if (endsInSlash) {
/*  47 */       name = name.substring(0, name.length() - 1);
/*  48 */     }  this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getInputStream() throws IOException {
/*  59 */     return BundleFile.secureAction.getFileInputStream(this.file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getSize() {
/*  69 */     return BundleFile.secureAction.length(this.file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  79 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTime() {
/*  91 */     return BundleFile.secureAction.lastModified(this.file);
/*     */   }
/*     */ 
/*     */   
/*     */   public URL getLocalURL() {
/*  96 */     return getFileURL();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getFileURL() {
/*     */     try {
/* 103 */       return this.file.toURL();
/* 104 */     } catch (MalformedURLException malformedURLException) {
/* 105 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\storage\bundlefile\FileBundleEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */