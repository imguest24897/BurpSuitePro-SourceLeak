/*     */ package org.eclipse.osgi.container;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import org.eclipse.osgi.internal.container.InternalUtils;
/*     */ import org.eclipse.osgi.internal.container.NamespaceList;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.Version;
/*     */ import org.osgi.framework.wiring.BundleCapability;
/*     */ import org.osgi.framework.wiring.BundleRequirement;
/*     */ import org.osgi.framework.wiring.BundleRevision;
/*     */ import org.osgi.framework.wiring.BundleWiring;
/*     */ import org.osgi.resource.Capability;
/*     */ import org.osgi.resource.Requirement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ModuleRevision
/*     */   implements BundleRevision
/*     */ {
/*     */   private final String symbolicName;
/*     */   private final Version version;
/*     */   private final int types;
/*     */   private final NamespaceList<ModuleCapability> capabilities;
/*     */   private final NamespaceList<ModuleRequirement> requirements;
/*     */   private final ModuleRevisions revisions;
/*     */   private final Object revisionInfo;
/*  48 */   private volatile Boolean lazyActivationPolicy = null;
/*     */   
/*     */   ModuleRevision(String symbolicName, Version version, int types, NamespaceList.Builder<ModuleRevisionBuilder.GenericInfo> capabilityInfos, NamespaceList.Builder<ModuleRevisionBuilder.GenericInfo> requirementInfos, ModuleRevisions revisions, Object revisionInfo) {
/*  51 */     this.symbolicName = symbolicName;
/*  52 */     this.version = version;
/*  53 */     this.types = types;
/*  54 */     this.capabilities = createCapabilities(capabilityInfos);
/*  55 */     this.requirements = createRequirements(requirementInfos);
/*  56 */     this.revisions = revisions;
/*  57 */     this.revisionInfo = revisionInfo;
/*     */   }
/*     */   
/*     */   private NamespaceList<ModuleCapability> createCapabilities(NamespaceList.Builder<ModuleRevisionBuilder.GenericInfo> capabilityInfos) {
/*  61 */     return capabilityInfos.transformIntoCopy(new Function<ModuleRevisionBuilder.GenericInfo, ModuleCapability>() {
/*     */           public ModuleCapability apply(ModuleRevisionBuilder.GenericInfo i) {
/*  63 */             Map<String, String> directives = i.mutable ? (Map)ModuleRevision.copyUnmodifiableMap((Map)i.directives) : i.directives;
/*  64 */             Map<String, Object> attributes = i.mutable ? (Map)ModuleRevision.copyUnmodifiableMap((Map)i.attributes) : i.attributes;
/*  65 */             return new ModuleCapability(i.namespace, directives, attributes, ModuleRevision.this);
/*     */           }
/*  67 */         }NamespaceList.CAPABILITY).build();
/*     */   }
/*     */   
/*     */   private static <K, V> Map<K, V> copyUnmodifiableMap(Map<K, V> map) {
/*  71 */     int size = map.size();
/*  72 */     if (size == 0) {
/*  73 */       return Collections.emptyMap();
/*     */     }
/*  75 */     if (size == 1) {
/*  76 */       Map.Entry<K, V> entry = map.entrySet().iterator().next();
/*  77 */       return Collections.singletonMap(entry.getKey(), entry.getValue());
/*     */     } 
/*  79 */     return Collections.unmodifiableMap(new HashMap<>(map));
/*     */   }
/*     */   
/*     */   private NamespaceList<ModuleRequirement> createRequirements(NamespaceList.Builder<ModuleRevisionBuilder.GenericInfo> infos) {
/*  83 */     return infos.transformIntoCopy(new Function<ModuleRevisionBuilder.GenericInfo, ModuleRequirement>() {
/*     */           public ModuleRequirement apply(ModuleRevisionBuilder.GenericInfo i) {
/*  85 */             return new ModuleRequirement(i.namespace, i.directives, i.attributes, ModuleRevision.this);
/*     */           }
/*  87 */         }NamespaceList.REQUIREMENT).build();
/*     */   }
/*     */ 
/*     */   
/*     */   public Bundle getBundle() {
/*  92 */     return this.revisions.getBundle();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSymbolicName() {
/*  97 */     return this.symbolicName;
/*     */   }
/*     */ 
/*     */   
/*     */   public Version getVersion() {
/* 102 */     return this.version;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<BundleCapability> getDeclaredCapabilities(String namespace) {
/* 107 */     return InternalUtils.asList(getModuleCapabilities(namespace));
/*     */   }
/*     */ 
/*     */   
/*     */   public List<BundleRequirement> getDeclaredRequirements(String namespace) {
/* 112 */     return InternalUtils.asList(getModuleRequirements(namespace));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ModuleCapability> getModuleCapabilities(String namespace) {
/* 122 */     return this.capabilities.getList(namespace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ModuleRequirement> getModuleRequirements(String namespace) {
/* 132 */     return this.requirements.getList(namespace);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTypes() {
/* 137 */     return this.types;
/*     */   }
/*     */ 
/*     */   
/*     */   public ModuleWiring getWiring() {
/* 142 */     return this.revisions.getContainer().getWiring(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Capability> getCapabilities(String namespace) {
/* 147 */     return InternalUtils.asList(getDeclaredCapabilities(namespace));
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Requirement> getRequirements(String namespace) {
/* 152 */     return InternalUtils.asList(getDeclaredRequirements(namespace));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModuleRevisions getRevisions() {
/* 160 */     return this.revisions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getRevisionInfo() {
/* 169 */     return this.revisionInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasLazyActivatePolicy() {
/* 178 */     Boolean currentPolicy = this.lazyActivationPolicy;
/* 179 */     if (currentPolicy != null) {
/* 180 */       return currentPolicy.booleanValue();
/*     */     }
/* 182 */     boolean lazyPolicy = false;
/* 183 */     List<Capability> data = getCapabilities("equinox.module.data");
/* 184 */     if (!data.isEmpty()) {
/* 185 */       Capability moduleData = data.get(0);
/* 186 */       lazyPolicy = "lazy".equals(moduleData.getAttributes().get("activation.policy"));
/*     */     } 
/* 188 */     this.lazyActivationPolicy = Boolean.valueOf(lazyPolicy);
/* 189 */     return lazyPolicy;
/*     */   }
/*     */   
/*     */   boolean isCurrent() {
/* 193 */     return (!this.revisions.isUninstalled() && equals(this.revisions.getCurrentRevision()));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 198 */     List<ModuleCapability> identities = getModuleCapabilities("osgi.identity");
/* 199 */     if (identities.isEmpty())
/* 200 */       return super.toString(); 
/* 201 */     return ((ModuleCapability)identities.get(0)).toString();
/*     */   }
/*     */   
/*     */   static <V> String toString(Map<String, V> map, boolean directives) {
/* 205 */     return toString(map, directives, false);
/*     */   }
/*     */   
/*     */   static <V> String toString(Map<String, V> map, boolean directives, boolean stringsOnly) {
/* 209 */     if (map.size() == 0)
/* 210 */       return ""; 
/* 211 */     String assignment = directives ? ":=" : "=";
/* 212 */     Set<Map.Entry<String, V>> set = map.entrySet();
/* 213 */     StringBuilder sb = new StringBuilder();
/* 214 */     for (Map.Entry<String, V> entry : set) {
/* 215 */       sb.append("; ");
/* 216 */       String key = entry.getKey();
/* 217 */       Object value = entry.getValue();
/* 218 */       if (value instanceof List) {
/*     */         
/* 220 */         List<Object> list = (List<Object>)value;
/* 221 */         if (list.isEmpty())
/*     */           continue; 
/* 223 */         Object component = list.get(0);
/* 224 */         String className = component.getClass().getName();
/* 225 */         String str1 = className.substring(className.lastIndexOf('.') + 1);
/* 226 */         sb.append(key).append(':').append("List<").append(str1).append(">").append(assignment).append('"');
/* 227 */         for (Object object : list)
/* 228 */           sb.append(object).append(','); 
/* 229 */         sb.setLength(sb.length() - 1);
/* 230 */         sb.append('"'); continue;
/*     */       } 
/* 232 */       String type = "";
/* 233 */       if (!(value instanceof String) && !stringsOnly) {
/* 234 */         String className = value.getClass().getName();
/* 235 */         type = ":" + className.substring(className.lastIndexOf('.') + 1);
/*     */       } 
/* 237 */       sb.append(key).append(type).append(assignment).append('"').append(value).append('"');
/*     */     } 
/*     */     
/* 240 */     return sb.toString();
/*     */   }
/*     */   
/*     */   NamespaceList<ModuleCapability> getCapabilities() {
/* 244 */     return this.capabilities;
/*     */   }
/*     */   
/*     */   NamespaceList<ModuleRequirement> getRequirements() {
/* 248 */     return this.requirements;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\container\ModuleRevision.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */