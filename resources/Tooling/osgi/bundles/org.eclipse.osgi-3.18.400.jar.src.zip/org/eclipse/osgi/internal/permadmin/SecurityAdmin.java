/*     */ package org.eclipse.osgi.internal.permadmin;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.math.BigInteger;
/*     */ import java.net.URL;
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AllPermission;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.security.Principal;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.security.PublicKey;
/*     */ import java.security.SignatureException;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateExpiredException;
/*     */ import java.security.cert.CertificateNotYetValidException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.osgi.internal.framework.EquinoxBundle;
/*     */ import org.eclipse.osgi.storage.PermissionData;
/*     */ import org.osgi.framework.AdminPermission;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleException;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.Version;
/*     */ import org.osgi.service.condpermadmin.ConditionInfo;
/*     */ import org.osgi.service.condpermadmin.ConditionalPermissionAdmin;
/*     */ import org.osgi.service.condpermadmin.ConditionalPermissionInfo;
/*     */ import org.osgi.service.condpermadmin.ConditionalPermissionUpdate;
/*     */ import org.osgi.service.permissionadmin.PermissionAdmin;
/*     */ import org.osgi.service.permissionadmin.PermissionInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SecurityAdmin
/*     */   implements PermissionAdmin, ConditionalPermissionAdmin
/*     */ {
/*     */   private static final PermissionCollection DEFAULT_DEFAULT;
/*     */   private static final String OSGI_BASE_IMPLIED_PERMISSIONS = "implied.permissions";
/*     */   private static final String ADMIN_IMPLIED_ACTIONS = "resource,metadata,class,context";
/*     */   
/*     */   static {
/*  70 */     AllPermission allPerm = new AllPermission();
/*  71 */     DEFAULT_DEFAULT = allPerm.newPermissionCollection();
/*  72 */     if (DEFAULT_DEFAULT != null) {
/*  73 */       DEFAULT_DEFAULT.add(allPerm);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private static final PermissionInfo[] EMPTY_PERM_INFO = new PermissionInfo[0];
/*     */   
/*  83 */   private final PermissionAdminTable permAdminTable = new PermissionAdminTable();
/*     */   
/*     */   private SecurityTable condAdminTable;
/*     */   
/*     */   private PermissionInfoCollection permAdminDefaults;
/*     */   
/*  89 */   private long timeStamp = 0L;
/*     */   
/*  91 */   private long nextID = System.currentTimeMillis();
/*     */   
/*     */   private final PermissionData permissionStorage;
/*  94 */   private final Object lock = new Object();
/*     */   
/*     */   private final PermissionInfo[] impliedPermissionInfos;
/*     */   private final EquinoxSecurityManager supportedSecurityManager;
/*     */   
/*     */   public SecurityAdmin(EquinoxSecurityManager supportedSecurityManager, PermissionData permissionStorage) {
/* 100 */     this.supportedSecurityManager = supportedSecurityManager;
/* 101 */     this.permissionStorage = permissionStorage;
/* 102 */     this.impliedPermissionInfos = 
/* 103 */       getPermissionInfos(getClass().getResource("implied.permissions"));
/* 104 */     String[] encodedDefaultInfos = permissionStorage.getPermissionData(null);
/* 105 */     PermissionInfo[] defaultInfos = getPermissionInfos(encodedDefaultInfos);
/* 106 */     if (defaultInfos != null)
/* 107 */       this.permAdminDefaults = new PermissionInfoCollection(defaultInfos); 
/* 108 */     String[] locations = permissionStorage.getLocations();
/* 109 */     if (locations != null) {
/* 110 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = locations).length, b = 0; b < i; ) { String location = arrayOfString[b];
/* 111 */         String[] encodedLocationInfos = permissionStorage.getPermissionData(location);
/* 112 */         if (encodedLocationInfos != null) {
/* 113 */           PermissionInfo[] locationInfos = getPermissionInfos(encodedLocationInfos);
/* 114 */           this.permAdminTable.setPermissions(location, locationInfos);
/*     */         }  b++; }
/*     */     
/*     */     } 
/* 118 */     String[] encodedCondPermInfos = permissionStorage.getConditionalPermissionInfos();
/* 119 */     if (encodedCondPermInfos == null) {
/* 120 */       this.condAdminTable = new SecurityTable(this, new SecurityRow[0]);
/*     */     } else {
/* 122 */       SecurityRow[] rows = new SecurityRow[encodedCondPermInfos.length];
/*     */       try {
/* 124 */         for (int i = 0; i < rows.length; i++)
/* 125 */           rows[i] = SecurityRow.createSecurityRow(this, encodedCondPermInfos[i]); 
/* 126 */       } catch (IllegalArgumentException illegalArgumentException) {
/*     */ 
/*     */         
/* 129 */         rows = new SecurityRow[0];
/*     */       } 
/* 131 */       this.condAdminTable = new SecurityTable(this, rows);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static PermissionInfo[] getPermissionInfos(String[] encodedInfos) {
/* 136 */     if (encodedInfos == null)
/* 137 */       return null; 
/* 138 */     PermissionInfo[] results = new PermissionInfo[encodedInfos.length];
/* 139 */     for (int i = 0; i < results.length; i++)
/* 140 */       results[i] = new PermissionInfo(encodedInfos[i]); 
/* 141 */     return results;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean checkPermission(Permission permission, BundlePermissions bundlePermissions) {
/*     */     PermissionInfoCollection locationCollection;
/*     */     SecurityTable curCondAdminTable;
/*     */     PermissionInfoCollection curPermAdminDefaults;
/* 150 */     synchronized (this.lock) {
/*     */       
/* 152 */       Bundle bundle = bundlePermissions.getBundle();
/* 153 */       locationCollection = (bundle instanceof EquinoxBundle) ? 
/* 154 */         this.permAdminTable.getCollection(((EquinoxBundle)bundle).getModule().getLocation()) : 
/* 155 */         null;
/* 156 */       curCondAdminTable = this.condAdminTable;
/* 157 */       curPermAdminDefaults = this.permAdminDefaults;
/*     */     } 
/* 159 */     if (locationCollection != null) {
/* 160 */       return locationCollection.implies(bundlePermissions, permission);
/*     */     }
/* 162 */     if (curCondAdminTable.isEmpty()) {
/* 163 */       return (curPermAdminDefaults != null) ? curPermAdminDefaults.implies(permission) : 
/* 164 */         DEFAULT_DEFAULT.implies(permission);
/*     */     }
/* 166 */     int result = curCondAdminTable.evaluate(bundlePermissions, permission);
/* 167 */     if ((result & 0x1) != 0)
/* 168 */       return true; 
/* 169 */     if ((result & 0x2) != 0)
/* 170 */       return false; 
/* 171 */     if ((result & 0x8) != 0)
/* 172 */       return true; 
/* 173 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public PermissionInfo[] getDefaultPermissions() {
/* 178 */     synchronized (this.lock) {
/* 179 */       if (this.permAdminDefaults == null)
/* 180 */         return null; 
/* 181 */       return this.permAdminDefaults.getPermissionInfos();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getLocations() {
/* 187 */     synchronized (this.lock) {
/* 188 */       String[] results = this.permAdminTable.getLocations();
/* 189 */       return (results.length == 0) ? null : results;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public PermissionInfo[] getPermissions(String location) {
/* 195 */     synchronized (this.lock) {
/* 196 */       return this.permAdminTable.getPermissions(location);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDefaultPermissions(PermissionInfo[] permissions) {
/* 202 */     checkAllPermission();
/* 203 */     synchronized (this.lock) {
/* 204 */       if (permissions == null) {
/* 205 */         this.permAdminDefaults = null;
/*     */       } else {
/* 207 */         this.permAdminDefaults = new PermissionInfoCollection(permissions);
/* 208 */       }  this.permissionStorage.setPermissionData(null, getEncodedPermissionInfos(permissions));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void checkAllPermission() {
/* 213 */     SecurityManager sm = System.getSecurityManager();
/* 214 */     if (sm != null)
/* 215 */       sm.checkPermission(new AllPermission()); 
/*     */   }
/*     */   
/*     */   private static String[] getEncodedPermissionInfos(PermissionInfo[] permissions) {
/* 219 */     if (permissions == null)
/* 220 */       return null; 
/* 221 */     String[] encoded = new String[permissions.length];
/* 222 */     for (int i = 0; i < encoded.length; i++)
/* 223 */       encoded[i] = permissions[i].getEncoded(); 
/* 224 */     return encoded;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPermissions(String location, PermissionInfo[] permissions) {
/* 229 */     checkAllPermission();
/* 230 */     synchronized (this.lock) {
/* 231 */       this.permAdminTable.setPermissions(location, permissions);
/* 232 */       this.permissionStorage.setPermissionData(location, getEncodedPermissionInfos(permissions));
/*     */     } 
/*     */   }
/*     */   
/*     */   void delete(SecurityRow securityRow, boolean firstTry) {
/* 237 */     ConditionalPermissionUpdate update = newConditionalPermissionUpdate();
/* 238 */     List<ConditionalPermissionInfo> rows = update.getConditionalPermissionInfos();
/* 239 */     for (Iterator<ConditionalPermissionInfo> iRows = rows.iterator(); iRows.hasNext(); ) {
/* 240 */       ConditionalPermissionInfo info = iRows.next();
/* 241 */       if (securityRow.getName().equals(info.getName())) {
/* 242 */         iRows.remove();
/* 243 */         synchronized (this.lock) {
/* 244 */           if (!update.commit() && 
/* 245 */             firstTry)
/*     */           {
/* 247 */             delete(securityRow, false);
/*     */           }
/*     */         } 
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConditionalPermissionInfo addConditionalPermissionInfo(ConditionInfo[] conds, PermissionInfo[] perms) {
/* 260 */     return setConditionalPermissionInfo(null, conds, perms, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ConditionalPermissionInfo newConditionalPermissionInfo(String name, ConditionInfo[] conditions, PermissionInfo[] permissions, String decision) {
/* 266 */     return new SecurityRowSnapShot(name, conditions, permissions, decision);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionalPermissionInfo newConditionalPermissionInfo(String encoded) {
/* 271 */     return SecurityRow.createSecurityRowSnapShot(encoded);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConditionalPermissionUpdate newConditionalPermissionUpdate() {
/* 276 */     synchronized (this.lock) {
/* 277 */       return new SecurityTableUpdate(this, this.condAdminTable.getRows(), this.timeStamp);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public AccessControlContext getAccessControlContext(String[] signers) {
/* 283 */     return new AccessControlContext(
/* 284 */         new ProtectionDomain[] { createProtectionDomain(createMockBundle(signers), this) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConditionalPermissionInfo getConditionalPermissionInfo(String name) {
/* 292 */     synchronized (this.lock) {
/* 293 */       return this.condAdminTable.getRow(name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<ConditionalPermissionInfo> getConditionalPermissionInfos() {
/* 304 */     synchronized (this.lock) {
/* 305 */       SecurityRow[] rows = this.condAdminTable.getRows();
/* 306 */       List<ConditionalPermissionInfo> vRows = new ArrayList<>(rows.length);
/* 307 */       Collections.addAll(vRows, (ConditionalPermissionInfo[])rows);
/* 308 */       return Collections.enumeration(vRows);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConditionalPermissionInfo setConditionalPermissionInfo(String name, ConditionInfo[] conds, PermissionInfo[] perms) {
/* 318 */     return setConditionalPermissionInfo(name, conds, perms, true);
/*     */   }
/*     */ 
/*     */   
/*     */   private ConditionalPermissionInfo setConditionalPermissionInfo(String name, ConditionInfo[] conds, PermissionInfo[] perms, boolean firstTry) {
/* 323 */     ConditionalPermissionUpdate update = newConditionalPermissionUpdate();
/* 324 */     List<ConditionalPermissionInfo> rows = update.getConditionalPermissionInfos();
/* 325 */     ConditionalPermissionInfo newInfo = newConditionalPermissionInfo(name, conds, perms, 
/* 326 */         "allow");
/* 327 */     int index = -1;
/* 328 */     if (name != null) {
/* 329 */       for (int i = 0; i < rows.size() && index < 0; i++) {
/* 330 */         ConditionalPermissionInfo info = rows.get(i);
/* 331 */         if (name.equals(info.getName())) {
/* 332 */           index = i;
/*     */         }
/*     */       } 
/*     */     }
/* 336 */     if (index < 0) {
/*     */       
/* 338 */       rows.add(0, newInfo);
/* 339 */       index = 0;
/*     */     } else {
/* 341 */       rows.set(index, newInfo);
/*     */     } 
/* 343 */     synchronized (this.lock) {
/* 344 */       if (!update.commit() && 
/* 345 */         firstTry)
/*     */       {
/* 347 */         setConditionalPermissionInfo(name, conds, perms, false);
/*     */       }
/* 349 */       return this.condAdminTable.getRow(index);
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean commit(List<ConditionalPermissionInfo> rows, long updateStamp) {
/* 354 */     checkAllPermission();
/* 355 */     synchronized (this.lock) {
/* 356 */       if (updateStamp != this.timeStamp)
/* 357 */         return false; 
/* 358 */       SecurityRow[] newRows = new SecurityRow[rows.size()];
/* 359 */       Collection<String> names = new ArrayList<>();
/* 360 */       for (int i = 0; i < newRows.length; i++) {
/* 361 */         Object rowObj = rows.get(i);
/* 362 */         if (!(rowObj instanceof ConditionalPermissionInfo))
/* 363 */           throw new IllegalStateException(
/* 364 */               "Invalid type \"" + rowObj.getClass().getName() + "\" at row: " + i); 
/* 365 */         ConditionalPermissionInfo infoBaseRow = (ConditionalPermissionInfo)rowObj;
/* 366 */         String name = infoBaseRow.getName();
/* 367 */         if (name == null)
/* 368 */           name = generateName(); 
/* 369 */         if (names.contains(name))
/* 370 */           throw new IllegalStateException("Duplicate name \"" + name + "\" at row: " + i); 
/* 371 */         names.add(name);
/* 372 */         newRows[i] = new SecurityRow(this, name, infoBaseRow.getConditionInfos(), 
/* 373 */             infoBaseRow.getPermissionInfos(), infoBaseRow.getAccessDecision());
/*     */       } 
/* 375 */       this.condAdminTable = new SecurityTable(this, newRows);
/* 376 */       this.permissionStorage.saveConditionalPermissionInfos(this.condAdminTable.getEncodedRows());
/* 377 */       this.timeStamp++;
/* 378 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String generateName() {
/* 384 */     return "generated_" + Long.toString(this.nextID++);
/*     */   }
/*     */   
/*     */   public ProtectionDomain createProtectionDomain(Bundle bundle) {
/* 388 */     return createProtectionDomain(bundle, this);
/*     */   }
/*     */   
/*     */   private ProtectionDomain createProtectionDomain(Bundle bundle, SecurityAdmin sa) {
/* 392 */     PermissionInfoCollection impliedPermissions = getImpliedPermission(bundle);
/* 393 */     URL permEntry = null;
/*     */     try {
/* 395 */       permEntry = bundle.getEntry("OSGI-INF/permissions.perm");
/* 396 */     } catch (IllegalStateException illegalStateException) {}
/*     */ 
/*     */     
/* 399 */     PermissionInfo[] restrictedInfos = getFileRelativeInfos(getPermissionInfos(permEntry), bundle);
/* 400 */     PermissionInfoCollection restrictedPermissions = (restrictedInfos == null) ? null : 
/* 401 */       new PermissionInfoCollection(restrictedInfos);
/* 402 */     BundlePermissions bundlePermissions = new BundlePermissions(bundle, sa, impliedPermissions, 
/* 403 */         restrictedPermissions);
/* 404 */     return new ProtectionDomain(null, bundlePermissions);
/*     */   }
/*     */   
/*     */   private PermissionInfoCollection getImpliedPermission(Bundle bundle) {
/* 408 */     if (this.impliedPermissionInfos == null) {
/* 409 */       return null;
/*     */     }
/* 411 */     PermissionInfo impliedAdminPermission = new PermissionInfo(AdminPermission.class.getName(), 
/* 412 */         "(id=" + bundle.getBundleId() + ")", "resource,metadata,class,context");
/* 413 */     PermissionInfo[] bundleImpliedInfos = new PermissionInfo[this.impliedPermissionInfos.length + 1];
/* 414 */     System.arraycopy(this.impliedPermissionInfos, 0, bundleImpliedInfos, 0, this.impliedPermissionInfos.length);
/* 415 */     bundleImpliedInfos[this.impliedPermissionInfos.length] = impliedAdminPermission;
/* 416 */     return new PermissionInfoCollection(getFileRelativeInfos(bundleImpliedInfos, bundle));
/*     */   }
/*     */   
/*     */   private PermissionInfo[] getFileRelativeInfos(PermissionInfo[] permissionInfos, Bundle bundle) {
/* 420 */     if (permissionInfos == null)
/* 421 */       return permissionInfos; 
/* 422 */     PermissionInfo[] results = new PermissionInfo[permissionInfos.length];
/* 423 */     for (int i = 0; i < permissionInfos.length; i++) {
/* 424 */       results[i] = permissionInfos[i];
/* 425 */       if (PermissionInfoCollection.FILE_PERMISSION_NAME.equals(permissionInfos[i].getType()) && 
/* 426 */         !"<<ALL FILES>>".equals(permissionInfos[i].getName())) {
/* 427 */         File file = new File(permissionInfos[i].getName());
/* 428 */         if (!file.isAbsolute()) {
/*     */           try {
/* 430 */             File target = bundle.getDataFile(permissionInfos[i].getName());
/* 431 */             if (target != null)
/* 432 */               results[i] = new PermissionInfo(permissionInfos[i].getType(), target.getPath(), 
/* 433 */                   permissionInfos[i].getActions()); 
/* 434 */           } catch (IllegalStateException illegalStateException) {}
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 442 */     return results;
/*     */   }
/*     */   
/*     */   public void clearCaches() {
/*     */     PermissionInfoCollection[] permAdminCollections;
/*     */     SecurityRow[] condAdminRows;
/* 448 */     synchronized (this.lock) {
/* 449 */       permAdminCollections = this.permAdminTable.getCollections();
/* 450 */       condAdminRows = this.condAdminTable.getRows();
/*     */     }  byte b; int i; PermissionInfoCollection[] arrayOfPermissionInfoCollection1;
/* 452 */     for (i = (arrayOfPermissionInfoCollection1 = permAdminCollections).length, b = 0; b < i; ) { PermissionInfoCollection permAdminCollection = arrayOfPermissionInfoCollection1[b];
/* 453 */       permAdminCollection.clearPermissionCache(); b++; }
/*     */      SecurityRow[] arrayOfSecurityRow1;
/* 455 */     for (i = (arrayOfSecurityRow1 = condAdminRows).length, b = 0; b < i; ) { SecurityRow condAdminRow = arrayOfSecurityRow1[b];
/* 456 */       condAdminRow.clearCaches(); b++; }
/*     */     
/* 458 */     this.condAdminTable.clearEvaluationCache();
/*     */   }
/*     */   
/*     */   EquinoxSecurityManager getSupportedSecurityManager() {
/* 462 */     return (this.supportedSecurityManager != null) ? this.supportedSecurityManager : getSupportedSystemSecurityManager();
/*     */   }
/*     */   
/*     */   private static EquinoxSecurityManager getSupportedSystemSecurityManager() {
/*     */     try {
/* 467 */       EquinoxSecurityManager equinoxManager = (EquinoxSecurityManager)System.getSecurityManager();
/* 468 */       return (equinoxManager != null && equinoxManager.inCheckPermission()) ? equinoxManager : null;
/* 469 */     } catch (ClassCastException classCastException) {
/* 470 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static PermissionInfo[] getPermissionInfos(URL resource) {
/* 475 */     if (resource == null)
/* 476 */       return null; 
/* 477 */     PermissionInfo[] info = EMPTY_PERM_INFO;
/* 478 */     List<PermissionInfo> permissions = new ArrayList<>(); try {
/* 479 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 500 */     catch (IOException iOException) {}
/*     */ 
/*     */     
/* 503 */     return info;
/*     */   }
/*     */   
/*     */   private static Bundle createMockBundle(String[] signers) {
/* 507 */     Map<X509Certificate, List<X509Certificate>> signersMap = new HashMap<>(); byte b; int i; String[] arrayOfString;
/* 508 */     for (i = (arrayOfString = signers).length, b = 0; b < i; ) { String signer = arrayOfString[b];
/* 509 */       List<String> chain = parseDNchain(signer);
/* 510 */       List<X509Certificate> signersList = new ArrayList<>();
/* 511 */       Principal subject = null, issuer = null;
/* 512 */       X509Certificate first = null;
/* 513 */       for (Iterator<String> iChain = chain.iterator(); iChain.hasNext(); ) {
/* 514 */         subject = (issuer == null) ? new MockPrincipal(iChain.next()) : issuer;
/* 515 */         issuer = iChain.hasNext() ? new MockPrincipal(iChain.next()) : subject;
/* 516 */         X509Certificate cert = new MockX509Certificate(subject, issuer);
/* 517 */         if (first == null)
/* 518 */           first = cert; 
/* 519 */         signersList.add(cert);
/*     */       } 
/* 521 */       if (subject != issuer)
/* 522 */         signersList.add(new MockX509Certificate(issuer, issuer)); 
/* 523 */       signersMap.put(first, signersList); b++; }
/*     */     
/* 525 */     return new MockBundle(signersMap);
/*     */   }
/*     */   
/*     */   static class MockBundle implements Bundle {
/*     */     private final Map<X509Certificate, List<X509Certificate>> signers;
/*     */     
/*     */     MockBundle(Map<X509Certificate, List<X509Certificate>> signers) {
/* 532 */       this.signers = signers;
/*     */     }
/*     */ 
/*     */     
/*     */     public Enumeration<URL> findEntries(String path, String filePattern, boolean recurse) {
/* 537 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public BundleContext getBundleContext() {
/* 542 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public long getBundleId() {
/* 547 */       return -1L;
/*     */     }
/*     */ 
/*     */     
/*     */     public URL getEntry(String path) {
/* 552 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Enumeration<String> getEntryPaths(String path) {
/* 557 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Dictionary<String, String> getHeaders() {
/* 562 */       return new Hashtable<>();
/*     */     }
/*     */ 
/*     */     
/*     */     public Dictionary<String, String> getHeaders(String locale) {
/* 567 */       return getHeaders();
/*     */     }
/*     */ 
/*     */     
/*     */     public long getLastModified() {
/* 572 */       return 0L;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getLocation() {
/* 577 */       return "";
/*     */     }
/*     */ 
/*     */     
/*     */     public ServiceReference<?>[] getRegisteredServices() {
/* 582 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public URL getResource(String name) {
/* 587 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Enumeration<URL> getResources(String name) throws IOException {
/* 595 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public ServiceReference<?>[] getServicesInUse() {
/* 600 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Map<X509Certificate, List<X509Certificate>> getSignerCertificates(int signersType) {
/* 605 */       return new HashMap<>(this.signers);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getState() {
/* 610 */       return 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getSymbolicName() {
/* 615 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Version getVersion() {
/* 620 */       return Version.emptyVersion;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasPermission(Object permission) {
/* 625 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<?> loadClass(String name) throws ClassNotFoundException {
/* 633 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void start(int options) throws BundleException {
/* 641 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void start() throws BundleException {
/* 649 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void stop(int options) throws BundleException {
/* 657 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void stop() throws BundleException {
/* 665 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void uninstall() throws BundleException {
/* 673 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void update() throws BundleException {
/* 681 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void update(InputStream in) throws BundleException {
/* 689 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(Bundle o) {
/* 694 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public <A> A adapt(Class<A> type) {
/* 699 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */     
/*     */     public File getDataFile(String filename) {
/* 704 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class MockX509Certificate extends X509Certificate {
/*     */     private final Principal subject;
/*     */     private final Principal issuer;
/*     */     
/*     */     MockX509Certificate(Principal subject, Principal issuer) {
/* 713 */       this.subject = subject;
/* 714 */       this.issuer = issuer;
/*     */     }
/*     */ 
/*     */     
/*     */     public Principal getSubjectDN() {
/* 719 */       return this.subject;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 724 */       if (this == obj)
/* 725 */         return true; 
/* 726 */       if (obj instanceof MockX509Certificate)
/* 727 */         return (this.subject.equals(((MockX509Certificate)obj).subject) && 
/* 728 */           this.issuer.equals(((MockX509Certificate)obj).issuer)); 
/* 729 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 734 */       return this.subject.hashCode() + this.issuer.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 739 */       return this.subject.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void checkValidity() throws CertificateExpiredException, CertificateNotYetValidException {
/* 749 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void checkValidity(Date var0) throws CertificateExpiredException, CertificateNotYetValidException {
/* 759 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public int getBasicConstraints() {
/* 764 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Principal getIssuerDN() {
/* 769 */       return this.issuer;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean[] getIssuerUniqueID() {
/* 774 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean[] getKeyUsage() {
/* 779 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Date getNotAfter() {
/* 784 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Date getNotBefore() {
/* 789 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public BigInteger getSerialNumber() {
/* 794 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getSigAlgName() {
/* 799 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getSigAlgOID() {
/* 804 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getSigAlgParams() {
/* 809 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getSignature() {
/* 814 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean[] getSubjectUniqueID() {
/* 819 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public byte[] getTBSCertificate() throws CertificateEncodingException {
/* 827 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public int getVersion() {
/* 832 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public byte[] getEncoded() throws CertificateEncodingException {
/* 840 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public PublicKey getPublicKey() {
/* 845 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void verify(PublicKey var0) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchProviderException, SignatureException, CertificateException {
/* 859 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void verify(PublicKey var0, String var1) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchProviderException, SignatureException, CertificateException {
/* 872 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<String> getCriticalExtensionOIDs() {
/* 877 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public byte[] getExtensionValue(String var0) {
/* 882 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<String> getNonCriticalExtensionOIDs() {
/* 887 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasUnsupportedCriticalExtension() {
/* 892 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class MockPrincipal implements Principal {
/*     */     private final String name;
/*     */     
/*     */     MockPrincipal(String name) {
/* 900 */       this.name = name;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/* 905 */       return this.name;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 910 */       if (this == obj) {
/* 911 */         return true;
/*     */       }
/* 913 */       if (obj instanceof MockPrincipal) {
/* 914 */         return this.name.equals(((MockPrincipal)obj).name);
/*     */       }
/* 916 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 921 */       return this.name.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 926 */       return getName();
/*     */     }
/*     */   }
/*     */   
/*     */   private static List<String> parseDNchain(String dnChain) {
/* 931 */     if (dnChain == null) {
/* 932 */       throw new IllegalArgumentException("The DN chain must not be null.");
/*     */     }
/* 934 */     List<String> parsed = new ArrayList<>();
/* 935 */     int startIndex = 0;
/* 936 */     startIndex = skipSpaces(dnChain, startIndex);
/* 937 */     while (startIndex < dnChain.length()) {
/* 938 */       int endIndex = startIndex;
/* 939 */       boolean inQuote = false;
/* 940 */       while (endIndex < dnChain.length()) {
/* 941 */         char c = dnChain.charAt(endIndex);
/* 942 */         switch (c) {
/*     */           case '"':
/* 944 */             inQuote = !inQuote;
/*     */             break;
/*     */           case '\\':
/* 947 */             endIndex++;
/*     */             break;
/*     */           case ';':
/* 950 */             if (!inQuote)
/*     */               break;  break;
/*     */         } 
/* 953 */         endIndex++;
/*     */       } 
/* 955 */       if (endIndex > dnChain.length()) {
/* 956 */         throw new IllegalArgumentException("unterminated escape");
/*     */       }
/* 958 */       parsed.add(dnChain.substring(startIndex, endIndex));
/* 959 */       startIndex = endIndex + 1;
/* 960 */       startIndex = skipSpaces(dnChain, startIndex);
/*     */     } 
/* 962 */     return parsed;
/*     */   }
/*     */   
/*     */   private static int skipSpaces(String dnChain, int startIndex) {
/* 966 */     while (startIndex < dnChain.length() && dnChain.charAt(startIndex) == ' ') {
/* 967 */       startIndex++;
/*     */     }
/* 969 */     return startIndex;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\permadmin\SecurityAdmin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */