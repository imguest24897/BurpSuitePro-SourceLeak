/*     */ package org.eclipse.osgi.internal.serviceregistry;
/*     */ 
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.eclipse.osgi.internal.debug.Debug;
/*     */ import org.eclipse.osgi.internal.framework.BundleContextImpl;
/*     */ import org.eclipse.osgi.internal.messages.Msg;
/*     */ import org.osgi.framework.ServiceException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrototypeServiceFactoryUse<S>
/*     */   extends ServiceFactoryUse<S>
/*     */ {
/*     */   private final Map<S, AtomicInteger> serviceObjects;
/*     */   
/*     */   PrototypeServiceFactoryUse(BundleContextImpl context, ServiceRegistrationImpl<S> registration) {
/*  49 */     super(context, registration);
/*  50 */     this.serviceObjects = new IdentityHashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   S newServiceObject() {
/*  63 */     assert getLock().isHeldByCurrentThread();
/*  64 */     if (this.debug.DEBUG_SERVICES) {
/*  65 */       Debug.println(String.valueOf('[') + Thread.currentThread().getName() + "] getServiceObject[PSfactory=" + 
/*  66 */           this.registration.getBundle() + "](" + this.context.getBundleImpl() + "," + this.registration + ")");
/*     */     }
/*  68 */     S service = factoryGetService();
/*  69 */     if (service == null) {
/*  70 */       return null;
/*     */     }
/*  72 */     AtomicInteger useCount = this.serviceObjects.get(service);
/*  73 */     if (useCount == null) {
/*  74 */       this.serviceObjects.put(service, new AtomicInteger(1));
/*     */     }
/*  76 */     else if (useCount.getAndIncrement() == Integer.MAX_VALUE) {
/*  77 */       useCount.getAndDecrement();
/*  78 */       throw new ServiceException(Msg.SERVICE_USE_OVERFLOW);
/*     */     } 
/*     */     
/*  81 */     return service;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean releaseServiceObject(S service) {
/*  95 */     assert getLock().isHeldByCurrentThread();
/*  96 */     if (service == null || !this.serviceObjects.containsKey(service)) {
/*  97 */       throw new IllegalArgumentException(Msg.SERVICE_OBJECTS_UNGET_ARGUMENT_EXCEPTION);
/*     */     }
/*  99 */     if (this.debug.DEBUG_SERVICES) {
/* 100 */       Debug.println(
/* 101 */           String.valueOf('[') + Thread.currentThread().getName() + "] ungetService[PSfactory=" + this.registration.getBundle() + 
/* 102 */           "](" + this.context.getBundleImpl() + "," + this.registration + ")");
/*     */     }
/* 104 */     AtomicInteger useCount = this.serviceObjects.get(service);
/* 105 */     if (useCount.decrementAndGet() < 1) {
/* 106 */       this.serviceObjects.remove(service);
/* 107 */       factoryUngetService(service);
/*     */     } 
/* 109 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void release() {
/* 124 */     super.release();
/* 125 */     for (S service : this.serviceObjects.keySet()) {
/* 126 */       if (this.debug.DEBUG_SERVICES) {
/* 127 */         Debug.println(String.valueOf('[') + Thread.currentThread().getName() + "] releaseService[PSfactory=" + 
/* 128 */             this.registration.getBundle() + "](" + this.context.getBundleImpl() + "," + this.registration + ")");
/*     */       }
/* 130 */       factoryUngetService(service);
/*     */     } 
/* 132 */     this.serviceObjects.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isEmpty() {
/* 143 */     return (super.isEmpty() && this.serviceObjects.isEmpty());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\serviceregistry\PrototypeServiceFactoryUse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */