/*    */ package org.eclipse.osgi.internal.framework.legacy;
/*    */ 
/*    */ import org.osgi.framework.Bundle;
/*    */ import org.osgi.framework.startlevel.BundleStartLevel;
/*    */ import org.osgi.framework.startlevel.FrameworkStartLevel;
/*    */ import org.osgi.service.startlevel.StartLevel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StartLevelImpl
/*    */   implements StartLevel
/*    */ {
/*    */   private final FrameworkStartLevel frameworkStartLevel;
/*    */   
/*    */   public StartLevelImpl(FrameworkStartLevel frameworkStartLevel) {
/* 27 */     this.frameworkStartLevel = frameworkStartLevel;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getStartLevel() {
/* 32 */     return this.frameworkStartLevel.getStartLevel();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setStartLevel(int startlevel) {
/* 37 */     this.frameworkStartLevel.setStartLevel(startlevel, new org.osgi.framework.FrameworkListener[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getBundleStartLevel(Bundle bundle) {
/* 42 */     return ((BundleStartLevel)bundle.adapt(BundleStartLevel.class)).getStartLevel();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setBundleStartLevel(Bundle bundle, int startlevel) {
/* 47 */     ((BundleStartLevel)bundle.adapt(BundleStartLevel.class)).setStartLevel(startlevel);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getInitialBundleStartLevel() {
/* 52 */     return this.frameworkStartLevel.getInitialBundleStartLevel();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setInitialBundleStartLevel(int startlevel) {
/* 57 */     this.frameworkStartLevel.setInitialBundleStartLevel(startlevel);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isBundlePersistentlyStarted(Bundle bundle) {
/* 62 */     return ((BundleStartLevel)bundle.adapt(BundleStartLevel.class)).isPersistentlyStarted();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isBundleActivationPolicyUsed(Bundle bundle) {
/* 67 */     return ((BundleStartLevel)bundle.adapt(BundleStartLevel.class)).isActivationPolicyUsed();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\framework\legacy\StartLevelImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */