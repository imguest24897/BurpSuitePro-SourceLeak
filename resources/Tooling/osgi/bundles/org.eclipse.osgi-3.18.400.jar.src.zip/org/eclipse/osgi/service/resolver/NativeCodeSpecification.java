package org.eclipse.osgi.service.resolver;

public interface NativeCodeSpecification extends VersionConstraint {
  NativeCodeDescription[] getPossibleSuppliers();
  
  boolean isOptional();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\service\resolver\NativeCodeSpecification.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */