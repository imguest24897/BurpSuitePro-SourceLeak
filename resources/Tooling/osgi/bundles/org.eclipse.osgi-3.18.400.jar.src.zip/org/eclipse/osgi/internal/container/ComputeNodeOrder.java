/*     */ package org.eclipse.osgi.internal.container;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComputeNodeOrder
/*     */ {
/*     */   private static class Digraph
/*     */   {
/*     */     public static class Vertex
/*     */     {
/*     */       public static final String WHITE = "white";
/*     */       public static final String GREY = "grey";
/*     */       public static final String BLACK = "black";
/*  72 */       public String color = "white";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  78 */       public Vertex predecessor = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int finishTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Object id;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  99 */       public List<Vertex> adjacent = new ArrayList<>(3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Vertex(Object id) {
/* 107 */         this.id = id;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     private List<Vertex> vertexList = new ArrayList<>(100);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     private Map<Object, Vertex> vertexMap = new HashMap<>(100);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int time;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean initialized = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean cycles = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void freeze() {
/* 162 */       if (!this.initialized) {
/* 163 */         this.initialized = true;
/*     */         
/* 165 */         DFS();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void addVertex(Object id) throws IllegalArgumentException {
/* 179 */       if (this.initialized) {
/* 180 */         throw new IllegalArgumentException();
/*     */       }
/* 182 */       Vertex vertex = new Vertex(id);
/* 183 */       Object existing = this.vertexMap.put(id, vertex);
/*     */       
/* 185 */       if (existing != null) {
/* 186 */         throw new IllegalArgumentException();
/*     */       }
/* 188 */       this.vertexList.add(vertex);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void addEdge(Object fromId, Object toId) throws IllegalArgumentException {
/* 204 */       if (this.initialized) {
/* 205 */         throw new IllegalArgumentException();
/*     */       }
/* 207 */       Vertex fromVertex = this.vertexMap.get(fromId);
/* 208 */       Vertex toVertex = this.vertexMap.get(toId);
/*     */       
/* 210 */       if (fromVertex == null || toVertex == null)
/*     */         return; 
/* 212 */       fromVertex.adjacent.add(toVertex);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<Object> idsByDFSFinishTime(boolean increasing) {
/* 228 */       if (!this.initialized) {
/* 229 */         throw new IllegalArgumentException();
/*     */       }
/* 231 */       int len = this.vertexList.size();
/* 232 */       Object[] r = new Object[len];
/* 233 */       for (Vertex vertex : this.vertexList) {
/* 234 */         int f = vertex.finishTime;
/*     */         
/* 236 */         if (increasing) {
/* 237 */           r[f - 1] = vertex.id; continue;
/*     */         } 
/* 239 */         r[len - f] = vertex.id;
/*     */       } 
/*     */       
/* 242 */       return Arrays.asList(r);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean containsCycles() {
/* 253 */       if (!this.initialized) {
/* 254 */         throw new IllegalArgumentException();
/*     */       }
/* 256 */       return this.cycles;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<Object[]> nonTrivialComponents() {
/* 270 */       if (!this.initialized) {
/* 271 */         throw new IllegalArgumentException();
/*     */       }
/*     */ 
/*     */       
/* 275 */       Map<Vertex, List<Object>> components = new HashMap<>();
/* 276 */       for (Vertex vertex : this.vertexList) {
/* 277 */         if (vertex.predecessor != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 282 */           Vertex root = vertex;
/* 283 */           while (root.predecessor != null) {
/* 284 */             root = root.predecessor;
/*     */           }
/* 286 */           List<Object> component = components.get(root);
/* 287 */           if (component == null) {
/* 288 */             component = new ArrayList(2);
/* 289 */             component.add(root.id);
/* 290 */             components.put(root, component);
/*     */           } 
/* 292 */           component.add(vertex.id);
/*     */         } 
/*     */       } 
/* 295 */       List<Object[]> result = new ArrayList(components.size());
/* 296 */       for (List<Object> component : components.values()) {
/* 297 */         if (component.size() > 1) {
/* 298 */           result.add(component.toArray());
/*     */         }
/*     */       } 
/* 301 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void DFS() {
/* 365 */       Integer NEXT_VERTEX_OBJECT = Integer.valueOf(1);
/* 366 */       Integer AFTER_NEXTED_DFS_VISIT_OBJECT = Integer.valueOf(4);
/*     */ 
/*     */ 
/*     */       
/* 370 */       this.time = 0;
/*     */       
/* 372 */       List<Object> stack = new ArrayList(Math.max(1, this.vertexList.size()));
/* 373 */       Iterator<Vertex> allAdjacent = null;
/* 374 */       Vertex vertex = null;
/* 375 */       Iterator<Vertex> allV = this.vertexList.iterator();
/* 376 */       int state = 1; while (true) {
/*     */         Vertex nextVertex; Iterator<Vertex> unchecked;
/* 378 */         switch (state) {
/*     */           
/*     */           case 1:
/* 381 */             if (!allV.hasNext()) {
/*     */               break;
/*     */             }
/*     */             
/* 385 */             nextVertex = allV.next();
/* 386 */             if (nextVertex.color == "white") {
/* 387 */               stack.add(NEXT_VERTEX_OBJECT);
/* 388 */               vertex = nextVertex;
/* 389 */               state = 2;
/*     */               continue;
/*     */             } 
/* 392 */             state = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 2:
/* 398 */             vertex.color = "grey";
/* 399 */             allAdjacent = vertex.adjacent.iterator();
/* 400 */             state = 3;
/*     */ 
/*     */ 
/*     */           
/*     */           case 3:
/* 405 */             if (allAdjacent.hasNext()) {
/* 406 */               Vertex adjVertex = allAdjacent.next();
/* 407 */               if (adjVertex.color == "white") {
/*     */                 
/* 409 */                 adjVertex.predecessor = vertex;
/* 410 */                 stack.add(allAdjacent);
/* 411 */                 stack.add(vertex);
/* 412 */                 stack.add(AFTER_NEXTED_DFS_VISIT_OBJECT);
/* 413 */                 vertex = adjVertex;
/* 414 */                 state = 2;
/*     */                 continue;
/*     */               } 
/* 417 */               if (adjVertex.color == "grey")
/*     */               {
/* 419 */                 this.cycles = true;
/*     */               }
/* 421 */               state = 3;
/*     */               
/*     */               continue;
/*     */             } 
/* 425 */             vertex.color = "black";
/*     */             
/* 427 */             vertex.finishTime = ++this.time;
/* 428 */             state = ((Integer)stack.remove(stack.size() - 1)).intValue();
/*     */ 
/*     */           
/*     */           case 4:
/* 432 */             vertex = (Vertex)stack.remove(stack.size() - 1);
/*     */             
/* 434 */             unchecked = (Iterator<Vertex>)stack.remove(stack.size() - 1);
/* 435 */             allAdjacent = unchecked;
/* 436 */             state = 3;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object[][] computeNodeOrder(Object[] objects, Object[][] references) {
/*     */     Object[][] knots;
/* 473 */     Digraph g1 = new Digraph(); byte b1; int j;
/*     */     Object[] arrayOfObject2;
/* 475 */     for (j = (arrayOfObject2 = objects).length, b1 = 0; b1 < j; ) { Object object = arrayOfObject2[b1];
/* 476 */       g1.addVertex(object); b1++; }
/*     */     
/*     */     Object[][] arrayOfObject1;
/* 479 */     for (j = (arrayOfObject1 = references).length, b1 = 0; b1 < j; ) { Object[] reference = arrayOfObject1[b1];
/*     */ 
/*     */       
/* 482 */       g1.addEdge(reference[1], reference[0]); b1++; }
/*     */     
/* 484 */     g1.freeze();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 489 */     Digraph g2 = new Digraph();
/*     */     
/* 491 */     List<Object> resortedVertexes = g1.idsByDFSFinishTime(false);
/* 492 */     for (Object object : resortedVertexes)
/* 493 */       g2.addVertex(object);  byte b2; int k;
/*     */     Object[][] arrayOfObject3;
/* 495 */     for (k = (arrayOfObject3 = references).length, b2 = 0; b2 < k; ) { Object[] reference = arrayOfObject3[b2];
/* 496 */       g2.addEdge(reference[0], reference[1]); b2++; }
/*     */     
/* 498 */     g2.freeze();
/*     */ 
/*     */ 
/*     */     
/* 502 */     List<Object> sortedProjectList = g2.idsByDFSFinishTime(true);
/* 503 */     Object[] orderedNodes = new Object[sortedProjectList.size()];
/* 504 */     sortedProjectList.toArray(orderedNodes);
/*     */     
/* 506 */     boolean hasCycles = g2.containsCycles();
/* 507 */     if (hasCycles) {
/* 508 */       List<Object[]> knotList = g2.nonTrivialComponents();
/* 509 */       knots = knotList.<Object[]>toArray(new Object[knotList.size()][]);
/*     */     } else {
/* 511 */       knots = new Object[0][];
/*     */     } 
/* 513 */     for (int i = 0; i < orderedNodes.length; i++)
/* 514 */       objects[i] = orderedNodes[i]; 
/* 515 */     return knots;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\container\ComputeNodeOrder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */