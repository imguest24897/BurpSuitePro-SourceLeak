/*     */ package org.eclipse.osgi.internal.cds;
/*     */ 
/*     */ import com.ibm.oti.shared.HelperAlreadyDefinedException;
/*     */ import com.ibm.oti.shared.Shared;
/*     */ import com.ibm.oti.shared.SharedClassHelperFactory;
/*     */ import com.ibm.oti.shared.SharedClassURLHelper;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.osgi.internal.hookregistry.BundleFileWrapperFactoryHook;
/*     */ import org.eclipse.osgi.internal.hookregistry.ClassLoaderHook;
/*     */ import org.eclipse.osgi.internal.hookregistry.HookRegistry;
/*     */ import org.eclipse.osgi.internal.loader.ModuleClassLoader;
/*     */ import org.eclipse.osgi.internal.loader.classpath.ClasspathEntry;
/*     */ import org.eclipse.osgi.internal.loader.classpath.ClasspathManager;
/*     */ import org.eclipse.osgi.internal.loader.classpath.FragmentClasspath;
/*     */ import org.eclipse.osgi.storage.BundleInfo;
/*     */ import org.eclipse.osgi.storage.ContentProvider;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleEntry;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFile;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFileWrapper;
/*     */ import org.eclipse.osgi.storage.bundlefile.BundleFileWrapperChain;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CDSHookImpls
/*     */   extends ClassLoaderHook
/*     */   implements BundleFileWrapperFactoryHook
/*     */ {
/*  47 */   private static SharedClassHelperFactory factory = Shared.getSharedClassHelperFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static CDSBundleFile getCDSBundleFile(BundleFile bundleFile) {
/*  58 */     if (bundleFile instanceof BundleFileWrapperChain) {
/*  59 */       return (CDSBundleFile)((BundleFileWrapperChain)bundleFile).getWrappedType(CDSBundleFile.class);
/*     */     }
/*  61 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void recordClassDefine(String name, Class<?> clazz, byte[] classbytes, ClasspathEntry classpathEntry, BundleEntry entry, ClasspathManager manager) {
/*  70 */     if (clazz == null || !hasMagicClassNumber(classbytes) || getCDSBundleFile(classpathEntry.getBundleFile()) == null) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/*  75 */       byte[] originalClassBytes = entry.getBytes();
/*  76 */       if (originalClassBytes != classbytes)
/*     */       {
/*  78 */         boolean modified = false;
/*  79 */         if (originalClassBytes.length == classbytes.length) {
/*     */           
/*  81 */           modified = !Arrays.equals(classbytes, originalClassBytes);
/*     */         } else {
/*  83 */           modified = true;
/*     */         } 
/*  85 */         if (modified) {
/*     */           return;
/*     */         }
/*     */       }
/*     */     
/*     */     }
/*  91 */     catch (IOException iOException) {
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/*  96 */     CDSBundleFile cdsFile = getCDSBundleFile(classpathEntry.getBundleFile());
/*     */     
/*  98 */     if (cdsFile.getURL() == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 104 */     SharedClassURLHelper urlHelper = cdsFile.getURLHelper();
/* 105 */     if (urlHelper == null) {
/*     */       
/* 107 */       CDSBundleFile hostBundleFile = getCDSBundleFile(manager.getGeneration().getBundleFile());
/* 108 */       if (hostBundleFile != null)
/*     */       {
/* 110 */         urlHelper = hostBundleFile.getURLHelper();
/*     */       }
/*     */       
/* 113 */       if (urlHelper != null) {
/* 114 */         cdsFile.setURLHelper(urlHelper);
/*     */       }
/*     */     } 
/* 117 */     if (urlHelper != null) {
/*     */       
/* 119 */       urlHelper.storeSharedClass(null, cdsFile.getURL(), clazz);
/* 120 */       cdsFile.setPrimed(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean hasMagicClassNumber(byte[] classbytes) {
/* 125 */     if (classbytes == null || classbytes.length < 4) {
/* 126 */       return false;
/*     */     }
/* 128 */     return ((classbytes[0] & 0xCA) == 202 && (classbytes[1] & 0xFE) == 254 && (classbytes[2] & 0xBA) == 186 && (classbytes[3] & 0xBE) == 190);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void classLoaderCreated(ModuleClassLoader classLoader) {
/* 134 */     if (factory == null) {
/*     */       return;
/*     */     }
/*     */     try {
/* 138 */       SharedClassURLHelper urlHelper = factory.getURLHelper((ClassLoader)classLoader);
/* 139 */       boolean minimizeUpdateChecks = urlHelper.setMinimizeUpdateChecks();
/*     */       
/* 141 */       CDSBundleFile hostFile = getCDSBundleFile(classLoader.getClasspathManager().getGeneration().getBundleFile());
/* 142 */       if (hostFile != null) {
/* 143 */         hostFile.setURLHelper(urlHelper);
/* 144 */         if (minimizeUpdateChecks)
/*     */         {
/* 146 */           hostFile.setPrimed(true);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 151 */       ClasspathManager cpManager = classLoader.getClasspathManager(); byte b; int i; ClasspathEntry[] arrayOfClasspathEntry;
/* 152 */       for (i = (arrayOfClasspathEntry = cpManager.getHostClasspathEntries()).length, b = 0; b < i; ) { ClasspathEntry entry = arrayOfClasspathEntry[b];
/* 153 */         CDSBundleFile cdsBundleFile = getCDSBundleFile(entry.getBundleFile());
/* 154 */         if (cdsBundleFile != null) {
/* 155 */           cdsBundleFile.setURLHelper(urlHelper);
/* 156 */           if (minimizeUpdateChecks)
/* 157 */             cdsBundleFile.setPrimed(true); 
/*     */         }  b++; }
/*     */       
/*     */       FragmentClasspath[] arrayOfFragmentClasspath;
/* 161 */       for (i = (arrayOfFragmentClasspath = cpManager.getFragmentClasspaths()).length, b = 0; b < i; ) { FragmentClasspath fragCP = arrayOfFragmentClasspath[b]; byte b1; int j; ClasspathEntry[] arrayOfClasspathEntry1;
/* 162 */         for (j = (arrayOfClasspathEntry1 = fragCP.getEntries()).length, b1 = 0; b1 < j; ) { ClasspathEntry entry = arrayOfClasspathEntry1[b1];
/* 163 */           CDSBundleFile cdsBundleFile = getCDSBundleFile(entry.getBundleFile());
/* 164 */           if (cdsBundleFile != null) {
/* 165 */             cdsBundleFile.setURLHelper(urlHelper);
/* 166 */             if (minimizeUpdateChecks)
/* 167 */               cdsBundleFile.setPrimed(true); 
/*     */           }  b1++; }
/*     */         
/*     */         b++; }
/*     */     
/* 172 */     } catch (HelperAlreadyDefinedException helperAlreadyDefinedException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addClassPathEntry(ArrayList<ClasspathEntry> cpEntries, String cp, ClasspathManager hostmanager, BundleInfo.Generation sourceGeneration) {
/* 180 */     CDSBundleFile hostFile = getCDSBundleFile(hostmanager.getGeneration().getBundleFile());
/* 181 */     CDSBundleFile sourceFile = getCDSBundleFile(sourceGeneration.getBundleFile());
/* 182 */     if (hostFile != sourceFile && hostFile != null && sourceFile != null) {
/*     */ 
/*     */       
/* 185 */       SharedClassURLHelper urlHelper = hostFile.getURLHelper();
/* 186 */       sourceFile.setURLHelper(urlHelper);
/* 187 */       sourceFile.setPrimed(hostFile.getPrimed());
/*     */     } 
/*     */     
/* 190 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public BundleFileWrapper wrapBundleFile(BundleFile bundleFile, BundleInfo.Generation generation, boolean base) {
/*     */     CDSBundleFile newBundleFile;
/* 196 */     if (generation.getContentType() == ContentProvider.Type.CONNECT) {
/* 197 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 201 */     if (!base && generation.getBundleInfo().getBundleId() != 0L) {
/*     */       
/* 203 */       SharedClassURLHelper urlHelper = null;
/* 204 */       BundleFile baseFile = generation.getBundleFile(); CDSBundleFile cDSBundleFile;
/* 205 */       if ((cDSBundleFile = getCDSBundleFile(baseFile)) != null) {
/* 206 */         urlHelper = cDSBundleFile.getURLHelper();
/*     */       }
/* 208 */       newBundleFile = new CDSBundleFile(bundleFile, urlHelper);
/*     */     } else {
/* 210 */       newBundleFile = new CDSBundleFile(bundleFile);
/*     */     } 
/*     */     
/* 213 */     return newBundleFile;
/*     */   }
/*     */ 
/*     */   
/*     */   void registerHooks(HookRegistry hookRegistry) {
/* 218 */     if (!Shared.isSharingEnabled()) {
/*     */       return;
/*     */     }
/* 221 */     hookRegistry.addClassLoaderHook(this);
/* 222 */     hookRegistry.addBundleFileWrapperFactoryHook(this);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\eclipse\osgi\internal\cds\CDSHookImpls.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */