package org.osgi.service.permissionadmin;

import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface PermissionAdmin {
  PermissionInfo[] getPermissions(String paramString);
  
  void setPermissions(String paramString, PermissionInfo[] paramArrayOfPermissionInfo);
  
  String[] getLocations();
  
  PermissionInfo[] getDefaultPermissions();
  
  void setDefaultPermissions(PermissionInfo[] paramArrayOfPermissionInfo);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\permissionadmin\PermissionAdmin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */