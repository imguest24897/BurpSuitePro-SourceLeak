/*     */ package org.osgi.service.condpermadmin;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Dictionary;
/*     */ import java.util.Hashtable;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.Filter;
/*     */ import org.osgi.framework.FrameworkUtil;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BundleLocationCondition
/*     */ {
/*     */   private static final String CONDITION_TYPE = "org.osgi.service.condpermadmin.BundleLocationCondition";
/*     */   
/*     */   public static Condition getCondition(final Bundle bundle, ConditionInfo info) {
/*  64 */     if (!"org.osgi.service.condpermadmin.BundleLocationCondition".equals(info.getType()))
/*  65 */       throw new IllegalArgumentException("ConditionInfo must be of type \"org.osgi.service.condpermadmin.BundleLocationCondition\""); 
/*  66 */     String[] args = info.getArgs();
/*  67 */     if (args.length != 1 && args.length != 2)
/*  68 */       throw new IllegalArgumentException("Illegal number of args: " + args.length); 
/*  69 */     String bundleLocation = AccessController.<String>doPrivileged(new PrivilegedAction<String>()
/*     */         {
/*     */           public String run() {
/*  72 */             return bundle.getLocation();
/*     */           }
/*     */         });
/*  75 */     Filter filter = null;
/*     */     try {
/*  77 */       filter = FrameworkUtil.createFilter("(location=" + escapeLocation(args[0]) + ")");
/*  78 */     } catch (InvalidSyntaxException e) {
/*     */       
/*  80 */       throw new RuntimeException("Invalid filter: " + e.getFilter(), e);
/*     */     } 
/*  82 */     Dictionary<String, String> matchProps = new Hashtable<>(2);
/*  83 */     matchProps.put("location", bundleLocation);
/*  84 */     boolean negate = (args.length == 2) ? "!".equals(args[1]) : false;
/*  85 */     return (negate ^ filter.match(matchProps)) ? Condition.TRUE : Condition.FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String escapeLocation(String value) {
/* 100 */     boolean escaped = false;
/* 101 */     int inlen = value.length();
/* 102 */     int outlen = inlen << 1;
/*     */     
/* 104 */     char[] output = new char[outlen];
/* 105 */     value.getChars(0, inlen, output, inlen);
/*     */     
/* 107 */     int cursor = 0;
/* 108 */     for (int i = inlen; i < outlen; i++) {
/* 109 */       char c = output[i];
/* 110 */       switch (c) {
/*     */         case '\\':
/* 112 */           if (i + 1 < outlen && output[i + 1] == '*')
/*     */             break; 
/*     */         case '(':
/*     */         case ')':
/* 116 */           output[cursor] = '\\';
/* 117 */           cursor++;
/* 118 */           escaped = true;
/*     */           break;
/*     */       } 
/*     */       
/* 122 */       output[cursor] = c;
/* 123 */       cursor++;
/*     */     } 
/*     */     
/* 126 */     return escaped ? new String(output, 0, cursor) : value;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\condpermadmin\BundleLocationCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */