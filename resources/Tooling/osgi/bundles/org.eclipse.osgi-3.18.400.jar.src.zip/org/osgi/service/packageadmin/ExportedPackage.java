package org.osgi.service.packageadmin;

import org.osgi.framework.Bundle;
import org.osgi.framework.Version;

public interface ExportedPackage {
  String getName();
  
  Bundle getExportingBundle();
  
  Bundle[] getImportingBundles();
  
  String getSpecificationVersion();
  
  Version getVersion();
  
  boolean isRemovalPending();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\packageadmin\ExportedPackage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */