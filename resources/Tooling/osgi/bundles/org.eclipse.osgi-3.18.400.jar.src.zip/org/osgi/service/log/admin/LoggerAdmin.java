package org.osgi.service.log.admin;

import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface LoggerAdmin {
  public static final String LOG_SERVICE_ID = "osgi.log.service.id";
  
  LoggerContext getLoggerContext(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\log\admin\LoggerAdmin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */