/*    */ package org.osgi.service.condpermadmin;
/*    */ 
/*    */ import java.util.Dictionary;
/*    */ import org.osgi.annotation.versioning.ConsumerType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConsumerType
/*    */ public interface Condition
/*    */ {
/* 36 */   public static final Condition TRUE = new BooleanCondition(true);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   public static final Condition FALSE = new BooleanCondition(false);
/*    */   
/*    */   boolean isPostponed();
/*    */   
/*    */   boolean isSatisfied();
/*    */   
/*    */   boolean isMutable();
/*    */   
/*    */   boolean isSatisfied(Condition[] paramArrayOfCondition, Dictionary<Object, Object> paramDictionary);
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\condpermadmin\Condition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */