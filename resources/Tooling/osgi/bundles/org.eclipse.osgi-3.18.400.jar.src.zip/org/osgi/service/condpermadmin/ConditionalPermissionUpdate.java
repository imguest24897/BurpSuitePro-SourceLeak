package org.osgi.service.condpermadmin;

import java.util.List;
import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface ConditionalPermissionUpdate {
  List<ConditionalPermissionInfo> getConditionalPermissionInfos();
  
  boolean commit();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\condpermadmin\ConditionalPermissionUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */