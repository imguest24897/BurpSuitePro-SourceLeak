/*     */ package org.osgi.service.url;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.URLStreamHandler;
/*     */ import org.osgi.annotation.versioning.ConsumerType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConsumerType
/*     */ public abstract class AbstractURLStreamHandlerService
/*     */   extends URLStreamHandler
/*     */   implements URLStreamHandlerService
/*     */ {
/*     */   protected volatile URLStreamHandlerSetter realHandler;
/*     */   
/*     */   public abstract URLConnection openConnection(URL paramURL) throws IOException;
/*     */   
/*     */   public void parseURL(URLStreamHandlerSetter realHandler, URL u, String spec, int start, int limit) {
/*  61 */     this.realHandler = realHandler;
/*  62 */     parseURL(u, spec, start, limit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toExternalForm(URL u) {
/*  72 */     return super.toExternalForm(u);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(URL u1, URL u2) {
/*  82 */     return super.equals(u1, u2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDefaultPort() {
/*  92 */     return super.getDefaultPort();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InetAddress getHostAddress(URL u) {
/* 102 */     return super.getHostAddress(u);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode(URL u) {
/* 112 */     return super.hashCode(u);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hostsEqual(URL u1, URL u2) {
/* 122 */     return super.hostsEqual(u1, u2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean sameFile(URL u1, URL u2) {
/* 132 */     return super.sameFile(u1, u2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setURL(URL u, String proto, String host, int port, String file, String ref) {
/* 145 */     this.realHandler.setURL(u, proto, host, port, file, ref);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setURL(URL u, String proto, String host, int port, String auth, String user, String path, String query, String ref) {
/* 157 */     this.realHandler.setURL(u, proto, host, port, auth, user, path, query, ref);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\servic\\url\AbstractURLStreamHandlerService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */