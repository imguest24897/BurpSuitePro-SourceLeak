package org.osgi.service.resolver;

import java.util.List;
import java.util.Map;
import org.osgi.annotation.versioning.ProviderType;
import org.osgi.resource.Requirement;
import org.osgi.resource.Resource;
import org.osgi.resource.Wire;
import org.osgi.resource.Wiring;

@ProviderType
public interface Resolver {
  Map<Resource, List<Wire>> resolve(ResolveContext paramResolveContext) throws ResolutionException;
  
  Map<Resource, List<Wire>> resolveDynamic(ResolveContext paramResolveContext, Wiring paramWiring, Requirement paramRequirement) throws ResolutionException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\resolver\Resolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */