/*     */ package org.osgi.service.resolver;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.osgi.annotation.versioning.ConsumerType;
/*     */ import org.osgi.resource.Capability;
/*     */ import org.osgi.resource.Requirement;
/*     */ import org.osgi.resource.Resource;
/*     */ import org.osgi.resource.Wire;
/*     */ import org.osgi.resource.Wiring;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConsumerType
/*     */ public abstract class ResolveContext
/*     */ {
/*     */   public Collection<Resource> getMandatoryResources() {
/*  84 */     return emptyCollection();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<Resource> getOptionalResources() {
/* 100 */     return emptyCollection();
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> Collection<T> emptyCollection() {
/* 105 */     return Collections.EMPTY_LIST;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract List<Capability> findProviders(Requirement paramRequirement);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int insertHostedCapability(List<Capability> paramList, HostedCapability paramHostedCapability);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isEffective(Requirement paramRequirement);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Map<Resource, Wiring> getWirings();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<Resource> findRelatedResources(Resource resource) {
/* 224 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onCancel(Runnable callback) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Wire> getSubstitutionWires(Wiring wiring) {
/* 292 */     Set<String> exportNames = new HashSet<>();
/*     */ 
/*     */     
/* 295 */     for (Capability cap : wiring.getResource().getCapabilities(null)) {
/* 296 */       if ("osgi.wiring.package".equals(cap.getNamespace())) {
/* 297 */         exportNames.add((String)cap.getAttributes()
/* 298 */             .get("osgi.wiring.package"));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 303 */     for (Wire wire : wiring.getProvidedResourceWires(null)) {
/* 304 */       if ("osgi.wiring.host"
/* 305 */         .equals(wire.getCapability().getNamespace())) {
/* 306 */         Resource fragment = wire.getRequirement().getResource();
/* 307 */         for (Capability cap : fragment.getCapabilities(null)) {
/* 308 */           if ("osgi.wiring.package"
/* 309 */             .equals(cap.getNamespace())) {
/* 310 */             exportNames.add((String)cap.getAttributes()
/* 311 */                 .get("osgi.wiring.package"));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 319 */     List<Wire> substitutionWires = new ArrayList<>();
/* 320 */     for (Wire wire : wiring.getRequiredResourceWires(null)) {
/* 321 */       if ("osgi.wiring.package"
/* 322 */         .equals(wire.getCapability().getNamespace()) && 
/* 323 */         exportNames
/* 324 */         .contains(wire.getCapability().getAttributes().get(
/* 325 */             "osgi.wiring.package"))) {
/* 326 */         substitutionWires.add(wire);
/*     */       }
/*     */     } 
/*     */     
/* 330 */     return substitutionWires;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\resolver\ResolveContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */