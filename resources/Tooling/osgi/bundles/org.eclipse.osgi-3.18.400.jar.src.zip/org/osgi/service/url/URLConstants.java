package org.osgi.service.url;

import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface URLConstants {
  public static final String URL_HANDLER_PROTOCOL = "url.handler.protocol";
  
  public static final String URL_CONTENT_MIMETYPE = "url.content.mimetype";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\servic\\url\URLConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */