/*     */ package org.osgi.service.condpermadmin;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConditionInfo
/*     */ {
/*     */   private final String type;
/*     */   private final String[] args;
/*     */   
/*     */   public ConditionInfo(String type, String[] args) {
/*  65 */     this.type = type;
/*  66 */     this.args = (args != null) ? (String[])args.clone() : new String[0];
/*  67 */     if (type == null) {
/*  68 */       throw new NullPointerException("type is null");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConditionInfo(String encodedCondition) {
/*  83 */     if (encodedCondition == null) {
/*  84 */       throw new NullPointerException("missing encoded condition");
/*     */     }
/*  86 */     if (encodedCondition.length() == 0) {
/*  87 */       throw new IllegalArgumentException("empty encoded condition");
/*     */     }
/*     */     try {
/*  90 */       char[] encoded = encodedCondition.toCharArray();
/*  91 */       int length = encoded.length;
/*  92 */       int pos = 0;
/*     */ 
/*     */       
/*  95 */       while (Character.isWhitespace(encoded[pos])) {
/*  96 */         pos++;
/*     */       }
/*     */ 
/*     */       
/* 100 */       if (encoded[pos] != '[') {
/* 101 */         throw new IllegalArgumentException("expecting open bracket");
/*     */       }
/* 103 */       pos++;
/*     */ 
/*     */       
/* 106 */       while (Character.isWhitespace(encoded[pos])) {
/* 107 */         pos++;
/*     */       }
/*     */ 
/*     */       
/* 111 */       int begin = pos;
/* 112 */       while (!Character.isWhitespace(encoded[pos]) && encoded[pos] != ']') {
/* 113 */         pos++;
/*     */       }
/* 115 */       if (pos == begin || encoded[begin] == '"') {
/* 116 */         throw new IllegalArgumentException("expecting type");
/*     */       }
/* 118 */       this.type = new String(encoded, begin, pos - begin);
/*     */ 
/*     */       
/* 121 */       while (Character.isWhitespace(encoded[pos])) {
/* 122 */         pos++;
/*     */       }
/*     */ 
/*     */       
/* 126 */       List<String> argsList = new ArrayList<>();
/* 127 */       while (encoded[pos] == '"') {
/*     */         
/* 129 */         begin = ++pos;
/* 130 */         while (encoded[pos] != '"') {
/* 131 */           if (encoded[pos] == '\\') {
/* 132 */             pos++;
/*     */           }
/* 134 */           pos++;
/*     */         } 
/* 136 */         argsList.add(unescapeString(encoded, begin, pos));
/* 137 */         pos++;
/*     */         
/* 139 */         if (Character.isWhitespace(encoded[pos]))
/*     */         {
/* 141 */           while (Character.isWhitespace(encoded[pos])) {
/* 142 */             pos++;
/*     */           }
/*     */         }
/*     */       } 
/* 146 */       this.args = argsList.<String>toArray(new String[0]);
/*     */ 
/*     */       
/* 149 */       char c = encoded[pos];
/* 150 */       pos++;
/* 151 */       while (pos < length && Character.isWhitespace(encoded[pos])) {
/* 152 */         pos++;
/*     */       }
/* 154 */       if (c != ']' || pos != length) {
/* 155 */         throw new IllegalArgumentException("expecting close bracket");
/*     */       }
/* 157 */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
/* 158 */       throw new IllegalArgumentException("parsing terminated abruptly");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getEncoded() {
/* 186 */     StringBuilder output = new StringBuilder();
/* 187 */     output.append('[');
/* 188 */     output.append(this.type);
/*     */     
/* 190 */     for (int i = 0; i < this.args.length; i++) {
/* 191 */       output.append(" \"");
/* 192 */       escapeString(this.args[i], output);
/* 193 */       output.append('"');
/*     */     } 
/*     */     
/* 196 */     output.append(']');
/*     */     
/* 198 */     return output.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 210 */     return getEncoded();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getType() {
/* 221 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] getArgs() {
/* 231 */     return (String[])this.args.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 248 */     if (obj == this) {
/* 249 */       return true;
/*     */     }
/*     */     
/* 252 */     if (!(obj instanceof ConditionInfo)) {
/* 253 */       return false;
/*     */     }
/*     */     
/* 256 */     ConditionInfo other = (ConditionInfo)obj;
/*     */     
/* 258 */     if (!this.type.equals(other.type) || this.args.length != other.args.length) {
/* 259 */       return false;
/*     */     }
/* 261 */     for (int i = 0; i < this.args.length; i++) {
/* 262 */       if (!this.args[i].equals(other.args[i]))
/* 263 */         return false; 
/*     */     } 
/* 265 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 275 */     int h = 527 + this.type.hashCode();
/* 276 */     for (int i = 0; i < this.args.length; i++) {
/* 277 */       h = 31 * h + this.args[i].hashCode();
/*     */     }
/* 279 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void escapeString(String str, StringBuilder output) {
/* 287 */     int len = str.length();
/* 288 */     for (int i = 0; i < len; i++) {
/* 289 */       char c = str.charAt(i);
/* 290 */       switch (c) {
/*     */         case '"':
/*     */         case '\\':
/* 293 */           output.append('\\');
/* 294 */           output.append(c);
/*     */           break;
/*     */         case '\r':
/* 297 */           output.append("\\r");
/*     */           break;
/*     */         case '\n':
/* 300 */           output.append("\\n");
/*     */           break;
/*     */         default:
/* 303 */           output.append(c);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String unescapeString(char[] str, int begin, int end) {
/* 313 */     StringBuilder output = new StringBuilder(end - begin);
/* 314 */     for (int i = begin; i < end; i++) {
/* 315 */       char c = str[i];
/*     */       
/* 317 */       i++;
/* 318 */       if (c == '\\' && i < end) {
/* 319 */         c = str[i];
/* 320 */         switch (c) {
/*     */           case '"':
/*     */           case '\\':
/*     */             break;
/*     */           case 'r':
/* 325 */             c = '\r';
/*     */             break;
/*     */           case 'n':
/* 328 */             c = '\n';
/*     */             break;
/*     */           default:
/* 331 */             c = '\\';
/* 332 */             i--;
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/* 337 */       output.append(c);
/*     */     } 
/*     */     
/* 340 */     return output.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\condpermadmin\ConditionInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */