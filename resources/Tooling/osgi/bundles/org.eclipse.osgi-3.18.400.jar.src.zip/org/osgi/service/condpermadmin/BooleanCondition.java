/*     */ package org.osgi.service.condpermadmin;
/*     */ 
/*     */ import java.util.Dictionary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BooleanCondition
/*     */   implements Condition
/*     */ {
/*     */   private final boolean satisfied;
/*     */   
/*     */   BooleanCondition(boolean satisfied) {
/* 118 */     this.satisfied = satisfied;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPostponed() {
/* 123 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSatisfied() {
/* 128 */     return this.satisfied;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMutable() {
/* 133 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSatisfied(Condition[] conds, Dictionary<Object, Object> context) {
/* 138 */     for (int i = 0, length = conds.length; i < length; i++) {
/* 139 */       if (!conds[i].isSatisfied())
/* 140 */         return false; 
/*     */     } 
/* 142 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\condpermadmin\BooleanCondition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */