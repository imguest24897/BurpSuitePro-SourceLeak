package org.osgi.service.condpermadmin;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.service.permissionadmin.PermissionInfo;

@ProviderType
public interface ConditionalPermissionInfo {
  public static final String ALLOW = "allow";
  
  public static final String DENY = "deny";
  
  ConditionInfo[] getConditionInfos();
  
  PermissionInfo[] getPermissionInfos();
  
  void delete();
  
  String getName();
  
  String getAccessDecision();
  
  String getEncoded();
  
  String toString();
  
  boolean equals(Object paramObject);
  
  int hashCode();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\condpermadmin\ConditionalPermissionInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */