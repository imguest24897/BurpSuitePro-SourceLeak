package org.osgi.service.url;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLConnection;
import org.osgi.annotation.versioning.ConsumerType;

@ConsumerType
public interface URLStreamHandlerService {
  URLConnection openConnection(URL paramURL) throws IOException;
  
  void parseURL(URLStreamHandlerSetter paramURLStreamHandlerSetter, URL paramURL, String paramString, int paramInt1, int paramInt2);
  
  String toExternalForm(URL paramURL);
  
  boolean equals(URL paramURL1, URL paramURL2);
  
  int getDefaultPort();
  
  InetAddress getHostAddress(URL paramURL);
  
  int hashCode(URL paramURL);
  
  boolean hostsEqual(URL paramURL1, URL paramURL2);
  
  boolean sameFile(URL paramURL1, URL paramURL2);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\servic\\url\URLStreamHandlerService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */