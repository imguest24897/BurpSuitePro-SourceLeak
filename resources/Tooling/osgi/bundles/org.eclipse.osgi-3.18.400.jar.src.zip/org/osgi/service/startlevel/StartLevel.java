package org.osgi.service.startlevel;

import org.osgi.framework.Bundle;

public interface StartLevel {
  int getStartLevel();
  
  void setStartLevel(int paramInt);
  
  int getBundleStartLevel(Bundle paramBundle);
  
  void setBundleStartLevel(Bundle paramBundle, int paramInt);
  
  int getInitialBundleStartLevel();
  
  void setInitialBundleStartLevel(int paramInt);
  
  boolean isBundlePersistentlyStarted(Bundle paramBundle);
  
  boolean isBundleActivationPolicyUsed(Bundle paramBundle);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\startlevel\StartLevel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */