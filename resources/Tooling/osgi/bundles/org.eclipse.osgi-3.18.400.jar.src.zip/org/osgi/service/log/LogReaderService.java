package org.osgi.service.log;

import java.util.Enumeration;
import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface LogReaderService {
  void addLogListener(LogListener paramLogListener);
  
  void removeLogListener(LogListener paramLogListener);
  
  Enumeration<LogEntry> getLog();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\service\log\LogReaderService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */