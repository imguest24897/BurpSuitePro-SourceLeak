/*     */ package org.osgi.util.tracker;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.osgi.annotation.versioning.ConsumerType;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleEvent;
/*     */ import org.osgi.framework.BundleListener;
/*     */ import org.osgi.framework.SynchronousBundleListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConsumerType
/*     */ public class BundleTracker<T>
/*     */   implements BundleTrackerCustomizer<T>
/*     */ {
/*     */   static final boolean DEBUG = false;
/*     */   protected final BundleContext context;
/*     */   final BundleTrackerCustomizer<T> customizer;
/*     */   private volatile Tracked tracked;
/*     */   final int mask;
/*     */   
/*     */   private Tracked tracked() {
/*  81 */     return this.tracked;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BundleTracker(BundleContext context, int stateMask, BundleTrackerCustomizer<T> customizer) {
/* 110 */     this.context = context;
/* 111 */     this.mask = stateMask;
/* 112 */     this.customizer = (customizer == null) ? this : customizer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() {
/*     */     Tracked t;
/* 132 */     synchronized (this) {
/* 133 */       if (this.tracked != null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 139 */       t = new Tracked();
/* 140 */       synchronized (t) {
/* 141 */         this.context.addBundleListener((BundleListener)t);
/* 142 */         Bundle[] bundles = this.context.getBundles();
/* 143 */         if (bundles != null) {
/* 144 */           int length = bundles.length;
/* 145 */           for (int i = 0; i < length; i++) {
/* 146 */             int state = bundles[i].getState();
/* 147 */             if ((state & this.mask) == 0)
/*     */             {
/* 149 */               bundles[i] = null;
/*     */             }
/*     */           } 
/*     */           
/* 153 */           t.setInitial(bundles);
/*     */         } 
/*     */       } 
/* 156 */       this.tracked = t;
/*     */     } 
/*     */     
/* 159 */     t.trackInitial();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     Bundle[] bundles;
/*     */     Tracked outgoing;
/* 176 */     synchronized (this) {
/* 177 */       outgoing = this.tracked;
/* 178 */       if (outgoing == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 184 */       outgoing.close();
/* 185 */       bundles = getBundles();
/* 186 */       this.tracked = null;
/*     */       try {
/* 188 */         this.context.removeBundleListener((BundleListener)outgoing);
/* 189 */       } catch (IllegalStateException illegalStateException) {}
/*     */     } 
/*     */ 
/*     */     
/* 193 */     if (bundles != null) {
/* 194 */       for (int i = 0; i < bundles.length; i++) {
/* 195 */         outgoing.untrack(bundles[i], null);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T addingBundle(Bundle bundle, BundleEvent event) {
/* 226 */     return (T)bundle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifiedBundle(Bundle bundle, BundleEvent event, T object) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removedBundle(Bundle bundle, BundleEvent event, T object) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bundle[] getBundles() {
/* 284 */     Tracked t = tracked();
/* 285 */     if (t == null) {
/* 286 */       return null;
/*     */     }
/* 288 */     synchronized (t) {
/* 289 */       if (t.isEmpty()) {
/* 290 */         return null;
/*     */       }
/* 292 */       return t.copyKeys(new Bundle[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getObject(Bundle bundle) {
/* 306 */     Tracked t = tracked();
/* 307 */     if (t == null) {
/* 308 */       return null;
/*     */     }
/* 310 */     synchronized (t) {
/* 311 */       return t.getCustomizedObject(bundle);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(Bundle bundle) {
/* 326 */     Tracked t = tracked();
/* 327 */     if (t == null) {
/*     */       return;
/*     */     }
/* 330 */     t.untrack(bundle, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 339 */     Tracked t = tracked();
/* 340 */     if (t == null) {
/* 341 */       return 0;
/*     */     }
/* 343 */     synchronized (t) {
/* 344 */       return t.size();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTrackingCount() {
/* 367 */     Tracked t = tracked();
/* 368 */     if (t == null) {
/* 369 */       return -1;
/*     */     }
/* 371 */     synchronized (t) {
/* 372 */       return t.getTrackingCount();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<Bundle, T> getTracked() {
/* 386 */     Map<Bundle, T> map = new HashMap<>();
/* 387 */     Tracked t = tracked();
/* 388 */     if (t == null) {
/* 389 */       return map;
/*     */     }
/* 391 */     synchronized (t) {
/* 392 */       return (Map<Bundle, T>)t.copyEntries(map);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 404 */     Tracked t = tracked();
/* 405 */     if (t == null) {
/* 406 */       return true;
/*     */     }
/* 408 */     synchronized (t) {
/* 409 */       return t.isEmpty();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class Tracked
/*     */     extends AbstractTracked<Bundle, T, BundleEvent>
/*     */     implements SynchronousBundleListener
/*     */   {
/*     */     public void bundleChanged(BundleEvent event) {
/* 440 */       if (this.closed) {
/*     */         return;
/*     */       }
/* 443 */       Bundle bundle = event.getBundle();
/* 444 */       int state = bundle.getState();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 449 */       if ((state & BundleTracker.this.mask) != 0) {
/* 450 */         track(bundle, event);
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 456 */         untrack(bundle, event);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     T customizerAdding(Bundle item, BundleEvent related) {
/* 475 */       return BundleTracker.this.customizer.addingBundle(item, related);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void customizerModified(Bundle item, BundleEvent related, T object) {
/* 488 */       BundleTracker.this.customizer.modifiedBundle(item, related, object);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void customizerRemoved(Bundle item, BundleEvent related, T object) {
/* 501 */       BundleTracker.this.customizer.removedBundle(item, related, object);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osg\\util\tracker\BundleTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */