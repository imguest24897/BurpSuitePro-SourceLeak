/*     */ package org.osgi.util.tracker;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractTracked<S, T, R>
/*     */ {
/* 106 */   private final Map<S, T> tracked = new HashMap<>();
/* 107 */   private int trackingCount = 0;
/* 108 */   private final List<S> adding = new ArrayList<>(6);
/* 109 */   private final LinkedList<S> initial = new LinkedList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   volatile boolean closed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final boolean DEBUG = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setInitial(Object[] list) {
/* 125 */     if (list == null)
/*     */       return;  byte b; int i;
/*     */     Object[] arrayOfObject;
/* 128 */     for (i = (arrayOfObject = list).length, b = 0; b < i; ) { S item = (S)arrayOfObject[b];
/* 129 */       if (item != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 135 */         this.initial.add(item);
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void trackInitial() {
/*     */     while (true) {
/*     */       S item;
/* 150 */       synchronized (this) {
/* 151 */         if (this.closed || this.initial.size() == 0) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 161 */         item = this.initial.removeFirst();
/* 162 */         if (this.tracked.get(item) != null) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 169 */         if (this.adding.contains(item)) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 178 */         this.adding.add(item);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 183 */       trackAdding(item, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void close() {
/* 195 */     this.closed = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void track(S item, R related) {
/*     */     T object;
/* 206 */     synchronized (this) {
/* 207 */       if (this.closed) {
/*     */         return;
/*     */       }
/* 210 */       object = this.tracked.get(item);
/* 211 */       if (object == null) {
/* 212 */         if (this.adding.contains(item)) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 219 */         this.adding.add(item);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 224 */         modified();
/*     */       } 
/*     */     } 
/*     */     
/* 228 */     if (object == null) {
/* 229 */       trackAdding(item, related);
/*     */     } else {
/*     */       
/* 232 */       customizerModified(item, related, object);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void trackAdding(S item, R related) {
/* 252 */     T object = null;
/* 253 */     boolean becameUntracked = false;
/*     */     
/*     */     try {
/* 256 */       object = customizerAdding(item, related);
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */       
/* 262 */       synchronized (this) {
/* 263 */         if (this.adding.remove(item) && !this.closed) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 268 */           if (object != null) {
/* 269 */             this.tracked.put(item, object);
/* 270 */             modified();
/* 271 */             notifyAll();
/*     */           } 
/*     */         } else {
/* 274 */           becameUntracked = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 281 */     if (becameUntracked && object != null)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 286 */       customizerRemoved(item, related, object);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void untrack(S item, R related) {
/*     */     T object;
/* 302 */     synchronized (this) {
/* 303 */       if (this.initial.remove(item)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 316 */       if (this.adding.remove(item)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 328 */       object = this.tracked.remove(item);
/*     */ 
/*     */ 
/*     */       
/* 332 */       if (object == null) {
/*     */         return;
/*     */       }
/* 335 */       modified();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 341 */     customizerRemoved(item, related, object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int size() {
/* 356 */     return this.tracked.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isEmpty() {
/* 368 */     return this.tracked.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T getCustomizedObject(S item) {
/* 380 */     return this.tracked.get(item);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   S[] copyKeys(Object[] list) {
/* 392 */     return (S[])this.tracked.keySet().toArray(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void modified() {
/* 402 */     this.trackingCount++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getTrackingCount() {
/* 416 */     return this.trackingCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   <M extends Map<? super S, ? super T>> M copyEntries(M map) {
/* 432 */     map.putAll(this.tracked);
/* 433 */     return map;
/*     */   }
/*     */   
/*     */   abstract T customizerAdding(S paramS, R paramR);
/*     */   
/*     */   abstract void customizerModified(S paramS, R paramR, T paramT);
/*     */   
/*     */   abstract void customizerRemoved(S paramS, R paramR, T paramT);
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osg\\util\tracker\AbstractTracked.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */