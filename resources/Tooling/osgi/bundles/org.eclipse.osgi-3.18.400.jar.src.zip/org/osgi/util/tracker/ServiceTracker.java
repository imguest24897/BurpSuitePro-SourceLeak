/*     */ package org.osgi.util.tracker;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Collections;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import org.osgi.annotation.versioning.ConsumerType;
/*     */ import org.osgi.framework.AllServiceListener;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.Filter;
/*     */ import org.osgi.framework.InvalidSyntaxException;
/*     */ import org.osgi.framework.ServiceEvent;
/*     */ import org.osgi.framework.ServiceListener;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConsumerType
/*     */ public class ServiceTracker<S, T>
/*     */   implements ServiceTrackerCustomizer<S, T>
/*     */ {
/*     */   static final boolean DEBUG = false;
/*     */   protected final BundleContext context;
/*     */   protected final Filter filter;
/*     */   final ServiceTrackerCustomizer<S, T> customizer;
/*     */   final String listenerFilter;
/*     */   private final String trackClass;
/*     */   private final ServiceReference<S> trackReference;
/*     */   private volatile Tracked tracked;
/*     */   private volatile ServiceReference<S> cachedReference;
/*     */   private volatile T cachedService;
/*     */   
/*     */   private Tracked tracked() {
/* 108 */     return this.tracked;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceTracker(BundleContext context, ServiceReference<S> reference, ServiceTrackerCustomizer<S, T> customizer) {
/* 144 */     this.context = context;
/* 145 */     this.trackReference = reference;
/* 146 */     this.trackClass = null;
/* 147 */     this.customizer = (customizer == null) ? this : customizer;
/* 148 */     this.listenerFilter = "(service.id=" + reference.getProperty("service.id").toString() + ")";
/*     */     try {
/* 150 */       this.filter = context.createFilter(this.listenerFilter);
/* 151 */     } catch (InvalidSyntaxException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 156 */       IllegalArgumentException iae = new IllegalArgumentException("unexpected InvalidSyntaxException: " + e.getMessage());
/* 157 */       iae.initCause((Throwable)e);
/* 158 */       throw iae;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceTracker(BundleContext context, String clazz, ServiceTrackerCustomizer<S, T> customizer) {
/* 180 */     this.context = context;
/* 181 */     this.trackReference = null;
/* 182 */     this.trackClass = clazz;
/* 183 */     this.customizer = (customizer == null) ? this : customizer;
/*     */     
/* 185 */     this.listenerFilter = "(objectClass=" + clazz.toString() + ")";
/*     */     try {
/* 187 */       this.filter = context.createFilter(this.listenerFilter);
/* 188 */     } catch (InvalidSyntaxException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 193 */       IllegalArgumentException iae = new IllegalArgumentException("unexpected InvalidSyntaxException: " + e.getMessage());
/* 194 */       iae.initCause((Throwable)e);
/* 195 */       throw iae;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceTracker(BundleContext context, Filter filter, ServiceTrackerCustomizer<S, T> customizer) {
/* 217 */     this.context = context;
/* 218 */     this.trackReference = null;
/* 219 */     this.trackClass = null;
/* 220 */     this.listenerFilter = filter.toString();
/* 221 */     this.filter = filter;
/* 222 */     this.customizer = (customizer == null) ? this : customizer;
/* 223 */     if (context == null || filter == null)
/*     */     {
/*     */ 
/*     */       
/* 227 */       throw new NullPointerException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceTracker(BundleContext context, Class<S> clazz, ServiceTrackerCustomizer<S, T> customizer) {
/* 250 */     this(context, clazz.getName(), customizer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open() {
/* 264 */     open(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void open(boolean trackAllServices) {
/*     */     Tracked t;
/* 287 */     synchronized (this) {
/* 288 */       if (this.tracked != null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 294 */       t = trackAllServices ? new AllTracked() : new Tracked();
/* 295 */       synchronized (t) {
/*     */         try {
/* 297 */           this.context.addServiceListener(t, this.listenerFilter);
/* 298 */           ServiceReference[] references = null;
/* 299 */           if (this.trackClass != null) {
/* 300 */             references = (ServiceReference[])getInitialReferences(trackAllServices, this.trackClass, null);
/*     */           }
/* 302 */           else if (this.trackReference != null) {
/* 303 */             if (this.trackReference.getBundle() != null) {
/*     */               
/* 305 */               ServiceReference[] single = { this.trackReference };
/* 306 */               references = single;
/*     */             } 
/*     */           } else {
/* 309 */             references = (ServiceReference[])getInitialReferences(trackAllServices, null, this.listenerFilter);
/*     */           } 
/*     */ 
/*     */           
/* 313 */           t.setInitial((ServiceReference<S>[])references);
/* 314 */         } catch (InvalidSyntaxException e) {
/* 315 */           throw new RuntimeException("unexpected InvalidSyntaxException: " + e.getMessage(), e);
/*     */         } 
/*     */       } 
/* 318 */       this.tracked = t;
/*     */     } 
/*     */     
/* 321 */     t.trackInitial();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ServiceReference<S>[] getInitialReferences(boolean trackAllServices, String className, String filterString) throws InvalidSyntaxException {
/* 339 */     ServiceReference[] result = trackAllServices ? this.context.getAllServiceReferences(className, filterString) : this.context.getServiceReferences(className, filterString);
/* 340 */     return (ServiceReference<S>[])result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     Tracked outgoing;
/*     */     ServiceReference[] references;
/* 357 */     synchronized (this) {
/* 358 */       outgoing = this.tracked;
/* 359 */       if (outgoing == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 365 */       outgoing.close();
/* 366 */       references = (ServiceReference[])getServiceReferences();
/* 367 */       this.tracked = null;
/*     */       try {
/* 369 */         this.context.removeServiceListener(outgoing);
/* 370 */       } catch (IllegalStateException illegalStateException) {}
/*     */     } 
/*     */ 
/*     */     
/* 374 */     modified();
/* 375 */     synchronized (outgoing) {
/* 376 */       outgoing.notifyAll();
/*     */     } 
/* 378 */     if (references != null) {
/* 379 */       for (int i = 0; i < references.length; i++) {
/* 380 */         outgoing.untrack(references[i], null);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T addingService(ServiceReference<S> reference) {
/* 416 */     T result = (T)this.context.getService(reference);
/* 417 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifiedService(ServiceReference<S> reference, T service) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removedService(ServiceReference<S> reference, T service) {
/* 461 */     this.context.ungetService(reference);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T waitForService(long timeout) throws InterruptedException {
/* 487 */     if (timeout < 0L) {
/* 488 */       throw new IllegalArgumentException("timeout value is negative");
/*     */     }
/*     */     
/* 491 */     T object = getService();
/* 492 */     if (object != null) {
/* 493 */       return object;
/*     */     }
/*     */     
/* 496 */     long endTime = (timeout == 0L) ? 0L : (System.currentTimeMillis() + timeout);
/*     */     do {
/* 498 */       Tracked t = tracked();
/* 499 */       if (t == null) {
/* 500 */         return null;
/*     */       }
/* 502 */       synchronized (t) {
/* 503 */         if (t.size() == 0) {
/* 504 */           t.wait(timeout);
/*     */         }
/*     */       } 
/* 507 */       object = getService();
/* 508 */       if (endTime <= 0L)
/* 509 */         continue;  timeout = endTime - System.currentTimeMillis();
/* 510 */       if (timeout <= 0L) {
/*     */         break;
/*     */       }
/*     */     }
/* 514 */     while (object == null);
/* 515 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceReference<S>[] getServiceReferences() {
/* 526 */     Tracked t = tracked();
/* 527 */     if (t == null) {
/* 528 */       return null;
/*     */     }
/* 530 */     synchronized (t) {
/* 531 */       if (t.isEmpty()) {
/* 532 */         return null;
/*     */       }
/*     */       
/* 535 */       ServiceReference[] result = new ServiceReference[0];
/* 536 */       return t.copyKeys((ServiceReference<S>[])result);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServiceReference<S> getServiceReference() {
/* 561 */     ServiceReference<S> reference = this.cachedReference;
/* 562 */     if (reference != null)
/*     */     {
/*     */ 
/*     */       
/* 566 */       return reference;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 571 */     ServiceReference[] references = (ServiceReference[])getServiceReferences();
/* 572 */     int length = (references == null) ? 0 : references.length;
/* 573 */     if (length == 0) {
/* 574 */       return null;
/*     */     }
/* 576 */     int index = 0;
/* 577 */     if (length > 1) {
/* 578 */       int[] rankings = new int[length];
/* 579 */       int count = 0;
/* 580 */       int maxRanking = Integer.MIN_VALUE;
/* 581 */       for (int i = 0; i < length; i++) {
/* 582 */         Object property = references[i].getProperty("service.ranking");
/* 583 */         int ranking = (property instanceof Integer) ? ((Integer)property).intValue() : 0;
/* 584 */         rankings[i] = ranking;
/* 585 */         if (ranking > maxRanking) {
/* 586 */           index = i;
/* 587 */           maxRanking = ranking;
/* 588 */           count = 1;
/*     */         }
/* 590 */         else if (ranking == maxRanking) {
/* 591 */           count++;
/*     */         } 
/*     */       } 
/*     */       
/* 595 */       if (count > 1) {
/* 596 */         long minId = Long.MAX_VALUE;
/* 597 */         for (int j = 0; j < length; j++) {
/* 598 */           if (rankings[j] == maxRanking) {
/* 599 */             long id = ((Long)references[j].getProperty("service.id")).longValue();
/* 600 */             if (id < minId) {
/* 601 */               index = j;
/* 602 */               minId = id;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 608 */     return this.cachedReference = references[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getService(ServiceReference<S> reference) {
/* 621 */     Tracked t = tracked();
/* 622 */     if (t == null) {
/* 623 */       return null;
/*     */     }
/* 625 */     synchronized (t) {
/* 626 */       return t.getCustomizedObject(reference);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getServices() {
/* 644 */     Tracked t = tracked();
/* 645 */     if (t == null) {
/* 646 */       return null;
/*     */     }
/* 648 */     synchronized (t) {
/* 649 */       ServiceReference[] references = (ServiceReference[])getServiceReferences();
/* 650 */       int length = (references == null) ? 0 : references.length;
/* 651 */       if (length == 0) {
/* 652 */         return null;
/*     */       }
/* 654 */       Object[] objects = new Object[length];
/* 655 */       for (int i = 0; i < length; i++) {
/* 656 */         objects[i] = getService(references[i]);
/*     */       }
/* 658 */       return objects;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getService() {
/* 674 */     T service = this.cachedService;
/* 675 */     if (service != null)
/*     */     {
/*     */ 
/*     */       
/* 679 */       return service;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 684 */     ServiceReference<S> reference = getServiceReference();
/* 685 */     if (reference == null) {
/* 686 */       return null;
/*     */     }
/* 688 */     return this.cachedService = getService(reference);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(ServiceReference<S> reference) {
/* 702 */     Tracked t = tracked();
/* 703 */     if (t == null) {
/*     */       return;
/*     */     }
/* 706 */     t.untrack(reference, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 716 */     Tracked t = tracked();
/* 717 */     if (t == null) {
/* 718 */       return 0;
/*     */     }
/* 720 */     synchronized (t) {
/* 721 */       return t.size();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTrackingCount() {
/* 745 */     Tracked t = tracked();
/* 746 */     if (t == null) {
/* 747 */       return -1;
/*     */     }
/* 749 */     synchronized (t) {
/* 750 */       return t.getTrackingCount();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void modified() {
/* 764 */     this.cachedReference = null;
/* 765 */     this.cachedService = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortedMap<ServiceReference<S>, T> getTracked() {
/* 785 */     SortedMap<ServiceReference<S>, T> map = new TreeMap<>(Collections.reverseOrder());
/* 786 */     Tracked t = tracked();
/* 787 */     if (t == null) {
/* 788 */       return map;
/*     */     }
/* 790 */     synchronized (t) {
/* 791 */       return (SortedMap<ServiceReference<S>, T>)t.copyEntries(map);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 803 */     Tracked t = tracked();
/* 804 */     if (t == null) {
/* 805 */       return true;
/*     */     }
/* 807 */     synchronized (t) {
/* 808 */       return t.isEmpty();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T[] getServices(Object[] array) {
/* 834 */     Tracked t = tracked();
/* 835 */     if (t == null) {
/* 836 */       if (array.length > 0) {
/* 837 */         array[0] = null;
/*     */       }
/* 839 */       return (T[])array;
/*     */     } 
/* 841 */     synchronized (t) {
/* 842 */       ServiceReference[] references = (ServiceReference[])getServiceReferences();
/* 843 */       int length = (references == null) ? 0 : references.length;
/* 844 */       if (length == 0) {
/* 845 */         if (array.length > 0) {
/* 846 */           array[0] = null;
/*     */         }
/* 848 */         return (T[])array;
/*     */       } 
/* 850 */       if (length > array.length) {
/*     */         
/* 852 */         Object[] newInstance = (Object[])Array.newInstance(array.getClass().getComponentType(), length);
/* 853 */         array = newInstance;
/*     */       } 
/* 855 */       for (int i = 0; i < length; i++) {
/* 856 */         array[i] = getService(references[i]);
/*     */       }
/* 858 */       if (array.length > length) {
/* 859 */         array[length] = null;
/*     */       }
/* 861 */       return (T[])array;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class Tracked
/*     */     extends AbstractTracked<ServiceReference<S>, T, ServiceEvent>
/*     */     implements ServiceListener
/*     */   {
/*     */     public final void serviceChanged(ServiceEvent event) {
/* 891 */       if (this.closed) {
/*     */         return;
/*     */       }
/*     */       
/* 895 */       ServiceReference<S> reference = event.getServiceReference();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 900 */       switch (event.getType()) {
/*     */         case 1:
/*     */         case 2:
/* 903 */           track(reference, event);
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 4:
/*     */         case 8:
/* 911 */           untrack(reference, event);
/*     */           break;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final void modified() {
/* 928 */       super.modified();
/* 929 */       ServiceTracker.this.modified();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final T customizerAdding(ServiceReference<S> item, ServiceEvent related) {
/* 943 */       return ServiceTracker.this.customizer.addingService(item);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final void customizerModified(ServiceReference<S> item, ServiceEvent related, T object) {
/* 956 */       ServiceTracker.this.customizer.modifiedService(item, object);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final void customizerRemoved(ServiceReference<S> item, ServiceEvent related, T object) {
/* 969 */       ServiceTracker.this.customizer.removedService(item, object);
/*     */     }
/*     */   }
/*     */   
/*     */   private class AllTracked extends Tracked implements AllServiceListener {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osg\\util\tracker\ServiceTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */