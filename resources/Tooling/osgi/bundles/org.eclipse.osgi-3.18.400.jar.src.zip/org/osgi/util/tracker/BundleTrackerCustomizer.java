package org.osgi.util.tracker;

import org.osgi.annotation.versioning.ConsumerType;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleEvent;

@ConsumerType
public interface BundleTrackerCustomizer<T> {
  T addingBundle(Bundle paramBundle, BundleEvent paramBundleEvent);
  
  void modifiedBundle(Bundle paramBundle, BundleEvent paramBundleEvent, T paramT);
  
  void removedBundle(Bundle paramBundle, BundleEvent paramBundleEvent, T paramT);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osg\\util\tracker\BundleTrackerCustomizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */