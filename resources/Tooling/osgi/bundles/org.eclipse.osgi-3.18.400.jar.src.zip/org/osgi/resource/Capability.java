package org.osgi.resource;

import java.util.Map;
import org.osgi.annotation.versioning.ConsumerType;

@ConsumerType
public interface Capability {
  String getNamespace();
  
  Map<String, String> getDirectives();
  
  Map<String, Object> getAttributes();
  
  Resource getResource();
  
  boolean equals(Object paramObject);
  
  int hashCode();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\resource\Capability.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */