package org.osgi.resource.dto;

import org.osgi.dto.DTO;

public class CapabilityRefDTO extends DTO {
  public int capability;
  
  public int resource;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\resource\dto\CapabilityRefDTO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */