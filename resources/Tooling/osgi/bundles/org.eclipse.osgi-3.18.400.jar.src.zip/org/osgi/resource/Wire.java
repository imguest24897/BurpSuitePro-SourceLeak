package org.osgi.resource;

import org.osgi.annotation.versioning.ConsumerType;

@ConsumerType
public interface Wire {
  Capability getCapability();
  
  Requirement getRequirement();
  
  Resource getProvider();
  
  Resource getRequirer();
  
  boolean equals(Object paramObject);
  
  int hashCode();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\resource\Wire.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */