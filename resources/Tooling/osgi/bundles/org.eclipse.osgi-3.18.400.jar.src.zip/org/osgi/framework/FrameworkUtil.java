/*      */ package org.osgi.framework;
/*      */ 
/*      */ import java.security.AccessController;
/*      */ import java.util.AbstractMap;
/*      */ import java.util.AbstractSet;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Dictionary;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.ServiceLoader;
/*      */ import java.util.Set;
/*      */ import javax.security.auth.x500.X500Principal;
/*      */ import org.eclipse.osgi.internal.framework.FilterImpl;
/*      */ import org.osgi.framework.connect.FrameworkUtilHelper;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FrameworkUtil
/*      */ {
/*      */   private static final List<FrameworkUtilHelper> helpers;
/*      */   
/*      */   public static Filter createFilter(String filter) throws InvalidSyntaxException {
/*   83 */     return (Filter)FilterImpl.newInstance(filter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean matchDistinguishedNameChain(String matchPattern, List<String> dnChain) {
/*  196 */     return DNChainMatching.match(matchPattern, dnChain);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Optional<Bundle> getBundle(ClassLoader bundleClassLoader) {
/*  209 */     Objects.requireNonNull(bundleClassLoader);
/*  210 */     return 
/*  211 */       Optional.ofNullable((bundleClassLoader instanceof BundleReference) ? (
/*  212 */         (BundleReference)bundleClassLoader).getBundle() : 
/*  213 */         null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Bundle getBundle(Class<?> classFromBundle) {
/*  227 */     Optional<ClassLoader> cl = 
/*  228 */       Optional.ofNullable(AccessController.<ClassLoader>doPrivileged(() -> paramClass.getClassLoader()));
/*      */ 
/*      */ 
/*      */     
/*  232 */     return cl.<Bundle>flatMap(FrameworkUtil::getBundle)
/*  233 */       .orElseGet(() -> (Bundle)helpers.stream().map(()).filter(Optional::isPresent).map(Optional::get).findFirst().orElse(null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  243 */     List<FrameworkUtilHelper> l = new ArrayList<>();
/*      */     try {
/*  245 */       ServiceLoader<FrameworkUtilHelper> helperLoader = 
/*  246 */         AccessController.<ServiceLoader<FrameworkUtilHelper>>doPrivileged(() -> ServiceLoader.load(FrameworkUtilHelper.class, FrameworkUtilHelper.class.getClassLoader()));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  251 */       helperLoader.forEach(l::add);
/*  252 */     } catch (Throwable error) {
/*      */       
/*      */       try {
/*  255 */         Thread t = Thread.currentThread();
/*  256 */         t.getUncaughtExceptionHandler().uncaughtException(t, error);
/*  257 */       } catch (Throwable throwable) {}
/*      */     } 
/*      */ 
/*      */     
/*  261 */     helpers = Collections.unmodifiableList(l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class DNChainMatching
/*      */   {
/*      */     private static final String MINUS_WILDCARD = "-";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String STAR_WILDCARD = "*";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static boolean rdnmatch(List<?> rdn, List<?> rdnPattern) {
/*  306 */       if (rdn.size() != rdnPattern.size()) {
/*  307 */         return false;
/*      */       }
/*  309 */       for (int i = 0; i < rdn.size(); i++) {
/*  310 */         String rdnNameValue = (String)rdn.get(i);
/*  311 */         String patNameValue = (String)rdnPattern.get(i);
/*  312 */         int rdnNameEnd = rdnNameValue.indexOf('=');
/*  313 */         int patNameEnd = patNameValue.indexOf('=');
/*  314 */         if (rdnNameEnd != patNameEnd || !rdnNameValue.regionMatches(0, patNameValue, 0, rdnNameEnd)) {
/*  315 */           return false;
/*      */         }
/*  317 */         String patValue = patNameValue.substring(patNameEnd);
/*  318 */         String rdnValue = rdnNameValue.substring(rdnNameEnd);
/*  319 */         if (!rdnValue.equals(patValue) && !patValue.equals("=*") && !patValue.equals("=#16012a")) {
/*  320 */           return false;
/*      */         }
/*      */       } 
/*  323 */       return true;
/*      */     }
/*      */     
/*      */     private static boolean dnmatch(List<?> dn, List<?> dnPattern) {
/*  327 */       int dnStart = 0;
/*  328 */       int patStart = 0;
/*  329 */       int patLen = dnPattern.size();
/*  330 */       if (patLen == 0) {
/*  331 */         return false;
/*      */       }
/*  333 */       if (dnPattern.get(0).equals("*")) {
/*  334 */         patStart = 1;
/*  335 */         patLen--;
/*      */       } 
/*  337 */       if (dn.size() < patLen) {
/*  338 */         return false;
/*      */       }
/*  340 */       if (dn.size() > patLen) {
/*  341 */         if (!dnPattern.get(0).equals("*"))
/*      */         {
/*      */           
/*  344 */           return false;
/*      */         }
/*      */ 
/*      */         
/*  348 */         dnStart = dn.size() - patLen;
/*      */       } 
/*      */       
/*  351 */       for (int i = 0; i < patLen; i++) {
/*  352 */         if (!rdnmatch((List)dn.get(i + dnStart), (List)dnPattern.get(i + patStart))) {
/*  353 */           return false;
/*      */         }
/*      */       } 
/*  356 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static List<Object> parseDNchainPattern(String pattern) {
/*  373 */       if (pattern == null) {
/*  374 */         throw new IllegalArgumentException("The pattern must not be null.");
/*      */       }
/*  376 */       List<Object> parsed = new ArrayList();
/*  377 */       int length = pattern.length();
/*  378 */       char c = ';';
/*  379 */       for (int startIndex = skipSpaces(pattern, 0); startIndex < length; ) {
/*  380 */         int cursor = startIndex;
/*  381 */         int endIndex = startIndex;
/*  382 */         for (boolean inQuote = false; cursor < length; cursor++) {
/*  383 */           c = pattern.charAt(cursor);
/*  384 */           switch (c) {
/*      */             case '"':
/*  386 */               inQuote = !inQuote;
/*      */               break;
/*      */             case '\\':
/*  389 */               cursor++;
/*  390 */               if (cursor == length) {
/*  391 */                 throw new IllegalArgumentException("unterminated escape");
/*      */               }
/*      */               break;
/*      */             case ';':
/*  395 */               if (!inQuote) {
/*      */                 break;
/*      */               }
/*      */               break;
/*      */           } 
/*  400 */           if (c != ' ') {
/*  401 */             endIndex = cursor + 1;
/*      */           }
/*      */         } 
/*  404 */         parsed.add(pattern.substring(startIndex, endIndex));
/*  405 */         startIndex = skipSpaces(pattern, cursor + 1);
/*      */       } 
/*  407 */       if (c == ';') {
/*  408 */         throw new IllegalArgumentException("empty pattern");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  413 */       for (int i = 0; i < parsed.size(); i++) {
/*  414 */         String dn = (String)parsed.get(i);
/*  415 */         if (!dn.equals("*") && !dn.equals("-")) {
/*      */ 
/*      */           
/*  418 */           List<Object> rdns = new ArrayList();
/*  419 */           if (dn.charAt(0) == '*') {
/*  420 */             int index = skipSpaces(dn, 1);
/*  421 */             if (dn.charAt(index) != ',') {
/*  422 */               throw new IllegalArgumentException("invalid wildcard prefix");
/*      */             }
/*  424 */             rdns.add("*");
/*  425 */             dn = (new X500Principal(dn.substring(index + 1))).getName("CANONICAL");
/*      */           } else {
/*  427 */             dn = (new X500Principal(dn)).getName("CANONICAL");
/*      */           } 
/*      */           
/*  430 */           parseDN(dn, rdns);
/*  431 */           parsed.set(i, rdns);
/*      */         } 
/*  433 */       }  return parsed;
/*      */     }
/*      */     
/*      */     private static List<Object> parseDNchain(List<String> chain) {
/*  437 */       if (chain == null) {
/*  438 */         throw new IllegalArgumentException("DN chain must not be null.");
/*      */       }
/*  440 */       List<Object> result = new ArrayList(chain.size());
/*      */ 
/*      */       
/*  443 */       for (String dn : chain) {
/*  444 */         dn = (new X500Principal(dn)).getName("CANONICAL");
/*      */         
/*  446 */         List<Object> rdns = new ArrayList();
/*  447 */         parseDN(dn, rdns);
/*  448 */         result.add(rdns);
/*      */       } 
/*  450 */       if (result.size() == 0) {
/*  451 */         throw new IllegalArgumentException("empty DN chain");
/*      */       }
/*  453 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static int skipSpaces(String dnChain, int startIndex) {
/*  461 */       while (startIndex < dnChain.length() && dnChain.charAt(startIndex) == ' ') {
/*  462 */         startIndex++;
/*      */       }
/*  464 */       return startIndex;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static void parseDN(String dn, List<Object> rdn) {
/*  476 */       int startIndex = 0;
/*  477 */       char c = Character.MIN_VALUE;
/*  478 */       List<String> nameValues = new ArrayList<>();
/*  479 */       while (startIndex < dn.length()) {
/*      */         int endIndex;
/*  481 */         for (endIndex = startIndex; endIndex < dn.length(); endIndex++) {
/*  482 */           c = dn.charAt(endIndex);
/*  483 */           if (c == ',' || c == '+') {
/*      */             break;
/*      */           }
/*  486 */           if (c == '\\') {
/*  487 */             endIndex++;
/*      */           }
/*      */         } 
/*  490 */         if (endIndex > dn.length()) {
/*  491 */           throw new IllegalArgumentException("unterminated escape " + dn);
/*      */         }
/*  493 */         nameValues.add(dn.substring(startIndex, endIndex));
/*  494 */         if (c != '+') {
/*  495 */           rdn.add(nameValues);
/*  496 */           if (endIndex != dn.length()) {
/*  497 */             nameValues = new ArrayList<>();
/*      */           } else {
/*  499 */             nameValues = null;
/*      */           } 
/*      */         } 
/*  502 */         startIndex = endIndex + 1;
/*      */       } 
/*  504 */       if (nameValues != null) {
/*  505 */         throw new IllegalArgumentException("improperly terminated DN " + dn);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static int skipWildCards(List<Object> dnChainPattern, int dnChainPatternIndex) {
/*  515 */       for (int i = dnChainPatternIndex; i < dnChainPattern.size(); i++) {
/*  516 */         Object dnPattern = dnChainPattern.get(i);
/*  517 */         if (dnPattern instanceof String) {
/*  518 */           if (!dnPattern.equals("*") && !dnPattern.equals("-")) {
/*  519 */             throw new IllegalArgumentException("expected wildcard in DN pattern");
/*      */           }
/*      */         } else {
/*      */           
/*  523 */           if (dnPattern instanceof List) {
/*      */             break;
/*      */           }
/*      */ 
/*      */           
/*  528 */           throw new IllegalArgumentException("expected String or List in DN Pattern");
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  534 */       return i;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static boolean dnChainMatch(List<Object> dnChain, int dnChainIndex, List<Object> dnChainPattern, int dnChainPatternIndex) throws IllegalArgumentException {
/*  543 */       if (dnChainIndex >= dnChain.size()) {
/*  544 */         return false;
/*      */       }
/*  546 */       if (dnChainPatternIndex >= dnChainPattern.size()) {
/*  547 */         return false;
/*      */       }
/*      */       
/*  550 */       Object dnPattern = dnChainPattern.get(dnChainPatternIndex);
/*  551 */       if (dnPattern instanceof String) {
/*  552 */         if (!dnPattern.equals("*") && !dnPattern.equals("-")) {
/*  553 */           throw new IllegalArgumentException("expected wildcard in DN pattern");
/*      */         }
/*      */ 
/*      */         
/*  557 */         if (dnPattern.equals("-")) {
/*  558 */           dnChainPatternIndex = skipWildCards(dnChainPattern, dnChainPatternIndex);
/*      */         } else {
/*  560 */           dnChainPatternIndex++;
/*      */         } 
/*  562 */         if (dnChainPatternIndex >= dnChainPattern.size())
/*      */         {
/*      */           
/*  565 */           return dnPattern.equals("-") ? true : ((dnChain.size() - 1 == dnChainIndex));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  572 */         if (dnPattern.equals("*"))
/*      */         {
/*  574 */           return !(!dnChainMatch(dnChain, dnChainIndex, dnChainPattern, dnChainPatternIndex) && !dnChainMatch(dnChain, dnChainIndex + 1, dnChainPattern, dnChainPatternIndex));
/*      */         }
/*  576 */         for (int i = dnChainIndex; i < dnChain.size(); i++)
/*      */         {
/*  578 */           if (dnChainMatch(dnChain, i, dnChainPattern, dnChainPatternIndex)) {
/*  579 */             return true;
/*      */           }
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/*  585 */         if (dnPattern instanceof List)
/*      */         {
/*      */           while (true) {
/*      */             
/*  589 */             if (!dnmatch((List)dnChain.get(dnChainIndex), (List)dnPattern)) {
/*  590 */               return false;
/*      */             }
/*      */             
/*  593 */             dnChainIndex++;
/*  594 */             dnChainPatternIndex++;
/*      */             
/*  596 */             if (dnChainIndex >= dnChain.size() && dnChainPatternIndex >= dnChainPattern.size()) {
/*  597 */               return true;
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*  602 */             if (dnChainIndex >= dnChain.size()) {
/*  603 */               dnChainPatternIndex = skipWildCards(dnChainPattern, dnChainPatternIndex);
/*      */ 
/*      */ 
/*      */               
/*  607 */               return (dnChainPatternIndex >= dnChainPattern.size());
/*      */             } 
/*      */ 
/*      */             
/*  611 */             if (dnChainPatternIndex >= dnChainPattern.size()) {
/*  612 */               return false;
/*      */             }
/*      */             
/*  615 */             dnPattern = dnChainPattern.get(dnChainPatternIndex);
/*  616 */             if (dnPattern instanceof String) {
/*  617 */               if (!dnPattern.equals("*") && !dnPattern.equals("-")) {
/*  618 */                 throw new IllegalArgumentException("expected wildcard in DN pattern");
/*      */               }
/*      */ 
/*      */               
/*  622 */               return dnChainMatch(dnChain, dnChainIndex, dnChainPattern, dnChainPatternIndex);
/*      */             } 
/*  624 */             if (!(dnPattern instanceof List)) {
/*  625 */               throw new IllegalArgumentException("expected String or List in DN Pattern");
/*      */             }
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  634 */         throw new IllegalArgumentException("expected String or List in DN Pattern");
/*      */       } 
/*      */ 
/*      */       
/*  638 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static boolean match(String pattern, List<String> dnChain) {
/*      */       List<Object> parsedDNChain;
/*      */       List<Object> parsedDNPattern;
/*      */       try {
/*  678 */         parsedDNChain = parseDNchain(dnChain);
/*  679 */       } catch (RuntimeException e) {
/*  680 */         throw new IllegalArgumentException(
/*  681 */             "Invalid DN chain: " + toString(dnChain), e);
/*      */       } 
/*      */       try {
/*  684 */         parsedDNPattern = parseDNchainPattern(pattern);
/*  685 */       } catch (RuntimeException e) {
/*  686 */         throw new IllegalArgumentException(
/*  687 */             "Invalid match pattern: " + pattern, e);
/*      */       } 
/*  689 */       return dnChainMatch(parsedDNChain, 0, parsedDNPattern, 0);
/*      */     }
/*      */     
/*      */     private static String toString(List<?> dnChain) {
/*  693 */       if (dnChain == null) {
/*  694 */         return null;
/*      */       }
/*  696 */       StringBuilder sb = new StringBuilder();
/*  697 */       for (Iterator<?> iChain = dnChain.iterator(); iChain.hasNext(); ) {
/*  698 */         sb.append(iChain.next());
/*  699 */         if (iChain.hasNext()) {
/*  700 */           sb.append("; ");
/*      */         }
/*      */       } 
/*  703 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Map<K, V> asMap(Dictionary<? extends K, ? extends V> dictionary) {
/*  720 */     if (dictionary instanceof Map) {
/*      */       
/*  722 */       Map<K, V> coerced = (Map)dictionary;
/*  723 */       return coerced;
/*      */     } 
/*  725 */     return new DictionaryAsMap<>(dictionary);
/*      */   }
/*      */   
/*      */   private static class DictionaryAsMap<K, V>
/*      */     extends AbstractMap<K, V> {
/*      */     private final Dictionary<K, V> dict;
/*      */     
/*      */     DictionaryAsMap(Dictionary<? extends K, ? extends V> dict) {
/*  733 */       this.dict = (Dictionary<K, V>)Objects.<Dictionary<? extends K, ? extends V>>requireNonNull(dict);
/*      */     }
/*      */     
/*      */     Iterator<K> keys() {
/*  737 */       List<K> keys = new ArrayList<>(this.dict.size());
/*  738 */       for (Enumeration<K> e = this.dict.keys(); e.hasMoreElements();) {
/*  739 */         keys.add(e.nextElement());
/*      */       }
/*  741 */       return keys.iterator();
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/*  746 */       return this.dict.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/*  751 */       return this.dict.isEmpty();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsKey(Object key) {
/*  756 */       if (key == null) {
/*  757 */         return false;
/*      */       }
/*  759 */       return (this.dict.get(key) != null);
/*      */     }
/*      */ 
/*      */     
/*      */     public V get(Object key) {
/*  764 */       if (key == null) {
/*  765 */         return null;
/*      */       }
/*  767 */       return this.dict.get(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public V put(K key, V value) {
/*  772 */       return this.dict.put(
/*  773 */           Objects.requireNonNull(key, 
/*  774 */             "a Dictionary cannot contain a null key"), 
/*  775 */           Objects.requireNonNull(value, 
/*  776 */             "a Dictionary cannot contain a null value"));
/*      */     }
/*      */ 
/*      */     
/*      */     public V remove(Object key) {
/*  781 */       if (key == null) {
/*  782 */         return null;
/*      */       }
/*  784 */       return this.dict.remove(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public void clear() {
/*  789 */       for (Iterator<K> iter = keys(); iter.hasNext();) {
/*  790 */         this.dict.remove(iter.next());
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public Set<K> keySet() {
/*  796 */       return new KeySet();
/*      */     }
/*      */ 
/*      */     
/*      */     public Set<Map.Entry<K, V>> entrySet() {
/*  801 */       return new EntrySet();
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/*  806 */       return this.dict.toString();
/*      */     }
/*      */     
/*      */     final class KeySet
/*      */       extends AbstractSet<K> {
/*      */       public Iterator<K> iterator() {
/*  812 */         return new FrameworkUtil.DictionaryAsMap.KeyIterator();
/*      */       }
/*      */ 
/*      */       
/*      */       public int size() {
/*  817 */         return FrameworkUtil.DictionaryAsMap.this.size();
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean isEmpty() {
/*  822 */         return FrameworkUtil.DictionaryAsMap.this.isEmpty();
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean contains(Object key) {
/*  827 */         return FrameworkUtil.DictionaryAsMap.this.containsKey(key);
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean remove(Object key) {
/*  832 */         return (FrameworkUtil.DictionaryAsMap.this.remove(key) != null);
/*      */       }
/*      */ 
/*      */       
/*      */       public void clear() {
/*  837 */         FrameworkUtil.DictionaryAsMap.this.clear();
/*      */       }
/*      */     }
/*      */     
/*      */     final class KeyIterator implements Iterator<K> {
/*  842 */       private final Iterator<K> keys = FrameworkUtil.DictionaryAsMap.this.keys();
/*  843 */       private K key = null;
/*      */ 
/*      */       
/*      */       public boolean hasNext() {
/*  847 */         return this.keys.hasNext();
/*      */       }
/*      */ 
/*      */       
/*      */       public K next() {
/*  852 */         return this.key = this.keys.next();
/*      */       }
/*      */ 
/*      */       
/*      */       public void remove() {
/*  857 */         if (this.key == null) {
/*  858 */           throw new IllegalStateException();
/*      */         }
/*  860 */         FrameworkUtil.DictionaryAsMap.this.remove(this.key);
/*  861 */         this.key = null;
/*      */       }
/*      */     }
/*      */     
/*      */     final class EntrySet
/*      */       extends AbstractSet<Map.Entry<K, V>> {
/*      */       public Iterator<Map.Entry<K, V>> iterator() {
/*  868 */         return new FrameworkUtil.DictionaryAsMap.EntryIterator();
/*      */       }
/*      */ 
/*      */       
/*      */       public int size() {
/*  873 */         return FrameworkUtil.DictionaryAsMap.this.size();
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean isEmpty() {
/*  878 */         return FrameworkUtil.DictionaryAsMap.this.isEmpty();
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean contains(Object o) {
/*  883 */         if (o instanceof Map.Entry) {
/*  884 */           Map.Entry<?, ?> e = (Map.Entry<?, ?>)o;
/*  885 */           return containsEntry(e);
/*      */         } 
/*  887 */         return false;
/*      */       }
/*      */       
/*      */       private boolean containsEntry(Map.Entry<?, ?> e) {
/*  891 */         Object key = e.getKey();
/*  892 */         if (key == null) {
/*  893 */           return false;
/*      */         }
/*  895 */         Object value = e.getValue();
/*  896 */         if (value == null) {
/*  897 */           return false;
/*      */         }
/*  899 */         return Objects.equals(FrameworkUtil.DictionaryAsMap.this.get(key), value);
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean remove(Object o) {
/*  904 */         if (o instanceof Map.Entry) {
/*  905 */           Map.Entry<?, ?> e = (Map.Entry<?, ?>)o;
/*  906 */           if (containsEntry(e)) {
/*  907 */             FrameworkUtil.DictionaryAsMap.this.remove(e.getKey());
/*  908 */             return true;
/*      */           } 
/*      */         } 
/*  911 */         return false;
/*      */       }
/*      */ 
/*      */       
/*      */       public void clear() {
/*  916 */         FrameworkUtil.DictionaryAsMap.this.clear();
/*      */       }
/*      */     }
/*      */     
/*      */     final class EntryIterator implements Iterator<Map.Entry<K, V>> {
/*  921 */       private final Iterator<K> keys = FrameworkUtil.DictionaryAsMap.this.keys();
/*  922 */       private K key = null;
/*      */ 
/*      */       
/*      */       public boolean hasNext() {
/*  926 */         return this.keys.hasNext();
/*      */       }
/*      */ 
/*      */       
/*      */       public Map.Entry<K, V> next() {
/*  931 */         return new FrameworkUtil.DictionaryAsMap.Entry(this.key = this.keys.next());
/*      */       }
/*      */ 
/*      */       
/*      */       public void remove() {
/*  936 */         if (this.key == null) {
/*  937 */           throw new IllegalStateException();
/*      */         }
/*  939 */         FrameworkUtil.DictionaryAsMap.this.remove(this.key);
/*  940 */         this.key = null;
/*      */       }
/*      */     }
/*      */     
/*      */     final class Entry extends AbstractMap.SimpleEntry<K, V> {
/*      */       private static final long serialVersionUID = 1L;
/*      */       
/*      */       Entry(K key) {
/*  948 */         super(key, (V)FrameworkUtil.DictionaryAsMap.this.get(key));
/*      */       }
/*      */ 
/*      */       
/*      */       public V setValue(V value) {
/*  953 */         FrameworkUtil.DictionaryAsMap.this.put(getKey(), value);
/*  954 */         return super.setValue(value);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <K, V> Dictionary<K, V> asDictionary(Map<? extends K, ? extends V> map) {
/*  972 */     if (map instanceof Dictionary) {
/*      */       
/*  974 */       Dictionary<K, V> coerced = (Dictionary)map;
/*  975 */       return coerced;
/*      */     } 
/*  977 */     return new MapAsDictionary<>(map);
/*      */   }
/*      */   
/*      */   private static class MapAsDictionary<K, V> extends Dictionary<K, V> {
/*      */     private final Map<K, V> map;
/*      */     
/*      */     MapAsDictionary(Map<? extends K, ? extends V> map) {
/*      */       boolean nullKey, nullValue;
/*  985 */       this.map = (Map<K, V>)Objects.<Map<? extends K, ? extends V>>requireNonNull(map);
/*      */       
/*      */       try {
/*  988 */         nullKey = map.containsKey(null);
/*  989 */       } catch (NullPointerException nullPointerException) {
/*  990 */         nullKey = false;
/*      */       } 
/*  992 */       if (nullKey) {
/*  993 */         throw new NullPointerException(
/*  994 */             "a Dictionary cannot contain a null key");
/*      */       }
/*      */       
/*      */       try {
/*  998 */         nullValue = map.containsValue(null);
/*  999 */       } catch (NullPointerException nullPointerException) {
/* 1000 */         nullValue = false;
/*      */       } 
/* 1002 */       if (nullValue) {
/* 1003 */         throw new NullPointerException(
/* 1004 */             "a Dictionary cannot contain a null value");
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 1010 */       return this.map.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isEmpty() {
/* 1015 */       return this.map.isEmpty();
/*      */     }
/*      */ 
/*      */     
/*      */     public Enumeration<K> keys() {
/* 1020 */       return Collections.enumeration(this.map.keySet());
/*      */     }
/*      */ 
/*      */     
/*      */     public Enumeration<V> elements() {
/* 1025 */       return Collections.enumeration(this.map.values());
/*      */     }
/*      */ 
/*      */     
/*      */     public V get(Object key) {
/* 1030 */       if (key == null) {
/* 1031 */         return null;
/*      */       }
/* 1033 */       return this.map.get(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public V put(K key, V value) {
/* 1038 */       return this.map.put(
/* 1039 */           Objects.requireNonNull(key, 
/* 1040 */             "a Dictionary cannot contain a null key"), 
/* 1041 */           Objects.requireNonNull(value, 
/* 1042 */             "a Dictionary cannot contain a null value"));
/*      */     }
/*      */ 
/*      */     
/*      */     public V remove(Object key) {
/* 1047 */       if (key == null) {
/* 1048 */         return null;
/*      */       }
/* 1050 */       return this.map.remove(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1055 */       return this.map.toString();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\FrameworkUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */