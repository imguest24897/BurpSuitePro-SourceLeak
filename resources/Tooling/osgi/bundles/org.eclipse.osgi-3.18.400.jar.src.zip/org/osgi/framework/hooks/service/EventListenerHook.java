package org.osgi.framework.hooks.service;

import java.util.Collection;
import java.util.Map;
import org.osgi.annotation.versioning.ConsumerType;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceEvent;

@ConsumerType
public interface EventListenerHook {
  void event(ServiceEvent paramServiceEvent, Map<BundleContext, Collection<ListenerHook.ListenerInfo>> paramMap);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\hooks\service\EventListenerHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */