package org.osgi.framework;

import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface BundleReference {
  Bundle getBundle();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\BundleReference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */