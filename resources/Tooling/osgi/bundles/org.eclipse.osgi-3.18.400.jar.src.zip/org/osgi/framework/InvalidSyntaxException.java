/*     */ package org.osgi.framework;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InvalidSyntaxException
/*     */   extends Exception
/*     */ {
/*     */   static final long serialVersionUID = -4295194420816491875L;
/*     */   private final String filter;
/*     */   
/*     */   public InvalidSyntaxException(String msg, String filter) {
/*  52 */     super(message(msg, filter));
/*  53 */     this.filter = filter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InvalidSyntaxException(String msg, String filter, Throwable cause) {
/*  69 */     super(message(msg, filter), cause);
/*  70 */     this.filter = filter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String message(String msg, String filter) {
/*  77 */     if (msg == null || filter == null || msg.indexOf(filter) >= 0) {
/*  78 */       return msg;
/*     */     }
/*  80 */     return String.valueOf(msg) + ": " + filter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFilter() {
/*  93 */     return this.filter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getCause() {
/* 104 */     return super.getCause();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable initCause(Throwable cause) {
/* 120 */     return super.initCause(cause);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\InvalidSyntaxException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */