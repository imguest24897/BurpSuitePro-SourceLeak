/*     */ package org.osgi.framework;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.security.BasicPermission;
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BundlePermission
/*     */   extends BasicPermission
/*     */ {
/*     */   private static final long serialVersionUID = 3257846601685873716L;
/*     */   public static final String PROVIDE = "provide";
/*     */   public static final String REQUIRE = "require";
/*     */   public static final String HOST = "host";
/*     */   public static final String FRAGMENT = "fragment";
/*     */   private static final int ACTION_PROVIDE = 1;
/*     */   private static final int ACTION_REQUIRE = 2;
/*     */   private static final int ACTION_HOST = 4;
/*     */   private static final int ACTION_FRAGMENT = 8;
/*     */   private static final int ACTION_ALL = 15;
/*     */   static final int ACTION_NONE = 0;
/*     */   private transient int action_mask;
/* 106 */   private volatile String actions = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BundlePermission(String symbolicName, String actions) {
/* 125 */     this(symbolicName, parseActions(actions));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BundlePermission(String symbolicName, int mask) {
/* 135 */     super(symbolicName);
/* 136 */     setTransients(mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void setTransients(int mask) {
/* 145 */     if (mask == 0 || (mask & 0xF) != mask) {
/* 146 */       throw new IllegalArgumentException("invalid action string");
/*     */     }
/*     */     
/* 149 */     this.action_mask = mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized int getActionsMask() {
/* 160 */     return this.action_mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int parseActions(String actions) {
/* 170 */     boolean seencomma = false;
/*     */     
/* 172 */     int mask = 0;
/*     */     
/* 174 */     if (actions == null) {
/* 175 */       return mask;
/*     */     }
/*     */     
/* 178 */     char[] a = actions.toCharArray();
/*     */     
/* 180 */     int i = a.length - 1;
/* 181 */     if (i < 0) {
/* 182 */       return mask;
/*     */     }
/* 184 */     while (i != -1) {
/*     */       int matchlen;
/*     */       
/*     */       char c;
/* 188 */       while (i != -1 && ((c = a[i]) == ' ' || c == '\r' || c == '\n' || c == '\f' || c == '\t')) {
/* 189 */         i--;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 194 */       if (i >= 6 && (a[i - 6] == 'p' || a[i - 6] == 'P') && (
/* 195 */         a[i - 5] == 'r' || a[i - 5] == 'R') && (
/* 196 */         a[i - 4] == 'o' || a[i - 4] == 'O') && (
/* 197 */         a[i - 3] == 'v' || a[i - 3] == 'V') && (
/* 198 */         a[i - 2] == 'i' || a[i - 2] == 'I') && (
/* 199 */         a[i - 1] == 'd' || a[i - 1] == 'D') && (
/* 200 */         a[i] == 'e' || a[i] == 'E')) {
/* 201 */         matchlen = 7;
/* 202 */         mask |= 0x3;
/*     */       }
/* 204 */       else if (i >= 6 && (a[i - 6] == 'r' || a[i - 6] == 'R') && (
/* 205 */         a[i - 5] == 'e' || a[i - 5] == 'E') && (
/* 206 */         a[i - 4] == 'q' || a[i - 4] == 'Q') && (
/* 207 */         a[i - 3] == 'u' || a[i - 3] == 'U') && (
/* 208 */         a[i - 2] == 'i' || a[i - 2] == 'I') && (
/* 209 */         a[i - 1] == 'r' || a[i - 1] == 'R') && (
/* 210 */         a[i] == 'e' || a[i] == 'E')) {
/* 211 */         matchlen = 7;
/* 212 */         mask |= 0x2;
/*     */       }
/* 214 */       else if (i >= 3 && (a[i - 3] == 'h' || a[i - 3] == 'H') && (
/* 215 */         a[i - 2] == 'o' || a[i - 2] == 'O') && (
/* 216 */         a[i - 1] == 's' || a[i - 1] == 'S') && (
/* 217 */         a[i] == 't' || a[i] == 'T')) {
/* 218 */         matchlen = 4;
/* 219 */         mask |= 0x4;
/*     */       }
/* 221 */       else if (i >= 7 && (a[i - 7] == 'f' || a[i - 7] == 'F') && (
/* 222 */         a[i - 6] == 'r' || a[i - 6] == 'R') && (
/* 223 */         a[i - 5] == 'a' || a[i - 5] == 'A') && (
/* 224 */         a[i - 4] == 'g' || a[i - 4] == 'G') && (
/* 225 */         a[i - 3] == 'm' || a[i - 3] == 'M') && (
/* 226 */         a[i - 2] == 'e' || a[i - 2] == 'E') && (
/* 227 */         a[i - 1] == 'n' || a[i - 1] == 'N') && (
/* 228 */         a[i] == 't' || a[i] == 'T')) {
/* 229 */         matchlen = 8;
/* 230 */         mask |= 0x8;
/*     */       } else {
/*     */         
/* 233 */         throw new IllegalArgumentException("invalid permission: " + actions);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 238 */       seencomma = false;
/* 239 */       while (i >= matchlen && !seencomma) {
/* 240 */         switch (a[i - matchlen]) {
/*     */           case ',':
/* 242 */             seencomma = true;
/*     */             break;
/*     */           case '\t':
/*     */           case '\n':
/*     */           case '\f':
/*     */           case '\r':
/*     */           case ' ':
/*     */             break;
/*     */           default:
/* 251 */             throw new IllegalArgumentException("invalid permission: " + actions);
/*     */         } 
/* 253 */         i--;
/*     */       } 
/*     */ 
/*     */       
/* 257 */       i -= matchlen;
/*     */     } 
/*     */     
/* 260 */     if (seencomma) {
/* 261 */       throw new IllegalArgumentException("invalid permission: " + actions);
/*     */     }
/*     */     
/* 264 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean implies(Permission p) {
/* 292 */     if (!(p instanceof BundlePermission)) {
/* 293 */       return false;
/*     */     }
/* 295 */     BundlePermission requested = (BundlePermission)p;
/*     */     
/* 297 */     int effective = getActionsMask();
/* 298 */     int desired = requested.getActionsMask();
/* 299 */     return ((effective & desired) == desired && super.implies(requested));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getActions() {
/* 315 */     String result = this.actions;
/* 316 */     if (result == null) {
/* 317 */       StringBuilder sb = new StringBuilder();
/* 318 */       boolean comma = false;
/*     */       
/* 320 */       if ((this.action_mask & 0x1) == 1) {
/* 321 */         sb.append("provide");
/* 322 */         comma = true;
/*     */       } 
/*     */       
/* 325 */       if ((this.action_mask & 0x2) == 2) {
/* 326 */         if (comma)
/* 327 */           sb.append(','); 
/* 328 */         sb.append("require");
/* 329 */         comma = true;
/*     */       } 
/*     */       
/* 332 */       if ((this.action_mask & 0x4) == 4) {
/* 333 */         if (comma)
/* 334 */           sb.append(','); 
/* 335 */         sb.append("host");
/* 336 */         comma = true;
/*     */       } 
/*     */       
/* 339 */       if ((this.action_mask & 0x8) == 8) {
/* 340 */         if (comma)
/* 341 */           sb.append(','); 
/* 342 */         sb.append("fragment");
/*     */       } 
/*     */       
/* 345 */       this.actions = result = sb.toString();
/*     */     } 
/* 347 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionCollection newPermissionCollection() {
/* 358 */     return new BundlePermissionCollection();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 376 */     if (obj == this) {
/* 377 */       return true;
/*     */     }
/*     */     
/* 380 */     if (!(obj instanceof BundlePermission)) {
/* 381 */       return false;
/*     */     }
/*     */     
/* 384 */     BundlePermission bp = (BundlePermission)obj;
/*     */     
/* 386 */     return (getActionsMask() == bp.getActionsMask() && getName().equals(bp.getName()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 396 */     int h = 527 + getName().hashCode();
/* 397 */     h = 31 * h + getActions().hashCode();
/* 398 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void writeObject(ObjectOutputStream s) throws IOException {
/* 409 */     if (this.actions == null)
/* 410 */       getActions(); 
/* 411 */     s.defaultWriteObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void readObject(ObjectInputStream s) throws IOException, ClassNotFoundException {
/* 420 */     s.defaultReadObject();
/* 421 */     setTransients(parseActions(this.actions));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\BundlePermission.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */