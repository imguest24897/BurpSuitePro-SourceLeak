package org.osgi.framework.startlevel.dto;

import org.osgi.dto.DTO;

public class FrameworkStartLevelDTO extends DTO {
  public int startLevel;
  
  public int initialBundleStartLevel;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\startlevel\dto\FrameworkStartLevelDTO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */