/*     */ package org.osgi.framework;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.NotSerializableException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.security.AccessController;
/*     */ import java.security.BasicPermission;
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AdminPermission
/*     */   extends BasicPermission
/*     */ {
/*     */   static final long serialVersionUID = 307051004521261705L;
/*     */   public static final String CLASS = "class";
/*     */   public static final String EXECUTE = "execute";
/*     */   public static final String EXTENSIONLIFECYCLE = "extensionLifecycle";
/*     */   public static final String LIFECYCLE = "lifecycle";
/*     */   public static final String LISTENER = "listener";
/*     */   public static final String METADATA = "metadata";
/*     */   public static final String RESOLVE = "resolve";
/*     */   public static final String RESOURCE = "resource";
/*     */   public static final String STARTLEVEL = "startlevel";
/*     */   public static final String CONTEXT = "context";
/*     */   public static final String WEAVE = "weave";
/*     */   private static final int ACTION_CLASS = 1;
/*     */   private static final int ACTION_EXECUTE = 2;
/*     */   private static final int ACTION_LIFECYCLE = 4;
/*     */   private static final int ACTION_LISTENER = 8;
/*     */   private static final int ACTION_METADATA = 16;
/*     */   private static final int ACTION_RESOLVE = 64;
/*     */   private static final int ACTION_RESOURCE = 128;
/*     */   private static final int ACTION_STARTLEVEL = 256;
/*     */   private static final int ACTION_EXTENSIONLIFECYCLE = 512;
/*     */   private static final int ACTION_CONTEXT = 1024;
/*     */   private static final int ACTION_WEAVE = 2048;
/*     */   private static final int ACTION_ALL = 4063;
/*     */   static final int ACTION_NONE = 0;
/* 194 */   private volatile String actions = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   transient int action_mask;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   transient Filter filter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final transient Bundle bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile transient Map<String, Object> properties;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 223 */   private static final ThreadLocal<Bundle> recurse = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AdminPermission() {
/* 230 */     this((Filter)null, 4063);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AdminPermission(String filter, String actions) {
/* 268 */     this(parseFilter(filter), parseActions(actions));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AdminPermission(Bundle bundle, String actions) {
/* 286 */     super(createName(bundle));
/* 287 */     setTransients(null, parseActions(actions));
/* 288 */     this.bundle = bundle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String createName(Bundle bundle) {
/* 298 */     if (bundle == null) {
/* 299 */       throw new IllegalArgumentException("bundle must not be null");
/*     */     }
/* 301 */     StringBuilder sb = new StringBuilder("(id=");
/* 302 */     sb.append(bundle.getBundleId());
/* 303 */     sb.append(")");
/* 304 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AdminPermission(Filter filter, int mask) {
/* 314 */     super((filter == null) ? "*" : filter.toString());
/* 315 */     setTransients(filter, mask);
/* 316 */     this.bundle = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setTransients(Filter filter, int mask) {
/* 326 */     this.filter = filter;
/* 327 */     if (mask == 0 || (mask & 0xFDF) != mask) {
/* 328 */       throw new IllegalArgumentException("invalid action string");
/*     */     }
/* 330 */     this.action_mask = mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int parseActions(String actions) {
/* 340 */     if (actions == null || actions.equals("*")) {
/* 341 */       return 4063;
/*     */     }
/*     */     
/* 344 */     boolean seencomma = false;
/*     */     
/* 346 */     int mask = 0;
/*     */     
/* 348 */     char[] a = actions.toCharArray();
/*     */     
/* 350 */     int i = a.length - 1;
/* 351 */     if (i < 0) {
/* 352 */       return mask;
/*     */     }
/* 354 */     while (i != -1) {
/*     */       int matchlen;
/*     */       
/*     */       char c;
/* 358 */       while (i != -1 && ((c = a[i]) == ' ' || c == '\r' || c == '\n' || c == '\f' || c == '\t')) {
/* 359 */         i--;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 364 */       if (i >= 4 && (a[i - 4] == 'c' || a[i - 4] == 'C') && (
/* 365 */         a[i - 3] == 'l' || a[i - 3] == 'L') && (
/* 366 */         a[i - 2] == 'a' || a[i - 2] == 'A') && (
/* 367 */         a[i - 1] == 's' || a[i - 1] == 'S') && (
/* 368 */         a[i] == 's' || a[i] == 'S')) {
/* 369 */         matchlen = 5;
/* 370 */         mask |= 0x41;
/*     */       
/*     */       }
/* 373 */       else if (i >= 6 && (a[i - 6] == 'e' || a[i - 6] == 'E') && (
/* 374 */         a[i - 5] == 'x' || a[i - 5] == 'X') && (
/* 375 */         a[i - 4] == 'e' || a[i - 4] == 'E') && (
/* 376 */         a[i - 3] == 'c' || a[i - 3] == 'C') && (
/* 377 */         a[i - 2] == 'u' || a[i - 2] == 'U') && (
/* 378 */         a[i - 1] == 't' || a[i - 1] == 'T') && (
/* 379 */         a[i] == 'e' || a[i] == 'E')) {
/* 380 */         matchlen = 7;
/* 381 */         mask |= 0x42;
/*     */       
/*     */       }
/* 384 */       else if (i >= 17 && (a[i - 17] == 'e' || a[i - 17] == 'E') && (
/* 385 */         a[i - 16] == 'x' || a[i - 16] == 'X') && (
/* 386 */         a[i - 15] == 't' || a[i - 15] == 'T') && (
/* 387 */         a[i - 14] == 'e' || a[i - 14] == 'E') && (
/* 388 */         a[i - 13] == 'n' || a[i - 13] == 'N') && (
/* 389 */         a[i - 12] == 's' || a[i - 12] == 'S') && (
/* 390 */         a[i - 11] == 'i' || a[i - 11] == 'I') && (
/* 391 */         a[i - 10] == 'o' || a[i - 10] == 'O') && (
/* 392 */         a[i - 9] == 'n' || a[i - 9] == 'N') && (
/* 393 */         a[i - 8] == 'l' || a[i - 8] == 'L') && (
/* 394 */         a[i - 7] == 'i' || a[i - 7] == 'I') && (
/* 395 */         a[i - 6] == 'f' || a[i - 6] == 'F') && (
/* 396 */         a[i - 5] == 'e' || a[i - 5] == 'E') && (
/* 397 */         a[i - 4] == 'c' || a[i - 4] == 'C') && (
/* 398 */         a[i - 3] == 'y' || a[i - 3] == 'Y') && (
/* 399 */         a[i - 2] == 'c' || a[i - 2] == 'C') && (
/* 400 */         a[i - 1] == 'l' || a[i - 1] == 'L') && (
/* 401 */         a[i] == 'e' || a[i] == 'E')) {
/* 402 */         matchlen = 18;
/* 403 */         mask |= 0x200;
/*     */       
/*     */       }
/* 406 */       else if (i >= 8 && (a[i - 8] == 'l' || a[i - 8] == 'L') && (
/* 407 */         a[i - 7] == 'i' || a[i - 7] == 'I') && (
/* 408 */         a[i - 6] == 'f' || a[i - 6] == 'F') && (
/* 409 */         a[i - 5] == 'e' || a[i - 5] == 'E') && (
/* 410 */         a[i - 4] == 'c' || a[i - 4] == 'C') && (
/* 411 */         a[i - 3] == 'y' || a[i - 3] == 'Y') && (
/* 412 */         a[i - 2] == 'c' || a[i - 2] == 'C') && (
/* 413 */         a[i - 1] == 'l' || a[i - 1] == 'L') && (
/* 414 */         a[i] == 'e' || a[i] == 'E')) {
/* 415 */         matchlen = 9;
/* 416 */         mask |= 0x4;
/*     */       
/*     */       }
/* 419 */       else if (i >= 7 && (a[i - 7] == 'l' || a[i - 7] == 'L') && (
/* 420 */         a[i - 6] == 'i' || a[i - 6] == 'I') && (
/* 421 */         a[i - 5] == 's' || a[i - 5] == 'S') && (
/* 422 */         a[i - 4] == 't' || a[i - 4] == 'T') && (
/* 423 */         a[i - 3] == 'e' || a[i - 3] == 'E') && (
/* 424 */         a[i - 2] == 'n' || a[i - 2] == 'N') && (
/* 425 */         a[i - 1] == 'e' || a[i - 1] == 'E') && (
/* 426 */         a[i] == 'r' || a[i] == 'R')) {
/* 427 */         matchlen = 8;
/* 428 */         mask |= 0x8;
/*     */       
/*     */       }
/* 431 */       else if (i >= 7 && (
/* 432 */         a[i - 7] == 'm' || a[i - 7] == 'M') && (
/* 433 */         a[i - 6] == 'e' || a[i - 6] == 'E') && (
/* 434 */         a[i - 5] == 't' || a[i - 5] == 'T') && (
/* 435 */         a[i - 4] == 'a' || a[i - 4] == 'A') && (
/* 436 */         a[i - 3] == 'd' || a[i - 3] == 'D') && (
/* 437 */         a[i - 2] == 'a' || a[i - 2] == 'A') && (
/* 438 */         a[i - 1] == 't' || a[i - 1] == 'T') && (
/* 439 */         a[i] == 'a' || a[i] == 'A')) {
/* 440 */         matchlen = 8;
/* 441 */         mask |= 0x10;
/*     */       
/*     */       }
/* 444 */       else if (i >= 6 && (
/* 445 */         a[i - 6] == 'r' || a[i - 6] == 'R') && (
/* 446 */         a[i - 5] == 'e' || a[i - 5] == 'E') && (
/* 447 */         a[i - 4] == 's' || a[i - 4] == 'S') && (
/* 448 */         a[i - 3] == 'o' || a[i - 3] == 'O') && (
/* 449 */         a[i - 2] == 'l' || a[i - 2] == 'L') && (
/* 450 */         a[i - 1] == 'v' || a[i - 1] == 'V') && (
/* 451 */         a[i] == 'e' || a[i] == 'E')) {
/* 452 */         matchlen = 7;
/* 453 */         mask |= 0x40;
/*     */       
/*     */       }
/* 456 */       else if (i >= 7 && (
/* 457 */         a[i - 7] == 'r' || a[i - 7] == 'R') && (
/* 458 */         a[i - 6] == 'e' || a[i - 6] == 'E') && (
/* 459 */         a[i - 5] == 's' || a[i - 5] == 'S') && (
/* 460 */         a[i - 4] == 'o' || a[i - 4] == 'O') && (
/* 461 */         a[i - 3] == 'u' || a[i - 3] == 'U') && (
/* 462 */         a[i - 2] == 'r' || a[i - 2] == 'R') && (
/* 463 */         a[i - 1] == 'c' || a[i - 1] == 'C') && (
/* 464 */         a[i] == 'e' || a[i] == 'E')) {
/* 465 */         matchlen = 8;
/* 466 */         mask |= 0xC0;
/*     */ 
/*     */       
/*     */       }
/* 470 */       else if (i >= 9 && (
/* 471 */         a[i - 9] == 's' || a[i - 9] == 'S') && (
/* 472 */         a[i - 8] == 't' || a[i - 8] == 'T') && (
/* 473 */         a[i - 7] == 'a' || a[i - 7] == 'A') && (
/* 474 */         a[i - 6] == 'r' || a[i - 6] == 'R') && (
/* 475 */         a[i - 5] == 't' || a[i - 5] == 'T') && (
/* 476 */         a[i - 4] == 'l' || a[i - 4] == 'L') && (
/* 477 */         a[i - 3] == 'e' || a[i - 3] == 'E') && (
/* 478 */         a[i - 2] == 'v' || a[i - 2] == 'V') && (
/* 479 */         a[i - 1] == 'e' || a[i - 1] == 'E') && (
/* 480 */         a[i] == 'l' || a[i] == 'L')) {
/* 481 */         matchlen = 10;
/* 482 */         mask |= 0x100;
/*     */       
/*     */       }
/* 485 */       else if (i >= 6 && (
/* 486 */         a[i - 6] == 'c' || a[i - 6] == 'C') && (
/* 487 */         a[i - 5] == 'o' || a[i - 5] == 'O') && (
/* 488 */         a[i - 4] == 'n' || a[i - 4] == 'N') && (
/* 489 */         a[i - 3] == 't' || a[i - 3] == 'T') && (
/* 490 */         a[i - 2] == 'e' || a[i - 2] == 'E') && (
/* 491 */         a[i - 1] == 'x' || a[i - 1] == 'X') && (
/* 492 */         a[i] == 't' || a[i] == 'T')) {
/* 493 */         matchlen = 7;
/* 494 */         mask |= 0x400;
/*     */       
/*     */       }
/* 497 */       else if (i >= 4 && (
/* 498 */         a[i - 4] == 'w' || a[i - 4] == 'W') && (
/* 499 */         a[i - 3] == 'e' || a[i - 3] == 'E') && (
/* 500 */         a[i - 2] == 'a' || a[i - 2] == 'A') && (
/* 501 */         a[i - 1] == 'v' || a[i - 1] == 'V') && (
/* 502 */         a[i] == 'e' || a[i] == 'E')) {
/* 503 */         matchlen = 5;
/* 504 */         mask |= 0x800;
/*     */       
/*     */       }
/* 507 */       else if (i >= 0 && a[i] == '*') {
/* 508 */         matchlen = 1;
/* 509 */         mask |= 0xFDF;
/*     */       }
/*     */       else {
/*     */         
/* 513 */         throw new IllegalArgumentException("invalid permission: " + actions);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 518 */       seencomma = false;
/* 519 */       while (i >= matchlen && !seencomma) {
/* 520 */         switch (a[i - matchlen]) {
/*     */           case ',':
/* 522 */             seencomma = true;
/*     */             break;
/*     */           case '\t':
/*     */           case '\n':
/*     */           case '\f':
/*     */           case '\r':
/*     */           case ' ':
/*     */             break;
/*     */           default:
/* 531 */             throw new IllegalArgumentException("invalid permission: " + actions);
/*     */         } 
/* 533 */         i--;
/*     */       } 
/*     */ 
/*     */       
/* 537 */       i -= matchlen;
/*     */     } 
/*     */     
/* 540 */     if (seencomma) {
/* 541 */       throw new IllegalArgumentException("invalid permission: " + actions);
/*     */     }
/*     */     
/* 544 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Filter parseFilter(String filterString) {
/* 557 */     if (filterString == null) {
/* 558 */       return null;
/*     */     }
/* 560 */     filterString = filterString.trim();
/* 561 */     if (filterString.equals("*")) {
/* 562 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 566 */       return FrameworkUtil.createFilter(filterString);
/* 567 */     } catch (InvalidSyntaxException e) {
/* 568 */       throw new IllegalArgumentException("invalid filter", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean implies(Permission p) {
/* 600 */     if (!(p instanceof AdminPermission)) {
/* 601 */       return false;
/*     */     }
/* 603 */     AdminPermission requested = (AdminPermission)p;
/* 604 */     if (this.bundle != null) {
/* 605 */       return false;
/*     */     }
/*     */     
/* 608 */     if (requested.filter != null) {
/* 609 */       return false;
/*     */     }
/* 611 */     return implies0(requested, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean implies0(AdminPermission requested, int effective) {
/* 627 */     effective |= this.action_mask;
/* 628 */     int desired = requested.action_mask;
/* 629 */     if ((effective & desired) != desired) {
/* 630 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 634 */     Filter f = this.filter;
/* 635 */     if (f == null)
/*     */     {
/* 637 */       return true;
/*     */     }
/*     */     
/* 640 */     if (requested.bundle == null) {
/* 641 */       return false;
/*     */     }
/* 643 */     Map<String, Object> requestedProperties = requested.getProperties();
/* 644 */     if (requestedProperties == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 651 */       return true;
/*     */     }
/* 653 */     return f.matches(requestedProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getActions() {
/* 671 */     String result = this.actions;
/* 672 */     if (result == null) {
/* 673 */       StringBuilder sb = new StringBuilder();
/*     */       
/* 675 */       int mask = this.action_mask;
/* 676 */       if ((mask & 0x1) == 1) {
/* 677 */         sb.append("class");
/* 678 */         sb.append(',');
/*     */       } 
/*     */       
/* 681 */       if ((mask & 0x2) == 2) {
/* 682 */         sb.append("execute");
/* 683 */         sb.append(',');
/*     */       } 
/*     */       
/* 686 */       if ((mask & 0x200) == 512) {
/* 687 */         sb.append("extensionLifecycle");
/* 688 */         sb.append(',');
/*     */       } 
/*     */       
/* 691 */       if ((mask & 0x4) == 4) {
/* 692 */         sb.append("lifecycle");
/* 693 */         sb.append(',');
/*     */       } 
/*     */       
/* 696 */       if ((mask & 0x8) == 8) {
/* 697 */         sb.append("listener");
/* 698 */         sb.append(',');
/*     */       } 
/*     */       
/* 701 */       if ((mask & 0x10) == 16) {
/* 702 */         sb.append("metadata");
/* 703 */         sb.append(',');
/*     */       } 
/*     */       
/* 706 */       if ((mask & 0x40) == 64) {
/* 707 */         sb.append("resolve");
/* 708 */         sb.append(',');
/*     */       } 
/*     */       
/* 711 */       if ((mask & 0x80) == 128) {
/* 712 */         sb.append("resource");
/* 713 */         sb.append(',');
/*     */       } 
/*     */       
/* 716 */       if ((mask & 0x100) == 256) {
/* 717 */         sb.append("startlevel");
/* 718 */         sb.append(',');
/*     */       } 
/*     */       
/* 721 */       if ((mask & 0x400) == 1024) {
/* 722 */         sb.append("context");
/* 723 */         sb.append(',');
/*     */       } 
/*     */       
/* 726 */       if ((mask & 0x800) == 2048) {
/* 727 */         sb.append("weave");
/* 728 */         sb.append(',');
/*     */       } 
/*     */ 
/*     */       
/* 732 */       if (sb.length() > 0) {
/* 733 */         sb.setLength(sb.length() - 1);
/*     */       }
/*     */       
/* 736 */       this.actions = result = sb.toString();
/*     */     } 
/* 738 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionCollection newPermissionCollection() {
/* 749 */     return new AdminPermissionCollection();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 761 */     if (obj == this) {
/* 762 */       return true;
/*     */     }
/*     */     
/* 765 */     if (!(obj instanceof AdminPermission)) {
/* 766 */       return false;
/*     */     }
/*     */     
/* 769 */     AdminPermission ap = (AdminPermission)obj;
/*     */     
/* 771 */     return (this.action_mask == ap.action_mask && (this.bundle == ap.bundle || (this.bundle != null && this.bundle.equals(ap.bundle))) && ((this.filter == null) ? (ap.filter == null) : this.filter.equals(ap.filter)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 781 */     int h = 527 + getName().hashCode();
/* 782 */     h = 31 * h + getActions().hashCode();
/* 783 */     if (this.bundle != null) {
/* 784 */       h = 31 * h + this.bundle.hashCode();
/*     */     }
/* 786 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void writeObject(ObjectOutputStream s) throws IOException {
/* 795 */     if (this.bundle != null) {
/* 796 */       throw new NotSerializableException("cannot serialize");
/*     */     }
/*     */ 
/*     */     
/* 800 */     if (this.actions == null)
/* 801 */       getActions(); 
/* 802 */     s.defaultWriteObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void readObject(ObjectInputStream s) throws IOException, ClassNotFoundException {
/* 811 */     s.defaultReadObject();
/* 812 */     setTransients(parseFilter(getName()), parseActions(this.actions));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Object> getProperties() {
/* 827 */     Map<String, Object> result = this.properties;
/* 828 */     if (result != null) {
/* 829 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 836 */     Object mark = recurse.get();
/* 837 */     if (mark == this.bundle) {
/* 838 */       return null;
/*     */     }
/* 840 */     recurse.set(this.bundle);
/*     */     try {
/* 842 */       final Map<String, Object> map = new HashMap<>(4);
/* 843 */       AccessController.doPrivileged(new PrivilegedAction<Void>()
/*     */           {
/*     */             public Void run() {
/* 846 */               map.put("id", Long.valueOf(AdminPermission.this.bundle.getBundleId()));
/* 847 */               map.put("location", AdminPermission.this.bundle.getLocation());
/* 848 */               String name = AdminPermission.this.bundle.getSymbolicName();
/* 849 */               if (name != null) {
/* 850 */                 map.put("name", name);
/*     */               }
/* 852 */               SignerProperty signer = new SignerProperty(AdminPermission.this.bundle);
/* 853 */               if (signer.isBundleSigned()) {
/* 854 */                 map.put("signer", signer);
/*     */               }
/* 856 */               return null;
/*     */             }
/*     */           });
/* 859 */       return this.properties = map;
/*     */     } finally {
/* 861 */       recurse.set(null);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\AdminPermission.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */