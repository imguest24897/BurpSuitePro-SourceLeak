package org.osgi.framework.wiring.dto;

import org.osgi.resource.dto.ResourceDTO;

public class BundleRevisionDTO extends ResourceDTO {
  public String symbolicName;
  
  public int type;
  
  public String version;
  
  public long bundle;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\wiring\dto\BundleRevisionDTO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */