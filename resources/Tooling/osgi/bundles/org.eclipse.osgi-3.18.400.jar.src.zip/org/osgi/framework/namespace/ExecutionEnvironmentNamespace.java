package org.osgi.framework.namespace;

import org.osgi.resource.Namespace;

public final class ExecutionEnvironmentNamespace extends Namespace {
  public static final String EXECUTION_ENVIRONMENT_NAMESPACE = "osgi.ee";
  
  public static final String CAPABILITY_VERSION_ATTRIBUTE = "version";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\namespace\ExecutionEnvironmentNamespace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */