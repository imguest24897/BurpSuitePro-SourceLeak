package org.osgi.framework.connect;

import java.util.Map;
import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.launch.Framework;

@ProviderType
public interface ConnectFrameworkFactory {
  Framework newFramework(Map<String, String> paramMap, ModuleConnector paramModuleConnector);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\connect\ConnectFrameworkFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */