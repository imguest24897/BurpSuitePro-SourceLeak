package org.osgi.framework.namespace;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.resource.Namespace;

@ProviderType
public abstract class AbstractWiringNamespace extends Namespace {
  public static final String CAPABILITY_MANDATORY_DIRECTIVE = "mandatory";
  
  public static final String CAPABILITY_BUNDLE_VERSION_ATTRIBUTE = "bundle-version";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\namespace\AbstractWiringNamespace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */