package org.osgi.framework.wiring;

import java.util.List;
import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.BundleReference;
import org.osgi.framework.Version;
import org.osgi.resource.Capability;
import org.osgi.resource.Requirement;
import org.osgi.resource.Resource;

@ProviderType
public interface BundleRevision extends BundleReference, Resource {
  public static final String PACKAGE_NAMESPACE = "osgi.wiring.package";
  
  public static final String BUNDLE_NAMESPACE = "osgi.wiring.bundle";
  
  public static final String HOST_NAMESPACE = "osgi.wiring.host";
  
  public static final int TYPE_FRAGMENT = 1;
  
  String getSymbolicName();
  
  Version getVersion();
  
  List<BundleCapability> getDeclaredCapabilities(String paramString);
  
  List<BundleRequirement> getDeclaredRequirements(String paramString);
  
  int getTypes();
  
  BundleWiring getWiring();
  
  List<Capability> getCapabilities(String paramString);
  
  List<Requirement> getRequirements(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\wiring\BundleRevision.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */