/*     */ package org.osgi.framework;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Version
/*     */   implements Comparable<Version>
/*     */ {
/*     */   private final int major;
/*     */   private final int minor;
/*     */   private final int micro;
/*     */   private final String qualifier;
/*     */   private static final String SEPARATOR = ".";
/*     */   private transient String versionString;
/*     */   private transient int hash;
/*  55 */   public static final Version emptyVersion = new Version(0, 0, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Version(int major, int minor, int micro) {
/*  70 */     this(major, minor, micro, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Version(int major, int minor, int micro, String qualifier) {
/*  86 */     if (qualifier == null) {
/*  87 */       qualifier = "";
/*     */     }
/*     */     
/*  90 */     this.major = major;
/*  91 */     this.minor = minor;
/*  92 */     this.micro = micro;
/*  93 */     this.qualifier = qualifier;
/*  94 */     validate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Version(String version) {
/* 119 */     int maj = 0;
/* 120 */     int min = 0;
/* 121 */     int mic = 0;
/* 122 */     String qual = "";
/*     */     
/*     */     try {
/* 125 */       StringTokenizer st = new StringTokenizer(version, ".", true);
/* 126 */       maj = parseInt(st.nextToken(), version);
/*     */       
/* 128 */       if (st.hasMoreTokens()) {
/* 129 */         st.nextToken();
/* 130 */         min = parseInt(st.nextToken(), version);
/*     */         
/* 132 */         if (st.hasMoreTokens()) {
/* 133 */           st.nextToken();
/* 134 */           mic = parseInt(st.nextToken(), version);
/*     */           
/* 136 */           if (st.hasMoreTokens()) {
/* 137 */             st.nextToken();
/* 138 */             qual = st.nextToken("");
/*     */             
/* 140 */             if (st.hasMoreTokens()) {
/* 141 */               throw new IllegalArgumentException("invalid version \"" + version + "\": invalid format");
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 146 */     } catch (NoSuchElementException e) {
/* 147 */       throw new IllegalArgumentException(
/* 148 */           "invalid version \"" + version + "\": invalid format", e);
/*     */     } 
/*     */     
/* 151 */     this.major = maj;
/* 152 */     this.minor = min;
/* 153 */     this.micro = mic;
/* 154 */     this.qualifier = qual;
/* 155 */     validate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int parseInt(String value, String version) {
/*     */     try {
/* 167 */       return Integer.parseInt(value);
/* 168 */     } catch (NumberFormatException e) {
/* 169 */       throw new IllegalArgumentException("invalid version \"" + version + 
/* 170 */           "\": non-numeric \"" + value + "\"", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validate() {
/* 181 */     if (this.major < 0) {
/* 182 */       throw new IllegalArgumentException("invalid version \"" + toString0() + "\": negative number \"" + this.major + "\"");
/*     */     }
/* 184 */     if (this.minor < 0) {
/* 185 */       throw new IllegalArgumentException("invalid version \"" + toString0() + "\": negative number \"" + this.minor + "\"");
/*     */     }
/* 187 */     if (this.micro < 0)
/* 188 */       throw new IllegalArgumentException("invalid version \"" + toString0() + "\": negative number \"" + this.micro + "\"");  byte b; int i;
/*     */     char[] arrayOfChar;
/* 190 */     for (i = (arrayOfChar = this.qualifier.toCharArray()).length, b = 0; b < i; ) { char ch = arrayOfChar[b];
/* 191 */       if ('A' > ch || ch > 'Z')
/*     */       {
/*     */         
/* 194 */         if ('a' > ch || ch > 'z')
/*     */         {
/*     */           
/* 197 */           if ('0' > ch || ch > '9')
/*     */           {
/*     */             
/* 200 */             if (ch != '_' && ch != '-')
/*     */             {
/*     */               
/* 203 */               throw new IllegalArgumentException("invalid version \"" + toString0() + "\": invalid qualifier \"" + this.qualifier + "\"");
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Version parseVersion(String version) {
/* 222 */     if (version == null) {
/* 223 */       return emptyVersion;
/*     */     }
/*     */     
/* 226 */     return valueOf(version);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Version valueOf(String version) {
/* 250 */     version = version.trim();
/* 251 */     if (version.length() == 0) {
/* 252 */       return emptyVersion;
/*     */     }
/*     */     
/* 255 */     return new Version(version);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMajor() {
/* 264 */     return this.major;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinor() {
/* 273 */     return this.minor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMicro() {
/* 282 */     return this.micro;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getQualifier() {
/* 291 */     return this.qualifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 306 */     return toString0();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toString0() {
/* 315 */     String s = this.versionString;
/* 316 */     if (s != null) {
/* 317 */       return s;
/*     */     }
/* 319 */     int q = this.qualifier.length();
/* 320 */     StringBuilder result = new StringBuilder(20 + q);
/* 321 */     result.append(this.major);
/* 322 */     result.append(".");
/* 323 */     result.append(this.minor);
/* 324 */     result.append(".");
/* 325 */     result.append(this.micro);
/* 326 */     if (q > 0) {
/* 327 */       result.append(".");
/* 328 */       result.append(this.qualifier);
/*     */     } 
/* 330 */     return this.versionString = result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 340 */     int h = this.hash;
/* 341 */     if (h != 0) {
/* 342 */       return h;
/*     */     }
/* 344 */     h = 527;
/* 345 */     h = 31 * h + this.major;
/* 346 */     h = 31 * h + this.minor;
/* 347 */     h = 31 * h + this.micro;
/* 348 */     h = 31 * h + this.qualifier.hashCode();
/* 349 */     return this.hash = h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 366 */     if (object == this) {
/* 367 */       return true;
/*     */     }
/*     */     
/* 370 */     if (!(object instanceof Version)) {
/* 371 */       return false;
/*     */     }
/*     */     
/* 374 */     Version other = (Version)object;
/* 375 */     return (this.major == other.major && this.minor == other.minor && this.micro == other.micro && this.qualifier.equals(other.qualifier));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(Version other) {
/* 405 */     if (other == this) {
/* 406 */       return 0;
/*     */     }
/*     */     
/* 409 */     int result = this.major - other.major;
/* 410 */     if (result != 0) {
/* 411 */       return result;
/*     */     }
/*     */     
/* 414 */     result = this.minor - other.minor;
/* 415 */     if (result != 0) {
/* 416 */       return result;
/*     */     }
/*     */     
/* 419 */     result = this.micro - other.micro;
/* 420 */     if (result != 0) {
/* 421 */       return result;
/*     */     }
/*     */     
/* 424 */     return this.qualifier.compareTo(other.qualifier);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\Version.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */