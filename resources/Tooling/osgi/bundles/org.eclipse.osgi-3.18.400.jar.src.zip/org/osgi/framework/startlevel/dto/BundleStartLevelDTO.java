package org.osgi.framework.startlevel.dto;

import org.osgi.dto.DTO;

public class BundleStartLevelDTO extends DTO {
  public long bundle;
  
  public int startLevel;
  
  public boolean activationPolicyUsed;
  
  public boolean persistentlyStarted;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\startlevel\dto\BundleStartLevelDTO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */