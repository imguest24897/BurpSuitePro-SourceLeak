/*     */ package org.osgi.framework;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.ObjectStreamField;
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BundlePermissionCollection
/*     */   extends PermissionCollection
/*     */ {
/*     */   private static final long serialVersionUID = 3258407326846433079L;
/* 456 */   private transient Map<String, BundlePermission> permissions = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean all_allowed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Permission permission) {
/* 471 */     if (!(permission instanceof BundlePermission)) {
/* 472 */       throw new IllegalArgumentException("invalid permission: " + permission);
/*     */     }
/* 474 */     if (isReadOnly()) {
/* 475 */       throw new SecurityException("attempt to add a Permission to a readonly PermissionCollection");
/*     */     }
/* 477 */     BundlePermission bp = (BundlePermission)permission;
/* 478 */     String name = bp.getName();
/* 479 */     synchronized (this) {
/* 480 */       Map<String, BundlePermission> pc = this.permissions;
/* 481 */       BundlePermission existing = pc.get(name);
/* 482 */       if (existing != null) {
/* 483 */         int oldMask = existing.getActionsMask();
/* 484 */         int newMask = bp.getActionsMask();
/* 485 */         if (oldMask != newMask) {
/* 486 */           pc.put(name, new BundlePermission(name, oldMask | newMask));
/*     */         }
/*     */       } else {
/*     */         
/* 490 */         pc.put(name, bp);
/*     */       } 
/*     */       
/* 493 */       if (!this.all_allowed && 
/* 494 */         name.equals("*")) {
/* 495 */         this.all_allowed = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean implies(Permission permission) {
/* 511 */     if (!(permission instanceof BundlePermission)) {
/* 512 */       return false;
/*     */     }
/* 514 */     BundlePermission requested = (BundlePermission)permission;
/* 515 */     String requestedName = requested.getName();
/* 516 */     int desired = requested.getActionsMask();
/* 517 */     int effective = 0;
/*     */ 
/*     */     
/* 520 */     synchronized (this) {
/* 521 */       Map<String, BundlePermission> pc = this.permissions;
/*     */       
/* 523 */       if (this.all_allowed) {
/* 524 */         BundlePermission bundlePermission = pc.get("*");
/* 525 */         if (bundlePermission != null) {
/* 526 */           effective |= bundlePermission.getActionsMask();
/* 527 */           if ((effective & desired) == desired) {
/* 528 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/* 532 */       BundlePermission bp = pc.get(requestedName);
/*     */ 
/*     */ 
/*     */       
/* 536 */       if (bp != null) {
/*     */         
/* 538 */         effective |= bp.getActionsMask();
/* 539 */         if ((effective & desired) == desired) {
/* 540 */           return true;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 545 */       int offset = requestedName.length() - 1; int last;
/* 546 */       while ((last = requestedName.lastIndexOf('.', offset)) != -1) {
/* 547 */         requestedName = String.valueOf(requestedName.substring(0, last + 1)) + "*";
/* 548 */         bp = pc.get(requestedName);
/* 549 */         if (bp != null) {
/* 550 */           effective |= bp.getActionsMask();
/* 551 */           if ((effective & desired) == desired) {
/* 552 */             return true;
/*     */           }
/*     */         } 
/* 555 */         offset = last - 1;
/*     */       } 
/*     */ 
/*     */       
/* 559 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Enumeration<Permission> elements() {
/* 571 */     List<Permission> all = new ArrayList<>(this.permissions.values());
/* 572 */     return Collections.enumeration(all);
/*     */   }
/*     */ 
/*     */   
/* 576 */   private static final ObjectStreamField[] serialPersistentFields = new ObjectStreamField[] { new ObjectStreamField("permissions", Hashtable.class), new ObjectStreamField("all_allowed", boolean.class) };
/*     */   
/*     */   private synchronized void writeObject(ObjectOutputStream out) throws IOException {
/* 579 */     Hashtable<String, BundlePermission> hashtable = new Hashtable<>(this.permissions);
/* 580 */     ObjectOutputStream.PutField pfields = out.putFields();
/* 581 */     pfields.put("permissions", hashtable);
/* 582 */     pfields.put("all_allowed", this.all_allowed);
/* 583 */     out.writeFields();
/*     */   }
/*     */   
/*     */   private synchronized void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 587 */     ObjectInputStream.GetField gfields = in.readFields();
/*     */     
/* 589 */     Hashtable<String, BundlePermission> hashtable = (Hashtable<String, BundlePermission>)gfields.get("permissions", (Object)null);
/* 590 */     this.permissions = new HashMap<>(hashtable);
/* 591 */     this.all_allowed = gfields.get("all_allowed", false);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\BundlePermissionCollection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */