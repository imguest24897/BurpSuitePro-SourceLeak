package org.osgi.framework.hooks.weaving;

import java.security.ProtectionDomain;
import java.util.List;
import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.wiring.BundleWiring;

@ProviderType
public interface WovenClass {
  public static final int TRANSFORMING = 1;
  
  public static final int TRANSFORMED = 2;
  
  public static final int DEFINED = 4;
  
  public static final int TRANSFORMING_FAILED = 8;
  
  public static final int DEFINE_FAILED = 16;
  
  byte[] getBytes();
  
  void setBytes(byte[] paramArrayOfbyte);
  
  List<String> getDynamicImports();
  
  boolean isWeavingComplete();
  
  String getClassName();
  
  ProtectionDomain getProtectionDomain();
  
  Class<?> getDefinedClass();
  
  BundleWiring getBundleWiring();
  
  int getState();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\hooks\weaving\WovenClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */