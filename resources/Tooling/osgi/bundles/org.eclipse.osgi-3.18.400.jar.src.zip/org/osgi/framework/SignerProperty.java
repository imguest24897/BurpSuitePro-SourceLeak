/*     */ package org.osgi.framework;
/*     */ 
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SignerProperty
/*     */ {
/*     */   private final Bundle bundle;
/*     */   private final String pattern;
/*     */   
/*     */   public SignerProperty(String pattern) {
/*  42 */     this.pattern = pattern;
/*  43 */     this.bundle = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SignerProperty(Bundle bundle) {
/*  53 */     this.bundle = bundle;
/*  54 */     this.pattern = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  69 */     if (!(o instanceof SignerProperty))
/*  70 */       return false; 
/*  71 */     SignerProperty other = (SignerProperty)o;
/*  72 */     Bundle matchBundle = (this.bundle != null) ? this.bundle : other.bundle;
/*  73 */     String matchPattern = (this.bundle != null) ? other.pattern : this.pattern;
/*  74 */     Map<X509Certificate, List<X509Certificate>> signers = matchBundle.getSignerCertificates(2);
/*  75 */     for (List<X509Certificate> signerCerts : signers.values()) {
/*  76 */       List<String> dnChain = new ArrayList<>(signerCerts.size());
/*  77 */       for (X509Certificate signerCert : signerCerts) {
/*  78 */         dnChain.add(signerCert.getSubjectDN().getName());
/*     */       }
/*     */       try {
/*  81 */         if (FrameworkUtil.matchDistinguishedNameChain(matchPattern, dnChain)) {
/*  82 */           return true;
/*     */         }
/*  84 */       } catch (IllegalArgumentException illegalArgumentException) {}
/*     */     } 
/*     */ 
/*     */     
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  97 */     return 31;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isBundleSigned() {
/* 106 */     if (this.bundle == null) {
/* 107 */       return false;
/*     */     }
/* 109 */     Map<X509Certificate, List<X509Certificate>> signers = this.bundle.getSignerCertificates(2);
/* 110 */     return !signers.isEmpty();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\SignerProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */