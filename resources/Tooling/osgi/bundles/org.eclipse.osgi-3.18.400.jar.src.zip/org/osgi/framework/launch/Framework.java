package org.osgi.framework.launch;

import java.io.InputStream;
import java.net.URL;
import java.util.Enumeration;
import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleException;
import org.osgi.framework.FrameworkEvent;
import org.osgi.framework.FrameworkListener;

@ProviderType
public interface Framework extends Bundle {
  void init() throws BundleException;
  
  void init(FrameworkListener... paramVarArgs) throws BundleException;
  
  FrameworkEvent waitForStop(long paramLong) throws InterruptedException;
  
  void start() throws BundleException;
  
  void start(int paramInt) throws BundleException;
  
  void stop() throws BundleException;
  
  void stop(int paramInt) throws BundleException;
  
  void uninstall() throws BundleException;
  
  void update() throws BundleException;
  
  void update(InputStream paramInputStream) throws BundleException;
  
  long getBundleId();
  
  String getLocation();
  
  String getSymbolicName();
  
  Enumeration<String> getEntryPaths(String paramString);
  
  URL getEntry(String paramString);
  
  long getLastModified();
  
  Enumeration<URL> findEntries(String paramString1, String paramString2, boolean paramBoolean);
  
  <A> A adapt(Class<A> paramClass);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\launch\Framework.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */