package org.osgi.framework.connect;

import java.io.File;
import java.util.Map;
import java.util.Optional;
import org.osgi.annotation.versioning.ConsumerType;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleException;

@ConsumerType
public interface ModuleConnector {
  void initialize(File paramFile, Map<String, String> paramMap);
  
  Optional<ConnectModule> connect(String paramString) throws BundleException;
  
  Optional<BundleActivator> newBundleActivator();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\connect\ModuleConnector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */