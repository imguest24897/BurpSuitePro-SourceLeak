/*     */ package org.osgi.framework;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.ObjectStreamField;
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ServicePermissionCollection
/*     */   extends PermissionCollection
/*     */ {
/*     */   static final long serialVersionUID = 662615640374640621L;
/* 718 */   private transient Map<String, ServicePermission> permissions = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean all_allowed = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, ServicePermission> filterPermissions;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Permission permission) {
/* 733 */     if (!(permission instanceof ServicePermission)) {
/* 734 */       throw new IllegalArgumentException("invalid permission: " + permission);
/*     */     }
/* 736 */     if (isReadOnly()) {
/* 737 */       throw new SecurityException("attempt to add a Permission to a readonly PermissionCollection");
/*     */     }
/*     */     
/* 740 */     ServicePermission sp = (ServicePermission)permission;
/* 741 */     if (sp.service != null) {
/* 742 */       throw new IllegalArgumentException("cannot add to collection: " + sp);
/*     */     }
/*     */     
/* 745 */     String name = sp.getName();
/* 746 */     Filter f = sp.filter;
/* 747 */     synchronized (this) {
/*     */       Map<String, ServicePermission> pc;
/*     */       
/* 750 */       if (f != null) {
/* 751 */         pc = this.filterPermissions;
/* 752 */         if (pc == null) {
/* 753 */           this.filterPermissions = pc = new HashMap<>();
/*     */         }
/*     */       } else {
/* 756 */         pc = this.permissions;
/*     */       } 
/* 758 */       ServicePermission existing = pc.get(name);
/*     */       
/* 760 */       if (existing != null) {
/* 761 */         int oldMask = existing.action_mask;
/* 762 */         int newMask = sp.action_mask;
/* 763 */         if (oldMask != newMask) {
/* 764 */           pc.put(name, new ServicePermission(name, oldMask | newMask));
/*     */         }
/*     */       } else {
/* 767 */         pc.put(name, sp);
/*     */       } 
/*     */       
/* 770 */       if (!this.all_allowed && 
/* 771 */         name.equals("*")) {
/* 772 */         this.all_allowed = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean implies(Permission permission) {
/*     */     Collection<ServicePermission> perms;
/* 788 */     if (!(permission instanceof ServicePermission)) {
/* 789 */       return false;
/*     */     }
/* 791 */     ServicePermission requested = (ServicePermission)permission;
/*     */     
/* 793 */     if (requested.filter != null) {
/* 794 */       return false;
/*     */     }
/*     */     
/* 797 */     int effective = 0;
/*     */     
/* 799 */     synchronized (this) {
/* 800 */       int desired = requested.action_mask;
/*     */       
/* 802 */       if (this.all_allowed) {
/* 803 */         ServicePermission sp = this.permissions.get("*");
/* 804 */         if (sp != null) {
/* 805 */           effective |= sp.action_mask;
/* 806 */           if ((effective & desired) == desired) {
/* 807 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 812 */       String[] requestedNames = requested.objectClass;
/*     */       
/* 814 */       if (requestedNames == null) {
/* 815 */         effective |= effective(requested.getName(), desired, effective);
/* 816 */         if ((effective & desired) == desired) {
/* 817 */           return true;
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 822 */         for (int i = 0, l = requestedNames.length; i < l; i++) {
/* 823 */           if ((effective(requestedNames[i], desired, effective) & desired) == desired) {
/* 824 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/* 828 */       Map<String, ServicePermission> pc = this.filterPermissions;
/* 829 */       if (pc == null) {
/* 830 */         return false;
/*     */       }
/* 832 */       perms = pc.values();
/*     */     } 
/*     */ 
/*     */     
/* 836 */     for (ServicePermission perm : perms) {
/* 837 */       if (perm.implies0(requested, effective)) {
/* 838 */         return true;
/*     */       }
/*     */     } 
/* 841 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int effective(String requestedName, int desired, int effective) {
/* 854 */     Map<String, ServicePermission> pc = this.permissions;
/* 855 */     ServicePermission sp = pc.get(requestedName);
/*     */ 
/*     */ 
/*     */     
/* 859 */     if (sp != null) {
/*     */       
/* 861 */       effective |= sp.action_mask;
/* 862 */       if ((effective & desired) == desired) {
/* 863 */         return effective;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 868 */     int offset = requestedName.length() - 1; int last;
/* 869 */     while ((last = requestedName.lastIndexOf('.', offset)) != -1) {
/* 870 */       requestedName = String.valueOf(requestedName.substring(0, last + 1)) + "*";
/* 871 */       sp = pc.get(requestedName);
/* 872 */       if (sp != null) {
/* 873 */         effective |= sp.action_mask;
/* 874 */         if ((effective & desired) == desired) {
/* 875 */           return effective;
/*     */         }
/*     */       } 
/* 878 */       offset = last - 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 884 */     return effective;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Enumeration<Permission> elements() {
/* 895 */     List<Permission> all = new ArrayList<>(this.permissions.values());
/* 896 */     Map<String, ServicePermission> pc = this.filterPermissions;
/* 897 */     if (pc != null) {
/* 898 */       all.addAll(pc.values());
/*     */     }
/* 900 */     return Collections.enumeration(all);
/*     */   }
/*     */ 
/*     */   
/* 904 */   private static final ObjectStreamField[] serialPersistentFields = new ObjectStreamField[] { new ObjectStreamField("permissions", Hashtable.class), new ObjectStreamField("all_allowed", boolean.class), 
/* 905 */       new ObjectStreamField("filterPermissions", HashMap.class) };
/*     */   
/*     */   private synchronized void writeObject(ObjectOutputStream out) throws IOException {
/* 908 */     Hashtable<String, ServicePermission> hashtable = new Hashtable<>(this.permissions);
/* 909 */     ObjectOutputStream.PutField pfields = out.putFields();
/* 910 */     pfields.put("permissions", hashtable);
/* 911 */     pfields.put("all_allowed", this.all_allowed);
/* 912 */     pfields.put("filterPermissions", this.filterPermissions);
/* 913 */     out.writeFields();
/*     */   }
/*     */   
/*     */   private synchronized void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 917 */     ObjectInputStream.GetField gfields = in.readFields();
/*     */     
/* 919 */     Hashtable<String, ServicePermission> hashtable = (Hashtable<String, ServicePermission>)gfields.get("permissions", (Object)null);
/* 920 */     this.permissions = new HashMap<>(hashtable);
/* 921 */     this.all_allowed = gfields.get("all_allowed", false);
/*     */     
/* 923 */     HashMap<String, ServicePermission> fp = (HashMap<String, ServicePermission>)gfields.get("filterPermissions", (Object)null);
/* 924 */     this.filterPermissions = fp;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\ServicePermissionCollection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */