package org.osgi.framework.wiring.dto;

import org.osgi.resource.dto.WireDTO;

public class BundleWireDTO extends WireDTO {
  public int providerWiring;
  
  public int requirerWiring;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\wiring\dto\BundleWireDTO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */