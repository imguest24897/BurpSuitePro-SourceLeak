package org.osgi.framework.hooks.service;

import java.util.Collection;
import org.osgi.annotation.versioning.ConsumerType;
import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.BundleContext;

@ConsumerType
public interface ListenerHook {
  void added(Collection<ListenerInfo> paramCollection);
  
  void removed(Collection<ListenerInfo> paramCollection);
  
  @ProviderType
  public static interface ListenerInfo {
    BundleContext getBundleContext();
    
    String getFilter();
    
    boolean isRemoved();
    
    boolean equals(Object param1Object);
    
    int hashCode();
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\hooks\service\ListenerHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */