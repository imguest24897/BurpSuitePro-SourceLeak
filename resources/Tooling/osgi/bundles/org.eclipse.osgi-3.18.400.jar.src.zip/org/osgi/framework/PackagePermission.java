/*     */ package org.osgi.framework;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.NotSerializableException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.security.AccessController;
/*     */ import java.security.BasicPermission;
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PackagePermission
/*     */   extends BasicPermission
/*     */ {
/*     */   static final long serialVersionUID = -5107705877071099135L;
/*     */   public static final String EXPORT = "export";
/*     */   public static final String EXPORTONLY = "exportonly";
/*     */   public static final String IMPORT = "import";
/*     */   private static final int ACTION_EXPORT = 1;
/*     */   private static final int ACTION_IMPORT = 2;
/*     */   private static final int ACTION_ALL = 3;
/*     */   static final int ACTION_NONE = 0;
/*     */   transient int action_mask;
/*  99 */   private volatile String actions = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final transient Bundle bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   transient Filter filter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile transient Map<String, Object> properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PackagePermission(String name, String actions) {
/* 169 */     this(name, parseActions(actions));
/* 170 */     if (this.filter != null && (this.action_mask & 0x3) != 2) {
/* 171 */       throw new IllegalArgumentException("invalid action string for filter expression");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PackagePermission(String name, Bundle exportingBundle, String actions) {
/* 189 */     super(name);
/* 190 */     setTransients(name, parseActions(actions));
/* 191 */     this.bundle = exportingBundle;
/* 192 */     if (exportingBundle == null) {
/* 193 */       throw new IllegalArgumentException("bundle must not be null");
/*     */     }
/* 195 */     if (this.filter != null) {
/* 196 */       throw new IllegalArgumentException("invalid name");
/*     */     }
/* 198 */     if ((this.action_mask & 0x3) != 2) {
/* 199 */       throw new IllegalArgumentException("invalid action string");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PackagePermission(String name, int mask) {
/* 210 */     super(name);
/* 211 */     setTransients(name, mask);
/* 212 */     this.bundle = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setTransients(String name, int mask) {
/* 221 */     if (mask == 0 || (mask & 0x3) != mask) {
/* 222 */       throw new IllegalArgumentException("invalid action string");
/*     */     }
/* 224 */     this.action_mask = mask;
/* 225 */     this.filter = parseFilter(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int parseActions(String actions) {
/* 235 */     boolean seencomma = false;
/*     */     
/* 237 */     int mask = 0;
/*     */     
/* 239 */     if (actions == null) {
/* 240 */       return mask;
/*     */     }
/*     */     
/* 243 */     char[] a = actions.toCharArray();
/*     */     
/* 245 */     int i = a.length - 1;
/* 246 */     if (i < 0) {
/* 247 */       return mask;
/*     */     }
/* 249 */     while (i != -1) {
/*     */       int matchlen;
/*     */       
/*     */       char c;
/* 253 */       while (i != -1 && ((c = a[i]) == ' ' || c == '\r' || c == '\n' || c == '\f' || c == '\t')) {
/* 254 */         i--;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 259 */       if (i >= 5 && (a[i - 5] == 'i' || a[i - 5] == 'I') && (
/* 260 */         a[i - 4] == 'm' || a[i - 4] == 'M') && (
/* 261 */         a[i - 3] == 'p' || a[i - 3] == 'P') && (
/* 262 */         a[i - 2] == 'o' || a[i - 2] == 'O') && (
/* 263 */         a[i - 1] == 'r' || a[i - 1] == 'R') && (
/* 264 */         a[i] == 't' || a[i] == 'T')) {
/* 265 */         matchlen = 6;
/* 266 */         mask |= 0x2;
/*     */       
/*     */       }
/* 269 */       else if (i >= 5 && (a[i - 5] == 'e' || a[i - 5] == 'E') && (
/* 270 */         a[i - 4] == 'x' || a[i - 4] == 'X') && (
/* 271 */         a[i - 3] == 'p' || a[i - 3] == 'P') && (
/* 272 */         a[i - 2] == 'o' || a[i - 2] == 'O') && (
/* 273 */         a[i - 1] == 'r' || a[i - 1] == 'R') && (
/* 274 */         a[i] == 't' || a[i] == 'T')) {
/* 275 */         matchlen = 6;
/* 276 */         mask |= 0x3;
/*     */       
/*     */       }
/* 279 */       else if (i >= 9 && (a[i - 9] == 'e' || a[i - 9] == 'E') && (
/* 280 */         a[i - 8] == 'x' || a[i - 8] == 'X') && (
/* 281 */         a[i - 7] == 'p' || a[i - 7] == 'P') && (
/* 282 */         a[i - 6] == 'o' || a[i - 6] == 'O') && (
/* 283 */         a[i - 5] == 'r' || a[i - 5] == 'R') && (
/* 284 */         a[i - 4] == 't' || a[i - 4] == 'T') && (
/* 285 */         a[i - 3] == 'o' || a[i - 3] == 'O') && (
/* 286 */         a[i - 2] == 'n' || a[i - 2] == 'N') && (
/* 287 */         a[i - 1] == 'l' || a[i - 1] == 'L') && (
/* 288 */         a[i] == 'y' || a[i] == 'Y')) {
/* 289 */         matchlen = 10;
/* 290 */         mask |= 0x1;
/*     */       }
/*     */       else {
/*     */         
/* 294 */         throw new IllegalArgumentException("invalid permission: " + actions);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 300 */       seencomma = false;
/* 301 */       while (i >= matchlen && !seencomma) {
/* 302 */         switch (a[i - matchlen]) {
/*     */           case ',':
/* 304 */             seencomma = true;
/*     */             break;
/*     */           case '\t':
/*     */           case '\n':
/*     */           case '\f':
/*     */           case '\r':
/*     */           case ' ':
/*     */             break;
/*     */           default:
/* 313 */             throw new IllegalArgumentException("invalid permission: " + actions);
/*     */         } 
/* 315 */         i--;
/*     */       } 
/*     */ 
/*     */       
/* 319 */       i -= matchlen;
/*     */     } 
/*     */     
/* 322 */     if (seencomma) {
/* 323 */       throw new IllegalArgumentException("invalid permission: " + actions);
/*     */     }
/*     */     
/* 326 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Filter parseFilter(String filterString) {
/* 338 */     filterString = filterString.trim();
/* 339 */     if (filterString.charAt(0) != '(') {
/* 340 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 344 */       return FrameworkUtil.createFilter(filterString);
/* 345 */     } catch (InvalidSyntaxException e) {
/* 346 */       throw new IllegalArgumentException("invalid filter", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean implies(Permission p) {
/* 375 */     if (!(p instanceof PackagePermission)) {
/* 376 */       return false;
/*     */     }
/* 378 */     PackagePermission requested = (PackagePermission)p;
/* 379 */     if (this.bundle != null) {
/* 380 */       return false;
/*     */     }
/*     */     
/* 383 */     if (requested.filter != null) {
/* 384 */       return false;
/*     */     }
/* 386 */     return implies0(requested, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean implies0(PackagePermission requested, int effective) {
/* 402 */     effective |= this.action_mask;
/* 403 */     int desired = requested.action_mask;
/* 404 */     if ((effective & desired) != desired) {
/* 405 */       return false;
/*     */     }
/*     */     
/* 408 */     Filter f = this.filter;
/* 409 */     if (f == null) {
/* 410 */       return super.implies(requested);
/*     */     }
/* 412 */     return f.matches(requested.getProperties());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getActions() {
/* 428 */     String result = this.actions;
/* 429 */     if (result == null) {
/* 430 */       StringBuilder sb = new StringBuilder();
/* 431 */       boolean comma = false;
/*     */       
/* 433 */       int mask = this.action_mask;
/* 434 */       if ((mask & 0x1) == 1) {
/* 435 */         sb.append("exportonly");
/* 436 */         comma = true;
/*     */       } 
/*     */       
/* 439 */       if ((mask & 0x2) == 2) {
/* 440 */         if (comma)
/* 441 */           sb.append(','); 
/* 442 */         sb.append("import");
/*     */       } 
/*     */       
/* 445 */       this.actions = result = sb.toString();
/*     */     } 
/* 447 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionCollection newPermissionCollection() {
/* 458 */     return new PackagePermissionCollection();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 476 */     if (obj == this) {
/* 477 */       return true;
/*     */     }
/*     */     
/* 480 */     if (!(obj instanceof PackagePermission)) {
/* 481 */       return false;
/*     */     }
/*     */     
/* 484 */     PackagePermission pp = (PackagePermission)obj;
/*     */     
/* 486 */     return (this.action_mask == pp.action_mask && getName().equals(pp.getName()) && (this.bundle == pp.bundle || (this.bundle != null && this.bundle.equals(pp.bundle))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 496 */     int h = 527 + getName().hashCode();
/* 497 */     h = 31 * h + getActions().hashCode();
/* 498 */     if (this.bundle != null) {
/* 499 */       h = 31 * h + this.bundle.hashCode();
/*     */     }
/* 501 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void writeObject(ObjectOutputStream s) throws IOException {
/* 510 */     if (this.bundle != null) {
/* 511 */       throw new NotSerializableException("cannot serialize");
/*     */     }
/*     */ 
/*     */     
/* 515 */     if (this.actions == null)
/* 516 */       getActions(); 
/* 517 */     s.defaultWriteObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void readObject(ObjectInputStream s) throws IOException, ClassNotFoundException {
/* 526 */     s.defaultReadObject();
/* 527 */     setTransients(getName(), parseActions(this.actions));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Object> getProperties() {
/* 537 */     Map<String, Object> result = this.properties;
/* 538 */     if (result != null) {
/* 539 */       return result;
/*     */     }
/* 541 */     final Map<String, Object> map = new HashMap<>(5);
/* 542 */     map.put("package.name", getName());
/* 543 */     if (this.bundle != null) {
/* 544 */       AccessController.doPrivileged(new PrivilegedAction<Void>()
/*     */           {
/*     */             public Void run() {
/* 547 */               map.put("id", Long.valueOf(PackagePermission.this.bundle.getBundleId()));
/* 548 */               map.put("location", PackagePermission.this.bundle.getLocation());
/* 549 */               String name = PackagePermission.this.bundle.getSymbolicName();
/* 550 */               if (name != null) {
/* 551 */                 map.put("name", name);
/*     */               }
/* 553 */               SignerProperty signer = new SignerProperty(PackagePermission.this.bundle);
/* 554 */               if (signer.isBundleSigned()) {
/* 555 */                 map.put("signer", signer);
/*     */               }
/* 557 */               return null;
/*     */             }
/*     */           });
/*     */     }
/* 561 */     return this.properties = map;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\PackagePermission.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */