package org.osgi.framework.namespace;

import org.osgi.resource.Namespace;

public final class NativeNamespace extends Namespace {
  public static final String NATIVE_NAMESPACE = "osgi.native";
  
  public static final String CAPABILITY_OSNAME_ATTRIBUTE = "osgi.native.osname";
  
  public static final String CAPABILITY_OSVERSION_ATTRIBUTE = "osgi.native.osversion";
  
  public static final String CAPABILITY_PROCESSOR_ATTRIBUTE = "osgi.native.processor";
  
  public static final String CAPABILITY_LANGUAGE_ATTRIBUTE = "osgi.native.language";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\namespace\NativeNamespace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */