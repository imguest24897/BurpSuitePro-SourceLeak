/*    */ package org.osgi.framework.connect;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import org.osgi.annotation.versioning.ConsumerType;
/*    */ import org.osgi.framework.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConsumerType
/*    */ public interface FrameworkUtilHelper
/*    */ {
/*    */   default Optional<Bundle> getBundle(Class<?> classFromBundle) {
/* 46 */     return Optional.empty();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\connect\FrameworkUtilHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */