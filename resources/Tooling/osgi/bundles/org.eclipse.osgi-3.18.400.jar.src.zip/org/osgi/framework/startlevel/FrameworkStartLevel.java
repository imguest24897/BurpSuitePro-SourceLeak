package org.osgi.framework.startlevel;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.framework.BundleReference;
import org.osgi.framework.FrameworkListener;

@ProviderType
public interface FrameworkStartLevel extends BundleReference {
  int getStartLevel();
  
  void setStartLevel(int paramInt, FrameworkListener... paramVarArgs);
  
  int getInitialBundleStartLevel();
  
  void setInitialBundleStartLevel(int paramInt);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\startlevel\FrameworkStartLevel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */