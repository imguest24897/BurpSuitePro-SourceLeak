package org.osgi.framework;

public interface Configurable {
  Object getConfigurationObject();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\Configurable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */