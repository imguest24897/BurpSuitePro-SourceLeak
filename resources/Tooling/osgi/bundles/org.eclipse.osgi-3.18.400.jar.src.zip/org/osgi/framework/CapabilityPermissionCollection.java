/*     */ package org.osgi.framework;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.ObjectStreamField;
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class CapabilityPermissionCollection
/*     */   extends PermissionCollection
/*     */ {
/*     */   static final long serialVersionUID = -615322242639008920L;
/* 604 */   private Map<String, CapabilityPermission> permissions = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean all_allowed = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, CapabilityPermission> filterPermissions;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Permission permission) {
/* 619 */     if (!(permission instanceof CapabilityPermission)) {
/* 620 */       throw new IllegalArgumentException("invalid permission: " + permission);
/*     */     }
/* 622 */     if (isReadOnly()) {
/* 623 */       throw new SecurityException("attempt to add a Permission to a readonly PermissionCollection");
/*     */     }
/*     */     
/* 626 */     CapabilityPermission cp = (CapabilityPermission)permission;
/* 627 */     if (cp.bundle != null) {
/* 628 */       throw new IllegalArgumentException("cannot add to collection: " + cp);
/*     */     }
/*     */     
/* 631 */     String name = cp.getName();
/* 632 */     Filter f = cp.filter;
/* 633 */     synchronized (this) {
/*     */       Map<String, CapabilityPermission> pc;
/*     */       
/* 636 */       if (f != null) {
/* 637 */         pc = this.filterPermissions;
/* 638 */         if (pc == null) {
/* 639 */           this.filterPermissions = pc = new HashMap<>();
/*     */         }
/*     */       } else {
/* 642 */         pc = this.permissions;
/*     */       } 
/* 644 */       CapabilityPermission existing = pc.get(name);
/*     */       
/* 646 */       if (existing != null) {
/* 647 */         int oldMask = existing.action_mask;
/* 648 */         int newMask = cp.action_mask;
/* 649 */         if (oldMask != newMask) {
/* 650 */           pc.put(name, new CapabilityPermission(name, oldMask | newMask));
/*     */         }
/*     */       } else {
/* 653 */         pc.put(name, cp);
/*     */       } 
/*     */       
/* 656 */       if (!this.all_allowed && 
/* 657 */         name.equals("*")) {
/* 658 */         this.all_allowed = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean implies(Permission permission) {
/*     */     Collection<CapabilityPermission> perms;
/* 674 */     if (!(permission instanceof CapabilityPermission)) {
/* 675 */       return false;
/*     */     }
/* 677 */     CapabilityPermission requested = (CapabilityPermission)permission;
/*     */     
/* 679 */     if (requested.filter != null) {
/* 680 */       return false;
/*     */     }
/*     */     
/* 683 */     String requestedName = requested.getName();
/* 684 */     int desired = requested.action_mask;
/* 685 */     int effective = 0;
/*     */ 
/*     */     
/* 688 */     synchronized (this) {
/* 689 */       Map<String, CapabilityPermission> pc = this.permissions;
/*     */ 
/*     */       
/* 692 */       if (this.all_allowed) {
/* 693 */         CapabilityPermission capabilityPermission = pc.get("*");
/* 694 */         if (capabilityPermission != null) {
/* 695 */           effective |= capabilityPermission.action_mask;
/* 696 */           if ((effective & desired) == desired) {
/* 697 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 706 */       CapabilityPermission cp = pc.get(requestedName);
/* 707 */       if (cp != null) {
/*     */         
/* 709 */         effective |= cp.action_mask;
/* 710 */         if ((effective & desired) == desired) {
/* 711 */           return true;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 716 */       int offset = requestedName.length() - 1; int last;
/* 717 */       while ((last = requestedName.lastIndexOf('.', offset)) != -1) {
/* 718 */         requestedName = String.valueOf(requestedName.substring(0, last + 1)) + "*";
/* 719 */         cp = pc.get(requestedName);
/* 720 */         if (cp != null) {
/* 721 */           effective |= cp.action_mask;
/* 722 */           if ((effective & desired) == desired) {
/* 723 */             return true;
/*     */           }
/*     */         } 
/* 726 */         offset = last - 1;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 732 */       pc = this.filterPermissions;
/* 733 */       if (pc == null) {
/* 734 */         return false;
/*     */       }
/* 736 */       perms = pc.values();
/*     */     } 
/*     */     
/* 739 */     for (CapabilityPermission perm : perms) {
/* 740 */       if (perm.implies0(requested, effective)) {
/* 741 */         return true;
/*     */       }
/*     */     } 
/* 744 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Enumeration<Permission> elements() {
/* 755 */     List<Permission> all = new ArrayList<>(this.permissions.values());
/* 756 */     Map<String, CapabilityPermission> pc = this.filterPermissions;
/* 757 */     if (pc != null) {
/* 758 */       all.addAll(pc.values());
/*     */     }
/* 760 */     return Collections.enumeration(all);
/*     */   }
/*     */ 
/*     */   
/* 764 */   private static final ObjectStreamField[] serialPersistentFields = new ObjectStreamField[] { new ObjectStreamField("permissions", HashMap.class), new ObjectStreamField("all_allowed", boolean.class), 
/* 765 */       new ObjectStreamField("filterPermissions", HashMap.class) };
/*     */   
/*     */   private synchronized void writeObject(ObjectOutputStream out) throws IOException {
/* 768 */     ObjectOutputStream.PutField pfields = out.putFields();
/* 769 */     pfields.put("permissions", this.permissions);
/* 770 */     pfields.put("all_allowed", this.all_allowed);
/* 771 */     pfields.put("filterPermissions", this.filterPermissions);
/* 772 */     out.writeFields();
/*     */   }
/*     */   
/*     */   private synchronized void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 776 */     ObjectInputStream.GetField gfields = in.readFields();
/*     */     
/* 778 */     HashMap<String, CapabilityPermission> p = (HashMap<String, CapabilityPermission>)gfields.get("permissions", (Object)null);
/* 779 */     this.permissions = p;
/* 780 */     this.all_allowed = gfields.get("all_allowed", false);
/*     */     
/* 782 */     HashMap<String, CapabilityPermission> fp = (HashMap<String, CapabilityPermission>)gfields.get("filterPermissions", (Object)null);
/* 783 */     this.filterPermissions = fp;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\CapabilityPermissionCollection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */