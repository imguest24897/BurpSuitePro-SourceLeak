package org.osgi.framework.dto;

import org.osgi.dto.DTO;

public class BundleDTO extends DTO {
  public long id;
  
  public long lastModified;
  
  public int state;
  
  public String symbolicName;
  
  public String version;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\dto\BundleDTO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */