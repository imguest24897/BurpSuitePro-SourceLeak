/*     */ package org.osgi.framework;
/*     */ 
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VersionRange
/*     */ {
/*     */   public static final char LEFT_OPEN = '(';
/*     */   public static final char LEFT_CLOSED = '[';
/*     */   public static final char RIGHT_OPEN = ')';
/*     */   public static final char RIGHT_CLOSED = ']';
/*     */   private final boolean leftClosed;
/*     */   private final Version left;
/*     */   private final Version right;
/*     */   private final boolean rightClosed;
/*     */   private final boolean empty;
/*     */   private transient String versionRangeString;
/*     */   private transient int hash;
/*     */   private static final String LEFT_OPEN_DELIMITER = "(";
/*     */   private static final String LEFT_CLOSED_DELIMITER = "[";
/*     */   private static final String LEFT_DELIMITERS = "[(";
/*     */   private static final String RIGHT_OPEN_DELIMITER = ")";
/*     */   private static final String RIGHT_CLOSED_DELIMITER = "]";
/*     */   private static final String RIGHT_DELIMITERS = ")]";
/*     */   private static final String ENDPOINT_DELIMITER = ",";
/*     */   
/*     */   public VersionRange(char leftType, Version leftEndpoint, Version rightEndpoint, char rightType) {
/*  94 */     if (leftType != '[' && leftType != '(') {
/*  95 */       throw new IllegalArgumentException("invalid leftType \"" + leftType + "\"");
/*     */     }
/*  97 */     if (rightType != ')' && rightType != ']') {
/*  98 */       throw new IllegalArgumentException("invalid rightType \"" + rightType + "\"");
/*     */     }
/* 100 */     if (leftEndpoint == null) {
/* 101 */       throw new IllegalArgumentException("null leftEndpoint argument");
/*     */     }
/* 103 */     this.leftClosed = (leftType == '[');
/* 104 */     this.rightClosed = (rightType == ']');
/* 105 */     this.left = leftEndpoint;
/* 106 */     this.right = rightEndpoint;
/* 107 */     this.empty = isEmpty0();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VersionRange(String range) {
/*     */     boolean closedLeft, closedRight;
/*     */     Version endpointLeft, endpointRight;
/*     */     try {
/* 137 */       StringTokenizer st = new StringTokenizer(range, "[(", true);
/* 138 */       String token = st.nextToken().trim();
/* 139 */       if (token.length() == 0) {
/* 140 */         token = st.nextToken();
/*     */       }
/* 142 */       closedLeft = "[".equals(token);
/* 143 */       if (!closedLeft && !"(".equals(token)) {
/*     */         
/* 145 */         if (st.hasMoreTokens()) {
/* 146 */           throw new IllegalArgumentException("invalid range \"" + range + "\": invalid format");
/*     */         }
/* 148 */         this.leftClosed = true;
/* 149 */         this.rightClosed = false;
/* 150 */         this.left = parseVersion(token, range);
/* 151 */         this.right = null;
/* 152 */         this.empty = false;
/*     */         return;
/*     */       } 
/* 155 */       String version = st.nextToken(",");
/* 156 */       endpointLeft = parseVersion(version, range);
/* 157 */       token = st.nextToken();
/* 158 */       version = st.nextToken(")]");
/* 159 */       token = st.nextToken();
/* 160 */       closedRight = "]".equals(token);
/* 161 */       if (!closedRight && !")".equals(token)) {
/* 162 */         throw new IllegalArgumentException("invalid range \"" + range + "\": invalid format");
/*     */       }
/* 164 */       endpointRight = parseVersion(version, range);
/*     */       
/* 166 */       if (st.hasMoreTokens()) {
/* 167 */         token = st.nextToken("").trim();
/* 168 */         if (token.length() != 0) {
/* 169 */           throw new IllegalArgumentException("invalid range \"" + range + "\": invalid format");
/*     */         }
/*     */       } 
/* 172 */     } catch (NoSuchElementException e) {
/* 173 */       throw new IllegalArgumentException(
/* 174 */           "invalid range \"" + range + "\": invalid format", e);
/*     */     } 
/*     */     
/* 177 */     this.leftClosed = closedLeft;
/* 178 */     this.rightClosed = closedRight;
/* 179 */     this.left = endpointLeft;
/* 180 */     this.right = endpointRight;
/* 181 */     this.empty = isEmpty0();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Version parseVersion(String version, String range) {
/*     */     try {
/* 193 */       return Version.valueOf(version);
/* 194 */     } catch (IllegalArgumentException e) {
/* 195 */       throw new IllegalArgumentException(
/* 196 */           "invalid range \"" + range + "\": " + e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Version getLeft() {
/* 206 */     return this.left;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Version getRight() {
/* 216 */     return this.right;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char getLeftType() {
/* 226 */     return this.leftClosed ? '[' : '(';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char getRightType() {
/* 236 */     return this.rightClosed ? ']' : ')';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean includes(Version version) {
/* 247 */     if (this.empty) {
/* 248 */       return false;
/*     */     }
/* 250 */     if (this.left.compareTo(version) >= (this.leftClosed ? 1 : 0)) {
/* 251 */       return false;
/*     */     }
/* 253 */     if (this.right == null) {
/* 254 */       return true;
/*     */     }
/* 256 */     return (this.right.compareTo(version) >= (this.rightClosed ? 0 : 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VersionRange intersection(VersionRange... ranges) {
/* 269 */     if (ranges == null || ranges.length == 0) {
/* 270 */       return this;
/*     */     }
/*     */     
/* 273 */     boolean closedLeft = this.leftClosed;
/* 274 */     boolean closedRight = this.rightClosed;
/* 275 */     Version endpointLeft = this.left;
/* 276 */     Version endpointRight = this.right; byte b; int i;
/*     */     VersionRange[] arrayOfVersionRange;
/* 278 */     for (i = (arrayOfVersionRange = ranges).length, b = 0; b < i; ) { VersionRange range = arrayOfVersionRange[b];
/* 279 */       int comparison = endpointLeft.compareTo(range.left);
/* 280 */       if (comparison == 0) {
/* 281 */         closedLeft = (closedLeft && range.leftClosed);
/*     */       }
/* 283 */       else if (comparison < 0) {
/* 284 */         endpointLeft = range.left;
/* 285 */         closedLeft = range.leftClosed;
/*     */       } 
/*     */       
/* 288 */       if (range.right != null) {
/* 289 */         if (endpointRight == null) {
/* 290 */           endpointRight = range.right;
/* 291 */           closedRight = range.rightClosed;
/*     */         } else {
/* 293 */           comparison = endpointRight.compareTo(range.right);
/* 294 */           if (comparison == 0) {
/* 295 */             closedRight = (closedRight && range.rightClosed);
/*     */           }
/* 297 */           else if (comparison > 0) {
/* 298 */             endpointRight = range.right;
/* 299 */             closedRight = range.rightClosed;
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/*     */       b++; }
/*     */     
/* 306 */     return new VersionRange(closedLeft ? 91 : 40, endpointLeft, endpointRight, closedRight ? 93 : 41);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 317 */     return this.empty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isEmpty0() {
/* 327 */     if (this.right == null) {
/* 328 */       return false;
/*     */     }
/* 330 */     int comparison = this.left.compareTo(this.right);
/* 331 */     if (comparison == 0) {
/* 332 */       return !(this.leftClosed && this.rightClosed);
/*     */     }
/* 334 */     return (comparison > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExact() {
/* 344 */     if (this.empty || this.right == null) {
/* 345 */       return false;
/*     */     }
/* 347 */     if (this.leftClosed) {
/* 348 */       if (this.rightClosed)
/*     */       {
/* 350 */         return this.left.equals(this.right);
/*     */       }
/*     */       
/* 353 */       Version adjacent1 = new Version(this.left.getMajor(), this.left.getMinor(), this.left.getMicro(), String.valueOf(this.left.getQualifier()) + "-");
/* 354 */       return (adjacent1.compareTo(this.right) >= 0);
/*     */     } 
/*     */     
/* 357 */     if (this.rightClosed) {
/*     */       
/* 359 */       Version adjacent1 = new Version(this.left.getMajor(), this.left.getMinor(), this.left.getMicro(), String.valueOf(this.left.getQualifier()) + "-");
/* 360 */       return adjacent1.equals(this.right);
/*     */     } 
/*     */     
/* 363 */     Version adjacent2 = new Version(this.left.getMajor(), this.left.getMinor(), this.left.getMicro(), String.valueOf(this.left.getQualifier()) + "--");
/* 364 */     return (adjacent2.compareTo(this.right) >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 380 */     String s = this.versionRangeString;
/* 381 */     if (s != null) {
/* 382 */       return s;
/*     */     }
/* 384 */     String leftVersion = this.left.toString();
/* 385 */     if (this.right == null) {
/* 386 */       StringBuilder stringBuilder = new StringBuilder(leftVersion.length() + 1);
/* 387 */       stringBuilder.append(this.left.toString0());
/* 388 */       return this.versionRangeString = stringBuilder.toString();
/*     */     } 
/* 390 */     String rightVerion = this.right.toString();
/* 391 */     StringBuilder result = new StringBuilder(
/* 392 */         leftVersion.length() + rightVerion.length() + 5);
/* 393 */     result.append(this.leftClosed ? 91 : 40);
/* 394 */     result.append(this.left.toString0());
/* 395 */     result.append(",");
/* 396 */     result.append(this.right.toString0());
/* 397 */     result.append(this.rightClosed ? 93 : 41);
/* 398 */     return this.versionRangeString = result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 408 */     int h = this.hash;
/* 409 */     if (h != 0) {
/* 410 */       return h;
/*     */     }
/* 412 */     if (this.empty) {
/* 413 */       return this.hash = 31;
/*     */     }
/* 415 */     h = 31 + (this.leftClosed ? 7 : 5);
/* 416 */     h = 31 * h + this.left.hashCode();
/* 417 */     if (this.right != null) {
/* 418 */       h = 31 * h + this.right.hashCode();
/* 419 */       h = 31 * h + (this.rightClosed ? 7 : 5);
/*     */     } 
/* 421 */     return this.hash = h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 438 */     if (object == this) {
/* 439 */       return true;
/*     */     }
/* 441 */     if (!(object instanceof VersionRange)) {
/* 442 */       return false;
/*     */     }
/* 444 */     VersionRange other = (VersionRange)object;
/* 445 */     if (this.empty && other.empty) {
/* 446 */       return true;
/*     */     }
/* 448 */     if (this.right == null) {
/* 449 */       return (this.leftClosed == other.leftClosed && other.right == null && this.left.equals(other.left));
/*     */     }
/* 451 */     return (this.leftClosed == other.leftClosed && this.rightClosed == other.rightClosed && this.left.equals(other.left) && this.right.equals(other.right));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toFilterString(String attributeName) {
/* 468 */     if (attributeName.length() == 0)
/* 469 */       throw new IllegalArgumentException("invalid attributeName \"" + attributeName + "\"");  byte b; int i;
/*     */     char[] arrayOfChar;
/* 471 */     for (i = (arrayOfChar = attributeName.toCharArray()).length, b = 0; b < i; ) { char ch = arrayOfChar[b];
/* 472 */       if (ch == '=' || ch == '>' || ch == '<' || ch == '~' || ch == '(' || ch == ')') {
/* 473 */         throw new IllegalArgumentException("invalid attributeName \"" + attributeName + "\"");
/*     */       }
/*     */       b++; }
/*     */     
/* 477 */     StringBuilder result = new StringBuilder(128);
/* 478 */     boolean needPresence = (!this.leftClosed && (this.right == null || !this.rightClosed));
/* 479 */     boolean multipleTerms = !(!needPresence && this.right == null);
/* 480 */     if (multipleTerms) {
/* 481 */       result.append("(&");
/*     */     }
/* 483 */     if (needPresence) {
/* 484 */       result.append('(');
/* 485 */       result.append(attributeName);
/* 486 */       result.append("=*)");
/*     */     } 
/* 488 */     if (this.leftClosed) {
/* 489 */       result.append('(');
/* 490 */       result.append(attributeName);
/* 491 */       result.append(">=");
/* 492 */       result.append(this.left.toString0());
/* 493 */       result.append(')');
/*     */     } else {
/* 495 */       result.append("(!(");
/* 496 */       result.append(attributeName);
/* 497 */       result.append("<=");
/* 498 */       result.append(this.left.toString0());
/* 499 */       result.append("))");
/*     */     } 
/* 501 */     if (this.right != null) {
/* 502 */       if (this.rightClosed) {
/* 503 */         result.append('(');
/* 504 */         result.append(attributeName);
/* 505 */         result.append("<=");
/* 506 */         result.append(this.right.toString0());
/* 507 */         result.append(')');
/*     */       } else {
/* 509 */         result.append("(!(");
/* 510 */         result.append(attributeName);
/* 511 */         result.append(">=");
/* 512 */         result.append(this.right.toString0());
/* 513 */         result.append("))");
/*     */       } 
/*     */     }
/* 516 */     if (multipleTerms) {
/* 517 */       result.append(')');
/*     */     }
/*     */     
/* 520 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VersionRange valueOf(String range) {
/* 540 */     return new VersionRange(range);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\VersionRange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */