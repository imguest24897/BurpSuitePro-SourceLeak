package org.osgi.framework;

import java.util.Dictionary;
import java.util.Map;
import org.osgi.annotation.versioning.ProviderType;

@ProviderType
public interface Filter {
  boolean match(ServiceReference<?> paramServiceReference);
  
  boolean match(Dictionary<String, ?> paramDictionary);
  
  String toString();
  
  boolean equals(Object paramObject);
  
  int hashCode();
  
  boolean matchCase(Dictionary<String, ?> paramDictionary);
  
  boolean matches(Map<String, ?> paramMap);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\Filter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */