package org.osgi.framework.hooks.service;

import java.util.Collection;
import org.osgi.annotation.versioning.ConsumerType;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

@ConsumerType
public interface FindHook {
  void find(BundleContext paramBundleContext, String paramString1, String paramString2, boolean paramBoolean, Collection<ServiceReference<?>> paramCollection);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\hooks\service\FindHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */