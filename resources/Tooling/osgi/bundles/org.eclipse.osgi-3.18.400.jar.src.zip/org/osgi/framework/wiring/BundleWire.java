package org.osgi.framework.wiring;

import org.osgi.annotation.versioning.ProviderType;
import org.osgi.resource.Capability;
import org.osgi.resource.Requirement;
import org.osgi.resource.Resource;
import org.osgi.resource.Wire;

@ProviderType
public interface BundleWire extends Wire {
  BundleCapability getCapability();
  
  BundleRequirement getRequirement();
  
  BundleWiring getProviderWiring();
  
  BundleWiring getRequirerWiring();
  
  BundleRevision getProvider();
  
  BundleRevision getRequirer();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\wiring\BundleWire.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */