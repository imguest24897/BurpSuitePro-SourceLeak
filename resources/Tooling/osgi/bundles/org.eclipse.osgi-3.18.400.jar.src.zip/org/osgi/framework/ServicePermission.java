/*     */ package org.osgi.framework;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.NotSerializableException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.security.AccessController;
/*     */ import java.security.BasicPermission;
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ServicePermission
/*     */   extends BasicPermission
/*     */ {
/*     */   static final long serialVersionUID = -7662148639076511574L;
/*     */   public static final String GET = "get";
/*     */   public static final String REGISTER = "register";
/*     */   private static final int ACTION_GET = 1;
/*     */   private static final int ACTION_REGISTER = 2;
/*     */   private static final int ACTION_ALL = 3;
/*     */   static final int ACTION_NONE = 0;
/*     */   transient int action_mask;
/*  83 */   private volatile String actions = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final transient ServiceReference<?> service;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final transient String[] objectClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   transient Filter filter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile transient Map<String, Object> properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient boolean wildcard;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient String prefix;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServicePermission(String name, String actions) {
/* 172 */     this(name, parseActions(actions));
/* 173 */     if (this.filter != null && (this.action_mask & 0x3) != 1) {
/* 174 */       throw new IllegalArgumentException("invalid action string for filter expression");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ServicePermission(ServiceReference<?> reference, String actions) {
/* 191 */     super(createName(reference));
/* 192 */     setTransients(null, parseActions(actions));
/* 193 */     this.service = reference;
/* 194 */     this.objectClass = (String[])reference.getProperty("objectClass");
/* 195 */     if ((this.action_mask & 0x3) != 1) {
/* 196 */       throw new IllegalArgumentException("invalid action string");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String createName(ServiceReference<?> reference) {
/* 207 */     if (reference == null) {
/* 208 */       throw new IllegalArgumentException("reference must not be null");
/*     */     }
/* 210 */     StringBuilder sb = new StringBuilder("(service.id=");
/* 211 */     sb.append(reference.getProperty("service.id"));
/* 212 */     sb.append(")");
/* 213 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ServicePermission(String name, int mask) {
/* 223 */     super(name);
/* 224 */     setTransients(parseFilter(name), mask);
/* 225 */     this.service = null;
/* 226 */     this.objectClass = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setTransients(Filter f, int mask) {
/* 235 */     if (mask == 0 || (mask & 0x3) != mask) {
/* 236 */       throw new IllegalArgumentException("invalid action string");
/*     */     }
/* 238 */     this.action_mask = mask;
/* 239 */     this.filter = f;
/* 240 */     if (f == null) {
/* 241 */       String name = getName();
/* 242 */       int l = name.length();
/*     */       
/* 244 */       this.wildcard = (name.charAt(l - 1) == '*' && (l == 1 || name.charAt(l - 2) == '.'));
/* 245 */       if (this.wildcard && l > 1) {
/* 246 */         this.prefix = name.substring(0, l - 1);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int parseActions(String actions) {
/* 258 */     boolean seencomma = false;
/*     */     
/* 260 */     int mask = 0;
/*     */     
/* 262 */     if (actions == null) {
/* 263 */       return mask;
/*     */     }
/*     */     
/* 266 */     char[] a = actions.toCharArray();
/*     */     
/* 268 */     int i = a.length - 1;
/* 269 */     if (i < 0) {
/* 270 */       return mask;
/*     */     }
/* 272 */     while (i != -1) {
/*     */       int matchlen;
/*     */       
/*     */       char c;
/* 276 */       while (i != -1 && ((c = a[i]) == ' ' || c == '\r' || c == '\n' || c == '\f' || c == '\t')) {
/* 277 */         i--;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 282 */       if (i >= 2 && (a[i - 2] == 'g' || a[i - 2] == 'G') && (
/* 283 */         a[i - 1] == 'e' || a[i - 1] == 'E') && (
/* 284 */         a[i] == 't' || a[i] == 'T')) {
/* 285 */         matchlen = 3;
/* 286 */         mask |= 0x1;
/*     */       
/*     */       }
/* 289 */       else if (i >= 7 && (a[i - 7] == 'r' || a[i - 7] == 'R') && (
/* 290 */         a[i - 6] == 'e' || a[i - 6] == 'E') && (
/* 291 */         a[i - 5] == 'g' || a[i - 5] == 'G') && (
/* 292 */         a[i - 4] == 'i' || a[i - 4] == 'I') && (
/* 293 */         a[i - 3] == 's' || a[i - 3] == 'S') && (
/* 294 */         a[i - 2] == 't' || a[i - 2] == 'T') && (
/* 295 */         a[i - 1] == 'e' || a[i - 1] == 'E') && (
/* 296 */         a[i] == 'r' || a[i] == 'R')) {
/* 297 */         matchlen = 8;
/* 298 */         mask |= 0x2;
/*     */       }
/*     */       else {
/*     */         
/* 302 */         throw new IllegalArgumentException("invalid permission: " + actions);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 307 */       seencomma = false;
/* 308 */       while (i >= matchlen && !seencomma) {
/* 309 */         switch (a[i - matchlen]) {
/*     */           case ',':
/* 311 */             seencomma = true;
/*     */             break;
/*     */           case '\t':
/*     */           case '\n':
/*     */           case '\f':
/*     */           case '\r':
/*     */           case ' ':
/*     */             break;
/*     */           default:
/* 320 */             throw new IllegalArgumentException("invalid permission: " + actions);
/*     */         } 
/* 322 */         i--;
/*     */       } 
/*     */ 
/*     */       
/* 326 */       i -= matchlen;
/*     */     } 
/*     */     
/* 329 */     if (seencomma) {
/* 330 */       throw new IllegalArgumentException("invalid permission: " + actions);
/*     */     }
/*     */     
/* 333 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Filter parseFilter(String filterString) {
/* 345 */     filterString = filterString.trim();
/* 346 */     if (filterString.charAt(0) != '(') {
/* 347 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 351 */       return FrameworkUtil.createFilter(filterString);
/* 352 */     } catch (InvalidSyntaxException e) {
/* 353 */       throw new IllegalArgumentException("invalid filter", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean implies(Permission p) {
/* 367 */     if (!(p instanceof ServicePermission)) {
/* 368 */       return false;
/*     */     }
/* 370 */     ServicePermission requested = (ServicePermission)p;
/* 371 */     if (this.service != null) {
/* 372 */       return false;
/*     */     }
/*     */     
/* 375 */     if (requested.filter != null) {
/* 376 */       return false;
/*     */     }
/* 378 */     return implies0(requested, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean implies0(ServicePermission requested, int effective) {
/* 394 */     effective |= this.action_mask;
/* 395 */     int desired = requested.action_mask;
/* 396 */     if ((effective & desired) != desired) {
/* 397 */       return false;
/*     */     }
/*     */     
/* 400 */     if (this.wildcard && this.prefix == null) {
/* 401 */       return true;
/*     */     }
/*     */     
/* 404 */     Filter f = this.filter;
/* 405 */     if (f != null) {
/* 406 */       return f.matches(requested.getProperties());
/*     */     }
/*     */     
/* 409 */     String[] requestedNames = requested.objectClass;
/* 410 */     if (requestedNames == null) {
/* 411 */       return super.implies(requested);
/*     */     }
/*     */     
/* 414 */     if (this.wildcard) {
/* 415 */       int pl = this.prefix.length();
/* 416 */       for (int i = 0, l = requestedNames.length; i < l; i++) {
/* 417 */         String requestedName = requestedNames[i];
/* 418 */         if (requestedName.length() > pl && requestedName.startsWith(this.prefix)) {
/* 419 */           return true;
/*     */         }
/*     */       } 
/*     */     } else {
/* 423 */       String name = getName();
/* 424 */       for (int i = 0, l = requestedNames.length; i < l; i++) {
/* 425 */         if (requestedNames[i].equals(name)) {
/* 426 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 430 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getActions() {
/* 442 */     String result = this.actions;
/* 443 */     if (result == null) {
/* 444 */       StringBuilder sb = new StringBuilder();
/* 445 */       boolean comma = false;
/*     */       
/* 447 */       int mask = this.action_mask;
/* 448 */       if ((mask & 0x1) == 1) {
/* 449 */         sb.append("get");
/* 450 */         comma = true;
/*     */       } 
/*     */       
/* 453 */       if ((mask & 0x2) == 2) {
/* 454 */         if (comma)
/* 455 */           sb.append(','); 
/* 456 */         sb.append("register");
/*     */       } 
/*     */       
/* 459 */       this.actions = result = sb.toString();
/*     */     } 
/*     */     
/* 462 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PermissionCollection newPermissionCollection() {
/* 474 */     return new ServicePermissionCollection();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 490 */     if (obj == this) {
/* 491 */       return true;
/*     */     }
/*     */     
/* 494 */     if (!(obj instanceof ServicePermission)) {
/* 495 */       return false;
/*     */     }
/*     */     
/* 498 */     ServicePermission sp = (ServicePermission)obj;
/*     */     
/* 500 */     return (this.action_mask == sp.action_mask && getName().equals(sp.getName()) && (this.service == sp.service || (this.service != null && this.service.compareTo(sp.service) == 0)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 510 */     int h = 527 + getName().hashCode();
/* 511 */     h = 31 * h + getActions().hashCode();
/* 512 */     if (this.service != null) {
/* 513 */       h = 31 * h + this.service.hashCode();
/*     */     }
/* 515 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void writeObject(ObjectOutputStream s) throws IOException {
/* 523 */     if (this.service != null) {
/* 524 */       throw new NotSerializableException("cannot serialize");
/*     */     }
/*     */ 
/*     */     
/* 528 */     if (this.actions == null)
/* 529 */       getActions(); 
/* 530 */     s.defaultWriteObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void readObject(ObjectInputStream s) throws IOException, ClassNotFoundException {
/* 539 */     s.defaultReadObject();
/* 540 */     setTransients(parseFilter(getName()), parseActions(this.actions));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Object> getProperties() {
/* 550 */     Map<String, Object> result = this.properties;
/* 551 */     if (result != null) {
/* 552 */       return result;
/*     */     }
/* 554 */     if (this.service == null) {
/* 555 */       result = new HashMap<>(1);
/* 556 */       result.put("objectClass", new String[] { getName() });
/* 557 */       return this.properties = result;
/*     */     } 
/* 559 */     final Map<String, Object> props = new HashMap<>(4);
/* 560 */     final Bundle bundle = this.service.getBundle();
/* 561 */     if (bundle != null) {
/* 562 */       AccessController.doPrivileged(new PrivilegedAction<Void>()
/*     */           {
/*     */             public Void run() {
/* 565 */               props.put("id", Long.valueOf(bundle.getBundleId()));
/* 566 */               props.put("location", bundle.getLocation());
/* 567 */               String name = bundle.getSymbolicName();
/* 568 */               if (name != null) {
/* 569 */                 props.put("name", name);
/*     */               }
/* 571 */               SignerProperty signer = new SignerProperty(bundle);
/* 572 */               if (signer.isBundleSigned()) {
/* 573 */                 props.put("signer", signer);
/*     */               }
/* 575 */               return null;
/*     */             }
/*     */           });
/*     */     }
/* 579 */     return this.properties = new Properties(props, this.service);
/*     */   }
/*     */   
/*     */   private static final class Properties extends AbstractMap<String, Object> {
/*     */     private final Map<String, Object> properties;
/*     */     private final ServiceReference<?> service;
/*     */     private volatile transient Set<Map.Entry<String, Object>> entries;
/*     */     
/*     */     Properties(Map<String, Object> properties, ServiceReference<?> service) {
/* 588 */       this.properties = properties;
/* 589 */       this.service = service;
/* 590 */       this.entries = null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object get(Object k) {
/* 595 */       if (!(k instanceof String)) {
/* 596 */         return null;
/*     */       }
/* 598 */       String key = (String)k;
/* 599 */       if (key.charAt(0) == '@') {
/* 600 */         return this.service.getProperty(key.substring(1));
/*     */       }
/* 602 */       Object value = this.properties.get(key);
/* 603 */       if (value != null) {
/* 604 */         return value;
/*     */       }
/* 606 */       return this.service.getProperty(key);
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<Map.Entry<String, Object>> entrySet() {
/* 611 */       if (this.entries != null) {
/* 612 */         return this.entries;
/*     */       }
/* 614 */       Set<Map.Entry<String, Object>> all = new HashSet<>(this.properties.entrySet()); byte b; int i; String[] arrayOfString;
/* 615 */       for (i = (arrayOfString = this.service.getPropertyKeys()).length, b = 0; b < i; ) { String k, key = arrayOfString[b];
/* 616 */         Iterator<String> iterator = this.properties.keySet().iterator(); do { if (!iterator.hasNext())
/*     */           
/*     */           { 
/*     */ 
/*     */             
/* 621 */             all.add(new Entry(key, this.service.getProperty(key))); break; }  k = iterator.next(); }
/*     */         while (!key.equalsIgnoreCase(k)); b++; }
/* 623 */        return this.entries = Collections.unmodifiableSet(all);
/*     */     }
/*     */     
/*     */     private static final class Entry implements Map.Entry<String, Object> {
/*     */       private final String k;
/*     */       private final Object v;
/*     */       
/*     */       Entry(String key, Object value) {
/* 631 */         this.k = key;
/* 632 */         this.v = value;
/*     */       }
/*     */ 
/*     */       
/*     */       public String getKey() {
/* 637 */         return this.k;
/*     */       }
/*     */ 
/*     */       
/*     */       public Object getValue() {
/* 642 */         return this.v;
/*     */       }
/*     */ 
/*     */       
/*     */       public Object setValue(Object value) {
/* 647 */         throw new UnsupportedOperationException();
/*     */       }
/*     */ 
/*     */       
/*     */       public String toString() {
/* 652 */         return String.valueOf(this.k) + "=" + this.v;
/*     */       }
/*     */ 
/*     */       
/*     */       public int hashCode() {
/* 657 */         return ((this.k == null) ? 0 : this.k.hashCode()) ^ ((this.v == null) ? 0 : this.v.hashCode());
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean equals(Object obj) {
/* 662 */         if (obj == this) {
/* 663 */           return true;
/*     */         }
/* 665 */         if (!(obj instanceof Map.Entry)) {
/* 666 */           return false;
/*     */         }
/* 668 */         Map.Entry<?, ?> e = (Map.Entry<?, ?>)obj;
/* 669 */         Object key = e.getKey();
/* 670 */         if (this.k == key || (this.k != null && this.k.equals(key))) {
/* 671 */           Object value = e.getValue();
/* 672 */           if (this.v == value || (this.v != null && this.v.equals(value))) {
/* 673 */             return true;
/*     */           }
/*     */         } 
/* 676 */         return false;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\framework\ServicePermission.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */