/*     */ package org.osgi.dto;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DTO
/*     */ {
/*     */   private static final int MAX_LENGTH = 100;
/*     */   
/*     */   public String toString() {
/*  56 */     return appendValue(new StringBuilder(), 
/*  57 */         new IdentityHashMap<>(), "#", this).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static StringBuilder appendDTO(StringBuilder result, Map<Object, String> objectRefs, String refpath, DTO dto) {
/*  74 */     result.append('{');
/*  75 */     String delim = ""; byte b; int i; Field[] arrayOfField;
/*  76 */     for (i = (arrayOfField = dto.getClass().getFields()).length, b = 0; b < i; ) { Field field = arrayOfField[b];
/*  77 */       if (!Modifier.isStatic(field.getModifiers())) {
/*     */ 
/*     */         
/*  80 */         result.append(delim);
/*  81 */         String name = field.getName();
/*  82 */         appendString(result, name);
/*  83 */         result.append(':');
/*  84 */         Object value = null;
/*     */         try {
/*  86 */           value = field.get(dto);
/*  87 */         } catch (IllegalAccessException illegalAccessException) {}
/*     */ 
/*     */         
/*  90 */         appendValue(result, objectRefs, String.valueOf(refpath) + "/" + name, value);
/*  91 */         delim = ", ";
/*     */       }  b++; }
/*  93 */      result.append('}');
/*  94 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static StringBuilder appendValue(StringBuilder result, Map<Object, String> objectRefs, String refpath, Object value) {
/* 115 */     if (value == null) {
/* 116 */       return result.append("null");
/*     */     }
/*     */     
/* 119 */     if (value instanceof String || value instanceof Character) {
/* 120 */       return appendString(result, compress(value.toString()));
/*     */     }
/* 122 */     if (value instanceof Number || value instanceof Boolean) {
/* 123 */       return result.append(value.toString());
/*     */     }
/* 125 */     if (value instanceof Enum) {
/* 126 */       return appendString(result, ((Enum)value).name());
/*     */     }
/* 128 */     if ("org.osgi.framework.Version".equals(value.getClass().getName())) {
/* 129 */       return appendString(result, value.toString());
/*     */     }
/*     */ 
/*     */     
/* 133 */     String path = objectRefs.get(value);
/* 134 */     if (path != null) {
/* 135 */       result.append("{\"$ref\":");
/* 136 */       appendString(result, path);
/* 137 */       result.append('}');
/* 138 */       return result;
/*     */     } 
/* 140 */     objectRefs.put(value, refpath);
/*     */     
/* 142 */     if (value instanceof DTO) {
/* 143 */       return appendDTO(result, objectRefs, refpath, (DTO)value);
/*     */     }
/* 145 */     if (value instanceof Map) {
/* 146 */       return appendMap(result, objectRefs, refpath, (Map<?, ?>)value);
/*     */     }
/* 148 */     if (value instanceof java.util.List || value instanceof java.util.Set) {
/* 149 */       return appendIterable(result, objectRefs, refpath, 
/* 150 */           (Iterable)value);
/*     */     }
/* 152 */     if (value.getClass().isArray()) {
/* 153 */       return appendArray(result, objectRefs, refpath, value);
/*     */     }
/* 155 */     return appendString(result, compress(value.toString()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static StringBuilder appendArray(StringBuilder result, Map<Object, String> objectRefs, String refpath, Object array) {
/* 172 */     result.append('[');
/* 173 */     int length = Array.getLength(array);
/* 174 */     for (int i = 0; i < length; i++) {
/* 175 */       if (i > 0) {
/* 176 */         result.append(',');
/*     */       }
/* 178 */       appendValue(result, objectRefs, String.valueOf(refpath) + "/" + i, 
/* 179 */           Array.get(array, i));
/*     */     } 
/* 181 */     result.append(']');
/* 182 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static StringBuilder appendIterable(StringBuilder result, Map<Object, String> objectRefs, String refpath, Iterable<?> iterable) {
/* 200 */     result.append('[');
/* 201 */     int i = 0;
/* 202 */     for (Object item : iterable) {
/* 203 */       if (i > 0) {
/* 204 */         result.append(',');
/*     */       }
/* 206 */       appendValue(result, objectRefs, String.valueOf(refpath) + "/" + i, item);
/* 207 */       i++;
/*     */     } 
/* 209 */     result.append(']');
/* 210 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static StringBuilder appendMap(StringBuilder result, Map<Object, String> objectRefs, String refpath, Map<?, ?> map) {
/* 227 */     result.append('{');
/* 228 */     String delim = "";
/* 229 */     for (Map.Entry<?, ?> entry : map.entrySet()) {
/* 230 */       result.append(delim);
/* 231 */       String name = String.valueOf(entry.getKey());
/* 232 */       appendString(result, name);
/* 233 */       result.append(':');
/* 234 */       Object value = entry.getValue();
/* 235 */       appendValue(result, objectRefs, String.valueOf(refpath) + "/" + name, value);
/* 236 */       delim = ", ";
/*     */     } 
/* 238 */     result.append('}');
/* 239 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static StringBuilder appendString(StringBuilder result, CharSequence string) {
/* 251 */     result.append('"');
/* 252 */     int i = result.length();
/* 253 */     result.append(string);
/* 254 */     while (i < result.length()) {
/* 255 */       char c = result.charAt(i);
/* 256 */       if (c == '"' || c == '\\') {
/* 257 */         result.insert(i, '\\');
/* 258 */         i += 2;
/*     */         continue;
/*     */       } 
/* 261 */       if (c < ' ') {
/* 262 */         result.insert(i + 1, Integer.toHexString(c | 0x10000));
/* 263 */         result.replace(i, i + 2, "\\u");
/* 264 */         i += 6;
/*     */         continue;
/*     */       } 
/* 267 */       i++;
/*     */     } 
/* 269 */     result.append('"');
/* 270 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static CharSequence compress(CharSequence in) {
/* 281 */     int length = in.length();
/* 282 */     if (length <= 100) {
/* 283 */       return in;
/*     */     }
/* 285 */     StringBuilder result = (new StringBuilder(100))
/* 286 */       .append(in, 0, 47)
/* 287 */       .append('.')
/* 288 */       .append('.')
/* 289 */       .append('.')
/* 290 */       .append(in, length - 50, length);
/* 291 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\osgi\dto\DTO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */