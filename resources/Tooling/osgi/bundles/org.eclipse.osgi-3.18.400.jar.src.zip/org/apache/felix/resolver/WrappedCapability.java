/*     */ package org.apache.felix.resolver;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.osgi.resource.Capability;
/*     */ import org.osgi.resource.Resource;
/*     */ import org.osgi.service.resolver.HostedCapability;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WrappedCapability
/*     */   implements HostedCapability
/*     */ {
/*     */   private final Resource m_host;
/*     */   private final Capability m_cap;
/*     */   private final Map<String, Object> m_augmentedAttrs;
/*     */   
/*     */   public WrappedCapability(Resource host, Capability cap) {
/*  34 */     this.m_host = host;
/*  35 */     this.m_cap = cap;
/*  36 */     if ("osgi.content".equals(this.m_cap.getNamespace())) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  41 */       Map<String, Object> augmentedDirs = new HashMap<>(this.m_cap.getAttributes());
/*  42 */       Object wrapperUrl = augmentedDirs.get("url");
/*  43 */       wrapperUrl = "wrapper:" + wrapperUrl;
/*  44 */       augmentedDirs.put("url", wrapperUrl);
/*  45 */       this.m_augmentedAttrs = Collections.unmodifiableMap(augmentedDirs);
/*     */     } else {
/*  47 */       this.m_augmentedAttrs = this.m_cap.getAttributes();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  54 */     if (obj == null)
/*     */     {
/*  56 */       return false;
/*     */     }
/*  58 */     if (getClass() != obj.getClass())
/*     */     {
/*  60 */       return false;
/*     */     }
/*  62 */     WrappedCapability other = (WrappedCapability)obj;
/*  63 */     if (this.m_host != other.m_host && (this.m_host == null || !this.m_host.equals(other.m_host)))
/*     */     {
/*  65 */       return false;
/*     */     }
/*  67 */     if (this.m_cap != other.m_cap && (this.m_cap == null || !this.m_cap.equals(other.m_cap)))
/*     */     {
/*  69 */       return false;
/*     */     }
/*  71 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  77 */     int hash = 7;
/*  78 */     hash = 37 * hash + ((this.m_host != null) ? this.m_host.hashCode() : 0);
/*  79 */     hash = 37 * hash + ((this.m_cap != null) ? this.m_cap.hashCode() : 0);
/*  80 */     return hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public Capability getDeclaredCapability() {
/*  85 */     return this.m_cap;
/*     */   }
/*     */ 
/*     */   
/*     */   public Resource getResource() {
/*  90 */     return this.m_host;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getNamespace() {
/*  95 */     return this.m_cap.getNamespace();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getDirectives() {
/* 100 */     return this.m_cap.getDirectives();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> getAttributes() {
/* 105 */     return this.m_augmentedAttrs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 117 */     if (this.m_host == null)
/*     */     {
/* 119 */       return getAttributes().toString();
/*     */     }
/* 121 */     if (getNamespace().equals("osgi.wiring.package"))
/*     */     {
/* 123 */       return "[" + this.m_host + "] " + 
/* 124 */         getNamespace() + 
/* 125 */         "; " + 
/* 126 */         getAttributes().get("osgi.wiring.package");
/*     */     }
/* 128 */     return "[" + this.m_host + "] " + getNamespace() + "; " + getAttributes();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolver\WrappedCapability.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */