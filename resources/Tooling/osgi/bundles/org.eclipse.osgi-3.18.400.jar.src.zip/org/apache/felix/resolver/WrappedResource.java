/*     */ package org.apache.felix.resolver;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.osgi.resource.Capability;
/*     */ import org.osgi.resource.Requirement;
/*     */ import org.osgi.resource.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WrappedResource
/*     */   implements Resource
/*     */ {
/*     */   private final Resource m_host;
/*     */   private final List<Resource> m_fragments;
/*     */   private final List<Capability> m_cachedCapabilities;
/*     */   private final List<Requirement> m_cachedRequirements;
/*     */   
/*     */   public WrappedResource(Resource host, List<Resource> fragments) {
/*  37 */     this.m_host = host;
/*  38 */     this.m_fragments = fragments;
/*     */ 
/*     */     
/*  41 */     List<Capability> caps = new ArrayList<>();
/*  42 */     for (Capability cap : this.m_host.getCapabilities(null))
/*     */     {
/*  44 */       caps.add(new WrappedCapability(this, cap));
/*     */     }
/*     */ 
/*     */     
/*  48 */     if (this.m_fragments != null)
/*     */     {
/*  50 */       for (Resource fragment : this.m_fragments) {
/*     */         
/*  52 */         for (Capability cap : fragment.getCapabilities(null))
/*     */         {
/*  54 */           caps.add(new WrappedCapability(this, cap));
/*     */         }
/*     */       } 
/*     */     }
/*  58 */     this.m_cachedCapabilities = Collections.unmodifiableList(caps);
/*     */ 
/*     */     
/*  61 */     List<Requirement> reqs = new ArrayList<>();
/*  62 */     for (Requirement req : this.m_host.getRequirements(null))
/*     */     {
/*  64 */       reqs.add(new WrappedRequirement(this, req));
/*     */     }
/*     */ 
/*     */     
/*  68 */     if (this.m_fragments != null)
/*     */     {
/*  70 */       for (Resource fragment : this.m_fragments) {
/*     */         
/*  72 */         for (Requirement req : fragment.getRequirements(null)) {
/*     */ 
/*     */ 
/*     */           
/*  76 */           if (!req.getNamespace().equals("osgi.wiring.host") && 
/*  77 */             !req.getNamespace().equals(
/*  78 */               "osgi.ee"))
/*     */           {
/*  80 */             reqs.add(new WrappedRequirement(this, req));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*  85 */     this.m_cachedRequirements = Collections.unmodifiableList(reqs);
/*     */   }
/*     */ 
/*     */   
/*     */   public Resource getDeclaredResource() {
/*  90 */     return this.m_host;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Resource> getFragments() {
/*  95 */     return this.m_fragments;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Capability> getCapabilities(String namespace) {
/* 100 */     if (namespace != null) {
/* 101 */       List<Capability> filtered = new ArrayList<>();
/* 102 */       for (Capability capability : this.m_cachedCapabilities) {
/* 103 */         if (namespace.equals(capability.getNamespace())) {
/* 104 */           filtered.add(capability);
/*     */         }
/*     */       } 
/* 107 */       return Collections.unmodifiableList(filtered);
/*     */     } 
/* 109 */     return this.m_cachedCapabilities;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Requirement> getRequirements(String namespace) {
/* 114 */     if (namespace != null) {
/* 115 */       List<Requirement> filtered = new ArrayList<>();
/* 116 */       for (Requirement requirement : this.m_cachedRequirements) {
/* 117 */         if (namespace.equals(requirement.getNamespace())) {
/* 118 */           filtered.add(requirement);
/*     */         }
/*     */       } 
/* 121 */       return Collections.unmodifiableList(filtered);
/*     */     } 
/* 123 */     return this.m_cachedRequirements;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 128 */     return this.m_host.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolver\WrappedResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */