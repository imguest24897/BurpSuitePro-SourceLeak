/*     */ package org.apache.felix.resolver.util;
/*     */ 
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayMap<K, V>
/*     */   extends AbstractMap<K, V>
/*     */ {
/*     */   private Object[] table;
/*     */   private int size;
/*     */   protected transient Collection<V> values;
/*     */   
/*     */   public ArrayMap() {
/*  30 */     this(32);
/*     */   }
/*     */   
/*     */   public ArrayMap(int capacity) {
/*  34 */     this.table = new Object[capacity * 2];
/*  35 */     this.size = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public V get(Object key) {
/*  41 */     for (int i = 0, l = this.size << 1; i < l; i += 2) {
/*  42 */       if (key.equals(this.table[i])) {
/*  43 */         return (V)this.table[i + 1];
/*     */       }
/*     */     } 
/*  46 */     return null;
/*     */   }
/*     */   
/*     */   public V put(K key, V value) {
/*     */     int i;
/*     */     int l;
/*  52 */     for (i = 0, l = this.size << 1; i < l; i += 2) {
/*  53 */       if (key.equals(this.table[i])) {
/*  54 */         V old = (V)this.table[i + 1];
/*  55 */         this.table[i + 1] = value;
/*  56 */         return old;
/*     */       } 
/*     */     } 
/*  59 */     if (this.size * 2 == this.table.length) {
/*  60 */       Object[] n = new Object[this.table.length * 2];
/*  61 */       System.arraycopy(this.table, 0, n, 0, this.table.length);
/*  62 */       this.table = n;
/*     */     } 
/*  64 */     i = this.size++ << 1;
/*  65 */     this.table[i++] = key;
/*  66 */     this.table[i] = value;
/*  67 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public V getOrCompute(K key) {
/*  72 */     for (int i = 0, l = this.size << 1; i < l; i += 2) {
/*  73 */       if (key.equals(this.table[i])) {
/*  74 */         return (V)this.table[i + 1];
/*     */       }
/*     */     } 
/*  77 */     V v = compute(key);
/*  78 */     if (this.size << 1 == this.table.length) {
/*  79 */       Object[] n = new Object[this.table.length << 1];
/*  80 */       System.arraycopy(this.table, 0, n, 0, this.table.length);
/*  81 */       this.table = n;
/*     */     } 
/*  83 */     int j = this.size++ << 1;
/*  84 */     this.table[j++] = key;
/*  85 */     this.table[j] = v;
/*  86 */     return v;
/*     */   }
/*     */   
/*     */   protected V compute(K key) {
/*  90 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<V> values() {
/*  95 */     if (this.values == null) {
/*  96 */       this.values = new AbstractCollection<V>()
/*     */         {
/*     */           public Iterator<V> iterator() {
/*  99 */             return new Iterator<V>() {
/* 100 */                 int index = 0;
/*     */                 
/*     */                 public boolean hasNext() {
/* 103 */                   return (this.index < (ArrayMap.null.access$0(ArrayMap.null.this)).size);
/*     */                 }
/*     */ 
/*     */                 
/*     */                 public V next() {
/* 108 */                   if (this.index >= (ArrayMap.null.access$0(ArrayMap.null.this)).size) {
/* 109 */                     throw new NoSuchElementException();
/*     */                   }
/* 111 */                   return (V)(ArrayMap.null.access$0(ArrayMap.null.this)).table[(this.index++ << 1) + 1];
/*     */                 }
/*     */                 
/*     */                 public void remove() {
/* 115 */                   throw new UnsupportedOperationException();
/*     */                 }
/*     */               };
/*     */           }
/*     */ 
/*     */           
/*     */           public int size() {
/* 122 */             return ArrayMap.this.size;
/*     */           }
/*     */         };
/*     */     }
/* 126 */     return this.values;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/* 131 */     return new AbstractSet<Map.Entry<K, V>>()
/*     */       {
/*     */         public Iterator<Map.Entry<K, V>> iterator() {
/* 134 */           return new Iterator<Map.Entry<K, V>>() {
/* 135 */               ArrayMap.FastEntry<K, V> entry = new ArrayMap.FastEntry<>();
/* 136 */               int index = 0;
/*     */               
/*     */               public boolean hasNext() {
/* 139 */                 return (this.index < (ArrayMap.null.access$0(ArrayMap.null.this)).size);
/*     */               }
/*     */ 
/*     */               
/*     */               public ArrayMap.FastEntry<K, V> next() {
/* 144 */                 if (this.index >= (ArrayMap.null.access$0(ArrayMap.null.this)).size) {
/* 145 */                   throw new NoSuchElementException();
/*     */                 }
/* 147 */                 int i = this.index << 1;
/* 148 */                 this.entry.key = (K)(ArrayMap.null.access$0(ArrayMap.null.this)).table[i];
/* 149 */                 this.entry.value = (V)(ArrayMap.null.access$0(ArrayMap.null.this)).table[i + 1];
/* 150 */                 this.index++;
/* 151 */                 return this.entry;
/*     */               }
/*     */               
/*     */               public void remove() {
/* 155 */                 throw new UnsupportedOperationException();
/*     */               }
/*     */             };
/*     */         }
/*     */ 
/*     */         
/*     */         public int size() {
/* 162 */           return ArrayMap.this.size;
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   static class FastEntry<K, V> implements Map.Entry<K, V> {
/*     */     K key;
/*     */     V value;
/*     */     
/*     */     public K getKey() {
/* 172 */       return this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     public V getValue() {
/* 177 */       return this.value;
/*     */     }
/*     */     
/*     */     public V setValue(V value) {
/* 181 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolve\\util\ArrayMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */