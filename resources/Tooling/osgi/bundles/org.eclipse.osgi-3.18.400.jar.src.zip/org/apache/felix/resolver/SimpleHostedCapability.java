/*    */ package org.apache.felix.resolver;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.osgi.resource.Capability;
/*    */ import org.osgi.resource.Resource;
/*    */ import org.osgi.service.resolver.HostedCapability;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SimpleHostedCapability
/*    */   implements HostedCapability
/*    */ {
/*    */   private final Resource m_host;
/*    */   private final Capability m_cap;
/*    */   
/*    */   SimpleHostedCapability(Resource host, Capability cap) {
/* 33 */     this.m_host = host;
/* 34 */     this.m_cap = cap;
/*    */   }
/*    */ 
/*    */   
/*    */   public Resource getResource() {
/* 39 */     return this.m_host;
/*    */   }
/*    */ 
/*    */   
/*    */   public Capability getDeclaredCapability() {
/* 44 */     return this.m_cap;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getNamespace() {
/* 49 */     return this.m_cap.getNamespace();
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, String> getDirectives() {
/* 54 */     return this.m_cap.getDirectives();
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, Object> getAttributes() {
/* 59 */     return this.m_cap.getAttributes();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolver\SimpleHostedCapability.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */