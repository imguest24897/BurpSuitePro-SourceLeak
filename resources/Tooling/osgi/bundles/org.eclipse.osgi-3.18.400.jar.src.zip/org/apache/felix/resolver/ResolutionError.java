/*    */ package org.apache.felix.resolver;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import org.osgi.resource.Requirement;
/*    */ import org.osgi.service.resolver.ResolutionException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ResolutionError
/*    */ {
/*    */   public abstract String getMessage();
/*    */   
/*    */   public Collection<Requirement> getUnresolvedRequirements() {
/* 38 */     return Collections.emptyList();
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract ResolutionException toException();
/*    */   
/*    */   public String toString() {
/* 45 */     return getMessage();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolver\ResolutionError.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */