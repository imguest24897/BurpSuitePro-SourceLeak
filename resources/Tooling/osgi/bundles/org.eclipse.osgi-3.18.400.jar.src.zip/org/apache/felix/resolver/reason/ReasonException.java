/*    */ package org.apache.felix.resolver.reason;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.osgi.resource.Requirement;
/*    */ import org.osgi.service.resolver.ResolutionException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReasonException
/*    */   extends ResolutionException
/*    */ {
/*    */   private static final long serialVersionUID = -5276675175114379539L;
/*    */   private final Reason reason;
/*    */   
/*    */   public enum Reason
/*    */   {
/* 37 */     DynamicImport,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 48 */     FragmentNotSelected,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 61 */     MissingRequirement,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 71 */     UseConstraint;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReasonException(Reason reason, String message, Throwable cause, Collection<Requirement> unresolvedRequirements) {
/* 86 */     super(message, cause, unresolvedRequirements);
/* 87 */     this.reason = reason;
/*    */   }
/*    */   
/*    */   public Reason getReason() {
/* 91 */     return this.reason;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolver\reason\ReasonException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */