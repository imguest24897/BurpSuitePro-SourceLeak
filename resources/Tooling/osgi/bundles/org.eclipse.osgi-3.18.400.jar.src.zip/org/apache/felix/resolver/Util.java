/*     */ package org.apache.felix.resolver;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.osgi.framework.Version;
/*     */ import org.osgi.resource.Capability;
/*     */ import org.osgi.resource.Requirement;
/*     */ import org.osgi.resource.Resource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Util
/*     */ {
/*     */   public static String getSymbolicName(Resource resource) {
/*  36 */     List<Capability> caps = resource.getCapabilities(null);
/*  37 */     for (Capability cap : caps) {
/*     */       
/*  39 */       if (cap.getNamespace().equals("osgi.identity"))
/*     */       {
/*  41 */         return cap.getAttributes().get("osgi.identity").toString();
/*     */       }
/*     */     } 
/*  44 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Version getVersion(Resource resource) {
/*  49 */     List<Capability> caps = resource.getCapabilities(null);
/*  50 */     for (Capability cap : caps) {
/*     */       
/*  52 */       if (cap.getNamespace().equals("osgi.identity"))
/*     */       {
/*  54 */         return 
/*  55 */           (Version)cap.getAttributes().get("version");
/*     */       }
/*     */     } 
/*  58 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isFragment(Resource resource) {
/*  63 */     List<Capability> caps = resource.getCapabilities(null);
/*  64 */     for (Capability cap : caps) {
/*     */       
/*  66 */       if (cap.getNamespace().equals("osgi.identity")) {
/*     */         
/*  68 */         String type = 
/*  69 */           (String)cap.getAttributes().get("type");
/*  70 */         return (type != null && type.equals("osgi.fragment"));
/*     */       } 
/*     */     } 
/*  73 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isOptional(Requirement req) {
/*  78 */     String resolution = (String)req.getDirectives().get("resolution");
/*  79 */     return "optional".equalsIgnoreCase(resolution);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isMultiple(Requirement req) {
/*  84 */     return ("multiple".equals(req.getDirectives()
/*  85 */         .get("cardinality")) && !isDynamic(req));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isDynamic(Requirement req) {
/*  90 */     return "dynamic".equals(req.getDirectives()
/*  91 */         .get("resolution"));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isReexport(Requirement req) {
/*  96 */     return "reexport".equals(req.getDirectives()
/*  97 */         .get("visibility"));
/*     */   }
/*     */ 
/*     */   
/*     */   public static List<Requirement> getDynamicRequirements(List<Requirement> reqs) {
/* 102 */     List<Requirement> result = new ArrayList<>();
/* 103 */     if (reqs != null)
/*     */     {
/* 105 */       for (Requirement req : reqs) {
/*     */         
/* 107 */         String resolution = (String)req.getDirectives()
/* 108 */           .get("resolution");
/* 109 */         if (resolution != null && 
/* 110 */           resolution.equals("dynamic"))
/*     */         {
/* 112 */           result.add(req);
/*     */         }
/*     */       } 
/*     */     }
/* 116 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.osgi-3.18.400.jar!\org\apache\felix\resolver\Util.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */