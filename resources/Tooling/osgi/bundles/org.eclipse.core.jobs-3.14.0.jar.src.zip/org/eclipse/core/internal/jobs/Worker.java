/*     */ package org.eclipse.core.internal.jobs;
/*     */ 
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Worker
/*     */   extends Thread
/*     */ {
/*  28 */   private static int nextWorkerNumber = 0;
/*     */   private volatile InternalJob currentJob;
/*     */   private final WorkerPool pool;
/*     */   private final String generalName;
/*     */   
/*     */   public Worker(WorkerPool pool) {
/*  34 */     super("Worker-" + nextWorkerNumber++);
/*  35 */     this.generalName = getName();
/*  36 */     this.pool = pool;
/*     */ 
/*     */     
/*  39 */     setContextClassLoader(pool.defaultContextLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Job currentJob() {
/*  46 */     return (Job)this.currentJob;
/*     */   }
/*     */   
/*     */   private IStatus handleException(InternalJob job, Throwable t) {
/*  50 */     String message = NLS.bind(JobMessages.jobs_internalError, job.getName());
/*  51 */     return (IStatus)new Status(4, "org.eclipse.core.jobs", 2, message, t);
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/*  56 */     setNormPriority();
/*     */     try {
/*  58 */       while ((this.currentJob = this.pool.startJob(this)) != null) {
/*  59 */         IStatus result = Status.OK_STATUS;
/*  60 */         IProgressMonitor monitor = this.currentJob.getProgressMonitor();
/*     */         try {
/*  62 */           setName(getJobName());
/*  63 */           result = this.currentJob.run(monitor);
/*  64 */         } catch (OperationCanceledException operationCanceledException) {
/*  65 */           result = Status.CANCEL_STATUS; continue;
/*  66 */         } catch (ThreadDeath e) {
/*     */           
/*  68 */           result = handleException(this.currentJob, e);
/*  69 */           throw e;
/*  70 */         } catch (Exception|Error e) {
/*  71 */           result = handleException(this.currentJob, e); continue;
/*     */         } finally {
/*  73 */           if (result != Job.ASYNC_FINISH && monitor != null) {
/*  74 */             monitor.done();
/*     */           }
/*     */           
/*  77 */           Thread.interrupted();
/*     */           
/*  79 */           if (result == null) {
/*  80 */             String message = NLS.bind(JobMessages.jobs_returnNoStatus, this.currentJob.getClass().getName());
/*  81 */             result = handleException(this.currentJob, new NullPointerException(message));
/*     */           } 
/*  83 */           this.pool.endJob(this.currentJob, result);
/*  84 */           this.currentJob = null;
/*  85 */           setName(this.generalName);
/*     */           
/*  87 */           setNormPriority();
/*     */         } 
/*     */       } 
/*  90 */     } catch (Throwable t) {
/*  91 */       RuntimeLog.log((IStatus)new Status(4, "org.eclipse.core.jobs", 2, "Unhandled error", t));
/*     */     } finally {
/*  93 */       this.currentJob = null;
/*  94 */       this.pool.endWorker(this);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setNormPriority() {
/*  99 */     if (getPriority() != 5)
/*     */     {
/* 101 */       setPriority(5);
/*     */     }
/*     */   }
/*     */   
/*     */   private String getJobName() {
/* 106 */     String name = this.currentJob.getName();
/* 107 */     if (name == null || name.trim().isEmpty()) {
/* 108 */       name = "<unnamed job: " + this.currentJob.getClass().getName() + ">";
/*     */     }
/* 110 */     return String.valueOf(this.generalName) + ": " + name;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\Worker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */