/*     */ package org.eclipse.core.runtime.jobs;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultiRule
/*     */   implements ISchedulingRule
/*     */ {
/*     */   private ISchedulingRule[] rules;
/*     */   
/*     */   public static ISchedulingRule combine(ISchedulingRule[] ruleArray) {
/*  47 */     ISchedulingRule result = null; byte b; int i; ISchedulingRule[] arrayOfISchedulingRule;
/*  48 */     for (i = (arrayOfISchedulingRule = ruleArray).length, b = 0; b < i; ) { ISchedulingRule element = arrayOfISchedulingRule[b];
/*  49 */       if (element != null)
/*     */       {
/*  51 */         if (result == null) {
/*  52 */           result = element;
/*     */         } else {
/*     */           
/*  55 */           result = combine(result, element);
/*     */         }  }  b++; }
/*  57 */      return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ISchedulingRule combine(ISchedulingRule rule1, ISchedulingRule rule2) {
/*  71 */     if (rule1 == rule2)
/*  72 */       return rule1; 
/*  73 */     if (rule1 == null)
/*  74 */       return rule2; 
/*  75 */     if (rule2 == null)
/*  76 */       return rule1; 
/*  77 */     if (rule1.contains(rule2))
/*  78 */       return rule1; 
/*  79 */     if (rule2.contains(rule1))
/*  80 */       return rule2; 
/*  81 */     MultiRule result = new MultiRule();
/*  82 */     result.rules = new ISchedulingRule[] { rule1, rule2 };
/*     */     
/*  84 */     if (rule1 instanceof MultiRule || rule2 instanceof MultiRule)
/*  85 */       result.rules = flatten(result.rules); 
/*  86 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ISchedulingRule[] flatten(ISchedulingRule[] nestedRules) {
/*  94 */     ArrayList<ISchedulingRule> myRules = new ArrayList<>(nestedRules.length); byte b; int i; ISchedulingRule[] arrayOfISchedulingRule;
/*  95 */     for (i = (arrayOfISchedulingRule = nestedRules).length, b = 0; b < i; ) { ISchedulingRule nestedRule = arrayOfISchedulingRule[b];
/*  96 */       if (nestedRule instanceof MultiRule) {
/*  97 */         ISchedulingRule[] children = ((MultiRule)nestedRule).getChildren();
/*  98 */         myRules.addAll(Arrays.asList(children));
/*     */       } else {
/* 100 */         myRules.add(nestedRule);
/*     */       }  b++; }
/*     */     
/* 103 */     return myRules.<ISchedulingRule>toArray(new ISchedulingRule[myRules.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultiRule(ISchedulingRule[] nestedRules) {
/* 112 */     this.rules = flatten(nestedRules);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MultiRule() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule[] getChildren() {
/* 128 */     return (ISchedulingRule[])this.rules.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(ISchedulingRule rule) {
/* 133 */     if (this == rule)
/* 134 */       return true; 
/* 135 */     if (rule instanceof MultiRule) {
/* 136 */       ISchedulingRule[] otherRules = ((MultiRule)rule).getChildren(); byte b1; int j;
/*     */       ISchedulingRule[] arrayOfISchedulingRule1;
/* 138 */       for (j = (arrayOfISchedulingRule1 = otherRules).length, b1 = 0; b1 < j; ) { ISchedulingRule otherRule = arrayOfISchedulingRule1[b1];
/* 139 */         boolean found = false;
/* 140 */         for (int mine = 0; !found && mine < this.rules.length; mine++)
/* 141 */           found = this.rules[mine].contains(otherRule); 
/* 142 */         if (!found)
/* 143 */           return false;  b1++; }
/*     */       
/* 145 */       return true;
/*     */     }  byte b; int i; ISchedulingRule[] arrayOfISchedulingRule;
/* 147 */     for (i = (arrayOfISchedulingRule = this.rules).length, b = 0; b < i; ) { ISchedulingRule rule2 = arrayOfISchedulingRule[b];
/* 148 */       if (rule2.contains(rule))
/* 149 */         return true;  b++; }
/* 150 */      return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConflicting(ISchedulingRule rule) {
/* 155 */     if (this == rule)
/* 156 */       return true; 
/* 157 */     if (rule instanceof MultiRule)
/* 158 */     { ISchedulingRule[] otherRules = ((MultiRule)rule).getChildren(); byte b; int i; ISchedulingRule[] arrayOfISchedulingRule1;
/* 159 */       for (i = (arrayOfISchedulingRule1 = otherRules).length, b = 0; b < i; ) { ISchedulingRule otherRule = arrayOfISchedulingRule1[b]; byte b1; int j; ISchedulingRule[] arrayOfISchedulingRule;
/* 160 */         for (j = (arrayOfISchedulingRule = this.rules).length, b1 = 0; b1 < j; ) { ISchedulingRule rule2 = arrayOfISchedulingRule[b1];
/* 161 */           if (rule2.isConflicting(otherRule))
/* 162 */             return true;  b1++; }  b++; }
/*     */        }
/* 164 */     else { byte b; int i; ISchedulingRule[] arrayOfISchedulingRule; for (i = (arrayOfISchedulingRule = this.rules).length, b = 0; b < i; ) { ISchedulingRule rule3 = arrayOfISchedulingRule[b];
/* 165 */         if (rule3.isConflicting(rule))
/* 166 */           return true;  b++; }
/*     */        }
/* 168 */      return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 176 */     StringBuilder buffer = new StringBuilder();
/* 177 */     buffer.append("MultiRule[");
/* 178 */     int last = this.rules.length - 1;
/* 179 */     for (int i = 0; i < this.rules.length; i++) {
/* 180 */       buffer.append(this.rules[i]);
/* 181 */       if (i != last)
/* 182 */         buffer.append(','); 
/*     */     } 
/* 184 */     buffer.append(']');
/* 185 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\runtime\jobs\MultiRule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */