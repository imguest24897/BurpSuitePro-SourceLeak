package org.eclipse.core.runtime.jobs;

import org.eclipse.core.runtime.IStatus;

public interface IJobStatus extends IStatus {
  Job getJob();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\runtime\jobs\IJobStatus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */