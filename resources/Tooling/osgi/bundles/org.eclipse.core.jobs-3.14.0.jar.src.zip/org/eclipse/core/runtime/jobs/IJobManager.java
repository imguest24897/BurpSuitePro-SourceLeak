package org.eclipse.core.runtime.jobs;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;

public interface IJobManager {
  public static final String PROP_USE_DAEMON_THREADS = "eclipse.jobs.daemon";
  
  void addJobChangeListener(IJobChangeListener paramIJobChangeListener);
  
  void beginRule(ISchedulingRule paramISchedulingRule, IProgressMonitor paramIProgressMonitor);
  
  void cancel(Object paramObject);
  
  IProgressMonitor createProgressGroup();
  
  ISchedulingRule currentRule();
  
  Job currentJob();
  
  void endRule(ISchedulingRule paramISchedulingRule);
  
  Job[] find(Object paramObject);
  
  boolean isIdle();
  
  boolean isSuspended();
  
  void join(Object paramObject, IProgressMonitor paramIProgressMonitor) throws InterruptedException, OperationCanceledException;
  
  ILock newLock();
  
  void removeJobChangeListener(IJobChangeListener paramIJobChangeListener);
  
  @Deprecated
  void resume(ISchedulingRule paramISchedulingRule);
  
  void resume();
  
  void setLockListener(LockListener paramLockListener);
  
  void setProgressProvider(ProgressProvider paramProgressProvider);
  
  void suspend();
  
  @Deprecated
  void suspend(ISchedulingRule paramISchedulingRule, IProgressMonitor paramIProgressMonitor);
  
  void sleep(Object paramObject);
  
  void transferRule(ISchedulingRule paramISchedulingRule, Thread paramThread);
  
  void wakeUp(Object paramObject);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\runtime\jobs\IJobManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */