/*     */ package org.eclipse.core.internal.jobs;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import org.eclipse.osgi.service.debug.DebugOptionsListener;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.FrameworkUtil;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JobOSGiUtils
/*     */ {
/*  33 */   private ServiceRegistration<DebugOptionsListener> debugRegistration = null;
/*     */   
/*  35 */   private static final JobOSGiUtils singleton = new JobOSGiUtils();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JobOSGiUtils getDefault() {
/*  42 */     return singleton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void openServices() {
/*  53 */     BundleContext context = JobActivator.getContext();
/*  54 */     if (context == null) {
/*  55 */       if (JobManager.DEBUG) {
/*  56 */         JobMessages.message("JobsOSGiUtils called before plugin started");
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*  61 */     Hashtable<String, String> properties = new Hashtable<>(2);
/*  62 */     properties.put("listener.symbolic.name", "org.eclipse.core.jobs");
/*  63 */     this.debugRegistration = context.registerService(DebugOptionsListener.class, JobManager.getInstance(), properties);
/*     */   }
/*     */   
/*     */   void closeServices() {
/*  67 */     if (this.debugRegistration != null) {
/*  68 */       this.debugRegistration.unregister();
/*  69 */       this.debugRegistration = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBundleId(Object object) {
/*  78 */     if (object == null)
/*  79 */       return null; 
/*  80 */     Bundle source = FrameworkUtil.getBundle(object.getClass());
/*  81 */     if (source != null && source.getSymbolicName() != null)
/*  82 */       return source.getSymbolicName(); 
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean useDaemonThreads() {
/*  95 */     BundleContext context = JobActivator.getContext();
/*  96 */     if (context == null) {
/*     */       
/*  98 */       String str = System.getProperty("eclipse.jobs.daemon");
/*     */       
/* 100 */       if (str == null)
/* 101 */         return true; 
/* 102 */       return "true".equalsIgnoreCase(str);
/*     */     } 
/*     */     
/* 105 */     String value = context.getProperty("eclipse.jobs.daemon");
/*     */     
/* 107 */     if (value == null)
/* 108 */       return false; 
/* 109 */     return "true".equalsIgnoreCase(value);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\JobOSGiUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */