/*     */ package org.eclipse.core.internal.jobs;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Queue;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.jobs.ILock;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OrderedLock
/*     */   implements ILock, ISchedulingRule
/*     */ {
/*     */   private static final boolean DEBUG = false;
/*  47 */   private static int nextLockNumber = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile Thread currentOperationThread;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int depth;
/*     */ 
/*     */ 
/*     */   
/*     */   private final LockManager manager;
/*     */ 
/*     */ 
/*     */   
/*     */   private final int number;
/*     */ 
/*     */ 
/*     */   
/*  69 */   private final Queue<Semaphore> operations = new ArrayDeque<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OrderedLock(LockManager manager) {
/*  75 */     this.manager = manager;
/*  76 */     this.number = nextLockNumber++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void acquire() {
/*  84 */     boolean interrupted = false; while (true) { try {
/*     */         do {
/*     */         
/*  87 */         } while (!acquire(Long.MAX_VALUE));
/*     */         break;
/*  89 */       } catch (InterruptedException interruptedException) {
/*  90 */         interrupted = true;
/*     */       }  }
/*     */ 
/*     */     
/*  94 */     if (interrupted) {
/*  95 */       Thread.currentThread().interrupt();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean acquire(long delay) throws InterruptedException {
/* 100 */     if (Thread.interrupted()) {
/* 101 */       throw new InterruptedException();
/*     */     }
/* 103 */     if (delay <= 0L)
/* 104 */       return attempt(); 
/* 105 */     Semaphore semaphore = createSemaphore();
/* 106 */     if (semaphore == null) {
/* 107 */       return true;
/*     */     }
/*     */     
/* 110 */     boolean success = doAcquire(semaphore, delay);
/* 111 */     this.manager.resumeSuspendedLocks(Thread.currentThread());
/*     */ 
/*     */ 
/*     */     
/* 115 */     if (!success && Thread.interrupted())
/* 116 */       throw new InterruptedException(); 
/* 117 */     return success;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized boolean attempt() {
/* 127 */     if (this.currentOperationThread == Thread.currentThread() || (this.currentOperationThread == null && this.operations.isEmpty())) {
/* 128 */       this.depth++;
/* 129 */       setCurrentOperationThread(Thread.currentThread());
/* 130 */       return true;
/*     */     } 
/* 132 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(ISchedulingRule rule) {
/* 137 */     return (rule == this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized Semaphore createSemaphore() {
/* 146 */     return attempt() ? null : enqueue(new Semaphore(Thread.currentThread()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean doAcquire(Semaphore semaphore, long delay) {
/* 154 */     boolean success = false;
/*     */     
/* 156 */     if (this.manager.aboutToWait(this.currentOperationThread)) {
/*     */ 
/*     */ 
/*     */       
/* 160 */       removeFromQueue(semaphore);
/* 161 */       this.depth++;
/* 162 */       this.manager.addLockThread(this.currentOperationThread, this);
/* 163 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 168 */     semaphore = createSemaphore();
/* 169 */     if (semaphore == null)
/* 170 */       return true; 
/* 171 */     Thread currentThread = Thread.currentThread();
/* 172 */     this.manager.addLockWaitThread(currentThread, this);
/*     */     try {
/* 174 */       success = semaphore.acquire(delay);
/* 175 */     } catch (InterruptedException interruptedException) {
/*     */ 
/*     */ 
/*     */       
/* 179 */       currentThread.interrupt();
/*     */     } 
/* 181 */     return updateOperationQueue(semaphore, success);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void doRelease() {
/* 190 */     this.manager.aboutToRelease();
/* 191 */     this.depth = 0;
/* 192 */     Semaphore next = this.operations.peek();
/* 193 */     setCurrentOperationThread(null);
/* 194 */     if (next != null) {
/* 195 */       next.release();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized Semaphore enqueue(Semaphore newSemaphore) {
/* 203 */     Semaphore semaphore = this.operations.stream().filter(s -> s.equals(paramSemaphore1)).findAny().orElse(null);
/* 204 */     if (semaphore == null) {
/* 205 */       this.operations.offer(newSemaphore);
/* 206 */       return newSemaphore;
/*     */     } 
/* 208 */     return semaphore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int forceRelease() {
/* 216 */     int oldDepth = this.depth;
/* 217 */     doRelease();
/* 218 */     return oldDepth;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDepth() {
/* 223 */     return this.depth;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConflicting(ISchedulingRule rule) {
/* 228 */     return (rule == this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void release() {
/* 233 */     if (this.depth == 0) {
/*     */       return;
/*     */     }
/* 236 */     Assert.isTrue((this.depth >= 0), "Lock released too many times");
/* 237 */     if (--this.depth == 0) {
/* 238 */       doRelease();
/*     */     } else {
/* 240 */       this.manager.removeLockThread(this.currentOperationThread, this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void removeFromQueue(Semaphore semaphore) {
/* 249 */     this.operations.remove(semaphore);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setCurrentOperationThread(Thread newThread) {
/* 257 */     if (this.currentOperationThread != null && newThread == null)
/* 258 */       this.manager.removeLockThread(this.currentOperationThread, this); 
/* 259 */     this.currentOperationThread = newThread;
/* 260 */     if (this.currentOperationThread != null) {
/* 261 */       this.manager.addLockThread(this.currentOperationThread, this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDepth(int newDepth) {
/* 269 */     for (int i = this.depth; i < newDepth; i++) {
/* 270 */       this.manager.addLockThread(this.currentOperationThread, this);
/*     */     }
/* 272 */     this.depth = newDepth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 280 */     return "OrderedLock (" + this.number + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void updateCurrentOperation() {
/* 288 */     this.operations.poll();
/* 289 */     setCurrentOperationThread(Thread.currentThread());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized boolean updateOperationQueue(Semaphore semaphore, boolean acquired) {
/* 302 */     if (!acquired)
/* 303 */       acquired = semaphore.attempt(); 
/* 304 */     if (acquired) {
/* 305 */       this.depth++;
/* 306 */       updateCurrentOperation();
/*     */     } else {
/* 308 */       removeFromQueue(semaphore);
/* 309 */       this.manager.removeLockWaitThread(Thread.currentThread(), this);
/*     */     } 
/* 311 */     return acquired;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\OrderedLock.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */