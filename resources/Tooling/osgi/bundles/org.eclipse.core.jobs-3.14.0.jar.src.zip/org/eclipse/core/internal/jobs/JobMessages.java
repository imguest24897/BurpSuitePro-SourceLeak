/*    */ package org.eclipse.core.internal.jobs;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JobMessages
/*    */   extends NLS
/*    */ {
/*    */   private static final String BUNDLE_NAME = "org.eclipse.core.internal.jobs.messages";
/*    */   public static String jobs_blocked0;
/*    */   public static String jobs_blocked1;
/*    */   public static String jobs_internalError;
/*    */   public static String jobs_waitFamSub;
/*    */   public static String jobs_waitFamSubOne;
/*    */   public static String jobs_returnNoStatus;
/*    */   public static String meta_pluginProblems;
/*    */   
/*    */   static {
/* 38 */     reloadMessages();
/*    */   }
/*    */   
/*    */   public static void reloadMessages() {
/* 42 */     NLS.initializeMessages("org.eclipse.core.internal.jobs.messages", JobMessages.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void message(String message) {
/* 50 */     StringBuilder buffer = new StringBuilder();
/* 51 */     buffer.append(new Date(System.currentTimeMillis()));
/* 52 */     buffer.append(" - [");
/* 53 */     buffer.append(Thread.currentThread().getName());
/* 54 */     buffer.append("] ");
/* 55 */     buffer.append(message);
/* 56 */     System.out.println(buffer.toString());
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\JobMessages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */