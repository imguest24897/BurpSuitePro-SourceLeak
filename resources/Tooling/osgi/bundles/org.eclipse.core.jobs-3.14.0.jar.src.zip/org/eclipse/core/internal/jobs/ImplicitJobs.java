/*     */ package org.eclipse.core.internal.jobs;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ImplicitJobs
/*     */ {
/*  34 */   private ThreadJob jobCache = null;
/*     */ 
/*     */ 
/*     */   
/*     */   protected JobManager manager;
/*     */ 
/*     */   
/*  41 */   private final Set<ISchedulingRule> suspendedRules = new HashSet<>(20);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private final Map<Thread, ThreadJob> threadJobs = new HashMap<>(20);
/*     */   
/*     */   ImplicitJobs(JobManager manager) {
/*  51 */     this.manager = manager;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void begin(ISchedulingRule rule, IProgressMonitor monitor, boolean suspend) {
/*     */     ThreadJob threadJob;
/*  58 */     if (JobManager.DEBUG_BEGIN_END)
/*  59 */       JobManager.debug("Begin rule: " + rule); 
/*  60 */     Thread currentThread = Thread.currentThread();
/*     */     
/*  62 */     synchronized (this) {
/*  63 */       threadJob = this.threadJobs.get(currentThread);
/*  64 */       if (threadJob != null) {
/*     */         
/*  66 */         threadJob.push(rule);
/*     */         
/*     */         return;
/*     */       } 
/*  70 */       if (rule == null) {
/*     */         return;
/*     */       }
/*  73 */       Job realJob = this.manager.currentJob();
/*  74 */       if (realJob != null && realJob.getRule() != null) {
/*  75 */         threadJob = newThreadJob(realJob.getRule());
/*     */       } else {
/*  77 */         threadJob = newThreadJob(rule);
/*  78 */         threadJob.acquireRule = true;
/*     */       } 
/*     */       
/*  81 */       if (isSuspended(rule)) {
/*  82 */         threadJob.acquireRule = false;
/*     */       }
/*  84 */       threadJob.setRealJob(realJob);
/*  85 */       threadJob.setThread(currentThread);
/*     */     } 
/*     */     try {
/*  88 */       threadJob.push(rule);
/*     */       
/*  90 */       if (threadJob.acquireRule)
/*     */       {
/*  92 */         if (this.manager.runNow(threadJob, false) == null) {
/*  93 */           this.manager.getLockManager().addLockThread(Thread.currentThread(), rule);
/*     */         } else {
/*  95 */           threadJob = ThreadJob.joinRun(threadJob, monitor);
/*     */         }
/*     */       
/*     */       }
/*     */     } finally {
/*     */       
/* 101 */       synchronized (this) {
/* 102 */         this.threadJobs.put(currentThread, threadJob);
/* 103 */         if (suspend) {
/* 104 */           this.suspendedRules.add(rule);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void end(ISchedulingRule rule, boolean resume) {
/* 113 */     if (JobManager.DEBUG_BEGIN_END)
/* 114 */       JobManager.debug("End rule: " + rule); 
/* 115 */     ThreadJob threadJob = this.threadJobs.get(Thread.currentThread());
/* 116 */     if (threadJob == null) {
/* 117 */       Assert.isLegal((rule == null), "endRule without matching beginRule: " + rule);
/* 118 */     } else if (threadJob.pop(rule)) {
/* 119 */       endThreadJob(threadJob, resume, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void endJob(InternalJob lastJob) {
/*     */     Status status;
/* 129 */     Thread currentThread = Thread.currentThread();
/*     */     
/* 131 */     synchronized (this) {
/* 132 */       ThreadJob threadJob = this.threadJobs.get(currentThread);
/* 133 */       if (threadJob == null) {
/* 134 */         if (lastJob.getRule() != null)
/* 135 */           notifyWaitingThreadJobs(lastJob); 
/*     */         return;
/*     */       } 
/* 138 */       String msg = "Worker thread ended job: " + lastJob + ", but still holds rule: " + threadJob;
/* 139 */       status = new Status(4, "org.eclipse.core.jobs", 1, msg, new IllegalStateException(msg));
/*     */       
/* 141 */       endThreadJob(threadJob, false, true);
/*     */     } 
/*     */     try {
/* 144 */       RuntimeLog.log((IStatus)status);
/* 145 */     } catch (RuntimeException runtimeException) {
/*     */       
/* 147 */       System.err.println(status.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void endThreadJob(ThreadJob threadJob, boolean resume, boolean worker) {
/* 155 */     Thread currentThread = Thread.currentThread();
/*     */     
/* 157 */     this.threadJobs.remove(currentThread);
/* 158 */     ISchedulingRule rule = threadJob.getRule();
/* 159 */     if (resume && rule != null) {
/* 160 */       this.suspendedRules.remove(rule);
/*     */     }
/*     */     
/* 163 */     if (threadJob.acquireRule) {
/* 164 */       this.manager.getLockManager().removeLockThread(currentThread, rule);
/* 165 */       notifyWaitingThreadJobs((InternalJob)threadJob);
/*     */     } 
/*     */     
/* 168 */     if (threadJob.isRunning())
/* 169 */       this.manager.endJob((InternalJob)threadJob, Status.OK_STATUS, false, worker); 
/* 170 */     recycle(threadJob);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isSuspended(ISchedulingRule rule) {
/* 178 */     if (this.suspendedRules.isEmpty())
/* 179 */       return false; 
/* 180 */     for (ISchedulingRule iSchedulingRule : this.suspendedRules) {
/* 181 */       if (iSchedulingRule.contains(rule))
/* 182 */         return true; 
/* 183 */     }  return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ThreadJob newThreadJob(ISchedulingRule rule) {
/* 191 */     if (this.jobCache != null) {
/* 192 */       ThreadJob job = this.jobCache;
/*     */ 
/*     */ 
/*     */       
/* 196 */       job.internalSetRule(rule);
/* 197 */       job.acquireRule = job.isRunning = false;
/* 198 */       job.realJob = null;
/* 199 */       this.jobCache = null;
/* 200 */       return job;
/*     */     } 
/* 202 */     return new ThreadJob(rule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void notifyWaitingThreadJobs(InternalJob job) {
/* 211 */     synchronized (job.jobStateLock) {
/* 212 */       job.jobStateLock.notifyAll();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void recycle(ThreadJob job) {
/* 221 */     if (this.jobCache == null && job.recycle()) {
/* 222 */       this.jobCache = job;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void resume(ISchedulingRule rule) {
/* 231 */     end(rule, true);
/* 232 */     if (JobManager.DEBUG_BEGIN_END) {
/* 233 */       JobManager.debug("Resume rule: " + rule);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void suspend(ISchedulingRule rule, IProgressMonitor monitor) {
/* 242 */     if (JobManager.DEBUG_BEGIN_END) {
/* 243 */       JobManager.debug("Suspend rule: " + rule);
/*     */     }
/* 245 */     begin(rule, monitor, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void transfer(ISchedulingRule rule, Thread destinationThread) {
/* 253 */     if (rule == null)
/*     */       return; 
/* 255 */     Thread currentThread = Thread.currentThread();
/*     */     
/* 257 */     if (currentThread == destinationThread) {
/*     */       return;
/*     */     }
/* 260 */     ThreadJob target = this.threadJobs.get(destinationThread);
/* 261 */     Assert.isLegal((target == null), "Transfer rule to job that already owns a rule");
/*     */     
/* 263 */     ThreadJob source = this.threadJobs.get(currentThread);
/* 264 */     Assert.isNotNull(source, "transferRule without beginRule");
/* 265 */     Assert.isLegal((source.getRule() == rule), "transferred rule " + rule + " does not match beginRule: " + source.getRule());
/* 266 */     source.setThread(destinationThread);
/* 267 */     this.threadJobs.remove(currentThread);
/* 268 */     this.threadJobs.put(destinationThread, source);
/*     */     
/* 270 */     if (source.acquireRule) {
/* 271 */       this.manager.getLockManager().removeLockThread(currentThread, rule);
/* 272 */       this.manager.getLockManager().addLockThread(destinationThread, rule);
/*     */     } 
/*     */ 
/*     */     
/* 276 */     notifyWaitingThreadJobs((InternalJob)source);
/*     */   }
/*     */   
/*     */   synchronized void removeWaiting(ThreadJob threadJob) {
/* 280 */     synchronized (((InternalJob)threadJob).jobStateLock) {
/* 281 */       threadJob.isWaiting = false;
/* 282 */       notifyWaitingThreadJobs((InternalJob)threadJob);
/* 283 */       threadJob.setWaitQueueStamp(-1L);
/*     */     } 
/* 285 */     this.manager.dequeue(this.manager.waitingThreadJobs, (InternalJob)threadJob);
/*     */   }
/*     */   
/*     */   synchronized void addWaiting(ThreadJob threadJob) {
/* 289 */     synchronized (((InternalJob)threadJob).jobStateLock) {
/* 290 */       threadJob.isWaiting = true;
/* 291 */       notifyWaitingThreadJobs((InternalJob)threadJob);
/* 292 */       threadJob.setWaitQueueStamp(this.manager.getNextWaitQueueStamp());
/*     */     } 
/* 294 */     this.manager.enqueue(this.manager.waitingThreadJobs, (InternalJob)threadJob);
/*     */   }
/*     */   
/*     */   synchronized ThreadJob getThreadJob(Thread thread) {
/* 298 */     return this.threadJobs.get(thread);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\ImplicitJobs.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */