/*    */ package org.eclipse.core.internal.jobs;
/*    */ 
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.core.runtime.jobs.IJobStatus;
/*    */ import org.eclipse.core.runtime.jobs.Job;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JobStatus
/*    */   extends Status
/*    */   implements IJobStatus
/*    */ {
/*    */   private Job job;
/*    */   
/*    */   public JobStatus(int severity, Job job, String message) {
/* 33 */     super(severity, "org.eclipse.core.jobs", 1, message, null);
/* 34 */     this.job = job;
/*    */   }
/*    */ 
/*    */   
/*    */   public Job getJob() {
/* 39 */     return this.job;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\JobStatus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */