package org.eclipse.core.runtime.jobs;

public interface ILock {
  boolean acquire(long paramLong) throws InterruptedException;
  
  void acquire();
  
  int getDepth();
  
  void release();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\runtime\jobs\ILock.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */