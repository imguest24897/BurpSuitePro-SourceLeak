package org.eclipse.core.runtime.jobs;

public interface ISchedulableOperation {
  ISchedulingRule getSchedulingRule();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\runtime\jobs\ISchedulableOperation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */