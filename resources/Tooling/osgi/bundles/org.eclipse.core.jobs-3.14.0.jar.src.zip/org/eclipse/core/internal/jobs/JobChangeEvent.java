/*    */ package org.eclipse.core.internal.jobs;
/*    */ 
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ import org.eclipse.core.runtime.jobs.IJobChangeEvent;
/*    */ import org.eclipse.core.runtime.jobs.Job;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JobChangeEvent
/*    */   implements IJobChangeEvent
/*    */ {
/*    */   final Job job;
/*    */   final IStatus result;
/*    */   IStatus jobGroupResult;
/*    */   final long delay;
/*    */   final boolean reschedule;
/*    */   final JobListeners.IListenerDoit doit;
/*    */   
/*    */   JobChangeEvent(JobListeners.IListenerDoit doit, Job job) {
/* 51 */     this.doit = doit;
/* 52 */     this.job = job;
/*    */     
/* 54 */     this.result = null;
/* 55 */     this.jobGroupResult = null;
/* 56 */     this.reschedule = false;
/* 57 */     this.delay = -1L;
/*    */   }
/*    */   
/*    */   JobChangeEvent(JobListeners.IListenerDoit doit, Job job, IStatus result, boolean reschedule) {
/* 61 */     this.doit = doit;
/* 62 */     this.job = job;
/* 63 */     this.result = result;
/*    */     
/* 65 */     this.jobGroupResult = null;
/* 66 */     this.reschedule = reschedule;
/* 67 */     this.delay = -1L;
/*    */   }
/*    */   
/*    */   JobChangeEvent(JobListeners.IListenerDoit doit, Job job, long delay, boolean reschedule) {
/* 71 */     this.doit = doit;
/* 72 */     this.job = job;
/* 73 */     this.delay = delay;
/*    */     
/* 75 */     this.result = null;
/* 76 */     this.jobGroupResult = null;
/* 77 */     this.reschedule = reschedule;
/*    */   }
/*    */ 
/*    */   
/*    */   public long getDelay() {
/* 82 */     return this.delay;
/*    */   }
/*    */ 
/*    */   
/*    */   public Job getJob() {
/* 87 */     return this.job;
/*    */   }
/*    */ 
/*    */   
/*    */   public IStatus getResult() {
/* 92 */     return this.result;
/*    */   }
/*    */ 
/*    */   
/*    */   public IStatus getJobGroupResult() {
/* 97 */     return this.jobGroupResult;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\JobChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */