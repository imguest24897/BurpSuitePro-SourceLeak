/*     */ package org.eclipse.core.internal.jobs;
/*     */ 
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.management.ThreadInfo;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.ListenerList;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.IJobChangeEvent;
/*     */ import org.eclipse.core.runtime.jobs.IJobChangeListener;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JobListeners
/*     */ {
/*  35 */   private final IListenerDoit aboutToRun = IJobChangeListener::aboutToRun;
/*  36 */   private final IListenerDoit awake = IJobChangeListener::awake;
/*  37 */   private final IListenerDoit done = IJobChangeListener::done;
/*  38 */   private final IListenerDoit running = IJobChangeListener::running;
/*  39 */   private final IListenerDoit scheduled = IJobChangeListener::scheduled;
/*  40 */   private final IListenerDoit sleeping = IJobChangeListener::sleeping;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int DEFAULT_JOB_LISTENER_TIMEOUT = 3000;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public static volatile int jobListenerTimeout = 3000;
/*     */ 
/*     */ 
/*     */   
/*  54 */   protected final ListenerList<IJobChangeListener> global = new ListenerList(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void waitAndSendEvents(InternalJob job, boolean shouldSend) {
/*  63 */     boolean send = !(!shouldSend && !job.eventQueueLock.isHeldByCurrentThread());
/*     */ 
/*     */     
/*     */     while (true) {
/*  67 */       if (getJobListenerTimeout() == 0) {
/*     */         
/*  69 */         if (send) {
/*  70 */           sendEventsAsync(job);
/*     */         }
/*     */         return;
/*     */       } 
/*  74 */       int timeout = getJobListenerTimeout();
/*     */       try {
/*  76 */         if (job.eventQueueLock.tryLock(timeout, TimeUnit.MILLISECONDS)) {
/*  77 */           job.eventQueueThread.set(Thread.currentThread());
/*     */           try {
/*  79 */             if (send) {
/*  80 */               sendEventsAsync(job);
/*     */               
/*     */               return;
/*     */             } 
/*  84 */             if (job.eventQueue.isEmpty()) {
/*     */               return;
/*     */             }
/*     */           } finally {
/*  88 */             job.eventQueueThread.set(null);
/*  89 */             job.eventQueueLock.unlock();
/*     */           } 
/*     */           
/*  92 */           Thread.yield();
/*  93 */           Thread.onSpinWait();
/*     */           continue;
/*     */         } 
/*  96 */       } catch (InterruptedException interruptedException) {
/*     */         continue;
/*     */       } 
/*  99 */       Thread eventQueueThread = job.eventQueueThread.get();
/* 100 */       if (eventQueueThread != null) {
/* 101 */         setJobListenerTimeout(0);
/* 102 */         String msg = "IJobChangeListener timeout detected. Further calls to IJobChangeListener may occur in random order and join(family) can return too soon. IJobChangeListener should return within " + 
/* 103 */           timeout + 
/* 104 */           " ms. IJobChangeListener methods should not block. Possible deadlock.";
/* 105 */         MultiStatus status = new MultiStatus("org.eclipse.core.jobs", 2, msg, 
/* 106 */             new TimeoutException(msg));
/* 107 */         StringBuilder buf = new StringBuilder(
/* 108 */             "Thread that is running the IJobChangeListener: " + eventQueueThread.getName());
/* 109 */         buf.append(System.lineSeparator());
/*     */         try {
/* 111 */           StackTraceElement[] stackTrace = eventQueueThread.getStackTrace(); byte b; int i; StackTraceElement[] arrayOfStackTraceElement1;
/* 112 */           for (i = (arrayOfStackTraceElement1 = stackTrace).length, b = 0; b < i; ) { StackTraceElement stackTraceElement = arrayOfStackTraceElement1[b];
/* 113 */             buf.append('\t');
/* 114 */             buf.append("at ");
/* 115 */             buf.append(stackTraceElement);
/* 116 */             buf.append(System.lineSeparator()); b++; }
/*     */           
/* 118 */           buf.append(System.lineSeparator());
/* 119 */           buf.append("All thread infos: ");
/* 120 */           ThreadInfo[] infos = ManagementFactory.getThreadMXBean().dumpAllThreads(true, true);
/* 121 */           buf.append(System.lineSeparator()); ThreadInfo[] arrayOfThreadInfo1;
/* 122 */           for (int j = (arrayOfThreadInfo1 = infos).length; i < j; ) { ThreadInfo info = arrayOfThreadInfo1[i];
/* 123 */             buf.append(info); i++; }
/*     */         
/* 125 */         } catch (UnsupportedOperationException|SecurityException e) {
/*     */           
/* 127 */           buf.append(e);
/*     */         } 
/* 129 */         Status child = new Status(4, "org.eclipse.core.jobs", 2, buf.toString(), 
/* 130 */             null);
/* 131 */         status.add((IStatus)child);
/* 132 */         RuntimeLog.log((IStatus)status);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void sendEventsAsync(InternalJob job) {
/*     */     JobChangeEvent event;
/* 139 */     while ((event = job.eventQueue.poll()) != null) {
/* 140 */       sendEvent(event);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void sendEvent(JobChangeEvent event) {
/* 149 */     IListenerDoit doit = event.doit;
/*     */     
/* 151 */     for (IJobChangeListener listener : this.global) {
/*     */       try {
/* 153 */         doit.notify(listener, event);
/* 154 */       } catch (Throwable e) {
/* 155 */         handleException(listener, e);
/*     */       } 
/*     */     } 
/* 158 */     for (IJobChangeListener listener : event.getJob().getListeners()) {
/*     */       try {
/* 160 */         doit.notify(listener, event);
/* 161 */       } catch (Throwable e) {
/* 162 */         handleException(listener, e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void queueEvent(JobChangeEvent event) {
/* 169 */     ((InternalJob)event.job).eventQueue.offer(event);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleException(IJobChangeListener listener, Throwable e) {
/* 175 */     if (e instanceof org.eclipse.core.runtime.OperationCanceledException)
/*     */       return; 
/* 177 */     String pluginId = JobOSGiUtils.getDefault().getBundleId(listener);
/* 178 */     if (pluginId == null)
/* 179 */       pluginId = "org.eclipse.core.jobs"; 
/* 180 */     String message = NLS.bind(JobMessages.meta_pluginProblems, pluginId);
/* 181 */     RuntimeLog.log((IStatus)new Status(4, pluginId, 2, message, e));
/*     */   }
/*     */   
/*     */   public void add(IJobChangeListener listener) {
/* 185 */     this.global.add(listener);
/*     */   }
/*     */   
/*     */   public void remove(IJobChangeListener listener) {
/* 189 */     this.global.remove(listener);
/*     */   }
/*     */   
/*     */   public void queueAboutToRun(Job job) {
/* 193 */     queueEvent(new JobChangeEvent(this.aboutToRun, job));
/*     */   }
/*     */   
/*     */   public void queueAwake(Job job) {
/* 197 */     queueEvent(new JobChangeEvent(this.awake, job));
/*     */   }
/*     */   
/*     */   public void queueDone(Job job, IStatus result, boolean reschedule) {
/* 201 */     queueEvent(new JobChangeEvent(this.done, job, result, reschedule));
/*     */   }
/*     */   
/*     */   public void queueRunning(Job job) {
/* 205 */     queueEvent(new JobChangeEvent(this.running, job));
/*     */   }
/*     */   
/*     */   public void queueScheduled(Job job, long delay, boolean reschedule) {
/* 209 */     queueEvent(new JobChangeEvent(this.scheduled, job, delay, reschedule));
/*     */   }
/*     */   
/*     */   public void queueSleeping(Job job) {
/* 213 */     queueEvent(new JobChangeEvent(this.sleeping, job));
/*     */   }
/*     */   
/*     */   public static void resetJobListenerTimeout() {
/* 217 */     setJobListenerTimeout(3000);
/*     */   }
/*     */   
/*     */   public static int getJobListenerTimeout() {
/* 221 */     return jobListenerTimeout;
/*     */   }
/*     */   
/*     */   public static void setJobListenerTimeout(int jobListenerTimeout) {
/* 225 */     JobListeners.jobListenerTimeout = jobListenerTimeout;
/*     */   }
/*     */   
/*     */   static interface IListenerDoit {
/*     */     void notify(IJobChangeListener param1IJobChangeListener, IJobChangeEvent param1IJobChangeEvent);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\JobListeners.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */