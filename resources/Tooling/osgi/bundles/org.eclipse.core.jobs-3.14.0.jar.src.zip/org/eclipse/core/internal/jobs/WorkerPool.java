/*     */ package org.eclipse.core.internal.jobs;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WorkerPool
/*     */ {
/*     */   private static final int BEST_BEFORE = 60000;
/*     */   private static final int MIN_THREADS = 1;
/*     */   private static final int MAX_THREADS = 50;
/*  52 */   private int busyThreads = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ClassLoader defaultContextLoader;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isDaemon = false;
/*     */ 
/*     */ 
/*     */   
/*     */   private final JobManager manager;
/*     */ 
/*     */ 
/*     */   
/*  68 */   private int numThreads = 0;
/*     */ 
/*     */ 
/*     */   
/*  72 */   private int sleepingThreads = 0;
/*     */ 
/*     */ 
/*     */   
/*  76 */   private Worker[] threads = new Worker[10];
/*     */   
/*     */   protected WorkerPool(JobManager manager) {
/*  79 */     this.manager = manager;
/*  80 */     this.defaultContextLoader = Thread.currentThread().getContextClassLoader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void add(Worker worker) {
/*  87 */     int size = this.threads.length;
/*  88 */     if (this.numThreads + 1 > size) {
/*  89 */       Worker[] newThreads = new Worker[2 * size];
/*  90 */       System.arraycopy(this.threads, 0, newThreads, 0, size);
/*  91 */       this.threads = newThreads;
/*     */     } 
/*  93 */     this.threads[this.numThreads++] = worker;
/*     */   }
/*     */ 
/*     */   
/*     */   private synchronized void decrementBusyThreads() {
/*  98 */     if (--this.busyThreads < 0) {
/*  99 */       if (JobManager.DEBUG)
/* 100 */         Assert.isTrue(false, Integer.toString(this.busyThreads)); 
/* 101 */       this.busyThreads = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void endJob(InternalJob job, IStatus result) {
/*     */     try {
/* 113 */       if (job.getRule() != null && !(job instanceof ThreadJob))
/*     */       {
/* 115 */         this.manager.getLockManager().removeLockCompletely(Thread.currentThread(), job.getRule());
/*     */       }
/* 117 */       this.manager.endJob(job, result, true, false);
/*     */       
/* 119 */       this.manager.implicitJobs.endJob(job);
/*     */     } finally {
/* 121 */       decrementBusyThreads();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void endWorker(Worker worker) {
/* 130 */     if (remove(worker) && JobManager.DEBUG) {
/* 131 */       JobManager.debug("worker removed from pool: " + worker);
/*     */     }
/*     */   }
/*     */   
/*     */   private synchronized void incrementBusyThreads() {
/* 136 */     if (++this.busyThreads > this.numThreads) {
/* 137 */       if (JobManager.DEBUG)
/* 138 */         Assert.isTrue(false, String.valueOf(Integer.toString(this.busyThreads)) + ',' + this.numThreads); 
/* 139 */       this.busyThreads = this.numThreads;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void jobQueued() {
/* 149 */     if (this.sleepingThreads > 0) {
/* 150 */       notify();
/*     */       
/*     */       return;
/*     */     } 
/* 154 */     if (this.busyThreads >= this.numThreads) {
/* 155 */       Worker worker = new Worker(this);
/* 156 */       worker.setDaemon(this.isDaemon);
/* 157 */       add(worker);
/* 158 */       if (JobManager.DEBUG)
/* 159 */         JobManager.debug("worker added to pool: " + worker); 
/* 160 */       worker.start();
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized boolean remove(Worker worker) {
/* 170 */     for (int i = 0; i < this.threads.length; i++) {
/* 171 */       if (this.threads[i] == worker) {
/* 172 */         System.arraycopy(this.threads, i + 1, this.threads, i, this.numThreads - i - 1);
/* 173 */         this.threads[--this.numThreads] = null;
/* 174 */         return true;
/*     */       } 
/*     */     } 
/* 177 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setDaemon(boolean value) {
/* 184 */     this.isDaemon = value;
/*     */   }
/*     */   
/*     */   protected synchronized void shutdown() {
/* 188 */     notifyAll();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void sleep(long duration) {
/* 195 */     this.sleepingThreads++;
/* 196 */     this.busyThreads--;
/* 197 */     if (JobManager.DEBUG)
/* 198 */       JobManager.debug("worker sleeping for: " + duration + "ms"); 
/*     */     try {
/* 200 */       wait(duration);
/* 201 */     } catch (InterruptedException interruptedException) {
/* 202 */       if (JobManager.DEBUG)
/* 203 */         JobManager.debug("worker interrupted while waiting... :-|"); 
/*     */     } finally {
/* 205 */       this.sleepingThreads--;
/* 206 */       this.busyThreads++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InternalJob startJob(Worker worker) {
/*     */     boolean bool;
/* 216 */     synchronized (this) {
/* 217 */       if (!this.manager.isActive()) {
/*     */         
/* 219 */         endWorker(worker);
/* 220 */         return null;
/*     */       } 
/*     */       
/* 223 */       incrementBusyThreads();
/* 224 */       bool = true;
/*     */     } 
/* 226 */     Job job = null;
/*     */     
/* 228 */     try { job = this.manager.startJob(worker);
/*     */       
/* 230 */       long idleStart = this.manager.now();
/* 231 */       while (this.manager.isActive() && job == null) {
/* 232 */         long hint = this.manager.sleepHint();
/* 233 */         if (hint > 0L) {
/* 234 */           synchronized (this) {
/* 235 */             if (this.numThreads > 50) {
/* 236 */               endWorker(worker);
/* 237 */               decrementBusyThreads();
/* 238 */               bool = false;
/* 239 */               return null;
/*     */             } 
/*     */           } 
/* 242 */           sleep(Math.min(hint, 60000L));
/*     */         } 
/* 244 */         job = this.manager.startJob(worker);
/*     */ 
/*     */         
/* 247 */         synchronized (this) {
/* 248 */           if (job == null && this.manager.now() - idleStart > 60000L && this.numThreads - this.busyThreads > 1) {
/*     */             
/* 250 */             endWorker(worker);
/* 251 */             decrementBusyThreads();
/* 252 */             bool = false;
/* 253 */             return null;
/*     */           } 
/*     */         } 
/*     */         
/* 257 */         if (hint <= 0L && job == null) {
/* 258 */           sleep(50L);
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */       
/*     */        }
/*     */     
/*     */     finally
/*     */     
/*     */     { 
/*     */       
/* 273 */       if (job == null && bool)
/* 274 */         decrementBusyThreads();  }  if (job == null && bool) decrementBusyThreads();
/*     */     
/* 276 */     return (InternalJob)job;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\WorkerPool.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */