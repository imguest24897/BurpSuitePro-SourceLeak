/*     */ package org.eclipse.core.internal.jobs;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JobQueue
/*     */   implements Iterable<InternalJob>
/*     */ {
/*     */   protected final InternalJob dummy;
/*     */   private final boolean allowConflictOvertaking;
/*     */   private final boolean allowPriorityOvertaking;
/*     */   
/*     */   public JobQueue(boolean allowConflictOvertaking) {
/*  42 */     this(allowConflictOvertaking, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JobQueue(boolean allowConflictOvertaking, boolean allowPriorityOvertaking) {
/*  49 */     this.allowPriorityOvertaking = allowPriorityOvertaking;
/*     */     
/*  51 */     this.dummy = new InternalJob("Queue-Head")
/*     */       {
/*     */         public IStatus run(IProgressMonitor m) {
/*  54 */           return Status.OK_STATUS;
/*     */         }
/*     */       };
/*  57 */     this.dummy.setNext(this.dummy);
/*  58 */     this.dummy.setPrevious(this.dummy);
/*  59 */     this.allowConflictOvertaking = allowConflictOvertaking;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  66 */     this.dummy.setNext(this.dummy);
/*  67 */     this.dummy.setPrevious(this.dummy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InternalJob dequeue() {
/*  74 */     InternalJob toRemove = this.dummy.previous();
/*  75 */     if (toRemove == this.dummy)
/*  76 */       return null; 
/*  77 */     return toRemove.remove();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void enqueue(InternalJob newEntry) {
/*  85 */     Assert.isTrue((newEntry.next() == null));
/*  86 */     Assert.isTrue((newEntry.previous() == null));
/*  87 */     InternalJob tail = this.dummy.next();
/*     */     
/*  89 */     while (canOvertake(newEntry, tail)) {
/*  90 */       tail = tail.next();
/*     */     }
/*  92 */     InternalJob tailPrevious = tail.previous();
/*  93 */     newEntry.setNext(tail);
/*  94 */     newEntry.setPrevious(tailPrevious);
/*  95 */     tailPrevious.setNext(newEntry);
/*  96 */     tail.setPrevious(newEntry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean canOvertake(InternalJob newEntry, InternalJob queueEntry) {
/* 106 */     if (queueEntry == this.dummy) {
/* 107 */       return false;
/*     */     }
/* 109 */     if (newEntry.getWaitQueueStamp() > 0L && newEntry.getWaitQueueStamp() < queueEntry.getWaitQueueStamp()) {
/* 110 */       return true;
/*     */     }
/* 112 */     if (this.allowPriorityOvertaking && queueEntry.compareTo(newEntry) >= 0) {
/* 113 */       return false;
/*     */     }
/* 115 */     return !(!this.allowConflictOvertaking && newEntry.isConflicting(queueEntry));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(InternalJob toRemove) {
/* 122 */     toRemove.remove();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resort(InternalJob entry) {
/* 131 */     remove(entry);
/* 132 */     enqueue(entry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 139 */     return (this.dummy.next() == this.dummy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InternalJob peek() {
/* 146 */     return (this.dummy.previous() == this.dummy) ? null : this.dummy.previous();
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<InternalJob> iterator() {
/* 151 */     return new Iterator<InternalJob>() {
/* 152 */         InternalJob pointer = JobQueue.this.dummy;
/*     */ 
/*     */         
/*     */         public boolean hasNext() {
/* 156 */           if (this.pointer.previous() == JobQueue.this.dummy) {
/* 157 */             this.pointer = null;
/*     */           } else {
/* 159 */             this.pointer = this.pointer.previous();
/* 160 */           }  return (this.pointer != null);
/*     */         }
/*     */ 
/*     */         
/*     */         public InternalJob next() {
/* 165 */           return this.pointer;
/*     */         }
/*     */ 
/*     */         
/*     */         public void remove() {
/* 170 */           throw new UnsupportedOperationException();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 179 */     List<InternalJob> all = new ArrayList<>();
/* 180 */     iterator().forEachRemaining(all::add);
/* 181 */     return all.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\JobQueue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */