/*    */ package org.eclipse.core.internal.jobs;
/*    */ 
/*    */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Deadlock
/*    */ {
/*    */   private Thread[] threads;
/*    */   private Thread candidate;
/*    */   private ISchedulingRule[] locks;
/*    */   
/*    */   public Deadlock(Thread[] threads, ISchedulingRule[] locks, Thread candidate) {
/* 33 */     this.threads = threads;
/* 34 */     this.locks = locks;
/* 35 */     this.candidate = candidate;
/*    */   }
/*    */   
/*    */   public ISchedulingRule[] getLocks() {
/* 39 */     return this.locks;
/*    */   }
/*    */   
/*    */   public Thread getCandidate() {
/* 43 */     return this.candidate;
/*    */   }
/*    */   
/*    */   public Thread[] getThreads() {
/* 47 */     return this.threads;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\Deadlock.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */