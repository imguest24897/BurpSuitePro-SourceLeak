/*    */ package org.eclipse.core.internal.jobs;
/*    */ 
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.jobs.Job;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InternalWorker
/*    */   extends Thread
/*    */ {
/*    */   private final JobManager manager;
/*    */   private boolean canceled;
/*    */   
/*    */   InternalWorker(JobManager manager) {
/* 31 */     super("Worker-JM");
/* 32 */     this.manager = manager;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/* 42 */     int timeout = 0;
/* 43 */     synchronized (this.manager.monitorStack) {
/* 44 */       while (!this.canceled) {
/* 45 */         if (this.manager.monitorStack.isEmpty()) {
/* 46 */           timeout = 0;
/*    */         } else {
/* 48 */           timeout = 250;
/*    */         } 
/* 50 */         for (Object[] o : this.manager.monitorStack) {
/* 51 */           IProgressMonitor monitor = (IProgressMonitor)o[1];
/* 52 */           if (monitor.isCanceled()) {
/* 53 */             Job job = (Job)o[0];
/* 54 */             Thread t = job.getThread();
/* 55 */             if (t != null) {
/* 56 */               t.interrupt();
/*    */             }
/*    */           } 
/*    */         } 
/*    */         try {
/* 61 */           this.manager.monitorStack.wait(timeout);
/* 62 */         } catch (InterruptedException interruptedException) {}
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void cancel() {
/* 73 */     synchronized (this.manager.monitorStack) {
/* 74 */       this.canceled = true;
/* 75 */       this.manager.monitorStack.notifyAll();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\InternalWorker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */