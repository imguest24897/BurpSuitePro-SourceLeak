/*     */ package org.eclipse.core.internal.jobs;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.ListenerList;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.core.runtime.jobs.IJobChangeListener;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.core.runtime.jobs.JobGroup;
/*     */ import org.eclipse.core.runtime.jobs.MultiRule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InternalJob
/*     */   extends PlatformObject
/*     */   implements Comparable<InternalJob>
/*     */ {
/*     */   static final int ABOUT_TO_RUN = 16;
/*     */   static final int ABOUT_TO_SCHEDULE = 32;
/*     */   static final int BLOCKED = 8;
/*     */   static final int YIELDING = 64;
/*     */   private static final int M_STATE = 255;
/*     */   private static final int M_SYSTEM = 256;
/*     */   private static final int M_USER = 512;
/*     */   private static final int M_ABOUT_TO_RUN_CANCELED = 1024;
/*     */   private static final int M_RUN_CANCELED = 2048;
/*  74 */   private static int nextJobNumber = 0;
/*  75 */   protected static final JobManager manager = JobManager.getInstance();
/*     */ 
/*     */ 
/*     */   
/*     */   static final long T_INFINITE = 9223372036854775807L;
/*     */ 
/*     */ 
/*     */   
/*     */   static final long T_NONE = -1L;
/*     */ 
/*     */ 
/*     */   
/*  87 */   private volatile int flags = 0;
/*  88 */   private final int jobNumber = getNextJobNumber();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   private final ListenerList<IJobChangeListener> listeners = new ListenerList(1);
/*     */ 
/*     */   
/*     */   private volatile IProgressMonitor monitor;
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */   
/*     */   private JobGroup jobGroup;
/*     */   
/*     */   private InternalJob next;
/*     */   
/*     */   private InternalJob previous;
/*     */   
/* 108 */   private int priority = 30;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjectMap<QualifiedName, Object> properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile IStatus result;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ISchedulingRule schedulingRule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile long startTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   private long waitQueueStamp = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   private volatile Thread thread = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 157 */   final Object jobStateLock = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   final Queue<JobChangeEvent> eventQueue = new ConcurrentLinkedQueue<>();
/* 163 */   final ReentrantLock eventQueueLock = new ReentrantLock();
/* 164 */   final AtomicReference<Thread> eventQueueThread = new AtomicReference<>();
/*     */   
/*     */   private static synchronized int getNextJobNumber() {
/* 167 */     return nextJobNumber++;
/*     */   }
/*     */   
/*     */   protected InternalJob(String name) {
/* 171 */     Assert.isNotNull(name);
/* 172 */     this.name = name;
/*     */   }
/*     */   
/*     */   protected void addJobChangeListener(IJobChangeListener listener) {
/* 176 */     this.listeners.add(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void addLast(InternalJob entry) {
/* 184 */     InternalJob last = this;
/*     */     
/* 186 */     while (last.previous != null) {
/* 187 */       last = last.previous;
/*     */     }
/* 189 */     last.previous = entry;
/* 190 */     entry.next = last;
/* 191 */     entry.previous = null;
/*     */   }
/*     */   
/*     */   protected boolean belongsTo(Object family) {
/* 195 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean cancel() {
/* 199 */     return manager.cancel(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void canceling() {}
/*     */ 
/*     */   
/*     */   public final int compareTo(InternalJob otherJob) {
/* 208 */     return (otherJob.startTime >= this.startTime) ? 1 : -1;
/*     */   }
/*     */   
/*     */   protected void done(IStatus endResult) {
/* 212 */     manager.endJob(this, endResult, true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final ListenerList<IJobChangeListener> getListeners() {
/* 220 */     return this.listeners;
/*     */   }
/*     */   
/*     */   protected String getName() {
/* 224 */     return this.name;
/*     */   }
/*     */   
/*     */   protected int getPriority() {
/* 228 */     return this.priority;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final IProgressMonitor getProgressMonitor() {
/* 235 */     return this.monitor;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object getProperty(QualifiedName key) {
/* 240 */     Map<QualifiedName, Object> temp = this.properties;
/* 241 */     if (temp == null)
/* 242 */       return null; 
/* 243 */     return temp.get(key);
/*     */   }
/*     */   
/*     */   protected IStatus getResult() {
/* 247 */     return this.result;
/*     */   }
/*     */   
/*     */   protected ISchedulingRule getRule() {
/* 251 */     return this.schedulingRule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final long getStartTime() {
/* 260 */     return this.startTime;
/*     */   }
/*     */   
/*     */   protected int getState() {
/* 264 */     int state = this.flags & 0xFF;
/* 265 */     switch (state) {
/*     */       
/*     */       case 8:
/*     */       case 64:
/* 269 */         return 2;
/*     */       case 16:
/* 271 */         return 4;
/*     */       case 32:
/* 273 */         return 2;
/*     */     } 
/* 275 */     return state;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Thread getThread() {
/* 280 */     return this.thread;
/*     */   }
/*     */   
/*     */   protected JobGroup getJobGroup() {
/* 284 */     return this.jobGroup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int internalGetState() {
/* 291 */     return this.flags & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void internalSetPriority(int newPriority) {
/* 298 */     this.priority = newPriority;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void internalSetRule(ISchedulingRule rule) {
/* 305 */     this.schedulingRule = rule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void internalSetState(int i) {
/* 312 */     this.flags = this.flags & 0xFFFFFF00 | i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean isAboutToRunCanceled() {
/* 319 */     return ((this.flags & 0x400) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean isRunCanceled() {
/* 326 */     return ((this.flags & 0x800) != 0);
/*     */   }
/*     */   
/*     */   protected boolean isBlocking() {
/* 330 */     return manager.isBlocking(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean isConflicting(InternalJob otherJob) {
/* 337 */     ISchedulingRule otherRule = otherJob.getRule();
/* 338 */     if (this.schedulingRule == null || otherRule == null) {
/* 339 */       return false;
/*     */     }
/* 341 */     if (this.schedulingRule.getClass() == MultiRule.class)
/* 342 */       return this.schedulingRule.isConflicting(otherRule); 
/* 343 */     return otherRule.isConflicting(this.schedulingRule);
/*     */   }
/*     */   
/*     */   protected boolean isSystem() {
/* 347 */     return ((this.flags & 0x100) != 0);
/*     */   }
/*     */   
/*     */   protected boolean isUser() {
/* 351 */     return ((this.flags & 0x200) != 0);
/*     */   }
/*     */   
/*     */   protected void join() throws InterruptedException {
/* 355 */     manager.join(this, 0L, (IProgressMonitor)null);
/*     */   }
/*     */   
/*     */   protected boolean join(long timeout, IProgressMonitor joinMonitor) throws InterruptedException, OperationCanceledException {
/* 359 */     return manager.join(this, timeout, joinMonitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final InternalJob next() {
/* 366 */     return this.next;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final InternalJob previous() {
/* 373 */     return this.previous;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final InternalJob remove() {
/* 380 */     if (this.next != null)
/* 381 */       this.next.setPrevious(this.previous); 
/* 382 */     if (this.previous != null)
/* 383 */       this.previous.setNext(this.next); 
/* 384 */     this.next = this.previous = null;
/* 385 */     return this;
/*     */   }
/*     */   
/*     */   protected void removeJobChangeListener(IJobChangeListener listener) {
/* 389 */     this.listeners.remove(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void schedule(long delay) {
/* 395 */     if (shouldSchedule()) {
/* 396 */       manager.schedule(this, delay);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final void setAboutToRunCanceled(boolean value) {
/* 403 */     synchronized (this.jobStateLock) {
/* 404 */       this.flags = value ? (this.flags | 0x400) : (this.flags & 0xFFFFFBFF);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setRunCanceled(boolean value) {
/* 413 */     synchronized (this.jobStateLock) {
/* 414 */       this.flags = value ? (this.flags | 0x800) : (this.flags & 0xFFFFF7FF);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setName(String name) {
/* 419 */     Assert.isNotNull(name);
/* 420 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setNext(InternalJob entry) {
/* 428 */     this.next = entry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setPrevious(InternalJob entry) {
/* 436 */     this.previous = entry;
/*     */   }
/*     */   
/*     */   protected void setPriority(int newPriority) {
/* 440 */     switch (newPriority) {
/*     */       case 10:
/*     */       case 20:
/*     */       case 30:
/*     */       case 40:
/*     */       case 50:
/* 446 */         manager.setPriority(this, newPriority);
/*     */         return;
/*     */     } 
/* 449 */     throw new IllegalArgumentException(String.valueOf(newPriority));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setProgressGroup(IProgressMonitor group, int ticks) {
/* 454 */     Assert.isNotNull(group);
/* 455 */     IProgressMonitor pm = manager.createMonitor(this, group, ticks);
/* 456 */     if (pm != null) {
/* 457 */       setProgressMonitor(pm);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setProgressMonitor(IProgressMonitor monitor) {
/* 466 */     this.monitor = monitor;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setProperty(QualifiedName key, Object value) {
/* 471 */     if (value == null)
/* 472 */     { if (this.properties == null)
/*     */         return; 
/* 474 */       ObjectMap<QualifiedName, Object> temp = new ObjectMap<>(this.properties);
/* 475 */       temp.remove(key);
/* 476 */       if (temp.isEmpty()) {
/* 477 */         this.properties = null;
/*     */       } else {
/* 479 */         this.properties = temp;
/*     */       }  }
/* 481 */     else { ObjectMap<QualifiedName, Object> temp = this.properties;
/* 482 */       if (temp == null) {
/* 483 */         temp = new ObjectMap<>(5);
/*     */       } else {
/* 485 */         temp = new ObjectMap<>(this.properties);
/* 486 */       }  temp.put(key, value);
/* 487 */       this.properties = temp; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setResult(IStatus result) {
/* 497 */     this.result = result;
/*     */   }
/*     */   
/*     */   protected void setRule(ISchedulingRule rule) {
/* 501 */     manager.setRule(this, rule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setStartTime(long time) {
/* 511 */     this.startTime = time;
/*     */   }
/*     */   
/*     */   protected void setSystem(boolean value) {
/* 515 */     synchronized (this.jobStateLock) {
/* 516 */       if (getState() != 0)
/* 517 */         throw new IllegalStateException(); 
/* 518 */       this.flags = value ? (this.flags | 0x100) : (this.flags & 0xFFFFFEFF);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setThread(Thread thread) {
/* 523 */     this.thread = thread;
/*     */   }
/*     */   
/*     */   protected void setUser(boolean value) {
/* 527 */     synchronized (this.jobStateLock) {
/* 528 */       if (getState() != 0)
/* 529 */         throw new IllegalStateException(); 
/* 530 */       this.flags = value ? (this.flags | 0x200) : (this.flags & 0xFFFFFDFF);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setJobGroup(JobGroup jobGroup) {
/* 535 */     if (getState() != 0)
/* 536 */       throw new IllegalStateException("Setting job group of an already scheduled job is not allowed"); 
/* 537 */     this.jobGroup = jobGroup;
/*     */   }
/*     */   
/*     */   protected boolean shouldSchedule() {
/* 541 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean sleep() {
/* 545 */     return manager.sleep(this);
/*     */   }
/*     */   
/*     */   protected Job yieldRule(IProgressMonitor progressMonitor) {
/* 549 */     return manager.yieldRule(this, progressMonitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 554 */     return String.valueOf(getName()) + "(" + this.jobNumber + ")";
/*     */   }
/*     */   
/*     */   protected void wakeUp(long delay) {
/* 558 */     manager.wakeUp(this, delay);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setWaitQueueStamp(long waitQueueStamp) {
/* 566 */     this.waitQueueStamp = waitQueueStamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getWaitQueueStamp() {
/* 574 */     return this.waitQueueStamp;
/*     */   }
/*     */   
/*     */   protected abstract IStatus run(IProgressMonitor paramIProgressMonitor);
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\InternalJob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */