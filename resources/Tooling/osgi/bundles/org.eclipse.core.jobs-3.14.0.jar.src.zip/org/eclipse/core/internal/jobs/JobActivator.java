/*    */ package org.eclipse.core.internal.jobs;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import org.eclipse.core.runtime.jobs.IJobManager;
/*    */ import org.osgi.framework.BundleActivator;
/*    */ import org.osgi.framework.BundleContext;
/*    */ import org.osgi.framework.ServiceRegistration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JobActivator
/*    */   implements BundleActivator
/*    */ {
/*    */   private static final String PROP_REGISTER_JOB_SERVICE = "eclipse.service.jobs";
/*    */   private static BundleContext bundleContext;
/* 39 */   private ServiceRegistration<IJobManager> jobManagerService = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void start(BundleContext context) throws Exception {
/* 46 */     bundleContext = context;
/* 47 */     JobOSGiUtils.getDefault().openServices();
/*    */     
/* 49 */     boolean shouldRegister = !"false".equalsIgnoreCase(context.getProperty("eclipse.service.jobs"));
/* 50 */     if (shouldRegister) {
/* 51 */       registerServices();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void stop(BundleContext context) throws Exception {
/* 59 */     unregisterServices();
/* 60 */     JobManager.shutdown();
/* 61 */     JobOSGiUtils.getDefault().closeServices();
/* 62 */     bundleContext = null;
/*    */   }
/*    */   
/*    */   static BundleContext getContext() {
/* 66 */     return bundleContext;
/*    */   }
/*    */   
/*    */   private void registerServices() {
/* 70 */     this.jobManagerService = bundleContext.registerService(IJobManager.class, JobManager.getInstance(), new Hashtable<>());
/*    */   }
/*    */   
/*    */   private void unregisterServices() {
/* 74 */     if (this.jobManagerService != null) {
/* 75 */       this.jobManagerService.unregister();
/* 76 */       this.jobManagerService = null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\JobActivator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */