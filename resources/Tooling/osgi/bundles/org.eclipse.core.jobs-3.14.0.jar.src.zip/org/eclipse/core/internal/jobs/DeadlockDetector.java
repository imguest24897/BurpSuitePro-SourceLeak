/*     */ package org.eclipse.core.internal.jobs;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeadlockDetector
/*     */ {
/*  72 */   private static int NO_STATE = 0;
/*     */   
/*  74 */   private static int WAITING_FOR_LOCK = -1;
/*     */   
/*  76 */   private static final int[][] EMPTY_MATRIX = new int[0][0];
/*     */   
/*  78 */   private int[][] graph = EMPTY_MATRIX;
/*     */   
/*  80 */   private final ArrayList<ISchedulingRule> locks = new ArrayList<>();
/*     */   
/*  82 */   private final ArrayList<Thread> lockThreads = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean resize = false;
/*     */ 
/*     */   
/*     */   private static volatile boolean noDeadlockReport;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean addCycleThreads(ArrayList<Thread> deadlockedThreads, Thread next) {
/*  94 */     Thread[] blocking = blockingThreads(next);
/*     */     
/*  96 */     if (blocking.length == 0)
/*  97 */       return false; 
/*  98 */     boolean inCycle = false; byte b; int i; Thread[] arrayOfThread1;
/*  99 */     for (i = (arrayOfThread1 = blocking).length, b = 0; b < i; ) { Thread element = arrayOfThread1[b];
/*     */       
/* 101 */       if (deadlockedThreads.contains(element)) {
/* 102 */         inCycle = true;
/*     */       } else {
/*     */         
/* 105 */         deadlockedThreads.add(element);
/*     */         
/* 107 */         if (addCycleThreads(deadlockedThreads, element)) {
/* 108 */           inCycle = true;
/*     */         } else {
/* 110 */           deadlockedThreads.remove(element);
/*     */         } 
/*     */       }  b++; }
/* 113 */      return inCycle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Thread[] blockingThreads(Thread current) {
/* 121 */     ISchedulingRule lock = (ISchedulingRule)getWaitingLock(current);
/* 122 */     return getThreadsOwningLock(lock);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkWaitCycles(int[] waitingThreads, int lockIndex) {
/* 134 */     for (int i = 0; i < this.graph.length; i++) {
/* 135 */       if (this.graph[i][lockIndex] > NO_STATE) {
/* 136 */         if (waitingThreads[i] > NO_STATE) {
/* 137 */           return true;
/*     */         }
/*     */         
/* 140 */         waitingThreads[i] = waitingThreads[i] + 1;
/* 141 */         for (int j = 0; j < (this.graph[i]).length; j++) {
/* 142 */           if (this.graph[i][j] == WAITING_FOR_LOCK && 
/* 143 */             checkWaitCycles(waitingThreads, j)) {
/* 144 */             return true;
/*     */           }
/*     */         } 
/*     */         
/* 148 */         waitingThreads[i] = waitingThreads[i] - 1;
/*     */       } 
/*     */     } 
/* 151 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean contains(Thread t) {
/* 159 */     return this.lockThreads.contains(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fillPresentEntries(ISchedulingRule newLock, int lockIndex) {
/*     */     int j;
/* 169 */     for (j = 0; j < this.locks.size(); j++) {
/* 170 */       if (j != lockIndex && newLock.isConflicting(this.locks.get(j))) {
/* 171 */         byte b; int i; int[][] arrayOfInt; for (i = (arrayOfInt = this.graph).length, b = 0; b < i; ) { int[] g = arrayOfInt[b];
/* 172 */           if (g[j] > NO_STATE && g[lockIndex] == NO_STATE) {
/* 173 */             g[lockIndex] = g[j];
/*     */           }
/*     */           b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 179 */     for (j = 0; j < this.locks.size(); j++) {
/* 180 */       if (j != lockIndex && newLock.isConflicting(this.locks.get(j))) {
/* 181 */         byte b; int i; int[][] arrayOfInt; for (i = (arrayOfInt = this.graph).length, b = 0; b < i; ) { int[] g = arrayOfInt[b];
/* 182 */           if (g[lockIndex] > NO_STATE && g[j] == NO_STATE) {
/* 183 */             g[j] = g[lockIndex];
/*     */           }
/*     */           b++; }
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object[] getOwnedLocks(Thread current) {
/* 194 */     ArrayList<ISchedulingRule> ownedLocks = new ArrayList<>(1);
/* 195 */     int index = indexOf(current, false);
/*     */     
/* 197 */     for (int j = 0; j < (this.graph[index]).length; j++) {
/* 198 */       if (this.graph[index][j] > NO_STATE)
/* 199 */         ownedLocks.add(this.locks.get(j)); 
/*     */     } 
/* 201 */     if (ownedLocks.isEmpty())
/* 202 */       Assert.isLegal(false, "A thread with no locks is part of a deadlock."); 
/* 203 */     return ownedLocks.toArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Thread[] getThreadsInDeadlock(Thread cause) {
/* 210 */     ArrayList<Thread> deadlockedThreads = new ArrayList<>(2);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     if (ownsLocks(cause))
/* 216 */       deadlockedThreads.add(cause); 
/* 217 */     addCycleThreads(deadlockedThreads, cause);
/* 218 */     return deadlockedThreads.<Thread>toArray(new Thread[deadlockedThreads.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Thread[] getThreadsOwningLock(ISchedulingRule rule) {
/* 225 */     if (rule == null)
/* 226 */       return new Thread[0]; 
/* 227 */     int lockIndex = indexOf(rule, false);
/* 228 */     ArrayList<Thread> blocking = new ArrayList<>(1);
/* 229 */     for (int i = 0; i < this.graph.length; i++) {
/* 230 */       if (this.graph[i][lockIndex] > NO_STATE)
/* 231 */         blocking.add(this.lockThreads.get(i)); 
/*     */     } 
/* 233 */     if (blocking.isEmpty() && JobManager.DEBUG_LOCKS)
/* 234 */       System.out.println("Lock " + rule + " is involved in deadlock but is not owned by any thread."); 
/* 235 */     if (blocking.size() > 1 && rule instanceof org.eclipse.core.runtime.jobs.ILock && JobManager.DEBUG_LOCKS)
/* 236 */       System.out.println("Lock " + rule + " is owned by more than 1 thread, but it is not a rule."); 
/* 237 */     return blocking.<Thread>toArray(new Thread[blocking.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object getWaitingLock(Thread current) {
/* 244 */     int index = indexOf(current, false);
/*     */     
/* 246 */     for (int j = 0; j < (this.graph[index]).length; j++) {
/* 247 */       if (this.graph[index][j] == WAITING_FOR_LOCK) {
/* 248 */         return this.locks.get(j);
/*     */       }
/*     */     } 
/* 251 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int indexOf(ISchedulingRule lock, boolean add) {
/* 259 */     int index = this.locks.indexOf(lock);
/* 260 */     if (index < 0 && add) {
/* 261 */       this.locks.add(lock);
/* 262 */       this.resize = true;
/* 263 */       index = this.locks.size() - 1;
/*     */     } 
/* 265 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int indexOf(Thread owner, boolean add) {
/* 273 */     int index = this.lockThreads.indexOf(owner);
/* 274 */     if (index < 0 && add) {
/* 275 */       this.lockThreads.add(owner);
/* 276 */       this.resize = true;
/* 277 */       index = this.lockThreads.size() - 1;
/*     */     } 
/* 279 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isEmpty() {
/* 286 */     return (this.locks.isEmpty() && this.lockThreads.isEmpty() && this.graph.length == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void lockAcquired(Thread owner, ISchedulingRule lock) {
/* 293 */     int lockIndex = indexOf(lock, true);
/* 294 */     int threadIndex = indexOf(owner, true);
/* 295 */     if (this.resize)
/* 296 */       resizeGraph(); 
/* 297 */     if (this.graph[threadIndex][lockIndex] == WAITING_FOR_LOCK) {
/* 298 */       this.graph[threadIndex][lockIndex] = NO_STATE;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 304 */     ArrayList<ISchedulingRule> conflicting = new ArrayList<>(1);
/*     */     
/* 306 */     int NUM_PASSES = 2;
/* 307 */     conflicting.add(lock);
/* 308 */     this.graph[threadIndex][lockIndex] = this.graph[threadIndex][lockIndex] + 1;
/* 309 */     for (int i = 0; i < NUM_PASSES; i++) {
/* 310 */       for (int k = 0; k < conflicting.size(); k++) {
/* 311 */         ISchedulingRule current = conflicting.get(k);
/* 312 */         for (int j = 0; j < this.locks.size(); j++) {
/* 313 */           ISchedulingRule possible = this.locks.get(j);
/* 314 */           if (current.isConflicting(possible) && !conflicting.contains(possible)) {
/* 315 */             conflicting.add(possible);
/* 316 */             this.graph[threadIndex][j] = this.graph[threadIndex][j] + 1;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void lockReleased(Thread owner, ISchedulingRule lock) {
/* 327 */     int lockIndex = indexOf(lock, false);
/* 328 */     int threadIndex = indexOf(owner, false);
/*     */     
/* 330 */     if (threadIndex < 0) {
/* 331 */       if (JobManager.DEBUG_LOCKS)
/* 332 */         System.out.println("[lockReleased] Lock " + lock + " was already released by thread " + owner.getName()); 
/*     */       return;
/*     */     } 
/* 335 */     if (lockIndex < 0) {
/* 336 */       if (JobManager.DEBUG_LOCKS) {
/* 337 */         System.out.println("[lockReleased] Thread " + owner.getName() + " already released lock " + lock);
/*     */       }
/*     */       return;
/*     */     } 
/* 341 */     if (lock instanceof org.eclipse.core.runtime.jobs.ILock && this.graph[threadIndex][lockIndex] == WAITING_FOR_LOCK) {
/* 342 */       this.graph[threadIndex][lockIndex] = NO_STATE;
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 347 */     for (int j = 0; j < (this.graph[threadIndex]).length; j++) {
/* 348 */       if (lock.isConflicting(this.locks.get(j)) || (!(lock instanceof org.eclipse.core.runtime.jobs.ILock) && !(this.locks.get(j) instanceof org.eclipse.core.runtime.jobs.ILock) && this.graph[threadIndex][j] > NO_STATE)) {
/* 349 */         if (this.graph[threadIndex][j] == NO_STATE) {
/* 350 */           if (JobManager.DEBUG_LOCKS)
/* 351 */             System.out.println("[lockReleased] More releases than acquires for thread " + owner.getName() + " and lock " + lock); 
/*     */         } else {
/* 353 */           this.graph[threadIndex][j] = this.graph[threadIndex][j] - 1;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 358 */     if (this.graph[threadIndex][lockIndex] == NO_STATE) {
/* 359 */       reduceGraph(threadIndex, lock);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void lockReleasedCompletely(Thread owner, ISchedulingRule rule) {
/* 367 */     int ruleIndex = indexOf(rule, false);
/* 368 */     int threadIndex = indexOf(owner, false);
/*     */     
/* 370 */     if (threadIndex < 0) {
/* 371 */       if (JobManager.DEBUG_LOCKS)
/* 372 */         System.out.println("[lockReleasedCompletely] Lock " + rule + " was already released by thread " + owner.getName()); 
/*     */       return;
/*     */     } 
/* 375 */     if (ruleIndex < 0) {
/* 376 */       if (JobManager.DEBUG_LOCKS) {
/* 377 */         System.out.println("[lockReleasedCompletely] Thread " + owner.getName() + " already released lock " + rule);
/*     */       }
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 385 */     for (int j = 0; j < (this.graph[threadIndex]).length; j++) {
/* 386 */       if (!(this.locks.get(j) instanceof org.eclipse.core.runtime.jobs.ILock) && this.graph[threadIndex][j] > NO_STATE)
/* 387 */         this.graph[threadIndex][j] = NO_STATE; 
/*     */     } 
/* 389 */     reduceGraph(threadIndex, rule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Deadlock lockWaitStart(Thread client, ISchedulingRule lock) {
/* 397 */     setToWait(client, lock, false);
/* 398 */     int lockIndex = indexOf(lock, false);
/* 399 */     int[] temp = new int[this.lockThreads.size()];
/*     */     
/* 401 */     if (!checkWaitCycles(temp, lockIndex)) {
/* 402 */       return null;
/*     */     }
/* 404 */     Thread[] threads = getThreadsInDeadlock(client);
/*     */     
/* 406 */     Thread candidate = resolutionCandidate(threads);
/* 407 */     ISchedulingRule[] locksToSuspend = realLocksForThread(candidate);
/* 408 */     Deadlock deadlock = new Deadlock(threads, locksToSuspend, candidate);
/* 409 */     reportDeadlock(deadlock);
/* 410 */     if (JobManager.DEBUG_DEADLOCK)
/* 411 */       throw new IllegalStateException("Deadlock detected. Caused by thread " + client.getName() + '.'); 
/*     */     byte b;
/*     */     int i;
/*     */     ISchedulingRule[] arrayOfISchedulingRule1;
/* 415 */     for (i = (arrayOfISchedulingRule1 = locksToSuspend).length, b = 0; b < i; ) { ISchedulingRule element = arrayOfISchedulingRule1[b];
/* 416 */       setToWait(deadlock.getCandidate(), element, true); b++; }
/* 417 */      return deadlock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void lockWaitStop(Thread owner, ISchedulingRule lock) {
/* 426 */     int lockIndex = indexOf(lock, false);
/* 427 */     int threadIndex = indexOf(owner, false);
/*     */     
/* 429 */     if (threadIndex < 0) {
/* 430 */       if (JobManager.DEBUG_LOCKS)
/* 431 */         System.out.println("Thread " + owner.getName() + " was already removed."); 
/*     */       return;
/*     */     } 
/* 434 */     if (lockIndex < 0) {
/* 435 */       if (JobManager.DEBUG_LOCKS)
/* 436 */         System.out.println("Lock " + lock + " was already removed."); 
/*     */       return;
/*     */     } 
/* 439 */     if (this.graph[threadIndex][lockIndex] != WAITING_FOR_LOCK) {
/*     */       
/* 441 */       if (JobManager.DEBUG_LOCKS)
/* 442 */         System.out.println("Lock " + lock + " already granted to depth: " + this.graph[threadIndex][lockIndex]); 
/*     */       return;
/*     */     } 
/* 445 */     this.graph[threadIndex][lockIndex] = NO_STATE;
/* 446 */     reduceGraph(threadIndex, lock);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ownsLocks(Thread cause) {
/* 453 */     int threadIndex = indexOf(cause, false);
/* 454 */     for (int j = 0; j < (this.graph[threadIndex]).length; j++) {
/* 455 */       if (this.graph[threadIndex][j] > NO_STATE)
/* 456 */         return true; 
/*     */     } 
/* 458 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ownsRealLocks(Thread owner) {
/* 466 */     int threadIndex = indexOf(owner, false);
/* 467 */     for (int j = 0; j < (this.graph[threadIndex]).length; j++) {
/* 468 */       if (this.graph[threadIndex][j] > NO_STATE) {
/* 469 */         Object lock = this.locks.get(j);
/* 470 */         if (lock instanceof org.eclipse.core.runtime.jobs.ILock)
/* 471 */           return true; 
/*     */       } 
/*     */     } 
/* 474 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ownsRuleLocks(Thread owner) {
/* 482 */     int threadIndex = indexOf(owner, false);
/* 483 */     for (int j = 0; j < (this.graph[threadIndex]).length; j++) {
/* 484 */       if (this.graph[threadIndex][j] > NO_STATE) {
/* 485 */         Object lock = this.locks.get(j);
/* 486 */         if (!(lock instanceof org.eclipse.core.runtime.jobs.ILock))
/* 487 */           return true; 
/*     */       } 
/*     */     } 
/* 490 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ISchedulingRule[] realLocksForThread(Thread owner) {
/* 498 */     int threadIndex = indexOf(owner, false);
/* 499 */     ArrayList<ISchedulingRule> ownedLocks = new ArrayList<>(1);
/* 500 */     for (int j = 0; j < (this.graph[threadIndex]).length; j++) {
/* 501 */       if (this.graph[threadIndex][j] > NO_STATE && this.locks.get(j) instanceof org.eclipse.core.runtime.jobs.ILock)
/* 502 */         ownedLocks.add(this.locks.get(j)); 
/*     */     } 
/* 504 */     if (ownedLocks.isEmpty())
/* 505 */       Assert.isLegal(false, "A thread with no real locks was chosen to resolve deadlock."); 
/* 506 */     return ownedLocks.<ISchedulingRule>toArray(new ISchedulingRule[ownedLocks.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void reduceGraph(int row, ISchedulingRule lock) {
/* 514 */     int numLocks = this.locks.size();
/* 515 */     boolean[] emptyColumns = new boolean[numLocks];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 521 */     for (int j = 0; j < numLocks; j++) {
/* 522 */       if (lock.isConflicting(this.locks.get(j)) || !(this.locks.get(j) instanceof org.eclipse.core.runtime.jobs.ILock)) {
/* 523 */         emptyColumns[j] = true;
/*     */       }
/*     */     } 
/* 526 */     boolean rowEmpty = true;
/* 527 */     int numEmpty = 0;
/*     */     int k;
/* 529 */     for (k = 0; k < (this.graph[row]).length; k++) {
/* 530 */       if (this.graph[row][k] != NO_STATE) {
/* 531 */         rowEmpty = false;
/*     */ 
/*     */ 
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 541 */     for (k = emptyColumns.length - 1; k >= 0; k--) {
/* 542 */       byte b; int m; int[][] arrayOfInt; for (m = (arrayOfInt = this.graph).length, b = 0; b < m; ) { int[] element = arrayOfInt[b];
/* 543 */         if (emptyColumns[k] && element[k] != NO_STATE) {
/* 544 */           emptyColumns[k] = false; break;
/*     */         } 
/*     */         b++; }
/*     */       
/* 548 */       if (emptyColumns[k]) {
/* 549 */         this.locks.remove(k);
/* 550 */         numEmpty++;
/*     */       } 
/*     */     } 
/*     */     
/* 554 */     if (numEmpty == 0 && !rowEmpty) {
/*     */       return;
/*     */     }
/* 557 */     if (rowEmpty) {
/* 558 */       this.lockThreads.remove(row);
/*     */     }
/*     */     
/* 561 */     int numThreads = this.lockThreads.size();
/* 562 */     numLocks = this.locks.size();
/*     */     
/* 564 */     if (numThreads == 0 && numLocks == 0) {
/* 565 */       this.graph = EMPTY_MATRIX;
/*     */       return;
/*     */     } 
/* 568 */     int[][] tempGraph = new int[numThreads][numLocks];
/*     */ 
/*     */     
/* 571 */     int numRowsSkipped = 0;
/* 572 */     for (int i = 0; i < this.graph.length - numRowsSkipped; i++) {
/* 573 */       if (i == row && rowEmpty) {
/* 574 */         numRowsSkipped++;
/*     */         
/* 576 */         if (i >= this.graph.length - numRowsSkipped) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */       
/* 581 */       int numColsSkipped = 0;
/* 582 */       for (int m = 0; m < (this.graph[i]).length - numColsSkipped; m++) {
/* 583 */         while (emptyColumns[m + numColsSkipped]) {
/* 584 */           numColsSkipped++;
/*     */           
/* 586 */           if (m >= (this.graph[i]).length - numColsSkipped) {
/*     */             break;
/*     */           }
/*     */         } 
/* 590 */         if (m >= (this.graph[i]).length - numColsSkipped)
/*     */           break; 
/* 592 */         tempGraph[i][m] = this.graph[i + numRowsSkipped][m + numColsSkipped];
/*     */       } 
/*     */     } 
/* 595 */     this.graph = tempGraph;
/* 596 */     Assert.isTrue((numThreads == this.graph.length), "Rows and threads don't match.");
/* 597 */     Assert.isTrue((numLocks == ((this.graph.length > 0) ? (this.graph[0]).length : 0)), "Columns and locks don't match.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void runSilent(Runnable runnable) {
/* 604 */     noDeadlockReport = true;
/*     */     try {
/* 606 */       runnable.run();
/*     */     } finally {
/* 608 */       noDeadlockReport = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void reportDeadlock(Deadlock deadlock) {
/* 616 */     if (noDeadlockReport) {
/*     */       return;
/*     */     }
/* 619 */     String msg = "Deadlock detected. All locks owned by thread " + deadlock.getCandidate().getName() + " will be suspended.";
/* 620 */     MultiStatus main = new MultiStatus("org.eclipse.core.jobs", 2, msg, new IllegalStateException());
/* 621 */     Thread[] threads = deadlock.getThreads(); byte b; int i; Thread[] arrayOfThread1;
/* 622 */     for (i = (arrayOfThread1 = threads).length, b = 0; b < i; ) { Thread thread = arrayOfThread1[b];
/* 623 */       Object[] ownedLocks = getOwnedLocks(thread);
/* 624 */       Object waitLock = getWaitingLock(thread);
/* 625 */       StringBuilder buf = new StringBuilder("Thread ");
/* 626 */       buf.append(thread.getName());
/* 627 */       buf.append(" has locks: ");
/* 628 */       for (int j = 0; j < ownedLocks.length; j++) {
/* 629 */         buf.append(ownedLocks[j]);
/* 630 */         buf.append((j < ownedLocks.length - 1) ? ", " : " ");
/*     */       } 
/* 632 */       buf.append("and is waiting for lock ");
/* 633 */       buf.append(waitLock);
/* 634 */       StackTraceElement[] stackTrace = thread.getStackTrace();
/* 635 */       if (stackTrace.length > 0) {
/* 636 */         buf.append(System.lineSeparator()); byte b1; int k; StackTraceElement[] arrayOfStackTraceElement;
/* 637 */         for (k = (arrayOfStackTraceElement = stackTrace).length, b1 = 0; b1 < k; ) { StackTraceElement stackTraceElement = arrayOfStackTraceElement[b1];
/* 638 */           buf.append('\t');
/* 639 */           buf.append("at ");
/* 640 */           buf.append(stackTraceElement);
/* 641 */           buf.append(System.lineSeparator()); b1++; }
/*     */       
/*     */       } 
/* 644 */       Status child = new Status(4, "org.eclipse.core.jobs", 2, buf.toString(), null);
/* 645 */       main.add((IStatus)child); b++; }
/*     */     
/* 647 */     RuntimeLog.log((IStatus)main);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void resizeGraph() {
/* 658 */     int newRows = this.lockThreads.size();
/* 659 */     int newCols = this.locks.size();
/*     */     
/* 661 */     if (newRows == 0 && newCols == 0) {
/* 662 */       this.graph = EMPTY_MATRIX;
/*     */       return;
/*     */     } 
/* 665 */     int[][] tempGraph = new int[newRows][newCols];
/* 666 */     for (int i = 0; i < this.graph.length; i++)
/* 667 */       System.arraycopy(this.graph[i], 0, tempGraph[i], 0, (this.graph[i]).length); 
/* 668 */     this.graph = tempGraph;
/* 669 */     this.resize = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Thread resolutionCandidate(Thread[] candidates) {
/*     */     byte b;
/*     */     int i;
/*     */     Thread[] arrayOfThread;
/* 678 */     for (i = (arrayOfThread = candidates).length, b = 0; b < i; ) { Thread candidate = arrayOfThread[b];
/* 679 */       if (!ownsRuleLocks(candidate)) {
/* 680 */         return candidate;
/*     */       }
/*     */       b++; }
/*     */     
/* 684 */     for (i = (arrayOfThread = candidates).length, b = 0; b < i; ) { Thread candidate = arrayOfThread[b];
/* 685 */       if (ownsRealLocks(candidate))
/* 686 */         return candidate; 
/*     */       b++; }
/*     */     
/* 689 */     return candidates[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setToWait(Thread owner, ISchedulingRule lock, boolean suspend) {
/* 696 */     boolean needTransfer = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 702 */     if (!suspend && !(lock instanceof org.eclipse.core.runtime.jobs.ILock))
/* 703 */       needTransfer = true; 
/* 704 */     int lockIndex = indexOf(lock, !suspend);
/* 705 */     int threadIndex = indexOf(owner, !suspend);
/* 706 */     if (this.resize) {
/* 707 */       resizeGraph();
/*     */     }
/* 709 */     this.graph[threadIndex][lockIndex] = WAITING_FOR_LOCK;
/* 710 */     if (needTransfer) {
/* 711 */       fillPresentEntries(lock, lockIndex);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toDebugString() {
/* 719 */     StringWriter sWriter = new StringWriter();
/* 720 */     PrintWriter out = new PrintWriter(sWriter, true);
/* 721 */     out.println(" :: ");
/* 722 */     for (ISchedulingRule lock : this.locks) {
/* 723 */       out.print(" " + lock + ',');
/*     */     }
/* 725 */     out.println();
/* 726 */     for (int i = 0; i < this.graph.length; i++) {
/* 727 */       out.print(" " + ((Thread)this.lockThreads.get(i)).getName() + " : ");
/* 728 */       for (int j = 0; j < (this.graph[i]).length; j++) {
/* 729 */         out.print(" " + this.graph[i][j] + ',');
/*     */       }
/* 731 */       out.println();
/*     */     } 
/* 733 */     out.println("-------");
/* 734 */     return sWriter.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\DeadlockDetector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */