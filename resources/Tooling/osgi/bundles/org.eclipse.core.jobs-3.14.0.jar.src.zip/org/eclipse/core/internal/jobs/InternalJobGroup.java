/*     */ package org.eclipse.core.internal.jobs;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.core.runtime.jobs.JobGroup;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InternalJobGroup
/*     */ {
/*     */   private static final long MAX_WAIT_INTERVAL = 100L;
/*  43 */   final Object jobGroupStateLock = new Object();
/*     */   
/*  45 */   private static final JobManager manager = JobManager.getInstance();
/*     */   
/*     */   private final String name;
/*     */   
/*     */   private final int maxThreads;
/*     */   
/*  51 */   private volatile int state = 0;
/*     */   
/*     */   private volatile MultiStatus result;
/*     */   
/*  55 */   private final Set<InternalJob> runningJobs = new HashSet<>();
/*     */   
/*  57 */   private final Set<InternalJob> otherActiveJobs = new HashSet<>();
/*     */   
/*  59 */   private final List<IStatus> results = new ArrayList<>();
/*     */   
/*     */   private boolean cancelingDueToError;
/*     */   
/*     */   private int failedJobsCount;
/*     */   
/*     */   private int canceledJobsCount;
/*     */   
/*     */   private int seedJobsCount;
/*     */   
/*     */   private int seedJobsRemainingCount;
/*     */   
/*     */   protected InternalJobGroup(String name, int maxThreads, int seedJobsCount) {
/*  72 */     Assert.isNotNull(name);
/*  73 */     Assert.isLegal((maxThreads >= 0));
/*  74 */     Assert.isLegal((seedJobsCount >= 0));
/*  75 */     this.name = name;
/*  76 */     this.maxThreads = maxThreads;
/*  77 */     this.seedJobsCount = seedJobsCount;
/*  78 */     this.seedJobsRemainingCount = seedJobsCount;
/*     */   }
/*     */   
/*     */   protected String getName() {
/*  82 */     return this.name;
/*     */   }
/*     */   
/*     */   protected int getMaxThreads() {
/*  86 */     return this.maxThreads;
/*     */   }
/*     */   
/*     */   protected MultiStatus getResult() {
/*  90 */     return this.result;
/*     */   }
/*     */   
/*     */   protected int getState() {
/*  94 */     return this.state;
/*     */   }
/*     */   
/*     */   protected List<Job> getActiveJobs() {
/*  98 */     return manager.find(this);
/*     */   }
/*     */   
/*     */   protected void cancel() {
/* 102 */     manager.cancel(this);
/*     */   }
/*     */   
/*     */   protected boolean join(long timeout, IProgressMonitor monitor) throws InterruptedException, OperationCanceledException {
/* 106 */     return manager.join(this, timeout, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void jobStateChanged(InternalJob job, int oldState, int newState) {
/* 119 */     assert Thread.holdsLock(manager.lock);
/* 120 */     switch (oldState) {
/*     */       case 0:
/*     */         break;
/*     */       case 1:
/*     */       case 2:
/* 125 */         this.otherActiveJobs.remove(job);
/*     */         break;
/*     */       case 4:
/* 128 */         this.runningJobs.remove(job);
/*     */         break;
/*     */       default:
/* 131 */         Assert.isLegal(false, "Invalid job state: " + job + ", state: " + oldState);
/*     */         break;
/*     */     } 
/*     */     
/* 135 */     switch (newState) {
/*     */       case 0:
/*     */         break;
/*     */       case 1:
/*     */       case 2:
/* 140 */         this.otherActiveJobs.add(job);
/*     */         break;
/*     */       case 4:
/* 143 */         this.runningJobs.add(job);
/*     */         break;
/*     */       default:
/* 146 */         Assert.isLegal(false, "Invalid job state: " + job + ", state: " + newState);
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 157 */     if (job.internalGetState() == 32 && getGroupOfCurrentlyRunningJob() != job.getJobGroup()) {
/* 158 */       this.seedJobsRemainingCount--;
/*     */     }
/*     */     
/* 161 */     if (oldState == 4 && newState == 0) {
/* 162 */       IStatus jobResult = job.getResult();
/* 163 */       Assert.isLegal((jobResult != null));
/* 164 */       if (this.cancelingDueToError && jobResult.getSeverity() == 8) {
/*     */         return;
/*     */       }
/* 167 */       this.results.add(jobResult);
/* 168 */       int jobResultSeverity = jobResult.getSeverity();
/* 169 */       if (jobResultSeverity == 4) {
/* 170 */         this.failedJobsCount++;
/* 171 */       } else if (jobResultSeverity == 8) {
/* 172 */         this.canceledJobsCount++;
/*     */       } 
/*     */     } 
/*     */     
/* 176 */     if (getState() == 0 && getActiveJobsCount() > 0) {
/* 177 */       synchronized (this.jobGroupStateLock) {
/* 178 */         this.state = 1;
/* 179 */         this.jobGroupStateLock.notifyAll();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JobGroup getGroupOfCurrentlyRunningJob() {
/* 190 */     Job job = manager.currentJob();
/* 191 */     return (job == null) ? null : job.getJobGroup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void updateCancelingReason(boolean cancelDueToError) {
/* 204 */     assert Thread.holdsLock(manager.lock);
/* 205 */     this.cancelingDueToError = cancelDueToError;
/* 206 */     if (!cancelDueToError)
/*     */     {
/*     */       
/* 209 */       this.results.add(Status.CANCEL_STATUS);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List<Job> cancelAndNotify(boolean cancelDueToError) {
/* 224 */     synchronized (this.jobGroupStateLock) {
/* 225 */       switch (getState()) {
/*     */         case 0:
/* 227 */           return Collections.emptyList();
/*     */         case 2:
/* 229 */           if (!cancelDueToError)
/*     */           {
/* 231 */             updateCancelingReason(cancelDueToError);
/*     */           }
/* 233 */           return Collections.emptyList();
/*     */       } 
/* 235 */       this.state = 2;
/* 236 */       updateCancelingReason(cancelDueToError);
/* 237 */       this.jobGroupStateLock.notifyAll();
/* 238 */       return internalGetActiveJobs();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void endJobGroup(MultiStatus groupResult) {
/* 251 */     assert Thread.holdsLock(manager.lock);
/* 252 */     synchronized (this.jobGroupStateLock) {
/* 253 */       if (this.seedJobsRemainingCount > 0 && !groupResult.matches(8))
/* 254 */         throw new IllegalStateException("Invalid initial jobs remaining count"); 
/* 255 */       this.state = 0;
/* 256 */       if (this.result != null) {
/* 257 */         IStatus[] children1 = this.result.getChildren();
/* 258 */         IStatus[] children2 = groupResult.getChildren();
/* 259 */         if (children1.length > 0 || children2.length > 0) {
/* 260 */           List<IStatus> combined = new ArrayList<>(children1.length + children2.length); byte b; int i; IStatus[] arrayOfIStatus;
/* 261 */           for (i = (arrayOfIStatus = children1).length, b = 0; b < i; ) { IStatus s = arrayOfIStatus[b];
/* 262 */             combined.add(s); b++; }
/*     */           
/* 264 */           for (i = (arrayOfIStatus = children2).length, b = 0; b < i; ) { IStatus s = arrayOfIStatus[b];
/* 265 */             combined.add(s); b++; }
/*     */           
/* 267 */           groupResult = computeGroupResult(combined);
/*     */         } 
/*     */       } 
/* 270 */       this.result = groupResult;
/* 271 */       this.results.clear();
/* 272 */       this.cancelingDueToError = false;
/* 273 */       this.failedJobsCount = 0;
/* 274 */       this.canceledJobsCount = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 282 */       this.seedJobsRemainingCount = (this.seedJobsCount == 0) ? 0 : 1;
/* 283 */       this.jobGroupStateLock.notifyAll();
/*     */     } 
/*     */   }
/*     */   
/*     */   final List<Job> internalGetActiveJobs() {
/* 288 */     assert Thread.holdsLock(manager.lock);
/* 289 */     List<Job> activeJobs = new ArrayList<>(this.runningJobs.size() + this.otherActiveJobs.size());
/* 290 */     for (InternalJob job : this.runningJobs)
/* 291 */       activeJobs.add((Job)job); 
/* 292 */     for (InternalJob job : this.otherActiveJobs)
/* 293 */       activeJobs.add((Job)job); 
/* 294 */     return activeJobs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int getSeedJobsRemainingCount() {
/* 305 */     assert Thread.holdsLock(manager.lock);
/* 306 */     return this.seedJobsRemainingCount;
/*     */   }
/*     */   
/*     */   final int getActiveJobsCount() {
/* 310 */     assert Thread.holdsLock(manager.lock);
/* 311 */     return this.runningJobs.size() + this.otherActiveJobs.size();
/*     */   }
/*     */   
/*     */   final int getRunningJobsCount() {
/* 315 */     assert Thread.holdsLock(manager.lock);
/* 316 */     return this.runningJobs.size();
/*     */   }
/*     */   
/*     */   final int getFailedJobsCount() {
/* 320 */     assert Thread.holdsLock(manager.lock);
/* 321 */     return this.failedJobsCount;
/*     */   }
/*     */   
/*     */   final int getCanceledJobsCount() {
/* 325 */     assert Thread.holdsLock(manager.lock);
/* 326 */     return this.canceledJobsCount;
/*     */   }
/*     */   
/*     */   final List<IStatus> getCompletedJobResults() {
/* 330 */     assert Thread.holdsLock(manager.lock);
/* 331 */     return new ArrayList<>(this.results);
/*     */   }
/*     */   
/*     */   protected boolean shouldCancel(IStatus lastCompletedJobResult, int numberOfFailedJobs, int numberOfCanceledJobs) {
/* 335 */     return (numberOfFailedJobs > 0);
/*     */   }
/*     */   
/*     */   protected MultiStatus computeGroupResult(List<IStatus> jobResults) {
/* 339 */     List<IStatus> importantResults = new ArrayList<>();
/* 340 */     for (IStatus jobResult : jobResults) {
/* 341 */       if (jobResult.getSeverity() != 0)
/* 342 */         importantResults.add(jobResult); 
/*     */     } 
/* 344 */     if (importantResults.isEmpty()) {
/* 345 */       return new MultiStatus("org.eclipse.core.jobs", 0, this.name, null);
/*     */     }
/* 347 */     String pluginId = ((IStatus)importantResults.get(0)).getPlugin();
/* 348 */     IStatus[] groupResults = importantResults.<IStatus>toArray(new IStatus[importantResults.size()]);
/* 349 */     return new MultiStatus(pluginId, 0, groupResults, this.name, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean doJoin(long remainingTime) throws InterruptedException {
/* 358 */     synchronized (this.jobGroupStateLock) {
/* 359 */       if (getState() == 0) {
/* 360 */         return true;
/*     */       }
/*     */       
/* 363 */       long sleepTime = (remainingTime != 0L && remainingTime <= 100L) ? remainingTime : 100L;
/* 364 */       this.jobGroupStateLock.wait(sleepTime);
/* 365 */       return (getState() == 0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\InternalJobGroup.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */