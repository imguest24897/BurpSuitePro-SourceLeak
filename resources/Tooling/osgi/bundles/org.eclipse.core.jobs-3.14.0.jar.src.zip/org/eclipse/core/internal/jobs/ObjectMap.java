/*     */ package org.eclipse.core.internal.jobs;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectMap<K, V>
/*     */   implements Map<K, V>
/*     */ {
/*     */   protected static final int DEFAULT_SIZE = 16;
/*     */   protected static final int GROW_SIZE = 10;
/*  30 */   protected int count = 0;
/*  31 */   protected Object[] elements = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectMap(int initialCapacity) {
/*  40 */     if (initialCapacity > 0) {
/*  41 */       this.elements = new Object[Math.max(initialCapacity * 2, 0)];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectMap(Map<K, V> map) {
/*  52 */     this(map.size());
/*  53 */     putAll(map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  61 */     this.elements = null;
/*  62 */     this.count = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/*  70 */     if (this.elements == null || this.count == 0)
/*  71 */       return false; 
/*  72 */     for (int i = 0; i < this.elements.length; i += 2) {
/*  73 */       if (this.elements[i] != null && this.elements[i].equals(key))
/*  74 */         return true; 
/*  75 */     }  return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/*  83 */     if (this.elements == null || this.count == 0)
/*  84 */       return false; 
/*  85 */     for (int i = 1; i < this.elements.length; i += 2) {
/*  86 */       if (this.elements[i] != null && this.elements[i].equals(value))
/*  87 */         return true; 
/*  88 */     }  return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/* 100 */     return (this.count == 0) ? Collections.EMPTY_SET : toHashMap().entrySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 108 */     if (!(o instanceof Map)) {
/* 109 */       return false;
/*     */     }
/* 111 */     Map<K, V> other = (Map<K, V>)o;
/*     */     
/* 113 */     if (this.count != other.size()) {
/* 114 */       return false;
/*     */     }
/* 116 */     if (!keySet().equals(other.keySet())) {
/* 117 */       return false;
/*     */     }
/* 119 */     for (int i = 0; i < this.elements.length; i += 2) {
/* 120 */       if (this.elements[i] != null && !this.elements[i + 1].equals(other.get(this.elements[i])))
/* 121 */         return false; 
/*     */     } 
/* 123 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V get(Object key) {
/* 132 */     if (this.elements == null || this.count == 0)
/* 133 */       return null; 
/* 134 */     for (int i = 0; i < this.elements.length; i += 2) {
/* 135 */       if (this.elements[i] != null && this.elements[i].equals(key))
/* 136 */         return (V)this.elements[i + 1]; 
/* 137 */     }  return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void grow() {
/* 145 */     Object[] expanded = new Object[this.elements.length + 10];
/* 146 */     System.arraycopy(this.elements, 0, expanded, 0, this.elements.length);
/* 147 */     this.elements = expanded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 155 */     int hash = 0;
/* 156 */     for (int i = 0; i < this.elements.length; i += 2) {
/* 157 */       if (this.elements[i] != null) {
/* 158 */         hash += this.elements[i].hashCode();
/*     */       }
/*     */     } 
/* 161 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 169 */     return (this.count == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<K> keySet() {
/* 182 */     Set<K> result = new HashSet<>(size());
/* 183 */     for (int i = 0; i < this.elements.length; i += 2) {
/* 184 */       if (this.elements[i] != null) {
/* 185 */         result.add((K)this.elements[i]);
/*     */       }
/*     */     } 
/* 188 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V put(K key, V value) {
/* 196 */     if (key == null)
/* 197 */       throw new NullPointerException(); 
/* 198 */     if (value == null) {
/* 199 */       return remove(key);
/*     */     }
/*     */     
/* 202 */     if (this.elements == null)
/* 203 */       this.elements = new Object[16]; 
/* 204 */     if (this.count == 0) {
/* 205 */       this.elements[0] = key;
/* 206 */       this.elements[1] = value;
/* 207 */       this.count++;
/* 208 */       return null;
/*     */     } 
/*     */     
/* 211 */     int emptyIndex = -1;
/*     */     
/* 213 */     for (int i = 0; i < this.elements.length; i += 2) {
/* 214 */       if (this.elements[i] != null) {
/* 215 */         if (this.elements[i].equals(key)) {
/*     */           
/* 217 */           V oldValue = (V)this.elements[i + 1];
/* 218 */           this.elements[i + 1] = value;
/* 219 */           return oldValue;
/*     */         } 
/* 221 */       } else if (emptyIndex == -1) {
/*     */         
/* 223 */         emptyIndex = i;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 228 */     if (emptyIndex == -1) {
/* 229 */       emptyIndex = this.count * 2;
/*     */     }
/*     */ 
/*     */     
/* 233 */     if (this.elements.length <= this.count * 2)
/* 234 */       grow(); 
/* 235 */     this.elements[emptyIndex] = key;
/* 236 */     this.elements[emptyIndex + 1] = value;
/* 237 */     this.count++;
/* 238 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> map) {
/* 246 */     for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
/* 247 */       put(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V remove(Object key) {
/* 256 */     if (this.elements == null || this.count == 0)
/* 257 */       return null; 
/* 258 */     for (int i = 0; i < this.elements.length; i += 2) {
/* 259 */       if (this.elements[i] != null && this.elements[i].equals(key)) {
/* 260 */         this.elements[i] = null;
/*     */         
/* 262 */         V result = (V)this.elements[i + 1];
/* 263 */         this.elements[i + 1] = null;
/* 264 */         this.count--;
/* 265 */         return result;
/*     */       } 
/*     */     } 
/* 268 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 276 */     return this.count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HashMap<K, V> toHashMap() {
/* 284 */     HashMap<K, V> result = new HashMap<>(size());
/* 285 */     for (int i = 0; i < this.elements.length; i += 2) {
/* 286 */       if (this.elements[i] != null) {
/* 287 */         result.put((K)this.elements[i], (V)this.elements[i + 1]);
/*     */       }
/*     */     } 
/* 290 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<V> values() {
/* 303 */     Set<V> result = new HashSet<>(size());
/* 304 */     for (int i = 1; i < this.elements.length; i += 2) {
/* 305 */       if (this.elements[i] != null) {
/* 306 */         result.add((V)this.elements[i]);
/*     */       }
/*     */     } 
/* 309 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\ObjectMap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */