package org.eclipse.core.runtime.jobs;

public interface IJobChangeListener {
  void aboutToRun(IJobChangeEvent paramIJobChangeEvent);
  
  void awake(IJobChangeEvent paramIJobChangeEvent);
  
  void done(IJobChangeEvent paramIJobChangeEvent);
  
  void running(IJobChangeEvent paramIJobChangeEvent);
  
  void scheduled(IJobChangeEvent paramIJobChangeEvent);
  
  void sleeping(IJobChangeEvent paramIJobChangeEvent);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\runtime\jobs\IJobChangeListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */