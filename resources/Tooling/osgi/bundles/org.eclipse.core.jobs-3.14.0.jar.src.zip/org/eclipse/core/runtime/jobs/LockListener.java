/*    */ package org.eclipse.core.runtime.jobs;
/*    */ 
/*    */ import org.eclipse.core.internal.jobs.JobManager;
/*    */ import org.eclipse.core.internal.jobs.LockManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LockListener
/*    */ {
/* 31 */   private final LockManager manager = ((JobManager)Job.getJobManager()).getLockManager();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean aboutToWait(Thread lockOwner) {
/* 46 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void aboutToRelease() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean canBlock() {
/* 69 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final boolean isLockOwnerThread() {
/* 78 */     return this.manager.isLockOwner();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\runtime\jobs\LockListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */