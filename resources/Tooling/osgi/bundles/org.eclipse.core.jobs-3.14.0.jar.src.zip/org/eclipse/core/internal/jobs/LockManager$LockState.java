/*    */ package org.eclipse.core.internal.jobs;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LockState
/*    */ {
/*    */   private int depth;
/*    */   private OrderedLock lock;
/*    */   
/*    */   protected static LockState suspend(OrderedLock lock) {
/* 43 */     LockState state = new LockState();
/* 44 */     state.lock = lock;
/* 45 */     state.depth = lock.forceRelease();
/* 46 */     return state;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void resume() {
/*    */     while (true) {
/*    */       try {
/*    */         do {
/*    */         
/* 58 */         } while (!this.lock.acquire(Long.MAX_VALUE));
/*    */         break;
/* 60 */       } catch (InterruptedException interruptedException) {}
/*    */     } 
/*    */ 
/*    */     
/* 64 */     this.lock.setDepth(this.depth);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\LockManager$LockState.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */