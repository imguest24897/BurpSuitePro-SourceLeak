/*     */ package org.eclipse.core.internal.jobs;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.LockListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LockManager
/*     */ {
/*     */   protected volatile LockListener lockListener;
/*     */   
/*     */   private static class LockState
/*     */   {
/*     */     private int depth;
/*     */     private OrderedLock lock;
/*     */     
/*     */     protected static LockState suspend(OrderedLock lock) {
/*  43 */       LockState state = new LockState();
/*  44 */       state.lock = lock;
/*  45 */       state.depth = lock.forceRelease();
/*  46 */       return state;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void resume() {
/*     */       while (true) {
/*     */         try {
/*     */           do {
/*     */           
/*  58 */           } while (!this.lock.acquire(Long.MAX_VALUE));
/*     */           break;
/*  60 */         } catch (InterruptedException interruptedException) {}
/*     */       } 
/*     */ 
/*     */       
/*  64 */       this.lock.setDepth(this.depth);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private DeadlockDetector locks = new DeadlockDetector();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private final Map<Thread, Deque<LockState[]>> suspendedLocks = new HashMap<>();
/*     */   
/*     */   public void aboutToRelease() {
/*  84 */     if (this.lockListener == null)
/*     */       return; 
/*     */     try {
/*  87 */       this.lockListener.aboutToRelease();
/*  88 */     } catch (Exception|LinkageError e) {
/*  89 */       handleException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean canBlock() {
/*  94 */     if (this.lockListener == null)
/*  95 */       return true; 
/*     */     try {
/*  97 */       return this.lockListener.canBlock();
/*  98 */     } catch (Exception|LinkageError e) {
/*  99 */       handleException(e);
/*     */       
/* 101 */       return false;
/*     */     } 
/*     */   }
/*     */   public boolean aboutToWait(Thread lockOwner) {
/* 105 */     if (this.lockListener == null)
/* 106 */       return false; 
/*     */     try {
/* 108 */       return this.lockListener.aboutToWait(lockOwner);
/* 109 */     } catch (Exception|LinkageError e) {
/* 110 */       handleException(e);
/*     */       
/* 112 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void addLockThread(Thread thread, ISchedulingRule lock) {
/* 119 */     DeadlockDetector tempLocks = this.locks;
/* 120 */     if (tempLocks == null)
/*     */       return; 
/*     */     try {
/* 123 */       synchronized (tempLocks) {
/*     */         try {
/* 125 */           tempLocks.lockAcquired(thread, lock);
/* 126 */         } catch (Exception e) {
/* 127 */           throw createDebugException(tempLocks, e);
/*     */         } 
/*     */       } 
/* 130 */     } catch (Exception e) {
/* 131 */       handleInternalError(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addLockWaitThread(Thread thread, ISchedulingRule lock) {
/* 139 */     DeadlockDetector tempLocks = this.locks;
/* 140 */     if (tempLocks == null)
/*     */       return; 
/*     */     try {
/* 143 */       Deadlock found = null;
/* 144 */       synchronized (tempLocks) {
/*     */         try {
/* 146 */           found = tempLocks.lockWaitStart(thread, lock);
/* 147 */         } catch (Exception e) {
/* 148 */           throw createDebugException(tempLocks, e);
/*     */         } 
/*     */       } 
/* 151 */       if (found == null) {
/*     */         return;
/*     */       }
/*     */       
/* 155 */       ISchedulingRule[] toSuspend = found.getLocks();
/* 156 */       LockState[] suspended = new LockState[toSuspend.length];
/* 157 */       for (int i = 0; i < toSuspend.length; i++)
/* 158 */         suspended[i] = LockState.suspend((OrderedLock)toSuspend[i]); 
/* 159 */       synchronized (this.suspendedLocks) {
/* 160 */         ((Deque<LockState[]>)this.suspendedLocks.computeIfAbsent(found.getCandidate(), key -> new ArrayDeque())).push(suspended);
/*     */       } 
/* 162 */     } catch (Exception e) {
/* 163 */       handleInternalError(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Exception createDebugException(DeadlockDetector tempLocks, Exception rootException) {
/* 168 */     String debugString = null;
/*     */     try {
/* 170 */       debugString = tempLocks.toDebugString();
/* 171 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 174 */     return new Exception(debugString, rootException);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void handleException(Throwable e) {
/*     */     Status status;
/* 183 */     if (e instanceof CoreException) {
/*     */       
/* 185 */       MultiStatus multiStatus = new MultiStatus("org.eclipse.core.jobs", 2, "LockManager.handleException", e);
/* 186 */       multiStatus.merge(((CoreException)e).getStatus());
/*     */     } else {
/* 188 */       status = new Status(4, "org.eclipse.core.jobs", 2, "LockManager.handleException", e);
/*     */     } 
/* 190 */     RuntimeLog.log((IStatus)status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleInternalError(Throwable t) {
/*     */     try {
/* 200 */       handleException(t);
/* 201 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/* 205 */     this.locks = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 213 */     return this.locks.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLockOwner() {
/* 222 */     Thread current = Thread.currentThread();
/* 223 */     if (current instanceof Worker)
/* 224 */       return true; 
/* 225 */     DeadlockDetector tempLocks = this.locks;
/* 226 */     if (tempLocks == null)
/* 227 */       return false; 
/* 228 */     synchronized (tempLocks) {
/* 229 */       return tempLocks.contains(Thread.currentThread());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized OrderedLock newLock() {
/* 237 */     return new OrderedLock(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeLockCompletely(Thread thread, ISchedulingRule rule) {
/* 244 */     DeadlockDetector tempLocks = this.locks;
/* 245 */     if (tempLocks == null)
/*     */       return; 
/*     */     try {
/* 248 */       synchronized (tempLocks) {
/*     */         try {
/* 250 */           tempLocks.lockReleasedCompletely(thread, rule);
/* 251 */         } catch (Exception e) {
/* 252 */           throw createDebugException(tempLocks, e);
/*     */         } 
/*     */       } 
/* 255 */     } catch (Exception e) {
/* 256 */       handleInternalError(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeLockThread(Thread thread, ISchedulingRule lock) {
/* 264 */     DeadlockDetector tempLocks = this.locks;
/* 265 */     if (tempLocks == null)
/*     */       return; 
/*     */     try {
/* 268 */       synchronized (tempLocks) {
/*     */         try {
/* 270 */           tempLocks.lockReleased(thread, lock);
/* 271 */         } catch (Exception e) {
/* 272 */           throw createDebugException(tempLocks, e);
/*     */         } 
/*     */       } 
/* 275 */     } catch (Exception e) {
/* 276 */       handleInternalError(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeLockWaitThread(Thread thread, ISchedulingRule lock) {
/* 286 */     DeadlockDetector tempLocks = this.locks;
/* 287 */     if (tempLocks == null)
/*     */       return; 
/*     */     try {
/* 290 */       synchronized (tempLocks) {
/*     */         try {
/* 292 */           tempLocks.lockWaitStop(thread, lock);
/* 293 */         } catch (Exception e) {
/* 294 */           throw createDebugException(tempLocks, e);
/*     */         } 
/*     */       } 
/* 297 */     } catch (Exception e) {
/* 298 */       handleInternalError(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void resumeSuspendedLocks(Thread owner) {
/*     */     LockState[] toResume;
/* 307 */     synchronized (this.suspendedLocks) {
/* 308 */       Deque<LockState[]> prevLocks = this.suspendedLocks.get(owner);
/* 309 */       if (prevLocks == null)
/*     */         return; 
/* 311 */       toResume = prevLocks.pop();
/* 312 */       if (prevLocks.isEmpty())
/* 313 */         this.suspendedLocks.remove(owner); 
/*     */     }  byte b; int i; LockState[] arrayOfLockState1;
/* 315 */     for (i = (arrayOfLockState1 = toResume).length, b = 0; b < i; ) { LockState element = arrayOfLockState1[b];
/* 316 */       element.resume();
/*     */       b++; }
/*     */   
/*     */   } public void setLockListener(LockListener listener) {
/* 320 */     this.lockListener = listener;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\LockManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */