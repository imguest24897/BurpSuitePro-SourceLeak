/*     */ package org.eclipse.core.internal.jobs;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ThreadJob
/*     */   extends Job
/*     */ {
/*     */   protected boolean acquireRule = false;
/*     */   boolean isBlocked = false;
/*     */   protected boolean isRunning = false;
/*  51 */   private RuntimeException lastPush = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Job realJob;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ISchedulingRule[] ruleStack;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int top;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isWaiting;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ThreadJob(ISchedulingRule rule) {
/*  79 */     super("Implicit Job");
/*  80 */     setSystem(true);
/*     */ 
/*     */ 
/*     */     
/*  84 */     internalSetPriority(10);
/*  85 */     this.ruleStack = new ISchedulingRule[2];
/*  86 */     this.top = -1;
/*  87 */     internalSetRule(rule);
/*     */   }
/*     */   
/*     */   boolean isResumingAfterYield() {
/*  91 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void illegalPop(ISchedulingRule rule) {
/* 101 */     StringBuilder buf = new StringBuilder("Attempted to endRule: ");
/* 102 */     buf.append(rule);
/* 103 */     if (this.top >= 0 && this.top < this.ruleStack.length) {
/* 104 */       buf.append(", does not match most recent begin: ");
/* 105 */       buf.append(this.ruleStack[this.top]);
/* 106 */     } else if (this.top < 0) {
/* 107 */       buf.append(", but there was no matching beginRule");
/*     */     } else {
/*     */       
/* 110 */       buf.append(", but the rule stack was out of bounds: " + this.top);
/*     */     } 
/* 112 */     buf.append(".  See log for trace information if rule tracing is enabled.");
/* 113 */     String msg = buf.toString();
/* 114 */     if (JobManager.DEBUG || JobManager.DEBUG_BEGIN_END) {
/* 115 */       System.out.println(msg);
/* 116 */       Throwable t = (this.lastPush == null) ? new IllegalArgumentException() : this.lastPush;
/* 117 */       Status status = new Status(4, "org.eclipse.core.jobs", 1, msg, t);
/* 118 */       RuntimeLog.log((IStatus)status);
/*     */     } 
/* 120 */     Assert.isLegal(false, msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void illegalPush(ISchedulingRule pushRule, ISchedulingRule baseRule) {
/* 128 */     StringBuilder buf = new StringBuilder("Attempted to beginRule: ");
/* 129 */     buf.append(pushRule);
/* 130 */     buf.append(", does not match outer scope rule: ");
/* 131 */     buf.append(baseRule);
/* 132 */     String msg = buf.toString();
/* 133 */     if (JobManager.DEBUG) {
/* 134 */       System.out.println(msg);
/* 135 */       Status status = new Status(4, "org.eclipse.core.jobs", 1, msg, new IllegalArgumentException());
/* 136 */       RuntimeLog.log((IStatus)status);
/*     */     } 
/* 138 */     Assert.isLegal(false, msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isCanceled(IProgressMonitor monitor) {
/*     */     try {
/* 148 */       return monitor.isCanceled();
/* 149 */     } catch (RuntimeException e) {
/*     */       
/* 151 */       Status status = new Status(4, "org.eclipse.core.jobs", 2, "ThreadJob.isCanceled", e);
/* 152 */       RuntimeLog.log((IStatus)status);
/*     */       
/* 154 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized boolean isRunning() {
/* 162 */     return this.isRunning;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static ThreadJob joinRun(ThreadJob threadJob, IProgressMonitor monitor) {
/*     */     ThreadJob result;
/*     */     boolean interruptedDuringWaitForRun;
/* 195 */     if (isCanceled(monitor)) {
/* 196 */       throw new OperationCanceledException();
/*     */     }
/*     */     
/* 199 */     InternalJob blockingJob = manager.findBlockingJob((InternalJob)threadJob);
/* 200 */     Thread blocker = (blockingJob == null) ? null : blockingJob.getThread();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 205 */       if (manager.getLockManager().aboutToWait(blocker)) {
/* 206 */         return threadJob;
/*     */       }
/* 208 */       result = waitForRun(threadJob, monitor, blockingJob);
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */       
/* 215 */       boolean bool = Thread.interrupted();
/* 216 */       manager.getLockManager().aboutToRelease();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 222 */     if (interruptedDuringWaitForRun) {
/* 223 */       throw new OperationCanceledException();
/*     */     }
/* 225 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ThreadJob waitForRun(ThreadJob threadJob, IProgressMonitor monitor, InternalJob blockingJob) {
/* 250 */     boolean canBlock = manager.getLockManager().canBlock();
/* 251 */     ThreadJob result = threadJob;
/* 252 */     boolean interrupted = false;
/* 253 */     boolean waiting = false;
/* 254 */     boolean ruleCompatibleAndTransferred = false;
/*     */     try {
/* 256 */       waitStart(threadJob, monitor, blockingJob);
/* 257 */       manager.implicitJobs.addWaiting(threadJob);
/* 258 */       waiting = true;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 263 */       if (canBlock) {
/* 264 */         manager.beginMonitoring(threadJob, monitor);
/*     */       }
/* 266 */       Thread currentThread = Thread.currentThread();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/* 280 */         if (interrupted || isCanceled(monitor))
/*     */         {
/* 282 */           throw new OperationCanceledException();
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 287 */         blockingJob = manager.runNow(threadJob, true);
/* 288 */         if (blockingJob == null) {
/*     */           
/* 290 */           waiting = false;
/* 291 */           return threadJob;
/*     */         } 
/* 293 */         Thread blocker = blockingJob.getThread();
/*     */         
/* 295 */         if (blocker == currentThread && blockingJob instanceof ThreadJob) {
/*     */           
/* 297 */           result = (ThreadJob)blockingJob;
/*     */           
/* 299 */           result.push(threadJob.getRule());
/*     */           
/* 301 */           ruleCompatibleAndTransferred = true;
/* 302 */           result.isBlocked = threadJob.isBlocked;
/*     */           
/* 304 */           return result;
/*     */         } 
/*     */         
/* 307 */         if (manager.getLockManager().aboutToWait(blocker))
/*     */         {
/* 309 */           return threadJob;
/*     */         }
/*     */ 
/*     */         
/* 313 */         manager.getLockManager().addLockWaitThread(currentThread, threadJob.getRule());
/* 314 */         synchronized (blockingJob.jobStateLock) {
/*     */ 
/*     */           
/*     */           try {
/*     */             
/* 319 */             int state = blockingJob.getState();
/*     */             
/* 321 */             if (state == 4 && canBlock) {
/* 322 */               blockingJob.jobStateLock.wait();
/* 323 */             } else if (state != 0) {
/* 324 */               blockingJob.jobStateLock.wait(250L);
/*     */             } 
/* 326 */           } catch (InterruptedException interruptedException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 334 */             interrupted = true;
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 339 */         manager.getLockManager().removeLockWaitThread(currentThread, threadJob.getRule());
/*     */       } 
/*     */     } finally {
/*     */       boolean canStopWaiting, updateLockState;
/*     */       
/* 344 */       if (threadJob != result) {
/*     */ 
/*     */ 
/*     */         
/* 348 */         canStopWaiting = ruleCompatibleAndTransferred;
/*     */         
/* 350 */         updateLockState = false;
/*     */       } else {
/*     */         
/* 353 */         canStopWaiting = true;
/*     */         
/* 355 */         updateLockState = true;
/*     */       } 
/* 357 */       waitEnd(threadJob, updateLockState, monitor);
/* 358 */       if (canStopWaiting && 
/* 359 */         waiting) {
/* 360 */         manager.implicitJobs.removeWaiting(threadJob);
/*     */       }
/*     */       
/* 363 */       if (canBlock)
/*     */       {
/* 365 */         manager.endMonitoring(threadJob);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean pop(ISchedulingRule rule) {
/* 376 */     if (this.top < 0 || this.ruleStack[this.top] != rule) {
/* 377 */       illegalPop(rule);
/*     */     }
/* 379 */     this.ruleStack[this.top--] = null;
/* 380 */     return (this.top < 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void push(ISchedulingRule rule) {
/* 390 */     ISchedulingRule baseRule = getRule();
/* 391 */     if (++this.top >= this.ruleStack.length) {
/* 392 */       ISchedulingRule[] newStack = new ISchedulingRule[this.ruleStack.length * 2];
/* 393 */       System.arraycopy(this.ruleStack, 0, newStack, 0, this.ruleStack.length);
/* 394 */       this.ruleStack = newStack;
/*     */     } 
/* 396 */     this.ruleStack[this.top] = rule;
/* 397 */     if (JobManager.DEBUG_BEGIN_END) {
/* 398 */       this.lastPush = (RuntimeException)(new RuntimeException()).fillInStackTrace();
/*     */     }
/*     */     
/* 401 */     if (baseRule != null && rule != null && (!baseRule.contains(rule) || !baseRule.isConflicting(rule))) {
/* 402 */       illegalPush(rule, baseRule);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean recycle() {
/* 413 */     if (getState() != 0) {
/* 414 */       return false;
/*     */     }
/*     */     
/* 417 */     this.acquireRule = this.isRunning = this.isBlocked = false;
/* 418 */     this.realJob = null;
/* 419 */     setRule(null);
/* 420 */     setThread(null);
/* 421 */     if (this.ruleStack.length != 2) {
/* 422 */       this.ruleStack = new ISchedulingRule[2];
/*     */     } else {
/* 424 */       this.ruleStack[1] = null; this.ruleStack[0] = null;
/*     */     } 
/* 426 */     this.top = -1;
/* 427 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public IStatus run(IProgressMonitor monitor) {
/* 432 */     synchronized (this) {
/* 433 */       this.isRunning = true;
/*     */     } 
/* 435 */     return ASYNC_FINISH;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setRealJob(Job realJob) {
/* 444 */     this.realJob = realJob;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean shouldInterrupt() {
/* 453 */     return (this.realJob == null) ? true : (!this.realJob.isSystem());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 461 */     StringBuilder buf = new StringBuilder("ThreadJob");
/* 462 */     buf.append('(').append(this.realJob).append(',').append(getRuleStack()).append(')');
/* 463 */     return buf.toString();
/*     */   }
/*     */   
/*     */   String getRuleStack() {
/* 467 */     StringBuilder buf = new StringBuilder();
/* 468 */     buf.append('[');
/* 469 */     for (int i = 0; i <= this.top && i < this.ruleStack.length; i++) {
/* 470 */       buf.append(this.ruleStack[i]);
/* 471 */       if (i != this.top) {
/* 472 */         buf.append(',');
/*     */       }
/*     */     } 
/* 475 */     buf.append(']');
/* 476 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void waitEnd(ThreadJob threadJob, boolean updateLockManager, IProgressMonitor monitor) {
/* 485 */     if (updateLockManager) {
/* 486 */       LockManager lockManager = manager.getLockManager();
/* 487 */       Thread currentThread = Thread.currentThread();
/* 488 */       if (threadJob.isRunning()) {
/* 489 */         lockManager.addLockThread(currentThread, threadJob.getRule());
/*     */         
/* 491 */         lockManager.resumeSuspendedLocks(currentThread);
/*     */       } else {
/*     */         
/* 494 */         lockManager.removeLockWaitThread(currentThread, threadJob.getRule());
/*     */       } 
/*     */     } 
/* 497 */     if (threadJob.isBlocked) {
/* 498 */       threadJob.isBlocked = false;
/* 499 */       manager.reportUnblocked(monitor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void waitStart(ThreadJob threadJob, IProgressMonitor monitor, InternalJob blockingJob) {
/* 510 */     threadJob.isBlocked = true;
/* 511 */     manager.reportBlocked(monitor, (blockingJob == null) ? List.<InternalJob>of() : List.<InternalJob>of(blockingJob));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldSchedule() {
/* 519 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\ThreadJob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */