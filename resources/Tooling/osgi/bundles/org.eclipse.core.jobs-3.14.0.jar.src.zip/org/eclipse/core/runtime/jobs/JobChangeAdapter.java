package org.eclipse.core.runtime.jobs;

public class JobChangeAdapter implements IJobChangeListener {
  public void aboutToRun(IJobChangeEvent event) {}
  
  public void awake(IJobChangeEvent event) {}
  
  public void done(IJobChangeEvent event) {}
  
  public void running(IJobChangeEvent event) {}
  
  public void scheduled(IJobChangeEvent event) {}
  
  public void sleeping(IJobChangeEvent event) {}
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\runtime\jobs\JobChangeAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */