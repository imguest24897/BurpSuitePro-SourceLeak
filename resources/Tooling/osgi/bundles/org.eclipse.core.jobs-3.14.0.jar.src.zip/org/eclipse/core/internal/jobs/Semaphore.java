/*    */ package org.eclipse.core.internal.jobs;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Semaphore
/*    */ {
/*    */   protected long notifications;
/*    */   protected Runnable runnable;
/*    */   private static final int NANOS_IN_MS = 1000000;
/*    */   
/*    */   public Semaphore(Runnable runnable) {
/* 25 */     this.runnable = runnable;
/* 26 */     this.notifications = 0L;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized boolean acquire(long delay) throws InterruptedException {
/* 34 */     if (Thread.interrupted())
/* 35 */       throw new InterruptedException(); 
/* 36 */     long start = System.nanoTime();
/* 37 */     long timeLeft = delay;
/*    */     while (true) {
/* 39 */       if (this.notifications > 0L) {
/* 40 */         this.notifications--;
/* 41 */         return true;
/*    */       } 
/* 43 */       if (timeLeft <= 0L)
/* 44 */         return false; 
/* 45 */       wait(timeLeft);
/* 46 */       timeLeft = (start - System.nanoTime()) / 1000000L + delay;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized boolean attempt() {
/* 55 */     if (this.notifications > 0L) {
/* 56 */       this.notifications--;
/* 57 */       return true;
/*    */     } 
/* 59 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 64 */     if (obj == null) {
/* 65 */       return false;
/*    */     }
/* 67 */     if (!(obj instanceof Semaphore)) {
/* 68 */       return false;
/*    */     }
/* 70 */     return (this.runnable == ((Semaphore)obj).runnable);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 75 */     return Objects.hashCode(this.runnable);
/*    */   }
/*    */   
/*    */   public synchronized void release() {
/* 79 */     this.notifications++;
/* 80 */     notifyAll();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 86 */     return "Semaphore(" + this.runnable + ")";
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\Semaphore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */