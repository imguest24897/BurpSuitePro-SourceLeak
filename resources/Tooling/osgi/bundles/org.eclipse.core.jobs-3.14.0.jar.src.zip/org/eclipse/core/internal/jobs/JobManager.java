/*      */ package org.eclipse.core.internal.jobs;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.function.Function;
/*      */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*      */ import org.eclipse.core.runtime.Assert;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.MultiStatus;
/*      */ import org.eclipse.core.runtime.NullProgressMonitor;
/*      */ import org.eclipse.core.runtime.OperationCanceledException;
/*      */ import org.eclipse.core.runtime.ProgressMonitorWrapper;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.core.runtime.SubMonitor;
/*      */ import org.eclipse.core.runtime.jobs.IJobChangeEvent;
/*      */ import org.eclipse.core.runtime.jobs.IJobChangeListener;
/*      */ import org.eclipse.core.runtime.jobs.IJobManager;
/*      */ import org.eclipse.core.runtime.jobs.ILock;
/*      */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*      */ import org.eclipse.core.runtime.jobs.Job;
/*      */ import org.eclipse.core.runtime.jobs.JobChangeAdapter;
/*      */ import org.eclipse.core.runtime.jobs.JobGroup;
/*      */ import org.eclipse.core.runtime.jobs.LockListener;
/*      */ import org.eclipse.core.runtime.jobs.MultiRule;
/*      */ import org.eclipse.core.runtime.jobs.ProgressProvider;
/*      */ import org.eclipse.osgi.service.debug.DebugOptions;
/*      */ import org.eclipse.osgi.service.debug.DebugOptionsListener;
/*      */ import org.eclipse.osgi.service.debug.DebugTrace;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JobManager
/*      */   implements IJobManager, DebugOptionsListener
/*      */ {
/*      */   private static final int NANOS_IN_MS = 1000000;
/*      */   public static final String PI_JOBS = "org.eclipse.core.jobs";
/*      */   public static final int PLUGIN_ERROR = 2;
/*      */   public static final long MAX_WAIT_INTERVAL = 100L;
/*      */   private static final String OPTION_DEADLOCK_ERROR = "org.eclipse.core.jobs/jobs/errorondeadlock";
/*      */   private static final String OPTION_DEBUG_BEGIN_END = "org.eclipse.core.jobs/jobs/beginend";
/*      */   private static final String OPTION_DEBUG_YIELDING = "org.eclipse.core.jobs/jobs/yielding";
/*      */   private static final String OPTION_DEBUG_YIELDING_DETAILED = "org.eclipse.core.jobs/jobs/yielding/detailed";
/*      */   private static final String OPTION_DEBUG_JOBS = "org.eclipse.core.jobs/jobs";
/*      */   private static final String OPTION_LOCKS = "org.eclipse.core.jobs/jobs/locks";
/*      */   private static final String OPTION_SHUTDOWN = "org.eclipse.core.jobs/jobs/shutdown";
/*      */   static DebugTrace DEBUG_TRACE;
/*      */   static boolean DEBUG = false;
/*      */   static boolean DEBUG_BEGIN_END = false;
/*      */   static boolean DEBUG_YIELDING = false;
/*      */   static boolean DEBUG_YIELDING_DETAILED = false;
/*      */   static boolean DEBUG_DEADLOCK = false;
/*      */   static boolean DEBUG_LOCKS = false;
/*      */   static boolean DEBUG_SHUTDOWN = false;
/*      */   private static JobManager instance;
/*   99 */   private final long originTime = System.nanoTime();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final AtomicLong currentTimeInMs;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  109 */   private static final ISchedulingRule nullRule = new ISchedulingRule()
/*      */     {
/*      */       public boolean contains(ISchedulingRule rule) {
/*  112 */         return (rule == this);
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean isConflicting(ISchedulingRule rule) {
/*  117 */         return (rule == this);
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private volatile boolean active = true;
/*      */ 
/*      */   
/*  127 */   final ImplicitJobs implicitJobs = new ImplicitJobs(this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  135 */   private final JobListeners jobListeners = new JobListeners();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  143 */   final Object lock = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  148 */   private final IJobChangeListener jobGroupUpdater = (IJobChangeListener)new JobGroupUpdater();
/*      */   
/*  150 */   private final LockManager lockManager = new LockManager();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WorkerPool pool;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  160 */   private ProgressProvider progressProvider = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final HashSet<InternalJob> running;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final HashSet<InternalJob> yielding;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JobQueue sleeping;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean suspended = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JobQueue waiting;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final JobQueue waitingThreadJobs;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  205 */   private final AtomicLong waitQueueCounter = new AtomicLong();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  211 */   final List<Object[]> monitorStack = new ArrayList();
/*      */   
/*      */   private final InternalWorker internalWorker;
/*      */   
/*      */   public static void debug(String msg) {
/*  216 */     DEBUG_TRACE.trace(null, msg);
/*      */   }
/*      */   
/*      */   long getNextWaitQueueStamp() {
/*  220 */     return this.waitQueueCounter.getAndIncrement();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static synchronized JobManager getInstance() {
/*  227 */     if (instance == null);
/*      */     
/*  229 */     return instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String printJobName(Job job) {
/*  236 */     if (job instanceof ThreadJob) {
/*  237 */       Job realJob = ((ThreadJob)job).realJob;
/*  238 */       if (realJob != null)
/*  239 */         return realJob.getClass().getName(); 
/*  240 */       return "ThreadJob on rule: " + job.getRule();
/*      */     } 
/*  242 */     return job.getClass().getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String printState(Job job) {
/*  249 */     return printState(job.internalGetState());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String printState(int state) {
/*  256 */     switch (state) {
/*      */       case 0:
/*  258 */         return "NONE";
/*      */       case 2:
/*  260 */         return "WAITING";
/*      */       case 1:
/*  262 */         return "SLEEPING";
/*      */       case 4:
/*  264 */         return "RUNNING";
/*      */       case 8:
/*  266 */         return "BLOCKED";
/*      */       case 64:
/*  268 */         return "YIELDING";
/*      */       case 16:
/*  270 */         return "ABOUT_TO_RUN";
/*      */       case 32:
/*  272 */         return "ABOUT_TO_SCHEDULE";
/*      */     } 
/*  274 */     return "UNKNOWN";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void shutdown() {
/*  284 */     if (instance != null) {
/*  285 */       instance.doShutdown();
/*  286 */       instance = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   private JobManager() {
/*  291 */     this.currentTimeInMs = new AtomicLong(lifeTimeInMs());
/*  292 */     instance = this;
/*  293 */     synchronized (this.lock) {
/*  294 */       this.waiting = new JobQueue(false);
/*  295 */       this.waitingThreadJobs = new JobQueue(false, false);
/*  296 */       this.sleeping = new JobQueue(true);
/*  297 */       this.running = new HashSet<>(10);
/*  298 */       this.yielding = new HashSet<>(10);
/*  299 */       this.pool = new WorkerPool(this);
/*      */     } 
/*  301 */     this.pool.setDaemon(JobOSGiUtils.getDefault().useDaemonThreads());
/*  302 */     this.internalWorker = new InternalWorker(this);
/*  303 */     this.internalWorker.setDaemon(JobOSGiUtils.getDefault().useDaemonThreads());
/*  304 */     this.internalWorker.start();
/*  305 */     this.jobListeners.add(this.jobGroupUpdater);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addJobChangeListener(IJobChangeListener listener) {
/*  310 */     this.jobListeners.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void beginRule(ISchedulingRule rule, IProgressMonitor monitor) {
/*  315 */     validateRule(rule);
/*  316 */     this.implicitJobs.begin(rule, monitorFor(monitor), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean cancel(InternalJob job) {
/*  323 */     IProgressMonitor[] monitor = new IProgressMonitor[1];
/*  324 */     boolean[] runCanceling = new boolean[1];
/*  325 */     Boolean canceled = withWriteLock(job, j -> {
/*      */           paramInternalJob1.setAboutToRunCanceled(true);
/*      */           switch (paramInternalJob1.getState()) {
/*      */             case 0:
/*      */               return Boolean.valueOf(true);
/*      */             
/*      */             case 4:
/*      */               if (paramInternalJob1.internalGetState() == 4) {
/*      */                 paramArrayOfIProgressMonitor[0] = paramInternalJob1.getProgressMonitor();
/*      */                 paramArrayOfboolean[0] = !paramInternalJob1.isRunCanceled();
/*      */                 if (paramArrayOfboolean[0]) {
/*      */                   paramInternalJob1.setRunCanceled(true);
/*      */                 }
/*      */                 break;
/*      */               } 
/*      */               return Boolean.valueOf(false);
/*      */             
/*      */             default:
/*      */               changeState(paramInternalJob1, 0);
/*      */               break;
/*      */           } 
/*      */           if (paramArrayOfIProgressMonitor[0] == null) {
/*      */             this.jobListeners.queueDone((Job)paramInternalJob1, Status.CANCEL_STATUS, false);
/*      */           }
/*      */           return null;
/*      */         });
/*  351 */     if (canceled != null) {
/*  352 */       return canceled.booleanValue();
/*      */     }
/*      */     
/*  355 */     if (monitor[0] != null) {
/*  356 */       if (runCanceling[0]) {
/*  357 */         if (!monitor[0].isCanceled()) {
/*  358 */           monitor[0].setCanceled(true);
/*      */         }
/*  360 */         job.canceling();
/*      */       } 
/*  362 */       return false;
/*      */     } 
/*  364 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void cancel(Object family) {
/*  370 */     for (InternalJob internalJob : select(family))
/*  371 */       cancel(internalJob); 
/*      */   }
/*      */   
/*      */   void cancel(InternalJobGroup jobGroup) {
/*  375 */     cancel(jobGroup, false);
/*      */   }
/*      */   void cancel(InternalJobGroup jobGroup, boolean cancelDueToError) {
/*      */     List<Job> jobsToCancel;
/*  379 */     Assert.isLegal((jobGroup != null), "jobGroup should not be null");
/*      */     
/*  381 */     synchronized (this.lock) {
/*  382 */       jobsToCancel = jobGroup.cancelAndNotify(cancelDueToError);
/*      */     } 
/*  384 */     for (Job job : jobsToCancel) {
/*  385 */       job.cancel();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void changeState(InternalJob job, int newState) {
/*      */     int oldJobState;
/*  394 */     assert Thread.holdsLock(this.lock);
/*  395 */     boolean blockedJobs = false;
/*      */     
/*  397 */     synchronized (job.jobStateLock) {
/*  398 */       InternalJob blocked; job.jobStateLock.notifyAll();
/*  399 */       oldJobState = job.getState();
/*  400 */       int oldState = job.internalGetState();
/*  401 */       switch (oldState) {
/*      */         case 64:
/*  403 */           this.yielding.remove(job);
/*      */           break;
/*      */         case 0:
/*      */         case 32:
/*      */           break;
/*      */         case 8:
/*  409 */           job.remove();
/*      */           break;
/*      */         case 2:
/*      */           try {
/*  413 */             this.waiting.remove(job);
/*  414 */           } catch (RuntimeException runtimeException) {
/*  415 */             Assert.isLegal(false, "Tried to remove a job that wasn't in the queue");
/*      */           } 
/*      */           break;
/*      */         case 1:
/*      */           try {
/*  420 */             this.sleeping.remove(job);
/*  421 */           } catch (RuntimeException runtimeException) {
/*  422 */             Assert.isLegal(false, "Tried to remove a job that wasn't in the queue");
/*      */           } 
/*      */           break;
/*      */         case 4:
/*      */         case 16:
/*  427 */           this.running.remove(job);
/*      */           
/*  429 */           blocked = job.previous();
/*  430 */           job.remove();
/*  431 */           blockedJobs = (blocked != null);
/*  432 */           while (blocked != null) {
/*  433 */             InternalJob previous = blocked.previous();
/*  434 */             changeState(blocked, 2);
/*  435 */             blocked = previous;
/*      */           } 
/*      */           break;
/*      */         default:
/*  439 */           Assert.isLegal(false, "Invalid job state: " + job + ", state: " + oldState); break;
/*      */       } 
/*  441 */       job.internalSetState(newState);
/*  442 */       switch (newState) {
/*      */         case 0:
/*  444 */           job.setStartTime(-1L);
/*  445 */           job.setWaitQueueStamp(-1L);
/*  446 */           job.setRunCanceled(false); break;
/*      */         case 8:
/*      */           break;
/*      */         case 2:
/*  450 */           this.waiting.enqueue(job);
/*      */           break;
/*      */         case 1:
/*      */           try {
/*  454 */             this.sleeping.enqueue(job);
/*  455 */           } catch (RuntimeException runtimeException) {
/*  456 */             throw new RuntimeException("Error changing from state: " + oldState);
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 4:
/*      */         case 16:
/*  462 */           job.setStartTime(-1L);
/*  463 */           job.setWaitQueueStamp(-1L);
/*  464 */           this.running.add(job);
/*      */           break;
/*      */         case 64:
/*  467 */           this.yielding.add(job); break;
/*      */         case 32:
/*      */           break;
/*      */         default:
/*  471 */           Assert.isLegal(false, "Invalid job state: " + job + ", state: " + newState);
/*      */           break;
/*      */       } 
/*      */     } 
/*  475 */     JobGroup jobGroup = job.getJobGroup();
/*  476 */     if (jobGroup != null) {
/*  477 */       jobGroup.jobStateChanged(job, oldJobState, job.getState());
/*      */     }
/*      */ 
/*      */     
/*  481 */     if (blockedJobs) {
/*  482 */       this.pool.jobQueued();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IProgressMonitor createMonitor(InternalJob job, IProgressMonitor group, int ticks) {
/*  490 */     synchronized (this.lock) {
/*      */       NullProgressMonitor nullProgressMonitor;
/*      */ 
/*      */       
/*  494 */       if (job.getState() != 0)
/*  495 */         return null; 
/*  496 */       IProgressMonitor monitor = null;
/*  497 */       if (this.progressProvider != null)
/*  498 */         monitor = this.progressProvider.createMonitor((Job)job, group, ticks); 
/*  499 */       if (monitor == null)
/*  500 */         nullProgressMonitor = new NullProgressMonitor(); 
/*  501 */       return (IProgressMonitor)nullProgressMonitor;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private <T, J extends InternalJob> T withWriteLock(J job, Function<J, T> function) {
/*      */     T result;
/*      */     while (true) {
/*  511 */       this.jobListeners.waitAndSendEvents((InternalJob)job, false);
/*      */       
/*  513 */       synchronized (this.lock) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  518 */         if (JobListeners.getJobListenerTimeout() != 0 && !((InternalJob)job).eventQueue.isEmpty()) {
/*      */           continue;
/*      */         }
/*  521 */         result = function.apply(job);
/*      */       }  break;
/*      */     } 
/*  524 */     this.jobListeners.waitAndSendEvents((InternalJob)job, true);
/*  525 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IProgressMonitor createMonitor(Job job) {
/*      */     NullProgressMonitor nullProgressMonitor;
/*  534 */     IProgressMonitor monitor = null;
/*  535 */     if (this.progressProvider != null)
/*  536 */       monitor = this.progressProvider.createMonitor(job); 
/*  537 */     if (monitor == null)
/*  538 */       nullProgressMonitor = new NullProgressMonitor(); 
/*  539 */     return (IProgressMonitor)nullProgressMonitor;
/*      */   }
/*      */ 
/*      */   
/*      */   public IProgressMonitor createProgressGroup() {
/*  544 */     if (this.progressProvider != null)
/*  545 */       return this.progressProvider.createProgressGroup(); 
/*  546 */     return (IProgressMonitor)new NullProgressMonitor();
/*      */   }
/*      */ 
/*      */   
/*      */   public Job currentJob() {
/*  551 */     Thread current = Thread.currentThread();
/*  552 */     if (current instanceof Worker)
/*  553 */       return ((Worker)current).currentJob(); 
/*  554 */     synchronized (this.lock) {
/*  555 */       for (InternalJob internalJob : this.running) {
/*  556 */         Job job = (Job)internalJob;
/*  557 */         if (job.getThread() == current)
/*  558 */           return job; 
/*      */       } 
/*      */     } 
/*  561 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ISchedulingRule currentRule() {
/*  567 */     Job currentJob = this.implicitJobs.getThreadJob(Thread.currentThread());
/*  568 */     if (currentJob != null)
/*  569 */       return currentJob.getRule(); 
/*  570 */     currentJob = currentJob();
/*  571 */     if (currentJob != null)
/*  572 */       return currentJob.getRule(); 
/*  573 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long delayFor(int priority) {
/*  582 */     switch (priority) {
/*      */       case 10:
/*  584 */         return 0L;
/*      */       case 20:
/*  586 */         return 50L;
/*      */       case 30:
/*  588 */         return 100L;
/*      */       case 40:
/*  590 */         return 500L;
/*      */       case 50:
/*  592 */         return 1000L;
/*      */     } 
/*  594 */     Assert.isTrue(false, "Job has invalid priority: " + priority);
/*  595 */     return 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean doSchedule(InternalJob job, long delay) {
/*  605 */     assert Thread.holdsLock(this.lock);
/*  606 */     boolean cancelling = false;
/*      */     
/*  608 */     int state = job.internalGetState();
/*  609 */     if (state != 32 && state != 1) {
/*  610 */       return false;
/*      */     }
/*  612 */     if (job.isAboutToRunCanceled()) {
/*  613 */       cancelling = true;
/*  614 */       job.setResult(Status.CANCEL_STATUS);
/*  615 */       job.setProgressMonitor(null);
/*  616 */       job.setThread(null);
/*  617 */       changeState(job, 0);
/*      */     }
/*      */     else {
/*      */       
/*  621 */       if (job.getPriority() == 50 && job.getRule() == null) {
/*  622 */         long minDelay = (this.running.size() * 100);
/*  623 */         delay = Math.max(delay, minDelay);
/*      */       } 
/*  625 */       if (delay > 0L) {
/*  626 */         job.setStartTime(now() + delay);
/*  627 */         changeState(job, 1);
/*      */       } else {
/*  629 */         job.setStartTime(now() + delayFor(job.getPriority()));
/*  630 */         job.setWaitQueueStamp(getNextWaitQueueStamp());
/*  631 */         changeState(job, 2);
/*      */       } 
/*      */     } 
/*  634 */     if (cancelling) {
/*  635 */       this.jobListeners.queueDone((Job)job, Status.CANCEL_STATUS, false);
/*      */     }
/*  637 */     return !cancelling;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doShutdown() {
/*  647 */     Job[] toCancel = null;
/*  648 */     synchronized (this.lock) {
/*  649 */       if (!this.active)
/*      */         return; 
/*  651 */       this.active = false;
/*      */       
/*  653 */       toCancel = this.running.<Job>toArray(new Job[this.running.size()]);
/*      */       
/*  655 */       this.sleeping.clear();
/*  656 */       this.waiting.clear();
/*      */     } 
/*      */ 
/*      */     
/*  660 */     if (toCancel != null && toCancel.length > 0) {
/*  661 */       byte b; int i; Job[] arrayOfJob; for (i = (arrayOfJob = toCancel).length, b = 0; b < i; ) { Job element = arrayOfJob[b];
/*  662 */         cancel((InternalJob)element);
/*      */         b++; }
/*      */       
/*  665 */       for (int waitAttempts = 0; waitAttempts < 3; waitAttempts++) {
/*  666 */         Thread.yield();
/*  667 */         synchronized (this.lock) {
/*  668 */           if (this.running.isEmpty())
/*      */             break; 
/*      */         } 
/*  671 */         if (DEBUG_SHUTDOWN) {
/*  672 */           debug("Shutdown - job wait cycle #" + (waitAttempts + 1));
/*  673 */           Job[] stillRunning = null;
/*  674 */           synchronized (this.lock) {
/*  675 */             stillRunning = this.running.<Job>toArray(new Job[this.running.size()]);
/*      */           } 
/*  677 */           if (stillRunning != null) {
/*  678 */             byte b1; int j; Job[] arrayOfJob1; for (j = (arrayOfJob1 = stillRunning).length, b1 = 0; b1 < j; ) { Job element = arrayOfJob1[b1];
/*  679 */               debug("\tJob: " + printJobName(element)); b1++; }
/*      */           
/*      */           } 
/*      */         } 
/*      */         try {
/*  684 */           Thread.sleep(100L);
/*  685 */         } catch (InterruptedException interruptedException) {}
/*      */ 
/*      */         
/*  688 */         Thread.yield();
/*      */       } 
/*      */       
/*  691 */       synchronized (this.lock) {
/*  692 */         toCancel = this.running.<Job>toArray(new Job[this.running.size()]);
/*      */       } 
/*      */     } 
/*  695 */     this.internalWorker.cancel();
/*  696 */     if (toCancel != null) {
/*  697 */       byte b; int i; Job[] arrayOfJob; for (i = (arrayOfJob = toCancel).length, b = 0; b < i; ) { Job element = arrayOfJob[b];
/*  698 */         String jobName = printJobName(element);
/*      */         
/*  700 */         String msg = "Job found still running after platform shutdown.  Jobs should be canceled by the plugin that scheduled them during shutdown: " + jobName;
/*  701 */         RuntimeLog.log((IStatus)new Status(2, "org.eclipse.core.jobs", 2, msg, null));
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  706 */         System.err.println(msg); b++; }
/*      */     
/*      */     } 
/*  709 */     synchronized (this.lock) {
/*      */       
/*  711 */       this.running.clear();
/*      */     } 
/*      */     
/*  714 */     this.pool.shutdown();
/*  715 */     this.jobListeners.remove(this.jobGroupUpdater);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void endJob(InternalJob job, IStatus result, boolean notify, boolean worker) {
/*  725 */     if (result == Job.ASYNC_FINISH) {
/*      */       return;
/*      */     }
/*  728 */     Boolean scheduled = withWriteLock(job, j -> {
/*      */           long rescheduleDelay = -1L;
/*      */           
/*      */           if (paramInternalJob1.getState() == 0) {
/*      */             return null;
/*      */           }
/*      */           if (DEBUG && paramBoolean) {
/*      */             debug("Ending job: " + paramInternalJob1);
/*      */           }
/*      */           paramInternalJob1.setResult(paramIStatus);
/*      */           paramInternalJob1.setProgressMonitor(null);
/*      */           paramInternalJob1.setThread(null);
/*      */           rescheduleDelay = paramInternalJob1.getStartTime();
/*      */           changeState(paramInternalJob1, 0);
/*  742 */           boolean reschedule = (this.active && rescheduleDelay > -1L && paramInternalJob1.shouldSchedule());
/*      */ 
/*      */           
/*      */           if (paramBoolean) {
/*      */             this.jobListeners.queueDone((Job)paramInternalJob1, paramIStatus, reschedule);
/*      */           }
/*      */           
/*      */           return reschedule ? Boolean.valueOf(scheduleInternal(paramInternalJob1, rescheduleDelay, reschedule)) : Boolean.valueOf(false);
/*      */         });
/*      */     
/*  752 */     if (scheduled == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  758 */     if (scheduled.booleanValue() && !worker) {
/*  759 */       this.pool.jobQueued();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  764 */     if (job.getJobGroup() == null && result.matches(6)) {
/*  765 */       RuntimeLog.log(result);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void endRule(ISchedulingRule rule) {
/*  771 */     this.implicitJobs.end(rule, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public Job[] find(Object family) {
/*  776 */     List<InternalJob> members = select(family);
/*  777 */     return members.<Job>toArray(new Job[members.size()]);
/*      */   }
/*      */   
/*      */   List<Job> find(InternalJobGroup jobGroup) {
/*  781 */     Assert.isLegal((jobGroup != null), "jobGroup should not be null");
/*  782 */     synchronized (this.lock) {
/*  783 */       return jobGroup.internalGetActiveJobs();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InternalJob findBlockingJob(InternalJob waitingJob) {
/*  794 */     if (waitingJob.getRule() == null)
/*  795 */       return null; 
/*  796 */     synchronized (this.lock) {
/*  797 */       if (this.running.isEmpty()) {
/*  798 */         return null;
/*      */       }
/*  800 */       boolean hasBlockedJobs = false;
/*  801 */       for (InternalJob job : this.running) {
/*  802 */         if (waitingJob.isConflicting(job))
/*  803 */           return job; 
/*  804 */         if (!hasBlockedJobs) {
/*  805 */           hasBlockedJobs = (job.previous() != null);
/*      */         }
/*      */       } 
/*  808 */       if (!hasBlockedJobs) {
/*  809 */         return null;
/*      */       }
/*  811 */       for (InternalJob job : this.running) {
/*      */         while (true) {
/*  813 */           job = job.previous();
/*  814 */           if (job == null)
/*      */             break; 
/*  816 */           if (waitingJob.isConflicting(job))
/*  817 */             return job; 
/*      */         } 
/*      */       } 
/*      */     } 
/*  821 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private InternalJob findBlockedJob(InternalJob job) {
/*  830 */     synchronized (this.lock) {
/*  831 */       for (InternalJob waitingJob : this.waitingThreadJobs) {
/*  832 */         if (waitingJob.isConflicting(job)) {
/*  833 */           return waitingJob;
/*      */         }
/*      */       } 
/*  836 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   void dequeue(JobQueue queue, InternalJob job) {
/*  841 */     synchronized (this.lock) {
/*  842 */       queue.remove(job);
/*      */     } 
/*      */   }
/*      */   
/*      */   void enqueue(JobQueue queue, InternalJob job) {
/*  847 */     synchronized (this.lock) {
/*  848 */       queue.enqueue(job);
/*      */     } 
/*      */   }
/*      */   
/*      */   public LockManager getLockManager() {
/*  853 */     return this.lockManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getWaitMessage(int jobCount) {
/*  861 */     String message = (jobCount == 1) ? JobMessages.jobs_waitFamSubOne : JobMessages.jobs_waitFamSub;
/*  862 */     return NLS.bind(message, Integer.toString(jobCount));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isActive() {
/*  869 */     return this.active;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isBlocking(InternalJob runningJob) {
/*  877 */     synchronized (this.lock) {
/*      */       
/*  879 */       if (runningJob.getState() != 4) {
/*  880 */         return false;
/*      */       }
/*  882 */       InternalJob previous = runningJob.previous();
/*  883 */       while (previous != null) {
/*      */         
/*  885 */         if (previous.getPriority() < runningJob.getPriority()) {
/*  886 */           if (!previous.isSystem()) {
/*  887 */             return true;
/*      */           }
/*  889 */           if (previous instanceof ThreadJob && ((ThreadJob)previous).shouldInterrupt())
/*  890 */             return true; 
/*      */         } 
/*  892 */         previous = previous.previous();
/*      */       } 
/*      */       
/*  895 */       for (InternalJob waitingThreadJob : this.waitingThreadJobs) {
/*  896 */         ThreadJob waitingJob = (ThreadJob)waitingThreadJob;
/*  897 */         if (runningJob.isConflicting((InternalJob)waitingJob) && waitingJob.shouldInterrupt()) {
/*  898 */           return true;
/*      */         }
/*      */       } 
/*  901 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isIdle() {
/*  907 */     synchronized (this.lock) {
/*  908 */       return (this.running.isEmpty() && this.waiting.isEmpty());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isSuspended() {
/*  914 */     synchronized (this.lock) {
/*  915 */       return this.suspended;
/*      */     } 
/*      */   } protected boolean join(InternalJob job, long timeout, IProgressMonitor monitor) throws InterruptedException {
/*      */     JobChangeAdapter jobChangeAdapter;
/*      */     final Semaphore barrier;
/*  920 */     Assert.isLegal((timeout >= 0L), "timeout should not be negative");
/*  921 */     long deadline = (timeout == 0L) ? 0L : (now() + timeout);
/*      */     
/*  923 */     Job currentJob = currentJob();
/*  924 */     if (currentJob != null) {
/*  925 */       JobGroup jobGroup = currentJob.getJobGroup();
/*  926 */       if (timeout == 0L && jobGroup != null && jobGroup.getMaxThreads() != 0 && jobGroup == job.getJobGroup()) {
/*  927 */         throw new IllegalStateException("Joining on a job belonging to the same group is not allowed");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  932 */     synchronized (this.lock) {
/*  933 */       int state = job.getState();
/*  934 */       if (state == 0) {
/*  935 */         return true;
/*      */       }
/*  937 */       if (this.suspended && state != 4) {
/*  938 */         return true;
/*      */       }
/*  940 */       if (state == 4 && job.getThread() == Thread.currentThread()) {
/*  941 */         throw new IllegalStateException("Job attempted to join itself");
/*      */       }
/*  943 */       barrier = new Semaphore(null);
/*  944 */       jobChangeAdapter = new JobChangeAdapter()
/*      */         {
/*      */           public void done(IJobChangeEvent event) {
/*  947 */             barrier.release();
/*      */           }
/*      */         };
/*  950 */       job.addJobChangeListener((IJobChangeListener)jobChangeAdapter);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  955 */     try { boolean canBlock = this.lockManager.canBlock();
/*      */       while (true) {
/*  957 */         if (monitor != null && monitor.isCanceled())
/*  958 */           throw new OperationCanceledException(); 
/*  959 */         long remainingTime = deadline;
/*  960 */         if (deadline != 0L) {
/*  961 */           remainingTime -= now();
/*  962 */           if (remainingTime <= 0L) {
/*  963 */             return false;
/*      */           }
/*      */         } 
/*      */         
/*  967 */         this.lockManager.aboutToWait(job.getThread());
/*      */ 
/*      */         
/*      */         try {
/*  971 */           long sleepTime = (remainingTime != 0L && remainingTime <= 100L) ? remainingTime : 100L;
/*  972 */           if (barrier.acquire(sleepTime))
/*      */             break; 
/*  974 */         } catch (InterruptedException e) {
/*      */           
/*  976 */           if (canBlock) {
/*  977 */             throw e;
/*      */           }
/*      */         } 
/*      */       }  }
/*      */     finally
/*  982 */     { this.lockManager.aboutToRelease();
/*  983 */       job.removeJobChangeListener((IJobChangeListener)jobChangeAdapter); }  this.lockManager.aboutToRelease(); job.removeJobChangeListener((IJobChangeListener)jobChangeAdapter);
/*      */     
/*  985 */     return true;
/*      */   } public void join(final Object family, IProgressMonitor monitor) throws InterruptedException, OperationCanceledException {
/*      */     JobChangeAdapter jobChangeAdapter;
/*      */     final Set<InternalJob> jobs;
/*      */     int jobCount, i;
/*  990 */     monitor = monitorFor(monitor);
/*  991 */     IJobChangeListener listener = null;
/*      */ 
/*      */     
/*  994 */     synchronized (this.lock) {
/*      */       
/*  996 */       int states = this.suspended ? 4 : 7;
/*  997 */       jobs = Collections.synchronizedSet(new HashSet<>(select(family, states)));
/*  998 */       jobCount = jobs.size();
/*  999 */       if (jobCount > 0) {
/* 1000 */         jobChangeAdapter = new JobChangeAdapter()
/*      */           {
/*      */             public void done(IJobChangeEvent event) {
/* 1003 */               Job job = event.getJob();
/* 1004 */               if (family == null || job.belongsTo(family)) {
/*      */                 
/* 1006 */                 if (((JobChangeEvent)event).reschedule) {
/*      */                   return;
/*      */                 }
/* 1009 */                 boolean removed = jobs.remove(job);
/* 1010 */                 if (!JobManager.$assertionsDisabled && !removed) throw new AssertionError(); 
/* 1011 */                 if (removed && jobs.isEmpty()) {
/* 1012 */                   synchronized (jobs) {
/* 1013 */                     jobs.notifyAll();
/*      */                   } 
/*      */                 }
/*      */               } 
/*      */             }
/*      */ 
/*      */             
/*      */             public void running(IJobChangeEvent event) {
/* 1021 */               Job job = event.getJob();
/* 1022 */               if (family == null || job.belongsTo(family))
/*      */               {
/*      */ 
/*      */                 
/* 1026 */                 jobs.add(job);
/*      */               }
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public void scheduled(IJobChangeEvent event) {
/* 1033 */               Job job = event.getJob();
/* 1034 */               if (family == null || job.belongsTo(family)) {
/*      */                 
/* 1036 */                 if (((JobChangeEvent)event).reschedule) {
/*      */                   return;
/*      */                 }
/* 1039 */                 if (JobManager.this.isSuspended())
/*      */                   return; 
/* 1041 */                 boolean added = jobs.add(job);
/* 1042 */                 if (!JobManager.$assertionsDisabled && !added) throw new AssertionError();
/*      */               
/*      */               } 
/*      */             }
/*      */           };
/* 1047 */         addJobChangeListener((IJobChangeListener)jobChangeAdapter);
/*      */       } 
/*      */     } 
/* 1050 */     if (jobCount == 0) {
/*      */       
/* 1052 */       monitor.beginTask(JobMessages.jobs_blocked0, 1);
/* 1053 */       monitor.done();
/*      */       return;
/*      */     } 
/* 1056 */     int blockReports = 0;
/*      */     
/*      */     try {
/* 1059 */       monitor.beginTask(JobMessages.jobs_blocked0, jobCount);
/* 1060 */       monitor.subTask(getWaitMessage(jobCount));
/* 1061 */       int reportedWorkDone = 0;
/* 1062 */       Set<InternalJob> reportedBlockingJobs = Set.of();
/* 1063 */       boolean first = true;
/*      */       while (true) {
/*      */         Set<InternalJob> blockingJobs;
/* 1066 */         synchronized (jobs) {
/* 1067 */           if (jobs.isEmpty()) {
/*      */             break;
/*      */           }
/* 1070 */           if (first) {
/* 1071 */             first = false;
/*      */           } else {
/*      */             
/* 1074 */             jobs.wait(100L);
/*      */             
/* 1076 */             if (jobs.isEmpty()) {
/*      */               break;
/*      */             }
/*      */           } 
/* 1080 */           blockingJobs = new HashSet<>(jobs);
/*      */         } 
/* 1082 */         int jobsLeft = blockingJobs.size();
/* 1083 */         if (!Objects.equals(reportedBlockingJobs, blockingJobs)) {
/* 1084 */           blockReports++;
/* 1085 */           reportBlocked(monitor, blockingJobs);
/* 1086 */           reportedBlockingJobs = blockingJobs;
/*      */         } 
/*      */ 
/*      */         
/* 1090 */         int actualWorkDone = Math.max(0, jobCount - jobsLeft);
/* 1091 */         if (reportedWorkDone < actualWorkDone) {
/* 1092 */           monitor.worked(actualWorkDone - reportedWorkDone);
/* 1093 */           reportedWorkDone = actualWorkDone;
/* 1094 */           monitor.subTask(getWaitMessage(jobsLeft));
/*      */         } 
/* 1096 */         if (Thread.interrupted())
/* 1097 */           throw new InterruptedException(); 
/* 1098 */         if (monitor.isCanceled()) {
/* 1099 */           throw new OperationCanceledException();
/*      */         }
/* 1101 */         this.lockManager.aboutToWait(null);
/*      */       } 
/*      */     } finally {
/* 1104 */       this.lockManager.aboutToRelease();
/* 1105 */       removeJobChangeListener((IJobChangeListener)jobChangeAdapter);
/* 1106 */       for (int j = 0; j < blockReports; j++) {
/* 1107 */         reportUnblocked(monitor);
/*      */       }
/* 1109 */       monitor.done();
/*      */     } 
/*      */   }
/*      */   boolean join(InternalJobGroup jobGroup, long timeout, IProgressMonitor monitor) throws InterruptedException, OperationCanceledException {
/*      */     int jobCount;
/* 1114 */     Assert.isLegal((jobGroup != null), "jobGroup should not be null");
/* 1115 */     Assert.isLegal((timeout >= 0L), "timeout should not be negative");
/* 1116 */     long deadline = (timeout == 0L) ? 0L : (now() + timeout);
/*      */     
/* 1118 */     synchronized (this.lock) {
/* 1119 */       jobCount = jobGroup.getActiveJobsCount();
/*      */     } 
/*      */     
/* 1122 */     SubMonitor subMonitor = SubMonitor.convert(monitor, JobMessages.jobs_blocked0, jobCount); 
/*      */     try { while (true) {
/*      */         int jobsLeft;
/* 1125 */         if (subMonitor.isCanceled())
/* 1126 */           throw new OperationCanceledException(); 
/* 1127 */         long remainingTime = deadline;
/* 1128 */         if (deadline != 0L) {
/* 1129 */           remainingTime -= now();
/* 1130 */           if (remainingTime <= 0L) {
/* 1131 */             return false;
/*      */           }
/*      */         } 
/* 1134 */         synchronized (this.lock) {
/* 1135 */           if (this.suspended && jobGroup.getRunningJobsCount() == 0)
/*      */             break; 
/*      */         } 
/* 1138 */         if (jobGroup.doJoin(remainingTime)) {
/*      */           break;
/*      */         }
/* 1141 */         synchronized (this.lock) {
/* 1142 */           jobsLeft = jobGroup.getActiveJobsCount();
/*      */         } 
/* 1144 */         if (jobsLeft < jobCount) {
/* 1145 */           subMonitor.worked(jobCount - jobsLeft);
/*      */         }
/* 1147 */         jobCount = jobsLeft;
/* 1148 */         subMonitor.setWorkRemaining(jobCount);
/* 1149 */         subMonitor.subTask(getWaitMessage(jobCount));
/*      */       }  }
/*      */     finally
/* 1152 */     { if (monitor != null)
/* 1153 */         monitor.done();  }  if (monitor != null) monitor.done();
/*      */ 
/*      */     
/* 1156 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IProgressMonitor monitorFor(IProgressMonitor monitor) {
/* 1170 */     if (this.progressProvider != null) {
/*      */       try {
/* 1172 */         IProgressMonitor monitorFor = this.progressProvider.monitorFor(monitor);
/* 1173 */         if (monitorFor == null) {
/* 1174 */           throw new IllegalStateException("Internal error: " + 
/* 1175 */               this.progressProvider.getClass().getName() + "#monitorFor(" + monitor + ") returned null!");
/*      */         }
/* 1177 */         return monitorFor;
/* 1178 */       } catch (Exception e) {
/* 1179 */         String msg = NLS.bind(JobMessages.meta_pluginProblems, "org.eclipse.core.jobs");
/* 1180 */         RuntimeLog.log((IStatus)new Status(4, "org.eclipse.core.jobs", 2, msg, e));
/*      */       } 
/*      */     }
/*      */     
/* 1184 */     if (monitor == null)
/* 1185 */       return (IProgressMonitor)new NullProgressMonitor(); 
/* 1186 */     return monitor;
/*      */   }
/*      */ 
/*      */   
/*      */   public ILock newLock() {
/* 1191 */     return this.lockManager.newLock();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Job nextJob() {
/* 1200 */     synchronized (this.lock) {
/*      */       
/* 1202 */       if (this.suspended) {
/* 1203 */         return null;
/*      */       }
/* 1205 */       long now = now();
/* 1206 */       InternalJob job = this.sleeping.peek();
/* 1207 */       while (job != null && job.getStartTime() < now) {
/* 1208 */         job.setStartTime(now + delayFor(job.getPriority()));
/* 1209 */         job.setWaitQueueStamp(getNextWaitQueueStamp());
/* 1210 */         changeState(job, 2);
/* 1211 */         job = this.sleeping.peek();
/*      */       } 
/* 1213 */       InternalJobGroup jobGroup = null;
/*      */       
/* 1215 */       job = this.waiting.peek();
/* 1216 */       while (job != null) {
/* 1217 */         InternalJob blocker = findBlockingJob(job);
/* 1218 */         JobGroup jobGroup1 = job.getJobGroup();
/*      */         
/* 1220 */         InternalJob nextWaitingJob = job.previous();
/* 1221 */         if (blocker != null) {
/*      */           
/* 1223 */           changeState(job, 8);
/*      */           
/* 1225 */           Assert.isTrue((job.next() == null));
/* 1226 */           Assert.isTrue((job.previous() == null));
/* 1227 */           blocker.addLast(job);
/* 1228 */         } else if (jobGroup1 == null || jobGroup1.getMaxThreads() == 0 || (jobGroup1.getState() != 2 && jobGroup1.getRunningJobsCount() < jobGroup1.getMaxThreads())) {
/*      */           break;
/*      */         } 
/*      */ 
/*      */         
/* 1233 */         job = (nextWaitingJob == this.waiting.dummy) ? null : nextWaitingJob;
/*      */       } 
/*      */ 
/*      */       
/* 1237 */       if (job != null) {
/* 1238 */         changeState(job, 16);
/* 1239 */         if (DEBUG)
/* 1240 */           debug("Starting job: " + job); 
/*      */       } 
/* 1242 */       return (Job)job;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long now() {
/* 1260 */     long now = this.currentTimeInMs.updateAndGet(lastValue -> Math.max(lastValue, lifeTimeInMs()));
/* 1261 */     return now;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long lifeTimeInMs() {
/* 1269 */     long now = Math.max(System.nanoTime() - this.originTime, 0L);
/* 1270 */     return now / 1000000L;
/*      */   }
/*      */ 
/*      */   
/*      */   public void optionsChanged(DebugOptions options) {
/* 1275 */     DEBUG_TRACE = options.newDebugTrace("org.eclipse.core.jobs");
/* 1276 */     DEBUG = options.getBooleanOption("org.eclipse.core.jobs/jobs", false);
/* 1277 */     DEBUG_BEGIN_END = options.getBooleanOption("org.eclipse.core.jobs/jobs/beginend", false);
/* 1278 */     DEBUG_YIELDING = options.getBooleanOption("org.eclipse.core.jobs/jobs/yielding", false);
/* 1279 */     DEBUG_YIELDING_DETAILED = options.getBooleanOption("org.eclipse.core.jobs/jobs/yielding/detailed", false);
/* 1280 */     DEBUG_DEADLOCK = options.getBooleanOption("org.eclipse.core.jobs/jobs/errorondeadlock", false);
/* 1281 */     DEBUG_LOCKS = options.getBooleanOption("org.eclipse.core.jobs/jobs/locks", false);
/* 1282 */     DEBUG_SHUTDOWN = options.getBooleanOption("org.eclipse.core.jobs/jobs/shutdown", false);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeJobChangeListener(IJobChangeListener listener) {
/* 1287 */     this.jobListeners.remove(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void reportBlocked(IProgressMonitor monitor, Collection<InternalJob> blockingJobs) {
/*      */     Status status;
/* 1302 */     InternalJob blockingJob = blockingJobs.stream().sorted(Comparator.comparing(InternalJob::isSystem)).findFirst()
/* 1303 */       .orElse(null);
/* 1304 */     if (blockingJob == null || blockingJob instanceof ThreadJob || blockingJob.isSystem()) {
/* 1305 */       status = new Status(1, "org.eclipse.core.jobs", 1, JobMessages.jobs_blocked0, null);
/*      */     } else {
/* 1307 */       String msg = NLS.bind(JobMessages.jobs_blocked1, blockingJob.getName());
/* 1308 */       status = new JobStatus(1, (Job)blockingJob, msg);
/*      */     } 
/* 1310 */     monitor.setBlocked((IStatus)status);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void reportUnblocked(IProgressMonitor monitor) {
/* 1320 */     monitor.clearBlocked();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void resume() {
/* 1325 */     synchronized (this.lock) {
/* 1326 */       this.suspended = false;
/*      */       
/* 1328 */       this.pool.jobQueued();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final void resume(ISchedulingRule rule) {
/* 1335 */     this.implicitJobs.resume(rule);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InternalJob runNow(ThreadJob job, boolean releaseWaiting) {
/* 1345 */     if (releaseWaiting) {
/* 1346 */       synchronized (this.implicitJobs) {
/* 1347 */         synchronized (this.lock) {
/* 1348 */           return doRunNow(job, releaseWaiting);
/*      */         } 
/*      */       } 
/*      */     }
/* 1352 */     synchronized (this.lock) {
/* 1353 */       return doRunNow(job, releaseWaiting);
/*      */     } 
/*      */   }
/*      */   
/*      */   private InternalJob doRunNow(ThreadJob job, boolean releaseWaiting) {
/* 1358 */     InternalJob blocking = findBlockingJob((InternalJob)job);
/*      */     
/* 1360 */     if (blocking == null) {
/* 1361 */       changeState((InternalJob)job, 4);
/* 1362 */       job.setProgressMonitor((IProgressMonitor)new NullProgressMonitor());
/* 1363 */       job.run((IProgressMonitor)null);
/* 1364 */       if (releaseWaiting)
/*      */       {
/* 1366 */         this.implicitJobs.removeWaiting(job);
/*      */       }
/*      */     } 
/* 1369 */     return blocking;
/*      */   }
/*      */   
/*      */   protected void schedule(InternalJob job, long delay) {
/* 1373 */     withWriteLock(job, j -> {
/*      */           if (scheduleInternal(paramInternalJob1, paramLong, false)) {
/*      */             this.pool.jobQueued();
/*      */           }
/*      */           return null;
/*      */         });
/*      */   }
/*      */   
/*      */   protected boolean scheduleInternal(InternalJob job, long delay, boolean reschedule) {
/* 1382 */     assert Thread.holdsLock(this.lock);
/* 1383 */     if (!this.active)
/* 1384 */       throw new IllegalStateException("Job manager has been shut down."); 
/* 1385 */     Assert.isNotNull(job, "Job is null");
/* 1386 */     Assert.isLegal((delay >= 0L), "Scheduling delay is negative");
/* 1387 */     if (!reschedule) {
/* 1388 */       job.setAboutToRunCanceled(false);
/*      */     }
/* 1390 */     if (job.getState() == 4) {
/* 1391 */       job.setStartTime(delay);
/* 1392 */       return false;
/*      */     } 
/*      */     
/* 1395 */     if (job.internalGetState() != 0)
/* 1396 */       return false; 
/* 1397 */     if (DEBUG) {
/* 1398 */       debug("Scheduling job: " + job);
/*      */     }
/*      */     
/* 1401 */     changeState(job, 32);
/* 1402 */     this.jobListeners.queueScheduled((Job)job, delay, reschedule);
/* 1403 */     doSchedule(job, delay);
/*      */     
/* 1405 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void select(List<InternalJob> members, Object family, InternalJob firstJob, int stateMask) {
/* 1412 */     if (firstJob == null)
/*      */       return; 
/* 1414 */     InternalJob job = firstJob;
/*      */     
/*      */     do {
/* 1417 */       if ((family == null || job.belongsTo(family)) && (job.getState() & stateMask) != 0)
/* 1418 */         members.add(job); 
/* 1419 */       job = job.previous();
/* 1420 */     } while (job != null && job != firstJob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<InternalJob> select(Object family) {
/* 1427 */     return select(family, 7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<InternalJob> select(Object family, int stateMask) {
/* 1435 */     List<InternalJob> members = new ArrayList<>();
/* 1436 */     synchronized (this.lock) {
/* 1437 */       if ((stateMask & 0x4) != 0) {
/* 1438 */         for (InternalJob internalJob : this.running) {
/* 1439 */           select(members, family, internalJob, stateMask);
/*      */         }
/*      */       }
/* 1442 */       if ((stateMask & 0x2) != 0) {
/* 1443 */         select(members, family, this.waiting.peek(), stateMask);
/* 1444 */         for (InternalJob internalJob : this.yielding) {
/* 1445 */           select(members, family, internalJob, stateMask);
/*      */         }
/*      */       } 
/* 1448 */       if ((stateMask & 0x1) != 0)
/* 1449 */         select(members, family, this.sleeping.peek(), stateMask); 
/*      */     } 
/* 1451 */     return members;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLockListener(LockListener listener) {
/* 1456 */     this.lockManager.setLockListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setPriority(InternalJob job, int newPriority) {
/* 1463 */     synchronized (this.lock) {
/* 1464 */       int oldPriority = job.getPriority();
/* 1465 */       if (oldPriority == newPriority)
/*      */         return; 
/* 1467 */       job.internalSetPriority(newPriority);
/*      */       
/* 1469 */       if (job.getState() == 2) {
/* 1470 */         long oldStart = job.getStartTime();
/* 1471 */         job.setStartTime(oldStart + delayFor(newPriority) - delayFor(oldPriority));
/* 1472 */         this.waiting.resort(job);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setProgressProvider(ProgressProvider provider) {
/* 1479 */     this.progressProvider = provider;
/*      */   }
/*      */   
/*      */   public void setRule(InternalJob job, ISchedulingRule rule) {
/* 1483 */     synchronized (this.lock) {
/*      */       
/* 1485 */       Assert.isLegal((job.getState() == 0));
/* 1486 */       validateRule(rule);
/* 1487 */       job.internalSetRule(rule);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean sleep(InternalJob job) {
/* 1495 */     return ((Boolean)withWriteLock(job, j -> { switch (paramInternalJob1.getState()) { case 4: if (paramInternalJob1.internalGetState() == 4) return Boolean.valueOf(false);  break;case 1: paramInternalJob1.setStartTime(Long.MAX_VALUE); changeState(paramInternalJob1, 1); return Boolean.valueOf(true);case 0: return Boolean.valueOf(true); }  paramInternalJob1.setStartTime(Long.MAX_VALUE); changeState(paramInternalJob1, 1); this.jobListeners.queueSleeping((Job)paramInternalJob1); return Boolean.valueOf(true); })).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sleep(Object family) {
/* 1525 */     for (InternalJob internalJob : select(family)) {
/* 1526 */       sleep(internalJob);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long sleepHint() {
/* 1536 */     synchronized (this.lock) {
/*      */       
/* 1538 */       if (this.suspended)
/* 1539 */         return Long.MAX_VALUE; 
/* 1540 */       if (!this.waiting.isEmpty()) {
/* 1541 */         return 0L;
/*      */       }
/* 1543 */       InternalJob next = this.sleeping.peek();
/* 1544 */       if (next == null)
/* 1545 */         return Long.MAX_VALUE; 
/* 1546 */       return next.getStartTime() - now();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected Job yieldRule(InternalJob job, IProgressMonitor monitor) {
/*      */     InternalJob unblocked;
/*      */     ThreadJob likeThreadJob;
/* 1554 */     Thread currentThread = Thread.currentThread();
/* 1555 */     Assert.isLegal((job.getState() == 4), "Cannot yieldRule job that is " + printState(job.internalGetState()));
/* 1556 */     Assert.isLegal((currentThread == job.getThread()), "Cannot yieldRule from outside job's thread");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1563 */     synchronized (this.implicitJobs) {
/* 1564 */       synchronized (this.lock) {
/*      */         
/* 1566 */         likeThreadJob = this.implicitJobs.getThreadJob(currentThread);
/*      */         
/* 1568 */         unblocked = job.previous();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1573 */         if (unblocked == null)
/*      */         {
/* 1575 */           if (likeThreadJob != null) {
/*      */ 
/*      */             
/* 1578 */             unblocked = likeThreadJob.previous();
/*      */             
/* 1580 */             if (unblocked == null)
/*      */             {
/*      */               
/* 1583 */               unblocked = findBlockedJob((InternalJob)likeThreadJob);
/*      */             
/*      */             }
/*      */           }
/*      */           else {
/*      */             
/* 1589 */             unblocked = findBlockedJob(job);
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/* 1594 */         if (unblocked == null) {
/* 1595 */           return null;
/*      */         }
/*      */         
/* 1598 */         changeState(job, 64);
/* 1599 */         if (DEBUG_YIELDING) {
/* 1600 */           debug(job + " will yieldRule to " + unblocked);
/*      */         }
/* 1602 */         if (likeThreadJob != null && likeThreadJob != job) {
/*      */           
/* 1604 */           changeState((InternalJob)likeThreadJob, 64);
/* 1605 */           if (DEBUG_YIELDING) {
/* 1606 */             debug(job + " will yieldRule to " + unblocked);
/*      */           }
/*      */         } 
/* 1609 */         if (likeThreadJob != null) {
/*      */           
/* 1611 */           job.setThread(null);
/* 1612 */           if (likeThreadJob.getRule() != null) {
/* 1613 */             getLockManager().removeLockThread(currentThread, likeThreadJob.getRule());
/*      */           }
/*      */         } 
/*      */         
/* 1617 */         if (job.getRule() != null && !(job instanceof ThreadJob)) {
/* 1618 */           getLockManager().removeLockThread(currentThread, job.getRule());
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1624 */     if (DEBUG_YIELDING_DETAILED) {
/* 1625 */       debug(job + " is waiting for " + unblocked + " to transition from WAITING state");
/*      */     }
/* 1627 */     waitForUnblocked(unblocked);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1632 */     IProgressMonitor mon = monitorFor(monitor);
/* 1633 */     ProgressMonitorWrapper nonCanceling = new ProgressMonitorWrapper(mon)
/*      */       {
/*      */         public boolean isCanceled()
/*      */         {
/* 1637 */           getWrappedProgressMonitor().isCanceled();
/*      */           
/* 1639 */           return false;
/*      */         }
/*      */       };
/*      */     
/* 1643 */     if (DEBUG_YIELDING) {
/* 1644 */       debug(job + " waiting to resume");
/*      */     }
/*      */     
/* 1647 */     if (likeThreadJob == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1652 */       ThreadJob threadJob = new ThreadJob(job.getRule())
/*      */         {
/*      */           boolean isResumingAfterYield() {
/* 1655 */             return true;
/*      */           }
/*      */         };
/* 1658 */       threadJob.setRealJob((Job)job);
/* 1659 */       ThreadJob.joinRun(threadJob, (IProgressMonitor)nonCanceling);
/*      */       
/* 1661 */       synchronized (this.lock) {
/*      */         
/* 1663 */         changeState((InternalJob)threadJob, 0);
/* 1664 */         changeState(job, 4);
/* 1665 */         job.setThread(currentThread);
/*      */       } 
/*      */     } else {
/* 1668 */       ThreadJob.joinRun(likeThreadJob, (IProgressMonitor)nonCanceling);
/* 1669 */       synchronized (this.lock) {
/* 1670 */         changeState(job, 4);
/* 1671 */         job.setThread(currentThread);
/*      */       } 
/*      */     } 
/* 1674 */     if (DEBUG_YIELDING) {
/*      */       
/* 1676 */       synchronized (this.lock) {
/* 1677 */         for (InternalJob other : this.running) {
/* 1678 */           if (other == job)
/*      */             continue; 
/* 1680 */           Assert.isTrue(!other.isConflicting(job), other + " conflicts and ran simultaneously with " + job);
/*      */         } 
/*      */       } 
/* 1683 */       debug(job + " resumed");
/*      */     } 
/* 1685 */     if (unblocked instanceof ThreadJob && ((ThreadJob)unblocked).isResumingAfterYield())
/*      */     {
/*      */       
/* 1688 */       return ((ThreadJob)unblocked).realJob;
/*      */     }
/* 1690 */     return (Job)unblocked;
/*      */   }
/*      */ 
/*      */   
/*      */   private void waitForUnblocked(InternalJob theJob) {
/* 1695 */     boolean interrupted = false;
/* 1696 */     synchronized (theJob.jobStateLock) {
/* 1697 */       if (theJob instanceof ThreadJob) {
/*      */ 
/*      */         
/* 1700 */         while (((ThreadJob)theJob).isWaiting) {
/*      */           try {
/* 1702 */             theJob.jobStateLock.wait();
/* 1703 */           } catch (InterruptedException interruptedException) {
/* 1704 */             interrupted = true;
/*      */           } 
/*      */         } 
/*      */       } else {
/* 1708 */         while (theJob.internalGetState() == 2) {
/*      */           try {
/* 1710 */             theJob.jobStateLock.wait();
/* 1711 */           } catch (InterruptedException interruptedException) {
/* 1712 */             interrupted = true;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1717 */     if (interrupted) {
/* 1718 */       Thread.currentThread().interrupt();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean shouldRun(Job job) {
/*      */     try {
/* 1727 */       return job.shouldRun();
/* 1728 */     } catch (Exception|LinkageError|AssertionError e) {
/* 1729 */       Throwable t = e;
/*      */       
/* 1731 */       RuntimeLog.log((IStatus)new Status(4, "org.eclipse.core.jobs", 2, "Error invoking shouldRun() method on: " + job, t));
/*      */       
/* 1733 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Job startJob(Worker worker) {
/* 1741 */     Job job = null;
/*      */     while (true) {
/* 1743 */       job = nextJob();
/* 1744 */       if (job == null) {
/* 1745 */         return null;
/*      */       }
/*      */       
/* 1748 */       boolean shouldRun = shouldRun(job);
/*      */       
/* 1750 */       if (shouldRun) {
/* 1751 */         this.jobListeners.queueAboutToRun(job);
/* 1752 */         this.jobListeners.waitAndSendEvents((InternalJob)job, true);
/*      */       } 
/*      */       
/* 1755 */       Boolean endJob = withWriteLock(job, j -> {
/*      */             JobGroup jobGroup = j.getJobGroup();
/* 1757 */             boolean shouldReallyRun = (paramBoolean && (jobGroup == null || jobGroup.getState() != 2));
/*      */             
/*      */             Job job = j;
/*      */             
/*      */             synchronized (((InternalJob)job).jobStateLock) {
/*      */               if (job.internalGetState() == 16) {
/*      */                 if (shouldReallyRun && !job.isAboutToRunCanceled()) {
/*      */                   job.setProgressMonitor(createMonitor(j));
/*      */                   job.setThread(paramWorker);
/*      */                   job.internalSetState(4);
/*      */                   ((InternalJob)job).jobStateLock.notifyAll();
/*      */                   this.jobListeners.queueRunning(j);
/*      */                   return null;
/*      */                 } 
/*      */                 return Boolean.valueOf(true);
/*      */               } 
/*      */             } 
/*      */             return Boolean.valueOf(false);
/*      */           });
/* 1776 */       if (endJob == null) {
/*      */         break;
/*      */       }
/* 1779 */       if (endJob.booleanValue())
/*      */       {
/* 1781 */         endJob((InternalJob)job, Status.CANCEL_STATUS, true, false);
/*      */       }
/*      */     } 
/*      */     
/* 1785 */     return job;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void suspend() {
/* 1791 */     synchronized (this.lock) {
/* 1792 */       this.suspended = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final void suspend(ISchedulingRule rule, IProgressMonitor monitor) {
/* 1799 */     Assert.isNotNull(rule);
/* 1800 */     this.implicitJobs.suspend(rule, monitorFor(monitor));
/*      */   }
/*      */ 
/*      */   
/*      */   public void transferRule(ISchedulingRule rule, Thread destinationThread) {
/* 1805 */     this.implicitJobs.transfer(rule, destinationThread);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void validateRule(ISchedulingRule rule) {
/* 1815 */     if (rule == null)
/*      */       return; 
/* 1817 */     if (rule instanceof MultiRule) {
/* 1818 */       ISchedulingRule[] children = ((MultiRule)rule).getChildren(); byte b; int i; ISchedulingRule[] arrayOfISchedulingRule1;
/* 1819 */       for (i = (arrayOfISchedulingRule1 = children).length, b = 0; b < i; ) { ISchedulingRule element = arrayOfISchedulingRule1[b];
/* 1820 */         Assert.isLegal((element != rule));
/* 1821 */         validateRule(element);
/*      */         b++; }
/*      */     
/*      */     } 
/* 1825 */     Assert.isLegal(rule.contains(rule));
/*      */     
/* 1827 */     Assert.isLegal(!rule.contains(nullRule));
/*      */     
/* 1829 */     Assert.isLegal(rule.isConflicting(rule));
/*      */     
/* 1831 */     Assert.isLegal(!rule.isConflicting(nullRule));
/*      */   }
/*      */   
/*      */   protected void wakeUp(InternalJob job, long delay) {
/* 1835 */     Assert.isLegal((delay >= 0L), "Scheduling delay is negative");
/* 1836 */     boolean notSleeping = ((Boolean)withWriteLock(job, j -> { if (paramInternalJob1.getState() != 1) return Boolean.valueOf(true);  boolean scheduled = doSchedule(paramInternalJob1, paramLong); if (scheduled && paramLong == 0L) this.jobListeners.queueAwake((Job)paramInternalJob1);  return Boolean.valueOf(false); })).booleanValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1848 */     if (notSleeping) {
/*      */       return;
/*      */     }
/*      */     
/* 1852 */     this.pool.jobQueued();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void wakeUp(Object family) {
/* 1858 */     for (InternalJob internalJob : select(family)) {
/* 1859 */       wakeUp(internalJob, 0L);
/*      */     }
/*      */   }
/*      */   
/*      */   void endMonitoring(ThreadJob threadJob) {
/* 1864 */     synchronized (this.monitorStack) {
/* 1865 */       for (int i = this.monitorStack.size() - 1; i >= 0; i--) {
/* 1866 */         if (((Object[])this.monitorStack.get(i))[0] == threadJob) {
/* 1867 */           this.monitorStack.remove(i);
/* 1868 */           this.monitorStack.notifyAll();
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   void beginMonitoring(ThreadJob threadJob, IProgressMonitor monitor) {
/* 1876 */     synchronized (this.monitorStack) {
/* 1877 */       this.monitorStack.add(new Object[] { threadJob, monitor });
/* 1878 */       this.monitorStack.notifyAll();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class JobGroupUpdater
/*      */     extends JobChangeAdapter
/*      */   {
/*      */     public void done(IJobChangeEvent event) {
/*      */       int jobGroupState, activeJobsCount, failedJobsCount, canceledJobsCount, seedJobsRemainingCount;
/* 1890 */       Job job = event.getJob();
/* 1891 */       JobGroup jobGroup = job.getJobGroup();
/* 1892 */       if (jobGroup == null)
/*      */         return; 
/* 1894 */       IStatus jobResult = event.getResult();
/* 1895 */       boolean reschedule = ((JobChangeEvent)event).reschedule;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1902 */       List<IStatus> jobResults = Collections.emptyList();
/* 1903 */       synchronized (JobManager.this.lock) {
/*      */ 
/*      */         
/* 1906 */         jobGroupState = jobGroup.getState();
/* 1907 */         activeJobsCount = jobGroup.getActiveJobsCount();
/* 1908 */         failedJobsCount = jobGroup.getFailedJobsCount();
/* 1909 */         canceledJobsCount = jobGroup.getCanceledJobsCount();
/* 1910 */         seedJobsRemainingCount = jobGroup.getSeedJobsRemainingCount();
/* 1911 */         if (activeJobsCount == 0) {
/* 1912 */           jobResults = jobGroup.getCompletedJobResults();
/*      */         }
/*      */       } 
/*      */       
/* 1916 */       if (!reschedule && jobGroupState != 0 && activeJobsCount == 0 && (seedJobsRemainingCount <= 0 || jobGroupState == 2)) {
/*      */         
/* 1918 */         MultiStatus jobGroupResult = jobGroup.computeGroupResult(jobResults);
/* 1919 */         Assert.isLegal((jobGroupResult != null), "The group result should not be null");
/* 1920 */         boolean isJobGroupCompleted = false;
/* 1921 */         synchronized (JobManager.this.lock) {
/*      */ 
/*      */ 
/*      */           
/* 1925 */           if (jobGroup.getState() != 0 && jobGroup.getActiveJobsCount() == 0) {
/* 1926 */             jobGroup.endJobGroup(jobGroupResult);
/* 1927 */             isJobGroupCompleted = true;
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1933 */         if (isJobGroupCompleted) {
/* 1934 */           ((JobChangeEvent)event).jobGroupResult = (IStatus)jobGroupResult;
/* 1935 */           if (jobGroupResult.matches(6)) {
/* 1936 */             RuntimeLog.log((IStatus)jobGroupResult);
/*      */           }
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/* 1942 */       if (jobGroupState != 2 && jobGroup.shouldCancel(jobResult, failedJobsCount, canceledJobsCount)) {
/* 1943 */         JobManager.this.cancel((InternalJobGroup)jobGroup, true);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1950 */     synchronized (this.lock) {
/* 1951 */       return "waiting: " + this.waiting + "\nsleeping: " + this.sleeping + "\nrunnning: " + this.running + "\nyielding: " + 
/* 1952 */         this.yielding;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\internal\jobs\JobManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */