package org.eclipse.core.runtime.jobs;

import org.eclipse.core.runtime.IStatus;

public interface IJobChangeEvent {
  long getDelay();
  
  Job getJob();
  
  IStatus getResult();
  
  IStatus getJobGroupResult();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\runtime\jobs\IJobChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */