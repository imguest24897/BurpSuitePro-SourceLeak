package org.eclipse.core.runtime.jobs;

public interface ISchedulingRule {
  boolean contains(ISchedulingRule paramISchedulingRule);
  
  boolean isConflicting(ISchedulingRule paramISchedulingRule);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.jobs-3.14.0.jar!\org\eclipse\core\runtime\jobs\ISchedulingRule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */