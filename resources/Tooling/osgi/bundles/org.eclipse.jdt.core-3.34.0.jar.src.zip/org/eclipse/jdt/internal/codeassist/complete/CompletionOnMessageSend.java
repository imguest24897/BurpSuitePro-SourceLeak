/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.MessageSend;
/*    */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnMessageSend
/*    */   extends MessageSend
/*    */ {
/*    */   public TypeBinding resolveType(BlockScope scope) {
/* 46 */     this.constant = Constant.NotAConstant;
/* 47 */     if (this.arguments != null) {
/* 48 */       int argsLength = this.arguments.length;
/* 49 */       for (int a = argsLength; --a >= 0;) {
/*    */         try {
/* 51 */           this.arguments[a].resolveType(scope);
/* 52 */         } catch (CompletionNodeFound completionNodeFound) {}
/*    */       } 
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 58 */     if (this.receiver.isImplicitThis()) {
/* 59 */       throw new CompletionNodeFound(this, null, scope);
/*    */     }
/* 61 */     this.actualReceiverType = this.receiver.resolveType(scope);
/* 62 */     if (this.actualReceiverType == null || this.actualReceiverType.isBaseType()) {
/* 63 */       throw new CompletionNodeFound();
/*    */     }
/* 65 */     if (this.actualReceiverType.isArrayType())
/* 66 */       this.actualReceiverType = (TypeBinding)scope.getJavaLangObject(); 
/* 67 */     throw new CompletionNodeFound(this, this.actualReceiverType, scope);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 73 */     output.append("<CompleteOnMessageSend:");
/* 74 */     if (!this.receiver.isImplicitThis()) this.receiver.printExpression(0, output).append('.'); 
/* 75 */     if (this.typeArguments != null) {
/* 76 */       output.append('<');
/* 77 */       int max = this.typeArguments.length - 1;
/* 78 */       for (int j = 0; j < max; j++) {
/* 79 */         this.typeArguments[j].print(0, output);
/* 80 */         output.append(", ");
/*    */       } 
/* 82 */       this.typeArguments[max].print(0, output);
/* 83 */       output.append('>');
/*    */     } 
/* 85 */     output.append(this.selector).append('(');
/* 86 */     if (this.arguments != null) {
/* 87 */       for (int i = 0; i < this.arguments.length; i++) {
/* 88 */         if (i > 0) output.append(", "); 
/* 89 */         this.arguments[i].printExpression(0, output);
/*    */       } 
/*    */     }
/* 92 */     return output.append(")>");
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnMessageSend.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */