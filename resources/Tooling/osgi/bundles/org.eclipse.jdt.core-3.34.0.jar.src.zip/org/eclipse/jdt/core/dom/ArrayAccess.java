/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayAccess
/*     */   extends Expression
/*     */ {
/*  39 */   public static final ChildPropertyDescriptor ARRAY_PROPERTY = new ChildPropertyDescriptor(ArrayAccess.class, "array", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final ChildPropertyDescriptor INDEX_PROPERTY = new ChildPropertyDescriptor(ArrayAccess.class, "index", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  56 */     List properyList = new ArrayList(3);
/*  57 */     createPropertyList(ArrayAccess.class, properyList);
/*  58 */     addProperty(ARRAY_PROPERTY, properyList);
/*  59 */     addProperty(INDEX_PROPERTY, properyList);
/*  60 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  75 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private Expression arrayExpression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private Expression indexExpression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ArrayAccess(AST ast) {
/* 101 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 106 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 111 */     if (property == ARRAY_PROPERTY) {
/* 112 */       if (get) {
/* 113 */         return getArray();
/*     */       }
/* 115 */       setArray((Expression)child);
/* 116 */       return null;
/*     */     } 
/*     */     
/* 119 */     if (property == INDEX_PROPERTY) {
/* 120 */       if (get) {
/* 121 */         return getIndex();
/*     */       }
/* 123 */       setIndex((Expression)child);
/* 124 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 128 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 133 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 138 */     ArrayAccess result = new ArrayAccess(target);
/* 139 */     result.setSourceRange(getStartPosition(), getLength());
/* 140 */     result.setArray((Expression)getArray().clone(target));
/* 141 */     result.setIndex((Expression)getIndex().clone(target));
/* 142 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 148 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 153 */     boolean visitChildren = visitor.visit(this);
/* 154 */     if (visitChildren) {
/*     */       
/* 156 */       acceptChild(visitor, getArray());
/* 157 */       acceptChild(visitor, getIndex());
/*     */     } 
/* 159 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getArray() {
/* 168 */     if (this.arrayExpression == null)
/*     */     {
/* 170 */       synchronized (this) {
/* 171 */         if (this.arrayExpression == null) {
/* 172 */           preLazyInit();
/* 173 */           this.arrayExpression = new SimpleName(this.ast);
/* 174 */           postLazyInit(this.arrayExpression, ARRAY_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 178 */     return this.arrayExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setArray(Expression expression) {
/* 193 */     if (expression == null) {
/* 194 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/* 198 */     ASTNode oldChild = this.arrayExpression;
/* 199 */     preReplaceChild(oldChild, expression, ARRAY_PROPERTY);
/* 200 */     this.arrayExpression = expression;
/* 201 */     postReplaceChild(oldChild, expression, ARRAY_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getIndex() {
/* 210 */     if (this.indexExpression == null)
/*     */     {
/* 212 */       synchronized (this) {
/* 213 */         if (this.indexExpression == null) {
/* 214 */           preLazyInit();
/* 215 */           this.indexExpression = new SimpleName(this.ast);
/* 216 */           postLazyInit(this.indexExpression, INDEX_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 220 */     return this.indexExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIndex(Expression expression) {
/* 235 */     if (expression == null) {
/* 236 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/* 240 */     ASTNode oldChild = this.indexExpression;
/* 241 */     preReplaceChild(oldChild, expression, INDEX_PROPERTY);
/* 242 */     this.indexExpression = expression;
/* 243 */     postReplaceChild(oldChild, expression, INDEX_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 248 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 253 */     return 
/* 254 */       memSize() + (
/* 255 */       (this.arrayExpression == null) ? 0 : getArray().treeSize()) + (
/* 256 */       (this.indexExpression == null) ? 0 : getIndex().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ArrayAccess.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */