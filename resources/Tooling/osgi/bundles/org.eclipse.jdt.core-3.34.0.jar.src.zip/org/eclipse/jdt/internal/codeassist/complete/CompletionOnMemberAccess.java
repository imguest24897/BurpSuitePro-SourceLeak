/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*    */ import org.eclipse.jdt.internal.compiler.ast.FieldReference;
/*    */ import org.eclipse.jdt.internal.compiler.ast.MessageSend;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ProblemMethodBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnMemberAccess
/*    */   extends FieldReference
/*    */ {
/*    */   public boolean isInsideAnnotation;
/*    */   
/*    */   public CompletionOnMemberAccess(char[] source, long pos, boolean isInsideAnnotation) {
/* 47 */     super(source, pos);
/* 48 */     this.isInsideAnnotation = isInsideAnnotation;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 54 */     output.append("<CompleteOnMemberAccess:");
/* 55 */     return super.printExpression(0, output).append('>');
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeBinding resolveType(BlockScope scope) {
/* 61 */     this.actualReceiverType = this.receiver.resolveType(scope);
/*    */     
/* 63 */     if ((this.actualReceiverType == null || !this.actualReceiverType.isValidBinding()) && this.receiver instanceof MessageSend) {
/* 64 */       MessageSend messageSend = (MessageSend)this.receiver;
/* 65 */       if (messageSend.receiver instanceof org.eclipse.jdt.internal.compiler.ast.ThisReference) {
/* 66 */         Expression[] arguments = messageSend.arguments;
/* 67 */         int length = (arguments == null) ? 0 : arguments.length;
/* 68 */         TypeBinding[] argBindings = new TypeBinding[length];
/* 69 */         for (int i = 0; i < length; i++) {
/* 70 */           argBindings[i] = (arguments[i]).resolvedType;
/* 71 */           if (argBindings[i] == null || !argBindings[i].isValidBinding()) {
/* 72 */             throw new CompletionNodeFound();
/*    */           }
/*    */         } 
/*    */         
/* 76 */         ProblemMethodBinding problemMethodBinding = new ProblemMethodBinding(messageSend.selector, argBindings, 1);
/* 77 */         throw new CompletionNodeFound(this, problemMethodBinding, scope);
/*    */       } 
/* 79 */       if (messageSend.binding != null) {
/* 80 */         throw new CompletionNodeFound(this, messageSend.binding.declaringClass, scope);
/*    */       }
/*    */     } 
/*    */     
/* 84 */     if (this.actualReceiverType == null || !this.actualReceiverType.isValidBinding()) {
/* 85 */       throw new CompletionNodeFound();
/*    */     }
/* 87 */     throw new CompletionNodeFound(this, this.actualReceiverType, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnMemberAccess.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */