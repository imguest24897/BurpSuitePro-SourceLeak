/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.CompilationUnitScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ import org.eclipse.jdt.internal.core.PackageFragment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RecoveredTypeBinding
/*     */   implements ITypeBinding
/*     */ {
/*     */   private VariableDeclaration variableDeclaration;
/*     */   private Type currentType;
/*     */   private BindingResolver resolver;
/*     */   private int dimensions;
/*     */   private RecoveredTypeBinding innerTypeBinding;
/*     */   private ITypeBinding[] typeArguments;
/*     */   private TypeBinding binding;
/*     */   
/*     */   RecoveredTypeBinding(BindingResolver resolver, VariableDeclaration variableDeclaration) {
/*  47 */     this.variableDeclaration = variableDeclaration;
/*  48 */     this.resolver = resolver;
/*  49 */     this.currentType = getType();
/*  50 */     this.dimensions = variableDeclaration.getExtraDimensions();
/*  51 */     if (this.currentType.isArrayType()) {
/*  52 */       this.dimensions += ((ArrayType)this.currentType).getDimensions();
/*     */     }
/*     */   }
/*     */   
/*     */   RecoveredTypeBinding(BindingResolver resolver, TypeBinding typeBinding) {
/*  57 */     this.resolver = resolver;
/*  58 */     this.dimensions = typeBinding.dimensions();
/*  59 */     this.binding = typeBinding;
/*     */   }
/*     */   
/*     */   RecoveredTypeBinding(BindingResolver resolver, Type type) {
/*  63 */     this.currentType = type;
/*  64 */     this.resolver = resolver;
/*  65 */     this.dimensions = 0;
/*  66 */     if (type.isArrayType()) {
/*  67 */       this.dimensions += ((ArrayType)type).getDimensions();
/*     */     }
/*     */   }
/*     */   
/*     */   RecoveredTypeBinding(BindingResolver resolver, RecoveredTypeBinding typeBinding, int dimensions) {
/*  72 */     this.innerTypeBinding = typeBinding;
/*  73 */     this.dimensions = typeBinding.getDimensions() + dimensions;
/*  74 */     this.resolver = resolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding createArrayType(int dims) {
/*  79 */     return this.resolver.getTypeBinding(this, dims);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getBinaryName() {
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding getBound() {
/*  89 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding getGenericTypeOfWildcardType() {
/*  94 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRank() {
/*  99 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding getComponentType() {
/* 104 */     if (this.dimensions == 0) return null; 
/* 105 */     return this.resolver.getTypeBinding(this, -1);
/*     */   }
/*     */ 
/*     */   
/*     */   public IVariableBinding[] getDeclaredFields() {
/* 110 */     return TypeBinding.NO_VARIABLE_BINDINGS;
/*     */   }
/*     */ 
/*     */   
/*     */   public IMethodBinding[] getDeclaredMethods() {
/* 115 */     return TypeBinding.NO_METHOD_BINDINGS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDeclaredModifiers() {
/* 124 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding[] getDeclaredTypes() {
/* 129 */     return TypeBinding.NO_TYPE_BINDINGS;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding getDeclaringClass() {
/* 134 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IMethodBinding getDeclaringMethod() {
/* 139 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IBinding getDeclaringMember() {
/* 144 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDimensions() {
/* 149 */     return this.dimensions;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding getElementType() {
/* 154 */     if (this.binding != null) {
/* 155 */       if (this.binding.isArrayType()) {
/* 156 */         ArrayBinding arrayBinding = (ArrayBinding)this.binding;
/* 157 */         return new RecoveredTypeBinding(this.resolver, arrayBinding.leafComponentType);
/*     */       } 
/* 159 */       return new RecoveredTypeBinding(this.resolver, this.binding);
/*     */     } 
/*     */     
/* 162 */     if (this.innerTypeBinding != null) {
/* 163 */       return this.innerTypeBinding.getElementType();
/*     */     }
/* 165 */     if (this.currentType != null && this.currentType.isArrayType()) {
/* 166 */       return this.resolver.getTypeBinding(((ArrayType)this.currentType).getElementType());
/*     */     }
/* 168 */     if (this.variableDeclaration != null && this.variableDeclaration.getExtraDimensions() != 0) {
/* 169 */       return this.resolver.getTypeBinding(getType());
/*     */     }
/* 171 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding getErasure() {
/* 176 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public IMethodBinding getFunctionalInterfaceMethod() {
/* 181 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding[] getInterfaces() {
/* 186 */     return TypeBinding.NO_TYPE_BINDINGS;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 191 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 196 */     char[] brackets = new char[this.dimensions * 2];
/* 197 */     for (int i = this.dimensions * 2 - 1; i >= 0; i -= 2) {
/* 198 */       brackets[i] = ']';
/* 199 */       brackets[i - 1] = '[';
/*     */     } 
/* 201 */     StringBuffer buffer = new StringBuffer(getInternalName());
/* 202 */     buffer.append(brackets);
/* 203 */     return String.valueOf(buffer);
/*     */   }
/*     */   
/*     */   private String getInternalName() {
/* 207 */     if (this.innerTypeBinding != null) {
/* 208 */       return this.innerTypeBinding.getInternalName();
/*     */     }
/* 210 */     ReferenceBinding referenceBinding = getReferenceBinding();
/* 211 */     if (referenceBinding != null) {
/* 212 */       return new String(referenceBinding.compoundName[referenceBinding.compoundName.length - 1]);
/*     */     }
/* 214 */     return getTypeNameFrom(getType());
/*     */   }
/*     */ 
/*     */   
/*     */   public IModuleBinding getModule() {
/* 219 */     if (this.binding != null) {
/* 220 */       switch (this.binding.kind()) {
/*     */         case 68:
/*     */         case 132:
/*     */         case 516:
/*     */         case 4100:
/*     */         case 8196:
/* 226 */           return null;
/*     */       } 
/* 228 */       return getModule(this.binding.getPackage());
/*     */     } 
/* 230 */     CompilationUnitScope scope = this.resolver.scope();
/* 231 */     return (scope != null) ? getModule(scope.getCurrentPackage()) : null;
/*     */   }
/*     */   
/*     */   private IModuleBinding getModule(PackageBinding pBinding) {
/* 235 */     IPackageBinding packageBinding = this.resolver.getPackageBinding(pBinding);
/* 236 */     return (packageBinding != null) ? packageBinding.getModule() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IPackageBinding getPackage() {
/* 241 */     if (this.binding != null) {
/* 242 */       switch (this.binding.kind()) {
/*     */         case 68:
/*     */         case 132:
/*     */         case 516:
/*     */         case 4100:
/*     */         case 8196:
/* 248 */           return null;
/*     */       } 
/* 250 */       IPackageBinding packageBinding = this.resolver.getPackageBinding(this.binding.getPackage());
/* 251 */       if (packageBinding != null) return packageBinding; 
/*     */     } 
/* 253 */     if (this.innerTypeBinding != null && this.dimensions > 0) {
/* 254 */       return null;
/*     */     }
/* 256 */     CompilationUnitScope scope = this.resolver.scope();
/* 257 */     if (scope != null) {
/* 258 */       return this.resolver.getPackageBinding(scope.getCurrentPackage());
/*     */     }
/* 260 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getQualifiedName() {
/* 265 */     ReferenceBinding referenceBinding = getReferenceBinding();
/* 266 */     if (referenceBinding != null) {
/* 267 */       StringBuffer buffer = new StringBuffer();
/* 268 */       char[] brackets = new char[this.dimensions * 2];
/* 269 */       for (int i = this.dimensions * 2 - 1; i >= 0; i -= 2) {
/* 270 */         brackets[i] = ']';
/* 271 */         brackets[i - 1] = '[';
/*     */       } 
/* 273 */       buffer.append(CharOperation.toString(referenceBinding.compoundName));
/* 274 */       buffer.append(brackets);
/* 275 */       return String.valueOf(buffer);
/*     */     } 
/* 277 */     return getName();
/*     */   }
/*     */ 
/*     */   
/*     */   private ReferenceBinding getReferenceBinding() {
/* 282 */     if (this.binding != null) {
/* 283 */       if (this.binding.isArrayType()) {
/* 284 */         ArrayBinding arrayBinding = (ArrayBinding)this.binding;
/* 285 */         if (arrayBinding.leafComponentType instanceof ReferenceBinding) {
/* 286 */           return (ReferenceBinding)arrayBinding.leafComponentType;
/*     */         }
/* 288 */       } else if (this.binding instanceof ReferenceBinding) {
/* 289 */         return (ReferenceBinding)this.binding;
/*     */       } 
/* 291 */     } else if (this.innerTypeBinding != null) {
/* 292 */       return this.innerTypeBinding.getReferenceBinding();
/*     */     } 
/* 294 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding getSuperclass() {
/* 299 */     if (getQualifiedName().equals("java.lang.Object")) {
/* 300 */       return null;
/*     */     }
/* 302 */     return this.resolver.resolveWellKnownType("java.lang.Object");
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding[] getTypeArguments() {
/* 307 */     if (this.binding != null) {
/* 308 */       return this.typeArguments = TypeBinding.NO_TYPE_BINDINGS;
/*     */     }
/* 310 */     if (this.typeArguments != null) {
/* 311 */       return this.typeArguments;
/*     */     }
/*     */     
/* 314 */     if (this.innerTypeBinding != null) {
/* 315 */       return this.innerTypeBinding.getTypeArguments();
/*     */     }
/*     */     
/* 318 */     if (this.currentType.isParameterizedType()) {
/* 319 */       ParameterizedType parameterizedType = (ParameterizedType)this.currentType;
/* 320 */       List<Type> typeArgumentsList = parameterizedType.typeArguments();
/* 321 */       int size = typeArgumentsList.size();
/* 322 */       ITypeBinding[] temp = new ITypeBinding[size];
/* 323 */       for (int i = 0; i < size; i++) {
/* 324 */         ITypeBinding currentTypeBinding = ((Type)typeArgumentsList.get(i)).resolveBinding();
/* 325 */         if (currentTypeBinding == null) {
/* 326 */           return this.typeArguments = TypeBinding.NO_TYPE_BINDINGS;
/*     */         }
/* 328 */         temp[i] = currentTypeBinding;
/*     */       } 
/* 330 */       return this.typeArguments = temp;
/*     */     } 
/* 332 */     return this.typeArguments = TypeBinding.NO_TYPE_BINDINGS;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding[] getTypeBounds() {
/* 337 */     return TypeBinding.NO_TYPE_BINDINGS;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding getTypeDeclaration() {
/* 342 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding[] getTypeParameters() {
/* 347 */     return TypeBinding.NO_TYPE_BINDINGS;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding getWildcard() {
/* 352 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAnnotation() {
/* 357 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAnonymous() {
/* 362 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isArray() {
/* 367 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAssignmentCompatible(ITypeBinding typeBinding) {
/* 372 */     if ("java.lang.Object".equals(typeBinding.getQualifiedName())) {
/* 373 */       return true;
/*     */     }
/*     */     
/* 376 */     return isEqualTo(typeBinding);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCapture() {
/* 381 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCastCompatible(ITypeBinding typeBinding) {
/* 386 */     if ("java.lang.Object".equals(typeBinding.getQualifiedName())) {
/* 387 */       return true;
/*     */     }
/*     */     
/* 390 */     return isEqualTo(typeBinding);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isClass() {
/* 395 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnum() {
/* 400 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRecord() {
/* 405 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFromSource() {
/* 410 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isGenericType() {
/* 415 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInterface() {
/* 420 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIntersectionType() {
/* 425 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLocal() {
/* 430 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMember() {
/* 435 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNested() {
/* 440 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNullType() {
/* 445 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isParameterizedType() {
/* 450 */     if (this.innerTypeBinding != null) {
/* 451 */       return this.innerTypeBinding.isParameterizedType();
/*     */     }
/* 453 */     if (this.currentType != null) {
/* 454 */       return this.currentType.isParameterizedType();
/*     */     }
/* 456 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPrimitive() {
/* 461 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRawType() {
/* 466 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSubTypeCompatible(ITypeBinding typeBinding) {
/* 471 */     if ("java.lang.Object".equals(typeBinding.getQualifiedName())) {
/* 472 */       return true;
/*     */     }
/*     */     
/* 475 */     return isEqualTo(typeBinding);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTopLevel() {
/* 480 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTypeVariable() {
/* 485 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUpperbound() {
/* 490 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWildcardType() {
/* 495 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public IAnnotationBinding[] getAnnotations() {
/* 500 */     return (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public IJavaElement getJavaElement() {
/* 505 */     IPackageBinding packageBinding = getPackage();
/* 506 */     if (packageBinding != null) {
/* 507 */       IJavaElement javaElement = packageBinding.getJavaElement();
/* 508 */       if (javaElement != null && javaElement.getElementType() == 4)
/*     */       {
/* 510 */         return (IJavaElement)((PackageFragment)javaElement).getCompilationUnit(String.valueOf(getInternalName()) + ".java").getType(getName());
/*     */       }
/*     */     } 
/* 513 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 518 */     StringBuffer buffer = new StringBuffer();
/* 519 */     buffer.append("Recovered#");
/* 520 */     if (this.innerTypeBinding != null) {
/* 521 */       buffer.append("innerTypeBinding")
/* 522 */         .append(this.innerTypeBinding.getKey());
/* 523 */     } else if (this.currentType != null) {
/* 524 */       buffer.append("currentType")
/* 525 */         .append(this.currentType.toString());
/* 526 */     } else if (this.binding != null) {
/* 527 */       buffer.append("typeBinding")
/* 528 */         .append(this.binding.computeUniqueKey());
/* 529 */     } else if (this.variableDeclaration != null) {
/* 530 */       buffer
/* 531 */         .append("variableDeclaration")
/* 532 */         .append(this.variableDeclaration.getClass())
/* 533 */         .append(this.variableDeclaration.getName().getIdentifier())
/* 534 */         .append(this.variableDeclaration.getExtraDimensions());
/*     */     } 
/* 536 */     buffer.append(getDimensions());
/* 537 */     if (this.typeArguments != null) {
/* 538 */       buffer.append('<');
/* 539 */       for (int i = 0, max = this.typeArguments.length; i < max; i++) {
/* 540 */         if (i != 0) {
/* 541 */           buffer.append(',');
/*     */         }
/* 543 */         buffer.append(this.typeArguments[i].getKey());
/*     */       } 
/* 545 */       buffer.append('>');
/*     */     } 
/* 547 */     return String.valueOf(buffer);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getKind() {
/* 552 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDeprecated() {
/* 557 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEqualTo(IBinding other) {
/* 562 */     if (!other.isRecovered() || other.getKind() != 2) return false; 
/* 563 */     return getKey().equals(other.getKey());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRecovered() {
/* 568 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSynthetic() {
/* 573 */     return false; } private String getTypeNameFrom(Type type) { ArrayType arrayType; ParameterizedType parameterizedType; StringBuffer buffer; ITypeBinding[] tArguments; int typeArgumentsLength; PrimitiveType primitiveType; QualifiedType qualifiedType;
/*     */     NameQualifiedType nameQualifiedType;
/*     */     SimpleType simpleType;
/*     */     Name name;
/* 577 */     if (type == null) return Util.EMPTY_STRING; 
/* 578 */     switch (type.getNodeType0()) {
/*     */       case 5:
/* 580 */         arrayType = (ArrayType)type;
/* 581 */         type = arrayType.getElementType();
/* 582 */         return getTypeNameFrom(type);
/*     */       case 74:
/* 584 */         parameterizedType = (ParameterizedType)type;
/* 585 */         buffer = new StringBuffer(getTypeNameFrom(parameterizedType.getType()));
/* 586 */         tArguments = getTypeArguments();
/* 587 */         typeArgumentsLength = tArguments.length;
/* 588 */         if (typeArgumentsLength != 0) {
/* 589 */           buffer.append('<');
/* 590 */           for (int i = 0; i < typeArgumentsLength; i++) {
/* 591 */             if (i > 0) {
/* 592 */               buffer.append(',');
/*     */             }
/* 594 */             buffer.append(tArguments[i].getName());
/*     */           } 
/* 596 */           buffer.append('>');
/*     */         } 
/* 598 */         return String.valueOf(buffer);
/*     */       case 39:
/* 600 */         primitiveType = (PrimitiveType)type;
/* 601 */         return primitiveType.getPrimitiveTypeCode().toString();
/*     */       case 75:
/* 603 */         qualifiedType = (QualifiedType)type;
/* 604 */         return qualifiedType.getName().getIdentifier();
/*     */       case 88:
/* 606 */         nameQualifiedType = (NameQualifiedType)type;
/* 607 */         return nameQualifiedType.getName().getIdentifier();
/*     */       case 43:
/* 609 */         simpleType = (SimpleType)type;
/* 610 */         name = simpleType.getName();
/* 611 */         if (name.isQualifiedName()) {
/* 612 */           QualifiedName qualifiedName = (QualifiedName)name;
/* 613 */           return qualifiedName.getName().getIdentifier();
/*     */         } 
/* 615 */         return ((SimpleName)name).getIdentifier();
/*     */     } 
/* 617 */     return Util.EMPTY_STRING; } private Type getType() { SingleVariableDeclaration singleVariableDeclaration;
/*     */     VariableDeclarationExpression variableDeclarationExpression;
/*     */     VariableDeclarationStatement statement;
/*     */     FieldDeclaration fieldDeclaration;
/* 621 */     if (this.currentType != null) {
/* 622 */       return this.currentType;
/*     */     }
/* 624 */     if (this.variableDeclaration == null) return null; 
/* 625 */     switch (this.variableDeclaration.getNodeType()) {
/*     */       case 44:
/* 627 */         singleVariableDeclaration = (SingleVariableDeclaration)this.variableDeclaration;
/* 628 */         return singleVariableDeclaration.getType();
/*     */     } 
/*     */     
/* 631 */     ASTNode parent = this.variableDeclaration.getParent();
/* 632 */     switch (parent.getNodeType()) {
/*     */       case 58:
/* 634 */         variableDeclarationExpression = (VariableDeclarationExpression)parent;
/* 635 */         return variableDeclarationExpression.getType();
/*     */       case 60:
/* 637 */         statement = (VariableDeclarationStatement)parent;
/* 638 */         return statement.getType();
/*     */       case 23:
/* 640 */         fieldDeclaration = (FieldDeclaration)parent;
/* 641 */         return fieldDeclaration.getType();
/*     */     } 
/*     */     
/* 644 */     return null; }
/*     */ 
/*     */ 
/*     */   
/*     */   public IAnnotationBinding[] getTypeAnnotations() {
/* 649 */     return (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\RecoveredTypeBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */