/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationTypeMemberDeclaration
/*     */   extends BodyDeclaration
/*     */ {
/*  50 */   public static final ChildPropertyDescriptor JAVADOC_PROPERTY = internalJavadocPropertyFactory(AnnotationTypeMemberDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   public static final ChildListPropertyDescriptor MODIFIERS2_PROPERTY = internalModifiers2PropertyFactory(AnnotationTypeMemberDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public static final ChildPropertyDescriptor TYPE_PROPERTY = new ChildPropertyDescriptor(AnnotationTypeMemberDeclaration.class, "type", Type.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(AnnotationTypeMemberDeclaration.class, "name", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public static final ChildPropertyDescriptor DEFAULT_PROPERTY = new ChildPropertyDescriptor(AnnotationTypeMemberDeclaration.class, "default", Expression.class, false, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  84 */     List properyList = new ArrayList(6);
/*  85 */     createPropertyList(AnnotationTypeMemberDeclaration.class, properyList);
/*  86 */     addProperty(JAVADOC_PROPERTY, properyList);
/*  87 */     addProperty(MODIFIERS2_PROPERTY, properyList);
/*  88 */     addProperty(TYPE_PROPERTY, properyList);
/*  89 */     addProperty(NAME_PROPERTY, properyList);
/*  90 */     addProperty(DEFAULT_PROPERTY, properyList);
/*  91 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 104 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   private Type memberType = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   private SimpleName memberName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   private Expression optionalDefaultValue = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotationTypeMemberDeclaration(AST ast) {
/* 137 */     super(ast);
/* 138 */     unsupportedIn2();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 143 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 148 */     if (property == JAVADOC_PROPERTY) {
/* 149 */       if (get) {
/* 150 */         return getJavadoc();
/*     */       }
/* 152 */       setJavadoc((Javadoc)child);
/* 153 */       return null;
/*     */     } 
/*     */     
/* 156 */     if (property == TYPE_PROPERTY) {
/* 157 */       if (get) {
/* 158 */         return getType();
/*     */       }
/* 160 */       setType((Type)child);
/* 161 */       return null;
/*     */     } 
/*     */     
/* 164 */     if (property == NAME_PROPERTY) {
/* 165 */       if (get) {
/* 166 */         return getName();
/*     */       }
/* 168 */       setName((SimpleName)child);
/* 169 */       return null;
/*     */     } 
/*     */     
/* 172 */     if (property == DEFAULT_PROPERTY) {
/* 173 */       if (get) {
/* 174 */         return getDefault();
/*     */       }
/* 176 */       setDefault((Expression)child);
/* 177 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 181 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 186 */     if (property == MODIFIERS2_PROPERTY) {
/* 187 */       return modifiers();
/*     */     }
/*     */     
/* 190 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalJavadocProperty() {
/* 195 */     return JAVADOC_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalModifiers2Property() {
/* 200 */     return MODIFIERS2_PROPERTY;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final SimplePropertyDescriptor internalModifiersProperty() {
/* 206 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 211 */     return 82;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 216 */     AnnotationTypeMemberDeclaration result = new AnnotationTypeMemberDeclaration(target);
/* 217 */     result.setSourceRange(getStartPosition(), getLength());
/* 218 */     result.setJavadoc(
/* 219 */         (Javadoc)ASTNode.copySubtree(target, getJavadoc()));
/* 220 */     result.modifiers().addAll(ASTNode.copySubtrees(target, modifiers()));
/* 221 */     result.setType((Type)ASTNode.copySubtree(target, getType()));
/* 222 */     result.setName((SimpleName)getName().clone(target));
/* 223 */     result.setDefault((Expression)ASTNode.copySubtree(target, getDefault()));
/* 224 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 230 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 235 */     boolean visitChildren = visitor.visit(this);
/* 236 */     if (visitChildren) {
/*     */       
/* 238 */       acceptChild(visitor, getJavadoc());
/* 239 */       acceptChildren(visitor, this.modifiers);
/* 240 */       acceptChild(visitor, getType());
/* 241 */       acceptChild(visitor, getName());
/* 242 */       acceptChild(visitor, getDefault());
/*     */     } 
/* 244 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 254 */     if (this.memberType == null)
/*     */     {
/* 256 */       synchronized (this) {
/* 257 */         if (this.memberType == null) {
/* 258 */           preLazyInit();
/* 259 */           this.memberType = this.ast.newPrimitiveType(PrimitiveType.INT);
/* 260 */           postLazyInit(this.memberType, TYPE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 264 */     return this.memberType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(Type type) {
/* 279 */     if (type == null) {
/* 280 */       throw new IllegalArgumentException();
/*     */     }
/* 282 */     ASTNode oldChild = this.memberType;
/* 283 */     preReplaceChild(oldChild, type, TYPE_PROPERTY);
/* 284 */     this.memberType = type;
/* 285 */     postReplaceChild(oldChild, type, TYPE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 294 */     if (this.memberName == null)
/*     */     {
/* 296 */       synchronized (this) {
/* 297 */         if (this.memberName == null) {
/* 298 */           preLazyInit();
/* 299 */           this.memberName = new SimpleName(this.ast);
/* 300 */           postLazyInit(this.memberName, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 304 */     return this.memberName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName memberName) {
/* 319 */     if (memberName == null) {
/* 320 */       throw new IllegalArgumentException();
/*     */     }
/* 322 */     ASTNode oldChild = this.memberName;
/* 323 */     preReplaceChild(oldChild, memberName, NAME_PROPERTY);
/* 324 */     this.memberName = memberName;
/* 325 */     postReplaceChild(oldChild, memberName, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getDefault() {
/* 335 */     return this.optionalDefaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefault(Expression defaultValue) {
/* 352 */     ASTNode oldChild = this.optionalDefaultValue;
/* 353 */     preReplaceChild(oldChild, defaultValue, DEFAULT_PROPERTY);
/* 354 */     this.optionalDefaultValue = defaultValue;
/* 355 */     postReplaceChild(oldChild, defaultValue, DEFAULT_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMethodBinding resolveBinding() {
/* 370 */     return this.ast.getBindingResolver().resolveMember(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 375 */     return super.memSize() + 12;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 380 */     return 
/* 381 */       memSize() + (
/* 382 */       (this.optionalDocComment == null) ? 0 : getJavadoc().treeSize()) + 
/* 383 */       this.modifiers.listSize() + (
/* 384 */       (this.memberName == null) ? 0 : getName().treeSize()) + (
/* 385 */       (this.memberType == null) ? 0 : getType().treeSize()) + (
/* 386 */       (this.optionalDefaultValue == null) ? 0 : getDefault().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\AnnotationTypeMemberDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */