/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationTypeDeclaration
/*     */   extends AbstractTypeDeclaration
/*     */ {
/*  56 */   public static final ChildPropertyDescriptor JAVADOC_PROPERTY = internalJavadocPropertyFactory(AnnotationTypeDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public static final ChildListPropertyDescriptor MODIFIERS2_PROPERTY = internalModifiers2PropertyFactory(AnnotationTypeDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public static final ChildPropertyDescriptor NAME_PROPERTY = internalNamePropertyFactory(AnnotationTypeDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public static final ChildListPropertyDescriptor BODY_DECLARATIONS_PROPERTY = internalBodyDeclarationPropertyFactory(AnnotationTypeDeclaration.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  84 */     List properyList = new ArrayList(5);
/*  85 */     createPropertyList(AnnotationTypeDeclaration.class, properyList);
/*  86 */     addProperty(JAVADOC_PROPERTY, properyList);
/*  87 */     addProperty(MODIFIERS2_PROPERTY, properyList);
/*  88 */     addProperty(NAME_PROPERTY, properyList);
/*  89 */     addProperty(BODY_DECLARATIONS_PROPERTY, properyList);
/*  90 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 104 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotationTypeDeclaration(AST ast) {
/* 121 */     super(ast);
/* 122 */     unsupportedIn2();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 127 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 132 */     if (property == JAVADOC_PROPERTY) {
/* 133 */       if (get) {
/* 134 */         return getJavadoc();
/*     */       }
/* 136 */       setJavadoc((Javadoc)child);
/* 137 */       return null;
/*     */     } 
/*     */     
/* 140 */     if (property == NAME_PROPERTY) {
/* 141 */       if (get) {
/* 142 */         return getName();
/*     */       }
/* 144 */       setName((SimpleName)child);
/* 145 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 149 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 154 */     if (property == MODIFIERS2_PROPERTY) {
/* 155 */       return modifiers();
/*     */     }
/* 157 */     if (property == BODY_DECLARATIONS_PROPERTY) {
/* 158 */       return bodyDeclarations();
/*     */     }
/*     */     
/* 161 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalJavadocProperty() {
/* 166 */     return JAVADOC_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalModifiers2Property() {
/* 171 */     return MODIFIERS2_PROPERTY;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final SimplePropertyDescriptor internalModifiersProperty() {
/* 177 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalNameProperty() {
/* 182 */     return NAME_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalBodyDeclarationsProperty() {
/* 187 */     return BODY_DECLARATIONS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 192 */     return 81;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 197 */     AnnotationTypeDeclaration result = new AnnotationTypeDeclaration(target);
/* 198 */     result.setSourceRange(getStartPosition(), getLength());
/* 199 */     result.setJavadoc(
/* 200 */         (Javadoc)ASTNode.copySubtree(target, getJavadoc()));
/* 201 */     result.modifiers().addAll(ASTNode.copySubtrees(target, modifiers()));
/* 202 */     result.setName((SimpleName)getName().clone(target));
/* 203 */     result.bodyDeclarations().addAll(ASTNode.copySubtrees(target, bodyDeclarations()));
/* 204 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 210 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 215 */     boolean visitChildren = visitor.visit(this);
/* 216 */     if (visitChildren) {
/*     */       
/* 218 */       acceptChild(visitor, getJavadoc());
/* 219 */       acceptChildren(visitor, this.modifiers);
/* 220 */       acceptChild(visitor, getName());
/* 221 */       acceptChildren(visitor, this.bodyDeclarations);
/*     */     } 
/* 223 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   ITypeBinding internalResolveBinding() {
/* 228 */     return this.ast.getBindingResolver().resolveType(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 233 */     return super.memSize();
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 238 */     return 
/* 239 */       memSize() + (
/* 240 */       (this.optionalDocComment == null) ? 0 : getJavadoc().treeSize()) + 
/* 241 */       this.modifiers.listSize() + (
/* 242 */       (this.typeName == null) ? 0 : getName().treeSize()) + 
/* 243 */       this.bodyDeclarations.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\AnnotationTypeDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */