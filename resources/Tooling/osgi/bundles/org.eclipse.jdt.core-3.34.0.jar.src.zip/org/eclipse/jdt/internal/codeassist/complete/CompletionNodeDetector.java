/*     */ package org.eclipse.jdt.internal.codeassist.complete;
/*     */ import org.eclipse.jdt.internal.compiler.ast.AND_AND_Expression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*     */ import org.eclipse.jdt.internal.compiler.ast.AllocationExpression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ArrayQualifiedTypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ArrayReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ArrayTypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Assignment;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ConditionalExpression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.FieldReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.MemberValuePair;
/*     */ import org.eclipse.jdt.internal.compiler.ast.MessageSend;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ParameterizedQualifiedTypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ParameterizedSingleTypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.QualifiedTypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ReferenceExpression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.SingleTypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.SwitchStatement;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ 
/*     */ public class CompletionNodeDetector extends ASTVisitor {
/*     */   private ASTNode searchedNode;
/*     */   private ASTNode parent;
/*     */   private Expression outerExpression;
/*     */   
/*     */   static class FindAny extends GenericAstVisitor {
/*     */     private ASTNode searchFor;
/*     */     
/*     */     public FindAny(ASTNode searchFor) {
/*  32 */       this.searchFor = searchFor;
/*     */     }
/*     */     boolean found;
/*     */     
/*     */     protected boolean visitNode(ASTNode node) {
/*  37 */       if (node == this.searchFor) {
/*  38 */         this.found = true;
/*     */       }
/*  40 */       return !this.found;
/*     */     } }
/*     */   
/*     */   public static boolean findAny(CompilationUnitDeclaration unit, ASTNode searchFor) {
/*  44 */     FindAny visitor = new FindAny(searchFor);
/*  45 */     unit.traverse((ASTVisitor)visitor, null, false);
/*  46 */     return visitor.found;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class StopTraversal
/*     */     extends RuntimeException {}
/*     */ 
/*     */   
/*  55 */   private Stack<ASTNode> interestingEnclosings = new Stack<>();
/*     */   private ASTNode enclosingNode;
/*     */   private boolean result;
/*     */   private ASTNode blockedNode;
/*     */   private boolean containsPotentialPolyExpression = false;
/*     */   
/*     */   public CompletionNodeDetector(ASTNode searchedNode, ASTNode visitedAst) {
/*  62 */     this.searchedNode = searchedNode;
/*  63 */     this.result = false;
/*     */     
/*  65 */     if (searchedNode != null && visitedAst != null) {
/*     */       try {
/*  67 */         if (visitedAst instanceof AbstractMethodDeclaration) {
/*  68 */           ((AbstractMethodDeclaration)visitedAst).traverse(this, null);
/*  69 */         } else if (visitedAst instanceof CompilationUnitDeclaration) {
/*  70 */           ((CompilationUnitDeclaration)visitedAst).traverse(this, null);
/*     */         } else {
/*  72 */           visitedAst.traverse(this, null);
/*     */         } 
/*  74 */       } catch (StopTraversal stopTraversal) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsCompletionNode() {
/*  81 */     return this.result;
/*     */   }
/*     */   
/*     */   public ASTNode getCompletionNodeParent() {
/*  85 */     return this.parent;
/*     */   }
/*     */   public Expression getCompletionNodeOuterExpression() {
/*  88 */     if (this.outerExpression != null)
/*  89 */       return this.outerExpression; 
/*  90 */     if (this.parent instanceof Expression)
/*  91 */       return (Expression)this.parent; 
/*  92 */     return null;
/*     */   }
/*     */   
/*     */   public ASTNode getCompletionEnclosingNode() {
/*  96 */     return this.enclosingNode;
/*     */   }
/*     */ 
/*     */   
/*     */   public void endVisit(AllocationExpression allocationExpression, BlockScope scope) {
/* 101 */     endVisit((ASTNode)allocationExpression);
/*     */   }
/*     */   
/*     */   public void endVisit(AND_AND_Expression and_and_Expression, BlockScope scope) {
/* 105 */     this.interestingEnclosings.pop();
/* 106 */     endVisit((ASTNode)and_and_Expression);
/*     */   }
/*     */   
/*     */   public void endVisit(ArrayAllocationExpression arrayAllocationExpression, BlockScope scope) {
/* 110 */     endVisit((ASTNode)arrayAllocationExpression);
/*     */   }
/*     */   
/*     */   public void endVisit(ArrayInitializer arrayInitializer, BlockScope scope) {
/* 114 */     endVisit((ASTNode)arrayInitializer);
/*     */   }
/*     */   
/*     */   public void endVisit(ArrayQualifiedTypeReference arrayQualifiedTypeReference, BlockScope scope) {
/* 118 */     endVisit((ASTNode)arrayQualifiedTypeReference);
/*     */   }
/*     */   
/*     */   public void endVisit(ArrayQualifiedTypeReference arrayQualifiedTypeReference, ClassScope scope) {
/* 122 */     endVisit((ASTNode)arrayQualifiedTypeReference);
/*     */   }
/*     */   
/*     */   public void endVisit(ArrayReference arrayReference, BlockScope scope) {
/* 126 */     endVisit((ASTNode)arrayReference);
/*     */   }
/*     */   
/*     */   public void endVisit(ArrayTypeReference arrayTypeReference, BlockScope scope) {
/* 130 */     endVisit((ASTNode)arrayTypeReference);
/*     */   }
/*     */   
/*     */   public void endVisit(ArrayTypeReference arrayTypeReference, ClassScope scope) {
/* 134 */     endVisit((ASTNode)arrayTypeReference);
/*     */   }
/*     */   
/*     */   public void endVisit(Assignment assignment, BlockScope scope) {
/* 138 */     endVisit((ASTNode)assignment);
/*     */   }
/*     */   
/*     */   public void endVisit(BinaryExpression binaryExpression, BlockScope scope) {
/* 142 */     endVisit((ASTNode)binaryExpression);
/*     */   }
/*     */   
/*     */   public void endVisit(CastExpression castExpression, BlockScope scope) {
/* 146 */     endVisit((ASTNode)castExpression);
/*     */   }
/*     */   
/*     */   public void endVisit(CompoundAssignment compoundAssignment, BlockScope scope) {
/* 150 */     endVisit((ASTNode)compoundAssignment);
/*     */   }
/*     */   
/*     */   public void endVisit(ConditionalExpression conditionalExpression, BlockScope scope) {
/* 154 */     endVisit((ASTNode)conditionalExpression);
/*     */   }
/*     */   
/*     */   public void endVisit(EqualExpression equalExpression, BlockScope scope) {
/* 158 */     endVisit((ASTNode)equalExpression);
/*     */   }
/*     */   
/*     */   public void endVisit(ExplicitConstructorCall explicitConstructor, BlockScope scope) {
/* 162 */     endVisit((ASTNode)explicitConstructor);
/*     */   }
/*     */   
/*     */   public void endVisit(FieldReference fieldReference, BlockScope scope) {
/* 166 */     endVisit((ASTNode)fieldReference);
/*     */   }
/*     */   
/*     */   public void endVisit(GuardedPattern guardedPattern, BlockScope scope) {
/* 170 */     endVisit((ASTNode)guardedPattern);
/*     */   }
/*     */   
/*     */   public void endVisit(IfStatement ifStatement, BlockScope scope) {
/* 174 */     this.interestingEnclosings.pop();
/*     */   }
/*     */   
/*     */   public void endVisit(InstanceOfExpression instanceOfExpression, BlockScope scope) {
/* 178 */     endVisit((ASTNode)instanceOfExpression);
/*     */   }
/*     */   
/*     */   public void endVisit(LocalDeclaration localDeclaration, BlockScope scope) {
/* 182 */     endVisit((ASTNode)localDeclaration);
/*     */   }
/*     */   
/*     */   public void endVisit(MessageSend messageSend, BlockScope scope) {
/* 186 */     endVisit((ASTNode)messageSend);
/*     */   }
/*     */   
/*     */   public void endVisit(OR_OR_Expression or_or_Expression, BlockScope scope) {
/* 190 */     endVisit((ASTNode)or_or_Expression);
/*     */   }
/*     */   
/*     */   public void endVisit(ParameterizedQualifiedTypeReference parameterizedQualifiedTypeReference, BlockScope scope) {
/* 194 */     endVisit((ASTNode)parameterizedQualifiedTypeReference);
/*     */   }
/*     */   
/*     */   public void endVisit(ParameterizedQualifiedTypeReference parameterizedQualifiedTypeReference, ClassScope scope) {
/* 198 */     endVisit((ASTNode)parameterizedQualifiedTypeReference);
/*     */   }
/*     */   
/*     */   public void endVisit(ParameterizedSingleTypeReference parameterizedSingleTypeReference, BlockScope scope) {
/* 202 */     endVisit((ASTNode)parameterizedSingleTypeReference);
/*     */   }
/*     */   
/*     */   public void endVisit(ParameterizedSingleTypeReference parameterizedSingleTypeReference, ClassScope scope) {
/* 206 */     endVisit((ASTNode)parameterizedSingleTypeReference);
/*     */   }
/*     */   
/*     */   public void endVisit(PostfixExpression postfixExpression, BlockScope scope) {
/* 210 */     endVisit((ASTNode)postfixExpression);
/*     */   }
/*     */   
/*     */   public void endVisit(PrefixExpression prefixExpression, BlockScope scope) {
/* 214 */     endVisit((ASTNode)prefixExpression);
/*     */   }
/*     */   
/*     */   public void endVisit(QualifiedAllocationExpression qualifiedAllocationExpression, BlockScope scope) {
/* 218 */     endVisit((ASTNode)qualifiedAllocationExpression);
/*     */   }
/*     */   
/*     */   public void endVisit(QualifiedNameReference qualifiedNameReference, BlockScope scope) {
/* 222 */     endVisit((ASTNode)qualifiedNameReference);
/*     */   }
/*     */   
/*     */   public void endVisit(QualifiedSuperReference qualifiedSuperReference, BlockScope scope) {
/* 226 */     endVisit((ASTNode)qualifiedSuperReference);
/*     */   }
/*     */   
/*     */   public void endVisit(QualifiedThisReference qualifiedThisReference, BlockScope scope) {
/* 230 */     endVisit((ASTNode)qualifiedThisReference);
/*     */   }
/*     */   
/*     */   public void endVisit(QualifiedTypeReference qualifiedTypeReference, BlockScope scope) {
/* 234 */     endVisit((ASTNode)qualifiedTypeReference);
/*     */   }
/*     */   
/*     */   public void endVisit(QualifiedTypeReference qualifiedTypeReference, ClassScope scope) {
/* 238 */     endVisit((ASTNode)qualifiedTypeReference);
/*     */   }
/*     */   
/*     */   public void endVisit(ReferenceExpression referenceExpression, BlockScope blockScope) {
/* 242 */     endVisit((ASTNode)referenceExpression);
/*     */   }
/*     */   
/*     */   public void endVisit(ReturnStatement returnStatement, BlockScope scope) {
/* 246 */     endVisit((ASTNode)returnStatement);
/*     */   }
/*     */   
/*     */   public void endVisit(SingleNameReference singleNameReference, BlockScope scope) {
/* 250 */     endVisit((ASTNode)singleNameReference);
/*     */   }
/*     */   
/*     */   public void endVisit(SingleTypeReference singleTypeReference, BlockScope scope) {
/* 254 */     endVisit((ASTNode)singleTypeReference);
/*     */   }
/*     */   
/*     */   public void endVisit(SingleTypeReference singleTypeReference, ClassScope scope) {
/* 258 */     endVisit((ASTNode)singleTypeReference);
/*     */   }
/*     */   
/*     */   public void endVisit(SuperReference superReference, BlockScope scope) {
/* 262 */     endVisit((ASTNode)superReference);
/*     */   }
/*     */   
/*     */   public void endVisit(SwitchStatement switchStatement, BlockScope scope) {
/* 266 */     endVisit((ASTNode)switchStatement);
/*     */   }
/*     */   
/*     */   public void endVisit(SwitchExpression switchExpression, BlockScope scope) {
/* 270 */     endVisit((ASTNode)switchExpression);
/*     */   }
/*     */   
/*     */   public void endVisit(ThisReference thisReference, BlockScope scope) {
/* 274 */     endVisit((ASTNode)thisReference);
/*     */   }
/*     */   
/*     */   public void endVisit(UnaryExpression unaryExpression, BlockScope scope) {
/* 278 */     endVisit((ASTNode)unaryExpression);
/*     */   }
/*     */   
/*     */   public void endVisit(MemberValuePair pair, BlockScope scope) {
/* 282 */     endVisit((ASTNode)pair);
/*     */   }
/*     */   public void endVisit(MemberValuePair pair, CompilationUnitScope scope) {
/* 285 */     endVisit((ASTNode)pair);
/*     */   }
/*     */   
/*     */   public void endVisit(LambdaExpression lambda, BlockScope scope) {
/* 289 */     endVisit((ASTNode)lambda);
/*     */   }
/*     */   
/*     */   public void endVisit(MethodDeclaration methodDeclaration, ClassScope scope) {
/* 293 */     if (this.result)
/* 294 */       throw new StopTraversal(); 
/*     */   }
/*     */   
/*     */   public void endVisit(ConstructorDeclaration constructorDeclaration, ClassScope scope) {
/* 298 */     if (this.result)
/* 299 */       throw new StopTraversal(); 
/*     */   }
/*     */   
/*     */   public boolean visit(AllocationExpression allocationExpression, BlockScope scope) {
/* 303 */     return visit((ASTNode)allocationExpression);
/*     */   }
/*     */   
/*     */   public boolean visit(AND_AND_Expression and_and_Expression, BlockScope scope) {
/* 307 */     this.interestingEnclosings.add(and_and_Expression);
/* 308 */     return visit((ASTNode)and_and_Expression);
/*     */   }
/*     */   
/*     */   public boolean visit(ArrayAllocationExpression arrayAllocationExpression, BlockScope scope) {
/* 312 */     return visit((ASTNode)arrayAllocationExpression);
/*     */   }
/*     */   
/*     */   public boolean visit(ArrayInitializer arrayInitializer, BlockScope scope) {
/* 316 */     return visit((ASTNode)arrayInitializer);
/*     */   }
/*     */   
/*     */   public boolean visit(ArrayQualifiedTypeReference arrayQualifiedTypeReference, BlockScope scope) {
/* 320 */     return visit((ASTNode)arrayQualifiedTypeReference);
/*     */   }
/*     */   
/*     */   public boolean visit(ArrayQualifiedTypeReference arrayQualifiedTypeReference, ClassScope scope) {
/* 324 */     return visit((ASTNode)arrayQualifiedTypeReference);
/*     */   }
/*     */   
/*     */   public boolean visit(ArrayReference arrayReference, BlockScope scope) {
/* 328 */     return visit((ASTNode)arrayReference);
/*     */   }
/*     */   
/*     */   public boolean visit(ArrayTypeReference arrayTypeReference, BlockScope scope) {
/* 332 */     return visit((ASTNode)arrayTypeReference);
/*     */   }
/*     */   
/*     */   public boolean visit(ArrayTypeReference arrayTypeReference, ClassScope scope) {
/* 336 */     return visit((ASTNode)arrayTypeReference);
/*     */   }
/*     */   
/*     */   public boolean visit(Assignment assignment, BlockScope scope) {
/* 340 */     return visit((ASTNode)assignment);
/*     */   }
/*     */   
/*     */   public boolean visit(BinaryExpression binaryExpression, BlockScope scope) {
/* 344 */     return visit((ASTNode)binaryExpression);
/*     */   }
/*     */   
/*     */   public boolean visit(CastExpression castExpression, BlockScope scope) {
/* 348 */     return visit((ASTNode)castExpression);
/*     */   }
/*     */   
/*     */   public boolean visit(CompoundAssignment compoundAssignment, BlockScope scope) {
/* 352 */     return visit((ASTNode)compoundAssignment);
/*     */   }
/*     */   
/*     */   public boolean visit(ConditionalExpression conditionalExpression, BlockScope scope) {
/* 356 */     return visit((ASTNode)conditionalExpression);
/*     */   }
/*     */   
/*     */   public boolean visit(EqualExpression equalExpression, BlockScope scope) {
/* 360 */     return visit((ASTNode)equalExpression);
/*     */   }
/*     */   
/*     */   public boolean visit(ExplicitConstructorCall explicitConstructor, BlockScope scope) {
/* 364 */     return visit((ASTNode)explicitConstructor);
/*     */   }
/*     */   
/*     */   public boolean visit(FieldReference fieldReference, BlockScope scope) {
/* 368 */     return visit((ASTNode)fieldReference);
/*     */   }
/*     */   
/*     */   public boolean visit(GuardedPattern guardedPattern, BlockScope scope) {
/* 372 */     return visit((ASTNode)guardedPattern);
/*     */   }
/*     */   
/*     */   public boolean visit(IfStatement ifStatement, BlockScope scope) {
/* 376 */     this.interestingEnclosings.push(ifStatement);
/* 377 */     return true;
/*     */   }
/*     */   
/*     */   public boolean visit(InstanceOfExpression instanceOfExpression, BlockScope scope) {
/* 381 */     return visit((ASTNode)instanceOfExpression);
/*     */   }
/*     */   
/*     */   public boolean visit(LocalDeclaration localDeclaration, BlockScope scope) {
/* 385 */     return visit((ASTNode)localDeclaration);
/*     */   }
/*     */   
/*     */   public boolean visit(MessageSend messageSend, BlockScope scope) {
/* 389 */     return visit((ASTNode)messageSend);
/*     */   }
/*     */   
/*     */   public boolean visit(OR_OR_Expression or_or_Expression, BlockScope scope) {
/* 393 */     return visit((ASTNode)or_or_Expression);
/*     */   }
/*     */   
/*     */   public boolean visit(ParameterizedQualifiedTypeReference parameterizedQualifiedTypeReference, BlockScope scope) {
/* 397 */     return visit((ASTNode)parameterizedQualifiedTypeReference);
/*     */   }
/*     */   
/*     */   public boolean visit(ParameterizedQualifiedTypeReference parameterizedQualifiedTypeReference, ClassScope scope) {
/* 401 */     return visit((ASTNode)parameterizedQualifiedTypeReference);
/*     */   }
/*     */   
/*     */   public boolean visit(ParameterizedSingleTypeReference parameterizedSingleTypeReference, BlockScope scope) {
/* 405 */     return visit((ASTNode)parameterizedSingleTypeReference);
/*     */   }
/*     */   
/*     */   public boolean visit(ParameterizedSingleTypeReference parameterizedSingleTypeReference, ClassScope scope) {
/* 409 */     return visit((ASTNode)parameterizedSingleTypeReference);
/*     */   }
/*     */   
/*     */   public boolean visit(PostfixExpression postfixExpression, BlockScope scope) {
/* 413 */     return visit((ASTNode)postfixExpression);
/*     */   }
/*     */   
/*     */   public boolean visit(PrefixExpression prefixExpression, BlockScope scope) {
/* 417 */     return visit((ASTNode)prefixExpression);
/*     */   }
/*     */   
/*     */   public boolean visit(QualifiedAllocationExpression qualifiedAllocationExpression, BlockScope scope) {
/* 421 */     return visit((ASTNode)qualifiedAllocationExpression);
/*     */   }
/*     */   
/*     */   public boolean visit(QualifiedNameReference qualifiedNameReference, BlockScope scope) {
/* 425 */     return visit((ASTNode)qualifiedNameReference);
/*     */   }
/*     */   
/*     */   public boolean visit(QualifiedSuperReference qualifiedSuperReference, BlockScope scope) {
/* 429 */     return visit((ASTNode)qualifiedSuperReference);
/*     */   }
/*     */   
/*     */   public boolean visit(QualifiedThisReference qualifiedThisReference, BlockScope scope) {
/* 433 */     return visit((ASTNode)qualifiedThisReference);
/*     */   }
/*     */   
/*     */   public boolean visit(QualifiedTypeReference qualifiedTypeReference, BlockScope scope) {
/* 437 */     return visit((ASTNode)qualifiedTypeReference);
/*     */   }
/*     */   
/*     */   public boolean visit(QualifiedTypeReference qualifiedTypeReference, ClassScope scope) {
/* 441 */     return visit((ASTNode)qualifiedTypeReference);
/*     */   }
/*     */   
/*     */   public boolean visit(ReferenceExpression referenceExpression, BlockScope blockScope) {
/* 445 */     return visit((ASTNode)referenceExpression);
/*     */   }
/*     */   
/*     */   public boolean visit(ReturnStatement returnStatement, BlockScope scope) {
/* 449 */     return visit((ASTNode)returnStatement);
/*     */   }
/*     */   
/*     */   public boolean visit(SingleNameReference singleNameReference, BlockScope scope) {
/* 453 */     return visit((ASTNode)singleNameReference);
/*     */   }
/*     */   
/*     */   public boolean visit(SingleTypeReference singleTypeReference, BlockScope scope) {
/* 457 */     return visit((ASTNode)singleTypeReference);
/*     */   }
/*     */   
/*     */   public boolean visit(SingleTypeReference singleTypeReference, ClassScope scope) {
/* 461 */     return visit((ASTNode)singleTypeReference);
/*     */   }
/*     */   
/*     */   public boolean visit(StringLiteral stringLiteral, BlockScope scope) {
/* 465 */     return visit((ASTNode)stringLiteral);
/*     */   }
/*     */   
/*     */   public boolean visit(SuperReference superReference, BlockScope scope) {
/* 469 */     return visit((ASTNode)superReference);
/*     */   }
/*     */   
/*     */   public boolean visit(SwitchStatement switchStatement, BlockScope blockScope) {
/* 473 */     return visit((ASTNode)switchStatement);
/*     */   }
/*     */   
/*     */   public boolean visit(SwitchExpression switchExpression, BlockScope blockScope) {
/* 477 */     return visit((ASTNode)switchExpression);
/*     */   }
/*     */   
/*     */   public boolean visit(ThisReference thisReference, BlockScope scope) {
/* 481 */     return visit((ASTNode)thisReference);
/*     */   }
/*     */   
/*     */   public boolean visit(UnaryExpression unaryExpression, BlockScope scope) {
/* 485 */     return visit((ASTNode)unaryExpression);
/*     */   }
/*     */   
/*     */   public boolean visit(MemberValuePair pair, BlockScope scope) {
/* 489 */     return visit((ASTNode)pair);
/*     */   }
/*     */   public boolean visit(MemberValuePair pair, CompilationUnitScope scope) {
/* 492 */     return visit((ASTNode)pair);
/*     */   }
/*     */   private void endVisit(ASTNode astNode) {
/* 495 */     if (this.blockedNode == astNode) {
/*     */       return;
/*     */     }
/* 498 */     if (this.result) {
/* 499 */       if ((this.parent == null || (
/* 500 */         this.parent instanceof ArrayInitializer && astNode instanceof Statement)) && 
/* 501 */         astNode != this.searchedNode && (
/* 502 */         !(astNode instanceof AllocationExpression) || ((AllocationExpression)astNode).type != this.searchedNode) && (
/* 503 */         !(astNode instanceof ConditionalExpression) || ((ConditionalExpression)astNode).valueIfTrue != this.searchedNode) && (
/* 504 */         !(astNode instanceof ConditionalExpression) || ((ConditionalExpression)astNode).valueIfFalse != this.searchedNode)) {
/* 505 */         this.parent = astNode;
/*     */       }
/*     */       
/* 508 */       checkUpdateOuter(astNode);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void checkUpdateOuter(ASTNode astNode) {
/* 513 */     if (this.containsPotentialPolyExpression && astNode instanceof Expression) {
/*     */       
/* 515 */       this.outerExpression = (Expression)astNode;
/*     */     } else {
/* 517 */       this.containsPotentialPolyExpression |= isPotentiallyPolyExpression(astNode);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 523 */     if (!this.interestingEnclosings.isEmpty()) {
/*     */       Statement statement;
/* 525 */       ASTNode enclosing = this.interestingEnclosings.peek();
/* 526 */       ASTNode rightOfEnclosing = null;
/* 527 */       if (enclosing instanceof AND_AND_Expression) {
/* 528 */         Expression expression = ((AND_AND_Expression)enclosing).right;
/* 529 */       } else if (enclosing instanceof IfStatement) {
/* 530 */         statement = ((IfStatement)enclosing).thenStatement;
/*     */       } 
/* 532 */       if (statement == astNode || statement == this.enclosingNode) {
/* 533 */         this.enclosingNode = enclosing;
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 538 */     if (astNode instanceof ReturnStatement || astNode instanceof org.eclipse.jdt.internal.compiler.ast.AbstractVariableDeclaration) {
/* 539 */       this.enclosingNode = astNode;
/* 540 */       throw new StopTraversal();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isPotentiallyPolyExpression(ASTNode node) {
/* 545 */     return !(!(node instanceof org.eclipse.jdt.internal.compiler.ast.Invocation) && !(node instanceof org.eclipse.jdt.internal.compiler.ast.FunctionalExpression) && !(node instanceof ConditionalExpression));
/*     */   }
/*     */   private boolean visit(ASTNode astNode) {
/* 548 */     if (this.result) {
/* 549 */       this.blockedNode = astNode;
/*     */     }
/* 551 */     if (astNode == this.searchedNode) {
/* 552 */       this.result = true;
/*     */     }
/* 554 */     return !this.result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionNodeDetector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */