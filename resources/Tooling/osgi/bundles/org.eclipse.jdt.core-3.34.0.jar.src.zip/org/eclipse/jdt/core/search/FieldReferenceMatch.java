/*    */ package org.eclipse.jdt.core.search;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.jdt.core.IJavaElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldReferenceMatch
/*    */   extends ReferenceMatch
/*    */ {
/*    */   private boolean isReadAccess;
/*    */   private boolean isWriteAccess;
/*    */   
/*    */   public FieldReferenceMatch(IJavaElement enclosingElement, int accuracy, int offset, int length, boolean isReadAccess, boolean isWriteAccess, boolean insideDocComment, SearchParticipant participant, IResource resource) {
/* 49 */     super(enclosingElement, accuracy, offset, length, insideDocComment, participant, resource);
/* 50 */     this.isReadAccess = isReadAccess;
/* 51 */     this.isWriteAccess = isWriteAccess;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean isReadAccess() {
/* 61 */     return this.isReadAccess;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean isWriteAccess() {
/* 71 */     return this.isWriteAccess;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\search\FieldReferenceMatch.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */