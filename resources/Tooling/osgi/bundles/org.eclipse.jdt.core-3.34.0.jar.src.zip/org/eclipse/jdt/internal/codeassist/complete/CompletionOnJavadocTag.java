/*     */ package org.eclipse.jdt.internal.codeassist.complete;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.ast.CompilationUnitDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.JavadocSingleNameReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.parser.JavadocTagConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompletionOnJavadocTag
/*     */   extends JavadocSingleNameReference
/*     */   implements JavadocTagConstants, CompletionOnJavadoc
/*     */ {
/*  27 */   public int completionFlags = 1;
/*  28 */   public static final char[][][] NO_CHAR_CHAR_CHAR = new char[0][][];
/*  29 */   private char[][][] possibleTags = NO_CHAR_CHAR_CHAR;
/*     */   
/*     */   public CompletionOnJavadocTag(char[] source, long pos, int tagStart, int tagEnd, char[][][] possibleTags, boolean orphan) {
/*  32 */     super(source, pos, tagStart, tagEnd);
/*  33 */     this.possibleTags = possibleTags;
/*  34 */     if (orphan) this.completionFlags |= 0x80;
/*     */   
/*     */   }
/*     */   
/*     */   public void addCompletionFlags(int flags) {
/*  39 */     this.completionFlags |= flags;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCompletionFlags() {
/*  44 */     return this.completionFlags;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/*  49 */     output.append("<CompleteOnJavadocTag:");
/*  50 */     output.append('@');
/*  51 */     if (this.token != null) super.printExpression(indent, output);
/*     */     
/*  53 */     char[][] blockTags = this.possibleTags[0];
/*  54 */     if (blockTags != null) {
/*  55 */       int length = blockTags.length;
/*  56 */       if (length > 0) {
/*  57 */         output.append("\npossible block tags:");
/*  58 */         for (int i = 0; i < length; i++) {
/*  59 */           output.append("\n\t- ");
/*  60 */           output.append(blockTags[i]);
/*     */         } 
/*  62 */         output.append('\n');
/*     */       } 
/*     */     } 
/*     */     
/*  66 */     char[][] inlineTags = this.possibleTags[1];
/*  67 */     if (inlineTags != null) {
/*  68 */       int length = inlineTags.length;
/*  69 */       if (length > 0) {
/*  70 */         output.append("\npossible inline tags:");
/*  71 */         for (int i = 0; i < length; i++) {
/*  72 */           output.append("\n\t- ");
/*  73 */           output.append(inlineTags[i]);
/*     */         } 
/*  75 */         output.append('\n');
/*     */       } 
/*     */     } 
/*     */     
/*  79 */     char[][] snipTags = this.possibleTags[2];
/*  80 */     if (snipTags != null) {
/*  81 */       int length = snipTags.length;
/*  82 */       if (length > 0) {
/*  83 */         output.append("\npossible snippet tags:");
/*  84 */         for (int i = 0; i < length; i++) {
/*  85 */           output.append("\n\t- ");
/*  86 */           output.append(snipTags[i]);
/*     */         } 
/*  88 */         output.append('\n');
/*     */       } 
/*     */     } 
/*  91 */     return output.append('>');
/*     */   } public void filterPossibleTags(Scope scope) {
/*     */     CompilationUnitDeclaration compilationUnit;
/*     */     MethodScope methodScope;
/*  95 */     if (this.possibleTags == null || this.possibleTags.length == 0 || (this.completionFlags & 0x80) != 0) {
/*     */       return;
/*     */     }
/*  98 */     int kind = scope.kind;
/*  99 */     char[][] specifiedTags = null;
/* 100 */     switch (kind) {
/*     */ 
/*     */       
/*     */       case 4:
/* 104 */         compilationUnit = scope.referenceCompilationUnit();
/* 105 */         if (compilationUnit != null && compilationUnit.isModuleInfo()) {
/* 106 */           specifiedTags = MODULE_TAGS;
/*     */           break;
/*     */         } 
/* 109 */         if (compilationUnit != null && 
/* 110 */           compilationUnit.types.length > 0 && (compilationUnit.types[0]).name == CompletionParser.FAKE_TYPE_NAME) {
/* 111 */           specifiedTags = CLASS_TAGS; break;
/*     */         } 
/* 113 */         specifiedTags = COMPILATION_UNIT_TAGS;
/*     */         break;
/*     */       
/*     */       case 3:
/* 117 */         specifiedTags = CLASS_TAGS;
/*     */         break;
/*     */       case 2:
/* 120 */         methodScope = (MethodScope)scope;
/* 121 */         if (methodScope.referenceMethod() == null) {
/* 122 */           if (methodScope.initializedField == null) {
/* 123 */             specifiedTags = PACKAGE_TAGS; break;
/*     */           } 
/* 125 */           specifiedTags = FIELD_TAGS;
/*     */           break;
/*     */         } 
/* 128 */         specifiedTags = METHOD_TAGS;
/*     */         break;
/*     */       
/*     */       default:
/*     */         return;
/*     */     } 
/* 134 */     int kinds = this.possibleTags.length;
/* 135 */     for (int k = 0; k < kinds; k++) {
/* 136 */       int length = (this.possibleTags[k]).length;
/* 137 */       int specLenth = specifiedTags.length;
/* 138 */       char[][] filteredTags = new char[length][];
/* 139 */       int size = 0;
/* 140 */       for (int i = 0; i < length; i++) {
/* 141 */         char[] possibleTag = this.possibleTags[k][i];
/* 142 */         for (int j = 0; j < specLenth; j++) {
/* 143 */           if (possibleTag[0] == specifiedTags[j][0] && CharOperation.equals(possibleTag, specifiedTags[j])) {
/* 144 */             if (possibleTag == TAG_PARAM) {
/* 145 */               switch (scope.kind) {
/*     */                 case 3:
/* 147 */                   if ((scope.compilerOptions()).sourceLevel >= 3211264L) {
/* 148 */                     TypeDeclaration typeDecl = ((ClassScope)scope).referenceContext;
/* 149 */                     boolean isRecordWithComponent = (typeDecl.isRecord() && typeDecl.nRecordComponents > 0);
/* 150 */                     if (((ClassScope)scope).referenceContext.binding.isGenericType() || isRecordWithComponent) {
/* 151 */                       filteredTags[size++] = possibleTag;
/*     */                     }
/*     */                   } 
/*     */                   break;
/*     */                 case 4:
/* 156 */                   if ((scope.compilerOptions()).sourceLevel >= 3211264L) {
/* 157 */                     filteredTags[size++] = possibleTag;
/*     */                   }
/*     */                   break;
/*     */               } 
/* 161 */               filteredTags[size++] = possibleTag;
/*     */               
/*     */               break;
/*     */             } 
/* 165 */             filteredTags[size++] = possibleTag;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 171 */       if (size < length) {
/* 172 */         System.arraycopy(filteredTags, 0, this.possibleTags[k] = new char[size][], 0, size);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[][] getPossibleBlockTags() {
/* 183 */     return this.possibleTags[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[][] getPossibleInlineTags() {
/* 192 */     return this.possibleTags[1];
/*     */   }
/*     */   public char[][] getPossibleInSnippetTags() {
/* 195 */     return this.possibleTags[2];
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnJavadocTag.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */