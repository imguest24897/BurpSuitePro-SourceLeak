/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayType
/*     */   extends Type
/*     */ {
/*  58 */   public static final ChildPropertyDescriptor COMPONENT_TYPE_PROPERTY = new ChildPropertyDescriptor(ArrayType.class, "componentType", Type.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public static final ChildPropertyDescriptor ELEMENT_TYPE_PROPERTY = new ChildPropertyDescriptor(ArrayType.class, "elementType", Type.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public static final ChildListPropertyDescriptor DIMENSIONS_PROPERTY = new ChildListPropertyDescriptor(ArrayType.class, "dimensions", Dimension.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_8_0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  89 */     List propertyList = new ArrayList(2);
/*  90 */     createPropertyList(ArrayType.class, propertyList);
/*  91 */     addProperty(COMPONENT_TYPE_PROPERTY, propertyList);
/*  92 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */     
/*  94 */     propertyList = new ArrayList(3);
/*  95 */     createPropertyList(ArrayType.class, propertyList);
/*  96 */     addProperty(ELEMENT_TYPE_PROPERTY, propertyList);
/*  97 */     addProperty(DIMENSIONS_PROPERTY, propertyList);
/*  98 */     PROPERTY_DESCRIPTORS_8_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 113 */     switch (apiLevel) {
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/* 117 */         return PROPERTY_DESCRIPTORS;
/*     */     } 
/* 119 */     return PROPERTY_DESCRIPTORS_8_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   private Type type = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   private ASTNode.NodeList dimensions = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ArrayType(AST ast) {
/* 149 */     super(ast);
/* 150 */     if (ast.apiLevel >= 8) {
/* 151 */       this.dimensions = new ASTNode.NodeList(this, DIMENSIONS_PROPERTY);
/*     */       
/* 153 */       dimensions().add(this.ast.newDimension());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ArrayType(AST ast, int dimensions) {
/* 169 */     super(ast);
/* 170 */     unsupportedIn2_3_4();
/* 171 */     this.dimensions = new ASTNode.NodeList(this, DIMENSIONS_PROPERTY);
/* 172 */     for (int i = 0; i < dimensions; i++) {
/* 173 */       dimensions().add(this.ast.newDimension());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 179 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 184 */     if (property == DIMENSIONS_PROPERTY) {
/* 185 */       return dimensions();
/*     */     }
/*     */     
/* 188 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 193 */     if (property == COMPONENT_TYPE_PROPERTY) {
/* 194 */       if (get) {
/* 195 */         return getComponentType();
/*     */       }
/* 197 */       setComponentType((Type)child);
/* 198 */       return null;
/*     */     } 
/* 200 */     if (property == ELEMENT_TYPE_PROPERTY) {
/* 201 */       if (get) {
/* 202 */         return getElementType();
/*     */       }
/* 204 */       setElementType((Type)child);
/* 205 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 209 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 214 */     return 5;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/*     */     ArrayType result;
/* 220 */     if (this.ast.apiLevel < 8) {
/* 221 */       result = new ArrayType(target);
/* 222 */       result.setComponentType((Type)getComponentType().clone(target));
/*     */     } else {
/* 224 */       result = new ArrayType(target, 0);
/* 225 */       result.setElementType((Type)getElementType().clone(target));
/* 226 */       result.dimensions().addAll(
/* 227 */           ASTNode.copySubtrees(target, dimensions()));
/*     */     } 
/* 229 */     result.setSourceRange(getStartPosition(), getLength());
/* 230 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 236 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 241 */     boolean visitChildren = visitor.visit(this);
/* 242 */     if (visitChildren)
/*     */     {
/* 244 */       if (this.ast.apiLevel < 8) {
/* 245 */         acceptChild(visitor, getComponentType());
/*     */       } else {
/* 247 */         acceptChild(visitor, getElementType());
/* 248 */         acceptChildren(visitor, this.dimensions);
/*     */       } 
/*     */     }
/* 251 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getComponentType() {
/* 265 */     supportedOnlyIn2_3_4();
/* 266 */     return internalGetType(COMPONENT_TYPE_PROPERTY);
/*     */   }
/*     */   
/*     */   private Type internalGetType(ChildPropertyDescriptor property) {
/* 270 */     if (this.type == null)
/*     */     {
/* 272 */       synchronized (this) {
/* 273 */         if (this.type == null) {
/* 274 */           preLazyInit();
/* 275 */           this.type = new SimpleType(this.ast);
/* 276 */           postLazyInit(this.type, property);
/*     */         } 
/*     */       } 
/*     */     }
/* 280 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setComponentType(Type componentType) {
/* 299 */     supportedOnlyIn2_3_4();
/* 300 */     if (componentType == null) {
/* 301 */       throw new IllegalArgumentException();
/*     */     }
/* 303 */     internalSetType(componentType, COMPONENT_TYPE_PROPERTY);
/*     */   }
/*     */   
/*     */   private void internalSetType(Type componentType, ChildPropertyDescriptor property) {
/* 307 */     ASTNode oldChild = this.type;
/* 308 */     preReplaceChild(oldChild, componentType, property);
/* 309 */     this.type = componentType;
/* 310 */     postReplaceChild(oldChild, componentType, property);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getElementType() {
/* 324 */     if (this.ast.apiLevel() < 8) {
/* 325 */       Type t = getComponentType();
/* 326 */       while (t.isArrayType()) {
/* 327 */         t = ((ArrayType)t).getComponentType();
/*     */       }
/* 329 */       return t;
/*     */     } 
/* 331 */     return internalGetType(ELEMENT_TYPE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setElementType(Type type) {
/* 348 */     unsupportedIn2_3_4();
/* 349 */     if (type == null || type instanceof ArrayType) {
/* 350 */       throw new IllegalArgumentException();
/*     */     }
/* 352 */     internalSetType(type, ELEMENT_TYPE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDimensions() {
/* 368 */     if (this.ast.apiLevel() >= 8) {
/* 369 */       return dimensions().size();
/*     */     }
/* 371 */     Type t = getComponentType();
/* 372 */     int dimension = 1;
/* 373 */     while (t.isArrayType()) {
/* 374 */       dimension++;
/* 375 */       t = ((ArrayType)t).getComponentType();
/*     */     } 
/* 377 */     return dimension;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List dimensions() {
/* 392 */     if (this.dimensions == null) {
/* 393 */       unsupportedIn2_3_4();
/*     */     }
/* 395 */     return this.dimensions;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 400 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 405 */     return 
/* 406 */       memSize() + (
/* 407 */       (this.type == null) ? 0 : (((this.ast.apiLevel() < 8) ? getComponentType().treeSize() : getElementType().treeSize()) + (
/* 408 */       (this.dimensions == null) ? 0 : this.dimensions.listSize())));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ArrayType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */