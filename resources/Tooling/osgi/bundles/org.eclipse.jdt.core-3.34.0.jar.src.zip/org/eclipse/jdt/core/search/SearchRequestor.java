package org.eclipse.jdt.core.search;

import org.eclipse.core.runtime.CoreException;

public abstract class SearchRequestor {
  public abstract void acceptSearchMatch(SearchMatch paramSearchMatch) throws CoreException;
  
  public void beginReporting() {}
  
  public void endReporting() {}
  
  public void enterParticipant(SearchParticipant participant) {}
  
  public void exitParticipant(SearchParticipant participant) {}
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\search\SearchRequestor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */