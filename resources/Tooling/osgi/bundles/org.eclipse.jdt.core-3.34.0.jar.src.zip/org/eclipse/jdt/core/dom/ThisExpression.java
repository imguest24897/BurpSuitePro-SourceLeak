/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThisExpression
/*     */   extends Expression
/*     */ {
/*  44 */   public static final ChildPropertyDescriptor QUALIFIER_PROPERTY = new ChildPropertyDescriptor(ThisExpression.class, "qualifier", Name.class, false, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  54 */     List propertyList = new ArrayList(2);
/*  55 */     createPropertyList(ThisExpression.class, propertyList);
/*  56 */     addProperty(QUALIFIER_PROPERTY, propertyList);
/*  57 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  71 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   private Name optionalQualifier = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ThisExpression(AST ast) {
/*  86 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  91 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/*  96 */     if (property == QUALIFIER_PROPERTY) {
/*  97 */       if (get) {
/*  98 */         return getQualifier();
/*     */       }
/* 100 */       setQualifier((Name)child);
/* 101 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 105 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 110 */     return 52;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 115 */     ThisExpression result = new ThisExpression(target);
/* 116 */     result.setSourceRange(getStartPosition(), getLength());
/* 117 */     result.setQualifier((Name)ASTNode.copySubtree(target, getQualifier()));
/* 118 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 124 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 129 */     boolean visitChildren = visitor.visit(this);
/* 130 */     if (visitChildren) {
/* 131 */       acceptChild(visitor, getQualifier());
/*     */     }
/* 133 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getQualifier() {
/* 143 */     return this.optionalQualifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQualifier(Name name) {
/* 158 */     ASTNode oldChild = this.optionalQualifier;
/* 159 */     preReplaceChild(oldChild, name, QUALIFIER_PROPERTY);
/* 160 */     this.optionalQualifier = name;
/* 161 */     postReplaceChild(oldChild, name, QUALIFIER_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 167 */     return 44;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 172 */     return 
/* 173 */       memSize() + (
/* 174 */       (this.optionalQualifier == null) ? 0 : getQualifier().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ThisExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */