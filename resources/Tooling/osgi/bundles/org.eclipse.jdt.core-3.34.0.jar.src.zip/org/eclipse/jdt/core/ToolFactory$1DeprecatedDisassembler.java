package org.eclipse.jdt.core;

import org.eclipse.jdt.core.util.IClassFileDisassembler;
import org.eclipse.jdt.internal.core.util.Disassembler;

class DeprecatedDisassembler extends Disassembler implements IClassFileDisassembler {}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\ToolFactory$1DeprecatedDisassembler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */