/*     */ package org.eclipse.jdt.core;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Flags
/*     */ {
/*     */   public static final int AccDefault = 0;
/*     */   public static final int AccPublic = 1;
/*     */   public static final int AccPrivate = 2;
/*     */   public static final int AccProtected = 4;
/*     */   public static final int AccStatic = 8;
/*     */   public static final int AccFinal = 16;
/*     */   public static final int AccSynchronized = 32;
/*     */   public static final int AccVolatile = 64;
/*     */   public static final int AccTransient = 128;
/*     */   public static final int AccNative = 256;
/*     */   public static final int AccInterface = 512;
/*     */   public static final int AccAbstract = 1024;
/*     */   public static final int AccStrictfp = 2048;
/*     */   public static final int AccSuper = 32;
/*     */   public static final int AccSynthetic = 4096;
/*     */   public static final int AccDeprecated = 1048576;
/*     */   public static final int AccBridge = 64;
/*     */   public static final int AccVarargs = 128;
/*     */   public static final int AccEnum = 16384;
/*     */   public static final int AccAnnotation = 8192;
/*     */   public static final int AccDefaultMethod = 65536;
/*     */   public static final int AccAnnotationDefault = 131072;
/*     */   public static final int AccModule = 32768;
/*     */   public static final int AccRecord = 16777216;
/*     */   public static final int AccSealed = 268435456;
/*     */   public static final int AccNonSealed = 67108864;
/*     */   
/*     */   public static boolean isAbstract(int flags) {
/* 227 */     return ((flags & 0x400) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDeprecated(int flags) {
/* 237 */     return ((flags & 0x100000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isFinal(int flags) {
/* 246 */     return ((flags & 0x10) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInterface(int flags) {
/* 256 */     return ((flags & 0x200) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNative(int flags) {
/* 265 */     return ((flags & 0x100) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPackageDefault(int flags) {
/* 276 */     return ((flags & 0x7) == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPrivate(int flags) {
/* 285 */     return ((flags & 0x2) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isProtected(int flags) {
/* 294 */     return ((flags & 0x4) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPublic(int flags) {
/* 303 */     return ((flags & 0x1) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isStatic(int flags) {
/* 312 */     return ((flags & 0x8) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSuper(int flags) {
/* 322 */     return ((flags & 0x20) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isStrictfp(int flags) {
/* 331 */     return ((flags & 0x800) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSynchronized(int flags) {
/* 340 */     return ((flags & 0x20) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSynthetic(int flags) {
/* 350 */     return ((flags & 0x1000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTransient(int flags) {
/* 359 */     return ((flags & 0x80) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isVolatile(int flags) {
/* 368 */     return ((flags & 0x40) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isBridge(int flags) {
/* 381 */     return ((flags & 0x40) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isVarargs(int flags) {
/* 394 */     return ((flags & 0x80) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEnum(int flags) {
/* 407 */     return ((flags & 0x4000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isRecord(int flags) {
/* 420 */     return ((flags & 0x1000000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSealed(int flags) {
/* 432 */     return ((flags & 0x10000000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNonSealed(int flags) {
/* 444 */     return ((flags & 0x4000000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAnnotation(int flags) {
/* 457 */     return ((flags & 0x2000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDefaultMethod(int flags) {
/* 470 */     return ((flags & 0x10000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAnnnotationDefault(int flags) {
/* 482 */     return ((flags & 0x20000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isModule(int flags) {
/* 494 */     return ((flags & 0x8000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(int flags) {
/* 528 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 530 */     if (isPublic(flags))
/* 531 */       sb.append("public "); 
/* 532 */     if (isProtected(flags))
/* 533 */       sb.append("protected "); 
/* 534 */     if (isPrivate(flags))
/* 535 */       sb.append("private "); 
/* 536 */     if (isAbstract(flags))
/* 537 */       sb.append("abstract "); 
/* 538 */     if (isDefaultMethod(flags))
/* 539 */       sb.append("default "); 
/* 540 */     if (isStatic(flags))
/* 541 */       sb.append("static "); 
/* 542 */     if (isFinal(flags))
/* 543 */       sb.append("final "); 
/* 544 */     if (isSynchronized(flags))
/* 545 */       sb.append("synchronized "); 
/* 546 */     if (isNative(flags))
/* 547 */       sb.append("native "); 
/* 548 */     if (isStrictfp(flags))
/* 549 */       sb.append("strictfp "); 
/* 550 */     if (isTransient(flags))
/* 551 */       sb.append("transient "); 
/* 552 */     if (isVolatile(flags))
/* 553 */       sb.append("volatile "); 
/* 554 */     if (isSealed(flags))
/* 555 */       sb.append("sealed "); 
/* 556 */     if (isNonSealed(flags))
/* 557 */       sb.append("non-sealed "); 
/* 558 */     int len = sb.length();
/* 559 */     if (len == 0)
/* 560 */       return ""; 
/* 561 */     sb.setLength(len - 1);
/* 562 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\Flags.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */