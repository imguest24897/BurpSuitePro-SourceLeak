/*      */ package org.eclipse.jdt.core.dom;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*      */ import org.eclipse.jdt.internal.compiler.parser.AbstractCommentParser;
/*      */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*      */ import org.eclipse.jdt.internal.compiler.parser.ScannerHelper;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class DocCommentParser
/*      */   extends AbstractCommentParser
/*      */ {
/*      */   private Javadoc docComment;
/*      */   private AST ast;
/*      */   
/*      */   DocCommentParser(AST ast, Scanner scanner, boolean check) {
/*   41 */     super(null);
/*   42 */     this.ast = ast;
/*   43 */     this.scanner = scanner;
/*   44 */     switch (this.ast.apiLevel()) {
/*      */       case 2:
/*   46 */         this.sourceLevel = 3080192L;
/*      */         break;
/*      */       case 3:
/*   49 */         this.sourceLevel = 3211264L;
/*      */         break;
/*      */       
/*      */       default:
/*   53 */         this.sourceLevel = 3342336L; break;
/*      */     } 
/*   55 */     this.checkDocComment = check;
/*   56 */     this.kind = 258;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Javadoc parse(int[] positions) {
/*   66 */     return parse(positions[0], positions[1] - positions[0]);
/*      */   }
/*      */ 
/*      */   
/*      */   public Javadoc parse(int start, int length) {
/*   71 */     this.source = this.scanner.source;
/*   72 */     this.lineEnds = this.scanner.lineEnds;
/*   73 */     this.docComment = new Javadoc(this.ast);
/*      */ 
/*      */     
/*   76 */     if (this.checkDocComment) {
/*   77 */       this.javadocStart = start;
/*   78 */       this.javadocEnd = start + length - 1;
/*   79 */       this.firstTagPosition = this.javadocStart;
/*   80 */       commentParse();
/*      */     } 
/*   82 */     this.docComment.setSourceRange(start, length);
/*   83 */     if (this.ast.apiLevel == 2) {
/*   84 */       setComment(start, length);
/*      */     }
/*   86 */     return this.docComment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setComment(int start, int length) {
/*   96 */     this.docComment.setComment(new String(this.source, start, length));
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*  101 */     StringBuilder buffer = new StringBuilder();
/*  102 */     buffer.append("javadoc: ").append(this.docComment).append("\n");
/*  103 */     buffer.append(super.toString());
/*  104 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   protected Object createArgumentReference(char[] name, int dim, boolean isVarargs, Object typeRef, long[] dimPositions, long argNamePos) throws InvalidInputException {
/*      */     try {
/*  110 */       MethodRefParameter argument = this.ast.newMethodRefParameter();
/*  111 */       ASTNode node = (ASTNode)typeRef;
/*  112 */       int argStart = node.getStartPosition();
/*  113 */       int argEnd = node.getStartPosition() + node.getLength() - 1;
/*  114 */       if (dim > 0) argEnd = (int)dimPositions[dim - 1]; 
/*  115 */       if (argNamePos >= 0L) argEnd = (int)argNamePos; 
/*  116 */       if (name.length != 0) {
/*  117 */         SimpleName argName = new SimpleName(this.ast);
/*  118 */         argName.internalSetIdentifier(new String(name));
/*  119 */         argument.setName(argName);
/*  120 */         int argNameStart = (int)(argNamePos >>> 32L);
/*  121 */         argName.setSourceRange(argNameStart, argEnd - argNameStart + 1);
/*      */       } 
/*  123 */       Type argType = null;
/*  124 */       if (node.getNodeType() == 39) {
/*  125 */         argType = (PrimitiveType)node;
/*      */       } else {
/*  127 */         Name argTypeName = (Name)node;
/*  128 */         argType = this.ast.newSimpleType(argTypeName);
/*  129 */         argType.setSourceRange(argStart, node.getLength());
/*      */       } 
/*  131 */       if (dim > 0 && !isVarargs) {
/*  132 */         if (this.ast.apiLevel <= 4) {
/*  133 */           for (int i = 0; i < dim; i++) {
/*  134 */             argType = this.ast.newArrayType(argType);
/*  135 */             argType.setSourceRange(argStart, (int)dimPositions[i] - argStart + 1);
/*      */           } 
/*      */         } else {
/*  138 */           ArrayType argArrayType = this.ast.newArrayType(argType, 0);
/*  139 */           argType = argArrayType;
/*  140 */           argType.setSourceRange(argStart, (int)dimPositions[dim - 1] - argStart + 1);
/*  141 */           for (int i = 0; i < dim; i++) {
/*  142 */             Dimension dimension = this.ast.newDimension();
/*  143 */             int dimStart = (int)(dimPositions[i] >>> 32L);
/*  144 */             int dimEnd = (int)dimPositions[i];
/*  145 */             dimension.setSourceRange(dimStart, dimEnd - dimStart + 1);
/*  146 */             argArrayType.dimensions().add(dimension);
/*      */           } 
/*      */         } 
/*      */       }
/*  150 */       argument.setType(argType);
/*  151 */       if (this.ast.apiLevel > 8) {
/*  152 */         argument.setVarargs(isVarargs);
/*      */       }
/*  154 */       argument.setSourceRange(argStart, argEnd - argStart + 1);
/*  155 */       return argument;
/*      */     }
/*  157 */     catch (ClassCastException classCastException) {
/*  158 */       throw new InvalidInputException();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected Object createFieldReference(Object receiver) throws InvalidInputException {
/*      */     try {
/*  165 */       MemberRef fieldRef = this.ast.newMemberRef();
/*  166 */       SimpleName fieldName = new SimpleName(this.ast);
/*  167 */       fieldName.internalSetIdentifier(new String(this.identifierStack[0]));
/*  168 */       fieldRef.setName(fieldName);
/*  169 */       int start = (int)(this.identifierPositionStack[0] >>> 32L);
/*  170 */       int end = (int)this.identifierPositionStack[0];
/*  171 */       fieldName.setSourceRange(start, end - start + 1);
/*  172 */       if (receiver == null) {
/*  173 */         start = this.memberStart;
/*  174 */         fieldRef.setSourceRange(start, end - start + 1);
/*      */       } else {
/*  176 */         Name typeRef = (Name)receiver;
/*  177 */         fieldRef.setQualifier(typeRef);
/*  178 */         start = typeRef.getStartPosition();
/*  179 */         end = fieldName.getStartPosition() + fieldName.getLength() - 1;
/*  180 */         fieldRef.setSourceRange(start, end - start + 1);
/*      */       } 
/*  182 */       return fieldRef;
/*      */     }
/*  184 */     catch (ClassCastException classCastException) {
/*  185 */       throw new InvalidInputException();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object createMethodReference(Object receiver, List arguments) throws InvalidInputException {
/*      */     try {
/*  193 */       MethodRef methodRef = this.ast.newMethodRef();
/*  194 */       SimpleName methodName = new SimpleName(this.ast);
/*  195 */       int length = this.identifierLengthStack[0] - 1;
/*  196 */       methodName.internalSetIdentifier(new String(this.identifierStack[length]));
/*  197 */       methodRef.setName(methodName);
/*  198 */       int start = (int)(this.identifierPositionStack[length] >>> 32L);
/*  199 */       int end = (int)this.identifierPositionStack[length];
/*  200 */       methodName.setSourceRange(start, end - start + 1);
/*      */       
/*  202 */       if (receiver == null) {
/*  203 */         start = this.memberStart;
/*  204 */         methodRef.setSourceRange(start, end - start + 1);
/*      */       } else {
/*  206 */         Name typeRef = (Name)receiver;
/*  207 */         methodRef.setQualifier(typeRef);
/*  208 */         start = typeRef.getStartPosition();
/*      */       } 
/*      */       
/*  211 */       if (arguments != null) {
/*  212 */         Iterator<MethodRefParameter> parameters = arguments.listIterator();
/*  213 */         while (parameters.hasNext()) {
/*  214 */           MethodRefParameter param = parameters.next();
/*  215 */           methodRef.parameters().add(param);
/*      */         } 
/*      */       } 
/*  218 */       methodRef.setSourceRange(start, this.scanner.getCurrentTokenEndPosition() - start + 1);
/*  219 */       return methodRef;
/*      */     }
/*  221 */     catch (ClassCastException classCastException) {
/*  222 */       throw new InvalidInputException();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void createTag() {
/*  228 */     int position = this.scanner.currentPosition;
/*  229 */     this.scanner.resetTo(this.tagSourceStart, this.tagSourceEnd);
/*  230 */     StringBuilder tagName = new StringBuilder();
/*  231 */     int start = this.tagSourceStart;
/*  232 */     this.scanner.getNextChar();
/*  233 */     while (this.scanner.currentPosition <= this.tagSourceEnd + 1) {
/*  234 */       tagName.append(this.scanner.currentCharacter);
/*  235 */       this.scanner.getNextChar();
/*      */     } 
/*  237 */     if ("@snippet".equals(tagName.toString())) {
/*  238 */       this.tagSourceEnd = this.index;
/*      */       
/*      */       return;
/*      */     } 
/*  242 */     TagElement tagElement = this.ast.newTagElement();
/*  243 */     tagElement.setTagName(tagName.toString());
/*  244 */     if (this.inlineTagStarted) {
/*  245 */       start = this.inlineTagStart;
/*  246 */       TagElement previousTag = null;
/*  247 */       if (this.astPtr == -1) {
/*  248 */         previousTag = this.ast.newTagElement();
/*  249 */         previousTag.setSourceRange(start, this.tagSourceEnd - start + 1);
/*  250 */         pushOnAstStack(previousTag, true);
/*      */       } else {
/*  252 */         previousTag = (TagElement)this.astStack[this.astPtr];
/*      */       } 
/*  254 */       int previousStart = previousTag.getStartPosition();
/*  255 */       previousTag.fragments().add(tagElement);
/*  256 */       previousTag.setSourceRange(previousStart, this.tagSourceEnd - previousStart + 1);
/*      */     } else {
/*  258 */       pushOnAstStack(tagElement, true);
/*      */     } 
/*  260 */     tagElement.setSourceRange(start, this.tagSourceEnd - start + 1);
/*  261 */     this.scanner.resetTo(position, this.javadocEnd);
/*      */   }
/*      */ 
/*      */   
/*      */   protected Object createSnippetTag() {
/*  266 */     TagElement tagElement = this.ast.newTagElement();
/*  267 */     int position = this.scanner.currentPosition;
/*  268 */     this.scanner.resetTo(this.tagSourceStart, this.tagSourceEnd);
/*  269 */     StringBuilder tagName = new StringBuilder();
/*  270 */     int start = this.tagSourceStart;
/*  271 */     this.scanner.getNextChar();
/*  272 */     while (this.scanner.currentPosition <= this.tagSourceEnd + 1) {
/*  273 */       tagName.append(this.scanner.currentCharacter);
/*  274 */       this.scanner.getNextChar();
/*      */     } 
/*  276 */     tagElement.setTagName(tagName.toString());
/*  277 */     if (this.inlineTagStarted) {
/*  278 */       start = this.inlineTagStart;
/*  279 */       TagElement previousTag = null;
/*  280 */       if (this.astPtr == -1) {
/*  281 */         previousTag = this.ast.newTagElement();
/*  282 */         previousTag.setSourceRange(start, this.tagSourceEnd - start + 1);
/*  283 */         pushOnAstStack(previousTag, true);
/*      */       } else {
/*  285 */         previousTag = (TagElement)this.astStack[this.astPtr];
/*      */       } 
/*  287 */       int previousStart = previousTag.getStartPosition();
/*  288 */       previousTag.fragments().add(tagElement);
/*  289 */       previousTag.setSourceRange(previousStart, this.tagSourceEnd - previousStart + 1);
/*      */     } else {
/*  291 */       pushOnAstStack(tagElement, true);
/*      */     } 
/*  293 */     tagElement.setSourceRange(start, this.tagSourceEnd - start + 1);
/*  294 */     this.scanner.resetTo(position, this.javadocEnd);
/*  295 */     return tagElement;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void setSnippetIsValid(Object tag, boolean value) {
/*  300 */     if (tag instanceof TagElement) {
/*  301 */       ((TagElement)tag).setProperty("IsSnippetValid", Boolean.valueOf(value));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void setSnippetError(Object tag, String value) {
/*  307 */     if (tag instanceof TagElement) {
/*  308 */       ((TagElement)tag).setProperty("SnippetError", value);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void setSnippetID(Object tag, String value) {
/*  314 */     if (tag instanceof TagElement) {
/*  315 */       ((TagElement)tag).setProperty("SnippetID", value);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected Object createSnippetRegion(String name, List<Object> tags, Object snippetTag, boolean isDummyRegion, boolean considerPrevTag) {
/*  321 */     if (!isDummyRegion) {
/*  322 */       return createSnippetOriginalRegion(name, tags);
/*      */     }
/*  324 */     List<TagElement> tagsToBeProcessed = new ArrayList<>();
/*  325 */     Object toBeReturned = null;
/*  326 */     if (tags != null && tags.size() > 0) {
/*  327 */       int start = -1;
/*  328 */       int end = -1;
/*  329 */       for (Object tag : tags) {
/*  330 */         if (tag instanceof TagElement) {
/*  331 */           TagElement tagElem = (TagElement)tag;
/*  332 */           tagsToBeProcessed.add(tagElem);
/*  333 */           int tagStart = tagElem.getStartPosition();
/*  334 */           int tagEnd = tagStart + tagElem.getLength();
/*  335 */           if (start == -1 || start > tagStart) {
/*  336 */             start = tagStart;
/*      */           }
/*  338 */           if (end == -1 || end < tagEnd)
/*  339 */             end = tagEnd;  continue;
/*      */         } 
/*  341 */         if (tag instanceof JavaDocRegion && snippetTag instanceof TagElement) {
/*  342 */           TagElement snippet = (TagElement)snippetTag;
/*  343 */           JavaDocRegion reg = (JavaDocRegion)tag;
/*  344 */           if (!reg.isDummyRegion()) {
/*  345 */             snippet.fragments().add(reg);
/*      */           }
/*  347 */           toBeReturned = reg;
/*      */         } 
/*      */       } 
/*  350 */       if (tagsToBeProcessed.size() > 0) {
/*  351 */         boolean process = true;
/*  352 */         if (considerPrevTag && snippetTag instanceof TagElement) {
/*  353 */           TagElement snippetTagElem = (TagElement)snippetTag;
/*  354 */           Object prevTag = snippetTagElem.fragments().get(snippetTagElem.fragments().size() - 1);
/*  355 */           if (prevTag instanceof TagElement) {
/*  356 */             tagsToBeProcessed.add(0, (TagElement)prevTag);
/*  357 */             snippetTagElem.fragments().remove(prevTag);
/*  358 */           } else if (prevTag instanceof JavaDocRegion) {
/*  359 */             JavaDocRegion region = (JavaDocRegion)prevTag;
/*  360 */             region.tags().addAll(tagsToBeProcessed);
/*  361 */             toBeReturned = snippetTag;
/*  362 */             process = false;
/*      */           } 
/*      */         } 
/*  365 */         if (process) {
/*  366 */           if (tagsToBeProcessed.size() == 1) {
/*  367 */             return tagsToBeProcessed.get(0);
/*      */           }
/*      */           
/*  370 */           JavaDocRegion region = this.ast.newJavaDocRegion();
/*  371 */           region.tags().addAll(tagsToBeProcessed);
/*  372 */           region.setSourceRange(start, end);
/*  373 */           toBeReturned = region;
/*      */         } 
/*      */       } else {
/*      */         
/*  377 */         toBeReturned = snippetTag;
/*      */       } 
/*      */     } 
/*  380 */     return toBeReturned;
/*      */   }
/*      */   
/*      */   private Object createSnippetOriginalRegion(String name, List<Object> tags) {
/*  384 */     JavaDocRegion region = this.ast.newJavaDocRegion();
/*  385 */     if (tags != null && tags.size() > 0) {
/*  386 */       int start = -1;
/*  387 */       int end = -1;
/*  388 */       for (Object tag : tags) {
/*  389 */         if (tag instanceof TagElement) {
/*  390 */           TagElement tagElem = (TagElement)tag;
/*  391 */           region.tags().add(tagElem);
/*  392 */           int tagStart = tagElem.getStartPosition();
/*  393 */           int tagEnd = tagStart + tagElem.getLength();
/*  394 */           if (start == -1 || start > tagStart) {
/*  395 */             start = tagStart;
/*      */           }
/*  397 */           if (end == -1 || end < tagEnd) {
/*  398 */             end = tagEnd;
/*      */           }
/*      */         } 
/*      */       } 
/*  402 */       region.setSourceRange(start, end - start);
/*  403 */       region.setDummyRegion(false);
/*      */     } 
/*  405 */     if (name != null) {
/*  406 */       region.setTagName(name);
/*      */     }
/*  408 */     return region;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Object createSnippetInnerTag(String tagName, int start, int end) {
/*  413 */     if (tagName != null) {
/*  414 */       TagElement tagElement = this.ast.newTagElement();
/*  415 */       tagElement.setTagName(tagName.toString());
/*  416 */       if (this.astPtr == -1) {
/*  417 */         return null;
/*      */       }
/*  419 */       tagElement.setSourceRange(start, end - start);
/*  420 */       return tagElement;
/*      */     } 
/*  422 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void closeJavaDocRegion(String name, Object snippetTag, int end) {
/*  427 */     if (snippetTag instanceof TagElement) {
/*  428 */       TagElement snippet = (TagElement)snippetTag;
/*  429 */       List<JavaDocRegion> regions = snippet.tagRegions();
/*  430 */       JavaDocRegion regionToClose = null;
/*  431 */       if (name != null) {
/*  432 */         for (JavaDocRegion region : regions) {
/*  433 */           if (name.equals(region.getTagName()) && 
/*  434 */             !isRegionToBeEnded(region) && 
/*  435 */             !hasRegionEnded(region)) {
/*  436 */             regionToClose = region;
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } else {
/*  442 */         for (int i = regions.size() - 1; i > -1; i--) {
/*  443 */           JavaDocRegion region = regions.get(i);
/*  444 */           if (!isRegionToBeEnded(region) && 
/*  445 */             !hasRegionEnded(region)) {
/*  446 */             regionToClose = region;
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*  451 */       if (regionToClose != null) {
/*  452 */         setRegionToBeEnded(regionToClose, true);
/*  453 */         int start = regionToClose.getStartPosition();
/*  454 */         int curEnd = start + regionToClose.getLength();
/*  455 */         if (end > curEnd) {
/*  456 */           regionToClose.setSourceRange(start, end - start);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addTagProperties(Object tag, Map<String, Object> map, int tagCount) {
/*  465 */     if (tag instanceof TagElement) {
/*  466 */       TagElement tagElement = (TagElement)tag;
/*  467 */       map.forEach((k, v) -> {
/*      */             TagProperty tagProperty = this.ast.newTagProperty();
/*      */             tagProperty.setName(k);
/*      */             if (v instanceof String) {
/*      */               tagProperty.setStringValue((String)v);
/*      */             } else if (v instanceof ASTNode) {
/*      */               tagProperty.setNodeValue((ASTNode)v);
/*      */             } 
/*      */             paramTagElement.tagProperties().add(tagProperty);
/*      */           });
/*  477 */       tagElement.setProperty("SnippetInlineTagCount", Integer.valueOf(tagCount));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void addSnippetInnerTag(Object obj, Object snippetTag) {
/*  483 */     boolean isNotDummyRegion = false;
/*  484 */     if (obj instanceof JavaDocRegion) {
/*  485 */       JavaDocRegion region = (JavaDocRegion)obj;
/*  486 */       if (snippetTag instanceof TagElement) {
/*  487 */         TagElement snippetTagElem = (TagElement)snippetTag;
/*  488 */         if (!region.isDummyRegion()) {
/*  489 */           snippetTagElem.fragments().add(region);
/*  490 */           isNotDummyRegion = true;
/*      */         } else {
/*  492 */           Iterator<Object> itr = region.tags().iterator();
/*  493 */           while (itr.hasNext()) {
/*  494 */             Object tag = itr.next();
/*  495 */             if (tag instanceof JavaDocRegion) {
/*  496 */               JavaDocRegion reg = (JavaDocRegion)tag;
/*  497 */               if (!reg.isDummyRegion()) {
/*  498 */                 region.tags().remove(reg);
/*  499 */                 snippetTagElem.fragments().add(reg);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  506 */     if (obj instanceof AbstractTagElement && !isNotDummyRegion) {
/*  507 */       AbstractTagElement tagElement = (AbstractTagElement)obj;
/*  508 */       AbstractTagElement previousTag = null;
/*  509 */       if (this.astPtr == -1) {
/*      */         return;
/*      */       }
/*  512 */       previousTag = (AbstractTagElement)this.astStack[this.astPtr];
/*  513 */       List<ASTNode> fragments = previousTag.fragments();
/*  514 */       if (this.inlineTagStarted) {
/*  515 */         int size = fragments.size();
/*  516 */         if (size != 0) {
/*      */ 
/*      */ 
/*      */           
/*  520 */           ASTNode lastFragment = fragments.get(size - 1);
/*  521 */           if (lastFragment instanceof AbstractTagElement) {
/*  522 */             previousTag = (AbstractTagElement)lastFragment;
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*  527 */       previousTag.fragments().add(tagElement);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object createTypeReference(int primitiveToken, boolean canBeModule) {
/*  534 */     return createTypeReference(primitiveToken);
/*      */   }
/*      */ 
/*      */   
/*      */   protected Object createTypeReference(int primitiveToken) {
/*  539 */     int size = this.identifierLengthStack[this.identifierLengthPtr];
/*  540 */     String[] identifiers = new String[size];
/*  541 */     int pos = this.identifierPtr - size + 1;
/*  542 */     for (int i = 0; i < size; i++) {
/*  543 */       identifiers[i] = new String(this.identifierStack[pos + i]);
/*      */     }
/*  545 */     ASTNode typeRef = null;
/*  546 */     if (primitiveToken == -1) {
/*  547 */       typeRef = this.ast.internalNewName(identifiers);
/*      */     } else {
/*  549 */       switch (primitiveToken) {
/*      */         case 115:
/*  551 */           typeRef = this.ast.newPrimitiveType(PrimitiveType.VOID);
/*      */           break;
/*      */         case 105:
/*  554 */           typeRef = this.ast.newPrimitiveType(PrimitiveType.BOOLEAN);
/*      */           break;
/*      */         case 106:
/*  557 */           typeRef = this.ast.newPrimitiveType(PrimitiveType.BYTE);
/*      */           break;
/*      */         case 108:
/*  560 */           typeRef = this.ast.newPrimitiveType(PrimitiveType.CHAR);
/*      */           break;
/*      */         case 109:
/*  563 */           typeRef = this.ast.newPrimitiveType(PrimitiveType.DOUBLE);
/*      */           break;
/*      */         case 110:
/*  566 */           typeRef = this.ast.newPrimitiveType(PrimitiveType.FLOAT);
/*      */           break;
/*      */         case 112:
/*  569 */           typeRef = this.ast.newPrimitiveType(PrimitiveType.INT);
/*      */           break;
/*      */         case 113:
/*  572 */           typeRef = this.ast.newPrimitiveType(PrimitiveType.LONG);
/*      */           break;
/*      */         case 114:
/*  575 */           typeRef = this.ast.newPrimitiveType(PrimitiveType.SHORT);
/*      */           break;
/*      */         
/*      */         default:
/*  579 */           return null;
/*      */       } 
/*      */     
/*      */     } 
/*  583 */     int start = (int)(this.identifierPositionStack[pos] >>> 32L);
/*      */ 
/*      */ 
/*      */     
/*  587 */     if (size > 1) {
/*  588 */       Name name = (Name)typeRef;
/*  589 */       int nameIndex = size;
/*  590 */       for (int j = this.identifierPtr; j > pos; j--, nameIndex--) {
/*  591 */         int s = (int)(this.identifierPositionStack[j] >>> 32L);
/*  592 */         int e = (int)this.identifierPositionStack[j];
/*  593 */         name.index = nameIndex;
/*  594 */         SimpleName simpleName = ((QualifiedName)name).getName();
/*  595 */         simpleName.index = nameIndex;
/*  596 */         simpleName.setSourceRange(s, e - s + 1);
/*  597 */         name.setSourceRange(start, e - start + 1);
/*  598 */         name = ((QualifiedName)name).getQualifier();
/*      */       } 
/*  600 */       int end = (int)this.identifierPositionStack[pos];
/*  601 */       name.setSourceRange(start, end - start + 1);
/*  602 */       name.index = nameIndex;
/*      */     } else {
/*  604 */       int end = (int)this.identifierPositionStack[pos];
/*  605 */       typeRef.setSourceRange(start, end - start + 1);
/*      */     } 
/*  607 */     return typeRef;
/*      */   }
/*      */   
/*      */   private ModuleQualifiedName createModuleReference(int moduleRefTokenCount) {
/*  611 */     String[] identifiers = new String[moduleRefTokenCount];
/*  612 */     for (int i = 0; i < moduleRefTokenCount; i++) {
/*  613 */       identifiers[i] = new String(this.identifierStack[i]);
/*      */     }
/*  615 */     ModuleQualifiedName moduleRef = new ModuleQualifiedName(this.ast);
/*      */     
/*  617 */     ASTNode typeRef = null;
/*  618 */     typeRef = this.ast.internalNewName(identifiers);
/*  619 */     int start = (int)(this.identifierPositionStack[0] >>> 32L);
/*  620 */     if (moduleRefTokenCount > 1) {
/*  621 */       Name name = (Name)typeRef;
/*  622 */       int nameIndex = moduleRefTokenCount;
/*  623 */       for (int j = moduleRefTokenCount - 1; j > 0; j--, nameIndex--) {
/*  624 */         int s = (int)(this.identifierPositionStack[j] >>> 32L);
/*  625 */         int e = (int)this.identifierPositionStack[j];
/*  626 */         name.index = nameIndex;
/*  627 */         SimpleName simpleName = ((QualifiedName)name).getName();
/*  628 */         simpleName.index = nameIndex;
/*  629 */         simpleName.setSourceRange(s, e - s + 1);
/*  630 */         name.setSourceRange(start, e - start + 1);
/*  631 */         name = ((QualifiedName)name).getQualifier();
/*      */       } 
/*  633 */       int end = (int)this.identifierPositionStack[0];
/*  634 */       name.setSourceRange(start, end - start + 1);
/*  635 */       name.index = nameIndex;
/*      */     } else {
/*  637 */       int end = (int)this.identifierPositionStack[0];
/*  638 */       typeRef.setSourceRange(start, end - start + 1);
/*      */     } 
/*  640 */     moduleRef.setModuleQualifier((Name)typeRef);
/*  641 */     moduleRef.setName((Name)null);
/*  642 */     moduleRef.setSourceRange(typeRef.getStartPosition(), typeRef.getLength() + 1);
/*  643 */     return moduleRef;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Object createModuleTypeReference(int primitiveToken, int moduleRefTokenCount) {
/*  648 */     int size = this.identifierLengthStack[this.identifierLengthPtr];
/*  649 */     ModuleQualifiedName moduleRef = null;
/*  650 */     Name typeRef = null;
/*  651 */     if (size == moduleRefTokenCount) {
/*  652 */       moduleRef = createModuleReference(moduleRefTokenCount);
/*  653 */       this.lastIdentifierEndPosition++;
/*      */     } else {
/*  655 */       String[] moduleIdentifiers = new String[moduleRefTokenCount];
/*  656 */       String[] identifiers = new String[size - moduleRefTokenCount];
/*  657 */       int pos = this.identifierPtr - size + 1;
/*  658 */       for (int i = 0; i < size; i++) {
/*  659 */         if (i < moduleRefTokenCount) {
/*  660 */           moduleIdentifiers[i] = new String(this.identifierStack[pos + i]);
/*      */         } else {
/*  662 */           identifiers[i - moduleRefTokenCount] = new String(this.identifierStack[pos + i]);
/*      */         } 
/*      */       } 
/*  665 */       moduleRef = createModuleReference(moduleRefTokenCount);
/*  666 */       pos = this.identifierPtr + moduleRefTokenCount - size + 1;
/*      */       
/*  668 */       if (primitiveToken == -1) {
/*  669 */         typeRef = this.ast.internalNewName(identifiers);
/*      */         
/*  671 */         int start = (int)(this.identifierPositionStack[pos] >>> 32L);
/*      */ 
/*      */ 
/*      */         
/*  675 */         if (size - moduleRefTokenCount > 1) {
/*  676 */           Name name = typeRef;
/*  677 */           int nameIndex = size - moduleRefTokenCount;
/*  678 */           for (int j = this.identifierPtr; j > pos; j--, nameIndex--) {
/*  679 */             int s = (int)(this.identifierPositionStack[j] >>> 32L);
/*  680 */             int e = (int)this.identifierPositionStack[j];
/*  681 */             name.index = nameIndex;
/*  682 */             SimpleName simpleName = ((QualifiedName)name).getName();
/*  683 */             simpleName.index = nameIndex;
/*  684 */             simpleName.setSourceRange(s, e - s + 1);
/*  685 */             name.setSourceRange(start, e - start + 1);
/*  686 */             name = ((QualifiedName)name).getQualifier();
/*      */           } 
/*  688 */           int end = (int)this.identifierPositionStack[pos];
/*  689 */           name.setSourceRange(start, end - start + 1);
/*  690 */           name.index = nameIndex;
/*      */         } else {
/*  692 */           int end = (int)this.identifierPositionStack[pos];
/*  693 */           typeRef.setSourceRange(start, end - start + 1);
/*      */         } 
/*  695 */         moduleRef.setName(typeRef);
/*  696 */         moduleRef.setSourceRange(moduleRef.getStartPosition(), moduleRef.getLength() + typeRef.getLength());
/*      */       } 
/*      */     } 
/*  699 */     return moduleRef;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean parseIdentifierTag(boolean report) {
/*  704 */     if (super.parseIdentifierTag(report)) {
/*  705 */       createTag();
/*  706 */       this.index = this.tagSourceEnd + 1;
/*  707 */       this.scanner.resetTo(this.index, this.javadocEnd);
/*  708 */       return true;
/*      */     } 
/*  710 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean parseReturn() {
/*  717 */     createTag();
/*  718 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean parseTag(int previousPosition) throws InvalidInputException {
/*  725 */     int currentPosition = this.index;
/*  726 */     int token = readTokenAndConsume();
/*  727 */     char[] tagName = CharOperation.NO_CHAR;
/*  728 */     if (currentPosition == this.scanner.startPosition) {
/*  729 */       this.tagSourceStart = this.scanner.getCurrentTokenStartPosition();
/*  730 */       this.tagSourceEnd = this.scanner.getCurrentTokenEndPosition();
/*  731 */       tagName = this.scanner.getCurrentIdentifierSource();
/*      */     } else {
/*  733 */       this.tagSourceEnd = currentPosition - 1;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  738 */     if (this.scanner.currentCharacter != ' ' && !ScannerHelper.isWhitespace(this.scanner.currentCharacter)) {
/*  739 */       while (token != 64 && this.index < this.scanner.eofPosition) {
/*  740 */         char[] ident; int i = tagName.length;
/*      */         
/*  742 */         switch (this.scanner.currentCharacter) {
/*      */           case '!':
/*      */           case '"':
/*      */           case '#':
/*      */           case '%':
/*      */           case '&':
/*      */           case '\'':
/*      */           case '*':
/*      */           case ':':
/*      */           case '<':
/*      */           case '>':
/*      */           case '}':
/*      */             break;
/*      */           case '-':
/*  756 */             System.arraycopy(tagName, 0, tagName = new char[i + 1], 0, i);
/*  757 */             tagName[i] = this.scanner.currentCharacter;
/*      */             break;
/*      */           default:
/*  760 */             if (this.scanner.currentCharacter == ' ' || ScannerHelper.isWhitespace(this.scanner.currentCharacter)) {
/*      */               break;
/*      */             }
/*  763 */             token = readTokenAndConsume();
/*  764 */             ident = this.scanner.getCurrentIdentifierSource();
/*  765 */             System.arraycopy(tagName, 0, tagName = new char[i + ident.length], 0, i);
/*  766 */             System.arraycopy(ident, 0, tagName, i, ident.length);
/*      */             break;
/*      */         } 
/*  769 */         this.tagSourceEnd = this.scanner.getCurrentTokenEndPosition();
/*  770 */         this.scanner.getNextChar();
/*  771 */         this.index = this.scanner.currentPosition;
/*      */       } 
/*      */     }
/*  774 */     int length = tagName.length;
/*  775 */     this.index = this.tagSourceEnd + 1;
/*  776 */     this.scanner.currentPosition = this.tagSourceEnd + 1;
/*  777 */     this.tagSourceStart = previousPosition;
/*      */ 
/*      */     
/*  780 */     if (tagName.length == 0) {
/*  781 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  785 */     this.tagValue = 0;
/*  786 */     boolean valid = true;
/*  787 */     switch (token) {
/*      */       case 19:
/*  789 */         switch (tagName[0]) {
/*      */           case 'c':
/*  791 */             if (length == TAG_CATEGORY_LENGTH && CharOperation.equals(TAG_CATEGORY, tagName)) {
/*  792 */               this.tagValue = 11;
/*  793 */               valid = parseIdentifierTag(false); break;
/*  794 */             }  if (length == TAG_CODE_LENGTH && CharOperation.equals(TAG_CODE, tagName)) {
/*  795 */               this.tagValue = 18;
/*  796 */               createTag(); break;
/*      */             } 
/*  798 */             this.tagValue = 100;
/*  799 */             createTag();
/*      */             break;
/*      */           
/*      */           case 'd':
/*  803 */             if (length == TAG_DEPRECATED_LENGTH && CharOperation.equals(TAG_DEPRECATED, tagName)) {
/*  804 */               this.deprecated = true;
/*  805 */               this.tagValue = 1;
/*      */             } else {
/*  807 */               this.tagValue = 100;
/*      */             } 
/*  809 */             createTag();
/*      */             break;
/*      */           case 'i':
/*  812 */             if (length == TAG_INHERITDOC_LENGTH && CharOperation.equals(TAG_INHERITDOC, tagName)) {
/*  813 */               if (this.reportProblems) {
/*  814 */                 recordInheritedPosition((this.tagSourceStart << 32L) + this.tagSourceEnd);
/*      */               }
/*  816 */               this.tagValue = 9;
/*      */             } else {
/*  818 */               this.tagValue = 100;
/*      */             } 
/*  820 */             createTag();
/*      */             break;
/*      */           case 'p':
/*  823 */             if (length == TAG_PARAM_LENGTH && CharOperation.equals(TAG_PARAM, tagName)) {
/*  824 */               this.tagValue = 2;
/*  825 */               valid = parseParam(); break;
/*      */             } 
/*  827 */             this.tagValue = 100;
/*  828 */             createTag();
/*      */             break;
/*      */           
/*      */           case 'e':
/*  832 */             if (length == TAG_EXCEPTION_LENGTH && CharOperation.equals(TAG_EXCEPTION, tagName)) {
/*  833 */               this.tagValue = 5;
/*  834 */               valid = parseThrows(); break;
/*      */             } 
/*  836 */             this.tagValue = 100;
/*  837 */             createTag();
/*      */             break;
/*      */           
/*      */           case 's':
/*  841 */             if (length == TAG_SEE_LENGTH && CharOperation.equals(TAG_SEE, tagName)) {
/*  842 */               this.tagValue = 6;
/*  843 */               if (this.inlineTagStarted) {
/*      */ 
/*      */                 
/*  846 */                 valid = false; break;
/*      */               } 
/*  848 */               valid = parseReference(true); break;
/*      */             } 
/*  850 */             if (length == TAG_SNIPPET_LENGTH && CharOperation.equals(TAG_SNIPPET, tagName)) {
/*  851 */               this.tagValue = TAG_SNIPPET_LENGTH;
/*  852 */               if (!this.inlineTagStarted) {
/*      */                 
/*  854 */                 valid = false; break;
/*      */               } 
/*  856 */               this.tagValue = 30;
/*  857 */               valid = parseSnippet();
/*      */               break;
/*      */             } 
/*  860 */             this.tagValue = 100;
/*  861 */             createTag();
/*      */             break;
/*      */           
/*      */           case 'l':
/*  865 */             if (length == TAG_LINK_LENGTH && CharOperation.equals(TAG_LINK, tagName)) {
/*  866 */               this.tagValue = 7;
/*  867 */             } else if (length == TAG_LINKPLAIN_LENGTH && CharOperation.equals(TAG_LINKPLAIN, tagName)) {
/*  868 */               this.tagValue = 8;
/*  869 */             } else if (length == TAG_LITERAL_LENGTH && CharOperation.equals(TAG_LITERAL, tagName)) {
/*  870 */               this.tagValue = 19;
/*      */             } 
/*      */             
/*  873 */             if (this.tagValue != 0 && this.tagValue != 19) {
/*  874 */               if (this.inlineTagStarted) {
/*  875 */                 valid = parseReference(true);
/*      */                 
/*      */                 break;
/*      */               } 
/*  879 */               valid = false;
/*      */               break;
/*      */             } 
/*  882 */             if (this.tagValue == 0) this.tagValue = 100; 
/*  883 */             createTag();
/*      */             break;
/*      */           
/*      */           case 'v':
/*  887 */             if (this.sourceLevel >= 3211264L && length == TAG_VALUE_LENGTH && CharOperation.equals(TAG_VALUE, tagName)) {
/*  888 */               this.tagValue = 10;
/*  889 */               if (this.inlineTagStarted) {
/*  890 */                 valid = parseReference(); break;
/*      */               } 
/*  892 */               valid = false;
/*      */               break;
/*      */             } 
/*  895 */             this.tagValue = 100;
/*  896 */             createTag();
/*      */             break;
/*      */         } 
/*      */         
/*  900 */         this.tagValue = 100;
/*  901 */         createTag();
/*      */         break;
/*      */       
/*      */       case 87:
/*  905 */         this.tagValue = 3;
/*  906 */         valid = parseReturn();
/*      */         break;
/*      */       case 117:
/*  909 */         this.tagValue = 4;
/*  910 */         valid = parseThrows();
/*      */         break;
/*      */       case 17:
/*      */       case 35:
/*      */       case 36:
/*      */       case 37:
/*      */       case 38:
/*      */       case 39:
/*      */       case 42:
/*      */       case 43:
/*      */       case 44:
/*      */       case 46:
/*      */       case 47:
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 63:
/*      */       case 70:
/*      */       case 73:
/*      */       case 74:
/*      */       case 76:
/*      */       case 78:
/*      */       case 79:
/*      */       case 81:
/*      */       case 82:
/*      */       case 83:
/*      */       case 84:
/*      */       case 85:
/*      */       case 86:
/*      */       case 88:
/*      */       case 90:
/*      */       case 91:
/*      */       case 92:
/*      */       case 105:
/*      */       case 106:
/*      */       case 107:
/*      */       case 108:
/*      */       case 109:
/*      */       case 110:
/*      */       case 111:
/*      */       case 112:
/*      */       case 113:
/*      */       case 114:
/*      */       case 115:
/*      */       case 116:
/*      */       case 121:
/*      */       case 133:
/*      */       case 136:
/*      */       case 137:
/*  963 */         this.tagValue = 100;
/*  964 */         createTag();
/*      */         break;
/*      */     } 
/*  967 */     this.textStart = this.index;
/*  968 */     return valid;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean pushParamName(boolean isTypeParam) {
/*  973 */     int idIndex = isTypeParam ? 1 : 0;
/*  974 */     SimpleName name = new SimpleName(this.ast);
/*  975 */     name.internalSetIdentifier(new String(this.identifierStack[idIndex]));
/*  976 */     int nameStart = (int)(this.identifierPositionStack[idIndex] >>> 32L);
/*  977 */     int nameEnd = (int)(this.identifierPositionStack[idIndex] & 0xFFFFFFFFL);
/*  978 */     name.setSourceRange(nameStart, nameEnd - nameStart + 1);
/*  979 */     TagElement paramTag = this.ast.newTagElement();
/*  980 */     paramTag.setTagName("@param");
/*  981 */     if (isTypeParam) {
/*      */       
/*  983 */       TextElement text = this.ast.newTextElement();
/*  984 */       text.setText(new String(this.identifierStack[0]));
/*  985 */       int txtStart = (int)(this.identifierPositionStack[0] >>> 32L);
/*  986 */       int txtEnd = (int)(this.identifierPositionStack[0] & 0xFFFFFFFFL);
/*  987 */       text.setSourceRange(txtStart, txtEnd - txtStart + 1);
/*  988 */       paramTag.fragments().add(text);
/*      */       
/*  990 */       paramTag.fragments().add(name);
/*      */       
/*  992 */       text = this.ast.newTextElement();
/*  993 */       text.setText(new String(this.identifierStack[2]));
/*  994 */       txtStart = (int)(this.identifierPositionStack[2] >>> 32L);
/*  995 */       txtEnd = (int)(this.identifierPositionStack[2] & 0xFFFFFFFFL);
/*  996 */       text.setSourceRange(txtStart, txtEnd - txtStart + 1);
/*  997 */       paramTag.fragments().add(text);
/*      */       
/*  999 */       paramTag.setSourceRange(this.tagSourceStart, txtEnd - this.tagSourceStart + 1);
/*      */     } else {
/* 1001 */       paramTag.setSourceRange(this.tagSourceStart, nameEnd - this.tagSourceStart + 1);
/* 1002 */       paramTag.fragments().add(name);
/*      */     } 
/* 1004 */     pushOnAstStack(paramTag, true);
/* 1005 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean pushSeeRef(Object statement) {
/* 1010 */     TagElement seeTag = this.ast.newTagElement();
/* 1011 */     ASTNode node = (ASTNode)statement;
/* 1012 */     seeTag.fragments().add(node);
/* 1013 */     int end = node.getStartPosition() + node.getLength() - 1;
/* 1014 */     if (this.inlineTagStarted) {
/* 1015 */       seeTag.setSourceRange(this.inlineTagStart, end - this.inlineTagStart + 1);
/* 1016 */       switch (this.tagValue) {
/*      */         case 7:
/* 1018 */           seeTag.setTagName("@link");
/*      */           break;
/*      */         case 8:
/* 1021 */           seeTag.setTagName("@linkplain");
/*      */           break;
/*      */         case 10:
/* 1024 */           seeTag.setTagName("@value");
/*      */           break;
/*      */       } 
/* 1027 */       TagElement previousTag = null;
/* 1028 */       int previousStart = this.inlineTagStart;
/* 1029 */       if (this.astPtr == -1) {
/* 1030 */         previousTag = this.ast.newTagElement();
/* 1031 */         pushOnAstStack(previousTag, true);
/*      */       } else {
/* 1033 */         previousTag = (TagElement)this.astStack[this.astPtr];
/* 1034 */         previousStart = previousTag.getStartPosition();
/*      */       } 
/* 1036 */       previousTag.fragments().add(seeTag);
/* 1037 */       previousTag.setSourceRange(previousStart, end - previousStart + 1);
/*      */     } else {
/* 1039 */       seeTag.setTagName("@see");
/* 1040 */       seeTag.setSourceRange(this.tagSourceStart, end - this.tagSourceStart + 1);
/* 1041 */       pushOnAstStack(seeTag, true);
/*      */     } 
/* 1043 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void pushText(int start, int end) {
/* 1050 */     TextElement text = this.ast.newTextElement();
/* 1051 */     text.setText(new String(this.source, start, end - start));
/* 1052 */     text.setSourceRange(start, end - start);
/*      */ 
/*      */     
/* 1055 */     TagElement previousTag = null;
/* 1056 */     int previousStart = start;
/* 1057 */     if (this.astPtr == -1) {
/* 1058 */       previousTag = this.ast.newTagElement();
/* 1059 */       previousTag.setSourceRange(start, end - start);
/* 1060 */       pushOnAstStack(previousTag, true);
/*      */     } else {
/* 1062 */       previousTag = (TagElement)this.astStack[this.astPtr];
/* 1063 */       previousStart = previousTag.getStartPosition();
/*      */     } 
/*      */ 
/*      */     
/* 1067 */     List<TagElement> fragments = previousTag.fragments();
/* 1068 */     if (this.inlineTagStarted) {
/* 1069 */       int size = fragments.size();
/* 1070 */       if (size == 0) {
/*      */         
/* 1072 */         TagElement inlineTag = this.ast.newTagElement();
/* 1073 */         fragments.add(inlineTag);
/* 1074 */         previousTag = inlineTag;
/*      */       } else {
/*      */         
/* 1077 */         ASTNode lastFragment = fragments.get(size - 1);
/* 1078 */         if (lastFragment.getNodeType() == 65) {
/* 1079 */           previousTag = (TagElement)lastFragment;
/* 1080 */           previousStart = previousTag.getStartPosition();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1086 */     previousTag.fragments().add(text);
/* 1087 */     previousTag.setSourceRange(previousStart, end - previousStart);
/* 1088 */     this.textStart = -1;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void pushSnippetText(char[] text, int start, int end, boolean addNewLine, Object snippetTag) {
/* 1093 */     pushSnippetText(text, start, end, addNewLine, snippetTag, false);
/*      */   }
/*      */ 
/*      */   
/*      */   private void pushSnippetText(char[] text, int start, int end, boolean addNewLine, Object snippetTag, boolean isExternalSnippet) {
/* 1098 */     String textToBeAdded = new String(text, start, end - start);
/* 1099 */     AbstractTextElement textElem = null;
/* 1100 */     if (isExternalSnippet && textToBeAdded.indexOf("*/") > 0) {
/* 1101 */       textElem = this.ast.newJavaDocTextElement();
/*      */     } else {
/* 1103 */       textElem = this.ast.newTextElement();
/*      */     } 
/*      */     
/* 1106 */     int iindex = textToBeAdded.indexOf('*');
/* 1107 */     if (iindex > -1 && textToBeAdded.substring(0, iindex + 1).trim().equals("*")) {
/* 1108 */       textToBeAdded = textToBeAdded.substring(iindex + 1);
/* 1109 */       if (addNewLine) {
/* 1110 */         textToBeAdded = String.valueOf(textToBeAdded) + System.lineSeparator();
/*      */       }
/* 1112 */     } else if (isExternalSnippet && 
/* 1113 */       addNewLine) {
/* 1114 */       textToBeAdded = String.valueOf(textToBeAdded) + System.lineSeparator();
/*      */     } 
/*      */     
/* 1117 */     textElem.setText(textToBeAdded);
/* 1118 */     textElem.setSourceRange(start, end - start);
/*      */ 
/*      */     
/* 1121 */     AbstractTagElement previousTag = null;
/* 1122 */     int previousStart = start;
/* 1123 */     if (this.astPtr == -1) {
/* 1124 */       previousTag = this.ast.newTagElement();
/* 1125 */       previousTag.setSourceRange(start, end - start);
/* 1126 */       pushOnAstStack(previousTag, true);
/*      */     } else {
/* 1128 */       previousTag = (AbstractTagElement)this.astStack[this.astPtr];
/* 1129 */       previousStart = previousTag.getStartPosition();
/*      */     } 
/*      */     
/* 1132 */     AbstractTagElement prevTag = null;
/*      */     
/* 1134 */     List<ASTNode> fragments = previousTag.fragments();
/* 1135 */     if (this.inlineTagStarted) {
/* 1136 */       int size = fragments.size();
/* 1137 */       if (size != 0) {
/*      */ 
/*      */ 
/*      */         
/* 1141 */         ASTNode lastFragment = fragments.get(size - 1);
/* 1142 */         if (lastFragment instanceof AbstractTagElement) {
/* 1143 */           previousTag = (AbstractTagElement)lastFragment;
/* 1144 */           previousStart = previousTag.getStartPosition();
/* 1145 */           if (this.snippetInlineTagStarted) {
/* 1146 */             fragments = previousTag.fragments();
/* 1147 */             size = fragments.size();
/* 1148 */             if (size != 0) {
/*      */ 
/*      */               
/* 1151 */               lastFragment = fragments.get(size - 1);
/* 1152 */               if (lastFragment instanceof AbstractTagElement) {
/* 1153 */                 prevTag = (AbstractTagElement)lastFragment;
/* 1154 */                 this.snippetInlineTagStarted = false;
/*      */               } 
/*      */             } 
/* 1157 */             this.snippetInlineTagStarted = false;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1163 */     int finEnd = end;
/* 1164 */     boolean isNotDummyJavaDocRegion = false;
/* 1165 */     if (prevTag instanceof JavaDocRegion && !((JavaDocRegion)prevTag).isDummyRegion()) {
/* 1166 */       isNotDummyJavaDocRegion = true;
/*      */     }
/*      */     
/* 1169 */     if (prevTag != null && !isNotDummyJavaDocRegion) {
/*      */       
/* 1171 */       prevTag.fragments().add(textElem);
/* 1172 */       int curStart = prevTag.getStartPosition();
/* 1173 */       int curEnd = curStart + prevTag.getLength();
/* 1174 */       int finStart = start;
/* 1175 */       if (curStart < start) {
/* 1176 */         finStart = curStart;
/*      */       }
/* 1178 */       if (curEnd > end) {
/* 1179 */         finEnd = curEnd;
/*      */       }
/* 1181 */       prevTag.setSourceRange(finStart, finEnd - finStart);
/*      */     } else {
/* 1183 */       previousTag.fragments().add(textElem);
/*      */     } 
/* 1185 */     if (!isExternalSnippet)
/* 1186 */       previousTag.setSourceRange(previousStart, finEnd - previousStart); 
/* 1187 */     this.textStart = -1;
/*      */     
/* 1189 */     if (snippetTag instanceof TagElement) {
/* 1190 */       fragments = ((TagElement)snippetTag).fragments();
/* 1191 */       for (ASTNode frag : fragments) {
/* 1192 */         if (frag instanceof JavaDocRegion) {
/* 1193 */           JavaDocRegion region = (JavaDocRegion)frag;
/* 1194 */           if (!region.isDummyRegion() && !hasRegionEnded(region)) {
/* 1195 */             int startPos = region.getStartPosition();
/* 1196 */             int endPos = startPos + region.getLength();
/* 1197 */             if (startPos > start) {
/* 1198 */               startPos = start;
/*      */             }
/* 1200 */             if (endPos < end) {
/* 1201 */               endPos = end;
/*      */             }
/* 1203 */             Object textVal = region.getProperty("SnippetRegionTextElement");
/* 1204 */             if (!(textVal instanceof AbstractTextElement)) {
/* 1205 */               region.setProperty("SnippetRegionTextElement", textElem);
/*      */             }
/* 1207 */             region.setSourceRange(startPos, endPos - startPos);
/* 1208 */             if (isRegionToBeEnded(region)) {
/* 1209 */               setRegionEnded(region, true);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean hasRegionEnded(JavaDocRegion region) {
/* 1218 */     boolean ended = false;
/* 1219 */     if (region != null) {
/* 1220 */       Object value = region.getProperty("Region Ended");
/* 1221 */       if (value instanceof Boolean && ((Boolean)value).booleanValue()) {
/* 1222 */         ended = true;
/*      */       }
/*      */     } 
/* 1225 */     return ended;
/*      */   }
/*      */   
/*      */   private boolean isRegionToBeEnded(JavaDocRegion region) {
/* 1229 */     boolean toBeEnded = false;
/* 1230 */     if (region != null) {
/* 1231 */       Object value = region.getProperty("Region To Be Ended");
/* 1232 */       if (value instanceof Boolean && ((Boolean)value).booleanValue()) {
/* 1233 */         toBeEnded = true;
/*      */       }
/*      */     } 
/* 1236 */     return toBeEnded;
/*      */   }
/*      */   
/*      */   private void setRegionToBeEnded(JavaDocRegion region, boolean value) {
/* 1240 */     if (region != null) {
/* 1241 */       region.setProperty("Region To Be Ended", Boolean.valueOf(value));
/*      */     }
/*      */   }
/*      */   
/*      */   private void setRegionEnded(JavaDocRegion region, boolean value) {
/* 1246 */     if (region != null) {
/* 1247 */       region.setProperty("Region Ended", Boolean.valueOf(value));
/* 1248 */       setRegionToBeEnded(region, !value);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void pushExternalSnippetText(char[] text, int start, int end, boolean addNewLine, Object snippetTag) {
/* 1254 */     pushSnippetText(text, start, end, addNewLine, snippetTag, true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean pushThrowName(Object typeRef) {
/* 1260 */     TagElement throwsTag = this.ast.newTagElement();
/* 1261 */     switch (this.tagValue) {
/*      */       case 4:
/* 1263 */         throwsTag.setTagName("@throws");
/*      */         break;
/*      */       case 5:
/* 1266 */         throwsTag.setTagName("@exception");
/*      */         break;
/*      */     } 
/* 1269 */     throwsTag.setSourceRange(this.tagSourceStart, this.scanner.getCurrentTokenEndPosition() - this.tagSourceStart + 1);
/* 1270 */     throwsTag.fragments().add(typeRef);
/* 1271 */     pushOnAstStack(throwsTag, true);
/* 1272 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void refreshInlineTagPosition(int previousPosition) {
/* 1277 */     if (this.astPtr != -1) {
/* 1278 */       TagElement previousTag = (TagElement)this.astStack[this.astPtr];
/* 1279 */       if (this.inlineTagStarted) {
/* 1280 */         int previousStart = previousTag.getStartPosition();
/* 1281 */         previousTag.setSourceRange(previousStart, previousPosition - previousStart + 1);
/* 1282 */         if (previousTag.fragments().size() > 0) {
/* 1283 */           ASTNode inlineTag = previousTag.fragments().get(previousTag.fragments().size() - 1);
/* 1284 */           if (inlineTag.getNodeType() == 65) {
/* 1285 */             int inlineStart = inlineTag.getStartPosition();
/* 1286 */             inlineTag.setSourceRange(inlineStart, previousPosition - inlineStart + 1);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateDocComment() {
/* 1298 */     for (int idx = 0; idx <= this.astPtr; idx++) {
/* 1299 */       this.docComment.tags().add(this.astStack[idx]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean areRegionsClosed() {
/* 1306 */     return true;
/*      */   }
/*      */   
/*      */   protected void setRegionPosition(int currentPosition) {}
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\DocCommentParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */