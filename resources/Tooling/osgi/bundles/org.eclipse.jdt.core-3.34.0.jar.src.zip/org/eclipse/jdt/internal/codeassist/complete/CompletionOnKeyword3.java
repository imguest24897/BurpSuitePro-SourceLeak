/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.SingleNameReference;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnKeyword3
/*    */   extends SingleNameReference
/*    */   implements CompletionOnKeyword
/*    */ {
/*    */   private char[][] possibleKeywords;
/*    */   private boolean tryOrCatch;
/*    */   
/*    */   public CompletionOnKeyword3(char[] token, long pos, char[] possibleKeyword) {
/* 24 */     this(token, pos, new char[][] { possibleKeyword }, false);
/*    */   }
/*    */   public CompletionOnKeyword3(char[] token, long pos, char[][] possibleKeywords, boolean afterTryOrCatch) {
/* 27 */     super(token, pos);
/* 28 */     this.token = token;
/* 29 */     this.possibleKeywords = possibleKeywords;
/* 30 */     this.tryOrCatch = afterTryOrCatch;
/*    */   }
/*    */   
/*    */   public char[] getToken() {
/* 34 */     return this.token;
/*    */   }
/*    */   
/*    */   public char[][] getPossibleKeywords() {
/* 38 */     return this.possibleKeywords;
/*    */   }
/*    */   public boolean afterTryOrCatch() {
/* 41 */     return this.tryOrCatch;
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 46 */     return output.append("<CompleteOnKeyword:").append(this.token).append('>');
/*    */   }
/*    */   
/*    */   public TypeBinding resolveType(BlockScope scope) {
/* 50 */     throw new CompletionNodeFound(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnKeyword3.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */