/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import org.eclipse.jdt.core.IBuffer;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.ISourceRange;
/*     */ import org.eclipse.jdt.core.ITypeRoot;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.core.ToolFactory;
/*     */ import org.eclipse.jdt.core.compiler.IScanner;
/*     */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NodeFinder
/*     */ {
/*     */   private ASTNode fCoveringNode;
/*     */   private ASTNode fCoveredNode;
/*     */   
/*     */   private static class NodeFinderVisitor
/*     */     extends ASTVisitor
/*     */   {
/*     */     private int fStart;
/*     */     private int fEnd;
/*     */     private ASTNode fCoveringNode;
/*     */     private ASTNode fCoveredNode;
/*     */     
/*     */     NodeFinderVisitor(int offset, int length) {
/*  43 */       super(true);
/*  44 */       this.fStart = offset;
/*  45 */       this.fEnd = offset + length;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean preVisit2(ASTNode node) {
/*  50 */       int nodeStart = node.getStartPosition();
/*  51 */       int nodeEnd = nodeStart + node.getLength();
/*  52 */       if (nodeEnd < this.fStart || this.fEnd < nodeStart) {
/*  53 */         return false;
/*     */       }
/*  55 */       if (nodeStart <= this.fStart && this.fEnd <= nodeEnd) {
/*  56 */         this.fCoveringNode = node;
/*     */       }
/*  58 */       if (this.fStart <= nodeStart && nodeEnd <= this.fEnd) {
/*  59 */         if (this.fCoveringNode == node) {
/*  60 */           this.fCoveredNode = node;
/*  61 */           return true;
/*  62 */         }  if (this.fCoveredNode == null) {
/*  63 */           this.fCoveredNode = node;
/*     */         }
/*  65 */         return false;
/*     */       } 
/*  67 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ASTNode getCoveredNode() {
/*  75 */       return this.fCoveredNode;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ASTNode getCoveringNode() {
/*  84 */       return this.fCoveringNode;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ASTNode perform(ASTNode root, int start, int length) {
/* 105 */     NodeFinder finder = new NodeFinder(root, start, length);
/* 106 */     ASTNode result = finder.getCoveredNode();
/* 107 */     if (result == null || result.getStartPosition() != start || result.getLength() != length) {
/* 108 */       return finder.getCoveringNode();
/*     */     }
/* 110 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ASTNode perform(ASTNode root, ISourceRange range) {
/* 123 */     return perform(root, range.getOffset(), range.getLength());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ASTNode perform(ASTNode root, int start, int length, ITypeRoot source) throws JavaModelException {
/* 145 */     NodeFinder finder = new NodeFinder(root, start, length);
/* 146 */     ASTNode result = finder.getCoveredNode();
/* 147 */     if (result == null)
/* 148 */       return null; 
/* 149 */     int nodeStart = result.getStartPosition();
/* 150 */     if (start <= nodeStart && nodeStart + result.getLength() <= start + length) {
/* 151 */       IBuffer buffer = source.getBuffer();
/* 152 */       if (buffer != null) {
/*     */         IScanner scanner;
/* 154 */         IJavaProject project = source.getJavaProject();
/* 155 */         if (project != null) {
/* 156 */           String sourceLevel = project.getOption("org.eclipse.jdt.core.compiler.source", true);
/* 157 */           String complianceLevel = project.getOption("org.eclipse.jdt.core.compiler.compliance", true);
/* 158 */           scanner = ToolFactory.createScanner(false, false, false, sourceLevel, complianceLevel);
/*     */         } else {
/* 160 */           scanner = ToolFactory.createScanner(false, false, false, false);
/*     */         } 
/*     */         try {
/* 163 */           scanner.setSource(buffer.getText(start, length).toCharArray());
/* 164 */           int token = scanner.getNextToken();
/* 165 */           if (token != 158) {
/* 166 */             int tStart = scanner.getCurrentTokenStartPosition();
/* 167 */             if (tStart == result.getStartPosition() - start) {
/* 168 */               scanner.resetTo(tStart + result.getLength(), length - 1);
/* 169 */               token = scanner.getNextToken();
/* 170 */               if (token == 158)
/* 171 */                 return result; 
/*     */             } 
/*     */           } 
/* 174 */         } catch (InvalidInputException invalidInputException) {
/*     */         
/* 176 */         } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/*     */           
/* 178 */           return null;
/*     */         } 
/*     */       } 
/*     */     } 
/* 182 */     return finder.getCoveringNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NodeFinder(ASTNode root, int start, int length) {
/* 195 */     NodeFinderVisitor nodeFinderVisitor = new NodeFinderVisitor(start, length);
/* 196 */     root.accept(nodeFinderVisitor);
/* 197 */     this.fCoveredNode = nodeFinderVisitor.getCoveredNode();
/* 198 */     this.fCoveringNode = nodeFinderVisitor.getCoveringNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ASTNode getCoveredNode() {
/* 213 */     return this.fCoveredNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ASTNode getCoveringNode() {
/* 226 */     return this.fCoveringNode;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\NodeFinder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */