/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConditionalExpression
/*     */   extends Expression
/*     */ {
/*  39 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(ConditionalExpression.class, "expression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final ChildPropertyDescriptor THEN_EXPRESSION_PROPERTY = new ChildPropertyDescriptor(ConditionalExpression.class, "thenExpression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public static final ChildPropertyDescriptor ELSE_EXPRESSION_PROPERTY = new ChildPropertyDescriptor(ConditionalExpression.class, "elseExpression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  63 */     List properyList = new ArrayList(4);
/*  64 */     createPropertyList(ConditionalExpression.class, properyList);
/*  65 */     addProperty(EXPRESSION_PROPERTY, properyList);
/*  66 */     addProperty(THEN_EXPRESSION_PROPERTY, properyList);
/*  67 */     addProperty(ELSE_EXPRESSION_PROPERTY, properyList);
/*  68 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  83 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   private Expression conditionExpression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   private Expression thenExpression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   private Expression elseExpression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConditionalExpression(AST ast) {
/* 115 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 120 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 125 */     if (property == EXPRESSION_PROPERTY) {
/* 126 */       if (get) {
/* 127 */         return getExpression();
/*     */       }
/* 129 */       setExpression((Expression)child);
/* 130 */       return null;
/*     */     } 
/*     */     
/* 133 */     if (property == THEN_EXPRESSION_PROPERTY) {
/* 134 */       if (get) {
/* 135 */         return getThenExpression();
/*     */       }
/* 137 */       setThenExpression((Expression)child);
/* 138 */       return null;
/*     */     } 
/*     */     
/* 141 */     if (property == ELSE_EXPRESSION_PROPERTY) {
/* 142 */       if (get) {
/* 143 */         return getElseExpression();
/*     */       }
/* 145 */       setElseExpression((Expression)child);
/* 146 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 150 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 155 */     return 16;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 160 */     ConditionalExpression result = new ConditionalExpression(target);
/* 161 */     result.setSourceRange(getStartPosition(), getLength());
/* 162 */     result.setExpression((Expression)getExpression().clone(target));
/* 163 */     result.setThenExpression(
/* 164 */         (Expression)getThenExpression().clone(target));
/* 165 */     result.setElseExpression(
/* 166 */         (Expression)getElseExpression().clone(target));
/* 167 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 173 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 178 */     boolean visitChildren = visitor.visit(this);
/* 179 */     if (visitChildren) {
/*     */       
/* 181 */       acceptChild(visitor, getExpression());
/* 182 */       acceptChild(visitor, getThenExpression());
/* 183 */       acceptChild(visitor, getElseExpression());
/*     */     } 
/* 185 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 194 */     if (this.conditionExpression == null)
/*     */     {
/* 196 */       synchronized (this) {
/* 197 */         if (this.conditionExpression == null) {
/* 198 */           preLazyInit();
/* 199 */           this.conditionExpression = new SimpleName(this.ast);
/* 200 */           postLazyInit(this.conditionExpression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 204 */     return this.conditionExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 219 */     if (expression == null) {
/* 220 */       throw new IllegalArgumentException();
/*     */     }
/* 222 */     ASTNode oldChild = this.conditionExpression;
/* 223 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 224 */     this.conditionExpression = expression;
/* 225 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getThenExpression() {
/* 234 */     if (this.thenExpression == null)
/*     */     {
/* 236 */       synchronized (this) {
/* 237 */         if (this.thenExpression == null) {
/* 238 */           preLazyInit();
/* 239 */           this.thenExpression = new SimpleName(this.ast);
/* 240 */           postLazyInit(this.thenExpression, THEN_EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 244 */     return this.thenExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setThenExpression(Expression expression) {
/* 259 */     if (expression == null) {
/* 260 */       throw new IllegalArgumentException();
/*     */     }
/* 262 */     ASTNode oldChild = this.thenExpression;
/* 263 */     preReplaceChild(oldChild, expression, THEN_EXPRESSION_PROPERTY);
/* 264 */     this.thenExpression = expression;
/* 265 */     postReplaceChild(oldChild, expression, THEN_EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getElseExpression() {
/* 274 */     if (this.elseExpression == null)
/*     */     {
/* 276 */       synchronized (this) {
/* 277 */         if (this.elseExpression == null) {
/* 278 */           preLazyInit();
/* 279 */           this.elseExpression = new SimpleName(this.ast);
/* 280 */           postLazyInit(this.elseExpression, ELSE_EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 284 */     return this.elseExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setElseExpression(Expression expression) {
/* 299 */     if (expression == null) {
/* 300 */       throw new IllegalArgumentException();
/*     */     }
/* 302 */     ASTNode oldChild = this.elseExpression;
/* 303 */     preReplaceChild(oldChild, expression, ELSE_EXPRESSION_PROPERTY);
/* 304 */     this.elseExpression = expression;
/* 305 */     postReplaceChild(oldChild, expression, ELSE_EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 311 */     return 52;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 316 */     return 
/* 317 */       memSize() + (
/* 318 */       (this.conditionExpression == null) ? 0 : getExpression().treeSize()) + (
/* 319 */       (this.thenExpression == null) ? 0 : getThenExpression().treeSize()) + (
/* 320 */       (this.elseExpression == null) ? 0 : getElseExpression().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ConditionalExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */