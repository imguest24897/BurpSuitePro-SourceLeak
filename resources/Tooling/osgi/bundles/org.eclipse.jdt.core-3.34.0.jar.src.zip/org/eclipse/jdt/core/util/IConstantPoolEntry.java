package org.eclipse.jdt.core.util;

public interface IConstantPoolEntry {
  int getKind();
  
  int getClassInfoNameIndex();
  
  int getClassIndex();
  
  int getNameAndTypeIndex();
  
  int getStringIndex();
  
  String getStringValue();
  
  int getIntegerValue();
  
  float getFloatValue();
  
  double getDoubleValue();
  
  long getLongValue();
  
  int getNameAndTypeInfoDescriptorIndex();
  
  int getNameAndTypeInfoNameIndex();
  
  char[] getClassInfoName();
  
  char[] getClassName();
  
  char[] getFieldName();
  
  char[] getMethodName();
  
  char[] getFieldDescriptor();
  
  char[] getMethodDescriptor();
  
  char[] getUtf8Value();
  
  int getUtf8Length();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\cor\\util\IConstantPoolEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */