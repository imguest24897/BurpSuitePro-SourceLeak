package org.eclipse.jdt.core;

import org.eclipse.core.runtime.IProgressMonitor;

public interface IOpenable {
  void close() throws JavaModelException;
  
  String findRecommendedLineSeparator() throws JavaModelException;
  
  IBuffer getBuffer() throws JavaModelException;
  
  boolean hasUnsavedChanges() throws JavaModelException;
  
  boolean isConsistent() throws JavaModelException;
  
  boolean isOpen();
  
  void makeConsistent(IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void open(IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void save(IProgressMonitor paramIProgressMonitor, boolean paramBoolean) throws JavaModelException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IOpenable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */