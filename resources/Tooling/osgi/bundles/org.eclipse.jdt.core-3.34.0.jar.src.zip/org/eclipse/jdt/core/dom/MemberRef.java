/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemberRef
/*     */   extends ASTNode
/*     */   implements IDocElement
/*     */ {
/*  42 */   public static final ChildPropertyDescriptor QUALIFIER_PROPERTY = new ChildPropertyDescriptor(MemberRef.class, "qualifier", Name.class, false, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(MemberRef.class, "name", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  59 */     List propertyList = new ArrayList(3);
/*  60 */     createPropertyList(MemberRef.class, propertyList);
/*  61 */     addProperty(QUALIFIER_PROPERTY, propertyList);
/*  62 */     addProperty(NAME_PROPERTY, propertyList);
/*  63 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  76 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private Name optionalQualifier = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private SimpleName memberName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MemberRef(AST ast) {
/* 103 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 108 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 113 */     if (property == QUALIFIER_PROPERTY) {
/* 114 */       if (get) {
/* 115 */         return getQualifier();
/*     */       }
/* 117 */       setQualifier((Name)child);
/* 118 */       return null;
/*     */     } 
/*     */     
/* 121 */     if (property == NAME_PROPERTY) {
/* 122 */       if (get) {
/* 123 */         return getName();
/*     */       }
/* 125 */       setName((SimpleName)child);
/* 126 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 130 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 135 */     return 67;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 140 */     MemberRef result = new MemberRef(target);
/* 141 */     result.setSourceRange(getStartPosition(), getLength());
/* 142 */     result.setQualifier((Name)ASTNode.copySubtree(target, getQualifier()));
/* 143 */     result.setName((SimpleName)ASTNode.copySubtree(target, getName()));
/* 144 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 150 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 155 */     boolean visitChildren = visitor.visit(this);
/* 156 */     if (visitChildren) {
/*     */       
/* 158 */       acceptChild(visitor, getQualifier());
/* 159 */       acceptChild(visitor, getName());
/*     */     } 
/* 161 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getQualifier() {
/* 171 */     return this.optionalQualifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQualifier(Name name) {
/* 186 */     ASTNode oldChild = this.optionalQualifier;
/* 187 */     preReplaceChild(oldChild, name, QUALIFIER_PROPERTY);
/* 188 */     this.optionalQualifier = name;
/* 189 */     postReplaceChild(oldChild, name, QUALIFIER_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 198 */     if (this.memberName == null)
/*     */     {
/* 200 */       synchronized (this) {
/* 201 */         if (this.memberName == null) {
/* 202 */           preLazyInit();
/* 203 */           this.memberName = new SimpleName(this.ast);
/* 204 */           postLazyInit(this.memberName, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 208 */     return this.memberName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName name) {
/* 223 */     if (name == null) {
/* 224 */       throw new IllegalArgumentException();
/*     */     }
/* 226 */     ASTNode oldChild = this.memberName;
/* 227 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 228 */     this.memberName = name;
/* 229 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IBinding resolveBinding() {
/* 244 */     return this.ast.getBindingResolver().resolveReference(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 249 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 254 */     return 
/* 255 */       memSize() + (
/* 256 */       (this.optionalQualifier == null) ? 0 : getQualifier().treeSize()) + (
/* 257 */       (this.memberName == null) ? 0 : getName().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\MemberRef.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */