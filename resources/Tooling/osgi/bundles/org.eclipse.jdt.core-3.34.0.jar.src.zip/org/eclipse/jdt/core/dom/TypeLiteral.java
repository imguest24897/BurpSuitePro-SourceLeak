/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeLiteral
/*     */   extends Expression
/*     */ {
/*  39 */   public static final ChildPropertyDescriptor TYPE_PROPERTY = new ChildPropertyDescriptor(TypeLiteral.class, "type", Type.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  49 */     List propertyList = new ArrayList(2);
/*  50 */     createPropertyList(TypeLiteral.class, propertyList);
/*  51 */     addProperty(TYPE_PROPERTY, propertyList);
/*  52 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  66 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   private Type type = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TypeLiteral(AST ast) {
/*  85 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  90 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/*  95 */     if (property == TYPE_PROPERTY) {
/*  96 */       if (get) {
/*  97 */         return getType();
/*     */       }
/*  99 */       setType((Type)child);
/* 100 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 104 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 109 */     return 57;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 114 */     TypeLiteral result = new TypeLiteral(target);
/* 115 */     result.setSourceRange(getStartPosition(), getLength());
/* 116 */     result.setType((Type)getType().clone(target));
/* 117 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 123 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 128 */     boolean visitChildren = visitor.visit(this);
/* 129 */     if (visitChildren) {
/* 130 */       acceptChild(visitor, getType());
/*     */     }
/* 132 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 141 */     if (this.type == null)
/*     */     {
/* 143 */       synchronized (this) {
/* 144 */         if (this.type == null) {
/* 145 */           preLazyInit();
/* 146 */           this.type = this.ast.newPrimitiveType(PrimitiveType.INT);
/* 147 */           postLazyInit(this.type, TYPE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 151 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(Type type) {
/* 165 */     if (type == null) {
/* 166 */       throw new IllegalArgumentException();
/*     */     }
/* 168 */     ASTNode oldChild = this.type;
/* 169 */     preReplaceChild(oldChild, type, TYPE_PROPERTY);
/* 170 */     this.type = type;
/* 171 */     postReplaceChild(oldChild, type, TYPE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 177 */     return 44;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 182 */     return 
/* 183 */       memSize() + (
/* 184 */       (this.type == null) ? 0 : getType().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\TypeLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */