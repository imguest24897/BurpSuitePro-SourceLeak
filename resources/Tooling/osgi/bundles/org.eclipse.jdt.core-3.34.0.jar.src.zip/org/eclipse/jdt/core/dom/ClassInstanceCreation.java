/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassInstanceCreation
/*     */   extends Expression
/*     */ {
/*  51 */   public static final ChildListPropertyDescriptor TYPE_ARGUMENTS_PROPERTY = new ChildListPropertyDescriptor(ClassInstanceCreation.class, "typeArguments", Type.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(ClassInstanceCreation.class, "expression", Expression.class, false, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(ClassInstanceCreation.class, "name", Name.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public static final ChildPropertyDescriptor TYPE_PROPERTY = new ChildPropertyDescriptor(ClassInstanceCreation.class, "type", Type.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public static final ChildListPropertyDescriptor ARGUMENTS_PROPERTY = new ChildListPropertyDescriptor(ClassInstanceCreation.class, "arguments", Expression.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public static final ChildPropertyDescriptor ANONYMOUS_CLASS_DECLARATION_PROPERTY = new ChildPropertyDescriptor(ClassInstanceCreation.class, "anonymousClassDeclaration", AnonymousClassDeclaration.class, false, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 106 */     List properyList = new ArrayList(5);
/* 107 */     createPropertyList(ClassInstanceCreation.class, properyList);
/* 108 */     addProperty(EXPRESSION_PROPERTY, properyList);
/* 109 */     addProperty(NAME_PROPERTY, properyList);
/* 110 */     addProperty(ARGUMENTS_PROPERTY, properyList);
/* 111 */     addProperty(ANONYMOUS_CLASS_DECLARATION_PROPERTY, properyList);
/* 112 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(properyList);
/*     */     
/* 114 */     properyList = new ArrayList(6);
/* 115 */     createPropertyList(ClassInstanceCreation.class, properyList);
/* 116 */     addProperty(EXPRESSION_PROPERTY, properyList);
/* 117 */     addProperty(TYPE_ARGUMENTS_PROPERTY, properyList);
/* 118 */     addProperty(TYPE_PROPERTY, properyList);
/* 119 */     addProperty(ARGUMENTS_PROPERTY, properyList);
/* 120 */     addProperty(ANONYMOUS_CLASS_DECLARATION_PROPERTY, properyList);
/* 121 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 136 */     if (apiLevel == 2) {
/* 137 */       return PROPERTY_DESCRIPTORS_2_0;
/*     */     }
/* 139 */     return PROPERTY_DESCRIPTORS_3_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   private Expression optionalExpression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   private ASTNode.NodeList typeArguments = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   private Name typeName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   private Type type = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   private ASTNode.NodeList arguments = new ASTNode.NodeList(this, ARGUMENTS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   private AnonymousClassDeclaration optionalAnonymousClassDeclaration = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ClassInstanceCreation(AST ast) {
/* 195 */     super(ast);
/* 196 */     if (ast.apiLevel >= 3) {
/* 197 */       this.typeArguments = new ASTNode.NodeList(this, TYPE_ARGUMENTS_PROPERTY);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 207 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 212 */     if (property == EXPRESSION_PROPERTY) {
/* 213 */       if (get) {
/* 214 */         return getExpression();
/*     */       }
/* 216 */       setExpression((Expression)child);
/* 217 */       return null;
/*     */     } 
/*     */     
/* 220 */     if (property == NAME_PROPERTY) {
/* 221 */       if (get) {
/* 222 */         return getName();
/*     */       }
/* 224 */       setName((Name)child);
/* 225 */       return null;
/*     */     } 
/*     */     
/* 228 */     if (property == TYPE_PROPERTY) {
/* 229 */       if (get) {
/* 230 */         return getType();
/*     */       }
/* 232 */       setType((Type)child);
/* 233 */       return null;
/*     */     } 
/*     */     
/* 236 */     if (property == ANONYMOUS_CLASS_DECLARATION_PROPERTY) {
/* 237 */       if (get) {
/* 238 */         return getAnonymousClassDeclaration();
/*     */       }
/* 240 */       setAnonymousClassDeclaration((AnonymousClassDeclaration)child);
/* 241 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 245 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 250 */     if (property == ARGUMENTS_PROPERTY) {
/* 251 */       return arguments();
/*     */     }
/* 253 */     if (property == TYPE_ARGUMENTS_PROPERTY) {
/* 254 */       return typeArguments();
/*     */     }
/*     */     
/* 257 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 262 */     return 14;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 267 */     ClassInstanceCreation result = new ClassInstanceCreation(target);
/* 268 */     result.setSourceRange(getStartPosition(), getLength());
/* 269 */     result.setExpression(
/* 270 */         (Expression)ASTNode.copySubtree(target, getExpression()));
/* 271 */     if (this.ast.apiLevel == 2) {
/* 272 */       result.setName((Name)getName().clone(target));
/*     */     }
/* 274 */     if (this.ast.apiLevel >= 3) {
/* 275 */       result.typeArguments().addAll(ASTNode.copySubtrees(target, typeArguments()));
/* 276 */       result.setType((Type)getType().clone(target));
/*     */     } 
/* 278 */     result.arguments().addAll(ASTNode.copySubtrees(target, arguments()));
/* 279 */     result.setAnonymousClassDeclaration(
/*     */         
/* 281 */         (AnonymousClassDeclaration)ASTNode.copySubtree(target, getAnonymousClassDeclaration()));
/* 282 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 288 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 293 */     boolean visitChildren = visitor.visit(this);
/* 294 */     if (visitChildren) {
/*     */       
/* 296 */       acceptChild(visitor, getExpression());
/* 297 */       if (this.ast.apiLevel == 2) {
/* 298 */         acceptChild(visitor, getName());
/*     */       }
/* 300 */       if (this.ast.apiLevel >= 3) {
/* 301 */         acceptChildren(visitor, this.typeArguments);
/* 302 */         acceptChild(visitor, getType());
/*     */       } 
/* 304 */       acceptChildren(visitor, this.arguments);
/* 305 */       acceptChild(visitor, getAnonymousClassDeclaration());
/*     */     } 
/* 307 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 317 */     return this.optionalExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 335 */     ASTNode oldChild = this.optionalExpression;
/* 336 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 337 */     this.optionalExpression = expression;
/* 338 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List typeArguments() {
/* 353 */     if (this.typeArguments == null) {
/* 354 */       unsupportedIn2();
/*     */     }
/* 356 */     return this.typeArguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getName() {
/* 371 */     return internalGetName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Name internalGetName() {
/* 380 */     supportedOnlyIn2();
/* 381 */     if (this.typeName == null)
/*     */     {
/* 383 */       synchronized (this) {
/* 384 */         if (this.typeName == null) {
/* 385 */           preLazyInit();
/* 386 */           this.typeName = new SimpleName(this.ast);
/* 387 */           postLazyInit(this.typeName, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 391 */     return this.typeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(Name name) {
/* 411 */     internalSetName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void internalSetName(Name name) {
/* 420 */     supportedOnlyIn2();
/* 421 */     if (name == null) {
/* 422 */       throw new IllegalArgumentException();
/*     */     }
/* 424 */     ASTNode oldChild = this.typeName;
/* 425 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 426 */     this.typeName = name;
/* 427 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 440 */     unsupportedIn2();
/* 441 */     if (this.type == null)
/*     */     {
/* 443 */       synchronized (this) {
/* 444 */         if (this.type == null) {
/* 445 */           preLazyInit();
/* 446 */           this.type = new SimpleType(this.ast);
/* 447 */           postLazyInit(this.type, TYPE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 451 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(Type type) {
/* 469 */     unsupportedIn2();
/* 470 */     if (type == null) {
/* 471 */       throw new IllegalArgumentException();
/*     */     }
/* 473 */     ASTNode oldChild = this.type;
/* 474 */     preReplaceChild(oldChild, type, TYPE_PROPERTY);
/* 475 */     this.type = type;
/* 476 */     postReplaceChild(oldChild, type, TYPE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List arguments() {
/* 487 */     return this.arguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnonymousClassDeclaration getAnonymousClassDeclaration() {
/* 497 */     return this.optionalAnonymousClassDeclaration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnonymousClassDeclaration(AnonymousClassDeclaration decl) {
/* 508 */     ASTNode oldChild = this.optionalAnonymousClassDeclaration;
/* 509 */     preReplaceChild(oldChild, decl, ANONYMOUS_CLASS_DECLARATION_PROPERTY);
/* 510 */     this.optionalAnonymousClassDeclaration = decl;
/* 511 */     postReplaceChild(oldChild, decl, ANONYMOUS_CLASS_DECLARATION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMethodBinding resolveConstructorBinding() {
/* 527 */     return this.ast.getBindingResolver().resolveConstructor(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isResolvedTypeInferredFromExpectedType() {
/* 541 */     return this.ast.getBindingResolver().isResolvedTypeInferredFromExpectedType(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 547 */     return 64;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 555 */     return 
/* 556 */       memSize() + (
/* 557 */       (this.typeName == null) ? 0 : getName().treeSize()) + (
/* 558 */       (this.type == null) ? 0 : getType().treeSize()) + (
/* 559 */       (this.optionalExpression == null) ? 0 : getExpression().treeSize()) + (
/* 560 */       (this.typeArguments == null) ? 0 : this.typeArguments.listSize()) + (
/* 561 */       (this.arguments == null) ? 0 : this.arguments.listSize()) + (
/* 562 */       (this.optionalAnonymousClassDeclaration == null) ? 0 : getAnonymousClassDeclaration().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ClassInstanceCreation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */