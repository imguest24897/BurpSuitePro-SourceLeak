/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Javadoc
/*     */   extends Comment
/*     */ {
/*  43 */   public static final SimplePropertyDescriptor COMMENT_PROPERTY = new SimplePropertyDescriptor(Javadoc.class, "comment", String.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public static final ChildListPropertyDescriptor TAGS_PROPERTY = new ChildListPropertyDescriptor(Javadoc.class, "tags", TagElement.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String MINIMAL_DOC_COMMENT = "/** */";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  70 */     List properyList = new ArrayList(3);
/*  71 */     createPropertyList(Javadoc.class, properyList);
/*  72 */     addProperty(COMMENT_PROPERTY, properyList);
/*  73 */     addProperty(TAGS_PROPERTY, properyList);
/*  74 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(properyList);
/*     */     
/*  76 */     properyList = new ArrayList(2);
/*  77 */     createPropertyList(Javadoc.class, properyList);
/*  78 */     addProperty(TAGS_PROPERTY, properyList);
/*  79 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  93 */     if (apiLevel == 2) {
/*  94 */       return PROPERTY_DESCRIPTORS_2_0;
/*     */     }
/*  96 */     return PROPERTY_DESCRIPTORS_3_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   private String comment = "/** */";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   private ASTNode.NodeList tags = new ASTNode.NodeList(this, TAGS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Javadoc(AST ast) {
/* 136 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 141 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final Object internalGetSetObjectProperty(SimplePropertyDescriptor property, boolean get, Object value) {
/* 146 */     if (property == COMMENT_PROPERTY) {
/* 147 */       if (get) {
/* 148 */         return getComment();
/*     */       }
/* 150 */       setComment((String)value);
/* 151 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 155 */     return super.internalGetSetObjectProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 160 */     if (property == TAGS_PROPERTY) {
/* 161 */       return tags();
/*     */     }
/*     */     
/* 164 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 169 */     return 29;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 174 */     Javadoc result = new Javadoc(target);
/* 175 */     result.setSourceRange(getStartPosition(), getLength());
/* 176 */     if (this.ast.apiLevel == 2) {
/* 177 */       result.setComment(getComment());
/*     */     }
/* 179 */     result.tags().addAll(ASTNode.copySubtrees(target, tags()));
/* 180 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 186 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 191 */     boolean visitChildren = visitor.visit(this);
/* 192 */     if (visitChildren)
/*     */     {
/* 194 */       acceptChildren(visitor, this.tags);
/*     */     }
/* 196 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getComment() {
/* 211 */     supportedOnlyIn2();
/* 212 */     return this.comment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setComment(String docComment) {
/* 229 */     supportedOnlyIn2();
/* 230 */     if (docComment == null) {
/* 231 */       throw new IllegalArgumentException();
/*     */     }
/* 233 */     char[] source = docComment.toCharArray();
/* 234 */     Scanner scanner = this.ast.scanner;
/* 235 */     scanner.resetTo(0, source.length);
/* 236 */     scanner.setSource(source);
/*     */     
/*     */     try {
/* 239 */       boolean onlyOneComment = false; int token;
/* 240 */       while ((token = scanner.getNextToken()) != 64) {
/* 241 */         switch (token) {
/*     */           case 1003:
/* 243 */             if (onlyOneComment) {
/* 244 */               throw new IllegalArgumentException();
/*     */             }
/* 246 */             onlyOneComment = true;
/*     */             continue;
/*     */         } 
/* 249 */         onlyOneComment = false;
/*     */       } 
/*     */       
/* 252 */       if (!onlyOneComment) {
/* 253 */         throw new IllegalArgumentException();
/*     */       }
/* 255 */     } catch (InvalidInputException e) {
/* 256 */       InvalidInputException invalidInputException1; throw new IllegalArgumentException(invalidInputException1);
/*     */     } 
/* 258 */     preValueChange(COMMENT_PROPERTY);
/* 259 */     this.comment = docComment;
/* 260 */     postValueChange(COMMENT_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List tags() {
/* 289 */     return this.tags;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 294 */     int size = super.memSize() + 8;
/* 295 */     if (this.comment != "/** */")
/*     */     {
/* 297 */       size += stringSize(this.comment);
/*     */     }
/* 299 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 304 */     return memSize() + this.tags.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\Javadoc.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */