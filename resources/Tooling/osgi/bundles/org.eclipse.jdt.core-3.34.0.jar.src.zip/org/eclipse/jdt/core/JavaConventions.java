/*     */ package org.eclipse.jdt.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.regex.Pattern;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*     */ import org.eclipse.jdt.internal.compiler.parser.ScannerHelper;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ import org.eclipse.jdt.internal.core.ClasspathEntry;
/*     */ import org.eclipse.jdt.internal.core.JavaModelStatus;
/*     */ import org.eclipse.jdt.internal.core.util.Messages;
/*     */ import org.eclipse.jdt.internal.core.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JavaConventions
/*     */ {
/*     */   private static final char DOT = '.';
/*  51 */   private static final Pattern DOT_DOT = Pattern.compile("(\\.)(\\1)+");
/*  52 */   private static final Pattern PREFIX_JAVA = Pattern.compile("java$");
/*  53 */   private static final Scanner SCANNER = new Scanner(false, true, false, 3080192L, null, null, true);
/*     */   
/*     */   private static Map<String, Set<String>> restrictedIdentifiersMap;
/*  56 */   private static String VAR_ID = "var"; private static Map<String, Set<String>> restrictedIdentifierPreviewMap; private static List<String> javaVersions;
/*  57 */   private static String YIELD_ID = "yield";
/*  58 */   private static String RECORD_ID = "record";
/*     */   
/*     */   static {
/*  61 */     javaVersions = new ArrayList<>();
/*  62 */     javaVersions.add(0, "10");
/*  63 */     javaVersions.add(1, "11");
/*  64 */     javaVersions.add(2, "12");
/*  65 */     javaVersions.add(3, "13");
/*  66 */     javaVersions.add(4, "14");
/*     */     
/*  68 */     restrictedIdentifiersMap = new HashMap<>();
/*     */     
/*  70 */     Set<String> set = new HashSet<>();
/*  71 */     set.add(new String(VAR_ID));
/*  72 */     restrictedIdentifiersMap.put("10", set);
/*     */     
/*  74 */     set = new HashSet<>();
/*  75 */     set.add(new String(YIELD_ID));
/*  76 */     restrictedIdentifiersMap.put("14", set);
/*     */     
/*  78 */     restrictedIdentifierPreviewMap = new HashMap<>();
/*     */     
/*  80 */     set = new HashSet<>();
/*  81 */     set.add(new String(RECORD_ID));
/*  82 */     restrictedIdentifierPreviewMap.put("14", set);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isOverlappingRoots(IPath rootPath1, IPath rootPath2) {
/* 103 */     if (rootPath1 == null || rootPath2 == null) {
/* 104 */       return false;
/*     */     }
/* 106 */     return !(!rootPath1.isPrefixOf(rootPath2) && !rootPath2.isPrefixOf(rootPath1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized char[] scannedIdentifier(String id, String sourceLevel, String complianceLevel) {
/* 115 */     return scannedIdentifier(id, sourceLevel, complianceLevel, null, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized char[] scannedIdentifier(String id, String sourceLevel, String complianceLevel, String previewEnabled, boolean allowRestrictedKeyWords) {
/* 123 */     if (id == null) {
/* 124 */       return null;
/*     */     }
/*     */     
/* 127 */     SCANNER.sourceLevel = (sourceLevel == null) ? 3080192L : CompilerOptions.versionToJdkLevel(sourceLevel);
/* 128 */     SCANNER.complianceLevel = (complianceLevel == null) ? 3080192L : CompilerOptions.versionToJdkLevel(complianceLevel);
/* 129 */     SCANNER.previewEnabled = (previewEnabled == null) ? false : "enabled".equals(previewEnabled);
/*     */     
/*     */     try {
/* 132 */       SCANNER.setSource(id.toCharArray());
/* 133 */       int token = SCANNER.scanIdentifier();
/* 134 */       if (token != 19) return null; 
/* 135 */       if (SCANNER.currentPosition == SCANNER.eofPosition) {
/*     */         try {
/* 137 */           char[] src = SCANNER.getCurrentIdentifierSource();
/* 138 */           src = scanForRestrictedKeyWords(src, sourceLevel, complianceLevel, SCANNER.previewEnabled, allowRestrictedKeyWords);
/* 139 */           return src;
/* 140 */         } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
/* 141 */           return null;
/*     */         } 
/*     */       }
/* 144 */       return null;
/*     */     
/*     */     }
/* 147 */     catch (InvalidInputException invalidInputException) {
/* 148 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static char[] scanForRestrictedKeyWords(char[] id, String sourceLevel, String complianceLevel, boolean previewEnabled, boolean allowRestrictedKeyWords) {
/* 153 */     if (allowRestrictedKeyWords) {
/* 154 */       return id;
/*     */     }
/* 156 */     int index = javaVersions.indexOf(sourceLevel);
/* 157 */     String searchId = new String(id);
/* 158 */     for (int i = index; i >= 0; i--) {
/* 159 */       String level = javaVersions.get(i);
/* 160 */       if (level != null) {
/* 161 */         Set<String> rIds = restrictedIdentifiersMap.get(level);
/* 162 */         if (rIds != null && rIds.contains(searchId)) {
/* 163 */           return null;
/*     */         }
/* 165 */         if (previewEnabled) {
/* 166 */           Set<String> prIds = restrictedIdentifierPreviewMap.get(level);
/* 167 */           if (prIds != null && prIds.contains(searchId)) {
/* 168 */             return null;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 173 */     return id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateCompilationUnitName(String name) {
/* 195 */     return validateCompilationUnitName(name, "1.3", "1.3");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateCompilationUnitName(String name, String sourceLevel, String complianceLevel) {
/* 219 */     if (name == null) {
/* 220 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_unit_nullName, null);
/*     */     }
/* 222 */     if (!Util.isJavaLikeFileName(name)) {
/* 223 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_unit_notJavaName, null);
/*     */     }
/*     */ 
/*     */     
/* 227 */     int index = name.lastIndexOf('.');
/* 228 */     if (index == -1) {
/* 229 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_unit_notJavaName, null);
/*     */     }
/* 231 */     String identifier = name.substring(0, index);
/*     */ 
/*     */ 
/*     */     
/* 235 */     if (!CharOperation.equals(identifier.toCharArray(), TypeConstants.PACKAGE_INFO_NAME) && 
/* 236 */       !CharOperation.equals(identifier.toCharArray(), TypeConstants.MODULE_INFO_NAME)) {
/* 237 */       IStatus iStatus = validateIdentifier(identifier, sourceLevel, complianceLevel);
/* 238 */       if (!iStatus.isOK()) {
/* 239 */         return iStatus;
/*     */       }
/*     */     } 
/* 242 */     IStatus status = ResourcesPlugin.getWorkspace().validateName(name, 1);
/* 243 */     if (!status.isOK()) {
/* 244 */       return status;
/*     */     }
/* 246 */     return JavaModelStatus.VERIFIED_OK;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateClassFileName(String name) {
/* 268 */     return validateClassFileName(name, "1.3", "1.3");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateClassFileName(String name, String sourceLevel, String complianceLevel) {
/* 291 */     if (name == null)
/* 292 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_classFile_nullName, null); 
/* 293 */     if (!Util.isClassFileName(name)) {
/* 294 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_classFile_notClassFileName, null);
/*     */     }
/*     */ 
/*     */     
/* 298 */     int index = name.lastIndexOf('.');
/* 299 */     if (index == -1) {
/* 300 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_classFile_notClassFileName, null);
/*     */     }
/* 302 */     String identifier = name.substring(0, index);
/*     */ 
/*     */ 
/*     */     
/* 306 */     if (!CharOperation.equals(identifier.toCharArray(), TypeConstants.PACKAGE_INFO_NAME) && 
/* 307 */       !CharOperation.equals(identifier.toCharArray(), TypeConstants.MODULE_INFO_NAME)) {
/* 308 */       IStatus iStatus = validateIdentifier(identifier, sourceLevel, complianceLevel);
/* 309 */       if (!iStatus.isOK()) {
/* 310 */         return iStatus;
/*     */       }
/*     */     } 
/* 313 */     IStatus status = ResourcesPlugin.getWorkspace().validateName(name, 1);
/* 314 */     if (!status.isOK()) {
/* 315 */       return status;
/*     */     }
/* 317 */     return JavaModelStatus.VERIFIED_OK;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateFieldName(String name) {
/* 333 */     return validateIdentifier(name, "1.3", "1.3");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateFieldName(String name, String sourceLevel, String complianceLevel) {
/* 351 */     return validateIdentifier(name, sourceLevel, complianceLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateIdentifier(String id) {
/* 368 */     return validateIdentifier(id, "1.3", "1.3");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateIdentifier(String id, String sourceLevel, String complianceLevel) {
/* 387 */     if (scannedIdentifier(id, sourceLevel, complianceLevel) != null) {
/* 388 */       return JavaModelStatus.VERIFIED_OK;
/*     */     }
/* 390 */     return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.bind(Messages.convention_illegalIdentifier, id), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateImportDeclaration(String name) {
/* 408 */     return validateImportDeclaration(name, "1.3", "1.3");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateImportDeclaration(String name, String sourceLevel, String complianceLevel) {
/* 427 */     if (name == null || name.length() == 0) {
/* 428 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_import_nullImport, null);
/*     */     }
/* 430 */     if (name.charAt(name.length() - 1) == '*') {
/* 431 */       if (name.charAt(name.length() - 2) == '.') {
/* 432 */         return validatePackageName(name.substring(0, name.length() - 2), sourceLevel, complianceLevel);
/*     */       }
/* 434 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_import_unqualifiedImport, null);
/*     */     } 
/*     */     
/* 437 */     return validatePackageName(name, sourceLevel, complianceLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateJavaTypeName(String name) {
/* 454 */     return validateJavaTypeName(name, "1.3", "1.3");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateJavaTypeName(String name, String sourceLevel, String complianceLevel) {
/* 489 */     return internalValidateJavaTypeName(name, sourceLevel, complianceLevel, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateJavaTypeName(String name, String sourceLevel, String complianceLevel, String previewEnabled) {
/* 533 */     return internalValidateJavaTypeName(name, sourceLevel, complianceLevel, previewEnabled);
/*     */   }
/*     */   private static IStatus internalValidateJavaTypeName(String name, String sourceLevel, String complianceLevel, String previewEnabled) {
/*     */     char[] scannedID;
/* 537 */     if (name == null) {
/* 538 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_type_nullName, null);
/*     */     }
/* 540 */     String trimmed = name.trim();
/* 541 */     if (!name.equals(trimmed)) {
/* 542 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_type_nameWithBlanks, null);
/*     */     }
/* 544 */     int index = name.lastIndexOf('.');
/*     */     
/* 546 */     if (index == -1) {
/*     */       
/* 548 */       scannedID = scannedIdentifier(name, sourceLevel, complianceLevel, previewEnabled, false);
/*     */     } else {
/*     */       
/* 551 */       String pkg = name.substring(0, index).trim();
/* 552 */       IStatus status = validatePackageName(pkg, sourceLevel, complianceLevel);
/* 553 */       if (!status.isOK()) {
/* 554 */         return status;
/*     */       }
/* 556 */       String type = name.substring(index + 1).trim();
/* 557 */       scannedID = scannedIdentifier(type, sourceLevel, complianceLevel, previewEnabled, false);
/*     */     } 
/*     */     
/* 560 */     if (scannedID != null) {
/* 561 */       IStatus status = ResourcesPlugin.getWorkspace().validateName(new String(scannedID), 1);
/* 562 */       if (!status.isOK()) {
/* 563 */         return status;
/*     */       }
/* 565 */       if (CharOperation.contains('$', scannedID)) {
/* 566 */         return (IStatus)new Status(2, "org.eclipse.jdt.core", -1, Messages.convention_type_dollarName, null);
/*     */       }
/* 568 */       if (scannedID.length > 0 && ScannerHelper.isLowerCase(scannedID[0])) {
/* 569 */         return (IStatus)new Status(2, "org.eclipse.jdt.core", -1, Messages.convention_type_lowercaseName, null);
/*     */       }
/* 571 */       return JavaModelStatus.VERIFIED_OK;
/*     */     } 
/* 573 */     return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.bind(Messages.convention_type_invalidName, name), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateMethodName(String name) {
/* 591 */     return validateMethodName(name, "1.3", "1.3");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateMethodName(String name, String sourceLevel, String complianceLevel) {
/* 610 */     return validateIdentifier(name, sourceLevel, complianceLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validatePackageName(String name) {
/* 631 */     return validatePackageName(name, "1.3", "1.3");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validatePackageName(String name, String sourceLevel, String complianceLevel) {
/*     */     Status status;
/* 655 */     if (name == null) {
/* 656 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_package_nullName, null);
/*     */     }
/*     */     int length;
/* 659 */     if ((length = name.length()) == 0) {
/* 660 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_package_emptyName, null);
/*     */     }
/* 662 */     if (name.charAt(0) == '.' || name.charAt(length - 1) == '.') {
/* 663 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_package_dotName, null);
/*     */     }
/* 665 */     if (CharOperation.isWhitespace(name.charAt(0)) || CharOperation.isWhitespace(name.charAt(name.length() - 1))) {
/* 666 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_package_nameWithBlanks, null);
/*     */     }
/* 668 */     if (DOT_DOT.matcher(name).find()) {
/* 669 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_package_consecutiveDotsName, null);
/*     */     }
/* 671 */     IWorkspace workspace = ResourcesPlugin.getWorkspace();
/* 672 */     StringTokenizer st = new StringTokenizer(name, ".");
/* 673 */     boolean firstToken = true;
/* 674 */     IStatus warningStatus = null;
/* 675 */     while (st.hasMoreTokens()) {
/* 676 */       String typeName = st.nextToken();
/* 677 */       typeName = typeName.trim();
/* 678 */       char[] scannedID = scannedIdentifier(typeName, sourceLevel, complianceLevel);
/* 679 */       if (scannedID == null) {
/* 680 */         return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.bind(Messages.convention_illegalIdentifier, typeName), null);
/*     */       }
/* 682 */       IStatus iStatus = workspace.validateName(new String(scannedID), 2);
/* 683 */       if (!iStatus.isOK()) {
/* 684 */         return iStatus;
/*     */       }
/* 686 */       if (firstToken && scannedID.length > 0 && ScannerHelper.isUpperCase(scannedID[0]) && 
/* 687 */         warningStatus == null) {
/* 688 */         status = new Status(2, "org.eclipse.jdt.core", -1, Messages.convention_package_uppercaseName, null);
/*     */       }
/*     */       
/* 691 */       firstToken = false;
/*     */     } 
/* 693 */     if (status != null) {
/* 694 */       return (IStatus)status;
/*     */     }
/* 696 */     return JavaModelStatus.VERIFIED_OK;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateModuleName(String name, String sourceLevel, String complianceLevel) {
/*     */     Status status;
/* 718 */     if (name == null) {
/* 719 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_module_nullName, null);
/*     */     }
/*     */     int length;
/* 722 */     if ((length = name.length()) == 0) {
/* 723 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_module_emptyName, null);
/*     */     }
/*     */     
/* 726 */     if (name.charAt(0) == '.' || name.charAt(length - 1) == '.') {
/* 727 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_module_dotName, null);
/*     */     }
/* 729 */     if (CharOperation.isWhitespace(name.charAt(0)) || CharOperation.isWhitespace(name.charAt(name.length() - 1))) {
/* 730 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_module_nameWithBlanks, null);
/*     */     }
/* 732 */     if (DOT_DOT.matcher(name).find()) {
/* 733 */       return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.convention_module_consecutiveDotsName, null);
/*     */     }
/* 735 */     IWorkspace workspace = ResourcesPlugin.getWorkspace();
/* 736 */     StringTokenizer st = new StringTokenizer(name, ".");
/* 737 */     boolean firstToken = true;
/* 738 */     IStatus warningStatus = null;
/* 739 */     while (st.hasMoreTokens()) {
/* 740 */       String segment = st.nextToken();
/* 741 */       segment = segment.trim();
/* 742 */       char[] scannedID = scannedIdentifier(segment, sourceLevel, complianceLevel);
/* 743 */       if (scannedID == null) {
/* 744 */         return (IStatus)new Status(4, "org.eclipse.jdt.core", -1, Messages.bind(Messages.convention_illegalIdentifier, segment), null);
/*     */       }
/* 746 */       if (firstToken && PREFIX_JAVA.matcher(segment).find()) {
/* 747 */         status = new Status(2, "org.eclipse.jdt.core", -1, Messages.bind(Messages.convention_module_javaName), null);
/*     */       }
/* 749 */       IStatus iStatus = workspace.validateName(new String(scannedID), 2);
/* 750 */       if (!iStatus.isOK()) {
/* 751 */         return iStatus;
/*     */       }
/* 753 */       if (firstToken && scannedID.length > 0 && ScannerHelper.isUpperCase(scannedID[0]) && 
/* 754 */         status == null) {
/* 755 */         status = new Status(2, "org.eclipse.jdt.core", -1, Messages.convention_module_uppercaseName, null);
/*     */       }
/*     */       
/* 758 */       firstToken = false;
/*     */     } 
/* 760 */     if (status != null) {
/* 761 */       return (IStatus)status;
/*     */     }
/* 763 */     return JavaModelStatus.VERIFIED_OK;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IJavaModelStatus validateClasspath(IJavaProject javaProject, IClasspathEntry[] rawClasspath, IPath projectOutputLocation) {
/* 801 */     return ClasspathEntry.validateClasspath(javaProject, rawClasspath, projectOutputLocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IJavaModelStatus validateClasspathEntry(IJavaProject project, IClasspathEntry entry, boolean checkSourceAttachment) {
/* 816 */     return ClasspathEntry.validateClasspathEntry(project, entry, checkSourceAttachment, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateTypeVariableName(String name) {
/* 833 */     return validateIdentifier(name, "1.3", "1.3");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateTypeVariableName(String name, String sourceLevel, String complianceLevel) {
/* 851 */     return validateIdentifier(name, sourceLevel, complianceLevel);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\JavaConventions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */