/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionNodeFound
/*    */   extends RuntimeException
/*    */ {
/*    */   public ASTNode astNode;
/*    */   public Binding qualifiedBinding;
/*    */   public Scope scope;
/*    */   public boolean insideTypeAnnotation = false;
/*    */   private static final long serialVersionUID = 6981437684184091462L;
/*    */   
/*    */   public CompletionNodeFound() {
/* 30 */     this(null, null, null, false);
/*    */   }
/*    */   public CompletionNodeFound(ASTNode astNode, Binding qualifiedBinding, Scope scope) {
/* 33 */     this(astNode, qualifiedBinding, scope, false);
/*    */   }
/*    */   public CompletionNodeFound(ASTNode astNode, Binding qualifiedBinding, Scope scope, boolean insideTypeAnnotation) {
/* 36 */     this.astNode = astNode;
/* 37 */     this.qualifiedBinding = qualifiedBinding;
/* 38 */     this.scope = scope;
/* 39 */     this.insideTypeAnnotation = insideTypeAnnotation;
/*    */   }
/*    */   public CompletionNodeFound(ASTNode astNode, Scope scope) {
/* 42 */     this(astNode, null, scope, false);
/*    */   }
/*    */   public CompletionNodeFound(ASTNode astNode, Scope scope, boolean insideTypeAnnotation) {
/* 45 */     this(astNode, null, scope, insideTypeAnnotation);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionNodeFound.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */