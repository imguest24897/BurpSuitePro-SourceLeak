/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldDeclaration
/*     */   extends BodyDeclaration
/*     */ {
/*  50 */   public static final ChildPropertyDescriptor JAVADOC_PROPERTY = internalJavadocPropertyFactory(FieldDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   public static final SimplePropertyDescriptor MODIFIERS_PROPERTY = internalModifiersPropertyFactory(FieldDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public static final ChildListPropertyDescriptor MODIFIERS2_PROPERTY = internalModifiers2PropertyFactory(FieldDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public static final ChildPropertyDescriptor TYPE_PROPERTY = new ChildPropertyDescriptor(FieldDeclaration.class, "type", Type.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public static final ChildListPropertyDescriptor FRAGMENTS_PROPERTY = new ChildListPropertyDescriptor(FieldDeclaration.class, "fragments", VariableDeclarationFragment.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  98 */     List properyList = new ArrayList(5);
/*  99 */     createPropertyList(FieldDeclaration.class, properyList);
/* 100 */     addProperty(JAVADOC_PROPERTY, properyList);
/* 101 */     addProperty(MODIFIERS_PROPERTY, properyList);
/* 102 */     addProperty(TYPE_PROPERTY, properyList);
/* 103 */     addProperty(FRAGMENTS_PROPERTY, properyList);
/* 104 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(properyList);
/*     */     
/* 106 */     properyList = new ArrayList(5);
/* 107 */     createPropertyList(FieldDeclaration.class, properyList);
/* 108 */     addProperty(JAVADOC_PROPERTY, properyList);
/* 109 */     addProperty(MODIFIERS2_PROPERTY, properyList);
/* 110 */     addProperty(TYPE_PROPERTY, properyList);
/* 111 */     addProperty(FRAGMENTS_PROPERTY, properyList);
/* 112 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 127 */     if (apiLevel == 2) {
/* 128 */       return PROPERTY_DESCRIPTORS_2_0;
/*     */     }
/* 130 */     return PROPERTY_DESCRIPTORS_3_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   private Type baseType = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   private ASTNode.NodeList variableDeclarationFragments = new ASTNode.NodeList(this, FRAGMENTS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FieldDeclaration(AST ast) {
/* 159 */     super(ast);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 168 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final int internalGetSetIntProperty(SimplePropertyDescriptor property, boolean get, int value) {
/* 173 */     if (property == MODIFIERS_PROPERTY) {
/* 174 */       if (get) {
/* 175 */         return getModifiers();
/*     */       }
/* 177 */       internalSetModifiers(value);
/* 178 */       return 0;
/*     */     } 
/*     */ 
/*     */     
/* 182 */     return super.internalGetSetIntProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 187 */     if (property == JAVADOC_PROPERTY) {
/* 188 */       if (get) {
/* 189 */         return getJavadoc();
/*     */       }
/* 191 */       setJavadoc((Javadoc)child);
/* 192 */       return null;
/*     */     } 
/*     */     
/* 195 */     if (property == TYPE_PROPERTY) {
/* 196 */       if (get) {
/* 197 */         return getType();
/*     */       }
/* 199 */       setType((Type)child);
/* 200 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 204 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 209 */     if (property == MODIFIERS2_PROPERTY) {
/* 210 */       return modifiers();
/*     */     }
/* 212 */     if (property == FRAGMENTS_PROPERTY) {
/* 213 */       return fragments();
/*     */     }
/*     */     
/* 216 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalJavadocProperty() {
/* 221 */     return JAVADOC_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final SimplePropertyDescriptor internalModifiersProperty() {
/* 226 */     return MODIFIERS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalModifiers2Property() {
/* 231 */     return MODIFIERS2_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 236 */     return 23;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 241 */     FieldDeclaration result = new FieldDeclaration(target);
/* 242 */     result.setSourceRange(getStartPosition(), getLength());
/* 243 */     result.setJavadoc(
/* 244 */         (Javadoc)ASTNode.copySubtree(target, getJavadoc()));
/* 245 */     if (this.ast.apiLevel == 2) {
/* 246 */       result.internalSetModifiers(getModifiers());
/*     */     }
/* 248 */     if (this.ast.apiLevel >= 3) {
/* 249 */       result.modifiers().addAll(ASTNode.copySubtrees(target, modifiers()));
/*     */     }
/* 251 */     result.setType((Type)getType().clone(target));
/* 252 */     result.fragments().addAll(
/* 253 */         ASTNode.copySubtrees(target, fragments()));
/* 254 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 260 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 265 */     boolean visitChildren = visitor.visit(this);
/* 266 */     if (visitChildren) {
/*     */       
/* 268 */       acceptChild(visitor, getJavadoc());
/* 269 */       if (this.ast.apiLevel >= 3) {
/* 270 */         acceptChildren(visitor, this.modifiers);
/*     */       }
/* 272 */       acceptChild(visitor, getType());
/* 273 */       acceptChildren(visitor, this.variableDeclarationFragments);
/*     */     } 
/* 275 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 289 */     if (this.baseType == null)
/*     */     {
/* 291 */       synchronized (this) {
/* 292 */         if (this.baseType == null) {
/* 293 */           preLazyInit();
/* 294 */           this.baseType = this.ast.newPrimitiveType(PrimitiveType.INT);
/* 295 */           postLazyInit(this.baseType, TYPE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 299 */     return this.baseType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(Type type) {
/* 313 */     if (type == null) {
/* 314 */       throw new IllegalArgumentException();
/*     */     }
/* 316 */     ASTNode oldChild = this.baseType;
/* 317 */     preReplaceChild(oldChild, type, TYPE_PROPERTY);
/* 318 */     this.baseType = type;
/* 319 */     postReplaceChild(oldChild, type, TYPE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List fragments() {
/* 333 */     return this.variableDeclarationFragments;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 338 */     return super.memSize() + 8;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 343 */     return 
/* 344 */       memSize() + (
/* 345 */       (this.optionalDocComment == null) ? 0 : getJavadoc().treeSize()) + (
/* 346 */       (this.modifiers == null) ? 0 : this.modifiers.listSize()) + (
/* 347 */       (this.baseType == null) ? 0 : getType().treeSize()) + 
/* 348 */       this.variableDeclarationFragments.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\FieldDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */