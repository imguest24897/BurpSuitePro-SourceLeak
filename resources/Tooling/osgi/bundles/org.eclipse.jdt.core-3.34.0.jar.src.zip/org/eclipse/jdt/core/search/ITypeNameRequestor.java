package org.eclipse.jdt.core.search;

public interface ITypeNameRequestor {
  void acceptClass(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[][] paramArrayOfchar, String paramString);
  
  void acceptInterface(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[][] paramArrayOfchar, String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\search\ITypeNameRequestor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */