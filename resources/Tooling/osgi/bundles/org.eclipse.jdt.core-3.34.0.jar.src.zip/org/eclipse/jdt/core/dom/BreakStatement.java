/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BreakStatement
/*     */   extends Statement
/*     */ {
/*  42 */   public static final ChildPropertyDescriptor LABEL_PROPERTY = new ChildPropertyDescriptor(BreakStatement.class, "label", SimpleName.class, false, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(BreakStatement.class, "expression", Expression.class, false, false);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isImplicit = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  66 */     List properyList = new ArrayList(2);
/*  67 */     createPropertyList(BreakStatement.class, properyList);
/*  68 */     addProperty(LABEL_PROPERTY, properyList);
/*  69 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  84 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel, boolean previewEnabled) {
/* 102 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   private SimpleName optionalLabel = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   private Expression optionalExpression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BreakStatement(AST ast) {
/* 125 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 130 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 135 */     if (property == LABEL_PROPERTY) {
/* 136 */       if (get) {
/* 137 */         return getLabel();
/*     */       }
/* 139 */       setLabel((SimpleName)child);
/* 140 */       return null;
/*     */     } 
/*     */     
/* 143 */     if (property == EXPRESSION_PROPERTY) {
/* 144 */       if (get) {
/* 145 */         return getExpression();
/*     */       }
/* 147 */       setExpression((Expression)child);
/* 148 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 152 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 157 */     return 10;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 162 */     BreakStatement result = new BreakStatement(target);
/* 163 */     result.setSourceRange(getStartPosition(), getLength());
/* 164 */     result.copyLeadingComment(this);
/* 165 */     result.setLabel((SimpleName)ASTNode.copySubtree(target, getLabel()));
/* 166 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 172 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 177 */     boolean visitChildren = visitor.visit(this);
/* 178 */     if (visitChildren) {
/* 179 */       acceptChild(visitor, getLabel());
/*     */     }
/* 181 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getLabel() {
/* 191 */     return this.optionalLabel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabel(SimpleName label) {
/* 206 */     ASTNode oldChild = this.optionalLabel;
/* 207 */     preReplaceChild(oldChild, label, LABEL_PROPERTY);
/* 208 */     this.optionalLabel = label;
/* 209 */     postReplaceChild(oldChild, label, LABEL_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 225 */     supportedOnlyIn12();
/* 226 */     return this.optionalExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 246 */     supportedOnlyIn12();
/* 247 */     ASTNode oldChild = this.optionalExpression;
/* 248 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 249 */     this.optionalExpression = expression;
/* 250 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isImplicit() {
/* 265 */     supportedOnlyIn12();
/* 266 */     return this.isImplicit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setImplicit(boolean isImplicit) {
/* 280 */     supportedOnlyIn12();
/* 281 */     this.isImplicit = isImplicit;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 286 */     return super.memSize() + 8;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 291 */     return 
/* 292 */       memSize() + (
/* 293 */       (this.optionalLabel == null) ? 0 : getLabel().treeSize()) + (
/* 294 */       (this.optionalExpression == null) ? 0 : getExpression().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\BreakStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */