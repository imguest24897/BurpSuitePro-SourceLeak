package org.eclipse.jdt.core.util;

public interface IModulePackagesAttribute extends IClassFileAttribute {
  int getPackagesCount();
  
  int[] getPackageIndices();
  
  char[][] getPackageNames();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\cor\\util\IModulePackagesAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */