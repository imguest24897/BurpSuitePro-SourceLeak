package org.eclipse.jdt.core;

import org.eclipse.core.runtime.IProgressMonitor;

public interface IPackageFragment extends IParent, IJavaElement, IOpenable, ISourceManipulation {
  public static final String DEFAULT_PACKAGE_NAME = "";
  
  boolean containsJavaResources() throws JavaModelException;
  
  ICompilationUnit createCompilationUnit(String paramString1, String paramString2, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  IClassFile getClassFile(String paramString);
  
  IOrdinaryClassFile getOrdinaryClassFile(String paramString);
  
  IModularClassFile getModularClassFile();
  
  IClassFile[] getAllClassFiles() throws JavaModelException;
  
  @Deprecated
  IClassFile[] getClassFiles() throws JavaModelException;
  
  IOrdinaryClassFile[] getOrdinaryClassFiles() throws JavaModelException;
  
  ICompilationUnit getCompilationUnit(String paramString);
  
  ICompilationUnit[] getCompilationUnits() throws JavaModelException;
  
  ICompilationUnit[] getCompilationUnits(WorkingCopyOwner paramWorkingCopyOwner) throws JavaModelException;
  
  String getElementName();
  
  int getKind() throws JavaModelException;
  
  Object[] getNonJavaResources() throws JavaModelException;
  
  boolean hasSubpackages() throws JavaModelException;
  
  boolean isDefaultPackage();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IPackageFragment.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */