/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NameQualifiedType
/*     */   extends AnnotatableType
/*     */ {
/*  50 */   public static final ChildPropertyDescriptor QUALIFIER_PROPERTY = new ChildPropertyDescriptor(NameQualifiedType.class, "qualifier", Name.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   public static final ChildListPropertyDescriptor ANNOTATIONS_PROPERTY = internalAnnotationsPropertyFactory(NameQualifiedType.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(NameQualifiedType.class, "name", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  72 */     List propertyList = new ArrayList(4);
/*  73 */     createPropertyList(NameQualifiedType.class, propertyList);
/*  74 */     addProperty(QUALIFIER_PROPERTY, propertyList);
/*  75 */     addProperty(ANNOTATIONS_PROPERTY, propertyList);
/*  76 */     addProperty(NAME_PROPERTY, propertyList);
/*  77 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  90 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   private Name qualifier = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   private SimpleName name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NameQualifiedType(AST ast) {
/* 115 */     super(ast);
/* 116 */     unsupportedIn2_3_4();
/*     */   }
/*     */ 
/*     */   
/*     */   ChildListPropertyDescriptor internalAnnotationsProperty() {
/* 121 */     return ANNOTATIONS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   List internalStructuralPropertiesForType(int apiLevel) {
/* 126 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 131 */     if (property == ANNOTATIONS_PROPERTY) {
/* 132 */       return annotations();
/*     */     }
/*     */     
/* 135 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 140 */     if (property == QUALIFIER_PROPERTY) {
/* 141 */       if (get) {
/* 142 */         return getQualifier();
/*     */       }
/* 144 */       setQualifier((Name)child);
/* 145 */       return null;
/*     */     } 
/*     */     
/* 148 */     if (property == NAME_PROPERTY) {
/* 149 */       if (get) {
/* 150 */         return getName();
/*     */       }
/* 152 */       setName((SimpleName)child);
/* 153 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 157 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 162 */     return 88;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 168 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 173 */     NameQualifiedType result = new NameQualifiedType(target);
/* 174 */     result.setSourceRange(getStartPosition(), getLength());
/* 175 */     result.setQualifier((Name)getQualifier().clone(target));
/* 176 */     result.annotations().addAll(ASTNode.copySubtrees(target, annotations()));
/* 177 */     result.setName((SimpleName)getName().clone(target));
/* 178 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 183 */     boolean visitChildren = visitor.visit(this);
/* 184 */     if (visitChildren) {
/*     */       
/* 186 */       acceptChild(visitor, getQualifier());
/* 187 */       acceptChildren(visitor, this.annotations);
/* 188 */       acceptChild(visitor, getName());
/*     */     } 
/* 190 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getQualifier() {
/* 199 */     if (this.qualifier == null)
/*     */     {
/* 201 */       synchronized (this) {
/* 202 */         if (this.qualifier == null) {
/* 203 */           preLazyInit();
/* 204 */           this.qualifier = new SimpleName(this.ast);
/* 205 */           postLazyInit(this.qualifier, QUALIFIER_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 209 */     return this.qualifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQualifier(Name name) {
/* 223 */     if (name == null) {
/* 224 */       throw new IllegalArgumentException();
/*     */     }
/* 226 */     ASTNode oldChild = this.qualifier;
/* 227 */     preReplaceChild(oldChild, name, QUALIFIER_PROPERTY);
/* 228 */     this.qualifier = name;
/* 229 */     postReplaceChild(oldChild, name, QUALIFIER_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 238 */     if (this.name == null)
/*     */     {
/* 240 */       synchronized (this) {
/* 241 */         if (this.name == null) {
/* 242 */           preLazyInit();
/* 243 */           this.name = new SimpleName(this.ast);
/* 244 */           postLazyInit(this.name, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 248 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName name) {
/* 262 */     if (name == null) {
/* 263 */       throw new IllegalArgumentException();
/*     */     }
/* 265 */     ASTNode oldChild = this.name;
/* 266 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 267 */     this.name = name;
/* 268 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 274 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 279 */     return 
/* 280 */       memSize() + (
/* 281 */       (this.qualifier == null) ? 0 : getQualifier().treeSize()) + (
/* 282 */       (this.annotations == null) ? 0 : this.annotations.listSize()) + (
/* 283 */       (this.name == null) ? 0 : getName().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\NameQualifiedType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */