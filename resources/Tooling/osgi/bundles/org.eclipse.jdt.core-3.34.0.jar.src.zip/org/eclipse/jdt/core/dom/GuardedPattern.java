/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.core.dom.util.DOMASTUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GuardedPattern
/*     */   extends Pattern
/*     */ {
/*     */   GuardedPattern(AST ast) {
/*  38 */     super(ast);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  58 */     this.restrictedIdentifierStartPosition = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  78 */     this.pattern = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     this.conditonalExpression = null;
/*     */     supportedOnlyIn20();
/*     */     unsupportedWithoutPreviewError();
/*     */   }
/*     */   
/*     */   public static final ChildPropertyDescriptor PATTERN_PROPERTY = internalPatternPropertyFactory(GuardedPattern.class); public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(GuardedPattern.class, "expression", Expression.class, true, true); private int restrictedIdentifierStartPosition;
/*  90 */   List internalStructuralPropertiesForType(int apiLevel) { return propertyDescriptors(apiLevel); }
/*     */   private static final List PROPERTY_DESCRIPTORS; private Pattern pattern; private Expression conditonalExpression; static { List propertyList = new ArrayList(3);
/*     */     createPropertyList(GuardedPattern.class, propertyList);
/*     */     addProperty(PATTERN_PROPERTY, propertyList);
/*     */     addProperty(EXPRESSION_PROPERTY, propertyList);
/*  95 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList); } final List internalStructuralPropertiesForType(int apiLevel, boolean previewEnabled) { return propertyDescriptors(apiLevel, previewEnabled); }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/*  99 */     if (property == EXPRESSION_PROPERTY) {
/* 100 */       if (get) {
/* 101 */         return getExpression();
/*     */       }
/* 103 */       setExpression((Expression)child);
/* 104 */       return null;
/*     */     } 
/* 106 */     if (property == PATTERN_PROPERTY) {
/* 107 */       if (get) {
/* 108 */         return getPattern();
/*     */       }
/* 110 */       setPattern((Pattern)child);
/* 111 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 115 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   int getNodeType0() {
/* 120 */     return 107;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 125 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 130 */     GuardedPattern result = new GuardedPattern(target);
/* 131 */     result.setSourceRange(getStartPosition(), getLength());
/* 132 */     result.setPattern((Pattern)getPattern().clone(target));
/* 133 */     result.setExpression((Expression)getExpression().clone(target));
/* 134 */     result.setRestrictedIdentifierStartPosition(this.restrictedIdentifierStartPosition);
/* 135 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 140 */     boolean visitChildren = visitor.visit(this);
/* 141 */     if (visitChildren) {
/*     */       
/* 143 */       acceptChild(visitor, getPattern());
/* 144 */       acceptChild(visitor, getExpression());
/*     */     } 
/* 146 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 152 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 157 */     return 
/* 158 */       memSize() + (
/* 159 */       (this.pattern == null) ? 0 : getPattern().treeSize()) + (
/* 160 */       (this.conditonalExpression == null) ? 0 : getExpression().treeSize());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 174 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel, boolean previewEnabled) {
/* 189 */     if (DOMASTUtil.isPatternSupported(apiLevel, previewEnabled)) {
/* 190 */       return PROPERTY_DESCRIPTORS;
/*     */     }
/* 192 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 202 */     supportedOnlyIn20();
/* 203 */     unsupportedWithoutPreviewError();
/* 204 */     return this.conditonalExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pattern getPattern() {
/* 217 */     supportedOnlyIn20();
/* 218 */     unsupportedWithoutPreviewError();
/* 219 */     return this.pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 236 */     supportedOnlyIn20();
/* 237 */     unsupportedWithoutPreviewError();
/* 238 */     ASTNode oldChild = this.conditonalExpression;
/* 239 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 240 */     this.conditonalExpression = expression;
/* 241 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPattern(Pattern pattern) {
/* 252 */     supportedOnlyIn20();
/* 253 */     unsupportedWithoutPreviewError();
/* 254 */     ASTNode oldChild = this.pattern;
/* 255 */     preReplaceChild(oldChild, pattern, PATTERN_PROPERTY);
/* 256 */     this.pattern = pattern;
/* 257 */     postReplaceChild(oldChild, pattern, PATTERN_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setRestrictedIdentifierStartPosition(int restrictedIdentifierStartPosition) {
/* 267 */     if (restrictedIdentifierStartPosition < 0) {
/* 268 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/* 272 */     checkModifiable();
/* 273 */     this.restrictedIdentifierStartPosition = restrictedIdentifierStartPosition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRestrictedIdentifierStartPosition() {
/* 283 */     return this.restrictedIdentifierStartPosition;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\GuardedPattern.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */