/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*     */ import org.eclipse.jdt.internal.compiler.parser.ScannerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextBlock
/*     */   extends Expression
/*     */ {
/*  41 */   public static final SimplePropertyDescriptor ESCAPED_VALUE_PROPERTY = new SimplePropertyDescriptor(TextBlock.class, "escapedValue", String.class, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  51 */     List propertyList = new ArrayList(2);
/*  52 */     createPropertyList(TextBlock.class, propertyList);
/*  53 */     addProperty(ESCAPED_VALUE_PROPERTY, propertyList);
/*  54 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  69 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   private String escapedValue = "\"\"";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private String literalValue = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TextBlock(AST ast) {
/*  95 */     super(ast);
/*  96 */     unsupportedBelow15();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 101 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final Object internalGetSetObjectProperty(SimplePropertyDescriptor property, boolean get, Object value) {
/* 106 */     if (property == ESCAPED_VALUE_PROPERTY) {
/* 107 */       if (get) {
/* 108 */         return getEscapedValue();
/*     */       }
/* 110 */       setEscapedValue((String)value);
/* 111 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 115 */     return super.internalGetSetObjectProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 120 */     return 102;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 125 */     TextBlock result = new TextBlock(target);
/* 126 */     result.setSourceRange(getStartPosition(), getLength());
/* 127 */     result.setEscapedValue(getEscapedValue());
/* 128 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 134 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 139 */     visitor.visit(this);
/* 140 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEscapedValue() {
/* 154 */     return this.escapedValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEscapedValue(String token) {
/* 175 */     if (token == null) {
/* 176 */       throw new IllegalArgumentException("Token cannot be null");
/*     */     }
/* 178 */     Scanner scanner = this.ast.scanner;
/* 179 */     char[] source = token.toCharArray();
/* 180 */     scanner.setSource(source);
/* 181 */     scanner.resetTo(0, source.length);
/*     */     try {
/* 183 */       int tokenType = scanner.getNextToken();
/* 184 */       switch (tokenType) {
/*     */         case 61:
/*     */           break;
/*     */         default:
/* 188 */           throw new IllegalArgumentException("Invalid Text Block : >" + token + "<");
/*     */       } 
/* 190 */     } catch (InvalidInputException invalidInputException) {
/* 191 */       throw new IllegalArgumentException("Invalid Text Block : >" + token + "<");
/*     */     } 
/* 193 */     preValueChange(ESCAPED_VALUE_PROPERTY);
/* 194 */     this.escapedValue = token;
/* 195 */     postValueChange(ESCAPED_VALUE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void internalSetEscapedValue(String token, String literal) {
/* 203 */     preValueChange(ESCAPED_VALUE_PROPERTY);
/* 204 */     this.escapedValue = token;
/* 205 */     this.literalValue = literal;
/* 206 */     postValueChange(ESCAPED_VALUE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLiteralValue() {
/* 227 */     if (!this.literalValue.isEmpty()) {
/* 228 */       return this.literalValue;
/*     */     }
/* 230 */     char[] escaped = getEscapedValue().toCharArray();
/* 231 */     int len = escaped.length;
/* 232 */     if (len < 7) {
/* 233 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 236 */     int start = -1;
/* 237 */     for (int i = 3; i < len; ) {
/* 238 */       char c = escaped[i];
/* 239 */       if (ScannerHelper.isWhitespace(c)) {
/* 240 */         switch (c) {
/*     */           case '\n':
/*     */           case '\r':
/* 243 */             start = i + 1;
/*     */             break;
/*     */         } 
/*     */ 
/*     */         
/*     */         i++;
/*     */       } 
/*     */       break;
/*     */     } 
/* 252 */     if (start == -1) {
/* 253 */       throw new IllegalArgumentException();
/*     */     }
/* 255 */     return new String(
/* 256 */         CharOperation.subarray(escaped, start, len - 3));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 263 */     int size = 44 + stringSize(this.escapedValue);
/* 264 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 269 */     return memSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\TextBlock.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */