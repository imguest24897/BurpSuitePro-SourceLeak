/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class StructuralPropertyDescriptor
/*     */ {
/*     */   private final String propertyId;
/*     */   private final Class nodeClass;
/*     */   
/*     */   StructuralPropertyDescriptor(Class nodeClass, String propertyId) {
/*  59 */     if (nodeClass == null || propertyId == null) {
/*  60 */       throw new IllegalArgumentException();
/*     */     }
/*  62 */     this.propertyId = propertyId;
/*  63 */     this.nodeClass = nodeClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getId() {
/*  72 */     return this.propertyId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Class getNodeClass() {
/*  85 */     return this.nodeClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSimpleProperty() {
/*  96 */     return this instanceof SimplePropertyDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isChildProperty() {
/* 107 */     return this instanceof ChildPropertyDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isChildListProperty() {
/* 118 */     return this instanceof ChildListPropertyDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 127 */     StringBuilder b = new StringBuilder();
/* 128 */     if (isChildListProperty()) {
/* 129 */       b.append("ChildList");
/*     */     }
/* 131 */     if (isChildProperty()) {
/* 132 */       b.append("Child");
/*     */     }
/* 134 */     if (isSimpleProperty()) {
/* 135 */       b.append("Simple");
/*     */     }
/* 137 */     b.append("Property[");
/* 138 */     if (this.nodeClass != null) {
/* 139 */       b.append(this.nodeClass.getName());
/*     */     }
/* 141 */     b.append(",");
/* 142 */     if (this.propertyId != null) {
/* 143 */       b.append(this.propertyId);
/*     */     }
/* 145 */     b.append("]");
/* 146 */     return b.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\StructuralPropertyDescriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */