/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RecoveredPackageBinding
/*     */   implements IPackageBinding
/*     */ {
/*  27 */   private static final String[] NO_NAME_COMPONENTS = CharOperation.NO_STRINGS;
/*  28 */   private static final String UNNAMED = Util.EMPTY_STRING;
/*     */   
/*     */   private static final char PACKAGE_NAME_SEPARATOR = '.';
/*     */   private PackageBinding binding;
/*     */   private BindingResolver resolver;
/*  33 */   private String name = null;
/*  34 */   private String[] components = null;
/*     */   
/*     */   RecoveredPackageBinding(PackageBinding binding, BindingResolver resolver) {
/*  37 */     this.binding = binding;
/*  38 */     this.resolver = resolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public IAnnotationBinding[] getAnnotations() {
/*  43 */     return (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getKind() {
/*  48 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/*  53 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDeprecated() {
/*  58 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRecovered() {
/*  63 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSynthetic() {
/*  68 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public IJavaElement getJavaElement() {
/*  73 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getKey() {
/*  78 */     StringBuilder buffer = new StringBuilder();
/*  79 */     buffer.append("Recovered#");
/*  80 */     buffer.append(this.binding.computeUniqueKey());
/*  81 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEqualTo(IBinding other) {
/*  86 */     if (!other.isRecovered() || other.getKind() != 1) return false; 
/*  87 */     return getKey().equals(other.getKey());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  92 */     if (this.name == null) {
/*  93 */       computeNameAndComponents();
/*     */     }
/*  95 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUnnamed() {
/* 100 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getNameComponents() {
/* 105 */     if (this.components == null) {
/* 106 */       computeNameAndComponents();
/*     */     }
/* 108 */     return this.components;
/*     */   }
/*     */   
/*     */   public IModuleBinding getModule() {
/* 112 */     ModuleBinding moduleBinding = this.binding.enclosingModule;
/* 113 */     return (moduleBinding != null) ? this.resolver.getModuleBinding(moduleBinding) : null;
/*     */   }
/*     */   private void computeNameAndComponents() {
/* 116 */     char[][] compoundName = this.binding.compoundName;
/* 117 */     if (compoundName == CharOperation.NO_CHAR_CHAR || compoundName == null) {
/* 118 */       this.name = UNNAMED;
/* 119 */       this.components = NO_NAME_COMPONENTS;
/*     */     } else {
/* 121 */       int length = compoundName.length;
/* 122 */       this.components = new String[length];
/* 123 */       StringBuilder buffer = new StringBuilder();
/* 124 */       for (int i = 0; i < length - 1; i++) {
/* 125 */         this.components[i] = new String(compoundName[i]);
/* 126 */         buffer.append(compoundName[i]).append('.');
/*     */       } 
/* 128 */       this.components[length - 1] = new String(compoundName[length - 1]);
/* 129 */       buffer.append(compoundName[length - 1]);
/* 130 */       this.name = buffer.toString();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\RecoveredPackageBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */