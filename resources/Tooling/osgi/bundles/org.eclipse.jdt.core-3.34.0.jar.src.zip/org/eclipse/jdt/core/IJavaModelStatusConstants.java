package org.eclipse.jdt.core;

public interface IJavaModelStatusConstants {
  public static final int INVALID_CP_CONTAINER_ENTRY = 962;
  
  public static final int CP_CONTAINER_PATH_UNBOUND = 963;
  
  public static final int INVALID_CLASSPATH = 964;
  
  public static final int CP_VARIABLE_PATH_UNBOUND = 965;
  
  public static final int CORE_EXCEPTION = 966;
  
  public static final int INVALID_ELEMENT_TYPES = 967;
  
  public static final int NO_ELEMENTS_TO_PROCESS = 968;
  
  public static final int ELEMENT_DOES_NOT_EXIST = 969;
  
  public static final int NULL_PATH = 970;
  
  public static final int PATH_OUTSIDE_PROJECT = 971;
  
  public static final int RELATIVE_PATH = 972;
  
  public static final int DEVICE_PATH = 973;
  
  public static final int NULL_STRING = 974;
  
  public static final int READ_ONLY = 976;
  
  public static final int NAME_COLLISION = 977;
  
  public static final int INVALID_DESTINATION = 978;
  
  public static final int INVALID_PATH = 979;
  
  public static final int INDEX_OUT_OF_BOUNDS = 980;
  
  public static final int UPDATE_CONFLICT = 981;
  
  public static final int NULL_NAME = 982;
  
  public static final int INVALID_NAME = 983;
  
  public static final int INVALID_CONTENTS = 984;
  
  public static final int IO_EXCEPTION = 985;
  
  public static final int DOM_EXCEPTION = 986;
  
  public static final int TARGET_EXCEPTION = 987;
  
  public static final int BUILDER_INITIALIZATION_ERROR = 990;
  
  public static final int BUILDER_SERIALIZATION_ERROR = 991;
  
  public static final int EVALUATION_ERROR = 992;
  
  public static final int INVALID_SIBLING = 993;
  
  public static final int INVALID_RESOURCE = 995;
  
  public static final int INVALID_RESOURCE_TYPE = 996;
  
  public static final int INVALID_PROJECT = 997;
  
  public static final int INVALID_PACKAGE = 998;
  
  public static final int NO_LOCAL_CONTENTS = 999;
  
  public static final int INVALID_CLASSPATH_FILE_FORMAT = 1000;
  
  public static final int CLASSPATH_CYCLE = 1001;
  
  public static final int DISABLED_CP_EXCLUSION_PATTERNS = 1002;
  
  public static final int DISABLED_CP_MULTIPLE_OUTPUT_LOCATIONS = 1003;
  
  public static final int INCOMPATIBLE_JDK_LEVEL = 1004;
  
  public static final int COMPILER_FAILURE = 1005;
  
  public static final int ELEMENT_NOT_ON_CLASSPATH = 1006;
  
  public static final int CANNOT_RETRIEVE_ATTACHED_JAVADOC = 1008;
  
  public static final int UNKNOWN_JAVADOC_FORMAT = 1009;
  
  public static final int DEPRECATED_VARIABLE = 1010;
  
  public static final int BAD_TEXT_EDIT_LOCATION = 1011;
  
  public static final int CANNOT_RETRIEVE_ATTACHED_JAVADOC_TIMEOUT = 1012;
  
  public static final int OUTPUT_LOCATION_OVERLAPPING_ANOTHER_SOURCE = 1013;
  
  public static final int CP_INVALID_EXTERNAL_ANNOTATION_PATH = 1014;
  
  public static final int TEST_SOURCE_REQUIRES_SEPARATE_OUTPUT_LOCATION = 1015;
  
  public static final int TEST_OUTPUT_FOLDER_MUST_BE_SEPARATE_FROM_MAIN_OUTPUT_FOLDERS = 1016;
  
  public static final int MAIN_ONLY_PROJECT_DEPENDS_ON_TEST_ONLY_PROJECT = 1017;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IJavaModelStatusConstants.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */