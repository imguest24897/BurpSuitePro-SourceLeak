/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeDeclarationStatement
/*     */   extends Statement
/*     */ {
/*  47 */   public static final ChildPropertyDescriptor TYPE_DECLARATION_PROPERTY = new ChildPropertyDescriptor(TypeDeclarationStatement.class, "typeDeclaration", TypeDeclaration.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final ChildPropertyDescriptor DECLARATION_PROPERTY = new ChildPropertyDescriptor(TypeDeclarationStatement.class, "declaration", AbstractTypeDeclaration.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  73 */     List propertyList = new ArrayList(2);
/*  74 */     createPropertyList(TypeDeclarationStatement.class, propertyList);
/*  75 */     addProperty(TYPE_DECLARATION_PROPERTY, propertyList);
/*  76 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(propertyList);
/*     */     
/*  78 */     propertyList = new ArrayList(2);
/*  79 */     createPropertyList(TypeDeclarationStatement.class, propertyList);
/*  80 */     addProperty(DECLARATION_PROPERTY, propertyList);
/*  81 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  96 */     if (apiLevel == 2) {
/*  97 */       return PROPERTY_DESCRIPTORS_2_0;
/*     */     }
/*  99 */     return PROPERTY_DESCRIPTORS_3_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private AbstractTypeDeclaration typeDecl = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ChildPropertyDescriptor typeDeclProperty() {
/* 120 */     if (getAST().apiLevel() == 2) {
/* 121 */       return TYPE_DECLARATION_PROPERTY;
/*     */     }
/* 123 */     return DECLARATION_PROPERTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TypeDeclarationStatement(AST ast) {
/* 139 */     super(ast);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 148 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 153 */     if (property == TYPE_DECLARATION_PROPERTY) {
/* 154 */       if (get) {
/* 155 */         return getTypeDeclaration();
/*     */       }
/* 157 */       setTypeDeclaration((TypeDeclaration)child);
/* 158 */       return null;
/*     */     } 
/*     */     
/* 161 */     if (property == DECLARATION_PROPERTY) {
/* 162 */       if (get) {
/* 163 */         return getDeclaration();
/*     */       }
/* 165 */       setDeclaration((AbstractTypeDeclaration)child);
/* 166 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 170 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 175 */     return 56;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 180 */     TypeDeclarationStatement result = 
/* 181 */       new TypeDeclarationStatement(target);
/* 182 */     result.setSourceRange(getStartPosition(), getLength());
/* 183 */     result.copyLeadingComment(this);
/* 184 */     result.setDeclaration(
/* 185 */         (AbstractTypeDeclaration)getDeclaration().clone(target));
/* 186 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 192 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 197 */     boolean visitChildren = visitor.visit(this);
/* 198 */     if (visitChildren) {
/* 199 */       acceptChild(visitor, getDeclaration());
/*     */     }
/* 201 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractTypeDeclaration getDeclaration() {
/* 212 */     if (this.typeDecl == null)
/*     */     {
/* 214 */       synchronized (this) {
/* 215 */         if (this.typeDecl == null) {
/* 216 */           preLazyInit();
/* 217 */           this.typeDecl = new TypeDeclaration(this.ast);
/* 218 */           postLazyInit(this.typeDecl, typeDeclProperty());
/*     */         } 
/*     */       } 
/*     */     }
/* 222 */     return this.typeDecl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeclaration(AbstractTypeDeclaration decl) {
/* 239 */     if (decl == null) {
/* 240 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/* 244 */     ASTNode oldChild = this.typeDecl;
/* 245 */     ChildPropertyDescriptor typeDeclProperty = typeDeclProperty();
/* 246 */     preReplaceChild(oldChild, decl, typeDeclProperty);
/* 247 */     this.typeDecl = decl;
/* 248 */     postReplaceChild(oldChild, decl, typeDeclProperty);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDeclaration getTypeDeclaration() {
/* 263 */     return internalGetTypeDeclaration();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final TypeDeclaration internalGetTypeDeclaration() {
/* 272 */     supportedOnlyIn2();
/* 273 */     return (TypeDeclaration)getDeclaration();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypeDeclaration(TypeDeclaration decl) {
/* 295 */     internalSetTypeDeclaration(decl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void internalSetTypeDeclaration(TypeDeclaration decl) {
/* 304 */     supportedOnlyIn2();
/*     */     
/* 306 */     setDeclaration(decl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeBinding resolveBinding() {
/* 322 */     AbstractTypeDeclaration d = getDeclaration();
/* 323 */     if (d instanceof TypeDeclaration)
/* 324 */       return ((TypeDeclaration)d).resolveBinding(); 
/* 325 */     if (d instanceof AnnotationTypeDeclaration) {
/* 326 */       return ((AnnotationTypeDeclaration)d).resolveBinding();
/*     */     }
/*     */     
/* 329 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 335 */     return super.memSize() + 4;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 340 */     return 
/* 341 */       memSize() + (
/* 342 */       (this.typeDecl == null) ? 0 : getDeclaration().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\TypeDeclarationStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */