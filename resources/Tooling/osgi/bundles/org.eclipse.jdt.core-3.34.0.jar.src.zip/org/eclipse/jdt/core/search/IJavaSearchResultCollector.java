package org.eclipse.jdt.core.search;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.IJavaElement;

public interface IJavaSearchResultCollector {
  public static final int EXACT_MATCH = 0;
  
  public static final int POTENTIAL_MATCH = 1;
  
  void aboutToStart();
  
  void accept(IResource paramIResource, int paramInt1, int paramInt2, IJavaElement paramIJavaElement, int paramInt3) throws CoreException;
  
  void done();
  
  IProgressMonitor getProgressMonitor();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\search\IJavaSearchResultCollector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */