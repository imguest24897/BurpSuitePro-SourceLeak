package org.eclipse.jdt.core.util;

public interface IBytecodeVisitor {
  void _aaload(int paramInt);
  
  void _aastore(int paramInt);
  
  void _aconst_null(int paramInt);
  
  void _aload(int paramInt1, int paramInt2);
  
  void _aload_0(int paramInt);
  
  void _aload_1(int paramInt);
  
  void _aload_2(int paramInt);
  
  void _aload_3(int paramInt);
  
  void _anewarray(int paramInt1, int paramInt2, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _areturn(int paramInt);
  
  void _arraylength(int paramInt);
  
  void _astore(int paramInt1, int paramInt2);
  
  void _astore_0(int paramInt);
  
  void _astore_1(int paramInt);
  
  void _astore_2(int paramInt);
  
  void _astore_3(int paramInt);
  
  void _athrow(int paramInt);
  
  void _baload(int paramInt);
  
  void _bastore(int paramInt);
  
  void _bipush(int paramInt, byte paramByte);
  
  void _caload(int paramInt);
  
  void _castore(int paramInt);
  
  void _checkcast(int paramInt1, int paramInt2, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _d2f(int paramInt);
  
  void _d2i(int paramInt);
  
  void _d2l(int paramInt);
  
  void _dadd(int paramInt);
  
  void _daload(int paramInt);
  
  void _dastore(int paramInt);
  
  void _dcmpg(int paramInt);
  
  void _dcmpl(int paramInt);
  
  void _dconst_0(int paramInt);
  
  void _dconst_1(int paramInt);
  
  void _ddiv(int paramInt);
  
  void _dload(int paramInt1, int paramInt2);
  
  void _dload_0(int paramInt);
  
  void _dload_1(int paramInt);
  
  void _dload_2(int paramInt);
  
  void _dload_3(int paramInt);
  
  void _dmul(int paramInt);
  
  void _dneg(int paramInt);
  
  void _drem(int paramInt);
  
  void _dreturn(int paramInt);
  
  void _dstore(int paramInt1, int paramInt2);
  
  void _dstore_0(int paramInt);
  
  void _dstore_1(int paramInt);
  
  void _dstore_2(int paramInt);
  
  void _dstore_3(int paramInt);
  
  void _dsub(int paramInt);
  
  void _dup(int paramInt);
  
  void _dup_x1(int paramInt);
  
  void _dup_x2(int paramInt);
  
  void _dup2(int paramInt);
  
  void _dup2_x1(int paramInt);
  
  void _dup2_x2(int paramInt);
  
  void _f2d(int paramInt);
  
  void _f2i(int paramInt);
  
  void _f2l(int paramInt);
  
  void _fadd(int paramInt);
  
  void _faload(int paramInt);
  
  void _fastore(int paramInt);
  
  void _fcmpg(int paramInt);
  
  void _fcmpl(int paramInt);
  
  void _fconst_0(int paramInt);
  
  void _fconst_1(int paramInt);
  
  void _fconst_2(int paramInt);
  
  void _fdiv(int paramInt);
  
  void _fload(int paramInt1, int paramInt2);
  
  void _fload_0(int paramInt);
  
  void _fload_1(int paramInt);
  
  void _fload_2(int paramInt);
  
  void _fload_3(int paramInt);
  
  void _fmul(int paramInt);
  
  void _fneg(int paramInt);
  
  void _frem(int paramInt);
  
  void _freturn(int paramInt);
  
  void _fstore(int paramInt1, int paramInt2);
  
  void _fstore_0(int paramInt);
  
  void _fstore_1(int paramInt);
  
  void _fstore_2(int paramInt);
  
  void _fstore_3(int paramInt);
  
  void _fsub(int paramInt);
  
  void _getfield(int paramInt1, int paramInt2, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _getstatic(int paramInt1, int paramInt2, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _goto(int paramInt1, int paramInt2);
  
  void _goto_w(int paramInt1, int paramInt2);
  
  void _i2b(int paramInt);
  
  void _i2c(int paramInt);
  
  void _i2d(int paramInt);
  
  void _i2f(int paramInt);
  
  void _i2l(int paramInt);
  
  void _i2s(int paramInt);
  
  void _iadd(int paramInt);
  
  void _iaload(int paramInt);
  
  void _iand(int paramInt);
  
  void _iastore(int paramInt);
  
  void _iconst_m1(int paramInt);
  
  void _iconst_0(int paramInt);
  
  void _iconst_1(int paramInt);
  
  void _iconst_2(int paramInt);
  
  void _iconst_3(int paramInt);
  
  void _iconst_4(int paramInt);
  
  void _iconst_5(int paramInt);
  
  void _idiv(int paramInt);
  
  void _if_acmpeq(int paramInt1, int paramInt2);
  
  void _if_acmpne(int paramInt1, int paramInt2);
  
  void _if_icmpeq(int paramInt1, int paramInt2);
  
  void _if_icmpne(int paramInt1, int paramInt2);
  
  void _if_icmplt(int paramInt1, int paramInt2);
  
  void _if_icmpge(int paramInt1, int paramInt2);
  
  void _if_icmpgt(int paramInt1, int paramInt2);
  
  void _if_icmple(int paramInt1, int paramInt2);
  
  void _ifeq(int paramInt1, int paramInt2);
  
  void _ifne(int paramInt1, int paramInt2);
  
  void _iflt(int paramInt1, int paramInt2);
  
  void _ifge(int paramInt1, int paramInt2);
  
  void _ifgt(int paramInt1, int paramInt2);
  
  void _ifle(int paramInt1, int paramInt2);
  
  void _ifnonnull(int paramInt1, int paramInt2);
  
  void _ifnull(int paramInt1, int paramInt2);
  
  void _iinc(int paramInt1, int paramInt2, int paramInt3);
  
  void _iload(int paramInt1, int paramInt2);
  
  void _iload_0(int paramInt);
  
  void _iload_1(int paramInt);
  
  void _iload_2(int paramInt);
  
  void _iload_3(int paramInt);
  
  void _imul(int paramInt);
  
  void _ineg(int paramInt);
  
  void _instanceof(int paramInt1, int paramInt2, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _invokedynamic(int paramInt1, int paramInt2, IConstantPoolEntry paramIConstantPoolEntry1, IConstantPoolEntry paramIConstantPoolEntry2);
  
  void _invokedynamic(int paramInt1, int paramInt2, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _invokeinterface(int paramInt1, int paramInt2, byte paramByte, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _invokespecial(int paramInt1, int paramInt2, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _invokestatic(int paramInt1, int paramInt2, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _invokevirtual(int paramInt1, int paramInt2, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _ior(int paramInt);
  
  void _irem(int paramInt);
  
  void _ireturn(int paramInt);
  
  void _ishl(int paramInt);
  
  void _ishr(int paramInt);
  
  void _istore(int paramInt1, int paramInt2);
  
  void _istore_0(int paramInt);
  
  void _istore_1(int paramInt);
  
  void _istore_2(int paramInt);
  
  void _istore_3(int paramInt);
  
  void _isub(int paramInt);
  
  void _iushr(int paramInt);
  
  void _ixor(int paramInt);
  
  void _jsr(int paramInt1, int paramInt2);
  
  void _jsr_w(int paramInt1, int paramInt2);
  
  void _l2d(int paramInt);
  
  void _l2f(int paramInt);
  
  void _l2i(int paramInt);
  
  void _ladd(int paramInt);
  
  void _laload(int paramInt);
  
  void _land(int paramInt);
  
  void _lastore(int paramInt);
  
  void _lcmp(int paramInt);
  
  void _lconst_0(int paramInt);
  
  void _lconst_1(int paramInt);
  
  void _ldc(int paramInt1, int paramInt2, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _ldc_w(int paramInt1, int paramInt2, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _ldc2_w(int paramInt1, int paramInt2, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _ldiv(int paramInt);
  
  void _lload(int paramInt1, int paramInt2);
  
  void _lload_0(int paramInt);
  
  void _lload_1(int paramInt);
  
  void _lload_2(int paramInt);
  
  void _lload_3(int paramInt);
  
  void _lmul(int paramInt);
  
  void _lneg(int paramInt);
  
  void _lookupswitch(int paramInt1, int paramInt2, int paramInt3, int[][] paramArrayOfint);
  
  void _lor(int paramInt);
  
  void _lrem(int paramInt);
  
  void _lreturn(int paramInt);
  
  void _lshl(int paramInt);
  
  void _lshr(int paramInt);
  
  void _lstore(int paramInt1, int paramInt2);
  
  void _lstore_0(int paramInt);
  
  void _lstore_1(int paramInt);
  
  void _lstore_2(int paramInt);
  
  void _lstore_3(int paramInt);
  
  void _lsub(int paramInt);
  
  void _lushr(int paramInt);
  
  void _lxor(int paramInt);
  
  void _monitorenter(int paramInt);
  
  void _monitorexit(int paramInt);
  
  void _multianewarray(int paramInt1, int paramInt2, int paramInt3, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _new(int paramInt1, int paramInt2, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _newarray(int paramInt1, int paramInt2);
  
  void _nop(int paramInt);
  
  void _pop(int paramInt);
  
  void _pop2(int paramInt);
  
  void _putfield(int paramInt1, int paramInt2, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _putstatic(int paramInt1, int paramInt2, IConstantPoolEntry paramIConstantPoolEntry);
  
  void _ret(int paramInt1, int paramInt2);
  
  void _return(int paramInt);
  
  void _saload(int paramInt);
  
  void _sastore(int paramInt);
  
  void _sipush(int paramInt, short paramShort);
  
  void _swap(int paramInt);
  
  void _tableswitch(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint);
  
  void _wide(int paramInt1, int paramInt2, int paramInt3);
  
  void _wide(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void _breakpoint(int paramInt);
  
  void _impdep1(int paramInt);
  
  void _impdep2(int paramInt);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\cor\\util\IBytecodeVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */