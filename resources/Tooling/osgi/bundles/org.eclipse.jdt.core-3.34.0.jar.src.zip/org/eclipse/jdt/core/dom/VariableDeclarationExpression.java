/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VariableDeclarationExpression
/*     */   extends Expression
/*     */ {
/*  49 */   public static final SimplePropertyDescriptor MODIFIERS_PROPERTY = new SimplePropertyDescriptor(VariableDeclarationExpression.class, "modifiers", int.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   public static final ChildListPropertyDescriptor MODIFIERS2_PROPERTY = new ChildListPropertyDescriptor(VariableDeclarationExpression.class, "modifiers", IExtendedModifier.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   public static final ChildPropertyDescriptor TYPE_PROPERTY = new ChildPropertyDescriptor(VariableDeclarationExpression.class, "type", Type.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public static final ChildListPropertyDescriptor FRAGMENTS_PROPERTY = new ChildListPropertyDescriptor(VariableDeclarationExpression.class, "fragments", VariableDeclarationFragment.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  89 */     List propertyList = new ArrayList(4);
/*  90 */     createPropertyList(VariableDeclarationExpression.class, propertyList);
/*  91 */     addProperty(MODIFIERS_PROPERTY, propertyList);
/*  92 */     addProperty(TYPE_PROPERTY, propertyList);
/*  93 */     addProperty(FRAGMENTS_PROPERTY, propertyList);
/*  94 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(propertyList);
/*     */     
/*  96 */     propertyList = new ArrayList(4);
/*  97 */     createPropertyList(VariableDeclarationExpression.class, propertyList);
/*  98 */     addProperty(MODIFIERS2_PROPERTY, propertyList);
/*  99 */     addProperty(TYPE_PROPERTY, propertyList);
/* 100 */     addProperty(FRAGMENTS_PROPERTY, propertyList);
/* 101 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 116 */     if (apiLevel == 2) {
/* 117 */       return PROPERTY_DESCRIPTORS_2_0;
/*     */     }
/* 119 */     return PROPERTY_DESCRIPTORS_3_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   private ASTNode.NodeList modifiers = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   private int modifierFlags = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   private Type baseType = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   private ASTNode.NodeList variableDeclarationFragments = new ASTNode.NodeList(this, FRAGMENTS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   VariableDeclarationExpression(AST ast) {
/* 162 */     super(ast);
/* 163 */     if (ast.apiLevel >= 3) {
/* 164 */       this.modifiers = new ASTNode.NodeList(this, MODIFIERS2_PROPERTY);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 170 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final int internalGetSetIntProperty(SimplePropertyDescriptor property, boolean get, int value) {
/* 175 */     if (property == MODIFIERS_PROPERTY) {
/* 176 */       if (get) {
/* 177 */         return getModifiers();
/*     */       }
/* 179 */       setModifiers(value);
/* 180 */       return 0;
/*     */     } 
/*     */ 
/*     */     
/* 184 */     return super.internalGetSetIntProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 189 */     if (property == TYPE_PROPERTY) {
/* 190 */       if (get) {
/* 191 */         return getType();
/*     */       }
/* 193 */       setType((Type)child);
/* 194 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 198 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 203 */     if (property == MODIFIERS2_PROPERTY) {
/* 204 */       return modifiers();
/*     */     }
/* 206 */     if (property == FRAGMENTS_PROPERTY) {
/* 207 */       return fragments();
/*     */     }
/*     */     
/* 210 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 215 */     return 58;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 220 */     VariableDeclarationExpression result = 
/* 221 */       new VariableDeclarationExpression(target);
/* 222 */     result.setSourceRange(getStartPosition(), getLength());
/* 223 */     if (this.ast.apiLevel == 2) {
/* 224 */       result.setModifiers(getModifiers());
/*     */     }
/* 226 */     if (this.ast.apiLevel >= 3) {
/* 227 */       result.modifiers().addAll(ASTNode.copySubtrees(target, modifiers()));
/*     */     }
/* 229 */     result.setType((Type)getType().clone(target));
/* 230 */     result.fragments().addAll(
/* 231 */         ASTNode.copySubtrees(target, fragments()));
/* 232 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 239 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 244 */     boolean visitChildren = visitor.visit(this);
/* 245 */     if (visitChildren) {
/*     */       
/* 247 */       if (this.ast.apiLevel >= 3) {
/* 248 */         acceptChildren(visitor, this.modifiers);
/*     */       }
/* 250 */       acceptChild(visitor, getType());
/* 251 */       acceptChildren(visitor, this.variableDeclarationFragments);
/*     */     } 
/* 253 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List modifiers() {
/* 272 */     if (this.modifiers == null) {
/* 273 */       unsupportedIn2();
/*     */     }
/* 275 */     return this.modifiers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 290 */     if (this.modifiers == null)
/*     */     {
/* 292 */       return this.modifierFlags;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 297 */     int computedModifierFlags = 0;
/* 298 */     for (Iterator it = modifiers().iterator(); it.hasNext(); ) {
/* 299 */       Object x = it.next();
/* 300 */       if (x instanceof Modifier) {
/* 301 */         computedModifierFlags |= ((Modifier)x).getKeyword().toFlagValue();
/*     */       }
/*     */     } 
/* 304 */     return computedModifierFlags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModifiers(int modifiers) {
/* 323 */     internalSetModifiers(modifiers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void internalSetModifiers(int pmodifiers) {
/* 332 */     supportedOnlyIn2();
/* 333 */     preValueChange(MODIFIERS_PROPERTY);
/* 334 */     this.modifierFlags = pmodifiers;
/* 335 */     postValueChange(MODIFIERS_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 349 */     if (this.baseType == null)
/*     */     {
/* 351 */       synchronized (this) {
/* 352 */         if (this.baseType == null) {
/* 353 */           preLazyInit();
/* 354 */           this.baseType = this.ast.newPrimitiveType(PrimitiveType.INT);
/* 355 */           postLazyInit(this.baseType, TYPE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 359 */     return this.baseType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(Type type) {
/* 374 */     if (type == null) {
/* 375 */       throw new IllegalArgumentException();
/*     */     }
/* 377 */     ASTNode oldChild = this.baseType;
/* 378 */     preReplaceChild(oldChild, type, TYPE_PROPERTY);
/* 379 */     this.baseType = type;
/* 380 */     postReplaceChild(oldChild, type, TYPE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List fragments() {
/* 394 */     return this.variableDeclarationFragments;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 400 */     return 56;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 405 */     return 
/* 406 */       memSize() + (
/* 407 */       (this.modifiers == null) ? 0 : this.modifiers.listSize()) + (
/* 408 */       (this.baseType == null) ? 0 : getType().treeSize()) + 
/* 409 */       this.variableDeclarationFragments.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\VariableDeclarationExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */