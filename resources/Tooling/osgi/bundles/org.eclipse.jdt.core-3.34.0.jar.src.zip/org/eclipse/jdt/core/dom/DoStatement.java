/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DoStatement
/*     */   extends Statement
/*     */ {
/*  39 */   public static final ChildPropertyDescriptor BODY_PROPERTY = new ChildPropertyDescriptor(DoStatement.class, "body", Statement.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(DoStatement.class, "expression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  56 */     List properyList = new ArrayList(3);
/*  57 */     createPropertyList(DoStatement.class, properyList);
/*  58 */     addProperty(BODY_PROPERTY, properyList);
/*  59 */     addProperty(EXPRESSION_PROPERTY, properyList);
/*  60 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  75 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private Statement body = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private Expression expression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DoStatement(AST ast) {
/* 100 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 105 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 110 */     if (property == BODY_PROPERTY) {
/* 111 */       if (get) {
/* 112 */         return getBody();
/*     */       }
/* 114 */       setBody((Statement)child);
/* 115 */       return null;
/*     */     } 
/*     */     
/* 118 */     if (property == EXPRESSION_PROPERTY) {
/* 119 */       if (get) {
/* 120 */         return getExpression();
/*     */       }
/* 122 */       setExpression((Expression)child);
/* 123 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 127 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 132 */     return 19;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 137 */     DoStatement result = new DoStatement(target);
/* 138 */     result.setSourceRange(getStartPosition(), getLength());
/* 139 */     result.copyLeadingComment(this);
/* 140 */     result.setBody((Statement)getBody().clone(target));
/* 141 */     result.setExpression((Expression)getExpression().clone(target));
/* 142 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 148 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 153 */     boolean visitChildren = visitor.visit(this);
/* 154 */     if (visitChildren) {
/*     */       
/* 156 */       acceptChild(visitor, getBody());
/* 157 */       acceptChild(visitor, getExpression());
/*     */     } 
/* 159 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement getBody() {
/* 168 */     if (this.body == null)
/*     */     {
/* 170 */       synchronized (this) {
/* 171 */         if (this.body == null) {
/* 172 */           preLazyInit();
/* 173 */           this.body = new Block(this.ast);
/* 174 */           postLazyInit(this.body, BODY_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 178 */     return this.body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBody(Statement statement) {
/* 201 */     if (statement == null) {
/* 202 */       throw new IllegalArgumentException();
/*     */     }
/* 204 */     ASTNode oldChild = this.body;
/* 205 */     preReplaceChild(oldChild, statement, BODY_PROPERTY);
/* 206 */     this.body = statement;
/* 207 */     postReplaceChild(oldChild, statement, BODY_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 216 */     if (this.expression == null)
/*     */     {
/* 218 */       synchronized (this) {
/* 219 */         if (this.expression == null) {
/* 220 */           preLazyInit();
/* 221 */           this.expression = new SimpleName(this.ast);
/* 222 */           postLazyInit(this.expression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 226 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 241 */     if (expression == null) {
/* 242 */       throw new IllegalArgumentException();
/*     */     }
/* 244 */     ASTNode oldChild = this.expression;
/* 245 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 246 */     this.expression = expression;
/* 247 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 252 */     return super.memSize() + 8;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 257 */     return 
/* 258 */       memSize() + (
/* 259 */       (this.expression == null) ? 0 : getExpression().treeSize()) + (
/* 260 */       (this.body == null) ? 0 : getBody().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\DoStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */