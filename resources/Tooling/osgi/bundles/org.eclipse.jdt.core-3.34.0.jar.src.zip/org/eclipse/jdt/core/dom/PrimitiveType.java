/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrimitiveType
/*     */   extends AnnotatableType
/*     */ {
/*     */   public static class Code
/*     */   {
/*     */     private String name;
/*     */     
/*     */     Code(String name) {
/*  79 */       this.name = name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/*  89 */       return this.name;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*  94 */   public static final Code INT = new Code("int");
/*     */   
/*  96 */   public static final Code CHAR = new Code("char");
/*     */   
/*  98 */   public static final Code BOOLEAN = new Code("boolean");
/*     */   
/* 100 */   public static final Code SHORT = new Code("short");
/*     */   
/* 102 */   public static final Code LONG = new Code("long");
/*     */   
/* 104 */   public static final Code FLOAT = new Code("float");
/*     */   
/* 106 */   public static final Code DOUBLE = new Code("double");
/*     */   
/* 108 */   public static final Code BYTE = new Code("byte");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public static final Code VOID = new Code("void");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   private Code typeCode = INT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   private static final Map CODES = new HashMap<>(20); static {
/* 129 */     Code[] ops = {
/* 130 */         INT, 
/* 131 */         BYTE, 
/* 132 */         CHAR, 
/* 133 */         BOOLEAN, 
/* 134 */         SHORT, 
/* 135 */         LONG, 
/* 136 */         FLOAT, 
/* 137 */         DOUBLE, 
/* 138 */         VOID
/*     */       };
/* 140 */     for (int i = 0; i < ops.length; i++) {
/* 141 */       CODES.put(ops[i].toString(), ops[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Code toCode(String token) {
/* 159 */     return (Code)CODES.get(token);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 167 */   public static final ChildListPropertyDescriptor ANNOTATIONS_PROPERTY = internalAnnotationsPropertyFactory(PrimitiveType.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   public static final SimplePropertyDescriptor PRIMITIVE_TYPE_CODE_PROPERTY = new SimplePropertyDescriptor(PrimitiveType.class, "primitiveTypeCode", Code.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_8_0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 190 */     List propertyList = new ArrayList(2);
/* 191 */     createPropertyList(PrimitiveType.class, propertyList);
/* 192 */     addProperty(PRIMITIVE_TYPE_CODE_PROPERTY, propertyList);
/* 193 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */     
/* 195 */     propertyList = new ArrayList(3);
/* 196 */     createPropertyList(PrimitiveType.class, propertyList);
/* 197 */     addProperty(ANNOTATIONS_PROPERTY, propertyList);
/* 198 */     addProperty(PRIMITIVE_TYPE_CODE_PROPERTY, propertyList);
/* 199 */     PROPERTY_DESCRIPTORS_8_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 214 */     switch (apiLevel) {
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/* 218 */         return PROPERTY_DESCRIPTORS;
/*     */     } 
/* 220 */     return PROPERTY_DESCRIPTORS_8_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PrimitiveType(AST ast) {
/* 234 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalAnnotationsProperty() {
/* 239 */     return ANNOTATIONS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 244 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 249 */     if (property == ANNOTATIONS_PROPERTY) {
/* 250 */       return annotations();
/*     */     }
/*     */     
/* 253 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final Object internalGetSetObjectProperty(SimplePropertyDescriptor property, boolean get, Object value) {
/* 258 */     if (property == PRIMITIVE_TYPE_CODE_PROPERTY) {
/* 259 */       if (get) {
/* 260 */         return getPrimitiveTypeCode();
/*     */       }
/* 262 */       setPrimitiveTypeCode((Code)value);
/* 263 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 267 */     return super.internalGetSetObjectProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 272 */     return 39;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 277 */     PrimitiveType result = new PrimitiveType(target);
/* 278 */     result.setSourceRange(getStartPosition(), getLength());
/* 279 */     if (this.ast.apiLevel >= 8) {
/* 280 */       result.annotations().addAll(
/* 281 */           ASTNode.copySubtrees(target, annotations()));
/*     */     }
/* 283 */     result.setPrimitiveTypeCode(getPrimitiveTypeCode());
/* 284 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 290 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 295 */     boolean visitChildren = visitor.visit(this);
/* 296 */     if (visitChildren)
/*     */     {
/* 298 */       if (this.ast.apiLevel >= 8) {
/* 299 */         acceptChildren(visitor, this.annotations);
/*     */       }
/*     */     }
/* 302 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Code getPrimitiveTypeCode() {
/* 312 */     return this.typeCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrimitiveTypeCode(Code typeCode) {
/* 323 */     if (typeCode == null) {
/* 324 */       throw new IllegalArgumentException();
/*     */     }
/* 326 */     preValueChange(PRIMITIVE_TYPE_CODE_PROPERTY);
/* 327 */     this.typeCode = typeCode;
/* 328 */     postValueChange(PRIMITIVE_TYPE_CODE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 334 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 339 */     return memSize() + (
/* 340 */       (this.annotations == null) ? 0 : this.annotations.listSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\PrimitiveType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */