/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NormalAnnotation
/*     */   extends Annotation
/*     */ {
/*  36 */   public static final ChildPropertyDescriptor TYPE_NAME_PROPERTY = internalTypeNamePropertyFactory(NormalAnnotation.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   public static final ChildListPropertyDescriptor VALUES_PROPERTY = new ChildListPropertyDescriptor(NormalAnnotation.class, "values", MemberValuePair.class, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  52 */     List propertyList = new ArrayList(3);
/*  53 */     createPropertyList(NormalAnnotation.class, propertyList);
/*  54 */     addProperty(TYPE_NAME_PROPERTY, propertyList);
/*  55 */     addProperty(VALUES_PROPERTY, propertyList);
/*  56 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  68 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   private ASTNode.NodeList values = new ASTNode.NodeList(this, VALUES_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NormalAnnotation(AST ast) {
/*  90 */     super(ast);
/*  91 */     unsupportedIn2();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  96 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 101 */     if (property == TYPE_NAME_PROPERTY) {
/* 102 */       if (get) {
/* 103 */         return getTypeName();
/*     */       }
/* 105 */       setTypeName((Name)child);
/* 106 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 110 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 115 */     if (property == VALUES_PROPERTY) {
/* 116 */       return values();
/*     */     }
/*     */     
/* 119 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalTypeNameProperty() {
/* 124 */     return TYPE_NAME_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 129 */     return 77;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 134 */     NormalAnnotation result = new NormalAnnotation(target);
/* 135 */     result.setSourceRange(getStartPosition(), getLength());
/* 136 */     result.setTypeName((Name)ASTNode.copySubtree(target, getTypeName()));
/* 137 */     result.values().addAll(ASTNode.copySubtrees(target, values()));
/* 138 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 144 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 149 */     boolean visitChildren = visitor.visit(this);
/* 150 */     if (visitChildren) {
/*     */       
/* 152 */       acceptChild(visitor, getTypeName());
/* 153 */       acceptChildren(visitor, this.values);
/*     */     } 
/* 155 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List values() {
/* 169 */     return this.values;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 174 */     return super.memSize() + 4;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 179 */     return 
/* 180 */       memSize() + (
/* 181 */       (this.typeName == null) ? 0 : getTypeName().treeSize()) + 
/* 182 */       this.values.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\NormalAnnotation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */