/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MemberValuePair
/*     */   extends ASTNode
/*     */ {
/*  42 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(MemberValuePair.class, "name", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   public static final ChildPropertyDescriptor VALUE_PROPERTY = new ChildPropertyDescriptor(MemberValuePair.class, "value", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  58 */     List propertyList = new ArrayList(3);
/*  59 */     createPropertyList(MemberValuePair.class, propertyList);
/*  60 */     addProperty(NAME_PROPERTY, propertyList);
/*  61 */     addProperty(VALUE_PROPERTY, propertyList);
/*  62 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  74 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private SimpleName name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private Expression value = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MemberValuePair(AST ast) {
/* 100 */     super(ast);
/* 101 */     unsupportedIn2();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 106 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 111 */     if (property == NAME_PROPERTY) {
/* 112 */       if (get) {
/* 113 */         return getName();
/*     */       }
/* 115 */       setName((SimpleName)child);
/* 116 */       return null;
/*     */     } 
/*     */     
/* 119 */     if (property == VALUE_PROPERTY) {
/* 120 */       if (get) {
/* 121 */         return getValue();
/*     */       }
/* 123 */       setValue((Expression)child);
/* 124 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 128 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 133 */     return 80;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 138 */     MemberValuePair result = new MemberValuePair(target);
/* 139 */     result.setSourceRange(getStartPosition(), getLength());
/* 140 */     result.setName((SimpleName)ASTNode.copySubtree(target, getName()));
/* 141 */     result.setValue((Expression)ASTNode.copySubtree(target, getValue()));
/* 142 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 148 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 153 */     boolean visitChildren = visitor.visit(this);
/* 154 */     if (visitChildren) {
/*     */       
/* 156 */       acceptChild(visitor, getName());
/* 157 */       acceptChild(visitor, getValue());
/*     */     } 
/* 159 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 168 */     if (this.name == null)
/*     */     {
/* 170 */       synchronized (this) {
/* 171 */         if (this.name == null) {
/* 172 */           preLazyInit();
/* 173 */           this.name = new SimpleName(this.ast);
/* 174 */           postLazyInit(this.name, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 178 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IMemberValuePairBinding resolveMemberValuePairBinding() {
/* 193 */     return this.ast.getBindingResolver().resolveMemberValuePair(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName name) {
/* 207 */     if (name == null) {
/* 208 */       throw new IllegalArgumentException();
/*     */     }
/* 210 */     ASTNode oldChild = this.name;
/* 211 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 212 */     this.name = name;
/* 213 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getValue() {
/* 222 */     if (this.value == null)
/*     */     {
/* 224 */       synchronized (this) {
/* 225 */         if (this.value == null) {
/* 226 */           preLazyInit();
/* 227 */           this.value = new SimpleName(this.ast);
/* 228 */           postLazyInit(this.value, VALUE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 232 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(Expression value) {
/* 247 */     if (value == null) {
/* 248 */       throw new IllegalArgumentException();
/*     */     }
/* 250 */     ASTNode oldChild = this.value;
/* 251 */     preReplaceChild(oldChild, value, VALUE_PROPERTY);
/* 252 */     this.value = value;
/* 253 */     postReplaceChild(oldChild, value, VALUE_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 258 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 263 */     return 
/* 264 */       memSize() + (
/* 265 */       (this.name == null) ? 0 : getName().treeSize()) + (
/* 266 */       (this.value == null) ? 0 : getValue().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\MemberValuePair.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */