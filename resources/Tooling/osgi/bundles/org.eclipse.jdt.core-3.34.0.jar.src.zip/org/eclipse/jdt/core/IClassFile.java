package org.eclipse.jdt.core;

import org.eclipse.core.runtime.IProgressMonitor;

public interface IClassFile extends ITypeRoot {
  ICompilationUnit becomeWorkingCopy(IProblemRequestor paramIProblemRequestor, WorkingCopyOwner paramWorkingCopyOwner, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  byte[] getBytes() throws JavaModelException;
  
  @Deprecated
  IType getType();
  
  IJavaElement getWorkingCopy(IProgressMonitor paramIProgressMonitor, IBufferFactory paramIBufferFactory) throws JavaModelException;
  
  boolean isClass() throws JavaModelException;
  
  boolean isInterface() throws JavaModelException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IClassFile.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */