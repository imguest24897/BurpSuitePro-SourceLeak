/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ITypeBinding
/*     */   extends IBinding
/*     */ {
/*     */   ITypeBinding createArrayType(int paramInt);
/*     */   
/*     */   String getBinaryName();
/*     */   
/*     */   ITypeBinding getBound();
/*     */   
/*     */   ITypeBinding getGenericTypeOfWildcardType();
/*     */   
/*     */   int getRank();
/*     */   
/*     */   ITypeBinding getComponentType();
/*     */   
/*     */   IVariableBinding[] getDeclaredFields();
/*     */   
/*     */   IMethodBinding[] getDeclaredMethods();
/*     */   
/*     */   int getDeclaredModifiers();
/*     */   
/*     */   ITypeBinding[] getDeclaredTypes();
/*     */   
/*     */   ITypeBinding getDeclaringClass();
/*     */   
/*     */   IMethodBinding getDeclaringMethod();
/*     */   
/*     */   IBinding getDeclaringMember();
/*     */   
/*     */   default IModuleBinding getModule() {
/* 300 */     return null;
/*     */   }
/*     */   
/*     */   int getDimensions();
/*     */   
/*     */   ITypeBinding getElementType();
/*     */   
/*     */   ITypeBinding getErasure();
/*     */   
/*     */   IMethodBinding getFunctionalInterfaceMethod();
/*     */   
/*     */   ITypeBinding[] getInterfaces();
/*     */   
/*     */   int getModifiers();
/*     */   
/*     */   String getName();
/*     */   
/*     */   IPackageBinding getPackage();
/*     */   
/*     */   String getQualifiedName();
/*     */   
/*     */   ITypeBinding getSuperclass();
/*     */   
/*     */   IAnnotationBinding[] getTypeAnnotations();
/*     */   
/*     */   ITypeBinding[] getTypeArguments();
/*     */   
/*     */   ITypeBinding[] getTypeBounds();
/*     */   
/*     */   ITypeBinding getTypeDeclaration();
/*     */   
/*     */   ITypeBinding[] getTypeParameters();
/*     */   
/*     */   ITypeBinding getWildcard();
/*     */   
/*     */   boolean isAnnotation();
/*     */   
/*     */   boolean isAnonymous();
/*     */   
/*     */   boolean isArray();
/*     */   
/*     */   boolean isAssignmentCompatible(ITypeBinding paramITypeBinding);
/*     */   
/*     */   boolean isCapture();
/*     */   
/*     */   boolean isCastCompatible(ITypeBinding paramITypeBinding);
/*     */   
/*     */   boolean isClass();
/*     */   
/*     */   boolean isEnum();
/*     */   
/*     */   boolean isRecord();
/*     */   
/*     */   boolean isFromSource();
/*     */   
/*     */   boolean isGenericType();
/*     */   
/*     */   boolean isInterface();
/*     */   
/*     */   boolean isIntersectionType();
/*     */   
/*     */   boolean isLocal();
/*     */   
/*     */   boolean isMember();
/*     */   
/*     */   boolean isNested();
/*     */   
/*     */   boolean isNullType();
/*     */   
/*     */   boolean isParameterizedType();
/*     */   
/*     */   boolean isPrimitive();
/*     */   
/*     */   boolean isRawType();
/*     */   
/*     */   boolean isSubTypeCompatible(ITypeBinding paramITypeBinding);
/*     */   
/*     */   boolean isTopLevel();
/*     */   
/*     */   boolean isTypeVariable();
/*     */   
/*     */   boolean isUpperbound();
/*     */   
/*     */   boolean isWildcardType();
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ITypeBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */