/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PackageDeclaration
/*     */   extends ASTNode
/*     */ {
/*  42 */   public static final ChildPropertyDescriptor JAVADOC_PROPERTY = new ChildPropertyDescriptor(PackageDeclaration.class, "javadoc", Javadoc.class, false, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   public static final ChildListPropertyDescriptor ANNOTATIONS_PROPERTY = new ChildListPropertyDescriptor(PackageDeclaration.class, "annotations", Annotation.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(PackageDeclaration.class, "name", Name.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  75 */     List propertyList = new ArrayList(2);
/*  76 */     createPropertyList(PackageDeclaration.class, propertyList);
/*  77 */     addProperty(NAME_PROPERTY, propertyList);
/*  78 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(propertyList);
/*     */     
/*  80 */     propertyList = new ArrayList(4);
/*  81 */     createPropertyList(PackageDeclaration.class, propertyList);
/*  82 */     addProperty(JAVADOC_PROPERTY, propertyList);
/*  83 */     addProperty(ANNOTATIONS_PROPERTY, propertyList);
/*  84 */     addProperty(NAME_PROPERTY, propertyList);
/*  85 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 100 */     if (apiLevel == 2) {
/* 101 */       return PROPERTY_DESCRIPTORS_2_0;
/*     */     }
/* 103 */     return PROPERTY_DESCRIPTORS_3_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   Javadoc optionalDocComment = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   private ASTNode.NodeList annotations = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   private Name packageName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PackageDeclaration(AST ast) {
/* 141 */     super(ast);
/* 142 */     if (ast.apiLevel >= 3) {
/* 143 */       this.annotations = new ASTNode.NodeList(this, ANNOTATIONS_PROPERTY);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 149 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 154 */     if (property == JAVADOC_PROPERTY) {
/* 155 */       if (get) {
/* 156 */         return getJavadoc();
/*     */       }
/* 158 */       setJavadoc((Javadoc)child);
/* 159 */       return null;
/*     */     } 
/*     */     
/* 162 */     if (property == NAME_PROPERTY) {
/* 163 */       if (get) {
/* 164 */         return getName();
/*     */       }
/* 166 */       setName((Name)child);
/* 167 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 171 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 176 */     if (property == ANNOTATIONS_PROPERTY) {
/* 177 */       return annotations();
/*     */     }
/*     */     
/* 180 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 185 */     return 35;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 190 */     PackageDeclaration result = new PackageDeclaration(target);
/* 191 */     result.setSourceRange(getStartPosition(), getLength());
/* 192 */     if (this.ast.apiLevel >= 3) {
/* 193 */       result.setJavadoc((Javadoc)ASTNode.copySubtree(target, getJavadoc()));
/* 194 */       result.annotations().addAll(ASTNode.copySubtrees(target, annotations()));
/*     */     } 
/* 196 */     result.setName((Name)getName().clone(target));
/* 197 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 203 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 208 */     boolean visitChildren = visitor.visit(this);
/* 209 */     if (visitChildren) {
/* 210 */       if (this.ast.apiLevel >= 3) {
/* 211 */         acceptChild(visitor, getJavadoc());
/* 212 */         acceptChildren(visitor, this.annotations);
/*     */       } 
/* 214 */       acceptChild(visitor, getName());
/*     */     } 
/* 216 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List annotations() {
/* 231 */     if (this.annotations == null) {
/* 232 */       unsupportedIn2();
/*     */     }
/* 234 */     return this.annotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Javadoc getJavadoc() {
/* 247 */     if (this.annotations == null) {
/* 248 */       unsupportedIn2();
/*     */     }
/* 250 */     return this.optionalDocComment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJavadoc(Javadoc docComment) {
/* 264 */     if (this.annotations == null) {
/* 265 */       unsupportedIn2();
/*     */     }
/* 267 */     ASTNode oldChild = this.optionalDocComment;
/* 268 */     preReplaceChild(oldChild, docComment, JAVADOC_PROPERTY);
/* 269 */     this.optionalDocComment = docComment;
/* 270 */     postReplaceChild(oldChild, docComment, JAVADOC_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getName() {
/* 279 */     if (this.packageName == null)
/*     */     {
/* 281 */       synchronized (this) {
/* 282 */         if (this.packageName == null) {
/* 283 */           preLazyInit();
/* 284 */           this.packageName = new SimpleName(this.ast);
/* 285 */           postLazyInit(this.packageName, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 289 */     return this.packageName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(Name name) {
/* 303 */     if (name == null) {
/* 304 */       throw new IllegalArgumentException();
/*     */     }
/* 306 */     ASTNode oldChild = this.packageName;
/* 307 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 308 */     this.packageName = name;
/* 309 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPackageBinding resolveBinding() {
/* 324 */     return this.ast.getBindingResolver().resolvePackage(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 329 */     return 52;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 334 */     return 
/* 335 */       memSize() + (
/* 336 */       (this.optionalDocComment == null) ? 0 : getJavadoc().treeSize()) + (
/* 337 */       (this.annotations == null) ? 0 : this.annotations.listSize()) + (
/* 338 */       (this.packageName == null) ? 0 : getName().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\PackageDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */