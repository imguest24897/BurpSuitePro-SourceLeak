/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpressionStatement
/*     */   extends Statement
/*     */ {
/*  42 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(ExpressionStatement.class, "expression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  52 */     List properyList = new ArrayList(2);
/*  53 */     createPropertyList(ExpressionStatement.class, properyList);
/*  54 */     addProperty(EXPRESSION_PROPERTY, properyList);
/*  55 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  70 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   private Expression expression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExpressionStatement(AST ast) {
/*  90 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  95 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 100 */     if (property == EXPRESSION_PROPERTY) {
/* 101 */       if (get) {
/* 102 */         return getExpression();
/*     */       }
/* 104 */       setExpression((Expression)child);
/* 105 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 109 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 114 */     return 21;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 119 */     ExpressionStatement result = new ExpressionStatement(target);
/* 120 */     result.setSourceRange(getStartPosition(), getLength());
/* 121 */     result.copyLeadingComment(this);
/* 122 */     result.setExpression((Expression)getExpression().clone(target));
/* 123 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 129 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 134 */     boolean visitChildren = visitor.visit(this);
/* 135 */     if (visitChildren) {
/* 136 */       acceptChild(visitor, getExpression());
/*     */     }
/* 138 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 147 */     if (this.expression == null)
/*     */     {
/* 149 */       synchronized (this) {
/* 150 */         if (this.expression == null) {
/* 151 */           preLazyInit();
/* 152 */           this.expression = new MethodInvocation(this.ast);
/* 153 */           postLazyInit(this.expression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 157 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 172 */     if (expression == null) {
/* 173 */       throw new IllegalArgumentException();
/*     */     }
/* 175 */     ASTNode oldChild = this.expression;
/* 176 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 177 */     this.expression = expression;
/* 178 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 183 */     return super.memSize() + 4;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 188 */     return 
/* 189 */       memSize() + (
/* 190 */       (this.expression == null) ? 0 : getExpression().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ExpressionStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */