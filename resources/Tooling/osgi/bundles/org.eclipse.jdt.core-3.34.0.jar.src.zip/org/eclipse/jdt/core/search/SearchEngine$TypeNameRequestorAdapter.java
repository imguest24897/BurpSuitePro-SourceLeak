/*     */ package org.eclipse.jdt.core.search;
/*     */ 
/*     */ import org.eclipse.jdt.core.Flags;
/*     */ import org.eclipse.jdt.internal.compiler.env.AccessRestriction;
/*     */ import org.eclipse.jdt.internal.core.search.IRestrictedAccessTypeRequestor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TypeNameRequestorAdapter
/*     */   implements IRestrictedAccessTypeRequestor
/*     */ {
/*     */   ITypeNameRequestor nameRequestor;
/*     */   
/*     */   TypeNameRequestorAdapter(ITypeNameRequestor requestor) {
/*  99 */     this.nameRequestor = requestor;
/*     */   }
/*     */   
/*     */   public void acceptType(int modifiers, char[] packageName, char[] simpleTypeName, char[][] enclosingTypeNames, String path, AccessRestriction access) {
/* 103 */     if (Flags.isInterface(modifiers)) {
/* 104 */       this.nameRequestor.acceptInterface(packageName, simpleTypeName, enclosingTypeNames, path);
/*     */     } else {
/* 106 */       this.nameRequestor.acceptClass(packageName, simpleTypeName, enclosingTypeNames, path);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\search\SearchEngine$TypeNameRequestorAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */