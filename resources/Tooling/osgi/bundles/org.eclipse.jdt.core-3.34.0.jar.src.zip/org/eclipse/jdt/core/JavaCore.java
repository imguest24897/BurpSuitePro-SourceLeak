/*      */ package org.eclipse.jdt.core;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Hashtable;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.eclipse.core.resources.IContainer;
/*      */ import org.eclipse.core.resources.IFile;
/*      */ import org.eclipse.core.resources.IFolder;
/*      */ import org.eclipse.core.resources.IMarker;
/*      */ import org.eclipse.core.resources.IMarkerDelta;
/*      */ import org.eclipse.core.resources.IProject;
/*      */ import org.eclipse.core.resources.IResource;
/*      */ import org.eclipse.core.resources.IResourceChangeListener;
/*      */ import org.eclipse.core.resources.IWorkspace;
/*      */ import org.eclipse.core.resources.IWorkspaceRoot;
/*      */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*      */ import org.eclipse.core.resources.ResourcesPlugin;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IConfigurationElement;
/*      */ import org.eclipse.core.runtime.IExtension;
/*      */ import org.eclipse.core.runtime.IExtensionPoint;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.OperationCanceledException;
/*      */ import org.eclipse.core.runtime.Path;
/*      */ import org.eclipse.core.runtime.Platform;
/*      */ import org.eclipse.core.runtime.Plugin;
/*      */ import org.eclipse.core.runtime.QualifiedName;
/*      */ import org.eclipse.core.runtime.SubMonitor;
/*      */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.core.search.IJavaSearchScope;
/*      */ import org.eclipse.jdt.core.search.SearchEngine;
/*      */ import org.eclipse.jdt.core.search.TypeNameRequestor;
/*      */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFormatException;
/*      */ import org.eclipse.jdt.internal.compiler.env.AutomaticModuleNaming;
/*      */ import org.eclipse.jdt.internal.compiler.env.IModule;
/*      */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*      */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*      */ import org.eclipse.jdt.internal.core.BatchOperation;
/*      */ import org.eclipse.jdt.internal.core.BufferFactoryWrapper;
/*      */ import org.eclipse.jdt.internal.core.BufferManager;
/*      */ import org.eclipse.jdt.internal.core.ClasspathAttribute;
/*      */ import org.eclipse.jdt.internal.core.ClasspathEntry;
/*      */ import org.eclipse.jdt.internal.core.ClasspathValidation;
/*      */ import org.eclipse.jdt.internal.core.CreateTypeHierarchyOperation;
/*      */ import org.eclipse.jdt.internal.core.DefaultWorkingCopyOwner;
/*      */ import org.eclipse.jdt.internal.core.ExternalFoldersManager;
/*      */ import org.eclipse.jdt.internal.core.JavaModel;
/*      */ import org.eclipse.jdt.internal.core.JavaModelManager;
/*      */ import org.eclipse.jdt.internal.core.JavaProject;
/*      */ import org.eclipse.jdt.internal.core.PackageFragmentRoot;
/*      */ import org.eclipse.jdt.internal.core.Region;
/*      */ import org.eclipse.jdt.internal.core.SetContainerOperation;
/*      */ import org.eclipse.jdt.internal.core.SetVariablesOperation;
/*      */ import org.eclipse.jdt.internal.core.builder.JavaBuilder;
/*      */ import org.eclipse.jdt.internal.core.builder.ModuleInfoBuilder;
/*      */ import org.eclipse.jdt.internal.core.builder.State;
/*      */ import org.eclipse.jdt.internal.core.search.indexing.IndexManager;
/*      */ import org.eclipse.jdt.internal.core.util.MementoTokenizer;
/*      */ import org.eclipse.jdt.internal.core.util.Messages;
/*      */ import org.eclipse.jdt.internal.core.util.ModuleUtil;
/*      */ import org.eclipse.jdt.internal.core.util.Util;
/*      */ import org.osgi.framework.BundleContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class JavaCore
/*      */   extends Plugin
/*      */ {
/*  221 */   private static final IResource[] NO_GENERATED_RESOURCES = new IResource[0];
/*      */   
/*  223 */   private static Plugin JAVA_CORE_PLUGIN = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String PLUGIN_ID = "org.eclipse.jdt.core";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String BUILDER_ID = "org.eclipse.jdt.core.javabuilder";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String MODEL_ID = "org.eclipse.jdt.core.javamodel";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String NATURE_ID = "org.eclipse.jdt.core.javanature";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String ATT_HANDLE_ID = "org.eclipse.jdt.internal.core.JavaModelManager.handleId";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String USER_LIBRARY_CONTAINER_ID = "org.eclipse.jdt.USER_LIBRARY";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String MODULE_PATH_CONTAINER_ID = "org.eclipse.jdt.MODULE_PATH";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_LOCAL_VARIABLE_ATTR = "org.eclipse.jdt.core.compiler.debug.localVariable";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_LINE_NUMBER_ATTR = "org.eclipse.jdt.core.compiler.debug.lineNumber";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_SOURCE_FILE_ATTR = "org.eclipse.jdt.core.compiler.debug.sourceFile";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_CODEGEN_UNUSED_LOCAL = "org.eclipse.jdt.core.compiler.codegen.unusedLocal";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_CODEGEN_METHOD_PARAMETERS_ATTR = "org.eclipse.jdt.core.compiler.codegen.methodParameters";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_CODEGEN_TARGET_PLATFORM = "org.eclipse.jdt.core.compiler.codegen.targetPlatform";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_CODEGEN_INLINE_JSR_BYTECODE = "org.eclipse.jdt.core.compiler.codegen.inlineJsrBytecode";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_DOC_COMMENT_SUPPORT = "org.eclipse.jdt.core.compiler.doc.comment.support";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNREACHABLE_CODE = "org.eclipse.jdt.core.compiler.problem.unreachableCode";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_INVALID_IMPORT = "org.eclipse.jdt.core.compiler.problem.invalidImport";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_OVERRIDING_PACKAGE_DEFAULT_METHOD = "org.eclipse.jdt.core.compiler.problem.overridingPackageDefaultMethod";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_METHOD_WITH_CONSTRUCTOR_NAME = "org.eclipse.jdt.core.compiler.problem.methodWithConstructorName";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_DEPRECATION = "org.eclipse.jdt.core.compiler.problem.deprecation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_TERMINAL_DEPRECATION = "org.eclipse.jdt.core.compiler.problem.terminalDeprecation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_DEPRECATION_IN_DEPRECATED_CODE = "org.eclipse.jdt.core.compiler.problem.deprecationInDeprecatedCode";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_DEPRECATION_WHEN_OVERRIDING_DEPRECATED_METHOD = "org.eclipse.jdt.core.compiler.problem.deprecationWhenOverridingDeprecatedMethod";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_HIDDEN_CATCH_BLOCK = "org.eclipse.jdt.core.compiler.problem.hiddenCatchBlock";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_LOCAL = "org.eclipse.jdt.core.compiler.problem.unusedLocal";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_PARAMETER = "org.eclipse.jdt.core.compiler.problem.unusedParameter";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_EXCEPTION_PARAMETER = "org.eclipse.jdt.core.compiler.problem.unusedExceptionParameter";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_PARAMETER_WHEN_IMPLEMENTING_ABSTRACT = "org.eclipse.jdt.core.compiler.problem.unusedParameterWhenImplementingAbstract";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_PARAMETER_WHEN_OVERRIDING_CONCRETE = "org.eclipse.jdt.core.compiler.problem.unusedParameterWhenOverridingConcrete";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_PARAMETER_INCLUDE_DOC_COMMENT_REFERENCE = "org.eclipse.jdt.core.compiler.problem.unusedParameterIncludeDocCommentReference";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_IMPORT = "org.eclipse.jdt.core.compiler.problem.unusedImport";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_TYPE_ARGUMENTS_FOR_METHOD_INVOCATION = "org.eclipse.jdt.core.compiler.problem.unusedTypeArgumentsForMethodInvocation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_SYNTHETIC_ACCESS_EMULATION = "org.eclipse.jdt.core.compiler.problem.syntheticAccessEmulation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_TYPE_PARAMETER = "org.eclipse.jdt.core.compiler.problem.unusedTypeParameter";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_NON_NLS_STRING_LITERAL = "org.eclipse.jdt.core.compiler.problem.nonExternalizedStringLiteral";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_ASSERT_IDENTIFIER = "org.eclipse.jdt.core.compiler.problem.assertIdentifier";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_ENUM_IDENTIFIER = "org.eclipse.jdt.core.compiler.problem.enumIdentifier";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_STATIC_ACCESS_RECEIVER = "org.eclipse.jdt.core.compiler.problem.staticAccessReceiver";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_INDIRECT_STATIC_ACCESS = "org.eclipse.jdt.core.compiler.problem.indirectStaticAccess";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_NO_EFFECT_ASSIGNMENT = "org.eclipse.jdt.core.compiler.problem.noEffectAssignment";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_INCOMPATIBLE_NON_INHERITED_INTERFACE_METHOD = "org.eclipse.jdt.core.compiler.problem.incompatibleNonInheritedInterfaceMethod";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_PRIVATE_MEMBER = "org.eclipse.jdt.core.compiler.problem.unusedPrivateMember";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_LOCAL_VARIABLE_HIDING = "org.eclipse.jdt.core.compiler.problem.localVariableHiding";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_SPECIAL_PARAMETER_HIDING_FIELD = "org.eclipse.jdt.core.compiler.problem.specialParameterHidingField";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_FIELD_HIDING = "org.eclipse.jdt.core.compiler.problem.fieldHiding";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_TYPE_PARAMETER_HIDING = "org.eclipse.jdt.core.compiler.problem.typeParameterHiding";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_POSSIBLE_ACCIDENTAL_BOOLEAN_ASSIGNMENT = "org.eclipse.jdt.core.compiler.problem.possibleAccidentalBooleanAssignment";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_FALLTHROUGH_CASE = "org.eclipse.jdt.core.compiler.problem.fallthroughCase";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_EMPTY_STATEMENT = "org.eclipse.jdt.core.compiler.problem.emptyStatement";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_BOOLEAN_METHOD_THROWING_EXCEPTION = "org.eclipse.jdt.core.compiler.problem.booleanMethodThrowingException";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNNECESSARY_TYPE_CHECK = "org.eclipse.jdt.core.compiler.problem.unnecessaryTypeCheck";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNNECESSARY_ELSE = "org.eclipse.jdt.core.compiler.problem.unnecessaryElse";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNDOCUMENTED_EMPTY_BLOCK = "org.eclipse.jdt.core.compiler.problem.undocumentedEmptyBlock";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_FINALLY_BLOCK_NOT_COMPLETING = "org.eclipse.jdt.core.compiler.problem.finallyBlockNotCompletingNormally";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_DECLARED_THROWN_EXCEPTION = "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownException";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_DECLARED_THROWN_EXCEPTION_WHEN_OVERRIDING = "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionWhenOverriding";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_DECLARED_THROWN_EXCEPTION_INCLUDE_DOC_COMMENT_REFERENCE = "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionIncludeDocCommentReference";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_DECLARED_THROWN_EXCEPTION_EXEMPT_EXCEPTION_AND_THROWABLE = "org.eclipse.jdt.core.compiler.problem.unusedDeclaredThrownExceptionExemptExceptionAndThrowable";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNQUALIFIED_FIELD_ACCESS = "org.eclipse.jdt.core.compiler.problem.unqualifiedFieldAccess";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNSAFE_TYPE_OPERATION = "org.eclipse.jdt.core.compiler.problem.uncheckedTypeOperation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNCHECKED_TYPE_OPERATION = "org.eclipse.jdt.core.compiler.problem.uncheckedTypeOperation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_RAW_TYPE_REFERENCE = "org.eclipse.jdt.core.compiler.problem.rawTypeReference";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNAVOIDABLE_GENERIC_TYPE_PROBLEMS = "org.eclipse.jdt.core.compiler.problem.unavoidableGenericTypeProblems";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_FINAL_PARAMETER_BOUND = "org.eclipse.jdt.core.compiler.problem.finalParameterBound";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_SERIAL_VERSION = "org.eclipse.jdt.core.compiler.problem.missingSerialVersion";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_VARARGS_ARGUMENT_NEED_CAST = "org.eclipse.jdt.core.compiler.problem.varargsArgumentNeedCast";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_AUTOBOXING = "org.eclipse.jdt.core.compiler.problem.autoboxing";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_ANNOTATION_SUPER_INTERFACE = "org.eclipse.jdt.core.compiler.problem.annotationSuperInterface";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_OVERRIDE_ANNOTATION = "org.eclipse.jdt.core.compiler.problem.missingOverrideAnnotation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_OVERRIDE_ANNOTATION_FOR_INTERFACE_METHOD_IMPLEMENTATION = "org.eclipse.jdt.core.compiler.problem.missingOverrideAnnotationForInterfaceMethodImplementation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_DEPRECATED_ANNOTATION = "org.eclipse.jdt.core.compiler.problem.missingDeprecatedAnnotation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_HASHCODE_METHOD = "org.eclipse.jdt.core.compiler.problem.missingHashCodeMethod";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_DEAD_CODE = "org.eclipse.jdt.core.compiler.problem.deadCode";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_DEAD_CODE_IN_TRIVIAL_IF_STATEMENT = "org.eclipse.jdt.core.compiler.problem.deadCodeInTrivialIfStatement";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_INCOMPLETE_ENUM_SWITCH = "org.eclipse.jdt.core.compiler.problem.incompleteEnumSwitch";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_ENUM_CASE_DESPITE_DEFAULT = "org.eclipse.jdt.core.compiler.problem.missingEnumCaseDespiteDefault";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_SWITCH_MISSING_DEFAULT_CASE = "org.eclipse.jdt.core.compiler.problem.missingDefaultCase";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_INCONSISTENT_NULL_CHECK = "org.eclipse.jdt.core.compiler.problem.inconsistentNullCheck";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_LABEL = "org.eclipse.jdt.core.compiler.problem.unusedLabel";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_INVALID_JAVADOC = "org.eclipse.jdt.core.compiler.problem.invalidJavadoc";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_INVALID_JAVADOC_TAGS = "org.eclipse.jdt.core.compiler.problem.invalidJavadocTags";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_INVALID_JAVADOC_TAGS__DEPRECATED_REF = "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsDeprecatedRef";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_INVALID_JAVADOC_TAGS__NOT_VISIBLE_REF = "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsNotVisibleRef";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_INVALID_JAVADOC_TAGS_VISIBILITY = "org.eclipse.jdt.core.compiler.problem.invalidJavadocTagsVisibility";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_JAVADOC_TAG_DESCRIPTION = "org.eclipse.jdt.core.compiler.problem.missingJavadocTagDescription";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_JAVADOC_TAGS = "org.eclipse.jdt.core.compiler.problem.missingJavadocTags";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_JAVADOC_TAGS_VISIBILITY = "org.eclipse.jdt.core.compiler.problem.missingJavadocTagsVisibility";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_JAVADOC_TAGS_OVERRIDING = "org.eclipse.jdt.core.compiler.problem.missingJavadocTagsOverriding";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_JAVADOC_TAGS_METHOD_TYPE_PARAMETERS = "org.eclipse.jdt.core.compiler.problem.missingJavadocTagsMethodTypeParameters";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_JAVADOC_COMMENTS = "org.eclipse.jdt.core.compiler.problem.missingJavadocComments";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_JAVADOC_COMMENTS_VISIBILITY = "org.eclipse.jdt.core.compiler.problem.missingJavadocCommentsVisibility";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_JAVADOC_COMMENTS_OVERRIDING = "org.eclipse.jdt.core.compiler.problem.missingJavadocCommentsOverriding";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_CHAR_ARRAY_IN_STRING_CONCATENATION = "org.eclipse.jdt.core.compiler.problem.noImplicitStringConversion";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MAX_PER_UNIT = "org.eclipse.jdt.core.compiler.maxProblemPerUnit";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_FATAL_OPTIONAL_ERROR = "org.eclipse.jdt.core.compiler.problem.fatalOptionalError";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_PARAMETER_ASSIGNMENT = "org.eclipse.jdt.core.compiler.problem.parameterAssignment";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_STATIC_ON_METHOD = "org.eclipse.jdt.core.compiler.problem.reportMethodCanBeStatic";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_POTENTIALLY_MISSING_STATIC_ON_METHOD = "org.eclipse.jdt.core.compiler.problem.reportMethodCanBePotentiallyStatic";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNCLOSED_CLOSEABLE = "org.eclipse.jdt.core.compiler.problem.unclosedCloseable";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_POTENTIALLY_UNCLOSED_CLOSEABLE = "org.eclipse.jdt.core.compiler.problem.potentiallyUnclosedCloseable";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_EXPLICITLY_CLOSED_AUTOCLOSEABLE = "org.eclipse.jdt.core.compiler.problem.explicitlyClosedAutoCloseable";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNLIKELY_COLLECTION_METHOD_ARGUMENT_TYPE = "org.eclipse.jdt.core.compiler.problem.unlikelyCollectionMethodArgumentType";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNLIKELY_COLLECTION_METHOD_ARGUMENT_TYPE_STRICT = "org.eclipse.jdt.core.compiler.problem.unlikelyCollectionMethodArgumentTypeStrict";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNLIKELY_EQUALS_ARGUMENT_TYPE = "org.eclipse.jdt.core.compiler.problem.unlikelyEqualsArgumentType";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_API_LEAKS = "org.eclipse.jdt.core.compiler.problem.APILeak";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNSTABLE_AUTO_MODULE_NAME = "org.eclipse.jdt.core.compiler.problem.unstableAutoModuleName";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_SUPPRESS_WARNINGS_NOT_FULLY_ANALYSED = "org.eclipse.jdt.core.compiler.problem.suppressWarningsNotFullyAnalysed";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_ANNOTATION_NULL_ANALYSIS = "org.eclipse.jdt.core.compiler.annotation.nullanalysis";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_NULLABLE_ANNOTATION_NAME = "org.eclipse.jdt.core.compiler.annotation.nullable";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_NULLABLE_ANNOTATION_SECONDARY_NAMES = "org.eclipse.jdt.core.compiler.annotation.nullable.secondary";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_NONNULL_ANNOTATION_NAME = "org.eclipse.jdt.core.compiler.annotation.nonnull";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_NONNULL_ANNOTATION_SECONDARY_NAMES = "org.eclipse.jdt.core.compiler.annotation.nonnull.secondary";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_NONNULL_BY_DEFAULT_ANNOTATION_NAME = "org.eclipse.jdt.core.compiler.annotation.nonnullbydefault";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_NONNULL_BY_DEFAULT_ANNOTATION_SECONDARY_NAMES = "org.eclipse.jdt.core.compiler.annotation.nonnullbydefault.secondary";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_NONNULL_BY_DEFAULT_ANNOTATION = "org.eclipse.jdt.core.compiler.annotation.missingNonNullByDefaultAnnotation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CORE_JAVA_BUILD_EXTERNAL_ANNOTATIONS_FROM_ALL_LOCATIONS = "org.eclipse.jdt.core.builder.annotationPath.allLocations";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_NULL_SPECIFICATION_VIOLATION = "org.eclipse.jdt.core.compiler.problem.nullSpecViolation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_NULL_ANNOTATION_INFERENCE_CONFLICT = "org.eclipse.jdt.core.compiler.problem.nullAnnotationInferenceConflict";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_NULL_UNCHECKED_CONVERSION = "org.eclipse.jdt.core.compiler.problem.nullUncheckedConversion";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_PESSIMISTIC_NULL_ANALYSIS_FOR_FREE_TYPE_VARIABLES = "org.eclipse.jdt.core.compiler.problem.pessimisticNullAnalysisForFreeTypeVariables";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_REDUNDANT_NULL_ANNOTATION = "org.eclipse.jdt.core.compiler.problem.redundantNullAnnotation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_SYNTACTIC_NULL_ANALYSIS_FOR_FIELDS = "org.eclipse.jdt.core.compiler.problem.syntacticNullAnalysisForFields";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_INHERIT_NULL_ANNOTATIONS = "org.eclipse.jdt.core.compiler.annotation.inheritNullAnnotations";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_NONNULL_PARAMETER_ANNOTATION_DROPPED = "org.eclipse.jdt.core.compiler.problem.nonnullParameterAnnotationDropped";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_NONNULL_TYPEVAR_FROM_LEGACY_INVOCATION = "org.eclipse.jdt.core.compiler.problem.nonnullTypeVariableFromLegacyInvocation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_ANNOTATED_TYPE_ARGUMENT_TO_UNANNOTATED = "org.eclipse.jdt.core.compiler.problem.annotatedTypeArgumentToUnannotated";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_SOURCE = "org.eclipse.jdt.core.compiler.source";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_COMPLIANCE = "org.eclipse.jdt.core.compiler.compliance";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_RELEASE = "org.eclipse.jdt.core.compiler.release";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_TASK_PRIORITIES = "org.eclipse.jdt.core.compiler.taskPriorities";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_TASK_TAGS = "org.eclipse.jdt.core.compiler.taskTags";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_TASK_CASE_SENSITIVE = "org.eclipse.jdt.core.compiler.taskCaseSensitive";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_FORBIDDEN_REFERENCE = "org.eclipse.jdt.core.compiler.problem.forbiddenReference";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_DISCOURAGED_REFERENCE = "org.eclipse.jdt.core.compiler.problem.discouragedReference";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_SUPPRESS_WARNINGS = "org.eclipse.jdt.core.compiler.problem.suppressWarnings";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_INCLUDE_ASSERTS_IN_NULL_ANALYSIS = "org.eclipse.jdt.core.compiler.problem.includeNullInfoFromAsserts";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_SUPPRESS_OPTIONAL_ERRORS = "org.eclipse.jdt.core.compiler.problem.suppressOptionalErrors";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNHANDLED_WARNING_TOKEN = "org.eclipse.jdt.core.compiler.problem.unhandledWarningToken";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_WARNING_TOKEN = "org.eclipse.jdt.core.compiler.problem.unusedWarningToken";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_NULL_REFERENCE = "org.eclipse.jdt.core.compiler.problem.nullReference";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_POTENTIAL_NULL_REFERENCE = "org.eclipse.jdt.core.compiler.problem.potentialNullReference";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_REDUNDANT_NULL_CHECK = "org.eclipse.jdt.core.compiler.problem.redundantNullCheck";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_OVERRIDING_METHOD_WITHOUT_SUPER_INVOCATION = "org.eclipse.jdt.core.compiler.problem.overridingMethodWithoutSuperInvocation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_REDUNDANT_SUPERINTERFACE = "org.eclipse.jdt.core.compiler.problem.redundantSuperinterface";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_COMPARING_IDENTICAL = "org.eclipse.jdt.core.compiler.problem.comparingIdentical";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_MISSING_SYNCHRONIZED_ON_INHERITED_METHOD = "org.eclipse.jdt.core.compiler.problem.missingSynchronizedOnInheritedMethod";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_UNUSED_OBJECT_ALLOCATION = "org.eclipse.jdt.core.compiler.problem.unusedObjectAllocation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_REDUNDANT_TYPE_ARGUMENTS = "org.eclipse.jdt.core.compiler.problem.redundantSpecificationOfTypeArguments";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CORE_JAVA_BUILD_ORDER = "org.eclipse.jdt.core.computeJavaBuildOrder";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CORE_JAVA_BUILD_RESOURCE_COPY_FILTER = "org.eclipse.jdt.core.builder.resourceCopyExclusionFilter";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CORE_JAVA_BUILD_DUPLICATE_RESOURCE = "org.eclipse.jdt.core.builder.duplicateResourceTask";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CORE_JAVA_BUILD_CLEAN_OUTPUT_FOLDER = "org.eclipse.jdt.core.builder.cleanOutputFolder";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CORE_JAVA_BUILD_RECREATE_MODIFIED_CLASS_FILES_IN_OUTPUT_FOLDER = "org.eclipse.jdt.core.builder.recreateModifiedClassFileInOutputFolder";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CORE_INCOMPLETE_CLASSPATH = "org.eclipse.jdt.core.incompleteClasspath";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CORE_CIRCULAR_CLASSPATH = "org.eclipse.jdt.core.circularClasspath";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CORE_INCOMPATIBLE_JDK_LEVEL = "org.eclipse.jdt.core.incompatibleJDKLevel";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CORE_JAVA_BUILD_INVALID_CLASSPATH = "org.eclipse.jdt.core.builder.invalidClasspath";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CORE_ENCODING = "org.eclipse.jdt.core.encoding";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CORE_ENABLE_CLASSPATH_EXCLUSION_PATTERNS = "org.eclipse.jdt.core.classpath.exclusionPatterns";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CORE_ENABLE_CLASSPATH_MULTIPLE_OUTPUT_LOCATIONS = "org.eclipse.jdt.core.classpath.multipleOutputLocations";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CORE_OUTPUT_LOCATION_OVERLAPPING_ANOTHER_SOURCE = "org.eclipse.jdt.core.classpath.outputOverlappingAnotherSource";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CORE_MAIN_ONLY_PROJECT_HAS_TEST_ONLY_DEPENDENCY = "org.eclipse.jdt.core.classpath.mainOnlyProjectHasTestOnlyDependency";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_ENABLE_PREVIEW_FEATURES = "org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_PB_REPORT_PREVIEW_FEATURES = "org.eclipse.jdt.core.compiler.problem.reportPreviewFeatures";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_IGNORE_UNNAMED_MODULE_FOR_SPLIT_PACKAGE = "org.eclipse.jdt.core.compiler.ignoreUnnamedModuleForSplitPackage";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String TIMEOUT_FOR_PARAMETER_NAME_FROM_ATTACHED_JAVADOC = "org.eclipse.jdt.core.timeoutForParameterNameFromAttachedJavadoc";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String JAVA_FORMATTER = "org.eclipse.jdt.core.javaFormatter";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String FORMATTER_NEWLINE_OPENING_BRACE = "org.eclipse.jdt.core.formatter.newline.openingBrace";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String FORMATTER_NEWLINE_CONTROL = "org.eclipse.jdt.core.formatter.newline.controlStatement";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String FORMATTER_NEWLINE_ELSE_IF = "org.eclipse.jdt.core.formatter.newline.elseIf";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String FORMATTER_NEWLINE_EMPTY_BLOCK = "org.eclipse.jdt.core.formatter.newline.emptyBlock";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String FORMATTER_CLEAR_BLANK_LINES = "org.eclipse.jdt.core.formatter.newline.clearAll";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String FORMATTER_LINE_SPLIT = "org.eclipse.jdt.core.formatter.lineSplit";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String FORMATTER_COMPACT_ASSIGNMENT = "org.eclipse.jdt.core.formatter.style.assignment";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String FORMATTER_TAB_CHAR = "org.eclipse.jdt.core.formatter.tabulation.char";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String FORMATTER_TAB_SIZE = "org.eclipse.jdt.core.formatter.tabulation.size";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String FORMATTER_SPACE_CASTEXPRESSION = "org.eclipse.jdt.core.formatter.space.castexpression";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_VISIBILITY_CHECK = "org.eclipse.jdt.core.codeComplete.visibilityCheck";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_DEPRECATION_CHECK = "org.eclipse.jdt.core.codeComplete.deprecationCheck";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_CAMEL_CASE_MATCH = "org.eclipse.jdt.core.codeComplete.camelCaseMatch";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_SUBSTRING_MATCH = "org.eclipse.jdt.core.codeComplete.substringMatch";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_SUBWORD_MATCH = "org.eclipse.jdt.core.codeComplete.subwordMatch";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_IMPLICIT_QUALIFICATION = "org.eclipse.jdt.core.codeComplete.forceImplicitQualification";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_FIELD_PREFIXES = "org.eclipse.jdt.core.codeComplete.fieldPrefixes";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_STATIC_FIELD_PREFIXES = "org.eclipse.jdt.core.codeComplete.staticFieldPrefixes";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_STATIC_FINAL_FIELD_PREFIXES = "org.eclipse.jdt.core.codeComplete.staticFinalFieldPrefixes";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_LOCAL_PREFIXES = "org.eclipse.jdt.core.codeComplete.localPrefixes";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_ARGUMENT_PREFIXES = "org.eclipse.jdt.core.codeComplete.argumentPrefixes";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_FIELD_SUFFIXES = "org.eclipse.jdt.core.codeComplete.fieldSuffixes";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_STATIC_FIELD_SUFFIXES = "org.eclipse.jdt.core.codeComplete.staticFieldSuffixes";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_STATIC_FINAL_FIELD_SUFFIXES = "org.eclipse.jdt.core.codeComplete.staticFinalFieldSuffixes";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_LOCAL_SUFFIXES = "org.eclipse.jdt.core.codeComplete.localSuffixes";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_ARGUMENT_SUFFIXES = "org.eclipse.jdt.core.codeComplete.argumentSuffixes";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_FORBIDDEN_REFERENCE_CHECK = "org.eclipse.jdt.core.codeComplete.forbiddenReferenceCheck";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_DISCOURAGED_REFERENCE_CHECK = "org.eclipse.jdt.core.codeComplete.discouragedReferenceCheck";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String CODEASSIST_SUGGEST_STATIC_IMPORTS = "org.eclipse.jdt.core.codeComplete.suggestStaticImports";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String DEFAULT_TASK_TAG = "TODO";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String DEFAULT_TASK_PRIORITY = "NORMAL";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String DEFAULT_TASK_TAGS = "TODO,FIXME,XXX";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String DEFAULT_TASK_PRIORITIES = "NORMAL,HIGH,NORMAL";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String GENERATE = "generate";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String DO_NOT_GENERATE = "do not generate";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String PRESERVE = "preserve";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String OPTIMIZE_OUT = "optimize out";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_TASK_PRIORITY_HIGH = "HIGH";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_TASK_PRIORITY_LOW = "LOW";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String COMPILER_TASK_PRIORITY_NORMAL = "NORMAL";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_1_1 = "1.1";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_1_2 = "1.2";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_1_3 = "1.3";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_1_4 = "1.4";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_1_5 = "1.5";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_1_6 = "1.6";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_1_7 = "1.7";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_1_8 = "1.8";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_9 = "9";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_10 = "10";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_11 = "11";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_12 = "12";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_13 = "13";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_14 = "14";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_15 = "15";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_16 = "16";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_17 = "17";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_18 = "18";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_19 = "19";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_20 = "20";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String VERSION_CLDC_1_1 = "cldc1.1";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3195 */   private static List<String> allVersions = Collections.unmodifiableList(Arrays.asList(new String[] { "cldc1.1", "1.1", "1.2", "1.3", "1.4", "1.5", 
/* 3196 */           "1.6", "1.7", "1.8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", 
/* 3197 */           "19", "20" })); public static final String ABORT = "abort"; public static final String ERROR = "error"; public static final String WARNING = "warning"; public static final String IGNORE = "ignore"; public static final String INFO = "info"; public static final String COMPUTE = "compute"; public static final String INSERT = "insert";
/*      */   public static final String DO_NOT_INSERT = "do not insert";
/*      */   public static final String PRESERVE_ONE = "preserve one";
/*      */   public static final String CLEAR_ALL = "clear all";
/*      */   public static final String NORMAL = "normal";
/*      */   public static final String COMPACT = "compact";
/*      */   public static final String TAB = "tab";
/*      */   public static final String SPACE = "space";
/*      */   
/*      */   public static List<String> getAllVersions() {
/* 3207 */     return allVersions;
/*      */   }
/*      */   public static final String ENABLED = "enabled"; public static final String DISABLED = "disabled"; public static final String CLEAN = "clean"; public static final String PUBLIC = "public";
/*      */   public static final String PROTECTED = "protected";
/*      */   public static final String DEFAULT = "default";
/*      */   public static final String PRIVATE = "private";
/*      */   public static final String NEVER = "never";
/*      */   public static final String COMPILER_PB_MISSING_JAVADOC_TAG_DESCRIPTION_NO_TAG = "no_tag";
/*      */   public static final String COMPILER_PB_MISSING_JAVADOC_TAG_DESCRIPTION_RETURN_TAG = "return_tag";
/*      */   public static final String COMPILER_PB_MISSING_JAVADOC_TAG_DESCRIPTION_ALL_STANDARD_TAGS = "all_standard_tags";
/*      */   public static final String JAVA_SOURCE_CONTENT_TYPE = "org.eclipse.jdt.core.javaSource";
/*      */   public static final String DEFAULT_JAVA_FORMATTER = "org.eclipse.jdt.core.defaultJavaFormatter";
/*      */   public static final String JAVA_FORMATTER_EXTENSION_POINT_ID = "javaFormatter";
/*      */   
/*      */   public static boolean isSupportedJavaVersion(String version) {
/* 3222 */     return (CompilerOptions.versionToJdkLevel(version, false) > 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaCore() {
/* 3411 */     JAVA_CORE_PLUGIN = this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addElementChangedListener(IElementChangedListener listener) {
/* 3430 */     addElementChangedListener(listener, 5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addElementChangedListener(IElementChangedListener listener, int eventMask) {
/* 3460 */     JavaModelManager.getDeltaState().addElementChangedListener(listener, eventMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addJavaElementMarkerAttributes(Map<String, String> attributes, IJavaElement element) {
/* 3474 */     if (element instanceof IMember)
/* 3475 */       element = ((IMember)element).getClassFile(); 
/* 3476 */     if (attributes != null && element != null) {
/* 3477 */       attributes.put("org.eclipse.jdt.internal.core.JavaModelManager.handleId", element.getHandleIdentifier());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void addNonJavaResources(Object[] nonJavaResources, IContainer container, int rootPathSegmentCounts, ArrayList<IResource> collector) {
/* 3484 */     for (int i = 0, max = nonJavaResources.length; i < max; i++) {
/* 3485 */       Object nonJavaResource = nonJavaResources[i];
/* 3486 */       if (nonJavaResource instanceof IFile) {
/* 3487 */         IFile file = (IFile)nonJavaResource;
/* 3488 */         IPath path = file.getFullPath().removeFirstSegments(rootPathSegmentCounts);
/* 3489 */         IResource member = container.findMember(path);
/* 3490 */         if (member != null && member.exists()) {
/* 3491 */           collector.add(member);
/*      */         }
/* 3493 */       } else if (nonJavaResource instanceof IFolder) {
/* 3494 */         IFolder folder = (IFolder)nonJavaResource;
/* 3495 */         IResource[] members = null;
/*      */         try {
/* 3497 */           members = folder.members();
/* 3498 */         } catch (CoreException coreException) {}
/*      */ 
/*      */         
/* 3501 */         if (members != null) {
/* 3502 */           addNonJavaResources((Object[])members, container, rootPathSegmentCounts, collector);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addPreProcessingResourceChangedListener(IResourceChangeListener listener) {
/* 3522 */     addPreProcessingResourceChangedListener(listener, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addPreProcessingResourceChangedListener(IResourceChangeListener listener, int eventMask) {
/* 3553 */     JavaModelManager.getDeltaState().addPreResourceChangedListener(listener, eventMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void configureJavaElementMarker(IMarker marker, IJavaElement element) throws CoreException {
/* 3566 */     if (element instanceof IMember)
/* 3567 */       element = ((IMember)element).getClassFile(); 
/* 3568 */     if (marker != null && element != null) {
/* 3569 */       marker.setAttribute("org.eclipse.jdt.internal.core.JavaModelManager.handleId", element.getHandleIdentifier());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaElement create(String handleIdentifier) {
/* 3581 */     return create(handleIdentifier, (WorkingCopyOwner)DefaultWorkingCopyOwner.PRIMARY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaElement create(String handleIdentifier, WorkingCopyOwner owner) {
/*      */     DefaultWorkingCopyOwner defaultWorkingCopyOwner;
/* 3599 */     if (handleIdentifier == null) {
/* 3600 */       return null;
/*      */     }
/* 3602 */     if (owner == null)
/* 3603 */       defaultWorkingCopyOwner = DefaultWorkingCopyOwner.PRIMARY; 
/* 3604 */     MementoTokenizer memento = new MementoTokenizer(handleIdentifier);
/* 3605 */     JavaModel model = JavaModelManager.getJavaModelManager().getJavaModel();
/* 3606 */     return model.getHandleFromMemento(memento, (WorkingCopyOwner)defaultWorkingCopyOwner);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaElement create(IFile file) {
/* 3632 */     return JavaModelManager.create(file, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaElement create(IFolder folder) {
/* 3650 */     return JavaModelManager.create(folder, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaProject create(IProject project) {
/* 3666 */     if (project == null) {
/* 3667 */       return null;
/*      */     }
/* 3669 */     JavaModel javaModel = JavaModelManager.getJavaModelManager().getJavaModel();
/* 3670 */     return javaModel.getJavaProject((IResource)project);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaElement create(IResource resource) {
/* 3700 */     return JavaModelManager.create(resource, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaElement create(IResource resource, IJavaProject project) {
/* 3731 */     return JavaModelManager.create(resource, project);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaModel create(IWorkspaceRoot root) {
/* 3740 */     if (root == null) {
/* 3741 */       return null;
/*      */     }
/* 3743 */     return (IJavaModel)JavaModelManager.getJavaModelManager().getJavaModel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClassFile createClassFileFrom(IFile file) {
/* 3755 */     return JavaModelManager.createClassFileFrom(file, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ICompilationUnit createCompilationUnitFrom(IFile file) {
/* 3768 */     return JavaModelManager.createCompilationUnitFrom(file, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IPackageFragmentRoot createJarPackageFragmentRootFrom(IFile file) {
/* 3780 */     return JavaModelManager.createJarPackageFragmentRootFrom(file, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathContainer getClasspathContainer(IPath containerPath, IJavaProject project) throws JavaModelException {
/* 3820 */     JavaModelManager manager = JavaModelManager.getJavaModelManager();
/* 3821 */     IClasspathContainer container = manager.getClasspathContainer(containerPath, project);
/* 3822 */     if (container == JavaModelManager.CONTAINER_INITIALIZATION_IN_PROGRESS) {
/* 3823 */       return manager.getPreviousSessionContainer(containerPath, project);
/*      */     }
/* 3825 */     return container;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ClasspathContainerInitializer getClasspathContainerInitializer(String containerID) {
/* 3841 */     Hashtable<String, ClasspathContainerInitializer> containerInitializersCache = (JavaModelManager.getJavaModelManager()).containerInitializersCache;
/* 3842 */     ClasspathContainerInitializer initializer = (ClasspathContainerInitializer)containerInitializersCache.get(containerID);
/* 3843 */     if (initializer == null) {
/* 3844 */       initializer = computeClasspathContainerInitializer(containerID);
/* 3845 */       if (initializer == null)
/* 3846 */         return null; 
/* 3847 */       containerInitializersCache.put(containerID, initializer);
/*      */     } 
/* 3849 */     return initializer;
/*      */   }
/*      */   
/*      */   private static ClasspathContainerInitializer computeClasspathContainerInitializer(String containerID) {
/* 3853 */     Plugin jdtCorePlugin = getPlugin();
/* 3854 */     if (jdtCorePlugin == null) return null;
/*      */     
/* 3856 */     IExtensionPoint extension = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.jdt.core", "classpathContainerInitializer");
/* 3857 */     if (extension != null) {
/* 3858 */       IExtension[] extensions = extension.getExtensions();
/* 3859 */       for (int i = 0; i < extensions.length; i++) {
/* 3860 */         IConfigurationElement[] configElements = extensions[i].getConfigurationElements();
/* 3861 */         for (int j = 0; j < configElements.length; j++) {
/* 3862 */           IConfigurationElement configurationElement = configElements[j];
/* 3863 */           String initializerID = configurationElement.getAttribute("id");
/* 3864 */           if (initializerID != null && initializerID.equals(containerID)) {
/* 3865 */             if (JavaModelManager.CP_RESOLVE_VERBOSE_ADVANCED)
/* 3866 */               verbose_found_container_initializer(containerID, configurationElement); 
/*      */             try {
/* 3868 */               Object execExt = configurationElement.createExecutableExtension("class");
/* 3869 */               if (execExt instanceof ClasspathContainerInitializer) {
/* 3870 */                 return (ClasspathContainerInitializer)execExt;
/*      */               }
/* 3872 */             } catch (CoreException e) {
/*      */               
/* 3874 */               if (JavaModelManager.CP_RESOLVE_VERBOSE || JavaModelManager.CP_RESOLVE_VERBOSE_FAILURE) {
/* 3875 */                 verbose_failed_to_instanciate_container_initializer(containerID, configurationElement);
/* 3876 */                 e.printStackTrace();
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 3883 */     return null;
/*      */   }
/*      */   
/*      */   private static void verbose_failed_to_instanciate_container_initializer(String containerID, IConfigurationElement configurationElement) {
/* 3887 */     Util.verbose(
/* 3888 */         "CPContainer INIT - failed to instanciate initializer\n\tcontainer ID: " + 
/* 3889 */         containerID + '\n' + 
/* 3890 */         "\tclass: " + configurationElement.getAttribute("class"), 
/* 3891 */         System.err);
/*      */   }
/*      */   
/*      */   private static void verbose_found_container_initializer(String containerID, IConfigurationElement configurationElement) {
/* 3895 */     Util.verbose(
/* 3896 */         "CPContainer INIT - found initializer\n\tcontainer ID: " + 
/* 3897 */         containerID + '\n' + 
/* 3898 */         "\tclass: " + configurationElement.getAttribute("class"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IPath getClasspathVariable(String variableName) {
/* 3922 */     JavaModelManager manager = JavaModelManager.getJavaModelManager();
/* 3923 */     IPath variablePath = manager.variableGet(variableName);
/* 3924 */     if (variablePath == JavaModelManager.VARIABLE_INITIALIZATION_IN_PROGRESS) {
/* 3925 */       return manager.getPreviousSessionVariable(variableName);
/*      */     }
/*      */     
/* 3928 */     if (variablePath != null) {
/* 3929 */       if (variablePath == JavaModelManager.CP_ENTRY_IGNORE_PATH)
/* 3930 */         return null; 
/* 3931 */       return variablePath;
/*      */     } 
/*      */ 
/*      */     
/* 3935 */     ClasspathVariableInitializer initializer = getClasspathVariableInitializer(variableName);
/* 3936 */     if (initializer != null) {
/* 3937 */       if (JavaModelManager.CP_RESOLVE_VERBOSE)
/* 3938 */         verbose_triggering_variable_initialization(variableName, initializer); 
/* 3939 */       if (JavaModelManager.CP_RESOLVE_VERBOSE_ADVANCED)
/* 3940 */         verbose_triggering_variable_initialization_invocation_trace(); 
/* 3941 */       manager.variablePut(variableName, JavaModelManager.VARIABLE_INITIALIZATION_IN_PROGRESS);
/* 3942 */       boolean ok = false;
/*      */ 
/*      */ 
/*      */       
/* 3946 */       try { initializer.initialize(variableName);
/*      */         
/* 3948 */         variablePath = manager.variableGet(variableName);
/* 3949 */         if (variablePath == JavaModelManager.VARIABLE_INITIALIZATION_IN_PROGRESS) return null; 
/* 3950 */         if (JavaModelManager.CP_RESOLVE_VERBOSE_ADVANCED)
/* 3951 */           verbose_variable_value_after_initialization(variableName, variablePath); 
/* 3952 */         manager.variablesWithInitializer.add(variableName); }
/*      */       
/* 3954 */       catch (RuntimeException|Error e)
/* 3955 */       { if (JavaModelManager.CP_RESOLVE_VERBOSE || JavaModelManager.CP_RESOLVE_VERBOSE_FAILURE)
/* 3956 */           e.printStackTrace(); 
/* 3957 */         throw e; }
/*      */       finally
/* 3959 */       { if (!ok) JavaModelManager.getJavaModelManager().variablePut(variableName, null);  }  if (!ok) JavaModelManager.getJavaModelManager().variablePut(variableName, null);
/*      */     
/*      */     }
/* 3962 */     else if (JavaModelManager.CP_RESOLVE_VERBOSE_ADVANCED || JavaModelManager.CP_RESOLVE_VERBOSE_FAILURE) {
/* 3963 */       verbose_no_variable_initializer_found(variableName);
/*      */     } 
/* 3965 */     return variablePath;
/*      */   }
/*      */   
/*      */   private static void verbose_no_variable_initializer_found(String variableName) {
/* 3969 */     Util.verbose(
/* 3970 */         "CPVariable INIT - no initializer found\n\tvariable: " + 
/* 3971 */         variableName);
/*      */   }
/*      */   
/*      */   private static void verbose_variable_value_after_initialization(String variableName, IPath variablePath) {
/* 3975 */     Util.verbose(
/* 3976 */         "CPVariable INIT - after initialization\n\tvariable: " + 
/* 3977 */         variableName + '\n' + 
/* 3978 */         "\tvariable path: " + variablePath);
/*      */   }
/*      */   
/*      */   private static void verbose_triggering_variable_initialization(String variableName, ClasspathVariableInitializer initializer) {
/* 3982 */     Util.verbose(
/* 3983 */         "CPVariable INIT - triggering initialization\n\tvariable: " + 
/* 3984 */         variableName + '\n' + 
/* 3985 */         "\tinitializer: " + initializer);
/*      */   }
/*      */   
/*      */   private static void verbose_triggering_variable_initialization_invocation_trace() {
/* 3989 */     Util.verbose(
/* 3990 */         "CPVariable INIT - triggering initialization\n\tinvocation trace:");
/*      */     
/* 3992 */     (new Exception("<Fake exception>")).printStackTrace(System.out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getClasspathVariableDeprecationMessage(String variableName) {
/* 4003 */     JavaModelManager manager = JavaModelManager.getJavaModelManager();
/*      */ 
/*      */     
/* 4006 */     String message = (String)manager.deprecatedVariables.get(variableName);
/* 4007 */     if (message != null) {
/* 4008 */       return message;
/*      */     }
/*      */ 
/*      */     
/* 4012 */     IPath variablePath = manager.variableGet(variableName);
/* 4013 */     if (variablePath != null && variablePath != JavaModelManager.VARIABLE_INITIALIZATION_IN_PROGRESS) {
/* 4014 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 4018 */     Plugin jdtCorePlugin = getPlugin();
/* 4019 */     if (jdtCorePlugin == null) return null;
/*      */     
/* 4021 */     IExtensionPoint extension = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.jdt.core", "classpathVariableInitializer");
/* 4022 */     if (extension != null) {
/* 4023 */       IExtension[] extensions = extension.getExtensions();
/* 4024 */       for (int i = 0; i < extensions.length; i++) {
/* 4025 */         IConfigurationElement[] configElements = extensions[i].getConfigurationElements();
/* 4026 */         for (int j = 0; j < configElements.length; j++) {
/* 4027 */           IConfigurationElement configElement = configElements[j];
/* 4028 */           String varAttribute = configElement.getAttribute("variable");
/* 4029 */           if (variableName.equals(varAttribute)) {
/* 4030 */             String deprecatedAttribute = configElement.getAttribute("deprecated");
/* 4031 */             if (deprecatedAttribute != null) {
/* 4032 */               return deprecatedAttribute;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 4038 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ClasspathVariableInitializer getClasspathVariableInitializer(String variable) {
/* 4053 */     Plugin jdtCorePlugin = getPlugin();
/* 4054 */     if (jdtCorePlugin == null) return null;
/*      */     
/* 4056 */     IExtensionPoint extension = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.jdt.core", "classpathVariableInitializer");
/* 4057 */     if (extension != null) {
/* 4058 */       IExtension[] extensions = extension.getExtensions();
/* 4059 */       for (int i = 0; i < extensions.length; i++) {
/* 4060 */         IConfigurationElement[] configElements = extensions[i].getConfigurationElements();
/* 4061 */         for (int j = 0; j < configElements.length; j++) {
/* 4062 */           IConfigurationElement configElement = configElements[j];
/*      */           try {
/* 4064 */             String varAttribute = configElement.getAttribute("variable");
/* 4065 */             if (variable.equals(varAttribute)) {
/* 4066 */               if (JavaModelManager.CP_RESOLVE_VERBOSE_ADVANCED)
/* 4067 */                 verbose_found_variable_initializer(variable, configElement); 
/* 4068 */               Object execExt = configElement.createExecutableExtension("class");
/* 4069 */               if (execExt instanceof ClasspathVariableInitializer) {
/* 4070 */                 ClasspathVariableInitializer initializer = (ClasspathVariableInitializer)execExt;
/* 4071 */                 String deprecatedAttribute = configElement.getAttribute("deprecated");
/* 4072 */                 if (deprecatedAttribute != null) {
/* 4073 */                   (JavaModelManager.getJavaModelManager()).deprecatedVariables.put(variable, deprecatedAttribute);
/*      */                 }
/* 4075 */                 String readOnlyAttribute = configElement.getAttribute("readOnly");
/* 4076 */                 if ("true".equals(readOnlyAttribute)) {
/* 4077 */                   (JavaModelManager.getJavaModelManager()).readOnlyVariables.add(variable);
/*      */                 }
/* 4079 */                 return initializer;
/*      */               } 
/*      */             } 
/* 4082 */           } catch (CoreException e) {
/*      */             
/* 4084 */             if (JavaModelManager.CP_RESOLVE_VERBOSE || JavaModelManager.CP_RESOLVE_VERBOSE_FAILURE) {
/* 4085 */               verbose_failed_to_instanciate_variable_initializer(variable, configElement);
/* 4086 */               e.printStackTrace();
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 4092 */     return null;
/*      */   }
/*      */   
/*      */   private static void verbose_failed_to_instanciate_variable_initializer(String variable, IConfigurationElement configElement) {
/* 4096 */     Util.verbose(
/* 4097 */         "CPContainer INIT - failed to instanciate initializer\n\tvariable: " + 
/* 4098 */         variable + '\n' + 
/* 4099 */         "\tclass: " + configElement.getAttribute("class"), 
/* 4100 */         System.err);
/*      */   }
/*      */   
/*      */   private static void verbose_found_variable_initializer(String variable, IConfigurationElement configElement) {
/* 4104 */     Util.verbose(
/* 4105 */         "CPVariable INIT - found initializer\n\tvariable: " + 
/* 4106 */         variable + '\n' + 
/* 4107 */         "\tclass: " + configElement.getAttribute("class"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getClasspathVariableNames() {
/* 4121 */     return JavaModelManager.getJavaModelManager().variableNames();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Hashtable<String, String> getDefaultOptions() {
/* 4142 */     return JavaModelManager.getJavaModelManager().getDefaultOptions();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getEncoding() {
/*      */     try {
/* 4155 */       return ResourcesPlugin.getWorkspace().getRoot().getDefaultCharset();
/*      */     }
/* 4157 */     catch (IllegalStateException illegalStateException) {
/*      */ 
/*      */       
/* 4160 */       return System.getProperty("file.encoding");
/*      */     }
/* 4162 */     catch (CoreException coreException) {
/*      */ 
/*      */       
/* 4165 */       return ResourcesPlugin.getEncoding();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IResource[] getGeneratedResources(IRegion region, boolean includesNonJavaResources) {
/* 4190 */     if (region == null) throw new IllegalArgumentException("region cannot be null"); 
/* 4191 */     IJavaElement[] elements = region.getElements();
/* 4192 */     HashMap<Object, Object> projectsStates = new HashMap<>();
/* 4193 */     ArrayList<IResource> collector = new ArrayList();
/* 4194 */     for (int i = 0, max = elements.length; i < max; i++) {
/*      */       
/* 4196 */       IJavaElement element = elements[i];
/* 4197 */       IJavaProject javaProject = element.getJavaProject();
/* 4198 */       IProject project = javaProject.getProject();
/* 4199 */       State state = null;
/* 4200 */       State currentState = (State)projectsStates.get(project);
/* 4201 */       if (currentState != null) {
/* 4202 */         state = currentState;
/*      */       } else {
/* 4204 */         state = (State)JavaModelManager.getJavaModelManager().getLastBuiltState(project, null);
/* 4205 */         if (state != null) {
/* 4206 */           projectsStates.put(project, state);
/*      */         }
/*      */       } 
/* 4209 */       if (state != null)
/* 4210 */         if (element.getElementType() == 2) {
/* 4211 */           IPackageFragmentRoot[] roots = null;
/*      */           try {
/* 4213 */             roots = javaProject.getPackageFragmentRoots();
/* 4214 */           } catch (JavaModelException javaModelException) {}
/*      */ 
/*      */           
/* 4217 */           if (roots != null) {
/* 4218 */             IRegion region2 = newRegion();
/* 4219 */             for (int j = 0; j < roots.length; j++) {
/* 4220 */               region2.add(roots[j]);
/*      */             }
/* 4222 */             IResource[] res = getGeneratedResources(region2, includesNonJavaResources);
/* 4223 */             for (int k = 0, max2 = res.length; k < max2; k++) {
/* 4224 */               collector.add(res[k]);
/*      */             }
/*      */           } 
/*      */         } else {
/* 4228 */           IPath outputLocation = null;
/*      */           try {
/* 4230 */             outputLocation = javaProject.getOutputLocation();
/* 4231 */           } catch (JavaModelException javaModelException) {}
/*      */ 
/*      */           
/* 4234 */           IJavaElement root = element;
/* 4235 */           while (root != null && root.getElementType() != 3) {
/* 4236 */             root = root.getParent();
/*      */           }
/* 4238 */           if (root != null) {
/* 4239 */             IPackageFragmentRoot packageFragmentRoot = (IPackageFragmentRoot)root;
/* 4240 */             int rootPathSegmentCounts = packageFragmentRoot.getPath().segmentCount();
/*      */             try {
/* 4242 */               IClasspathEntry entry = packageFragmentRoot.getRawClasspathEntry();
/* 4243 */               IPath entryOutputLocation = entry.getOutputLocation();
/* 4244 */               if (entryOutputLocation != null) {
/* 4245 */                 outputLocation = entryOutputLocation;
/*      */               }
/* 4247 */             } catch (JavaModelException e) {
/* 4248 */               e.printStackTrace();
/*      */             } 
/* 4250 */             if (outputLocation != null) {
/* 4251 */               ICompilationUnit unit; IPackageFragment fragment; ICompilationUnit[] compilationUnits; int j; IPackageFragmentRoot fragmentRoot; int max2; IJavaElement[] children; int k, m; IContainer container = (IContainer)project.getWorkspace().getRoot().findMember(outputLocation);
/* 4252 */               switch (element.getElementType()) {
/*      */                 
/*      */                 case 5:
/* 4255 */                   unit = (ICompilationUnit)element;
/* 4256 */                   getGeneratedResource(unit, container, state, rootPathSegmentCounts, collector);
/*      */                   break;
/*      */                 
/*      */                 case 4:
/* 4260 */                   fragment = (IPackageFragment)element;
/* 4261 */                   compilationUnits = null;
/*      */                   try {
/* 4263 */                     compilationUnits = fragment.getCompilationUnits();
/* 4264 */                   } catch (JavaModelException javaModelException) {}
/*      */ 
/*      */                   
/* 4267 */                   if (compilationUnits == null)
/* 4268 */                     break;  for (j = 0, max2 = compilationUnits.length; j < max2; j++) {
/* 4269 */                     getGeneratedResource(compilationUnits[j], container, state, rootPathSegmentCounts, collector);
/*      */                   }
/* 4271 */                   if (includesNonJavaResources) {
/*      */                     
/* 4273 */                     Object[] nonJavaResources = null;
/*      */                     try {
/* 4275 */                       nonJavaResources = fragment.getNonJavaResources();
/* 4276 */                     } catch (JavaModelException javaModelException) {}
/*      */ 
/*      */                     
/* 4279 */                     if (nonJavaResources != null) {
/* 4280 */                       addNonJavaResources(nonJavaResources, container, rootPathSegmentCounts, collector);
/*      */                     }
/*      */                   } 
/*      */                   break;
/*      */                 
/*      */                 case 3:
/* 4286 */                   fragmentRoot = (IPackageFragmentRoot)element;
/* 4287 */                   if (fragmentRoot.isArchive())
/* 4288 */                     break;  children = null;
/*      */                   try {
/* 4290 */                     children = fragmentRoot.getChildren();
/* 4291 */                   } catch (JavaModelException javaModelException) {}
/*      */ 
/*      */                   
/* 4294 */                   if (children == null)
/* 4295 */                     break;  for (k = 0, m = children.length; k < m; k++) {
/* 4296 */                     fragment = (IPackageFragment)children[k];
/* 4297 */                     ICompilationUnit[] units = null;
/*      */                     try {
/* 4299 */                       units = fragment.getCompilationUnits();
/* 4300 */                     } catch (JavaModelException javaModelException) {}
/*      */ 
/*      */                     
/* 4303 */                     if (units != null) {
/* 4304 */                       for (int n = 0, max3 = units.length; n < max3; n++) {
/* 4305 */                         getGeneratedResource(units[n], container, state, rootPathSegmentCounts, collector);
/*      */                       }
/* 4307 */                       if (includesNonJavaResources)
/*      */                       
/* 4309 */                       { Object[] nonJavaResources = null;
/*      */                         try {
/* 4311 */                           nonJavaResources = fragment.getNonJavaResources();
/* 4312 */                         } catch (JavaModelException javaModelException) {}
/*      */ 
/*      */                         
/* 4315 */                         if (nonJavaResources != null)
/* 4316 */                           addNonJavaResources(nonJavaResources, container, rootPathSegmentCounts, collector);  } 
/*      */                     } 
/*      */                   }  break;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         }  
/* 4323 */     }  int size = collector.size();
/* 4324 */     if (size != 0) {
/* 4325 */       IResource[] result = new IResource[size];
/* 4326 */       collector.toArray(result);
/* 4327 */       return result;
/*      */     } 
/* 4329 */     return NO_GENERATED_RESOURCES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void getGeneratedResource(ICompilationUnit unit, IContainer container, State state, int rootPathSegmentCounts, ArrayList<IResource> collector) {
/* 4337 */     IResource resource = unit.getResource();
/* 4338 */     char[][] typeNames = state.getDefinedTypeNamesFor(resource.getProjectRelativePath().toString());
/* 4339 */     if (typeNames != null) {
/* 4340 */       IPath path = unit.getPath().removeFirstSegments(rootPathSegmentCounts).removeLastSegments(1);
/* 4341 */       for (int j = 0, max2 = typeNames.length; j < max2; j++) {
/* 4342 */         IPath localPath = path.append(String.valueOf(new String(typeNames[j])) + ".class");
/* 4343 */         IResource member = container.findMember(localPath);
/* 4344 */         if (member != null && member.exists()) {
/* 4345 */           collector.add(member);
/*      */         }
/*      */       } 
/*      */     } else {
/* 4349 */       IPath path = unit.getPath().removeFirstSegments(rootPathSegmentCounts).removeLastSegments(1);
/* 4350 */       path = path.append(String.valueOf(Util.getNameWithoutJavaLikeExtension(unit.getElementName())) + ".class");
/* 4351 */       IResource member = container.findMember(path);
/* 4352 */       if (member != null && member.exists()) {
/* 4353 */         collector.add(member);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static JavaCore getJavaCore() {
/* 4365 */     return (JavaCore)getPlugin();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getJavaLikeExtensions() {
/* 4381 */     return CharOperation.toStrings(Util.getJavaLikeExtensions());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getOption(String optionName) {
/* 4404 */     return JavaModelManager.getJavaModelManager().getOption(optionName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getOptionForConfigurableSeverity(int problemID) {
/* 4423 */     return CompilerOptions.optionKeyFromIrritant(ProblemReporter.getIrritant(problemID));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getOptionForConfigurableBuildPathProblemSeverity(int id) {
/* 4442 */     switch (id) {
/*      */       case 1001:
/* 4444 */         return "org.eclipse.jdt.core.circularClasspath";
/*      */       case 1004:
/* 4446 */         return "org.eclipse.jdt.core.incompatibleJDKLevel";
/*      */       case 1013:
/* 4448 */         return "org.eclipse.jdt.core.classpath.outputOverlappingAnotherSource";
/*      */       case 1017:
/* 4450 */         return "org.eclipse.jdt.core.classpath.mainOnlyProjectHasTestOnlyDependency";
/*      */       case 964:
/* 4452 */         return "org.eclipse.jdt.core.incompleteClasspath";
/*      */     } 
/* 4454 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Hashtable<String, String> getOptions() {
/* 4477 */     return JavaModelManager.getJavaModelManager().getOptions();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Plugin getPlugin() {
/* 4486 */     return JAVA_CORE_PLUGIN;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry getResolvedClasspathEntry(IClasspathEntry entry) {
/* 4513 */     return JavaModelManager.getJavaModelManager().resolveVariableEntry(entry, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IPath getResolvedVariablePath(IPath variablePath) {
/* 4524 */     return JavaModelManager.getJavaModelManager().getResolvedVariablePath(variablePath, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IWorkingCopy[] getSharedWorkingCopies(IBufferFactory factory) {
/* 4540 */     if (factory == null) factory = BufferManager.getDefaultBufferManager().getDefaultBufferFactory();
/*      */     
/* 4542 */     return (IWorkingCopy[])getWorkingCopies(BufferFactoryWrapper.create(factory));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getUserLibraryNames() {
/* 4552 */     return JavaModelManager.getUserLibraryManager().getUserLibraryNames();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ICompilationUnit[] getWorkingCopies(WorkingCopyOwner owner) {
/*      */     DefaultWorkingCopyOwner defaultWorkingCopyOwner;
/* 4566 */     JavaModelManager manager = JavaModelManager.getJavaModelManager();
/* 4567 */     if (owner == null) defaultWorkingCopyOwner = DefaultWorkingCopyOwner.PRIMARY; 
/* 4568 */     ICompilationUnit[] result = manager.getWorkingCopies((WorkingCopyOwner)defaultWorkingCopyOwner, false);
/* 4569 */     if (result == null) return JavaModelManager.NO_WORKING_COPY; 
/* 4570 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void initializeAfterLoad(IProgressMonitor monitor) throws CoreException {
/* 4600 */     SubMonitor mainMonitor = SubMonitor.convert(monitor, Messages.javamodel_initialization, 100);
/* 4601 */     mainMonitor.subTask(Messages.javamodel_configuring_classpath_containers);
/*      */ 
/*      */     
/* 4604 */     JavaModelManager manager = JavaModelManager.getJavaModelManager();
/*      */     try {
/* 4606 */       SubMonitor subMonitor = mainMonitor.split(50).setWorkRemaining(100);
/* 4607 */       subMonitor.split(5);
/* 4608 */       manager.batchContainerInitializationsProgress.initializeAfterLoadMonitor.set(subMonitor);
/* 4609 */       if (manager.forceBatchInitializations(true)) {
/* 4610 */         manager.getClasspathContainer((IPath)Path.EMPTY, null);
/*      */       } else {
/* 4612 */         while (manager.batchContainerInitializations == 2) {
/* 4613 */           subMonitor.subTask(manager.batchContainerInitializationsProgress.subTaskName);
/* 4614 */           subMonitor.split(manager.batchContainerInitializationsProgress.getWorked());
/* 4615 */           synchronized (manager) {
/*      */             try {
/* 4617 */               manager.wait(100L);
/* 4618 */             } catch (InterruptedException interruptedException) {}
/*      */           }
/*      */         
/*      */         } 
/*      */       } 
/*      */     } finally {
/*      */       
/* 4625 */       manager.batchContainerInitializationsProgress.initializeAfterLoadMonitor.remove();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4630 */     mainMonitor.subTask(Messages.javamodel_resetting_source_attachment_properties);
/* 4631 */     final IJavaProject[] projects = manager.getJavaModel().getJavaProjects();
/* 4632 */     HashSet<IPath> visitedPaths = new HashSet();
/* 4633 */     ExternalFoldersManager externalFoldersManager = JavaModelManager.getExternalManager();
/* 4634 */     for (int i = 0, length = projects.length; i < length; i++) {
/* 4635 */       IClasspathEntry[] classpath; JavaProject javaProject = (JavaProject)projects[i];
/*      */       
/*      */       try {
/* 4638 */         classpath = javaProject.getResolvedClasspath();
/* 4639 */       } catch (JavaModelException javaModelException) {}
/*      */ 
/*      */ 
/*      */       
/* 4643 */       if (classpath != null) {
/* 4644 */         for (int j = 0, length2 = classpath.length; j < length2; j++) {
/* 4645 */           IClasspathEntry entry = classpath[j];
/* 4646 */           if (entry.getSourceAttachmentPath() != null) {
/* 4647 */             IPath entryPath = entry.getPath();
/* 4648 */             if (visitedPaths.add(entryPath)) {
/* 4649 */               Util.setSourceAttachmentProperty(entryPath, null);
/*      */             }
/*      */           } 
/*      */           
/* 4653 */           if (entry.getEntryKind() == 1) {
/* 4654 */             IPath entryPath = entry.getPath();
/* 4655 */             if (ExternalFoldersManager.isExternalFolderPath(entryPath) && externalFoldersManager.getFolder(entryPath) == null) {
/* 4656 */               externalFoldersManager.addFolder(entryPath, true);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */     try {
/* 4663 */       externalFoldersManager.createPendingFolders((IProgressMonitor)mainMonitor.split(1));
/*      */     }
/* 4665 */     catch (JavaModelException jme) {
/*      */       
/* 4667 */       Util.log((Throwable)jme, "Error while processing external folders");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4672 */     JavaModel model = manager.getJavaModel();
/*      */     try {
/* 4674 */       mainMonitor.subTask(Messages.javamodel_refreshing_external_jars);
/* 4675 */       model.refreshExternalArchives(
/* 4676 */           null, 
/* 4677 */           (IProgressMonitor)mainMonitor.split(1));
/*      */     }
/* 4679 */     catch (JavaModelException javaModelException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4684 */     mainMonitor.subTask(Messages.javamodel_initializing_delta_state);
/* 4685 */     manager.deltaState.rootsAreStale = true;
/* 4686 */     manager.deltaState.initializeRoots(true);
/*      */ 
/*      */     
/* 4689 */     mainMonitor.subTask(Messages.javamodel_configuring_searchengine);
/*      */     
/* 4691 */     updateLegacyIndex((IProgressMonitor)mainMonitor.split(47));
/*      */ 
/*      */ 
/*      */     
/* 4695 */     mainMonitor.subTask(Messages.javamodel_getting_build_state_number);
/* 4696 */     QualifiedName qName = new QualifiedName("org.eclipse.jdt.core", "stateVersionNumber");
/* 4697 */     IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
/* 4698 */     String str1 = null;
/*      */     try {
/* 4700 */       str1 = root.getPersistentProperty(qName);
/* 4701 */     } catch (CoreException coreException) {}
/*      */ 
/*      */     
/* 4704 */     String newVersionNumber = Byte.toString((byte)38);
/* 4705 */     if (!newVersionNumber.equals(str1)) {
/*      */       
/* 4707 */       if (JavaBuilder.DEBUG)
/* 4708 */         System.out.println("Build state version number has changed"); 
/* 4709 */       IWorkspaceRunnable runnable = new IWorkspaceRunnable()
/*      */         {
/*      */           public void run(IProgressMonitor progressMonitor2) throws CoreException {
/* 4712 */             for (int i = 0, length = projects.length; i < length; i++) {
/* 4713 */               IJavaProject project = projects[i];
/*      */               try {
/* 4715 */                 if (JavaBuilder.DEBUG)
/* 4716 */                   System.out.println("Touching " + project.getElementName()); 
/* 4717 */                 (new ClasspathValidation((JavaProject)project)).validate();
/* 4718 */                 project.getProject().touch(progressMonitor2);
/* 4719 */               } catch (CoreException coreException) {}
/*      */             } 
/*      */           }
/*      */         };
/*      */ 
/*      */       
/* 4725 */       mainMonitor.subTask(Messages.javamodel_building_after_upgrade);
/*      */       try {
/* 4727 */         ResourcesPlugin.getWorkspace().run(runnable, (IProgressMonitor)mainMonitor.split(1));
/* 4728 */       } catch (CoreException coreException) {}
/*      */ 
/*      */       
/*      */       try {
/* 4732 */         root.setPersistentProperty(qName, newVersionNumber);
/* 4733 */       } catch (CoreException e) {
/* 4734 */         Util.log((Throwable)e, "Could not persist build state version number");
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void updateLegacyIndex(IProgressMonitor monitor) {
/* 4740 */     SearchEngine engine = new SearchEngine();
/* 4741 */     IJavaSearchScope scope = SearchEngine.createWorkspaceScope();
/*      */     try {
/* 4743 */       engine.searchAllTypeNames(
/* 4744 */           null, 
/* 4745 */           0, 
/* 4746 */           "!@$#!@".toCharArray(), 
/* 4747 */           10, 
/* 4748 */           5, 
/* 4749 */           scope, 
/* 4750 */           new TypeNameRequestor()
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public void acceptType(int modifiers, char[] packageName, char[] simpleTypeName, char[][] enclosingTypeNames, String path) {}
/*      */           }, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4763 */           2, 
/* 4764 */           monitor);
/*      */     }
/* 4766 */     catch (JavaModelException javaModelException) {
/*      */     
/* 4768 */     } catch (OperationCanceledException e) {
/* 4769 */       if (monitor.isCanceled()) {
/* 4770 */         throw e;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isClasspathVariableReadOnly(String variableName) {
/* 4784 */     return (JavaModelManager.getJavaModelManager()).readOnlyVariables.contains(variableName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isJavaLikeFileName(String fileName) {
/* 4795 */     return Util.isJavaLikeFileName(fileName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isReferencedBy(IJavaElement element, IMarker marker) throws CoreException {
/* 4810 */     if (element instanceof IMember) {
/* 4811 */       IMember member = (IMember)element;
/* 4812 */       if (member.isBinary()) {
/* 4813 */         element = member.getClassFile();
/*      */       } else {
/* 4815 */         element = member.getCompilationUnit();
/*      */       } 
/*      */     } 
/* 4818 */     if (element == null) return false; 
/* 4819 */     if (marker == null) return false;
/*      */     
/* 4821 */     String markerHandleId = (String)marker.getAttribute("org.eclipse.jdt.internal.core.JavaModelManager.handleId");
/* 4822 */     if (markerHandleId == null) return false;
/*      */     
/* 4824 */     IJavaElement markerElement = create(markerHandleId);
/*      */     while (true) {
/* 4826 */       if (element.equals(markerElement)) return true;
/*      */ 
/*      */       
/* 4829 */       if (markerElement instanceof IOrdinaryClassFile) {
/* 4830 */         IType enclosingType = ((IOrdinaryClassFile)markerElement).getType().getDeclaringType();
/* 4831 */         if (enclosingType != null) {
/* 4832 */           markerElement = enclosingType.getClassFile();
/*      */           continue;
/*      */         } 
/*      */       } 
/*      */       break;
/*      */     } 
/* 4838 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isReferencedBy(IJavaElement element, IMarkerDelta markerDelta) throws CoreException {
/* 4853 */     if (element instanceof IMember) {
/* 4854 */       IMember member = (IMember)element;
/* 4855 */       if (member.isBinary()) {
/* 4856 */         element = member.getClassFile();
/*      */       } else {
/* 4858 */         element = member.getCompilationUnit();
/*      */       } 
/*      */     } 
/* 4861 */     if (element == null) return false; 
/* 4862 */     if (markerDelta == null) return false;
/*      */     
/* 4864 */     String markerDeltarHandleId = (String)markerDelta.getAttribute("org.eclipse.jdt.internal.core.JavaModelManager.handleId");
/* 4865 */     if (markerDeltarHandleId == null) return false;
/*      */     
/* 4867 */     IJavaElement markerElement = create(markerDeltarHandleId);
/*      */     while (true) {
/* 4869 */       if (element.equals(markerElement)) return true;
/*      */ 
/*      */       
/* 4872 */       if (markerElement instanceof IOrdinaryClassFile) {
/* 4873 */         IType enclosingType = ((IOrdinaryClassFile)markerElement).getType().getDeclaringType();
/* 4874 */         if (enclosingType != null) {
/* 4875 */           markerElement = enclosingType.getClassFile();
/*      */           continue;
/*      */         } 
/*      */       } 
/*      */       break;
/*      */     } 
/* 4881 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IAccessRule newAccessRule(IPath filePattern, int kind) {
/* 4902 */     return JavaModelManager.getJavaModelManager().getAccessRule(filePattern, kind);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathAttribute newClasspathAttribute(String name, String value) {
/* 4912 */     return (IClasspathAttribute)new ClasspathAttribute(name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newContainerEntry(IPath containerPath) {
/* 4929 */     return newContainerEntry(
/* 4930 */         containerPath, 
/* 4931 */         ClasspathEntry.NO_ACCESS_RULES, 
/* 4932 */         ClasspathEntry.NO_EXTRA_ATTRIBUTES, 
/* 4933 */         false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newContainerEntry(IPath containerPath, boolean isExported) {
/* 4953 */     return newContainerEntry(
/* 4954 */         containerPath, 
/* 4955 */         ClasspathEntry.NO_ACCESS_RULES, 
/* 4956 */         ClasspathEntry.NO_EXTRA_ATTRIBUTES, 
/* 4957 */         isExported);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newContainerEntry(IPath containerPath, IAccessRule[] accessRules, IClasspathAttribute[] extraAttributes, boolean isExported) {
/* 5042 */     if (containerPath == null)
/* 5043 */       throw new ClasspathEntry.AssertionFailedException("Container path cannot be null"); 
/* 5044 */     if (containerPath.segmentCount() < 1) {
/* 5045 */       throw new ClasspathEntry.AssertionFailedException("Illegal classpath container path: '" + containerPath.makeRelative().toString() + "', must have at least one segment (containerID+hints)");
/*      */     }
/* 5047 */     if (accessRules == null || accessRules.length == 0) {
/* 5048 */       accessRules = ClasspathEntry.NO_ACCESS_RULES;
/*      */     }
/* 5050 */     if (extraAttributes == null || extraAttributes.length == 0) {
/* 5051 */       extraAttributes = ClasspathEntry.NO_EXTRA_ATTRIBUTES;
/*      */     }
/* 5053 */     return (IClasspathEntry)new ClasspathEntry(
/* 5054 */         1, 
/* 5055 */         5, 
/* 5056 */         containerPath, 
/* 5057 */         ClasspathEntry.INCLUDE_ALL, 
/* 5058 */         ClasspathEntry.EXCLUDE_NONE, 
/* 5059 */         null, 
/* 5060 */         null, 
/* 5061 */         null, 
/* 5062 */         isExported, 
/* 5063 */         accessRules, 
/* 5064 */         true, 
/* 5065 */         extraAttributes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ITypeHierarchy newTypeHierarchy(IRegion region, WorkingCopyOwner owner, IProgressMonitor monitor) throws JavaModelException {
/* 5091 */     if (region == null) {
/* 5092 */       throw new IllegalArgumentException(Messages.hierarchy_nullRegion);
/*      */     }
/* 5094 */     ICompilationUnit[] workingCopies = JavaModelManager.getJavaModelManager().getWorkingCopies(owner, true);
/* 5095 */     CreateTypeHierarchyOperation op = 
/* 5096 */       new CreateTypeHierarchyOperation(region, workingCopies, null, true);
/* 5097 */     op.runOperation(monitor);
/* 5098 */     return op.getResult();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newLibraryEntry(IPath path, IPath sourceAttachmentPath, IPath sourceAttachmentRootPath) {
/* 5123 */     return newLibraryEntry(
/* 5124 */         path, 
/* 5125 */         sourceAttachmentPath, 
/* 5126 */         sourceAttachmentRootPath, 
/* 5127 */         ClasspathEntry.NO_ACCESS_RULES, 
/* 5128 */         ClasspathEntry.NO_EXTRA_ATTRIBUTES, 
/* 5129 */         false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newLibraryEntry(IPath path, IPath sourceAttachmentPath, IPath sourceAttachmentRootPath, boolean isExported) {
/* 5160 */     return newLibraryEntry(
/* 5161 */         path, 
/* 5162 */         sourceAttachmentPath, 
/* 5163 */         sourceAttachmentRootPath, 
/* 5164 */         ClasspathEntry.NO_ACCESS_RULES, 
/* 5165 */         ClasspathEntry.NO_EXTRA_ATTRIBUTES, 
/* 5166 */         isExported);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newLibraryEntry(IPath path, IPath sourceAttachmentPath, IPath sourceAttachmentRootPath, IAccessRule[] accessRules, IClasspathAttribute[] extraAttributes, boolean isExported) {
/* 5245 */     if (path == null) throw new ClasspathEntry.AssertionFailedException("Library path cannot be null"); 
/* 5246 */     if (accessRules == null || accessRules.length == 0) {
/* 5247 */       accessRules = ClasspathEntry.NO_ACCESS_RULES;
/*      */     }
/* 5249 */     if (extraAttributes == null || extraAttributes.length == 0) {
/* 5250 */       extraAttributes = ClasspathEntry.NO_EXTRA_ATTRIBUTES;
/*      */     }
/* 5252 */     boolean hasDotDot = ClasspathEntry.hasDotDot(path);
/* 5253 */     if (!hasDotDot && !path.isAbsolute()) throw new ClasspathEntry.AssertionFailedException("Path for IClasspathEntry must be absolute: " + path); 
/* 5254 */     if (sourceAttachmentPath != null) {
/* 5255 */       if (sourceAttachmentPath.isEmpty()) {
/* 5256 */         sourceAttachmentPath = null;
/* 5257 */       } else if (!sourceAttachmentPath.isAbsolute()) {
/* 5258 */         throw new ClasspathEntry.AssertionFailedException("Source attachment path '" + 
/* 5259 */             sourceAttachmentPath + 
/* 5260 */             "' for IClasspathEntry must be absolute");
/*      */       } 
/*      */     }
/* 5263 */     return (IClasspathEntry)new ClasspathEntry(
/* 5264 */         2, 
/* 5265 */         1, 
/* 5266 */         hasDotDot ? path : JavaProject.createPackageFragementKey(path), 
/* 5267 */         ClasspathEntry.INCLUDE_ALL, 
/* 5268 */         ClasspathEntry.EXCLUDE_NONE, 
/* 5269 */         sourceAttachmentPath, 
/* 5270 */         sourceAttachmentRootPath, 
/* 5271 */         null, 
/* 5272 */         isExported, 
/* 5273 */         accessRules, 
/* 5274 */         false, 
/* 5275 */         extraAttributes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newProjectEntry(IPath path) {
/* 5291 */     return newProjectEntry(path, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newProjectEntry(IPath path, boolean isExported) {
/* 5311 */     if (!path.isAbsolute()) throw new ClasspathEntry.AssertionFailedException("Path for IClasspathEntry must be absolute");
/*      */     
/* 5313 */     return newProjectEntry(
/* 5314 */         path, 
/* 5315 */         ClasspathEntry.NO_ACCESS_RULES, 
/* 5316 */         true, 
/* 5317 */         ClasspathEntry.NO_EXTRA_ATTRIBUTES, 
/* 5318 */         isExported);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newProjectEntry(IPath path, IAccessRule[] accessRules, boolean combineAccessRules, IClasspathAttribute[] extraAttributes, boolean isExported) {
/* 5376 */     if (!path.isAbsolute()) throw new ClasspathEntry.AssertionFailedException("Path for IClasspathEntry must be absolute"); 
/* 5377 */     if (accessRules == null || accessRules.length == 0) {
/* 5378 */       accessRules = ClasspathEntry.NO_ACCESS_RULES;
/*      */     }
/* 5380 */     if (extraAttributes == null || extraAttributes.length == 0) {
/* 5381 */       extraAttributes = ClasspathEntry.NO_EXTRA_ATTRIBUTES;
/*      */     }
/* 5383 */     return (IClasspathEntry)new ClasspathEntry(
/* 5384 */         1, 
/* 5385 */         2, 
/* 5386 */         path, 
/* 5387 */         ClasspathEntry.INCLUDE_ALL, 
/* 5388 */         ClasspathEntry.EXCLUDE_NONE, 
/* 5389 */         null, 
/* 5390 */         null, 
/* 5391 */         null, 
/* 5392 */         isExported, 
/* 5393 */         accessRules, 
/* 5394 */         combineAccessRules, 
/* 5395 */         extraAttributes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRegion newRegion() {
/* 5404 */     return (IRegion)new Region();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newSourceEntry(IPath path) {
/* 5424 */     return newSourceEntry(path, ClasspathEntry.INCLUDE_ALL, ClasspathEntry.EXCLUDE_NONE, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newSourceEntry(IPath path, IPath[] exclusionPatterns) {
/* 5448 */     return newSourceEntry(path, ClasspathEntry.INCLUDE_ALL, exclusionPatterns, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newSourceEntry(IPath path, IPath[] exclusionPatterns, IPath specificOutputLocation) {
/* 5474 */     return newSourceEntry(path, ClasspathEntry.INCLUDE_ALL, exclusionPatterns, specificOutputLocation);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newSourceEntry(IPath path, IPath[] inclusionPatterns, IPath[] exclusionPatterns, IPath specificOutputLocation) {
/* 5501 */     return newSourceEntry(path, inclusionPatterns, exclusionPatterns, specificOutputLocation, ClasspathEntry.NO_EXTRA_ATTRIBUTES);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newSourceEntry(IPath path, IPath[] inclusionPatterns, IPath[] exclusionPatterns, IPath specificOutputLocation, IClasspathAttribute[] extraAttributes) {
/* 5583 */     if (path == null) throw new ClasspathEntry.AssertionFailedException("Source path cannot be null"); 
/* 5584 */     if (!path.isAbsolute()) throw new ClasspathEntry.AssertionFailedException("Path for IClasspathEntry must be absolute"); 
/* 5585 */     if (exclusionPatterns == null) {
/* 5586 */       exclusionPatterns = ClasspathEntry.EXCLUDE_NONE;
/*      */     }
/* 5588 */     if (inclusionPatterns == null) {
/* 5589 */       inclusionPatterns = ClasspathEntry.INCLUDE_ALL;
/*      */     }
/* 5591 */     if (extraAttributes == null) {
/* 5592 */       extraAttributes = ClasspathEntry.NO_EXTRA_ATTRIBUTES;
/*      */     }
/* 5594 */     return (IClasspathEntry)new ClasspathEntry(
/* 5595 */         1, 
/* 5596 */         3, 
/* 5597 */         path, 
/* 5598 */         inclusionPatterns, 
/* 5599 */         exclusionPatterns, 
/* 5600 */         null, 
/* 5601 */         null, 
/* 5602 */         specificOutputLocation, 
/* 5603 */         false, 
/* 5604 */         null, 
/* 5605 */         false, 
/* 5606 */         extraAttributes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newVariableEntry(IPath variablePath, IPath variableSourceAttachmentPath, IPath sourceAttachmentRootPath) {
/* 5630 */     return newVariableEntry(variablePath, variableSourceAttachmentPath, sourceAttachmentRootPath, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newVariableEntry(IPath variablePath, IPath variableSourceAttachmentPath, IPath variableSourceAttachmentRootPath, boolean isExported) {
/* 5658 */     return newVariableEntry(
/* 5659 */         variablePath, 
/* 5660 */         variableSourceAttachmentPath, 
/* 5661 */         variableSourceAttachmentRootPath, 
/* 5662 */         ClasspathEntry.NO_ACCESS_RULES, 
/* 5663 */         ClasspathEntry.NO_EXTRA_ATTRIBUTES, 
/* 5664 */         isExported);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry newVariableEntry(IPath variablePath, IPath variableSourceAttachmentPath, IPath variableSourceAttachmentRootPath, IAccessRule[] accessRules, IClasspathAttribute[] extraAttributes, boolean isExported) {
/* 5737 */     if (variablePath == null) throw new ClasspathEntry.AssertionFailedException("Variable path cannot be null"); 
/* 5738 */     if (variablePath.segmentCount() < 1) {
/* 5739 */       throw new ClasspathEntry.AssertionFailedException("Illegal classpath variable path: '" + variablePath.makeRelative().toString() + "', must have at least one segment");
/*      */     }
/* 5741 */     if (accessRules == null || accessRules.length == 0) {
/* 5742 */       accessRules = ClasspathEntry.NO_ACCESS_RULES;
/*      */     }
/* 5744 */     if (extraAttributes == null || extraAttributes.length == 0) {
/* 5745 */       extraAttributes = ClasspathEntry.NO_EXTRA_ATTRIBUTES;
/*      */     }
/*      */     
/* 5748 */     return (IClasspathEntry)new ClasspathEntry(
/* 5749 */         1, 
/* 5750 */         4, 
/* 5751 */         variablePath, 
/* 5752 */         ClasspathEntry.INCLUDE_ALL, 
/* 5753 */         ClasspathEntry.EXCLUDE_NONE, 
/* 5754 */         variableSourceAttachmentPath, 
/* 5755 */         variableSourceAttachmentRootPath, 
/* 5756 */         null, 
/* 5757 */         isExported, 
/* 5758 */         accessRules, 
/* 5759 */         false, 
/* 5760 */         extraAttributes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry[] getReferencedClasspathEntries(IClasspathEntry libraryEntry, IJavaProject project) {
/* 5788 */     JavaModelManager manager = JavaModelManager.getJavaModelManager();
/* 5789 */     return manager.getReferencedClasspathEntries(libraryEntry, project);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void removeClasspathVariable(String variableName) {
/* 5809 */     removeClasspathVariable(variableName, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void removeClasspathVariable(String variableName, IProgressMonitor monitor) {
/*      */     try {
/* 5829 */       SetVariablesOperation operation = new SetVariablesOperation(new String[] { variableName }, new IPath[1], true);
/* 5830 */       operation.runOperation(monitor);
/* 5831 */     } catch (JavaModelException e) {
/* 5832 */       Util.log((Throwable)e, "Exception while removing variable " + variableName);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void removeElementChangedListener(IElementChangedListener listener) {
/* 5843 */     JavaModelManager.getDeltaState().removeElementChangedListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removeJavaLikeExtension(String fileName) {
/* 5856 */     return Util.getNameWithoutJavaLikeExtension(fileName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void removePreProcessingResourceChangedListener(IResourceChangeListener listener) {
/* 5869 */     JavaModelManager.getDeltaState().removePreResourceChangedListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rebuildIndex(IProgressMonitor monitor) throws CoreException {
/* 5882 */     SubMonitor subMonitor = SubMonitor.convert(monitor, 100);
/* 5883 */     IndexManager manager = JavaModelManager.getIndexManager();
/* 5884 */     manager.deleteIndexFiles((IProgressMonitor)subMonitor.split(1));
/* 5885 */     manager.reset();
/* 5886 */     updateLegacyIndex((IProgressMonitor)subMonitor.split(4));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void run(IWorkspaceRunnable action, IProgressMonitor monitor) throws CoreException {
/* 5918 */     run(action, (ISchedulingRule)ResourcesPlugin.getWorkspace().getRoot(), monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void run(IWorkspaceRunnable action, ISchedulingRule rule, IProgressMonitor monitor) throws CoreException {
/* 5956 */     IWorkspace workspace = ResourcesPlugin.getWorkspace();
/* 5957 */     if (workspace.isTreeLocked()) {
/* 5958 */       (new BatchOperation(action)).run(monitor);
/*      */     } else {
/*      */       
/* 5961 */       workspace.run((IWorkspaceRunnable)new BatchOperation(action), rule, 1, monitor);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setClasspathContainer(IPath containerPath, IJavaProject[] affectedProjects, IClasspathContainer[] respectiveContainers, IProgressMonitor monitor) throws JavaModelException {
/* 6016 */     if (affectedProjects.length != respectiveContainers.length)
/* 6017 */       throw new ClasspathEntry.AssertionFailedException("Projects and containers collections should have the same size"); 
/* 6018 */     if (affectedProjects.length == 1) {
/* 6019 */       IClasspathContainer container = respectiveContainers[0];
/* 6020 */       if (container != null) {
/* 6021 */         JavaModelManager manager = JavaModelManager.getJavaModelManager();
/* 6022 */         IJavaProject project = affectedProjects[0];
/* 6023 */         IClasspathContainer existingCointainer = manager.containerGet(project, containerPath);
/* 6024 */         if (existingCointainer == JavaModelManager.CONTAINER_INITIALIZATION_IN_PROGRESS) {
/* 6025 */           manager.containerBeingInitializedPut(project, containerPath, container);
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 6030 */     SetContainerOperation operation = new SetContainerOperation(containerPath, affectedProjects, respectiveContainers);
/* 6031 */     operation.runOperation(monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setClasspathVariable(String variableName, IPath path) throws JavaModelException {
/* 6055 */     setClasspathVariable(variableName, path, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setClasspathVariable(String variableName, IPath path, IProgressMonitor monitor) throws JavaModelException {
/* 6085 */     if (path == null) throw new ClasspathEntry.AssertionFailedException("Variable path cannot be null"); 
/* 6086 */     setClasspathVariables(new String[] { variableName }, new IPath[] { path }, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setClasspathVariables(String[] variableNames, IPath[] paths, IProgressMonitor monitor) throws JavaModelException {
/* 6125 */     if (variableNames.length != paths.length) throw new ClasspathEntry.AssertionFailedException("Variable names and paths collections should have the same size"); 
/* 6126 */     SetVariablesOperation operation = new SetVariablesOperation(variableNames, paths, true);
/* 6127 */     operation.runOperation(monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setComplianceOptions(String compliance, Map<String, String> options) {
/* 6156 */     long jdkLevel = CompilerOptions.versionToJdkLevel(compliance);
/* 6157 */     int major = (int)(jdkLevel >>> 16L);
/* 6158 */     switch (major) {
/*      */       case 47:
/* 6160 */         options.put("org.eclipse.jdt.core.compiler.compliance", "1.3");
/* 6161 */         options.put("org.eclipse.jdt.core.compiler.source", "1.3");
/* 6162 */         options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.1");
/* 6163 */         options.put("org.eclipse.jdt.core.compiler.problem.assertIdentifier", "ignore");
/* 6164 */         options.put("org.eclipse.jdt.core.compiler.problem.enumIdentifier", "ignore");
/*      */         return;
/*      */       case 48:
/* 6167 */         options.put("org.eclipse.jdt.core.compiler.compliance", "1.4");
/* 6168 */         options.put("org.eclipse.jdt.core.compiler.source", "1.3");
/* 6169 */         options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.2");
/* 6170 */         options.put("org.eclipse.jdt.core.compiler.problem.assertIdentifier", "warning");
/* 6171 */         options.put("org.eclipse.jdt.core.compiler.problem.enumIdentifier", "warning");
/*      */         return;
/*      */       case 49:
/* 6174 */         options.put("org.eclipse.jdt.core.compiler.compliance", "1.5");
/* 6175 */         options.put("org.eclipse.jdt.core.compiler.source", "1.5");
/* 6176 */         options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.5");
/* 6177 */         options.put("org.eclipse.jdt.core.compiler.problem.assertIdentifier", "error");
/* 6178 */         options.put("org.eclipse.jdt.core.compiler.problem.enumIdentifier", "error");
/* 6179 */         options.put("org.eclipse.jdt.core.compiler.codegen.inlineJsrBytecode", "enabled");
/*      */         return;
/*      */       case 50:
/* 6182 */         options.put("org.eclipse.jdt.core.compiler.compliance", "1.6");
/* 6183 */         options.put("org.eclipse.jdt.core.compiler.source", "1.6");
/* 6184 */         options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.6");
/* 6185 */         options.put("org.eclipse.jdt.core.compiler.problem.assertIdentifier", "error");
/* 6186 */         options.put("org.eclipse.jdt.core.compiler.problem.enumIdentifier", "error");
/* 6187 */         options.put("org.eclipse.jdt.core.compiler.codegen.inlineJsrBytecode", "enabled");
/*      */         return;
/*      */       case 51:
/* 6190 */         options.put("org.eclipse.jdt.core.compiler.compliance", "1.7");
/* 6191 */         options.put("org.eclipse.jdt.core.compiler.source", "1.7");
/* 6192 */         options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.7");
/* 6193 */         options.put("org.eclipse.jdt.core.compiler.problem.assertIdentifier", "error");
/* 6194 */         options.put("org.eclipse.jdt.core.compiler.problem.enumIdentifier", "error");
/* 6195 */         options.put("org.eclipse.jdt.core.compiler.codegen.inlineJsrBytecode", "enabled");
/*      */         return;
/*      */       case 52:
/* 6198 */         options.put("org.eclipse.jdt.core.compiler.compliance", "1.8");
/* 6199 */         options.put("org.eclipse.jdt.core.compiler.source", "1.8");
/* 6200 */         options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "1.8");
/* 6201 */         options.put("org.eclipse.jdt.core.compiler.problem.assertIdentifier", "error");
/* 6202 */         options.put("org.eclipse.jdt.core.compiler.problem.enumIdentifier", "error");
/* 6203 */         options.put("org.eclipse.jdt.core.compiler.codegen.inlineJsrBytecode", "enabled");
/*      */         return;
/*      */       case 53:
/* 6206 */         options.put("org.eclipse.jdt.core.compiler.compliance", "9");
/* 6207 */         options.put("org.eclipse.jdt.core.compiler.source", "9");
/* 6208 */         options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "9");
/* 6209 */         options.put("org.eclipse.jdt.core.compiler.problem.assertIdentifier", "error");
/* 6210 */         options.put("org.eclipse.jdt.core.compiler.problem.enumIdentifier", "error");
/* 6211 */         options.put("org.eclipse.jdt.core.compiler.codegen.inlineJsrBytecode", "enabled");
/* 6212 */         options.put("org.eclipse.jdt.core.compiler.release", "enabled");
/*      */         return;
/*      */       case 54:
/* 6215 */         options.put("org.eclipse.jdt.core.compiler.compliance", "10");
/* 6216 */         options.put("org.eclipse.jdt.core.compiler.source", "10");
/* 6217 */         options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "10");
/* 6218 */         options.put("org.eclipse.jdt.core.compiler.problem.assertIdentifier", "error");
/* 6219 */         options.put("org.eclipse.jdt.core.compiler.problem.enumIdentifier", "error");
/* 6220 */         options.put("org.eclipse.jdt.core.compiler.codegen.inlineJsrBytecode", "enabled");
/* 6221 */         options.put("org.eclipse.jdt.core.compiler.release", "enabled");
/*      */         return;
/*      */     } 
/* 6224 */     if (major > 54) {
/* 6225 */       String version = CompilerOptions.versionFromJdkLevel(jdkLevel);
/* 6226 */       options.put("org.eclipse.jdt.core.compiler.compliance", version);
/* 6227 */       options.put("org.eclipse.jdt.core.compiler.source", version);
/* 6228 */       options.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", version);
/* 6229 */       options.put("org.eclipse.jdt.core.compiler.problem.assertIdentifier", "error");
/* 6230 */       options.put("org.eclipse.jdt.core.compiler.problem.enumIdentifier", "error");
/* 6231 */       options.put("org.eclipse.jdt.core.compiler.codegen.inlineJsrBytecode", "enabled");
/* 6232 */       options.put("org.eclipse.jdt.core.compiler.release", "enabled");
/* 6233 */       options.put("org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures", "disabled");
/* 6234 */       options.put("org.eclipse.jdt.core.compiler.problem.reportPreviewFeatures", "warning");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setOptions(Hashtable<String, String> newOptions) {
/* 6260 */     JavaModelManager.getJavaModelManager().setOptions(newOptions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String latestSupportedJavaVersion() {
/* 6271 */     return allVersions.get(allVersions.size() - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compareJavaVersions(String first, String second) {
/* 6287 */     return Long.compare(CompilerOptions.versionToJdkLevel(first), CompilerOptions.versionToJdkLevel(second));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getReferencedModules(IJavaProject project) throws CoreException {
/* 6308 */     return ModuleUtil.getReferencedModules(project);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IModuleDescription getAutomaticModuleDescription(IJavaElement element) throws JavaModelException, IllegalArgumentException {
/* 6328 */     switch (element.getElementType()) {
/*      */       case 2:
/* 6330 */         return ((JavaProject)element).getAutomaticModuleDescription();
/*      */       case 3:
/* 6332 */         return ((PackageFragmentRoot)element).getAutomaticModuleDescription();
/*      */     } 
/* 6334 */     throw new IllegalArgumentException("Illegal kind of java element: " + element.getElementType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> defaultRootModules(Iterable<IPackageFragmentRoot> allSystemRoots) {
/* 6345 */     return JavaProject.defaultRootModules(allSystemRoots);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] compileWithAttributes(IModuleDescription module, Map<String, String> classFileAttributes) throws JavaModelException, IllegalArgumentException {
/* 6379 */     return (new ModuleInfoBuilder()).compileWithAttributes(module, classFileAttributes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getModuleNameFromJar(File file) {
/* 6392 */     if (!file.isFile()) {
/* 6393 */       return null;
/*      */     }
/*      */     
/* 6396 */     char[] moduleName = null; try {
/* 6397 */       Exception exception2, exception1 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 6406 */     catch (ClassFormatException|java.io.IOException ex) {
/* 6407 */       Util.log(ex);
/*      */     } 
/* 6409 */     if (moduleName == null) {
/* 6410 */       moduleName = AutomaticModuleNaming.determineAutomaticModuleName(file.getAbsolutePath());
/*      */     }
/* 6412 */     return new String(moduleName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Set<String> getRequiredModulesFromJar(File file) {
/* 6424 */     if (!file.isFile())
/* 6425 */       return Collections.emptySet(); 
/*      */     
/* 6427 */     try { Exception exception1 = null, exception2 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {  }
/*      */       finally
/* 6440 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (ClassFormatException|java.io.IOException ex)
/* 6441 */     { Util.log(ex); }
/*      */     
/* 6443 */     return Collections.emptySet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void stop(BundleContext context) throws Exception {
/*      */     try {
/* 6457 */       JavaModelManager.unregisterDebugOptionsListener();
/* 6458 */       JavaModelManager.getJavaModelManager().shutdown();
/*      */     } finally {
/*      */       
/* 6461 */       super.stop(context);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void start(BundleContext context) throws Exception {
/* 6476 */     super.start(context);
/* 6477 */     JavaModelManager.registerDebugOptionsListener(context);
/* 6478 */     JavaModelManager.getJavaModelManager().startup();
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\JavaCore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */