/*     */ package org.eclipse.jdt.core;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.resources.IMarker;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.core.compiler.IProblem;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*     */ import org.eclipse.jdt.internal.core.util.Messages;
/*     */ import org.eclipse.jdt.internal.core.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CorrectionEngine
/*     */ {
/*     */   protected int correctionStart;
/*     */   protected int correctionEnd;
/*     */   protected int prefixLength;
/*     */   protected ICompilationUnit compilationUnit;
/*     */   protected ICorrectionRequestor correctionRequestor;
/*     */   protected static final int CLASSES = 1;
/*     */   protected static final int INTERFACES = 2;
/*     */   protected static final int IMPORT = 4;
/*     */   protected static final int METHOD = 8;
/*     */   protected static final int FIELD = 16;
/*     */   protected static final int LOCAL = 32;
/*     */   protected int filter;
/*     */   
/*     */   public CorrectionEngine(Map setting) {}
/*     */   
/*     */   public void computeCorrections(IMarker marker, ICompilationUnit targetUnit, int positionOffset, ICorrectionRequestor requestor) throws JavaModelException {
/* 119 */     IJavaElement element = (targetUnit == null) ? JavaCore.create(marker.getResource()) : targetUnit;
/*     */     
/* 121 */     if (!(element instanceof ICompilationUnit)) {
/*     */       return;
/*     */     }
/* 124 */     ICompilationUnit unit = (ICompilationUnit)element;
/*     */     
/* 126 */     int id = marker.getAttribute("id", -1);
/* 127 */     String[] args = Util.getProblemArgumentsFromMarker(marker.getAttribute("arguments", ""));
/* 128 */     int start = marker.getAttribute("charStart", -1);
/* 129 */     int end = marker.getAttribute("charEnd", -1);
/*     */     
/* 131 */     computeCorrections(unit, id, start + positionOffset, end + positionOffset, args, requestor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void computeCorrections(IProblem problem, ICompilationUnit targetUnit, ICorrectionRequestor requestor) throws JavaModelException {
/* 152 */     if (requestor == null) {
/* 153 */       throw new IllegalArgumentException(Messages.correction_nullUnit);
/*     */     }
/* 155 */     computeCorrections(
/* 156 */         targetUnit, problem.getID(), 
/* 157 */         problem.getSourceStart(), 
/* 158 */         problem.getSourceEnd(), 
/* 159 */         problem.getArguments(), 
/* 160 */         requestor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void computeCorrections(ICompilationUnit unit, int id, int start, int end, String[] arguments, ICorrectionRequestor requestor) {
/* 190 */     if (id == -1 || arguments == null || start == -1 || end == -1)
/*     */       return; 
/* 192 */     if (requestor == null) {
/* 193 */       throw new IllegalArgumentException(Messages.correction_nullRequestor);
/*     */     }
/*     */     
/* 196 */     this.correctionRequestor = requestor;
/* 197 */     this.correctionStart = start;
/* 198 */     this.correctionEnd = end;
/* 199 */     this.compilationUnit = unit;
/*     */     
/* 201 */     String argument = null;
/*     */     try {
/* 203 */       switch (id) {
/*     */         
/*     */         case 268435846:
/* 206 */           this.filter = 4;
/* 207 */           argument = arguments[0];
/*     */           break;
/*     */         case 16777218:
/* 210 */           this.filter = 3;
/* 211 */           argument = arguments[0];
/*     */           break;
/*     */ 
/*     */         
/*     */         case 67108964:
/* 216 */           this.filter = 8;
/* 217 */           argument = arguments[1];
/*     */           break;
/*     */ 
/*     */         
/*     */         case 33554502:
/* 222 */           this.filter = 16;
/* 223 */           argument = arguments[0];
/*     */           break;
/*     */         case 33554515:
/*     */         case 570425394:
/* 227 */           this.filter = 48;
/* 228 */           argument = arguments[0];
/*     */           break;
/*     */       } 
/* 231 */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
/*     */       return;
/*     */     } 
/* 234 */     if (argument != null) {
/* 235 */       correct(argument.toCharArray());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void correct(char[] argument) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield compilationUnit : Lorg/eclipse/jdt/core/ICompilationUnit;
/*     */     //   4: invokeinterface getSource : ()Ljava/lang/String;
/*     */     //   9: astore_2
/*     */     //   10: aload_0
/*     */     //   11: getfield compilationUnit : Lorg/eclipse/jdt/core/ICompilationUnit;
/*     */     //   14: invokeinterface getJavaProject : ()Lorg/eclipse/jdt/core/IJavaProject;
/*     */     //   19: iconst_1
/*     */     //   20: invokeinterface getOptions : (Z)Ljava/util/Map;
/*     */     //   25: astore_3
/*     */     //   26: aload_3
/*     */     //   27: ldc 'org.eclipse.jdt.core.compiler.source'
/*     */     //   29: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   34: checkcast java/lang/String
/*     */     //   37: invokestatic versionToJdkLevel : (Ljava/lang/String;)J
/*     */     //   40: lstore #4
/*     */     //   42: aload_3
/*     */     //   43: ldc 'org.eclipse.jdt.core.compiler.compliance'
/*     */     //   45: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   50: checkcast java/lang/String
/*     */     //   53: invokestatic versionToJdkLevel : (Ljava/lang/String;)J
/*     */     //   56: lstore #6
/*     */     //   58: new org/eclipse/jdt/internal/compiler/parser/Scanner
/*     */     //   61: dup
/*     */     //   62: iconst_0
/*     */     //   63: iconst_0
/*     */     //   64: iconst_0
/*     */     //   65: lload #4
/*     */     //   67: lload #6
/*     */     //   69: aconst_null
/*     */     //   70: aconst_null
/*     */     //   71: iconst_1
/*     */     //   72: ldc 'enabled'
/*     */     //   74: aload_3
/*     */     //   75: ldc 'org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures'
/*     */     //   77: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   82: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   85: invokespecial <init> : (ZZZJJ[[C[[CZZ)V
/*     */     //   88: astore #8
/*     */     //   90: aload #8
/*     */     //   92: aload_2
/*     */     //   93: invokevirtual toCharArray : ()[C
/*     */     //   96: invokevirtual setSource : ([C)V
/*     */     //   99: aload #8
/*     */     //   101: aload_0
/*     */     //   102: getfield correctionStart : I
/*     */     //   105: aload_0
/*     */     //   106: getfield correctionEnd : I
/*     */     //   109: invokevirtual resetTo : (II)V
/*     */     //   112: iconst_0
/*     */     //   113: istore #9
/*     */     //   115: getstatic org/eclipse/jdt/core/compiler/CharOperation.NO_CHAR : [C
/*     */     //   118: astore #10
/*     */     //   120: aload #8
/*     */     //   122: invokevirtual getNextToken : ()I
/*     */     //   125: istore #9
/*     */     //   127: iload #9
/*     */     //   129: bipush #64
/*     */     //   131: if_icmpne -> 135
/*     */     //   134: return
/*     */     //   135: aload #8
/*     */     //   137: invokevirtual getCurrentTokenSource : ()[C
/*     */     //   140: astore #11
/*     */     //   142: aload #10
/*     */     //   144: aload #11
/*     */     //   146: invokestatic concat : ([C[C)[C
/*     */     //   149: astore #10
/*     */     //   151: aload #10
/*     */     //   153: aload_1
/*     */     //   154: invokestatic prefixEquals : ([C[C)Z
/*     */     //   157: ifne -> 161
/*     */     //   160: return
/*     */     //   161: aload_1
/*     */     //   162: aload #10
/*     */     //   164: invokestatic equals : ([C[C)Z
/*     */     //   167: ifeq -> 120
/*     */     //   170: aload_0
/*     */     //   171: aload #8
/*     */     //   173: getfield startPosition : I
/*     */     //   176: putfield correctionStart : I
/*     */     //   179: aload_0
/*     */     //   180: aload #8
/*     */     //   182: getfield currentPosition : I
/*     */     //   185: putfield correctionEnd : I
/*     */     //   188: aload_0
/*     */     //   189: bipush #46
/*     */     //   191: aload_1
/*     */     //   192: invokestatic lastIndexOf : (C[C)I
/*     */     //   195: iconst_1
/*     */     //   196: iadd
/*     */     //   197: putfield prefixLength : I
/*     */     //   200: aload_0
/*     */     //   201: getfield correctionStart : I
/*     */     //   204: istore #11
/*     */     //   206: aload #8
/*     */     //   208: iload #11
/*     */     //   210: aload_0
/*     */     //   211: getfield correctionEnd : I
/*     */     //   214: invokevirtual resetTo : (II)V
/*     */     //   217: iload #11
/*     */     //   219: istore #12
/*     */     //   221: iconst_0
/*     */     //   222: istore #13
/*     */     //   224: goto -> 249
/*     */     //   227: aload #8
/*     */     //   229: invokevirtual getNextCharAsJavaIdentifierPart : ()Z
/*     */     //   232: ifeq -> 255
/*     */     //   235: iload #12
/*     */     //   237: istore #11
/*     */     //   239: aload #8
/*     */     //   241: getfield currentPosition : I
/*     */     //   244: istore #12
/*     */     //   246: iinc #13, 1
/*     */     //   249: iload #13
/*     */     //   251: iconst_4
/*     */     //   252: if_icmplt -> 227
/*     */     //   255: invokestatic getOptions : ()Ljava/util/Hashtable;
/*     */     //   258: astore #13
/*     */     //   260: new java/util/Hashtable
/*     */     //   263: dup
/*     */     //   264: aload #13
/*     */     //   266: invokespecial <init> : (Ljava/util/Map;)V
/*     */     //   269: astore #14
/*     */     //   271: aload #14
/*     */     //   273: ldc_w 'org.eclipse.jdt.core.codeComplete.camelCaseMatch'
/*     */     //   276: ldc_w 'disabled'
/*     */     //   279: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   282: pop
/*     */     //   283: aload #14
/*     */     //   285: ldc_w 'org.eclipse.jdt.core.codeComplete.subwordMatch'
/*     */     //   288: ldc_w 'disabled'
/*     */     //   291: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   294: pop
/*     */     //   295: aload #14
/*     */     //   297: invokestatic setOptions : (Ljava/util/Hashtable;)V
/*     */     //   300: aload_0
/*     */     //   301: getfield compilationUnit : Lorg/eclipse/jdt/core/ICompilationUnit;
/*     */     //   304: iload #11
/*     */     //   306: aload_0
/*     */     //   307: getfield completionRequestor : Lorg/eclipse/jdt/core/CompletionRequestor;
/*     */     //   310: invokeinterface codeComplete : (ILorg/eclipse/jdt/core/CompletionRequestor;)V
/*     */     //   315: goto -> 328
/*     */     //   318: astore #15
/*     */     //   320: aload #13
/*     */     //   322: invokestatic setOptions : (Ljava/util/Hashtable;)V
/*     */     //   325: aload #15
/*     */     //   327: athrow
/*     */     //   328: aload #13
/*     */     //   330: invokestatic setOptions : (Ljava/util/Hashtable;)V
/*     */     //   333: goto -> 338
/*     */     //   336: pop
/*     */     //   337: return
/*     */     //   338: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #241	-> 0
/*     */     //   #242	-> 10
/*     */     //   #243	-> 26
/*     */     //   #244	-> 42
/*     */     //   #247	-> 58
/*     */     //   #248	-> 62
/*     */     //   #249	-> 63
/*     */     //   #250	-> 64
/*     */     //   #251	-> 65
/*     */     //   #252	-> 67
/*     */     //   #253	-> 69
/*     */     //   #254	-> 70
/*     */     //   #255	-> 71
/*     */     //   #256	-> 72
/*     */     //   #247	-> 85
/*     */     //   #246	-> 88
/*     */     //   #257	-> 90
/*     */     //   #259	-> 99
/*     */     //   #260	-> 112
/*     */     //   #261	-> 115
/*     */     //   #265	-> 120
/*     */     //   #266	-> 127
/*     */     //   #268	-> 135
/*     */     //   #270	-> 142
/*     */     //   #271	-> 151
/*     */     //   #272	-> 160
/*     */     //   #274	-> 161
/*     */     //   #275	-> 170
/*     */     //   #276	-> 179
/*     */     //   #277	-> 188
/*     */     //   #284	-> 200
/*     */     //   #285	-> 206
/*     */     //   #286	-> 217
/*     */     //   #288	-> 221
/*     */     //   #289	-> 227
/*     */     //   #290	-> 235
/*     */     //   #291	-> 239
/*     */     //   #288	-> 246
/*     */     //   #296	-> 255
/*     */     //   #298	-> 260
/*     */     //   #299	-> 271
/*     */     //   #300	-> 283
/*     */     //   #301	-> 295
/*     */     //   #303	-> 300
/*     */     //   #304	-> 304
/*     */     //   #305	-> 306
/*     */     //   #303	-> 310
/*     */     //   #307	-> 315
/*     */     //   #308	-> 320
/*     */     //   #309	-> 325
/*     */     //   #308	-> 328
/*     */     //   #310	-> 333
/*     */     //   #311	-> 337
/*     */     //   #313	-> 338
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	339	0	this	Lorg/eclipse/jdt/core/CorrectionEngine;
/*     */     //   0	339	1	argument	[C
/*     */     //   10	323	2	source	Ljava/lang/String;
/*     */     //   26	307	3	currentProjectOptions	Ljava/util/Map;
/*     */     //   42	291	4	sourceLevel	J
/*     */     //   58	275	6	complianceLevel	J
/*     */     //   90	243	8	scanner	Lorg/eclipse/jdt/internal/compiler/parser/Scanner;
/*     */     //   115	218	9	token	I
/*     */     //   120	213	10	argumentSource	[C
/*     */     //   142	58	11	tokenSource	[C
/*     */     //   206	127	11	completionPosition	I
/*     */     //   221	112	12	position	I
/*     */     //   224	31	13	i	I
/*     */     //   260	73	13	oldOptions	Ljava/util/Hashtable;
/*     */     //   271	44	14	options	Ljava/util/Hashtable;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   26	307	3	currentProjectOptions	Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   0	134	336	org/eclipse/jdt/core/JavaModelException
/*     */     //   0	134	336	org/eclipse/jdt/core/compiler/InvalidInputException
/*     */     //   135	160	336	org/eclipse/jdt/core/JavaModelException
/*     */     //   135	160	336	org/eclipse/jdt/core/compiler/InvalidInputException
/*     */     //   161	333	336	org/eclipse/jdt/core/JavaModelException
/*     */     //   161	333	336	org/eclipse/jdt/core/compiler/InvalidInputException
/*     */     //   260	318	318	finally
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 318 */   protected CompletionRequestor completionRequestor = new CompletionRequestor() {
/*     */       public void accept(CompletionProposal proposal) {
/*     */         int flags;
/* 321 */         switch (proposal.getKind()) {
/*     */           case 9:
/* 323 */             flags = proposal.getFlags();
/* 324 */             if (!Flags.isEnum(flags) && !Flags.isAnnotation(flags)) {
/* 325 */               if ((CorrectionEngine.this.filter & 0x3) != 0) {
/* 326 */                 char[] completionName = proposal.getCompletion();
/* 327 */                 CorrectionEngine.this.correctionRequestor.acceptClass(
/* 328 */                     proposal.getDeclarationSignature(), 
/* 329 */                     Signature.getSignatureSimpleName(proposal.getSignature()), 
/* 330 */                     CharOperation.subarray(completionName, CorrectionEngine.this.prefixLength, completionName.length), 
/* 331 */                     proposal.getFlags(), 
/* 332 */                     CorrectionEngine.this.correctionStart, 
/* 333 */                     CorrectionEngine.this.correctionEnd); break;
/* 334 */               }  if ((CorrectionEngine.this.filter & 0x4) != 0) {
/* 335 */                 char[] packageName = proposal.getDeclarationSignature();
/* 336 */                 char[] className = Signature.getSignatureSimpleName(proposal.getSignature());
/* 337 */                 char[] fullName = CharOperation.concat(packageName, className, '.');
/* 338 */                 CorrectionEngine.this.correctionRequestor.acceptClass(
/* 339 */                     packageName, 
/* 340 */                     className, 
/* 341 */                     CharOperation.subarray(fullName, CorrectionEngine.this.prefixLength, fullName.length), 
/* 342 */                     proposal.getFlags(), 
/* 343 */                     CorrectionEngine.this.correctionStart, 
/* 344 */                     CorrectionEngine.this.correctionEnd);
/*     */               } 
/*     */             } 
/*     */             break;
/*     */           case 2:
/* 349 */             if ((CorrectionEngine.this.filter & 0x10) != 0) {
/* 350 */               char[] declaringSignature = proposal.getDeclarationSignature();
/* 351 */               char[] signature = proposal.getSignature();
/* 352 */               CorrectionEngine.this.correctionRequestor.acceptField(
/* 353 */                   Signature.getSignatureQualifier(declaringSignature), 
/* 354 */                   Signature.getSignatureSimpleName(declaringSignature), 
/* 355 */                   proposal.getName(), 
/* 356 */                   Signature.getSignatureQualifier(signature), 
/* 357 */                   Signature.getSignatureSimpleName(signature), 
/* 358 */                   proposal.getName(), 
/* 359 */                   proposal.getFlags(), 
/* 360 */                   CorrectionEngine.this.correctionStart, 
/* 361 */                   CorrectionEngine.this.correctionEnd);
/*     */             } 
/*     */             break;
/*     */           case 5:
/* 365 */             if ((CorrectionEngine.this.filter & 0x20) != 0) {
/* 366 */               char[] signature = proposal.getSignature();
/* 367 */               CorrectionEngine.this.correctionRequestor.acceptLocalVariable(
/* 368 */                   proposal.getName(), 
/* 369 */                   Signature.getSignatureQualifier(signature), 
/* 370 */                   Signature.getSignatureSimpleName(signature), 
/* 371 */                   proposal.getFlags(), 
/* 372 */                   CorrectionEngine.this.correctionStart, 
/* 373 */                   CorrectionEngine.this.correctionEnd);
/*     */             } 
/*     */             break;
/*     */           case 6:
/* 377 */             if ((CorrectionEngine.this.filter & 0x8) != 0) {
/* 378 */               char[] declaringSignature = proposal.getDeclarationSignature();
/* 379 */               char[] signature = proposal.getSignature();
/* 380 */               char[][] parameterTypeSignatures = Signature.getParameterTypes(signature);
/* 381 */               int length = parameterTypeSignatures.length;
/* 382 */               char[][] parameterPackageNames = new char[length][];
/* 383 */               char[][] parameterTypeNames = new char[length][];
/* 384 */               for (int i = 0; i < length; i++) {
/* 385 */                 parameterPackageNames[i] = Signature.getSignatureQualifier(parameterTypeSignatures[i]);
/* 386 */                 parameterTypeNames[i] = Signature.getSignatureSimpleName(parameterTypeSignatures[i]);
/*     */               } 
/* 388 */               char[] returnTypeSignature = Signature.getReturnType(signature);
/* 389 */               CorrectionEngine.this.correctionRequestor.acceptMethod(
/* 390 */                   Signature.getSignatureQualifier(declaringSignature), 
/* 391 */                   Signature.getSignatureSimpleName(declaringSignature), 
/* 392 */                   proposal.getName(), 
/* 393 */                   parameterPackageNames, 
/* 394 */                   parameterTypeNames, 
/* 395 */                   proposal.findParameterNames(null), 
/* 396 */                   Signature.getSignatureQualifier(returnTypeSignature), 
/* 397 */                   Signature.getSignatureSimpleName(returnTypeSignature), 
/* 398 */                   proposal.getName(), 
/* 399 */                   proposal.getFlags(), 
/* 400 */                   CorrectionEngine.this.correctionStart, 
/* 401 */                   CorrectionEngine.this.correctionEnd);
/*     */             } 
/*     */             break;
/*     */           case 8:
/* 405 */             if ((CorrectionEngine.this.filter & 0x7) != 0) {
/* 406 */               char[] packageName = proposal.getDeclarationSignature();
/* 407 */               CorrectionEngine.this.correctionRequestor.acceptPackage(
/* 408 */                   packageName, 
/* 409 */                   CharOperation.subarray(packageName, CorrectionEngine.this.prefixLength, packageName.length), 
/* 410 */                   CorrectionEngine.this.correctionStart, 
/* 411 */                   CorrectionEngine.this.correctionEnd);
/*     */             } 
/*     */             break;
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getAllWarningTokens() {
/* 435 */     return CompilerOptions.warningTokens;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getProblemArguments(IMarker problemMarker) {
/* 449 */     String argumentsString = problemMarker.getAttribute("arguments", null);
/* 450 */     return Util.getProblemArgumentsFromMarker(argumentsString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getWarningToken(int problemID) {
/* 481 */     int irritant = ProblemReporter.getIrritant(problemID);
/* 482 */     if (irritant != 0) {
/* 483 */       return CompilerOptions.warningTokenFromIrritant(irritant);
/*     */     }
/* 485 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\CorrectionEngine.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */