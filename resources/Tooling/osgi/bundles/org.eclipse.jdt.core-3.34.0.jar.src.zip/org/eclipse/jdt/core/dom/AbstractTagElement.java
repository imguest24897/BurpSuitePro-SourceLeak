/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTagElement
/*     */   extends ASTNode
/*     */   implements IDocElement
/*     */ {
/*     */   public static final SimplePropertyDescriptor internalTagNamePropertyFactory(Class nodeClass) {
/*  48 */     return new SimplePropertyDescriptor(nodeClass, "tagName", String.class, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final ChildListPropertyDescriptor internalFragmentsPropertyFactory(Class nodeClass) {
/*  57 */     return new ChildListPropertyDescriptor(nodeClass, "fragments", IDocElement.class, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   String optionalTagName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   ASTNode.NodeList fragments = new ASTNode.NodeList(this, internalFragmentsPropertyFactory());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractTagElement(AST ast) {
/*  85 */     super(ast);
/*  86 */     this.fragments = new ASTNode.NodeList(this, internalFragmentsPropertyFactory());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract ChildListPropertyDescriptor internalFragmentsPropertyFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract SimplePropertyDescriptor internalTagNamePropertyFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SimplePropertyDescriptor getTagNameProperty() {
/* 114 */     return internalTagNamePropertyFactory();
/*     */   }
/*     */ 
/*     */   
/*     */   final Object internalGetSetObjectProperty(SimplePropertyDescriptor property, boolean get, Object value) {
/* 119 */     if (property == internalTagNamePropertyFactory()) {
/* 120 */       if (get) {
/* 121 */         return getTagName();
/*     */       }
/* 123 */       setTagName((String)value);
/* 124 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 128 */     return super.internalGetSetObjectProperty(property, get, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTagName() {
/* 143 */     return this.optionalTagName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTagName(String tagName) {
/* 159 */     preValueChange(internalTagNamePropertyFactory());
/* 160 */     this.optionalTagName = tagName;
/* 161 */     postValueChange(internalTagNamePropertyFactory());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List fragments() {
/* 207 */     return this.fragments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNested() {
/* 228 */     return getParent() instanceof AbstractTagElement;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 233 */     int size = 46 + stringSize(this.optionalTagName);
/* 234 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 239 */     return memSize() + this.fragments.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\AbstractTagElement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */