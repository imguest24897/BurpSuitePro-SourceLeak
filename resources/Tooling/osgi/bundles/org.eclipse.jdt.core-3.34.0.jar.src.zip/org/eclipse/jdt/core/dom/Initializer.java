/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Initializer
/*     */   extends BodyDeclaration
/*     */ {
/*  38 */   public static final ChildPropertyDescriptor JAVADOC_PROPERTY = internalJavadocPropertyFactory(Initializer.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final SimplePropertyDescriptor MODIFIERS_PROPERTY = internalModifiersPropertyFactory(Initializer.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public static final ChildListPropertyDescriptor MODIFIERS2_PROPERTY = internalModifiers2PropertyFactory(Initializer.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public static final ChildPropertyDescriptor BODY_PROPERTY = new ChildPropertyDescriptor(Initializer.class, "body", Block.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  79 */     List properyList = new ArrayList(4);
/*  80 */     createPropertyList(Initializer.class, properyList);
/*  81 */     addProperty(JAVADOC_PROPERTY, properyList);
/*  82 */     addProperty(MODIFIERS_PROPERTY, properyList);
/*  83 */     addProperty(BODY_PROPERTY, properyList);
/*  84 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(properyList);
/*     */     
/*  86 */     properyList = new ArrayList(4);
/*  87 */     createPropertyList(Initializer.class, properyList);
/*  88 */     addProperty(JAVADOC_PROPERTY, properyList);
/*  89 */     addProperty(MODIFIERS2_PROPERTY, properyList);
/*  90 */     addProperty(BODY_PROPERTY, properyList);
/*  91 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 106 */     if (apiLevel == 2) {
/* 107 */       return PROPERTY_DESCRIPTORS_2_0;
/*     */     }
/* 109 */     return PROPERTY_DESCRIPTORS_3_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   private Block body = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Initializer(AST ast) {
/* 129 */     super(ast);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 138 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final int internalGetSetIntProperty(SimplePropertyDescriptor property, boolean get, int value) {
/* 143 */     if (property == MODIFIERS_PROPERTY) {
/* 144 */       if (get) {
/* 145 */         return getModifiers();
/*     */       }
/* 147 */       internalSetModifiers(value);
/* 148 */       return 0;
/*     */     } 
/*     */ 
/*     */     
/* 152 */     return super.internalGetSetIntProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 157 */     if (property == JAVADOC_PROPERTY) {
/* 158 */       if (get) {
/* 159 */         return getJavadoc();
/*     */       }
/* 161 */       setJavadoc((Javadoc)child);
/* 162 */       return null;
/*     */     } 
/*     */     
/* 165 */     if (property == BODY_PROPERTY) {
/* 166 */       if (get) {
/* 167 */         return getBody();
/*     */       }
/* 169 */       setBody((Block)child);
/* 170 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 174 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 179 */     if (property == MODIFIERS2_PROPERTY) {
/* 180 */       return modifiers();
/*     */     }
/*     */     
/* 183 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalJavadocProperty() {
/* 188 */     return JAVADOC_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalModifiers2Property() {
/* 193 */     return MODIFIERS2_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final SimplePropertyDescriptor internalModifiersProperty() {
/* 198 */     return MODIFIERS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 203 */     return 28;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 208 */     Initializer result = new Initializer(target);
/* 209 */     result.setSourceRange(getStartPosition(), getLength());
/* 210 */     if (this.ast.apiLevel == 2) {
/* 211 */       result.internalSetModifiers(getModifiers());
/*     */     }
/* 213 */     if (this.ast.apiLevel >= 3) {
/* 214 */       result.modifiers().addAll(ASTNode.copySubtrees(target, modifiers()));
/*     */     }
/* 216 */     result.setJavadoc(
/* 217 */         (Javadoc)ASTNode.copySubtree(target, getJavadoc()));
/* 218 */     result.setBody((Block)getBody().clone(target));
/* 219 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 225 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 230 */     boolean visitChildren = visitor.visit(this);
/* 231 */     if (visitChildren) {
/* 232 */       acceptChild(visitor, getJavadoc());
/* 233 */       if (this.ast.apiLevel >= 3) {
/* 234 */         acceptChildren(visitor, this.modifiers);
/*     */       }
/* 236 */       acceptChild(visitor, getBody());
/*     */     } 
/* 238 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Block getBody() {
/* 247 */     if (this.body == null)
/*     */     {
/* 249 */       synchronized (this) {
/* 250 */         if (this.body == null) {
/* 251 */           preLazyInit();
/* 252 */           this.body = new Block(this.ast);
/* 253 */           postLazyInit(this.body, BODY_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 257 */     return this.body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBody(Block body) {
/* 272 */     if (body == null) {
/* 273 */       throw new IllegalArgumentException();
/*     */     }
/* 275 */     ASTNode oldChild = this.body;
/* 276 */     preReplaceChild(oldChild, body, BODY_PROPERTY);
/* 277 */     this.body = body;
/* 278 */     postReplaceChild(oldChild, body, BODY_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 283 */     return super.memSize() + 4;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 288 */     return 
/* 289 */       memSize() + (
/* 290 */       (this.optionalDocComment == null) ? 0 : getJavadoc().treeSize()) + (
/* 291 */       (this.modifiers == null) ? 0 : this.modifiers.listSize()) + (
/* 292 */       (this.body == null) ? 0 : getBody().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\Initializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */