package org.eclipse.jdt.core.util;

public interface IVerificationTypeInfo {
  public static final int ITEM_TOP = 0;
  
  public static final int ITEM_INTEGER = 1;
  
  public static final int ITEM_FLOAT = 2;
  
  public static final int ITEM_DOUBLE = 3;
  
  public static final int ITEM_LONG = 4;
  
  public static final int ITEM_NULL = 5;
  
  public static final int ITEM_UNINITIALIZED_THIS = 6;
  
  public static final int ITEM_OBJECT = 7;
  
  public static final int ITEM_UNINITIALIZED = 8;
  
  int getTag();
  
  int getOffset();
  
  int getConstantPoolIndex();
  
  char[] getClassTypeName();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\cor\\util\IVerificationTypeInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */