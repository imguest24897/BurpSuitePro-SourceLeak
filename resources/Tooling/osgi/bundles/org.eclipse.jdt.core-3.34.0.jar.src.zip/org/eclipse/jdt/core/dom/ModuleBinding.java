/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.env.INameEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PlainPackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ import org.eclipse.jdt.internal.core.NameLookup;
/*     */ import org.eclipse.jdt.internal.core.SearchableEnvironment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ModuleBinding
/*     */   implements IModuleBinding
/*     */ {
/*  32 */   protected static final ITypeBinding[] NO_TYPE_BINDINGS = new ITypeBinding[0];
/*  33 */   private String name = null;
/*     */   
/*     */   private volatile String key;
/*     */   
/*     */   private boolean isOpen = false;
/*     */   private org.eclipse.jdt.internal.compiler.lookup.ModuleBinding binding;
/*     */   protected BindingResolver resolver;
/*     */   private IAnnotationBinding[] annotations;
/*     */   private IModuleBinding[] requiredModules;
/*     */   private IPackageBinding[] exports;
/*     */   private IPackageBinding[] opens;
/*     */   private ITypeBinding[] uses;
/*     */   private ITypeBinding[] services;
/*     */   
/*     */   ModuleBinding(BindingResolver resolver, org.eclipse.jdt.internal.compiler.lookup.ModuleBinding binding) {
/*  48 */     this.resolver = resolver;
/*  49 */     this.binding = binding;
/*  50 */     this.isOpen = binding.isOpen();
/*     */   }
/*     */ 
/*     */   
/*     */   public IAnnotationBinding[] getAnnotations() {
/*  55 */     if (this.annotations == null) {
/*  56 */       this.annotations = resolveAnnotationBindings(this.binding.getAnnotations());
/*     */     }
/*  58 */     return this.annotations;
/*     */   }
/*     */   
/*     */   private IAnnotationBinding[] resolveAnnotationBindings(AnnotationBinding[] internalAnnotations) {
/*  62 */     int length = (internalAnnotations == null) ? 0 : internalAnnotations.length;
/*  63 */     if (length != 0) {
/*  64 */       IAnnotationBinding[] tempAnnotations = new IAnnotationBinding[length];
/*  65 */       int convertedAnnotationCount = 0;
/*  66 */       for (int i = 0; i < length; i++) {
/*  67 */         AnnotationBinding internalAnnotation = internalAnnotations[i];
/*  68 */         if (internalAnnotation == null)
/*     */           break; 
/*  70 */         IAnnotationBinding annotationInstance = this.resolver.getAnnotationInstance(internalAnnotation);
/*  71 */         if (annotationInstance != null)
/*     */         {
/*  73 */           tempAnnotations[convertedAnnotationCount++] = annotationInstance; } 
/*     */       } 
/*  75 */       if (convertedAnnotationCount != length) {
/*  76 */         if (convertedAnnotationCount == 0) {
/*  77 */           return this.annotations = (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */         }
/*  79 */         System.arraycopy(tempAnnotations, 0, tempAnnotations = new IAnnotationBinding[convertedAnnotationCount], 0, convertedAnnotationCount);
/*     */       } 
/*  81 */       return tempAnnotations;
/*     */     } 
/*  83 */     return (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  88 */     if (this.name == null) {
/*  89 */       char[] tmp = this.binding.moduleName;
/*  90 */       return (tmp != null && tmp.length != 0) ? new String(tmp) : Util.EMPTY_STRING;
/*     */     } 
/*  92 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/*  98 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDeprecated() {
/* 103 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRecovered() {
/* 108 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSynthetic() {
/* 117 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public IJavaElement getJavaElement() {
/* 122 */     INameEnvironment nameEnvironment = this.binding.environment.nameEnvironment;
/* 123 */     if (!(nameEnvironment instanceof SearchableEnvironment)) return null; 
/* 124 */     NameLookup nameLookup = ((SearchableEnvironment)nameEnvironment).nameLookup;
/* 125 */     if (nameLookup == null) return null; 
/* 126 */     NameLookup.Answer answer = nameLookup.findModule(getName().toCharArray());
/* 127 */     if (answer == null) return null; 
/* 128 */     return (IJavaElement)answer.module;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 133 */     if (this.key == null) {
/* 134 */       char[] k = this.binding.computeUniqueKey();
/* 135 */       this.key = (k == null || k == CharOperation.NO_CHAR) ? Util.EMPTY_STRING : new String(k);
/*     */     } 
/* 137 */     return this.key;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEqualTo(IBinding other) {
/* 142 */     if (other == this)
/* 143 */       return true; 
/* 144 */     if (other == null) {
/* 145 */       return false;
/*     */     }
/* 147 */     if (!(other instanceof ModuleBinding)) {
/* 148 */       return false;
/*     */     }
/* 150 */     org.eclipse.jdt.internal.compiler.lookup.ModuleBinding otherBinding = ((ModuleBinding)other).binding;
/* 151 */     return BindingComparator.isEqual(this.binding, otherBinding);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 156 */     return this.isOpen;
/*     */   }
/*     */   
/*     */   public IModuleBinding[] getRequiredModules() {
/* 160 */     if (this.requiredModules != null) {
/* 161 */       return this.requiredModules;
/*     */     }
/* 163 */     org.eclipse.jdt.internal.compiler.lookup.ModuleBinding[] reqs = this.binding.getRequires();
/* 164 */     IModuleBinding[] result = new IModuleBinding[(reqs != null) ? reqs.length : 0];
/* 165 */     for (int i = 0, l = result.length; i < l; i++) {
/* 166 */       org.eclipse.jdt.internal.compiler.lookup.ModuleBinding req = reqs[i];
/* 167 */       result[i] = (req != null) ? this.resolver.getModuleBinding(req) : null;
/*     */     } 
/* 169 */     return this.requiredModules = result;
/*     */   }
/*     */ 
/*     */   
/*     */   public IPackageBinding[] getExportedPackages() {
/* 174 */     if (this.exports == null) {
/* 175 */       PlainPackageBinding[] arrayOfPlainPackageBinding = this.binding.getExports();
/* 176 */       this.exports = (IPackageBinding[])Arrays.<PlainPackageBinding>stream(arrayOfPlainPackageBinding)
/* 177 */         .map(e -> this.resolver.getPackageBinding(e))
/* 178 */         .toArray(paramInt -> new IPackageBinding[paramInt]);
/*     */     } 
/* 180 */     return this.exports;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getExportedTo(IPackageBinding packageBinding) {
/* 185 */     return this.binding.getExportRestrictions(((PackageBinding)packageBinding).getCompilerBinding());
/*     */   }
/*     */ 
/*     */   
/*     */   public IPackageBinding[] getOpenedPackages() {
/* 190 */     if (this.opens == null) {
/* 191 */       PlainPackageBinding[] arrayOfPlainPackageBinding = this.binding.getOpens();
/* 192 */       this.opens = (IPackageBinding[])Arrays.<PlainPackageBinding>stream(arrayOfPlainPackageBinding)
/* 193 */         .map(o -> this.resolver.getPackageBinding(o))
/* 194 */         .toArray(paramInt -> new IPackageBinding[paramInt]);
/*     */     } 
/* 196 */     return this.opens;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getOpenedTo(IPackageBinding packageBinding) {
/* 201 */     return this.binding.getOpenRestrictions(((PackageBinding)packageBinding).getCompilerBinding());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ITypeBinding[] getTypes(TypeBinding[] types) {
/* 208 */     int length = (types == null) ? 0 : types.length;
/* 209 */     TypeBinding[] result = new TypeBinding[length];
/* 210 */     for (int i = 0; i < length; i++) {
/* 211 */       result[i] = (TypeBinding)this.resolver.getTypeBinding(types[i]);
/*     */     }
/* 213 */     return (ITypeBinding[])result;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding[] getUses() {
/* 218 */     if (this.uses == null)
/* 219 */       this.uses = getTypes(this.binding.getUses()); 
/* 220 */     return this.uses;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding[] getServices() {
/* 225 */     if (this.services == null)
/* 226 */       this.services = getTypes(this.binding.getServices()); 
/* 227 */     return this.services;
/*     */   }
/*     */   
/*     */   public ITypeBinding[] getImplementations(ITypeBinding service) {
/* 231 */     return getTypes(this.binding.getImplementations(((TypeBinding)service).binding));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 239 */     return this.binding.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ModuleBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */