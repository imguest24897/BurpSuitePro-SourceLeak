/*     */ package org.eclipse.jdt.internal.codeassist.complete;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Annotation;
/*     */ import org.eclipse.jdt.internal.compiler.ast.QualifiedTypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompletionOnQualifiedTypeReference
/*     */   extends QualifiedTypeReference
/*     */ {
/*     */   public static final int K_TYPE = 0;
/*     */   public static final int K_CLASS = 1;
/*     */   public static final int K_INTERFACE = 2;
/*     */   public static final int K_EXCEPTION = 3;
/*  39 */   private int kind = 0;
/*     */   
/*     */   public char[] completionIdentifier;
/*     */   public boolean isConstructorType;
/*     */   
/*     */   public CompletionOnQualifiedTypeReference(char[][] previousIdentifiers, char[] completionIdentifier, long[] positions) {
/*  45 */     this(previousIdentifiers, completionIdentifier, positions, 0);
/*     */   }
/*     */   public CompletionOnQualifiedTypeReference(char[][] previousIdentifiers, char[] completionIdentifier, long[] positions, int kind) {
/*  48 */     super(previousIdentifiers, positions);
/*  49 */     this.completionIdentifier = completionIdentifier;
/*  50 */     this.kind = kind;
/*     */   }
/*     */   
/*     */   public void aboutToResolve(Scope scope) {
/*  54 */     getTypeBinding(scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeReference augmentTypeWithAdditionalDimensions(int additionalDimensions, Annotation[][] additionalAnnotations, boolean isVarargs) {
/*  61 */     return (TypeReference)this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected TypeBinding getTypeBinding(Scope scope) {
/*  66 */     Binding binding = scope.parent.getTypeOrPackage(this.tokens);
/*  67 */     if (!binding.isValidBinding()) {
/*  68 */       scope.problemReporter().invalidType((ASTNode)this, (TypeBinding)binding);
/*     */       
/*  70 */       if (binding.problemId() == 1) {
/*  71 */         throw new CompletionNodeFound(this, binding, scope);
/*     */       }
/*     */       
/*  74 */       throw new CompletionNodeFound();
/*     */     } 
/*     */     
/*  77 */     throw new CompletionNodeFound(this, binding, scope);
/*     */   }
/*     */   public boolean isClass() {
/*  80 */     return (this.kind == 1);
/*     */   }
/*     */   
/*     */   public boolean isInterface() {
/*  84 */     return (this.kind == 2);
/*     */   }
/*     */   
/*     */   public boolean isException() {
/*  88 */     return (this.kind == 3);
/*     */   }
/*     */   
/*     */   public boolean isSuperType() {
/*  92 */     return !(this.kind != 1 && this.kind != 2);
/*     */   }
/*     */   public void setKind(int kind) {
/*  95 */     this.kind = kind;
/*     */   }
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/*  99 */     switch (this.kind) {
/*     */       case 1:
/* 101 */         output.append("<CompleteOnClass:");
/*     */         break;
/*     */       case 2:
/* 104 */         output.append("<CompleteOnInterface:");
/*     */         break;
/*     */       case 3:
/* 107 */         output.append("<CompleteOnException:");
/*     */         break;
/*     */       default:
/* 110 */         output.append("<CompleteOnType:");
/*     */         break;
/*     */     } 
/* 113 */     for (int i = 0; i < this.tokens.length; i++) {
/* 114 */       output.append(this.tokens[i]);
/* 115 */       output.append('.');
/*     */     } 
/* 117 */     output.append(this.completionIdentifier).append('>');
/* 118 */     return output;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnQualifiedTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */