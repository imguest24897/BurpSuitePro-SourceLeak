/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ModulePackageAccess
/*     */   extends ModuleDirective
/*     */ {
/*  36 */   protected Name name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   protected ASTNode.NodeList modules = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract ChildListPropertyDescriptor internalModulesProperty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract ChildPropertyDescriptor internalNameProperty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ChildPropertyDescriptor getNameProperty() {
/*  68 */     return internalNameProperty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final ChildPropertyDescriptor internalNamePropertyFactory(Class nodeClass) {
/*  78 */     return new ChildPropertyDescriptor(nodeClass, "name", Name.class, true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final ChildListPropertyDescriptor internalModulesPropertyFactory(Class nodeClass) {
/*  88 */     return new ChildListPropertyDescriptor(nodeClass, "modules", Name.class, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ModulePackageAccess(AST ast) {
/* 101 */     super(ast);
/* 102 */     this.modules = new ASTNode.NodeList(this, internalModulesProperty());
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 107 */     if (property == internalNameProperty()) {
/* 108 */       if (get) {
/* 109 */         return getName();
/*     */       }
/* 111 */       setName((Name)child);
/* 112 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 116 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 121 */     if (property == internalModulesProperty()) {
/* 122 */       return modules();
/*     */     }
/*     */     
/* 125 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getName() {
/* 134 */     if (this.name == null)
/*     */     {
/* 136 */       synchronized (this) {
/* 137 */         if (this.name == null) {
/* 138 */           preLazyInit();
/* 139 */           this.name = this.ast.newQualifiedName(
/* 140 */               new SimpleName(this.ast), new SimpleName(this.ast));
/* 141 */           ChildPropertyDescriptor p = internalNameProperty();
/* 142 */           postLazyInit(this.name, p);
/*     */         } 
/*     */       } 
/*     */     }
/* 146 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(Name name) {
/* 160 */     if (name == null) {
/* 161 */       throw new IllegalArgumentException();
/*     */     }
/* 163 */     ASTNode oldChild = this.name;
/* 164 */     ChildPropertyDescriptor p = internalNameProperty();
/* 165 */     preReplaceChild(oldChild, name, p);
/* 166 */     this.name = name;
/* 167 */     postReplaceChild(oldChild, name, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List modules() {
/* 178 */     return this.modules;
/*     */   }
/*     */   
/*     */   protected ASTNode cloneHelper(AST target, ModulePackageAccess result) {
/* 182 */     result.setSourceRange(getStartPosition(), getLength());
/* 183 */     result.setName((Name)getName().clone(target));
/* 184 */     result.modules().addAll(ASTNode.copySubtrees(target, modules()));
/* 185 */     return result;
/*     */   }
/*     */   
/*     */   protected void acceptVisitChildren(boolean visitChildren, ASTVisitor visitor) {
/* 189 */     if (visitChildren) {
/* 190 */       acceptChild(visitor, getName());
/* 191 */       acceptChildren(visitor, this.modules);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 197 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 202 */     return 
/* 203 */       memSize() + (
/* 204 */       (this.name == null) ? 0 : getName().treeSize()) + 
/* 205 */       this.modules.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ModulePackageAccess.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */