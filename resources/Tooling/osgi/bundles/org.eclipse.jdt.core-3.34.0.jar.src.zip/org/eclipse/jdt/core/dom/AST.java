/*      */ package org.eclipse.jdt.core.dom;
/*      */ 
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.StringTokenizer;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.jdt.core.IClassFile;
/*      */ import org.eclipse.jdt.core.ICompilationUnit;
/*      */ import org.eclipse.jdt.core.IJavaProject;
/*      */ import org.eclipse.jdt.core.ITypeRoot;
/*      */ import org.eclipse.jdt.core.JavaCore;
/*      */ import org.eclipse.jdt.internal.compiler.ast.CompilationUnitDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.classfmt.ClassFileConstants;
/*      */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*      */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*      */ import org.eclipse.jdt.internal.core.CompilationUnit;
/*      */ import org.eclipse.jface.text.IDocument;
/*      */ import org.eclipse.text.edits.TextEdit;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class AST
/*      */ {
/*  109 */   private static final Class[] AST_CLASS = new Class[] { AST.class };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS2 = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int JLS2_INTERNAL = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS3 = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int JLS3_INTERNAL = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS4 = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int JLS4_INTERNAL = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS8 = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int JLS8_INTERNAL = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS9 = 9;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int JLS9_INTERNAL = 9;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS10 = 10;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int JLS10_INTERNAL = 10;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS11 = 11;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int JLS11_INTERNAL = 11;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS12 = 12;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int JLS12_INTERNAL = 12;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS13 = 13;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int JLS13_INTERNAL = 13;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS14 = 14;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int JLS14_INTERNAL = 14;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS15 = 15;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS16 = 16;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS17 = 17;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS18 = 18;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS19 = 19;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS20 = 20;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int JLS15_INTERNAL = 15;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int JLS16_INTERNAL = 16;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int JLS17_INTERNAL = 17;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int JLS18_INTERNAL = 18;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int JLS19_INTERNAL = 19;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int JLS20_INTERNAL = 20;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int JLS_INTERNAL_Latest = 20;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JLS_Latest = 20;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int RESOLVED_BINDINGS = -2147483648;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  491 */   private static Map<String, Long> jdkLevelMap = getLevelMapTable();
/*      */   
/*  493 */   private static Map<String, Integer> apiLevelMap = getApiLevelMapTable();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int apiLevel;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean previewEnabled;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int bits;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static CompilationUnit convertCompilationUnit(int level, CompilationUnitDeclaration compilationUnitDeclaration, char[] source, Map options, boolean isResolved, CompilationUnit workingCopy, int reconcileFlags, IProgressMonitor monitor) {
/*  523 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static CompilationUnit convertCompilationUnit(int level, CompilationUnitDeclaration compilationUnitDeclaration, Map<String, String> options, boolean isResolved, CompilationUnit workingCopy, int reconcileFlags, IProgressMonitor monitor) {
/*  553 */     ASTConverter converter = new ASTConverter(options, isResolved, monitor);
/*  554 */     AST ast = newAST(level, "enabled".equals(options.get("org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures")));
/*  555 */     String sourceModeSetting = options.get("org.eclipse.jdt.core.compiler.source");
/*  556 */     long sourceLevel = CompilerOptions.versionToJdkLevel(sourceModeSetting);
/*  557 */     if (sourceLevel == 0L)
/*      */     {
/*  559 */       sourceLevel = 3080192L;
/*      */     }
/*  561 */     ast.scanner.sourceLevel = sourceLevel;
/*  562 */     String compliance = options.get("org.eclipse.jdt.core.compiler.compliance");
/*  563 */     long complianceLevel = CompilerOptions.versionToJdkLevel(compliance);
/*  564 */     if (complianceLevel == 0L)
/*      */     {
/*  566 */       complianceLevel = sourceLevel;
/*      */     }
/*  568 */     ast.scanner.complianceLevel = complianceLevel;
/*  569 */     ast.scanner.previewEnabled = "enabled".equals(options.get("org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures"));
/*  570 */     int savedDefaultNodeFlag = ast.getDefaultNodeFlag();
/*  571 */     ast.setDefaultNodeFlag(2);
/*  572 */     BindingResolver resolver = null;
/*  573 */     if (isResolved) {
/*  574 */       resolver = new DefaultBindingResolver(compilationUnitDeclaration.scope, workingCopy.owner, new DefaultBindingResolver.BindingTables(), false, true);
/*  575 */       ((DefaultBindingResolver)resolver).isRecoveringBindings = ((reconcileFlags & 0x4) != 0);
/*  576 */       ast.setFlag(-2147483648);
/*      */     } else {
/*  578 */       resolver = new BindingResolver();
/*      */     } 
/*  580 */     ast.setFlag(reconcileFlags);
/*  581 */     ast.setBindingResolver(resolver);
/*  582 */     converter.setAST(ast);
/*      */     
/*  584 */     CompilationUnit unit = converter.convert(compilationUnitDeclaration, workingCopy.getContents());
/*  585 */     unit.setLineEndTable(compilationUnitDeclaration.compilationResult.getLineSeparatorPositions());
/*  586 */     unit.setTypeRoot((ITypeRoot)workingCopy.originalFromClone());
/*  587 */     ast.setDefaultNodeFlag(savedDefaultNodeFlag);
/*  588 */     return unit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static AST newAST(int level) {
/*  610 */     return new AST(level, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static AST newAST(int level, boolean previewEnabled) {
/*  631 */     return new AST(level, previewEnabled);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static AST newAST(Map<String, String> options) {
/*  662 */     return new AST(options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static CompilationUnit parseCompilationUnit(char[] source) {
/*  700 */     if (source == null) {
/*  701 */       throw new IllegalArgumentException();
/*      */     }
/*  703 */     ASTParser c = ASTParser.newParser(2);
/*  704 */     c.setSource(source);
/*  705 */     ASTNode result = c.createAST(null);
/*  706 */     return (CompilationUnit)result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static CompilationUnit parseCompilationUnit(char[] source, String unitName, IJavaProject project) {
/*  781 */     if (source == null) {
/*  782 */       throw new IllegalArgumentException();
/*      */     }
/*  784 */     ASTParser astParser = ASTParser.newParser(2);
/*  785 */     astParser.setSource(source);
/*  786 */     astParser.setUnitName(unitName);
/*  787 */     astParser.setProject(project);
/*  788 */     astParser.setResolveBindings((project != null));
/*  789 */     ASTNode result = astParser.createAST(null);
/*  790 */     return (CompilationUnit)result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static CompilationUnit parseCompilationUnit(IClassFile classFile, boolean resolveBindings) {
/*  856 */     if (classFile == null) {
/*  857 */       throw new IllegalArgumentException();
/*      */     }
/*      */     try {
/*  860 */       ASTParser c = ASTParser.newParser(2);
/*  861 */       c.setSource(classFile);
/*  862 */       c.setResolveBindings(resolveBindings);
/*  863 */       ASTNode result = c.createAST(null);
/*  864 */       return (CompilationUnit)result;
/*  865 */     } catch (IllegalStateException e) {
/*      */       
/*  867 */       throw new IllegalArgumentException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static CompilationUnit parseCompilationUnit(ICompilationUnit unit, boolean resolveBindings) {
/*      */     try {
/*  934 */       ASTParser c = ASTParser.newParser(2);
/*  935 */       c.setSource(unit);
/*  936 */       c.setResolveBindings(resolveBindings);
/*  937 */       ASTNode result = c.createAST(null);
/*  938 */       return (CompilationUnit)result;
/*  939 */     } catch (IllegalStateException e) {
/*      */       
/*  941 */       throw new IllegalArgumentException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  961 */   private int defaultNodeFlag = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  973 */   private int disableEvents = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  980 */   private NodeEventHandler eventHandler = new NodeEventHandler();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  987 */   private final Object internalASTLock = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  993 */   private long modificationCount = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1001 */   private long originalModificationCount = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1007 */   private BindingResolver resolver = new BindingResolver();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   InternalASTRewrite rewriter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Scanner scanner;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1024 */   private final Object[] THIS_AST = new Object[] { this };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AST() {
/* 1034 */     this(JavaCore.getDefaultOptions());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private AST(int level, boolean previewEnabled) {
/* 1045 */     this.previewEnabled = previewEnabled;
/* 1046 */     switch (level) {
/*      */       case 2:
/*      */       case 3:
/* 1049 */         this.apiLevel = level;
/*      */         
/* 1051 */         this.scanner = new Scanner(
/* 1052 */             true, 
/* 1053 */             true, 
/* 1054 */             false, 
/* 1055 */             3080192L, 
/* 1056 */             3211264L, 
/* 1057 */             null, 
/* 1058 */             null, 
/* 1059 */             true, 
/* 1060 */             false);
/*      */         return;
/*      */       case 4:
/* 1063 */         this.apiLevel = level;
/*      */         
/* 1065 */         this.scanner = new Scanner(
/* 1066 */             true, 
/* 1067 */             true, 
/* 1068 */             false, 
/* 1069 */             3342336L, 
/* 1070 */             3342336L, 
/* 1071 */             null, 
/* 1072 */             null, 
/* 1073 */             true, 
/* 1074 */             false);
/*      */         return;
/*      */       case 8:
/* 1077 */         this.apiLevel = level;
/*      */         
/* 1079 */         this.scanner = new Scanner(
/* 1080 */             true, 
/* 1081 */             true, 
/* 1082 */             false, 
/* 1083 */             3407872L, 
/* 1084 */             3407872L, 
/* 1085 */             null, 
/* 1086 */             null, 
/* 1087 */             true, 
/* 1088 */             false);
/*      */         return;
/*      */       case 9:
/* 1091 */         this.apiLevel = level;
/*      */         
/* 1093 */         this.scanner = new Scanner(
/* 1094 */             true, 
/* 1095 */             true, 
/* 1096 */             false, 
/* 1097 */             3473408L, 
/* 1098 */             3473408L, 
/* 1099 */             null, 
/* 1100 */             null, 
/* 1101 */             true, 
/* 1102 */             false);
/*      */         return;
/*      */       case 10:
/* 1105 */         this.apiLevel = level;
/*      */         
/* 1107 */         this.scanner = new Scanner(
/* 1108 */             true, 
/* 1109 */             true, 
/* 1110 */             false, 
/* 1111 */             3538944L, 
/* 1112 */             3538944L, 
/* 1113 */             null, 
/* 1114 */             null, 
/* 1115 */             true, 
/* 1116 */             false);
/*      */         return;
/*      */     } 
/* 1119 */     if (level < 2 && level > 20) {
/* 1120 */       throw new IllegalArgumentException("Unsupported JLS level : " + level);
/*      */     }
/* 1122 */     this.apiLevel = level;
/*      */ 
/*      */ 
/*      */     
/* 1126 */     long compliance = ClassFileConstants.getComplianceLevelForJavaVersion(level + 44);
/* 1127 */     this.scanner = new Scanner(
/* 1128 */         true, 
/* 1129 */         true, 
/* 1130 */         false, 
/* 1131 */         compliance, 
/* 1132 */         compliance, 
/* 1133 */         null, 
/* 1134 */         null, 
/* 1135 */         true, 
/* 1136 */         false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AST(Map options) {
/* 1170 */     this(((Integer)apiLevelMap.get(options.get("org.eclipse.jdt.core.compiler.source"))).intValue(), "enabled".equals(options.get("org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures")));
/*      */     
/*      */     long sourceLevel, complianceLevel;
/*      */     
/* 1174 */     switch (this.apiLevel) {
/*      */       case 2:
/*      */       case 3:
/* 1177 */         sourceLevel = 3080192L;
/* 1178 */         complianceLevel = 3211264L;
/*      */         break;
/*      */       case 4:
/* 1181 */         sourceLevel = 3342336L;
/* 1182 */         complianceLevel = 3342336L;
/*      */         break;
/*      */       default:
/* 1185 */         sourceLevel = ((Long)jdkLevelMap.get(options.get("org.eclipse.jdt.core.compiler.source"))).longValue();
/* 1186 */         complianceLevel = sourceLevel; break;
/*      */     } 
/* 1188 */     this.scanner = new Scanner(
/* 1189 */         true, 
/* 1190 */         true, 
/* 1191 */         false, 
/* 1192 */         sourceLevel, 
/* 1193 */         complianceLevel, 
/* 1194 */         null, 
/* 1195 */         null, 
/* 1196 */         true, 
/* 1197 */         this.previewEnabled);
/*      */   }
/*      */   
/*      */   private static Map<String, Long> getLevelMapTable() {
/* 1201 */     Map<String, Long> t = new HashMap<>();
/* 1202 */     t.put(null, Long.valueOf(3014656L));
/* 1203 */     t.put("1.2", Long.valueOf(3014656L));
/* 1204 */     t.put("1.3", Long.valueOf(3080192L));
/* 1205 */     t.put("1.4", Long.valueOf(3145728L));
/* 1206 */     t.put("1.5", Long.valueOf(3211264L));
/* 1207 */     t.put("1.6", Long.valueOf(3276800L));
/* 1208 */     t.put("1.7", Long.valueOf(3342336L));
/* 1209 */     t.put("1.8", Long.valueOf(3407872L));
/* 1210 */     t.put("9", Long.valueOf(3473408L));
/* 1211 */     t.put("10", Long.valueOf(3538944L));
/* 1212 */     t.put("11", Long.valueOf(3604480L));
/* 1213 */     t.put("12", Long.valueOf(3670016L));
/* 1214 */     t.put("13", Long.valueOf(3735552L));
/* 1215 */     t.put("14", Long.valueOf(3801088L));
/* 1216 */     t.put("15", Long.valueOf(3866624L));
/* 1217 */     t.put("16", Long.valueOf(3932160L));
/* 1218 */     t.put("17", Long.valueOf(3997696L));
/* 1219 */     t.put("18", Long.valueOf(4063232L));
/* 1220 */     t.put("19", Long.valueOf(4128768L));
/* 1221 */     t.put("20", Long.valueOf(4194304L));
/* 1222 */     return Collections.unmodifiableMap(t);
/*      */   }
/*      */   private static Map<String, Integer> getApiLevelMapTable() {
/* 1225 */     Map<String, Integer> t = new HashMap<>();
/* 1226 */     t.put(null, Integer.valueOf(2));
/* 1227 */     t.put("1.2", Integer.valueOf(2));
/* 1228 */     t.put("1.3", Integer.valueOf(3));
/* 1229 */     t.put("1.4", Integer.valueOf(4));
/* 1230 */     t.put("1.5", Integer.valueOf(4));
/* 1231 */     t.put("1.6", Integer.valueOf(4));
/* 1232 */     t.put("1.7", Integer.valueOf(4));
/* 1233 */     t.put("1.8", Integer.valueOf(8));
/* 1234 */     t.put("9", Integer.valueOf(9));
/* 1235 */     t.put("10", Integer.valueOf(10));
/* 1236 */     t.put("11", Integer.valueOf(11));
/* 1237 */     t.put("12", Integer.valueOf(12));
/* 1238 */     t.put("13", Integer.valueOf(13));
/* 1239 */     t.put("14", Integer.valueOf(14));
/* 1240 */     t.put("15", Integer.valueOf(15));
/* 1241 */     t.put("16", Integer.valueOf(16));
/* 1242 */     t.put("17", Integer.valueOf(17));
/* 1243 */     t.put("18", Integer.valueOf(18));
/* 1244 */     t.put("19", Integer.valueOf(19));
/* 1245 */     t.put("20", Integer.valueOf(20));
/* 1246 */     return Collections.unmodifiableMap(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int apiLevel() {
/* 1256 */     return this.apiLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ASTNode createInstance(Class nodeClass) {
/* 1271 */     if (nodeClass == null) {
/* 1272 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/*      */     try {
/* 1276 */       Constructor c = nodeClass.getDeclaredConstructor(AST_CLASS);
/* 1277 */       Object result = c.newInstance(this.THIS_AST);
/* 1278 */       return (ASTNode)result;
/* 1279 */     } catch (NoSuchMethodException|InstantiationException|IllegalAccessException e) {
/*      */ 
/*      */       
/* 1282 */       throw new IllegalArgumentException(e);
/* 1283 */     } catch (InvocationTargetException e) {
/*      */ 
/*      */       
/* 1286 */       throw new IllegalArgumentException(e.getCause());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ASTNode createInstance(int nodeType) {
/* 1306 */     Class nodeClass = ASTNode.nodeClassForType(nodeType);
/* 1307 */     return createInstance(nodeClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void disableEvents() {
/* 1318 */     synchronized (this.internalASTLock) {
/*      */       
/* 1320 */       this.disableEvents++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   BindingResolver getBindingResolver() {
/* 1331 */     return this.resolver;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getDefaultNodeFlag() {
/* 1341 */     return this.defaultNodeFlag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   NodeEventHandler getEventHandler() {
/* 1351 */     return this.eventHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasBindingsRecovery() {
/* 1361 */     return ((this.bits & 0x4) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasResolvedBindings() {
/* 1371 */     return ((this.bits & Integer.MIN_VALUE) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasStatementsRecovery() {
/* 1381 */     return ((this.bits & 0x2) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Name internalNewName(String[] identifiers) {
/* 1388 */     int count = identifiers.length;
/* 1389 */     if (count == 0) {
/* 1390 */       throw new IllegalArgumentException();
/*      */     }
/* 1392 */     SimpleName simpleName = new SimpleName(this);
/* 1393 */     simpleName.internalSetIdentifier(identifiers[0]);
/* 1394 */     Name result = simpleName;
/* 1395 */     for (int i = 1; i < count; i++) {
/* 1396 */       SimpleName name = new SimpleName(this);
/* 1397 */       name.internalSetIdentifier(identifiers[i]);
/* 1398 */       result = newQualifiedName(result, name);
/*      */     } 
/* 1400 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long modificationCount() {
/* 1430 */     return this.modificationCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void modifying() {
/* 1451 */     if (this.disableEvents > 0) {
/*      */       return;
/*      */     }
/*      */     
/* 1455 */     this.modificationCount++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setArrayComponentType(ArrayType arrayType, Type type) {
/* 1463 */     arrayType.setComponentType(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationTypeDeclaration newAnnotationTypeDeclaration() {
/* 1477 */     AnnotationTypeDeclaration result = new AnnotationTypeDeclaration(this);
/* 1478 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationTypeMemberDeclaration newAnnotationTypeMemberDeclaration() {
/* 1493 */     AnnotationTypeMemberDeclaration result = new AnnotationTypeMemberDeclaration(this);
/* 1494 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnonymousClassDeclaration newAnonymousClassDeclaration() {
/* 1504 */     AnonymousClassDeclaration result = new AnonymousClassDeclaration(this);
/* 1505 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayAccess newArrayAccess() {
/* 1516 */     ArrayAccess result = new ArrayAccess(this);
/* 1517 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayCreation newArrayCreation() {
/* 1559 */     ArrayCreation result = new ArrayCreation(this);
/* 1560 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayInitializer newArrayInitializer() {
/* 1570 */     ArrayInitializer result = new ArrayInitializer(this);
/* 1571 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayType newArrayType(Type elementType) {
/* 1594 */     if (this.apiLevel < 8) {
/* 1595 */       ArrayType arrayType = new ArrayType(this);
/* 1596 */       setArrayComponentType(arrayType, elementType);
/* 1597 */       return arrayType;
/*      */     } 
/* 1599 */     if (elementType.isArrayType()) {
/* 1600 */       throw new IllegalArgumentException();
/*      */     }
/* 1602 */     ArrayType result = new ArrayType(this);
/* 1603 */     result.setElementType(elementType);
/* 1604 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayType newArrayType(Type elementType, int dimensions) {
/* 1630 */     if (elementType == null) {
/* 1631 */       throw new IllegalArgumentException();
/*      */     }
/* 1633 */     if (dimensions < 0 || dimensions > 255)
/*      */     {
/* 1635 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/* 1638 */     if (this.apiLevel < 8) {
/* 1639 */       if (dimensions < 1) {
/* 1640 */         throw new IllegalArgumentException();
/*      */       }
/* 1642 */       ArrayType arrayType = new ArrayType(this);
/* 1643 */       setArrayComponentType(arrayType, elementType);
/* 1644 */       for (int j = 2; j <= dimensions; j++) {
/* 1645 */         arrayType = newArrayType(arrayType);
/*      */       }
/* 1647 */       return arrayType;
/*      */     } 
/*      */     
/* 1650 */     if (elementType.isArrayType()) {
/* 1651 */       throw new IllegalArgumentException();
/*      */     }
/* 1653 */     ArrayType result = new ArrayType(this, 0);
/* 1654 */     result.setElementType(elementType);
/* 1655 */     for (int i = 0; i < dimensions; i++) {
/* 1656 */       result.dimensions().add(new Dimension(this));
/*      */     }
/* 1658 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AssertStatement newAssertStatement() {
/* 1670 */     return new AssertStatement(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Assignment newAssignment() {
/* 1682 */     Assignment result = new Assignment(this);
/* 1683 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Block newBlock() {
/* 1693 */     return new Block(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BlockComment newBlockComment() {
/* 1710 */     BlockComment result = new BlockComment(this);
/* 1711 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BooleanLiteral newBooleanLiteral(boolean value) {
/* 1731 */     BooleanLiteral result = new BooleanLiteral(this);
/* 1732 */     result.setBooleanValue(value);
/* 1733 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BreakStatement newBreakStatement() {
/* 1743 */     return new BreakStatement(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CaseDefaultExpression newCaseDefaultExpression() {
/* 1753 */     CaseDefaultExpression result = new CaseDefaultExpression(this);
/* 1754 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CastExpression newCastExpression() {
/* 1765 */     CastExpression result = new CastExpression(this);
/* 1766 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CatchClause newCatchClause() {
/* 1777 */     return new CatchClause(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CharacterLiteral newCharacterLiteral() {
/* 1787 */     return new CharacterLiteral(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClassInstanceCreation newClassInstanceCreation() {
/* 1800 */     ClassInstanceCreation result = new ClassInstanceCreation(this);
/* 1801 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CompilationUnit newCompilationUnit() {
/* 1813 */     return new CompilationUnit(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConditionalExpression newConditionalExpression() {
/* 1824 */     ConditionalExpression result = new ConditionalExpression(this);
/* 1825 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConstructorInvocation newConstructorInvocation() {
/* 1841 */     ConstructorInvocation result = new ConstructorInvocation(this);
/* 1842 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContinueStatement newContinueStatement() {
/* 1852 */     return new ContinueStatement(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CreationReference newCreationReference() {
/* 1864 */     CreationReference result = new CreationReference(this);
/* 1865 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DoStatement newDoStatement() {
/* 1876 */     return new DoStatement(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public EmptyStatement newEmptyStatement() {
/* 1885 */     return new EmptyStatement(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public EnhancedForStatement newEnhancedForStatement() {
/* 1899 */     return new EnhancedForStatement(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public EnumConstantDeclaration newEnumConstantDeclaration() {
/* 1914 */     EnumConstantDeclaration result = new EnumConstantDeclaration(this);
/* 1915 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public EnumDeclaration newEnumDeclaration() {
/* 1931 */     EnumDeclaration result = new EnumDeclaration(this);
/* 1932 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExportsDirective newExportsStatement() {
/* 1944 */     ExportsDirective result = new ExportsDirective(this);
/* 1945 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExpressionMethodReference newExpressionMethodReference() {
/* 1958 */     ExpressionMethodReference result = new ExpressionMethodReference(this);
/* 1959 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExpressionStatement newExpressionStatement(Expression expression) {
/* 1982 */     ExpressionStatement result = new ExpressionStatement(this);
/* 1983 */     result.setExpression(expression);
/* 1984 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Dimension newDimension() {
/* 2002 */     Dimension result = new Dimension(this);
/* 2003 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FieldAccess newFieldAccess() {
/* 2014 */     FieldAccess result = new FieldAccess(this);
/* 2015 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FieldDeclaration newFieldDeclaration(VariableDeclarationFragment fragment) {
/* 2041 */     if (fragment == null) {
/* 2042 */       throw new IllegalArgumentException();
/*      */     }
/* 2044 */     FieldDeclaration result = new FieldDeclaration(this);
/* 2045 */     result.fragments().add(fragment);
/* 2046 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ForStatement newForStatement() {
/* 2057 */     return new ForStatement(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GuardedPattern newGuardedPattern() {
/* 2068 */     GuardedPattern result = new GuardedPattern(this);
/* 2069 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IfStatement newIfStatement() {
/* 2080 */     return new IfStatement(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImportDeclaration newImportDeclaration() {
/* 2091 */     ImportDeclaration result = new ImportDeclaration(this);
/* 2092 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InfixExpression newInfixExpression() {
/* 2104 */     InfixExpression result = new InfixExpression(this);
/* 2105 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Initializer newInitializer() {
/* 2116 */     Initializer result = new Initializer(this);
/* 2117 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InstanceofExpression newInstanceofExpression() {
/* 2128 */     InstanceofExpression result = new InstanceofExpression(this);
/* 2129 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Javadoc newJavadoc() {
/* 2141 */     Javadoc result = new Javadoc(this);
/* 2142 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaDocRegion newJavaDocRegion() {
/* 2155 */     JavaDocRegion result = new JavaDocRegion(this);
/* 2156 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaDocTextElement newJavaDocTextElement() {
/* 2171 */     JavaDocTextElement result = new JavaDocTextElement(this);
/* 2172 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LabeledStatement newLabeledStatement() {
/* 2182 */     return new LabeledStatement(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LambdaExpression newLambdaExpression() {
/* 2195 */     LambdaExpression result = new LambdaExpression(this);
/* 2196 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LineComment newLineComment() {
/* 2213 */     LineComment result = new LineComment(this);
/* 2214 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MarkerAnnotation newMarkerAnnotation() {
/* 2227 */     MarkerAnnotation result = new MarkerAnnotation(this);
/* 2228 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MemberRef newMemberRef() {
/* 2244 */     MemberRef result = new MemberRef(this);
/* 2245 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MemberValuePair newMemberValuePair() {
/* 2260 */     MemberValuePair result = new MemberValuePair(this);
/* 2261 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodDeclaration newMethodDeclaration() {
/* 2279 */     MethodDeclaration result = new MethodDeclaration(this);
/* 2280 */     result.setConstructor(false);
/* 2281 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodInvocation newMethodInvocation() {
/* 2293 */     MethodInvocation result = new MethodInvocation(this);
/* 2294 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodRef newMethodRef() {
/* 2311 */     MethodRef result = new MethodRef(this);
/* 2312 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodRefParameter newMethodRefParameter() {
/* 2328 */     MethodRefParameter result = new MethodRefParameter(this);
/* 2329 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Modifier newModifier(Modifier.ModifierKeyword keyword) {
/* 2344 */     Modifier result = new Modifier(this);
/* 2345 */     result.setKeyword(keyword);
/* 2346 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ModuleModifier newModuleModifier(ModuleModifier.ModuleModifierKeyword keyword) {
/* 2361 */     ModuleModifier result = new ModuleModifier(this);
/* 2362 */     result.setKeyword(keyword);
/* 2363 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List newModifiers(int flags) {
/* 2384 */     if (this.apiLevel == 2) {
/* 2385 */       unsupportedIn2();
/*      */     }
/* 2387 */     List<Modifier> result = new ArrayList(3);
/* 2388 */     if (Modifier.isPublic(flags)) {
/* 2389 */       result.add(newModifier(Modifier.ModifierKeyword.PUBLIC_KEYWORD));
/*      */     }
/* 2391 */     if (Modifier.isProtected(flags)) {
/* 2392 */       result.add(newModifier(Modifier.ModifierKeyword.PROTECTED_KEYWORD));
/*      */     }
/* 2394 */     if (Modifier.isPrivate(flags)) {
/* 2395 */       result.add(newModifier(Modifier.ModifierKeyword.PRIVATE_KEYWORD));
/*      */     }
/* 2397 */     if (Modifier.isAbstract(flags)) {
/* 2398 */       result.add(newModifier(Modifier.ModifierKeyword.ABSTRACT_KEYWORD));
/*      */     }
/* 2400 */     if (Modifier.isDefault(flags)) {
/* 2401 */       result.add(newModifier(Modifier.ModifierKeyword.DEFAULT_KEYWORD));
/*      */     }
/* 2403 */     if (Modifier.isStatic(flags)) {
/* 2404 */       result.add(newModifier(Modifier.ModifierKeyword.STATIC_KEYWORD));
/*      */     }
/* 2406 */     if (Modifier.isFinal(flags)) {
/* 2407 */       result.add(newModifier(Modifier.ModifierKeyword.FINAL_KEYWORD));
/*      */     }
/* 2409 */     if (Modifier.isSynchronized(flags)) {
/* 2410 */       result.add(newModifier(Modifier.ModifierKeyword.SYNCHRONIZED_KEYWORD));
/*      */     }
/* 2412 */     if (Modifier.isNative(flags)) {
/* 2413 */       result.add(newModifier(Modifier.ModifierKeyword.NATIVE_KEYWORD));
/*      */     }
/* 2415 */     if (Modifier.isStrictfp(flags)) {
/* 2416 */       result.add(newModifier(Modifier.ModifierKeyword.STRICTFP_KEYWORD));
/*      */     }
/* 2418 */     if (Modifier.isTransient(flags)) {
/* 2419 */       result.add(newModifier(Modifier.ModifierKeyword.TRANSIENT_KEYWORD));
/*      */     }
/* 2421 */     if (Modifier.isVolatile(flags)) {
/* 2422 */       result.add(newModifier(Modifier.ModifierKeyword.VOLATILE_KEYWORD));
/*      */     }
/* 2424 */     if (Modifier.isSealed(flags)) {
/* 2425 */       result.add(newModifier(Modifier.ModifierKeyword.SEALED_KEYWORD));
/*      */     }
/* 2427 */     if (Modifier.isNonSealed(flags)) {
/* 2428 */       result.add(newModifier(Modifier.ModifierKeyword.NON_SEALED_KEYWORD));
/*      */     }
/* 2430 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ModuleDeclaration newModuleDeclaration() {
/* 2443 */     ModuleDeclaration result = new ModuleDeclaration(this);
/* 2444 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Name newName(String qualifiedName) {
/* 2471 */     StringTokenizer t = new StringTokenizer(qualifiedName, ".", true);
/* 2472 */     Name result = null;
/*      */ 
/*      */     
/* 2475 */     int balance = 0;
/* 2476 */     while (t.hasMoreTokens()) {
/* 2477 */       String s = t.nextToken();
/* 2478 */       if (s.indexOf('.') >= 0) {
/*      */         
/* 2480 */         if (s.length() > 1)
/*      */         {
/* 2482 */           throw new IllegalArgumentException();
/*      */         }
/* 2484 */         balance--;
/* 2485 */         if (balance < 0) {
/* 2486 */           throw new IllegalArgumentException();
/*      */         }
/*      */         continue;
/*      */       } 
/* 2490 */       balance++;
/* 2491 */       SimpleName name = newSimpleName(s);
/* 2492 */       if (result == null) {
/* 2493 */         result = name; continue;
/*      */       } 
/* 2495 */       result = newQualifiedName(result, name);
/*      */     } 
/*      */ 
/*      */     
/* 2499 */     if (balance != 1) {
/* 2500 */       throw new IllegalArgumentException();
/*      */     }
/* 2502 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Name newName(String[] identifiers) {
/* 2523 */     int count = identifiers.length;
/* 2524 */     if (count == 0) {
/* 2525 */       throw new IllegalArgumentException();
/*      */     }
/* 2527 */     Name result = newSimpleName(identifiers[0]);
/* 2528 */     for (int i = 1; i < count; i++) {
/* 2529 */       SimpleName name = newSimpleName(identifiers[i]);
/* 2530 */       result = newQualifiedName(result, name);
/*      */     } 
/* 2532 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NameQualifiedType newNameQualifiedType(Name qualifier, SimpleName name) {
/* 2552 */     NameQualifiedType result = new NameQualifiedType(this);
/* 2553 */     result.setQualifier(qualifier);
/* 2554 */     result.setName(name);
/* 2555 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NormalAnnotation newNormalAnnotation() {
/* 2569 */     NormalAnnotation result = new NormalAnnotation(this);
/* 2570 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NullLiteral newNullLiteral() {
/* 2579 */     return new NullLiteral(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NullPattern newNullPattern() {
/* 2589 */     NullPattern result = new NullPattern(this);
/* 2590 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NumberLiteral newNumberLiteral() {
/* 2600 */     NumberLiteral result = new NumberLiteral(this);
/* 2601 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NumberLiteral newNumberLiteral(String literal) {
/* 2613 */     if (literal == null) {
/* 2614 */       throw new IllegalArgumentException();
/*      */     }
/* 2616 */     NumberLiteral result = new NumberLiteral(this);
/* 2617 */     result.setToken(literal);
/* 2618 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OpensDirective newOpensDirective() {
/* 2630 */     OpensDirective result = new OpensDirective(this);
/* 2631 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PackageDeclaration newPackageDeclaration() {
/* 2642 */     PackageDeclaration result = new PackageDeclaration(this);
/* 2643 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ParameterizedType newParameterizedType(Type type) {
/* 2662 */     ParameterizedType result = new ParameterizedType(this);
/* 2663 */     result.setType(type);
/* 2664 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ParenthesizedExpression newParenthesizedExpression() {
/* 2674 */     ParenthesizedExpression result = new ParenthesizedExpression(this);
/* 2675 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PatternInstanceofExpression newPatternInstanceofExpression() {
/* 2687 */     PatternInstanceofExpression result = new PatternInstanceofExpression(this);
/* 2688 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PostfixExpression newPostfixExpression() {
/* 2699 */     PostfixExpression result = new PostfixExpression(this);
/* 2700 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PrefixExpression newPrefixExpression() {
/* 2711 */     PrefixExpression result = new PrefixExpression(this);
/* 2712 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PrimitiveType newPrimitiveType(PrimitiveType.Code typeCode) {
/* 2725 */     PrimitiveType result = new PrimitiveType(this);
/* 2726 */     result.setPrimitiveTypeCode(typeCode);
/* 2727 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ProvidesDirective newProvidesDirective() {
/* 2739 */     ProvidesDirective result = new ProvidesDirective(this);
/* 2740 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QualifiedName newQualifiedName(Name qualifier, SimpleName name) {
/* 2759 */     QualifiedName result = new QualifiedName(this);
/* 2760 */     result.setQualifier(qualifier);
/* 2761 */     result.setName(name);
/* 2762 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public QualifiedType newQualifiedType(Type qualifier, SimpleName name) {
/* 2783 */     QualifiedType result = new QualifiedType(this);
/* 2784 */     result.setQualifier(qualifier);
/* 2785 */     result.setName(name);
/* 2786 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RecordDeclaration newRecordDeclaration() {
/* 2800 */     RecordDeclaration result = new RecordDeclaration(this);
/* 2801 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RecordPattern newRecordPattern() {
/* 2812 */     RecordPattern result = new RecordPattern(this);
/* 2813 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RequiresDirective newRequiresDirective() {
/* 2824 */     RequiresDirective result = new RequiresDirective(this);
/* 2825 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ReturnStatement newReturnStatement() {
/* 2835 */     return new ReturnStatement(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SimpleName newSimpleName(String identifier) {
/* 2849 */     if (identifier == null) {
/* 2850 */       throw new IllegalArgumentException();
/*      */     }
/* 2852 */     SimpleName result = new SimpleName(this);
/* 2853 */     result.setIdentifier(identifier);
/* 2854 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SimpleType newSimpleType(Name typeName) {
/* 2875 */     SimpleType result = new SimpleType(this);
/* 2876 */     result.setName(typeName);
/* 2877 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SingleMemberAnnotation newSingleMemberAnnotation() {
/* 2890 */     SingleMemberAnnotation result = new SingleMemberAnnotation(this);
/* 2891 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SingleVariableDeclaration newSingleVariableDeclaration() {
/* 2903 */     SingleVariableDeclaration result = new SingleVariableDeclaration(this);
/* 2904 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StringLiteral newStringLiteral() {
/* 2915 */     return new StringLiteral(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SuperConstructorInvocation newSuperConstructorInvocation() {
/* 2931 */     SuperConstructorInvocation result = 
/* 2932 */       new SuperConstructorInvocation(this);
/* 2933 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SuperFieldAccess newSuperFieldAccess() {
/* 2944 */     SuperFieldAccess result = new SuperFieldAccess(this);
/* 2945 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SuperMethodInvocation newSuperMethodInvocation() {
/* 2957 */     SuperMethodInvocation result = new SuperMethodInvocation(this);
/* 2958 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SuperMethodReference newSuperMethodReference() {
/* 2970 */     SuperMethodReference result = new SuperMethodReference(this);
/* 2971 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SwitchExpression newSwitchExpression() {
/* 2983 */     SwitchExpression result = new SwitchExpression(this);
/* 2984 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SwitchCase newSwitchCase() {
/* 2995 */     return new SwitchCase(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SwitchStatement newSwitchStatement() {
/* 3006 */     return new SwitchStatement(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SynchronizedStatement newSynchronizedStatement() {
/* 3017 */     return new SynchronizedStatement(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TagElement newTagElement() {
/* 3032 */     TagElement result = new TagElement(this);
/* 3033 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TagProperty newTagProperty() {
/* 3048 */     TagProperty result = new TagProperty(this);
/* 3049 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TextBlock newTextBlock() {
/* 3060 */     return new TextBlock(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TextElement newTextElement() {
/* 3075 */     TextElement result = new TextElement(this);
/* 3076 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ThisExpression newThisExpression() {
/* 3086 */     ThisExpression result = new ThisExpression(this);
/* 3087 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ThrowStatement newThrowStatement() {
/* 3097 */     return new ThrowStatement(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TryStatement newTryStatement() {
/* 3108 */     return new TryStatement(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeDeclaration newTypeDeclaration() {
/* 3124 */     TypeDeclaration result = new TypeDeclaration(this);
/* 3125 */     result.setInterface(false);
/* 3126 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeDeclarationStatement newTypeDeclarationStatement(AbstractTypeDeclaration decl) {
/* 3149 */     TypeDeclarationStatement result = new TypeDeclarationStatement(this);
/* 3150 */     if (this.apiLevel == 2) {
/* 3151 */       result.internalSetTypeDeclaration((TypeDeclaration)decl);
/*      */     }
/* 3153 */     if (this.apiLevel >= 3) {
/* 3154 */       result.setDeclaration(decl);
/*      */     }
/* 3156 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeDeclarationStatement newTypeDeclarationStatement(TypeDeclaration decl) {
/* 3178 */     TypeDeclarationStatement result = new TypeDeclarationStatement(this);
/* 3179 */     result.setDeclaration(decl);
/* 3180 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeLiteral newTypeLiteral() {
/* 3190 */     TypeLiteral result = new TypeLiteral(this);
/* 3191 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeMethodReference newTypeMethodReference() {
/* 3204 */     TypeMethodReference result = new TypeMethodReference(this);
/* 3205 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeParameter newTypeParameter() {
/* 3218 */     TypeParameter result = new TypeParameter(this);
/* 3219 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypePattern newTypePattern() {
/* 3230 */     TypePattern result = new TypePattern(this);
/* 3231 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UnionType newUnionType() {
/* 3244 */     return new UnionType(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UsesDirective newUsesDirective() {
/* 3256 */     UsesDirective result = new UsesDirective(this);
/* 3257 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IntersectionType newIntersectionType() {
/* 3270 */     return new IntersectionType(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VariableDeclarationExpression newVariableDeclarationExpression(VariableDeclarationFragment fragment) {
/* 3296 */     if (fragment == null) {
/* 3297 */       throw new IllegalArgumentException();
/*      */     }
/* 3299 */     VariableDeclarationExpression result = 
/* 3300 */       new VariableDeclarationExpression(this);
/* 3301 */     result.fragments().add(fragment);
/* 3302 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VariableDeclarationFragment newVariableDeclarationFragment() {
/* 3313 */     VariableDeclarationFragment result = new VariableDeclarationFragment(this);
/* 3314 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VariableDeclarationStatement newVariableDeclarationStatement(VariableDeclarationFragment fragment) {
/* 3341 */     if (fragment == null) {
/* 3342 */       throw new IllegalArgumentException();
/*      */     }
/* 3344 */     VariableDeclarationStatement result = 
/* 3345 */       new VariableDeclarationStatement(this);
/* 3346 */     result.fragments().add(fragment);
/* 3347 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WhileStatement newWhileStatement() {
/* 3358 */     return new WhileStatement(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WildcardType newWildcardType() {
/* 3371 */     WildcardType result = new WildcardType(this);
/* 3372 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public YieldStatement newYieldStatement() {
/* 3383 */     return new YieldStatement(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void postAddChildEvent(ASTNode node, ASTNode child, StructuralPropertyDescriptor property) {
/* 3396 */     synchronized (this.internalASTLock) {
/*      */       
/* 3398 */       if (this.disableEvents > 0) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 3403 */       disableEvents();
/*      */     } 
/*      */     
/*      */     try {
/* 3407 */       this.eventHandler.postAddChildEvent(node, child, property);
/*      */     }
/*      */     finally {
/*      */       
/* 3411 */       reenableEvents();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void postCloneNodeEvent(ASTNode node, ASTNode clone) {
/* 3423 */     synchronized (this.internalASTLock) {
/*      */       
/* 3425 */       if (this.disableEvents > 0) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 3430 */       disableEvents();
/*      */     } 
/*      */     
/*      */     try {
/* 3434 */       this.eventHandler.postCloneNodeEvent(node, clone);
/*      */     }
/*      */     finally {
/*      */       
/* 3438 */       reenableEvents();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void postRemoveChildEvent(ASTNode node, ASTNode child, StructuralPropertyDescriptor property) {
/* 3452 */     synchronized (this.internalASTLock) {
/*      */       
/* 3454 */       if (this.disableEvents > 0) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 3459 */       disableEvents();
/*      */     } 
/*      */     
/*      */     try {
/* 3463 */       this.eventHandler.postRemoveChildEvent(node, child, property);
/*      */     }
/*      */     finally {
/*      */       
/* 3467 */       reenableEvents();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void postReplaceChildEvent(ASTNode node, ASTNode child, ASTNode newChild, StructuralPropertyDescriptor property) {
/* 3482 */     synchronized (this.internalASTLock) {
/*      */       
/* 3484 */       if (this.disableEvents > 0) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 3489 */       disableEvents();
/*      */     } 
/*      */     
/*      */     try {
/* 3493 */       this.eventHandler.postReplaceChildEvent(node, child, newChild, property);
/*      */     }
/*      */     finally {
/*      */       
/* 3497 */       reenableEvents();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void postValueChangeEvent(ASTNode node, SimplePropertyDescriptor property) {
/* 3511 */     synchronized (this.internalASTLock) {
/*      */       
/* 3513 */       if (this.disableEvents > 0) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 3518 */       disableEvents();
/*      */     } 
/*      */     
/*      */     try {
/* 3522 */       this.eventHandler.postValueChangeEvent(node, property);
/*      */     }
/*      */     finally {
/*      */       
/* 3526 */       reenableEvents();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void preAddChildEvent(ASTNode node, ASTNode child, StructuralPropertyDescriptor property) {
/* 3540 */     synchronized (this.internalASTLock) {
/*      */       
/* 3542 */       if (this.disableEvents > 0) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 3547 */       disableEvents();
/*      */     } 
/*      */     
/*      */     try {
/* 3551 */       this.eventHandler.preAddChildEvent(node, child, property);
/*      */     }
/*      */     finally {
/*      */       
/* 3555 */       reenableEvents();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void preCloneNodeEvent(ASTNode node) {
/* 3566 */     synchronized (this.internalASTLock) {
/*      */       
/* 3568 */       if (this.disableEvents > 0) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 3573 */       disableEvents();
/*      */     } 
/*      */     
/*      */     try {
/* 3577 */       this.eventHandler.preCloneNodeEvent(node);
/*      */     }
/*      */     finally {
/*      */       
/* 3581 */       reenableEvents();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void preRemoveChildEvent(ASTNode node, ASTNode child, StructuralPropertyDescriptor property) {
/* 3595 */     synchronized (this.internalASTLock) {
/*      */       
/* 3597 */       if (this.disableEvents > 0) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 3602 */       disableEvents();
/*      */     } 
/*      */     
/*      */     try {
/* 3606 */       this.eventHandler.preRemoveChildEvent(node, child, property);
/*      */     }
/*      */     finally {
/*      */       
/* 3610 */       reenableEvents();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void preReplaceChildEvent(ASTNode node, ASTNode child, ASTNode newChild, StructuralPropertyDescriptor property) {
/* 3625 */     synchronized (this.internalASTLock) {
/*      */       
/* 3627 */       if (this.disableEvents > 0) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 3632 */       disableEvents();
/*      */     } 
/*      */     
/*      */     try {
/* 3636 */       this.eventHandler.preReplaceChildEvent(node, child, newChild, property);
/*      */     }
/*      */     finally {
/*      */       
/* 3640 */       reenableEvents();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void preValueChangeEvent(ASTNode node, SimplePropertyDescriptor property) {
/* 3654 */     synchronized (this.internalASTLock) {
/*      */       
/* 3656 */       if (this.disableEvents > 0) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 3661 */       disableEvents();
/*      */     } 
/*      */     
/*      */     try {
/* 3665 */       this.eventHandler.preValueChangeEvent(node, property);
/*      */     }
/*      */     finally {
/*      */       
/* 3669 */       reenableEvents();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void recordModifications(CompilationUnit root) {
/* 3692 */     if (this.modificationCount != this.originalModificationCount)
/* 3693 */       throw new IllegalArgumentException("AST is already modified"); 
/* 3694 */     if (this.rewriter != null)
/* 3695 */       throw new IllegalArgumentException("AST modifications are already recorded"); 
/* 3696 */     if ((root.getFlags() & 0x4) != 0)
/* 3697 */       throw new IllegalArgumentException("Root node is unmodifiable"); 
/* 3698 */     if (root.getAST() != this) {
/* 3699 */       throw new IllegalArgumentException("Root node is not owned by this ast");
/*      */     }
/*      */     
/* 3702 */     this.rewriter = new InternalASTRewrite(root);
/* 3703 */     setEventHandler(this.rewriter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void reenableEvents() {
/* 3716 */     synchronized (this.internalASTLock) {
/*      */       
/* 3718 */       this.disableEvents--;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ITypeBinding resolveWellKnownType(String name) {
/* 3768 */     if (name == null) {
/* 3769 */       return null;
/*      */     }
/* 3771 */     return getBindingResolver().resolveWellKnownType(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   TextEdit rewrite(IDocument document, Map options) {
/* 3797 */     if (document == null) {
/* 3798 */       throw new IllegalArgumentException();
/*      */     }
/* 3800 */     if (this.rewriter == null) {
/* 3801 */       throw new IllegalStateException("Modifications record is not enabled");
/*      */     }
/* 3803 */     return this.rewriter.rewriteAST(document, options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setBindingResolver(BindingResolver resolver) {
/* 3812 */     if (resolver == null) {
/* 3813 */       throw new IllegalArgumentException();
/*      */     }
/* 3815 */     this.resolver = resolver;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setDefaultNodeFlag(int flag) {
/* 3825 */     this.defaultNodeFlag = flag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setEventHandler(NodeEventHandler eventHandler) {
/* 3835 */     if (this.eventHandler == null) {
/* 3836 */       throw new IllegalArgumentException();
/*      */     }
/* 3838 */     this.eventHandler = eventHandler;
/*      */   }
/*      */   
/*      */   void setFlag(int newValue) {
/* 3842 */     this.bits |= newValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setOriginalModificationCount(long count) {
/* 3851 */     this.originalModificationCount = count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void supportedOnlyIn2() {
/* 3862 */     if (this.apiLevel != 2) {
/* 3863 */       throw new UnsupportedOperationException("Operation not supported in JLS2 AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void unsupportedIn2() {
/* 3875 */     if (this.apiLevel == 2) {
/* 3876 */       throw new UnsupportedOperationException("Operation not supported in JLS2 AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPreviewEnabledSet() {
/* 3888 */     return this.previewEnabled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPreviewEnabled() {
/* 3897 */     if (this.apiLevel == 20 && this.previewEnabled) {
/* 3898 */       return true;
/*      */     }
/* 3900 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getJLSLatest() {
/* 3910 */     return 20;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\AST.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */