/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InstanceofExpression
/*     */   extends Expression
/*     */ {
/*  38 */   public static final ChildPropertyDescriptor LEFT_OPERAND_PROPERTY = new ChildPropertyDescriptor(InstanceofExpression.class, "leftOperand", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public static final ChildPropertyDescriptor RIGHT_OPERAND_PROPERTY = new ChildPropertyDescriptor(InstanceofExpression.class, "rightOperand", Type.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  55 */     List properyList = new ArrayList(3);
/*  56 */     createPropertyList(InstanceofExpression.class, properyList);
/*  57 */     addProperty(LEFT_OPERAND_PROPERTY, properyList);
/*  58 */     addProperty(RIGHT_OPERAND_PROPERTY, properyList);
/*  59 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  74 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private Expression leftOperand = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private Type rightOperand = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InstanceofExpression(AST ast) {
/*  97 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 102 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 107 */     if (property == LEFT_OPERAND_PROPERTY) {
/* 108 */       if (get) {
/* 109 */         return getLeftOperand();
/*     */       }
/* 111 */       setLeftOperand((Expression)child);
/* 112 */       return null;
/*     */     } 
/*     */     
/* 115 */     if (property == RIGHT_OPERAND_PROPERTY) {
/* 116 */       if (get) {
/* 117 */         return getRightOperand();
/*     */       }
/* 119 */       setRightOperand((Type)child);
/* 120 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 124 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 129 */     return 62;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 134 */     InstanceofExpression result = new InstanceofExpression(target);
/* 135 */     result.setSourceRange(getStartPosition(), getLength());
/* 136 */     result.setLeftOperand((Expression)getLeftOperand().clone(target));
/* 137 */     result.setRightOperand((Type)getRightOperand().clone(target));
/* 138 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 144 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 149 */     boolean visitChildren = visitor.visit(this);
/* 150 */     if (visitChildren) {
/*     */       
/* 152 */       acceptChild(visitor, getLeftOperand());
/* 153 */       acceptChild(visitor, getRightOperand());
/*     */     } 
/* 155 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getLeftOperand() {
/* 164 */     if (this.leftOperand == null)
/*     */     {
/* 166 */       synchronized (this) {
/* 167 */         if (this.leftOperand == null) {
/* 168 */           preLazyInit();
/* 169 */           this.leftOperand = new SimpleName(this.ast);
/* 170 */           postLazyInit(this.leftOperand, LEFT_OPERAND_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 174 */     return this.leftOperand;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLeftOperand(Expression expression) {
/* 189 */     if (expression == null) {
/* 190 */       throw new IllegalArgumentException();
/*     */     }
/* 192 */     ASTNode oldChild = this.leftOperand;
/* 193 */     preReplaceChild(oldChild, expression, LEFT_OPERAND_PROPERTY);
/* 194 */     this.leftOperand = expression;
/* 195 */     postReplaceChild(oldChild, expression, LEFT_OPERAND_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getRightOperand() {
/* 204 */     if (this.rightOperand == null)
/*     */     {
/* 206 */       synchronized (this) {
/* 207 */         if (this.rightOperand == null) {
/* 208 */           preLazyInit();
/* 209 */           this.rightOperand = new SimpleType(this.ast);
/* 210 */           postLazyInit(this.rightOperand, RIGHT_OPERAND_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 214 */     return this.rightOperand;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRightOperand(Type referenceType) {
/* 229 */     if (referenceType == null) {
/* 230 */       throw new IllegalArgumentException();
/*     */     }
/* 232 */     ASTNode oldChild = this.rightOperand;
/* 233 */     preReplaceChild(oldChild, referenceType, RIGHT_OPERAND_PROPERTY);
/* 234 */     this.rightOperand = referenceType;
/* 235 */     postReplaceChild(oldChild, referenceType, RIGHT_OPERAND_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 241 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 246 */     return 
/* 247 */       memSize() + (
/* 248 */       (this.leftOperand == null) ? 0 : getLeftOperand().treeSize()) + (
/* 249 */       (this.rightOperand == null) ? 0 : getRightOperand().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\InstanceofExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */