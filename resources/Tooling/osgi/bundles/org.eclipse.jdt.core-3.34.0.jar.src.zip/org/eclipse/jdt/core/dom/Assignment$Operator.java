/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Operator
/*     */ {
/*     */   private String op;
/*     */   
/*     */   private Operator(String op) {
/*  71 */     this.op = op;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  81 */     return this.op;
/*     */   }
/*     */ 
/*     */   
/*  85 */   public static final Operator ASSIGN = new Operator("=");
/*     */   
/*  87 */   public static final Operator PLUS_ASSIGN = new Operator("+=");
/*     */   
/*  89 */   public static final Operator MINUS_ASSIGN = new Operator("-=");
/*     */   
/*  91 */   public static final Operator TIMES_ASSIGN = new Operator("*=");
/*     */   
/*  93 */   public static final Operator DIVIDE_ASSIGN = new Operator("/=");
/*     */   
/*  95 */   public static final Operator BIT_AND_ASSIGN = new Operator("&=");
/*     */   
/*  97 */   public static final Operator BIT_OR_ASSIGN = new Operator("|=");
/*     */   
/*  99 */   public static final Operator BIT_XOR_ASSIGN = new Operator("^=");
/*     */   
/* 101 */   public static final Operator REMAINDER_ASSIGN = new Operator("%=");
/*     */ 
/*     */   
/* 104 */   public static final Operator LEFT_SHIFT_ASSIGN = new Operator("<<=");
/*     */ 
/*     */   
/* 107 */   public static final Operator RIGHT_SHIFT_SIGNED_ASSIGN = new Operator(">>=");
/*     */ 
/*     */   
/* 110 */   public static final Operator RIGHT_SHIFT_UNSIGNED_ASSIGN = new Operator(">>>=");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Operator toOperator(String token) {
/* 125 */     return (Operator)CODES.get(token);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   private static final Map CODES = new HashMap<>(20); static {
/* 135 */     Operator[] ops = { 
/* 136 */         ASSIGN, 
/* 137 */         PLUS_ASSIGN, 
/* 138 */         MINUS_ASSIGN, 
/* 139 */         TIMES_ASSIGN, 
/* 140 */         DIVIDE_ASSIGN, 
/* 141 */         BIT_AND_ASSIGN, 
/* 142 */         BIT_OR_ASSIGN, 
/* 143 */         BIT_XOR_ASSIGN, 
/* 144 */         REMAINDER_ASSIGN, 
/* 145 */         LEFT_SHIFT_ASSIGN, 
/* 146 */         RIGHT_SHIFT_SIGNED_ASSIGN, 
/* 147 */         RIGHT_SHIFT_UNSIGNED_ASSIGN };
/*     */     
/* 149 */     for (int i = 0; i < ops.length; i++)
/* 150 */       CODES.put(ops[i].toString(), ops[i]); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\Assignment$Operator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */