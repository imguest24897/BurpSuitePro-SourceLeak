package org.eclipse.jdt.core;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.text.edits.TextEdit;
import org.eclipse.text.edits.UndoEdit;

public interface ITextEditCapability {
  UndoEdit applyTextEdit(TextEdit paramTextEdit, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IBuffer$ITextEditCapability.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */