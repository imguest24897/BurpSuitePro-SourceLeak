/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PatternInstanceofExpression
/*     */   extends Expression
/*     */ {
/*  42 */   public static final ChildPropertyDescriptor LEFT_OPERAND_PROPERTY = new ChildPropertyDescriptor(PatternInstanceofExpression.class, "leftOperand", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   public static final ChildPropertyDescriptor RIGHT_OPERAND_PROPERTY = new ChildPropertyDescriptor(PatternInstanceofExpression.class, "rightOperand", SingleVariableDeclaration.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public static final ChildPropertyDescriptor PATTERN_PROPERTY = new ChildPropertyDescriptor(PatternInstanceofExpression.class, "pattern", Pattern.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_16;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_20;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  75 */     List properyList = new ArrayList(3);
/*  76 */     createPropertyList(PatternInstanceofExpression.class, properyList);
/*  77 */     addProperty(LEFT_OPERAND_PROPERTY, properyList);
/*  78 */     addProperty(RIGHT_OPERAND_PROPERTY, properyList);
/*  79 */     PROPERTY_DESCRIPTORS_16 = reapPropertyList(properyList);
/*     */     
/*  81 */     properyList = new ArrayList(3);
/*  82 */     createPropertyList(PatternInstanceofExpression.class, properyList);
/*  83 */     addProperty(LEFT_OPERAND_PROPERTY, properyList);
/*  84 */     addProperty(PATTERN_PROPERTY, properyList);
/*  85 */     PROPERTY_DESCRIPTORS_20 = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 100 */     return PROPERTY_DESCRIPTORS_16;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel, boolean isPreview) {
/* 114 */     if (apiLevel >= 20 && isPreview) {
/* 115 */       return PROPERTY_DESCRIPTORS_20;
/*     */     }
/* 117 */     return PROPERTY_DESCRIPTORS_16;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   private Expression leftOperand = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   private SingleVariableDeclaration rightOperand = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   private Pattern pattern = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PatternInstanceofExpression(AST ast) {
/* 146 */     super(ast);
/* 147 */     unsupportedBelow16();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel, boolean isPreview) {
/* 152 */     return propertyDescriptors(apiLevel, isPreview);
/*     */   }
/*     */ 
/*     */   
/*     */   List internalStructuralPropertiesForType(int apiLevel) {
/* 157 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 162 */     if (property == LEFT_OPERAND_PROPERTY) {
/* 163 */       if (get) {
/* 164 */         return getLeftOperand();
/*     */       }
/* 166 */       setLeftOperand((Expression)child);
/* 167 */       return null;
/*     */     } 
/*     */     
/* 170 */     if (property == RIGHT_OPERAND_PROPERTY) {
/* 171 */       if (get) {
/* 172 */         return getRightOperand();
/*     */       }
/* 174 */       setRightOperand((SingleVariableDeclaration)child);
/* 175 */       return null;
/*     */     } 
/*     */     
/* 178 */     if (property == PATTERN_PROPERTY) {
/* 179 */       if (!this.ast.isPreviewEnabled())
/* 180 */         return null; 
/* 181 */       if (get) {
/* 182 */         return getPattern();
/*     */       }
/* 184 */       setPattern((Pattern)child);
/* 185 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 189 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 194 */     return 104;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 199 */     PatternInstanceofExpression result = new PatternInstanceofExpression(target);
/* 200 */     result.setSourceRange(getStartPosition(), getLength());
/* 201 */     result.setLeftOperand((Expression)getLeftOperand().clone(target));
/* 202 */     if (this.ast.apiLevel < 20) {
/* 203 */       result.setRightOperand((SingleVariableDeclaration)getRightOperand().clone(target));
/*     */     } else {
/* 205 */       result.setPattern((Pattern)getPattern().clone(target));
/*     */     } 
/* 207 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 213 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 218 */     boolean visitChildren = visitor.visit(this);
/* 219 */     if (visitChildren) {
/*     */       
/* 221 */       acceptChild(visitor, getLeftOperand());
/* 222 */       if (this.ast.apiLevel >= 20 && this.ast.isPreviewEnabled()) {
/* 223 */         acceptChild(visitor, getPattern());
/*     */       } else {
/* 225 */         acceptChild(visitor, getRightOperand());
/*     */       } 
/*     */     } 
/* 228 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getLeftOperand() {
/* 238 */     if (this.leftOperand == null)
/*     */     {
/* 240 */       synchronized (this) {
/* 241 */         if (this.leftOperand == null) {
/* 242 */           preLazyInit();
/* 243 */           this.leftOperand = new SimpleName(this.ast);
/* 244 */           postLazyInit(this.leftOperand, LEFT_OPERAND_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 248 */     return this.leftOperand;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLeftOperand(Expression expression) {
/* 264 */     if (expression == null) {
/* 265 */       throw new IllegalArgumentException();
/*     */     }
/* 267 */     ASTNode oldChild = this.leftOperand;
/* 268 */     preReplaceChild(oldChild, expression, LEFT_OPERAND_PROPERTY);
/* 269 */     this.leftOperand = expression;
/* 270 */     postReplaceChild(oldChild, expression, LEFT_OPERAND_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SingleVariableDeclaration getRightOperand() {
/* 281 */     if (this.rightOperand == null)
/*     */     {
/* 283 */       synchronized (this) {
/* 284 */         if (this.rightOperand == null) {
/* 285 */           preLazyInit();
/* 286 */           this.rightOperand = new SingleVariableDeclaration(this.ast);
/* 287 */           postLazyInit(this.rightOperand, RIGHT_OPERAND_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 291 */     return this.rightOperand;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pattern getPattern() {
/* 300 */     supportedOnlyIn20();
/* 301 */     if (this.pattern == null)
/*     */     {
/* 303 */       synchronized (this) {
/* 304 */         if (this.pattern == null) {
/* 305 */           preLazyInit();
/* 306 */           this.pattern = new TypePattern(this.ast);
/* 307 */           postLazyInit(this.pattern, PATTERN_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 311 */     return this.pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRightOperand(SingleVariableDeclaration referenceDeclaration) {
/* 327 */     if (referenceDeclaration == null) {
/* 328 */       throw new IllegalArgumentException();
/*     */     }
/* 330 */     ASTNode oldChild = this.rightOperand;
/* 331 */     preReplaceChild(oldChild, referenceDeclaration, RIGHT_OPERAND_PROPERTY);
/* 332 */     this.rightOperand = referenceDeclaration;
/* 333 */     postReplaceChild(oldChild, referenceDeclaration, RIGHT_OPERAND_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPattern(Pattern pattern) {
/* 348 */     supportedOnlyIn20();
/* 349 */     if (pattern == null) {
/* 350 */       throw new IllegalArgumentException();
/*     */     }
/* 352 */     ASTNode oldChild = this.pattern;
/* 353 */     preReplaceChild(oldChild, pattern, PATTERN_PROPERTY);
/* 354 */     this.pattern = pattern;
/* 355 */     postReplaceChild(oldChild, pattern, PATTERN_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 361 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 366 */     return 
/* 367 */       memSize() + (
/* 368 */       (this.leftOperand == null) ? 0 : getLeftOperand().treeSize()) + (
/* 369 */       (this.ast.apiLevel < 20) ? (
/* 370 */       (this.rightOperand == null) ? 0 : getRightOperand().treeSize()) : (
/* 371 */       (this.pattern == null) ? 0 : getPattern().treeSize()));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\PatternInstanceofExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */