package org.eclipse.jdt.core.jdom;

public interface IDOMMethod extends IDOMMember {
  void addException(String paramString) throws IllegalArgumentException;
  
  void addParameter(String paramString1, String paramString2) throws IllegalArgumentException;
  
  String getBody();
  
  void setDefault(String paramString);
  
  String getDefault();
  
  String[] getExceptions();
  
  String[] getTypeParameters();
  
  String getName();
  
  String[] getParameterNames();
  
  String[] getParameterTypes();
  
  String getReturnType();
  
  boolean isConstructor();
  
  void setBody(String paramString);
  
  void setConstructor(boolean paramBoolean);
  
  void setExceptions(String[] paramArrayOfString);
  
  void setTypeParameters(String[] paramArrayOfString);
  
  void setName(String paramString) throws IllegalArgumentException;
  
  void setParameters(String[] paramArrayOfString1, String[] paramArrayOfString2) throws IllegalArgumentException;
  
  void setReturnType(String paramString) throws IllegalArgumentException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\jdom\IDOMMethod.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */