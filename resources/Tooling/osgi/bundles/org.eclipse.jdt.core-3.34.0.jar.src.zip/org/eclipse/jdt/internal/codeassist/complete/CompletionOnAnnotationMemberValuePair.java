/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*    */ import org.eclipse.jdt.internal.compiler.ast.MemberValuePair;
/*    */ import org.eclipse.jdt.internal.compiler.ast.NormalAnnotation;
/*    */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnAnnotationMemberValuePair
/*    */   extends NormalAnnotation
/*    */ {
/*    */   public MemberValuePair completedMemberValuePair;
/*    */   
/*    */   public CompletionOnAnnotationMemberValuePair(TypeReference type, int sourceStart, MemberValuePair[] memberValuePairs, MemberValuePair completedMemberValuePair) {
/* 27 */     super(type, sourceStart);
/* 28 */     this.memberValuePairs = memberValuePairs;
/* 29 */     this.completedMemberValuePair = completedMemberValuePair;
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeBinding resolveType(BlockScope scope) {
/* 34 */     super.resolveType(scope);
/*    */     
/* 36 */     if (this.resolvedType == null || !this.resolvedType.isValidBinding()) {
/* 37 */       throw new CompletionNodeFound();
/*    */     }
/* 39 */     throw new CompletionNodeFound(this.completedMemberValuePair, scope);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 45 */     output.append('@');
/* 46 */     this.type.printExpression(0, output);
/* 47 */     output.append('(');
/* 48 */     if (this.memberValuePairs != null) {
/* 49 */       for (int i = 0, max = this.memberValuePairs.length; i < max; i++) {
/* 50 */         if (i > 0) {
/* 51 */           output.append(',');
/*    */         }
/* 53 */         this.memberValuePairs[i].print(indent, output);
/*    */       } 
/* 55 */       output.append(',');
/*    */     } 
/* 57 */     this.completedMemberValuePair.print(indent, output);
/* 58 */     output.append(')');
/*    */     
/* 60 */     return output;
/*    */   }
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, ClassScope scope) {
/* 65 */     super.traverse(visitor, scope);
/* 66 */     this.completedMemberValuePair.traverse(visitor, scope);
/*    */   }
/*    */ 
/*    */   
/*    */   public void traverse(ASTVisitor visitor, BlockScope scope) {
/* 71 */     super.traverse(visitor, scope);
/* 72 */     this.completedMemberValuePair.traverse(visitor, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnAnnotationMemberValuePair.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */