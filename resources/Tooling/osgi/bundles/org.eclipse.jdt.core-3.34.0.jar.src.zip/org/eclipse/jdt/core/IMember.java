package org.eclipse.jdt.core;

public interface IMember extends IJavaElement, ISourceReference, ISourceManipulation, IParent {
  String[] getCategories() throws JavaModelException;
  
  IClassFile getClassFile();
  
  ICompilationUnit getCompilationUnit();
  
  IType getDeclaringType();
  
  int getFlags() throws JavaModelException;
  
  ISourceRange getJavadocRange() throws JavaModelException;
  
  int getOccurrenceCount();
  
  ITypeRoot getTypeRoot();
  
  IType getType(String paramString, int paramInt);
  
  boolean isBinary();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IMember.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */