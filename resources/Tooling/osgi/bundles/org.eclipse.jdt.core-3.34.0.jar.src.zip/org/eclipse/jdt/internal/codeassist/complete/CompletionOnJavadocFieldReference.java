/*     */ package org.eclipse.jdt.internal.codeassist.complete;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.JavadocFieldReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.JavadocMessageSend;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompletionOnJavadocFieldReference
/*     */   extends JavadocFieldReference
/*     */   implements CompletionOnJavadoc
/*     */ {
/*  26 */   public int completionFlags = 1;
/*     */   public int separatorPosition;
/*     */   
/*     */   public CompletionOnJavadocFieldReference(Expression receiver, int tag, int position, int separatorPos, char[] name) {
/*  30 */     super(null, (position << 32L) + position - 1L);
/*  31 */     this.receiver = receiver;
/*  32 */     this.tagSourceStart = position;
/*  33 */     this.tagSourceEnd = position;
/*  34 */     this.tagValue = tag;
/*  35 */     this.separatorPosition = separatorPos;
/*     */   }
/*     */   
/*     */   public CompletionOnJavadocFieldReference(JavadocFieldReference fieldRef, int position, char[] name) {
/*  39 */     super(fieldRef.token, fieldRef.nameSourcePosition);
/*  40 */     this.receiver = fieldRef.receiver;
/*  41 */     this.separatorPosition = position;
/*  42 */     this.tagSourceStart = fieldRef.tagSourceStart;
/*  43 */     this.tagSourceEnd = fieldRef.tagSourceEnd;
/*  44 */     this.tagValue = fieldRef.tagValue;
/*     */   }
/*     */   
/*     */   public CompletionOnJavadocFieldReference(JavadocMessageSend msgSend, int position) {
/*  48 */     super(msgSend.selector, (msgSend.nameSourcePosition >> 32L << 32L) + msgSend.sourceEnd);
/*  49 */     this.receiver = msgSend.receiver;
/*  50 */     this.separatorPosition = position;
/*  51 */     this.tagSourceStart = msgSend.tagSourceStart;
/*  52 */     this.tagSourceEnd = msgSend.tagSourceEnd;
/*  53 */     this.tagValue = msgSend.tagValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addCompletionFlags(int flags) {
/*  58 */     this.completionFlags |= flags;
/*     */   }
/*     */   
/*     */   public boolean completeAnException() {
/*  62 */     return ((this.completionFlags & 0x2) != 0);
/*     */   }
/*     */   
/*     */   public boolean completeInText() {
/*  66 */     return ((this.completionFlags & 0x4) != 0);
/*     */   }
/*     */   
/*     */   public boolean completeBaseTypes() {
/*  70 */     return ((this.completionFlags & 0x8) != 0);
/*     */   }
/*     */   
/*     */   public boolean completeFormalReference() {
/*  74 */     return ((this.completionFlags & 0x40) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCompletionFlags() {
/*  79 */     return this.completionFlags;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeBinding internalResolveType(Scope scope) {
/*  85 */     if (this.token != null) {
/*  86 */       return super.internalResolveType(scope);
/*     */     }
/*     */ 
/*     */     
/*  90 */     if (this.receiver == null) {
/*  91 */       this.actualReceiverType = (TypeBinding)scope.enclosingSourceType();
/*  92 */     } else if (scope.kind == 3) {
/*  93 */       this.actualReceiverType = this.receiver.resolveType((ClassScope)scope);
/*     */     } else {
/*  95 */       this.actualReceiverType = this.receiver.resolveType((BlockScope)scope);
/*     */     } 
/*  97 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 102 */     output.append("<CompleteOnJavadocFieldReference:");
/* 103 */     super.printExpression(indent, output);
/* 104 */     indent++;
/* 105 */     if (this.completionFlags > 0) {
/* 106 */       output.append('\n');
/* 107 */       for (int j = 0; j < indent; ) { output.append('\t'); j++; }
/* 108 */        output.append("infos:");
/* 109 */       char separator = Character.MIN_VALUE;
/* 110 */       if (completeAnException()) {
/* 111 */         output.append("exception");
/* 112 */         separator = ',';
/*     */       } 
/* 114 */       if (completeInText()) {
/* 115 */         if (separator != '\000') output.append(separator); 
/* 116 */         output.append("text");
/* 117 */         separator = ',';
/*     */       } 
/* 119 */       if (completeBaseTypes()) {
/* 120 */         if (separator != '\000') output.append(separator); 
/* 121 */         output.append("base types");
/* 122 */         separator = ',';
/*     */       } 
/* 124 */       if (completeFormalReference()) {
/* 125 */         if (separator != '\000') output.append(separator); 
/* 126 */         output.append("formal reference");
/* 127 */         separator = ',';
/*     */       } 
/* 129 */       output.append('\n');
/*     */     } 
/* 131 */     indent--;
/* 132 */     for (int i = 0; i < indent; ) { output.append('\t'); i++; }
/* 133 */      return output.append('>');
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnJavadocFieldReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */