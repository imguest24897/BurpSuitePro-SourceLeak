package org.eclipse.jdt.core.dom;

import org.eclipse.jdt.core.IJavaElement;

public interface IBinding {
  public static final int PACKAGE = 1;
  
  public static final int TYPE = 2;
  
  public static final int VARIABLE = 3;
  
  public static final int METHOD = 4;
  
  public static final int ANNOTATION = 5;
  
  public static final int MEMBER_VALUE_PAIR = 6;
  
  public static final int MODULE = 7;
  
  IAnnotationBinding[] getAnnotations();
  
  int getKind();
  
  String getName();
  
  int getModifiers();
  
  boolean isDeprecated();
  
  boolean isRecovered();
  
  boolean isSynthetic();
  
  IJavaElement getJavaElement();
  
  String getKey();
  
  boolean equals(Object paramObject);
  
  boolean isEqualTo(IBinding paramIBinding);
  
  String toString();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\IBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */