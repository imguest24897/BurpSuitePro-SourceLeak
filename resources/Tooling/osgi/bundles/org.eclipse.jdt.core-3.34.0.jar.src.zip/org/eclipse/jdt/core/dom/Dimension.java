/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Dimension
/*     */   extends ASTNode
/*     */ {
/*  45 */   public static final ChildListPropertyDescriptor ANNOTATIONS_PROPERTY = new ChildListPropertyDescriptor(Dimension.class, "annotations", Annotation.class, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_8_0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  55 */     List propertyList = new ArrayList(2);
/*  56 */     createPropertyList(Dimension.class, propertyList);
/*  57 */     addProperty(ANNOTATIONS_PROPERTY, propertyList);
/*  58 */     PROPERTY_DESCRIPTORS_8_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  71 */     return PROPERTY_DESCRIPTORS_8_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private ASTNode.NodeList annotations = new ASTNode.NodeList(this, ANNOTATIONS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Dimension(AST ast) {
/*  91 */     super(ast);
/*  92 */     unsupportedIn2_3_4();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  97 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 102 */     if (property == ANNOTATIONS_PROPERTY) {
/* 103 */       return annotations();
/*     */     }
/*     */     
/* 106 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 111 */     return 85;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 116 */     Dimension result = new Dimension(target);
/* 117 */     result.annotations().addAll(
/* 118 */         ASTNode.copySubtrees(target, annotations()));
/* 119 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 125 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 130 */     boolean visitChildren = visitor.visit(this);
/* 131 */     if (visitChildren)
/*     */     {
/* 133 */       acceptChildren(visitor, this.annotations);
/*     */     }
/* 135 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List annotations() {
/* 144 */     return this.annotations;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 149 */     return 44;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 154 */     return 
/* 155 */       memSize() + 
/* 156 */       this.annotations.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\Dimension.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */