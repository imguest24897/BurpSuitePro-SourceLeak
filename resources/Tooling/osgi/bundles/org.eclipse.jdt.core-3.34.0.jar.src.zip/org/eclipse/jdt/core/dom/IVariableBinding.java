/*    */ package org.eclipse.jdt.core.dom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IVariableBinding
/*    */   extends IBinding
/*    */ {
/*    */   boolean isField();
/*    */   
/*    */   boolean isEnumConstant();
/*    */   
/*    */   boolean isParameter();
/*    */   
/*    */   default boolean isRecordComponent() {
/* 68 */     return false;
/*    */   }
/*    */   
/*    */   String getName();
/*    */   
/*    */   ITypeBinding getDeclaringClass();
/*    */   
/*    */   ITypeBinding getType();
/*    */   
/*    */   int getVariableId();
/*    */   
/*    */   Object getConstantValue();
/*    */   
/*    */   IMethodBinding getDeclaringMethod();
/*    */   
/*    */   IVariableBinding getVariableDeclaration();
/*    */   
/*    */   boolean isEffectivelyFinal();
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\IVariableBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */