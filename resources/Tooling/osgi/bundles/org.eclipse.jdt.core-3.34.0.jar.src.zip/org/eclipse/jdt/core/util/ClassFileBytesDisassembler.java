package org.eclipse.jdt.core.util;

public abstract class ClassFileBytesDisassembler {
  public static final int DETAILED = 1;
  
  public static final int DEFAULT = 2;
  
  public static final int SYSTEM = 4;
  
  public static final int COMPACT = 8;
  
  public static final int WORKING_COPY = 16;
  
  public abstract String disassemble(byte[] paramArrayOfbyte, String paramString) throws ClassFormatException;
  
  public abstract String disassemble(byte[] paramArrayOfbyte, String paramString, int paramInt) throws ClassFormatException;
  
  public abstract String getDescription();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\cor\\util\ClassFileBytesDisassembler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */