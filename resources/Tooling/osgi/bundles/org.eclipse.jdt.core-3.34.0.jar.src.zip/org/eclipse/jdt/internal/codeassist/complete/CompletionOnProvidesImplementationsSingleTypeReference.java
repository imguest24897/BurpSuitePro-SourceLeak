/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnProvidesImplementationsSingleTypeReference
/*    */   extends CompletionOnSingleTypeReference
/*    */ {
/*    */   public CompletionOnProvidesImplementationsSingleTypeReference(char[] source, long pos) {
/* 19 */     super(source, pos);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnProvidesImplementationsSingleTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */