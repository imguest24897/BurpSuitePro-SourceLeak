/*    */ package org.eclipse.jdt.core.dom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Pattern
/*    */   extends Expression
/*    */ {
/*    */   Pattern(AST ast) {
/* 41 */     super(ast);
/* 42 */     supportedOnlyIn20();
/* 43 */     unsupportedWithoutPreviewError();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static final ChildPropertyDescriptor internalPatternPropertyFactory(Class nodeClass) {
/* 55 */     return new ChildPropertyDescriptor(nodeClass, "pattern", Javadoc.class, true, false);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\Pattern.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */