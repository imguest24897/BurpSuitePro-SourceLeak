/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.dom.rewrite.TargetSourceRangeComputer;
/*     */ import org.eclipse.jdt.internal.compiler.parser.RecoveryScannerData;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.ASTRewriteAnalyzer;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.LineInformation;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.ListRewriteEvent;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.NodeInfoStore;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.NodeRewriteEvent;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.RewriteEventStore;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.TextUtilities;
/*     */ import org.eclipse.text.edits.MultiTextEdit;
/*     */ import org.eclipse.text.edits.TextEdit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class InternalASTRewrite
/*     */   extends NodeEventHandler
/*     */ {
/*     */   private CompilationUnit root;
/*     */   protected final RewriteEventStore eventStore;
/*     */   protected final NodeInfoStore nodeStore;
/*     */   protected final Hashtable clonedNodes;
/*  52 */   int cloneDepth = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InternalASTRewrite(CompilationUnit root) {
/*  59 */     this.root = root;
/*  60 */     this.eventStore = new RewriteEventStore();
/*  61 */     this.nodeStore = new NodeInfoStore(root.getAST());
/*  62 */     this.clonedNodes = new Hashtable<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextEdit rewriteAST(IDocument document, Map options) {
/*  77 */     MultiTextEdit multiTextEdit = new MultiTextEdit();
/*     */     
/*  79 */     final CompilationUnit rootNode = getRootNode();
/*  80 */     if (rootNode != null) {
/*  81 */       TargetSourceRangeComputer xsrComputer = new TargetSourceRangeComputer()
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public TargetSourceRangeComputer.SourceRange computeSourceRange(ASTNode node)
/*     */           {
/*  91 */             int extendedStartPosition = rootNode.getExtendedStartPosition(node);
/*  92 */             int extendedLength = rootNode.getExtendedLength(node);
/*  93 */             return new TargetSourceRangeComputer.SourceRange(extendedStartPosition, extendedLength);
/*     */           }
/*     */         };
/*  96 */       char[] content = document.get().toCharArray();
/*  97 */       LineInformation lineInfo = LineInformation.create(document);
/*  98 */       String lineDelim = TextUtilities.getDefaultLineDelimiter(document);
/*  99 */       List comments = rootNode.getCommentList();
/*     */       
/* 101 */       Map currentOptions = (options == null) ? JavaCore.getOptions() : options;
/* 102 */       ASTRewriteAnalyzer visitor = new ASTRewriteAnalyzer(content, lineInfo, lineDelim, (TextEdit)multiTextEdit, this.eventStore, this.nodeStore, comments, currentOptions, xsrComputer, (RecoveryScannerData)rootNode.getStatementsRecoveryData());
/* 103 */       rootNode.accept((ASTVisitor)visitor);
/*     */     } 
/* 105 */     return (TextEdit)multiTextEdit;
/*     */   }
/*     */   
/*     */   private void markAsMoveOrCopyTarget(ASTNode node, ASTNode newChild) {
/* 109 */     if (this.cloneDepth == 0) {
/* 110 */       while (node != null && this.clonedNodes.containsKey(node)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 118 */         ASTNode orig = (ASTNode)this.clonedNodes.remove(node);
/* 119 */         if (orig != null) {
/* 120 */           List<StructuralPropertyDescriptor> properties = node.structuralPropertiesForType();
/* 121 */           for (int i = 0; i < properties.size(); i++) {
/* 122 */             StructuralPropertyDescriptor property = properties.get(i);
/* 123 */             Object child = node.getStructuralProperty(property);
/* 124 */             if (child instanceof ASTNode) {
/* 125 */               markAsMoveOrCopyTarget(node, (ASTNode)child);
/* 126 */             } else if (child instanceof List) {
/* 127 */               List<ASTNode> children = (List)child;
/* 128 */               for (int j = 0; j < children.size(); j++) {
/* 129 */                 ASTNode clonedChild = children.get(j);
/* 130 */                 markAsMoveOrCopyTarget(node, clonedChild);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 136 */         node = node.getParent();
/*     */       } 
/*     */     }
/*     */     
/* 140 */     ASTNode source = (ASTNode)this.clonedNodes.get(newChild);
/* 141 */     if (source != null) {
/* 142 */       if (this.cloneDepth == 0) {
/* 143 */         RewriteEventStore.PropertyLocation propertyLocation = this.eventStore.getPropertyLocation(source, 2);
/* 144 */         RewriteEventStore.CopySourceInfo sourceInfo = 
/* 145 */           this.eventStore.markAsCopySource(
/* 146 */             propertyLocation.getParent(), 
/* 147 */             propertyLocation.getProperty(), 
/* 148 */             source, 
/* 149 */             false);
/* 150 */         this.nodeStore.markAsCopyTarget(newChild, sourceInfo);
/*     */       } 
/* 152 */     } else if ((newChild.getFlags() & 0x2) != 0) {
/* 153 */       RewriteEventStore.PropertyLocation propertyLocation = this.eventStore.getPropertyLocation(newChild, 2);
/* 154 */       RewriteEventStore.CopySourceInfo sourceInfo = 
/* 155 */         this.eventStore.markAsCopySource(
/* 156 */           propertyLocation.getParent(), 
/* 157 */           propertyLocation.getProperty(), 
/* 158 */           newChild, 
/* 159 */           true);
/* 160 */       this.nodeStore.markAsCopyTarget(newChild, sourceInfo);
/*     */     } 
/*     */   }
/*     */   
/*     */   private CompilationUnit getRootNode() {
/* 165 */     return this.root;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 170 */     StringBuilder buf = new StringBuilder();
/* 171 */     buf.append("Events:\n");
/* 172 */     buf.append(this.eventStore.toString());
/* 173 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void preValueChangeEvent(ASTNode node, SimplePropertyDescriptor property) {
/* 179 */     getNodeEvent(node, property);
/*     */   }
/*     */ 
/*     */   
/*     */   void postValueChangeEvent(ASTNode node, SimplePropertyDescriptor property) {
/* 184 */     NodeRewriteEvent event = getNodeEvent(node, property);
/* 185 */     event.setNewValue(node.getStructuralProperty(property));
/*     */   }
/*     */ 
/*     */   
/*     */   void preAddChildEvent(ASTNode node, ASTNode child, StructuralPropertyDescriptor property) {
/* 190 */     if (property.isChildProperty()) {
/* 191 */       NodeRewriteEvent event = getNodeEvent(node, property);
/* 192 */       event.setNewValue(child);
/* 193 */       if (child != null) {
/* 194 */         markAsMoveOrCopyTarget(node, child);
/*     */       }
/* 196 */     } else if (property.isChildListProperty()) {
/*     */       
/* 198 */       getListEvent(node, property);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void postAddChildEvent(ASTNode node, ASTNode child, StructuralPropertyDescriptor property) {
/* 204 */     if (property.isChildListProperty()) {
/*     */       int index;
/* 206 */       ListRewriteEvent event = getListEvent(node, property);
/* 207 */       List<ASTNode> list = (List)node.getStructuralProperty(property);
/* 208 */       int i = list.indexOf(child);
/* 209 */       int s = list.size();
/*     */       
/* 211 */       if (i + 1 < s) {
/* 212 */         ASTNode nextNode = list.get(i + 1);
/* 213 */         index = event.getIndex(nextNode, 1);
/*     */       } else {
/* 215 */         index = -1;
/*     */       } 
/* 217 */       event.insert(child, index);
/* 218 */       if (child != null) {
/* 219 */         markAsMoveOrCopyTarget(node, child);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void preRemoveChildEvent(ASTNode node, ASTNode child, StructuralPropertyDescriptor property) {
/* 226 */     if (property.isChildProperty()) {
/* 227 */       NodeRewriteEvent event = getNodeEvent(node, property);
/* 228 */       event.setNewValue(null);
/* 229 */     } else if (property.isChildListProperty()) {
/* 230 */       ListRewriteEvent event = getListEvent(node, property);
/* 231 */       int i = event.getIndex(child, 1);
/* 232 */       NodeRewriteEvent nodeEvent = (NodeRewriteEvent)event.getChildren()[i];
/* 233 */       if (nodeEvent.getOriginalValue() == null) {
/* 234 */         event.revertChange(nodeEvent);
/*     */       } else {
/* 236 */         nodeEvent.setNewValue(null);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void preReplaceChildEvent(ASTNode node, ASTNode child, ASTNode newChild, StructuralPropertyDescriptor property) {
/* 243 */     if (property.isChildProperty()) {
/* 244 */       NodeRewriteEvent event = getNodeEvent(node, property);
/* 245 */       event.setNewValue(newChild);
/* 246 */       if (newChild != null) {
/* 247 */         markAsMoveOrCopyTarget(node, newChild);
/*     */       }
/* 249 */     } else if (property.isChildListProperty()) {
/* 250 */       ListRewriteEvent event = getListEvent(node, property);
/* 251 */       int i = event.getIndex(child, 1);
/* 252 */       NodeRewriteEvent nodeEvent = (NodeRewriteEvent)event.getChildren()[i];
/* 253 */       nodeEvent.setNewValue(newChild);
/* 254 */       if (newChild != null) {
/* 255 */         markAsMoveOrCopyTarget(node, newChild);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void preCloneNodeEvent(ASTNode node) {
/* 263 */     this.cloneDepth++;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void postCloneNodeEvent(ASTNode node, ASTNode clone) {
/* 269 */     if (node.ast == this.root.ast && clone.ast == this.root.ast) {
/* 270 */       if ((node.getFlags() & 0x2) != 0) {
/* 271 */         this.clonedNodes.put(clone, node);
/*     */       } else {
/*     */         
/* 274 */         Object original = this.clonedNodes.get(node);
/* 275 */         if (original != null) {
/* 276 */           this.clonedNodes.put(clone, original);
/*     */         }
/*     */       } 
/*     */     }
/* 280 */     this.cloneDepth--;
/*     */   }
/*     */   
/*     */   private NodeRewriteEvent getNodeEvent(ASTNode node, StructuralPropertyDescriptor property) {
/* 284 */     return this.eventStore.getNodeEvent(node, property, true);
/*     */   }
/*     */   
/*     */   private ListRewriteEvent getListEvent(ASTNode node, StructuralPropertyDescriptor property) {
/* 288 */     return this.eventStore.getListEvent(node, property, true);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\InternalASTRewrite.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */