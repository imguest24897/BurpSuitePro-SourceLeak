package org.eclipse.jdt.core.dom;

interface IGetJavaDoc {
  Javadoc getJavaDoc();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ASTConverter$IGetJavaDoc.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */