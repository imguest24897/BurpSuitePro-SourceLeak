/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProvidesDirective
/*     */   extends ModuleDirective
/*     */ {
/*  37 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(ProvidesDirective.class, "name", Name.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   public static final ChildListPropertyDescriptor IMPLEMENTATIONS_PROPERTY = new ChildListPropertyDescriptor(ProvidesDirective.class, "implementations", Name.class, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_9_0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  53 */     List properyList = new ArrayList(3);
/*  54 */     createPropertyList(ProvidesDirective.class, properyList);
/*  55 */     addProperty(NAME_PROPERTY, properyList);
/*  56 */     addProperty(IMPLEMENTATIONS_PROPERTY, properyList);
/*  57 */     PROPERTY_DESCRIPTORS_9_0 = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  71 */     return PROPERTY_DESCRIPTORS_9_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private Name name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   private ASTNode.NodeList implementations = new ASTNode.NodeList(this, IMPLEMENTATIONS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ProvidesDirective(AST ast) {
/* 101 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 106 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 111 */     if (property == NAME_PROPERTY) {
/* 112 */       if (get) {
/* 113 */         return getName();
/*     */       }
/* 115 */       setName((Name)child);
/* 116 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 121 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 126 */     if (property == IMPLEMENTATIONS_PROPERTY) {
/* 127 */       return implementations();
/*     */     }
/*     */     
/* 130 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 135 */     return 98;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 140 */     ProvidesDirective result = new ProvidesDirective(target);
/* 141 */     result.setSourceRange(getStartPosition(), getLength());
/* 142 */     result.setName((Name)getName().clone(target));
/* 143 */     result.implementations().addAll(ASTNode.copySubtrees(target, implementations()));
/* 144 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 150 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 155 */     boolean visitChildren = visitor.visit(this);
/* 156 */     if (visitChildren) {
/* 157 */       acceptChild(visitor, getName());
/* 158 */       acceptChildren(visitor, this.implementations);
/*     */     } 
/* 160 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getName() {
/* 170 */     if (this.name == null)
/*     */     {
/* 172 */       synchronized (this) {
/* 173 */         if (this.name == null) {
/* 174 */           preLazyInit();
/* 175 */           this.name = this.ast.newQualifiedName(
/* 176 */               new SimpleName(this.ast), new SimpleName(this.ast));
/* 177 */           postLazyInit(this.name, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 181 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(Name name) {
/* 195 */     if (name == null) {
/* 196 */       throw new IllegalArgumentException();
/*     */     }
/* 198 */     ASTNode oldChild = this.name;
/* 199 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 200 */     this.name = name;
/* 201 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List implementations() {
/* 211 */     return this.implementations;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 216 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 221 */     return 
/* 222 */       memSize() + (
/* 223 */       (this.name == null) ? 0 : getName().treeSize()) + 
/* 224 */       this.implementations.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ProvidesDirective.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */