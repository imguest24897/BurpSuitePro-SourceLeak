/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.core.dom.util.DOMASTUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TagProperty
/*     */   extends ASTNode
/*     */   implements IDocElement
/*     */ {
/*     */   TagProperty(AST ast) {
/*  38 */     super(ast);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     this.name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     this.string_value = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     this.node_value = null;
/*     */     unsupportedBelow18();
/*     */   }
/*     */   public static final SimplePropertyDescriptor NAME_PROPERTY = new SimplePropertyDescriptor(TagProperty.class, "name", String.class, true); public static final SimplePropertyDescriptor STRING_VALUE_PROPERTY = new SimplePropertyDescriptor(TagProperty.class, "string_value", String.class, true); public static final ChildPropertyDescriptor NODE_VALUE_PROPERTY = new ChildPropertyDescriptor(TagProperty.class, "node_value", ASTNode.class, true, true); public static final String TAG_PROPERTY_SNIPPET_IS_VALID = "IsSnippetValid";
/*     */   public static final String TAG_PROPERTY_SNIPPET_ERROR = "SnippetError";
/*     */   public static final String TAG_PROPERTY_SNIPPET_ID = "SnippetID";
/*     */   
/* 116 */   List internalStructuralPropertiesForType(int apiLevel) { return propertyDescriptors(apiLevel); }
/*     */ 
/*     */   
/*     */   public static final String TAG_PROPERTY_SNIPPET_INLINE_TAG_COUNT = "SnippetInlineTagCount"; public static final String TAG_PROPERTY_SNIPPET_REGION_TEXT = "SnippetRegionTextElement";
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */   
/* 122 */   final Object internalGetSetObjectProperty(SimplePropertyDescriptor property, boolean get, Object newValue) { if (property == NAME_PROPERTY) {
/* 123 */       if (get) {
/* 124 */         return getName();
/*     */       }
/* 126 */       setName((String)newValue);
/* 127 */       return null;
/*     */     } 
/* 129 */     if (property == STRING_VALUE_PROPERTY) {
/* 130 */       if (get) {
/* 131 */         return getStringValue();
/*     */       }
/* 133 */       setStringValue((String)newValue);
/* 134 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 138 */     return super.internalGetSetObjectProperty(property, get, newValue); }
/*     */   private String name; private String string_value; private ASTNode node_value; static { List propertyList = new ArrayList(4); createPropertyList(TagProperty.class, propertyList);
/*     */     addProperty(NAME_PROPERTY, propertyList);
/*     */     addProperty(STRING_VALUE_PROPERTY, propertyList);
/*     */     addProperty(NODE_VALUE_PROPERTY, propertyList);
/* 143 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList); } final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) { if (property == NODE_VALUE_PROPERTY) {
/* 144 */       if (get) {
/* 145 */         return getNodeValue();
/*     */       }
/* 147 */       setNodeValue(child);
/* 148 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 152 */     return super.internalGetSetChildProperty(property, get, child); }
/*     */ 
/*     */ 
/*     */   
/*     */   int getNodeType0() {
/* 157 */     return 110;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 162 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 167 */     TagProperty result = new TagProperty(target);
/* 168 */     result.setSourceRange(getStartPosition(), getLength());
/* 169 */     result.setName(getName());
/* 170 */     result.setStringValue(getStringValue());
/* 171 */     result.setNodeValue(ASTNode.copySubtree(target, getNodeValue()));
/* 172 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 177 */     visitor.visit(this);
/* 178 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 184 */     return 44 + stringSize(this.name) + stringSize(this.string_value);
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 189 */     return memSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 204 */     if (DOMASTUtil.isJavaDocCodeSnippetSupported(apiLevel)) {
/* 205 */       return PROPERTY_DESCRIPTORS;
/*     */     }
/* 207 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 216 */     unsupportedBelow18();
/* 217 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringValue() {
/* 226 */     unsupportedBelow18();
/* 227 */     return this.string_value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ASTNode getNodeValue() {
/* 236 */     unsupportedBelow18();
/* 237 */     return this.node_value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 247 */     unsupportedBelow18();
/* 248 */     preValueChange(NAME_PROPERTY);
/* 249 */     this.name = name;
/* 250 */     postValueChange(NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStringValue(String value) {
/* 259 */     unsupportedBelow18();
/* 260 */     preValueChange(STRING_VALUE_PROPERTY);
/* 261 */     this.string_value = value;
/* 262 */     postValueChange(STRING_VALUE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNodeValue(ASTNode value) {
/* 271 */     unsupportedBelow18();
/* 272 */     ASTNode oldChild = this.node_value;
/* 273 */     preReplaceChild(oldChild, value, NODE_VALUE_PROPERTY);
/* 274 */     this.node_value = value;
/* 275 */     postReplaceChild(oldChild, value, NODE_VALUE_PROPERTY);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\TagProperty.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */