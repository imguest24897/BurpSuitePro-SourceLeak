/*     */ package org.eclipse.jdt.internal.codeassist.complete;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ast.Annotation;
/*     */ import org.eclipse.jdt.internal.compiler.ast.SingleTypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompletionOnSingleTypeReference
/*     */   extends SingleTypeReference
/*     */ {
/*     */   public static final int K_TYPE = 0;
/*     */   public static final int K_CLASS = 1;
/*     */   public static final int K_INTERFACE = 2;
/*     */   public static final int K_EXCEPTION = 3;
/*  39 */   private int kind = 0;
/*     */   public boolean isCompletionNode;
/*     */   public boolean isConstructorType;
/*     */   public CompletionOnFieldType fieldTypeCompletionNode;
/*     */   public char[][] possibleKeywords;
/*     */   public boolean canBeExplicitConstructor;
/*     */   
/*     */   public CompletionOnSingleTypeReference(char[] source, long pos) {
/*  47 */     this(source, pos, 0);
/*     */   }
/*     */   public CompletionOnSingleTypeReference(char[] source, long pos, int kind) {
/*  50 */     super(source, pos);
/*  51 */     this.isCompletionNode = true;
/*  52 */     this.kind = kind;
/*     */   }
/*     */   public CompletionOnSingleTypeReference(char[] assistName, long position, char[][] keywords, boolean canBeSuperCall) {
/*  55 */     this(assistName, position);
/*  56 */     this.possibleKeywords = keywords;
/*  57 */     this.canBeExplicitConstructor = canBeSuperCall;
/*     */   }
/*     */   
/*     */   public void aboutToResolve(Scope scope) {
/*  61 */     getTypeBinding(scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeReference augmentTypeWithAdditionalDimensions(int additionalDimensions, Annotation[][] additionalAnnotations, boolean isVarargs) {
/*  68 */     return (TypeReference)this;
/*     */   }
/*     */   
/*     */   protected TypeBinding getTypeBinding(Scope scope) {
/*  72 */     if (this.fieldTypeCompletionNode != null) {
/*  73 */       throw new CompletionNodeFound(this.fieldTypeCompletionNode, scope);
/*     */     }
/*  75 */     if (this.isCompletionNode) {
/*  76 */       throw new CompletionNodeFound(this, scope);
/*     */     }
/*  78 */     return super.getTypeBinding(scope);
/*     */   }
/*     */   
/*     */   public boolean isClass() {
/*  82 */     return (this.kind == 1);
/*     */   }
/*     */   public boolean isInterface() {
/*  85 */     return (this.kind == 2);
/*     */   }
/*     */   public boolean isException() {
/*  88 */     return (this.kind == 3);
/*     */   }
/*     */   public boolean isSuperType() {
/*  91 */     return !(this.kind != 1 && this.kind != 2);
/*     */   }
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/*  95 */     switch (this.kind)
/*     */     { case 1:
/*  97 */         output.append("<CompleteOnClass:");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 109 */         return output.append(this.token).append('>');case 2: output.append("<CompleteOnInterface:"); return output.append(this.token).append('>');case 3: output.append("<CompleteOnException:"); return output.append(this.token).append('>'); }  output.append("<CompleteOnType:"); return output.append(this.token).append('>');
/*     */   }
/*     */   
/*     */   public TypeBinding resolveTypeEnclosing(BlockScope scope, ReferenceBinding enclosingType) {
/* 113 */     if (this.fieldTypeCompletionNode != null) {
/* 114 */       throw new CompletionNodeFound(this.fieldTypeCompletionNode, scope);
/*     */     }
/* 116 */     if (this.isCompletionNode) {
/* 117 */       throw new CompletionNodeFound(this, enclosingType, scope);
/*     */     }
/* 119 */     return super.resolveTypeEnclosing(scope, enclosingType);
/*     */   }
/*     */   
/*     */   public void setKind(int kind) {
/* 123 */     this.kind = kind;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnSingleTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */