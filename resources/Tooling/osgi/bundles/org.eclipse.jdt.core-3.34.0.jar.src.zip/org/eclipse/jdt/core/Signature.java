/*      */ package org.eclipse.jdt.core;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.parser.ScannerHelper;
/*      */ import org.eclipse.jdt.internal.compiler.util.Util;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Signature
/*      */ {
/*      */   public static final int ARRAY_TYPE_SIGNATURE = 4;
/*      */   public static final int BASE_TYPE_SIGNATURE = 2;
/*  168 */   private static final char[] BOOLEAN = "boolean".toCharArray();
/*      */   
/*  170 */   private static final char[] BYTE = "byte".toCharArray();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_ARRAY = '[';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_BOOLEAN = 'Z';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_BYTE = 'B';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_CAPTURE = '!';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_CHAR = 'C';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_COLON = ':';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_DOLLAR = '$';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_DOT = '.';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_DOUBLE = 'D';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_EXCEPTION_START = '^';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_EXTENDS = '+';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_FLOAT = 'F';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_GENERIC_END = '>';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_GENERIC_START = '<';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_INT = 'I';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_INTERSECTION = '|';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_UNION = '&';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_LONG = 'J';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_NAME_END = ';';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_PARAM_END = ')';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_PARAM_START = '(';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_RESOLVED = 'L';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_SEMICOLON = ';';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_SHORT = 'S';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_STAR = '*';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_SUPER = '-';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_TYPE_VARIABLE = 'T';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_UNRESOLVED = 'Q';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char C_VOID = 'V';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  361 */   private static final char[] CAPTURE = "capture-of".toCharArray();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int CAPTURE_TYPE_SIGNATURE = 6;
/*      */ 
/*      */ 
/*      */   
/*  370 */   private static final char[] CHAR = "char".toCharArray();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int CLASS_TYPE_SIGNATURE = 1;
/*      */ 
/*      */ 
/*      */   
/*  379 */   private static final char[] DOUBLE = "double".toCharArray();
/*      */ 
/*      */   
/*  382 */   private static final char[] EXTENDS = "extends".toCharArray();
/*      */   
/*  384 */   private static final char[] FLOAT = "float".toCharArray();
/*      */   
/*  386 */   private static final char[] INT = "int".toCharArray();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int INTERSECTION_TYPE_SIGNATURE = 7;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int UNION_TYPE_SIGNATURE = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  401 */   private static final char[] LONG = "long".toCharArray();
/*      */   
/*  403 */   private static final char[] SHORT = "short".toCharArray();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String SIG_BOOLEAN = "Z";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String SIG_BYTE = "B";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String SIG_CHAR = "C";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String SIG_DOUBLE = "D";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String SIG_FLOAT = "F";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String SIG_INT = "I";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String SIG_LONG = "J";
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String SIG_SHORT = "S";
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String SIG_VOID = "V";
/*      */ 
/*      */ 
/*      */   
/*  450 */   private static final char[] SUPER = "super".toCharArray();
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TYPE_VARIABLE_SIGNATURE = 3;
/*      */ 
/*      */   
/*  457 */   private static final char[] VOID = "void".toCharArray();
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int WILDCARD_TYPE_SIGNATURE = 5;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void appendArgumentSimpleNames(char[] name, int start, int end, StringBuffer buffer) {
/*  467 */     buffer.append('<');
/*  468 */     int depth = 0;
/*  469 */     int argumentStart = -1;
/*  470 */     int argumentCount = 0;
/*  471 */     for (int i = start; i <= end; i++) {
/*  472 */       switch (name[i]) {
/*      */         case '<':
/*  474 */           depth++;
/*  475 */           if (depth == 1) {
/*  476 */             argumentStart = i + 1;
/*      */           }
/*      */           break;
/*      */         case '>':
/*  480 */           if (depth == 1) {
/*  481 */             if (argumentCount > 0) buffer.append(','); 
/*  482 */             appendSimpleName(name, argumentStart, i - 1, buffer);
/*  483 */             argumentCount++;
/*      */           } 
/*  485 */           depth--;
/*      */           break;
/*      */         case ',':
/*  488 */           if (depth == 1) {
/*  489 */             if (argumentCount > 0) buffer.append(','); 
/*  490 */             appendSimpleName(name, argumentStart, i - 1, buffer);
/*  491 */             argumentCount++;
/*  492 */             argumentStart = i + 1;
/*      */           } 
/*      */           break;
/*      */       } 
/*      */     } 
/*  497 */     buffer.append('>');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int appendArrayTypeSignature(char[] string, int start, boolean fullyQualifyTypeNames, StringBuffer buffer) {
/*  514 */     return appendArrayTypeSignature(string, start, fullyQualifyTypeNames, buffer, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int appendArrayTypeSignature(char[] string, int start, boolean fullyQualifyTypeNames, StringBuffer buffer, boolean isVarArgs) {
/*  533 */     int length = string.length;
/*      */     
/*  535 */     if (start >= length - 1) {
/*  536 */       throw newIllegalArgumentException(string, start);
/*      */     }
/*  538 */     char c = string[start];
/*  539 */     if (c != '[') {
/*  540 */       throw newIllegalArgumentException(string, start);
/*      */     }
/*      */     
/*  543 */     int index = start;
/*  544 */     c = string[++index];
/*  545 */     while (c == '[') {
/*      */       
/*  547 */       if (index >= length - 1) {
/*  548 */         throw newIllegalArgumentException(string, start);
/*      */       }
/*  550 */       c = string[++index];
/*      */     } 
/*      */     
/*  553 */     int e = appendTypeSignature(string, index, fullyQualifyTypeNames, buffer);
/*      */     
/*  555 */     for (int i = 1, dims = index - start; i < dims; i++) {
/*  556 */       buffer.append('[').append(']');
/*      */     }
/*      */     
/*  559 */     if (isVarArgs) {
/*  560 */       buffer.append('.').append('.').append('.');
/*      */     } else {
/*  562 */       buffer.append('[').append(']');
/*      */     } 
/*  564 */     return e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int appendCaptureTypeSignature(char[] string, int start, boolean fullyQualifyTypeNames, StringBuffer buffer) {
/*  581 */     if (start >= string.length - 1) {
/*  582 */       throw newIllegalArgumentException(string, start);
/*      */     }
/*  584 */     char c = string[start];
/*  585 */     if (c != '!') {
/*  586 */       throw newIllegalArgumentException(string, start);
/*      */     }
/*  588 */     buffer.append(CAPTURE).append(' ');
/*  589 */     return appendTypeArgumentSignature(string, start + 1, fullyQualifyTypeNames, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int appendClassTypeSignature(char[] string, int start, boolean fullyQualifyTypeNames, StringBuffer buffer) {
/*  607 */     if (start >= string.length - 2) {
/*  608 */       throw newIllegalArgumentException(string, start);
/*      */     }
/*      */     
/*  611 */     char c = string[start];
/*  612 */     if (c != 'L' && c != 'Q') {
/*  613 */       throw newIllegalArgumentException(string, start);
/*      */     }
/*  615 */     boolean resolved = (c == 'L');
/*  616 */     boolean removePackageQualifiers = !fullyQualifyTypeNames;
/*  617 */     if (!resolved)
/*      */     {
/*  619 */       removePackageQualifiers = false;
/*      */     }
/*  621 */     int p = start + 1;
/*  622 */     int checkpoint = buffer.length();
/*  623 */     int innerTypeStart = -1;
/*  624 */     boolean inAnonymousType = false; while (true) {
/*      */       int e;
/*  626 */       if (p >= string.length) {
/*  627 */         throw newIllegalArgumentException(string, start);
/*      */       }
/*  629 */       c = string[p];
/*  630 */       switch (c) {
/*      */         
/*      */         case ';':
/*  633 */           return p;
/*      */         case '<':
/*  635 */           e = appendTypeArgumentSignatures(string, p, fullyQualifyTypeNames, buffer);
/*      */           
/*  637 */           removePackageQualifiers = false;
/*  638 */           p = e;
/*      */           break;
/*      */         case '.':
/*  641 */           if (removePackageQualifiers) {
/*      */             
/*  643 */             buffer.setLength(checkpoint); break;
/*      */           } 
/*  645 */           buffer.append('.');
/*      */           break;
/*      */         
/*      */         case '/':
/*  649 */           if (removePackageQualifiers) {
/*      */             
/*  651 */             buffer.setLength(checkpoint); break;
/*      */           } 
/*  653 */           buffer.append('/');
/*      */           break;
/*      */         
/*      */         case '$':
/*  657 */           innerTypeStart = buffer.length();
/*  658 */           inAnonymousType = false;
/*  659 */           if (resolved) {
/*      */             
/*  661 */             removePackageQualifiers = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  668 */             buffer.append('.');
/*      */           } 
/*      */           break;
/*      */         default:
/*  672 */           if (innerTypeStart != -1 && !inAnonymousType && Character.isDigit(c)) {
/*  673 */             inAnonymousType = true;
/*  674 */             buffer.setLength(innerTypeStart);
/*  675 */             buffer.insert(checkpoint, "new ");
/*  676 */             buffer.append("(){}");
/*      */           } 
/*  678 */           if (!inAnonymousType)
/*  679 */             buffer.append(c); 
/*  680 */           innerTypeStart = -1; break;
/*      */       } 
/*  682 */       p++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int appendIntersectionTypeSignature(char[] string, int start, boolean fullyQualifyTypeNames, StringBuffer buffer) {
/*  700 */     if (start >= string.length - 1) {
/*  701 */       throw newIllegalArgumentException(string, start);
/*      */     }
/*  703 */     char c = string[start];
/*  704 */     if (c != '|') {
/*  705 */       throw newIllegalArgumentException(string, start);
/*      */     }
/*  707 */     start = appendClassTypeSignature(string, start + 1, fullyQualifyTypeNames, buffer);
/*  708 */     if (start < string.length - 1) {
/*  709 */       start++;
/*  710 */       if (string[start] != ':') {
/*  711 */         throw new IllegalArgumentException("should be a colon at this location");
/*      */       }
/*  713 */       while (string[start] == ':') {
/*  714 */         buffer.append(" | ");
/*  715 */         start = appendClassTypeSignature(string, start + 1, fullyQualifyTypeNames, buffer);
/*  716 */         if (start == string.length - 1)
/*  717 */           return start; 
/*  718 */         if (start > string.length - 1) {
/*  719 */           throw new IllegalArgumentException("Should be at the end");
/*      */         }
/*  721 */         start++;
/*      */       } 
/*      */     } 
/*  724 */     return start;
/*      */   }
/*      */   private static void appendSimpleName(char[] name, int start, int end, StringBuffer buffer) {
/*  727 */     int lastDot = -1, lastGenericStart = -1, lastGenericEnd = -1;
/*  728 */     int depth = 0;
/*  729 */     if (name[start] == '?') {
/*  730 */       int checkPos; buffer.append("?");
/*  731 */       int index = consumeWhitespace(name, start + 1, end + 1);
/*  732 */       switch (name[index]) {
/*      */         case 'e':
/*  734 */           checkPos = checkName(EXTENDS, name, index, end);
/*  735 */           if (checkPos > 0) {
/*  736 */             buffer.append(' ').append(EXTENDS).append(' ');
/*  737 */             index = consumeWhitespace(name, checkPos, end + 1);
/*      */           } 
/*      */           break;
/*      */         case 's':
/*  741 */           checkPos = checkName(SUPER, name, index, end + 1);
/*  742 */           if (checkPos > 0) {
/*  743 */             buffer.append(' ').append(SUPER).append(' ');
/*  744 */             index = consumeWhitespace(name, checkPos, end + 1);
/*      */           } 
/*      */           break;
/*      */       } 
/*  748 */       start = index;
/*      */     } 
/*  750 */     for (int i = end; i >= start; i--) {
/*  751 */       switch (name[i]) {
/*      */         case '.':
/*  753 */           if (depth == 0) {
/*  754 */             lastDot = i;
/*  755 */             char c = name[start];
/*  756 */             if (c == '+' || c == '-') {
/*  757 */               buffer.append(c);
/*      */             }
/*      */             break;
/*      */           } 
/*      */           break;
/*      */         case '<':
/*  763 */           depth--;
/*  764 */           if (depth == 0) lastGenericStart = i; 
/*      */           break;
/*      */         case '>':
/*  767 */           if (depth == 0) lastGenericEnd = i; 
/*  768 */           depth++;
/*      */           break;
/*      */       } 
/*      */     } 
/*  772 */     int nameStart = (lastDot < 0) ? start : (lastDot + 1);
/*  773 */     int nameEnd = (lastGenericStart < 0) ? (end + 1) : lastGenericStart;
/*  774 */     buffer.append(name, nameStart, nameEnd - nameStart);
/*  775 */     if (lastGenericStart >= 0) {
/*  776 */       appendArgumentSimpleNames(name, lastGenericStart, lastGenericEnd, buffer);
/*  777 */       buffer.append(name, lastGenericEnd + 1, end - lastGenericEnd);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int appendTypeArgumentSignature(char[] string, int start, boolean fullyQualifyTypeNames, StringBuffer buffer) {
/*  797 */     if (start >= string.length) {
/*  798 */       throw newIllegalArgumentException(string, start);
/*      */     }
/*  800 */     char c = string[start];
/*  801 */     switch (c) {
/*      */       case '*':
/*  803 */         buffer.append('?');
/*  804 */         return start;
/*      */       case '+':
/*  806 */         buffer.append("? extends ");
/*  807 */         return appendTypeSignature(string, start + 1, fullyQualifyTypeNames, buffer);
/*      */       case '-':
/*  809 */         buffer.append("? super ");
/*  810 */         return appendTypeSignature(string, start + 1, fullyQualifyTypeNames, buffer);
/*      */     } 
/*  812 */     return appendTypeSignature(string, start, fullyQualifyTypeNames, buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int appendTypeArgumentSignatures(char[] string, int start, boolean fullyQualifyTypeNames, StringBuffer buffer) {
/*  833 */     if (start >= string.length - 1) {
/*  834 */       throw newIllegalArgumentException(string, start);
/*      */     }
/*  836 */     char c = string[start];
/*  837 */     if (c != '<') {
/*  838 */       throw newIllegalArgumentException(string, start);
/*      */     }
/*  840 */     buffer.append('<');
/*  841 */     int p = start + 1;
/*  842 */     int count = 0;
/*      */     while (true) {
/*  844 */       if (p >= string.length) {
/*  845 */         throw newIllegalArgumentException(string, start);
/*      */       }
/*  847 */       c = string[p];
/*  848 */       if (c == '>') {
/*  849 */         buffer.append('>');
/*  850 */         return p;
/*      */       } 
/*  852 */       if (count != 0) {
/*  853 */         buffer.append(',');
/*      */       }
/*  855 */       int e = appendTypeArgumentSignature(string, p, fullyQualifyTypeNames, buffer);
/*  856 */       count++;
/*  857 */       p = e + 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int appendTypeSignature(char[] string, int start, boolean fullyQualifyTypeNames, StringBuffer buffer) {
/*  875 */     return appendTypeSignature(string, start, fullyQualifyTypeNames, buffer, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int appendTypeSignature(char[] string, int start, boolean fullyQualifyTypeNames, StringBuffer buffer, boolean isVarArgs) {
/*      */     int e;
/*  897 */     if (start >= string.length) {
/*  898 */       throw newIllegalArgumentException(string, start);
/*      */     }
/*  900 */     char c = string[start];
/*  901 */     if (isVarArgs) {
/*  902 */       switch (c) {
/*      */         case '[':
/*  904 */           return appendArrayTypeSignature(string, start, fullyQualifyTypeNames, buffer, true);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  923 */       throw newIllegalArgumentException(string, start);
/*      */     } 
/*      */     
/*  926 */     switch (c) {
/*      */       case '[':
/*  928 */         return appendArrayTypeSignature(string, start, fullyQualifyTypeNames, buffer);
/*      */       case 'L':
/*      */       case 'Q':
/*  931 */         return appendClassTypeSignature(string, start, fullyQualifyTypeNames, buffer);
/*      */       case 'T':
/*  933 */         e = Util.scanTypeVariableSignature(string, start);
/*  934 */         buffer.append(string, start + 1, e - start - 1);
/*  935 */         return e;
/*      */       case 'Z':
/*  937 */         buffer.append(BOOLEAN);
/*  938 */         return start;
/*      */       case 'B':
/*  940 */         buffer.append(BYTE);
/*  941 */         return start;
/*      */       case 'C':
/*  943 */         buffer.append(CHAR);
/*  944 */         return start;
/*      */       case 'D':
/*  946 */         buffer.append(DOUBLE);
/*  947 */         return start;
/*      */       case 'F':
/*  949 */         buffer.append(FLOAT);
/*  950 */         return start;
/*      */       case 'I':
/*  952 */         buffer.append(INT);
/*  953 */         return start;
/*      */       case 'J':
/*  955 */         buffer.append(LONG);
/*  956 */         return start;
/*      */       case 'S':
/*  958 */         buffer.append(SHORT);
/*  959 */         return start;
/*      */       case 'V':
/*  961 */         buffer.append(VOID);
/*  962 */         return start;
/*      */       case '!':
/*  964 */         return appendCaptureTypeSignature(string, start, fullyQualifyTypeNames, buffer);
/*      */       case '|':
/*  966 */         return appendIntersectionTypeSignature(string, start, fullyQualifyTypeNames, buffer);
/*      */       case '*':
/*      */       case '+':
/*      */       case '-':
/*  970 */         return appendTypeArgumentSignature(string, start, fullyQualifyTypeNames, buffer);
/*      */     } 
/*  972 */     throw newIllegalArgumentException(string, start);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static int checkArrayDimension(char[] typeName, int pos, int length) {
/*  978 */     int genericBalance = 0;
/*  979 */     while (pos < length) {
/*  980 */       switch (typeName[pos]) {
/*      */         case '<':
/*  982 */           genericBalance++;
/*      */           break;
/*      */         case ',':
/*  985 */           if (genericBalance == 0) return -1; 
/*      */           break;
/*      */         case '>':
/*  988 */           if (genericBalance == 0) return -1; 
/*  989 */           genericBalance--;
/*      */           break;
/*      */         case '[':
/*  992 */           if (genericBalance == 0)
/*  993 */             return pos; 
/*      */           break;
/*      */       } 
/*  996 */       pos++;
/*      */     } 
/*  998 */     return -1;
/*      */   }
/*      */   private static int checkName(char[] name, char[] typeName, int pos, int length) {
/* 1001 */     if (CharOperation.fragmentEquals(name, typeName, pos, true)) {
/* 1002 */       pos += name.length;
/* 1003 */       if (pos == length) return pos; 
/* 1004 */       char currentChar = typeName[pos];
/* 1005 */       switch (currentChar) {
/*      */         case ' ':
/*      */         case ',':
/*      */         case '.':
/*      */         case '<':
/*      */         case '>':
/*      */         case '[':
/* 1012 */           return pos;
/*      */       } 
/* 1014 */       if (ScannerHelper.isWhitespace(currentChar)) {
/* 1015 */         return pos;
/*      */       }
/*      */     } 
/*      */     
/* 1019 */     return -1;
/*      */   }
/*      */   private static int checkNextChar(char[] typeName, char expectedChar, int pos, int length, boolean isOptional) {
/* 1022 */     pos = consumeWhitespace(typeName, pos, length);
/* 1023 */     if (pos < length && typeName[pos] == expectedChar)
/* 1024 */       return pos + 1; 
/* 1025 */     if (!isOptional) throw new IllegalArgumentException(String.valueOf(typeName)); 
/* 1026 */     return -1;
/*      */   }
/*      */   
/*      */   private static int consumeWhitespace(char[] typeName, int pos, int length) {
/* 1030 */     while (pos < length) {
/* 1031 */       char currentChar = typeName[pos];
/* 1032 */       if (currentChar != ' ' && !ScannerHelper.isWhitespace(currentChar)) {
/*      */         break;
/*      */       }
/* 1035 */       pos++;
/*      */     } 
/* 1037 */     return pos;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] createArraySignature(char[] typeSignature, int arrayCount) {
/* 1050 */     if (arrayCount == 0) return typeSignature; 
/* 1051 */     int sigLength = typeSignature.length;
/* 1052 */     char[] result = new char[arrayCount + sigLength];
/* 1053 */     for (int i = 0; i < arrayCount; i++) {
/* 1054 */       result[i] = '[';
/*      */     }
/* 1056 */     System.arraycopy(typeSignature, 0, result, arrayCount, sigLength);
/* 1057 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String createArraySignature(String typeSignature, int arrayCount) {
/* 1068 */     return new String(createArraySignature(typeSignature.toCharArray(), arrayCount));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] createCharArrayTypeSignature(char[] typeName, boolean isResolved) {
/* 1091 */     if (typeName == null) throw new IllegalArgumentException("null"); 
/* 1092 */     int length = typeName.length;
/* 1093 */     if (length == 0) throw new IllegalArgumentException(String.valueOf(typeName)); 
/* 1094 */     StringBuffer buffer = new StringBuffer(5);
/* 1095 */     int pos = encodeTypeSignature(typeName, 0, isResolved, length, buffer);
/* 1096 */     pos = consumeWhitespace(typeName, pos, length);
/* 1097 */     if (pos < length) throw new IllegalArgumentException(String.valueOf(typeName)); 
/* 1098 */     char[] result = new char[length = buffer.length()];
/* 1099 */     buffer.getChars(0, length, result, 0);
/* 1100 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String createIntersectionTypeSignature(char[][] typeSignatures) {
/* 1113 */     StringBuffer buffer = new StringBuffer();
/* 1114 */     buffer.append('|');
/* 1115 */     for (int i = 0, max = typeSignatures.length; i < max; i++) {
/* 1116 */       if (i > 0) {
/* 1117 */         buffer.append(':');
/*      */       }
/* 1119 */       buffer.append(typeSignatures[i]);
/*      */     } 
/* 1121 */     return String.valueOf(buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String createUnionTypeSignature(char[][] typeSignatures) {
/* 1133 */     StringBuffer buffer = new StringBuffer();
/* 1134 */     buffer.append('&');
/* 1135 */     for (int i = 0, max = typeSignatures.length; i < max; i++) {
/* 1136 */       if (i > 0) {
/* 1137 */         buffer.append(':');
/*      */       }
/* 1139 */       buffer.append(typeSignatures[i]);
/*      */     } 
/* 1141 */     return String.valueOf(buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String createIntersectionTypeSignature(String[] typeSignatures) {
/* 1154 */     int typeSignaturesLenth = typeSignatures.length;
/* 1155 */     char[][] signatures = new char[typeSignaturesLenth][];
/* 1156 */     for (int i = 0; i < typeSignaturesLenth; i++) {
/* 1157 */       signatures[i] = typeSignatures[i].toCharArray();
/*      */     }
/* 1159 */     return createIntersectionTypeSignature(signatures);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String createUnionTypeSignature(String[] typeSignatures) {
/* 1171 */     int typeSignaturesLenth = typeSignatures.length;
/* 1172 */     char[][] signatures = new char[typeSignaturesLenth][];
/* 1173 */     for (int i = 0; i < typeSignaturesLenth; i++) {
/* 1174 */       signatures[i] = typeSignatures[i].toCharArray();
/*      */     }
/* 1176 */     return createUnionTypeSignature(signatures);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] createMethodSignature(char[][] parameterTypes, char[] returnType) {
/* 1189 */     int parameterTypesLength = parameterTypes.length;
/* 1190 */     int parameterLength = 0;
/* 1191 */     for (int i = 0; i < parameterTypesLength; i++) {
/* 1192 */       parameterLength += (parameterTypes[i]).length;
/*      */     }
/*      */     
/* 1195 */     int returnTypeLength = returnType.length;
/* 1196 */     char[] result = new char[1 + parameterLength + 1 + returnTypeLength];
/* 1197 */     result[0] = '(';
/* 1198 */     int index = 1;
/* 1199 */     for (int j = 0; j < parameterTypesLength; j++) {
/* 1200 */       char[] parameterType = parameterTypes[j];
/* 1201 */       int length = parameterType.length;
/* 1202 */       System.arraycopy(parameterType, 0, result, index, length);
/* 1203 */       index += length;
/*      */     } 
/* 1205 */     result[index] = ')';
/* 1206 */     System.arraycopy(returnType, 0, result, index + 1, returnTypeLength);
/* 1207 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String createMethodSignature(String[] parameterTypes, String returnType) {
/* 1221 */     int parameterTypesLenth = parameterTypes.length;
/* 1222 */     char[][] parameters = new char[parameterTypesLenth][];
/* 1223 */     for (int i = 0; i < parameterTypesLenth; i++) {
/* 1224 */       parameters[i] = parameterTypes[i].toCharArray();
/*      */     }
/* 1226 */     return new String(createMethodSignature(parameters, returnType.toCharArray()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] createTypeParameterSignature(char[] typeParameterName, char[][] boundSignatures) {
/* 1238 */     int length = boundSignatures.length;
/* 1239 */     if (length == 0) {
/* 1240 */       return CharOperation.append(typeParameterName, ':');
/*      */     }
/* 1242 */     int boundsSize = 0;
/* 1243 */     for (int i = 0; i < length; i++) {
/* 1244 */       boundsSize += (boundSignatures[i]).length + 1;
/*      */     }
/* 1246 */     int nameLength = typeParameterName.length;
/* 1247 */     char[] result = new char[nameLength + boundsSize];
/* 1248 */     System.arraycopy(typeParameterName, 0, result, 0, nameLength);
/* 1249 */     int index = nameLength;
/* 1250 */     for (int j = 0; j < length; j++) {
/* 1251 */       result[index++] = ':';
/* 1252 */       int boundLength = (boundSignatures[j]).length;
/* 1253 */       System.arraycopy(boundSignatures[j], 0, result, index, boundLength);
/* 1254 */       index += boundLength;
/*      */     } 
/* 1256 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String createTypeParameterSignature(String typeParameterName, String[] boundSignatures) {
/* 1268 */     int length = boundSignatures.length;
/* 1269 */     char[][] boundSignatureChars = new char[length][];
/* 1270 */     for (int i = 0; i < length; i++) {
/* 1271 */       boundSignatureChars[i] = boundSignatures[i].toCharArray();
/*      */     }
/* 1273 */     return new String(createTypeParameterSignature(typeParameterName.toCharArray(), boundSignatureChars));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String createTypeSignature(char[] typeName, boolean isResolved) {
/* 1293 */     return new String(createCharArrayTypeSignature(typeName, isResolved));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String createTypeSignature(String typeName, boolean isResolved) {
/* 1320 */     return createTypeSignature((typeName == null) ? null : typeName.toCharArray(), isResolved);
/*      */   }
/*      */   
/*      */   private static int encodeArrayDimension(char[] typeName, int pos, int length, StringBuffer buffer) {
/*      */     int checkPos;
/* 1325 */     while (pos < length && (checkPos = checkNextChar(typeName, '[', pos, length, true)) > 0) {
/* 1326 */       pos = checkNextChar(typeName, ']', checkPos, length, false);
/* 1327 */       buffer.append('[');
/*      */     } 
/* 1329 */     return pos;
/*      */   }
/*      */   
/*      */   private static int encodeQualifiedName(char[] typeName, int pos, int length, StringBuffer buffer) {
/* 1333 */     int count = 0;
/* 1334 */     char lastAppendedChar = Character.MIN_VALUE;
/* 1335 */     while (pos < length) {
/* 1336 */       char currentChar = typeName[pos];
/* 1337 */       switch (currentChar) {
/*      */         case '&':
/*      */         case ',':
/*      */         case '<':
/*      */         case '>':
/*      */         case '[':
/*      */           break;
/*      */         case '.':
/* 1345 */           buffer.append('.');
/* 1346 */           lastAppendedChar = '.';
/* 1347 */           count++;
/*      */           break;
/*      */         default:
/* 1350 */           if (currentChar == ' ' || ScannerHelper.isWhitespace(currentChar)) {
/* 1351 */             if (lastAppendedChar == '.') {
/* 1352 */               pos = consumeWhitespace(typeName, pos, length) - 1;
/*      */               
/*      */               break;
/*      */             } 
/* 1356 */             int checkPos = checkNextChar(typeName, '.', pos, length, true);
/* 1357 */             if (checkPos > 0) {
/* 1358 */               buffer.append('.');
/* 1359 */               lastAppendedChar = '.';
/* 1360 */               count++;
/* 1361 */               pos = checkPos;
/*      */               break;
/*      */             } 
/*      */             break;
/*      */           } 
/* 1366 */           buffer.append(currentChar);
/* 1367 */           lastAppendedChar = currentChar;
/* 1368 */           count++;
/*      */           break;
/*      */       } 
/* 1371 */       pos++;
/*      */     } 
/* 1373 */     if (count == 0) throw new IllegalArgumentException(String.valueOf(typeName)); 
/* 1374 */     return pos;
/*      */   }
/*      */   
/*      */   private static int encodeTypeSignature(char[] typeName, int start, boolean isResolved, int length, StringBuffer buffer) {
/* 1378 */     int end, pos = start;
/* 1379 */     pos = consumeWhitespace(typeName, pos, length);
/* 1380 */     if (pos >= length) throw new IllegalArgumentException(String.valueOf(typeName));
/*      */     
/* 1382 */     char currentChar = typeName[pos];
/* 1383 */     switch (currentChar) {
/*      */       
/*      */       case 'b':
/* 1386 */         checkPos = checkName(BOOLEAN, typeName, pos, length);
/* 1387 */         if (checkPos > 0) {
/* 1388 */           pos = encodeArrayDimension(typeName, checkPos, length, buffer);
/* 1389 */           buffer.append('Z');
/* 1390 */           return pos;
/*      */         } 
/* 1392 */         checkPos = checkName(BYTE, typeName, pos, length);
/* 1393 */         if (checkPos > 0) {
/* 1394 */           pos = encodeArrayDimension(typeName, checkPos, length, buffer);
/* 1395 */           buffer.append('B');
/* 1396 */           return pos;
/*      */         } 
/*      */         break;
/*      */       case 'd':
/* 1400 */         checkPos = checkName(DOUBLE, typeName, pos, length);
/* 1401 */         if (checkPos > 0) {
/* 1402 */           pos = encodeArrayDimension(typeName, checkPos, length, buffer);
/* 1403 */           buffer.append('D');
/* 1404 */           return pos;
/*      */         } 
/*      */         break;
/*      */       case 'f':
/* 1408 */         checkPos = checkName(FLOAT, typeName, pos, length);
/* 1409 */         if (checkPos > 0) {
/* 1410 */           pos = encodeArrayDimension(typeName, checkPos, length, buffer);
/* 1411 */           buffer.append('F');
/* 1412 */           return pos;
/*      */         } 
/*      */         break;
/*      */       case 'i':
/* 1416 */         checkPos = checkName(INT, typeName, pos, length);
/* 1417 */         if (checkPos > 0) {
/* 1418 */           pos = encodeArrayDimension(typeName, checkPos, length, buffer);
/* 1419 */           buffer.append('I');
/* 1420 */           return pos;
/*      */         } 
/*      */         break;
/*      */       case 'l':
/* 1424 */         checkPos = checkName(LONG, typeName, pos, length);
/* 1425 */         if (checkPos > 0) {
/* 1426 */           pos = encodeArrayDimension(typeName, checkPos, length, buffer);
/* 1427 */           buffer.append('J');
/* 1428 */           return pos;
/*      */         } 
/*      */         break;
/*      */       case 's':
/* 1432 */         checkPos = checkName(SHORT, typeName, pos, length);
/* 1433 */         if (checkPos > 0) {
/* 1434 */           pos = encodeArrayDimension(typeName, checkPos, length, buffer);
/* 1435 */           buffer.append('S');
/* 1436 */           return pos;
/*      */         } 
/*      */         break;
/*      */       case 'v':
/* 1440 */         checkPos = checkName(VOID, typeName, pos, length);
/* 1441 */         if (checkPos > 0) {
/* 1442 */           pos = encodeArrayDimension(typeName, checkPos, length, buffer);
/* 1443 */           buffer.append('V');
/* 1444 */           return pos;
/*      */         } 
/*      */         break;
/*      */       case 'c':
/* 1448 */         checkPos = checkName(CHAR, typeName, pos, length);
/* 1449 */         if (checkPos > 0) {
/* 1450 */           pos = encodeArrayDimension(typeName, checkPos, length, buffer);
/* 1451 */           buffer.append('C');
/* 1452 */           return pos;
/*      */         } 
/* 1454 */         checkPos = checkName(CAPTURE, typeName, pos, length);
/* 1455 */         if (checkPos > 0)
/* 1456 */         { pos = consumeWhitespace(typeName, checkPos, length);
/* 1457 */           if (typeName[pos] != '?') {
/*      */             break;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1464 */           buffer.append('!'); }
/*      */         else { break; }
/*      */       
/*      */       case '?':
/* 1468 */         pos = consumeWhitespace(typeName, pos + 1, length);
/* 1469 */         checkPos = checkName(EXTENDS, typeName, pos, length);
/* 1470 */         if (checkPos > 0) {
/* 1471 */           buffer.append('+');
/* 1472 */           pos = encodeTypeSignature(typeName, checkPos, isResolved, length, buffer);
/* 1473 */           return pos;
/*      */         } 
/* 1475 */         checkPos = checkName(SUPER, typeName, pos, length);
/* 1476 */         if (checkPos > 0) {
/* 1477 */           buffer.append('-');
/* 1478 */           pos = encodeTypeSignature(typeName, checkPos, isResolved, length, buffer);
/* 1479 */           return pos;
/*      */         } 
/* 1481 */         buffer.append('*');
/* 1482 */         return pos;
/*      */     } 
/*      */     
/* 1485 */     int checkPos = checkArrayDimension(typeName, pos, length);
/*      */     
/* 1487 */     if (checkPos > 0) {
/* 1488 */       end = encodeArrayDimension(typeName, checkPos, length, buffer);
/*      */     } else {
/* 1490 */       end = -1;
/*      */     } 
/* 1492 */     buffer.append(isResolved ? 76 : 81);
/*      */     
/*      */     while (true) {
/* 1495 */       pos = encodeQualifiedName(typeName, pos, length, buffer);
/* 1496 */       checkPos = checkNextChar(typeName, '<', pos, length, true);
/* 1497 */       if (checkPos > 0) {
/* 1498 */         buffer.append('<');
/*      */         
/* 1500 */         if ((pos = checkNextChar(typeName, '>', checkPos, length, true)) > 0) {
/* 1501 */           buffer.append('>');
/*      */         } else {
/* 1503 */           pos = encodeTypeSignature(typeName, checkPos, isResolved, length, buffer);
/* 1504 */           while ((checkPos = checkNextChar(typeName, ',', pos, length, true)) > 0) {
/* 1505 */             pos = encodeTypeSignature(typeName, checkPos, isResolved, length, buffer);
/*      */           }
/* 1507 */           pos = checkNextChar(typeName, '>', pos, length, false);
/* 1508 */           buffer.append('>');
/*      */         } 
/*      */       } 
/* 1511 */       checkPos = checkNextChar(typeName, '.', pos, length, true);
/* 1512 */       if (checkPos > 0) {
/* 1513 */         buffer.append('.');
/* 1514 */         pos = checkPos;
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/* 1519 */       buffer.append(';');
/* 1520 */       checkPos = checkNextChar(typeName, '&', pos, length, true);
/* 1521 */       if (checkPos > 0) {
/* 1522 */         if (buffer.charAt(0) != '&')
/* 1523 */           buffer.insert(0, '&'); 
/* 1524 */         buffer.append(':');
/* 1525 */         pos = encodeTypeSignature(typeName, checkPos, isResolved, length, buffer);
/* 1526 */         if (pos == length) {
/*      */           break;
/*      */         }
/*      */         continue;
/*      */       } 
/*      */       break;
/*      */     } 
/* 1533 */     if (end > 0) pos = end; 
/* 1534 */     return pos;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getArrayCount(char[] typeSignature) throws IllegalArgumentException {
/*      */     try {
/* 1549 */       int count = 0;
/* 1550 */       while (typeSignature[count] == '[') {
/* 1551 */         count++;
/*      */       }
/* 1553 */       return count;
/* 1554 */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
/* 1555 */       throw new IllegalArgumentException(String.valueOf(typeSignature));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getArrayCount(String typeSignature) throws IllegalArgumentException {
/* 1568 */     return getArrayCount(typeSignature.toCharArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] getElementType(char[] typeSignature) throws IllegalArgumentException {
/* 1589 */     int count = getArrayCount(typeSignature);
/* 1590 */     if (count == 0) return typeSignature; 
/* 1591 */     int length = typeSignature.length;
/* 1592 */     char[] result = new char[length - count];
/* 1593 */     System.arraycopy(typeSignature, count, result, 0, length - count);
/* 1594 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getElementType(String typeSignature) throws IllegalArgumentException {
/* 1613 */     char[] signature = typeSignature.toCharArray();
/* 1614 */     char[] elementType = getElementType(signature);
/* 1615 */     return (signature == elementType) ? typeSignature : new String(elementType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[][] getIntersectionTypeBounds(char[] intersectionTypeSignature) throws IllegalArgumentException {
/* 1628 */     if (getTypeSignatureKind(intersectionTypeSignature) != 7) {
/* 1629 */       return CharOperation.NO_CHAR_CHAR;
/*      */     }
/* 1631 */     ArrayList<char[]> args = new ArrayList();
/* 1632 */     int i = 1;
/* 1633 */     int length = intersectionTypeSignature.length;
/*      */     while (true) {
/* 1635 */       int e = Util.scanClassTypeSignature(intersectionTypeSignature, i);
/* 1636 */       if (e < 0) {
/* 1637 */         throw new IllegalArgumentException("Invalid format");
/*      */       }
/* 1639 */       args.add(CharOperation.subarray(intersectionTypeSignature, i, e + 1));
/* 1640 */       if (e == length - 1) {
/* 1641 */         int size = args.size();
/* 1642 */         char[][] result = new char[size][];
/* 1643 */         args.toArray(result);
/* 1644 */         return result;
/* 1645 */       }  if (intersectionTypeSignature[e + 1] != ':') {
/* 1646 */         throw new IllegalArgumentException("Invalid format");
/*      */       }
/* 1648 */       i = e + 2;
/*      */     } 
/*      */   }
/*      */   private static char[][] getUnionTypeBounds(char[] unionTypeSignature) throws IllegalArgumentException {
/* 1652 */     if (getTypeSignatureKind(unionTypeSignature) != 8) {
/* 1653 */       return CharOperation.NO_CHAR_CHAR;
/*      */     }
/* 1655 */     ArrayList<char[]> args = new ArrayList();
/* 1656 */     int i = 1;
/* 1657 */     int length = unionTypeSignature.length;
/*      */     while (true) {
/* 1659 */       int e = Util.scanClassTypeSignature(unionTypeSignature, i);
/* 1660 */       if (e < 0) {
/* 1661 */         throw new IllegalArgumentException("Invalid format");
/*      */       }
/* 1663 */       args.add(CharOperation.subarray(unionTypeSignature, i, e + 1));
/* 1664 */       if (e == length - 1) {
/* 1665 */         int size = args.size();
/* 1666 */         char[][] result = new char[size][];
/* 1667 */         args.toArray(result);
/* 1668 */         return result;
/* 1669 */       }  if (unionTypeSignature[e + 1] != ':') {
/* 1670 */         throw new IllegalArgumentException("Invalid format");
/*      */       }
/* 1672 */       i = e + 2;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getIntersectionTypeBounds(String intersectionTypeSignature) throws IllegalArgumentException {
/* 1686 */     char[][] args = getIntersectionTypeBounds(intersectionTypeSignature.toCharArray());
/* 1687 */     return CharOperation.toStrings(args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getUnionTypeBounds(String unionSignature) throws IllegalArgumentException {
/* 1700 */     char[][] args = getUnionTypeBounds(unionSignature.toCharArray());
/* 1701 */     return CharOperation.toStrings(args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getParameterCount(char[] methodSignature) throws IllegalArgumentException {
/*      */     try {
/* 1714 */       int count = 0;
/* 1715 */       int i = CharOperation.indexOf('(', methodSignature);
/* 1716 */       if (i < 0) {
/* 1717 */         throw new IllegalArgumentException(String.valueOf(methodSignature));
/*      */       }
/* 1719 */       i++;
/*      */       
/*      */       while (true) {
/* 1722 */         if (methodSignature[i] == ')') {
/* 1723 */           return count;
/*      */         }
/* 1725 */         int e = Util.scanTypeSignature(methodSignature, i);
/* 1726 */         if (e < 0) {
/* 1727 */           throw new IllegalArgumentException(String.valueOf(methodSignature));
/*      */         }
/* 1729 */         i = e + 1;
/*      */         
/* 1731 */         count++;
/*      */       } 
/* 1733 */     } catch (ArrayIndexOutOfBoundsException e) {
/* 1734 */       throw new IllegalArgumentException(String.valueOf(methodSignature), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getParameterCount(String methodSignature) throws IllegalArgumentException {
/* 1747 */     return getParameterCount(methodSignature.toCharArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[][] getParameterTypes(char[] methodSignature) throws IllegalArgumentException {
/*      */     try {
/* 1763 */       int count = getParameterCount(methodSignature);
/* 1764 */       char[][] result = new char[count][];
/* 1765 */       if (count == 0) {
/* 1766 */         return result;
/*      */       }
/* 1768 */       int i = CharOperation.indexOf('(', methodSignature);
/* 1769 */       if (i < 0) {
/* 1770 */         throw new IllegalArgumentException(String.valueOf(methodSignature));
/*      */       }
/* 1772 */       i++;
/*      */       
/* 1774 */       int t = 0;
/*      */       while (true) {
/* 1776 */         if (methodSignature[i] == ')') {
/* 1777 */           return result;
/*      */         }
/* 1779 */         int e = Util.scanTypeSignature(methodSignature, i);
/* 1780 */         if (e < 0) {
/* 1781 */           throw new IllegalArgumentException(String.valueOf(methodSignature));
/*      */         }
/* 1783 */         result[t] = CharOperation.subarray(methodSignature, i, e + 1);
/* 1784 */         t++;
/* 1785 */         i = e + 1;
/*      */       } 
/* 1787 */     } catch (ArrayIndexOutOfBoundsException e) {
/* 1788 */       throw new IllegalArgumentException(String.valueOf(methodSignature), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getParameterTypes(String methodSignature) throws IllegalArgumentException {
/* 1801 */     char[][] parameterTypes = getParameterTypes(methodSignature.toCharArray());
/* 1802 */     return CharOperation.toStrings(parameterTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] getQualifier(char[] name) {
/* 1825 */     int firstGenericStart = CharOperation.indexOf('<', name);
/* 1826 */     int lastDot = CharOperation.lastIndexOf('.', name, 0, (firstGenericStart == -1) ? (name.length - 1) : firstGenericStart);
/* 1827 */     if (lastDot == -1) {
/* 1828 */       return CharOperation.NO_CHAR;
/*      */     }
/* 1830 */     return CharOperation.subarray(name, 0, lastDot);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getQualifier(String name) {
/* 1852 */     char[] qualifier = getQualifier(name.toCharArray());
/* 1853 */     if (qualifier.length == 0) return Util.EMPTY_STRING; 
/* 1854 */     return new String(qualifier);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] getReturnType(char[] methodSignature) throws IllegalArgumentException {
/* 1870 */     int paren = CharOperation.lastIndexOf(')', methodSignature);
/* 1871 */     if (paren == -1) {
/* 1872 */       throw new IllegalArgumentException(String.valueOf(methodSignature));
/*      */     }
/*      */     
/* 1875 */     int last = Util.scanTypeSignature(methodSignature, paren + 1);
/* 1876 */     return CharOperation.subarray(methodSignature, paren + 1, last + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getReturnType(String methodSignature) throws IllegalArgumentException {
/* 1889 */     return new String(getReturnType(methodSignature.toCharArray()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] getSignatureQualifier(char[] typeSignature) {
/* 1908 */     if (typeSignature == null) return CharOperation.NO_CHAR;
/*      */     
/* 1910 */     char[] qualifiedType = toCharArray(typeSignature);
/*      */     
/* 1912 */     int dotCount = 0; int i;
/* 1913 */     for (i = 0; i < typeSignature.length; i++) {
/* 1914 */       switch (typeSignature[i]) {
/*      */         case '.':
/* 1916 */           dotCount++;
/*      */           break;
/*      */         
/*      */         case '<':
/*      */         case '$':
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/* 1925 */     if (dotCount > 0) {
/* 1926 */       for (i = 0; i < qualifiedType.length; i++) {
/* 1927 */         if (qualifiedType[i] == '.') {
/* 1928 */           dotCount--;
/*      */         }
/* 1930 */         if (dotCount <= 0) {
/* 1931 */           return CharOperation.subarray(qualifiedType, 0, i);
/*      */         }
/*      */       } 
/*      */     }
/* 1935 */     return CharOperation.NO_CHAR;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getSignatureQualifier(String typeSignature) {
/* 1953 */     return new String(getSignatureQualifier((typeSignature == null) ? null : typeSignature.toCharArray()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] getSignatureSimpleName(char[] typeSignature) {
/* 1971 */     if (typeSignature == null) return CharOperation.NO_CHAR;
/*      */     
/* 1973 */     char[] qualifiedType = toCharArray(typeSignature);
/*      */     
/* 1975 */     int dotCount = 0;
/* 1976 */     for (int i = 0; i < typeSignature.length; i++) {
/* 1977 */       switch (typeSignature[i]) {
/*      */         case '.':
/* 1979 */           dotCount++;
/*      */           break;
/*      */         
/*      */         case '<':
/*      */         case '$':
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/* 1988 */     if (dotCount > 0) {
/* 1989 */       int typeStart = 0;
/* 1990 */       for (int j = 0; j < qualifiedType.length; j++) {
/* 1991 */         switch (qualifiedType[j]) {
/*      */           case '.':
/* 1993 */             dotCount--;
/*      */             break;
/*      */           case ' ':
/* 1996 */             typeStart = j + 1;
/*      */             break;
/*      */         } 
/* 1999 */         if (dotCount <= 0) {
/* 2000 */           char[] simpleName = CharOperation.subarray(qualifiedType, j + 1, qualifiedType.length);
/* 2001 */           if (typeStart > 0 && typeStart < qualifiedType.length)
/* 2002 */             return CharOperation.concat(CharOperation.subarray(qualifiedType, 0, typeStart), simpleName); 
/* 2003 */           return simpleName;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2007 */     return qualifiedType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getSignatureSimpleName(String typeSignature) {
/* 2025 */     return new String(getSignatureSimpleName((typeSignature == null) ? null : typeSignature.toCharArray()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] getSimpleName(char[] name) {
/* 2045 */     int lastDot = -1, lastGenericStart = -1, lastGenericEnd = -1;
/* 2046 */     int depth = 0;
/* 2047 */     int length = name.length;
/* 2048 */     for (int i = length - 1; i >= 0; i--) {
/* 2049 */       switch (name[i]) {
/*      */         case '.':
/* 2051 */           if (depth == 0) {
/* 2052 */             lastDot = i;
/*      */             break;
/*      */           } 
/*      */           break;
/*      */         case '<':
/* 2057 */           depth--;
/* 2058 */           if (depth == 0) lastGenericStart = i; 
/*      */           break;
/*      */         case '>':
/* 2061 */           if (depth == 0) lastGenericEnd = i; 
/* 2062 */           depth++;
/*      */           break;
/*      */       } 
/*      */     } 
/* 2066 */     if (lastGenericStart < 0) {
/* 2067 */       if (lastDot < 0) {
/* 2068 */         return name;
/*      */       }
/* 2070 */       return CharOperation.subarray(name, lastDot + 1, length);
/*      */     } 
/* 2072 */     StringBuffer buffer = new StringBuffer(10);
/* 2073 */     int nameStart = (lastDot < 0) ? 0 : (lastDot + 1);
/* 2074 */     buffer.append(name, nameStart, lastGenericStart - nameStart);
/* 2075 */     appendArgumentSimpleNames(name, lastGenericStart, lastGenericEnd, buffer);
/* 2076 */     buffer.append(name, lastGenericEnd + 1, length - lastGenericEnd - 1);
/* 2077 */     char[] result = new char[length = buffer.length()];
/* 2078 */     buffer.getChars(0, length, result, 0);
/* 2079 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getSimpleName(String name) {
/* 2100 */     int lastDot = -1, lastGenericStart = -1, lastGenericEnd = -1;
/* 2101 */     int depth = 0;
/* 2102 */     int length = name.length();
/* 2103 */     for (int i = length - 1; i >= 0; i--) {
/* 2104 */       switch (name.charAt(i)) {
/*      */         case '.':
/* 2106 */           if (depth == 0) {
/* 2107 */             lastDot = i;
/*      */             break;
/*      */           } 
/*      */           break;
/*      */         case '<':
/* 2112 */           depth--;
/* 2113 */           if (depth == 0) lastGenericStart = i; 
/*      */           break;
/*      */         case '>':
/* 2116 */           if (depth == 0) lastGenericEnd = i; 
/* 2117 */           depth++;
/*      */           break;
/*      */       } 
/*      */     } 
/* 2121 */     if (lastGenericStart < 0) {
/* 2122 */       if (lastDot < 0) {
/* 2123 */         return name;
/*      */       }
/* 2125 */       return name.substring(lastDot + 1, length);
/*      */     } 
/* 2127 */     StringBuffer buffer = new StringBuffer(10);
/* 2128 */     char[] nameChars = name.toCharArray();
/* 2129 */     int nameStart = (lastDot < 0) ? 0 : (lastDot + 1);
/* 2130 */     buffer.append(nameChars, nameStart, lastGenericStart - nameStart);
/* 2131 */     appendArgumentSimpleNames(nameChars, lastGenericStart, lastGenericEnd, buffer);
/* 2132 */     buffer.append(nameChars, lastGenericEnd + 1, length - lastGenericEnd - 1);
/* 2133 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[][] getSimpleNames(char[] name) {
/* 2156 */     int length = (name == null) ? 0 : name.length;
/* 2157 */     if (length == 0) {
/* 2158 */       return CharOperation.NO_CHAR_CHAR;
/*      */     }
/* 2160 */     int wordCount = 1;
/* 2161 */     for (int i = 0; i < length; i++) {
/* 2162 */       switch (name[i]) {
/*      */         case '.':
/* 2164 */           wordCount++; break;
/*      */         case '<':
/*      */           break;
/*      */       } 
/*      */     } 
/* 2169 */     char[][] split = new char[wordCount][];
/* 2170 */     int last = 0, currentWord = 0;
/* 2171 */     for (int j = 0; j < length && 
/* 2172 */       name[j] != '<'; j++) {
/* 2173 */       if (name[j] == '.') {
/* 2174 */         split[currentWord] = new char[j - last];
/* 2175 */         System.arraycopy(
/* 2176 */             name, 
/* 2177 */             last, 
/* 2178 */             split[currentWord++], 
/* 2179 */             0, 
/* 2180 */             j - last);
/* 2181 */         last = j + 1;
/*      */       } 
/*      */     } 
/* 2184 */     split[currentWord] = new char[length - last];
/* 2185 */     System.arraycopy(name, last, split[currentWord], 0, length - last);
/* 2186 */     return split;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getSimpleNames(String name) {
/* 2209 */     return CharOperation.toStrings(getSimpleNames(name.toCharArray()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[][] getThrownExceptionTypes(char[] methodSignature) throws IllegalArgumentException {
/* 2225 */     int exceptionStart = CharOperation.indexOf('^', methodSignature);
/* 2226 */     if (exceptionStart == -1) {
/* 2227 */       int paren = CharOperation.lastIndexOf(')', methodSignature);
/* 2228 */       if (paren == -1) {
/* 2229 */         throw new IllegalArgumentException(String.valueOf(methodSignature));
/*      */       }
/*      */       
/* 2232 */       exceptionStart = Util.scanTypeSignature(methodSignature, paren + 1) + 1;
/* 2233 */       int j = methodSignature.length;
/* 2234 */       if (exceptionStart == j) return CharOperation.NO_CHAR_CHAR; 
/* 2235 */       throw new IllegalArgumentException(String.valueOf(methodSignature));
/*      */     } 
/* 2237 */     int length = methodSignature.length;
/* 2238 */     int i = exceptionStart;
/* 2239 */     ArrayList<char[]> exceptionList = new ArrayList(1);
/* 2240 */     while (i < length) {
/* 2241 */       if (methodSignature[i] == '^') {
/* 2242 */         exceptionStart++;
/* 2243 */         i++;
/*      */       } else {
/* 2245 */         throw new IllegalArgumentException(String.valueOf(methodSignature));
/*      */       } 
/* 2247 */       i = Util.scanTypeSignature(methodSignature, i) + 1;
/* 2248 */       exceptionList.add(CharOperation.subarray(methodSignature, exceptionStart, i));
/* 2249 */       exceptionStart = i;
/*      */     } 
/*      */     char[][] result;
/* 2252 */     exceptionList.toArray(result = new char[exceptionList.size()][]);
/* 2253 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getThrownExceptionTypes(String methodSignature) throws IllegalArgumentException {
/* 2267 */     char[][] parameterTypes = getThrownExceptionTypes(methodSignature.toCharArray());
/* 2268 */     return CharOperation.toStrings(parameterTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[][] getTypeArguments(char[] parameterizedTypeSignature) throws IllegalArgumentException {
/* 2281 */     int length = parameterizedTypeSignature.length;
/* 2282 */     if (length < 2 || parameterizedTypeSignature[length - 2] != '>')
/*      */     {
/* 2284 */       return CharOperation.NO_CHAR_CHAR; } 
/* 2285 */     int count = 1;
/* 2286 */     int start = length - 2;
/* 2287 */     while (start >= 0 && count > 0) {
/* 2288 */       switch (parameterizedTypeSignature[--start]) {
/*      */         case '<':
/* 2290 */           count--;
/*      */         
/*      */         case '>':
/* 2293 */           count++;
/*      */       } 
/*      */     
/*      */     } 
/* 2297 */     if (start < 0)
/* 2298 */       throw new IllegalArgumentException(String.valueOf(parameterizedTypeSignature)); 
/* 2299 */     ArrayList<char[]> args = new ArrayList();
/* 2300 */     int p = start + 1;
/*      */     while (true) {
/* 2302 */       if (p >= parameterizedTypeSignature.length) {
/* 2303 */         throw new IllegalArgumentException(String.valueOf(parameterizedTypeSignature));
/*      */       }
/* 2305 */       char c = parameterizedTypeSignature[p];
/* 2306 */       if (c == '>') {
/* 2307 */         int size = args.size();
/* 2308 */         char[][] result = new char[size][];
/* 2309 */         args.toArray((Object[])result);
/* 2310 */         return result;
/*      */       } 
/* 2312 */       int e = Util.scanTypeArgumentSignature(parameterizedTypeSignature, p);
/* 2313 */       args.add(CharOperation.subarray(parameterizedTypeSignature, p, e + 1));
/* 2314 */       p = e + 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getTypeArguments(String parameterizedTypeSignature) throws IllegalArgumentException {
/* 2328 */     char[][] args = getTypeArguments(parameterizedTypeSignature.toCharArray());
/* 2329 */     return CharOperation.toStrings(args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] getTypeErasure(char[] parameterizedTypeSignature) throws IllegalArgumentException {
/* 2343 */     int end = CharOperation.indexOf('<', parameterizedTypeSignature);
/* 2344 */     if (end == -1) return parameterizedTypeSignature; 
/* 2345 */     int length = parameterizedTypeSignature.length;
/* 2346 */     char[] result = new char[length];
/* 2347 */     int pos = 0;
/* 2348 */     int start = 0;
/* 2349 */     int deep = 0;
/* 2350 */     for (int idx = end; idx < length; idx++) {
/* 2351 */       switch (parameterizedTypeSignature[idx]) {
/*      */         case '<':
/* 2353 */           if (deep == 0) {
/* 2354 */             int i = idx - start;
/* 2355 */             System.arraycopy(parameterizedTypeSignature, start, result, pos, i);
/* 2356 */             end = idx;
/* 2357 */             pos += i;
/*      */           } 
/* 2359 */           deep++;
/*      */           break;
/*      */         case '>':
/* 2362 */           deep--;
/* 2363 */           if (deep < 0) throw new IllegalArgumentException(String.valueOf(parameterizedTypeSignature)); 
/* 2364 */           if (deep == 0) start = idx + 1; 
/*      */           break;
/*      */       } 
/*      */     } 
/* 2368 */     if (deep > 0) throw new IllegalArgumentException(String.valueOf(parameterizedTypeSignature)); 
/* 2369 */     int size = pos + length - start;
/* 2370 */     char[] resized = new char[size];
/* 2371 */     System.arraycopy(result, 0, resized, 0, pos);
/* 2372 */     System.arraycopy(parameterizedTypeSignature, start, resized, pos, length - start);
/* 2373 */     return resized;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getTypeErasure(String parameterizedTypeSignature) throws IllegalArgumentException {
/* 2387 */     char[] signature = parameterizedTypeSignature.toCharArray();
/* 2388 */     char[] erasure = getTypeErasure(signature);
/* 2389 */     return (signature == erasure) ? parameterizedTypeSignature : new String(erasure);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[][] getTypeParameterBounds(char[] formalTypeParameterSignature) throws IllegalArgumentException {
/*      */     char[] classBound;
/* 2404 */     int p1 = CharOperation.indexOf(':', formalTypeParameterSignature);
/* 2405 */     if (p1 < 0)
/*      */     {
/* 2407 */       throw new IllegalArgumentException(String.valueOf(formalTypeParameterSignature));
/*      */     }
/* 2409 */     if (p1 == formalTypeParameterSignature.length - 1)
/*      */     {
/* 2411 */       return CharOperation.NO_CHAR_CHAR;
/*      */     }
/* 2413 */     int p2 = CharOperation.indexOf(':', formalTypeParameterSignature, p1 + 1);
/*      */     
/* 2415 */     if (p2 < 0) {
/*      */       
/* 2417 */       classBound = CharOperation.subarray(formalTypeParameterSignature, p1 + 1, formalTypeParameterSignature.length);
/* 2418 */       return new char[][] { classBound };
/*      */     } 
/* 2420 */     if (p2 == p1 + 1) {
/*      */       
/* 2422 */       classBound = null;
/*      */     } else {
/* 2424 */       classBound = CharOperation.subarray(formalTypeParameterSignature, p1 + 1, p2);
/*      */     } 
/* 2426 */     char[][] interfaceBounds = CharOperation.splitOn(':', formalTypeParameterSignature, p2 + 1, formalTypeParameterSignature.length);
/* 2427 */     if (classBound == null) {
/* 2428 */       return interfaceBounds;
/*      */     }
/* 2430 */     int resultLength = interfaceBounds.length + 1;
/* 2431 */     char[][] result = new char[resultLength][];
/* 2432 */     result[0] = classBound;
/* 2433 */     System.arraycopy(interfaceBounds, 0, result, 1, interfaceBounds.length);
/* 2434 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getTypeParameterBounds(String formalTypeParameterSignature) throws IllegalArgumentException {
/* 2449 */     char[][] bounds = getTypeParameterBounds(formalTypeParameterSignature.toCharArray());
/* 2450 */     return CharOperation.toStrings(bounds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[][] getTypeParameters(char[] methodOrTypeSignature) throws IllegalArgumentException {
/*      */     try {
/* 2466 */       int length = methodOrTypeSignature.length;
/* 2467 */       if (length == 0) return CharOperation.NO_CHAR_CHAR; 
/* 2468 */       if (methodOrTypeSignature[0] != '<') return CharOperation.NO_CHAR_CHAR;
/*      */       
/* 2470 */       ArrayList<char[]> paramList = new ArrayList(1);
/* 2471 */       int paramStart = 1, i = 1;
/* 2472 */       while (i < length) {
/* 2473 */         if (methodOrTypeSignature[i] == '>') {
/* 2474 */           int size = paramList.size();
/* 2475 */           if (size == 0) throw new IllegalArgumentException(String.valueOf(methodOrTypeSignature)); 
/*      */           char[][] result;
/* 2477 */           paramList.toArray((Object[])(result = new char[size][]));
/* 2478 */           return result;
/*      */         } 
/* 2480 */         i = CharOperation.indexOf(':', methodOrTypeSignature, i);
/* 2481 */         if (i < 0 || i >= length) {
/* 2482 */           throw new IllegalArgumentException(String.valueOf(methodOrTypeSignature));
/*      */         }
/* 2484 */         while (methodOrTypeSignature[i] == ':') {
/* 2485 */           i++;
/* 2486 */           switch (methodOrTypeSignature[i]) {
/*      */             
/*      */             case 'L':
/*      */               
/*      */               try {
/*      */ 
/*      */ 
/*      */                 
/* 2494 */                 i = Util.scanClassTypeSignature(methodOrTypeSignature, i);
/* 2495 */                 i++;
/* 2496 */               } catch (IllegalArgumentException illegalArgumentException) {}
/*      */ 
/*      */ 
/*      */             
/*      */             case '[':
/*      */               try {
/* 2502 */                 i = Util.scanArrayTypeSignature(methodOrTypeSignature, i);
/* 2503 */                 i++;
/* 2504 */               } catch (IllegalArgumentException illegalArgumentException) {}
/*      */ 
/*      */ 
/*      */             
/*      */             case 'T':
/*      */               try {
/* 2510 */                 i = Util.scanTypeVariableSignature(methodOrTypeSignature, i);
/* 2511 */                 i++;
/* 2512 */               } catch (IllegalArgumentException illegalArgumentException) {}
/*      */ 
/*      */ 
/*      */             
/*      */             case '!':
/*      */               try {
/* 2518 */                 i = Util.scanCaptureTypeSignature(methodOrTypeSignature, i);
/* 2519 */                 i++;
/* 2520 */               } catch (IllegalArgumentException illegalArgumentException) {}
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         } 
/* 2527 */         paramList.add(CharOperation.subarray(methodOrTypeSignature, paramStart, i));
/* 2528 */         paramStart = i;
/*      */       } 
/* 2530 */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {}
/*      */ 
/*      */     
/* 2533 */     throw new IllegalArgumentException(String.valueOf(methodOrTypeSignature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getTypeParameters(String methodOrTypeSignature) throws IllegalArgumentException {
/* 2547 */     char[][] params = getTypeParameters(methodOrTypeSignature.toCharArray());
/* 2548 */     return CharOperation.toStrings(params);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getTypeSignatureKind(char[] typeSignature) {
/* 2564 */     if (typeSignature.length < 1) {
/* 2565 */       throw new IllegalArgumentException();
/*      */     }
/* 2567 */     char c = typeSignature[0];
/* 2568 */     if (c == '<') {
/* 2569 */       int count = 1;
/* 2570 */       for (int i = 1, length = typeSignature.length; i < length; i++) {
/* 2571 */         switch (typeSignature[i]) {
/*      */           case '<':
/* 2573 */             count++;
/*      */             break;
/*      */           case '>':
/* 2576 */             count--;
/*      */             break;
/*      */         } 
/* 2579 */         if (count == 0) {
/* 2580 */           if (i + 1 < length)
/* 2581 */             c = typeSignature[i + 1]; 
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2586 */     switch (c) {
/*      */       case '[':
/* 2588 */         return 4;
/*      */       case 'L':
/*      */       case 'Q':
/* 2591 */         return 1;
/*      */       case 'T':
/* 2593 */         return 3;
/*      */       case 'B':
/*      */       case 'C':
/*      */       case 'D':
/*      */       case 'F':
/*      */       case 'I':
/*      */       case 'J':
/*      */       case 'S':
/*      */       case 'V':
/*      */       case 'Z':
/* 2603 */         return 2;
/*      */       case '*':
/*      */       case '+':
/*      */       case '-':
/* 2607 */         return 5;
/*      */       case '!':
/* 2609 */         return 6;
/*      */       case '|':
/* 2611 */         return 7;
/*      */       case '&':
/* 2613 */         return 8;
/*      */     } 
/* 2615 */     throw new IllegalArgumentException(String.valueOf(typeSignature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getTypeSignatureKind(String typeSignature) {
/* 2632 */     return getTypeSignatureKind(typeSignature.toCharArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] getTypeVariable(char[] formalTypeParameterSignature) throws IllegalArgumentException {
/* 2645 */     int p = CharOperation.indexOf(':', formalTypeParameterSignature);
/* 2646 */     if (p < 0)
/*      */     {
/* 2648 */       throw new IllegalArgumentException(String.valueOf(formalTypeParameterSignature));
/*      */     }
/* 2650 */     return CharOperation.subarray(formalTypeParameterSignature, 0, p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getTypeVariable(String formalTypeParameterSignature) throws IllegalArgumentException {
/* 2663 */     return new String(getTypeVariable(formalTypeParameterSignature.toCharArray()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] removeCapture(char[] methodOrTypeSignature) {
/* 2687 */     return CharOperation.remove(methodOrTypeSignature, '!');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removeCapture(String methodOrTypeSignature) {
/* 2711 */     char[] array = methodOrTypeSignature.toCharArray();
/* 2712 */     char[] result = removeCapture(array);
/* 2713 */     if (array == result) return methodOrTypeSignature; 
/* 2714 */     return new String(result);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] toCharArray(char[] signature) throws IllegalArgumentException {
/* 2744 */     int sigLength = signature.length;
/* 2745 */     if (sigLength == 0) {
/* 2746 */       throw new IllegalArgumentException();
/*      */     }
/* 2748 */     if (signature[0] == '(' || signature[0] == '<') {
/* 2749 */       return toCharArray(signature, CharOperation.NO_CHAR, null, true, true);
/*      */     }
/*      */     
/* 2752 */     StringBuffer buffer = new StringBuffer(signature.length + 10);
/* 2753 */     appendTypeSignature(signature, 0, true, buffer);
/* 2754 */     char[] result = new char[buffer.length()];
/* 2755 */     buffer.getChars(0, buffer.length(), result, 0);
/* 2756 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] toCharArray(char[] methodSignature, char[] methodName, char[][] parameterNames, boolean fullyQualifyTypeNames, boolean includeReturnType) {
/* 2784 */     return toCharArray(methodSignature, methodName, parameterNames, fullyQualifyTypeNames, includeReturnType, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] toCharArray(char[] methodSignature, char[] methodName, char[][] parameterNames, boolean fullyQualifyTypeNames, boolean includeReturnType, boolean isVargArgs) {
/* 2816 */     int firstParen = CharOperation.indexOf('(', methodSignature);
/* 2817 */     if (firstParen == -1) {
/* 2818 */       throw new IllegalArgumentException(String.valueOf(methodSignature));
/*      */     }
/*      */     
/* 2821 */     StringBuffer buffer = new StringBuffer(methodSignature.length + 10);
/*      */ 
/*      */     
/* 2824 */     if (includeReturnType) {
/* 2825 */       char[] rts = getReturnType(methodSignature);
/* 2826 */       appendTypeSignature(rts, 0, fullyQualifyTypeNames, buffer);
/* 2827 */       buffer.append(' ');
/*      */     } 
/*      */ 
/*      */     
/* 2831 */     if (methodName != null) {
/* 2832 */       buffer.append(methodName);
/*      */     }
/*      */ 
/*      */     
/* 2836 */     buffer.append('(');
/* 2837 */     char[][] pts = getParameterTypes(methodSignature);
/*      */     
/* 2839 */     int max = pts.length;
/* 2840 */     int index = max - 1; int i;
/* 2841 */     for (i = index; i >= 0 && 
/* 2842 */       pts[i][0] != '['; i--)
/*      */     {
/*      */       
/* 2845 */       index--;
/*      */     }
/* 2847 */     for (i = 0; i < max; i++) {
/* 2848 */       if (i == index) {
/* 2849 */         appendTypeSignature(pts[i], 0, fullyQualifyTypeNames, buffer, isVargArgs);
/*      */       } else {
/* 2851 */         appendTypeSignature(pts[i], 0, fullyQualifyTypeNames, buffer);
/*      */       } 
/* 2853 */       if (parameterNames != null) {
/* 2854 */         buffer.append(' ');
/* 2855 */         buffer.append(parameterNames[i]);
/*      */       } 
/* 2857 */       if (i != pts.length - 1) {
/* 2858 */         buffer.append(',');
/* 2859 */         buffer.append(' ');
/*      */       } 
/*      */     } 
/* 2862 */     buffer.append(')');
/* 2863 */     char[] result = new char[buffer.length()];
/* 2864 */     buffer.getChars(0, buffer.length(), result, 0);
/* 2865 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] toQualifiedName(char[][] segments) {
/* 2886 */     int length = segments.length;
/* 2887 */     if (length == 0) return CharOperation.NO_CHAR; 
/* 2888 */     if (length == 1) return segments[0];
/*      */     
/* 2890 */     int resultLength = 0;
/* 2891 */     for (int i = 0; i < length; i++) {
/* 2892 */       resultLength += (segments[i]).length + 1;
/*      */     }
/* 2894 */     resultLength--;
/* 2895 */     char[] result = new char[resultLength];
/* 2896 */     int index = 0;
/* 2897 */     for (int j = 0; j < length; j++) {
/* 2898 */       char[] segment = segments[j];
/* 2899 */       int segmentLength = segment.length;
/* 2900 */       System.arraycopy(segment, 0, result, index, segmentLength);
/* 2901 */       index += segmentLength;
/* 2902 */       if (j != length - 1) {
/* 2903 */         result[index++] = '.';
/*      */       }
/*      */     } 
/* 2906 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toQualifiedName(String[] segments) {
/* 2925 */     int length = segments.length;
/* 2926 */     char[][] charArrays = new char[length][];
/* 2927 */     for (int i = 0; i < length; i++) {
/* 2928 */       charArrays[i] = segments[i].toCharArray();
/*      */     }
/* 2930 */     return new String(toQualifiedName(charArrays));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(String signature) throws IllegalArgumentException {
/* 2959 */     return new String(toCharArray(signature.toCharArray()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(String methodSignature, String methodName, String[] parameterNames, boolean fullyQualifyTypeNames, boolean includeReturnType) {
/* 2979 */     return toString(methodSignature, methodName, parameterNames, fullyQualifyTypeNames, includeReturnType, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(String methodSignature, String methodName, String[] parameterNames, boolean fullyQualifyTypeNames, boolean includeReturnType, boolean isVarArgs) {
/*      */     char[][] params;
/* 3004 */     if (parameterNames == null) {
/* 3005 */       params = null;
/*      */     } else {
/* 3007 */       int paramLength = parameterNames.length;
/* 3008 */       params = new char[paramLength][];
/* 3009 */       for (int i = 0; i < paramLength; i++) {
/* 3010 */         params[i] = parameterNames[i].toCharArray();
/*      */       }
/*      */     } 
/* 3013 */     return new String(toCharArray(methodSignature.toCharArray(), (methodName == null) ? null : methodName.toCharArray(), params, fullyQualifyTypeNames, includeReturnType, isVarArgs));
/*      */   }
/*      */   
/*      */   private static IllegalArgumentException newIllegalArgumentException(char[] string, int start) {
/* 3017 */     return new IllegalArgumentException("\"" + String.valueOf(string) + "\" at " + start);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\Signature.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */