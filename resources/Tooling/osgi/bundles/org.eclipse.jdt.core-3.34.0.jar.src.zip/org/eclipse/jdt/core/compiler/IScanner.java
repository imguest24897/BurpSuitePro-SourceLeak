package org.eclipse.jdt.core.compiler;

public interface IScanner {
  char[] getCurrentTokenSource();
  
  char[] getRawTokenSource();
  
  int getCurrentTokenStartPosition();
  
  int getCurrentTokenEndPosition();
  
  int getLineStart(int paramInt);
  
  int getLineEnd(int paramInt);
  
  int[] getLineEnds();
  
  int getLineNumber(int paramInt);
  
  int getNextToken() throws InvalidInputException;
  
  char[] getSource();
  
  void resetTo(int paramInt1, int paramInt2);
  
  void setSource(char[] paramArrayOfchar);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\compiler\IScanner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */