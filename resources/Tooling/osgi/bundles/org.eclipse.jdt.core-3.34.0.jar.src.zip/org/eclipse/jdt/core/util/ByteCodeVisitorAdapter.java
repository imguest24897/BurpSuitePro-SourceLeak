package org.eclipse.jdt.core.util;

public class ByteCodeVisitorAdapter implements IBytecodeVisitor {
  public void _aaload(int pc) {}
  
  public void _aastore(int pc) {}
  
  public void _aconst_null(int pc) {}
  
  public void _aload_0(int pc) {}
  
  public void _aload_1(int pc) {}
  
  public void _aload_2(int pc) {}
  
  public void _aload_3(int pc) {}
  
  public void _aload(int pc, int index) {}
  
  public void _anewarray(int pc, int index, IConstantPoolEntry constantClass) {}
  
  public void _areturn(int pc) {}
  
  public void _arraylength(int pc) {}
  
  public void _astore_0(int pc) {}
  
  public void _astore_1(int pc) {}
  
  public void _astore_2(int pc) {}
  
  public void _astore_3(int pc) {}
  
  public void _astore(int pc, int index) {}
  
  public void _athrow(int pc) {}
  
  public void _baload(int pc) {}
  
  public void _bastore(int pc) {}
  
  public void _bipush(int pc, byte _byte) {}
  
  public void _caload(int pc) {}
  
  public void _castore(int pc) {}
  
  public void _checkcast(int pc, int index, IConstantPoolEntry constantClass) {}
  
  public void _d2f(int pc) {}
  
  public void _d2i(int pc) {}
  
  public void _d2l(int pc) {}
  
  public void _dadd(int pc) {}
  
  public void _daload(int pc) {}
  
  public void _dastore(int pc) {}
  
  public void _dcmpg(int pc) {}
  
  public void _dcmpl(int pc) {}
  
  public void _dconst_0(int pc) {}
  
  public void _dconst_1(int pc) {}
  
  public void _ddiv(int pc) {}
  
  public void _dload_0(int pc) {}
  
  public void _dload_1(int pc) {}
  
  public void _dload_2(int pc) {}
  
  public void _dload_3(int pc) {}
  
  public void _dload(int pc, int index) {}
  
  public void _dmul(int pc) {}
  
  public void _dneg(int pc) {}
  
  public void _drem(int pc) {}
  
  public void _dreturn(int pc) {}
  
  public void _dstore_0(int pc) {}
  
  public void _dstore_1(int pc) {}
  
  public void _dstore_2(int pc) {}
  
  public void _dstore_3(int pc) {}
  
  public void _dstore(int pc, int index) {}
  
  public void _dsub(int pc) {}
  
  public void _dup_x1(int pc) {}
  
  public void _dup_x2(int pc) {}
  
  public void _dup(int pc) {}
  
  public void _dup2_x1(int pc) {}
  
  public void _dup2_x2(int pc) {}
  
  public void _dup2(int pc) {}
  
  public void _f2d(int pc) {}
  
  public void _f2i(int pc) {}
  
  public void _f2l(int pc) {}
  
  public void _fadd(int pc) {}
  
  public void _faload(int pc) {}
  
  public void _fastore(int pc) {}
  
  public void _fcmpg(int pc) {}
  
  public void _fcmpl(int pc) {}
  
  public void _fconst_0(int pc) {}
  
  public void _fconst_1(int pc) {}
  
  public void _fconst_2(int pc) {}
  
  public void _fdiv(int pc) {}
  
  public void _fload_0(int pc) {}
  
  public void _fload_1(int pc) {}
  
  public void _fload_2(int pc) {}
  
  public void _fload_3(int pc) {}
  
  public void _fload(int pc, int index) {}
  
  public void _fmul(int pc) {}
  
  public void _fneg(int pc) {}
  
  public void _frem(int pc) {}
  
  public void _freturn(int pc) {}
  
  public void _fstore_0(int pc) {}
  
  public void _fstore_1(int pc) {}
  
  public void _fstore_2(int pc) {}
  
  public void _fstore_3(int pc) {}
  
  public void _fstore(int pc, int index) {}
  
  public void _fsub(int pc) {}
  
  public void _getfield(int pc, int index, IConstantPoolEntry constantFieldref) {}
  
  public void _getstatic(int pc, int index, IConstantPoolEntry constantFieldref) {}
  
  public void _goto_w(int pc, int branchOffset) {}
  
  public void _goto(int pc, int branchOffset) {}
  
  public void _i2b(int pc) {}
  
  public void _i2c(int pc) {}
  
  public void _i2d(int pc) {}
  
  public void _i2f(int pc) {}
  
  public void _i2l(int pc) {}
  
  public void _i2s(int pc) {}
  
  public void _iadd(int pc) {}
  
  public void _iaload(int pc) {}
  
  public void _iand(int pc) {}
  
  public void _iastore(int pc) {}
  
  public void _iconst_0(int pc) {}
  
  public void _iconst_1(int pc) {}
  
  public void _iconst_2(int pc) {}
  
  public void _iconst_3(int pc) {}
  
  public void _iconst_4(int pc) {}
  
  public void _iconst_5(int pc) {}
  
  public void _iconst_m1(int pc) {}
  
  public void _idiv(int pc) {}
  
  public void _if_acmpeq(int pc, int branchOffset) {}
  
  public void _if_acmpne(int pc, int branchOffset) {}
  
  public void _if_icmpeq(int pc, int branchOffset) {}
  
  public void _if_icmpge(int pc, int branchOffset) {}
  
  public void _if_icmpgt(int pc, int branchOffset) {}
  
  public void _if_icmple(int pc, int branchOffset) {}
  
  public void _if_icmplt(int pc, int branchOffset) {}
  
  public void _if_icmpne(int pc, int branchOffset) {}
  
  public void _ifeq(int pc, int branchOffset) {}
  
  public void _ifge(int pc, int branchOffset) {}
  
  public void _ifgt(int pc, int branchOffset) {}
  
  public void _ifle(int pc, int branchOffset) {}
  
  public void _iflt(int pc, int branchOffset) {}
  
  public void _ifne(int pc, int branchOffset) {}
  
  public void _ifnonnull(int pc, int branchOffset) {}
  
  public void _ifnull(int pc, int branchOffset) {}
  
  public void _iinc(int pc, int index, int _const) {}
  
  public void _iload_0(int pc) {}
  
  public void _iload_1(int pc) {}
  
  public void _iload_2(int pc) {}
  
  public void _iload_3(int pc) {}
  
  public void _iload(int pc, int index) {}
  
  public void _imul(int pc) {}
  
  public void _ineg(int pc) {}
  
  public void _instanceof(int pc, int index, IConstantPoolEntry constantClass) {}
  
  public void _invokedynamic(int pc, int index, IConstantPoolEntry nameEntry, IConstantPoolEntry descriptorEntry) {}
  
  public void _invokedynamic(int pc, int index, IConstantPoolEntry invokeDynamicEntry) {}
  
  public void _invokeinterface(int pc, int index, byte nargs, IConstantPoolEntry constantInterfaceMethodref) {}
  
  public void _invokespecial(int pc, int index, IConstantPoolEntry constantMethodref) {}
  
  public void _invokestatic(int pc, int index, IConstantPoolEntry constantMethodref) {}
  
  public void _invokevirtual(int pc, int index, IConstantPoolEntry constantMethodref) {}
  
  public void _ior(int pc) {}
  
  public void _irem(int pc) {}
  
  public void _ireturn(int pc) {}
  
  public void _ishl(int pc) {}
  
  public void _ishr(int pc) {}
  
  public void _istore_0(int pc) {}
  
  public void _istore_1(int pc) {}
  
  public void _istore_2(int pc) {}
  
  public void _istore_3(int pc) {}
  
  public void _istore(int pc, int index) {}
  
  public void _isub(int pc) {}
  
  public void _iushr(int pc) {}
  
  public void _ixor(int pc) {}
  
  public void _jsr_w(int pc, int branchOffset) {}
  
  public void _jsr(int pc, int branchOffset) {}
  
  public void _l2d(int pc) {}
  
  public void _l2f(int pc) {}
  
  public void _l2i(int pc) {}
  
  public void _ladd(int pc) {}
  
  public void _laload(int pc) {}
  
  public void _land(int pc) {}
  
  public void _lastore(int pc) {}
  
  public void _lcmp(int pc) {}
  
  public void _lconst_0(int pc) {}
  
  public void _lconst_1(int pc) {}
  
  public void _ldc_w(int pc, int index, IConstantPoolEntry constantPoolEntry) {}
  
  public void _ldc(int pc, int index, IConstantPoolEntry constantPoolEntry) {}
  
  public void _ldc2_w(int pc, int index, IConstantPoolEntry constantPoolEntry) {}
  
  public void _ldiv(int pc) {}
  
  public void _lload_0(int pc) {}
  
  public void _lload_1(int pc) {}
  
  public void _lload_2(int pc) {}
  
  public void _lload_3(int pc) {}
  
  public void _lload(int pc, int index) {}
  
  public void _lmul(int pc) {}
  
  public void _lneg(int pc) {}
  
  public void _lookupswitch(int pc, int defaultoffset, int npairs, int[][] offset_pairs) {}
  
  public void _lor(int pc) {}
  
  public void _lrem(int pc) {}
  
  public void _lreturn(int pc) {}
  
  public void _lshl(int pc) {}
  
  public void _lshr(int pc) {}
  
  public void _lstore_0(int pc) {}
  
  public void _lstore_1(int pc) {}
  
  public void _lstore_2(int pc) {}
  
  public void _lstore_3(int pc) {}
  
  public void _lstore(int pc, int index) {}
  
  public void _lsub(int pc) {}
  
  public void _lushr(int pc) {}
  
  public void _lxor(int pc) {}
  
  public void _monitorenter(int pc) {}
  
  public void _monitorexit(int pc) {}
  
  public void _multianewarray(int pc, int index, int dimensions, IConstantPoolEntry constantClass) {}
  
  public void _new(int pc, int index, IConstantPoolEntry constantClass) {}
  
  public void _newarray(int pc, int atype) {}
  
  public void _nop(int pc) {}
  
  public void _pop(int pc) {}
  
  public void _pop2(int pc) {}
  
  public void _putfield(int pc, int index, IConstantPoolEntry constantFieldref) {}
  
  public void _putstatic(int pc, int index, IConstantPoolEntry constantFieldref) {}
  
  public void _ret(int pc, int index) {}
  
  public void _return(int pc) {}
  
  public void _saload(int pc) {}
  
  public void _sastore(int pc) {}
  
  public void _sipush(int pc, short value) {}
  
  public void _swap(int pc) {}
  
  public void _tableswitch(int pc, int defaultoffset, int low, int high, int[] jump_offsets) {}
  
  public void _wide(int pc, int iincopcode, int index, int _const) {}
  
  public void _wide(int pc, int opcode, int index) {}
  
  public void _breakpoint(int pc) {}
  
  public void _impdep1(int pc) {}
  
  public void _impdep2(int pc) {}
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\cor\\util\ByteCodeVisitorAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */