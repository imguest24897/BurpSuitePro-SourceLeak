/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SuperFieldAccess
/*     */   extends Expression
/*     */ {
/*  45 */   public static final ChildPropertyDescriptor QUALIFIER_PROPERTY = new ChildPropertyDescriptor(SuperFieldAccess.class, "qualifier", Name.class, false, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(SuperFieldAccess.class, "name", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  62 */     List propertyList = new ArrayList(3);
/*  63 */     createPropertyList(SuperFieldAccess.class, propertyList);
/*  64 */     addProperty(QUALIFIER_PROPERTY, propertyList);
/*  65 */     addProperty(NAME_PROPERTY, propertyList);
/*  66 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  80 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   private Name optionalQualifier = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   private SimpleName fieldName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SuperFieldAccess(AST ast) {
/* 105 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 110 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 115 */     if (property == QUALIFIER_PROPERTY) {
/* 116 */       if (get) {
/* 117 */         return getQualifier();
/*     */       }
/* 119 */       setQualifier((Name)child);
/* 120 */       return null;
/*     */     } 
/*     */     
/* 123 */     if (property == NAME_PROPERTY) {
/* 124 */       if (get) {
/* 125 */         return getName();
/*     */       }
/* 127 */       setName((SimpleName)child);
/* 128 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 132 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 137 */     return 47;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 142 */     SuperFieldAccess result = new SuperFieldAccess(target);
/* 143 */     result.setSourceRange(getStartPosition(), getLength());
/* 144 */     result.setName((SimpleName)ASTNode.copySubtree(target, getName()));
/* 145 */     result.setQualifier((Name)ASTNode.copySubtree(target, getQualifier()));
/* 146 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 152 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 157 */     boolean visitChildren = visitor.visit(this);
/* 158 */     if (visitChildren) {
/*     */       
/* 160 */       acceptChild(visitor, getQualifier());
/* 161 */       acceptChild(visitor, getName());
/*     */     } 
/* 163 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getQualifier() {
/* 173 */     return this.optionalQualifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQualifier(Name name) {
/* 188 */     ASTNode oldChild = this.optionalQualifier;
/* 189 */     preReplaceChild(oldChild, name, QUALIFIER_PROPERTY);
/* 190 */     this.optionalQualifier = name;
/* 191 */     postReplaceChild(oldChild, name, QUALIFIER_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 201 */     if (this.fieldName == null)
/*     */     {
/* 203 */       synchronized (this) {
/* 204 */         if (this.fieldName == null) {
/* 205 */           preLazyInit();
/* 206 */           this.fieldName = new SimpleName(this.ast);
/* 207 */           postLazyInit(this.fieldName, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 211 */     return this.fieldName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IVariableBinding resolveFieldBinding() {
/* 227 */     return this.ast.getBindingResolver().resolveField(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName fieldName) {
/* 242 */     if (fieldName == null) {
/* 243 */       throw new IllegalArgumentException();
/*     */     }
/* 245 */     ASTNode oldChild = this.fieldName;
/* 246 */     preReplaceChild(oldChild, fieldName, NAME_PROPERTY);
/* 247 */     this.fieldName = fieldName;
/* 248 */     postReplaceChild(oldChild, fieldName, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 254 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 259 */     return 
/* 260 */       memSize() + (
/* 261 */       (this.optionalQualifier == null) ? 0 : getQualifier().treeSize()) + (
/* 262 */       (this.fieldName == null) ? 0 : getName().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\SuperFieldAccess.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */