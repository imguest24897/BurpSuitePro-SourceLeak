/*      */ package org.eclipse.jdt.core.dom;
/*      */ 
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringWriter;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.SubMonitor;
/*      */ import org.eclipse.jdt.core.IClassFile;
/*      */ import org.eclipse.jdt.core.ICompilationUnit;
/*      */ import org.eclipse.jdt.core.IJavaElement;
/*      */ import org.eclipse.jdt.core.IJavaProject;
/*      */ import org.eclipse.jdt.core.ITypeRoot;
/*      */ import org.eclipse.jdt.core.JavaCore;
/*      */ import org.eclipse.jdt.core.JavaModelException;
/*      */ import org.eclipse.jdt.core.WorkingCopyOwner;
/*      */ import org.eclipse.jdt.core.compiler.CategorizedProblem;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.core.compiler.IProblem;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*      */ import org.eclipse.jdt.internal.compiler.ast.CompilationUnitDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ConstructorDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ExplicitConstructorCall;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Statement;
/*      */ import org.eclipse.jdt.internal.compiler.batch.FileSystem;
/*      */ import org.eclipse.jdt.internal.compiler.batch.Main;
/*      */ import org.eclipse.jdt.internal.compiler.env.IBinaryType;
/*      */ import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
/*      */ import org.eclipse.jdt.internal.compiler.parser.RecoveryScanner;
/*      */ import org.eclipse.jdt.internal.compiler.parser.RecoveryScannerData;
/*      */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*      */ import org.eclipse.jdt.internal.compiler.util.SuffixConstants;
/*      */ import org.eclipse.jdt.internal.compiler.util.Util;
/*      */ import org.eclipse.jdt.internal.core.BasicCompilationUnit;
/*      */ import org.eclipse.jdt.internal.core.BinaryType;
/*      */ import org.eclipse.jdt.internal.core.ClassFileWorkingCopy;
/*      */ import org.eclipse.jdt.internal.core.DefaultWorkingCopyOwner;
/*      */ import org.eclipse.jdt.internal.core.PackageFragment;
/*      */ import org.eclipse.jdt.internal.core.dom.util.DOMASTUtil;
/*      */ import org.eclipse.jdt.internal.core.util.CodeSnippetParsingUtil;
/*      */ import org.eclipse.jdt.internal.core.util.RecordedParsingInformation;
/*      */ import org.eclipse.jdt.internal.core.util.Util;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ASTParser
/*      */ {
/*      */   public static final int K_EXPRESSION = 1;
/*      */   public static final int K_STATEMENTS = 2;
/*      */   public static final int K_CLASS_BODY_DECLARATIONS = 4;
/*      */   public static final int K_COMPILATION_UNIT = 8;
/*      */   private final int apiLevel;
/*      */   private int astKind;
/*      */   private Map<String, String> compilerOptions;
/*      */   private int focalPointPosition;
/*      */   
/*      */   public static ASTParser newParser(int level) {
/*  139 */     return new ASTParser(level);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  166 */   private char[] rawSource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  171 */   private ITypeRoot typeRoot = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  177 */   private int sourceOffset = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  185 */   private int sourceLength = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  190 */   private WorkingCopyOwner workingCopyOwner = (WorkingCopyOwner)DefaultWorkingCopyOwner.PRIMARY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  196 */   private IJavaProject project = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  202 */   private String unitName = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] classpaths;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] sourcepaths;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] sourcepathsEncodings;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int bits;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ASTParser(int level) {
/*  234 */     DOMASTUtil.checkASTLevel(level);
/*  235 */     this.apiLevel = level;
/*  236 */     initializeDefaults();
/*      */   }
/*      */   
/*      */   private List<FileSystem.Classpath> getClasspath() throws IllegalStateException {
/*  240 */     Main main = new Main(new PrintWriter(System.out), new PrintWriter(System.err), false, null, null);
/*  241 */     ArrayList<FileSystem.Classpath> allClasspaths = new ArrayList<>();
/*      */     try {
/*  243 */       if ((this.bits & 0x20) != 0) {
/*  244 */         Util.collectRunningVMBootclasspath(allClasspaths);
/*      */       }
/*  246 */       if (this.sourcepaths != null) {
/*  247 */         for (int i = 0, max = this.sourcepaths.length; i < max; i++) {
/*  248 */           String encoding = (this.sourcepathsEncodings == null) ? null : this.sourcepathsEncodings[i];
/*  249 */           main.processPathEntries(
/*  250 */               4, 
/*  251 */               allClasspaths, this.sourcepaths[i], encoding, true, false);
/*      */         } 
/*      */       }
/*  254 */       if (this.classpaths != null) {
/*  255 */         for (int i = 0, max = this.classpaths.length; i < max; i++) {
/*  256 */           main.processPathEntries(
/*  257 */               4, 
/*  258 */               allClasspaths, this.classpaths[i], null, false, false);
/*      */         }
/*      */       }
/*  261 */       ArrayList pendingErrors = main.pendingErrors;
/*  262 */       if (pendingErrors != null && pendingErrors.size() != 0) {
/*  263 */         throw new IllegalStateException("invalid environment settings");
/*      */       }
/*  265 */     } catch (IllegalArgumentException e) {
/*  266 */       throw new IllegalStateException("invalid environment settings", e);
/*      */     } 
/*  268 */     return allClasspaths;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeDefaults() {
/*  274 */     this.astKind = 8;
/*  275 */     this.rawSource = null;
/*  276 */     this.typeRoot = null;
/*  277 */     this.bits = 0;
/*  278 */     this.sourceLength = -1;
/*  279 */     this.sourceOffset = 0;
/*  280 */     this.workingCopyOwner = (WorkingCopyOwner)DefaultWorkingCopyOwner.PRIMARY;
/*  281 */     this.unitName = null;
/*  282 */     this.project = null;
/*  283 */     this.classpaths = null;
/*  284 */     this.sourcepaths = null;
/*  285 */     this.sourcepathsEncodings = null;
/*  286 */     Map<String, String> options = JavaCore.getOptions();
/*  287 */     options.remove("org.eclipse.jdt.core.compiler.taskTags");
/*  288 */     this.compilerOptions = options;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBindingsRecovery(boolean enabled) {
/*  307 */     if (enabled) {
/*  308 */       this.bits |= 0x10;
/*      */     } else {
/*  310 */       this.bits &= 0xFFFFFFEF;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnvironment(String[] classpathEntries, String[] sourcepathEntries, String[] encodings, boolean includeRunningVMBootclasspath) {
/*  337 */     this.classpaths = classpathEntries;
/*  338 */     this.sourcepaths = sourcepathEntries;
/*  339 */     this.sourcepathsEncodings = encodings;
/*  340 */     if (encodings != null && (
/*  341 */       sourcepathEntries == null || sourcepathEntries.length != encodings.length)) {
/*  342 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/*  345 */     if (includeRunningVMBootclasspath) {
/*  346 */       this.bits |= 0x20;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCompilerOptions(Map<String, String> options) {
/*  375 */     if (options == null) {
/*  376 */       options = JavaCore.getOptions();
/*      */     } else {
/*      */       
/*  379 */       options = new HashMap<>(options);
/*      */     } 
/*  381 */     options.remove("org.eclipse.jdt.core.compiler.taskTags");
/*  382 */     this.compilerOptions = options;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResolveBindings(boolean enabled) {
/*  437 */     if (enabled) {
/*  438 */       this.bits |= 0x1;
/*      */     } else {
/*  440 */       this.bits &= 0xFFFFFFFE;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFocalPosition(int position) {
/*  485 */     this.bits |= 0x2;
/*  486 */     this.focalPointPosition = position;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKind(int kind) {
/*  568 */     if (kind != 8 && 
/*  569 */       kind != 4 && 
/*  570 */       kind != 1 && 
/*  571 */       kind != 2) {
/*  572 */       throw new IllegalArgumentException();
/*      */     }
/*  574 */     this.astKind = kind;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSource(char[] source) {
/*  594 */     this.rawSource = source;
/*      */     
/*  596 */     this.typeRoot = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSource(ICompilationUnit source) {
/*  613 */     setSource((ITypeRoot)source);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSource(IClassFile source) {
/*  632 */     setSource((ITypeRoot)source);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSource(ITypeRoot source) {
/*  652 */     this.typeRoot = source;
/*      */     
/*  654 */     this.rawSource = null;
/*  655 */     if (source != null) {
/*  656 */       this.project = source.getJavaProject();
/*  657 */       Map<String, String> options = this.project.getOptions(true);
/*  658 */       options.remove("org.eclipse.jdt.core.compiler.taskTags");
/*  659 */       this.compilerOptions = options;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSource(ITypeRoot source, int astLevel) {
/*  692 */     this.typeRoot = source;
/*      */     
/*  694 */     this.rawSource = null;
/*  695 */     if (source != null) {
/*  696 */       this.project = source.getJavaProject();
/*  697 */       Map<String, String> options = this.project.getOptions(true);
/*  698 */       options.remove("org.eclipse.jdt.core.compiler.taskTags");
/*  699 */       this.compilerOptions = options;
/*  700 */       String compliance = DOMASTUtil.getCompliance(astLevel);
/*  701 */       this.compilerOptions.put("org.eclipse.jdt.core.compiler.compliance", compliance);
/*  702 */       this.compilerOptions.put("org.eclipse.jdt.core.compiler.source", compliance);
/*  703 */       this.compilerOptions.put("org.eclipse.jdt.core.compiler.codegen.targetPlatform", compliance);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSourceRange(int offset, int length) {
/*  720 */     if (offset < 0 || length < -1) {
/*  721 */       throw new IllegalArgumentException();
/*      */     }
/*  723 */     this.sourceOffset = offset;
/*  724 */     this.sourceLength = length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStatementsRecovery(boolean enabled) {
/*  741 */     if (enabled) {
/*  742 */       this.bits |= 0x4;
/*      */     } else {
/*  744 */       this.bits &= 0xFFFFFFFB;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIgnoreMethodBodies(boolean enabled) {
/*  759 */     if (enabled) {
/*  760 */       this.bits |= 0x8;
/*      */     } else {
/*  762 */       this.bits &= 0xFFFFFFF7;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWorkingCopyOwner(WorkingCopyOwner owner) {
/*  774 */     if (owner == null) {
/*  775 */       this.workingCopyOwner = (WorkingCopyOwner)DefaultWorkingCopyOwner.PRIMARY;
/*      */     } else {
/*  777 */       this.workingCopyOwner = owner;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnitName(String unitName) {
/*  811 */     this.unitName = unitName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProject(IJavaProject project) {
/*  835 */     this.project = project;
/*  836 */     if (project != null) {
/*  837 */       Map<String, String> options = project.getOptions(true);
/*  838 */       options.remove("org.eclipse.jdt.core.compiler.taskTags");
/*  839 */       this.compilerOptions = options;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ASTNode createAST(IProgressMonitor monitor) {
/*  862 */     SubMonitor subMonitor = SubMonitor.convert(monitor, 1);
/*  863 */     ASTNode result = null;
/*      */     try {
/*  865 */       if (this.rawSource == null && this.typeRoot == null) {
/*  866 */         throw new IllegalStateException("source not specified");
/*      */       }
/*  868 */       result = internalCreateAST((IProgressMonitor)subMonitor.split(1));
/*      */     } finally {
/*      */       
/*  871 */       initializeDefaults();
/*      */     } 
/*  873 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void createASTs(ICompilationUnit[] compilationUnits, String[] bindingKeys, ASTRequestor requestor, IProgressMonitor monitor) {
/*      */     try {
/*  941 */       int flags = 0;
/*  942 */       if ((this.bits & 0x4) != 0) {
/*  943 */         flags |= 0x2;
/*      */       }
/*  945 */       if ((this.bits & 0x8) != 0) {
/*  946 */         flags |= 0x8;
/*      */       }
/*  948 */       if ((this.bits & 0x1) != 0) {
/*  949 */         if (this.project == null)
/*  950 */           throw new IllegalStateException("project not specified"); 
/*  951 */         if ((this.bits & 0x10) != 0) {
/*  952 */           flags |= 0x4;
/*      */         }
/*  954 */         CompilationUnitResolver.resolve(compilationUnits, bindingKeys, requestor, this.apiLevel, this.compilerOptions, this.project, this.workingCopyOwner, flags, monitor);
/*      */       } else {
/*  956 */         CompilationUnitResolver.parse(compilationUnits, requestor, this.apiLevel, this.compilerOptions, flags, monitor);
/*      */       } 
/*      */     } finally {
/*      */       
/*  960 */       initializeDefaults();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void createASTs(String[] sourceFilePaths, String[] encodings, String[] bindingKeys, FileASTRequestor requestor, IProgressMonitor monitor) {
/*      */     try {
/* 1035 */       int flags = 0;
/* 1036 */       if ((this.bits & 0x4) != 0) {
/* 1037 */         flags |= 0x2;
/*      */       }
/* 1039 */       if ((this.bits & 0x8) != 0) {
/* 1040 */         flags |= 0x8;
/*      */       }
/* 1042 */       if ((this.bits & 0x1) != 0) {
/* 1043 */         if (this.classpaths == null && this.sourcepaths == null && (this.bits & 0x20) == 0) {
/* 1044 */           throw new IllegalStateException("no environment is specified");
/*      */         }
/* 1046 */         if ((this.bits & 0x10) != 0) {
/* 1047 */           flags |= 0x4;
/*      */         }
/* 1049 */         CompilationUnitResolver.resolve(sourceFilePaths, encodings, bindingKeys, requestor, this.apiLevel, this.compilerOptions, getClasspath(), flags, monitor);
/*      */       } else {
/* 1051 */         CompilationUnitResolver.parse(sourceFilePaths, encodings, requestor, this.apiLevel, this.compilerOptions, flags, monitor);
/*      */       } 
/*      */     } finally {
/*      */       
/* 1055 */       initializeDefaults();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IBinding[] createBindings(IJavaElement[] elements, IProgressMonitor monitor) {
/*      */     try {
/* 1100 */       if (this.project == null)
/* 1101 */         throw new IllegalStateException("project or classpath not specified"); 
/* 1102 */       int flags = 0;
/* 1103 */       if ((this.bits & 0x4) != 0) {
/* 1104 */         flags |= 0x2;
/*      */       }
/* 1106 */       if ((this.bits & 0x10) != 0) {
/* 1107 */         flags |= 0x4;
/*      */       }
/* 1109 */       if ((this.bits & 0x8) != 0) {
/* 1110 */         flags |= 0x8;
/*      */       }
/* 1112 */       return CompilationUnitResolver.resolve(elements, this.apiLevel, this.compilerOptions, this.project, this.workingCopyOwner, flags, monitor);
/*      */     } finally {
/*      */       
/* 1115 */       initializeDefaults();
/*      */     } 
/*      */   }
/*      */   private ASTNode internalCreateAST(IProgressMonitor monitor) {
/*      */     CompilationUnitDeclaration compilationUnitDeclaration;
/* 1120 */     boolean needToResolveBindings = ((this.bits & 0x1) != 0);
/* 1121 */     switch (this.astKind) {
/*      */       case 1:
/*      */       case 2:
/*      */       case 4:
/* 1125 */         if (this.rawSource == null && 
/* 1126 */           this.typeRoot != null)
/*      */         {
/* 1128 */           if (this.typeRoot instanceof ICompilationUnit) {
/* 1129 */             ICompilationUnit sourceUnit = (ICompilationUnit)this.typeRoot;
/* 1130 */             this.rawSource = sourceUnit.getContents();
/* 1131 */           } else if (this.typeRoot instanceof IClassFile) {
/*      */             try {
/* 1133 */               String sourceString = this.typeRoot.getSource();
/* 1134 */               if (sourceString != null) {
/* 1135 */                 this.rawSource = sourceString.toCharArray();
/*      */               }
/* 1137 */             } catch (JavaModelException e) {
/*      */               
/* 1139 */               StringWriter stringWriter = new StringWriter();
/* 1140 */               Exception exception1 = null, exception2 = null;
/*      */             } 
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1148 */         if (this.rawSource != null) {
/* 1149 */           if (this.sourceOffset + this.sourceLength > this.rawSource.length) {
/* 1150 */             throw new IllegalStateException();
/*      */           }
/* 1152 */           return internalCreateASTForKind();
/*      */         } 
/*      */         break;
/*      */       case 8:
/* 1156 */         compilationUnitDeclaration = null; try {
/*      */           BasicCompilationUnit basicCompilationUnit;
/* 1158 */           NodeSearcher searcher = null;
/* 1159 */           ICompilationUnit sourceUnit = null;
/* 1160 */           WorkingCopyOwner wcOwner = this.workingCopyOwner;
/* 1161 */           if (this.typeRoot instanceof ClassFileWorkingCopy)
/*      */           {
/* 1163 */             this.typeRoot = (ITypeRoot)((ClassFileWorkingCopy)this.typeRoot).classFile;
/*      */           }
/* 1165 */           if (this.typeRoot instanceof ICompilationUnit) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1170 */             sourceUnit = (ICompilationUnit)this.typeRoot;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1176 */             basicCompilationUnit = new BasicCompilationUnit(sourceUnit.getContents(), sourceUnit.getPackageName(), new String(sourceUnit.getFileName()), (IJavaElement)this.project);
/* 1177 */             wcOwner = ((ICompilationUnit)this.typeRoot).getOwner();
/* 1178 */           } else if (this.typeRoot instanceof IClassFile) {
/*      */             try {
/* 1180 */               String sourceString = this.typeRoot.getSource();
/* 1181 */               if (sourceString == null) {
/* 1182 */                 throw new IllegalStateException();
/*      */               }
/* 1184 */               PackageFragment packageFragment = (PackageFragment)this.typeRoot.getParent();
/* 1185 */               BinaryType type = (BinaryType)this.typeRoot.findPrimaryType();
/* 1186 */               String fileNameString = null;
/* 1187 */               if (type != null) {
/* 1188 */                 IBinaryType binaryType = (IBinaryType)type.getElementInfo();
/*      */                 
/* 1190 */                 char[] fileName = binaryType.getFileName();
/*      */                 
/* 1192 */                 int firstDollar = CharOperation.indexOf('$', fileName);
/* 1193 */                 if (firstDollar != -1) {
/* 1194 */                   char[] suffix = SuffixConstants.SUFFIX_class;
/* 1195 */                   int suffixLength = suffix.length;
/* 1196 */                   char[] newFileName = new char[firstDollar + suffixLength];
/* 1197 */                   System.arraycopy(fileName, 0, newFileName, 0, firstDollar);
/* 1198 */                   System.arraycopy(suffix, 0, newFileName, firstDollar, suffixLength);
/* 1199 */                   fileName = newFileName;
/*      */                 } 
/* 1201 */                 fileNameString = new String(fileName);
/*      */               } else {
/*      */                 
/* 1204 */                 fileNameString = this.typeRoot.getElementName();
/*      */               } 
/* 1206 */               basicCompilationUnit = new BasicCompilationUnit(sourceString.toCharArray(), Util.toCharArrays(packageFragment.names), fileNameString, (IJavaElement)this.typeRoot);
/* 1207 */             } catch (JavaModelException e) {
/*      */               
/* 1209 */               StringWriter stringWriter = new StringWriter();
/* 1210 */               Exception exception1 = null, exception2 = null;
/*      */             
/*      */             }
/*      */           
/*      */           }
/* 1215 */           else if (this.rawSource != null) {
/* 1216 */             needToResolveBindings = 
/* 1217 */               ((this.bits & 0x1) != 0 && 
/* 1218 */               this.unitName != null && (
/* 1219 */               this.project != null || 
/* 1220 */               this.classpaths != null || 
/* 1221 */               this.sourcepaths != null || (
/* 1222 */               this.bits & 0x20) != 0) && 
/* 1223 */               this.compilerOptions != null);
/* 1224 */             basicCompilationUnit = new BasicCompilationUnit(this.rawSource, null, (this.unitName == null) ? "" : this.unitName, (IJavaElement)this.project);
/*      */           } else {
/* 1226 */             throw new IllegalStateException();
/*      */           } 
/* 1228 */           if ((this.bits & 0x2) != 0) {
/* 1229 */             searcher = new NodeSearcher(this.focalPointPosition);
/*      */           }
/* 1231 */           int flags = 0;
/* 1232 */           if ((this.bits & 0x4) != 0) {
/* 1233 */             flags |= 0x2;
/*      */           }
/* 1235 */           if (searcher == null && (this.bits & 0x8) != 0) {
/* 1236 */             flags |= 0x8;
/*      */           }
/* 1238 */           if (needToResolveBindings) {
/* 1239 */             if ((this.bits & 0x10) != 0) {
/* 1240 */               flags |= 0x4;
/*      */             }
/*      */             
/*      */             try {
/* 1244 */               compilationUnitDeclaration = 
/* 1245 */                 CompilationUnitResolver.resolve(
/* 1246 */                   (ICompilationUnit)basicCompilationUnit, 
/* 1247 */                   this.project, 
/* 1248 */                   getClasspath(), 
/* 1249 */                   searcher, 
/* 1250 */                   this.compilerOptions, 
/* 1251 */                   this.workingCopyOwner, 
/* 1252 */                   flags, 
/* 1253 */                   monitor);
/* 1254 */             } catch (JavaModelException javaModelException) {
/* 1255 */               flags &= 0xFFFFFFFB;
/* 1256 */               compilationUnitDeclaration = CompilationUnitResolver.parse(
/* 1257 */                   (ICompilationUnit)basicCompilationUnit, 
/* 1258 */                   searcher, 
/* 1259 */                   this.compilerOptions, 
/* 1260 */                   flags);
/* 1261 */               needToResolveBindings = false;
/*      */             } 
/*      */           } else {
/* 1264 */             compilationUnitDeclaration = CompilationUnitResolver.parse(
/* 1265 */                 (ICompilationUnit)basicCompilationUnit, 
/* 1266 */                 searcher, 
/* 1267 */                 this.compilerOptions, 
/* 1268 */                 flags, 
/* 1269 */                 this.project);
/* 1270 */             needToResolveBindings = false;
/*      */           } 
/* 1272 */           CompilationUnit result = CompilationUnitResolver.convert(
/* 1273 */               compilationUnitDeclaration, 
/* 1274 */               basicCompilationUnit.getContents(), 
/* 1275 */               this.apiLevel, 
/* 1276 */               this.compilerOptions, 
/* 1277 */               needToResolveBindings, 
/* 1278 */               wcOwner, 
/* 1279 */               needToResolveBindings ? new DefaultBindingResolver.BindingTables() : null, 
/* 1280 */               flags, 
/* 1281 */               monitor, 
/* 1282 */               (this.project != null), 
/* 1283 */               this.project);
/* 1284 */           result.setTypeRoot(this.typeRoot);
/* 1285 */           return result;
/*      */         } finally {
/* 1287 */           if (compilationUnitDeclaration != null && (
/* 1288 */             this.bits & 0x1) != 0) {
/* 1289 */             compilationUnitDeclaration.cleanUp();
/*      */           }
/*      */         } 
/*      */     } 
/* 1293 */     throw new IllegalStateException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ASTNode internalCreateASTForKind() {
/*      */     ConstructorDeclaration constructorDeclaration;
/*      */     RecoveryScannerData data;
/*      */     RecordedParsingInformation recordedParsingInformation;
/*      */     int[][] comments;
/*      */     Block block;
/*      */     ExplicitConstructorCall constructorCall;
/*      */     Statement[] statements;
/*      */     Expression expression;
/*      */     CategorizedProblem[] problems;
/*      */     ASTNode[] nodes;
/*      */     CategorizedProblem[] arrayOfCategorizedProblem1;
/* 1368 */     ASTConverter converter = new ASTConverter(this.compilerOptions, false, null);
/* 1369 */     converter.compilationUnitSource = this.rawSource;
/* 1370 */     converter.compilationUnitSourceLength = this.rawSource.length;
/* 1371 */     converter.scanner.setSource(this.rawSource);
/*      */     
/* 1373 */     AST ast = AST.newAST(this.apiLevel, "enabled".equals(this.compilerOptions.get("org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures")));
/* 1374 */     ast.setDefaultNodeFlag(2);
/* 1375 */     ast.setBindingResolver(new BindingResolver());
/* 1376 */     if ((this.bits & 0x4) != 0) {
/* 1377 */       ast.setFlag(2);
/*      */     }
/* 1379 */     ast.scanner.previewEnabled = "enabled".equals(this.compilerOptions.get("org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures"));
/* 1380 */     converter.setAST(ast);
/* 1381 */     CodeSnippetParsingUtil codeSnippetParsingUtil = new CodeSnippetParsingUtil(((this.bits & 0x8) != 0));
/* 1382 */     CompilationUnit compilationUnit = ast.newCompilationUnit();
/* 1383 */     if (this.sourceLength == -1) {
/* 1384 */       this.sourceLength = this.rawSource.length;
/*      */     }
/* 1386 */     switch (this.astKind) {
/*      */       case 2:
/* 1388 */         constructorDeclaration = codeSnippetParsingUtil.parseStatements(
/* 1389 */             this.rawSource, 
/* 1390 */             this.sourceOffset, 
/* 1391 */             this.sourceLength, 
/* 1392 */             this.compilerOptions, 
/* 1393 */             true, 
/* 1394 */             ((this.bits & 0x4) != 0));
/* 1395 */         data = constructorDeclaration.compilationResult.recoveryScannerData;
/* 1396 */         if (data != null) {
/* 1397 */           Scanner scanner = converter.scanner;
/* 1398 */           converter.scanner = (Scanner)new RecoveryScanner(scanner, data.removeUnused());
/* 1399 */           converter.docParser.scanner = converter.scanner;
/* 1400 */           converter.scanner.setSource(scanner.source);
/*      */           
/* 1402 */           compilationUnit.setStatementsRecoveryData(data);
/*      */         } 
/* 1404 */         recordedParsingInformation = codeSnippetParsingUtil.recordedParsingInformation;
/* 1405 */         comments = recordedParsingInformation.commentPositions;
/* 1406 */         if (comments != null) {
/* 1407 */           converter.buildCommentsTable(compilationUnit, comments);
/*      */         }
/* 1409 */         compilationUnit.setLineEndTable(recordedParsingInformation.lineEnds);
/* 1410 */         block = ast.newBlock();
/* 1411 */         block.setSourceRange(this.sourceOffset, this.sourceOffset + this.sourceLength);
/* 1412 */         constructorCall = constructorDeclaration.constructorCall;
/* 1413 */         if (constructorCall != null && constructorCall.accessMode != 1) {
/* 1414 */           block.statements().add(converter.convert(constructorCall));
/*      */         }
/* 1416 */         statements = constructorDeclaration.statements;
/* 1417 */         if (statements != null) {
/* 1418 */           int statementsLength = statements.length;
/* 1419 */           for (int i = 0; i < statementsLength; i++) {
/* 1420 */             if (statements[i] instanceof org.eclipse.jdt.internal.compiler.ast.LocalDeclaration) {
/* 1421 */               converter.checkAndAddMultipleLocalDeclaration(statements, i, block.statements());
/*      */             } else {
/* 1423 */               Statement statement = converter.convert(statements[i]);
/* 1424 */               if (statement != null) {
/* 1425 */                 block.statements().add(statement);
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/* 1430 */         rootNodeToCompilationUnit(ast, compilationUnit, block, recordedParsingInformation, data);
/* 1431 */         ast.setDefaultNodeFlag(0);
/* 1432 */         ast.setOriginalModificationCount(ast.modificationCount());
/* 1433 */         return block;
/*      */       case 1:
/* 1435 */         expression = codeSnippetParsingUtil.parseExpression(this.rawSource, this.sourceOffset, this.sourceLength, this.compilerOptions, true);
/* 1436 */         recordedParsingInformation = codeSnippetParsingUtil.recordedParsingInformation;
/* 1437 */         comments = recordedParsingInformation.commentPositions;
/* 1438 */         if (comments != null) {
/* 1439 */           converter.buildCommentsTable(compilationUnit, comments);
/*      */         }
/* 1441 */         compilationUnit.setLineEndTable(recordedParsingInformation.lineEnds);
/* 1442 */         if (expression != null) {
/* 1443 */           Expression expression2 = converter.convert(expression);
/* 1444 */           rootNodeToCompilationUnit(expression2.getAST(), compilationUnit, expression2, codeSnippetParsingUtil.recordedParsingInformation, null);
/* 1445 */           ast.setDefaultNodeFlag(0);
/* 1446 */           ast.setOriginalModificationCount(ast.modificationCount());
/* 1447 */           return expression2;
/*      */         } 
/* 1449 */         problems = recordedParsingInformation.problems;
/* 1450 */         if (problems != null) {
/* 1451 */           compilationUnit.setProblems((IProblem[])problems);
/*      */         }
/* 1453 */         ast.setDefaultNodeFlag(0);
/* 1454 */         ast.setOriginalModificationCount(ast.modificationCount());
/* 1455 */         return compilationUnit;
/*      */       
/*      */       case 4:
/* 1458 */         nodes = 
/* 1459 */           codeSnippetParsingUtil.parseClassBodyDeclarations(
/* 1460 */             this.rawSource, 
/* 1461 */             this.sourceOffset, 
/* 1462 */             this.sourceLength, 
/* 1463 */             this.compilerOptions, 
/* 1464 */             true, 
/* 1465 */             ((this.bits & 0x4) != 0));
/* 1466 */         recordedParsingInformation = codeSnippetParsingUtil.recordedParsingInformation;
/* 1467 */         comments = recordedParsingInformation.commentPositions;
/* 1468 */         if (comments != null) {
/* 1469 */           converter.buildCommentsTable(compilationUnit, comments);
/*      */         }
/* 1471 */         compilationUnit.setLineEndTable(recordedParsingInformation.lineEnds);
/* 1472 */         if (nodes != null) {
/*      */           
/* 1474 */           TypeDeclaration typeDeclaration = converter.convert(nodes);
/* 1475 */           typeDeclaration.setSourceRange(this.sourceOffset, this.sourceOffset + this.sourceLength);
/* 1476 */           rootNodeToCompilationUnit(typeDeclaration.getAST(), compilationUnit, typeDeclaration, codeSnippetParsingUtil.recordedParsingInformation, null);
/* 1477 */           ast.setDefaultNodeFlag(0);
/* 1478 */           ast.setOriginalModificationCount(ast.modificationCount());
/* 1479 */           return typeDeclaration;
/*      */         } 
/*      */         
/* 1482 */         arrayOfCategorizedProblem1 = recordedParsingInformation.problems;
/* 1483 */         if (arrayOfCategorizedProblem1 != null) {
/* 1484 */           compilationUnit.setProblems((IProblem[])arrayOfCategorizedProblem1);
/*      */         }
/* 1486 */         ast.setDefaultNodeFlag(0);
/* 1487 */         ast.setOriginalModificationCount(ast.modificationCount());
/* 1488 */         return compilationUnit;
/*      */     } 
/*      */     
/* 1491 */     throw new IllegalStateException();
/*      */   }
/*      */   
/*      */   private void propagateErrors(ASTNode astNode, CategorizedProblem[] problems, RecoveryScannerData data) {
/* 1495 */     astNode.accept(new ASTSyntaxErrorPropagator(problems));
/* 1496 */     if (data != null)
/* 1497 */       astNode.accept(new ASTRecoveryPropagator(problems, data)); 
/*      */   } private void rootNodeToCompilationUnit(AST ast, CompilationUnit compilationUnit, ASTNode node, RecordedParsingInformation recordedParsingInformation, RecoveryScannerData data) {
/*      */     Block block;
/*      */     TypeDeclaration typeDeclaration, typeDeclaration1;
/*      */     Initializer initializer;
/* 1502 */     int problemsCount = recordedParsingInformation.problemsCount;
/* 1503 */     switch (node.getNodeType()) {
/*      */       
/*      */       case 8:
/* 1506 */         block = (Block)node;
/* 1507 */         if (problemsCount != 0) {
/*      */           
/* 1509 */           CategorizedProblem[] problems = recordedParsingInformation.problems;
/* 1510 */           propagateErrors(block, problems, data);
/* 1511 */           compilationUnit.setProblems((IProblem[])problems);
/*      */         } 
/* 1513 */         typeDeclaration1 = ast.newTypeDeclaration();
/* 1514 */         initializer = ast.newInitializer();
/* 1515 */         initializer.setBody(block);
/* 1516 */         typeDeclaration1.bodyDeclarations().add(initializer);
/* 1517 */         compilationUnit.types().add(typeDeclaration1);
/*      */         return;
/*      */ 
/*      */       
/*      */       case 55:
/* 1522 */         typeDeclaration = (TypeDeclaration)node;
/* 1523 */         if (problemsCount != 0) {
/*      */           
/* 1525 */           CategorizedProblem[] problems = recordedParsingInformation.problems;
/* 1526 */           propagateErrors(typeDeclaration, problems, data);
/* 1527 */           compilationUnit.setProblems((IProblem[])problems);
/*      */         } 
/* 1529 */         compilationUnit.types().add(typeDeclaration);
/*      */         return;
/*      */     } 
/*      */     
/* 1533 */     if (node instanceof Expression) {
/* 1534 */       Expression expression = (Expression)node;
/* 1535 */       if (problemsCount != 0) {
/*      */         
/* 1537 */         CategorizedProblem[] problems = recordedParsingInformation.problems;
/* 1538 */         propagateErrors(expression, problems, data);
/* 1539 */         compilationUnit.setProblems((IProblem[])problems);
/*      */       } 
/* 1541 */       ExpressionStatement expressionStatement = ast.newExpressionStatement(expression);
/* 1542 */       Block block1 = ast.newBlock();
/* 1543 */       block1.statements().add(expressionStatement);
/* 1544 */       Initializer initializer1 = ast.newInitializer();
/* 1545 */       initializer1.setBody(block1);
/* 1546 */       TypeDeclaration typeDeclaration2 = ast.newTypeDeclaration();
/* 1547 */       typeDeclaration2.bodyDeclarations().add(initializer1);
/* 1548 */       compilationUnit.types().add(typeDeclaration2);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ASTParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */