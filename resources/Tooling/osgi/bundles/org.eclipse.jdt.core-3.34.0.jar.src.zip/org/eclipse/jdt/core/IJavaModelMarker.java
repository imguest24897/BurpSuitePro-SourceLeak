package org.eclipse.jdt.core;

public interface IJavaModelMarker {
  public static final String JAVA_MODEL_PROBLEM_MARKER = "org.eclipse.jdt.core.problem";
  
  public static final String TRANSIENT_PROBLEM = "org.eclipse.jdt.core.transient_problem";
  
  public static final String TASK_MARKER = "org.eclipse.jdt.core.task";
  
  public static final String ARGUMENTS = "arguments";
  
  public static final String ID = "id";
  
  public static final String CATEGORY_ID = "categoryId";
  
  public static final String FLAGS = "flags";
  
  public static final String CYCLE_DETECTED = "cycleDetected";
  
  public static final String BUILDPATH_PROBLEM_MARKER = "org.eclipse.jdt.core.buildpath_problem";
  
  public static final String CLASSPATH_FILE_FORMAT = "classpathFileFormat";
  
  public static final String OUTPUT_OVERLAPPING_SOURCE = "outputOverlappingSource";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IJavaModelMarker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */