/*      */ package org.eclipse.jdt.internal.codeassist.complete;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*      */ import org.eclipse.jdt.internal.codeassist.impl.AssistParser;
/*      */ import org.eclipse.jdt.internal.codeassist.impl.Keywords;
/*      */ import org.eclipse.jdt.internal.codeassist.impl.RestrictedIdentifiers;
/*      */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*      */ import org.eclipse.jdt.internal.compiler.ast.AND_AND_Expression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*      */ import org.eclipse.jdt.internal.compiler.ast.AbstractMethodDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.AbstractVariableDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.AllocationExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Annotation;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Argument;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ArrayAllocationExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ArrayInitializer;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ArrayReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.AssertStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Assignment;
/*      */ import org.eclipse.jdt.internal.compiler.ast.BinaryExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Block;
/*      */ import org.eclipse.jdt.internal.compiler.ast.CaseStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.CastExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.CompilationUnitDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.CompoundAssignment;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ConstructorDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.EmptyStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.EqualExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ExplicitConstructorCall;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.FieldDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ForStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.IfStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ImportReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Initializer;
/*      */ import org.eclipse.jdt.internal.compiler.ast.InstanceOfExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.IntLiteral;
/*      */ import org.eclipse.jdt.internal.compiler.ast.IntersectionCastTypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.LocalDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.MarkerAnnotation;
/*      */ import org.eclipse.jdt.internal.compiler.ast.MemberValuePair;
/*      */ import org.eclipse.jdt.internal.compiler.ast.MessageSend;
/*      */ import org.eclipse.jdt.internal.compiler.ast.MethodDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ModuleDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ModuleReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.NameReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.NormalAnnotation;
/*      */ import org.eclipse.jdt.internal.compiler.ast.OR_OR_Expression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ParameterizedQualifiedTypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ParameterizedSingleTypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.PrefixExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.QualifiedAllocationExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.QualifiedNameReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.RecordComponent;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ReferenceExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ReturnStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.SingleNameReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.SingleTypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Statement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.StringLiteral;
/*      */ import org.eclipse.jdt.internal.compiler.ast.SuperReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.SwitchExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.SwitchStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.SynchronizedStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ThisReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ThrowStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TrueLiteral;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TryStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeParameter;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.UnaryExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.UnionTypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.WhileStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Wildcard;
/*      */ import org.eclipse.jdt.internal.compiler.env.ICompilationUnit;
/*      */ import org.eclipse.jdt.internal.compiler.impl.JavaFeature;
/*      */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.parser.JavadocParser;
/*      */ import org.eclipse.jdt.internal.compiler.parser.Parser;
/*      */ import org.eclipse.jdt.internal.compiler.parser.RecoveredAnnotation;
/*      */ import org.eclipse.jdt.internal.compiler.parser.RecoveredBlock;
/*      */ import org.eclipse.jdt.internal.compiler.parser.RecoveredElement;
/*      */ import org.eclipse.jdt.internal.compiler.parser.RecoveredField;
/*      */ import org.eclipse.jdt.internal.compiler.parser.RecoveredLocalVariable;
/*      */ import org.eclipse.jdt.internal.compiler.parser.RecoveredMethod;
/*      */ import org.eclipse.jdt.internal.compiler.parser.RecoveredModule;
/*      */ import org.eclipse.jdt.internal.compiler.parser.RecoveredPackageVisibilityStatement;
/*      */ import org.eclipse.jdt.internal.compiler.parser.RecoveredProvidesStatement;
/*      */ import org.eclipse.jdt.internal.compiler.parser.RecoveredType;
/*      */ import org.eclipse.jdt.internal.compiler.parser.RecoveredUnit;
/*      */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*      */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilation;
/*      */ import org.eclipse.jdt.internal.compiler.problem.ProblemReporter;
/*      */ import org.eclipse.jdt.internal.compiler.util.HashtableOfObjectToInt;
/*      */ import org.eclipse.jdt.internal.compiler.util.Util;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CompletionParser
/*      */   extends AssistParser
/*      */ {
/*      */   protected static final int COMPLETION_PARSER = 1024;
/*      */   protected static final int COMPLETION_OR_ASSIST_PARSER = 1536;
/*      */   protected static final int K_BLOCK_DELIMITER = 1025;
/*      */   protected static final int K_SELECTOR_INVOCATION_TYPE = 1026;
/*      */   protected static final int K_SELECTOR_QUALIFIER = 1027;
/*      */   protected static final int K_BETWEEN_CATCH_AND_RIGHT_PAREN = 1028;
/*      */   protected static final int K_NEXT_TYPEREF_IS_CLASS = 1029;
/*      */   protected static final int K_NEXT_TYPEREF_IS_INTERFACE = 1030;
/*      */   protected static final int K_NEXT_TYPEREF_IS_EXCEPTION = 1031;
/*      */   protected static final int K_BETWEEN_NEW_AND_LEFT_BRACKET = 1032;
/*      */   protected static final int K_INSIDE_THROW_STATEMENT = 1033;
/*      */   protected static final int K_INSIDE_RETURN_STATEMENT = 1034;
/*      */   protected static final int K_CAST_STATEMENT = 1035;
/*      */   protected static final int K_LOCAL_INITIALIZER_DELIMITER = 1036;
/*      */   protected static final int K_ARRAY_INITIALIZER = 1037;
/*      */   protected static final int K_ARRAY_CREATION = 1038;
/*      */   protected static final int K_UNARY_OPERATOR = 1039;
/*      */   protected static final int K_BINARY_OPERATOR = 1040;
/*      */   protected static final int K_ASSISGNMENT_OPERATOR = 1041;
/*      */   protected static final int K_CONDITIONAL_OPERATOR = 1042;
/*      */   protected static final int K_BETWEEN_IF_AND_RIGHT_PAREN = 1043;
/*      */   protected static final int K_BETWEEN_WHILE_AND_RIGHT_PAREN = 1044;
/*      */   protected static final int K_BETWEEN_FOR_AND_RIGHT_PAREN = 1045;
/*      */   protected static final int K_BETWEEN_SWITCH_AND_RIGHT_PAREN = 1046;
/*      */   protected static final int K_BETWEEN_SYNCHRONIZED_AND_RIGHT_PAREN = 1047;
/*      */   protected static final int K_INSIDE_ASSERT_STATEMENT = 1048;
/*      */   protected static final int K_SWITCH_LABEL = 1049;
/*      */   protected static final int K_BETWEEN_CASE_AND_COLON = 1050;
/*      */   protected static final int K_BETWEEN_DEFAULT_AND_COLON = 1051;
/*      */   protected static final int K_BETWEEN_LEFT_AND_RIGHT_BRACKET = 1052;
/*      */   protected static final int K_EXTENDS_KEYWORD = 1053;
/*      */   protected static final int K_PARAMETERIZED_METHOD_INVOCATION = 1054;
/*      */   protected static final int K_PARAMETERIZED_ALLOCATION = 1055;
/*      */   protected static final int K_PARAMETERIZED_CAST = 1056;
/*      */   protected static final int K_BETWEEN_ANNOTATION_NAME_AND_RPAREN = 1057;
/*      */   protected static final int K_INSIDE_BREAK_STATEMENT = 1058;
/*      */   protected static final int K_INSIDE_CONTINUE_STATEMENT = 1059;
/*      */   protected static final int K_LABEL = 1060;
/*      */   protected static final int K_MEMBER_VALUE_ARRAY_INITIALIZER = 1061;
/*      */   protected static final int K_CONTROL_STATEMENT_DELIMITER = 1062;
/*      */   protected static final int K_INSIDE_ASSERT_EXCEPTION = 1063;
/*      */   protected static final int K_INSIDE_FOR_CONDITIONAL = 1064;
/*      */   protected static final int K_BETWEEN_INSTANCEOF_AND_RPAREN = 1065;
/*      */   protected static final int K_INSIDE_IMPORT_STATEMENT = 1067;
/*      */   protected static final int K_INSIDE_EXPORTS_STATEMENT = 1068;
/*      */   protected static final int K_INSIDE_REQUIRES_STATEMENT = 1069;
/*      */   protected static final int K_INSIDE_USES_STATEMENT = 1070;
/*      */   protected static final int K_INSIDE_PROVIDES_STATEMENT = 1071;
/*      */   protected static final int K_AFTER_PACKAGE_IN_PACKAGE_VISIBILITY_STATEMENT = 1072;
/*      */   protected static final int K_AFTER_NAME_IN_PROVIDES_STATEMENT = 1073;
/*      */   protected static final int K_AFTER_WITH_IN_PROVIDES_STATEMENT = 1074;
/*      */   protected static final int K_INSIDE_OPENS_STATEMENT = 1075;
/*      */   protected static final int K_YIELD_KEYWORD = 1076;
/*  198 */   public static final char[] FAKE_TYPE_NAME = new char[] { ' ' };
/*  199 */   public static final char[] FAKE_METHOD_NAME = new char[] { ' ' };
/*  200 */   public static final char[] FAKE_ARGUMENT_NAME = new char[] { ' ' };
/*  201 */   public static final char[] VALUE = new char[] { 'v', 'a', 'l', 'u', 'e' };
/*      */   
/*      */   public ASTNode assistNodeParent;
/*      */   
/*      */   public ASTNode enclosingNode;
/*      */   
/*      */   static final int IF = 1;
/*      */   
/*      */   static final int TRY = 2;
/*      */   
/*      */   static final int CATCH = 3;
/*      */   
/*      */   static final int WHILE = 4;
/*      */   
/*      */   static final int SWITCH = 5;
/*      */   
/*      */   static final int FOR = 6;
/*      */   
/*      */   static final int DO = 7;
/*      */   
/*      */   static final int SYNCHRONIZED = 8;
/*      */   
/*      */   static final int DEFAULT = 1;
/*      */   
/*      */   static final int EXPLICIT_RECEIVER = 0;
/*      */   
/*      */   static final int NO_RECEIVER = -1;
/*      */   
/*      */   static final int SUPER_RECEIVER = -2;
/*      */   
/*      */   static final int NAME_RECEIVER = -3;
/*      */   
/*      */   static final int ALLOCATION = -4;
/*      */   
/*      */   static final int QUALIFIED_ALLOCATION = -5;
/*      */   
/*      */   static final int QUESTION = 1;
/*      */   
/*      */   static final int COLON = 2;
/*      */   
/*      */   static final int LPAREN_NOT_CONSUMED = 1;
/*      */   
/*      */   static final int LPAREN_CONSUMED = 2;
/*      */   
/*      */   static final int ANNOTATION_NAME_COMPLETION = 4;
/*      */   
/*      */   static final int INSIDE_NAME = 1;
/*      */   
/*      */   int invocationType;
/*      */   int qualifier;
/*      */   boolean hasUnusedModifiers;
/*  252 */   int canBeExplicitConstructor = 0;
/*      */   
/*      */   static final int NO = 0;
/*      */   static final int NEXTTOKEN = 1;
/*      */   static final int YES = 2;
/*      */   protected static final int LabelStackIncrement = 10;
/*  258 */   char[][] labelStack = new char[10][];
/*  259 */   int labelPtr = -1;
/*      */   
/*      */   boolean isAlreadyAttached;
/*      */   
/*      */   boolean shouldStackAssistNode;
/*      */   
/*      */   public boolean record = false;
/*      */   
/*      */   public boolean skipRecord = false;
/*      */   public int recordFrom;
/*      */   public int recordTo;
/*      */   public int potentialVariableNamesPtr;
/*      */   public char[][] potentialVariableNames;
/*      */   public int[] potentialVariableNameStarts;
/*      */   public int[] potentialVariableNameEnds;
/*      */   CompletionOnAnnotationOfType pendingAnnotation;
/*      */   private boolean storeSourceEnds;
/*      */   public HashtableOfObjectToInt sourceEnds;
/*      */   private boolean inReferenceExpression;
/*      */   private IProgressMonitor monitor;
/*  279 */   private int resumeOnSyntaxError = 0;
/*      */   private boolean consumedEnhancedFor;
/*      */   
/*      */   public CompletionParser(ProblemReporter problemReporter, boolean storeExtraSourceEnds) {
/*  283 */     super(problemReporter);
/*  284 */     this.reportSyntaxErrorIsRequired = false;
/*  285 */     this.javadocParser.checkDocComment = true;
/*  286 */     this.annotationRecoveryActivated = false;
/*  287 */     if (storeExtraSourceEnds) {
/*  288 */       this.storeSourceEnds = true;
/*  289 */       this.sourceEnds = new HashtableOfObjectToInt();
/*      */     } 
/*      */   }
/*      */   public CompletionParser(ProblemReporter problemReporter, boolean storeExtraSourceEnds, IProgressMonitor monitor) {
/*  293 */     this(problemReporter, storeExtraSourceEnds);
/*  294 */     this.monitor = monitor;
/*      */   }
/*      */   private void addPotentialName(char[] potentialVariableName, int start, int end) {
/*  297 */     int length = this.potentialVariableNames.length;
/*  298 */     if (this.potentialVariableNamesPtr >= length - 1) {
/*  299 */       System.arraycopy(
/*  300 */           this.potentialVariableNames, 
/*  301 */           0, 
/*  302 */           this.potentialVariableNames = new char[length * 2][], 
/*  303 */           0, 
/*  304 */           length);
/*  305 */       System.arraycopy(
/*  306 */           this.potentialVariableNameStarts, 
/*  307 */           0, 
/*  308 */           this.potentialVariableNameStarts = new int[length * 2], 
/*  309 */           0, 
/*  310 */           length);
/*  311 */       System.arraycopy(
/*  312 */           this.potentialVariableNameEnds, 
/*  313 */           0, 
/*  314 */           this.potentialVariableNameEnds = new int[length * 2], 
/*  315 */           0, 
/*  316 */           length);
/*      */     } 
/*  318 */     this.potentialVariableNames[++this.potentialVariableNamesPtr] = potentialVariableName;
/*  319 */     this.potentialVariableNameStarts[this.potentialVariableNamesPtr] = start;
/*  320 */     this.potentialVariableNameEnds[this.potentialVariableNamesPtr] = end;
/*      */   }
/*      */   public void startRecordingIdentifiers(int from, int to) {
/*  323 */     this.record = true;
/*  324 */     this.skipRecord = false;
/*  325 */     this.recordFrom = from;
/*  326 */     this.recordTo = to;
/*      */     
/*  328 */     this.potentialVariableNamesPtr = -1;
/*  329 */     this.potentialVariableNames = new char[10][];
/*  330 */     this.potentialVariableNameStarts = new int[10];
/*  331 */     this.potentialVariableNameEnds = new int[10];
/*      */   }
/*      */   public void stopRecordingIdentifiers() {
/*  334 */     this.record = true;
/*  335 */     this.skipRecord = false;
/*      */   }
/*      */   
/*      */   public char[] assistIdentifier() {
/*  339 */     return ((CompletionScanner)this.scanner).completionIdentifier;
/*      */   }
/*      */   
/*      */   protected ASTNode assistNodeParent() {
/*  343 */     return this.assistNodeParent;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void detectAssistNodeParent(ASTNode node) {
/*  348 */     if (this.assistNode == null || this.assistNodeParent != null)
/*      */       return; 
/*  350 */     CompletionNodeDetector detector = new CompletionNodeDetector(this.assistNode, node);
/*  351 */     if (detector.containsCompletionNode()) {
/*  352 */       this.assistNodeParent = detector.getCompletionNodeParent();
/*  353 */       if (this.assistNodeParent == null && node instanceof Statement && node != this.assistNode) {
/*  354 */         this.assistNodeParent = node;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void attachOrphanCompletionNode() {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   4: ifnull -> 14
/*      */     //   7: aload_0
/*      */     //   8: getfield isAlreadyAttached : Z
/*      */     //   11: ifeq -> 15
/*      */     //   14: return
/*      */     //   15: aload_0
/*      */     //   16: iconst_1
/*      */     //   17: putfield isAlreadyAttached : Z
/*      */     //   20: aload_0
/*      */     //   21: getfield isOrphanCompletionNode : Z
/*      */     //   24: ifeq -> 804
/*      */     //   27: aload_0
/*      */     //   28: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   31: astore_1
/*      */     //   32: aload_0
/*      */     //   33: iconst_0
/*      */     //   34: putfield isOrphanCompletionNode : Z
/*      */     //   37: aload_0
/*      */     //   38: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   41: instanceof org/eclipse/jdt/internal/compiler/parser/RecoveredUnit
/*      */     //   44: ifeq -> 93
/*      */     //   47: aload_1
/*      */     //   48: instanceof org/eclipse/jdt/internal/compiler/ast/ImportReference
/*      */     //   51: ifeq -> 70
/*      */     //   54: aload_0
/*      */     //   55: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   58: aload_1
/*      */     //   59: checkcast org/eclipse/jdt/internal/compiler/ast/ImportReference
/*      */     //   62: iconst_0
/*      */     //   63: invokevirtual add : (Lorg/eclipse/jdt/internal/compiler/ast/ImportReference;I)Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   66: pop
/*      */     //   67: goto -> 399
/*      */     //   70: aload_1
/*      */     //   71: instanceof org/eclipse/jdt/internal/compiler/ast/ModuleDeclaration
/*      */     //   74: ifeq -> 399
/*      */     //   77: aload_0
/*      */     //   78: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   81: aload_1
/*      */     //   82: checkcast org/eclipse/jdt/internal/compiler/ast/ModuleDeclaration
/*      */     //   85: iconst_0
/*      */     //   86: invokevirtual add : (Lorg/eclipse/jdt/internal/compiler/ast/ModuleDeclaration;I)Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   89: pop
/*      */     //   90: goto -> 399
/*      */     //   93: aload_0
/*      */     //   94: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   97: instanceof org/eclipse/jdt/internal/compiler/parser/RecoveredType
/*      */     //   100: ifeq -> 399
/*      */     //   103: aload_0
/*      */     //   104: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   107: checkcast org/eclipse/jdt/internal/compiler/parser/RecoveredType
/*      */     //   110: astore_2
/*      */     //   111: aload_2
/*      */     //   112: getfield typeDeclaration : Lorg/eclipse/jdt/internal/compiler/ast/TypeDeclaration;
/*      */     //   115: invokevirtual isRecord : ()Z
/*      */     //   118: istore_3
/*      */     //   119: aload_2
/*      */     //   120: getfield foundOpeningBrace : Z
/*      */     //   123: ifne -> 130
/*      */     //   126: iload_3
/*      */     //   127: ifeq -> 399
/*      */     //   130: aload_1
/*      */     //   131: instanceof org/eclipse/jdt/internal/compiler/ast/TypeReference
/*      */     //   134: ifeq -> 399
/*      */     //   137: aload_0
/*      */     //   138: invokevirtual isInsideModuleInfo : ()Z
/*      */     //   141: ifeq -> 145
/*      */     //   144: return
/*      */     //   145: aload_0
/*      */     //   146: sipush #1536
/*      */     //   149: invokevirtual topKnownElementKind : (I)I
/*      */     //   152: istore #5
/*      */     //   154: aload_0
/*      */     //   155: sipush #1536
/*      */     //   158: invokevirtual topKnownElementInfo : (I)I
/*      */     //   161: istore #6
/*      */     //   163: iload #5
/*      */     //   165: sipush #1040
/*      */     //   168: if_icmpne -> 226
/*      */     //   171: iload #6
/*      */     //   173: iconst_4
/*      */     //   174: if_icmpne -> 226
/*      */     //   177: aload_0
/*      */     //   178: getfield identifierPtr : I
/*      */     //   181: iconst_m1
/*      */     //   182: if_icmple -> 226
/*      */     //   185: aload_0
/*      */     //   186: getfield genericsLengthStack : [I
/*      */     //   189: aload_0
/*      */     //   190: getfield genericsLengthPtr : I
/*      */     //   193: iaload
/*      */     //   194: ifle -> 201
/*      */     //   197: aload_0
/*      */     //   198: invokevirtual consumeTypeArguments : ()V
/*      */     //   201: aload_0
/*      */     //   202: aload_1
/*      */     //   203: invokevirtual pushOnGenericsStack : (Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;)V
/*      */     //   206: aload_0
/*      */     //   207: invokevirtual consumeTypeArguments : ()V
/*      */     //   210: aload_0
/*      */     //   211: iconst_0
/*      */     //   212: invokevirtual getTypeReference : (I)Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   215: astore #4
/*      */     //   217: aload_0
/*      */     //   218: aload #4
/*      */     //   220: putfield assistNodeParent : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   223: goto -> 232
/*      */     //   226: aload_1
/*      */     //   227: checkcast org/eclipse/jdt/internal/compiler/ast/TypeReference
/*      */     //   230: astore #4
/*      */     //   232: new org/eclipse/jdt/internal/codeassist/complete/CompletionOnFieldType
/*      */     //   235: dup
/*      */     //   236: aload #4
/*      */     //   238: iload_3
/*      */     //   239: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;Z)V
/*      */     //   242: astore #7
/*      */     //   244: aload_0
/*      */     //   245: getfield expressionLengthStack : [I
/*      */     //   248: aload_0
/*      */     //   249: getfield expressionLengthPtr : I
/*      */     //   252: iaload
/*      */     //   253: dup
/*      */     //   254: istore #8
/*      */     //   256: ifeq -> 304
/*      */     //   259: aload_0
/*      */     //   260: getfield expressionStack : [Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   263: aload_0
/*      */     //   264: getfield expressionPtr : I
/*      */     //   267: aaload
/*      */     //   268: instanceof org/eclipse/jdt/internal/compiler/ast/Annotation
/*      */     //   271: ifeq -> 304
/*      */     //   274: aload_0
/*      */     //   275: getfield expressionStack : [Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   278: aload_0
/*      */     //   279: getfield expressionPtr : I
/*      */     //   282: iload #8
/*      */     //   284: isub
/*      */     //   285: iconst_1
/*      */     //   286: iadd
/*      */     //   287: aload #7
/*      */     //   289: iload #8
/*      */     //   291: anewarray org/eclipse/jdt/internal/compiler/ast/Annotation
/*      */     //   294: dup_x1
/*      */     //   295: putfield annotations : [Lorg/eclipse/jdt/internal/compiler/ast/Annotation;
/*      */     //   298: iconst_0
/*      */     //   299: iload #8
/*      */     //   301: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*      */     //   304: iload_3
/*      */     //   305: ifne -> 384
/*      */     //   308: aload_0
/*      */     //   309: getfield intPtr : I
/*      */     //   312: iconst_2
/*      */     //   313: if_icmplt -> 384
/*      */     //   316: aload_0
/*      */     //   317: getfield intStack : [I
/*      */     //   320: aload_0
/*      */     //   321: getfield intPtr : I
/*      */     //   324: iconst_1
/*      */     //   325: isub
/*      */     //   326: iaload
/*      */     //   327: aload_0
/*      */     //   328: getfield lastModifiersStart : I
/*      */     //   331: if_icmpne -> 384
/*      */     //   334: aload_0
/*      */     //   335: getfield intStack : [I
/*      */     //   338: aload_0
/*      */     //   339: getfield intPtr : I
/*      */     //   342: iconst_2
/*      */     //   343: isub
/*      */     //   344: iaload
/*      */     //   345: aload_0
/*      */     //   346: getfield lastModifiers : I
/*      */     //   349: if_icmpne -> 384
/*      */     //   352: aload #7
/*      */     //   354: aload_0
/*      */     //   355: getfield intStack : [I
/*      */     //   358: aload_0
/*      */     //   359: getfield intPtr : I
/*      */     //   362: iconst_1
/*      */     //   363: isub
/*      */     //   364: iaload
/*      */     //   365: putfield modifiersSourceStart : I
/*      */     //   368: aload #7
/*      */     //   370: aload_0
/*      */     //   371: getfield intStack : [I
/*      */     //   374: aload_0
/*      */     //   375: getfield intPtr : I
/*      */     //   378: iconst_2
/*      */     //   379: isub
/*      */     //   380: iaload
/*      */     //   381: putfield modifiers : I
/*      */     //   384: aload_0
/*      */     //   385: aload_0
/*      */     //   386: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   389: aload #7
/*      */     //   391: iconst_0
/*      */     //   392: invokevirtual add : (Lorg/eclipse/jdt/internal/compiler/ast/FieldDeclaration;I)Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   395: putfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   398: return
/*      */     //   399: aload_0
/*      */     //   400: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   403: instanceof org/eclipse/jdt/internal/compiler/parser/RecoveredMethod
/*      */     //   406: ifeq -> 512
/*      */     //   409: aload_0
/*      */     //   410: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   413: checkcast org/eclipse/jdt/internal/compiler/parser/RecoveredMethod
/*      */     //   416: astore_2
/*      */     //   417: aload_2
/*      */     //   418: getfield foundOpeningBrace : Z
/*      */     //   421: ifne -> 512
/*      */     //   424: aload_1
/*      */     //   425: instanceof org/eclipse/jdt/internal/compiler/ast/TypeReference
/*      */     //   428: ifeq -> 459
/*      */     //   431: aload_0
/*      */     //   432: aload_0
/*      */     //   433: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   436: getfield parent : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   439: new org/eclipse/jdt/internal/codeassist/complete/CompletionOnFieldType
/*      */     //   442: dup
/*      */     //   443: aload_1
/*      */     //   444: checkcast org/eclipse/jdt/internal/compiler/ast/TypeReference
/*      */     //   447: iconst_1
/*      */     //   448: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;Z)V
/*      */     //   451: iconst_0
/*      */     //   452: invokevirtual add : (Lorg/eclipse/jdt/internal/compiler/ast/FieldDeclaration;I)Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   455: putfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   458: return
/*      */     //   459: aload_1
/*      */     //   460: instanceof org/eclipse/jdt/internal/compiler/ast/Annotation
/*      */     //   463: ifeq -> 512
/*      */     //   466: new org/eclipse/jdt/internal/codeassist/complete/CompletionOnAnnotationOfType
/*      */     //   469: dup
/*      */     //   470: getstatic org/eclipse/jdt/internal/codeassist/complete/CompletionParser.FAKE_TYPE_NAME : [C
/*      */     //   473: aload_0
/*      */     //   474: getfield compilationUnit : Lorg/eclipse/jdt/internal/compiler/ast/CompilationUnitDeclaration;
/*      */     //   477: invokevirtual compilationResult : ()Lorg/eclipse/jdt/internal/compiler/CompilationResult;
/*      */     //   480: aload_1
/*      */     //   481: checkcast org/eclipse/jdt/internal/compiler/ast/Annotation
/*      */     //   484: invokespecial <init> : ([CLorg/eclipse/jdt/internal/compiler/CompilationResult;Lorg/eclipse/jdt/internal/compiler/ast/Annotation;)V
/*      */     //   487: astore_3
/*      */     //   488: aload_3
/*      */     //   489: iconst_1
/*      */     //   490: putfield isParameter : Z
/*      */     //   493: aload_0
/*      */     //   494: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   497: getfield parent : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   500: aload_3
/*      */     //   501: iconst_0
/*      */     //   502: invokevirtual add : (Lorg/eclipse/jdt/internal/compiler/ast/TypeDeclaration;I)Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   505: pop
/*      */     //   506: aload_0
/*      */     //   507: aload_3
/*      */     //   508: putfield pendingAnnotation : Lorg/eclipse/jdt/internal/codeassist/complete/CompletionOnAnnotationOfType;
/*      */     //   511: return
/*      */     //   512: aload_1
/*      */     //   513: instanceof org/eclipse/jdt/internal/compiler/ast/MemberValuePair
/*      */     //   516: ifeq -> 528
/*      */     //   519: aload_0
/*      */     //   520: aload_1
/*      */     //   521: checkcast org/eclipse/jdt/internal/compiler/ast/MemberValuePair
/*      */     //   524: invokevirtual buildMoreAnnotationCompletionContext : (Lorg/eclipse/jdt/internal/compiler/ast/MemberValuePair;)V
/*      */     //   527: return
/*      */     //   528: aload_1
/*      */     //   529: instanceof org/eclipse/jdt/internal/compiler/ast/Annotation
/*      */     //   532: ifeq -> 584
/*      */     //   535: aload_0
/*      */     //   536: invokevirtual popUntilCompletedAnnotationIfNecessary : ()V
/*      */     //   539: new org/eclipse/jdt/internal/codeassist/complete/CompletionOnAnnotationOfType
/*      */     //   542: dup
/*      */     //   543: getstatic org/eclipse/jdt/internal/codeassist/complete/CompletionParser.FAKE_TYPE_NAME : [C
/*      */     //   546: aload_0
/*      */     //   547: getfield compilationUnit : Lorg/eclipse/jdt/internal/compiler/ast/CompilationUnitDeclaration;
/*      */     //   550: invokevirtual compilationResult : ()Lorg/eclipse/jdt/internal/compiler/CompilationResult;
/*      */     //   553: aload_1
/*      */     //   554: checkcast org/eclipse/jdt/internal/compiler/ast/Annotation
/*      */     //   557: invokespecial <init> : ([CLorg/eclipse/jdt/internal/compiler/CompilationResult;Lorg/eclipse/jdt/internal/compiler/ast/Annotation;)V
/*      */     //   560: astore_2
/*      */     //   561: aload_0
/*      */     //   562: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   565: aload_2
/*      */     //   566: iconst_0
/*      */     //   567: invokevirtual add : (Lorg/eclipse/jdt/internal/compiler/ast/TypeDeclaration;I)Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   570: pop
/*      */     //   571: aload_0
/*      */     //   572: invokevirtual isInsideAnnotation : ()Z
/*      */     //   575: ifne -> 583
/*      */     //   578: aload_0
/*      */     //   579: aload_2
/*      */     //   580: putfield pendingAnnotation : Lorg/eclipse/jdt/internal/codeassist/complete/CompletionOnAnnotationOfType;
/*      */     //   583: return
/*      */     //   584: aload_0
/*      */     //   585: sipush #1536
/*      */     //   588: invokevirtual topKnownElementKind : (I)I
/*      */     //   591: sipush #1028
/*      */     //   594: if_icmpne -> 702
/*      */     //   597: aload_0
/*      */     //   598: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   601: instanceof org/eclipse/jdt/internal/codeassist/complete/CompletionOnSingleTypeReference
/*      */     //   604: ifeq -> 632
/*      */     //   607: aload_0
/*      */     //   608: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   611: checkcast org/eclipse/jdt/internal/codeassist/complete/CompletionOnSingleTypeReference
/*      */     //   614: invokevirtual isException : ()Z
/*      */     //   617: ifeq -> 632
/*      */     //   620: aload_0
/*      */     //   621: aload_0
/*      */     //   622: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   625: checkcast org/eclipse/jdt/internal/compiler/ast/TypeReference
/*      */     //   628: invokevirtual buildMoreTryStatementCompletionContext : (Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;)V
/*      */     //   631: return
/*      */     //   632: aload_0
/*      */     //   633: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   636: instanceof org/eclipse/jdt/internal/codeassist/complete/CompletionOnQualifiedTypeReference
/*      */     //   639: ifeq -> 667
/*      */     //   642: aload_0
/*      */     //   643: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   646: checkcast org/eclipse/jdt/internal/codeassist/complete/CompletionOnQualifiedTypeReference
/*      */     //   649: invokevirtual isException : ()Z
/*      */     //   652: ifeq -> 667
/*      */     //   655: aload_0
/*      */     //   656: aload_0
/*      */     //   657: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   660: checkcast org/eclipse/jdt/internal/compiler/ast/TypeReference
/*      */     //   663: invokevirtual buildMoreTryStatementCompletionContext : (Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;)V
/*      */     //   666: return
/*      */     //   667: aload_0
/*      */     //   668: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   671: instanceof org/eclipse/jdt/internal/codeassist/complete/CompletionOnParameterizedQualifiedTypeReference
/*      */     //   674: ifeq -> 702
/*      */     //   677: aload_0
/*      */     //   678: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   681: checkcast org/eclipse/jdt/internal/codeassist/complete/CompletionOnParameterizedQualifiedTypeReference
/*      */     //   684: invokevirtual isException : ()Z
/*      */     //   687: ifeq -> 702
/*      */     //   690: aload_0
/*      */     //   691: aload_0
/*      */     //   692: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   695: checkcast org/eclipse/jdt/internal/compiler/ast/TypeReference
/*      */     //   698: invokevirtual buildMoreTryStatementCompletionContext : (Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;)V
/*      */     //   701: return
/*      */     //   702: aload_1
/*      */     //   703: instanceof org/eclipse/jdt/internal/compiler/ast/Statement
/*      */     //   706: ifeq -> 804
/*      */     //   709: aload_0
/*      */     //   710: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   713: invokevirtual enclosingMethod : ()Lorg/eclipse/jdt/internal/compiler/parser/RecoveredMethod;
/*      */     //   716: astore_2
/*      */     //   717: aload_2
/*      */     //   718: ifnull -> 787
/*      */     //   721: aload_2
/*      */     //   722: getfield methodDeclaration : Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;
/*      */     //   725: astore_3
/*      */     //   726: aload_3
/*      */     //   727: getfield bodyStart : I
/*      */     //   730: aload_3
/*      */     //   731: getfield sourceEnd : I
/*      */     //   734: iconst_1
/*      */     //   735: iadd
/*      */     //   736: if_icmpne -> 787
/*      */     //   739: aload_1
/*      */     //   740: getfield sourceStart : I
/*      */     //   743: aload_0
/*      */     //   744: getfield scanner : Lorg/eclipse/jdt/internal/compiler/parser/Scanner;
/*      */     //   747: getfield lineEnds : [I
/*      */     //   750: iconst_0
/*      */     //   751: aload_0
/*      */     //   752: getfield scanner : Lorg/eclipse/jdt/internal/compiler/parser/Scanner;
/*      */     //   755: getfield linePtr : I
/*      */     //   758: invokestatic getLineNumber : (I[III)I
/*      */     //   761: aload_3
/*      */     //   762: getfield sourceEnd : I
/*      */     //   765: aload_0
/*      */     //   766: getfield scanner : Lorg/eclipse/jdt/internal/compiler/parser/Scanner;
/*      */     //   769: getfield lineEnds : [I
/*      */     //   772: iconst_0
/*      */     //   773: aload_0
/*      */     //   774: getfield scanner : Lorg/eclipse/jdt/internal/compiler/parser/Scanner;
/*      */     //   777: getfield linePtr : I
/*      */     //   780: invokestatic getLineNumber : (I[III)I
/*      */     //   783: if_icmpne -> 787
/*      */     //   786: return
/*      */     //   787: aload_0
/*      */     //   788: aload_0
/*      */     //   789: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   792: aload_1
/*      */     //   793: checkcast org/eclipse/jdt/internal/compiler/ast/Statement
/*      */     //   796: iconst_0
/*      */     //   797: invokevirtual add : (Lorg/eclipse/jdt/internal/compiler/ast/Statement;I)Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   800: putfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   803: return
/*      */     //   804: aload_0
/*      */     //   805: invokevirtual isInsideAnnotation : ()Z
/*      */     //   808: ifeq -> 1404
/*      */     //   811: aload_0
/*      */     //   812: getfield expressionPtr : I
/*      */     //   815: iconst_m1
/*      */     //   816: if_icmple -> 1337
/*      */     //   819: aload_0
/*      */     //   820: getfield expressionStack : [Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   823: aload_0
/*      */     //   824: getfield expressionPtr : I
/*      */     //   827: aaload
/*      */     //   828: astore_1
/*      */     //   829: aload_1
/*      */     //   830: aload_0
/*      */     //   831: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   834: if_acmpne -> 1292
/*      */     //   837: aload_0
/*      */     //   838: sipush #1536
/*      */     //   841: invokevirtual topKnownElementKind : (I)I
/*      */     //   844: sipush #1061
/*      */     //   847: if_icmpne -> 1073
/*      */     //   850: new org/eclipse/jdt/internal/compiler/ast/ArrayInitializer
/*      */     //   853: dup
/*      */     //   854: invokespecial <init> : ()V
/*      */     //   857: astore_2
/*      */     //   858: aload_2
/*      */     //   859: iconst_1
/*      */     //   860: anewarray org/eclipse/jdt/internal/compiler/ast/Expression
/*      */     //   863: dup
/*      */     //   864: iconst_0
/*      */     //   865: aload_1
/*      */     //   866: aastore
/*      */     //   867: putfield expressions : [Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   870: getstatic org/eclipse/jdt/internal/codeassist/complete/CompletionParser.VALUE : [C
/*      */     //   873: astore_3
/*      */     //   874: aload_0
/*      */     //   875: sipush #1536
/*      */     //   878: iconst_1
/*      */     //   879: invokevirtual topKnownElementKind : (II)I
/*      */     //   882: sipush #517
/*      */     //   885: if_icmpne -> 934
/*      */     //   888: aload_0
/*      */     //   889: getfield identifierLengthPtr : I
/*      */     //   892: ifle -> 934
/*      */     //   895: aload_0
/*      */     //   896: getfield identifierStack : [[C
/*      */     //   899: aload_0
/*      */     //   900: getfield identifierPtr : I
/*      */     //   903: aaload
/*      */     //   904: astore_3
/*      */     //   905: aload_0
/*      */     //   906: getfield identifierLengthStack : [I
/*      */     //   909: aload_0
/*      */     //   910: dup
/*      */     //   911: getfield identifierLengthPtr : I
/*      */     //   914: dup_x1
/*      */     //   915: iconst_1
/*      */     //   916: isub
/*      */     //   917: putfield identifierLengthPtr : I
/*      */     //   920: iaload
/*      */     //   921: istore #4
/*      */     //   923: aload_0
/*      */     //   924: dup
/*      */     //   925: getfield identifierPtr : I
/*      */     //   928: iload #4
/*      */     //   930: isub
/*      */     //   931: putfield identifierPtr : I
/*      */     //   934: new org/eclipse/jdt/internal/compiler/ast/MemberValuePair
/*      */     //   937: dup
/*      */     //   938: aload_3
/*      */     //   939: aload_1
/*      */     //   940: getfield sourceStart : I
/*      */     //   943: aload_1
/*      */     //   944: getfield sourceEnd : I
/*      */     //   947: aload_2
/*      */     //   948: invokespecial <init> : ([CIILorg/eclipse/jdt/internal/compiler/ast/Expression;)V
/*      */     //   951: astore #4
/*      */     //   953: aload_0
/*      */     //   954: getfield astLengthPtr : I
/*      */     //   957: iconst_m1
/*      */     //   958: if_icmple -> 971
/*      */     //   961: aload_0
/*      */     //   962: dup
/*      */     //   963: getfield astLengthPtr : I
/*      */     //   966: iconst_1
/*      */     //   967: isub
/*      */     //   968: putfield astLengthPtr : I
/*      */     //   971: aload_0
/*      */     //   972: invokevirtual getAnnotationType : ()Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   975: astore #5
/*      */     //   977: new org/eclipse/jdt/internal/compiler/ast/NormalAnnotation
/*      */     //   980: dup
/*      */     //   981: aload #5
/*      */     //   983: aload_0
/*      */     //   984: getfield intStack : [I
/*      */     //   987: aload_0
/*      */     //   988: dup
/*      */     //   989: getfield intPtr : I
/*      */     //   992: dup_x1
/*      */     //   993: iconst_1
/*      */     //   994: isub
/*      */     //   995: putfield intPtr : I
/*      */     //   998: iaload
/*      */     //   999: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;I)V
/*      */     //   1002: astore #6
/*      */     //   1004: aload #6
/*      */     //   1006: iconst_1
/*      */     //   1007: anewarray org/eclipse/jdt/internal/compiler/ast/MemberValuePair
/*      */     //   1010: dup
/*      */     //   1011: iconst_0
/*      */     //   1012: aload #4
/*      */     //   1014: aastore
/*      */     //   1015: putfield memberValuePairs : [Lorg/eclipse/jdt/internal/compiler/ast/MemberValuePair;
/*      */     //   1018: new org/eclipse/jdt/internal/codeassist/complete/CompletionOnAnnotationOfType
/*      */     //   1021: dup
/*      */     //   1022: getstatic org/eclipse/jdt/internal/codeassist/complete/CompletionParser.FAKE_TYPE_NAME : [C
/*      */     //   1025: aload_0
/*      */     //   1026: getfield compilationUnit : Lorg/eclipse/jdt/internal/compiler/ast/CompilationUnitDeclaration;
/*      */     //   1029: invokevirtual compilationResult : ()Lorg/eclipse/jdt/internal/compiler/CompilationResult;
/*      */     //   1032: aload #6
/*      */     //   1034: invokespecial <init> : ([CLorg/eclipse/jdt/internal/compiler/CompilationResult;Lorg/eclipse/jdt/internal/compiler/ast/Annotation;)V
/*      */     //   1037: astore #7
/*      */     //   1039: aload_0
/*      */     //   1040: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   1043: aload #7
/*      */     //   1045: iconst_0
/*      */     //   1046: invokevirtual add : (Lorg/eclipse/jdt/internal/compiler/ast/TypeDeclaration;I)Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   1049: pop
/*      */     //   1050: aload_0
/*      */     //   1051: aload #7
/*      */     //   1053: putfield pendingAnnotation : Lorg/eclipse/jdt/internal/codeassist/complete/CompletionOnAnnotationOfType;
/*      */     //   1056: aload_0
/*      */     //   1057: new org/eclipse/jdt/internal/codeassist/complete/AssistNodeParentAnnotationArrayInitializer
/*      */     //   1060: dup
/*      */     //   1061: aload #5
/*      */     //   1063: aload_3
/*      */     //   1064: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;[C)V
/*      */     //   1067: putfield assistNodeParent : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1070: goto -> 1337
/*      */     //   1073: aload_0
/*      */     //   1074: sipush #1536
/*      */     //   1077: invokevirtual topKnownElementKind : (I)I
/*      */     //   1080: sipush #1057
/*      */     //   1083: if_icmpne -> 1166
/*      */     //   1086: aload_1
/*      */     //   1087: instanceof org/eclipse/jdt/internal/compiler/ast/SingleNameReference
/*      */     //   1090: ifeq -> 1124
/*      */     //   1093: aload_1
/*      */     //   1094: checkcast org/eclipse/jdt/internal/compiler/ast/SingleNameReference
/*      */     //   1097: astore_2
/*      */     //   1098: new org/eclipse/jdt/internal/codeassist/complete/CompletionOnMemberValueName
/*      */     //   1101: dup
/*      */     //   1102: aload_2
/*      */     //   1103: getfield token : [C
/*      */     //   1106: aload_2
/*      */     //   1107: getfield sourceStart : I
/*      */     //   1110: aload_2
/*      */     //   1111: getfield sourceEnd : I
/*      */     //   1114: invokespecial <init> : ([CII)V
/*      */     //   1117: astore_3
/*      */     //   1118: aload_0
/*      */     //   1119: aload_3
/*      */     //   1120: invokevirtual buildMoreAnnotationCompletionContext : (Lorg/eclipse/jdt/internal/compiler/ast/MemberValuePair;)V
/*      */     //   1123: return
/*      */     //   1124: aload_1
/*      */     //   1125: instanceof org/eclipse/jdt/internal/compiler/ast/QualifiedNameReference
/*      */     //   1128: ifne -> 1138
/*      */     //   1131: aload_1
/*      */     //   1132: instanceof org/eclipse/jdt/internal/compiler/ast/StringLiteral
/*      */     //   1135: ifeq -> 1337
/*      */     //   1138: new org/eclipse/jdt/internal/compiler/ast/MemberValuePair
/*      */     //   1141: dup
/*      */     //   1142: getstatic org/eclipse/jdt/internal/codeassist/complete/CompletionParser.VALUE : [C
/*      */     //   1145: aload_1
/*      */     //   1146: getfield sourceStart : I
/*      */     //   1149: aload_1
/*      */     //   1150: getfield sourceEnd : I
/*      */     //   1153: aload_1
/*      */     //   1154: invokespecial <init> : ([CIILorg/eclipse/jdt/internal/compiler/ast/Expression;)V
/*      */     //   1157: astore_2
/*      */     //   1158: aload_0
/*      */     //   1159: aload_2
/*      */     //   1160: invokevirtual buildMoreAnnotationCompletionContext : (Lorg/eclipse/jdt/internal/compiler/ast/MemberValuePair;)V
/*      */     //   1163: goto -> 1337
/*      */     //   1166: aload_0
/*      */     //   1167: sipush #517
/*      */     //   1170: invokevirtual lastIndexOfElement : (I)I
/*      */     //   1173: dup
/*      */     //   1174: istore_2
/*      */     //   1175: iconst_m1
/*      */     //   1176: if_icmpeq -> 1337
/*      */     //   1179: aload_0
/*      */     //   1180: getfield elementInfoStack : [I
/*      */     //   1183: iload_2
/*      */     //   1184: iaload
/*      */     //   1185: istore_3
/*      */     //   1186: aload_0
/*      */     //   1187: getfield identifierLengthPtr : I
/*      */     //   1190: istore #4
/*      */     //   1192: aload_0
/*      */     //   1193: getfield identifierPtr : I
/*      */     //   1196: istore #5
/*      */     //   1198: goto -> 1216
/*      */     //   1201: iload #5
/*      */     //   1203: aload_0
/*      */     //   1204: getfield identifierLengthStack : [I
/*      */     //   1207: iload #4
/*      */     //   1209: iinc #4, -1
/*      */     //   1212: iaload
/*      */     //   1213: isub
/*      */     //   1214: istore #5
/*      */     //   1216: iload_3
/*      */     //   1217: iload #5
/*      */     //   1219: if_icmplt -> 1201
/*      */     //   1222: iload_3
/*      */     //   1223: iload #5
/*      */     //   1225: if_icmpeq -> 1229
/*      */     //   1228: return
/*      */     //   1229: aload_0
/*      */     //   1230: iload #4
/*      */     //   1232: putfield identifierLengthPtr : I
/*      */     //   1235: aload_0
/*      */     //   1236: iload #5
/*      */     //   1238: putfield identifierPtr : I
/*      */     //   1241: aload_0
/*      */     //   1242: dup
/*      */     //   1243: getfield identifierLengthPtr : I
/*      */     //   1246: iconst_1
/*      */     //   1247: isub
/*      */     //   1248: putfield identifierLengthPtr : I
/*      */     //   1251: new org/eclipse/jdt/internal/compiler/ast/MemberValuePair
/*      */     //   1254: dup
/*      */     //   1255: aload_0
/*      */     //   1256: getfield identifierStack : [[C
/*      */     //   1259: aload_0
/*      */     //   1260: dup
/*      */     //   1261: getfield identifierPtr : I
/*      */     //   1264: dup_x1
/*      */     //   1265: iconst_1
/*      */     //   1266: isub
/*      */     //   1267: putfield identifierPtr : I
/*      */     //   1270: aaload
/*      */     //   1271: aload_1
/*      */     //   1272: getfield sourceStart : I
/*      */     //   1275: aload_1
/*      */     //   1276: getfield sourceEnd : I
/*      */     //   1279: aload_1
/*      */     //   1280: invokespecial <init> : ([CIILorg/eclipse/jdt/internal/compiler/ast/Expression;)V
/*      */     //   1283: astore #6
/*      */     //   1285: aload_0
/*      */     //   1286: aload #6
/*      */     //   1288: invokevirtual buildMoreAnnotationCompletionContext : (Lorg/eclipse/jdt/internal/compiler/ast/MemberValuePair;)V
/*      */     //   1291: return
/*      */     //   1292: new org/eclipse/jdt/internal/codeassist/complete/CompletionNodeDetector
/*      */     //   1295: dup
/*      */     //   1296: aload_0
/*      */     //   1297: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1300: aload_1
/*      */     //   1301: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;)V
/*      */     //   1304: astore_2
/*      */     //   1305: aload_2
/*      */     //   1306: invokevirtual containsCompletionNode : ()Z
/*      */     //   1309: ifeq -> 1337
/*      */     //   1312: new org/eclipse/jdt/internal/compiler/ast/MemberValuePair
/*      */     //   1315: dup
/*      */     //   1316: getstatic org/eclipse/jdt/internal/codeassist/complete/CompletionParser.VALUE : [C
/*      */     //   1319: aload_1
/*      */     //   1320: getfield sourceStart : I
/*      */     //   1323: aload_1
/*      */     //   1324: getfield sourceEnd : I
/*      */     //   1327: aload_1
/*      */     //   1328: invokespecial <init> : ([CIILorg/eclipse/jdt/internal/compiler/ast/Expression;)V
/*      */     //   1331: astore_3
/*      */     //   1332: aload_0
/*      */     //   1333: aload_3
/*      */     //   1334: invokevirtual buildMoreAnnotationCompletionContext : (Lorg/eclipse/jdt/internal/compiler/ast/MemberValuePair;)V
/*      */     //   1337: aload_0
/*      */     //   1338: getfield astPtr : I
/*      */     //   1341: iconst_m1
/*      */     //   1342: if_icmple -> 1404
/*      */     //   1345: aload_0
/*      */     //   1346: getfield astStack : [Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1349: aload_0
/*      */     //   1350: getfield astPtr : I
/*      */     //   1353: aaload
/*      */     //   1354: astore_2
/*      */     //   1355: aload_2
/*      */     //   1356: instanceof org/eclipse/jdt/internal/compiler/ast/MemberValuePair
/*      */     //   1359: ifeq -> 1404
/*      */     //   1362: aload_2
/*      */     //   1363: checkcast org/eclipse/jdt/internal/compiler/ast/MemberValuePair
/*      */     //   1366: astore_3
/*      */     //   1367: new org/eclipse/jdt/internal/codeassist/complete/CompletionNodeDetector
/*      */     //   1370: dup
/*      */     //   1371: aload_0
/*      */     //   1372: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1375: aload_3
/*      */     //   1376: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;)V
/*      */     //   1379: astore #4
/*      */     //   1381: aload #4
/*      */     //   1383: invokevirtual containsCompletionNode : ()Z
/*      */     //   1386: ifeq -> 1404
/*      */     //   1389: aload_0
/*      */     //   1390: aload_3
/*      */     //   1391: invokevirtual buildMoreAnnotationCompletionContext : (Lorg/eclipse/jdt/internal/compiler/ast/MemberValuePair;)V
/*      */     //   1394: aload_0
/*      */     //   1395: aload #4
/*      */     //   1397: invokevirtual getCompletionNodeParent : ()Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1400: putfield assistNodeParent : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1403: return
/*      */     //   1404: aload_0
/*      */     //   1405: getfield genericsPtr : I
/*      */     //   1408: iconst_m1
/*      */     //   1409: if_icmple -> 1513
/*      */     //   1412: aload_0
/*      */     //   1413: getfield genericsStack : [Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1416: aload_0
/*      */     //   1417: getfield genericsPtr : I
/*      */     //   1420: aaload
/*      */     //   1421: astore_1
/*      */     //   1422: aload_1
/*      */     //   1423: instanceof org/eclipse/jdt/internal/compiler/ast/Wildcard
/*      */     //   1426: ifeq -> 1513
/*      */     //   1429: aload_1
/*      */     //   1430: checkcast org/eclipse/jdt/internal/compiler/ast/Wildcard
/*      */     //   1433: getfield bound : Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   1436: aload_0
/*      */     //   1437: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1440: if_acmpne -> 1513
/*      */     //   1443: aload_0
/*      */     //   1444: sipush #1536
/*      */     //   1447: invokevirtual topKnownElementKind : (I)I
/*      */     //   1450: istore_2
/*      */     //   1451: iload_2
/*      */     //   1452: sipush #1040
/*      */     //   1455: if_icmpne -> 1478
/*      */     //   1458: aload_0
/*      */     //   1459: sipush #1536
/*      */     //   1462: invokevirtual topKnownElementInfo : (I)I
/*      */     //   1465: istore_3
/*      */     //   1466: iload_3
/*      */     //   1467: iconst_4
/*      */     //   1468: if_icmpne -> 1478
/*      */     //   1471: aload_0
/*      */     //   1472: aload_1
/*      */     //   1473: iconst_1
/*      */     //   1474: invokevirtual buildMoreGenericsCompletionContext : (Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Z)V
/*      */     //   1477: return
/*      */     //   1478: aload_0
/*      */     //   1479: getfield identifierLengthPtr : I
/*      */     //   1482: iconst_m1
/*      */     //   1483: if_icmple -> 1513
/*      */     //   1486: aload_0
/*      */     //   1487: getfield identifierLengthStack : [I
/*      */     //   1490: aload_0
/*      */     //   1491: getfield identifierLengthPtr : I
/*      */     //   1494: iaload
/*      */     //   1495: ifeq -> 1513
/*      */     //   1498: aload_0
/*      */     //   1499: sipush #1040
/*      */     //   1502: iconst_4
/*      */     //   1503: invokevirtual pushOnElementStack : (II)V
/*      */     //   1506: aload_0
/*      */     //   1507: aload_1
/*      */     //   1508: iconst_0
/*      */     //   1509: invokevirtual buildMoreGenericsCompletionContext : (Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Z)V
/*      */     //   1512: return
/*      */     //   1513: aload_0
/*      */     //   1514: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   1517: instanceof org/eclipse/jdt/internal/compiler/parser/RecoveredType
/*      */     //   1520: ifne -> 1533
/*      */     //   1523: aload_0
/*      */     //   1524: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   1527: instanceof org/eclipse/jdt/internal/compiler/parser/RecoveredMethod
/*      */     //   1530: ifeq -> 1978
/*      */     //   1533: aload_0
/*      */     //   1534: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   1537: instanceof org/eclipse/jdt/internal/compiler/parser/RecoveredType
/*      */     //   1540: ifeq -> 1646
/*      */     //   1543: aload_0
/*      */     //   1544: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   1547: checkcast org/eclipse/jdt/internal/compiler/parser/RecoveredType
/*      */     //   1550: astore_1
/*      */     //   1551: aload_1
/*      */     //   1552: getfield foundOpeningBrace : Z
/*      */     //   1555: ifeq -> 1646
/*      */     //   1558: aload_0
/*      */     //   1559: getfield genericsPtr : I
/*      */     //   1562: iconst_m1
/*      */     //   1563: if_icmple -> 1646
/*      */     //   1566: aload_0
/*      */     //   1567: getfield genericsStack : [Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1570: aload_0
/*      */     //   1571: getfield genericsPtr : I
/*      */     //   1574: aaload
/*      */     //   1575: instanceof org/eclipse/jdt/internal/compiler/ast/TypeParameter
/*      */     //   1578: ifeq -> 1646
/*      */     //   1581: aload_0
/*      */     //   1582: getfield genericsStack : [Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1585: aload_0
/*      */     //   1586: getfield genericsPtr : I
/*      */     //   1589: aaload
/*      */     //   1590: checkcast org/eclipse/jdt/internal/compiler/ast/TypeParameter
/*      */     //   1593: astore_2
/*      */     //   1594: new org/eclipse/jdt/internal/codeassist/complete/CompletionNodeDetector
/*      */     //   1597: dup
/*      */     //   1598: aload_0
/*      */     //   1599: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1602: aload_2
/*      */     //   1603: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;)V
/*      */     //   1606: astore_3
/*      */     //   1607: aload_3
/*      */     //   1608: invokevirtual containsCompletionNode : ()Z
/*      */     //   1611: ifeq -> 1645
/*      */     //   1614: aload_0
/*      */     //   1615: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   1618: new org/eclipse/jdt/internal/codeassist/complete/CompletionOnMethodTypeParameter
/*      */     //   1621: dup
/*      */     //   1622: iconst_1
/*      */     //   1623: anewarray org/eclipse/jdt/internal/compiler/ast/TypeParameter
/*      */     //   1626: dup
/*      */     //   1627: iconst_0
/*      */     //   1628: aload_2
/*      */     //   1629: aastore
/*      */     //   1630: aload_0
/*      */     //   1631: getfield compilationUnit : Lorg/eclipse/jdt/internal/compiler/ast/CompilationUnitDeclaration;
/*      */     //   1634: invokevirtual compilationResult : ()Lorg/eclipse/jdt/internal/compiler/CompilationResult;
/*      */     //   1637: invokespecial <init> : ([Lorg/eclipse/jdt/internal/compiler/ast/TypeParameter;Lorg/eclipse/jdt/internal/compiler/CompilationResult;)V
/*      */     //   1640: iconst_0
/*      */     //   1641: invokevirtual add : (Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;I)Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   1644: pop
/*      */     //   1645: return
/*      */     //   1646: aload_0
/*      */     //   1647: invokevirtual isInsideMethod : ()Z
/*      */     //   1650: ifne -> 1978
/*      */     //   1653: aload_0
/*      */     //   1654: invokevirtual isInsideFieldInitialization : ()Z
/*      */     //   1657: ifne -> 1978
/*      */     //   1660: aload_0
/*      */     //   1661: getfield genericsPtr : I
/*      */     //   1664: iconst_m1
/*      */     //   1665: if_icmple -> 1978
/*      */     //   1668: aload_0
/*      */     //   1669: getfield genericsLengthPtr : I
/*      */     //   1672: iconst_m1
/*      */     //   1673: if_icmple -> 1978
/*      */     //   1676: aload_0
/*      */     //   1677: getfield genericsIdentifiersLengthPtr : I
/*      */     //   1680: iconst_m1
/*      */     //   1681: if_icmple -> 1978
/*      */     //   1684: aload_0
/*      */     //   1685: sipush #1536
/*      */     //   1688: invokevirtual topKnownElementKind : (I)I
/*      */     //   1691: istore_1
/*      */     //   1692: aload_0
/*      */     //   1693: sipush #1536
/*      */     //   1696: invokevirtual topKnownElementInfo : (I)I
/*      */     //   1699: istore_2
/*      */     //   1700: iload_1
/*      */     //   1701: sipush #1040
/*      */     //   1704: if_icmpne -> 1716
/*      */     //   1707: iload_2
/*      */     //   1708: iconst_4
/*      */     //   1709: if_icmpne -> 1716
/*      */     //   1712: aload_0
/*      */     //   1713: invokevirtual consumeTypeArguments : ()V
/*      */     //   1716: aload_0
/*      */     //   1717: getfield genericsIdentifiersLengthStack : [I
/*      */     //   1720: aload_0
/*      */     //   1721: getfield genericsIdentifiersLengthPtr : I
/*      */     //   1724: iaload
/*      */     //   1725: istore_3
/*      */     //   1726: aload_0
/*      */     //   1727: getfield genericsPtr : I
/*      */     //   1730: istore #4
/*      */     //   1732: iconst_0
/*      */     //   1733: istore #5
/*      */     //   1735: goto -> 1889
/*      */     //   1738: aload_0
/*      */     //   1739: getfield identifierLengthStack : [I
/*      */     //   1742: aload_0
/*      */     //   1743: getfield identifierLengthPtr : I
/*      */     //   1746: iload #5
/*      */     //   1748: isub
/*      */     //   1749: iaload
/*      */     //   1750: istore #6
/*      */     //   1752: aload_0
/*      */     //   1753: getfield genericsLengthStack : [I
/*      */     //   1756: aload_0
/*      */     //   1757: getfield genericsLengthPtr : I
/*      */     //   1760: iload #5
/*      */     //   1762: isub
/*      */     //   1763: iaload
/*      */     //   1764: istore #7
/*      */     //   1766: iconst_0
/*      */     //   1767: istore #8
/*      */     //   1769: goto -> 1867
/*      */     //   1772: aload_0
/*      */     //   1773: getfield genericsStack : [Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1776: iload #4
/*      */     //   1778: iload #8
/*      */     //   1780: isub
/*      */     //   1781: aaload
/*      */     //   1782: astore #9
/*      */     //   1784: new org/eclipse/jdt/internal/codeassist/complete/CompletionNodeDetector
/*      */     //   1787: dup
/*      */     //   1788: aload_0
/*      */     //   1789: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1792: aload #9
/*      */     //   1794: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;)V
/*      */     //   1797: astore #10
/*      */     //   1799: aload #10
/*      */     //   1801: invokevirtual containsCompletionNode : ()Z
/*      */     //   1804: ifeq -> 1864
/*      */     //   1807: aload #9
/*      */     //   1809: aload_0
/*      */     //   1810: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1813: if_acmpne -> 1852
/*      */     //   1816: aload_0
/*      */     //   1817: getfield identifierLengthPtr : I
/*      */     //   1820: iconst_m1
/*      */     //   1821: if_icmple -> 1902
/*      */     //   1824: aload_0
/*      */     //   1825: getfield identifierLengthStack : [I
/*      */     //   1828: aload_0
/*      */     //   1829: getfield identifierLengthPtr : I
/*      */     //   1832: iaload
/*      */     //   1833: ifeq -> 1902
/*      */     //   1836: aload_0
/*      */     //   1837: iconst_0
/*      */     //   1838: invokevirtual getTypeReference : (I)Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   1841: astore #11
/*      */     //   1843: aload_0
/*      */     //   1844: aload #11
/*      */     //   1846: putfield assistNodeParent : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1849: goto -> 1902
/*      */     //   1852: aload_0
/*      */     //   1853: aload #10
/*      */     //   1855: invokevirtual getCompletionNodeParent : ()Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1858: putfield assistNodeParent : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1861: goto -> 1902
/*      */     //   1864: iinc #8, 1
/*      */     //   1867: iload #8
/*      */     //   1869: iload #7
/*      */     //   1871: if_icmplt -> 1772
/*      */     //   1874: iload #4
/*      */     //   1876: iload #7
/*      */     //   1878: isub
/*      */     //   1879: istore #4
/*      */     //   1881: iload_3
/*      */     //   1882: iload #6
/*      */     //   1884: isub
/*      */     //   1885: istore_3
/*      */     //   1886: iinc #5, 1
/*      */     //   1889: iload #5
/*      */     //   1891: aload_0
/*      */     //   1892: getfield identifierLengthPtr : I
/*      */     //   1895: if_icmpgt -> 1902
/*      */     //   1898: iload_3
/*      */     //   1899: ifgt -> 1738
/*      */     //   1902: aload_0
/*      */     //   1903: getfield assistNodeParent : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1906: ifnull -> 1978
/*      */     //   1909: aload_0
/*      */     //   1910: getfield assistNodeParent : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1913: instanceof org/eclipse/jdt/internal/compiler/ast/TypeReference
/*      */     //   1916: ifeq -> 1978
/*      */     //   1919: aload_0
/*      */     //   1920: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   1923: instanceof org/eclipse/jdt/internal/compiler/parser/RecoveredType
/*      */     //   1926: ifeq -> 1959
/*      */     //   1929: aload_0
/*      */     //   1930: aload_0
/*      */     //   1931: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   1934: new org/eclipse/jdt/internal/codeassist/complete/CompletionOnFieldType
/*      */     //   1937: dup
/*      */     //   1938: aload_0
/*      */     //   1939: getfield assistNodeParent : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1942: checkcast org/eclipse/jdt/internal/compiler/ast/TypeReference
/*      */     //   1945: iconst_0
/*      */     //   1946: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;Z)V
/*      */     //   1949: iconst_0
/*      */     //   1950: invokevirtual add : (Lorg/eclipse/jdt/internal/compiler/ast/FieldDeclaration;I)Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   1953: putfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   1956: goto -> 1978
/*      */     //   1959: aload_0
/*      */     //   1960: aload_0
/*      */     //   1961: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   1964: aload_0
/*      */     //   1965: getfield assistNodeParent : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1968: checkcast org/eclipse/jdt/internal/compiler/ast/TypeReference
/*      */     //   1971: iconst_0
/*      */     //   1972: invokevirtual add : (Lorg/eclipse/jdt/internal/compiler/ast/Statement;I)Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   1975: putfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   1978: aload_0
/*      */     //   1979: invokevirtual isInsideMethod : ()Z
/*      */     //   1982: ifne -> 2000
/*      */     //   1985: aload_0
/*      */     //   1986: invokevirtual isInsideFieldInitialization : ()Z
/*      */     //   1989: ifne -> 2000
/*      */     //   1992: aload_0
/*      */     //   1993: invokevirtual isInsideAttributeValue : ()Z
/*      */     //   1996: ifne -> 2000
/*      */     //   1999: return
/*      */     //   2000: aload_0
/*      */     //   2001: getfield assistNodeParent : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2004: instanceof org/eclipse/jdt/internal/codeassist/complete/AssistNodeParentAnnotationArrayInitializer
/*      */     //   2007: ifeq -> 2011
/*      */     //   2010: return
/*      */     //   2011: aload_0
/*      */     //   2012: getfield genericsPtr : I
/*      */     //   2015: iconst_m1
/*      */     //   2016: if_icmple -> 2145
/*      */     //   2019: aload_0
/*      */     //   2020: getfield genericsStack : [Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2023: aload_0
/*      */     //   2024: getfield genericsPtr : I
/*      */     //   2027: aaload
/*      */     //   2028: astore_1
/*      */     //   2029: new org/eclipse/jdt/internal/codeassist/complete/CompletionNodeDetector
/*      */     //   2032: dup
/*      */     //   2033: aload_0
/*      */     //   2034: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2037: aload_1
/*      */     //   2038: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;)V
/*      */     //   2041: astore_2
/*      */     //   2042: aload_2
/*      */     //   2043: invokevirtual containsCompletionNode : ()Z
/*      */     //   2046: ifeq -> 2145
/*      */     //   2049: aload_0
/*      */     //   2050: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   2053: invokevirtual enclosingMethod : ()Lorg/eclipse/jdt/internal/compiler/parser/RecoveredMethod;
/*      */     //   2056: astore_3
/*      */     //   2057: aload_3
/*      */     //   2058: ifnull -> 2131
/*      */     //   2061: aload_3
/*      */     //   2062: getfield methodDeclaration : Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;
/*      */     //   2065: astore #4
/*      */     //   2067: aload #4
/*      */     //   2069: getfield bodyStart : I
/*      */     //   2072: aload #4
/*      */     //   2074: getfield sourceEnd : I
/*      */     //   2077: iconst_1
/*      */     //   2078: iadd
/*      */     //   2079: if_icmpne -> 2131
/*      */     //   2082: aload_1
/*      */     //   2083: getfield sourceStart : I
/*      */     //   2086: aload_0
/*      */     //   2087: getfield scanner : Lorg/eclipse/jdt/internal/compiler/parser/Scanner;
/*      */     //   2090: getfield lineEnds : [I
/*      */     //   2093: iconst_0
/*      */     //   2094: aload_0
/*      */     //   2095: getfield scanner : Lorg/eclipse/jdt/internal/compiler/parser/Scanner;
/*      */     //   2098: getfield linePtr : I
/*      */     //   2101: invokestatic getLineNumber : (I[III)I
/*      */     //   2104: aload #4
/*      */     //   2106: getfield sourceEnd : I
/*      */     //   2109: aload_0
/*      */     //   2110: getfield scanner : Lorg/eclipse/jdt/internal/compiler/parser/Scanner;
/*      */     //   2113: getfield lineEnds : [I
/*      */     //   2116: iconst_0
/*      */     //   2117: aload_0
/*      */     //   2118: getfield scanner : Lorg/eclipse/jdt/internal/compiler/parser/Scanner;
/*      */     //   2121: getfield linePtr : I
/*      */     //   2124: invokestatic getLineNumber : (I[III)I
/*      */     //   2127: if_icmpne -> 2131
/*      */     //   2130: return
/*      */     //   2131: aload_1
/*      */     //   2132: aload_0
/*      */     //   2133: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2136: if_acmpne -> 2145
/*      */     //   2139: aload_0
/*      */     //   2140: aload_1
/*      */     //   2141: iconst_1
/*      */     //   2142: invokevirtual buildMoreGenericsCompletionContext : (Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Z)V
/*      */     //   2145: aload_0
/*      */     //   2146: getfield expressionPtr : I
/*      */     //   2149: iconst_m1
/*      */     //   2150: if_icmple -> 2475
/*      */     //   2153: aload_0
/*      */     //   2154: getfield expressionStack : [Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   2157: aload_0
/*      */     //   2158: getfield expressionPtr : I
/*      */     //   2161: aaload
/*      */     //   2162: astore_1
/*      */     //   2163: new org/eclipse/jdt/internal/codeassist/complete/CompletionNodeDetector
/*      */     //   2166: dup
/*      */     //   2167: aload_0
/*      */     //   2168: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2171: aload_1
/*      */     //   2172: invokespecial <init> : (Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;)V
/*      */     //   2175: astore_2
/*      */     //   2176: aload_2
/*      */     //   2177: invokevirtual containsCompletionNode : ()Z
/*      */     //   2180: ifeq -> 2475
/*      */     //   2183: aload_0
/*      */     //   2184: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   2187: invokevirtual enclosingMethod : ()Lorg/eclipse/jdt/internal/compiler/parser/RecoveredMethod;
/*      */     //   2190: astore_3
/*      */     //   2191: aload_3
/*      */     //   2192: ifnull -> 2265
/*      */     //   2195: aload_3
/*      */     //   2196: getfield methodDeclaration : Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;
/*      */     //   2199: astore #4
/*      */     //   2201: aload #4
/*      */     //   2203: getfield bodyStart : I
/*      */     //   2206: aload #4
/*      */     //   2208: getfield sourceEnd : I
/*      */     //   2211: iconst_1
/*      */     //   2212: iadd
/*      */     //   2213: if_icmpne -> 2265
/*      */     //   2216: aload_1
/*      */     //   2217: getfield sourceStart : I
/*      */     //   2220: aload_0
/*      */     //   2221: getfield scanner : Lorg/eclipse/jdt/internal/compiler/parser/Scanner;
/*      */     //   2224: getfield lineEnds : [I
/*      */     //   2227: iconst_0
/*      */     //   2228: aload_0
/*      */     //   2229: getfield scanner : Lorg/eclipse/jdt/internal/compiler/parser/Scanner;
/*      */     //   2232: getfield linePtr : I
/*      */     //   2235: invokestatic getLineNumber : (I[III)I
/*      */     //   2238: aload #4
/*      */     //   2240: getfield sourceEnd : I
/*      */     //   2243: aload_0
/*      */     //   2244: getfield scanner : Lorg/eclipse/jdt/internal/compiler/parser/Scanner;
/*      */     //   2247: getfield lineEnds : [I
/*      */     //   2250: iconst_0
/*      */     //   2251: aload_0
/*      */     //   2252: getfield scanner : Lorg/eclipse/jdt/internal/compiler/parser/Scanner;
/*      */     //   2255: getfield linePtr : I
/*      */     //   2258: invokestatic getLineNumber : (I[III)I
/*      */     //   2261: if_icmpne -> 2265
/*      */     //   2264: return
/*      */     //   2265: aload_1
/*      */     //   2266: aload_0
/*      */     //   2267: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2270: if_acmpeq -> 2411
/*      */     //   2273: aload_1
/*      */     //   2274: instanceof org/eclipse/jdt/internal/compiler/ast/Assignment
/*      */     //   2277: ifeq -> 2340
/*      */     //   2280: aload_1
/*      */     //   2281: checkcast org/eclipse/jdt/internal/compiler/ast/Assignment
/*      */     //   2284: getfield expression : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   2287: aload_0
/*      */     //   2288: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2291: if_acmpne -> 2340
/*      */     //   2294: aload_0
/*      */     //   2295: getfield expressionPtr : I
/*      */     //   2298: ifle -> 2318
/*      */     //   2301: aload_0
/*      */     //   2302: aload_0
/*      */     //   2303: getfield expressionStack : [Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   2306: aload_0
/*      */     //   2307: getfield expressionPtr : I
/*      */     //   2310: iconst_1
/*      */     //   2311: isub
/*      */     //   2312: invokevirtual stackHasInstanceOfExpression : ([Ljava/lang/Object;I)Z
/*      */     //   2315: ifne -> 2411
/*      */     //   2318: aload_0
/*      */     //   2319: getfield elementPtr : I
/*      */     //   2322: iflt -> 2340
/*      */     //   2325: aload_0
/*      */     //   2326: aload_0
/*      */     //   2327: getfield elementObjectInfoStack : [Ljava/lang/Object;
/*      */     //   2330: aload_0
/*      */     //   2331: getfield elementPtr : I
/*      */     //   2334: invokevirtual stackHasInstanceOfExpression : ([Ljava/lang/Object;I)Z
/*      */     //   2337: ifne -> 2411
/*      */     //   2340: aload_1
/*      */     //   2341: instanceof org/eclipse/jdt/internal/compiler/ast/AllocationExpression
/*      */     //   2344: ifeq -> 2361
/*      */     //   2347: aload_1
/*      */     //   2348: checkcast org/eclipse/jdt/internal/compiler/ast/AllocationExpression
/*      */     //   2351: getfield type : Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   2354: aload_0
/*      */     //   2355: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2358: if_acmpeq -> 2411
/*      */     //   2361: aload_1
/*      */     //   2362: instanceof org/eclipse/jdt/internal/compiler/ast/AND_AND_Expression
/*      */     //   2365: ifeq -> 2390
/*      */     //   2368: aload_0
/*      */     //   2369: getfield elementPtr : I
/*      */     //   2372: iflt -> 2390
/*      */     //   2375: aload_0
/*      */     //   2376: getfield elementObjectInfoStack : [Ljava/lang/Object;
/*      */     //   2379: aload_0
/*      */     //   2380: getfield elementPtr : I
/*      */     //   2383: aaload
/*      */     //   2384: instanceof org/eclipse/jdt/internal/compiler/ast/InstanceOfExpression
/*      */     //   2387: ifne -> 2411
/*      */     //   2390: aload_1
/*      */     //   2391: instanceof org/eclipse/jdt/internal/compiler/ast/ConditionalExpression
/*      */     //   2394: ifeq -> 2439
/*      */     //   2397: aload_1
/*      */     //   2398: checkcast org/eclipse/jdt/internal/compiler/ast/ConditionalExpression
/*      */     //   2401: getfield valueIfFalse : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   2404: aload_0
/*      */     //   2405: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2408: if_acmpne -> 2439
/*      */     //   2411: aload_0
/*      */     //   2412: aload_1
/*      */     //   2413: invokevirtual buildMoreCompletionContext : (Lorg/eclipse/jdt/internal/compiler/ast/Expression;)V
/*      */     //   2416: aload_0
/*      */     //   2417: getfield assistNodeParent : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2420: ifnonnull -> 2438
/*      */     //   2423: aload_1
/*      */     //   2424: instanceof org/eclipse/jdt/internal/compiler/ast/Assignment
/*      */     //   2427: ifeq -> 2438
/*      */     //   2430: aload_0
/*      */     //   2431: aload_2
/*      */     //   2432: invokevirtual getCompletionNodeParent : ()Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2435: putfield assistNodeParent : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2438: return
/*      */     //   2439: aload_0
/*      */     //   2440: aload_2
/*      */     //   2441: invokevirtual getCompletionNodeParent : ()Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2444: putfield assistNodeParent : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2447: aload_2
/*      */     //   2448: invokevirtual getCompletionNodeOuterExpression : ()Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   2451: astore #4
/*      */     //   2453: aload #4
/*      */     //   2455: ifnull -> 2461
/*      */     //   2458: aload #4
/*      */     //   2460: astore_1
/*      */     //   2461: aload_0
/*      */     //   2462: aload_0
/*      */     //   2463: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   2466: aload_1
/*      */     //   2467: iconst_0
/*      */     //   2468: invokevirtual add : (Lorg/eclipse/jdt/internal/compiler/ast/Statement;I)Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   2471: putfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   2474: return
/*      */     //   2475: aload_0
/*      */     //   2476: getfield astPtr : I
/*      */     //   2479: iconst_m1
/*      */     //   2480: if_icmple -> 2586
/*      */     //   2483: aload_0
/*      */     //   2484: getfield astStack : [Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2487: aload_0
/*      */     //   2488: getfield astPtr : I
/*      */     //   2491: aaload
/*      */     //   2492: instanceof org/eclipse/jdt/internal/compiler/ast/LocalDeclaration
/*      */     //   2495: ifeq -> 2586
/*      */     //   2498: aload_0
/*      */     //   2499: getfield astStack : [Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2502: aload_0
/*      */     //   2503: getfield astPtr : I
/*      */     //   2506: aaload
/*      */     //   2507: checkcast org/eclipse/jdt/internal/compiler/ast/LocalDeclaration
/*      */     //   2510: astore_2
/*      */     //   2511: aload_2
/*      */     //   2512: getfield initialization : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   2515: aload_0
/*      */     //   2516: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2519: if_acmpne -> 2586
/*      */     //   2522: aload_0
/*      */     //   2523: aload_2
/*      */     //   2524: invokevirtual buildMoreCompletionEnclosingContext : (Lorg/eclipse/jdt/internal/compiler/ast/Statement;)Lorg/eclipse/jdt/internal/compiler/ast/Statement;
/*      */     //   2527: astore_3
/*      */     //   2528: aload_3
/*      */     //   2529: instanceof org/eclipse/jdt/internal/compiler/ast/IfStatement
/*      */     //   2532: ifeq -> 2586
/*      */     //   2535: aload_0
/*      */     //   2536: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   2539: instanceof org/eclipse/jdt/internal/compiler/parser/RecoveredBlock
/*      */     //   2542: ifeq -> 2586
/*      */     //   2545: aload_0
/*      */     //   2546: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   2549: checkcast org/eclipse/jdt/internal/compiler/parser/RecoveredBlock
/*      */     //   2552: astore #4
/*      */     //   2554: aload #4
/*      */     //   2556: getfield statements : [Lorg/eclipse/jdt/internal/compiler/parser/RecoveredStatement;
/*      */     //   2559: aload #4
/*      */     //   2561: dup
/*      */     //   2562: getfield statementCount : I
/*      */     //   2565: iconst_1
/*      */     //   2566: isub
/*      */     //   2567: dup_x1
/*      */     //   2568: putfield statementCount : I
/*      */     //   2571: aconst_null
/*      */     //   2572: aastore
/*      */     //   2573: aload_0
/*      */     //   2574: aload_0
/*      */     //   2575: getfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   2578: aload_3
/*      */     //   2579: iconst_0
/*      */     //   2580: invokevirtual add : (Lorg/eclipse/jdt/internal/compiler/ast/Statement;I)Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   2583: putfield currentElement : Lorg/eclipse/jdt/internal/compiler/parser/RecoveredElement;
/*      */     //   2586: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #358	-> 0
/*      */     //   #360	-> 15
/*      */     //   #362	-> 20
/*      */     //   #363	-> 27
/*      */     //   #364	-> 32
/*      */     //   #366	-> 37
/*      */     //   #367	-> 47
/*      */     //   #368	-> 54
/*      */     //   #369	-> 67
/*      */     //   #370	-> 77
/*      */     //   #372	-> 90
/*      */     //   #373	-> 103
/*      */     //   #375	-> 111
/*      */     //   #376	-> 119
/*      */     //   #378	-> 130
/*      */     //   #379	-> 137
/*      */     //   #383	-> 145
/*      */     //   #384	-> 154
/*      */     //   #385	-> 163
/*      */     //   #386	-> 185
/*      */     //   #387	-> 197
/*      */     //   #389	-> 201
/*      */     //   #390	-> 206
/*      */     //   #391	-> 210
/*      */     //   #392	-> 217
/*      */     //   #393	-> 223
/*      */     //   #394	-> 226
/*      */     //   #397	-> 232
/*      */     //   #398	-> 238
/*      */     //   #397	-> 239
/*      */     //   #403	-> 244
/*      */     //   #404	-> 259
/*      */     //   #406	-> 274
/*      */     //   #407	-> 278
/*      */     //   #408	-> 287
/*      */     //   #409	-> 298
/*      */     //   #410	-> 299
/*      */     //   #405	-> 301
/*      */     //   #414	-> 304
/*      */     //   #415	-> 334
/*      */     //   #416	-> 352
/*      */     //   #417	-> 368
/*      */     //   #420	-> 384
/*      */     //   #421	-> 398
/*      */     //   #426	-> 399
/*      */     //   #427	-> 409
/*      */     //   #429	-> 417
/*      */     //   #431	-> 424
/*      */     //   #432	-> 431
/*      */     //   #433	-> 439
/*      */     //   #432	-> 452
/*      */     //   #434	-> 458
/*      */     //   #437	-> 459
/*      */     //   #439	-> 466
/*      */     //   #440	-> 470
/*      */     //   #441	-> 473
/*      */     //   #442	-> 480
/*      */     //   #439	-> 484
/*      */     //   #438	-> 487
/*      */     //   #443	-> 488
/*      */     //   #444	-> 493
/*      */     //   #445	-> 506
/*      */     //   #446	-> 511
/*      */     //   #451	-> 512
/*      */     //   #452	-> 519
/*      */     //   #453	-> 527
/*      */     //   #456	-> 528
/*      */     //   #457	-> 535
/*      */     //   #460	-> 539
/*      */     //   #461	-> 543
/*      */     //   #462	-> 546
/*      */     //   #463	-> 553
/*      */     //   #460	-> 557
/*      */     //   #459	-> 560
/*      */     //   #464	-> 561
/*      */     //   #466	-> 571
/*      */     //   #467	-> 578
/*      */     //   #470	-> 583
/*      */     //   #473	-> 584
/*      */     //   #474	-> 597
/*      */     //   #475	-> 607
/*      */     //   #476	-> 620
/*      */     //   #477	-> 631
/*      */     //   #478	-> 632
/*      */     //   #479	-> 642
/*      */     //   #480	-> 655
/*      */     //   #481	-> 666
/*      */     //   #482	-> 667
/*      */     //   #483	-> 677
/*      */     //   #484	-> 690
/*      */     //   #485	-> 701
/*      */     //   #490	-> 702
/*      */     //   #494	-> 709
/*      */     //   #495	-> 717
/*      */     //   #496	-> 721
/*      */     //   #497	-> 726
/*      */     //   #498	-> 739
/*      */     //   #499	-> 761
/*      */     //   #498	-> 783
/*      */     //   #500	-> 786
/*      */     //   #504	-> 787
/*      */     //   #505	-> 803
/*      */     //   #509	-> 804
/*      */     //   #512	-> 811
/*      */     //   #513	-> 819
/*      */     //   #514	-> 829
/*      */     //   #515	-> 837
/*      */     //   #516	-> 850
/*      */     //   #517	-> 858
/*      */     //   #518	-> 870
/*      */     //   #519	-> 874
/*      */     //   #520	-> 888
/*      */     //   #521	-> 895
/*      */     //   #522	-> 905
/*      */     //   #523	-> 923
/*      */     //   #526	-> 934
/*      */     //   #527	-> 943
/*      */     //   #526	-> 948
/*      */     //   #530	-> 953
/*      */     //   #531	-> 961
/*      */     //   #533	-> 971
/*      */     //   #535	-> 977
/*      */     //   #536	-> 1004
/*      */     //   #538	-> 1018
/*      */     //   #539	-> 1025
/*      */     //   #538	-> 1034
/*      */     //   #541	-> 1039
/*      */     //   #542	-> 1050
/*      */     //   #543	-> 1056
/*      */     //   #544	-> 1070
/*      */     //   #545	-> 1086
/*      */     //   #546	-> 1093
/*      */     //   #547	-> 1098
/*      */     //   #549	-> 1118
/*      */     //   #550	-> 1123
/*      */     //   #551	-> 1124
/*      */     //   #553	-> 1138
/*      */     //   #552	-> 1157
/*      */     //   #554	-> 1158
/*      */     //   #556	-> 1163
/*      */     //   #558	-> 1166
/*      */     //   #559	-> 1179
/*      */     //   #560	-> 1186
/*      */     //   #561	-> 1192
/*      */     //   #562	-> 1198
/*      */     //   #563	-> 1201
/*      */     //   #562	-> 1216
/*      */     //   #566	-> 1222
/*      */     //   #568	-> 1229
/*      */     //   #569	-> 1235
/*      */     //   #571	-> 1241
/*      */     //   #572	-> 1251
/*      */     //   #573	-> 1255
/*      */     //   #574	-> 1271
/*      */     //   #575	-> 1275
/*      */     //   #576	-> 1279
/*      */     //   #572	-> 1280
/*      */     //   #578	-> 1285
/*      */     //   #579	-> 1291
/*      */     //   #583	-> 1292
/*      */     //   #584	-> 1305
/*      */     //   #586	-> 1312
/*      */     //   #585	-> 1331
/*      */     //   #587	-> 1332
/*      */     //   #592	-> 1337
/*      */     //   #593	-> 1345
/*      */     //   #594	-> 1355
/*      */     //   #595	-> 1362
/*      */     //   #596	-> 1367
/*      */     //   #597	-> 1381
/*      */     //   #598	-> 1389
/*      */     //   #599	-> 1394
/*      */     //   #600	-> 1403
/*      */     //   #606	-> 1404
/*      */     //   #607	-> 1412
/*      */     //   #608	-> 1422
/*      */     //   #609	-> 1443
/*      */     //   #610	-> 1451
/*      */     //   #611	-> 1458
/*      */     //   #612	-> 1466
/*      */     //   #613	-> 1471
/*      */     //   #614	-> 1477
/*      */     //   #617	-> 1478
/*      */     //   #618	-> 1498
/*      */     //   #619	-> 1506
/*      */     //   #620	-> 1512
/*      */     //   #625	-> 1513
/*      */     //   #626	-> 1533
/*      */     //   #627	-> 1543
/*      */     //   #628	-> 1551
/*      */     //   #629	-> 1566
/*      */     //   #630	-> 1581
/*      */     //   #631	-> 1594
/*      */     //   #632	-> 1607
/*      */     //   #633	-> 1614
/*      */     //   #635	-> 1645
/*      */     //   #640	-> 1646
/*      */     //   #641	-> 1660
/*      */     //   #642	-> 1684
/*      */     //   #643	-> 1692
/*      */     //   #644	-> 1700
/*      */     //   #645	-> 1712
/*      */     //   #647	-> 1716
/*      */     //   #648	-> 1726
/*      */     //   #649	-> 1732
/*      */     //   #650	-> 1738
/*      */     //   #651	-> 1752
/*      */     //   #652	-> 1766
/*      */     //   #653	-> 1772
/*      */     //   #654	-> 1784
/*      */     //   #655	-> 1799
/*      */     //   #656	-> 1807
/*      */     //   #657	-> 1816
/*      */     //   #658	-> 1836
/*      */     //   #659	-> 1843
/*      */     //   #661	-> 1849
/*      */     //   #662	-> 1852
/*      */     //   #664	-> 1861
/*      */     //   #652	-> 1864
/*      */     //   #667	-> 1874
/*      */     //   #668	-> 1881
/*      */     //   #649	-> 1886
/*      */     //   #670	-> 1902
/*      */     //   #671	-> 1919
/*      */     //   #672	-> 1929
/*      */     //   #673	-> 1956
/*      */     //   #674	-> 1959
/*      */     //   #682	-> 1978
/*      */     //   #683	-> 1999
/*      */     //   #685	-> 2000
/*      */     //   #686	-> 2010
/*      */     //   #689	-> 2011
/*      */     //   #690	-> 2019
/*      */     //   #691	-> 2029
/*      */     //   #692	-> 2042
/*      */     //   #696	-> 2049
/*      */     //   #697	-> 2057
/*      */     //   #698	-> 2061
/*      */     //   #699	-> 2067
/*      */     //   #700	-> 2082
/*      */     //   #701	-> 2104
/*      */     //   #700	-> 2127
/*      */     //   #702	-> 2130
/*      */     //   #705	-> 2131
/*      */     //   #706	-> 2139
/*      */     //   #713	-> 2145
/*      */     //   #714	-> 2153
/*      */     //   #715	-> 2163
/*      */     //   #716	-> 2176
/*      */     //   #720	-> 2183
/*      */     //   #721	-> 2191
/*      */     //   #722	-> 2195
/*      */     //   #723	-> 2201
/*      */     //   #724	-> 2216
/*      */     //   #725	-> 2238
/*      */     //   #724	-> 2261
/*      */     //   #726	-> 2264
/*      */     //   #729	-> 2265
/*      */     //   #730	-> 2273
/*      */     //   #731	-> 2280
/*      */     //   #732	-> 2294
/*      */     //   #734	-> 2318
/*      */     //   #735	-> 2340
/*      */     //   #736	-> 2347
/*      */     //   #737	-> 2361
/*      */     //   #738	-> 2368
/*      */     //   #739	-> 2390
/*      */     //   #740	-> 2397
/*      */     //   #741	-> 2411
/*      */     //   #742	-> 2416
/*      */     //   #743	-> 2423
/*      */     //   #744	-> 2430
/*      */     //   #746	-> 2438
/*      */     //   #748	-> 2439
/*      */     //   #749	-> 2447
/*      */     //   #750	-> 2453
/*      */     //   #751	-> 2458
/*      */     //   #753	-> 2461
/*      */     //   #754	-> 2474
/*      */     //   #758	-> 2475
/*      */     //   #760	-> 2498
/*      */     //   #761	-> 2511
/*      */     //   #762	-> 2522
/*      */     //   #763	-> 2528
/*      */     //   #764	-> 2535
/*      */     //   #766	-> 2545
/*      */     //   #767	-> 2554
/*      */     //   #768	-> 2573
/*      */     //   #773	-> 2586
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	2587	0	this	Lorg/eclipse/jdt/internal/codeassist/complete/CompletionParser;
/*      */     //   32	772	1	orphan	Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   111	288	2	recoveredType	Lorg/eclipse/jdt/internal/compiler/parser/RecoveredType;
/*      */     //   119	280	3	isAtRecordType	Z
/*      */     //   217	9	4	fieldType	Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   232	167	4	fieldType	Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   154	245	5	kind	I
/*      */     //   163	236	6	info	I
/*      */     //   244	155	7	fieldDeclaration	Lorg/eclipse/jdt/internal/codeassist/complete/CompletionOnFieldType;
/*      */     //   256	143	8	length	I
/*      */     //   417	95	2	recoveredMethod	Lorg/eclipse/jdt/internal/compiler/parser/RecoveredMethod;
/*      */     //   488	24	3	fakeType	Lorg/eclipse/jdt/internal/codeassist/complete/CompletionOnAnnotationOfType;
/*      */     //   561	23	2	fakeType	Lorg/eclipse/jdt/internal/codeassist/complete/CompletionOnAnnotationOfType;
/*      */     //   717	87	2	method	Lorg/eclipse/jdt/internal/compiler/parser/RecoveredMethod;
/*      */     //   726	61	3	methodDecl	Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;
/*      */     //   829	508	1	expression	Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   858	212	2	arrayInitializer	Lorg/eclipse/jdt/internal/compiler/ast/ArrayInitializer;
/*      */     //   874	196	3	memberValueName	[C
/*      */     //   923	11	4	length	I
/*      */     //   953	117	4	memberValuePair	Lorg/eclipse/jdt/internal/compiler/ast/MemberValuePair;
/*      */     //   977	93	5	typeReference	Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   1004	66	6	annotation	Lorg/eclipse/jdt/internal/compiler/ast/NormalAnnotation;
/*      */     //   1039	31	7	fakeType	Lorg/eclipse/jdt/internal/codeassist/complete/CompletionOnAnnotationOfType;
/*      */     //   1098	26	2	nameReference	Lorg/eclipse/jdt/internal/compiler/ast/SingleNameReference;
/*      */     //   1118	6	3	memberValueName	Lorg/eclipse/jdt/internal/codeassist/complete/CompletionOnMemberValueName;
/*      */     //   1158	5	2	valuePair	Lorg/eclipse/jdt/internal/compiler/ast/MemberValuePair;
/*      */     //   1175	117	2	index	I
/*      */     //   1186	106	3	attributeIndentifierPtr	I
/*      */     //   1192	100	4	identLengthPtr	I
/*      */     //   1198	94	5	identPtr	I
/*      */     //   1285	7	6	memberValuePair	Lorg/eclipse/jdt/internal/compiler/ast/MemberValuePair;
/*      */     //   1305	32	2	detector	Lorg/eclipse/jdt/internal/codeassist/complete/CompletionNodeDetector;
/*      */     //   1332	5	3	valuePair	Lorg/eclipse/jdt/internal/compiler/ast/MemberValuePair;
/*      */     //   1355	49	2	node	Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1367	37	3	memberValuePair	Lorg/eclipse/jdt/internal/compiler/ast/MemberValuePair;
/*      */     //   1381	23	4	detector	Lorg/eclipse/jdt/internal/codeassist/complete/CompletionNodeDetector;
/*      */     //   1422	91	1	node	Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1451	62	2	kind	I
/*      */     //   1466	12	3	info	I
/*      */     //   1551	95	1	recoveredType	Lorg/eclipse/jdt/internal/compiler/parser/RecoveredType;
/*      */     //   1594	52	2	typeParameter	Lorg/eclipse/jdt/internal/compiler/ast/TypeParameter;
/*      */     //   1607	39	3	detector	Lorg/eclipse/jdt/internal/codeassist/complete/CompletionNodeDetector;
/*      */     //   1692	286	1	kind	I
/*      */     //   1700	278	2	info	I
/*      */     //   1726	252	3	numberOfIdentifiers	I
/*      */     //   1732	246	4	genPtr	I
/*      */     //   1735	167	5	i	I
/*      */     //   1752	134	6	identifierLength	I
/*      */     //   1766	120	7	length	I
/*      */     //   1769	105	8	j	I
/*      */     //   1784	80	9	node	Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   1799	65	10	detector	Lorg/eclipse/jdt/internal/codeassist/complete/CompletionNodeDetector;
/*      */     //   1843	6	11	ref	Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   2029	116	1	node	Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   2042	103	2	detector	Lorg/eclipse/jdt/internal/codeassist/complete/CompletionNodeDetector;
/*      */     //   2057	88	3	method	Lorg/eclipse/jdt/internal/compiler/parser/RecoveredMethod;
/*      */     //   2067	64	4	methodDecl	Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;
/*      */     //   2163	312	1	expression	Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   2176	299	2	detector	Lorg/eclipse/jdt/internal/codeassist/complete/CompletionNodeDetector;
/*      */     //   2191	284	3	method	Lorg/eclipse/jdt/internal/compiler/parser/RecoveredMethod;
/*      */     //   2201	64	4	methodDecl	Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;
/*      */     //   2453	22	4	outerExpression	Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   2511	75	2	local	Lorg/eclipse/jdt/internal/compiler/ast/LocalDeclaration;
/*      */     //   2528	58	3	enclosing	Lorg/eclipse/jdt/internal/compiler/ast/Statement;
/*      */     //   2554	32	4	recoveredBlock	Lorg/eclipse/jdt/internal/compiler/parser/RecoveredBlock;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class SavedState
/*      */   {
/*      */     final ASTNode assistNodeParent;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final int parserCursorLocation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final int scannerCursorLocation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public SavedState(int parserCursorLocation, int scannerCursorLocation, ASTNode assistNodeParent) {
/*  781 */       this.parserCursorLocation = parserCursorLocation;
/*  782 */       this.scannerCursorLocation = scannerCursorLocation;
/*  783 */       this.assistNodeParent = assistNodeParent;
/*      */     }
/*      */   }
/*      */   
/*      */   public Object becomeSimpleParser() {
/*  788 */     CompletionScanner completionScanner = (CompletionScanner)this.scanner;
/*  789 */     SavedState parserState = new SavedState(this.cursorLocation, completionScanner.cursorLocation, this.assistNodeParent);
/*      */     
/*  791 */     this.cursorLocation = Integer.MAX_VALUE;
/*  792 */     completionScanner.cursorLocation = Integer.MAX_VALUE;
/*      */     
/*  794 */     return parserState;
/*      */   } private void buildMoreAnnotationCompletionContext(MemberValuePair memberValuePair) {
/*      */     NormalAnnotation annotation;
/*  797 */     if (this.identifierPtr < 0 || this.identifierLengthPtr < 0)
/*      */       return; 
/*  799 */     TypeReference typeReference = getAnnotationType();
/*      */     
/*  801 */     int nodesToRemove = (this.astPtr > -1 && this.astStack[this.astPtr] == memberValuePair) ? 1 : 0;
/*      */ 
/*      */     
/*  804 */     if (memberValuePair instanceof CompletionOnMemberValueName) {
/*  805 */       MemberValuePair[] memberValuePairs = null;
/*      */       int length;
/*  807 */       if (this.astLengthPtr > -1 && (length = this.astLengthStack[this.astLengthPtr--]) > nodesToRemove && 
/*  808 */         this.astStack[this.astPtr] instanceof MemberValuePair) {
/*  809 */         System.arraycopy(
/*  810 */             this.astStack, (
/*  811 */             this.astPtr -= length) + 1, 
/*  812 */             memberValuePairs = new MemberValuePair[length - nodesToRemove], 
/*  813 */             0, 
/*  814 */             length - nodesToRemove);
/*      */       }
/*      */       
/*  817 */       annotation = 
/*  818 */         new CompletionOnAnnotationMemberValuePair(
/*  819 */           typeReference, 
/*  820 */           this.intStack[this.intPtr--], 
/*  821 */           memberValuePairs, 
/*  822 */           memberValuePair);
/*      */       
/*  824 */       this.assistNode = (ASTNode)memberValuePair;
/*  825 */       this.assistNodeParent = (ASTNode)annotation;
/*      */       
/*  827 */       if (memberValuePair.sourceEnd >= this.lastCheckPoint) {
/*  828 */         this.lastCheckPoint = memberValuePair.sourceEnd + 1;
/*      */       }
/*      */     } else {
/*  831 */       MemberValuePair[] memberValuePairs = null;
/*  832 */       int length = 0;
/*  833 */       if (this.astLengthPtr > -1 && (length = this.astLengthStack[this.astLengthPtr--]) > nodesToRemove) {
/*  834 */         if (this.astStack[this.astPtr] instanceof MemberValuePair) {
/*  835 */           System.arraycopy(
/*  836 */               this.astStack, (
/*  837 */               this.astPtr -= length) + 1, 
/*  838 */               memberValuePairs = new MemberValuePair[length - nodesToRemove + 1], 
/*  839 */               0, 
/*  840 */               length - nodesToRemove);
/*      */         }
/*  842 */         if (memberValuePairs != null) {
/*  843 */           memberValuePairs[length - nodesToRemove] = memberValuePair;
/*      */         } else {
/*  845 */           memberValuePairs = new MemberValuePair[] { memberValuePair };
/*      */         } 
/*      */       } else {
/*  848 */         memberValuePairs = new MemberValuePair[] { memberValuePair };
/*      */       } 
/*      */       
/*  851 */       annotation = 
/*  852 */         new NormalAnnotation(
/*  853 */           typeReference, 
/*  854 */           this.intStack[this.intPtr--]);
/*  855 */       annotation.memberValuePairs = memberValuePairs;
/*  856 */       this.assistNodeParent = (ASTNode)annotation;
/*      */     } 
/*      */     
/*  859 */     CompletionOnAnnotationOfType fakeType = 
/*  860 */       new CompletionOnAnnotationOfType(
/*  861 */         FAKE_TYPE_NAME, 
/*  862 */         this.compilationUnit.compilationResult(), 
/*  863 */         (Annotation)annotation);
/*      */     
/*  865 */     this.currentElement.add(fakeType, 0);
/*  866 */     this.pendingAnnotation = fakeType;
/*      */   } private void buildMoreCompletionContext(Expression expression) {
/*      */     ArrayInitializer arrayInitializer;
/*  869 */     Expression expression1 = expression;
/*  870 */     int kind = topKnownElementKind(1536);
/*  871 */     if (kind != 0) {
/*  872 */       int selector, invocType; Expression castType; int qualifierExprPtr; ArrayInitializer arrayInitializer1; int length; ArrayAllocationExpression allocationExpression; Expression[] arguments; ArrayReference arrayReference; QualifiedAllocationExpression allocationExpr; IfStatement ifStatement; WhileStatement whileStatement; ForStatement forStatement; SwitchStatement switchStatement; SynchronizedStatement synchronizedStatement; int info = topKnownElementInfo(1536);
/*  873 */       switch (kind) {
/*      */         case 1027:
/*  875 */           selector = topKnownElementInfo(1536, 2);
/*  876 */           if (selector == -1 || selector == -2) {
/*  877 */             ExplicitConstructorCall call = new ExplicitConstructorCall(
/*  878 */                 (selector == -1) ? 
/*  879 */                 3 : 
/*  880 */                 2);
/*      */             
/*  882 */             call.arguments = new Expression[] { expression };
/*  883 */             call.sourceStart = expression.sourceStart;
/*  884 */             call.sourceEnd = expression.sourceEnd;
/*  885 */             this.assistNodeParent = (ASTNode)call; break;
/*      */           } 
/*  887 */           invocType = topKnownElementInfo(1536, 1);
/*  888 */           qualifierExprPtr = info;
/*      */ 
/*      */           
/*  891 */           length = this.expressionLengthStack[this.expressionLengthPtr];
/*      */ 
/*      */           
/*  894 */           if (this.expressionPtr > 0 && this.expressionLengthPtr > 0 && length == 1) {
/*  895 */             int start = (int)(this.identifierPositionStack[selector] >>> 32L);
/*  896 */             if (this.expressionStack[this.expressionPtr - 1] != null && (this.expressionStack[this.expressionPtr - 1]).sourceStart > start) {
/*  897 */               length += this.expressionLengthStack[this.expressionLengthPtr - 1];
/*      */             }
/*      */           } 
/*      */ 
/*      */           
/*  902 */           arguments = null;
/*  903 */           if (length != 0) {
/*  904 */             arguments = new Expression[length];
/*  905 */             this.expressionPtr -= length;
/*  906 */             System.arraycopy(this.expressionStack, this.expressionPtr + 1, arguments, 0, length - 1);
/*  907 */             arguments[length - 1] = expression;
/*      */           } 
/*      */           
/*  910 */           if (invocType != -4 && invocType != -5) {
/*  911 */             int identifierLength; MessageSend messageSend = new MessageSend();
/*  912 */             messageSend.selector = this.identifierStack[selector];
/*  913 */             messageSend.arguments = arguments;
/*      */ 
/*      */             
/*  916 */             switch (invocType) {
/*      */               case -1:
/*  918 */                 messageSend.receiver = (Expression)ThisReference.implicitThis();
/*      */                 break;
/*      */               
/*      */               case -3:
/*  922 */                 while (this.identifierLengthPtr >= 0 && this.identifierLengthStack[this.identifierLengthPtr] < 0) {
/*  923 */                   this.identifierLengthPtr--;
/*      */                 }
/*      */ 
/*      */                 
/*  927 */                 this.identifierPtr--;
/*  928 */                 if (this.genericsPtr > -1 && this.genericsLengthPtr > -1 && this.genericsLengthStack[this.genericsLengthPtr] > 0) {
/*      */                   
/*  930 */                   this.identifierLengthPtr--;
/*      */                 } else {
/*  932 */                   this.identifierLengthStack[this.identifierLengthPtr] = this.identifierLengthStack[this.identifierLengthPtr] - 1;
/*  933 */                   length = this.typeAnnotationLengthStack[this.typeAnnotationLengthPtr--];
/*      */                   
/*  935 */                   if (length != 0) {
/*  936 */                     Annotation[] typeAnnotations; System.arraycopy(
/*  937 */                         this.typeAnnotationStack, (
/*  938 */                         this.typeAnnotationPtr -= length) + 1, 
/*  939 */                         typeAnnotations = new Annotation[length], 
/*  940 */                         0, 
/*  941 */                         length);
/*  942 */                     problemReporter().misplacedTypeAnnotations(typeAnnotations[0], typeAnnotations[typeAnnotations.length - 1]);
/*      */                   } 
/*      */                 } 
/*      */                 
/*  946 */                 identifierLength = this.identifierLengthStack[this.identifierLengthPtr];
/*  947 */                 if (this.identifierPtr > -1 && identifierLength > 0 && this.identifierPtr + 1 >= identifierLength) {
/*  948 */                   messageSend.receiver = (Expression)getUnspecifiedReference(); break;
/*      */                 } 
/*  950 */                 messageSend = null;
/*      */                 break;
/*      */               
/*      */               case -2:
/*  954 */                 messageSend.receiver = (Expression)new SuperReference(0, 0);
/*      */                 break;
/*      */               case 0:
/*  957 */                 messageSend.receiver = this.expressionStack[qualifierExprPtr];
/*      */                 break;
/*      */               default:
/*  960 */                 messageSend.receiver = (Expression)ThisReference.implicitThis();
/*      */                 break;
/*      */             } 
/*  963 */             this.assistNodeParent = (ASTNode)messageSend; break;
/*      */           } 
/*  965 */           if (invocType == -4) {
/*  966 */             AllocationExpression allocationExpression1 = new AllocationExpression();
/*  967 */             allocationExpression1.arguments = arguments;
/*  968 */             pushOnGenericsIdentifiersLengthStack(this.identifierLengthStack[this.identifierLengthPtr]);
/*  969 */             pushOnGenericsLengthStack(0);
/*  970 */             allocationExpression1.type = getTypeReference(0);
/*  971 */             this.assistNodeParent = (ASTNode)allocationExpression1; break;
/*      */           } 
/*  973 */           allocationExpr = new QualifiedAllocationExpression();
/*  974 */           allocationExpr.enclosingInstance = this.expressionStack[qualifierExprPtr];
/*  975 */           allocationExpr.arguments = arguments;
/*  976 */           pushOnGenericsIdentifiersLengthStack(this.identifierLengthStack[this.identifierLengthPtr]);
/*  977 */           pushOnGenericsLengthStack(0);
/*      */           
/*  979 */           allocationExpr.type = getTypeReference(0);
/*  980 */           this.assistNodeParent = (ASTNode)allocationExpr;
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 1034:
/*  986 */           if (info == this.bracketDepth) {
/*  987 */             ReturnStatement returnStatement = new ReturnStatement(expression, expression.sourceStart, expression.sourceEnd);
/*  988 */             this.assistNodeParent = (ASTNode)returnStatement;
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 1035:
/*  993 */           if (this.expressionPtr > 0 && 
/*  994 */             castType = this.expressionStack[this.expressionPtr - 1] instanceof TypeReference) {
/*  995 */             CastExpression cast = new CastExpression(expression, (TypeReference)castType);
/*  996 */             cast.sourceStart = castType.sourceStart;
/*  997 */             cast.sourceEnd = expression.sourceEnd;
/*  998 */             this.assistNodeParent = (ASTNode)cast;
/*      */           } 
/*      */           break;
/*      */         case 1039:
/* 1002 */           if (this.expressionPtr > -1) {
/* 1003 */             PrefixExpression prefixExpression; UnaryExpression unaryExpression; Expression operatorExpression = null;
/* 1004 */             switch (info) {
/*      */               case 32:
/* 1006 */                 prefixExpression = new PrefixExpression(expression, (Expression)IntLiteral.One, 14, expression.sourceStart);
/*      */                 break;
/*      */               case 33:
/* 1009 */                 prefixExpression = new PrefixExpression(expression, (Expression)IntLiteral.One, 13, expression.sourceStart);
/*      */                 break;
/*      */               default:
/* 1012 */                 unaryExpression = new UnaryExpression(expression, info);
/*      */                 break;
/*      */             } 
/* 1015 */             this.assistNodeParent = (ASTNode)unaryExpression;
/*      */           } 
/*      */           break;
/*      */         case 1040:
/* 1019 */           if (this.expressionPtr > -1) {
/* 1020 */             BinaryExpression binaryExpression; NameReference nameReference; Expression operatorExpression = null;
/* 1021 */             Expression left = null;
/* 1022 */             if (this.expressionPtr == 0) {
/*      */               
/* 1024 */               if (this.identifierPtr > -1) {
/* 1025 */                 nameReference = getUnspecifiedReferenceOptimized();
/*      */               }
/*      */             } else {
/* 1028 */               left = this.expressionStack[this.expressionPtr - 1];
/*      */               
/* 1030 */               if (this.identifierPtr > -1) {
/* 1031 */                 int start = (int)(this.identifierPositionStack[this.identifierPtr] >>> 32L);
/* 1032 */                 if (left.sourceStart < start) {
/* 1033 */                   nameReference = getUnspecifiedReferenceOptimized();
/*      */                 }
/*      */               } 
/*      */             } 
/*      */             
/* 1038 */             if (nameReference != null) {
/* 1039 */               AND_AND_Expression aND_AND_Expression; OR_OR_Expression oR_OR_Expression; EqualExpression equalExpression; switch (info) {
/*      */                 case 0:
/* 1041 */                   aND_AND_Expression = new AND_AND_Expression((Expression)nameReference, expression, info);
/*      */                   break;
/*      */                 case 1:
/* 1044 */                   oR_OR_Expression = new OR_OR_Expression((Expression)nameReference, expression, info);
/*      */                   break;
/*      */                 case 18:
/*      */                 case 29:
/* 1048 */                   equalExpression = new EqualExpression((Expression)nameReference, expression, info);
/*      */                   break;
/*      */                 default:
/* 1051 */                   binaryExpression = new BinaryExpression((Expression)nameReference, expression, info);
/*      */                   break;
/*      */               } 
/*      */             } 
/* 1055 */             if (binaryExpression != null) {
/* 1056 */               this.assistNodeParent = (ASTNode)binaryExpression;
/*      */             }
/*      */           } 
/*      */           break;
/*      */         case 1037:
/* 1061 */           arrayInitializer1 = new ArrayInitializer();
/* 1062 */           arrayInitializer1.expressions = new Expression[] { expression };
/* 1063 */           this.expressionPtr -= this.expressionLengthStack[this.expressionLengthPtr--];
/*      */           
/* 1065 */           if (this.expressionLengthPtr > -1 && 
/* 1066 */             this.expressionPtr > -1 && 
/* 1067 */             this.expressionStack[this.expressionPtr] != null && 
/* 1068 */             (this.expressionStack[this.expressionPtr]).sourceStart > info) {
/* 1069 */             this.expressionLengthPtr--;
/*      */           }
/*      */           
/* 1072 */           if (topKnownElementKind(1536, 1) == 1038) {
/* 1073 */             ArrayAllocationExpression arrayAllocationExpression = new ArrayAllocationExpression();
/* 1074 */             pushOnGenericsLengthStack(0);
/* 1075 */             pushOnGenericsIdentifiersLengthStack(this.identifierLengthStack[this.identifierLengthPtr]);
/* 1076 */             arrayAllocationExpression.type = getTypeReference(0);
/* 1077 */             arrayAllocationExpression.type.bits |= 0x40000000;
/* 1078 */             int i = this.expressionLengthStack[this.expressionLengthPtr];
/* 1079 */             arrayAllocationExpression.dimensions = new Expression[i];
/*      */             
/* 1081 */             arrayAllocationExpression.initializer = arrayInitializer1;
/* 1082 */             this.assistNodeParent = (ASTNode)arrayAllocationExpression; break;
/* 1083 */           }  if (this.currentElement instanceof RecoveredField && !(this.currentElement instanceof org.eclipse.jdt.internal.compiler.parser.RecoveredInitializer)) {
/* 1084 */             RecoveredField recoveredField = (RecoveredField)this.currentElement;
/* 1085 */             if (recoveredField.fieldDeclaration.type.dimensions() == 0) {
/* 1086 */               Block block = new Block(0);
/* 1087 */               block.sourceStart = info;
/* 1088 */               this.currentElement = this.currentElement.add(block, 1); break;
/*      */             } 
/* 1090 */             ArrayInitializer arrayInitializer2 = arrayInitializer1; break;
/*      */           } 
/* 1092 */           if (this.currentElement instanceof RecoveredLocalVariable) {
/* 1093 */             RecoveredLocalVariable recoveredLocalVariable = (RecoveredLocalVariable)this.currentElement;
/* 1094 */             if (recoveredLocalVariable.localDeclaration.type.dimensions() == 0) {
/* 1095 */               Block block = new Block(0);
/* 1096 */               block.sourceStart = info;
/* 1097 */               this.currentElement = this.currentElement.add(block, 1); break;
/*      */             } 
/* 1099 */             ArrayInitializer arrayInitializer2 = arrayInitializer1;
/*      */             break;
/*      */           } 
/* 1102 */           arrayInitializer = arrayInitializer1;
/*      */           break;
/*      */         
/*      */         case 1038:
/* 1106 */           allocationExpression = new ArrayAllocationExpression();
/* 1107 */           allocationExpression.type = getTypeReference(0);
/* 1108 */           allocationExpression.dimensions = new Expression[] { expression };
/*      */           
/* 1110 */           this.assistNodeParent = (ASTNode)allocationExpression;
/*      */           break;
/*      */         case 1041:
/* 1113 */           if (this.expressionPtr > 0 && this.expressionStack[this.expressionPtr - 1] != null) {
/*      */             CompoundAssignment compoundAssignment;
/* 1115 */             if (info == 30) {
/* 1116 */               Assignment assignment = new Assignment(
/* 1117 */                   this.expressionStack[this.expressionPtr - 1], 
/* 1118 */                   expression, 
/* 1119 */                   expression.sourceEnd);
/*      */             } else {
/*      */               
/* 1122 */               compoundAssignment = new CompoundAssignment(
/* 1123 */                   this.expressionStack[this.expressionPtr - 1], 
/* 1124 */                   expression, 
/* 1125 */                   info, 
/* 1126 */                   expression.sourceEnd);
/*      */             } 
/*      */             
/* 1129 */             this.assistNodeParent = (ASTNode)compoundAssignment;
/*      */           } 
/*      */           break;
/*      */         case 1042:
/* 1133 */           if (info == 1) {
/* 1134 */             if (this.expressionPtr > 0) {
/* 1135 */               this.expressionPtr--;
/* 1136 */               this.expressionLengthPtr--;
/* 1137 */               this.expressionStack[this.expressionPtr] = this.expressionStack[this.expressionPtr + 1];
/* 1138 */               popElement(1042);
/* 1139 */               buildMoreCompletionContext(expression); return;
/*      */             } 
/*      */             break;
/*      */           } 
/* 1143 */           if (this.expressionPtr > 1) {
/* 1144 */             this.expressionPtr -= 2;
/* 1145 */             this.expressionLengthPtr -= 2;
/* 1146 */             this.expressionStack[this.expressionPtr] = this.expressionStack[this.expressionPtr + 2];
/* 1147 */             popElement(1042);
/* 1148 */             buildMoreCompletionContext(expression);
/*      */             return;
/*      */           } 
/*      */           break;
/*      */ 
/*      */         
/*      */         case 1052:
/* 1155 */           if (this.identifierPtr < 0 && this.expressionPtr > 0 && this.expressionStack[this.expressionPtr] == expression) {
/* 1156 */             arrayReference = 
/* 1157 */               new ArrayReference(
/* 1158 */                 this.expressionStack[this.expressionPtr - 1], 
/* 1159 */                 expression);
/*      */           } else {
/* 1161 */             arrayReference = 
/* 1162 */               new ArrayReference(
/* 1163 */                 (Expression)getUnspecifiedReferenceOptimized(), 
/* 1164 */                 expression);
/*      */           } 
/* 1166 */           this.assistNodeParent = (ASTNode)arrayReference;
/*      */           break;
/*      */         case 1050:
/* 1169 */           if (this.expressionPtr > 0) {
/* 1170 */             SwitchStatement switchStatement1 = new SwitchStatement();
/* 1171 */             switchStatement1.expression = this.expressionStack[this.expressionPtr - 1];
/* 1172 */             if (this.astLengthPtr > -1 && this.astPtr > -1) {
/* 1173 */               int i = this.astLengthStack[this.astLengthPtr];
/* 1174 */               int newAstPtr = this.astPtr - i;
/* 1175 */               ASTNode firstNode = this.astStack[newAstPtr + 1];
/* 1176 */               if (i != 0 && firstNode.sourceStart > switchStatement1.expression.sourceEnd) {
/* 1177 */                 switchStatement1.statements = new Statement[i + 1];
/* 1178 */                 System.arraycopy(
/* 1179 */                     this.astStack, 
/* 1180 */                     newAstPtr + 1, 
/* 1181 */                     switchStatement1.statements, 
/* 1182 */                     0, 
/* 1183 */                     i);
/*      */               } 
/*      */             } 
/* 1186 */             CaseStatement caseStatement = new CaseStatement(expression, expression.sourceStart, expression.sourceEnd);
/* 1187 */             if (switchStatement1.statements == null) {
/* 1188 */               switchStatement1.statements = new Statement[] { (Statement)caseStatement };
/*      */             } else {
/* 1190 */               switchStatement1.statements[switchStatement1.statements.length - 1] = (Statement)caseStatement;
/*      */             } 
/* 1192 */             this.assistNodeParent = (ASTNode)switchStatement1;
/*      */           } 
/*      */           break;
/*      */         case 1043:
/* 1196 */           ifStatement = new IfStatement(expression, (Statement)new EmptyStatement(expression.sourceEnd, expression.sourceEnd), expression.sourceStart, expression.sourceEnd);
/* 1197 */           this.assistNodeParent = (ASTNode)ifStatement;
/*      */           break;
/*      */         case 1044:
/* 1200 */           whileStatement = new WhileStatement(expression, (Statement)new EmptyStatement(expression.sourceEnd, expression.sourceEnd), expression.sourceStart, expression.sourceEnd);
/* 1201 */           this.assistNodeParent = (ASTNode)whileStatement;
/*      */           break;
/*      */         case 1064:
/* 1204 */           forStatement = new ForStatement(new Statement[0], expression, new Statement[0], 
/* 1205 */               (Statement)new EmptyStatement(expression.sourceEnd, expression.sourceEnd), 
/* 1206 */               false, 
/* 1207 */               expression.sourceStart, expression.sourceEnd);
/* 1208 */           this.assistNodeParent = (ASTNode)forStatement;
/*      */           break;
/*      */         case 1046:
/* 1211 */           switchStatement = new SwitchStatement();
/* 1212 */           switchStatement.expression = expression;
/* 1213 */           switchStatement.statements = new Statement[0];
/* 1214 */           this.assistNodeParent = (ASTNode)switchStatement;
/*      */           break;
/*      */         case 1047:
/* 1217 */           synchronizedStatement = new SynchronizedStatement(expression, new Block(0), expression.sourceStart, expression.sourceEnd);
/* 1218 */           this.assistNodeParent = (ASTNode)synchronizedStatement;
/*      */           break;
/*      */         case 1033:
/* 1221 */           if (info == this.bracketDepth) {
/* 1222 */             ThrowStatement throwStatement = new ThrowStatement(expression, expression.sourceStart, expression.sourceEnd);
/* 1223 */             this.assistNodeParent = (ASTNode)throwStatement;
/*      */           } 
/*      */           break;
/*      */         case 1048:
/* 1227 */           if (info == this.bracketDepth) {
/* 1228 */             AssertStatement assertStatement = new AssertStatement(expression, expression.sourceStart);
/* 1229 */             this.assistNodeParent = (ASTNode)assertStatement;
/*      */           } 
/*      */           break;
/*      */         case 1063:
/* 1233 */           if (info == this.bracketDepth) {
/* 1234 */             AssertStatement assertStatement = new AssertStatement(expression, (Expression)new TrueLiteral(expression.sourceStart, expression.sourceStart), expression.sourceStart);
/* 1235 */             this.assistNodeParent = (ASTNode)assertStatement;
/*      */           } 
/*      */           break;
/*      */       } 
/*      */     } 
/* 1240 */     if (this.assistNodeParent != null) {
/* 1241 */       this.currentElement = this.currentElement.add(buildMoreCompletionEnclosingContext((Statement)this.assistNodeParent), 0);
/*      */     }
/* 1243 */     else if (this.currentElement instanceof RecoveredField && !(this.currentElement instanceof org.eclipse.jdt.internal.compiler.parser.RecoveredInitializer) && 
/* 1244 */       ((RecoveredField)this.currentElement).fieldDeclaration.initialization == null) {
/* 1245 */       if (lastIndexOfElement(519) <= lastIndexOfElement(516))
/* 1246 */         this.assistNodeParent = (ASTNode)((RecoveredField)this.currentElement).fieldDeclaration; 
/* 1247 */       this.currentElement = this.currentElement.add(buildMoreCompletionEnclosingContext((Statement)arrayInitializer), 0);
/* 1248 */     } else if (this.currentElement instanceof RecoveredLocalVariable && 
/* 1249 */       ((RecoveredLocalVariable)this.currentElement).localDeclaration.initialization == null) {
/*      */       
/* 1251 */       this.assistNodeParent = (ASTNode)((RecoveredLocalVariable)this.currentElement).localDeclaration;
/* 1252 */       this.currentElement = this.currentElement.add(buildMoreCompletionEnclosingContext((Statement)arrayInitializer), 0);
/*      */     } else {
/* 1254 */       this.currentElement = this.currentElement.add(buildMoreCompletionEnclosingContext((Statement)expression), 0);
/*      */     } 
/*      */   }
/*      */   
/*      */   private Statement buildMoreCompletionEnclosingContext(Statement statement) {
/* 1259 */     IfStatement ifStatement = null;
/* 1260 */     int index = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1268 */     int blockIndex = lastIndexOfElement(1025);
/* 1269 */     int controlIndex = lastIndexOfElement(1062);
/* 1270 */     int instanceOfIndex = lastIndexOfElement(1065);
/* 1271 */     if (instanceOfIndex != -1 && instanceOfIndex > controlIndex) {
/* 1272 */       index = instanceOfIndex;
/* 1273 */     } else if (controlIndex == -1) {
/* 1274 */       index = blockIndex;
/*      */     } else {
/* 1276 */       index = (blockIndex != -1 && controlIndex < blockIndex) ? blockIndex : controlIndex;
/*      */     } 
/* 1278 */     while (index >= 0) {
/*      */ 
/*      */       
/* 1281 */       Object elementObjectInfo = this.elementObjectInfoStack[index];
/* 1282 */       int kind = this.elementKindStack[index];
/* 1283 */       if ((kind == 1025 || kind == 1062 || kind == 1065) && 
/* 1284 */         this.elementInfoStack[index] == 1 && elementObjectInfo != null && (
/* 1285 */         isInstanceOfGuard(elementObjectInfo) || this.assistNode == elementObjectInfo)) {
/*      */         
/* 1287 */         Expression condition = (Expression)elementObjectInfo;
/*      */ 
/*      */         
/* 1290 */         if (this.currentElement instanceof RecoveredLocalVariable && 
/* 1291 */           this.currentElement.parent instanceof RecoveredBlock) {
/* 1292 */           RecoveredLocalVariable recoveredLocalVariable = (RecoveredLocalVariable)this.currentElement;
/* 1293 */           if (recoveredLocalVariable.localDeclaration.initialization == null && 
/* 1294 */             statement instanceof Expression && ((Expression)statement).isTrulyExpression() && 
/* 1295 */             condition.sourceStart < recoveredLocalVariable.localDeclaration.sourceStart) {
/* 1296 */             this.currentElement.add(statement, 0);
/*      */             
/* 1298 */             statement = recoveredLocalVariable.updatedStatement(0, new HashSet());
/*      */ 
/*      */             
/* 1301 */             RecoveredBlock recoveredBlock = (RecoveredBlock)recoveredLocalVariable.parent;
/* 1302 */             recoveredBlock.statements[--recoveredBlock.statementCount] = null;
/*      */             
/* 1304 */             this.currentElement = (RecoveredElement)recoveredBlock;
/*      */           } 
/*      */         } 
/*      */         
/* 1308 */         if (statement instanceof AND_AND_Expression && this.assistNode instanceof Statement) {
/* 1309 */           statement = (Statement)this.assistNode;
/*      */         }
/* 1311 */         ifStatement = 
/* 1312 */           new IfStatement(
/* 1313 */             condition, 
/* 1314 */             (statement == condition) ? (Statement)new EmptyStatement(condition.sourceEnd, condition.sourceEnd) : statement, 
/* 1315 */             condition.sourceStart, 
/* 1316 */             statement.sourceEnd);
/*      */         
/* 1318 */         this.elementPtr = --index;
/*      */         break;
/*      */       } 
/* 1321 */       index--;
/*      */     } 
/* 1323 */     if (ifStatement == null) {
/* 1324 */       return statement;
/*      */     }
/*      */ 
/*      */     
/* 1328 */     while (index >= 0) {
/* 1329 */       if (this.elementInfoStack[index] == 1 && isInstanceOfGuard(this.elementObjectInfoStack[index])) {
/* 1330 */         Expression condition = (Expression)this.elementObjectInfoStack[index];
/* 1331 */         ifStatement = 
/* 1332 */           new IfStatement(
/* 1333 */             condition, 
/* 1334 */             (Statement)ifStatement, 
/* 1335 */             condition.sourceStart, 
/* 1336 */             ifStatement.sourceEnd);
/* 1337 */         this.elementPtr = index;
/*      */       } 
/* 1339 */       index--;
/*      */     } 
/* 1341 */     this.enclosingNode = (ASTNode)ifStatement;
/* 1342 */     return (Statement)ifStatement;
/*      */   }
/*      */   private boolean isInstanceOfGuard(Object object) {
/* 1345 */     if (object instanceof InstanceOfExpression)
/* 1346 */       return true; 
/* 1347 */     if (object instanceof AND_AND_Expression) {
/* 1348 */       AND_AND_Expression expression = (AND_AND_Expression)object;
/* 1349 */       return !(!isInstanceOfGuard(expression.left) && !isInstanceOfGuard(expression.right));
/*      */     } 
/* 1351 */     return false;
/*      */   }
/*      */   private void buildMoreGenericsCompletionContext(ASTNode node, boolean consumeTypeArguments) {
/* 1354 */     int kind = topKnownElementKind(1536);
/* 1355 */     if (kind != 0) {
/* 1356 */       int prevKind, info = topKnownElementInfo(1536);
/* 1357 */       switch (kind) {
/*      */         case 1040:
/* 1359 */           prevKind = topKnownElementKind(1536, 1);
/* 1360 */           switch (prevKind) {
/*      */             case 1055:
/* 1362 */               if (this.invocationType == -4 || this.invocationType == -5) {
/* 1363 */                 this.currentElement = this.currentElement.add((Statement)node, 0);
/*      */               }
/*      */               return;
/*      */             case 1054:
/* 1367 */               if (topKnownElementInfo(1536, 1) == 0) {
/* 1368 */                 this.currentElement = this.currentElement.add((Statement)node, 0); return;
/*      */               } 
/*      */               break;
/*      */           } 
/* 1372 */           if (info == 4 && node instanceof TypeReference) {
/* 1373 */             if (this.identifierLengthPtr > -1 && this.identifierLengthStack[this.identifierLengthPtr] != 0) {
/* 1374 */               ParameterizedQualifiedTypeReference parameterizedQualifiedTypeReference; if (consumeTypeArguments) consumeTypeArguments(); 
/* 1375 */               TypeReference ref = getTypeReference(0);
/* 1376 */               if (prevKind == 1056) {
/* 1377 */                 parameterizedQualifiedTypeReference = computeQualifiedGenericsFromRightSide(ref, 0, null);
/*      */               }
/* 1379 */               if (this.currentElement instanceof RecoveredType) {
/* 1380 */                 this.currentElement = this.currentElement.add(new CompletionOnFieldType((TypeReference)parameterizedQualifiedTypeReference, false), 0);
/*      */               
/*      */               }
/* 1383 */               else if (prevKind == 1032) {
/*      */                 AllocationExpression exp;
/*      */                 
/* 1386 */                 if (this.expressionPtr > -1 && this.expressionStack[this.expressionPtr] instanceof AllocationExpression && 
/* 1387 */                   this.invocationType == -5) {
/* 1388 */                   QualifiedAllocationExpression qualifiedAllocationExpression = new QualifiedAllocationExpression();
/* 1389 */                   ((AllocationExpression)qualifiedAllocationExpression).type = (TypeReference)parameterizedQualifiedTypeReference;
/* 1390 */                   qualifiedAllocationExpression.enclosingInstance = this.expressionStack[this.expressionPtr];
/*      */                 } else {
/* 1392 */                   exp = new AllocationExpression();
/* 1393 */                   exp.type = (TypeReference)parameterizedQualifiedTypeReference;
/*      */                 } 
/* 1395 */                 if (isInsideReturn()) {
/* 1396 */                   ReturnStatement returnStatement = new ReturnStatement((Expression)exp, exp.sourceStart, exp.sourceEnd);
/* 1397 */                   this.enclosingNode = (ASTNode)returnStatement;
/* 1398 */                   this.currentElement = this.currentElement.add((Statement)returnStatement, 0);
/* 1399 */                 } else if (this.currentElement instanceof RecoveredLocalVariable) {
/* 1400 */                   if (((RecoveredLocalVariable)this.currentElement).localDeclaration.initialization == null) {
/* 1401 */                     this.enclosingNode = (ASTNode)((RecoveredLocalVariable)this.currentElement).localDeclaration;
/* 1402 */                     this.currentElement = this.currentElement.add((Statement)exp, 0);
/*      */                   } 
/* 1404 */                 } else if (this.currentElement instanceof RecoveredField) {
/* 1405 */                   if (((RecoveredField)this.currentElement).fieldDeclaration.initialization == null) {
/* 1406 */                     this.enclosingNode = (ASTNode)((RecoveredField)this.currentElement).fieldDeclaration;
/* 1407 */                     this.currentElement = this.currentElement.add((Statement)exp, 0);
/*      */                   } 
/*      */                 } else {
/* 1410 */                   this.currentElement = this.currentElement.add((Statement)parameterizedQualifiedTypeReference, 0);
/*      */                 } 
/*      */               } else {
/* 1413 */                 this.currentElement = this.currentElement.add((Statement)parameterizedQualifiedTypeReference, 0);
/*      */               }
/*      */             
/* 1416 */             } else if (this.currentElement.enclosingMethod() != null && 
/* 1417 */               (this.currentElement.enclosingMethod()).methodDeclaration.isConstructor()) {
/* 1418 */               this.currentElement = this.currentElement.add((Statement)node, 0);
/*      */             } 
/*      */           }
/*      */           return;
/*      */       } 
/*      */       
/* 1424 */       if (this.identifierLengthPtr != -1 && this.genericsIdentifiersLengthPtr != -1) {
/* 1425 */         int length = this.identifierLengthStack[this.identifierLengthPtr];
/* 1426 */         int numberOfIdentifiers = this.genericsIdentifiersLengthStack[this.genericsIdentifiersLengthPtr];
/* 1427 */         if (length != numberOfIdentifiers || this.genericsLengthStack[this.genericsLengthPtr] != 0) {
/* 1428 */           TypeReference ref = getTypeReference(0);
/* 1429 */           this.currentElement = this.currentElement.add((Statement)ref, 0);
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void buildMoreTryStatementCompletionContext(TypeReference exceptionRef) {
/* 1437 */     if (this.astLengthPtr > 0 && 
/* 1438 */       this.astPtr > 2 && 
/* 1439 */       this.astStack[this.astPtr - 1] instanceof Block && 
/* 1440 */       this.astStack[this.astPtr - 2] instanceof Argument) {
/* 1441 */       TryStatement tryStatement = new TryStatement();
/*      */       
/* 1443 */       int newAstPtr = this.astPtr - 1;
/*      */       
/* 1445 */       int length = this.astLengthStack[this.astLengthPtr - 1];
/* 1446 */       Block[] bks = tryStatement.catchBlocks = new Block[length + 1];
/* 1447 */       Argument[] args = tryStatement.catchArguments = new Argument[length + 1];
/* 1448 */       if (length != 0) {
/* 1449 */         while (length-- > 0) {
/* 1450 */           bks[length] = (Block)this.astStack[newAstPtr--];
/* 1451 */           (bks[length]).statements = null;
/* 1452 */           args[length] = (Argument)this.astStack[newAstPtr--];
/*      */         } 
/*      */       }
/*      */       
/* 1456 */       bks[bks.length - 1] = new Block(0);
/* 1457 */       if (this.astStack[this.astPtr] instanceof UnionTypeReference) {
/* 1458 */         UnionTypeReference unionTypeReference = (UnionTypeReference)this.astStack[this.astPtr];
/* 1459 */         args[args.length - 1] = new Argument(FAKE_ARGUMENT_NAME, 0L, (TypeReference)unionTypeReference, 0);
/*      */       } else {
/* 1461 */         args[args.length - 1] = new Argument(FAKE_ARGUMENT_NAME, 0L, exceptionRef, 0);
/*      */       } 
/*      */       
/* 1464 */       tryStatement.tryBlock = (Block)this.astStack[newAstPtr--];
/*      */       
/* 1466 */       this.assistNodeParent = (ASTNode)tryStatement;
/*      */       
/* 1468 */       this.currentElement.add((Statement)tryStatement, 0);
/* 1469 */     } else if (this.astLengthPtr > -1 && 
/* 1470 */       this.astPtr > 0 && 
/* 1471 */       this.astStack[this.astPtr - 1] instanceof Block) {
/* 1472 */       TryStatement tryStatement = new TryStatement();
/*      */       
/* 1474 */       int newAstPtr = this.astPtr - 1;
/*      */       
/* 1476 */       Block[] bks = tryStatement.catchBlocks = new Block[1];
/* 1477 */       Argument[] args = tryStatement.catchArguments = new Argument[1];
/*      */       
/* 1479 */       bks[0] = new Block(0);
/* 1480 */       if (this.astStack[this.astPtr] instanceof UnionTypeReference) {
/* 1481 */         UnionTypeReference unionTypeReference = (UnionTypeReference)this.astStack[this.astPtr];
/* 1482 */         args[0] = new Argument(FAKE_ARGUMENT_NAME, 0L, (TypeReference)unionTypeReference, 0);
/*      */       } else {
/* 1484 */         args[0] = new Argument(FAKE_ARGUMENT_NAME, 0L, exceptionRef, 0);
/*      */       } 
/*      */       
/* 1487 */       tryStatement.tryBlock = (Block)this.astStack[newAstPtr--];
/*      */       
/* 1489 */       this.assistNodeParent = (ASTNode)tryStatement;
/*      */       
/* 1491 */       this.currentElement.add((Statement)tryStatement, 0);
/*      */     } else {
/* 1493 */       this.currentElement = this.currentElement.add((Statement)exceptionRef, 0);
/*      */     } 
/*      */   }
/*      */   
/*      */   public int bodyEnd(Initializer initializer) {
/* 1498 */     return this.cursorLocation;
/*      */   }
/*      */   
/*      */   protected void checkAndSetModifiers(int flag) {
/* 1502 */     super.checkAndSetModifiers(flag);
/*      */     
/* 1504 */     if (isInsideMethod()) {
/* 1505 */       this.hasUnusedModifiers = true;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void consumePushCombineModifiers() {
/* 1510 */     super.consumePushCombineModifiers();
/*      */     
/* 1512 */     if (isInsideMethod()) {
/* 1513 */       this.hasUnusedModifiers = true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkClassInstanceCreation() {
/* 1521 */     if (topKnownElementKind(1536) == 1032) {
/* 1522 */       TypeReference type; int length = this.identifierLengthStack[this.identifierLengthPtr];
/* 1523 */       int numberOfIdentifiers = this.genericsIdentifiersLengthStack[this.genericsIdentifiersLengthPtr];
/* 1524 */       if (length != numberOfIdentifiers || this.genericsLengthStack[this.genericsLengthPtr] != 0)
/*      */       {
/* 1526 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1532 */       if (this.invocationType == -4) {
/*      */         
/* 1534 */         AllocationExpression allocExpr = new AllocationExpression();
/* 1535 */         if (topKnownElementKind(1536, 1) == 1033 && 
/* 1536 */           topKnownElementInfo(1536, 1) == this.bracketDepth) {
/* 1537 */           pushOnElementStack(1031);
/* 1538 */           type = getTypeReference(0);
/* 1539 */           popElement(1031);
/*      */         } else {
/* 1541 */           type = getTypeReference(0);
/*      */         } 
/* 1543 */         if (type instanceof CompletionOnSingleTypeReference) {
/* 1544 */           ((CompletionOnSingleTypeReference)type).isConstructorType = true;
/* 1545 */         } else if (type instanceof CompletionOnQualifiedTypeReference) {
/* 1546 */           ((CompletionOnQualifiedTypeReference)type).isConstructorType = true;
/*      */         } 
/* 1548 */         allocExpr.type = type;
/* 1549 */         allocExpr.sourceStart = type.sourceStart;
/* 1550 */         allocExpr.sourceEnd = type.sourceEnd;
/* 1551 */         pushOnExpressionStack((Expression)allocExpr);
/* 1552 */         this.isOrphanCompletionNode = false;
/*      */       } else {
/*      */         
/* 1555 */         QualifiedAllocationExpression allocExpr = new QualifiedAllocationExpression();
/* 1556 */         pushOnGenericsIdentifiersLengthStack(this.identifierLengthStack[this.identifierLengthPtr]);
/* 1557 */         pushOnGenericsLengthStack(0);
/* 1558 */         if (topKnownElementKind(1536, 1) == 1033 && 
/* 1559 */           topKnownElementInfo(1536, 1) == this.bracketDepth) {
/* 1560 */           pushOnElementStack(1031);
/* 1561 */           type = getTypeReference(0);
/* 1562 */           popElement(1031);
/*      */         } else {
/* 1564 */           type = getTypeReference(0);
/*      */         } 
/* 1566 */         if (type instanceof CompletionOnSingleTypeReference) {
/* 1567 */           ((CompletionOnSingleTypeReference)type).isConstructorType = true;
/*      */         }
/* 1569 */         allocExpr.type = type;
/* 1570 */         allocExpr.enclosingInstance = this.expressionStack[this.qualifier];
/* 1571 */         allocExpr.sourceStart = this.intStack[this.intPtr--];
/* 1572 */         allocExpr.sourceEnd = type.sourceEnd;
/* 1573 */         this.expressionStack[this.qualifier] = (Expression)allocExpr;
/* 1574 */         this.isOrphanCompletionNode = false;
/*      */       } 
/* 1576 */       this.assistNode = (ASTNode)type;
/* 1577 */       this.lastCheckPoint = type.sourceEnd + 1;
/*      */       
/* 1579 */       popElement(1032);
/* 1580 */       return true;
/*      */     } 
/* 1582 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkClassLiteralAccess() {
/* 1590 */     if (this.identifierLengthPtr >= 1 && this.previousToken == 1) {
/*      */       int length;
/*      */ 
/*      */       
/* 1594 */       if ((length = this.identifierLengthStack[this.identifierLengthPtr - 1]) < 0) {
/*      */         
/* 1596 */         int dim = isAfterArrayType() ? this.intStack[this.intPtr--] : 0;
/* 1597 */         Annotation[][] annotationsOnDimensions = (dim == 0) ? null : getAnnotationsOnDimensions(dim);
/* 1598 */         SingleTypeReference typeRef = (SingleTypeReference)TypeReference.baseTypeReference(-length, dim, annotationsOnDimensions);
/* 1599 */         typeRef.sourceStart = this.intStack[this.intPtr--];
/* 1600 */         if (dim == 0) {
/* 1601 */           typeRef.sourceEnd = this.intStack[this.intPtr--];
/*      */         } else {
/* 1603 */           this.intPtr--;
/* 1604 */           typeRef.sourceEnd = this.endPosition;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1609 */         char[] source = this.identifierStack[this.identifierPtr];
/* 1610 */         long pos = this.identifierPositionStack[this.identifierPtr--];
/* 1611 */         this.identifierLengthPtr--;
/*      */ 
/*      */         
/* 1614 */         CompletionOnClassLiteralAccess access = new CompletionOnClassLiteralAccess(pos, (TypeReference)typeRef);
/* 1615 */         access.completionIdentifier = source;
/* 1616 */         this.identifierLengthPtr--;
/* 1617 */         this.assistNode = (ASTNode)access;
/* 1618 */         this.isOrphanCompletionNode = true;
/* 1619 */         return true;
/*      */       } 
/*      */ 
/*      */       
/* 1623 */       if (isAfterArrayType()) {
/*      */         
/* 1625 */         char[] source = this.identifierStack[this.identifierPtr];
/* 1626 */         long pos = this.identifierPositionStack[this.identifierPtr--];
/* 1627 */         this.identifierLengthPtr--;
/*      */ 
/*      */         
/* 1630 */         pushOnGenericsIdentifiersLengthStack(this.identifierLengthStack[this.identifierLengthPtr]);
/* 1631 */         pushOnGenericsLengthStack(0);
/*      */         
/* 1633 */         TypeReference typeRef = getTypeReference(this.intStack[this.intPtr--]);
/*      */ 
/*      */         
/* 1636 */         CompletionOnClassLiteralAccess access = new CompletionOnClassLiteralAccess(pos, typeRef);
/* 1637 */         access.completionIdentifier = source;
/* 1638 */         this.assistNode = (ASTNode)access;
/* 1639 */         this.isOrphanCompletionNode = true;
/* 1640 */         return true;
/*      */       } 
/*      */     } 
/*      */     
/* 1644 */     return false;
/*      */   }
/*      */   private boolean checkKeywordAndRestrictedIdentifiers() {
/* 1647 */     if (this.currentElement instanceof RecoveredUnit) {
/* 1648 */       RecoveredUnit unit = (RecoveredUnit)this.currentElement;
/* 1649 */       if (unit.unitDeclaration.isModuleInfo()) return false; 
/* 1650 */       int index = -1;
/* 1651 */       if ((index = indexOfAssistIdentifier()) > -1) {
/* 1652 */         int ptr = this.identifierPtr - this.identifierLengthStack[this.identifierLengthPtr] + index + 1;
/*      */         
/* 1654 */         char[] ident = this.identifierStack[ptr];
/* 1655 */         long pos = this.identifierPositionStack[ptr];
/*      */         
/* 1657 */         char[][] keywordsAndRestrictedIndentifiers = new char[54][];
/* 1658 */         int count = 0;
/* 1659 */         if (unit.typeCount == 0 && (
/* 1660 */           !this.compilationUnit.isPackageInfo() || this.compilationUnit.currentPackage != null) && 
/* 1661 */           this.lastModifiers == 0) {
/* 1662 */           keywordsAndRestrictedIndentifiers[count++] = Keywords.IMPORT;
/*      */         }
/* 1664 */         if (unit.typeCount == 0 && 
/* 1665 */           unit.importCount == 0 && 
/* 1666 */           this.lastModifiers == 0 && 
/* 1667 */           this.compilationUnit.currentPackage == null) {
/* 1668 */           keywordsAndRestrictedIndentifiers[count++] = Keywords.PACKAGE;
/*      */         }
/* 1670 */         if (!this.compilationUnit.isPackageInfo()) {
/* 1671 */           if ((this.lastModifiers & 0x1) == 0) {
/* 1672 */             boolean hasNoPublicType = true;
/* 1673 */             for (int i = 0; i < unit.typeCount; i++) {
/* 1674 */               if (((unit.types[i]).typeDeclaration.modifiers & 0x1) != 0) {
/* 1675 */                 hasNoPublicType = false;
/*      */                 break;
/*      */               } 
/*      */             } 
/* 1679 */             if (hasNoPublicType) {
/* 1680 */               keywordsAndRestrictedIndentifiers[count++] = Keywords.PUBLIC;
/*      */             }
/*      */           } 
/* 1683 */           if ((this.lastModifiers & 0x400) == 0 && (
/* 1684 */             this.lastModifiers & 0x10) == 0) {
/* 1685 */             keywordsAndRestrictedIndentifiers[count++] = Keywords.ABSTRACT;
/*      */           }
/* 1687 */           if ((this.lastModifiers & 0x400) == 0 && (
/* 1688 */             this.lastModifiers & 0x10) == 0) {
/* 1689 */             keywordsAndRestrictedIndentifiers[count++] = Keywords.FINAL;
/*      */           }
/*      */           
/* 1692 */           keywordsAndRestrictedIndentifiers[count++] = Keywords.CLASS;
/* 1693 */           if (this.options.complianceLevel >= 3211264L) {
/* 1694 */             keywordsAndRestrictedIndentifiers[count++] = Keywords.ENUM;
/*      */           }
/* 1696 */           if ((this.lastModifiers & 0x10) == 0) {
/* 1697 */             keywordsAndRestrictedIndentifiers[count++] = Keywords.INTERFACE;
/*      */           }
/* 1699 */           if (JavaFeature.RECORDS.isSupported(this.options)) {
/* 1700 */             keywordsAndRestrictedIndentifiers[count++] = RestrictedIdentifiers.RECORD;
/*      */           }
/* 1702 */           if (JavaFeature.SEALED_CLASSES.isSupported(this.options)) {
/* 1703 */             boolean nonSeal = ((this.lastModifiers & 0x4000000) != 0);
/* 1704 */             boolean seal = ((this.lastModifiers & 0x10000000) != 0);
/* 1705 */             if (!nonSeal && !seal) {
/* 1706 */               keywordsAndRestrictedIndentifiers[count++] = RestrictedIdentifiers.SEALED;
/* 1707 */               keywordsAndRestrictedIndentifiers[count++] = RestrictedIdentifiers.NON_SEALED;
/*      */             } 
/*      */           } 
/*      */         } 
/* 1711 */         if (count != 0) {
/* 1712 */           System.arraycopy(keywordsAndRestrictedIndentifiers, 0, keywordsAndRestrictedIndentifiers = new char[count][], 0, count);
/*      */           
/* 1714 */           this.assistNode = (ASTNode)new CompletionOnKeyword2(ident, pos, keywordsAndRestrictedIndentifiers);
/* 1715 */           this.lastCheckPoint = this.assistNode.sourceEnd + 1;
/* 1716 */           this.isOrphanCompletionNode = true;
/* 1717 */           return true;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1721 */     return false;
/*      */   }
/*      */   
/*      */   private enum ModuleKeyword {
/* 1725 */     FIRST_ALL,
/* 1726 */     TO,
/* 1727 */     PROVIDES_WITH,
/* 1728 */     NOT_A_KEYWORD;
/*      */   }
/*      */   
/*      */   private ModuleKeyword getKeyword() {
/* 1732 */     ModuleKeyword keyword = ModuleKeyword.FIRST_ALL;
/* 1733 */     if (isInModuleStatements())
/* 1734 */       if (foundToken(1072)) { keyword = ModuleKeyword.TO; }
/* 1735 */       else if (foundToken(1073)) { keyword = ModuleKeyword.PROVIDES_WITH; }
/* 1736 */       else { keyword = ModuleKeyword.NOT_A_KEYWORD; }
/*      */        
/* 1738 */     return keyword;
/*      */   }
/*      */   private char[][] getModuleKeywords(ModuleKeyword keyword) {
/* 1741 */     if (keyword == ModuleKeyword.TO) return new char[][] { Keywords.TO }; 
/* 1742 */     if (keyword == ModuleKeyword.PROVIDES_WITH) return new char[][] { Keywords.WITH }; 
/* 1743 */     return new char[][] { Keywords.EXPORTS, Keywords.OPENS, Keywords.REQUIRES, Keywords.PROVIDES, Keywords.USES };
/*      */   }
/*      */   
/*      */   private boolean checkModuleInfoConstructs() {
/* 1747 */     if (!isInsideModuleInfo()) return false;
/*      */     
/* 1749 */     int index = -1;
/* 1750 */     if ((index = indexOfAssistIdentifier()) <= -1) return false;
/*      */     
/* 1752 */     if (this.currentElement instanceof RecoveredModule) {
/* 1753 */       RecoveredModule module = (RecoveredModule)this.currentElement;
/* 1754 */       if (checkModuleInfoKeyword(module, index)) return true; 
/*      */     } else {
/* 1756 */       ModuleKeyword keyword = ModuleKeyword.NOT_A_KEYWORD;
/* 1757 */       if (isInModuleStatements()) {
/* 1758 */         if (foundToken(1072)) keyword = ModuleKeyword.TO; 
/* 1759 */         if (foundToken(1073)) keyword = ModuleKeyword.PROVIDES_WITH; 
/*      */       } 
/* 1761 */       if (keyword == ModuleKeyword.NOT_A_KEYWORD) return false;
/*      */       
/* 1763 */       int length = this.identifierLengthStack[this.identifierLengthPtr];
/* 1764 */       int ptr = this.identifierPtr - length + index + 1;
/*      */       
/* 1766 */       char[] ident = this.identifierStack[ptr];
/* 1767 */       long pos = this.identifierPositionStack[ptr];
/* 1768 */       char[][] keywords = getModuleKeywords(keyword);
/* 1769 */       if (this.currentElement instanceof RecoveredPackageVisibilityStatement) {
/* 1770 */         RecoveredPackageVisibilityStatement rPvs = (RecoveredPackageVisibilityStatement)this.currentElement;
/* 1771 */         rPvs.add(new CompletionOnKeywordModule2(ident, pos, keywords), 0);
/* 1772 */         return true;
/* 1773 */       }  if (this.currentElement instanceof RecoveredProvidesStatement) {
/* 1774 */         RecoveredProvidesStatement rPs = (RecoveredProvidesStatement)this.currentElement;
/* 1775 */         rPs.add(new CompletionOnKeyword1(ident, pos, keywords), 0);
/* 1776 */         return true;
/*      */       } 
/*      */     } 
/* 1779 */     return false;
/*      */   }
/*      */   private boolean checkModuleInfoKeyword(RecoveredModule module, int index) {
/* 1782 */     ModuleKeyword keyword = getKeyword();
/* 1783 */     if (keyword == ModuleKeyword.NOT_A_KEYWORD) return false;
/*      */     
/* 1785 */     int length = this.identifierLengthStack[this.identifierLengthPtr];
/* 1786 */     int ptr = this.identifierPtr - length + index + 1;
/*      */     
/* 1788 */     char[] ident = this.identifierStack[ptr];
/* 1789 */     long pos = this.identifierPositionStack[ptr];
/* 1790 */     char[][] keywords = getModuleKeywords(keyword);
/* 1791 */     module.add(new CompletionOnKeywordModuleInfo(ident, pos, keywords), 0);
/* 1792 */     return true;
/*      */   }
/*      */   
/*      */   private boolean checkInstanceofKeyword() {
/* 1796 */     if (isInsideMethod()) {
/* 1797 */       int kind = topKnownElementKind(1536);
/*      */       int index;
/* 1799 */       if (kind != 1025 && (
/* 1800 */         index = indexOfAssistIdentifier()) > -1 && 
/* 1801 */         this.expressionPtr > -1 && 
/* 1802 */         this.expressionLengthStack[this.expressionPtr] == 1) {
/*      */         
/* 1804 */         int ptr = this.identifierPtr - this.identifierLengthStack[this.identifierLengthPtr] + index + 1;
/* 1805 */         if ((this.identifierStack[ptr]).length > 0 && CharOperation.prefixEquals(this.identifierStack[ptr], Keywords.INSTANCEOF)) {
/* 1806 */           this.assistNode = (ASTNode)new CompletionOnKeyword3(
/* 1807 */               this.identifierStack[ptr], 
/* 1808 */               this.identifierPositionStack[ptr], 
/* 1809 */               Keywords.INSTANCEOF);
/* 1810 */           this.lastCheckPoint = this.assistNode.sourceEnd + 1;
/* 1811 */           this.isOrphanCompletionNode = true;
/* 1812 */           return true;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1816 */     return false;
/*      */   }
/*      */   
/*      */   private boolean checkYieldKeyword() {
/* 1820 */     char[] id = this.scanner.getCurrentIdentifierSource();
/* 1821 */     if (id.length > 0 && CharOperation.equals(id, Keywords.YIELD)) {
/* 1822 */       return true;
/*      */     }
/* 1824 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkInvocation() {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield expressionPtr : I
/*      */     //   4: iflt -> 19
/*      */     //   7: aload_0
/*      */     //   8: getfield expressionStack : [Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   11: aload_0
/*      */     //   12: getfield expressionPtr : I
/*      */     //   15: aaload
/*      */     //   16: goto -> 20
/*      */     //   19: aconst_null
/*      */     //   20: astore_1
/*      */     //   21: iconst_0
/*      */     //   22: istore_2
/*      */     //   23: iconst_0
/*      */     //   24: istore_3
/*      */     //   25: aload_0
/*      */     //   26: sipush #1536
/*      */     //   29: invokevirtual topKnownElementKind : (I)I
/*      */     //   32: sipush #1027
/*      */     //   35: if_icmpne -> 876
/*      */     //   38: aload_1
/*      */     //   39: aload_0
/*      */     //   40: getfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   43: if_acmpne -> 57
/*      */     //   46: aload_0
/*      */     //   47: invokevirtual isEmptyNameCompletion : ()Z
/*      */     //   50: ifeq -> 57
/*      */     //   53: iconst_1
/*      */     //   54: goto -> 58
/*      */     //   57: iconst_0
/*      */     //   58: dup
/*      */     //   59: istore_2
/*      */     //   60: ifne -> 93
/*      */     //   63: aload_0
/*      */     //   64: invokevirtual indexOfAssistIdentifier : ()I
/*      */     //   67: iflt -> 87
/*      */     //   70: aload_0
/*      */     //   71: getfield identifierStack : [[C
/*      */     //   74: aload_0
/*      */     //   75: getfield identifierPtr : I
/*      */     //   78: aaload
/*      */     //   79: arraylength
/*      */     //   80: ifne -> 87
/*      */     //   83: iconst_1
/*      */     //   84: goto -> 88
/*      */     //   87: iconst_0
/*      */     //   88: dup
/*      */     //   89: istore_3
/*      */     //   90: ifeq -> 876
/*      */     //   93: iload_2
/*      */     //   94: ifeq -> 123
/*      */     //   97: aload_0
/*      */     //   98: dup
/*      */     //   99: getfield expressionPtr : I
/*      */     //   102: iconst_1
/*      */     //   103: isub
/*      */     //   104: putfield expressionPtr : I
/*      */     //   107: aload_0
/*      */     //   108: getfield expressionLengthStack : [I
/*      */     //   111: aload_0
/*      */     //   112: getfield expressionLengthPtr : I
/*      */     //   115: dup2
/*      */     //   116: iaload
/*      */     //   117: iconst_1
/*      */     //   118: isub
/*      */     //   119: iastore
/*      */     //   120: goto -> 147
/*      */     //   123: iload_3
/*      */     //   124: ifeq -> 147
/*      */     //   127: aload_0
/*      */     //   128: dup
/*      */     //   129: getfield identifierPtr : I
/*      */     //   132: iconst_1
/*      */     //   133: isub
/*      */     //   134: putfield identifierPtr : I
/*      */     //   137: aload_0
/*      */     //   138: dup
/*      */     //   139: getfield identifierLengthPtr : I
/*      */     //   142: iconst_1
/*      */     //   143: isub
/*      */     //   144: putfield identifierLengthPtr : I
/*      */     //   147: aload_0
/*      */     //   148: sipush #1536
/*      */     //   151: iconst_1
/*      */     //   152: invokevirtual topKnownElementInfo : (II)I
/*      */     //   155: istore #4
/*      */     //   157: aload_0
/*      */     //   158: sipush #1536
/*      */     //   161: invokevirtual topKnownElementInfo : (I)I
/*      */     //   164: istore #5
/*      */     //   166: aload_0
/*      */     //   167: getfield expressionPtr : I
/*      */     //   170: iload #5
/*      */     //   172: isub
/*      */     //   173: istore #6
/*      */     //   175: iload #5
/*      */     //   177: iconst_1
/*      */     //   178: iadd
/*      */     //   179: istore #7
/*      */     //   181: aconst_null
/*      */     //   182: astore #8
/*      */     //   184: iload #6
/*      */     //   186: ifle -> 254
/*      */     //   189: iload #6
/*      */     //   191: anewarray org/eclipse/jdt/internal/compiler/ast/Expression
/*      */     //   194: astore #8
/*      */     //   196: aload_0
/*      */     //   197: getfield expressionStack : [Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   200: iload #7
/*      */     //   202: aload #8
/*      */     //   204: iconst_0
/*      */     //   205: iload #6
/*      */     //   207: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*      */     //   210: aload_0
/*      */     //   211: dup
/*      */     //   212: getfield expressionPtr : I
/*      */     //   215: iload #6
/*      */     //   217: isub
/*      */     //   218: putfield expressionPtr : I
/*      */     //   221: iload #6
/*      */     //   223: istore #9
/*      */     //   225: goto -> 249
/*      */     //   228: iload #9
/*      */     //   230: aload_0
/*      */     //   231: getfield expressionLengthStack : [I
/*      */     //   234: aload_0
/*      */     //   235: dup
/*      */     //   236: getfield expressionLengthPtr : I
/*      */     //   239: dup_x1
/*      */     //   240: iconst_1
/*      */     //   241: isub
/*      */     //   242: putfield expressionLengthPtr : I
/*      */     //   245: iaload
/*      */     //   246: isub
/*      */     //   247: istore #9
/*      */     //   249: iload #9
/*      */     //   251: ifgt -> 228
/*      */     //   254: iload #4
/*      */     //   256: bipush #-4
/*      */     //   258: if_icmpeq -> 649
/*      */     //   261: iload #4
/*      */     //   263: bipush #-5
/*      */     //   265: if_icmpeq -> 649
/*      */     //   268: new org/eclipse/jdt/internal/codeassist/complete/CompletionOnMessageSend
/*      */     //   271: dup
/*      */     //   272: invokespecial <init> : ()V
/*      */     //   275: astore #9
/*      */     //   277: aload #9
/*      */     //   279: aload #8
/*      */     //   281: putfield arguments : [Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   284: iload #4
/*      */     //   286: tableswitch default -> 538, -3 -> 327, -2 -> 509, -1 -> 316, 0 -> 526
/*      */     //   316: aload #9
/*      */     //   318: invokestatic implicitThis : ()Lorg/eclipse/jdt/internal/compiler/ast/ThisReference;
/*      */     //   321: putfield receiver : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   324: goto -> 538
/*      */     //   327: goto -> 340
/*      */     //   330: aload_0
/*      */     //   331: dup
/*      */     //   332: getfield identifierLengthPtr : I
/*      */     //   335: iconst_1
/*      */     //   336: isub
/*      */     //   337: putfield identifierLengthPtr : I
/*      */     //   340: aload_0
/*      */     //   341: getfield identifierLengthPtr : I
/*      */     //   344: iflt -> 359
/*      */     //   347: aload_0
/*      */     //   348: getfield identifierLengthStack : [I
/*      */     //   351: aload_0
/*      */     //   352: getfield identifierLengthPtr : I
/*      */     //   355: iaload
/*      */     //   356: iflt -> 330
/*      */     //   359: aload_0
/*      */     //   360: dup
/*      */     //   361: getfield identifierPtr : I
/*      */     //   364: iconst_1
/*      */     //   365: isub
/*      */     //   366: putfield identifierPtr : I
/*      */     //   369: aload_0
/*      */     //   370: getfield genericsPtr : I
/*      */     //   373: iconst_m1
/*      */     //   374: if_icmple -> 410
/*      */     //   377: aload_0
/*      */     //   378: getfield genericsLengthPtr : I
/*      */     //   381: iconst_m1
/*      */     //   382: if_icmple -> 410
/*      */     //   385: aload_0
/*      */     //   386: getfield genericsLengthStack : [I
/*      */     //   389: aload_0
/*      */     //   390: getfield genericsLengthPtr : I
/*      */     //   393: iaload
/*      */     //   394: ifle -> 410
/*      */     //   397: aload_0
/*      */     //   398: dup
/*      */     //   399: getfield identifierLengthPtr : I
/*      */     //   402: iconst_1
/*      */     //   403: isub
/*      */     //   404: putfield identifierLengthPtr : I
/*      */     //   407: goto -> 497
/*      */     //   410: aload_0
/*      */     //   411: getfield identifierLengthStack : [I
/*      */     //   414: aload_0
/*      */     //   415: getfield identifierLengthPtr : I
/*      */     //   418: dup2
/*      */     //   419: iaload
/*      */     //   420: iconst_1
/*      */     //   421: isub
/*      */     //   422: iastore
/*      */     //   423: aload_0
/*      */     //   424: getfield typeAnnotationLengthStack : [I
/*      */     //   427: aload_0
/*      */     //   428: dup
/*      */     //   429: getfield typeAnnotationLengthPtr : I
/*      */     //   432: dup_x1
/*      */     //   433: iconst_1
/*      */     //   434: isub
/*      */     //   435: putfield typeAnnotationLengthPtr : I
/*      */     //   438: iaload
/*      */     //   439: istore #10
/*      */     //   441: iload #10
/*      */     //   443: ifeq -> 497
/*      */     //   446: aload_0
/*      */     //   447: getfield typeAnnotationStack : [Lorg/eclipse/jdt/internal/compiler/ast/Annotation;
/*      */     //   450: aload_0
/*      */     //   451: dup
/*      */     //   452: getfield typeAnnotationPtr : I
/*      */     //   455: iload #10
/*      */     //   457: isub
/*      */     //   458: dup_x1
/*      */     //   459: putfield typeAnnotationPtr : I
/*      */     //   462: iconst_1
/*      */     //   463: iadd
/*      */     //   464: iload #10
/*      */     //   466: anewarray org/eclipse/jdt/internal/compiler/ast/Annotation
/*      */     //   469: dup
/*      */     //   470: astore #11
/*      */     //   472: iconst_0
/*      */     //   473: iload #10
/*      */     //   475: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*      */     //   478: aload_0
/*      */     //   479: invokevirtual problemReporter : ()Lorg/eclipse/jdt/internal/compiler/problem/ProblemReporter;
/*      */     //   482: aload #11
/*      */     //   484: iconst_0
/*      */     //   485: aaload
/*      */     //   486: aload #11
/*      */     //   488: aload #11
/*      */     //   490: arraylength
/*      */     //   491: iconst_1
/*      */     //   492: isub
/*      */     //   493: aaload
/*      */     //   494: invokevirtual misplacedTypeAnnotations : (Lorg/eclipse/jdt/internal/compiler/ast/Annotation;Lorg/eclipse/jdt/internal/compiler/ast/Annotation;)V
/*      */     //   497: aload #9
/*      */     //   499: aload_0
/*      */     //   500: invokevirtual getUnspecifiedReference : ()Lorg/eclipse/jdt/internal/compiler/ast/NameReference;
/*      */     //   503: putfield receiver : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   506: goto -> 538
/*      */     //   509: aload #9
/*      */     //   511: new org/eclipse/jdt/internal/compiler/ast/SuperReference
/*      */     //   514: dup
/*      */     //   515: iconst_0
/*      */     //   516: iconst_0
/*      */     //   517: invokespecial <init> : (II)V
/*      */     //   520: putfield receiver : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   523: goto -> 538
/*      */     //   526: aload #9
/*      */     //   528: aload_0
/*      */     //   529: getfield expressionStack : [Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   532: iload #5
/*      */     //   534: aaload
/*      */     //   535: putfield receiver : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   538: aload_0
/*      */     //   539: sipush #1536
/*      */     //   542: iconst_2
/*      */     //   543: invokevirtual topKnownElementInfo : (II)I
/*      */     //   546: istore #10
/*      */     //   548: aload #9
/*      */     //   550: aload_0
/*      */     //   551: getfield identifierStack : [[C
/*      */     //   554: iload #10
/*      */     //   556: aaload
/*      */     //   557: putfield selector : [C
/*      */     //   560: aload_0
/*      */     //   561: getfield identifierLengthPtr : I
/*      */     //   564: iflt -> 600
/*      */     //   567: aload_0
/*      */     //   568: getfield identifierLengthStack : [I
/*      */     //   571: aload_0
/*      */     //   572: getfield identifierLengthPtr : I
/*      */     //   575: iaload
/*      */     //   576: iconst_1
/*      */     //   577: if_icmpne -> 600
/*      */     //   580: aload_0
/*      */     //   581: dup
/*      */     //   582: getfield identifierPtr : I
/*      */     //   585: iconst_1
/*      */     //   586: isub
/*      */     //   587: putfield identifierPtr : I
/*      */     //   590: aload_0
/*      */     //   591: dup
/*      */     //   592: getfield identifierLengthPtr : I
/*      */     //   595: iconst_1
/*      */     //   596: isub
/*      */     //   597: putfield identifierLengthPtr : I
/*      */     //   600: aload #9
/*      */     //   602: aload_0
/*      */     //   603: getfield identifierPositionStack : [J
/*      */     //   606: iload #10
/*      */     //   608: laload
/*      */     //   609: bipush #32
/*      */     //   611: lshr
/*      */     //   612: l2i
/*      */     //   613: putfield sourceStart : I
/*      */     //   616: aload #9
/*      */     //   618: aload_0
/*      */     //   619: getfield cursorLocation : I
/*      */     //   622: putfield sourceEnd : I
/*      */     //   625: aload_0
/*      */     //   626: aload #9
/*      */     //   628: putfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   631: aload_0
/*      */     //   632: aload #9
/*      */     //   634: getfield sourceEnd : I
/*      */     //   637: iconst_1
/*      */     //   638: iadd
/*      */     //   639: putfield lastCheckPoint : I
/*      */     //   642: aload_0
/*      */     //   643: iconst_1
/*      */     //   644: putfield isOrphanCompletionNode : Z
/*      */     //   647: iconst_1
/*      */     //   648: ireturn
/*      */     //   649: aload_0
/*      */     //   650: sipush #1536
/*      */     //   653: iconst_2
/*      */     //   654: invokevirtual topKnownElementInfo : (II)I
/*      */     //   657: istore #9
/*      */     //   659: iload #9
/*      */     //   661: iconst_m1
/*      */     //   662: if_icmpeq -> 672
/*      */     //   665: iload #9
/*      */     //   667: bipush #-2
/*      */     //   669: if_icmpne -> 762
/*      */     //   672: new org/eclipse/jdt/internal/codeassist/complete/CompletionOnExplicitConstructorCall
/*      */     //   675: dup
/*      */     //   676: iload #9
/*      */     //   678: iconst_m1
/*      */     //   679: if_icmpne -> 686
/*      */     //   682: iconst_3
/*      */     //   683: goto -> 687
/*      */     //   686: iconst_2
/*      */     //   687: invokespecial <init> : (I)V
/*      */     //   690: astore #10
/*      */     //   692: aload #10
/*      */     //   694: aload #8
/*      */     //   696: putfield arguments : [Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   699: iload #4
/*      */     //   701: bipush #-5
/*      */     //   703: if_icmpne -> 718
/*      */     //   706: aload #10
/*      */     //   708: aload_0
/*      */     //   709: getfield expressionStack : [Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   712: iload #5
/*      */     //   714: aaload
/*      */     //   715: putfield qualification : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   718: aload #10
/*      */     //   720: aload_0
/*      */     //   721: getfield cursorLocation : I
/*      */     //   724: iconst_1
/*      */     //   725: iadd
/*      */     //   726: putfield sourceStart : I
/*      */     //   729: aload #10
/*      */     //   731: aload_0
/*      */     //   732: getfield cursorLocation : I
/*      */     //   735: putfield sourceEnd : I
/*      */     //   738: aload_0
/*      */     //   739: aload #10
/*      */     //   741: putfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   744: aload_0
/*      */     //   745: aload #10
/*      */     //   747: getfield sourceEnd : I
/*      */     //   750: iconst_1
/*      */     //   751: iadd
/*      */     //   752: putfield lastCheckPoint : I
/*      */     //   755: aload_0
/*      */     //   756: iconst_1
/*      */     //   757: putfield isOrphanCompletionNode : Z
/*      */     //   760: iconst_1
/*      */     //   761: ireturn
/*      */     //   762: new org/eclipse/jdt/internal/codeassist/complete/CompletionOnQualifiedAllocationExpression
/*      */     //   765: dup
/*      */     //   766: invokespecial <init> : ()V
/*      */     //   769: astore #10
/*      */     //   771: aload #10
/*      */     //   773: aload #8
/*      */     //   775: putfield arguments : [Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   778: aload_0
/*      */     //   779: getfield genericsLengthPtr : I
/*      */     //   782: ifge -> 803
/*      */     //   785: aload_0
/*      */     //   786: iconst_0
/*      */     //   787: invokevirtual pushOnGenericsLengthStack : (I)V
/*      */     //   790: aload_0
/*      */     //   791: aload_0
/*      */     //   792: getfield identifierLengthStack : [I
/*      */     //   795: aload_0
/*      */     //   796: getfield identifierLengthPtr : I
/*      */     //   799: iaload
/*      */     //   800: invokevirtual pushOnGenericsIdentifiersLengthStack : (I)V
/*      */     //   803: aload #10
/*      */     //   805: aload_0
/*      */     //   806: iconst_0
/*      */     //   807: invokespecial getTypeReference : (I)Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   810: putfield type : Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   813: iload #4
/*      */     //   815: bipush #-5
/*      */     //   817: if_icmpne -> 832
/*      */     //   820: aload #10
/*      */     //   822: aload_0
/*      */     //   823: getfield expressionStack : [Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   826: iload #5
/*      */     //   828: aaload
/*      */     //   829: putfield enclosingInstance : Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   832: aload #10
/*      */     //   834: aload_0
/*      */     //   835: getfield cursorLocation : I
/*      */     //   838: iconst_1
/*      */     //   839: iadd
/*      */     //   840: putfield sourceStart : I
/*      */     //   843: aload #10
/*      */     //   845: aload_0
/*      */     //   846: getfield cursorLocation : I
/*      */     //   849: putfield sourceEnd : I
/*      */     //   852: aload_0
/*      */     //   853: aload #10
/*      */     //   855: putfield assistNode : Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;
/*      */     //   858: aload_0
/*      */     //   859: aload #10
/*      */     //   861: getfield sourceEnd : I
/*      */     //   864: iconst_1
/*      */     //   865: iadd
/*      */     //   866: putfield lastCheckPoint : I
/*      */     //   869: aload_0
/*      */     //   870: iconst_1
/*      */     //   871: putfield isOrphanCompletionNode : Z
/*      */     //   874: iconst_1
/*      */     //   875: ireturn
/*      */     //   876: iconst_0
/*      */     //   877: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1831	-> 0
/*      */     //   #1832	-> 7
/*      */     //   #1833	-> 19
/*      */     //   #1831	-> 20
/*      */     //   #1834	-> 21
/*      */     //   #1835	-> 23
/*      */     //   #1836	-> 25
/*      */     //   #1837	-> 38
/*      */     //   #1838	-> 63
/*      */     //   #1841	-> 93
/*      */     //   #1842	-> 97
/*      */     //   #1843	-> 107
/*      */     //   #1844	-> 120
/*      */     //   #1845	-> 127
/*      */     //   #1846	-> 137
/*      */     //   #1850	-> 147
/*      */     //   #1851	-> 157
/*      */     //   #1854	-> 166
/*      */     //   #1855	-> 175
/*      */     //   #1856	-> 181
/*      */     //   #1857	-> 184
/*      */     //   #1859	-> 189
/*      */     //   #1860	-> 196
/*      */     //   #1863	-> 210
/*      */     //   #1864	-> 221
/*      */     //   #1865	-> 225
/*      */     //   #1866	-> 228
/*      */     //   #1865	-> 249
/*      */     //   #1871	-> 254
/*      */     //   #1873	-> 268
/*      */     //   #1874	-> 277
/*      */     //   #1875	-> 284
/*      */     //   #1878	-> 316
/*      */     //   #1879	-> 324
/*      */     //   #1882	-> 327
/*      */     //   #1883	-> 330
/*      */     //   #1882	-> 340
/*      */     //   #1887	-> 359
/*      */     //   #1888	-> 369
/*      */     //   #1890	-> 397
/*      */     //   #1891	-> 407
/*      */     //   #1892	-> 410
/*      */     //   #1893	-> 423
/*      */     //   #1895	-> 441
/*      */     //   #1897	-> 446
/*      */     //   #1898	-> 450
/*      */     //   #1899	-> 464
/*      */     //   #1900	-> 472
/*      */     //   #1901	-> 473
/*      */     //   #1896	-> 475
/*      */     //   #1902	-> 478
/*      */     //   #1906	-> 497
/*      */     //   #1907	-> 506
/*      */     //   #1909	-> 509
/*      */     //   #1910	-> 523
/*      */     //   #1912	-> 526
/*      */     //   #1916	-> 538
/*      */     //   #1917	-> 548
/*      */     //   #1919	-> 560
/*      */     //   #1920	-> 580
/*      */     //   #1921	-> 590
/*      */     //   #1925	-> 600
/*      */     //   #1926	-> 616
/*      */     //   #1929	-> 625
/*      */     //   #1930	-> 631
/*      */     //   #1931	-> 642
/*      */     //   #1932	-> 647
/*      */     //   #1934	-> 649
/*      */     //   #1935	-> 659
/*      */     //   #1937	-> 672
/*      */     //   #1938	-> 676
/*      */     //   #1937	-> 687
/*      */     //   #1939	-> 692
/*      */     //   #1940	-> 699
/*      */     //   #1941	-> 706
/*      */     //   #1945	-> 718
/*      */     //   #1946	-> 729
/*      */     //   #1949	-> 738
/*      */     //   #1950	-> 744
/*      */     //   #1951	-> 755
/*      */     //   #1952	-> 760
/*      */     //   #1955	-> 762
/*      */     //   #1956	-> 771
/*      */     //   #1957	-> 778
/*      */     //   #1958	-> 785
/*      */     //   #1959	-> 790
/*      */     //   #1961	-> 803
/*      */     //   #1962	-> 813
/*      */     //   #1963	-> 820
/*      */     //   #1966	-> 832
/*      */     //   #1967	-> 843
/*      */     //   #1970	-> 852
/*      */     //   #1971	-> 858
/*      */     //   #1972	-> 869
/*      */     //   #1973	-> 874
/*      */     //   #1977	-> 876
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	878	0	this	Lorg/eclipse/jdt/internal/codeassist/complete/CompletionParser;
/*      */     //   21	857	1	topExpression	Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   23	855	2	isEmptyNameCompletion	Z
/*      */     //   25	853	3	isEmptyAssistIdentifier	Z
/*      */     //   157	719	4	invocType	I
/*      */     //   166	710	5	qualifierExprPtr	I
/*      */     //   175	701	6	numArgs	I
/*      */     //   181	695	7	argStart	I
/*      */     //   184	692	8	arguments	[Lorg/eclipse/jdt/internal/compiler/ast/Expression;
/*      */     //   225	29	9	count	I
/*      */     //   277	372	9	messageSend	Lorg/eclipse/jdt/internal/codeassist/complete/CompletionOnMessageSend;
/*      */     //   441	56	10	length	I
/*      */     //   472	25	11	typeAnnotations	[Lorg/eclipse/jdt/internal/compiler/ast/Annotation;
/*      */     //   548	101	10	selectorPtr	I
/*      */     //   659	217	9	selectorPtr	I
/*      */     //   692	70	10	call	Lorg/eclipse/jdt/internal/codeassist/complete/CompletionOnExplicitConstructorCall;
/*      */     //   771	105	10	allocExpr	Lorg/eclipse/jdt/internal/codeassist/complete/CompletionOnQualifiedAllocationExpression;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkLabelStatement() {
/* 1980 */     if (isInsideMethod() || isInsideFieldInitialization()) {
/*      */       
/* 1982 */       int kind = topKnownElementKind(1536);
/* 1983 */       if (kind != 1058 && kind != 1059) return false;
/*      */       
/* 1985 */       if (indexOfAssistIdentifier() != 0) return false;
/*      */       
/* 1987 */       char[][] labels = new char[this.labelPtr + 1][];
/* 1988 */       int labelCount = 0;
/*      */       
/* 1990 */       int labelKind = kind;
/* 1991 */       int index = 1;
/* 1992 */       while (labelKind != 0 && labelKind != 515) {
/* 1993 */         labelKind = topKnownElementKind(1536, index);
/* 1994 */         if (labelKind == 1060) {
/* 1995 */           int ptr = topKnownElementInfo(1536, index);
/* 1996 */           labels[labelCount++] = this.labelStack[ptr];
/*      */         } 
/* 1998 */         index++;
/*      */       } 
/* 2000 */       System.arraycopy(labels, 0, labels = new char[labelCount][], 0, labelCount);
/*      */       
/* 2002 */       long position = this.identifierPositionStack[this.identifierPtr];
/* 2003 */       if (kind == 1058) {  } else {  }  this.assistNode = 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2009 */         (ASTNode)new CompletionOnContinueStatement(
/* 2010 */           this.identifierStack[this.identifierPtr--], 
/* 2011 */           (int)(position >>> 32L), 
/* 2012 */           (int)position, 
/* 2013 */           labels);
/* 2014 */       this.lastCheckPoint = this.assistNode.sourceEnd + 1;
/* 2015 */       this.isOrphanCompletionNode = true;
/* 2016 */       return true;
/*      */     } 
/* 2018 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkMemberAccess() {
/* 2025 */     if (this.previousToken == 1 && this.qualifier > -1 && this.expressionPtr == this.qualifier) {
/* 2026 */       if (this.identifierLengthPtr > 1 && this.identifierLengthStack[this.identifierLengthPtr - 1] < 0)
/*      */       {
/*      */         
/* 2029 */         return false;
/*      */       }
/*      */       
/* 2032 */       pushCompletionOnMemberAccessOnExpressionStack(false);
/* 2033 */       return true;
/*      */     } 
/* 2035 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkNameCompletion() {
/* 2052 */     this.assistNode = (ASTNode)getUnspecifiedReferenceOptimized();
/* 2053 */     this.lastCheckPoint = this.assistNode.sourceEnd + 1;
/* 2054 */     this.isOrphanCompletionNode = true;
/* 2055 */     if (this.hasUnusedModifiers && 
/* 2056 */       this.assistNode instanceof CompletionOnSingleNameReference) {
/* 2057 */       ((CompletionOnSingleNameReference)this.assistNode).isPrecededByModifiers = true;
/*      */     }
/* 2059 */     return true;
/*      */   }
/*      */   private boolean checkParemeterizedMethodName() {
/* 2062 */     if (topKnownElementKind(1536) == 1054 && 
/* 2063 */       topKnownElementInfo(1536) == 1 && 
/* 2064 */       this.identifierLengthPtr > -1 && this.genericsLengthPtr > -1 && this.genericsIdentifiersLengthPtr == -1) {
/* 2065 */       char[] selector; long position; int end, start, length; CompletionOnMessageSendName m = null;
/* 2066 */       switch (this.invocationType) {
/*      */         case -1:
/*      */         case 0:
/* 2069 */           if (this.expressionPtr > -1 && this.expressionLengthStack[this.expressionLengthPtr] == 1) {
/* 2070 */             char[] arrayOfChar = this.identifierStack[this.identifierPtr];
/* 2071 */             long l = this.identifierPositionStack[this.identifierPtr--];
/* 2072 */             this.identifierLengthPtr--;
/* 2073 */             int i = (int)l;
/* 2074 */             int j = (int)(l >>> 32L);
/* 2075 */             m = new CompletionOnMessageSendName(arrayOfChar, j, i, false);
/*      */ 
/*      */             
/* 2078 */             int k = this.genericsLengthStack[this.genericsLengthPtr--];
/* 2079 */             this.genericsPtr -= k;
/* 2080 */             System.arraycopy(this.genericsStack, this.genericsPtr + 1, m.typeArguments = new TypeReference[k], 0, k);
/* 2081 */             this.intPtr--;
/*      */             
/* 2083 */             m.receiver = this.expressionStack[this.expressionPtr--];
/* 2084 */             this.expressionLengthPtr--;
/*      */           } 
/*      */           break;
/*      */         case -3:
/* 2088 */           if (this.identifierPtr > 0) {
/* 2089 */             char[] arrayOfChar = this.identifierStack[this.identifierPtr];
/* 2090 */             long l = this.identifierPositionStack[this.identifierPtr--];
/* 2091 */             this.identifierLengthPtr--;
/* 2092 */             int i = (int)l;
/* 2093 */             int j = (int)(l >>> 32L);
/* 2094 */             m = new CompletionOnMessageSendName(arrayOfChar, j, i, false);
/*      */ 
/*      */             
/* 2097 */             int k = this.genericsLengthStack[this.genericsLengthPtr--];
/* 2098 */             this.genericsPtr -= k;
/* 2099 */             System.arraycopy(this.genericsStack, this.genericsPtr + 1, m.typeArguments = new TypeReference[k], 0, k);
/* 2100 */             this.intPtr--;
/*      */             
/* 2102 */             m.receiver = (Expression)getUnspecifiedReference();
/*      */           } 
/*      */           break;
/*      */         case -2:
/* 2106 */           selector = this.identifierStack[this.identifierPtr];
/* 2107 */           position = this.identifierPositionStack[this.identifierPtr--];
/* 2108 */           this.identifierLengthPtr--;
/* 2109 */           end = (int)position;
/* 2110 */           start = (int)(position >>> 32L);
/* 2111 */           m = new CompletionOnMessageSendName(selector, start, end, false);
/*      */ 
/*      */           
/* 2114 */           length = this.genericsLengthStack[this.genericsLengthPtr--];
/* 2115 */           this.genericsPtr -= length;
/* 2116 */           System.arraycopy(this.genericsStack, this.genericsPtr + 1, m.typeArguments = new TypeReference[length], 0, length);
/* 2117 */           this.intPtr--;
/*      */           
/* 2119 */           m.receiver = (Expression)new SuperReference(start, end);
/*      */           break;
/*      */       } 
/*      */       
/* 2123 */       if (m != null) {
/* 2124 */         pushOnExpressionStack((Expression)m);
/*      */         
/* 2126 */         this.assistNode = (ASTNode)m;
/* 2127 */         this.lastCheckPoint = this.assistNode.sourceEnd + 1;
/* 2128 */         this.isOrphanCompletionNode = true;
/* 2129 */         return true;
/*      */       } 
/*      */     } 
/*      */     
/* 2133 */     return false;
/*      */   }
/*      */   private boolean checkParemeterizedType() {
/* 2136 */     if (this.identifierLengthPtr > -1 && this.genericsLengthPtr > -1 && this.genericsIdentifiersLengthPtr > -1) {
/* 2137 */       int length = this.identifierLengthStack[this.identifierLengthPtr];
/* 2138 */       int numberOfIdentifiers = this.genericsIdentifiersLengthStack[this.genericsIdentifiersLengthPtr];
/* 2139 */       if (length != numberOfIdentifiers || this.genericsLengthStack[this.genericsLengthPtr] != 0) {
/* 2140 */         this.genericsIdentifiersLengthPtr--;
/* 2141 */         this.identifierLengthPtr--;
/*      */         
/* 2143 */         this.assistNode = (ASTNode)getAssistTypeReferenceForGenericType(0, length, numberOfIdentifiers);
/* 2144 */         this.lastCheckPoint = this.assistNode.sourceEnd + 1;
/* 2145 */         this.isOrphanCompletionNode = true;
/* 2146 */         return true;
/* 2147 */       }  if (this.genericsPtr > -1 && this.genericsStack[this.genericsPtr] instanceof TypeReference) {
/*      */         
/* 2149 */         numberOfIdentifiers++;
/*      */         
/* 2151 */         this.genericsIdentifiersLengthPtr--;
/* 2152 */         this.identifierLengthPtr--;
/*      */         
/* 2154 */         this.assistNode = (ASTNode)getAssistTypeReferenceForGenericType(0, length, numberOfIdentifiers);
/* 2155 */         this.lastCheckPoint = this.assistNode.sourceEnd + 1;
/* 2156 */         this.isOrphanCompletionNode = true;
/* 2157 */         return true;
/*      */       } 
/*      */     } 
/* 2160 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkRecoveredMethod() {
/* 2167 */     if (this.currentElement instanceof RecoveredMethod) {
/*      */       
/* 2169 */       if (indexOfAssistIdentifier() < 0) return false;
/*      */ 
/*      */ 
/*      */       
/* 2173 */       if (this.lastErrorEndPosition <= this.cursorLocation && 
/* 2174 */         Util.getLineNumber(this.lastErrorEndPosition, this.scanner.lineEnds, 0, this.scanner.linePtr) == 
/* 2175 */         Util.getLineNumber(((CompletionScanner)this.scanner).completedIdentifierStart, this.scanner.lineEnds, 0, this.scanner.linePtr)) {
/* 2176 */         return false;
/*      */       }
/* 2178 */       RecoveredMethod recoveredMethod = (RecoveredMethod)this.currentElement;
/*      */       
/* 2180 */       if (!recoveredMethod.foundOpeningBrace && 
/* 2181 */         this.lastIgnoredToken == -1) {
/*      */         
/* 2183 */         this.assistNode = (ASTNode)getTypeReference(0);
/* 2184 */         this.lastCheckPoint = this.assistNode.sourceEnd + 1;
/* 2185 */         this.isOrphanCompletionNode = true;
/* 2186 */         return true;
/*      */       } 
/*      */     } 
/* 2189 */     return false;
/*      */   }
/*      */   
/*      */   private boolean checkMemberValueName() {
/* 2193 */     if (indexOfAssistIdentifier() < 0) return false;
/*      */     
/* 2195 */     if (topKnownElementKind(1536) != 1057) return false;
/*      */     
/* 2197 */     if (this.identifierPtr > -1 && this.identifierLengthPtr > -1 && this.identifierLengthStack[this.identifierLengthPtr] == 1) {
/* 2198 */       char[] simpleName = this.identifierStack[this.identifierPtr];
/* 2199 */       long position = this.identifierPositionStack[this.identifierPtr--];
/* 2200 */       this.identifierLengthPtr--;
/* 2201 */       int end = (int)position;
/* 2202 */       int start = (int)(position >>> 32L);
/*      */ 
/*      */       
/* 2205 */       CompletionOnMemberValueName memberValueName = new CompletionOnMemberValueName(simpleName, start, end);
/* 2206 */       this.assistNode = (ASTNode)memberValueName;
/* 2207 */       this.lastCheckPoint = this.assistNode.sourceEnd + 1;
/* 2208 */       this.isOrphanCompletionNode = true;
/*      */       
/* 2210 */       return true;
/*      */     } 
/* 2212 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkRecoveredType() {
/* 2220 */     if (this.currentElement instanceof RecoveredType) {
/*      */       
/* 2222 */       if (indexOfAssistIdentifier() < 0) return false;
/*      */ 
/*      */ 
/*      */       
/* 2226 */       if (this.lastErrorEndPosition <= this.cursorLocation && (
/* 2227 */         (RecoveredType)this.currentElement).lastMemberEnd() < this.lastErrorEndPosition && 
/* 2228 */         Util.getLineNumber(this.lastErrorEndPosition, this.scanner.lineEnds, 0, this.scanner.linePtr) == 
/* 2229 */         Util.getLineNumber(((CompletionScanner)this.scanner).completedIdentifierStart, this.scanner.lineEnds, 0, this.scanner.linePtr)) {
/* 2230 */         return false;
/*      */       }
/* 2232 */       RecoveredType recoveredType = (RecoveredType)this.currentElement;
/*      */       
/* 2234 */       if (recoveredType.foundOpeningBrace || (
/* 2235 */         this.lastIgnoredToken == -1 && recoveredType.typeDeclaration.isRecord())) {
/*      */         
/* 2237 */         if ((this.genericsIdentifiersLengthPtr < 0 && this.identifierPtr > -1) || 
/* 2238 */           this.genericsIdentifiersLengthStack[this.genericsIdentifiersLengthPtr] <= this.identifierPtr) {
/* 2239 */           pushOnGenericsIdentifiersLengthStack(this.identifierLengthStack[this.identifierLengthPtr]);
/* 2240 */           pushOnGenericsLengthStack(0);
/*      */         } 
/* 2242 */         this.assistNode = (ASTNode)getTypeReference(0);
/* 2243 */         this.lastCheckPoint = this.assistNode.sourceEnd + 1;
/* 2244 */         this.isOrphanCompletionNode = true;
/* 2245 */         return true;
/*      */       } 
/* 2247 */       if (recoveredType.typeDeclaration.superclass == null && 
/* 2248 */         topKnownElementKind(1536) == 1053) {
/* 2249 */         consumeClassOrInterfaceName();
/* 2250 */         pushOnElementStack(1029);
/* 2251 */         this.assistNode = (ASTNode)getTypeReference(0);
/* 2252 */         popElement(1029);
/* 2253 */         this.lastCheckPoint = this.assistNode.sourceEnd + 1;
/* 2254 */         this.isOrphanCompletionNode = true;
/* 2255 */         return true;
/*      */       } 
/*      */     } 
/*      */     
/* 2259 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void classHeaderExtendsOrImplements(boolean isInterface, boolean isRecord) {
/* 2266 */     pushIdentifier();
/* 2267 */     int index = -1;
/*      */     
/* 2269 */     if (this.currentElement != null && this.currentToken == 19 && this.cursorLocation + 1 >= this.scanner.startPosition && this.cursorLocation < this.scanner.currentPosition && (index = indexOfAssistIdentifier()) > -1) {
/* 2270 */       int ptr = this.identifierPtr - this.identifierLengthStack[this.identifierLengthPtr] + index + 1;
/* 2271 */       RecoveredType recoveredType = (RecoveredType)this.currentElement;
/*      */       
/* 2273 */       if (!recoveredType.foundOpeningBrace) {
/* 2274 */         TypeDeclaration type = recoveredType.typeDeclaration;
/* 2275 */         if (!isInterface) {
/* 2276 */           char[][] keywords = new char[50][];
/* 2277 */           int count = 0;
/*      */ 
/*      */           
/* 2280 */           if (type.superInterfaces == null) {
/* 2281 */             if (!isRecord && 
/* 2282 */               type.superclass == null) {
/* 2283 */               keywords[count++] = Keywords.EXTENDS;
/*      */             }
/*      */             
/* 2286 */             keywords[count++] = Keywords.IMPLEMENTS;
/*      */           } 
/* 2288 */           if (JavaFeature.SEALED_CLASSES.isSupported(this.options)) {
/* 2289 */             boolean sealed = ((type.modifiers & 0x10000000) != 0);
/* 2290 */             if (sealed) {
/* 2291 */               keywords[count++] = RestrictedIdentifiers.PERMITS;
/*      */             }
/*      */           } 
/* 2294 */           System.arraycopy(keywords, 0, keywords = new char[count][], 0, count);
/*      */           
/* 2296 */           if (count > 0) {
/* 2297 */             CompletionOnKeyword1 completionOnKeyword = new CompletionOnKeyword1(
/* 2298 */                 this.identifierStack[ptr], 
/* 2299 */                 this.identifierPositionStack[ptr], 
/* 2300 */                 keywords);
/* 2301 */             type.superclass = (TypeReference)completionOnKeyword;
/* 2302 */             type.superclass.bits |= 0x10;
/* 2303 */             this.assistNode = (ASTNode)completionOnKeyword;
/* 2304 */             this.lastCheckPoint = completionOnKeyword.sourceEnd + 1;
/*      */           }
/*      */         
/* 2307 */         } else if (type.superInterfaces == null) {
/* 2308 */           CompletionOnKeyword1 completionOnKeyword = new CompletionOnKeyword1(
/* 2309 */               this.identifierStack[ptr], 
/* 2310 */               this.identifierPositionStack[ptr], 
/* 2311 */               Keywords.EXTENDS);
/* 2312 */           type.superInterfaces = new TypeReference[] { (TypeReference)completionOnKeyword };
/* 2313 */           (type.superInterfaces[0]).bits |= 0x10;
/* 2314 */           this.assistNode = (ASTNode)completionOnKeyword;
/* 2315 */           this.lastCheckPoint = completionOnKeyword.sourceEnd + 1;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void completionIdentifierCheck() {
/* 2331 */     if (checkMemberValueName())
/*      */       return; 
/* 2333 */     if (checkKeywordAndRestrictedIdentifiers())
/* 2334 */       return;  if (checkModuleInfoConstructs())
/* 2335 */       return;  if (checkRecoveredType())
/* 2336 */       return;  if (checkRecoveredMethod()) {
/*      */       return;
/*      */     }
/* 2339 */     if ((!isInsideMethod() || this.diet) && 
/* 2340 */       !isIndirectlyInsideFieldInitialization() && 
/* 2341 */       !isIndirectlyInsideEnumConstantnitialization() && 
/* 2342 */       !isInsideAttributeValue() && 
/* 2343 */       !isInsideModuleInfo()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2352 */     if (assistIdentifier() == null && this.currentToken == 19) {
/* 2353 */       if (this.cursorLocation < this.scanner.startPosition && this.scanner.currentPosition == this.scanner.startPosition) {
/* 2354 */         pushIdentifier();
/* 2355 */       } else if (this.cursorLocation + 1 >= this.scanner.startPosition && this.cursorLocation < this.scanner.currentPosition) {
/* 2356 */         pushIdentifier();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2363 */     if (this.assistNode != null)
/*      */     {
/*      */       
/* 2366 */       if (!isEmptyNameCompletion() || checkInvocation()) {
/*      */         return;
/*      */       }
/*      */     }
/* 2370 */     if (indexOfAssistIdentifier() < 0)
/*      */       return; 
/* 2372 */     if (checkModuleInfoConstructs())
/* 2373 */       return;  if (checkClassInstanceCreation())
/* 2374 */       return;  if (checkMemberAccess())
/* 2375 */       return;  if (checkClassLiteralAccess())
/* 2376 */       return;  if (checkInstanceofKeyword()) {
/*      */       return;
/*      */     }
/*      */     
/* 2380 */     if (checkInvocation())
/*      */       return; 
/* 2382 */     if (checkParemeterizedType())
/* 2383 */       return;  if (checkParemeterizedMethodName())
/* 2384 */       return;  if (checkLabelStatement())
/* 2385 */       return;  if (checkNameCompletion())
/*      */       return; 
/*      */   }
/*      */   protected void consumeArrayCreationExpressionWithInitializer() {
/* 2389 */     super.consumeArrayCreationExpressionWithInitializer();
/* 2390 */     popElement(1038);
/*      */   }
/*      */   
/*      */   protected void consumeArrayCreationExpressionWithoutInitializer() {
/* 2394 */     super.consumeArrayCreationExpressionWithoutInitializer();
/* 2395 */     popElement(1038);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeArrayCreationHeader() {}
/*      */ 
/*      */   
/*      */   protected void consumeAssignment() {
/* 2403 */     popElement(1041);
/* 2404 */     super.consumeAssignment();
/*      */   }
/*      */   
/*      */   protected void consumeAssignmentOperator(int pos) {
/* 2408 */     super.consumeAssignmentOperator(pos);
/* 2409 */     pushOnElementStack(1041, pos);
/*      */   }
/*      */   
/*      */   protected void consumeBinaryExpression(int op) {
/* 2413 */     super.consumeBinaryExpression(op);
/* 2414 */     popElement(1040);
/*      */     
/* 2416 */     if (this.expressionStack[this.expressionPtr] instanceof BinaryExpression) {
/* 2417 */       BinaryExpression exp = (BinaryExpression)this.expressionStack[this.expressionPtr];
/* 2418 */       if (this.assistNode != null && exp.right == this.assistNode) {
/* 2419 */         this.assistNodeParent = (ASTNode)exp;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeBinaryExpressionWithName(int op) {
/* 2425 */     super.consumeBinaryExpressionWithName(op);
/* 2426 */     popElement(1040);
/*      */     
/* 2428 */     if (this.expressionStack[this.expressionPtr] instanceof BinaryExpression) {
/* 2429 */       BinaryExpression exp = (BinaryExpression)this.expressionStack[this.expressionPtr];
/* 2430 */       if (this.assistNode != null && exp.right == this.assistNode) {
/* 2431 */         this.assistNodeParent = (ASTNode)exp;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeCaseLabel() {
/* 2437 */     super.consumeCaseLabel();
/* 2438 */     if (topKnownElementKind(1536) != 1049) {
/* 2439 */       pushOnElementStack(1049);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void consumeCastExpressionWithPrimitiveType() {
/* 2444 */     popElement(1035);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2449 */     this.expressionPtr--;
/* 2450 */     this.expressionLengthPtr--; Expression exp; TypeReference castType;
/* 2451 */     CastExpression castExpression = new CastExpression(exp = this.expressionStack[this.expressionPtr + 1], castType = (TypeReference)this.expressionStack[this.expressionPtr]);
/* 2452 */     ((Expression)castExpression).sourceStart = castType.sourceStart - 1;
/* 2453 */     ((Expression)castExpression).sourceEnd = exp.sourceEnd;
/*      */   }
/*      */   
/*      */   protected void consumeCastExpressionWithGenericsArray() {
/* 2457 */     popElement(1035);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2462 */     this.expressionPtr--;
/* 2463 */     this.expressionLengthPtr--; Expression exp; TypeReference castType;
/* 2464 */     CastExpression castExpression = new CastExpression(exp = this.expressionStack[this.expressionPtr + 1], castType = (TypeReference)this.expressionStack[this.expressionPtr]);
/* 2465 */     ((Expression)castExpression).sourceStart = castType.sourceStart - 1;
/* 2466 */     ((Expression)castExpression).sourceEnd = exp.sourceEnd;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeCastExpressionWithQualifiedGenericsArray() {
/* 2471 */     popElement(1035);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2476 */     this.expressionPtr--;
/* 2477 */     this.expressionLengthPtr--; Expression exp; TypeReference castType;
/* 2478 */     CastExpression castExpression = new CastExpression(exp = this.expressionStack[this.expressionPtr + 1], castType = (TypeReference)this.expressionStack[this.expressionPtr]);
/* 2479 */     ((Expression)castExpression).sourceStart = castType.sourceStart - 1;
/* 2480 */     ((Expression)castExpression).sourceEnd = exp.sourceEnd;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeCastExpressionWithNameArray() {
/* 2485 */     popElement(1035);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2490 */     this.expressionPtr--;
/* 2491 */     this.expressionLengthPtr--; Expression exp; TypeReference castType;
/* 2492 */     CastExpression castExpression = new CastExpression(exp = this.expressionStack[this.expressionPtr + 1], castType = (TypeReference)this.expressionStack[this.expressionPtr]);
/* 2493 */     ((Expression)castExpression).sourceStart = castType.sourceStart - 1;
/* 2494 */     ((Expression)castExpression).sourceEnd = exp.sourceEnd;
/*      */   }
/*      */   
/*      */   protected void consumeCastExpressionLL1() {
/* 2498 */     popElement(1035);
/* 2499 */     super.consumeCastExpressionLL1();
/*      */   }
/*      */   
/*      */   protected void consumeCatchFormalParameter() {
/* 2503 */     if (indexOfAssistIdentifier() < 0) {
/* 2504 */       super.consumeCatchFormalParameter();
/* 2505 */       if (this.pendingAnnotation != null) {
/* 2506 */         this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 2507 */         this.pendingAnnotation = null;
/*      */       } 
/*      */     } else {
/* 2510 */       this.identifierLengthPtr--;
/* 2511 */       char[] identifierName = this.identifierStack[this.identifierPtr];
/* 2512 */       long namePositions = this.identifierPositionStack[this.identifierPtr--];
/* 2513 */       this.intPtr--;
/* 2514 */       TypeReference type = (TypeReference)this.astStack[this.astPtr--];
/* 2515 */       this.intPtr -= 2;
/* 2516 */       CompletionOnArgumentName arg = 
/* 2517 */         new CompletionOnArgumentName(
/* 2518 */           identifierName, 
/* 2519 */           namePositions, 
/* 2520 */           type, 
/* 2521 */           this.intStack[this.intPtr + 1] & 0xFFEFFFFF);
/* 2522 */       arg.bits &= 0xFFFFFFFB;
/*      */       
/*      */       int length;
/* 2525 */       if ((length = this.expressionLengthStack[this.expressionLengthPtr--]) != 0) {
/* 2526 */         System.arraycopy(
/* 2527 */             this.expressionStack, (
/* 2528 */             this.expressionPtr -= length) + 1, 
/* 2529 */             arg.annotations = new Annotation[length], 
/* 2530 */             0, 
/* 2531 */             length);
/*      */       }
/*      */       
/* 2534 */       arg.isCatchArgument = (topKnownElementKind(1536) == 1028);
/* 2535 */       pushOnAstStack((ASTNode)arg);
/*      */       
/* 2537 */       this.assistNode = (ASTNode)arg;
/* 2538 */       this.lastCheckPoint = (int)namePositions;
/* 2539 */       this.isOrphanCompletionNode = true;
/*      */ 
/*      */ 
/*      */       
/* 2543 */       this.listLength++;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeClassBodyDeclaration() {
/* 2548 */     popElement(1025);
/* 2549 */     super.consumeClassBodyDeclaration();
/* 2550 */     this.pendingAnnotation = null;
/*      */   }
/*      */   
/*      */   protected void consumeClassBodyopt() {
/* 2554 */     popElement(1027);
/* 2555 */     popElement(1026);
/* 2556 */     super.consumeClassBodyopt();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeClassDeclaration() {
/* 2561 */     if (this.astPtr >= 0) {
/* 2562 */       int length = this.astLengthStack[this.astLengthPtr];
/* 2563 */       TypeDeclaration typeDeclaration = (TypeDeclaration)this.astStack[this.astPtr - length];
/* 2564 */       this.javadoc = null;
/* 2565 */       CompletionJavadocParser completionJavadocParser = (CompletionJavadocParser)this.javadocParser;
/* 2566 */       completionJavadocParser.allPossibleTags = true;
/* 2567 */       checkComment();
/* 2568 */       if (this.javadoc != null && this.cursorLocation > this.javadoc.sourceStart && this.cursorLocation < this.javadoc.sourceEnd)
/*      */       {
/* 2570 */         typeDeclaration.javadoc = this.javadoc;
/*      */       }
/* 2572 */       completionJavadocParser.allPossibleTags = false;
/*      */     } 
/* 2574 */     super.consumeClassDeclaration();
/*      */   }
/*      */   
/*      */   protected void consumeClassHeaderName1() {
/* 2578 */     super.consumeClassHeaderName1();
/* 2579 */     this.hasUnusedModifiers = false;
/* 2580 */     if (this.pendingAnnotation != null) {
/* 2581 */       this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 2582 */       this.pendingAnnotation = null;
/*      */     } 
/* 2584 */     classHeaderExtendsOrImplements(false, false);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeRecordHeaderPart() {
/* 2589 */     super.consumeRecordHeaderPart();
/* 2590 */     this.hasUnusedModifiers = false;
/* 2591 */     if (this.pendingAnnotation != null) {
/* 2592 */       this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 2593 */       this.pendingAnnotation = null;
/*      */     } 
/* 2595 */     classHeaderExtendsOrImplements(false, true);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeClassHeaderExtends() {
/* 2600 */     pushOnElementStack(1029);
/* 2601 */     super.consumeClassHeaderExtends();
/* 2602 */     if (this.assistNode != null && this.assistNodeParent == null) {
/* 2603 */       TypeDeclaration typeDecl = (TypeDeclaration)this.astStack[this.astPtr];
/* 2604 */       if (typeDecl != null && typeDecl.superclass == this.assistNode)
/* 2605 */         this.assistNodeParent = (ASTNode)typeDecl; 
/*      */     } 
/* 2607 */     popElement(1029);
/* 2608 */     popElement(1053);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2614 */     pushIdentifier();
/*      */     
/* 2616 */     int index = -1;
/*      */     
/* 2618 */     if (this.currentElement != null && this.currentToken == 19 && this.cursorLocation + 1 >= this.scanner.startPosition && this.cursorLocation < this.scanner.currentPosition && (index = indexOfAssistIdentifier()) > -1) {
/* 2619 */       int ptr = this.identifierPtr - this.identifierLengthStack[this.identifierLengthPtr] + index + 1;
/* 2620 */       RecoveredType recoveredType = (RecoveredType)this.currentElement;
/*      */       
/* 2622 */       if (!recoveredType.foundOpeningBrace) {
/* 2623 */         char[][] keywords = new char[2][];
/* 2624 */         int count = 0;
/* 2625 */         TypeDeclaration type = recoveredType.typeDeclaration;
/* 2626 */         if (type.superInterfaces == null) {
/* 2627 */           keywords[count++] = Keywords.IMPLEMENTS;
/*      */         }
/* 2629 */         if (JavaFeature.SEALED_CLASSES.isSupported(this.options)) {
/* 2630 */           boolean sealed = ((type.modifiers & 0x10000000) != 0);
/* 2631 */           if (sealed)
/* 2632 */             keywords[count++] = RestrictedIdentifiers.PERMITS; 
/*      */         } 
/* 2634 */         System.arraycopy(keywords, 0, keywords = new char[count][], 0, count);
/* 2635 */         if (count > 0) {
/* 2636 */           CompletionOnKeyword1 completionOnKeyword = new CompletionOnKeyword1(
/* 2637 */               this.identifierStack[ptr], 
/* 2638 */               this.identifierPositionStack[ptr], 
/* 2639 */               keywords);
/* 2640 */           type.superclass = (TypeReference)completionOnKeyword;
/* 2641 */           type.superclass.bits |= 0x10;
/* 2642 */           this.assistNode = (ASTNode)completionOnKeyword;
/* 2643 */           this.lastCheckPoint = completionOnKeyword.sourceEnd + 1;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeClassHeaderImplements() {
/* 2651 */     super.consumeClassHeaderImplements();
/* 2652 */     if (this.assistNode != null && this.assistNodeParent == null) {
/* 2653 */       TypeDeclaration typeDecl = (TypeDeclaration)this.astStack[this.astPtr];
/* 2654 */       if (typeDecl != null) {
/* 2655 */         TypeReference[] superInterfaces = typeDecl.superInterfaces;
/* 2656 */         int length = (superInterfaces == null) ? 0 : superInterfaces.length;
/* 2657 */         for (int i = 0; i < length; i++) {
/* 2658 */           if (superInterfaces[i] == this.assistNode) {
/* 2659 */             this.assistNodeParent = (ASTNode)typeDecl;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeClassInstanceCreationExpressionName() {
/* 2667 */     super.consumeClassInstanceCreationExpressionName();
/* 2668 */     this.invocationType = -5;
/* 2669 */     this.qualifier = this.expressionPtr;
/*      */   }
/*      */   
/*      */   protected void consumeClassTypeElt() {
/* 2673 */     pushOnElementStack(1031);
/* 2674 */     super.consumeClassTypeElt();
/* 2675 */     popElement(1031);
/*      */   }
/*      */   
/*      */   protected void consumeCompilationUnit() {
/* 2679 */     this.javadoc = null;
/* 2680 */     checkComment();
/* 2681 */     if (this.javadoc != null && this.cursorLocation > this.javadoc.sourceStart && this.cursorLocation < this.javadoc.sourceEnd) {
/*      */       
/* 2683 */       this.compilationUnit.javadoc = this.javadoc;
/*      */       
/* 2685 */       if (this.compilationUnit.types == null) {
/* 2686 */         this.compilationUnit.types = new TypeDeclaration[1];
/* 2687 */         TypeDeclaration declaration = new TypeDeclaration(this.compilationUnit.compilationResult);
/* 2688 */         declaration.name = FAKE_TYPE_NAME;
/* 2689 */         declaration.modifiers = 512;
/* 2690 */         this.compilationUnit.types[0] = declaration;
/*      */       } 
/*      */     } 
/* 2693 */     super.consumeCompilationUnit();
/*      */   }
/*      */   
/*      */   protected void consumeSwitchExpression() {
/* 2697 */     super.consumeSwitchExpression();
/* 2698 */     if (this.assistNode != null) {
/* 2699 */       SwitchExpression expr = (SwitchExpression)this.expressionStack[this.expressionPtr];
/* 2700 */       expr.resolveAll = true;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeConditionalExpression(int op) {
/* 2705 */     popElement(1042);
/* 2706 */     super.consumeConditionalExpression(op);
/*      */   }
/*      */   
/*      */   protected void consumeConditionalExpressionWithName(int op) {
/* 2710 */     popElement(1042);
/* 2711 */     super.consumeConditionalExpressionWithName(op);
/*      */   }
/*      */   
/*      */   protected void consumeConstructorBody() {
/* 2715 */     popElement(1025);
/* 2716 */     super.consumeConstructorBody();
/*      */   }
/*      */   
/*      */   protected void consumeConstructorHeader() {
/* 2720 */     super.consumeConstructorHeader();
/* 2721 */     pushOnElementStack(1025);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void consumeConstructorHeaderName() {
/* 2727 */     if (indexOfAssistIdentifier() < 0) {
/* 2728 */       long selectorSourcePositions = this.identifierPositionStack[this.identifierPtr];
/* 2729 */       int selectorSourceEnd = (int)selectorSourcePositions;
/* 2730 */       int currentAstPtr = this.astPtr;
/*      */       
/* 2732 */       if (this.currentElement != null && this.lastIgnoredToken == 38) {
/* 2733 */         super.consumeConstructorHeaderName();
/*      */       } else {
/* 2735 */         super.consumeConstructorHeaderName();
/* 2736 */         if (this.pendingAnnotation != null) {
/* 2737 */           this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 2738 */           this.pendingAnnotation = null;
/*      */         } 
/*      */       } 
/* 2741 */       if (this.sourceEnds != null && this.astPtr > currentAstPtr) {
/* 2742 */         this.sourceEnds.put(this.astStack[this.astPtr], selectorSourceEnd);
/*      */       }
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2748 */     if (this.currentElement == null) {
/* 2749 */       this.hasReportedError = true;
/*      */     }
/* 2751 */     pushOnGenericsIdentifiersLengthStack(this.identifierLengthStack[this.identifierLengthPtr]);
/* 2752 */     pushOnGenericsLengthStack(0);
/* 2753 */     this.restartRecovery = true;
/*      */   }
/*      */   
/*      */   protected void consumeConstructorHeaderNameWithTypeParameters() {
/* 2757 */     long selectorSourcePositions = this.identifierPositionStack[this.identifierPtr];
/* 2758 */     int selectorSourceEnd = (int)selectorSourcePositions;
/* 2759 */     int currentAstPtr = this.astPtr;
/* 2760 */     if (this.currentElement != null && this.lastIgnoredToken == 38) {
/* 2761 */       super.consumeConstructorHeaderNameWithTypeParameters();
/*      */     } else {
/* 2763 */       super.consumeConstructorHeaderNameWithTypeParameters();
/* 2764 */       if (this.pendingAnnotation != null) {
/* 2765 */         this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 2766 */         this.pendingAnnotation = null;
/*      */       } 
/*      */     } 
/* 2769 */     if (this.sourceEnds != null && this.astPtr > currentAstPtr) {
/* 2770 */       this.sourceEnds.put(this.astStack[this.astPtr], selectorSourceEnd);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void consumeDefaultLabel() {
/* 2775 */     super.consumeDefaultLabel();
/* 2776 */     if (topKnownElementKind(1536) == 1049) {
/* 2777 */       popElement(1049);
/*      */     }
/* 2779 */     pushOnElementStack(1049, 1);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeDimWithOrWithOutExpr() {
/* 2784 */     pushOnExpressionStack(null);
/*      */   }
/*      */   
/*      */   protected void consumeEmptyStatement() {
/* 2788 */     boolean shouldAttachParent = !(!(this.assistNodeParent instanceof MessageSend) && 
/* 2789 */       !(this.assistNodeParent instanceof ParameterizedSingleTypeReference) && 
/* 2790 */       !(this.assistNodeParent instanceof LocalDeclaration));
/* 2791 */     ASTNode nodeToAttach = shouldAttachParent ? this.assistNodeParent : this.assistNode;
/* 2792 */     if (this.shouldStackAssistNode && nodeToAttach != null) {
/* 2793 */       for (int ptr = this.astPtr; ptr >= 0; ptr--) {
/* 2794 */         if ((new CompletionNodeDetector(nodeToAttach, this.astStack[ptr])).containsCompletionNode()) {
/*      */           
/* 2796 */           this.astLengthStack[++this.astLengthPtr] = 0;
/* 2797 */           this.shouldStackAssistNode = false;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     }
/* 2802 */     super.consumeEmptyStatement();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2807 */     if (this.shouldStackAssistNode && this.assistNode != null) {
/* 2808 */       this.astStack[this.astPtr] = nodeToAttach;
/*      */     }
/* 2810 */     this.shouldStackAssistNode = false;
/*      */   }
/*      */   
/*      */   protected void consumeBlockStatement() {
/* 2814 */     super.consumeBlockStatement();
/* 2815 */     if (this.shouldStackAssistNode && this.assistNode != null) {
/* 2816 */       Statement stmt = (Statement)this.astStack[this.astPtr];
/* 2817 */       if (stmt.sourceStart <= this.assistNode.sourceStart && stmt.sourceEnd >= this.assistNode.sourceEnd)
/* 2818 */         this.shouldStackAssistNode = false; 
/*      */     } 
/* 2820 */     if (this.currentElement != null && 
/* 2821 */       this.scanner.currentPosition > this.cursorLocation && 
/* 2822 */       this.astLengthStack[this.astLengthPtr] == 1 && 
/* 2823 */       topKnownElementKind(1536) == 1025) {
/*      */ 
/*      */       
/* 2826 */       Statement stmt = (Statement)this.astStack[this.astPtr];
/* 2827 */       Statement newStatement = buildMoreCompletionEnclosingContext(stmt);
/* 2828 */       if (newStatement != this.astStack[this.astPtr]) {
/* 2829 */         RecoveredElement newElement = this.currentElement.add(newStatement, 0);
/* 2830 */         this.currentElement = newElement;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeEnhancedForStatement() {
/* 2836 */     super.consumeEnhancedForStatement();
/*      */     
/* 2838 */     if (topKnownElementKind(1536) == 1062) {
/* 2839 */       popElement(1062);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void consumeEnhancedForStatementHeader() {
/* 2844 */     this.consumedEnhancedFor = true;
/* 2845 */     super.consumeEnhancedForStatementHeader();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void consumeEnhancedForStatementHeaderInit(boolean hasModifiers) {
/* 2851 */     super.consumeEnhancedForStatementHeaderInit(hasModifiers);
/* 2852 */     this.hasUnusedModifiers = false;
/* 2853 */     if (this.pendingAnnotation != null) {
/* 2854 */       this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 2855 */       this.pendingAnnotation = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeEnterAnonymousClassBody(boolean qualified) {
/* 2860 */     popElement(1027);
/* 2861 */     popElement(1026);
/* 2862 */     super.consumeEnterAnonymousClassBody(qualified);
/*      */   }
/*      */   
/*      */   protected void consumeEnterVariable() {
/* 2866 */     this.identifierPtr--;
/* 2867 */     this.identifierLengthPtr--;
/*      */     
/* 2869 */     boolean isLocalDeclaration = (this.nestedMethod[this.nestedType] != 0);
/* 2870 */     int variableIndex = this.variablesCounter[this.nestedType];
/*      */     
/* 2872 */     this.hasUnusedModifiers = false;
/*      */     
/* 2874 */     if (isLocalDeclaration || indexOfAssistIdentifier() < 0 || variableIndex != 0) {
/* 2875 */       this.identifierPtr++;
/* 2876 */       this.identifierLengthPtr++;
/*      */       
/* 2878 */       if (this.pendingAnnotation != null && 
/* 2879 */         this.assistNode != null && 
/* 2880 */         this.currentElement != null && 
/* 2881 */         this.currentElement instanceof RecoveredMethod && 
/* 2882 */         !this.currentElement.foundOpeningBrace && 
/* 2883 */         ((RecoveredMethod)this.currentElement).methodDeclaration.declarationSourceEnd == 0) {
/*      */         
/* 2885 */         super.consumeEnterVariable();
/* 2886 */         this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 2887 */         this.pendingAnnotation.isParameter = true;
/* 2888 */         this.pendingAnnotation = null;
/*      */       } else {
/*      */         
/* 2891 */         super.consumeEnterVariable();
/* 2892 */         if (this.pendingAnnotation != null) {
/* 2893 */           this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 2894 */           this.pendingAnnotation = null;
/*      */         } 
/*      */       } 
/*      */     } else {
/* 2898 */       this.restartRecovery = true;
/*      */ 
/*      */       
/* 2901 */       if (this.currentElement != null && 
/* 2902 */         !checkKeywordAndRestrictedIdentifiers() && (!(this.currentElement instanceof RecoveredUnit) || ((RecoveredUnit)this.currentElement).typeCount != 0)) {
/* 2903 */         int nameSourceStart = (int)(this.identifierPositionStack[this.identifierPtr] >>> 32L);
/* 2904 */         this.intPtr--;
/* 2905 */         TypeReference type = getTypeReference(this.intStack[this.intPtr--]);
/* 2906 */         this.intPtr--;
/*      */         
/* 2908 */         if (!(this.currentElement instanceof RecoveredType) && (
/* 2909 */           this.currentToken == 1 || 
/* 2910 */           Util.getLineNumber(type.sourceStart, this.scanner.lineEnds, 0, this.scanner.linePtr) != 
/* 2911 */           Util.getLineNumber(nameSourceStart, this.scanner.lineEnds, 0, this.scanner.linePtr))) {
/* 2912 */           this.lastCheckPoint = nameSourceStart;
/* 2913 */           this.restartRecovery = true;
/*      */           
/*      */           return;
/*      */         } 
/* 2917 */         FieldDeclaration completionFieldDecl = new CompletionOnFieldType(type, false);
/*      */         
/*      */         int length;
/* 2920 */         if ((length = this.expressionLengthStack[this.expressionLengthPtr--]) != 0) {
/* 2921 */           System.arraycopy(
/* 2922 */               this.expressionStack, (
/* 2923 */               this.expressionPtr -= length) + 1, 
/* 2924 */               completionFieldDecl.annotations = new Annotation[length], 
/* 2925 */               0, 
/* 2926 */               length);
/*      */         }
/* 2928 */         completionFieldDecl.modifiers = this.intStack[this.intPtr--];
/* 2929 */         this.assistNode = (ASTNode)completionFieldDecl;
/* 2930 */         this.lastCheckPoint = type.sourceEnd + 1;
/* 2931 */         this.currentElement = this.currentElement.add(completionFieldDecl, 0);
/* 2932 */         this.lastIgnoredToken = -1;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeEnumConstantHeaderName() {
/* 2939 */     if (this.currentElement != null && ((
/* 2940 */       !(this.currentElement instanceof RecoveredType) && (
/* 2941 */       !(this.currentElement instanceof RecoveredField) || ((RecoveredField)this.currentElement).fieldDeclaration.type != null)) || 
/* 2942 */       this.lastIgnoredToken == 1)) {
/* 2943 */       super.consumeEnumConstantHeaderName();
/*      */       
/*      */       return;
/*      */     } 
/* 2947 */     super.consumeEnumConstantHeaderName();
/* 2948 */     if (this.pendingAnnotation != null) {
/* 2949 */       this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 2950 */       this.pendingAnnotation = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeEnumConstantNoClassBody() {
/* 2955 */     super.consumeEnumConstantNoClassBody();
/* 2956 */     if ((this.currentToken == 32 || this.currentToken == 24) && 
/* 2957 */       this.astStack[this.astPtr] instanceof FieldDeclaration && 
/* 2958 */       this.sourceEnds != null) {
/* 2959 */       this.sourceEnds.put(this.astStack[this.astPtr], this.scanner.currentPosition - 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeEnumConstantWithClassBody() {
/* 2965 */     super.consumeEnumConstantWithClassBody();
/* 2966 */     if ((this.currentToken == 32 || this.currentToken == 24) && 
/* 2967 */       this.astStack[this.astPtr] instanceof FieldDeclaration && 
/* 2968 */       this.sourceEnds != null) {
/* 2969 */       this.sourceEnds.put(this.astStack[this.astPtr], this.scanner.currentPosition - 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeEnumHeaderName() {
/* 2975 */     super.consumeEnumHeaderName();
/* 2976 */     this.hasUnusedModifiers = false;
/* 2977 */     if (this.pendingAnnotation != null) {
/* 2978 */       this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 2979 */       this.pendingAnnotation = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeEnumHeaderNameWithTypeParameters() {
/* 2984 */     super.consumeEnumHeaderNameWithTypeParameters();
/* 2985 */     if (this.pendingAnnotation != null) {
/* 2986 */       this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 2987 */       this.pendingAnnotation = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeEqualityExpression(int op) {
/* 2992 */     super.consumeEqualityExpression(op);
/* 2993 */     popElement(1040);
/*      */     
/* 2995 */     BinaryExpression exp = (BinaryExpression)this.expressionStack[this.expressionPtr];
/* 2996 */     if (this.assistNode != null && exp.right == this.assistNode) {
/* 2997 */       this.assistNodeParent = (ASTNode)exp;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void consumeEqualityExpressionWithName(int op) {
/* 3002 */     super.consumeEqualityExpressionWithName(op);
/* 3003 */     popElement(1040);
/*      */     
/* 3005 */     BinaryExpression exp = (BinaryExpression)this.expressionStack[this.expressionPtr];
/* 3006 */     if (this.assistNode != null && exp.right == this.assistNode) {
/* 3007 */       this.assistNodeParent = (ASTNode)exp;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void consumeExitVariableWithInitialization() {
/* 3012 */     super.consumeExitVariableWithInitialization();
/* 3013 */     if ((this.currentToken == 32 || this.currentToken == 24) && 
/* 3014 */       this.astStack[this.astPtr] instanceof FieldDeclaration && 
/* 3015 */       this.sourceEnds != null) {
/* 3016 */       this.sourceEnds.put(this.astStack[this.astPtr], this.scanner.currentPosition - 1);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3021 */     AbstractVariableDeclaration variable = (AbstractVariableDeclaration)this.astStack[this.astPtr];
/* 3022 */     if (this.cursorLocation + 1 < variable.initialization.sourceStart || 
/* 3023 */       this.cursorLocation > variable.initialization.sourceEnd) {
/* 3024 */       if (!variable.type.isTypeNameVar(null) && (
/* 3025 */         !(variable instanceof LocalDeclaration) || !((LocalDeclaration)variable).isTypeNameVar((Scope)this.compilationUnit.scope))) {
/* 3026 */         variable.initialization = null;
/*      */       }
/*      */     }
/* 3029 */     else if (this.assistNode != null && this.assistNode == variable.initialization) {
/* 3030 */       this.assistNodeParent = (ASTNode)variable;
/*      */     } 
/* 3032 */     if (triggerRecoveryUponLambdaClosure((Statement)variable, false) && 
/* 3033 */       this.currentElement != null) {
/* 3034 */       this.restartRecovery = true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void consumeExitVariableWithoutInitialization() {
/* 3042 */     super.consumeExitVariableWithoutInitialization();
/* 3043 */     if ((this.currentToken == 32 || this.currentToken == 24) && 
/* 3044 */       this.astStack[this.astPtr] instanceof FieldDeclaration && 
/* 3045 */       this.sourceEnds != null) {
/* 3046 */       this.sourceEnds.put(this.astStack[this.astPtr], this.scanner.currentPosition - 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeExplicitConstructorInvocation(int flag, int recFlag) {
/* 3052 */     popElement(1027);
/* 3053 */     popElement(1026);
/* 3054 */     super.consumeExplicitConstructorInvocation(flag, recFlag);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void consumeFieldAccess(boolean isSuperAccess) {
/* 3067 */     this.invocationType = -1;
/* 3068 */     this.qualifier = -1;
/*      */     
/* 3070 */     if (indexOfAssistIdentifier() < 0) {
/* 3071 */       super.consumeFieldAccess(isSuperAccess);
/*      */     } else {
/* 3073 */       pushCompletionOnMemberAccessOnExpressionStack(isSuperAccess);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeForceNoDiet() {
/* 3078 */     super.consumeForceNoDiet();
/* 3079 */     if (isInsideMethod()) {
/* 3080 */       pushOnElementStack(1036);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeFormalParameter(boolean isVarArgs) {
/* 3086 */     this.invocationType = -1;
/* 3087 */     this.qualifier = -1;
/*      */     
/* 3089 */     if (indexOfAssistIdentifier() < 0) {
/* 3090 */       super.consumeFormalParameter(isVarArgs);
/* 3091 */       if (this.pendingAnnotation != null) {
/* 3092 */         this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 3093 */         this.pendingAnnotation = null;
/*      */       } 
/*      */     } else {
/* 3096 */       boolean isReceiver = (this.intStack[this.intPtr--] == 0);
/* 3097 */       if (isReceiver) {
/* 3098 */         this.expressionPtr--;
/* 3099 */         this.expressionLengthPtr--;
/*      */       } 
/* 3101 */       this.identifierLengthPtr--;
/* 3102 */       char[] identifierName = this.identifierStack[this.identifierPtr];
/* 3103 */       long namePositions = this.identifierPositionStack[this.identifierPtr--];
/* 3104 */       int extendedDimensions = this.intStack[this.intPtr--];
/* 3105 */       Annotation[][] annotationsOnExtendedDimensions = (extendedDimensions == 0) ? null : getAnnotationsOnDimensions(extendedDimensions);
/* 3106 */       Annotation[] varArgsAnnotations = null;
/*      */       
/* 3108 */       int endOfEllipsis = 0;
/*      */       
/* 3110 */       endOfEllipsis = this.intStack[this.intPtr--]; int length;
/* 3111 */       if (isVarArgs && (length = this.typeAnnotationLengthStack[this.typeAnnotationLengthPtr--]) != 0) {
/* 3112 */         System.arraycopy(
/* 3113 */             this.typeAnnotationStack, (
/* 3114 */             this.typeAnnotationPtr -= length) + 1, 
/* 3115 */             varArgsAnnotations = new Annotation[length], 
/* 3116 */             0, 
/* 3117 */             length);
/*      */       }
/*      */       
/* 3120 */       int firstDimensions = this.intStack[this.intPtr--];
/* 3121 */       TypeReference type = getTypeReference(firstDimensions);
/*      */       
/* 3123 */       if (isVarArgs || extendedDimensions != 0) {
/* 3124 */         if (isVarArgs) {
/* 3125 */           (new Annotation[1][])[0] = varArgsAnnotations; type = augmentTypeWithAdditionalDimensions(type, 1, (varArgsAnnotations != null) ? new Annotation[1][] : null, true);
/*      */         } 
/* 3127 */         if (extendedDimensions != 0) {
/* 3128 */           type = augmentTypeWithAdditionalDimensions(type, extendedDimensions, annotationsOnExtendedDimensions, false);
/*      */         }
/* 3130 */         type.sourceEnd = type.isParameterizedTypeReference() ? this.endStatementPosition : this.endPosition;
/*      */       } 
/* 3132 */       if (isVarArgs) {
/* 3133 */         if (extendedDimensions == 0) {
/* 3134 */           type.sourceEnd = endOfEllipsis;
/*      */         }
/* 3136 */         type.bits |= 0x4000;
/*      */       } 
/* 3138 */       this.intPtr -= 2;
/* 3139 */       CompletionOnArgumentName arg = 
/* 3140 */         new CompletionOnArgumentName(
/* 3141 */           identifierName, 
/* 3142 */           namePositions, 
/* 3143 */           type, 
/* 3144 */           this.intStack[this.intPtr + 1] & 0xFFEFFFFF);
/*      */       
/* 3146 */       if ((length = this.expressionLengthStack[this.expressionLengthPtr--]) != 0) {
/* 3147 */         System.arraycopy(
/* 3148 */             this.expressionStack, (
/* 3149 */             this.expressionPtr -= length) + 1, 
/* 3150 */             arg.annotations = new Annotation[length], 
/* 3151 */             0, 
/* 3152 */             length);
/* 3153 */         RecoveredType currentRecoveryType = currentRecoveryType();
/* 3154 */         if (currentRecoveryType != null) {
/* 3155 */           currentRecoveryType.annotationsConsumed(arg.annotations);
/*      */         }
/*      */       } 
/* 3158 */       arg.isCatchArgument = (topKnownElementKind(1536) == 1028);
/* 3159 */       pushOnAstStack((ASTNode)arg);
/*      */       
/* 3161 */       this.assistNode = (ASTNode)arg;
/* 3162 */       this.lastCheckPoint = (int)namePositions;
/* 3163 */       this.isOrphanCompletionNode = true;
/*      */ 
/*      */ 
/*      */       
/* 3167 */       this.listLength++;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeGenericTypeWithDiamond() {
/* 3172 */     super.consumeGenericTypeWithDiamond();
/*      */ 
/*      */ 
/*      */     
/* 3176 */     popElement(1040);
/* 3177 */     popElement(1040);
/*      */   }
/*      */   
/*      */   protected void consumeStatementFor() {
/* 3181 */     super.consumeStatementFor();
/*      */     
/* 3183 */     if (topKnownElementKind(1536) == 1062) {
/* 3184 */       popElement(1062);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void consumeStatementIfNoElse() {
/* 3189 */     super.consumeStatementIfNoElse();
/*      */     
/* 3191 */     if (topKnownElementKind(1536) == 1062) {
/* 3192 */       popElement(1062);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void consumeStatementIfWithElse() {
/* 3197 */     super.consumeStatementIfWithElse();
/*      */     
/* 3199 */     if (topKnownElementKind(1536) == 1062)
/* 3200 */       popElement(1062); 
/*      */   }
/*      */   
/*      */   protected void consumeInsideCastExpression() {
/*      */     IntersectionCastTypeReference intersectionCastTypeReference;
/* 3205 */     TypeReference[] bounds = null;
/* 3206 */     int additionalBoundsLength = this.genericsLengthStack[this.genericsLengthPtr--];
/* 3207 */     if (additionalBoundsLength > 0) {
/* 3208 */       bounds = new TypeReference[additionalBoundsLength + 1];
/* 3209 */       this.genericsPtr -= additionalBoundsLength;
/* 3210 */       System.arraycopy(this.genericsStack, this.genericsPtr + 1, bounds, 1, additionalBoundsLength);
/*      */     } 
/*      */     
/* 3213 */     int end = this.intStack[this.intPtr--];
/* 3214 */     boolean isParameterized = (topKnownElementKind(1536) == 1056);
/* 3215 */     if (isParameterized) {
/* 3216 */       popElement(1056);
/*      */       
/* 3218 */       if (this.identifierLengthStack[this.identifierLengthPtr] > 0) {
/* 3219 */         pushOnGenericsIdentifiersLengthStack(this.identifierLengthStack[this.identifierLengthPtr]);
/*      */       }
/*      */     }
/* 3222 */     else if (this.identifierLengthStack[this.identifierLengthPtr] > 0) {
/* 3223 */       pushOnGenericsIdentifiersLengthStack(this.identifierLengthStack[this.identifierLengthPtr]);
/* 3224 */       pushOnGenericsLengthStack(0);
/*      */     } 
/*      */     
/* 3227 */     TypeReference typeReference = getTypeReference(this.intStack[this.intPtr--]);
/* 3228 */     if (additionalBoundsLength > 0) {
/* 3229 */       bounds[0] = typeReference;
/* 3230 */       intersectionCastTypeReference = createIntersectionCastTypeReference(bounds);
/*      */     } 
/* 3232 */     if (isParameterized) {
/* 3233 */       this.intPtr--;
/*      */     }
/* 3235 */     ((Expression)intersectionCastTypeReference).sourceEnd = end - 1;
/* 3236 */     ((Expression)intersectionCastTypeReference).sourceStart = this.intStack[this.intPtr--] + 1;
/* 3237 */     pushOnExpressionStack((Expression)intersectionCastTypeReference);
/*      */     
/* 3239 */     pushOnElementStack(1035);
/*      */   }
/*      */   
/*      */   protected void consumeInsideCastExpressionLL1() {
/* 3243 */     if (topKnownElementKind(1536) == 1056) {
/* 3244 */       popElement(1056);
/*      */     }
/* 3246 */     if (!this.record) {
/* 3247 */       super.consumeInsideCastExpressionLL1();
/*      */     } else {
/* 3249 */       boolean temp = this.skipRecord;
/*      */       try {
/* 3251 */         this.skipRecord = true;
/* 3252 */         super.consumeInsideCastExpressionLL1();
/* 3253 */         if (this.record) {
/* 3254 */           Expression typeReference = this.expressionStack[this.expressionPtr];
/* 3255 */           if (!isAlreadyPotentialName(typeReference.sourceStart)) {
/* 3256 */             addPotentialName((char[])null, typeReference.sourceStart, typeReference.sourceEnd);
/*      */           }
/*      */         } 
/*      */       } finally {
/* 3260 */         this.skipRecord = temp;
/*      */       } 
/*      */     } 
/* 3263 */     pushOnElementStack(1035);
/*      */   }
/*      */   
/*      */   protected void consumeInsideCastExpressionLL1WithBounds() {
/* 3267 */     if (topKnownElementKind(1536) == 1056) {
/* 3268 */       popElement(1056);
/*      */     }
/* 3270 */     if (!this.record) {
/* 3271 */       super.consumeInsideCastExpressionLL1WithBounds();
/*      */     } else {
/* 3273 */       boolean temp = this.skipRecord;
/*      */       try {
/* 3275 */         this.skipRecord = true;
/* 3276 */         super.consumeInsideCastExpressionLL1WithBounds();
/* 3277 */         if (this.record) {
/* 3278 */           int length = this.expressionLengthStack[this.expressionLengthPtr];
/* 3279 */           for (int i = 0; i < length; i++) {
/* 3280 */             Expression typeReference = this.expressionStack[this.expressionPtr - length + i + 1];
/* 3281 */             if (!isAlreadyPotentialName(typeReference.sourceStart)) {
/* 3282 */               addPotentialName((char[])null, typeReference.sourceStart, typeReference.sourceEnd);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } finally {
/* 3287 */         this.skipRecord = temp;
/*      */       } 
/*      */     } 
/* 3290 */     pushOnElementStack(1035);
/*      */   }
/*      */   protected void consumeInsideCastExpressionWithQualifiedGenerics() {
/*      */     IntersectionCastTypeReference intersectionCastTypeReference;
/* 3294 */     popElement(1056);
/*      */ 
/*      */     
/* 3297 */     int end = this.intStack[this.intPtr--];
/*      */     
/* 3299 */     int dim = this.intStack[this.intPtr--];
/* 3300 */     Annotation[][] annotationsOnDimensions = (dim == 0) ? null : getAnnotationsOnDimensions(dim);
/*      */     
/* 3302 */     TypeReference[] bounds = null;
/* 3303 */     int additionalBoundsLength = this.genericsLengthStack[this.genericsLengthPtr--];
/* 3304 */     if (additionalBoundsLength > 0) {
/* 3305 */       bounds = new TypeReference[additionalBoundsLength + 1];
/* 3306 */       this.genericsPtr -= additionalBoundsLength;
/* 3307 */       System.arraycopy(this.genericsStack, this.genericsPtr + 1, bounds, 1, additionalBoundsLength);
/*      */     } 
/*      */     
/* 3310 */     TypeReference rightSide = getTypeReference(0);
/*      */     
/* 3312 */     ParameterizedQualifiedTypeReference parameterizedQualifiedTypeReference = computeQualifiedGenericsFromRightSide(rightSide, dim, annotationsOnDimensions);
/* 3313 */     if (additionalBoundsLength > 0) {
/* 3314 */       bounds[0] = (TypeReference)parameterizedQualifiedTypeReference;
/* 3315 */       intersectionCastTypeReference = createIntersectionCastTypeReference(bounds);
/*      */     } 
/* 3317 */     this.intPtr--;
/* 3318 */     ((Expression)intersectionCastTypeReference).sourceEnd = end - 1;
/* 3319 */     ((Expression)intersectionCastTypeReference).sourceStart = this.intStack[this.intPtr--] + 1;
/* 3320 */     pushOnExpressionStack((Expression)intersectionCastTypeReference);
/*      */     
/* 3322 */     pushOnElementStack(1035);
/*      */   }
/*      */   
/*      */   protected void consumeInstanceOfExpression() {
/* 3326 */     super.consumeInstanceOfExpression();
/* 3327 */     popElement(1040);
/*      */     
/* 3329 */     if (topKnownElementKind(1536) == 1043) {
/* 3330 */       pushOnElementStack(1065, 1, this.expressionStack[this.expressionPtr]);
/*      */     }
/*      */     
/* 3333 */     InstanceOfExpression exp = (InstanceOfExpression)this.expressionStack[this.expressionPtr];
/* 3334 */     if (this.assistNode != null && exp.type == this.assistNode) {
/* 3335 */       this.assistNodeParent = (ASTNode)exp;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void consumeInstanceOfExpressionWithName() {
/* 3340 */     super.consumeInstanceOfExpressionWithName();
/* 3341 */     popElement(1040);
/*      */     
/* 3343 */     InstanceOfExpression exp = (InstanceOfExpression)this.expressionStack[this.expressionPtr];
/* 3344 */     if (this.assistNode != null && exp.type == this.assistNode) {
/* 3345 */       this.assistNodeParent = (ASTNode)exp;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void consumeInterfaceHeaderName1() {
/* 3350 */     super.consumeInterfaceHeaderName1();
/* 3351 */     this.hasUnusedModifiers = false;
/* 3352 */     if (this.pendingAnnotation != null) {
/* 3353 */       this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 3354 */       this.pendingAnnotation = null;
/*      */     } 
/* 3356 */     classHeaderExtendsOrImplements(true, false);
/*      */   }
/*      */   
/*      */   protected void consumeInterfaceHeaderExtends() {
/* 3360 */     super.consumeInterfaceHeaderExtends();
/* 3361 */     popElement(1053);
/*      */   }
/*      */   
/*      */   protected void consumeInterfaceType() {
/* 3365 */     pushOnElementStack(1030);
/* 3366 */     super.consumeInterfaceType();
/* 3367 */     popElement(1030);
/*      */   }
/*      */   
/*      */   protected void consumeMethodInvocationName() {
/* 3371 */     popElement(1027);
/* 3372 */     popElement(1026);
/* 3373 */     super.consumeMethodInvocationName();
/* 3374 */     adjustPositionsOfMessageSendOnStack();
/*      */   }
/*      */   
/*      */   protected void consumeMethodInvocationNameWithTypeArguments() {
/* 3378 */     popElement(1027);
/* 3379 */     popElement(1026);
/* 3380 */     super.consumeMethodInvocationNameWithTypeArguments();
/* 3381 */     adjustPositionsOfMessageSendOnStack();
/*      */   }
/*      */   
/*      */   protected void consumeMethodInvocationPrimary() {
/* 3385 */     popElement(1027);
/* 3386 */     popElement(1026);
/* 3387 */     super.consumeMethodInvocationPrimary();
/* 3388 */     adjustPositionsOfMessageSendOnStack();
/*      */   }
/*      */   
/*      */   protected void consumeMethodInvocationPrimaryWithTypeArguments() {
/* 3392 */     popElement(1027);
/* 3393 */     popElement(1026);
/* 3394 */     super.consumeMethodInvocationPrimaryWithTypeArguments();
/* 3395 */     adjustPositionsOfMessageSendOnStack();
/*      */   }
/*      */   
/*      */   protected void consumeMethodInvocationSuper() {
/* 3399 */     popElement(1027);
/* 3400 */     popElement(1026);
/* 3401 */     super.consumeMethodInvocationSuper();
/* 3402 */     adjustPositionsOfMessageSendOnStack();
/*      */   }
/*      */   protected void adjustPositionsOfMessageSendOnStack() {
/* 3405 */     MessageSend messageSend = (MessageSend)this.expressionStack[this.expressionPtr];
/* 3406 */     if (messageSend instanceof CompletionOnMessageSendName) {
/* 3407 */       CompletionScanner completionScanner = (CompletionScanner)this.scanner;
/* 3408 */       messageSend.sourceStart = completionScanner.completedIdentifierStart;
/* 3409 */       messageSend.sourceEnd = completionScanner.completedIdentifierEnd;
/* 3410 */     } else if (messageSend instanceof CompletionOnMessageSend) {
/* 3411 */       messageSend.sourceStart = messageSend.nameSourceStart();
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeMethodInvocationSuperWithTypeArguments() {
/* 3416 */     popElement(1027);
/* 3417 */     popElement(1026);
/* 3418 */     super.consumeMethodInvocationSuperWithTypeArguments();
/*      */   }
/*      */   
/*      */   protected void consumeMethodHeaderName(boolean isAnnotationMethod) {
/* 3422 */     if (indexOfAssistIdentifier() < 0) {
/* 3423 */       this.identifierPtr--;
/* 3424 */       this.identifierLengthPtr--;
/* 3425 */       if (indexOfAssistIdentifier() != 0 || 
/* 3426 */         this.identifierLengthStack[this.identifierLengthPtr] != this.genericsIdentifiersLengthStack[this.genericsIdentifiersLengthPtr]) {
/* 3427 */         this.identifierPtr++;
/* 3428 */         this.identifierLengthPtr++;
/* 3429 */         long selectorSourcePositions = this.identifierPositionStack[this.identifierPtr];
/* 3430 */         int selectorSourceEnd = (int)selectorSourcePositions;
/* 3431 */         int currentAstPtr = this.astPtr;
/* 3432 */         super.consumeMethodHeaderName(isAnnotationMethod);
/* 3433 */         if (this.sourceEnds != null && this.astPtr > currentAstPtr) {
/* 3434 */           this.sourceEnds.put(this.astStack[this.astPtr], selectorSourceEnd);
/*      */         }
/* 3436 */         if (this.pendingAnnotation != null) {
/* 3437 */           this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 3438 */           this.pendingAnnotation = null;
/*      */         } 
/*      */       } else {
/* 3441 */         this.restartRecovery = true;
/*      */ 
/*      */         
/* 3444 */         if (this.currentElement != null) {
/*      */           
/* 3446 */           char[] selector = this.identifierStack[this.identifierPtr + 1];
/* 3447 */           long selectorSource = this.identifierPositionStack[this.identifierPtr + 1];
/*      */ 
/*      */           
/* 3450 */           TypeReference type = getTypeReference(this.intStack[this.intPtr--]);
/* 3451 */           ((CompletionOnSingleTypeReference)type).isCompletionNode = false;
/*      */           
/* 3453 */           int declarationSourceStart = this.intStack[this.intPtr--];
/* 3454 */           int mod = this.intStack[this.intPtr--];
/*      */           
/* 3456 */           if (Util.getLineNumber(type.sourceStart, this.scanner.lineEnds, 0, this.scanner.linePtr) != 
/* 3457 */             Util.getLineNumber((int)(selectorSource >>> 32L), this.scanner.lineEnds, 0, this.scanner.linePtr)) {
/* 3458 */             FieldDeclaration completionFieldDecl = new CompletionOnFieldType(type, false);
/*      */             
/*      */             int length;
/* 3461 */             if ((length = this.expressionLengthStack[this.expressionLengthPtr--]) != 0) {
/* 3462 */               System.arraycopy(
/* 3463 */                   this.expressionStack, (
/* 3464 */                   this.expressionPtr -= length) + 1, 
/* 3465 */                   completionFieldDecl.annotations = new Annotation[length], 
/* 3466 */                   0, 
/* 3467 */                   length);
/*      */             }
/* 3469 */             completionFieldDecl.modifiers = mod;
/* 3470 */             this.assistNode = (ASTNode)completionFieldDecl;
/* 3471 */             this.lastCheckPoint = type.sourceEnd + 1;
/* 3472 */             this.currentElement = this.currentElement.add(completionFieldDecl, 0);
/* 3473 */             this.lastIgnoredToken = -1;
/*      */           } else {
/* 3475 */             CompletionOnMethodReturnType md = new CompletionOnMethodReturnType(type, this.compilationUnit.compilationResult);
/*      */             
/*      */             int length;
/* 3478 */             if ((length = this.expressionLengthStack[this.expressionLengthPtr--]) != 0) {
/* 3479 */               System.arraycopy(
/* 3480 */                   this.expressionStack, (
/* 3481 */                   this.expressionPtr -= length) + 1, 
/* 3482 */                   md.annotations = new Annotation[length], 
/* 3483 */                   0, 
/* 3484 */                   length);
/*      */             }
/* 3486 */             md.selector = selector;
/* 3487 */             md.declarationSourceStart = declarationSourceStart;
/* 3488 */             md.modifiers = mod;
/* 3489 */             md.bodyStart = this.lParenPos + 1;
/* 3490 */             this.listLength = 0;
/* 3491 */             this.assistNode = (ASTNode)md;
/* 3492 */             this.lastCheckPoint = md.bodyStart;
/* 3493 */             this.currentElement = this.currentElement.add((AbstractMethodDeclaration)md, 0);
/* 3494 */             this.lastIgnoredToken = -1;
/*      */             
/* 3496 */             md.javadoc = this.javadoc;
/* 3497 */             this.javadoc = null;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/* 3503 */       CompletionOnMethodName md = new CompletionOnMethodName(this.compilationUnit.compilationResult);
/*      */ 
/*      */       
/* 3506 */       md.selector = this.identifierStack[this.identifierPtr];
/* 3507 */       long selectorSource = this.identifierPositionStack[this.identifierPtr--];
/* 3508 */       this.identifierLengthPtr--;
/*      */       
/* 3510 */       md.returnType = getTypeReference(this.intStack[this.intPtr--]);
/* 3511 */       md.bits |= md.returnType.bits & 0x100000;
/*      */       
/* 3513 */       md.declarationSourceStart = this.intStack[this.intPtr--];
/* 3514 */       md.modifiers = this.intStack[this.intPtr--];
/*      */       
/*      */       int length;
/* 3517 */       if ((length = this.expressionLengthStack[this.expressionLengthPtr--]) != 0) {
/* 3518 */         System.arraycopy(
/* 3519 */             this.expressionStack, (
/* 3520 */             this.expressionPtr -= length) + 1, 
/* 3521 */             md.annotations = new Annotation[length], 
/* 3522 */             0, 
/* 3523 */             length);
/*      */       }
/*      */       
/* 3526 */       md.javadoc = this.javadoc;
/* 3527 */       this.javadoc = null;
/*      */ 
/*      */       
/* 3530 */       md.sourceStart = (int)(selectorSource >>> 32L);
/* 3531 */       md.selectorEnd = (int)selectorSource;
/* 3532 */       pushOnAstStack((ASTNode)md);
/* 3533 */       md.sourceEnd = this.lParenPos;
/* 3534 */       md.bodyStart = this.lParenPos + 1;
/* 3535 */       this.listLength = 0;
/*      */       
/* 3537 */       this.assistNode = (ASTNode)md;
/* 3538 */       this.lastCheckPoint = md.sourceEnd;
/*      */       
/* 3540 */       if (this.currentElement != null) {
/* 3541 */         if (!(this.currentElement instanceof RecoveredType)) {
/*      */           
/* 3543 */           if (Util.getLineNumber(md.returnType.sourceStart, this.scanner.lineEnds, 0, this.scanner.linePtr) == 
/* 3544 */             Util.getLineNumber(md.sourceStart, this.scanner.lineEnds, 0, this.scanner.linePtr)) {
/* 3545 */             this.lastCheckPoint = md.bodyStart;
/* 3546 */             this.currentElement = this.currentElement.add((AbstractMethodDeclaration)md, 0);
/* 3547 */             this.lastIgnoredToken = -1;
/*      */           } 
/* 3549 */           this.lastCheckPoint = md.sourceStart;
/* 3550 */           this.restartRecovery = true; return;
/*      */         } 
/*      */       } else {
/*      */         return;
/*      */       }  this.lastCheckPoint = md.bodyStart;
/*      */       this.currentElement = this.currentElement.add((AbstractMethodDeclaration)md, 0);
/*      */       this.lastIgnoredToken = -1;
/* 3557 */     }  } protected void consumeMethodHeaderNameWithTypeParameters(boolean isAnnotationMethod) { long selectorSourcePositions = this.identifierPositionStack[this.identifierPtr];
/* 3558 */     int selectorSourceEnd = (int)selectorSourcePositions;
/* 3559 */     int currentAstPtr = this.astPtr;
/* 3560 */     super.consumeMethodHeaderNameWithTypeParameters(isAnnotationMethod);
/* 3561 */     if (this.sourceEnds != null && this.astPtr > currentAstPtr) {
/* 3562 */       this.sourceEnds.put(this.astStack[this.astPtr], selectorSourceEnd);
/*      */     }
/* 3564 */     if (this.pendingAnnotation != null) {
/* 3565 */       this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 3566 */       this.pendingAnnotation = null;
/*      */     }  }
/*      */ 
/*      */   
/*      */   protected void consumeMethodHeaderRightParen() {
/* 3571 */     super.consumeMethodHeaderRightParen();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3577 */     pushIdentifier();
/*      */     
/* 3579 */     int index = -1;
/*      */     
/* 3581 */     if (this.currentElement != null && this.currentToken == 19 && this.cursorLocation + 1 >= this.scanner.startPosition && this.cursorLocation < this.scanner.currentPosition && (index = indexOfAssistIdentifier()) > -1) {
/* 3582 */       int ptr = this.identifierPtr - this.identifierLengthStack[this.identifierLengthPtr] + index + 1;
/* 3583 */       if (this.currentElement instanceof RecoveredMethod) {
/* 3584 */         RecoveredMethod recoveredMethod = (RecoveredMethod)this.currentElement;
/*      */         
/* 3586 */         if (!recoveredMethod.foundOpeningBrace) {
/* 3587 */           AbstractMethodDeclaration method = recoveredMethod.methodDeclaration;
/* 3588 */           if (method.thrownExceptions == null) {
/* 3589 */             CompletionOnKeyword1 completionOnKeyword = new CompletionOnKeyword1(
/* 3590 */                 this.identifierStack[ptr], 
/* 3591 */                 this.identifierPositionStack[ptr], 
/* 3592 */                 Keywords.THROWS);
/* 3593 */             method.thrownExceptions = new TypeReference[] { (TypeReference)completionOnKeyword };
/* 3594 */             recoveredMethod.foundOpeningBrace = true;
/* 3595 */             this.assistNode = (ASTNode)completionOnKeyword;
/* 3596 */             this.lastCheckPoint = completionOnKeyword.sourceEnd + 1;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeMethodHeaderExtendedDims() {
/* 3605 */     super.consumeMethodHeaderExtendedDims();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3611 */     pushIdentifier();
/*      */     
/* 3613 */     int index = -1;
/*      */     
/* 3615 */     if (this.currentElement != null && this.currentToken == 19 && this.cursorLocation + 1 >= this.scanner.startPosition && this.cursorLocation < this.scanner.currentPosition && (index = indexOfAssistIdentifier()) > -1) {
/* 3616 */       int ptr = this.identifierPtr - this.identifierLengthStack[this.identifierLengthPtr] + index + 1;
/* 3617 */       RecoveredMethod recoveredMethod = (RecoveredMethod)this.currentElement;
/*      */       
/* 3619 */       if (!recoveredMethod.foundOpeningBrace) {
/* 3620 */         AbstractMethodDeclaration method = recoveredMethod.methodDeclaration;
/* 3621 */         if (method.thrownExceptions == null) {
/* 3622 */           CompletionOnKeyword1 completionOnKeyword = new CompletionOnKeyword1(
/* 3623 */               this.identifierStack[ptr], 
/* 3624 */               this.identifierPositionStack[ptr], 
/* 3625 */               Keywords.THROWS);
/* 3626 */           method.thrownExceptions = new TypeReference[] { (TypeReference)completionOnKeyword };
/* 3627 */           recoveredMethod.foundOpeningBrace = true;
/* 3628 */           this.assistNode = (ASTNode)completionOnKeyword;
/* 3629 */           this.lastCheckPoint = completionOnKeyword.sourceEnd + 1;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeAnnotationAsModifier() {
/* 3637 */     super.consumeAnnotationAsModifier();
/*      */     
/* 3639 */     if (isInsideMethod()) {
/* 3640 */       this.hasUnusedModifiers = true;
/*      */     }
/*      */   }
/*      */   
/*      */   protected void consumeAdditionalBound() {
/* 3645 */     super.consumeAdditionalBound();
/* 3646 */     ASTNode node = this.genericsStack[this.genericsPtr];
/* 3647 */     if (node instanceof CompletionOnSingleTypeReference) {
/* 3648 */       ((CompletionOnSingleTypeReference)node).setKind(2);
/* 3649 */     } else if (node instanceof CompletionOnQualifiedTypeReference) {
/* 3650 */       ((CompletionOnQualifiedTypeReference)node).setKind(2);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeAdditionalBound1() {
/* 3655 */     super.consumeAdditionalBound1();
/* 3656 */     ASTNode node = this.genericsStack[this.genericsPtr];
/* 3657 */     if (node instanceof CompletionOnSingleTypeReference) {
/* 3658 */       ((CompletionOnSingleTypeReference)node).setKind(2);
/* 3659 */     } else if (node instanceof CompletionOnQualifiedTypeReference) {
/* 3660 */       ((CompletionOnQualifiedTypeReference)node).setKind(2);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeAnnotationName() {
/*      */     TypeReference typeReference;
/*      */     int index;
/* 3667 */     if ((index = indexOfAssistIdentifier()) < 0) {
/* 3668 */       super.consumeAnnotationName();
/* 3669 */       pushOnElementStack(1057, 1);
/*      */       
/*      */       return;
/*      */     } 
/* 3673 */     if (isInImportStatement()) {
/*      */       return;
/*      */     }
/* 3676 */     MarkerAnnotation markerAnnotation = null;
/* 3677 */     int length = this.identifierLengthStack[this.identifierLengthPtr];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3683 */     char[][] subset = identifierSubSet(index);
/* 3684 */     this.identifierLengthPtr--;
/* 3685 */     this.identifierPtr -= length;
/* 3686 */     long[] positions = new long[length];
/* 3687 */     System.arraycopy(
/* 3688 */         this.identifierPositionStack, 
/* 3689 */         this.identifierPtr + 1, 
/* 3690 */         positions, 
/* 3691 */         0, 
/* 3692 */         length);
/*      */ 
/*      */ 
/*      */     
/* 3696 */     if (index == 0) {
/*      */       
/* 3698 */       typeReference = createSingleAssistTypeReference(
/* 3699 */           assistIdentifier(), 
/* 3700 */           positions[0]);
/*      */     } else {
/*      */       
/* 3703 */       typeReference = createQualifiedAssistTypeReference(
/* 3704 */           subset, 
/* 3705 */           assistIdentifier(), 
/* 3706 */           positions);
/*      */     } 
/*      */     
/* 3709 */     markerAnnotation = new CompletionOnMarkerAnnotationName(typeReference, typeReference.sourceStart);
/* 3710 */     this.intPtr--;
/* 3711 */     markerAnnotation.declarationSourceEnd = markerAnnotation.sourceEnd;
/* 3712 */     pushOnExpressionStack((Expression)markerAnnotation);
/*      */     
/* 3714 */     this.assistNode = (ASTNode)markerAnnotation;
/* 3715 */     this.isOrphanCompletionNode = true;
/*      */     
/* 3717 */     this.lastCheckPoint = markerAnnotation.sourceEnd + 1;
/*      */     
/* 3719 */     pushOnElementStack(1057, 5);
/*      */   }
/*      */   
/*      */   protected void consumeAnnotationTypeDeclarationHeaderName() {
/* 3723 */     super.consumeAnnotationTypeDeclarationHeaderName();
/* 3724 */     this.hasUnusedModifiers = false;
/* 3725 */     if (this.pendingAnnotation != null) {
/* 3726 */       this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 3727 */       this.pendingAnnotation = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeAnnotationTypeDeclarationHeaderNameWithTypeParameters() {
/* 3732 */     super.consumeAnnotationTypeDeclarationHeaderNameWithTypeParameters();
/* 3733 */     this.hasUnusedModifiers = false;
/* 3734 */     if (this.pendingAnnotation != null) {
/* 3735 */       this.pendingAnnotation.potentialAnnotatedNode = this.astStack[this.astPtr];
/* 3736 */       this.pendingAnnotation = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeLabel() {
/* 3741 */     super.consumeLabel();
/* 3742 */     pushOnLabelStack(this.identifierStack[this.identifierPtr]);
/* 3743 */     pushOnElementStack(1060, this.labelPtr);
/*      */   }
/*      */   
/*      */   protected void consumeLambdaExpression() {
/* 3747 */     super.consumeLambdaExpression();
/* 3748 */     Expression expression = this.expressionStack[this.expressionPtr];
/* 3749 */     if (this.assistNode == null || this.assistNode.sourceStart < expression.sourceStart || this.assistNode.sourceEnd > expression.sourceEnd)
/* 3750 */       popElement(519); 
/*      */   }
/*      */   
/*      */   protected Argument typeElidedArgument() {
/* 3754 */     long namePositions = this.identifierPositionStack[this.identifierPtr];
/* 3755 */     Argument typeElidedArgument = super.typeElidedArgument();
/* 3756 */     if (typeElidedArgument.sourceEnd == this.cursorLocation) {
/* 3757 */       return new CompletionOnArgumentName(typeElidedArgument, namePositions);
/*      */     }
/* 3759 */     return typeElidedArgument;
/*      */   }
/*      */   
/*      */   protected void consumeMarkerAnnotation(boolean isTypeAnnotation) {
/* 3763 */     if (topKnownElementKind(1536) == 1057 && (
/* 3764 */       topKnownElementInfo(1536) & 0x4) != 0) {
/* 3765 */       popElement(1057);
/* 3766 */       this.restartRecovery = true;
/*      */     } else {
/* 3768 */       popElement(1057);
/* 3769 */       super.consumeMarkerAnnotation(isTypeAnnotation);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeMemberValuePair() {
/* 3775 */     if (indexOfAssistIdentifier() < 0) {
/* 3776 */       super.consumeMemberValuePair();
/* 3777 */       MemberValuePair memberValuePair = (MemberValuePair)this.astStack[this.astPtr];
/* 3778 */       if (this.assistNode != null && memberValuePair.value == this.assistNode) {
/* 3779 */         this.assistNodeParent = (ASTNode)memberValuePair;
/*      */       }
/*      */       
/*      */       return;
/*      */     } 
/* 3784 */     char[] simpleName = this.identifierStack[this.identifierPtr];
/* 3785 */     long position = this.identifierPositionStack[this.identifierPtr--];
/* 3786 */     this.identifierLengthPtr--;
/* 3787 */     int end = (int)position;
/* 3788 */     int start = (int)(position >>> 32L);
/*      */     
/* 3790 */     this.expressionPtr--;
/* 3791 */     this.expressionLengthPtr--;
/*      */     
/* 3793 */     CompletionOnMemberValueName memberValueName = new CompletionOnMemberValueName(simpleName, start, end);
/* 3794 */     pushOnAstStack((ASTNode)memberValueName);
/* 3795 */     this.assistNode = (ASTNode)memberValueName;
/* 3796 */     this.lastCheckPoint = this.assistNode.sourceEnd + 1;
/* 3797 */     this.isOrphanCompletionNode = true;
/*      */     
/* 3799 */     this.restartRecovery = true;
/*      */   }
/*      */   
/*      */   protected void consumeMemberValueAsName() {
/* 3803 */     if (indexOfAssistIdentifier() < 0) {
/* 3804 */       super.consumeMemberValueAsName();
/*      */     } else {
/* 3806 */       super.consumeMemberValueAsName();
/* 3807 */       int topKnownElementKind = topKnownElementKind(1536);
/* 3808 */       if (topKnownElementKind == 1057 || topKnownElementKind == 1061) {
/* 3809 */         this.restartRecovery = true;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeMethodBody() {
/* 3815 */     popElement(1025);
/* 3816 */     super.consumeMethodBody();
/*      */   }
/*      */   
/*      */   protected void consumeMethodHeader() {
/* 3820 */     super.consumeMethodHeader();
/* 3821 */     pushOnElementStack(1025);
/*      */   }
/*      */   
/*      */   protected void consumeMethodDeclaration(boolean isNotAbstract, boolean isDefaultMethod) {
/* 3825 */     if (!isNotAbstract) {
/* 3826 */       popElement(1025);
/*      */     }
/* 3828 */     super.consumeMethodDeclaration(isNotAbstract, isDefaultMethod);
/*      */   }
/*      */   
/*      */   protected void consumeModifiers() {
/* 3832 */     super.consumeModifiers();
/*      */     
/* 3834 */     this.lastModifiersStart = this.intStack[this.intPtr];
/* 3835 */     this.lastModifiers = this.intStack[this.intPtr - 1];
/*      */   }
/*      */   
/*      */   protected void consumeModuleHeader() {
/* 3839 */     super.consumeModuleHeader();
/*      */   }
/*      */   
/*      */   protected void consumeProvidesInterface() {
/* 3843 */     super.consumeProvidesInterface();
/* 3844 */     pushOnElementStack(1073);
/*      */   }
/*      */   
/*      */   protected void consumeProvidesStatement() {
/* 3848 */     super.consumeProvidesStatement();
/* 3849 */     popElement(1071);
/*      */   }
/*      */   
/*      */   protected void consumeWithClause() {
/* 3853 */     super.consumeWithClause();
/* 3854 */     popElement(1074);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeReferenceType() {
/* 3859 */     if (this.identifierLengthStack[this.identifierLengthPtr] > 1) {
/*      */       
/* 3861 */       this.invocationType = -1;
/* 3862 */       this.qualifier = -1;
/*      */     } 
/* 3864 */     super.consumeReferenceType();
/*      */   }
/*      */   
/*      */   protected void consumeRequiresStatement() {
/* 3868 */     super.consumeRequiresStatement();
/* 3869 */     popElement(1069);
/*      */   }
/*      */   
/*      */   protected void consumeRestoreDiet() {
/* 3873 */     super.consumeRestoreDiet();
/* 3874 */     if (isInsideMethod()) {
/* 3875 */       popElement(1036);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void consumeExportsStatement() {
/* 3880 */     super.consumeExportsStatement();
/* 3881 */     popElement(1072);
/* 3882 */     popElement(1068);
/*      */   }
/*      */   
/*      */   protected void consumeSinglePkgName() {
/* 3886 */     super.consumeSinglePkgName();
/* 3887 */     pushOnElementStack(1072);
/*      */   }
/*      */   
/*      */   protected void consumeSingleMemberAnnotation(boolean isTypeAnnotation) {
/* 3891 */     if (topKnownElementKind(1536) == 1057 && (
/* 3892 */       topKnownElementInfo(1536) & 0x4) != 0) {
/* 3893 */       popElement(1057);
/* 3894 */       this.restartRecovery = true;
/*      */     } else {
/* 3896 */       popElement(1057);
/* 3897 */       super.consumeSingleMemberAnnotation(isTypeAnnotation);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeSingleStaticImportDeclarationName() {
/* 3902 */     super.consumeSingleStaticImportDeclarationName();
/* 3903 */     this.pendingAnnotation = null;
/*      */   }
/*      */   
/*      */   protected void consumeSingleTypeImportDeclarationName() {
/* 3907 */     super.consumeSingleTypeImportDeclarationName();
/* 3908 */     this.pendingAnnotation = null;
/*      */   }
/*      */   
/*      */   protected void consumeStatementBreakWithLabel() {
/* 3912 */     super.consumeStatementBreakWithLabel();
/* 3913 */     if (this.record) {
/* 3914 */       ASTNode breakStatement = this.astStack[this.astPtr];
/* 3915 */       if (!isAlreadyPotentialName(breakStatement.sourceStart)) {
/* 3916 */         addPotentialName((char[])null, breakStatement.sourceStart, breakStatement.sourceEnd);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeStatementLabel() {
/* 3923 */     popElement(1060);
/* 3924 */     super.consumeStatementLabel();
/*      */   }
/*      */   
/*      */   protected void consumeStatementSwitch() {
/* 3928 */     super.consumeStatementSwitch();
/* 3929 */     if (topKnownElementKind(1536) == 1049) {
/* 3930 */       popElement(1049);
/* 3931 */       popElement(1025);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeStatementWhile() {
/* 3936 */     super.consumeStatementWhile();
/* 3937 */     if (topKnownElementKind(1536) == 1062) {
/* 3938 */       popElement(1062);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void consumeStaticImportOnDemandDeclarationName() {
/* 3943 */     super.consumeStaticImportOnDemandDeclarationName();
/* 3944 */     this.pendingAnnotation = null;
/*      */   }
/*      */   
/*      */   protected void consumeStaticInitializer() {
/* 3948 */     super.consumeStaticInitializer();
/* 3949 */     this.pendingAnnotation = null;
/*      */   }
/*      */   
/*      */   protected void consumeNestedMethod() {
/* 3953 */     super.consumeNestedMethod();
/* 3954 */     if (topKnownElementKind(1536) != 1025) pushOnElementStack(1025); 
/*      */   }
/*      */   
/*      */   protected void consumeNormalAnnotation(boolean isTypeAnnotation) {
/* 3958 */     if (topKnownElementKind(1536) == 1057 && (
/* 3959 */       topKnownElementInfo(1536) & 0x4) != 0) {
/* 3960 */       popElement(1057);
/* 3961 */       this.restartRecovery = true;
/*      */     } else {
/* 3963 */       popElement(1057);
/* 3964 */       if (this.expressionPtr >= 0 && this.expressionStack[this.expressionPtr] instanceof CompletionOnMarkerAnnotationName) {
/* 3965 */         Annotation annotation = (Annotation)this.expressionStack[this.expressionPtr];
/* 3966 */         if (this.currentElement != null) {
/* 3967 */           annotationRecoveryCheckPoint(annotation.sourceStart, annotation.declarationSourceEnd);
/* 3968 */           if (this.currentElement instanceof RecoveredAnnotation) {
/* 3969 */             this.currentElement = ((RecoveredAnnotation)this.currentElement).addAnnotation(annotation, this.identifierPtr);
/*      */           }
/*      */         } 
/*      */         
/* 3973 */         if (!this.statementRecoveryActivated && 
/* 3974 */           this.options.sourceLevel < 3211264L && 
/* 3975 */           this.lastErrorEndPositionBeforeRecovery < this.scanner.currentPosition) {
/* 3976 */           problemReporter().invalidUsageOfAnnotation(annotation);
/*      */         }
/* 3978 */         this.recordStringLiterals = true;
/*      */         return;
/*      */       } 
/* 3981 */       super.consumeNormalAnnotation(isTypeAnnotation);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumePackageDeclarationName() {
/* 3986 */     super.consumePackageDeclarationName();
/* 3987 */     if (this.pendingAnnotation != null) {
/* 3988 */       this.pendingAnnotation.potentialAnnotatedNode = (ASTNode)this.compilationUnit.currentPackage;
/* 3989 */       this.pendingAnnotation = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumePackageDeclarationNameWithModifiers() {
/* 3994 */     super.consumePackageDeclarationNameWithModifiers();
/* 3995 */     if (this.pendingAnnotation != null) {
/* 3996 */       this.pendingAnnotation.potentialAnnotatedNode = (ASTNode)this.compilationUnit.currentPackage;
/* 3997 */       this.pendingAnnotation = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumePrimaryNoNewArrayName() {
/* 4003 */     this.invocationType = -1;
/* 4004 */     this.qualifier = -1;
/*      */     
/* 4006 */     super.consumePrimaryNoNewArrayName();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeQualifiedSuperReceiver() {
/* 4011 */     this.invocationType = -1;
/* 4012 */     this.qualifier = -1;
/*      */     
/* 4014 */     super.consumeQualifiedSuperReceiver();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumePrimaryNoNewArrayNameThis() {
/* 4019 */     this.invocationType = -1;
/* 4020 */     this.qualifier = -1;
/*      */     
/* 4022 */     super.consumePrimaryNoNewArrayNameThis();
/*      */   }
/*      */   
/*      */   protected void consumePushPosition() {
/* 4026 */     super.consumePushPosition();
/* 4027 */     if (topKnownElementKind(1536) == 1040) {
/* 4028 */       int info = topKnownElementInfo(1536);
/* 4029 */       popElement(1040);
/* 4030 */       pushOnElementStack(1039, info);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeSwitchLabeledBlock() {
/* 4035 */     popUntilElement(1049);
/* 4036 */     popElement(1049);
/* 4037 */     concatNodeLists();
/*      */   }
/*      */   
/*      */   protected int fetchNextToken() throws InvalidInputException {
/* 4041 */     int token = this.scanner.getNextToken();
/* 4042 */     if (token != 64 && this.scanner.currentPosition > this.cursorLocation) {
/* 4043 */       if ((!this.diet || this.dietInt != 0) && 
/* 4044 */         this.currentToken == 19 && (
/* 4045 */         this.identifierStack[this.identifierPtr]).length == 0) {
/* 4046 */         if (Scanner.isLiteral(token))
/*      */         {
/* 4048 */           return fetchNextToken();
/*      */         }
/* 4050 */         if (token == 19) {
/*      */ 
/*      */           
/* 4053 */           this.scanner.currentPosition = this.scanner.startPosition;
/* 4054 */           if (this.unstackedAct < 18574) {
/* 4055 */             if ("LocalVariableDeclaration".equals(reduce(24)))
/* 4056 */               return 24; 
/* 4057 */             if ("ArgumentList".equals(reduce(32))) {
/* 4058 */               return 32;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/* 4063 */       if (!this.diet && 
/* 4064 */         this.expressionPtr <= -1 && !requireExtendedRecovery()) {
/* 4065 */         this.scanner.eofPosition = this.cursorLocation + 1;
/*      */ 
/*      */         
/* 4068 */         if (topKnownElementKind(1536) == 1025 && 
/* 4069 */           this.scanner.startPosition > this.cursorLocation + 1 && 
/* 4070 */           this.currentElement == null)
/*      */         {
/* 4072 */           return 64;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 4077 */     return token;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String reduce(int token) {
/* 4084 */     int myStackTop = this.stateStackTop;
/* 4085 */     int[] myStack = Arrays.copyOf(this.stack, this.stack.length);
/* 4086 */     int act = this.unstackedAct;
/* 4087 */     String reduceName = "";
/*      */     label25: while (true) {
/* 4089 */       int stackLength = myStack.length;
/* 4090 */       if (++myStackTop >= stackLength) {
/* 4091 */         System.arraycopy(
/* 4092 */             myStack, 0, 
/* 4093 */             myStack = new int[stackLength + 255], 0, 
/* 4094 */             stackLength);
/*      */       }
/* 4096 */       myStack[myStackTop] = act;
/* 4097 */       act = tAction(act, token);
/* 4098 */       if (act == 18574)
/* 4099 */         return null; 
/* 4100 */       if (act <= 942)
/* 4101 */       { myStackTop--; }
/* 4102 */       else { if (act > 18574) {
/* 4103 */           return reduceName;
/*      */         }
/* 4105 */         if (act < 18573) {
/* 4106 */           return reduceName;
/*      */         }
/* 4108 */         return reduceName; }
/*      */       
/*      */       while (true) {
/* 4111 */         reduceName = name[non_terminal_index[lhs[act]]];
/* 4112 */         myStackTop -= rhs[act] - 1;
/* 4113 */         act = ntAction(myStack[myStackTop], lhs[act]);
/* 4114 */         if (act == 18573) {
/* 4115 */           return reduceName;
/*      */         }
/* 4117 */         if (act > 942)
/*      */           continue label25; 
/*      */       } 
/*      */       break;
/*      */     }  } protected void consumeToken(int token) {
/* 4122 */     if (this.isFirst) {
/* 4123 */       super.consumeToken(token);
/*      */       return;
/*      */     } 
/* 4126 */     if (this.canBeExplicitConstructor == 1) {
/* 4127 */       this.canBeExplicitConstructor = 2;
/*      */     } else {
/* 4129 */       this.canBeExplicitConstructor = 0;
/*      */     } 
/*      */     
/* 4132 */     int previous = this.previousToken;
/* 4133 */     int prevIdentifierPtr = this.previousIdentifierPtr;
/*      */     
/* 4135 */     isInsideEnhancedForLoopWithoutBlock(token);
/*      */     
/* 4137 */     if (isInsideMethod() || isInsideFieldInitialization() || isInsideAnnotation() || isInsideEnumConstantnitialization()) {
/* 4138 */       int kind; switch (token) {
/*      */         case 23:
/* 4140 */           if (previous == 19 && 
/* 4141 */             topKnownElementKind(1536) == 1054) {
/* 4142 */             popElement(1054); break;
/*      */           } 
/* 4144 */           popElement(1032);
/*      */           break;
/*      */         
/*      */         case 40:
/* 4148 */           popElement(1032);
/* 4149 */           if (topKnownElementKind(1536) == 1049 && 
/* 4150 */             previous == 104) {
/* 4151 */             pushOnElementStack(521);
/*      */           }
/*      */           break;
/*      */         case 6:
/* 4155 */           if (topKnownElementKind(1536) == 1032) {
/* 4156 */             popElement(1032);
/* 4157 */             pushOnElementStack(1038);
/*      */           } 
/*      */           break;
/*      */         case 33:
/* 4161 */           kind = topKnownElementKind(1536);
/* 4162 */           switch (kind) {
/*      */             case 1025:
/* 4164 */               popElement(1025);
/*      */               break;
/*      */             case 1061:
/* 4167 */               popElement(1061);
/*      */               break;
/*      */             case 519:
/*      */               break;
/*      */           } 
/* 4172 */           popElement(1037);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 69:
/* 4177 */           if (topKnownElementKind(1536) == 1052) {
/* 4178 */             popElement(1052);
/*      */           }
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */     
/*      */     } 
/* 4186 */     if (previous == 19 && token == 27 && this.currentElement == null && 
/* 4187 */       this.identifierStack[this.previousIdentifierPtr] == assistIdentifier() && 
/* 4188 */       !isIndirectlyInsideFieldInitialization() && isInsideType()) {
/* 4189 */       pushOnElementStack(516);
/* 4190 */       this.scanner.eofPosition = (this.cursorLocation < Integer.MAX_VALUE) ? (this.cursorLocation + 1) : this.cursorLocation;
/*      */     } 
/*      */     
/* 4193 */     super.consumeToken(token);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4198 */     if (token == 19 && 
/* 4199 */       this.identifierStack[this.identifierPtr] == assistIdentifier() && 
/* 4200 */       this.currentElement == null && 
/* 4201 */       !isIndirectlyInsideLambdaExpression() && 
/* 4202 */       isIndirectlyInsideFieldInitialization()) {
/* 4203 */       this.scanner.eofPosition = (this.cursorLocation < Integer.MAX_VALUE) ? (this.cursorLocation + 1) : this.cursorLocation;
/*      */     }
/* 4205 */     if (token == 111) {
/* 4206 */       pushOnElementStack(1067);
/* 4207 */     } else if (token == 123) {
/* 4208 */       pushOnElementStack(1068);
/* 4209 */     } else if (token == 124) {
/* 4210 */       pushOnElementStack(1075);
/* 4211 */     } else if (token == 134) {
/* 4212 */       popElement(1072);
/* 4213 */     } else if (token == 122) {
/* 4214 */       pushOnElementStack(1069);
/* 4215 */     } else if (token == 126) {
/* 4216 */       pushOnElementStack(1071);
/* 4217 */     } else if (token == 125) {
/* 4218 */       pushOnElementStack(1070);
/* 4219 */     } else if (token == 135) {
/* 4220 */       popElement(1073);
/* 4221 */       pushOnElementStack(1074);
/*      */     } 
/*      */ 
/*      */     
/* 4225 */     if (isInsideMethod() || isInsideFieldInitialization() || isInsideAttributeValue() || isInsideEnumConstantnitialization()) {
/* 4226 */       int kind; switch (token) {
/*      */         case 1:
/* 4228 */           switch (previous) {
/*      */             case 36:
/* 4230 */               this.invocationType = 0;
/*      */               break;
/*      */             case 35:
/* 4233 */               this.invocationType = -2;
/*      */               break;
/*      */             case 19:
/* 4236 */               if (topKnownElementKind(1536) != 1032) {
/* 4237 */                 if (this.identifierPtr != prevIdentifierPtr) {
/* 4238 */                   this.invocationType = 0; break;
/*      */                 } 
/* 4240 */                 this.invocationType = -3;
/*      */               } 
/*      */               break;
/*      */           } 
/*      */           
/*      */           break;
/*      */         case 7:
/* 4247 */           this.inReferenceExpression = true;
/*      */           break;
/*      */         case 19:
/* 4250 */           if (this.inReferenceExpression)
/*      */             break; 
/* 4252 */           if (JavaFeature.SWITCH_EXPRESSIONS.isSupported(this.scanner.complianceLevel, this.previewEnabled) && 
/* 4253 */             isInsideSwitch() && checkYieldKeyword()) {
/* 4254 */             pushOnElementStack(1076);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 4260 */             token = this.currentToken = getNextToken();
/* 4261 */             if (token == 55 && this.previousToken == 19) {
/* 4262 */               token = this.currentToken = getNextToken();
/*      */             }
/* 4264 */             super.consumeToken(this.currentToken);
/*      */           } 
/* 4266 */           if (previous == 1 && 
/* 4267 */             this.invocationType != -2 && 
/* 4268 */             this.invocationType != -3 && 
/* 4269 */             this.invocationType != -4 && 
/* 4270 */             this.invocationType != -5) {
/*      */             
/* 4272 */             this.invocationType = 0;
/* 4273 */             this.qualifier = this.expressionPtr;
/*      */           } 
/*      */           
/* 4276 */           if (previous == 15 && 
/* 4277 */             this.invocationType != -2 && 
/* 4278 */             this.invocationType != -3 && 
/* 4279 */             this.invocationType != -4 && 
/* 4280 */             this.invocationType != -5)
/*      */           {
/* 4282 */             if (topKnownElementKind(1536) == 1054) {
/* 4283 */               this.invocationType = 0;
/* 4284 */               this.qualifier = this.expressionPtr;
/*      */             } 
/*      */           }
/*      */           break;
/*      */         
/*      */         case 38:
/* 4290 */           if (this.inReferenceExpression)
/*      */             break; 
/* 4292 */           pushOnElementStack(1032);
/* 4293 */           this.qualifier = this.expressionPtr;
/* 4294 */           if (previous == 1) {
/* 4295 */             this.invocationType = -5; break;
/*      */           } 
/* 4297 */           this.invocationType = -4;
/*      */           break;
/*      */         
/*      */         case 36:
/* 4301 */           if (previous == 1) {
/* 4302 */             this.invocationType = -5;
/* 4303 */             this.qualifier = this.expressionPtr;
/*      */           } 
/*      */           break;
/*      */         case 35:
/* 4307 */           if (previous == 1) {
/* 4308 */             this.invocationType = -5;
/* 4309 */             this.qualifier = this.expressionPtr;
/*      */           } 
/*      */           break;
/*      */         case 107:
/* 4313 */           pushOnElementStack(1028);
/*      */           break;
/*      */         case 23:
/* 4316 */           if (this.invocationType == -1 || this.invocationType == -3 || this.invocationType == -2) {
/* 4317 */             this.qualifier = this.expressionPtr;
/*      */           }
/* 4319 */           switch (previous) {
/*      */             case 19:
/* 4321 */               if (topKnownElementKind(1536) == 513) {
/* 4322 */                 int info = 0;
/* 4323 */                 if (topKnownElementKind(1536, 1) == 1057 && (
/* 4324 */                   info = topKnownElementInfo(1536, 1) & 0x1) != 0) {
/* 4325 */                   popElement(513);
/* 4326 */                   popElement(1057);
/* 4327 */                   if ((info & 0x4) != 0) {
/* 4328 */                     pushOnElementStack(1057, 6);
/*      */                   } else {
/* 4330 */                     pushOnElementStack(1057, 2);
/*      */                   } 
/*      */                 } else {
/* 4333 */                   pushOnElementStack(1026, this.invocationType);
/* 4334 */                   pushOnElementStack(1027, this.qualifier);
/*      */                 } 
/*      */               } 
/* 4337 */               this.qualifier = -1;
/* 4338 */               this.invocationType = -1;
/*      */               break;
/*      */             case 36:
/* 4341 */               if (topKnownElementKind(1536) == 513) {
/* 4342 */                 pushOnElementStack(1026, (this.invocationType == -5) ? -5 : -4);
/* 4343 */                 pushOnElementStack(1027, this.qualifier);
/*      */               } 
/* 4345 */               this.qualifier = -1;
/* 4346 */               this.invocationType = -1;
/*      */               break;
/*      */             case 35:
/* 4349 */               if (topKnownElementKind(1536) == 513) {
/* 4350 */                 pushOnElementStack(1026, (this.invocationType == -5) ? -5 : -4);
/* 4351 */                 pushOnElementStack(1027, this.qualifier);
/*      */               } 
/* 4353 */               this.qualifier = -1;
/* 4354 */               this.invocationType = -1;
/*      */               break;
/*      */             case 14:
/*      */             case 15:
/*      */             case 16:
/* 4359 */               if (topKnownElementKind(1536) == 513) {
/*      */                 int info;
/* 4361 */                 if (topKnownElementKind(1536, 1) == 1040 && ((
/* 4362 */                   info = topKnownElementInfo(1536, 1)) == 6 || info == 17 || info == 19)) {
/*      */                   
/* 4364 */                   popElement(513);
/*      */                 } else {
/* 4366 */                   pushOnElementStack(1026, (this.invocationType == -5) ? -5 : -4);
/* 4367 */                   pushOnElementStack(1027, this.qualifier);
/*      */                 } 
/*      */               } 
/* 4370 */               this.qualifier = -1;
/* 4371 */               this.invocationType = -1;
/*      */               break;
/*      */           } 
/*      */           break;
/*      */         case 40:
/* 4376 */           kind = topKnownElementKind(1536);
/* 4377 */           if (kind == 516 || 
/* 4378 */             kind == 1036 || 
/* 4379 */             kind == 1038) {
/* 4380 */             pushOnElementStack(1037, this.endPosition); break;
/* 4381 */           }  if (kind == 1057 || kind == 517) {
/* 4382 */             pushOnElementStack(1061, this.endPosition); break;
/*      */           } 
/* 4384 */           if (kind == 1062) {
/* 4385 */             int info = topKnownElementInfo(1536);
/* 4386 */             popElement(1062);
/* 4387 */             switch (info) {
/*      */ 
/*      */               
/*      */               case 1:
/*      */               case 4:
/*      */               case 6:
/* 4393 */                 if (this.expressionPtr > -1) {
/* 4394 */                   pushOnElementStack(1025, info, this.expressionStack[this.expressionPtr]);
/*      */                 }
/*      */                 break;
/*      */             } 
/*      */             
/* 4399 */             pushOnElementStack(1025, info);
/*      */             break;
/*      */           } 
/* 4402 */           switch (previous) {
/*      */             case 26:
/* 4404 */               switch (this.previousKind) {
/*      */                 case 1028:
/* 4406 */                   pushOnElementStack(1025, 3);
/*      */                   break;
/*      */                 case 1046:
/* 4409 */                   pushOnElementStack(1025, 5);
/*      */                   break;
/*      */                 case 1047:
/* 4412 */                   pushOnElementStack(1025, 8);
/*      */                   break;
/*      */               } 
/* 4415 */               pushOnElementStack(1025);
/*      */               break;
/*      */ 
/*      */             
/*      */             case 88:
/* 4420 */               pushOnElementStack(1025, 2);
/*      */               break;
/*      */             case 84:
/* 4423 */               pushOnElementStack(1025, 7);
/*      */               break;
/*      */             case 104:
/*      */               break;
/*      */           } 
/* 4428 */           pushOnElementStack(1025);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 6:
/* 4435 */           if (topKnownElementKind(1536) != 1038) {
/* 4436 */             pushOnElementStack(1052); break;
/*      */           } 
/* 4438 */           switch (previous) {
/*      */             case 14:
/*      */             case 15:
/*      */             case 16:
/*      */             case 19:
/*      */             case 105:
/*      */             case 106:
/*      */             case 108:
/*      */             case 109:
/*      */             case 110:
/*      */             case 112:
/*      */             case 113:
/*      */             case 114:
/* 4451 */               this.invocationType = -1;
/* 4452 */               this.qualifier = -1;
/*      */               break;
/*      */           } 
/*      */           
/*      */           break;
/*      */         case 26:
/* 4458 */           switch (topKnownElementKind(1536)) {
/*      */             case 1028:
/* 4460 */               popElement(1028);
/*      */               break;
/*      */             case 1065:
/* 4463 */               popElement(1065);
/*      */             
/*      */             case 1043:
/* 4466 */               if (topKnownElementInfo(1536) == this.bracketDepth) {
/* 4467 */                 popElement(1043);
/* 4468 */                 pushOnElementStack(1062, 1, this.expressionStack[this.expressionPtr]);
/*      */               } 
/*      */               break;
/*      */             case 1044:
/* 4472 */               if (topKnownElementInfo(1536) == this.bracketDepth) {
/* 4473 */                 popElement(1044);
/* 4474 */                 pushOnElementStack(1062, 4);
/*      */               } 
/*      */               break;
/*      */             case 1045:
/* 4478 */               if (topKnownElementInfo(1536) == this.bracketDepth) {
/* 4479 */                 popElement(1045);
/* 4480 */                 pushOnElementStack(1062, 6);
/*      */               } 
/*      */               break;
/*      */             case 1046:
/* 4484 */               if (topKnownElementInfo(1536) == this.bracketDepth) {
/* 4485 */                 popElement(1046);
/*      */               }
/*      */               break;
/*      */             case 1047:
/* 4489 */               if (topKnownElementInfo(1536) == this.bracketDepth) {
/* 4490 */                 popElement(1047);
/*      */               }
/*      */               break;
/*      */           } 
/*      */           break;
/*      */         case 78:
/* 4496 */           pushOnElementStack(1033, this.bracketDepth);
/*      */           break;
/*      */         case 24:
/* 4499 */           switch (topKnownElementKind(1536)) {
/*      */             case 1033:
/* 4501 */               if (topKnownElementInfo(1536) == this.bracketDepth) {
/* 4502 */                 popElement(1033);
/*      */               }
/*      */               break;
/*      */             case 1034:
/* 4506 */               if (topKnownElementInfo(1536) == this.bracketDepth) {
/* 4507 */                 popElement(1034);
/*      */               }
/*      */               break;
/*      */             case 1048:
/* 4511 */               if (topKnownElementInfo(1536) == this.bracketDepth) {
/* 4512 */                 popElement(1048);
/*      */               }
/*      */               break;
/*      */             case 1063:
/* 4516 */               if (topKnownElementInfo(1536) == this.bracketDepth) {
/* 4517 */                 popElement(1063);
/* 4518 */                 popElement(1048);
/*      */               } 
/*      */               break;
/*      */             case 1058:
/* 4522 */               if (topKnownElementInfo(1536) == this.bracketDepth) {
/* 4523 */                 popElement(1058);
/*      */               }
/*      */               break;
/*      */             case 1059:
/* 4527 */               if (topKnownElementInfo(1536) == this.bracketDepth) {
/* 4528 */                 popElement(1059);
/*      */               }
/*      */               break;
/*      */             case 1045:
/* 4532 */               if (topKnownElementInfo(1536) == this.bracketDepth - 1) {
/* 4533 */                 popElement(1045);
/* 4534 */                 pushOnElementStack(1064, this.bracketDepth - 1);
/*      */               } 
/*      */               break;
/*      */             case 1064:
/* 4538 */               if (topKnownElementInfo(1536) == this.bracketDepth - 1) {
/* 4539 */                 popElement(1064);
/* 4540 */                 pushOnElementStack(1045, this.bracketDepth - 1);
/*      */               } 
/*      */               break;
/*      */           } 
/*      */           break;
/*      */         case 87:
/* 4546 */           pushOnElementStack(1034, this.bracketDepth);
/*      */           break;
/*      */         case 8:
/* 4549 */           pushOnElementStack(1040, 15);
/*      */           break;
/*      */         case 10:
/* 4552 */           pushOnElementStack(1040, 9);
/*      */           break;
/*      */         case 9:
/* 4555 */           pushOnElementStack(1040, 16);
/*      */           break;
/*      */         case 4:
/* 4558 */           pushOnElementStack(1040, 14);
/*      */           break;
/*      */         case 5:
/* 4561 */           pushOnElementStack(1040, 13);
/*      */           break;
/*      */         case 18:
/* 4564 */           pushOnElementStack(1040, 10);
/*      */           break;
/*      */         case 14:
/* 4567 */           pushOnElementStack(1040, 17);
/*      */           break;
/*      */         case 16:
/* 4570 */           pushOnElementStack(1040, 19);
/*      */           break;
/*      */         case 11:
/* 4573 */           switch (previous) {
/*      */             case 1:
/* 4575 */               pushOnElementStack(1054);
/*      */               break;
/*      */             case 38:
/* 4578 */               pushOnElementStack(1055);
/*      */               break;
/*      */           } 
/* 4581 */           pushOnElementStack(1040, 4);
/*      */           break;
/*      */         case 15:
/* 4584 */           pushOnElementStack(1040, 6);
/*      */           break;
/*      */         case 12:
/* 4587 */           pushOnElementStack(1040, 5);
/*      */           break;
/*      */         case 13:
/* 4590 */           pushOnElementStack(1040, 7);
/*      */           break;
/*      */         case 22:
/* 4593 */           pushOnElementStack(1040, 2);
/*      */           break;
/*      */         case 25:
/* 4596 */           pushOnElementStack(1040, 8);
/*      */           break;
/*      */         
/*      */         case 28:
/* 4600 */           if (topKnownElementKind(1024) != 1028)
/* 4601 */             pushOnElementStack(1040, 3); 
/*      */           break;
/*      */         case 30:
/* 4604 */           pushOnElementStack(1040, 0);
/*      */           break;
/*      */         case 31:
/* 4607 */           pushOnElementStack(1040, 1);
/*      */           break;
/*      */         case 2:
/* 4610 */           pushOnElementStack(1039, 32);
/*      */           break;
/*      */         case 3:
/* 4613 */           pushOnElementStack(1039, 33);
/*      */           break;
/*      */         case 67:
/* 4616 */           pushOnElementStack(1039, 12);
/*      */           break;
/*      */         case 66:
/* 4619 */           pushOnElementStack(1039, 11);
/*      */           break;
/*      */         case 20:
/* 4622 */           pushOnElementStack(1040, 18);
/*      */           break;
/*      */         case 21:
/* 4625 */           pushOnElementStack(1040, 29);
/*      */           break;
/*      */         case 17:
/* 4628 */           pushOnElementStack(1040, 31);
/*      */           break;
/*      */         case 29:
/* 4631 */           if (previous != 11 && previous != 32) {
/* 4632 */             pushOnElementStack(1042, 1);
/*      */           }
/*      */           break;
/*      */         case 104:
/* 4636 */           switch (topKnownElementKind(1536)) {
/*      */             case 1050:
/* 4638 */               popElement(1050);
/*      */               break;
/*      */             case 1051:
/* 4641 */               popElement(1051);
/*      */               break;
/*      */           } 
/*      */           break;
/*      */         case 65:
/* 4646 */           switch (topKnownElementKind(1536)) {
/*      */             case 1042:
/* 4648 */               if (topKnownElementInfo(1536) == 1) {
/* 4649 */                 popElement(1042);
/* 4650 */                 pushOnElementStack(1042, 2);
/*      */               } 
/*      */               break;
/*      */             case 1050:
/* 4654 */               popElement(1050);
/*      */               break;
/*      */             case 1051:
/* 4657 */               popElement(1051);
/*      */               break;
/*      */             case 1048:
/* 4660 */               pushOnElementStack(1063, this.bracketDepth);
/*      */               break;
/*      */           } 
/*      */           break;
/*      */         case 86:
/* 4665 */           pushOnElementStack(1043, this.bracketDepth);
/*      */           break;
/*      */         case 121:
/* 4668 */           if (topKnownElementKind(1536) == 1062) {
/* 4669 */             popElement(1062);
/*      */           }
/* 4671 */           pushOnElementStack(1062);
/*      */           break;
/*      */         case 79:
/* 4674 */           pushOnElementStack(1044, this.bracketDepth);
/*      */           break;
/*      */         case 85:
/* 4677 */           pushOnElementStack(1045, this.bracketDepth);
/*      */           break;
/*      */         case 63:
/* 4680 */           popElement(1036);
/* 4681 */           pushOnElementStack(1046, this.bracketDepth);
/*      */           break;
/*      */         case 39:
/* 4684 */           pushOnElementStack(1047, this.bracketDepth);
/*      */           break;
/*      */         case 81:
/* 4687 */           pushOnElementStack(1048, this.bracketDepth);
/*      */           break;
/*      */         case 91:
/* 4690 */           pushOnElementStack(1050);
/*      */           break;
/*      */         case 32:
/* 4693 */           switch (topKnownElementKind(1536)) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             case 1050:
/* 4699 */               this.expressionPtr--;
/* 4700 */               this.expressionLengthStack[this.expressionLengthPtr] = this.expressionLengthStack[this.expressionLengthPtr] - 1; break;
/*      */           } 
/*      */           break;
/*      */         case 76:
/* 4704 */           pushOnElementStack(1051);
/*      */           break;
/*      */         case 92:
/* 4707 */           pushOnElementStack(1053);
/*      */           break;
/*      */         case 82:
/* 4710 */           pushOnElementStack(1058, this.bracketDepth);
/*      */           break;
/*      */         case 83:
/* 4713 */           pushOnElementStack(1059, this.bracketDepth);
/*      */           break;
/*      */       } 
/* 4716 */     } else if (isInsideAnnotation()) {
/* 4717 */       int kind; switch (token) {
/*      */         case 40:
/* 4719 */           this.bracketDepth++;
/* 4720 */           kind = topKnownElementKind(1536);
/* 4721 */           if (kind == 1057) {
/* 4722 */             pushOnElementStack(1061, this.endPosition);
/*      */           }
/*      */           break;
/*      */       } 
/*      */     } else {
/* 4727 */       switch (token) {
/*      */         case 92:
/* 4729 */           pushOnElementStack(1053);
/*      */           break;
/*      */         case 11:
/* 4732 */           pushOnElementStack(1040, 4);
/*      */           break;
/*      */         case 15:
/* 4735 */           pushOnElementStack(1040, 6);
/*      */           break;
/*      */         case 14:
/* 4738 */           pushOnElementStack(1040, 17);
/*      */           break;
/*      */         case 16:
/* 4741 */           pushOnElementStack(1040, 19);
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void isInsideEnhancedForLoopWithoutBlock(int token) {
/* 4748 */     if (this.consumedEnhancedFor && token != 40) {
/* 4749 */       consumeOpenFakeBlock();
/*      */     }
/* 4751 */     this.consumedEnhancedFor = false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeInvocationExpression() {
/* 4756 */     super.consumeInvocationExpression();
/* 4757 */     triggerRecoveryUponLambdaClosure((Statement)this.expressionStack[this.expressionPtr], false);
/*      */   }
/*      */   
/*      */   protected void consumeReferenceExpression(ReferenceExpression referenceExpression) {
/* 4761 */     this.inReferenceExpression = false;
/* 4762 */     super.consumeReferenceExpression(referenceExpression);
/*      */   }
/*      */   
/*      */   protected void consumeOnlySynchronized() {
/* 4766 */     super.consumeOnlySynchronized();
/* 4767 */     this.hasUnusedModifiers = false;
/*      */   }
/*      */   
/*      */   protected void consumeOnlyTypeArguments() {
/* 4771 */     super.consumeOnlyTypeArguments();
/* 4772 */     popElement(1040);
/* 4773 */     if (topKnownElementKind(1536) == 1054) {
/* 4774 */       popElement(1054);
/* 4775 */       pushOnElementStack(1054, 1);
/*      */     } else {
/* 4777 */       popElement(1055);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeOnlyTypeArgumentsForCastExpression() {
/* 4782 */     super.consumeOnlyTypeArgumentsForCastExpression();
/* 4783 */     pushOnElementStack(1056);
/*      */   }
/*      */   
/*      */   protected void consumeOpenFakeBlock() {
/* 4787 */     super.consumeOpenFakeBlock();
/* 4788 */     pushOnElementStack(1025);
/*      */   }
/*      */   
/*      */   protected void consumeOpensStatement() {
/* 4792 */     super.consumeOpensStatement();
/* 4793 */     popElement(1072);
/* 4794 */     popElement(1075);
/*      */   }
/*      */   
/*      */   protected void consumeRightParen() {
/* 4798 */     super.consumeRightParen();
/*      */   }
/*      */   
/*      */   protected void consumeReferenceType1() {
/* 4802 */     super.consumeReferenceType1();
/* 4803 */     popElement(1040);
/*      */   }
/*      */   
/*      */   protected void consumeReferenceType2() {
/* 4807 */     super.consumeReferenceType2();
/* 4808 */     popElement(1040);
/*      */   }
/*      */   
/*      */   protected void consumeReferenceType3() {
/* 4812 */     super.consumeReferenceType3();
/* 4813 */     popElement(1040);
/*      */   }
/*      */   
/*      */   protected void consumeTypeArgumentReferenceType1() {
/* 4817 */     super.consumeTypeArgumentReferenceType1();
/* 4818 */     popElement(1040);
/*      */   }
/*      */   
/*      */   protected void consumeTypeArgumentReferenceType2() {
/* 4822 */     super.consumeTypeArgumentReferenceType2();
/* 4823 */     popElement(1040);
/*      */   }
/*      */   
/*      */   protected void consumeTypeArguments() {
/* 4827 */     super.consumeTypeArguments();
/* 4828 */     popElement(1040);
/*      */   }
/*      */   
/*      */   protected void consumeTypeHeaderNameWithTypeParameters() {
/* 4832 */     super.consumeTypeHeaderNameWithTypeParameters();
/*      */     
/* 4834 */     TypeDeclaration typeDecl = (TypeDeclaration)this.astStack[this.astPtr];
/* 4835 */     classHeaderExtendsOrImplements(((typeDecl.modifiers & 0x200) != 0), false);
/*      */   }
/*      */   
/*      */   protected void consumeTypeImportOnDemandDeclarationName() {
/* 4839 */     super.consumeTypeImportOnDemandDeclarationName();
/* 4840 */     this.pendingAnnotation = null;
/*      */   }
/*      */   
/*      */   protected void consumeImportDeclaration() {
/* 4844 */     super.consumeImportDeclaration();
/* 4845 */     popElement(1067);
/*      */   }
/*      */   
/*      */   protected void consumeTypeParameters() {
/* 4849 */     super.consumeTypeParameters();
/* 4850 */     popElement(1040);
/*      */   }
/*      */   
/*      */   protected void consumeTypeParameterHeader() {
/* 4854 */     super.consumeTypeParameterHeader();
/* 4855 */     TypeParameter typeParameter = (TypeParameter)this.genericsStack[this.genericsPtr];
/* 4856 */     if (typeParameter.type != null || (typeParameter.bounds != null && typeParameter.bounds.length > 0))
/*      */       return; 
/* 4858 */     if (assistIdentifier() == null && this.currentToken == 19) {
/* 4859 */       if (this.cursorLocation < this.scanner.startPosition && this.scanner.currentPosition == this.scanner.startPosition) {
/* 4860 */         pushIdentifier();
/* 4861 */       } else if (this.cursorLocation + 1 >= this.scanner.startPosition && this.cursorLocation < this.scanner.currentPosition) {
/* 4862 */         pushIdentifier();
/*      */       } else {
/*      */         return;
/*      */       } 
/*      */     } else {
/*      */       return;
/*      */     } 
/*      */     
/* 4870 */     CompletionOnKeyword1 keyword = new CompletionOnKeyword1(
/* 4871 */         this.identifierStack[this.identifierPtr], 
/* 4872 */         this.identifierPositionStack[this.identifierPtr], 
/* 4873 */         Keywords.EXTENDS);
/* 4874 */     typeParameter.type = (TypeReference)keyword;
/*      */     
/* 4876 */     this.identifierPtr--;
/* 4877 */     this.identifierLengthPtr--;
/*      */     
/* 4879 */     this.assistNode = (ASTNode)typeParameter.type;
/* 4880 */     this.lastCheckPoint = typeParameter.type.sourceEnd + 1;
/*      */   }
/*      */   
/*      */   protected void consumeTypeParameter1() {
/* 4884 */     super.consumeTypeParameter1();
/* 4885 */     popElement(1040);
/*      */   }
/*      */   
/*      */   protected void consumeTypeParameterWithExtends() {
/* 4889 */     super.consumeTypeParameterWithExtends();
/* 4890 */     if (this.assistNode != null && this.assistNodeParent == null) {
/* 4891 */       TypeParameter typeParameter = (TypeParameter)this.genericsStack[this.genericsPtr];
/* 4892 */       if (typeParameter != null && typeParameter.type == this.assistNode)
/* 4893 */         this.assistNodeParent = (ASTNode)typeParameter; 
/*      */     } 
/* 4895 */     popElement(1053);
/*      */   }
/*      */   
/*      */   protected void consumeTypeParameterWithExtendsAndBounds() {
/* 4899 */     super.consumeTypeParameterWithExtendsAndBounds();
/* 4900 */     if (this.assistNode != null && this.assistNodeParent == null) {
/* 4901 */       TypeParameter typeParameter = (TypeParameter)this.genericsStack[this.genericsPtr];
/* 4902 */       if (typeParameter != null && typeParameter.type == this.assistNode)
/* 4903 */         this.assistNodeParent = (ASTNode)typeParameter; 
/*      */     } 
/* 4905 */     popElement(1053);
/*      */   }
/*      */   
/*      */   protected void consumeTypeParameter1WithExtends() {
/* 4909 */     super.consumeTypeParameter1WithExtends();
/* 4910 */     if (this.assistNode != null && this.assistNodeParent == null) {
/* 4911 */       TypeParameter typeParameter = (TypeParameter)this.genericsStack[this.genericsPtr];
/* 4912 */       if (typeParameter != null && typeParameter.type == this.assistNode)
/* 4913 */         this.assistNodeParent = (ASTNode)typeParameter; 
/*      */     } 
/* 4915 */     popElement(1053);
/*      */   }
/*      */   
/*      */   protected void consumeTypeParameter1WithExtendsAndBounds() {
/* 4919 */     super.consumeTypeParameter1WithExtendsAndBounds();
/* 4920 */     if (this.assistNode != null && this.assistNodeParent == null) {
/* 4921 */       TypeParameter typeParameter = (TypeParameter)this.genericsStack[this.genericsPtr];
/* 4922 */       if (typeParameter != null && typeParameter.type == this.assistNode)
/* 4923 */         this.assistNodeParent = (ASTNode)typeParameter; 
/*      */     } 
/* 4925 */     popElement(1053);
/*      */   }
/*      */   
/*      */   protected void consumeUnionType() {
/* 4929 */     pushOnElementStack(1031);
/* 4930 */     super.consumeUnionType();
/* 4931 */     popElement(1031);
/*      */   }
/*      */   
/*      */   protected void consumeUnionTypeAsClassType() {
/* 4935 */     pushOnElementStack(1031);
/* 4936 */     super.consumeUnionTypeAsClassType();
/* 4937 */     popElement(1031);
/*      */   }
/*      */   
/*      */   protected void consumeUsesStatement() {
/* 4941 */     super.consumeUsesStatement();
/* 4942 */     popElement(1070);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void consumeWildcard() {
/* 4947 */     super.consumeWildcard();
/* 4948 */     if (assistIdentifier() == null && this.currentToken == 19) {
/* 4949 */       if (this.cursorLocation < this.scanner.startPosition && this.scanner.currentPosition == this.scanner.startPosition) {
/* 4950 */         pushIdentifier();
/* 4951 */       } else if (this.cursorLocation + 1 >= this.scanner.startPosition && this.cursorLocation < this.scanner.currentPosition) {
/* 4952 */         pushIdentifier();
/*      */       } else {
/*      */         return;
/*      */       } 
/*      */     } else {
/*      */       return;
/*      */     } 
/* 4959 */     Wildcard wildcard = (Wildcard)this.genericsStack[this.genericsPtr];
/* 4960 */     CompletionOnKeyword1 keyword = new CompletionOnKeyword1(
/* 4961 */         this.identifierStack[this.identifierPtr], 
/* 4962 */         this.identifierPositionStack[this.identifierPtr], 
/* 4963 */         new char[][] { Keywords.EXTENDS, Keywords.SUPER });
/* 4964 */     wildcard.kind = 1;
/* 4965 */     wildcard.bound = (TypeReference)keyword;
/*      */     
/* 4967 */     this.identifierPtr--;
/* 4968 */     this.identifierLengthPtr--;
/*      */     
/* 4970 */     this.assistNode = (ASTNode)wildcard.bound;
/* 4971 */     this.lastCheckPoint = wildcard.bound.sourceEnd + 1;
/*      */   }
/*      */   
/*      */   protected void consumeWildcard1() {
/* 4975 */     super.consumeWildcard1();
/* 4976 */     popElement(1040);
/*      */   }
/*      */   
/*      */   protected void consumeWildcard2() {
/* 4980 */     super.consumeWildcard2();
/* 4981 */     popElement(1040);
/*      */   }
/*      */   
/*      */   protected void consumeWildcard3() {
/* 4985 */     super.consumeWildcard3();
/* 4986 */     popElement(1040);
/*      */   }
/*      */   
/*      */   protected void consumeWildcardBoundsExtends() {
/* 4990 */     super.consumeWildcardBoundsExtends();
/* 4991 */     if (this.assistNode != null && this.assistNodeParent == null) {
/* 4992 */       Wildcard wildcard = (Wildcard)this.genericsStack[this.genericsPtr];
/* 4993 */       if (wildcard != null && wildcard.bound == this.assistNode)
/* 4994 */         this.assistNodeParent = (ASTNode)wildcard; 
/*      */     } 
/* 4996 */     popElement(1053);
/*      */   }
/*      */   
/*      */   protected void consumeWildcardBounds1Extends() {
/* 5000 */     super.consumeWildcardBounds1Extends();
/* 5001 */     if (this.assistNode != null && this.assistNodeParent == null) {
/* 5002 */       Wildcard wildcard = (Wildcard)this.genericsStack[this.genericsPtr];
/* 5003 */       if (wildcard != null && wildcard.bound == this.assistNode)
/* 5004 */         this.assistNodeParent = (ASTNode)wildcard; 
/*      */     } 
/* 5006 */     popElement(1053);
/*      */   }
/*      */   
/*      */   protected void consumeWildcardBounds2Extends() {
/* 5010 */     super.consumeWildcardBounds2Extends();
/* 5011 */     if (this.assistNode != null && this.assistNodeParent == null) {
/* 5012 */       Wildcard wildcard = (Wildcard)this.genericsStack[this.genericsPtr];
/* 5013 */       if (wildcard != null && wildcard.bound == this.assistNode)
/* 5014 */         this.assistNodeParent = (ASTNode)wildcard; 
/*      */     } 
/* 5016 */     popElement(1053);
/*      */   }
/*      */   
/*      */   protected void consumeWildcardBounds3Extends() {
/* 5020 */     super.consumeWildcardBounds3Extends();
/* 5021 */     if (this.assistNode != null && this.assistNodeParent == null) {
/* 5022 */       Wildcard wildcard = (Wildcard)this.genericsStack[this.genericsPtr];
/* 5023 */       if (wildcard != null && wildcard.bound == this.assistNode)
/* 5024 */         this.assistNodeParent = (ASTNode)wildcard; 
/*      */     } 
/* 5026 */     popElement(1053);
/*      */   }
/*      */   
/*      */   protected void consumeUnaryExpression(int op) {
/* 5030 */     super.consumeUnaryExpression(op);
/* 5031 */     popElement(1039);
/*      */     
/* 5033 */     if (this.expressionStack[this.expressionPtr] instanceof UnaryExpression) {
/* 5034 */       UnaryExpression exp = (UnaryExpression)this.expressionStack[this.expressionPtr];
/* 5035 */       if (this.assistNode != null && exp.expression == this.assistNode) {
/* 5036 */         this.assistNodeParent = (ASTNode)exp;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumeUnaryExpression(int op, boolean post) {
/* 5042 */     super.consumeUnaryExpression(op, post);
/* 5043 */     popElement(1039);
/*      */     
/* 5045 */     if (this.expressionStack[this.expressionPtr] instanceof UnaryExpression) {
/* 5046 */       UnaryExpression exp = (UnaryExpression)this.expressionStack[this.expressionPtr];
/* 5047 */       if (this.assistNode != null && exp.expression == this.assistNode) {
/* 5048 */         this.assistNodeParent = (ASTNode)exp;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public MethodDeclaration convertToMethodDeclaration(ConstructorDeclaration c, CompilationResult compilationResult) {
/* 5054 */     MethodDeclaration methodDeclaration = super.convertToMethodDeclaration(c, compilationResult);
/* 5055 */     if (this.sourceEnds != null) {
/* 5056 */       int selectorSourceEnd = this.sourceEnds.removeKey(c);
/* 5057 */       if (selectorSourceEnd != -1)
/* 5058 */         this.sourceEnds.put(methodDeclaration, selectorSourceEnd); 
/*      */     } 
/* 5060 */     return methodDeclaration;
/*      */   }
/*      */   
/*      */   public ImportReference createAssistPackageVisibilityReference(char[][] tokens, long[] positions) {
/* 5064 */     return new CompletionOnPackageVisibilityReference(tokens, positions);
/*      */   }
/*      */   
/*      */   public ImportReference createAssistImportReference(char[][] tokens, long[] positions, int mod) {
/* 5068 */     return new CompletionOnImportReference(tokens, positions, mod);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ModuleReference createAssistModuleReference(int index) {
/* 5074 */     int length = this.identifierLengthStack[this.identifierLengthPtr];
/* 5075 */     char[][] subset = identifierSubSet(index + 1);
/* 5076 */     this.identifierLengthPtr--;
/* 5077 */     this.identifierPtr -= length;
/* 5078 */     long[] positions = new long[length];
/* 5079 */     System.arraycopy(
/* 5080 */         this.identifierPositionStack, 
/* 5081 */         this.identifierPtr + 1, 
/* 5082 */         positions, 
/* 5083 */         0, 
/* 5084 */         length);
/* 5085 */     return new CompletionOnModuleReference(subset, positions);
/*      */   }
/*      */ 
/*      */   
/*      */   public ModuleDeclaration createAssistModuleDeclaration(CompilationResult compilationResult, char[][] tokens, long[] positions) {
/* 5090 */     return new CompletionOnModuleDeclaration(compilationResult, tokens, positions);
/*      */   }
/*      */   
/*      */   public ImportReference createAssistPackageReference(char[][] tokens, long[] positions) {
/* 5094 */     return new CompletionOnPackageReference(tokens, positions);
/*      */   }
/*      */   
/*      */   public NameReference createQualifiedAssistNameReference(char[][] previousIdentifiers, char[] assistName, long[] positions) {
/* 5098 */     return (NameReference)new CompletionOnQualifiedNameReference(
/* 5099 */         previousIdentifiers, 
/* 5100 */         assistName, 
/* 5101 */         positions, 
/* 5102 */         isInsideAttributeValue());
/*      */   }
/*      */   private TypeReference checkAndCreateModuleQualifiedAssistTypeReference(char[][] previousIdentifiers, char[] assistName, long[] positions) {
/* 5105 */     if (isInUsesStatement()) return (TypeReference)new CompletionOnUsesQualifiedTypeReference(previousIdentifiers, assistName, positions); 
/* 5106 */     if (isInProvidesStatement()) {
/* 5107 */       if (isAfterWithClause()) return (TypeReference)new CompletionOnProvidesImplementationsQualifiedTypeReference(previousIdentifiers, assistName, positions); 
/* 5108 */       return (TypeReference)new CompletionOnProvidesInterfacesQualifiedTypeReference(previousIdentifiers, assistName, positions);
/*      */     } 
/* 5110 */     return null;
/*      */   }
/*      */   
/*      */   public TypeReference createQualifiedAssistTypeReference(char[][] previousIdentifiers, char[] assistName, long[] positions) {
/* 5114 */     switch (topKnownElementKind(1536)) {
/*      */       case 1031:
/* 5116 */         if (topKnownElementKind(1536, 1) == 1028)
/* 5117 */           this.isOrphanCompletionNode = true; 
/* 5118 */         return (TypeReference)new CompletionOnQualifiedTypeReference(
/* 5119 */             previousIdentifiers, 
/* 5120 */             assistName, 
/* 5121 */             positions, 
/* 5122 */             3);
/*      */       case 1029:
/* 5124 */         return (TypeReference)new CompletionOnQualifiedTypeReference(
/* 5125 */             previousIdentifiers, 
/* 5126 */             assistName, 
/* 5127 */             positions, 
/* 5128 */             1);
/*      */       case 1030:
/* 5130 */         return (TypeReference)new CompletionOnQualifiedTypeReference(
/* 5131 */             previousIdentifiers, 
/* 5132 */             assistName, 
/* 5133 */             positions, 
/* 5134 */             2);
/*      */     } 
/* 5136 */     TypeReference ref = checkAndCreateModuleQualifiedAssistTypeReference(
/* 5137 */         previousIdentifiers, 
/* 5138 */         assistName, 
/* 5139 */         positions);
/* 5140 */     if (ref != null)
/* 5141 */       return ref; 
/* 5142 */     return (TypeReference)new CompletionOnQualifiedTypeReference(previousIdentifiers, assistName, positions, 
/* 5143 */         0);
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeReference createParameterizedQualifiedAssistTypeReference(char[][] previousIdentifiers, TypeReference[][] typeArguments, char[] assistName, TypeReference[] assistTypeArguments, long[] positions) {
/* 5148 */     boolean isParameterized = false;
/* 5149 */     for (int i = 0; i < typeArguments.length; i++) {
/* 5150 */       if (typeArguments[i] != null) {
/* 5151 */         isParameterized = true;
/*      */         break;
/*      */       } 
/*      */     } 
/* 5155 */     if (!isParameterized) {
/* 5156 */       return createQualifiedAssistTypeReference(previousIdentifiers, assistName, positions);
/*      */     }
/* 5158 */     switch (topKnownElementKind(1536)) {
/*      */       case 1031:
/* 5160 */         if (topKnownElementKind(1536, 1) == 1028)
/* 5161 */           this.isOrphanCompletionNode = true; 
/* 5162 */         return (TypeReference)new CompletionOnParameterizedQualifiedTypeReference(
/* 5163 */             previousIdentifiers, 
/* 5164 */             typeArguments, 
/* 5165 */             assistName, 
/* 5166 */             positions, 
/* 5167 */             3);
/*      */       case 1029:
/* 5169 */         return (TypeReference)new CompletionOnParameterizedQualifiedTypeReference(
/* 5170 */             previousIdentifiers, 
/* 5171 */             typeArguments, 
/* 5172 */             assistName, 
/* 5173 */             positions, 
/* 5174 */             1);
/*      */       case 1030:
/* 5176 */         return (TypeReference)new CompletionOnParameterizedQualifiedTypeReference(
/* 5177 */             previousIdentifiers, 
/* 5178 */             typeArguments, 
/* 5179 */             assistName, 
/* 5180 */             positions, 
/* 5181 */             2);
/*      */     } 
/* 5183 */     return (TypeReference)new CompletionOnParameterizedQualifiedTypeReference(
/* 5184 */         previousIdentifiers, 
/* 5185 */         typeArguments, 
/* 5186 */         assistName, 
/* 5187 */         positions);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public NameReference createSingleAssistNameReference(char[] assistName, long position) {
/* 5193 */     int kind = topKnownElementKind(1536);
/* 5194 */     if (!isInsideMethod()) {
/* 5195 */       if (isInsideFieldInitialization()) {
/* 5196 */         return (NameReference)new CompletionOnSingleNameReference(
/* 5197 */             assistName, 
/* 5198 */             position, 
/* 5199 */             new char[][] { Keywords.FALSE, Keywords.TRUE
/* 5200 */             }, false, 
/* 5201 */             isInsideAttributeValue());
/*      */       }
/* 5203 */       return (NameReference)new CompletionOnSingleNameReference(assistName, position, isInsideAttributeValue());
/*      */     } 
/* 5205 */     boolean canBeExplicitConstructorCall = false;
/* 5206 */     if ((kind == 1025 || kind == 519) && 
/* 5207 */       this.previousKind == 1025 && 
/* 5208 */       this.previousInfo == 7)
/* 5209 */       return (NameReference)new CompletionOnKeyword3(assistName, position, Keywords.WHILE); 
/* 5210 */     if ((kind == 1025 || kind == 519) && 
/* 5211 */       this.previousKind == 1025 && 
/* 5212 */       this.previousInfo == 2)
/* 5213 */       return (NameReference)new CompletionOnKeyword3(assistName, position, new char[][] { Keywords.CATCH, Keywords.FINALLY }, true); 
/* 5214 */     if (kind == 1025 && 
/* 5215 */       topKnownElementInfo(1536) == 5) {
/* 5216 */       return (NameReference)new CompletionOnKeyword3(assistName, position, new char[][] { Keywords.CASE, Keywords.DEFAULT }, false);
/*      */     }
/* 5218 */     List<char[]> keywordsList = (List)new ArrayList<>(50);
/* 5219 */     canBeExplicitConstructorCall = computeKeywords(kind, keywordsList);
/* 5220 */     char[][] keywords = (char[][])keywordsList.toArray(paramInt -> new char[paramInt][]);
/* 5221 */     return (NameReference)new CompletionOnSingleNameReference(assistName, position, keywords, canBeExplicitConstructorCall, isInsideAttributeValue());
/*      */   }
/*      */ 
/*      */   
/*      */   boolean computeKeywords(int kind, List<char[]> keywords) {
/* 5226 */     boolean canBeExplicitConstructorCall = false;
/*      */     
/* 5228 */     if ((this.lastModifiers & 0x8) == 0) {
/* 5229 */       keywords.add(Keywords.SUPER);
/* 5230 */       keywords.add(Keywords.THIS);
/*      */     } 
/* 5232 */     keywords.add(Keywords.NEW);
/*      */ 
/*      */ 
/*      */     
/* 5236 */     if (kind == 1025 || kind == 1062 || kind == 519 || 
/* 5237 */       kind == 521) {
/* 5238 */       if (this.canBeExplicitConstructor == 2) {
/* 5239 */         canBeExplicitConstructorCall = true;
/*      */       }
/* 5241 */       if (this.options.complianceLevel >= 3145728L) {
/* 5242 */         keywords.add(Keywords.ASSERT);
/*      */       }
/* 5244 */       keywords.add(Keywords.DO);
/* 5245 */       keywords.add(Keywords.FOR);
/* 5246 */       keywords.add(Keywords.IF);
/* 5247 */       keywords.add(Keywords.RETURN);
/* 5248 */       keywords.add(Keywords.SWITCH);
/* 5249 */       keywords.add(Keywords.SYNCHRONIZED);
/* 5250 */       keywords.add(Keywords.THROW);
/* 5251 */       keywords.add(Keywords.TRY);
/* 5252 */       keywords.add(Keywords.WHILE);
/*      */       
/* 5254 */       keywords.add(Keywords.FINAL);
/* 5255 */       keywords.add(Keywords.CLASS);
/* 5256 */       if (this.options.complianceLevel >= 3538944L) {
/* 5257 */         keywords.add(Keywords.VAR);
/*      */       }
/* 5259 */       if (this.options.complianceLevel >= 3932160L) {
/* 5260 */         keywords.add(Keywords.INTERFACE);
/* 5261 */         keywords.add(Keywords.ENUM);
/*      */       } 
/*      */       
/* 5264 */       if (this.previousKind == 1025) {
/* 5265 */         switch (this.previousInfo) {
/*      */           case 1:
/* 5267 */             keywords.add(Keywords.ELSE);
/*      */             break;
/*      */           case 3:
/* 5270 */             keywords.add(Keywords.CATCH);
/* 5271 */             keywords.add(Keywords.FINALLY);
/*      */             break;
/*      */         } 
/* 5274 */       } else if (this.previousKind == 1062 && this.previousInfo == 1) {
/* 5275 */         keywords.add(Keywords.ELSE);
/*      */       } 
/* 5277 */       if (isInsideLoop()) {
/* 5278 */         keywords.add(Keywords.CONTINUE);
/*      */       }
/* 5280 */       if (isInsideBreakable()) {
/* 5281 */         keywords.add(Keywords.BREAK);
/*      */       }
/* 5283 */       if (isInsideSwitch()) {
/* 5284 */         keywords.add(Keywords.YIELD);
/*      */       }
/* 5286 */     } else if (kind == 1045) {
/* 5287 */       if (this.options.complianceLevel >= 3538944L) {
/* 5288 */         keywords.add(Keywords.VAR);
/*      */       }
/* 5290 */     } else if (kind != 1050 && kind != 1051) {
/* 5291 */       if (kind == 1036 && this.options.complianceLevel >= 3604480L) {
/* 5292 */         keywords.add(Keywords.VAR);
/*      */       }
/* 5294 */       if (kind == 1027 && this.options.complianceLevel >= 3670016L) {
/* 5295 */         keywords.add(Keywords.SWITCH);
/*      */       }
/* 5297 */       keywords.add(Keywords.TRUE);
/* 5298 */       keywords.add(Keywords.FALSE);
/* 5299 */       keywords.add(Keywords.NULL);
/* 5300 */       if (this.options.complianceLevel >= 4128768L) {
/* 5301 */         keywords.add(Keywords.WHEN);
/*      */       }
/* 5303 */       if (kind == 1076) {
/* 5304 */         keywords.add(Keywords.YIELD);
/*      */       }
/* 5306 */       if (kind == 1049) {
/* 5307 */         if (topKnownElementInfo(1536) != 1) {
/* 5308 */           keywords.add(Keywords.DEFAULT);
/*      */         }
/* 5310 */         keywords.add(Keywords.BREAK);
/* 5311 */         keywords.add(Keywords.CASE);
/* 5312 */         keywords.add(Keywords.YIELD);
/* 5313 */         if (this.options.complianceLevel >= 3145728L) {
/* 5314 */           keywords.add(Keywords.ASSERT);
/*      */         }
/* 5316 */         keywords.add(Keywords.DO);
/* 5317 */         keywords.add(Keywords.FOR);
/* 5318 */         keywords.add(Keywords.IF);
/* 5319 */         keywords.add(Keywords.RETURN);
/* 5320 */         keywords.add(Keywords.SWITCH);
/* 5321 */         keywords.add(Keywords.SYNCHRONIZED);
/* 5322 */         keywords.add(Keywords.THROW);
/* 5323 */         keywords.add(Keywords.TRY);
/* 5324 */         keywords.add(Keywords.WHILE);
/*      */         
/* 5326 */         keywords.add(Keywords.FINAL);
/* 5327 */         keywords.add(Keywords.CLASS);
/*      */         
/* 5329 */         if (this.options.complianceLevel >= 3538944L) {
/* 5330 */           keywords.add(Keywords.VAR);
/*      */         }
/* 5332 */         if (isInsideLoop()) {
/* 5333 */           keywords.add(Keywords.CONTINUE);
/*      */         }
/*      */       } 
/*      */     } 
/* 5337 */     return canBeExplicitConstructorCall;
/*      */   }
/*      */   private TypeReference checkAndCreateModuleSingleAssistTypeReference(char[] assistName, long position) {
/* 5340 */     if (isInUsesStatement()) return (TypeReference)new CompletionOnUsesSingleTypeReference(assistName, position); 
/* 5341 */     if (isInProvidesStatement()) {
/* 5342 */       if (isAfterWithClause()) return (TypeReference)new CompletionOnProvidesImplementationsSingleTypeReference(assistName, position); 
/* 5343 */       return (TypeReference)new CompletionOnProvidesInterfacesSingleTypeReference(assistName, position);
/*      */     } 
/* 5345 */     List<char[]> keywords = (List)new ArrayList<>(50);
/* 5346 */     boolean canBeCtorCall = computeKeywords(topKnownElementKind(1536), keywords);
/* 5347 */     return (TypeReference)new CompletionOnSingleTypeReference(assistName, position, (char[][])keywords.toArray(paramInt -> new char[paramInt][]), canBeCtorCall);
/*      */   }
/*      */   
/*      */   public TypeReference createSingleAssistTypeReference(char[] assistName, long position) {
/* 5351 */     switch (topKnownElementKind(1536)) {
/*      */       case 1031:
/* 5353 */         if (topKnownElementKind(1536, 1) == 1028)
/* 5354 */           this.isOrphanCompletionNode = true; 
/* 5355 */         return (TypeReference)new CompletionOnSingleTypeReference(assistName, position, 3);
/*      */       case 1029:
/* 5357 */         return (TypeReference)new CompletionOnSingleTypeReference(assistName, position, 1);
/*      */       case 1030:
/* 5359 */         return (TypeReference)new CompletionOnSingleTypeReference(assistName, position, 2);
/*      */     } 
/* 5361 */     return checkAndCreateModuleSingleAssistTypeReference(assistName, position);
/*      */   }
/*      */ 
/*      */   
/*      */   public TypeReference createParameterizedSingleAssistTypeReference(TypeReference[] typeArguments, char[] assistName, long position) {
/* 5366 */     return createSingleAssistTypeReference(assistName, position);
/*      */   }
/*      */   
/*      */   protected StringLiteral createStringLiteral(char[] token, int start, int end, int lineNumber) {
/* 5370 */     if (start <= this.cursorLocation && this.cursorLocation <= end) {
/* 5371 */       char[] source = this.scanner.source;
/*      */       
/* 5373 */       int contentStart = start;
/* 5374 */       int contentEnd = end;
/*      */ 
/*      */       
/* 5377 */       int pos = contentStart;
/* 5378 */       if (source[pos] == '"') {
/* 5379 */         contentStart = pos + 1;
/* 5380 */       } else if (source[pos] == '\\' && source[pos + 1] == 'u') {
/* 5381 */         pos += 2;
/* 5382 */         while (source[pos] == 'u') {
/* 5383 */           pos++;
/*      */         }
/* 5385 */         if (source[pos] == '\000' && source[pos + 1] == '\000' && source[pos + 2] == '\002' && source[pos + 3] == '\002') {
/* 5386 */           contentStart = pos + 4;
/*      */         }
/*      */       } 
/*      */       
/* 5390 */       pos = contentEnd;
/* 5391 */       if (source[pos] == '"') {
/* 5392 */         contentEnd = pos - 1;
/* 5393 */       } else if (source.length > 5 && source[pos - 4] == 'u' && 
/* 5394 */         source[pos - 3] == '\000' && source[pos - 2] == '\000' && source[pos - 1] == '\002' && source[pos] == '\002') {
/* 5395 */         pos -= 5;
/* 5396 */         while (pos > -1 && source[pos] == 'u') {
/* 5397 */           pos--;
/*      */         }
/* 5399 */         if (pos > -1 && source[pos] == '\\') {
/* 5400 */           contentEnd = pos - 1;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 5405 */       if (contentEnd < start) {
/* 5406 */         contentEnd = end;
/*      */       }
/*      */       
/* 5409 */       if (this.cursorLocation != end || end == contentEnd) {
/* 5410 */         CompletionOnStringLiteral stringLiteral = new CompletionOnStringLiteral(
/* 5411 */             token, 
/* 5412 */             start, 
/* 5413 */             end, 
/* 5414 */             contentStart, 
/* 5415 */             contentEnd, 
/* 5416 */             lineNumber);
/*      */         
/* 5418 */         this.assistNode = (ASTNode)stringLiteral;
/* 5419 */         this.restartRecovery = true;
/* 5420 */         this.lastCheckPoint = end;
/*      */         
/* 5422 */         return stringLiteral;
/*      */       } 
/*      */     } 
/* 5425 */     return super.createStringLiteral(token, start, end, lineNumber);
/*      */   }
/*      */   
/*      */   protected TypeReference augmentTypeWithAdditionalDimensions(TypeReference typeRef, int additionalDimensions, Annotation[][] additionalAnnotations, boolean isVarargs) {
/* 5429 */     if (this.assistNode == typeRef) {
/* 5430 */       return typeRef;
/*      */     }
/* 5432 */     TypeReference result = super.augmentTypeWithAdditionalDimensions(typeRef, additionalDimensions, additionalAnnotations, isVarargs);
/* 5433 */     if (this.assistNodeParent == typeRef) {
/* 5434 */       this.assistNodeParent = (ASTNode)result;
/*      */     }
/* 5436 */     return result;
/*      */   }
/*      */   
/*      */   public CompilationUnitDeclaration dietParse(ICompilationUnit sourceUnit, CompilationResult compilationResult, int cursorLoc) {
/* 5440 */     this.cursorLocation = cursorLoc;
/* 5441 */     CompletionScanner completionScanner = (CompletionScanner)this.scanner;
/* 5442 */     completionScanner.completionIdentifier = null;
/* 5443 */     completionScanner.cursorLocation = cursorLoc;
/* 5444 */     return dietParse(sourceUnit, compilationResult);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void flushAssistState() {
/* 5452 */     super.flushAssistState();
/* 5453 */     this.isOrphanCompletionNode = false;
/* 5454 */     this.isAlreadyAttached = false;
/* 5455 */     this.assistNodeParent = null;
/* 5456 */     CompletionScanner completionScanner = (CompletionScanner)this.scanner;
/* 5457 */     completionScanner.completedIdentifierStart = 0;
/* 5458 */     completionScanner.completedIdentifierEnd = -1;
/*      */   }
/*      */ 
/*      */   
/*      */   protected TypeReference getTypeReferenceForGenericType(int dim, int identifierLength, int numberOfIdentifiers) {
/* 5463 */     TypeReference ref = super.getTypeReferenceForGenericType(dim, identifierLength, numberOfIdentifiers);
/*      */ 
/*      */ 
/*      */     
/* 5467 */     checkForDiamond(ref);
/* 5468 */     if (this.assistNode != null) {
/* 5469 */       if (identifierLength == 1 && numberOfIdentifiers == 1) {
/* 5470 */         ParameterizedSingleTypeReference singleRef = (ParameterizedSingleTypeReference)ref;
/* 5471 */         TypeReference[] typeArguments = singleRef.typeArguments;
/* 5472 */         for (int i = 0; i < typeArguments.length; i++) {
/* 5473 */           if (typeArguments[i] == this.assistNode) {
/* 5474 */             this.assistNodeParent = (ASTNode)ref;
/* 5475 */             return ref;
/*      */           } 
/*      */         } 
/*      */       } else {
/* 5479 */         ParameterizedQualifiedTypeReference qualifiedRef = (ParameterizedQualifiedTypeReference)ref;
/* 5480 */         TypeReference[][] typeArguments = qualifiedRef.typeArguments;
/* 5481 */         for (int i = 0; i < typeArguments.length; i++) {
/* 5482 */           if (typeArguments[i] != null) {
/* 5483 */             for (int j = 0; j < (typeArguments[i]).length; j++) {
/* 5484 */               if (typeArguments[i][j] == this.assistNode) {
/* 5485 */                 this.assistNodeParent = (ASTNode)ref;
/* 5486 */                 return ref;
/*      */               } 
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 5495 */     return ref;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected NameReference getUnspecifiedReference(boolean rejectTypeAnnotations) {
/*      */     QualifiedNameReference qualifiedNameReference;
/* 5502 */     if (rejectTypeAnnotations) {
/* 5503 */       consumeNonTypeUseName();
/*      */     }
/*      */     
/*      */     int length;
/* 5507 */     if ((length = this.identifierLengthStack[this.identifierLengthPtr--]) == 1) {
/*      */       
/* 5509 */       char[] token = this.identifierStack[this.identifierPtr];
/* 5510 */       long position = this.identifierPositionStack[this.identifierPtr--];
/* 5511 */       int start = (int)(position >>> 32L), end = (int)position;
/*      */ 
/*      */       
/* 5514 */       int adjustedStart = (token.length == 0) ? (start - 1) : start;
/* 5515 */       if (this.assistNode == null && adjustedStart <= this.cursorLocation && end >= this.cursorLocation) {
/* 5516 */         CompletionOnSingleNameReference completionOnSingleNameReference = new CompletionOnSingleNameReference(token, position, isInsideAttributeValue());
/* 5517 */         ((NameReference)completionOnSingleNameReference).sourceEnd = (token.length == 0) ? adjustedStart : ((NameReference)completionOnSingleNameReference).sourceEnd;
/* 5518 */         this.assistNode = (ASTNode)completionOnSingleNameReference;
/*      */       } else {
/* 5520 */         SingleNameReference singleNameReference = new SingleNameReference(token, position);
/*      */       } 
/*      */     } else {
/*      */       
/* 5524 */       char[][] tokens = new char[length][];
/* 5525 */       this.identifierPtr -= length;
/* 5526 */       System.arraycopy(this.identifierStack, this.identifierPtr + 1, tokens, 0, length);
/* 5527 */       long[] positions = new long[length];
/* 5528 */       System.arraycopy(this.identifierPositionStack, this.identifierPtr + 1, positions, 0, length);
/* 5529 */       int start = (int)(positions[0] >>> 32L), end = (int)positions[length - 1];
/* 5530 */       if (this.assistNode == null && start <= this.cursorLocation && end >= this.cursorLocation) {
/*      */         CompletionOnSingleNameReference completionOnSingleNameReference;
/* 5532 */         int previousCount = 0;
/* 5533 */         for (int i = 0; i < length; i++) {
/* 5534 */           if ((int)positions[i] < this.cursorLocation)
/* 5535 */             previousCount = i + 1; 
/*      */         } 
/* 5537 */         if (previousCount > 0) {
/* 5538 */           char[][] subset = new char[previousCount][];
/* 5539 */           System.arraycopy(tokens, 0, subset, 0, previousCount);
/* 5540 */           qualifiedNameReference = new CompletionOnQualifiedNameReference(subset, tokens[previousCount], positions, isInsideAttributeValue());
/*      */         } else {
/*      */           
/* 5543 */           completionOnSingleNameReference = new CompletionOnSingleNameReference(tokens[0], positions[0], isInsideAttributeValue());
/*      */         } 
/* 5545 */         this.assistNode = (ASTNode)completionOnSingleNameReference;
/*      */       } else {
/* 5547 */         qualifiedNameReference = 
/* 5548 */           new QualifiedNameReference(tokens, 
/* 5549 */             positions, 
/* 5550 */             (int)(this.identifierPositionStack[this.identifierPtr + 1] >> 32L), 
/* 5551 */             (int)this.identifierPositionStack[this.identifierPtr + length]);
/*      */       } 
/*      */     } 
/* 5554 */     if (this.record) {
/* 5555 */       recordReference((NameReference)qualifiedNameReference);
/*      */     }
/* 5557 */     return (NameReference)qualifiedNameReference;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void updateSourcePosition(Expression exp) {
/* 5562 */     if (exp == this.assistNode) {
/* 5563 */       this.intPtr -= 2;
/*      */     } else {
/* 5565 */       super.updateSourcePosition(exp);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void consumePostfixExpression() {
/* 5570 */     if (topKnownElementKind(1536) != 1076) {
/* 5571 */       super.consumePostfixExpression();
/*      */     }
/*      */   }
/*      */   
/*      */   protected NameReference getUnspecifiedReferenceOptimized() {
/* 5576 */     if (this.identifierLengthStack[this.identifierLengthPtr] > 1) {
/*      */       
/* 5578 */       this.invocationType = -1;
/* 5579 */       this.qualifier = -1;
/*      */     } 
/* 5581 */     NameReference nameReference = super.getUnspecifiedReferenceOptimized();
/* 5582 */     if (this.record) {
/* 5583 */       recordReference(nameReference);
/*      */     }
/* 5585 */     return nameReference;
/*      */   }
/*      */   private boolean isAlreadyPotentialName(int identifierStart) {
/* 5588 */     if (this.potentialVariableNamesPtr < 0) return false;
/*      */     
/* 5590 */     return (identifierStart <= this.potentialVariableNameEnds[this.potentialVariableNamesPtr]);
/*      */   }
/*      */   
/*      */   protected int indexOfAssistIdentifier(boolean useGenericsStack) {
/* 5594 */     if (this.record) return -1; 
/* 5595 */     return super.indexOfAssistIdentifier(useGenericsStack);
/*      */   }
/*      */   
/*      */   public void initialize() {
/* 5599 */     super.initialize();
/* 5600 */     this.labelPtr = -1;
/* 5601 */     initializeForBlockStatements();
/*      */   }
/*      */   
/*      */   public void initialize(boolean parsingCompilationUnit) {
/* 5605 */     super.initialize(parsingCompilationUnit);
/* 5606 */     this.labelPtr = -1;
/* 5607 */     initializeForBlockStatements();
/*      */   }
/*      */ 
/*      */   
/*      */   public void copyState(Parser from) {
/* 5612 */     super.copyState(from);
/*      */     
/* 5614 */     CompletionParser parser = (CompletionParser)from;
/*      */     
/* 5616 */     this.invocationType = parser.invocationType;
/* 5617 */     this.qualifier = parser.qualifier;
/* 5618 */     this.inReferenceExpression = parser.inReferenceExpression;
/* 5619 */     this.hasUnusedModifiers = parser.hasUnusedModifiers;
/* 5620 */     this.canBeExplicitConstructor = parser.canBeExplicitConstructor;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeForBlockStatements() {
/* 5626 */     this.previousToken = -1;
/* 5627 */     this.previousIdentifierPtr = -1;
/* 5628 */     this.invocationType = -1;
/* 5629 */     this.qualifier = -1;
/* 5630 */     popUntilElement(1049);
/* 5631 */     if (topKnownElementKind(1536) != 1049) {
/* 5632 */       if (topKnownElementKind(1536) == 1037) {
/*      */ 
/*      */ 
/*      */         
/* 5636 */         popUntilElement(1037);
/*      */       } else {
/* 5638 */         popUntilElement(1025);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   public void initializeScanner() {
/* 5644 */     this.scanner = new CompletionScanner(this.options.sourceLevel, this.options.enablePreviewFeatures);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isAfterArrayType() {
/* 5654 */     if (this.intPtr > -1 && this.intStack[this.intPtr] < 11) {
/* 5655 */       return true;
/*      */     }
/* 5657 */     return false;
/*      */   }
/*      */   private boolean isEmptyNameCompletion() {
/* 5660 */     return 
/* 5661 */       (this.assistNode != null && 
/* 5662 */       this.assistNode instanceof CompletionOnSingleNameReference && 
/* 5663 */       ((CompletionOnSingleNameReference)this.assistNode).token.length == 0);
/*      */   }
/*      */   protected boolean isInsideAnnotation() {
/* 5666 */     int i = this.elementPtr;
/* 5667 */     while (i > -1) {
/* 5668 */       if (this.elementKindStack[i] == 1057)
/* 5669 */         return true; 
/* 5670 */       i--;
/*      */     } 
/* 5672 */     return false;
/*      */   }
/*      */   
/*      */   protected boolean isInsideSwitch() {
/* 5676 */     int i = this.elementPtr;
/* 5677 */     while (i > -1) {
/* 5678 */       switch (this.elementKindStack[i]) { case 1049:
/* 5679 */           return true; }
/*      */       
/* 5681 */       i--;
/*      */     } 
/* 5683 */     return false;
/*      */   }
/*      */   protected boolean isInsideBreakable() {
/* 5686 */     int i = this.elementPtr;
/* 5687 */     while (i > -1) {
/* 5688 */       switch (this.elementKindStack[i]) { case 514:
/* 5689 */           return false;
/* 5690 */         case 515: return false;
/* 5691 */         case 516: return false;
/* 5692 */         case 1049: return true;
/*      */         case 1025:
/*      */         case 1062:
/* 5695 */           switch (this.elementInfoStack[i]) {
/*      */             case 4:
/*      */             case 6:
/*      */             case 7:
/* 5699 */               return true;
/*      */           }  break; }
/*      */       
/* 5702 */       i--;
/*      */     } 
/* 5704 */     return false;
/*      */   }
/*      */   protected boolean isInsideLoop() {
/* 5707 */     int i = this.elementPtr;
/* 5708 */     while (i > -1) {
/* 5709 */       switch (this.elementKindStack[i]) { case 514:
/* 5710 */           return false;
/* 5711 */         case 515: return false;
/* 5712 */         case 516: return false;
/*      */         case 1025:
/*      */         case 1062:
/* 5715 */           switch (this.elementInfoStack[i]) {
/*      */             case 4:
/*      */             case 6:
/*      */             case 7:
/* 5719 */               return true;
/*      */           }  break; }
/*      */       
/* 5722 */       i--;
/*      */     } 
/* 5724 */     return false;
/*      */   }
/*      */   protected boolean isInsideReturn() {
/* 5727 */     int i = this.elementPtr;
/* 5728 */     while (i > -1) {
/* 5729 */       switch (this.elementKindStack[i]) { case 514:
/* 5730 */           return false;
/* 5731 */         case 515: return false;
/* 5732 */         case 516: return false;
/* 5733 */         case 1025: return false;
/* 5734 */         case 1062: return false;
/* 5735 */         case 1034: return true; }
/*      */       
/* 5737 */       i--;
/*      */     } 
/* 5739 */     return false;
/*      */   }
/*      */   
/*      */   public ReferenceExpression newReferenceExpression() {
/* 5743 */     char[] selector = this.identifierStack[this.identifierPtr];
/* 5744 */     if (selector != assistIdentifier()) {
/* 5745 */       return super.newReferenceExpression();
/*      */     }
/* 5747 */     ReferenceExpression referenceExpression = new CompletionOnReferenceExpressionName(this.scanner);
/* 5748 */     this.assistNode = (ASTNode)referenceExpression;
/* 5749 */     return referenceExpression;
/*      */   }
/*      */ 
/*      */   
/*      */   protected MessageSend newMessageSend() {
/* 5754 */     MessageSend m = internalNewMessageSend();
/* 5755 */     if (m != null)
/* 5756 */       return m; 
/* 5757 */     return super.newMessageSend();
/*      */   }
/*      */ 
/*      */   
/*      */   protected MessageSend newMessageSendWithTypeArguments() {
/* 5762 */     MessageSend m = internalNewMessageSend();
/* 5763 */     if (m != null)
/* 5764 */       return m; 
/* 5765 */     return super.newMessageSendWithTypeArguments();
/*      */   }
/*      */   private MessageSend internalNewMessageSend() {
/* 5768 */     MessageSend m = null;
/* 5769 */     long nameStart = this.identifierPositionStack[this.identifierPtr] >>> 32L;
/* 5770 */     if (this.assistNode == null && this.lParenPos > this.cursorLocation && nameStart <= (this.cursorLocation + 1)) {
/* 5771 */       boolean nextIsCast = (this.expressionPtr > -1 && this.expressionStack[this.expressionPtr] instanceof CastExpression);
/* 5772 */       m = new CompletionOnMessageSendName(null, 0, 0, nextIsCast);
/* 5773 */     } else if (this.assistNode != null && this.lParenPos == this.assistNode.sourceEnd) {
/*      */       
/* 5775 */       if (this.expressionPtr != -1 && this.expressionStack[this.expressionPtr] == this.assistNode) {
/*      */         
/* 5777 */         this.expressionLengthStack[this.expressionLengthPtr] = this.expressionLengthStack[this.expressionLengthPtr] - 1;
/* 5778 */         this.expressionPtr--;
/*      */       } 
/* 5780 */       m = new CompletionOnMessageSend();
/*      */     } 
/* 5782 */     if (m != null) {
/*      */       int length;
/*      */       
/* 5785 */       if ((length = this.expressionLengthStack[this.expressionLengthPtr--]) != 0) {
/* 5786 */         this.expressionPtr -= length;
/* 5787 */         System.arraycopy(
/* 5788 */             this.expressionStack, 
/* 5789 */             this.expressionPtr + 1, 
/* 5790 */             m.arguments = new Expression[length], 
/* 5791 */             0, 
/* 5792 */             length);
/*      */       } 
/* 5794 */       this.assistNode = (ASTNode)m;
/* 5795 */       return m;
/*      */     } 
/* 5797 */     return null;
/*      */   }
/*      */   
/*      */   protected AllocationExpression newAllocationExpression(boolean isQualified) {
/* 5801 */     if (this.assistNode != null && checkIfAtFirstArgumentOfConstructor()) {
/* 5802 */       CompletionOnQualifiedAllocationExpression allocation = new CompletionOnQualifiedAllocationExpression();
/* 5803 */       this.assistNode = (ASTNode)allocation;
/* 5804 */       return (AllocationExpression)allocation;
/*      */     } 
/* 5806 */     return super.newAllocationExpression(isQualified);
/*      */   }
/*      */   
/*      */   private boolean checkIfAtFirstArgumentOfConstructor() {
/* 5810 */     if (this.lParenPos == this.assistNode.sourceEnd) {
/* 5811 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5820 */     int startPos = this.intStack[this.intPtr] + (this.identifierStack[this.identifierPtr]).length + 1 + 3;
/*      */     
/* 5822 */     if (this.assistNode instanceof CompletionOnSingleNameReference)
/* 5823 */       return (startPos == this.assistNode.sourceEnd); 
/* 5824 */     ASTNode aSTNode = this.assistNode; if (aSTNode instanceof CompletionOnMessageSendName) { CompletionOnMessageSendName completionOnMessageSendName; (CompletionOnMessageSendName)aSTNode;
/* 5825 */       return (startPos == completionOnMessageSendName.sourceStart - 1); }
/*      */     
/* 5827 */     return false;
/*      */   }
/*      */   
/*      */   public CompilationUnitDeclaration parse(ICompilationUnit sourceUnit, CompilationResult compilationResult, int cursorLoc) {
/* 5831 */     this.cursorLocation = cursorLoc;
/* 5832 */     CompletionScanner completionScanner = (CompletionScanner)this.scanner;
/* 5833 */     completionScanner.completionIdentifier = null;
/* 5834 */     completionScanner.cursorLocation = cursorLoc;
/* 5835 */     return parse(sourceUnit, compilationResult);
/*      */   }
/*      */   
/*      */   public void parseBlockStatements(AbstractMethodDeclaration md, CompilationUnitDeclaration unit) {
/* 5839 */     if (md.arguments != null) {
/* 5840 */       byte b; int i; Argument[] arrayOfArgument; for (i = (arrayOfArgument = md.arguments).length, b = 0; b < i; ) { Argument argument = arrayOfArgument[b];
/* 5841 */         if (argument instanceof CompletionOnArgumentName && argument == this.assistNode)
/*      */           return;  b++; }
/*      */     
/*      */     } 
/* 5845 */     super.parseBlockStatements(md, unit);
/*      */ 
/*      */     
/* 5848 */     if ((md.bits & 0x80000) != 0 && this.lastAct == 18574 && 
/* 5849 */       this.assistNode != null && this.assistNode.sourceEnd >= this.cursorLocation) {
/* 5850 */       md.bits &= 0xFFF7FFFF;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void parseBlockStatements(ConstructorDeclaration cd, CompilationUnitDeclaration unit) {
/* 5857 */     this.canBeExplicitConstructor = 1;
/* 5858 */     if (cd.arguments != null) {
/* 5859 */       byte b; int i; Argument[] arrayOfArgument; for (i = (arrayOfArgument = cd.arguments).length, b = 0; b < i; ) { Argument argument = arrayOfArgument[b];
/* 5860 */         if (argument instanceof CompletionOnArgumentName && argument == this.assistNode)
/*      */           return;  b++; }
/*      */     
/*      */     } 
/* 5864 */     super.parseBlockStatements(cd, unit);
/*      */   }
/*      */   public MethodDeclaration parseSomeStatements(int start, int end, int fakeBlocksCount, CompilationUnitDeclaration unit) {
/* 5867 */     this.methodRecoveryActivated = true;
/*      */     
/* 5869 */     initialize();
/*      */ 
/*      */     
/* 5872 */     goForBlockStatementsopt();
/*      */     
/* 5874 */     MethodDeclaration fakeMethod = new MethodDeclaration(unit.compilationResult());
/* 5875 */     fakeMethod.selector = FAKE_METHOD_NAME;
/* 5876 */     fakeMethod.bodyStart = start;
/* 5877 */     fakeMethod.bodyEnd = end;
/* 5878 */     fakeMethod.declarationSourceStart = start;
/* 5879 */     fakeMethod.declarationSourceEnd = end;
/* 5880 */     fakeMethod.sourceStart = start;
/* 5881 */     fakeMethod.sourceEnd = start;
/*      */     
/* 5883 */     this.referenceContext = (ReferenceContext)fakeMethod;
/* 5884 */     this.compilationUnit = unit;
/*      */     
/* 5886 */     this.diet = false;
/* 5887 */     this.restartRecovery = true;
/*      */     
/* 5889 */     this.scanner.resetTo(start, end);
/* 5890 */     consumeNestedMethod();
/* 5891 */     for (int i = 0; i < fakeBlocksCount; i++) {
/* 5892 */       consumeOpenFakeBlock();
/*      */     }
/*      */     try {
/* 5895 */       parse();
/* 5896 */     } catch (AbortCompilation abortCompilation) {
/* 5897 */       this.lastAct = 18574;
/*      */     } finally {
/* 5899 */       this.nestedMethod[this.nestedType] = this.nestedMethod[this.nestedType] - 1;
/*      */     } 
/* 5901 */     if (!this.hasError) {
/*      */       int length;
/* 5903 */       if (this.astLengthPtr > -1 && (length = this.astLengthStack[this.astLengthPtr--]) != 0) {
/* 5904 */         System.arraycopy(
/* 5905 */             this.astStack, (
/* 5906 */             this.astPtr -= length) + 1, 
/* 5907 */             fakeMethod.statements = new Statement[length], 
/* 5908 */             0, 
/* 5909 */             length);
/*      */       }
/*      */     } 
/*      */     
/* 5913 */     return fakeMethod;
/*      */   }
/*      */   protected void popUntilCompletedAnnotationIfNecessary() {
/* 5916 */     if (this.elementPtr < 0)
/*      */       return; 
/* 5918 */     int i = this.elementPtr;
/* 5919 */     while (i > -1 && (
/* 5920 */       this.elementKindStack[i] != 1057 || (
/* 5921 */       this.elementInfoStack[i] & 0x4) == 0)) {
/* 5922 */       i--;
/*      */     }
/*      */     
/* 5925 */     if (i >= 0) {
/* 5926 */       this.previousKind = this.elementKindStack[i];
/* 5927 */       this.previousInfo = this.elementInfoStack[i];
/* 5928 */       this.previousObjectInfo = this.elementObjectInfoStack[i];
/*      */       
/* 5930 */       for (int j = i; j <= this.elementPtr; j++) {
/* 5931 */         this.elementObjectInfoStack[j] = null;
/*      */       }
/*      */       
/* 5934 */       this.elementPtr = i - 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void prepareForBlockStatements() {
/* 5942 */     this.nestedMethod[this.nestedType = 0] = 1;
/* 5943 */     this.variablesCounter[this.nestedType] = 0;
/* 5944 */     this.realBlockStack[this.realBlockPtr = 1] = 0;
/*      */     
/* 5946 */     initializeForBlockStatements();
/*      */   }
/*      */   protected void pushOnLabelStack(char[] label) {
/* 5949 */     if (this.labelPtr < -1)
/*      */       return; 
/* 5951 */     int stackLength = this.labelStack.length;
/* 5952 */     if (++this.labelPtr >= stackLength) {
/* 5953 */       System.arraycopy(
/* 5954 */           this.labelStack, 0, 
/* 5955 */           this.labelStack = new char[stackLength + 10][], 0, 
/* 5956 */           stackLength);
/*      */     }
/* 5958 */     this.labelStack[this.labelPtr] = label;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void pushCompletionOnMemberAccessOnExpressionStack(boolean isSuperAccess) {
/* 5965 */     char[] source = this.identifierStack[this.identifierPtr];
/* 5966 */     long pos = this.identifierPositionStack[this.identifierPtr--];
/* 5967 */     CompletionOnMemberAccess fr = new CompletionOnMemberAccess(source, pos, isInsideAnnotation());
/* 5968 */     this.assistNode = (ASTNode)fr;
/* 5969 */     this.lastCheckPoint = fr.sourceEnd + 1;
/* 5970 */     this.identifierLengthPtr--;
/* 5971 */     if (isSuperAccess) {
/* 5972 */       fr.sourceStart = this.intStack[this.intPtr--];
/* 5973 */       fr.receiver = (Expression)new SuperReference(fr.sourceStart, this.endPosition);
/* 5974 */       pushOnExpressionStack((Expression)fr);
/*      */     } else {
/* 5976 */       if ((fr.receiver = this.expressionStack[this.expressionPtr]).isThis()) {
/* 5977 */         fr.sourceStart = fr.receiver.sourceStart;
/*      */       }
/* 5979 */       this.expressionStack[this.expressionPtr] = (Expression)fr;
/*      */     } 
/*      */   }
/*      */   private void recordReference(NameReference nameReference) {
/* 5983 */     if (!this.skipRecord && 
/* 5984 */       this.recordFrom <= nameReference.sourceStart && 
/* 5985 */       nameReference.sourceEnd <= this.recordTo && 
/* 5986 */       !isAlreadyPotentialName(nameReference.sourceStart)) {
/*      */       char[] token;
/* 5988 */       if (nameReference instanceof SingleNameReference) {
/* 5989 */         token = ((SingleNameReference)nameReference).token;
/*      */       } else {
/* 5991 */         token = ((QualifiedNameReference)nameReference).tokens[0];
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 5996 */       if (Character.isUpperCase(token[0]))
/*      */         return; 
/* 5998 */       addPotentialName(token, nameReference.sourceStart, nameReference.sourceEnd);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void recoveryExitFromVariable() {
/* 6003 */     if (this.currentElement != null && this.currentElement instanceof RecoveredLocalVariable) {
/* 6004 */       RecoveredElement oldElement = this.currentElement;
/* 6005 */       super.recoveryExitFromVariable();
/* 6006 */       if (oldElement != this.currentElement) {
/* 6007 */         popElement(1036);
/*      */       }
/* 6009 */     } else if (this.currentElement != null && this.currentElement instanceof RecoveredField) {
/*      */ 
/*      */ 
/*      */       
/* 6013 */       RecoveredElement oldElement = this.currentElement;
/* 6014 */       super.recoveryExitFromVariable();
/* 6015 */       if (oldElement != this.currentElement && 
/* 6016 */         topKnownElementKind(1536) == 1037) {
/* 6017 */         popElement(1037);
/* 6018 */         popElement(516);
/*      */       } 
/*      */     } else {
/*      */       
/* 6022 */       super.recoveryExitFromVariable();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void recoveryTokenCheck() {
/* 6027 */     RecoveredElement oldElement = this.currentElement;
/* 6028 */     switch (this.currentToken) {
/*      */       case 40:
/* 6030 */         if (!this.ignoreNextOpeningBrace) {
/* 6031 */           this.pendingAnnotation = null;
/*      */         }
/* 6033 */         super.recoveryTokenCheck();
/*      */         return;
/*      */       case 33:
/* 6036 */         super.recoveryTokenCheck();
/* 6037 */         if (this.currentElement != oldElement && oldElement instanceof RecoveredBlock) {
/* 6038 */           if (topKnownElementKind(1536) == 1037) {
/*      */ 
/*      */             
/* 6041 */             popElement(1037);
/*      */           } else {
/* 6043 */             popElement(1025);
/*      */           } 
/*      */         }
/*      */         return;
/*      */       case 91:
/* 6048 */         super.recoveryTokenCheck();
/* 6049 */         if (topKnownElementKind(1536) == 1025 && 
/* 6050 */           topKnownElementInfo(1536) == 5) {
/* 6051 */           pushOnElementStack(1049);
/*      */         }
/*      */         return;
/*      */       case 76:
/* 6055 */         super.recoveryTokenCheck();
/* 6056 */         if (topKnownElementKind(1536) == 1025 && 
/* 6057 */           topKnownElementInfo(1536) == 5) {
/* 6058 */           pushOnElementStack(1049, 1);
/* 6059 */         } else if (topKnownElementKind(1536) == 1049) {
/* 6060 */           popElement(1049);
/* 6061 */           pushOnElementStack(1049, 1);
/*      */         } 
/*      */         return;
/*      */     } 
/* 6065 */     super.recoveryTokenCheck();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CompletionParser createSnapShotParser() {
/* 6072 */     return new CompletionParser(this.problemReporter, this.storeSourceEnds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reset() {
/* 6080 */     super.reset();
/* 6081 */     this.cursorLocation = 0;
/* 6082 */     if (this.storeSourceEnds) {
/* 6083 */       this.sourceEnds = new HashtableOfObjectToInt();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetAfterCompletion() {
/* 6091 */     this.cursorLocation = 0;
/* 6092 */     flushAssistState();
/*      */   }
/*      */   
/*      */   public void restoreAssistParser(Object parserState) {
/* 6096 */     SavedState state = (SavedState)parserState;
/*      */     
/* 6098 */     CompletionScanner completionScanner = (CompletionScanner)this.scanner;
/*      */     
/* 6100 */     this.cursorLocation = state.parserCursorLocation;
/* 6101 */     completionScanner.cursorLocation = state.scannerCursorLocation;
/* 6102 */     this.assistNodeParent = state.assistNodeParent;
/*      */   }
/*      */   
/*      */   protected int resumeOnSyntaxError() {
/* 6106 */     if (this.monitor != null && 
/* 6107 */       ++this.resumeOnSyntaxError > 100) {
/* 6108 */       this.resumeOnSyntaxError = 0;
/* 6109 */       if (this.monitor.isCanceled()) {
/* 6110 */         return 0;
/*      */       }
/*      */     } 
/* 6113 */     return super.resumeOnSyntaxError();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int resumeAfterRecovery() {
/* 6124 */     this.hasUnusedModifiers = false;
/* 6125 */     if (this.assistNode != null) {
/*      */       
/* 6127 */       if (requireExtendedRecovery()) {
/* 6128 */         if (this.unstackedAct != 18574) {
/* 6129 */           return 2;
/*      */         }
/* 6131 */         return super.resumeAfterRecovery();
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6137 */       if (this.scanner.eofPosition >= this.cursorLocation + 1 && (
/* 6138 */         !(this.referenceContext instanceof CompilationUnitDeclaration) || 
/* 6139 */         isIndirectlyInsideFieldInitialization() || (
/* 6140 */         this.assistNodeParent instanceof FieldDeclaration && !(this.assistNodeParent instanceof Initializer))))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6167 */         if (this.currentElement instanceof RecoveredType || 
/* 6168 */           this.currentElement.enclosingType() != null) {
/*      */           
/* 6170 */           this.pendingAnnotation = null;
/*      */           
/* 6172 */           if (this.lastCheckPoint <= this.assistNode.sourceEnd) {
/* 6173 */             this.lastCheckPoint = this.assistNode.sourceEnd + 1;
/*      */           }
/* 6175 */           int end = this.currentElement.topElement().sourceEnd();
/* 6176 */           this.scanner.eofPosition = (end < Integer.MAX_VALUE) ? (end + 1) : end;
/*      */         } else {
/* 6178 */           resetStacks();
/* 6179 */           return 0;
/*      */         } 
/*      */       }
/*      */     } 
/* 6183 */     return super.resumeAfterRecovery();
/*      */   }
/*      */   
/*      */   public void setAssistIdentifier(char[] assistIdent) {
/* 6187 */     ((CompletionScanner)this.scanner).completionIdentifier = assistIdent;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void shouldStackAssistNode() {
/* 6192 */     this.shouldStackAssistNode = true;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean assistNodeNeedsStacking() {
/* 6197 */     return this.shouldStackAssistNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 6202 */     StringBuffer buffer = new StringBuffer();
/* 6203 */     buffer.append("elementKindStack : int[] = {"); int i;
/* 6204 */     for (i = 0; i <= this.elementPtr; i++) {
/* 6205 */       buffer.append(String.valueOf(this.elementKindStack[i])).append(',');
/*      */     }
/* 6207 */     buffer.append("}\n");
/* 6208 */     buffer.append("elementInfoStack : int[] = {");
/* 6209 */     for (i = 0; i <= this.elementPtr; i++) {
/* 6210 */       buffer.append(String.valueOf(this.elementInfoStack[i])).append(',');
/*      */     }
/* 6212 */     buffer.append("}\n");
/* 6213 */     buffer.append(super.toString());
/* 6214 */     return String.valueOf(buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateRecoveryState() {
/* 6224 */     this.currentElement.updateFromParserState();
/*      */ 
/*      */     
/* 6227 */     AssistParser parser = null;
/* 6228 */     if (lastIndexOfElement(519) >= 0) {
/* 6229 */       parser = createSnapShotParser();
/* 6230 */       parser.copyState((Parser)this);
/*      */     } 
/*      */ 
/*      */     
/* 6234 */     completionIdentifierCheck();
/* 6235 */     attachOrphanCompletionNode();
/* 6236 */     if (parser != null) {
/* 6237 */       copyState((Parser)parser);
/*      */     }
/*      */ 
/*      */     
/* 6241 */     if (this.assistNode != null && this.currentElement != null) {
/* 6242 */       this.currentElement.preserveEnclosingBlocks();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6249 */     recoveryTokenCheck();
/*      */     
/* 6251 */     recoveryExitFromVariable();
/*      */   }
/*      */   
/*      */   protected CompilationUnitDeclaration endParse(int act) {
/* 6255 */     CompilationUnitDeclaration cud = super.endParse(act);
/*      */ 
/*      */     
/* 6258 */     ASTNode topNode = (this.astPtr > -1) ? this.astStack[this.astPtr] : (
/* 6259 */       (this.referenceContext instanceof ASTNode) ? (ASTNode)this.referenceContext : 
/* 6260 */       null);
/* 6261 */     if (topNode != null) {
/* 6262 */       if (this.referenceContext instanceof AbstractMethodDeclaration) {
/* 6263 */         Statement statement = null;
/* 6264 */         if (topNode instanceof Statement) {
/* 6265 */           statement = (Statement)topNode;
/* 6266 */         } else if (this.assistNodeParent instanceof Statement) {
/* 6267 */           statement = (Statement)this.assistNodeParent;
/* 6268 */         } else if (this.assistNode instanceof Statement) {
/* 6269 */           statement = (Statement)this.assistNode;
/*      */         } 
/* 6271 */         AbstractMethodDeclaration method = (AbstractMethodDeclaration)this.referenceContext;
/* 6272 */         if (statement != null && isInsideBody(statement, method) && 
/* 6273 */           this.assistNode != null && !CompletionNodeDetector.findAny(cud, this.assistNode))
/*      */         {
/*      */           
/* 6276 */           if (method.statements == null) {
/* 6277 */             method.statements = new Statement[] { statement };
/* 6278 */           } else if (this.currentElement != null) {
/*      */             
/* 6280 */             this.currentElement.add(statement, 0);
/* 6281 */             RecoveredElement element = this.currentElement;
/* 6282 */             while (element != null) {
/* 6283 */               if (element instanceof RecoveredMethod && ((RecoveredMethod)element).methodDeclaration == method) {
/* 6284 */                 element.updateParseTree();
/*      */                 break;
/*      */               } 
/* 6287 */               element = element.parent;
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/* 6292 */       if (this.assistNode != null && 
/* 6293 */         !(this.assistNode instanceof CompletionOnKeyword) && (
/* 6294 */         this.assistNodeParent == null || this.enclosingNode == null)) {
/*      */         
/* 6296 */         CompletionNodeDetector detector = new CompletionNodeDetector(this.assistNode, topNode);
/* 6297 */         if (detector.containsCompletionNode()) {
/* 6298 */           if (this.assistNodeParent == null)
/* 6299 */             this.assistNodeParent = detector.getCompletionNodeParent(); 
/* 6300 */           if (this.enclosingNode == null)
/* 6301 */             this.enclosingNode = detector.getCompletionEnclosingNode(); 
/*      */         } 
/*      */       } 
/*      */     } 
/* 6305 */     return cud;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isInsideBody(Statement statement, AbstractMethodDeclaration method) {
/* 6311 */     if (statement.sourceStart < method.bodyStart) {
/* 6312 */       return false;
/*      */     }
/* 6314 */     this.scanner.resetTo(method.sourceEnd, statement.sourceStart);
/*      */     try {
/*      */       int tkn;
/* 6317 */       while ((tkn = this.scanner.getNextToken()) != 64) {
/* 6318 */         if (tkn == 40)
/* 6319 */           return true; 
/*      */       } 
/* 6321 */     } catch (InvalidInputException invalidInputException) {
/* 6322 */       return true;
/*      */     } 
/* 6324 */     return false;
/*      */   }
/*      */   
/*      */   protected LocalDeclaration createLocalDeclaration(char[] assistName, int sourceStart, int sourceEnd) {
/* 6328 */     if (indexOfAssistIdentifier() < 0) {
/* 6329 */       return super.createLocalDeclaration(assistName, sourceStart, sourceEnd);
/*      */     }
/* 6331 */     CompletionOnLocalName local = new CompletionOnLocalName(assistName, sourceStart, sourceEnd);
/* 6332 */     this.assistNode = (ASTNode)local;
/* 6333 */     this.lastCheckPoint = sourceEnd + 1;
/* 6334 */     return local;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavadocParser createJavadocParser() {
/* 6340 */     return new CompletionJavadocParser(this);
/*      */   }
/*      */ 
/*      */   
/*      */   protected FieldDeclaration createFieldDeclaration(char[] assistName, int sourceStart, int sourceEnd) {
/* 6345 */     if (indexOfAssistIdentifier() < 0 || (this.currentElement instanceof RecoveredUnit && ((RecoveredUnit)this.currentElement).typeCount == 0)) {
/* 6346 */       return super.createFieldDeclaration(assistName, sourceStart, sourceEnd);
/*      */     }
/* 6348 */     CompletionOnFieldName field = new CompletionOnFieldName(assistName, sourceStart, sourceEnd);
/* 6349 */     this.assistNode = (ASTNode)field;
/* 6350 */     this.lastCheckPoint = sourceEnd + 1;
/* 6351 */     return field;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RecordComponent createComponent(char[] identifierName, long namePositions, TypeReference type, int modifier, int declStart) {
/* 6358 */     int endPos = (int)namePositions;
/* 6359 */     if (this.cursorLocation > declStart && this.cursorLocation <= endPos) {
/* 6360 */       return new CompletionOnRecordComponentName(identifierName, namePositions, type, modifier);
/*      */     }
/* 6362 */     return super.createComponent(identifierName, namePositions, type, modifier, declStart);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean stackHasInstanceOfExpression(Object[] stackToSearch, int startIndex) {
/* 6370 */     int indexInstanceOf = startIndex;
/* 6371 */     while (indexInstanceOf >= 0) {
/* 6372 */       if (stackToSearch[indexInstanceOf] instanceof InstanceOfExpression) {
/* 6373 */         return true;
/*      */       }
/* 6375 */       indexInstanceOf--;
/*      */     } 
/* 6377 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isInsideArrayInitializer() {
/* 6383 */     int i = this.elementPtr;
/* 6384 */     if (i > -1 && this.elementKindStack[i] == 1037) {
/* 6385 */       return true;
/*      */     }
/* 6387 */     return false;
/*      */   }
/*      */   private boolean foundToken(int token) {
/* 6390 */     int i = this.elementPtr;
/* 6391 */     while (i > -1) {
/* 6392 */       if (this.elementKindStack[i] == token) {
/* 6393 */         return true;
/*      */       }
/* 6395 */       i--;
/*      */     } 
/* 6397 */     return false;
/*      */   }
/*      */   
/*      */   protected int actFromTokenOrSynthetic(int previousAct) {
/* 6401 */     int newAct = tAction(previousAct, this.currentToken);
/* 6402 */     if (this.hasError && !this.diet && newAct == 18574 && this.scanner.currentPosition > this.cursorLocation && 
/* 6403 */       requireExtendedRecovery()) {
/*      */       byte b; int i; int[] arrayOfInt;
/* 6405 */       for (i = (arrayOfInt = RECOVERY_TOKENS).length, b = 0; b < i; ) { int tok = arrayOfInt[b];
/* 6406 */         newAct = tAction(previousAct, tok);
/* 6407 */         if (newAct != 18574) {
/* 6408 */           this.currentToken = tok;
/* 6409 */           return newAct;
/*      */         } 
/*      */         b++; }
/*      */       
/* 6413 */       this.currentToken = 64;
/* 6414 */       return tAction(previousAct, this.currentToken);
/*      */     } 
/*      */     
/* 6417 */     return newAct;
/*      */   }
/*      */   
/*      */   protected boolean isInImportStatement() {
/* 6421 */     return foundToken(1067);
/*      */   }
/*      */   protected boolean isInExportsStatement() {
/* 6424 */     return foundToken(1068);
/*      */   }
/*      */   protected boolean isInOpensStatement() {
/* 6427 */     return foundToken(1075);
/*      */   }
/*      */   protected boolean isInRequiresStatement() {
/* 6430 */     return foundToken(1069);
/*      */   }
/*      */   protected boolean isInUsesStatement() {
/* 6433 */     return foundToken(1070);
/*      */   }
/*      */   protected boolean isInProvidesStatement() {
/* 6436 */     return foundToken(1071);
/*      */   }
/*      */   protected boolean isAfterWithClause() {
/* 6439 */     return foundToken(1074);
/*      */   }
/*      */   protected boolean isInModuleStatements() {
/* 6442 */     return !(!isInExportsStatement() && 
/* 6443 */       !isInOpensStatement() && 
/* 6444 */       !isInRequiresStatement() && 
/* 6445 */       !isInProvidesStatement() && 
/* 6446 */       !isInUsesStatement());
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */