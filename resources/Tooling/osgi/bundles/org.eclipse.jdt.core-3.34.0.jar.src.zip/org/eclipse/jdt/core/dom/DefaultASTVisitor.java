/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultASTVisitor
/*     */   extends ASTVisitor
/*     */ {
/*     */   public DefaultASTVisitor() {}
/*     */   
/*     */   public DefaultASTVisitor(boolean visitDocTags) {
/*  28 */     super(visitDocTags);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endVisit(AnnotationTypeDeclaration node) {
/*  33 */     endVisitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endVisit(AnnotationTypeMemberDeclaration node) {
/*  38 */     endVisitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endVisit(AnonymousClassDeclaration node) {
/*  43 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ArrayAccess node) {
/*  47 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ArrayCreation node) {
/*  51 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ArrayInitializer node) {
/*  55 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ArrayType node) {
/*  59 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(AssertStatement node) {
/*  63 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(Assignment node) {
/*  67 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(Block node) {
/*  71 */     endVisitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endVisit(BlockComment node) {
/*  76 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(BooleanLiteral node) {
/*  80 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(BreakStatement node) {
/*  84 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(CaseDefaultExpression node) {
/*  88 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(CastExpression node) {
/*  92 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(CatchClause node) {
/*  96 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(CharacterLiteral node) {
/* 100 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ClassInstanceCreation node) {
/* 104 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(CompilationUnit node) {
/* 108 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ConditionalExpression node) {
/* 112 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ConstructorInvocation node) {
/* 116 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ContinueStatement node) {
/* 120 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(CreationReference node) {
/* 124 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(Dimension node) {
/* 128 */     endVisitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endVisit(DoStatement node) {
/* 133 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(EmptyStatement node) {
/* 137 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(EnhancedForStatement node) {
/* 141 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(EnumConstantDeclaration node) {
/* 145 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(EnumDeclaration node) {
/* 149 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ExpressionMethodReference node) {
/* 153 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ExpressionStatement node) {
/* 157 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(FieldAccess node) {
/* 161 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(FieldDeclaration node) {
/* 165 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ForStatement node) {
/* 169 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(GuardedPattern node) {
/* 173 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(IfStatement node) {
/* 177 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ImportDeclaration node) {
/* 181 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(InfixExpression node) {
/* 185 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(Initializer node) {
/* 189 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(InstanceofExpression node) {
/* 193 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(IntersectionType node) {
/* 197 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(Javadoc node) {
/* 201 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(JavaDocRegion node) {
/* 205 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(JavaDocTextElement node) {
/* 209 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(LabeledStatement node) {
/* 213 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(LambdaExpression node) {
/* 217 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(LineComment node) {
/* 221 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(MarkerAnnotation node) {
/* 225 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(MemberRef node) {
/* 229 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(MemberValuePair node) {
/* 233 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(MethodDeclaration node) {
/* 237 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(MethodInvocation node) {
/* 241 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(MethodRef node) {
/* 245 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(MethodRefParameter node) {
/* 249 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(Modifier node) {
/* 253 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ModuleDeclaration node) {
/* 257 */     endVisitNode(node);
/*     */   }
/*     */   public void endVisit(ModuleDirective node) {
/* 260 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ModuleQualifiedName node) {
/* 264 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(NameQualifiedType node) {
/* 268 */     endVisitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endVisit(NormalAnnotation node) {
/* 273 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(NullLiteral node) {
/* 277 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(NullPattern node) {
/* 281 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(NumberLiteral node) {
/* 285 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(PackageDeclaration node) {
/* 289 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ParameterizedType node) {
/* 293 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ParenthesizedExpression node) {
/* 297 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(PatternInstanceofExpression node) {
/* 301 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(PostfixExpression node) {
/* 305 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(PrefixExpression node) {
/* 309 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(PrimitiveType node) {
/* 313 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(QualifiedName node) {
/* 317 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(QualifiedType node) {
/* 321 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(RecordDeclaration node) {
/* 325 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(RecordPattern node) {
/* 329 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ReturnStatement node) {
/* 333 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(SimpleName node) {
/* 337 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(SimpleType node) {
/* 341 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(SingleMemberAnnotation node) {
/* 345 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(SingleVariableDeclaration node) {
/* 349 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(StringLiteral node) {
/* 353 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(SuperConstructorInvocation node) {
/* 357 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(SuperFieldAccess node) {
/* 361 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(SuperMethodInvocation node) {
/* 365 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(SuperMethodReference node) {
/* 369 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(SwitchExpression node) {
/* 373 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(SwitchCase node) {
/* 377 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(SwitchStatement node) {
/* 381 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(SynchronizedStatement node) {
/* 385 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(TagElement node) {
/* 389 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(TagProperty node) {
/* 393 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(TextBlock node) {
/* 397 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(TextElement node) {
/* 401 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ThisExpression node) {
/* 405 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(ThrowStatement node) {
/* 409 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(TryStatement node) {
/* 413 */     endVisitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public void endVisit(TypeDeclaration node) {
/* 418 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(TypeDeclarationStatement node) {
/* 422 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(TypeLiteral node) {
/* 426 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(TypeMethodReference node) {
/* 430 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(TypeParameter node) {
/* 434 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(TypePattern node) {
/* 438 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(UnionType node) {
/* 442 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(VariableDeclarationExpression node) {
/* 446 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(VariableDeclarationFragment node) {
/* 450 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(VariableDeclarationStatement node) {
/* 454 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(WhileStatement node) {
/* 458 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(WildcardType node) {
/* 462 */     endVisitNode(node);
/*     */   }
/*     */   
/*     */   public void endVisit(YieldStatement node) {
/* 466 */     endVisitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void endVisitNode(ASTNode node) {}
/*     */   
/*     */   public boolean visit(AnnotationTypeDeclaration node) {
/* 473 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(AnnotationTypeMemberDeclaration node) {
/* 477 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(AnonymousClassDeclaration node) {
/* 481 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ArrayAccess node) {
/* 485 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ArrayCreation node) {
/* 489 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ArrayInitializer node) {
/* 493 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ArrayType node) {
/* 497 */     visitNode(node);
/* 498 */     return false;
/*     */   }
/*     */   
/*     */   public boolean visit(AssertStatement node) {
/* 502 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(Assignment node) {
/* 506 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(Block node) {
/* 510 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(BlockComment node) {
/* 515 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(BooleanLiteral node) {
/* 519 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(BreakStatement node) {
/* 523 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(CaseDefaultExpression node) {
/* 527 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(CastExpression node) {
/* 531 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(CatchClause node) {
/* 535 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(CharacterLiteral node) {
/* 539 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ClassInstanceCreation node) {
/* 543 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(CompilationUnit node) {
/* 547 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ConditionalExpression node) {
/* 551 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ConstructorInvocation node) {
/* 555 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ContinueStatement node) {
/* 559 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(CreationReference node) {
/* 563 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(Dimension node) {
/* 567 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(DoStatement node) {
/* 572 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(EmptyStatement node) {
/* 576 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(EnhancedForStatement node) {
/* 580 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(EnumConstantDeclaration node) {
/* 584 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(EnumDeclaration node) {
/* 588 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ExpressionMethodReference node) {
/* 592 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ExpressionStatement node) {
/* 596 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(FieldAccess node) {
/* 600 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(FieldDeclaration node) {
/* 604 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ForStatement node) {
/* 608 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(GuardedPattern node) {
/* 612 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(IfStatement node) {
/* 616 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ImportDeclaration node) {
/* 620 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(InfixExpression node) {
/* 624 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(Initializer node) {
/* 628 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(InstanceofExpression node) {
/* 632 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(IntersectionType node) {
/* 636 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(Javadoc node) {
/* 641 */     if (super.visit(node)) {
/* 642 */       return visitNode(node);
/*     */     }
/* 644 */     return false;
/*     */   }
/*     */   
/*     */   public boolean visit(JavaDocRegion node) {
/* 648 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(JavaDocTextElement node) {
/* 652 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(LabeledStatement node) {
/* 656 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(LambdaExpression node) {
/* 660 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(LineComment node) {
/* 664 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(MarkerAnnotation node) {
/* 668 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(MemberRef node) {
/* 672 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(MemberValuePair node) {
/* 676 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(MethodDeclaration node) {
/* 680 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(MethodInvocation node) {
/* 684 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(MethodRef node) {
/* 688 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(Modifier node) {
/* 692 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ModuleDeclaration node) {
/* 696 */     return visitNode(node);
/*     */   }
/*     */   public boolean visit(ModuleDirective node) {
/* 699 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ModuleQualifiedName node) {
/* 703 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(MethodRefParameter node) {
/* 707 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(NameQualifiedType node) {
/* 711 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(NormalAnnotation node) {
/* 716 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(NullLiteral node) {
/* 720 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(NullPattern node) {
/* 724 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(NumberLiteral node) {
/* 728 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(PackageDeclaration node) {
/* 732 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ParameterizedType node) {
/* 736 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ParenthesizedExpression node) {
/* 740 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(PatternInstanceofExpression node) {
/* 744 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(PostfixExpression node) {
/* 748 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(PrefixExpression node) {
/* 752 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(PrimitiveType node) {
/* 757 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(QualifiedName node) {
/* 761 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(QualifiedType node) {
/* 765 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(RecordDeclaration node) {
/* 769 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(RecordPattern node) {
/* 773 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(ReturnStatement node) {
/* 777 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(SimpleName node) {
/* 781 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(SimpleType node) {
/* 785 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(SingleMemberAnnotation node) {
/* 789 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   public boolean visit(SingleVariableDeclaration node) {
/* 793 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(StringLiteral node) {
/* 798 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(SuperConstructorInvocation node) {
/* 803 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(SuperFieldAccess node) {
/* 808 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(SuperMethodInvocation node) {
/* 813 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(SuperMethodReference node) {
/* 818 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(SwitchCase node) {
/* 823 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(SwitchExpression node) {
/* 828 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(SwitchStatement node) {
/* 833 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(SynchronizedStatement node) {
/* 838 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(TagElement node) {
/* 843 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(TagProperty node) {
/* 848 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(TextBlock node) {
/* 853 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(TextElement node) {
/* 858 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(ThisExpression node) {
/* 863 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(ThrowStatement node) {
/* 868 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(TryStatement node) {
/* 873 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(TypeDeclaration node) {
/* 878 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(TypeDeclarationStatement node) {
/* 883 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(TypeLiteral node) {
/* 888 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(TypeMethodReference node) {
/* 893 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(TypeParameter node) {
/* 898 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(TypePattern node) {
/* 903 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(UnionType node) {
/* 908 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(VariableDeclarationExpression node) {
/* 913 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(VariableDeclarationFragment node) {
/* 918 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(VariableDeclarationStatement node) {
/* 923 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(WhileStatement node) {
/* 928 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(WildcardType node) {
/* 933 */     return visitNode(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(YieldStatement node) {
/* 938 */     return visitNode(node);
/*     */   }
/*     */   
/*     */   protected boolean visitNode(ASTNode node) {
/* 942 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\DefaultASTVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */