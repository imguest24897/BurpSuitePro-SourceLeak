/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*    */ import org.eclipse.jdt.internal.compiler.ast.MethodDeclaration;
/*    */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnMethodReturnType
/*    */   extends MethodDeclaration
/*    */ {
/*    */   public CompletionOnMethodReturnType(TypeReference returnType, CompilationResult compilationResult) {
/* 22 */     super(compilationResult);
/* 23 */     this.returnType = returnType;
/* 24 */     this.sourceStart = returnType.sourceStart;
/* 25 */     this.sourceEnd = returnType.sourceEnd;
/*    */   }
/*    */ 
/*    */   
/*    */   public void resolveStatements() {
/* 30 */     throw new CompletionNodeFound(this, this.scope);
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer print(int tab, StringBuffer output) {
/* 35 */     return this.returnType.print(tab, output);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnMethodReturnType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */