/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.ModuleReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnKeywordModule2
/*    */   extends ModuleReference
/*    */   implements CompletionOnKeyword
/*    */ {
/*    */   private char[] token;
/*    */   private char[][] possibleKeywords;
/*    */   
/*    */   public CompletionOnKeywordModule2(char[] token, long pos, char[][] possibleKeywords) {
/* 24 */     super(new char[][] { token }, new long[] { pos });
/* 25 */     this.token = token;
/* 26 */     this.possibleKeywords = possibleKeywords;
/* 27 */     this.sourceStart = (int)(pos >>> 32L);
/* 28 */     this.sourceEnd = (int)(pos & 0xFFFFFFFFL);
/*    */   }
/*    */ 
/*    */   
/*    */   public char[] getToken() {
/* 33 */     return this.token;
/*    */   }
/*    */ 
/*    */   
/*    */   public char[][] getPossibleKeywords() {
/* 38 */     return this.possibleKeywords;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnKeywordModule2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */