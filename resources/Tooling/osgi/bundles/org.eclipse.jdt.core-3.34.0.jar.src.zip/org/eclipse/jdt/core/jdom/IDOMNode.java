package org.eclipse.jdt.core.jdom;

import java.util.Enumeration;
import org.eclipse.jdt.core.IJavaElement;

public interface IDOMNode extends Cloneable {
  public static final int COMPILATION_UNIT = 1;
  
  public static final int PACKAGE = 2;
  
  public static final int IMPORT = 3;
  
  public static final int TYPE = 4;
  
  public static final int FIELD = 5;
  
  public static final int METHOD = 6;
  
  public static final int INITIALIZER = 7;
  
  void addChild(IDOMNode paramIDOMNode) throws DOMException, IllegalArgumentException;
  
  boolean canHaveChildren();
  
  Object clone();
  
  char[] getCharacters();
  
  IDOMNode getChild(String paramString);
  
  Enumeration getChildren();
  
  String getContents();
  
  IDOMNode getFirstChild();
  
  IJavaElement getJavaElement(IJavaElement paramIJavaElement) throws IllegalArgumentException;
  
  String getName();
  
  IDOMNode getNextNode();
  
  int getNodeType();
  
  IDOMNode getParent();
  
  IDOMNode getPreviousNode();
  
  void insertSibling(IDOMNode paramIDOMNode) throws DOMException, IllegalArgumentException;
  
  boolean isAllowableChild(IDOMNode paramIDOMNode);
  
  boolean isSignatureEqual(IDOMNode paramIDOMNode);
  
  void remove();
  
  void setName(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\jdom\IDOMNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */