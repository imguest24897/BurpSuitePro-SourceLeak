/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*    */ import org.eclipse.jdt.internal.compiler.ast.MethodDeclaration;
/*    */ import org.eclipse.jdt.internal.compiler.ast.TypeParameter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnMethodTypeParameter
/*    */   extends MethodDeclaration
/*    */ {
/*    */   public CompletionOnMethodTypeParameter(TypeParameter[] typeParameters, CompilationResult compilationResult) {
/* 23 */     super(compilationResult);
/* 24 */     this.selector = CharOperation.NO_CHAR;
/* 25 */     this.typeParameters = typeParameters;
/* 26 */     this.sourceStart = (typeParameters[0]).sourceStart;
/* 27 */     this.sourceEnd = (typeParameters[typeParameters.length - 1]).sourceEnd;
/*    */   }
/*    */ 
/*    */   
/*    */   public void resolveStatements() {
/* 32 */     throw new CompletionNodeFound(this, this.scope);
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer print(int tab, StringBuffer output) {
/* 37 */     printIndent(tab, output);
/* 38 */     output.append('<');
/* 39 */     int max = this.typeParameters.length - 1;
/* 40 */     for (int j = 0; j < max; j++) {
/* 41 */       this.typeParameters[j].print(0, output);
/* 42 */       output.append(", ");
/*    */     } 
/* 44 */     this.typeParameters[max].print(0, output);
/* 45 */     output.append('>');
/* 46 */     return output;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnMethodTypeParameter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */