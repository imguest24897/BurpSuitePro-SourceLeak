/*    */ package org.eclipse.jdt.internal.codeassist.impl;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.jdt.core.JavaModelException;
/*    */ import org.eclipse.jdt.internal.core.Annotation;
/*    */ import org.eclipse.jdt.internal.core.JavaElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AssistAnnotation
/*    */   extends Annotation
/*    */ {
/*    */   private Map infoCache;
/*    */   
/*    */   public AssistAnnotation(JavaElement parent, String name, Map infoCache) {
/* 27 */     super(parent, name);
/* 28 */     this.infoCache = infoCache;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getElementInfo(IProgressMonitor monitor) throws JavaModelException {
/* 33 */     return this.infoCache.get(this);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\impl\AssistAnnotation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */