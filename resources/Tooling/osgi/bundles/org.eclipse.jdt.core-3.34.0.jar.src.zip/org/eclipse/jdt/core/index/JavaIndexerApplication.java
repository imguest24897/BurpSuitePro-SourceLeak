/*     */ package org.eclipse.jdt.core.index;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import org.eclipse.equinox.app.IApplication;
/*     */ import org.eclipse.equinox.app.IApplicationContext;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaIndexerApplication
/*     */   implements IApplication
/*     */ {
/*     */   private String jarToIndex;
/*     */   private String indexFile;
/*     */   
/*     */   private static final class Messages
/*     */     extends NLS
/*     */   {
/*     */     private static final String MESSAGES_NAME = "org.eclipse.jdt.core.index.messages";
/*     */     public static String CommandLineProcessing;
/*     */     public static String CommandLineUsage;
/*     */     public static String CommandLineOnlyOneOutputError;
/*     */     public static String CommandLineOutputTakesArgs;
/*     */     public static String CommandLineOnlyOneJarError;
/*     */     public static String CommandLineJarNotSpecified;
/*     */     public static String CommandLineIndexFileNotSpecified;
/*     */     public static String CaughtException;
/*     */     public static String CommandLineJarFileNotExist;
/*     */     
/*     */     static {
/*  56 */       NLS.initializeMessages("org.eclipse.jdt.core.index.messages", Messages.class);
/*     */     }
/*     */     
/*     */     public static String bind(String message) {
/*  60 */       return bind(message, (Object[])null);
/*     */     }
/*     */     
/*     */     public static String bind(String message, Object binding) {
/*  64 */       return bind(message, new Object[] { binding });
/*     */     }
/*     */     
/*     */     public static String bind(String message, Object binding1, Object binding2) {
/*  68 */       return bind(message, new Object[] { binding1, binding2 });
/*     */     }
/*     */     
/*     */     public static String bind(String message, Object[] bindings) {
/*  72 */       return MessageFormat.format(message, bindings);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean verbose = false;
/*     */   
/*     */   private static final String PDE_LAUNCH = "-pdelaunch";
/*     */   
/*     */   private static final String ARG_HELP = "-help";
/*     */   private static final String ARG_VERBOSE = "-verbose";
/*     */   private static final String ARG_OUTPUT = "-output";
/*     */   
/*     */   private void displayHelp() {
/*  85 */     System.out.println(Messages.bind(Messages.CommandLineUsage));
/*     */   }
/*     */   
/*     */   private void displayError(String message) {
/*  89 */     System.out.println(message);
/*  90 */     System.out.println();
/*  91 */     displayHelp();
/*     */   }
/*     */   
/*     */   private boolean processCommandLine(String[] argsArray) {
/*  95 */     ArrayList<String> args = new ArrayList();
/*  96 */     for (int i = 0, max = argsArray.length; i < max; i++) {
/*  97 */       args.add(argsArray[i]);
/*     */     }
/*  99 */     int index = 0;
/* 100 */     int argCount = argsArray.length;
/*     */     
/* 102 */     while (index < argCount) {
/* 103 */       String currentArg = argsArray[index++];
/* 104 */       if ("-pdelaunch".equals(currentArg))
/*     */         continue; 
/* 106 */       if ("-help".equals(currentArg)) {
/* 107 */         displayHelp();
/* 108 */         return false;
/* 109 */       }  if ("-verbose".equals(currentArg)) {
/* 110 */         this.verbose = true; continue;
/*     */       } 
/* 112 */       if ("-output".equals(currentArg)) {
/* 113 */         if (this.indexFile != null) {
/* 114 */           displayError(Messages.bind(Messages.CommandLineOnlyOneOutputError));
/* 115 */           return false;
/* 116 */         }  if (index == argCount) {
/* 117 */           displayError(Messages.bind(Messages.CommandLineOutputTakesArgs));
/* 118 */           return false;
/*     */         } 
/* 120 */         this.indexFile = argsArray[index++]; continue;
/*     */       } 
/* 122 */       if (this.jarToIndex != null) {
/* 123 */         displayError(Messages.bind(Messages.CommandLineOnlyOneJarError));
/* 124 */         return false;
/*     */       } 
/* 126 */       this.jarToIndex = currentArg;
/*     */     } 
/*     */     
/* 129 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object start(IApplicationContext context) throws Exception {
/* 134 */     boolean execute = processCommandLine((String[])context.getArguments().get("application.args"));
/* 135 */     if (execute) {
/* 136 */       if (this.jarToIndex != null && this.indexFile != null) {
/* 137 */         File f = new File(this.jarToIndex);
/* 138 */         if (f.exists()) {
/* 139 */           if (this.verbose) {
/* 140 */             System.out.println(Messages.bind(Messages.CommandLineProcessing, this.indexFile, this.jarToIndex));
/*     */           }
/*     */           try {
/* 143 */             JavaIndexer.generateIndexForJar(this.jarToIndex, this.indexFile);
/* 144 */           } catch (IOException e) {
/* 145 */             System.out.println(Messages.bind(Messages.CaughtException, "IOException", e.getLocalizedMessage()));
/*     */           } 
/*     */         } else {
/* 148 */           System.out.println(Messages.bind(Messages.CommandLineJarFileNotExist, this.jarToIndex));
/*     */         } 
/* 150 */       } else if (this.jarToIndex == null) {
/* 151 */         System.out.println(Messages.bind(Messages.CommandLineJarNotSpecified));
/* 152 */       } else if (this.indexFile == null) {
/* 153 */         System.out.println(Messages.bind(Messages.CommandLineIndexFileNotSpecified));
/*     */       } 
/*     */     }
/* 156 */     return IApplication.EXIT_OK;
/*     */   }
/*     */   
/*     */   public void stop() {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\index\JavaIndexerApplication.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */