/*      */ package org.eclipse.jdt.core.dom;
/*      */ 
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import org.eclipse.jdt.core.WorkingCopyOwner;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*      */ import org.eclipse.jdt.internal.compiler.ast.AbstractMethodDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.AbstractVariableDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.AllocationExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Annotation;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ArrayAllocationExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.CompilationUnitDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ExplicitConstructorCall;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.FieldDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.FieldReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ImportReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Initializer;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocAllocationExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocFieldReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocImplicitTypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocMessageSend;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocModuleReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocQualifiedTypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocSingleNameReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocSingleTypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.LambdaExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Literal;
/*      */ import org.eclipse.jdt.internal.compiler.ast.LocalDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.MemberValuePair;
/*      */ import org.eclipse.jdt.internal.compiler.ast.MessageSend;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ModuleDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ModuleReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ParameterizedQualifiedTypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.QualifiedNameReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.QualifiedSuperReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.QualifiedTypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Receiver;
/*      */ import org.eclipse.jdt.internal.compiler.ast.RecordComponent;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ReferenceExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.SingleNameReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.SingleTypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ThisReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeParameter;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.CompilationUnitScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ElementValuePair;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedGenericMethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ProblemFieldBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ProblemMethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.RecordComponentBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.SyntheticArgumentBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilation;
/*      */ import org.eclipse.jdt.internal.core.util.Util;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class DefaultBindingResolver
/*      */   extends BindingResolver
/*      */ {
/*      */   Map astNodesToBlockScope;
/*      */   Map bindingsToAstNodes;
/*      */   BindingTables bindingTables;
/*      */   Map newAstToOldAst;
/*      */   private CompilationUnitScope scope;
/*      */   WorkingCopyOwner workingCopyOwner;
/*      */   boolean isRecoveringBindings;
/*      */   boolean fromJavaProject;
/*      */   
/*      */   static class BindingTables
/*      */   {
/*  122 */     Map compilerBindingsToASTBindings = new ConcurrentHashMap<>();
/*  123 */     Map compilerAnnotationBindingsToASTBindings = new ConcurrentHashMap<>();
/*  124 */     Map bindingKeysToBindings = new ConcurrentHashMap<>();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   DefaultBindingResolver(CompilationUnitScope scope, WorkingCopyOwner workingCopyOwner, BindingTables bindingTables, boolean isRecoveringBindings, boolean fromJavaProject) {
/*  176 */     this.newAstToOldAst = new HashMap<>();
/*  177 */     this.astNodesToBlockScope = new HashMap<>();
/*  178 */     this.bindingsToAstNodes = new HashMap<>();
/*  179 */     this.bindingTables = bindingTables;
/*  180 */     this.scope = scope;
/*  181 */     this.workingCopyOwner = workingCopyOwner;
/*  182 */     this.isRecoveringBindings = isRecoveringBindings;
/*  183 */     this.fromJavaProject = fromJavaProject;
/*      */   }
/*      */   
/*      */   DefaultBindingResolver(LookupEnvironment lookupEnvironment, WorkingCopyOwner workingCopyOwner, BindingTables bindingTables, boolean isRecoveringBindings, boolean fromJavaProject) {
/*  187 */     this.newAstToOldAst = new HashMap<>();
/*  188 */     this.astNodesToBlockScope = new HashMap<>();
/*  189 */     this.bindingsToAstNodes = new HashMap<>();
/*  190 */     this.bindingTables = bindingTables;
/*  191 */     this.scope = new CompilationUnitScope(new CompilationUnitDeclaration(null, null, -1), lookupEnvironment);
/*  192 */     this.workingCopyOwner = workingCopyOwner;
/*  193 */     this.isRecoveringBindings = isRecoveringBindings;
/*  194 */     this.fromJavaProject = fromJavaProject;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized ASTNode findDeclaringNode(IBinding binding) {
/*  199 */     if (binding == null) {
/*  200 */       return null;
/*      */     }
/*  202 */     if (binding instanceof IMethodBinding) {
/*  203 */       IMethodBinding methodBinding = (IMethodBinding)binding;
/*  204 */       return (ASTNode)this.bindingsToAstNodes.get(methodBinding.getMethodDeclaration());
/*  205 */     }  if (binding instanceof ITypeBinding) {
/*  206 */       ITypeBinding typeBinding = (ITypeBinding)binding;
/*  207 */       return (ASTNode)this.bindingsToAstNodes.get(typeBinding.getTypeDeclaration());
/*  208 */     }  if (binding instanceof IVariableBinding) {
/*  209 */       IVariableBinding variableBinding = (IVariableBinding)binding;
/*  210 */       return (ASTNode)this.bindingsToAstNodes.get(variableBinding.getVariableDeclaration());
/*      */     } 
/*  212 */     return (ASTNode)this.bindingsToAstNodes.get(binding);
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized ASTNode findDeclaringNode(String bindingKey) {
/*  217 */     if (bindingKey == null) {
/*  218 */       return null;
/*      */     }
/*  220 */     Object binding = this.bindingTables.bindingKeysToBindings.get(bindingKey);
/*  221 */     if (binding == null)
/*  222 */       return null; 
/*  223 */     return (ASTNode)this.bindingsToAstNodes.get(binding);
/*      */   }
/*      */   
/*      */   IBinding getBinding(Binding binding) {
/*  227 */     switch (binding.kind()) {
/*      */       case 16:
/*  229 */         return getPackageBinding((PackageBinding)binding);
/*      */       case 4:
/*      */       case 132:
/*      */       case 260:
/*      */       case 1028:
/*      */       case 2052:
/*  235 */         return getTypeBinding((TypeBinding)binding);
/*      */       case 68:
/*      */       case 4100:
/*  238 */         return new TypeBinding(this, (TypeBinding)binding);
/*      */       case 8:
/*  240 */         return getMethodBinding((MethodBinding)binding);
/*      */       case 64:
/*  242 */         return getModuleBinding((ModuleBinding)binding);
/*      */       case 1:
/*      */       case 2:
/*      */       case 131072:
/*  246 */         return getVariableBinding((VariableBinding)binding);
/*      */     } 
/*  248 */     return null;
/*      */   }
/*      */   
/*      */   Util.BindingsToNodesMap getBindingsToNodesMap() {
/*  252 */     return new Util.BindingsToNodesMap()
/*      */       {
/*      */         public ASTNode get(Binding binding) {
/*  255 */           return 
/*  256 */             (ASTNode)DefaultBindingResolver.this.newAstToOldAst.get(DefaultBindingResolver.this.bindingsToAstNodes.get(binding));
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized ASTNode getCorrespondingNode(ASTNode currentNode) {
/*  263 */     return (ASTNode)this.newAstToOldAst.get(currentNode);
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IMethodBinding getMethodBinding(MethodBinding methodBinding) {
/*  268 */     return getMethodOrLambdaBinding(methodBinding, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized IMethodBinding getMethodOrLambdaBinding(MethodBinding methodBinding, MethodBinding descriptor, IBinding enclosingBinding) {
/*  275 */     if (methodBinding != null && !methodBinding.isValidBinding()) {
/*  276 */       ProblemMethodBinding problemMethodBinding = 
/*  277 */         (ProblemMethodBinding)methodBinding;
/*  278 */       methodBinding = problemMethodBinding.closestMatch;
/*      */     } 
/*      */     
/*  281 */     if (methodBinding != null) {
/*  282 */       if (!this.isRecoveringBindings && (methodBinding.tagBits & 0x80L) != 0L) {
/*  283 */         return null;
/*      */       }
/*  285 */       IMethodBinding binding = (IMethodBinding)this.bindingTables.compilerBindingsToASTBindings.get(methodBinding);
/*  286 */       if (binding != null) {
/*  287 */         return binding;
/*      */       }
/*  289 */       if (descriptor != null && enclosingBinding != null) {
/*  290 */         binding = new MethodBinding.LambdaMethod(this, descriptor, methodBinding, enclosingBinding);
/*      */       } else {
/*  292 */         binding = new MethodBinding(this, methodBinding);
/*      */       } 
/*  294 */       this.bindingTables.compilerBindingsToASTBindings.put(methodBinding, binding);
/*  295 */       return binding;
/*      */     } 
/*  297 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IMemberValuePairBinding getMemberValuePairBinding(ElementValuePair valuePair) {
/*  302 */     if (valuePair == null || valuePair.binding == null) return null; 
/*  303 */     IMemberValuePairBinding binding = 
/*  304 */       (IMemberValuePairBinding)this.bindingTables.compilerBindingsToASTBindings.get(valuePair);
/*  305 */     if (binding != null)
/*  306 */       return binding; 
/*  307 */     binding = new MemberValuePairBinding(valuePair, this);
/*  308 */     this.bindingTables.compilerBindingsToASTBindings.put(valuePair, binding);
/*  309 */     return binding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized IModuleBinding getModuleBinding(ModuleBinding moduleBinding) {
/*  317 */     if (moduleBinding != null) {
/*  318 */       IModuleBinding binding = (IModuleBinding)this.bindingTables.compilerBindingsToASTBindings.get(moduleBinding);
/*  319 */       if (binding == null) {
/*  320 */         binding = new ModuleBinding(this, moduleBinding);
/*  321 */         this.bindingTables.compilerBindingsToASTBindings.put(moduleBinding, binding);
/*      */       } 
/*  323 */       return binding;
/*      */     } 
/*  325 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IPackageBinding getPackageBinding(PackageBinding packageBinding) {
/*  330 */     if (packageBinding == null || packageBinding instanceof org.eclipse.jdt.internal.compiler.lookup.ProblemPackageBinding) {
/*  331 */       return null;
/*      */     }
/*  333 */     IPackageBinding binding = (IPackageBinding)this.bindingTables.compilerBindingsToASTBindings.get(packageBinding);
/*  334 */     if (binding != null) {
/*  335 */       return binding;
/*      */     }
/*  337 */     binding = (packageBinding instanceof org.eclipse.jdt.internal.compiler.lookup.ProblemPackageBinding) ? new RecoveredPackageBinding(packageBinding, this) : 
/*  338 */       new PackageBinding(packageBinding, this);
/*  339 */     this.bindingTables.compilerBindingsToASTBindings.put(packageBinding, binding);
/*  340 */     return binding;
/*      */   }
/*      */   private int getTypeCount(ParameterizedQualifiedTypeReference typeReference) {
/*  343 */     TypeReference[][] typeArguments = typeReference.typeArguments;
/*  344 */     int value = 0;
/*  345 */     Annotation[][] typeAnnotations = typeReference.annotations;
/*  346 */     int length = typeReference.tokens.length;
/*  347 */     for (int i = 0; i < length; i++) {
/*  348 */       if (value != 0 || (typeArguments != null && typeArguments[i] != null) || (
/*  349 */         typeAnnotations != null && typeAnnotations[i] != null)) {
/*  350 */         value++;
/*      */       }
/*      */     } 
/*  353 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized ITypeBinding getTypeBinding(VariableDeclaration variableDeclaration) {
/*  358 */     ITypeBinding binding = (ITypeBinding)this.bindingTables.compilerBindingsToASTBindings.get(variableDeclaration);
/*  359 */     if (binding != null) {
/*  360 */       return binding;
/*      */     }
/*  362 */     binding = new RecoveredTypeBinding(this, variableDeclaration);
/*  363 */     this.bindingTables.compilerBindingsToASTBindings.put(variableDeclaration, binding);
/*  364 */     return binding;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized ITypeBinding getTypeBinding(Type type) {
/*  369 */     ITypeBinding binding = (ITypeBinding)this.bindingTables.compilerBindingsToASTBindings.get(type);
/*  370 */     if (binding != null) {
/*  371 */       return binding;
/*      */     }
/*  373 */     binding = new RecoveredTypeBinding(this, type);
/*  374 */     this.bindingTables.compilerBindingsToASTBindings.put(type, binding);
/*  375 */     return binding;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized ITypeBinding getTypeBinding(TypeBinding referenceBinding) {
/*  380 */     return internalGetTypeBinding(referenceBinding, null);
/*      */   }
/*      */ 
/*      */   
/*      */   private synchronized ITypeBinding internalGetTypeBinding(TypeBinding referenceBinding, IBinding declaringMember) {
/*  385 */     if (referenceBinding == null)
/*  386 */       return null; 
/*  387 */     if (!referenceBinding.isValidBinding()) {
/*  388 */       ITypeBinding iTypeBinding; switch (referenceBinding.problemId()) {
/*      */         case 2:
/*      */         case 7:
/*  391 */           if (referenceBinding instanceof ProblemReferenceBinding) {
/*  392 */             ProblemReferenceBinding problemReferenceBinding = (ProblemReferenceBinding)referenceBinding;
/*  393 */             TypeBinding binding2 = problemReferenceBinding.closestMatch();
/*  394 */             ITypeBinding iTypeBinding1 = (ITypeBinding)this.bindingTables.compilerBindingsToASTBindings.get(binding2);
/*  395 */             if (iTypeBinding1 != null) {
/*  396 */               return iTypeBinding1;
/*      */             }
/*  398 */             iTypeBinding1 = TypeBinding.createTypeBinding(this, binding2, declaringMember);
/*  399 */             this.bindingTables.compilerBindingsToASTBindings.put(binding2, iTypeBinding1);
/*  400 */             return iTypeBinding1;
/*      */           } 
/*      */           break;
/*      */         case 1:
/*  404 */           if (!this.isRecoveringBindings) {
/*  405 */             return null;
/*      */           }
/*  407 */           iTypeBinding = (ITypeBinding)this.bindingTables.compilerBindingsToASTBindings.get(referenceBinding);
/*  408 */           if (iTypeBinding != null) {
/*  409 */             return iTypeBinding;
/*      */           }
/*  411 */           if ((referenceBinding.tagBits & 0x80L) != 0L) {
/*  412 */             iTypeBinding = TypeBinding.createTypeBinding(this, referenceBinding, declaringMember);
/*      */           } else {
/*  414 */             iTypeBinding = new RecoveredTypeBinding(this, referenceBinding);
/*      */           } 
/*  416 */           this.bindingTables.compilerBindingsToASTBindings.put(referenceBinding, iTypeBinding);
/*  417 */           return iTypeBinding;
/*      */       } 
/*  419 */       return null;
/*      */     } 
/*  421 */     if ((referenceBinding.tagBits & 0x80L) != 0L && !this.isRecoveringBindings) {
/*  422 */       return null;
/*      */     }
/*  424 */     ITypeBinding binding = (ITypeBinding)this.bindingTables.compilerBindingsToASTBindings.get(referenceBinding);
/*  425 */     if (binding != null) {
/*  426 */       return binding;
/*      */     }
/*  428 */     binding = TypeBinding.createTypeBinding(this, referenceBinding, declaringMember);
/*  429 */     this.bindingTables.compilerBindingsToASTBindings.put(referenceBinding, binding);
/*  430 */     return binding;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized ITypeBinding getTypeBinding(RecoveredTypeBinding recoveredTypeBinding, int dimensions) {
/*  436 */     if (recoveredTypeBinding == null) {
/*  437 */       return null;
/*      */     }
/*  439 */     return new RecoveredTypeBinding(this, recoveredTypeBinding, dimensions);
/*      */   }
/*      */   
/*      */   synchronized IVariableBinding getVariableBinding(VariableBinding variableBinding, VariableDeclaration variableDeclaration) {
/*  443 */     if (this.isRecoveringBindings) {
/*  444 */       if (variableBinding != null) {
/*  445 */         if (variableBinding.isValidBinding()) {
/*  446 */           IVariableBinding binding = (IVariableBinding)this.bindingTables.compilerBindingsToASTBindings.get(variableBinding);
/*  447 */           if (binding != null) {
/*  448 */             return binding;
/*      */           }
/*  450 */           if (variableBinding.type != null) {
/*  451 */             binding = new VariableBinding(this, variableBinding);
/*      */           } else {
/*  453 */             binding = new RecoveredVariableBinding(this, variableDeclaration);
/*      */           } 
/*  455 */           this.bindingTables.compilerBindingsToASTBindings.put(variableBinding, binding);
/*  456 */           return binding;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  461 */         if (variableBinding instanceof ProblemFieldBinding) {
/*  462 */           ReferenceBinding declaringClass; FieldBinding exactBinding; ProblemFieldBinding problemFieldBinding = (ProblemFieldBinding)variableBinding;
/*  463 */           switch (problemFieldBinding.problemId()) {
/*      */             case 2:
/*      */             case 6:
/*      */             case 7:
/*  467 */               declaringClass = problemFieldBinding.declaringClass;
/*  468 */               exactBinding = declaringClass.getField(problemFieldBinding.name, true);
/*  469 */               if (exactBinding != null) {
/*  470 */                 IVariableBinding variableBinding2 = (IVariableBinding)this.bindingTables.compilerBindingsToASTBindings.get(exactBinding);
/*  471 */                 if (variableBinding2 != null) {
/*  472 */                   return variableBinding2;
/*      */                 }
/*  474 */                 variableBinding2 = new VariableBinding(this, (VariableBinding)exactBinding);
/*  475 */                 this.bindingTables.compilerBindingsToASTBindings.put(exactBinding, variableBinding2);
/*  476 */                 return variableBinding2;
/*      */               } 
/*      */               break;
/*      */           } 
/*      */         
/*      */         } 
/*      */       } 
/*  483 */       return null;
/*      */     } 
/*  485 */     return getVariableBinding(variableBinding);
/*      */   }
/*      */ 
/*      */   
/*      */   public WorkingCopyOwner getWorkingCopyOwner() {
/*  490 */     return this.workingCopyOwner;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IVariableBinding getVariableBinding(VariableBinding variableBinding) {
/*  495 */     if (variableBinding != null) {
/*  496 */       if (variableBinding.isValidBinding()) {
/*  497 */         TypeBinding variableType = variableBinding.type;
/*  498 */         if (variableType != null) {
/*  499 */           if (!this.isRecoveringBindings && (variableType.tagBits & 0x80L) != 0L) {
/*  500 */             return null;
/*      */           }
/*  502 */           IVariableBinding binding = (IVariableBinding)this.bindingTables.compilerBindingsToASTBindings.get(variableBinding);
/*  503 */           if (binding != null) {
/*  504 */             return binding;
/*      */           }
/*  506 */           binding = new VariableBinding(this, variableBinding);
/*  507 */           this.bindingTables.compilerBindingsToASTBindings.put(variableBinding, binding);
/*  508 */           return binding;
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*  514 */       else if (variableBinding instanceof ProblemFieldBinding) {
/*  515 */         ReferenceBinding declaringClass; FieldBinding exactBinding; ProblemFieldBinding problemFieldBinding = (ProblemFieldBinding)variableBinding;
/*  516 */         switch (problemFieldBinding.problemId()) {
/*      */           case 2:
/*      */           case 6:
/*      */           case 7:
/*  520 */             declaringClass = problemFieldBinding.declaringClass;
/*  521 */             exactBinding = declaringClass.getField(problemFieldBinding.name, true);
/*  522 */             if (exactBinding != null) {
/*  523 */               IVariableBinding variableBinding2 = (IVariableBinding)this.bindingTables.compilerBindingsToASTBindings.get(exactBinding);
/*  524 */               if (variableBinding2 != null) {
/*  525 */                 return variableBinding2;
/*      */               }
/*  527 */               variableBinding2 = new VariableBinding(this, (VariableBinding)exactBinding);
/*  528 */               this.bindingTables.compilerBindingsToASTBindings.put(exactBinding, variableBinding2);
/*  529 */               return variableBinding2;
/*      */             } 
/*      */             break;
/*      */         } 
/*      */       
/*      */       } 
/*      */     }
/*  536 */     return null;
/*      */   }
/*      */   
/*      */   static class AnnotationIdentityBinding { AnnotationBinding internalInstance;
/*      */     
/*      */     AnnotationIdentityBinding(AnnotationBinding internalInstance) {
/*  542 */       this.internalInstance = internalInstance;
/*      */     }
/*      */     
/*      */     public boolean equals(Object o) {
/*  546 */       return (o instanceof AnnotationIdentityBinding && this.internalInstance == ((AnnotationIdentityBinding)o).internalInstance);
/*      */     }
/*      */     
/*      */     public int hashCode() {
/*  550 */       return this.internalInstance.hashCode();
/*      */     } }
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized IAnnotationBinding getAnnotationInstance(AnnotationBinding internalInstance) {
/*  556 */     if (internalInstance == null) return null; 
/*  557 */     ReferenceBinding annotationType = internalInstance.getAnnotationType();
/*  558 */     if (!this.isRecoveringBindings && (
/*  559 */       annotationType == null || (annotationType.tagBits & 0x80L) != 0L)) {
/*  560 */       return null;
/*      */     }
/*      */     
/*  563 */     Object key = new AnnotationIdentityBinding(internalInstance);
/*  564 */     IAnnotationBinding newDomInstance = new AnnotationBinding(internalInstance, this);
/*  565 */     IAnnotationBinding domInstance = ((ConcurrentHashMap<Object, IAnnotationBinding>)this.bindingTables.compilerAnnotationBindingsToASTBindings).putIfAbsent(key, newDomInstance);
/*  566 */     return (domInstance != null) ? domInstance : newDomInstance;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean isResolvedTypeInferredFromExpectedType(MethodInvocation methodInvocation) {
/*  571 */     Object oldNode = this.newAstToOldAst.get(methodInvocation);
/*  572 */     if (oldNode instanceof MessageSend) {
/*  573 */       MessageSend messageSend = (MessageSend)oldNode;
/*  574 */       MethodBinding methodBinding = messageSend.binding;
/*  575 */       if (methodBinding instanceof ParameterizedGenericMethodBinding) {
/*  576 */         ParameterizedGenericMethodBinding genericMethodBinding = (ParameterizedGenericMethodBinding)methodBinding;
/*  577 */         return genericMethodBinding.inferredReturnType;
/*      */       } 
/*      */     } 
/*  580 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean isResolvedTypeInferredFromExpectedType(SuperMethodInvocation superMethodInvocation) {
/*  585 */     Object oldNode = this.newAstToOldAst.get(superMethodInvocation);
/*  586 */     if (oldNode instanceof MessageSend) {
/*  587 */       MessageSend messageSend = (MessageSend)oldNode;
/*  588 */       MethodBinding methodBinding = messageSend.binding;
/*  589 */       if (methodBinding instanceof ParameterizedGenericMethodBinding) {
/*  590 */         ParameterizedGenericMethodBinding genericMethodBinding = (ParameterizedGenericMethodBinding)methodBinding;
/*  591 */         return genericMethodBinding.inferredReturnType;
/*      */       } 
/*      */     } 
/*  594 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean isResolvedTypeInferredFromExpectedType(ClassInstanceCreation classInstanceCreation) {
/*  599 */     Object oldNode = this.newAstToOldAst.get(classInstanceCreation);
/*  600 */     if (oldNode instanceof AllocationExpression) {
/*  601 */       AllocationExpression allocationExpression = (AllocationExpression)oldNode;
/*  602 */       return allocationExpression.inferredReturnType;
/*      */     } 
/*  604 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   LookupEnvironment lookupEnvironment() {
/*  609 */     return this.scope.environment();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void recordScope(ASTNode astNode, BlockScope blockScope) {
/*  617 */     this.astNodesToBlockScope.put(astNode, blockScope);
/*      */   }
/*      */ 
/*      */   
/*      */   boolean resolveBoxing(Expression expression) {
/*  622 */     ASTNode node = (ASTNode)this.newAstToOldAst.get(expression);
/*  623 */     if (node instanceof Expression && (
/*  624 */       (Expression)node).isTrulyExpression()) {
/*  625 */       Expression compilerExpression = (Expression)node;
/*  626 */       return ((compilerExpression.implicitConversion & 0x200) != 0);
/*      */     } 
/*  628 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean resolveUnboxing(Expression expression) {
/*  633 */     ASTNode node = (ASTNode)this.newAstToOldAst.get(expression);
/*  634 */     if (node instanceof Expression) {
/*  635 */       Expression compilerExpression = (Expression)node;
/*  636 */       return ((compilerExpression.implicitConversion & 0x400) != 0);
/*      */     } 
/*  638 */     return false;
/*      */   }
/*      */   
/*      */   Object resolveConstantExpressionValue(Expression expression) {
/*      */     Expression expression1;
/*  643 */     ASTNode node = (ASTNode)this.newAstToOldAst.get(expression);
/*  644 */     if (node instanceof FieldDeclaration) {
/*  645 */       expression1 = ((FieldDeclaration)node).initialization;
/*      */     }
/*  647 */     if (expression1 instanceof Expression && 
/*  648 */       expression1.isTrulyExpression()) {
/*  649 */       Expression compilerExpression = expression1;
/*  650 */       Constant constant = compilerExpression.constant;
/*  651 */       if (constant != null && constant != Constant.NotAConstant) {
/*  652 */         switch (constant.typeID()) { case 10:
/*  653 */             return Integer.valueOf(constant.intValue());
/*  654 */           case 3: return Byte.valueOf(constant.byteValue());
/*  655 */           case 4: return Short.valueOf(constant.shortValue());
/*  656 */           case 2: return Character.valueOf(constant.charValue());
/*  657 */           case 9: return Float.valueOf(constant.floatValue());
/*  658 */           case 8: return Double.valueOf(constant.doubleValue());
/*  659 */           case 5: return constant.booleanValue() ? Boolean.TRUE : Boolean.FALSE;
/*  660 */           case 7: return Long.valueOf(constant.longValue());
/*  661 */           case 11: return constant.stringValue(); }
/*      */         
/*  663 */         return null;
/*      */       } 
/*      */     } 
/*  666 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IMethodBinding resolveConstructor(ClassInstanceCreation expression) {
/*  671 */     ASTNode node = (ASTNode)this.newAstToOldAst.get(expression);
/*  672 */     if (node != null && (node.bits & 0x200) != 0) {
/*  673 */       TypeDeclaration anonymousLocalTypeDeclaration = (TypeDeclaration)node;
/*  674 */       return getMethodBinding(anonymousLocalTypeDeclaration.allocation.binding);
/*  675 */     }  if (node instanceof AllocationExpression) {
/*  676 */       return getMethodBinding(((AllocationExpression)node).binding);
/*      */     }
/*  678 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IMethodBinding resolveConstructor(ConstructorInvocation expression) {
/*  683 */     ASTNode node = (ASTNode)this.newAstToOldAst.get(expression);
/*  684 */     if (node instanceof ExplicitConstructorCall) {
/*  685 */       ExplicitConstructorCall explicitConstructorCall = (ExplicitConstructorCall)node;
/*  686 */       return getMethodBinding(explicitConstructorCall.binding);
/*      */     } 
/*  688 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   IMethodBinding resolveConstructor(EnumConstantDeclaration enumConstantDeclaration) {
/*  693 */     ASTNode node = (ASTNode)this.newAstToOldAst.get(enumConstantDeclaration);
/*  694 */     if (node instanceof FieldDeclaration) {
/*  695 */       FieldDeclaration fieldDeclaration = (FieldDeclaration)node;
/*  696 */       if (fieldDeclaration.getKind() == 3 && fieldDeclaration.initialization != null) {
/*  697 */         AllocationExpression allocationExpression = (AllocationExpression)fieldDeclaration.initialization;
/*  698 */         return getMethodBinding(allocationExpression.binding);
/*      */       } 
/*      */     } 
/*  701 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IMethodBinding resolveConstructor(SuperConstructorInvocation expression) {
/*  706 */     ASTNode node = (ASTNode)this.newAstToOldAst.get(expression);
/*  707 */     if (node instanceof ExplicitConstructorCall) {
/*  708 */       ExplicitConstructorCall explicitConstructorCall = (ExplicitConstructorCall)node;
/*  709 */       return getMethodBinding(explicitConstructorCall.binding);
/*      */     } 
/*  711 */     return null; } synchronized ITypeBinding resolveExpressionType(Expression expression) { try {
/*      */       ASTNode astNode; Expression compilerExpression; Literal literal; ThisReference thisReference;
/*      */       BlockScope blockScope;
/*      */       ParenthesizedExpression parenthesizedExpression;
/*      */       VariableDeclarationExpression variableDeclarationExpression;
/*      */       Type type;
/*  717 */       switch (expression.getNodeType()) {
/*      */         case 14:
/*  719 */           astNode = (ASTNode)this.newAstToOldAst.get(expression);
/*  720 */           if (astNode instanceof TypeDeclaration) {
/*      */             
/*  722 */             TypeDeclaration typeDeclaration = (TypeDeclaration)astNode;
/*  723 */             ITypeBinding typeBinding = getTypeBinding((TypeBinding)typeDeclaration.binding);
/*  724 */             if (typeBinding != null)
/*  725 */               return typeBinding;  break;
/*      */           } 
/*  727 */           if (astNode instanceof AllocationExpression) {
/*      */             
/*  729 */             AllocationExpression allocationExpression = (AllocationExpression)astNode;
/*  730 */             return getTypeBinding(allocationExpression.resolvedType);
/*      */           } 
/*      */           break;
/*      */         case 40:
/*      */         case 42:
/*  735 */           return resolveTypeBindingForName((Name)expression);
/*      */         case 2:
/*      */         case 3:
/*      */         case 4:
/*      */         case 7:
/*      */         case 11:
/*      */         case 16:
/*      */         case 22:
/*      */         case 27:
/*      */         case 32:
/*      */         case 37:
/*      */         case 38:
/*      */         case 47:
/*      */         case 48:
/*      */         case 57:
/*      */         case 62:
/*      */         case 77:
/*      */         case 78:
/*      */         case 79:
/*      */         case 86:
/*      */         case 89:
/*      */         case 90:
/*      */         case 91:
/*      */         case 92:
/*      */         case 100:
/*      */         case 106:
/*      */         case 107:
/*  762 */           compilerExpression = (Expression)this.newAstToOldAst.get(expression);
/*  763 */           if (compilerExpression != null) {
/*  764 */             return getTypeBinding(compilerExpression.resolvedType);
/*      */           }
/*      */           break;
/*      */         case 45:
/*      */         case 102:
/*  769 */           if (this.scope != null) {
/*  770 */             return getTypeBinding((TypeBinding)this.scope.getJavaLangString());
/*      */           }
/*      */           break;
/*      */         case 108:
/*  774 */           return null;
/*      */         case 9:
/*      */         case 13:
/*      */         case 33:
/*      */         case 34:
/*  779 */           literal = (Literal)this.newAstToOldAst.get(expression);
/*  780 */           if (literal != null) {
/*  781 */             return getTypeBinding(literal.literalType(null));
/*      */           }
/*      */           break;
/*      */         case 52:
/*  785 */           thisReference = (ThisReference)this.newAstToOldAst.get(expression);
/*  786 */           blockScope = (BlockScope)this.astNodesToBlockScope.get(expression);
/*  787 */           if (blockScope != null) {
/*  788 */             return getTypeBinding(thisReference.resolveType(blockScope));
/*      */           }
/*      */           break;
/*      */         case 36:
/*  792 */           parenthesizedExpression = (ParenthesizedExpression)expression;
/*  793 */           return resolveExpressionType(parenthesizedExpression.getExpression());
/*      */         case 58:
/*  795 */           variableDeclarationExpression = (VariableDeclarationExpression)expression;
/*  796 */           type = variableDeclarationExpression.getType();
/*  797 */           if (type != null) {
/*  798 */             return type.resolveBinding();
/*      */           }
/*      */           break;
/*      */       } 
/*  802 */     } catch (AbortCompilation abortCompilation) {}
/*      */ 
/*      */     
/*  805 */     return null; }
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized IVariableBinding resolveField(FieldAccess fieldAccess) {
/*  810 */     Object oldNode = this.newAstToOldAst.get(fieldAccess);
/*  811 */     if (oldNode instanceof FieldReference) {
/*  812 */       FieldReference fieldReference = (FieldReference)oldNode;
/*  813 */       return getVariableBinding((VariableBinding)fieldReference.binding);
/*      */     } 
/*  815 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IVariableBinding resolveField(SuperFieldAccess fieldAccess) {
/*  820 */     Object oldNode = this.newAstToOldAst.get(fieldAccess);
/*  821 */     if (oldNode instanceof FieldReference) {
/*  822 */       FieldReference fieldReference = (FieldReference)oldNode;
/*  823 */       return getVariableBinding((VariableBinding)fieldReference.binding);
/*      */     } 
/*  825 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IBinding resolveImport(ImportDeclaration importDeclaration) {
/*  830 */     if (this.scope == null) return null; 
/*      */     try {
/*  832 */       ASTNode node = (ASTNode)this.newAstToOldAst.get(importDeclaration);
/*  833 */       if (node instanceof ImportReference) {
/*  834 */         ImportReference importReference = (ImportReference)node;
/*  835 */         boolean isStatic = importReference.isStatic();
/*  836 */         if ((importReference.bits & 0x20000) != 0) {
/*  837 */           Binding binding = this.scope.getImport(CharOperation.subarray(importReference.tokens, 0, importReference.tokens.length), true, isStatic);
/*  838 */           if (binding != null) {
/*  839 */             if (isStatic) {
/*  840 */               if (binding instanceof TypeBinding) {
/*  841 */                 ITypeBinding typeBinding = getTypeBinding((TypeBinding)binding);
/*  842 */                 return (typeBinding == null) ? null : typeBinding;
/*      */               } 
/*      */             } else {
/*  845 */               if ((binding.kind() & 0x10) != 0) {
/*  846 */                 IPackageBinding packageBinding = getPackageBinding((PackageBinding)binding);
/*  847 */                 if (packageBinding == null) {
/*  848 */                   return null;
/*      */                 }
/*  850 */                 return packageBinding;
/*      */               } 
/*      */               
/*  853 */               ITypeBinding typeBinding = getTypeBinding((TypeBinding)binding);
/*  854 */               if (typeBinding == null) {
/*  855 */                 return null;
/*      */               }
/*  857 */               return typeBinding;
/*      */             } 
/*      */           }
/*      */         } else {
/*      */           
/*  862 */           Binding binding = this.scope.getImport(importReference.tokens, false, isStatic);
/*  863 */           if (binding != null) {
/*  864 */             if (isStatic) {
/*  865 */               if (binding instanceof TypeBinding) {
/*  866 */                 ITypeBinding typeBinding = getTypeBinding((TypeBinding)binding);
/*  867 */                 return (typeBinding == null) ? null : typeBinding;
/*  868 */               }  if (binding instanceof FieldBinding) {
/*  869 */                 IVariableBinding variableBinding = getVariableBinding((VariableBinding)binding);
/*  870 */                 return (variableBinding == null) ? null : variableBinding;
/*  871 */               }  if (binding instanceof MethodBinding)
/*      */               {
/*  873 */                 return getMethodBinding((MethodBinding)binding); } 
/*  874 */               if (binding instanceof RecordComponentBinding) {
/*  875 */                 IVariableBinding variableBinding = getVariableBinding((VariableBinding)binding);
/*  876 */                 return (variableBinding == null) ? null : variableBinding;
/*      */               }
/*      */             
/*  879 */             } else if (binding instanceof TypeBinding) {
/*  880 */               ITypeBinding typeBinding = getTypeBinding((TypeBinding)binding);
/*  881 */               return (typeBinding == null) ? null : typeBinding;
/*      */             }
/*      */           
/*      */           }
/*      */         } 
/*      */       } 
/*  887 */     } catch (AbortCompilation abortCompilation) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  892 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   IMethodBinding resolveMember(AnnotationTypeMemberDeclaration declaration) {
/*  897 */     Object oldNode = this.newAstToOldAst.get(declaration);
/*  898 */     if (oldNode instanceof AbstractMethodDeclaration) {
/*  899 */       AbstractMethodDeclaration methodDeclaration = (AbstractMethodDeclaration)oldNode;
/*  900 */       IMethodBinding methodBinding = getMethodBinding(methodDeclaration.binding);
/*  901 */       if (methodBinding == null) {
/*  902 */         return null;
/*      */       }
/*  904 */       this.bindingsToAstNodes.put(methodBinding, declaration);
/*  905 */       String key = methodBinding.getKey();
/*  906 */       if (key != null) {
/*  907 */         this.bindingTables.bindingKeysToBindings.put(key, methodBinding);
/*      */       }
/*  909 */       return methodBinding;
/*      */     } 
/*  911 */     return null;
/*      */   }
/*      */   
/*      */   private IVariableBinding[] getSyntheticOuterLocalVariables(LambdaExpression lambdaExpression) {
/*  915 */     IVariableBinding[] syntheticOuterLocals = new IVariableBinding[lambdaExpression.outerLocalVariables.length];
/*  916 */     int i = 0; byte b; int j; SyntheticArgumentBinding[] arrayOfSyntheticArgumentBinding;
/*  917 */     for (j = (arrayOfSyntheticArgumentBinding = lambdaExpression.outerLocalVariables).length, b = 0; b < j; ) { SyntheticArgumentBinding sab = arrayOfSyntheticArgumentBinding[b];
/*  918 */       syntheticOuterLocals[i++] = getVariableBinding((VariableBinding)sab); b++; }
/*      */     
/*  920 */     return syntheticOuterLocals;
/*      */   }
/*      */   
/*      */   synchronized IMethodBinding resolveMethod(LambdaExpression lambda) {
/*  924 */     Object oldNode = this.newAstToOldAst.get(lambda);
/*  925 */     if (oldNode instanceof LambdaExpression) {
/*  926 */       LambdaExpression lambdaExpression = (LambdaExpression)oldNode;
/*  927 */       IMethodBinding methodBinding = null;
/*  928 */       if (lambdaExpression.descriptor != null) {
/*  929 */         IBinding declaringMember = getDeclaringMember((ASTNode)lambdaExpression, (Scope)lambdaExpression.enclosingScope);
/*  930 */         if (declaringMember != null)
/*  931 */           methodBinding = getMethodOrLambdaBinding(lambdaExpression.getMethodBinding(), lambdaExpression.descriptor, declaringMember); 
/*      */       } 
/*  933 */       if (methodBinding == null) {
/*  934 */         return null;
/*      */       }
/*  936 */       if (methodBinding instanceof MethodBinding.LambdaMethod) {
/*  937 */         ((MethodBinding.LambdaMethod)methodBinding).setSyntheticOuterLocals(getSyntheticOuterLocalVariables(lambdaExpression));
/*      */       }
/*  939 */       this.bindingsToAstNodes.put(methodBinding, lambda);
/*  940 */       String key = methodBinding.getKey();
/*  941 */       if (key != null) {
/*  942 */         this.bindingTables.bindingKeysToBindings.put(key, methodBinding);
/*      */       }
/*  944 */       return methodBinding;
/*      */     } 
/*  946 */     return null;
/*      */   }
/*      */   
/*      */   private IBinding getDeclaringMember(ASTNode node, Scope currentScope) {
/*  950 */     MethodScope methodScope = (currentScope != null) ? currentScope.methodScope() : null;
/*  951 */     if (methodScope != null) {
/*  952 */       if (methodScope.isInsideInitializer()) {
/*  953 */         TypeDeclaration enclosingType = methodScope.referenceType();
/*  954 */         if (enclosingType.fields != null) {
/*  955 */           for (int i = 0; i < enclosingType.fields.length; i++) {
/*  956 */             FieldDeclaration field = enclosingType.fields[i];
/*  957 */             if (field.declarationSourceStart <= node.sourceStart && node.sourceEnd <= field.declarationSourceEnd) {
/*  958 */               if (field instanceof Initializer) {
/*  959 */                 return getMethodBinding(((Initializer)field).getMethodBinding());
/*      */               }
/*  961 */               return getVariableBinding((VariableBinding)field.binding);
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } else {
/*  966 */         if (methodScope.isLambdaScope()) {
/*  967 */           LambdaExpression lambdaExpression = (LambdaExpression)methodScope.referenceContext;
/*  968 */           IMethodBinding methodBinding = null;
/*  969 */           if (lambdaExpression.descriptor != null) {
/*  970 */             IBinding declaringMember = getDeclaringMember((ASTNode)lambdaExpression, (Scope)lambdaExpression.enclosingScope);
/*  971 */             if (declaringMember != null)
/*  972 */               methodBinding = getMethodOrLambdaBinding(lambdaExpression.getMethodBinding(), lambdaExpression.descriptor, declaringMember); 
/*      */           } 
/*  974 */           if (methodBinding == null) {
/*  975 */             return null;
/*      */           }
/*  977 */           String key = methodBinding.getKey();
/*  978 */           if (key != null) {
/*  979 */             this.bindingTables.bindingKeysToBindings.put(key, methodBinding);
/*      */           }
/*  981 */           return methodBinding;
/*      */         } 
/*  983 */         return getMethodBinding(methodScope.referenceMethodBinding());
/*      */       } 
/*      */     }
/*      */     
/*  987 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IMethodBinding resolveMethod(MethodDeclaration method) {
/*  992 */     Object oldNode = this.newAstToOldAst.get(method);
/*  993 */     if (oldNode instanceof AbstractMethodDeclaration) {
/*  994 */       AbstractMethodDeclaration methodDeclaration = (AbstractMethodDeclaration)oldNode;
/*  995 */       IMethodBinding methodBinding = getMethodBinding(methodDeclaration.binding);
/*  996 */       if (methodBinding == null) {
/*  997 */         return null;
/*      */       }
/*  999 */       this.bindingsToAstNodes.put(methodBinding, method);
/* 1000 */       String key = methodBinding.getKey();
/* 1001 */       if (key != null) {
/* 1002 */         this.bindingTables.bindingKeysToBindings.put(key, methodBinding);
/*      */       }
/* 1004 */       return methodBinding;
/*      */     } 
/* 1006 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IMethodBinding resolveMethod(MethodInvocation method) {
/* 1011 */     Object oldNode = this.newAstToOldAst.get(method);
/* 1012 */     if (oldNode instanceof MessageSend) {
/* 1013 */       MessageSend messageSend = (MessageSend)oldNode;
/* 1014 */       return getMethodBinding(messageSend.binding);
/*      */     } 
/* 1016 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IMethodBinding resolveMethod(MethodReference methodReference) {
/* 1021 */     Object oldNode = this.newAstToOldAst.get(methodReference);
/* 1022 */     if (oldNode instanceof ReferenceExpression) {
/* 1023 */       ReferenceExpression referenceExpression = (ReferenceExpression)oldNode;
/* 1024 */       if (referenceExpression.receiverType != null && referenceExpression.receiverType.isArrayType())
/* 1025 */         return null; 
/* 1026 */       IMethodBinding methodBinding = getMethodBinding(referenceExpression.getMethodBinding());
/* 1027 */       if (methodBinding == null) {
/* 1028 */         return null;
/*      */       }
/* 1030 */       return methodBinding;
/*      */     } 
/* 1032 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IMethodBinding resolveMethod(SuperMethodInvocation method) {
/* 1037 */     Object oldNode = this.newAstToOldAst.get(method);
/* 1038 */     if (oldNode instanceof MessageSend) {
/* 1039 */       MessageSend messageSend = (MessageSend)oldNode;
/* 1040 */       return getMethodBinding(messageSend.binding);
/*      */     } 
/* 1042 */     return null;
/*      */   }
/*      */   
/*      */   synchronized ITypeBinding resolveTypeBindingForName(Name name) {
/* 1046 */     ASTNode node = (ASTNode)this.newAstToOldAst.get(name);
/* 1047 */     int index = name.index;
/* 1048 */     if (node instanceof QualifiedNameReference)
/* 1049 */     { QualifiedNameReference qualifiedNameReference = (QualifiedNameReference)node;
/* 1050 */       char[][] tokens = qualifiedNameReference.tokens;
/* 1051 */       if (tokens.length == index) {
/* 1052 */         return getTypeBinding(qualifiedNameReference.resolvedType);
/*      */       }
/* 1054 */       int indexOfFirstFieldBinding = qualifiedNameReference.indexOfFirstFieldBinding;
/* 1055 */       if (index < indexOfFirstFieldBinding) {
/*      */         
/* 1057 */         BlockScope internalScope = (BlockScope)this.astNodesToBlockScope.get(name);
/* 1058 */         Binding binding = null;
/*      */         try {
/* 1060 */           if (internalScope == null) {
/* 1061 */             if (this.scope == null) return null; 
/* 1062 */             binding = this.scope.getTypeOrPackage(CharOperation.subarray(tokens, 0, index));
/*      */           } else {
/* 1064 */             binding = internalScope.getTypeOrPackage(CharOperation.subarray(tokens, 0, index));
/*      */           } 
/* 1066 */         } catch (AbortCompilation abortCompilation) {}
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1071 */         if (binding instanceof PackageBinding)
/* 1072 */           return null; 
/* 1073 */         if (binding instanceof TypeBinding)
/*      */         {
/* 1075 */           return getTypeBinding((TypeBinding)binding); } 
/*      */       } else {
/* 1077 */         TypeBinding typeBinding; if (index == indexOfFirstFieldBinding) {
/* 1078 */           TypeBinding typeBinding1; if (qualifiedNameReference.isTypeReference()) {
/* 1079 */             return getTypeBinding(qualifiedNameReference.resolvedType);
/*      */           }
/*      */           
/* 1082 */           if (qualifiedNameReference.otherBindings == null) {
/* 1083 */             return null;
/*      */           }
/* 1085 */           FieldBinding fieldBinding1 = qualifiedNameReference.otherBindings[0];
/* 1086 */           if (fieldBinding1 == null) return null; 
/* 1087 */           ReferenceBinding referenceBinding1 = fieldBinding1.declaringClass;
/* 1088 */           if (referenceBinding1 == null)
/*      */           {
/* 1090 */             switch (qualifiedNameReference.bits & 0x7) {
/*      */               case 1:
/* 1092 */                 typeBinding1 = ((FieldBinding)qualifiedNameReference.binding).type;
/*      */                 break;
/*      */               case 2:
/* 1095 */                 typeBinding1 = ((LocalVariableBinding)qualifiedNameReference.binding).type;
/*      */                 break;
/*      */               case 131072:
/* 1098 */                 typeBinding1 = ((RecordComponentBinding)qualifiedNameReference.binding).type;
/*      */                 break;
/*      */             } 
/*      */           }
/* 1102 */           return getTypeBinding(typeBinding1);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1108 */         if (qualifiedNameReference.otherBindings == null) return null; 
/* 1109 */         int otherBindingsLength = qualifiedNameReference.otherBindings.length;
/* 1110 */         if (otherBindingsLength == index - indexOfFirstFieldBinding) {
/* 1111 */           return getTypeBinding(qualifiedNameReference.resolvedType);
/*      */         }
/* 1113 */         FieldBinding fieldBinding = qualifiedNameReference.otherBindings[index - indexOfFirstFieldBinding];
/* 1114 */         if (fieldBinding == null) return null; 
/* 1115 */         ReferenceBinding referenceBinding = fieldBinding.declaringClass;
/* 1116 */         if (referenceBinding == null) {
/*      */           
/* 1118 */           fieldBinding = qualifiedNameReference.otherBindings[index - indexOfFirstFieldBinding - 1];
/* 1119 */           if (fieldBinding == null) return null; 
/* 1120 */           typeBinding = fieldBinding.type;
/*      */         } 
/* 1122 */         return getTypeBinding(typeBinding);
/*      */       }  }
/* 1124 */     else if (node instanceof QualifiedTypeReference)
/* 1125 */     { QualifiedTypeReference qualifiedTypeReference = (QualifiedTypeReference)node;
/* 1126 */       if (qualifiedTypeReference.resolvedType == null) {
/* 1127 */         return null;
/*      */       }
/* 1129 */       if (index == qualifiedTypeReference.tokens.length) {
/* 1130 */         if (!qualifiedTypeReference.resolvedType.isValidBinding() && qualifiedTypeReference instanceof JavadocQualifiedTypeReference) {
/* 1131 */           JavadocQualifiedTypeReference typeRef = (JavadocQualifiedTypeReference)node;
/* 1132 */           if (typeRef.packageBinding != null) {
/* 1133 */             return null;
/*      */           }
/*      */         } 
/* 1136 */         return getTypeBinding(qualifiedTypeReference.resolvedType.leafComponentType());
/*      */       } 
/* 1138 */       if (index >= 0) {
/* 1139 */         BlockScope internalScope = (BlockScope)this.astNodesToBlockScope.get(name);
/* 1140 */         Binding binding = null;
/*      */         try {
/* 1142 */           if (internalScope == null) {
/* 1143 */             if (this.scope == null) return null; 
/* 1144 */             binding = this.scope.getTypeOrPackage(CharOperation.subarray(qualifiedTypeReference.tokens, 0, index));
/*      */           } else {
/* 1146 */             binding = internalScope.getTypeOrPackage(CharOperation.subarray(qualifiedTypeReference.tokens, 0, index));
/*      */           } 
/* 1148 */         } catch (AbortCompilation abortCompilation) {}
/*      */ 
/*      */         
/* 1151 */         if (binding instanceof PackageBinding)
/* 1152 */           return null; 
/* 1153 */         if (binding instanceof TypeBinding)
/*      */         {
/* 1155 */           return getTypeBinding((TypeBinding)binding);
/*      */         }
/* 1157 */         return null;
/*      */       }
/*      */        }
/*      */     
/* 1161 */     else if (node instanceof ImportReference)
/* 1162 */     { if ((node.bits & 0x40000) != 0)
/* 1163 */         return null; 
/* 1164 */       ImportReference importReference = (ImportReference)node;
/* 1165 */       int importReferenceLength = importReference.tokens.length;
/* 1166 */       if (index >= 0) {
/* 1167 */         Binding binding = null;
/* 1168 */         if (this.scope == null) return null; 
/* 1169 */         if (importReferenceLength == index) {
/*      */           try {
/* 1171 */             binding = this.scope.getImport(CharOperation.subarray(importReference.tokens, 0, index), ((importReference.bits & 0x20000) != 0), importReference.isStatic());
/* 1172 */           } catch (AbortCompilation abortCompilation) {}
/*      */         } else {
/*      */ 
/*      */           
/*      */           try {
/* 1177 */             binding = this.scope.getImport(CharOperation.subarray(importReference.tokens, 0, index), true, importReference.isStatic());
/* 1178 */           } catch (AbortCompilation abortCompilation) {}
/*      */         } 
/*      */ 
/*      */         
/* 1182 */         if (binding != null) {
/* 1183 */           if (binding instanceof TypeBinding)
/*      */           {
/* 1185 */             return getTypeBinding((TypeBinding)binding);
/*      */           }
/* 1187 */           return null;
/*      */         } 
/*      */       }  }
/* 1190 */     else { if (node instanceof AbstractMethodDeclaration) {
/* 1191 */         AbstractMethodDeclaration methodDeclaration = (AbstractMethodDeclaration)node;
/* 1192 */         IMethodBinding method = getMethodBinding(methodDeclaration.binding);
/* 1193 */         if (method == null) return null; 
/* 1194 */         return method.getReturnType();
/* 1195 */       }  if (node instanceof TypeDeclaration) {
/* 1196 */         TypeDeclaration typeDeclaration = (TypeDeclaration)node;
/* 1197 */         ITypeBinding typeBinding = getTypeBinding((TypeBinding)typeDeclaration.binding);
/* 1198 */         if (typeBinding != null)
/* 1199 */           return typeBinding; 
/*      */       }  }
/* 1201 */      if (node instanceof JavadocSingleNameReference) {
/* 1202 */       JavadocSingleNameReference singleNameReference = (JavadocSingleNameReference)node;
/* 1203 */       VariableBinding localVariable = (VariableBinding)singleNameReference.binding;
/* 1204 */       if (localVariable != null)
/* 1205 */         return getTypeBinding(localVariable.type); 
/*      */     } 
/* 1207 */     if (node instanceof SingleNameReference) {
/* 1208 */       SingleNameReference singleNameReference = (SingleNameReference)node;
/* 1209 */       return getTypeBinding(singleNameReference.resolvedType);
/* 1210 */     }  if (node instanceof QualifiedSuperReference) {
/* 1211 */       QualifiedSuperReference qualifiedSuperReference = (QualifiedSuperReference)node;
/* 1212 */       return getTypeBinding(qualifiedSuperReference.qualification.resolvedType);
/* 1213 */     }  if (node instanceof Receiver) {
/* 1214 */       TypeBinding receiver = ((Receiver)node).type.resolvedType;
/* 1215 */       return getTypeBinding(receiver);
/* 1216 */     }  if (node instanceof LocalDeclaration) {
/* 1217 */       IVariableBinding variable = getVariableBinding((VariableBinding)((LocalDeclaration)node).binding);
/* 1218 */       if (variable == null) return null; 
/* 1219 */       return variable.getType();
/* 1220 */     }  if (node instanceof JavadocFieldReference) {
/* 1221 */       JavadocFieldReference fieldRef = (JavadocFieldReference)node;
/* 1222 */       if (fieldRef.methodBinding != null) {
/* 1223 */         return getMethodBinding(fieldRef.methodBinding).getReturnType();
/*      */       }
/* 1225 */       return getTypeBinding(fieldRef.resolvedType);
/* 1226 */     }  if (node instanceof FieldReference)
/* 1227 */       return getTypeBinding(((FieldReference)node).resolvedType); 
/* 1228 */     if (node instanceof SingleTypeReference) {
/* 1229 */       SingleTypeReference singleTypeReference = (SingleTypeReference)node;
/* 1230 */       TypeBinding binding = singleTypeReference.resolvedType;
/* 1231 */       if (binding != null)
/* 1232 */         return getTypeBinding(binding.leafComponentType()); 
/*      */     } else {
/* 1234 */       if (node instanceof FieldDeclaration) {
/* 1235 */         FieldDeclaration fieldDeclaration = (FieldDeclaration)node;
/* 1236 */         IVariableBinding field = getVariableBinding((VariableBinding)fieldDeclaration.binding);
/* 1237 */         if (field == null) return null; 
/* 1238 */         return field.getType();
/* 1239 */       }  if (node instanceof MessageSend) {
/* 1240 */         MessageSend messageSend = (MessageSend)node;
/* 1241 */         IMethodBinding method = getMethodBinding(messageSend.binding);
/* 1242 */         if (method == null) return null; 
/* 1243 */         return method.getReturnType();
/* 1244 */       }  if (node instanceof AllocationExpression) {
/* 1245 */         AllocationExpression allocation = (AllocationExpression)node;
/* 1246 */         return getTypeBinding(allocation.resolvedType);
/* 1247 */       }  if (node instanceof JavadocImplicitTypeReference) {
/* 1248 */         JavadocImplicitTypeReference implicitRef = (JavadocImplicitTypeReference)node;
/* 1249 */         return getTypeBinding(implicitRef.resolvedType);
/* 1250 */       }  if (node instanceof TypeParameter) {
/* 1251 */         TypeParameter typeParameter = (TypeParameter)node;
/* 1252 */         return getTypeBinding((TypeBinding)typeParameter.binding);
/* 1253 */       }  if (node instanceof MemberValuePair) {
/* 1254 */         MemberValuePair memberValuePair = (MemberValuePair)node;
/* 1255 */         IMethodBinding method = getMethodBinding(memberValuePair.binding);
/* 1256 */         if (method == null) return null; 
/* 1257 */         return method.getReturnType();
/* 1258 */       }  if (node instanceof ReferenceExpression) {
/* 1259 */         ReferenceExpression referenceExpression = (ReferenceExpression)node;
/* 1260 */         IMethodBinding method = getMethodBinding(referenceExpression.getMethodBinding());
/* 1261 */         if (method == null) return null; 
/* 1262 */         return method.getReturnType();
/* 1263 */       }  if (node instanceof RecordComponent) {
/* 1264 */         RecordComponent recordComponent = (RecordComponent)node;
/* 1265 */         TypeBinding recordComponentType = recordComponent.type.resolvedType;
/* 1266 */         return getTypeBinding(recordComponentType);
/*      */       } 
/* 1268 */     }  return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IBinding resolveName(Name name) {
/* 1273 */     ASTNode node = (ASTNode)this.newAstToOldAst.get(name);
/* 1274 */     int index = name.index;
/* 1275 */     if (node instanceof QualifiedNameReference) {
/* 1276 */       QualifiedNameReference qualifiedNameReference = (QualifiedNameReference)node;
/* 1277 */       char[][] tokens = qualifiedNameReference.tokens;
/* 1278 */       int indexOfFirstFieldBinding = qualifiedNameReference.indexOfFirstFieldBinding;
/* 1279 */       if (index < indexOfFirstFieldBinding) {
/*      */         
/* 1281 */         BlockScope internalScope = (BlockScope)this.astNodesToBlockScope.get(name);
/* 1282 */         Binding binding = null;
/*      */         try {
/* 1284 */           if (internalScope == null) {
/* 1285 */             if (this.scope == null) return null; 
/* 1286 */             binding = this.scope.getTypeOrPackage(CharOperation.subarray(tokens, 0, index));
/*      */           } else {
/* 1288 */             binding = internalScope.getTypeOrPackage(CharOperation.subarray(tokens, 0, index));
/*      */           } 
/* 1290 */         } catch (AbortCompilation abortCompilation) {}
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1295 */         if (binding instanceof PackageBinding)
/* 1296 */           return getPackageBinding((PackageBinding)binding); 
/* 1297 */         if (binding instanceof TypeBinding)
/*      */         {
/* 1299 */           return getTypeBinding((TypeBinding)binding);
/*      */         }
/* 1301 */       } else if (index == indexOfFirstFieldBinding) {
/* 1302 */         if (qualifiedNameReference.isTypeReference()) {
/* 1303 */           return getTypeBinding(qualifiedNameReference.resolvedType);
/*      */         }
/* 1305 */         Binding binding = qualifiedNameReference.binding;
/* 1306 */         if (binding != null) {
/* 1307 */           if (binding.isValidBinding())
/* 1308 */             return getVariableBinding((VariableBinding)binding); 
/* 1309 */           if (binding instanceof ProblemFieldBinding) {
/* 1310 */             ReferenceBinding declaringClass; ProblemFieldBinding problemFieldBinding = (ProblemFieldBinding)binding;
/* 1311 */             switch (problemFieldBinding.problemId()) {
/*      */               case 2:
/*      */               case 7:
/* 1314 */                 declaringClass = problemFieldBinding.declaringClass;
/* 1315 */                 if (declaringClass != null) {
/* 1316 */                   FieldBinding exactBinding = declaringClass.getField(tokens[tokens.length - 1], true);
/* 1317 */                   if (exactBinding != null && 
/* 1318 */                     exactBinding.type != null) {
/* 1319 */                     IVariableBinding variableBinding = (IVariableBinding)this.bindingTables.compilerBindingsToASTBindings.get(exactBinding);
/* 1320 */                     if (variableBinding != null) {
/* 1321 */                       return variableBinding;
/*      */                     }
/* 1323 */                     variableBinding = new VariableBinding(this, (VariableBinding)exactBinding);
/* 1324 */                     this.bindingTables.compilerBindingsToASTBindings.put(exactBinding, variableBinding);
/* 1325 */                     return variableBinding;
/*      */                   } 
/*      */                 } 
/*      */                 break;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           } 
/*      */         } 
/*      */       } else {
/* 1338 */         if (qualifiedNameReference.otherBindings == null || index - indexOfFirstFieldBinding - 1 < 0) {
/* 1339 */           return null;
/*      */         }
/* 1341 */         return getVariableBinding((VariableBinding)qualifiedNameReference.otherBindings[index - indexOfFirstFieldBinding - 1]);
/*      */       }
/*      */     
/* 1344 */     } else if (node instanceof JavadocModuleReference) {
/* 1345 */       JavadocModuleReference modRef = (JavadocModuleReference)node;
/* 1346 */       if (modRef.typeReference == null) {
/* 1347 */         ModuleReference moduleReference = modRef.moduleReference;
/* 1348 */         IModuleBinding moduleBinding = getModuleBinding(moduleReference.binding);
/* 1349 */         if (moduleBinding != null) {
/* 1350 */           return moduleBinding;
/*      */         }
/*      */       }
/* 1353 */       else if (name instanceof ModuleQualifiedName) {
/* 1354 */         return resolveName(((ModuleQualifiedName)name).getName());
/*      */       }
/*      */     
/* 1357 */     } else if (node instanceof QualifiedTypeReference) {
/* 1358 */       QualifiedTypeReference qualifiedTypeReference = (QualifiedTypeReference)node;
/* 1359 */       if (qualifiedTypeReference.resolvedType == null) {
/* 1360 */         return null;
/*      */       }
/* 1362 */       if (index == qualifiedTypeReference.tokens.length) {
/* 1363 */         if (!qualifiedTypeReference.resolvedType.isValidBinding() && qualifiedTypeReference instanceof JavadocQualifiedTypeReference) {
/* 1364 */           JavadocQualifiedTypeReference typeRef = (JavadocQualifiedTypeReference)node;
/* 1365 */           if (typeRef.packageBinding != null) {
/* 1366 */             return getPackageBinding(typeRef.packageBinding);
/*      */           }
/*      */         } 
/* 1369 */         return getTypeBinding(qualifiedTypeReference.resolvedType.leafComponentType());
/*      */       } 
/* 1371 */       if (index >= 0) {
/* 1372 */         BlockScope internalScope = (BlockScope)this.astNodesToBlockScope.get(name);
/* 1373 */         Binding binding = null;
/*      */         try {
/* 1375 */           if (internalScope == null) {
/* 1376 */             if (this.scope == null) return null; 
/* 1377 */             binding = this.scope.getTypeOrPackage(CharOperation.subarray(qualifiedTypeReference.tokens, 0, index));
/*      */           } else {
/* 1379 */             binding = internalScope.getTypeOrPackage(CharOperation.subarray(qualifiedTypeReference.tokens, 0, index));
/*      */           } 
/* 1381 */         } catch (AbortCompilation abortCompilation) {}
/*      */ 
/*      */         
/* 1384 */         if (binding instanceof PackageBinding)
/* 1385 */           return getPackageBinding((PackageBinding)binding); 
/* 1386 */         if (binding instanceof TypeBinding)
/*      */         {
/* 1388 */           return getTypeBinding((TypeBinding)binding);
/*      */         }
/* 1390 */         return null;
/*      */       }
/*      */     
/*      */     }
/* 1394 */     else if (node instanceof ImportReference) {
/* 1395 */       ImportReference importReference = (ImportReference)node;
/* 1396 */       int importReferenceLength = importReference.tokens.length;
/* 1397 */       boolean inModule = ((importReference.bits & 0x40000) != 0);
/* 1398 */       if (index >= 0) {
/* 1399 */         Binding binding = null;
/* 1400 */         if (this.scope == null) return null; 
/* 1401 */         if (importReferenceLength == index && !inModule) {
/*      */           try {
/* 1403 */             binding = this.scope.getImport(CharOperation.subarray(importReference.tokens, 0, index), ((importReference.bits & 0x20000) != 0), importReference.isStatic());
/* 1404 */           } catch (AbortCompilation abortCompilation) {}
/*      */         } else {
/*      */ 
/*      */           
/*      */           try {
/* 1409 */             binding = this.scope.getImport(inModule ? importReference.tokens : CharOperation.subarray(importReference.tokens, 0, index), true, importReference.isStatic());
/* 1410 */           } catch (AbortCompilation abortCompilation) {}
/*      */         } 
/*      */ 
/*      */         
/* 1414 */         if (binding != null) {
/* 1415 */           if (binding instanceof PackageBinding)
/* 1416 */             return getPackageBinding((PackageBinding)binding); 
/* 1417 */           if (binding instanceof TypeBinding)
/*      */           {
/* 1419 */             return getTypeBinding((TypeBinding)binding); } 
/* 1420 */           if (binding instanceof FieldBinding)
/*      */           {
/* 1422 */             return getVariableBinding((VariableBinding)binding); } 
/* 1423 */           if (binding instanceof MethodBinding)
/*      */           {
/* 1425 */             return getMethodBinding((MethodBinding)binding); } 
/* 1426 */           if (binding instanceof RecordComponentBinding)
/*      */           {
/* 1428 */             return getVariableBinding((VariableBinding)binding);
/*      */           }
/* 1430 */           return null;
/*      */         }
/*      */       
/*      */       } 
/* 1434 */     } else if (node instanceof CompilationUnitDeclaration) {
/* 1435 */       CompilationUnitDeclaration compilationUnitDeclaration = (CompilationUnitDeclaration)node;
/* 1436 */       TypeDeclaration[] types = compilationUnitDeclaration.types;
/* 1437 */       if (types == null || types.length == 0) {
/* 1438 */         return null;
/*      */       }
/* 1440 */       TypeDeclaration type = types[0];
/* 1441 */       if (type != null) {
/* 1442 */         ITypeBinding typeBinding = getTypeBinding((TypeBinding)type.binding);
/* 1443 */         if (typeBinding != null) {
/* 1444 */           return typeBinding.getPackage();
/*      */         }
/*      */       } 
/* 1447 */     } else if (node instanceof AbstractMethodDeclaration) {
/* 1448 */       AbstractMethodDeclaration methodDeclaration = (AbstractMethodDeclaration)node;
/* 1449 */       IMethodBinding methodBinding = getMethodBinding(methodDeclaration.binding);
/* 1450 */       if (methodBinding != null) {
/* 1451 */         return methodBinding;
/*      */       }
/* 1453 */     } else if (node instanceof ModuleReference) {
/* 1454 */       ModuleReference moduleReference = (ModuleReference)node;
/* 1455 */       IModuleBinding moduleBinding = getModuleBinding(moduleReference.binding);
/* 1456 */       if (moduleBinding != null) {
/* 1457 */         return moduleBinding;
/*      */       }
/* 1459 */     } else if (node instanceof ModuleDeclaration) {
/* 1460 */       ModuleDeclaration moduleDeclaration = (ModuleDeclaration)node;
/* 1461 */       IModuleBinding moduleBinding = getModuleBinding((ModuleBinding)moduleDeclaration.binding);
/* 1462 */       if (moduleBinding != null) {
/* 1463 */         return moduleBinding;
/*      */       }
/* 1465 */     } else if (node instanceof TypeDeclaration) {
/* 1466 */       TypeDeclaration typeDeclaration = (TypeDeclaration)node;
/* 1467 */       ITypeBinding typeBinding = getTypeBinding((TypeBinding)typeDeclaration.binding);
/* 1468 */       if (typeBinding != null)
/* 1469 */         return typeBinding; 
/*      */     } 
/* 1471 */     if (node instanceof SingleNameReference) {
/* 1472 */       SingleNameReference singleNameReference = (SingleNameReference)node;
/* 1473 */       if (singleNameReference.isTypeReference()) {
/* 1474 */         return getTypeBinding(singleNameReference.resolvedType);
/*      */       }
/*      */       
/* 1477 */       Binding binding = singleNameReference.binding;
/* 1478 */       if (binding != null) {
/* 1479 */         if (binding.isValidBinding()) {
/* 1480 */           return getVariableBinding((VariableBinding)binding);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1485 */         if (binding instanceof ProblemFieldBinding) {
/* 1486 */           ReferenceBinding declaringClass; FieldBinding exactBinding; ProblemFieldBinding problemFieldBinding = (ProblemFieldBinding)binding;
/* 1487 */           switch (problemFieldBinding.problemId()) {
/*      */             case 2:
/*      */             case 6:
/*      */             case 7:
/* 1491 */               declaringClass = problemFieldBinding.declaringClass;
/* 1492 */               exactBinding = declaringClass.getField(problemFieldBinding.name, true);
/* 1493 */               if (exactBinding != null && 
/* 1494 */                 exactBinding.type != null) {
/* 1495 */                 IVariableBinding variableBinding2 = (IVariableBinding)this.bindingTables.compilerBindingsToASTBindings.get(exactBinding);
/* 1496 */                 if (variableBinding2 != null) {
/* 1497 */                   return variableBinding2;
/*      */                 }
/* 1499 */                 variableBinding2 = new VariableBinding(this, (VariableBinding)exactBinding);
/* 1500 */                 this.bindingTables.compilerBindingsToASTBindings.put(exactBinding, variableBinding2);
/* 1501 */                 return variableBinding2;
/*      */               } 
/*      */               break;
/*      */           } 
/*      */ 
/*      */         
/*      */         } 
/*      */       } 
/*      */     } else {
/* 1510 */       if (node instanceof QualifiedSuperReference) {
/* 1511 */         QualifiedSuperReference qualifiedSuperReference = (QualifiedSuperReference)node;
/* 1512 */         return getTypeBinding(qualifiedSuperReference.qualification.resolvedType);
/* 1513 */       }  if (node instanceof LocalDeclaration)
/* 1514 */         return (name.getAST().apiLevel() >= 10 && name instanceof SimpleName && ((SimpleName)name).isVar()) ? 
/* 1515 */           resolveTypeBindingForName(name) : 
/* 1516 */           getVariableBinding((VariableBinding)((LocalDeclaration)node).binding); 
/* 1517 */       if (node instanceof JavadocFieldReference) {
/* 1518 */         JavadocFieldReference fieldRef = (JavadocFieldReference)node;
/* 1519 */         if (fieldRef.methodBinding != null) {
/* 1520 */           return getMethodBinding(fieldRef.methodBinding);
/*      */         }
/* 1522 */         return getVariableBinding((VariableBinding)fieldRef.binding);
/* 1523 */       }  if (node instanceof FieldReference)
/* 1524 */         return getVariableBinding((VariableBinding)((FieldReference)node).binding); 
/* 1525 */       if (node instanceof SingleTypeReference) {
/* 1526 */         if (node instanceof JavadocSingleTypeReference) {
/* 1527 */           JavadocSingleTypeReference typeRef = (JavadocSingleTypeReference)node;
/* 1528 */           if (typeRef.packageBinding != null) {
/* 1529 */             return getPackageBinding(typeRef.packageBinding);
/*      */           }
/*      */         } 
/* 1532 */         SingleTypeReference singleTypeReference = (SingleTypeReference)node;
/* 1533 */         TypeBinding binding = singleTypeReference.resolvedType;
/* 1534 */         if (binding == null) {
/* 1535 */           return null;
/*      */         }
/* 1537 */         return getTypeBinding(binding.leafComponentType());
/* 1538 */       }  if (node instanceof FieldDeclaration) {
/* 1539 */         FieldDeclaration fieldDeclaration = (FieldDeclaration)node;
/* 1540 */         return getVariableBinding((VariableBinding)fieldDeclaration.binding);
/* 1541 */       }  if (node instanceof MessageSend) {
/* 1542 */         MessageSend messageSend = (MessageSend)node;
/* 1543 */         return getMethodBinding(messageSend.binding);
/* 1544 */       }  if (node instanceof AllocationExpression) {
/* 1545 */         AllocationExpression allocation = (AllocationExpression)node;
/* 1546 */         return getMethodBinding(allocation.binding);
/* 1547 */       }  if (node instanceof JavadocImplicitTypeReference) {
/* 1548 */         JavadocImplicitTypeReference implicitRef = (JavadocImplicitTypeReference)node;
/* 1549 */         return getTypeBinding(implicitRef.resolvedType);
/* 1550 */       }  if (node instanceof TypeParameter) {
/* 1551 */         TypeParameter typeParameter = (TypeParameter)node;
/* 1552 */         return getTypeBinding((TypeBinding)typeParameter.binding);
/* 1553 */       }  if (node instanceof MemberValuePair) {
/* 1554 */         MemberValuePair memberValuePair = (MemberValuePair)node;
/* 1555 */         return getMethodBinding(memberValuePair.binding);
/* 1556 */       }  if (node instanceof ReferenceExpression) {
/* 1557 */         ReferenceExpression referenceExpression = (ReferenceExpression)node;
/* 1558 */         return getMethodBinding(referenceExpression.getMethodBinding());
/* 1559 */       }  if (node instanceof RecordComponent) {
/* 1560 */         RecordComponent recordComponent = (RecordComponent)node;
/* 1561 */         return getVariableBinding((VariableBinding)recordComponent.binding);
/*      */       } 
/* 1563 */     }  return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IPackageBinding resolvePackage(PackageDeclaration pkg) {
/* 1568 */     if (this.scope == null) return null; 
/*      */     try {
/* 1570 */       ASTNode node = (ASTNode)this.newAstToOldAst.get(pkg);
/* 1571 */       if (node instanceof ImportReference) {
/* 1572 */         ImportReference importReference = (ImportReference)node;
/* 1573 */         Binding binding = this.scope.getOnlyPackage(CharOperation.subarray(importReference.tokens, 0, importReference.tokens.length));
/* 1574 */         if (binding != null && binding.isValidBinding()) {
/* 1575 */           PackageBinding packageBinding; if (binding instanceof ReferenceBinding) {
/*      */             
/* 1577 */             ReferenceBinding referenceBinding = (ReferenceBinding)binding;
/* 1578 */             packageBinding = referenceBinding.fPackage;
/*      */           } 
/* 1580 */           if (packageBinding instanceof PackageBinding) {
/* 1581 */             IPackageBinding iPackageBinding = getPackageBinding(packageBinding);
/* 1582 */             if (iPackageBinding == null) {
/* 1583 */               return null;
/*      */             }
/* 1585 */             this.bindingsToAstNodes.put(iPackageBinding, pkg);
/* 1586 */             String key = iPackageBinding.getKey();
/* 1587 */             if (key != null) {
/* 1588 */               this.bindingTables.bindingKeysToBindings.put(key, iPackageBinding);
/*      */             }
/* 1590 */             return iPackageBinding;
/*      */           } 
/*      */         } 
/*      */       } 
/* 1594 */     } catch (AbortCompilation abortCompilation) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1599 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IBinding resolveReference(MemberRef ref) {
/* 1604 */     Expression expression = (Expression)this.newAstToOldAst.get(ref);
/* 1605 */     if (expression instanceof TypeReference)
/* 1606 */       return getTypeBinding(expression.resolvedType); 
/* 1607 */     if (expression instanceof JavadocFieldReference) {
/* 1608 */       JavadocFieldReference fieldRef = (JavadocFieldReference)expression;
/* 1609 */       if (fieldRef.methodBinding != null) {
/* 1610 */         return getMethodBinding(fieldRef.methodBinding);
/*      */       }
/* 1612 */       return getVariableBinding((VariableBinding)fieldRef.binding);
/*      */     } 
/* 1614 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IMemberValuePairBinding resolveMemberValuePair(MemberValuePair memberValuePair) {
/* 1619 */     MemberValuePair valuePair = (MemberValuePair)this.newAstToOldAst.get(memberValuePair);
/* 1620 */     if (valuePair != null) {
/* 1621 */       return getMemberValuePairBinding(valuePair.compilerElementPair);
/*      */     }
/* 1623 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   IModuleBinding resolveModule(ModuleDeclaration module) {
/* 1632 */     Object oldNode = this.newAstToOldAst.get(module);
/* 1633 */     if (oldNode instanceof ModuleDeclaration) {
/* 1634 */       ModuleDeclaration moduleDeclaration = (ModuleDeclaration)oldNode;
/* 1635 */       IModuleBinding moduleBinding = getModuleBinding((ModuleBinding)moduleDeclaration.binding);
/* 1636 */       if (moduleBinding == null) {
/* 1637 */         return null;
/*      */       }
/* 1639 */       this.bindingsToAstNodes.put(moduleBinding, module);
/* 1640 */       String key = moduleBinding.getKey();
/* 1641 */       if (key != null) {
/* 1642 */         this.bindingTables.bindingKeysToBindings.put(key, moduleBinding);
/*      */       }
/* 1644 */       return moduleBinding;
/*      */     } 
/*      */     
/* 1647 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IBinding resolveReference(MethodRef ref) {
/* 1652 */     Expression expression = (Expression)this.newAstToOldAst.get(ref);
/* 1653 */     if (expression instanceof JavadocMessageSend) {
/* 1654 */       return getMethodBinding(((JavadocMessageSend)expression).binding);
/*      */     }
/* 1656 */     if (expression instanceof JavadocAllocationExpression) {
/* 1657 */       return getMethodBinding(((JavadocAllocationExpression)expression).binding);
/*      */     }
/* 1659 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   ITypeBinding resolveType(AnnotationTypeDeclaration type) {
/* 1664 */     Object node = this.newAstToOldAst.get(type);
/* 1665 */     if (node instanceof TypeDeclaration) {
/* 1666 */       TypeDeclaration typeDeclaration = (TypeDeclaration)node;
/* 1667 */       ITypeBinding typeBinding = getTypeBinding((TypeBinding)typeDeclaration.binding);
/* 1668 */       if (typeBinding == null) {
/* 1669 */         return null;
/*      */       }
/* 1671 */       this.bindingsToAstNodes.put(typeBinding, type);
/* 1672 */       String key = typeBinding.getKey();
/* 1673 */       if (key != null) {
/* 1674 */         this.bindingTables.bindingKeysToBindings.put(key, typeBinding);
/*      */       }
/* 1676 */       return typeBinding;
/*      */     } 
/* 1678 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized ITypeBinding resolveType(AnonymousClassDeclaration type) {
/* 1683 */     ASTNode node = (ASTNode)this.newAstToOldAst.get(type);
/* 1684 */     if (node != null && (node.bits & 0x200) != 0) {
/* 1685 */       TypeDeclaration anonymousLocalTypeDeclaration = (TypeDeclaration)node;
/* 1686 */       IBinding declaringMember = getDeclaringMember((ASTNode)anonymousLocalTypeDeclaration, (Scope)anonymousLocalTypeDeclaration.scope);
/* 1687 */       ITypeBinding typeBinding = internalGetTypeBinding((TypeBinding)anonymousLocalTypeDeclaration.binding, declaringMember);
/* 1688 */       if (typeBinding == null) {
/* 1689 */         return null;
/*      */       }
/* 1691 */       this.bindingsToAstNodes.put(typeBinding, type);
/* 1692 */       String key = typeBinding.getKey();
/* 1693 */       if (key != null) {
/* 1694 */         this.bindingTables.bindingKeysToBindings.put(key, typeBinding);
/*      */       }
/* 1696 */       return typeBinding;
/*      */     } 
/* 1698 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   ITypeBinding resolveType(EnumDeclaration type) {
/* 1703 */     Object node = this.newAstToOldAst.get(type);
/* 1704 */     if (node instanceof TypeDeclaration) {
/* 1705 */       TypeDeclaration typeDeclaration = (TypeDeclaration)node;
/* 1706 */       ITypeBinding typeBinding = getTypeBinding((TypeBinding)typeDeclaration.binding);
/* 1707 */       if (typeBinding == null) {
/* 1708 */         return null;
/*      */       }
/* 1710 */       this.bindingsToAstNodes.put(typeBinding, type);
/* 1711 */       String key = typeBinding.getKey();
/* 1712 */       if (key != null) {
/* 1713 */         this.bindingTables.bindingKeysToBindings.put(key, typeBinding);
/*      */       }
/* 1715 */       return typeBinding;
/*      */     } 
/* 1717 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   ITypeBinding resolveType(RecordDeclaration type) {
/* 1722 */     Object node = this.newAstToOldAst.get(type);
/* 1723 */     if (node instanceof TypeDeclaration) {
/* 1724 */       TypeDeclaration typeDeclaration = (TypeDeclaration)node;
/* 1725 */       ITypeBinding typeBinding = getTypeBinding((TypeBinding)typeDeclaration.binding);
/* 1726 */       if (typeBinding == null) {
/* 1727 */         return null;
/*      */       }
/* 1729 */       this.bindingsToAstNodes.put(typeBinding, type);
/* 1730 */       String key = typeBinding.getKey();
/* 1731 */       if (key != null) {
/* 1732 */         this.bindingTables.bindingKeysToBindings.put(key, typeBinding);
/*      */       }
/* 1734 */       return typeBinding;
/*      */     } 
/* 1736 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized ITypeBinding resolveType(Type type) {
/* 1744 */     ASTNode node = (ASTNode)this.newAstToOldAst.get(type);
/* 1745 */     TypeBinding binding = null;
/* 1746 */     if (type.getAST().apiLevel() >= 10 && type.isVar()) {
/* 1747 */       return resolveTypeBindingForName(((SimpleType)type).getName());
/*      */     }
/* 1749 */     if (node != null) {
/* 1750 */       TypeReference typeReference; if (node instanceof Receiver) {
/* 1751 */         typeReference = ((Receiver)node).type;
/*      */       }
/* 1753 */       if (typeReference instanceof ParameterizedQualifiedTypeReference) {
/* 1754 */         ReferenceBinding referenceBinding; int index; ParameterizedQualifiedTypeReference parameterizedQualifiedTypeReference = (ParameterizedQualifiedTypeReference)typeReference;
/* 1755 */         TypeBinding typeBinding = parameterizedQualifiedTypeReference.resolvedType;
/*      */         
/* 1757 */         if (typeBinding == null) return null; 
/* 1758 */         if (type.isArrayType()) {
/* 1759 */           if (this.scope == null) {
/* 1760 */             return null;
/*      */           }
/* 1762 */           ArrayType arrayType = (ArrayType)type;
/* 1763 */           ArrayBinding arrayBinding = (ArrayBinding)typeBinding;
/* 1764 */           int dimensions = arrayType.getDimensions();
/* 1765 */           boolean isVarargs = parameterizedQualifiedTypeReference.isVarargs();
/* 1766 */           if (dimensions == arrayBinding.dimensions)
/* 1767 */             return getTypeBinding((TypeBinding)arrayBinding); 
/* 1768 */           return getTypeBinding((TypeBinding)this.scope.createArrayType(arrayBinding.leafComponentType, dimensions, getTypeAnnotations(dimensions, arrayBinding, isVarargs)));
/*      */         } 
/* 1770 */         if (typeBinding.isArrayType())
/*      */         {
/* 1772 */           typeBinding = ((ArrayBinding)typeBinding).leafComponentType;
/*      */         }
/*      */         
/* 1775 */         if (type.isQualifiedType()) {
/* 1776 */           index = ((QualifiedType)type).index;
/* 1777 */         } else if (type.isParameterizedType()) {
/* 1778 */           index = ((ParameterizedType)type).index;
/*      */         } else {
/* 1780 */           index = 1;
/*      */         } 
/* 1782 */         int numberOfTypeArgumentsNotNull = getTypeCount(parameterizedQualifiedTypeReference);
/* 1783 */         if (index != numberOfTypeArgumentsNotNull) {
/* 1784 */           int i = numberOfTypeArgumentsNotNull;
/* 1785 */           while (i != index) {
/* 1786 */             referenceBinding = typeBinding.enclosingType();
/* 1787 */             i--;
/*      */           } 
/* 1789 */           ReferenceBinding referenceBinding1 = referenceBinding;
/*      */         } else {
/* 1791 */           ReferenceBinding referenceBinding1 = referenceBinding;
/*      */         } 
/* 1793 */       } else if (typeReference instanceof TypeReference) {
/* 1794 */         if (type instanceof SimpleType && typeReference instanceof QualifiedTypeReference)
/* 1795 */           return resolveTypeBindingForName(((SimpleType)type).getName()); 
/* 1796 */         if (type instanceof QualifiedType)
/* 1797 */           return resolveTypeBindingForName(((QualifiedType)type).getName()); 
/* 1798 */         if (type instanceof NameQualifiedType) {
/* 1799 */           return resolveTypeBindingForName(((NameQualifiedType)type).getName());
/*      */         }
/* 1801 */         TypeReference typeReference1 = typeReference;
/* 1802 */         binding = typeReference1.resolvedType;
/* 1803 */       } else if (typeReference instanceof SingleNameReference && ((SingleNameReference)typeReference).isTypeReference()) {
/* 1804 */         binding = ((SingleNameReference)typeReference).resolvedType;
/* 1805 */       } else if (typeReference instanceof QualifiedNameReference && ((QualifiedNameReference)typeReference).isTypeReference()) {
/* 1806 */         binding = ((QualifiedNameReference)typeReference).resolvedType;
/* 1807 */       } else if (typeReference instanceof ArrayAllocationExpression) {
/* 1808 */         binding = ((ArrayAllocationExpression)typeReference).resolvedType;
/*      */       } 
/* 1810 */       if (binding != null) {
/* 1811 */         if (type.isArrayType()) {
/* 1812 */           ArrayType arrayType = (ArrayType)type;
/* 1813 */           if (this.scope == null) {
/* 1814 */             return null;
/*      */           }
/* 1816 */           ArrayBinding arrayBinding = (ArrayBinding)binding;
/* 1817 */           int dimensions = arrayType.getDimensions();
/* 1818 */           boolean isVarargs = (typeReference instanceof TypeReference && typeReference.isVarargs());
/* 1819 */           if (dimensions == arrayBinding.dimensions)
/* 1820 */             return getTypeBinding((TypeBinding)arrayBinding); 
/* 1821 */           return getTypeBinding((TypeBinding)this.scope.createArrayType(arrayBinding.leafComponentType, dimensions, getTypeAnnotations(dimensions, arrayBinding, isVarargs)));
/* 1822 */         }  if (binding.isArrayType()) {
/*      */           
/* 1824 */           ArrayBinding arrayBinding = (ArrayBinding)binding;
/* 1825 */           return getTypeBinding(arrayBinding.leafComponentType);
/*      */         } 
/* 1827 */         return getTypeBinding(binding);
/*      */       } 
/* 1829 */     } else if (type.isPrimitiveType()) {
/*      */ 
/*      */ 
/*      */       
/* 1833 */       if (((PrimitiveType)type).getPrimitiveTypeCode() == PrimitiveType.VOID) {
/* 1834 */         return getTypeBinding((TypeBinding)TypeBinding.VOID);
/*      */       }
/*      */     } 
/* 1837 */     return null;
/*      */   }
/*      */   
/*      */   private AnnotationBinding[] getTypeAnnotations(int dimensions, ArrayBinding arrayBinding, boolean isVarargs) {
/* 1841 */     AnnotationBinding[] oldies = arrayBinding.getTypeAnnotations();
/* 1842 */     AnnotationBinding[] newbies = Binding.NO_ANNOTATIONS;
/*      */     
/* 1844 */     int extendedDimensions = arrayBinding.dimensions - dimensions - (isVarargs ? 1 : 0);
/*      */     int i, length;
/* 1846 */     for (i = 0, length = (oldies == null) ? 0 : oldies.length; i < length && extendedDimensions > 0; i++) {
/* 1847 */       if (oldies[i] == null)
/* 1848 */         extendedDimensions--; 
/*      */     } 
/* 1850 */     int cells = 0;
/* 1851 */     for (int j = i; j < length && dimensions > 0; j++) {
/* 1852 */       if (oldies[j] == null)
/* 1853 */         dimensions--; 
/* 1854 */       cells++;
/*      */     } 
/* 1856 */     if (cells > 0)
/* 1857 */       System.arraycopy(oldies, i, newbies = new AnnotationBinding[cells], 0, cells); 
/* 1858 */     return newbies;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized ITypeBinding resolveType(TypeDeclaration type) {
/* 1863 */     Object node = this.newAstToOldAst.get(type);
/* 1864 */     if (node instanceof TypeDeclaration) {
/* 1865 */       TypeDeclaration typeDeclaration = (TypeDeclaration)node;
/* 1866 */       IBinding declaringMember = getDeclaringMember((ASTNode)typeDeclaration, (Scope)typeDeclaration.scope);
/* 1867 */       ITypeBinding typeBinding = internalGetTypeBinding((TypeBinding)typeDeclaration.binding, declaringMember);
/* 1868 */       if (typeBinding == null) {
/* 1869 */         return null;
/*      */       }
/* 1871 */       this.bindingsToAstNodes.put(typeBinding, type);
/* 1872 */       String key = typeBinding.getKey();
/* 1873 */       if (key != null) {
/* 1874 */         this.bindingTables.bindingKeysToBindings.put(key, typeBinding);
/*      */       }
/* 1876 */       return typeBinding;
/*      */     } 
/* 1878 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized ITypeBinding resolveTypeParameter(TypeParameter typeParameter) {
/* 1883 */     Object node = this.newAstToOldAst.get(typeParameter);
/* 1884 */     if (node instanceof TypeParameter) {
/* 1885 */       TypeParameter typeParameter2 = (TypeParameter)node;
/* 1886 */       ITypeBinding typeBinding = getTypeBinding((TypeBinding)typeParameter2.binding);
/* 1887 */       if (typeBinding == null) {
/* 1888 */         return null;
/*      */       }
/* 1890 */       this.bindingsToAstNodes.put(typeBinding, typeParameter);
/* 1891 */       String key = typeBinding.getKey();
/* 1892 */       if (key != null) {
/* 1893 */         this.bindingTables.bindingKeysToBindings.put(key, typeBinding);
/*      */       }
/* 1895 */       return typeBinding;
/*      */     } 
/* 1897 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IVariableBinding resolveVariable(EnumConstantDeclaration enumConstant) {
/* 1902 */     Object node = this.newAstToOldAst.get(enumConstant);
/* 1903 */     if (node instanceof FieldDeclaration) {
/* 1904 */       FieldDeclaration fieldDeclaration = (FieldDeclaration)node;
/* 1905 */       IVariableBinding variableBinding = getVariableBinding((VariableBinding)fieldDeclaration.binding);
/* 1906 */       if (variableBinding == null) {
/* 1907 */         return null;
/*      */       }
/* 1909 */       this.bindingsToAstNodes.put(variableBinding, enumConstant);
/* 1910 */       String key = variableBinding.getKey();
/* 1911 */       if (key != null) {
/* 1912 */         this.bindingTables.bindingKeysToBindings.put(key, variableBinding);
/*      */       }
/* 1914 */       return variableBinding;
/*      */     } 
/* 1916 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IVariableBinding resolveVariable(VariableDeclaration variable) {
/* 1921 */     Object node = this.newAstToOldAst.get(variable);
/* 1922 */     if (node instanceof AbstractVariableDeclaration) {
/* 1923 */       AbstractVariableDeclaration abstractVariableDeclaration = (AbstractVariableDeclaration)node;
/* 1924 */       IVariableBinding variableBinding = null;
/* 1925 */       if (abstractVariableDeclaration instanceof FieldDeclaration) {
/* 1926 */         FieldDeclaration fieldDeclaration = (FieldDeclaration)abstractVariableDeclaration;
/* 1927 */         variableBinding = getVariableBinding((VariableBinding)fieldDeclaration.binding, variable);
/* 1928 */       } else if (abstractVariableDeclaration instanceof RecordComponent) {
/* 1929 */         RecordComponent recordComponent = (RecordComponent)abstractVariableDeclaration;
/* 1930 */         variableBinding = getVariableBinding((VariableBinding)recordComponent.binding, variable);
/*      */       } else {
/* 1932 */         variableBinding = getVariableBinding((VariableBinding)((LocalDeclaration)abstractVariableDeclaration).binding, variable);
/*      */       } 
/* 1934 */       if (variableBinding == null) {
/* 1935 */         return null;
/*      */       }
/* 1937 */       this.bindingsToAstNodes.put(variableBinding, variable);
/* 1938 */       String key = variableBinding.getKey();
/* 1939 */       if (key != null) {
/* 1940 */         this.bindingTables.bindingKeysToBindings.put(key, variableBinding);
/*      */       }
/* 1942 */       return variableBinding;
/*      */     } 
/* 1944 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized ITypeBinding resolveWellKnownType(String name) {
/* 1949 */     if (this.scope == null) return null; 
/* 1950 */     ITypeBinding typeBinding = null;
/*      */     try {
/* 1952 */       if ("boolean".equals(name) || 
/* 1953 */         "char".equals(name) || 
/* 1954 */         "byte".equals(name) || 
/* 1955 */         "short".equals(name) || 
/* 1956 */         "int".equals(name) || 
/* 1957 */         "long".equals(name) || 
/* 1958 */         "float".equals(name) || 
/* 1959 */         "double".equals(name) || 
/* 1960 */         "void".equals(name)) {
/* 1961 */         typeBinding = getTypeBinding(Scope.getBaseType(name.toCharArray()));
/* 1962 */       } else if ("java.lang.Object".equals(name)) {
/* 1963 */         typeBinding = getTypeBinding((TypeBinding)this.scope.getJavaLangObject());
/* 1964 */       } else if ("java.lang.String".equals(name)) {
/* 1965 */         typeBinding = getTypeBinding((TypeBinding)this.scope.getJavaLangString());
/* 1966 */       } else if ("java.lang.StringBuffer".equals(name)) {
/* 1967 */         typeBinding = getTypeBinding(this.scope.getType(TypeConstants.JAVA_LANG_STRINGBUFFER, 3));
/* 1968 */       } else if ("java.lang.Throwable".equals(name)) {
/* 1969 */         typeBinding = getTypeBinding((TypeBinding)this.scope.getJavaLangThrowable());
/* 1970 */       } else if ("java.lang.Exception".equals(name)) {
/* 1971 */         typeBinding = getTypeBinding(this.scope.getType(TypeConstants.JAVA_LANG_EXCEPTION, 3));
/* 1972 */       } else if ("java.lang.RuntimeException".equals(name)) {
/* 1973 */         typeBinding = getTypeBinding(this.scope.getType(TypeConstants.JAVA_LANG_RUNTIMEEXCEPTION, 3));
/* 1974 */       } else if ("java.lang.Error".equals(name)) {
/* 1975 */         typeBinding = getTypeBinding(this.scope.getType(TypeConstants.JAVA_LANG_ERROR, 3));
/* 1976 */       } else if ("java.lang.Class".equals(name)) {
/* 1977 */         typeBinding = getTypeBinding((TypeBinding)this.scope.getJavaLangClass());
/* 1978 */       } else if ("java.lang.Cloneable".equals(name)) {
/* 1979 */         typeBinding = getTypeBinding((TypeBinding)this.scope.getJavaLangCloneable());
/* 1980 */       } else if ("java.io.Serializable".equals(name)) {
/* 1981 */         typeBinding = getTypeBinding((TypeBinding)this.scope.getJavaIoSerializable());
/* 1982 */       } else if ("java.lang.Boolean".equals(name)) {
/* 1983 */         typeBinding = getTypeBinding(this.scope.getType(TypeConstants.JAVA_LANG_BOOLEAN, 3));
/* 1984 */       } else if ("java.lang.Byte".equals(name)) {
/* 1985 */         typeBinding = getTypeBinding(this.scope.getType(TypeConstants.JAVA_LANG_BYTE, 3));
/* 1986 */       } else if ("java.lang.Character".equals(name)) {
/* 1987 */         typeBinding = getTypeBinding(this.scope.getType(TypeConstants.JAVA_LANG_CHARACTER, 3));
/* 1988 */       } else if ("java.lang.Double".equals(name)) {
/* 1989 */         typeBinding = getTypeBinding(this.scope.getType(TypeConstants.JAVA_LANG_DOUBLE, 3));
/* 1990 */       } else if ("java.lang.Float".equals(name)) {
/* 1991 */         typeBinding = getTypeBinding(this.scope.getType(TypeConstants.JAVA_LANG_FLOAT, 3));
/* 1992 */       } else if ("java.lang.Integer".equals(name)) {
/* 1993 */         typeBinding = getTypeBinding(this.scope.getType(TypeConstants.JAVA_LANG_INTEGER, 3));
/* 1994 */       } else if ("java.lang.Long".equals(name)) {
/* 1995 */         typeBinding = getTypeBinding(this.scope.getType(TypeConstants.JAVA_LANG_LONG, 3));
/* 1996 */       } else if ("java.lang.Short".equals(name)) {
/* 1997 */         typeBinding = getTypeBinding(this.scope.getType(TypeConstants.JAVA_LANG_SHORT, 3));
/* 1998 */       } else if ("java.lang.Void".equals(name)) {
/* 1999 */         typeBinding = getTypeBinding(this.scope.getType(TypeConstants.JAVA_LANG_VOID, 3));
/* 2000 */       } else if ("java.lang.AssertionError".equals(name)) {
/* 2001 */         typeBinding = getTypeBinding(this.scope.getType(TypeConstants.JAVA_LANG_ASSERTIONERROR, 3));
/*      */       } 
/* 2003 */     } catch (AbortCompilation abortCompilation) {}
/*      */ 
/*      */     
/* 2006 */     if (typeBinding != null && !typeBinding.isRecovered()) {
/* 2007 */       return typeBinding;
/*      */     }
/* 2009 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized IAnnotationBinding resolveAnnotation(Annotation domASTNode) {
/* 2014 */     Object oldNode = this.newAstToOldAst.get(domASTNode);
/* 2015 */     if (oldNode instanceof Annotation) {
/* 2016 */       Annotation internalAstNode = 
/* 2017 */         (Annotation)oldNode;
/*      */       
/* 2019 */       IAnnotationBinding domAnnotation = getAnnotationInstance(internalAstNode.getCompilerAnnotation());
/* 2020 */       if (domAnnotation == null)
/* 2021 */         return null; 
/* 2022 */       this.bindingsToAstNodes.put(domAnnotation, domASTNode);
/* 2023 */       return domAnnotation;
/*      */     } 
/* 2025 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public CompilationUnitScope scope() {
/* 2030 */     return this.scope;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized void store(ASTNode node, ASTNode oldASTNode) {
/* 2035 */     this.newAstToOldAst.put(node, oldASTNode);
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized void updateKey(ASTNode node, ASTNode newNode) {
/* 2040 */     Object astNode = this.newAstToOldAst.remove(node);
/* 2041 */     if (astNode != null) {
/* 2042 */       this.newAstToOldAst.put(newNode, astNode);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   ITypeBinding resolveArrayType(ITypeBinding typeBinding, int dimensions) {
/* 2048 */     if (typeBinding instanceof RecoveredTypeBinding) throw new IllegalArgumentException("Cannot be called on a recovered type binding"); 
/* 2049 */     ITypeBinding leafComponentType = typeBinding;
/* 2050 */     int actualDimensions = dimensions;
/* 2051 */     if (typeBinding.isArray()) {
/* 2052 */       leafComponentType = typeBinding.getElementType();
/* 2053 */       actualDimensions += typeBinding.getDimensions();
/*      */     } 
/* 2055 */     if (!(leafComponentType instanceof TypeBinding)) return null; 
/* 2056 */     TypeBinding leafTypeBinding = 
/* 2057 */       ((TypeBinding)leafComponentType).binding;
/* 2058 */     if (leafTypeBinding instanceof org.eclipse.jdt.internal.compiler.lookup.VoidTypeBinding) {
/* 2059 */       throw new IllegalArgumentException();
/*      */     }
/* 2061 */     if (typeBinding.isArray()) {
/* 2062 */       return getTypeBinding((TypeBinding)lookupEnvironment().createArrayType(
/* 2063 */             leafTypeBinding, 
/* 2064 */             actualDimensions, 
/* 2065 */             insertAnnotations(((TypeBinding)typeBinding).binding.getTypeAnnotations(), dimensions)));
/*      */     }
/* 2067 */     return getTypeBinding((TypeBinding)lookupEnvironment().createArrayType(
/* 2068 */           leafTypeBinding, 
/* 2069 */           actualDimensions));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private AnnotationBinding[] insertAnnotations(AnnotationBinding[] annots, int dimensions) {
/* 2075 */     if (dimensions == 0 || annots == null || annots.length == 0) {
/* 2076 */       return annots;
/*      */     }
/* 2078 */     int index = 0;
/* 2079 */     if (dimensions < 0) {
/* 2080 */       for (int i = 0; i < annots.length; i++) {
/* 2081 */         index++;
/* 2082 */         if (annots[i] == null && 
/* 2083 */           ++dimensions == 0)
/*      */           break; 
/*      */       } 
/* 2086 */       if (dimensions < 0) dimensions = 0; 
/*      */     } 
/* 2088 */     AnnotationBinding[] newAnnots = 
/* 2089 */       new AnnotationBinding[annots.length - index + dimensions];
/*      */     
/* 2091 */     System.arraycopy(annots, index, newAnnots, dimensions, annots.length - index);
/* 2092 */     return newAnnots;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\DefaultBindingResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */