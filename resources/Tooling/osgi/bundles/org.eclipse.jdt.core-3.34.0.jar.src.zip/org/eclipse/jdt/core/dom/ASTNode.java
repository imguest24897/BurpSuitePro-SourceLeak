/*      */ package org.eclipse.jdt.core.dom;
/*      */ 
/*      */ import java.util.AbstractList;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.eclipse.jdt.internal.core.dom.NaiveASTFlattener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class ASTNode
/*      */ {
/*      */   public static final int ANONYMOUS_CLASS_DECLARATION = 1;
/*      */   public static final int ARRAY_ACCESS = 2;
/*      */   public static final int ARRAY_CREATION = 3;
/*      */   public static final int ARRAY_INITIALIZER = 4;
/*      */   public static final int ARRAY_TYPE = 5;
/*      */   public static final int ASSERT_STATEMENT = 6;
/*      */   public static final int ASSIGNMENT = 7;
/*      */   public static final int BLOCK = 8;
/*      */   public static final int BOOLEAN_LITERAL = 9;
/*      */   public static final int BREAK_STATEMENT = 10;
/*      */   public static final int CAST_EXPRESSION = 11;
/*      */   public static final int CATCH_CLAUSE = 12;
/*      */   public static final int CHARACTER_LITERAL = 13;
/*      */   public static final int CLASS_INSTANCE_CREATION = 14;
/*      */   public static final int COMPILATION_UNIT = 15;
/*      */   public static final int CONDITIONAL_EXPRESSION = 16;
/*      */   public static final int CONSTRUCTOR_INVOCATION = 17;
/*      */   public static final int CONTINUE_STATEMENT = 18;
/*      */   public static final int DO_STATEMENT = 19;
/*      */   public static final int EMPTY_STATEMENT = 20;
/*      */   public static final int EXPRESSION_STATEMENT = 21;
/*      */   public static final int FIELD_ACCESS = 22;
/*      */   public static final int FIELD_DECLARATION = 23;
/*      */   public static final int FOR_STATEMENT = 24;
/*      */   public static final int IF_STATEMENT = 25;
/*      */   public static final int IMPORT_DECLARATION = 26;
/*      */   public static final int INFIX_EXPRESSION = 27;
/*      */   public static final int INITIALIZER = 28;
/*      */   public static final int JAVADOC = 29;
/*      */   public static final int LABELED_STATEMENT = 30;
/*      */   public static final int METHOD_DECLARATION = 31;
/*      */   public static final int METHOD_INVOCATION = 32;
/*      */   public static final int NULL_LITERAL = 33;
/*      */   public static final int NUMBER_LITERAL = 34;
/*      */   public static final int PACKAGE_DECLARATION = 35;
/*      */   public static final int PARENTHESIZED_EXPRESSION = 36;
/*      */   public static final int POSTFIX_EXPRESSION = 37;
/*      */   public static final int PREFIX_EXPRESSION = 38;
/*      */   public static final int PRIMITIVE_TYPE = 39;
/*      */   public static final int QUALIFIED_NAME = 40;
/*      */   public static final int RETURN_STATEMENT = 41;
/*      */   public static final int SIMPLE_NAME = 42;
/*      */   public static final int SIMPLE_TYPE = 43;
/*      */   public static final int SINGLE_VARIABLE_DECLARATION = 44;
/*      */   public static final int STRING_LITERAL = 45;
/*      */   public static final int SUPER_CONSTRUCTOR_INVOCATION = 46;
/*      */   public static final int SUPER_FIELD_ACCESS = 47;
/*      */   public static final int SUPER_METHOD_INVOCATION = 48;
/*      */   public static final int SWITCH_CASE = 49;
/*      */   public static final int SWITCH_STATEMENT = 50;
/*      */   public static final int SYNCHRONIZED_STATEMENT = 51;
/*      */   public static final int THIS_EXPRESSION = 52;
/*      */   public static final int THROW_STATEMENT = 53;
/*      */   public static final int TRY_STATEMENT = 54;
/*      */   public static final int TYPE_DECLARATION = 55;
/*      */   public static final int TYPE_DECLARATION_STATEMENT = 56;
/*      */   public static final int TYPE_LITERAL = 57;
/*      */   public static final int VARIABLE_DECLARATION_EXPRESSION = 58;
/*      */   public static final int VARIABLE_DECLARATION_FRAGMENT = 59;
/*      */   public static final int VARIABLE_DECLARATION_STATEMENT = 60;
/*      */   public static final int WHILE_STATEMENT = 61;
/*      */   public static final int INSTANCEOF_EXPRESSION = 62;
/*      */   public static final int LINE_COMMENT = 63;
/*      */   public static final int BLOCK_COMMENT = 64;
/*      */   public static final int TAG_ELEMENT = 65;
/*      */   public static final int TEXT_ELEMENT = 66;
/*      */   public static final int MEMBER_REF = 67;
/*      */   public static final int METHOD_REF = 68;
/*      */   public static final int METHOD_REF_PARAMETER = 69;
/*      */   public static final int ENHANCED_FOR_STATEMENT = 70;
/*      */   public static final int ENUM_DECLARATION = 71;
/*      */   public static final int ENUM_CONSTANT_DECLARATION = 72;
/*      */   public static final int TYPE_PARAMETER = 73;
/*      */   public static final int PARAMETERIZED_TYPE = 74;
/*      */   public static final int QUALIFIED_TYPE = 75;
/*      */   public static final int WILDCARD_TYPE = 76;
/*      */   public static final int NORMAL_ANNOTATION = 77;
/*      */   public static final int MARKER_ANNOTATION = 78;
/*      */   public static final int SINGLE_MEMBER_ANNOTATION = 79;
/*      */   public static final int MEMBER_VALUE_PAIR = 80;
/*      */   public static final int ANNOTATION_TYPE_DECLARATION = 81;
/*      */   public static final int ANNOTATION_TYPE_MEMBER_DECLARATION = 82;
/*      */   public static final int MODIFIER = 83;
/*      */   public static final int UNION_TYPE = 84;
/*      */   public static final int DIMENSION = 85;
/*      */   public static final int LAMBDA_EXPRESSION = 86;
/*      */   public static final int INTERSECTION_TYPE = 87;
/*      */   public static final int NAME_QUALIFIED_TYPE = 88;
/*      */   public static final int CREATION_REFERENCE = 89;
/*      */   public static final int EXPRESSION_METHOD_REFERENCE = 90;
/*      */   public static final int SUPER_METHOD_REFERENCE = 91;
/*      */   public static final int TYPE_METHOD_REFERENCE = 92;
/*      */   public static final int MODULE_DECLARATION = 93;
/*      */   public static final int REQUIRES_DIRECTIVE = 94;
/*      */   public static final int EXPORTS_DIRECTIVE = 95;
/*      */   public static final int OPENS_DIRECTIVE = 96;
/*      */   public static final int USES_DIRECTIVE = 97;
/*      */   public static final int PROVIDES_DIRECTIVE = 98;
/*      */   public static final int MODULE_MODIFIER = 99;
/*      */   public static final int SWITCH_EXPRESSION = 100;
/*      */   public static final int YIELD_STATEMENT = 101;
/*      */   public static final int TEXT_BLOCK = 102;
/*      */   public static final int RECORD_DECLARATION = 103;
/*      */   public static final int PATTERN_INSTANCEOF_EXPRESSION = 104;
/*      */   public static final int MODULE_QUALIFIED_NAME = 105;
/*      */   public static final int TYPE_PATTERN = 106;
/*      */   public static final int GUARDED_PATTERN = 107;
/*      */   public static final int NULL_PATTERN = 108;
/*      */   public static final int CASE_DEFAULT_EXPRESSION = 109;
/*      */   public static final int TAG_PROPERTY = 110;
/*      */   public static final int JAVADOC_REGION = 111;
/*      */   public static final int JAVADOC_TEXT_ELEMENT = 112;
/*      */   public static final int RECORD_PATTERN = 113;
/*      */   public static final int ENHANCED_FOR_WITH_RECORD_PATTERN = 114;
/*      */   final AST ast;
/*      */   
/*      */   public static Class nodeClassForType(int nodeType) {
/* 1090 */     switch (nodeType) {
/*      */       case 81:
/* 1092 */         return AnnotationTypeDeclaration.class;
/*      */       case 82:
/* 1094 */         return AnnotationTypeMemberDeclaration.class;
/*      */       case 1:
/* 1096 */         return AnonymousClassDeclaration.class;
/*      */       case 2:
/* 1098 */         return ArrayAccess.class;
/*      */       case 3:
/* 1100 */         return ArrayCreation.class;
/*      */       case 4:
/* 1102 */         return ArrayInitializer.class;
/*      */       case 5:
/* 1104 */         return ArrayType.class;
/*      */       case 6:
/* 1106 */         return AssertStatement.class;
/*      */       case 7:
/* 1108 */         return Assignment.class;
/*      */       case 8:
/* 1110 */         return Block.class;
/*      */       case 64:
/* 1112 */         return BlockComment.class;
/*      */       case 9:
/* 1114 */         return BooleanLiteral.class;
/*      */       case 10:
/* 1116 */         return BreakStatement.class;
/*      */       case 109:
/* 1118 */         return CaseDefaultExpression.class;
/*      */       case 11:
/* 1120 */         return CastExpression.class;
/*      */       case 12:
/* 1122 */         return CatchClause.class;
/*      */       case 13:
/* 1124 */         return CharacterLiteral.class;
/*      */       case 14:
/* 1126 */         return ClassInstanceCreation.class;
/*      */       case 15:
/* 1128 */         return CompilationUnit.class;
/*      */       case 16:
/* 1130 */         return ConditionalExpression.class;
/*      */       case 17:
/* 1132 */         return ConstructorInvocation.class;
/*      */       case 18:
/* 1134 */         return ContinueStatement.class;
/*      */       case 89:
/* 1136 */         return CreationReference.class;
/*      */       case 85:
/* 1138 */         return Dimension.class;
/*      */       case 19:
/* 1140 */         return DoStatement.class;
/*      */       case 20:
/* 1142 */         return EmptyStatement.class;
/*      */       case 70:
/* 1144 */         return EnhancedForStatement.class;
/*      */       case 114:
/* 1146 */         return EnhancedForWithRecordPattern.class;
/*      */       case 72:
/* 1148 */         return EnumConstantDeclaration.class;
/*      */       case 71:
/* 1150 */         return EnumDeclaration.class;
/*      */       case 95:
/* 1152 */         return ExportsDirective.class;
/*      */       case 90:
/* 1154 */         return ExpressionMethodReference.class;
/*      */       case 21:
/* 1156 */         return ExpressionStatement.class;
/*      */       case 22:
/* 1158 */         return FieldAccess.class;
/*      */       case 23:
/* 1160 */         return FieldDeclaration.class;
/*      */       case 24:
/* 1162 */         return ForStatement.class;
/*      */       case 107:
/* 1164 */         return GuardedPattern.class;
/*      */       case 25:
/* 1166 */         return IfStatement.class;
/*      */       case 26:
/* 1168 */         return ImportDeclaration.class;
/*      */       case 27:
/* 1170 */         return InfixExpression.class;
/*      */       case 28:
/* 1172 */         return Initializer.class;
/*      */       case 62:
/* 1174 */         return InstanceofExpression.class;
/*      */       case 87:
/* 1176 */         return IntersectionType.class;
/*      */       case 29:
/* 1178 */         return Javadoc.class;
/*      */       case 111:
/* 1180 */         return JavaDocRegion.class;
/*      */       case 112:
/* 1182 */         return JavaDocTextElement.class;
/*      */       case 30:
/* 1184 */         return LabeledStatement.class;
/*      */       case 86:
/* 1186 */         return LambdaExpression.class;
/*      */       case 63:
/* 1188 */         return LineComment.class;
/*      */       case 78:
/* 1190 */         return MarkerAnnotation.class;
/*      */       case 67:
/* 1192 */         return MemberRef.class;
/*      */       case 80:
/* 1194 */         return MemberValuePair.class;
/*      */       case 31:
/* 1196 */         return MethodDeclaration.class;
/*      */       case 32:
/* 1198 */         return MethodInvocation.class;
/*      */       case 68:
/* 1200 */         return MethodRef.class;
/*      */       case 69:
/* 1202 */         return MethodRefParameter.class;
/*      */       case 83:
/* 1204 */         return Modifier.class;
/*      */       case 93:
/* 1206 */         return ModuleDeclaration.class;
/*      */       case 99:
/* 1208 */         return ModuleModifier.class;
/*      */       case 105:
/* 1210 */         return ModuleQualifiedName.class;
/*      */       case 88:
/* 1212 */         return NameQualifiedType.class;
/*      */       case 77:
/* 1214 */         return NormalAnnotation.class;
/*      */       case 33:
/* 1216 */         return NullLiteral.class;
/*      */       case 108:
/* 1218 */         return NullPattern.class;
/*      */       case 34:
/* 1220 */         return NumberLiteral.class;
/*      */       case 96:
/* 1222 */         return OpensDirective.class;
/*      */       case 35:
/* 1224 */         return PackageDeclaration.class;
/*      */       case 74:
/* 1226 */         return ParameterizedType.class;
/*      */       case 36:
/* 1228 */         return ParenthesizedExpression.class;
/*      */       case 104:
/* 1230 */         return PatternInstanceofExpression.class;
/*      */       case 37:
/* 1232 */         return PostfixExpression.class;
/*      */       case 38:
/* 1234 */         return PrefixExpression.class;
/*      */       case 39:
/* 1236 */         return PrimitiveType.class;
/*      */       case 98:
/* 1238 */         return ProvidesDirective.class;
/*      */       case 40:
/* 1240 */         return QualifiedName.class;
/*      */       case 75:
/* 1242 */         return QualifiedType.class;
/*      */       case 103:
/* 1244 */         return RecordDeclaration.class;
/*      */       case 113:
/* 1246 */         return RecordPattern.class;
/*      */       case 94:
/* 1248 */         return RequiresDirective.class;
/*      */       case 41:
/* 1250 */         return ReturnStatement.class;
/*      */       case 42:
/* 1252 */         return SimpleName.class;
/*      */       case 43:
/* 1254 */         return SimpleType.class;
/*      */       case 79:
/* 1256 */         return SingleMemberAnnotation.class;
/*      */       case 44:
/* 1258 */         return SingleVariableDeclaration.class;
/*      */       case 45:
/* 1260 */         return StringLiteral.class;
/*      */       case 46:
/* 1262 */         return SuperConstructorInvocation.class;
/*      */       case 47:
/* 1264 */         return SuperFieldAccess.class;
/*      */       case 48:
/* 1266 */         return SuperMethodInvocation.class;
/*      */       case 91:
/* 1268 */         return SuperMethodReference.class;
/*      */       case 49:
/* 1270 */         return SwitchCase.class;
/*      */       case 50:
/* 1272 */         return SwitchStatement.class;
/*      */       case 100:
/* 1274 */         return SwitchExpression.class;
/*      */       case 51:
/* 1276 */         return SynchronizedStatement.class;
/*      */       case 65:
/* 1278 */         return TagElement.class;
/*      */       case 110:
/* 1280 */         return TagProperty.class;
/*      */       case 102:
/* 1282 */         return TextBlock.class;
/*      */       case 66:
/* 1284 */         return TextElement.class;
/*      */       case 52:
/* 1286 */         return ThisExpression.class;
/*      */       case 53:
/* 1288 */         return ThrowStatement.class;
/*      */       case 54:
/* 1290 */         return TryStatement.class;
/*      */       case 55:
/* 1292 */         return TypeDeclaration.class;
/*      */       case 56:
/* 1294 */         return TypeDeclarationStatement.class;
/*      */       case 92:
/* 1296 */         return TypeMethodReference.class;
/*      */       case 57:
/* 1298 */         return TypeLiteral.class;
/*      */       case 73:
/* 1300 */         return TypeParameter.class;
/*      */       case 106:
/* 1302 */         return TypePattern.class;
/*      */       case 84:
/* 1304 */         return UnionType.class;
/*      */       case 97:
/* 1306 */         return UsesDirective.class;
/*      */       case 58:
/* 1308 */         return VariableDeclarationExpression.class;
/*      */       case 59:
/* 1310 */         return VariableDeclarationFragment.class;
/*      */       case 60:
/* 1312 */         return VariableDeclarationStatement.class;
/*      */       case 61:
/* 1314 */         return WhileStatement.class;
/*      */       case 76:
/* 1316 */         return WildcardType.class;
/*      */       case 101:
/* 1318 */         return YieldStatement.class;
/*      */     } 
/* 1320 */     throw new IllegalArgumentException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1336 */   private ASTNode parent = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1342 */   private static final Map UNMODIFIABLE_EMPTY_MAP = Collections.unmodifiableMap(new HashMap<>(1));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1356 */   private Object property1 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1363 */   private Object property2 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1370 */   private int startPosition = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1376 */   private int length = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int MALFORMED = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ORIGINAL = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int PROTECT = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int RECOVERED = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1441 */   int typeAndFlags = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1450 */   private StructuralPropertyDescriptor location = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean CYCLE_RISK = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean NO_CYCLE_RISK = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean MANDATORY = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean OPTIONAL = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int HEADERS = 12;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int BASE_NODE_SIZE = 40;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class NodeList
/*      */     extends AbstractList
/*      */   {
/* 1494 */     ArrayList store = new ArrayList(0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ChildListPropertyDescriptor propertyDescriptor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     class Cursor
/*      */       implements Iterator
/*      */     {
/* 1513 */       private int position = 0;
/*      */ 
/*      */       
/*      */       public boolean hasNext() {
/* 1517 */         return (this.position < ASTNode.NodeList.this.store.size());
/*      */       }
/*      */ 
/*      */       
/*      */       public Object next() {
/* 1522 */         Object result = ASTNode.NodeList.this.store.get(this.position);
/* 1523 */         this.position++;
/* 1524 */         return result;
/*      */       }
/*      */ 
/*      */       
/*      */       public void remove() {
/* 1529 */         throw new UnsupportedOperationException();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       void update(int index, int delta) {
/* 1541 */         if (this.position > index)
/*      */         {
/* 1543 */           this.position += delta;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1561 */     private List cursors = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     NodeList(ChildListPropertyDescriptor property) {
/* 1573 */       this.propertyDescriptor = property;
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/* 1578 */       return this.store.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public Object get(int index) {
/* 1583 */       return this.store.get(index);
/*      */     }
/*      */ 
/*      */     
/*      */     public Object set(int index, Object element) {
/* 1588 */       if (element == null) {
/* 1589 */         throw new IllegalArgumentException();
/*      */       }
/* 1591 */       if ((ASTNode.this.typeAndFlags & 0x4) != 0)
/*      */       {
/* 1593 */         throw new IllegalArgumentException("AST node cannot be modified");
/*      */       }
/*      */       
/* 1596 */       ASTNode newChild = (ASTNode)element;
/* 1597 */       ASTNode oldChild = this.store.get(index);
/* 1598 */       if (oldChild == newChild) {
/* 1599 */         return oldChild;
/*      */       }
/* 1601 */       if ((oldChild.typeAndFlags & 0x4) != 0)
/*      */       {
/* 1603 */         throw new IllegalArgumentException("AST node cannot be modified");
/*      */       }
/* 1605 */       ASTNode.checkNewChild(ASTNode.this, newChild, this.propertyDescriptor.cycleRisk, this.propertyDescriptor.elementType);
/* 1606 */       ASTNode.this.ast.preReplaceChildEvent(ASTNode.this, oldChild, newChild, this.propertyDescriptor);
/*      */       
/* 1608 */       Object result = this.store.set(index, newChild);
/*      */       
/* 1610 */       oldChild.setParent(null, null);
/* 1611 */       newChild.setParent(ASTNode.this, this.propertyDescriptor);
/* 1612 */       ASTNode.this.ast.postReplaceChildEvent(ASTNode.this, oldChild, newChild, this.propertyDescriptor);
/* 1613 */       return result;
/*      */     }
/*      */ 
/*      */     
/*      */     public void add(int index, Object element) {
/* 1618 */       if (element == null) {
/* 1619 */         throw new IllegalArgumentException();
/*      */       }
/* 1621 */       if ((ASTNode.this.typeAndFlags & 0x4) != 0)
/*      */       {
/* 1623 */         throw new IllegalArgumentException("AST node cannot be modified");
/*      */       }
/*      */       
/* 1626 */       ASTNode newChild = (ASTNode)element;
/* 1627 */       ASTNode.checkNewChild(ASTNode.this, newChild, this.propertyDescriptor.cycleRisk, this.propertyDescriptor.elementType);
/* 1628 */       ASTNode.this.ast.preAddChildEvent(ASTNode.this, newChild, this.propertyDescriptor);
/*      */ 
/*      */       
/* 1631 */       this.store.add(index, element);
/* 1632 */       updateCursors(index, 1);
/*      */       
/* 1634 */       newChild.setParent(ASTNode.this, this.propertyDescriptor);
/* 1635 */       ASTNode.this.ast.postAddChildEvent(ASTNode.this, newChild, this.propertyDescriptor);
/*      */     }
/*      */ 
/*      */     
/*      */     public Object remove(int index) {
/* 1640 */       if ((ASTNode.this.typeAndFlags & 0x4) != 0)
/*      */       {
/* 1642 */         throw new IllegalArgumentException("AST node cannot be modified");
/*      */       }
/*      */       
/* 1645 */       ASTNode oldChild = this.store.get(index);
/* 1646 */       if ((oldChild.typeAndFlags & 0x4) != 0)
/*      */       {
/* 1648 */         throw new IllegalArgumentException("AST node cannot be modified");
/*      */       }
/*      */       
/* 1651 */       ASTNode.this.ast.preRemoveChildEvent(ASTNode.this, oldChild, this.propertyDescriptor);
/*      */       
/* 1653 */       oldChild.setParent(null, null);
/* 1654 */       Object result = this.store.remove(index);
/* 1655 */       updateCursors(index, -1);
/* 1656 */       ASTNode.this.ast.postRemoveChildEvent(ASTNode.this, oldChild, this.propertyDescriptor);
/* 1657 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Cursor newCursor() {
/* 1673 */       synchronized (this) {
/*      */         
/* 1675 */         if (this.cursors == null)
/*      */         {
/* 1677 */           this.cursors = new ArrayList(1);
/*      */         }
/* 1679 */         Cursor result = new Cursor();
/* 1680 */         this.cursors.add(result);
/* 1681 */         return result;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void releaseCursor(Cursor cursor) {
/* 1695 */       synchronized (this) {
/*      */         
/* 1697 */         this.cursors.remove(cursor);
/* 1698 */         if (this.cursors.isEmpty())
/*      */         {
/*      */           
/* 1701 */           this.cursors = null;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private synchronized void updateCursors(int index, int delta) {
/* 1719 */       if (this.cursors == null) {
/*      */         return;
/*      */       }
/*      */       
/* 1723 */       for (Iterator<Cursor> it = this.cursors.iterator(); it.hasNext(); ) {
/* 1724 */         Cursor c = it.next();
/* 1725 */         c.update(index, delta);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int memSize() {
/* 1745 */       int result = 32;
/* 1746 */       result += 20;
/* 1747 */       result += 12 + 4 * size();
/* 1748 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int listSize() {
/* 1758 */       int result = memSize();
/* 1759 */       for (Iterator<E> it = iterator(); it.hasNext(); ) {
/* 1760 */         ASTNode child = (ASTNode)it.next();
/* 1761 */         result += child.treeSize();
/*      */       } 
/* 1763 */       return result;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ASTNode(AST ast) {
/* 1781 */     if (ast == null) {
/* 1782 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/* 1785 */     this.ast = ast;
/* 1786 */     setNodeType(getNodeType0());
/* 1787 */     setFlags(ast.getDefaultNodeFlag());
/*      */   } class Cursor implements Iterator {
/*      */     private int position = 0; public boolean hasNext() {
/*      */       return (this.position < this.this$1.store.size());
/*      */     } public Object next() {
/*      */       Object result = this.this$1.store.get(this.position);
/*      */       this.position++;
/*      */       return result;
/*      */     } public void remove() {
/*      */       throw new UnsupportedOperationException();
/*      */     } void update(int index, int delta) {
/*      */       if (this.position > index)
/*      */         this.position += delta; 
/*      */     } } public final AST getAST() {
/* 1801 */     return this.ast;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ASTNode getParent() {
/* 1815 */     return this.parent;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final StructuralPropertyDescriptor getLocationInParent() {
/* 1841 */     return this.location;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ASTNode getRoot() {
/* 1851 */     ASTNode candidate = this;
/*      */     while (true) {
/* 1853 */       ASTNode p = candidate.getParent();
/* 1854 */       if (p == null)
/*      */       {
/* 1856 */         return candidate;
/*      */       }
/* 1858 */       candidate = p;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Object getStructuralProperty(StructuralPropertyDescriptor property) {
/* 1879 */     if (property instanceof SimplePropertyDescriptor) {
/* 1880 */       SimplePropertyDescriptor p = (SimplePropertyDescriptor)property;
/* 1881 */       if (p.getValueType() == int.class) {
/* 1882 */         int result = internalGetSetIntProperty(p, true, 0);
/* 1883 */         return Integer.valueOf(result);
/* 1884 */       }  if (p.getValueType() == boolean.class) {
/* 1885 */         boolean result = internalGetSetBooleanProperty(p, true, false);
/* 1886 */         return Boolean.valueOf(result);
/*      */       } 
/* 1888 */       return internalGetSetObjectProperty(p, true, null);
/*      */     } 
/*      */     
/* 1891 */     if (property instanceof ChildPropertyDescriptor) {
/* 1892 */       return internalGetSetChildProperty((ChildPropertyDescriptor)property, true, null);
/*      */     }
/* 1894 */     if (property instanceof ChildListPropertyDescriptor) {
/* 1895 */       return internalGetChildListProperty((ChildListPropertyDescriptor)property);
/*      */     }
/* 1897 */     throw new IllegalArgumentException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setStructuralProperty(StructuralPropertyDescriptor property, Object value) {
/* 1918 */     if (property instanceof SimplePropertyDescriptor) {
/* 1919 */       SimplePropertyDescriptor p = (SimplePropertyDescriptor)property;
/* 1920 */       if (p.getValueType() == int.class) {
/* 1921 */         int arg = ((Integer)value).intValue();
/* 1922 */         internalGetSetIntProperty(p, false, arg); return;
/*      */       } 
/* 1924 */       if (p.getValueType() == boolean.class) {
/* 1925 */         boolean arg = ((Boolean)value).booleanValue();
/* 1926 */         internalGetSetBooleanProperty(p, false, arg);
/*      */         return;
/*      */       } 
/* 1929 */       if (value == null && p.isMandatory()) {
/* 1930 */         throw new IllegalArgumentException();
/*      */       }
/* 1932 */       internalGetSetObjectProperty(p, false, value);
/*      */       
/*      */       return;
/*      */     } 
/* 1936 */     if (property instanceof ChildPropertyDescriptor) {
/* 1937 */       ChildPropertyDescriptor p = (ChildPropertyDescriptor)property;
/* 1938 */       ASTNode child = (ASTNode)value;
/* 1939 */       if (child == null && p.isMandatory()) {
/* 1940 */         throw new IllegalArgumentException();
/*      */       }
/* 1942 */       internalGetSetChildProperty(p, false, child);
/*      */       return;
/*      */     } 
/* 1945 */     if (property instanceof ChildListPropertyDescriptor) {
/* 1946 */       throw new IllegalArgumentException("Cannot set the list of child list property");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int internalGetSetIntProperty(SimplePropertyDescriptor property, boolean get, int value) {
/* 1968 */     throw new RuntimeException("Node does not have this property");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean internalGetSetBooleanProperty(SimplePropertyDescriptor property, boolean get, boolean value) {
/* 1989 */     throw new RuntimeException("Node does not have this property");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object internalGetSetObjectProperty(SimplePropertyDescriptor property, boolean get, Object value) {
/* 2011 */     throw new RuntimeException("Node does not have this property");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 2032 */     throw new RuntimeException("Node does not have this property");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 2048 */     throw new RuntimeException("Node does not have this property");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final List structuralPropertiesForType() {
/* 2065 */     return internalStructuralPropertiesForType(this.ast.apiLevel, this.ast.isPreviewEnabled());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract List internalStructuralPropertiesForType(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   List internalStructuralPropertiesForType(int apiLevel, boolean previewEnabled) {
/* 2103 */     return internalStructuralPropertiesForType(apiLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void createPropertyList(Class<?> nodeClass, List<Class<?>> propertyList) {
/* 2115 */     propertyList.add(nodeClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void addProperty(StructuralPropertyDescriptor property, List<Class<?>> propertyList) {
/* 2126 */     Class nodeClass = propertyList.get(0);
/* 2127 */     if (property.getNodeClass() != nodeClass)
/*      */     {
/* 2129 */       throw new RuntimeException("Structural property descriptor has wrong node class!");
/*      */     }
/* 2131 */     propertyList.add(property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static List reapPropertyList(List propertyList) {
/* 2144 */     propertyList.remove(0);
/*      */     
/* 2146 */     ArrayList<?> a = new ArrayList(propertyList.size());
/* 2147 */     a.addAll(propertyList);
/* 2148 */     return Collections.unmodifiableList(a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unsupportedIn2() {
/* 2162 */     if (this.ast.apiLevel == 2) {
/* 2163 */       throw new UnsupportedOperationException("Operation not supported in JLS2 AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unsupportedIn2_3() {
/* 2178 */     if (this.ast.apiLevel <= 3) {
/* 2179 */       throw new UnsupportedOperationException("Operation only supported in JLS4 and later AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unsupportedIn2_3_4() {
/* 2194 */     if (this.ast.apiLevel < 8) {
/* 2195 */       throw new UnsupportedOperationException("Operation only supported in JLS8 and later AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unsupportedBelow9() {
/* 2210 */     if (this.ast.apiLevel < 9) {
/* 2211 */       throw new UnsupportedOperationException("Operation only supported in JLS9 and later AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unsupportedBelow10() {
/* 2225 */     if (this.ast.apiLevel < 10) {
/* 2226 */       throw new UnsupportedOperationException("Operation only supported in ASTs with level JLS10 and above");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unsupportedBelow11() {
/* 2240 */     if (this.ast.apiLevel < 11) {
/* 2241 */       throw new UnsupportedOperationException("Operation only supported in ASTs with level JLS11 and above");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unsupportedBelow12() {
/* 2257 */     if (this.ast.apiLevel < 12) {
/* 2258 */       throw new UnsupportedOperationException("Operation only supported in ASTs with level JLS12 and above");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unsupportedBelow14() {
/* 2273 */     if (this.ast.apiLevel < 14) {
/* 2274 */       throw new UnsupportedOperationException("Operation only supported in ASTs with level JLS14 and above");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unsupportedBelow15() {
/* 2289 */     if (this.ast.apiLevel < 15) {
/* 2290 */       throw new UnsupportedOperationException("Operation only supported in ASTs with level JLS15 and above");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unsupportedBelow16() {
/* 2305 */     if (this.ast.apiLevel < 16) {
/* 2306 */       throw new UnsupportedOperationException("Operation only supported in ASTs with level JLS16 and above");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unsupportedBelow17() {
/* 2321 */     if (this.ast.apiLevel < 17) {
/* 2322 */       throw new UnsupportedOperationException("Operation only supported in ASTs with level JLS17 and above");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unsupportedBelow18() {
/* 2337 */     if (this.ast.apiLevel < 18) {
/* 2338 */       throw new UnsupportedOperationException("Operation only supported in ASTs with level JLS17 and above");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unsupportedWithoutPreviewError() {
/* 2354 */     if (!this.ast.isPreviewEnabled()) {
/* 2355 */       throw new UnsupportedOperationException("Operation only supported in ASTs with previewEnabled flag as true");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void supportedOnlyIn2() {
/* 2371 */     if (this.ast.apiLevel != 2) {
/* 2372 */       throw new UnsupportedOperationException("Operation only supported in JLS2 AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void supportedOnlyIn2_3_4() {
/* 2388 */     if (this.ast.apiLevel >= 8) {
/* 2389 */       throw new UnsupportedOperationException("Operation only supported in JLS2, JLS3 and JLS4 ASTs");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void supportedOnlyIn12() {
/* 2405 */     if (this.ast.apiLevel != 12) {
/* 2406 */       throw new UnsupportedOperationException("Operation only supported in JLS12 AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void supportedOnlyIn13() {
/* 2421 */     if (this.ast.apiLevel != 13) {
/* 2422 */       throw new UnsupportedOperationException("Operation only supported in JLS13 AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void supportedOnlyIn14() {
/* 2437 */     if (this.ast.apiLevel != 14) {
/* 2438 */       throw new UnsupportedOperationException("Operation only supported in JLS14 AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void supportedOnlyIn15() {
/* 2453 */     if (this.ast.apiLevel != 15) {
/* 2454 */       throw new UnsupportedOperationException("Operation only supported in JLS15 AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void supportedOnlyIn16() {
/* 2469 */     if (this.ast.apiLevel != 16) {
/* 2470 */       throw new UnsupportedOperationException("Operation only supported in JLS16 AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void supportedOnlyIn17() {
/* 2485 */     if (this.ast.apiLevel != 17) {
/* 2486 */       throw new UnsupportedOperationException("Operation only supported in JLS17 AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void supportedOnlyIn18() {
/* 2500 */     if (this.ast.apiLevel != 18) {
/* 2501 */       throw new UnsupportedOperationException("Operation only supported in JLS18 AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void supportedOnlyIn19() {
/* 2515 */     if (this.ast.apiLevel != 19) {
/* 2516 */       throw new UnsupportedOperationException("Operation only supported in JLS19 AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void supportedOnlyIn20() {
/* 2531 */     if (this.ast.apiLevel < 20) {
/* 2532 */       throw new UnsupportedOperationException("Operation only supported in JLS20 AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void unsupportedIn20() {
/* 2545 */     if (this.ast.apiLevel == 20) {
/* 2546 */       throw new UnsupportedOperationException("Operation not supported in JLS20 AST");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setParent(ASTNode parent, StructuralPropertyDescriptor property) {
/* 2566 */     this.ast.modifying();
/* 2567 */     this.parent = parent;
/* 2568 */     this.location = property;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void delete() {
/* 2584 */     StructuralPropertyDescriptor p = getLocationInParent();
/* 2585 */     if (p == null) {
/*      */       return;
/*      */     }
/*      */     
/* 2589 */     if (p.isChildProperty()) {
/* 2590 */       getParent().setStructuralProperty(this.location, null);
/*      */       return;
/*      */     } 
/* 2593 */     if (p.isChildListProperty()) {
/* 2594 */       List l = (List)getParent().getStructuralProperty(this.location);
/* 2595 */       l.remove(this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void checkNewChild(ASTNode node, ASTNode newChild, boolean cycleCheck, Class nodeType) {
/* 2624 */     if (newChild.ast != node.ast)
/*      */     {
/* 2626 */       throw new IllegalArgumentException();
/*      */     }
/* 2628 */     if (newChild.getParent() != null)
/*      */     {
/* 2630 */       throw new IllegalArgumentException();
/*      */     }
/* 2632 */     if (cycleCheck && newChild == node.getRoot())
/*      */     {
/* 2634 */       throw new IllegalArgumentException();
/*      */     }
/* 2636 */     Class<?> childClass = newChild.getClass();
/* 2637 */     if (nodeType != null && !nodeType.isAssignableFrom(childClass))
/*      */     {
/* 2639 */       throw new ClassCastException(childClass + " is not an instance of " + nodeType);
/*      */     }
/* 2641 */     if ((newChild.typeAndFlags & 0x4) != 0)
/*      */     {
/* 2643 */       throw new IllegalArgumentException("AST node cannot be modified");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void preReplaceChild(ASTNode oldChild, ASTNode newChild, ChildPropertyDescriptor property) {
/* 2687 */     if ((this.typeAndFlags & 0x4) != 0)
/*      */     {
/* 2689 */       throw new IllegalArgumentException("AST node cannot be modified");
/*      */     }
/* 2691 */     if (newChild != null) {
/* 2692 */       checkNewChild(this, newChild, property.cycleRisk, null);
/*      */     }
/*      */     
/* 2695 */     if (oldChild != null) {
/* 2696 */       if ((oldChild.typeAndFlags & 0x4) != 0)
/*      */       {
/* 2698 */         throw new IllegalArgumentException("AST node cannot be modified");
/*      */       }
/* 2700 */       if (newChild != null) {
/* 2701 */         this.ast.preReplaceChildEvent(this, oldChild, newChild, property);
/*      */       } else {
/* 2703 */         this.ast.preRemoveChildEvent(this, oldChild, property);
/*      */       } 
/* 2705 */       oldChild.setParent(null, null);
/*      */     }
/* 2707 */     else if (newChild != null) {
/* 2708 */       this.ast.preAddChildEvent(this, newChild, property);
/*      */     } 
/*      */ 
/*      */     
/* 2712 */     if (newChild != null) {
/* 2713 */       newChild.setParent(this, property);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void postReplaceChild(ASTNode oldChild, ASTNode newChild, ChildPropertyDescriptor property) {
/* 2727 */     if (newChild != null) {
/* 2728 */       if (oldChild != null) {
/* 2729 */         this.ast.postReplaceChildEvent(this, oldChild, newChild, property);
/*      */       } else {
/* 2731 */         this.ast.postAddChildEvent(this, newChild, property);
/*      */       } 
/*      */     } else {
/* 2734 */       this.ast.postRemoveChildEvent(this, oldChild, property);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void preValueChange(SimplePropertyDescriptor property) {
/* 2765 */     if ((this.typeAndFlags & 0x4) != 0)
/*      */     {
/* 2767 */       throw new IllegalArgumentException("AST node cannot be modified");
/*      */     }
/* 2769 */     this.ast.preValueChangeEvent(this, property);
/* 2770 */     this.ast.modifying();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void postValueChange(SimplePropertyDescriptor property) {
/* 2780 */     this.ast.postValueChangeEvent(this, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void checkModifiable() {
/* 2789 */     if ((this.typeAndFlags & 0x4) != 0) {
/* 2790 */       throw new IllegalArgumentException("AST node cannot be modified");
/*      */     }
/* 2792 */     this.ast.modifying();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void preLazyInit() {
/* 2816 */     this.ast.disableEvents();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void postLazyInit(ASTNode newChild, ChildPropertyDescriptor property) {
/* 2833 */     newChild.setParent(this, property);
/*      */     
/* 2835 */     this.ast.reenableEvents();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Object getProperty(String propertyName) {
/* 2846 */     if (propertyName == null) {
/* 2847 */       throw new IllegalArgumentException();
/*      */     }
/* 2849 */     if (this.property1 == null)
/*      */     {
/* 2851 */       return null;
/*      */     }
/* 2853 */     if (this.property1 instanceof String) {
/*      */       
/* 2855 */       if (propertyName.equals(this.property1)) {
/* 2856 */         return this.property2;
/*      */       }
/* 2858 */       return null;
/*      */     } 
/*      */ 
/*      */     
/* 2862 */     Map m = (Map)this.property1;
/* 2863 */     return m.get(propertyName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setProperty(String propertyName, Object data) {
/* 2887 */     if (propertyName == null) {
/* 2888 */       throw new IllegalArgumentException();
/*      */     }
/*      */ 
/*      */     
/* 2892 */     if (this.property1 == null) {
/*      */       
/* 2894 */       if (data == null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 2899 */       this.property1 = propertyName;
/* 2900 */       this.property2 = data;
/*      */       
/*      */       return;
/*      */     } 
/* 2904 */     if (this.property1 instanceof String) {
/*      */       
/* 2906 */       if (propertyName.equals(this.property1)) {
/*      */         
/* 2908 */         if (data == null) {
/*      */           
/* 2910 */           this.property1 = null;
/* 2911 */           this.property2 = null;
/*      */         } else {
/* 2913 */           this.property2 = data;
/*      */         } 
/*      */         return;
/*      */       } 
/* 2917 */       if (data == null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 2923 */       Map<Object, Object> map = new HashMap<>(3);
/* 2924 */       map.put(this.property1, this.property2);
/* 2925 */       map.put(propertyName, data);
/* 2926 */       this.property1 = map;
/* 2927 */       this.property2 = null;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 2932 */     Map<String, Object> m = (Map)this.property1;
/* 2933 */     if (data == null) {
/* 2934 */       m.remove(propertyName);
/*      */       
/* 2936 */       if (m.size() == 1) {
/*      */         
/* 2938 */         Map.Entry[] entries = (Map.Entry[])m.entrySet().toArray((Object[])new Map.Entry[1]);
/* 2939 */         this.property1 = entries[0].getKey();
/* 2940 */         this.property2 = entries[0].getValue();
/*      */       } 
/*      */       return;
/*      */     } 
/* 2944 */     m.put(propertyName, data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Map properties() {
/* 2958 */     if (this.property1 == null)
/*      */     {
/* 2960 */       return UNMODIFIABLE_EMPTY_MAP;
/*      */     }
/* 2962 */     if (this.property1 instanceof String)
/*      */     {
/* 2964 */       return Collections.singletonMap(this.property1, this.property2);
/*      */     }
/*      */ 
/*      */     
/* 2968 */     if (this.property2 == null) {
/* 2969 */       this.property2 = Collections.unmodifiableMap((Map<?, ?>)this.property1);
/*      */     }
/*      */     
/* 2972 */     return (Map)this.property2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getFlags() {
/* 2999 */     return this.typeAndFlags & 0xFFFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setFlags(int flags) {
/* 3028 */     this.ast.modifying();
/* 3029 */     int old = this.typeAndFlags & 0xFFFF0000;
/* 3030 */     this.typeAndFlags = old | flags & 0xFFFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getNodeType() {
/* 3045 */     return this.typeAndFlags >>> 16;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setNodeType(int nodeType) {
/* 3055 */     int old = this.typeAndFlags & 0xFFFF0000;
/* 3056 */     this.typeAndFlags = old | nodeType << 16;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract int getNodeType0();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean equals(Object obj) {
/* 3081 */     return (this == obj);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int hashCode() {
/* 3091 */     return super.hashCode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean subtreeMatch(ASTMatcher matcher, Object other) {
/* 3104 */     return subtreeMatch0(matcher, other);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract boolean subtreeMatch0(ASTMatcher paramASTMatcher, Object paramObject);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ASTNode copySubtree(AST target, ASTNode node) {
/* 3142 */     if (node == null) {
/* 3143 */       return null;
/*      */     }
/* 3145 */     if (target == null) {
/* 3146 */       throw new IllegalArgumentException();
/*      */     }
/* 3148 */     if (target.apiLevel() != node.getAST().apiLevel()) {
/* 3149 */       throw new UnsupportedOperationException();
/*      */     }
/* 3151 */     ASTNode newNode = node.clone(target);
/* 3152 */     return newNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List copySubtrees(AST target, List nodes) {
/* 3173 */     List<ASTNode> result = new ArrayList(nodes.size());
/* 3174 */     for (Iterator<ASTNode> it = nodes.iterator(); it.hasNext(); ) {
/* 3175 */       ASTNode oldNode = it.next();
/* 3176 */       ASTNode newNode = oldNode.clone(target);
/* 3177 */       result.add(newNode);
/*      */     } 
/* 3179 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ASTNode clone(AST target) {
/* 3196 */     this.ast.preCloneNodeEvent(this);
/* 3197 */     ASTNode c = clone0(target);
/* 3198 */     this.ast.postCloneNodeEvent(this, c);
/* 3199 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract ASTNode clone0(AST paramAST);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void accept(ASTVisitor visitor) {
/* 3248 */     if (visitor == null) {
/* 3249 */       throw new IllegalArgumentException();
/*      */     }
/*      */     
/* 3252 */     if (visitor.preVisit2(this))
/*      */     {
/* 3254 */       accept0(visitor);
/*      */     }
/*      */     
/* 3257 */     visitor.postVisit(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract void accept0(ASTVisitor paramASTVisitor);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void acceptChild(ASTVisitor visitor, ASTNode child) {
/* 3299 */     if (child == null) {
/*      */       return;
/*      */     }
/* 3302 */     child.accept(visitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void acceptChildren(ASTVisitor visitor, NodeList children) {
/* 3321 */     NodeList.Cursor cursor = children.newCursor();
/*      */     try {
/* 3323 */       while (cursor.hasNext()) {
/* 3324 */         ASTNode child = (ASTNode)cursor.next();
/* 3325 */         child.accept(visitor);
/*      */       } 
/*      */     } finally {
/* 3328 */       children.releaseCursor(cursor);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getStartPosition() {
/* 3347 */     return this.startPosition;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getLength() {
/* 3365 */     return this.length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setSourceRange(int startPosition, int length) {
/* 3387 */     if (startPosition >= 0 && length < 0) {
/* 3388 */       throw new IllegalArgumentException();
/*      */     }
/* 3390 */     if (startPosition < 0 && length != 0) {
/* 3391 */       throw new IllegalArgumentException();
/*      */     }
/*      */ 
/*      */     
/* 3395 */     checkModifiable();
/* 3396 */     this.startPosition = startPosition;
/* 3397 */     this.length = length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String toString() {
/* 3408 */     StringBuffer buffer = new StringBuffer();
/* 3409 */     int p = buffer.length();
/*      */     try {
/* 3411 */       appendDebugString(buffer);
/* 3412 */     } catch (RuntimeException runtimeException) {
/*      */ 
/*      */       
/* 3415 */       buffer.setLength(p);
/* 3416 */       buffer.append("!");
/* 3417 */       buffer.append(standardToString());
/*      */     } 
/* 3419 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final String standardToString() {
/* 3429 */     return super.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void appendDebugString(StringBuffer buffer) {
/* 3443 */     appendPrintString(buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void appendPrintString(StringBuffer buffer) {
/* 3453 */     NaiveASTFlattener printer = new NaiveASTFlattener();
/* 3454 */     accept((ASTVisitor)printer);
/* 3455 */     buffer.append(printer.getResult());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int stringSize(String string) {
/* 3480 */     int size = 0;
/* 3481 */     if (string != null) {
/*      */       
/* 3483 */       size += 28;
/*      */       
/* 3485 */       size += 12 + 2 * string.length();
/*      */     } 
/* 3487 */     return size;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int subtreeBytes() {
/* 3497 */     return treeSize();
/*      */   }
/*      */   
/*      */   abstract int treeSize();
/*      */   
/*      */   abstract int memSize();
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ASTNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */