/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodRefParameter
/*     */   extends ASTNode
/*     */ {
/*  47 */   public static final ChildPropertyDescriptor TYPE_PROPERTY = new ChildPropertyDescriptor(MethodRefParameter.class, "type", Type.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final SimplePropertyDescriptor VARARGS_PROPERTY = new SimplePropertyDescriptor(MethodRefParameter.class, "varargs", boolean.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(MethodRefParameter.class, "name", SimpleName.class, false, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  80 */     List properyList = new ArrayList(3);
/*  81 */     createPropertyList(MethodRefParameter.class, properyList);
/*  82 */     addProperty(TYPE_PROPERTY, properyList);
/*  83 */     addProperty(NAME_PROPERTY, properyList);
/*  84 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(properyList);
/*     */     
/*  86 */     properyList = new ArrayList(3);
/*  87 */     createPropertyList(MethodRefParameter.class, properyList);
/*  88 */     addProperty(TYPE_PROPERTY, properyList);
/*  89 */     addProperty(VARARGS_PROPERTY, properyList);
/*  90 */     addProperty(NAME_PROPERTY, properyList);
/*  91 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 104 */     if (apiLevel == 2) {
/* 105 */       return PROPERTY_DESCRIPTORS_2_0;
/*     */     }
/* 107 */     return PROPERTY_DESCRIPTORS_3_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   private Type type = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean variableArity = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   private SimpleName optionalParameterName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MethodRefParameter(AST ast) {
/* 142 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 147 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 152 */     if (property == TYPE_PROPERTY) {
/* 153 */       if (get) {
/* 154 */         return getType();
/*     */       }
/* 156 */       setType((Type)child);
/* 157 */       return null;
/*     */     } 
/*     */     
/* 160 */     if (property == NAME_PROPERTY) {
/* 161 */       if (get) {
/* 162 */         return getName();
/*     */       }
/* 164 */       setName((SimpleName)child);
/* 165 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 169 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final boolean internalGetSetBooleanProperty(SimplePropertyDescriptor property, boolean get, boolean value) {
/* 174 */     if (property == VARARGS_PROPERTY) {
/* 175 */       if (get) {
/* 176 */         return isVarargs();
/*     */       }
/* 178 */       setVarargs(value);
/* 179 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 183 */     return super.internalGetSetBooleanProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 188 */     return 69;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 193 */     MethodRefParameter result = new MethodRefParameter(target);
/* 194 */     result.setSourceRange(getStartPosition(), getLength());
/* 195 */     result.setType((Type)ASTNode.copySubtree(target, getType()));
/* 196 */     if (this.ast.apiLevel >= 3) {
/* 197 */       result.setVarargs(isVarargs());
/*     */     }
/* 199 */     result.setName((SimpleName)ASTNode.copySubtree(target, getName()));
/* 200 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 206 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 211 */     boolean visitChildren = visitor.visit(this);
/* 212 */     if (visitChildren) {
/*     */       
/* 214 */       acceptChild(visitor, getType());
/* 215 */       acceptChild(visitor, getName());
/*     */     } 
/* 217 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 226 */     if (this.type == null)
/*     */     {
/* 228 */       synchronized (this) {
/* 229 */         if (this.type == null) {
/* 230 */           preLazyInit();
/* 231 */           this.type = this.ast.newPrimitiveType(PrimitiveType.INT);
/* 232 */           postLazyInit(this.type, TYPE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 236 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(Type type) {
/* 251 */     if (type == null) {
/* 252 */       throw new IllegalArgumentException();
/*     */     }
/* 254 */     ASTNode oldChild = this.type;
/* 255 */     preReplaceChild(oldChild, type, TYPE_PROPERTY);
/* 256 */     this.type = type;
/* 257 */     postReplaceChild(oldChild, type, TYPE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVarargs() {
/* 280 */     unsupportedIn2();
/* 281 */     return this.variableArity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVarargs(boolean variableArity) {
/* 293 */     unsupportedIn2();
/* 294 */     preValueChange(VARARGS_PROPERTY);
/* 295 */     this.variableArity = variableArity;
/* 296 */     postValueChange(VARARGS_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 305 */     return this.optionalParameterName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName name) {
/* 320 */     ASTNode oldChild = this.optionalParameterName;
/* 321 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 322 */     this.optionalParameterName = name;
/* 323 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 328 */     return 50;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 333 */     return 
/* 334 */       memSize() + (
/* 335 */       (this.type == null) ? 0 : getType().treeSize()) + (
/* 336 */       (this.optionalParameterName == null) ? 0 : getName().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\MethodRefParameter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */