/*      */ package org.eclipse.jdt.internal.codeassist.complete;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*      */ import org.eclipse.jdt.internal.codeassist.CompletionEngine;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocAllocationExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocArgumentExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocFieldReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocMessageSend;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocModuleReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocQualifiedTypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocSingleNameReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocSingleTypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.parser.JavadocParser;
/*      */ import org.eclipse.jdt.internal.compiler.parser.Parser;
/*      */ import org.eclipse.jdt.internal.compiler.parser.ScannerHelper;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CompletionJavadocParser
/*      */   extends JavadocParser
/*      */ {
/*      */   boolean parsingSnippet = false;
/*      */   public static final int INLINE_ALL_TAGS_LENGTH;
/*      */   public static final int BLOCK_ALL_TAGS_LENGTH;
/*      */   public static final int SNIPPET_ALL_TAGS_LENGTH;
/*      */   
/*      */   static {
/*   42 */     int length = 0; int i;
/*   43 */     for (i = 0; i < INLINE_TAGS_LENGTH; i++) {
/*   44 */       length += (INLINE_TAGS[i]).length;
/*      */     }
/*   46 */     INLINE_ALL_TAGS_LENGTH = length;
/*   47 */     length = 0;
/*   48 */     for (i = 0; i < BLOCK_TAGS_LENGTH; i++) {
/*   49 */       length += (BLOCK_TAGS[i]).length;
/*      */     }
/*   51 */     BLOCK_ALL_TAGS_LENGTH = length;
/*   52 */     length = 0;
/*   53 */     for (i = 0; i < SNIPPET_TAGS_LENGTH; i++) {
/*   54 */       length += (IN_SNIPPET_TAGS[i]).length;
/*      */     }
/*   56 */     SNIPPET_ALL_TAGS_LENGTH = length;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*   61 */   char[][][] levelTags = new char[3][][];
/*   62 */   int[] levelTagsLength = new int[3];
/*      */   
/*      */   int cursorLocation;
/*      */   
/*   66 */   CompletionOnJavadoc completionNode = null;
/*      */   boolean pushText = false;
/*      */   boolean allPossibleTags = false;
/*      */   
/*      */   public CompletionJavadocParser(CompletionParser sourceParser) {
/*   71 */     super((Parser)sourceParser);
/*   72 */     this.scanner = new CompletionScanner(3080192L);
/*   73 */     this.kind = 264;
/*   74 */     initLevelTags();
/*   75 */     setSourceComplianceLevel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean checkDeprecation(int commentPtr) {
/*   83 */     boolean isDeprecated = false;
/*      */     
/*   85 */     this.cursorLocation = ((CompletionParser)this.sourceParser).cursorLocation;
/*   86 */     CompletionScanner completionScanner = (CompletionScanner)this.scanner;
/*   87 */     completionScanner.cursorLocation = this.cursorLocation;
/*   88 */     this.javadocStart = this.sourceParser.scanner.commentStarts[commentPtr];
/*   89 */     this.javadocEnd = this.sourceParser.scanner.commentStops[commentPtr];
/*   90 */     if (this.javadocStart <= this.cursorLocation && this.cursorLocation <= this.javadocEnd) {
/*   91 */       if (CompletionEngine.DEBUG) {
/*   92 */         System.out.println("COMPLETION in Javadoc:");
/*      */       }
/*   94 */       completionScanner.completionIdentifier = null;
/*   95 */       super.checkDeprecation(commentPtr);
/*      */     } else {
/*   97 */       if (this.sourceParser.scanner.commentTagStarts[commentPtr] != 0) {
/*   98 */         boolean previousValue = this.checkDocComment;
/*   99 */         this.checkDocComment = false;
/*  100 */         isDeprecated = super.checkDeprecation(commentPtr);
/*  101 */         this.checkDocComment = previousValue;
/*      */       } 
/*  103 */       this.docComment = null;
/*      */     } 
/*  105 */     return isDeprecated;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean commentParse() {
/*  113 */     this.docComment = new CompletionJavadoc(this.javadocStart, this.javadocEnd);
/*  114 */     this.firstTagPosition = 1;
/*  115 */     return super.commentParse();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object createArgumentReference(char[] name, int dim, boolean isVarargs, Object typeRef, long[] dimPositions, long argNamePos) throws InvalidInputException {
/*  124 */     char[] argName = (name == null) ? CharOperation.NO_CHAR : name;
/*  125 */     Expression expression = (Expression)super.createArgumentReference(argName, dim, isVarargs, typeRef, dimPositions, argNamePos);
/*      */     
/*  127 */     int refStart = ((TypeReference)typeRef).sourceStart;
/*  128 */     int refEnd = ((TypeReference)typeRef).sourceEnd;
/*  129 */     boolean inCompletion = !((refStart > this.cursorLocation || this.cursorLocation > refEnd) && (
/*  130 */       refStart != refEnd + 1 || refEnd != this.cursorLocation));
/*  131 */     if (this.completionNode == null && inCompletion) {
/*  132 */       JavadocArgumentExpression javadocArgument = (JavadocArgumentExpression)expression;
/*  133 */       TypeReference expressionType = javadocArgument.argument.type;
/*  134 */       if (expressionType instanceof JavadocSingleTypeReference) {
/*  135 */         this.completionNode = new CompletionOnJavadocSingleTypeReference((JavadocSingleTypeReference)expressionType);
/*  136 */       } else if (expressionType instanceof JavadocQualifiedTypeReference) {
/*  137 */         this.completionNode = new CompletionOnJavadocQualifiedTypeReference((JavadocQualifiedTypeReference)expressionType);
/*      */       } 
/*  139 */       if (CompletionEngine.DEBUG) {
/*  140 */         System.out.println("\tcompletion argument=" + this.completionNode);
/*      */       }
/*  142 */       return this.completionNode;
/*      */     } 
/*  144 */     return expression;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object createFieldReference(Object receiver) throws InvalidInputException {
/*  152 */     int refStart = (int)(this.identifierPositionStack[0] >>> 32L);
/*  153 */     int refEnd = (int)this.identifierPositionStack[0];
/*  154 */     boolean inCompletion = !((refStart > this.cursorLocation + 1 || this.cursorLocation > refEnd) && (
/*  155 */       refStart != refEnd + 1 || refEnd != this.cursorLocation) && 
/*  156 */       this.memberStart != this.cursorLocation);
/*  157 */     if (inCompletion) {
/*  158 */       JavadocFieldReference fieldRef = (JavadocFieldReference)super.createFieldReference(receiver);
/*  159 */       char[] name = this.sourceParser.compilationUnit.getMainTypeName();
/*  160 */       TypeDeclaration typeDecl = getParsedTypeDeclaration();
/*  161 */       if (typeDecl != null) {
/*  162 */         name = typeDecl.name;
/*      */       }
/*  164 */       this.completionNode = new CompletionOnJavadocFieldReference(fieldRef, this.memberStart, name);
/*  165 */       if (CompletionEngine.DEBUG) {
/*  166 */         System.out.println("\tcompletion field=" + this.completionNode);
/*      */       }
/*  168 */       return this.completionNode;
/*      */     } 
/*  170 */     return super.createFieldReference(receiver);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object createMethodReference(Object receiver, List arguments) throws InvalidInputException {
/*  180 */     int memberPtr = this.identifierLengthStack[0] - 1;
/*  181 */     int refStart = (int)(this.identifierPositionStack[memberPtr] >>> 32L);
/*  182 */     int refEnd = (int)this.identifierPositionStack[memberPtr];
/*  183 */     boolean inCompletion = !((refStart > this.cursorLocation + 1 || this.cursorLocation > refEnd) && (
/*  184 */       refStart != refEnd + 1 || refEnd != this.cursorLocation) && 
/*  185 */       this.memberStart != this.cursorLocation);
/*  186 */     if (inCompletion) {
/*  187 */       ASTNode node = (ASTNode)super.createMethodReference(receiver, arguments);
/*  188 */       if (node instanceof JavadocMessageSend) {
/*  189 */         JavadocMessageSend messageSend = (JavadocMessageSend)node;
/*  190 */         int nameStart = (int)(messageSend.nameSourcePosition >>> 32L);
/*  191 */         int nameEnd = (int)messageSend.nameSourcePosition;
/*  192 */         if (nameStart <= this.cursorLocation + 1 && this.cursorLocation <= nameEnd) {
/*  193 */           this.completionNode = new CompletionOnJavadocFieldReference(messageSend, this.memberStart);
/*      */         } else {
/*  195 */           this.completionNode = new CompletionOnJavadocMessageSend(messageSend, this.memberStart);
/*      */         } 
/*  197 */       } else if (node instanceof JavadocAllocationExpression) {
/*  198 */         this.completionNode = new CompletionOnJavadocAllocationExpression((JavadocAllocationExpression)node, this.memberStart);
/*      */       } 
/*  200 */       if (CompletionEngine.DEBUG) {
/*  201 */         System.out.println("\tcompletion method=" + this.completionNode);
/*      */       }
/*  203 */       return this.completionNode;
/*      */     } 
/*  205 */     return super.createMethodReference(receiver, arguments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object createTypeReference(int primitiveToken, boolean canBeModule) {
/*  214 */     int nbIdentifiers = this.identifierLengthStack[this.identifierLengthPtr];
/*  215 */     int startPtr = this.identifierPtr - nbIdentifiers - 1;
/*  216 */     int refStart = (int)(this.identifierPositionStack[startPtr] >>> 32L);
/*  217 */     int refEnd = (int)this.identifierPositionStack[this.identifierPtr];
/*  218 */     boolean inCompletion = !((refStart > this.cursorLocation + 1 || this.cursorLocation > refEnd) && (
/*  219 */       refStart != refEnd + 1 || refEnd != this.cursorLocation));
/*  220 */     if (!inCompletion) {
/*  221 */       return super.createTypeReference(primitiveToken, canBeModule);
/*      */     }
/*  223 */     this.identifierLengthPtr--;
/*  224 */     if (nbIdentifiers == 1) {
/*  225 */       this.completionNode = new CompletionOnJavadocSingleTypeReference(
/*  226 */           this.identifierStack[this.identifierPtr], 
/*  227 */           this.identifierPositionStack[this.identifierPtr], 
/*  228 */           this.tagSourceStart, 
/*  229 */           this.tagSourceEnd);
/*  230 */     } else if (nbIdentifiers > 1) {
/*  231 */       for (int i = startPtr; i < this.identifierPtr; i++) {
/*  232 */         int start = (int)(this.identifierPositionStack[i] >>> 32L);
/*  233 */         int end = (int)this.identifierPositionStack[i];
/*  234 */         if (start <= this.cursorLocation && this.cursorLocation <= end) {
/*  235 */           if (i == startPtr) {
/*  236 */             this.completionNode = new CompletionOnJavadocSingleTypeReference(
/*  237 */                 this.identifierStack[startPtr], 
/*  238 */                 this.identifierPositionStack[startPtr], 
/*  239 */                 this.tagSourceStart, 
/*  240 */                 this.tagSourceEnd); break;
/*      */           } 
/*  242 */           char[][] tokens = new char[i][];
/*  243 */           System.arraycopy(this.identifierStack, startPtr, tokens, 0, i);
/*  244 */           long[] positions = new long[i + 1];
/*  245 */           System.arraycopy(this.identifierPositionStack, startPtr, positions, 0, i + 1);
/*  246 */           this.completionNode = new CompletionOnJavadocQualifiedTypeReference(tokens, this.identifierStack[i], positions, this.tagSourceStart, this.tagSourceEnd);
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*  251 */       if (this.completionNode == null) {
/*  252 */         char[][] tokens = new char[nbIdentifiers - 1][];
/*  253 */         System.arraycopy(this.identifierStack, startPtr, tokens, 0, nbIdentifiers - 1);
/*  254 */         long[] positions = new long[nbIdentifiers];
/*  255 */         System.arraycopy(this.identifierPositionStack, startPtr, positions, 0, nbIdentifiers);
/*  256 */         this.completionNode = new CompletionOnJavadocQualifiedTypeReference(tokens, this.identifierStack[this.identifierPtr], positions, this.tagSourceStart, this.tagSourceEnd);
/*      */       } 
/*      */     } 
/*      */     
/*  260 */     if (CompletionEngine.DEBUG) {
/*  261 */       System.out.println("\tcompletion partial qualified type=" + this.completionNode);
/*      */     }
/*  263 */     return this.completionNode;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object createModuleTypeReference(int primitiveToken, int moduleRefTokenCount) {
/*      */     CompletionOnJavadocQualifiedTypeReference completionOnJavadocQualifiedTypeReference;
/*  270 */     int nbIdentifiers = this.identifierLengthStack[this.identifierLengthPtr];
/*  271 */     int startPtr = this.identifierPtr - nbIdentifiers - 1;
/*  272 */     int refStart = (int)(this.identifierPositionStack[startPtr] >>> 32L);
/*  273 */     int refEnd = (int)this.identifierPositionStack[this.identifierPtr];
/*  274 */     boolean inCompletion = !((refStart > this.cursorLocation + 1 || this.cursorLocation > refEnd) && (
/*  275 */       refStart != refEnd + 1 || refEnd != this.cursorLocation));
/*  276 */     if (!inCompletion) {
/*  277 */       return super.createModuleTypeReference(primitiveToken, moduleRefTokenCount);
/*      */     }
/*      */     
/*  280 */     JavadocModuleReference moduleRef = createModuleReference(moduleRefTokenCount);
/*      */     
/*  282 */     TypeReference typeRef = null;
/*  283 */     int size = this.identifierLengthStack[this.identifierLengthPtr];
/*  284 */     int newSize = size - moduleRefTokenCount;
/*  285 */     if (newSize == 1) {
/*  286 */       CompletionOnJavadocSingleTypeReference completionOnJavadocSingleTypeReference = new CompletionOnJavadocSingleTypeReference(
/*  287 */           this.identifierStack[moduleRefTokenCount], 
/*  288 */           this.identifierPositionStack[moduleRefTokenCount], 
/*  289 */           this.tagSourceStart, 
/*  290 */           this.tagSourceEnd);
/*  291 */     } else if (newSize > 1) {
/*  292 */       for (int i = moduleRefTokenCount + 1; i < this.identifierPtr; i++) {
/*  293 */         int start = (int)(this.identifierPositionStack[i] >>> 32L);
/*  294 */         int end = (int)this.identifierPositionStack[i];
/*  295 */         if (start <= this.cursorLocation && this.cursorLocation <= end) {
/*  296 */           if (i == moduleRefTokenCount) {
/*  297 */             this.completionNode = new CompletionOnJavadocSingleTypeReference(
/*  298 */                 this.identifierStack[moduleRefTokenCount + 1], 
/*  299 */                 this.identifierPositionStack[moduleRefTokenCount + 1], 
/*  300 */                 this.tagSourceStart, 
/*  301 */                 this.tagSourceEnd); break;
/*      */           } 
/*  303 */           char[][] tokens = new char[i][];
/*  304 */           System.arraycopy(this.identifierStack, moduleRefTokenCount, tokens, 0, i);
/*  305 */           long[] positions = new long[i + 1];
/*  306 */           System.arraycopy(this.identifierPositionStack, moduleRefTokenCount, positions, 0, i + 1);
/*  307 */           completionOnJavadocQualifiedTypeReference = new CompletionOnJavadocQualifiedTypeReference(tokens, this.identifierStack[i], positions, this.tagSourceStart, this.tagSourceEnd);
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*  312 */       if (this.completionNode == null) {
/*  313 */         char[][] tokens = new char[newSize - 1][];
/*  314 */         System.arraycopy(this.identifierStack, moduleRefTokenCount, tokens, 0, newSize - 1);
/*  315 */         long[] positions = new long[newSize];
/*  316 */         System.arraycopy(this.identifierPositionStack, moduleRefTokenCount, positions, 0, newSize);
/*  317 */         completionOnJavadocQualifiedTypeReference = new CompletionOnJavadocQualifiedTypeReference(tokens, this.identifierStack[this.identifierPtr], positions, this.tagSourceStart, this.tagSourceEnd);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  322 */     moduleRef.setTypeReference((TypeReference)completionOnJavadocQualifiedTypeReference);
/*  323 */     this.completionNode = (CompletionOnJavadocModuleReference)moduleRef;
/*  324 */     return moduleRef;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JavadocModuleReference createModuleReference(int moduleRefTokenCount) {
/*  329 */     JavadocModuleReference moduleRef = null;
/*  330 */     char[][] tokens = new char[moduleRefTokenCount][];
/*  331 */     System.arraycopy(this.identifierStack, 0, tokens, 0, moduleRefTokenCount);
/*  332 */     long[] positions = new long[moduleRefTokenCount + 1];
/*  333 */     System.arraycopy(this.identifierPositionStack, 0, positions, 0, moduleRefTokenCount + 1);
/*  334 */     moduleRef = new CompletionOnJavadocModuleReference(tokens, this.identifierStack[this.identifierPtr], positions, this.tagSourceStart, this.tagSourceEnd);
/*  335 */     return moduleRef;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char[][][] possibleTags(char[] prefix, boolean newLine, boolean inSnippet) {
/*  342 */     char[][][] possibleTags = new char[3][][];
/*  343 */     if (newLine && !inSnippet) {
/*  344 */       System.arraycopy(this.levelTags[0], 0, possibleTags[0] = new char[this.levelTagsLength[0]][], 0, this.levelTagsLength[0]);
/*      */     } else {
/*  346 */       possibleTags[0] = CharOperation.NO_CHAR_CHAR;
/*      */     } 
/*  348 */     if (!inSnippet) {
/*  349 */       System.arraycopy(this.levelTags[1], 0, possibleTags[1] = new char[this.levelTagsLength[1]][], 0, this.levelTagsLength[1]);
/*      */     } else {
/*      */       
/*  352 */       possibleTags[1] = CharOperation.NO_CHAR_CHAR;
/*      */     } 
/*      */     
/*  355 */     if (inSnippet) {
/*  356 */       System.arraycopy(this.levelTags[2], 0, possibleTags[2] = new char[this.levelTagsLength[2]][], 0, this.levelTagsLength[2]);
/*      */     }
/*      */     else {
/*      */       
/*  360 */       possibleTags[2] = CharOperation.NO_CHAR_CHAR;
/*      */     } 
/*  362 */     if (prefix == null || prefix.length == 0) return possibleTags; 
/*  363 */     int kinds = this.levelTags.length;
/*  364 */     for (int k = 0; k < kinds; k++) {
/*  365 */       int length = (possibleTags[k]).length, size = 0;
/*  366 */       int[] indexes = new int[length];
/*  367 */       for (int i = 0; i < length; i++) {
/*  368 */         if (CharOperation.prefixEquals(prefix, possibleTags[k][i], false)) {
/*  369 */           indexes[size++] = i;
/*      */         }
/*      */       } 
/*  372 */       char[][] tags = new char[size][];
/*  373 */       for (int j = 0; j < size; j++) {
/*  374 */         tags[j] = possibleTags[k][indexes[j]];
/*      */       }
/*  376 */       possibleTags[k] = tags;
/*      */     } 
/*  378 */     return possibleTags;
/*      */   }
/*      */   
/*      */   private CompletionJavadoc getCompletionJavadoc() {
/*  382 */     return (CompletionJavadoc)this.docComment;
/*      */   }
/*      */   
/*      */   private CompletionParser getCompletionParser() {
/*  386 */     return (CompletionParser)this.sourceParser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initLevelTags() {
/*  393 */     int level = (int)(this.complianceLevel >>> 16L) - 45 + 1;
/*  394 */     if (level >= BLOCK_TAGS_LENGTH) {
/*      */       return;
/*      */     }
/*  397 */     this.levelTags[0] = new char[BLOCK_ALL_TAGS_LENGTH][];
/*  398 */     this.levelTagsLength[0] = 0; int i;
/*  399 */     for (i = 0; i <= level; i++) {
/*  400 */       int length = (BLOCK_TAGS[i]).length;
/*  401 */       System.arraycopy(BLOCK_TAGS[i], 0, this.levelTags[0], this.levelTagsLength[0], length);
/*  402 */       this.levelTagsLength[0] = this.levelTagsLength[0] + length;
/*      */     } 
/*  404 */     if (this.levelTagsLength[0] < BLOCK_ALL_TAGS_LENGTH) {
/*  405 */       System.arraycopy(this.levelTags[0], 0, this.levelTags[0] = new char[this.levelTagsLength[0]][], 0, this.levelTagsLength[0]);
/*      */     }
/*      */     
/*  408 */     this.levelTags[1] = new char[INLINE_ALL_TAGS_LENGTH][];
/*  409 */     this.levelTagsLength[1] = 0;
/*  410 */     for (i = 0; i <= level; i++) {
/*  411 */       int length = (INLINE_TAGS[i]).length;
/*  412 */       System.arraycopy(INLINE_TAGS[i], 0, this.levelTags[1], this.levelTagsLength[1], length);
/*  413 */       this.levelTagsLength[1] = this.levelTagsLength[1] + length;
/*      */     } 
/*  415 */     if (this.levelTagsLength[1] < INLINE_ALL_TAGS_LENGTH) {
/*  416 */       System.arraycopy(this.levelTags[1], 0, this.levelTags[1] = new char[this.levelTagsLength[1]][], 0, this.levelTagsLength[1]);
/*      */     }
/*      */     
/*  419 */     this.levelTags[2] = new char[SNIPPET_ALL_TAGS_LENGTH][];
/*  420 */     this.levelTagsLength[2] = 0;
/*  421 */     for (i = 0; i < 1; i++) {
/*  422 */       int length = (IN_SNIPPET_TAGS[i]).length;
/*  423 */       System.arraycopy(IN_SNIPPET_TAGS[i], 0, this.levelTags[2], this.levelTagsLength[2], length);
/*  424 */       this.levelTagsLength[2] = this.levelTagsLength[2] + length;
/*      */     } 
/*  426 */     if (this.levelTagsLength[2] < INLINE_ALL_TAGS_LENGTH) {
/*  427 */       System.arraycopy(this.levelTags[2], 0, this.levelTags[2] = new char[this.levelTagsLength[2]][], 0, this.levelTagsLength[2]);
/*      */     }
/*      */   }
/*      */   
/*      */   protected Object parseArguments(Object receiver) throws InvalidInputException {
/*  432 */     return parseArguments(receiver, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object parseArguments(Object receiver, boolean verifySpaceOrEndComment) throws InvalidInputException {
/*  440 */     if (this.tagSourceStart > this.cursorLocation) {
/*  441 */       return super.parseArguments(receiver, verifySpaceOrEndComment);
/*      */     }
/*      */ 
/*      */     
/*  445 */     int modulo = 0;
/*  446 */     int iToken = 0;
/*  447 */     char[] argName = null;
/*  448 */     List<Object> arguments = new ArrayList(10);
/*  449 */     Object typeRef = null;
/*  450 */     int dim = 0;
/*  451 */     boolean isVarargs = false;
/*  452 */     long[] dimPositions = new long[20];
/*  453 */     char[] name = null;
/*  454 */     long argNamePos = -1L;
/*  455 */     boolean tokenWhiteSpace = this.scanner.tokenizeWhiteSpace;
/*  456 */     this.scanner.tokenizeWhiteSpace = false;
/*      */ 
/*      */ 
/*      */     
/*  460 */     try { label103: while (this.index < this.scanner.eofPosition)
/*      */       
/*      */       { 
/*      */         
/*  464 */         try { typeRef = parseQualifiedName(false);
/*  465 */           if (this.abort)
/*      */           
/*      */           { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  587 */             this.scanner.tokenizeWhiteSpace = tokenWhiteSpace; return null; }  } catch (InvalidInputException invalidInputException) { break; }  boolean firstArg = (modulo == 0); if (firstArg ? (iToken != 0) : (iToken % modulo != 0)) break;  if (typeRef == null) { if (firstArg && getCurrentTokenType() == 26) { this.lineStarted = true; Object object = createMethodReference(receiver, (List)null); this.scanner.tokenizeWhiteSpace = tokenWhiteSpace; return object; }  Object methodRef = createMethodReference(receiver, arguments); Object object2 = syntaxRecoverEmptyArgumentType(methodRef); this.scanner.tokenizeWhiteSpace = tokenWhiteSpace; return object2; }  if (this.index >= this.scanner.eofPosition) { int argumentStart = ((ASTNode)typeRef).sourceStart; Object object2 = createArgumentReference(this.scanner.getCurrentIdentifierSource(), 0, false, typeRef, (long[])null, (argumentStart << 32L) + this.tokenPreviousPosition - 1L); Object object3 = syntaxRecoverArgumentType(receiver, arguments, object2); this.scanner.tokenizeWhiteSpace = tokenWhiteSpace; return object3; }  if (this.index >= this.cursorLocation) { if (this.completionNode instanceof CompletionOnJavadocSingleTypeReference) { CompletionOnJavadocSingleTypeReference singleTypeReference = (CompletionOnJavadocSingleTypeReference)this.completionNode; if (singleTypeReference.token == null || singleTypeReference.token.length == 0) { Object methodRef = createMethodReference(receiver, arguments); Object object2 = syntaxRecoverEmptyArgumentType(methodRef); this.scanner.tokenizeWhiteSpace = tokenWhiteSpace; return object2; }  }  if (this.completionNode instanceof CompletionOnJavadocQualifiedTypeReference) { CompletionOnJavadocQualifiedTypeReference qualifiedTypeReference = (CompletionOnJavadocQualifiedTypeReference)this.completionNode; if (qualifiedTypeReference.tokens == null || qualifiedTypeReference.tokens.length < qualifiedTypeReference.sourcePositions.length) { Object methodRef = createMethodReference(receiver, arguments); Object object2 = syntaxRecoverEmptyArgumentType(methodRef); this.scanner.tokenizeWhiteSpace = tokenWhiteSpace; return object2; }  }  }  iToken++; dim = 0; isVarargs = false; if (readToken() == 6) { int dimStart = this.scanner.getCurrentTokenStartPosition(); while (readToken() == 6) { consumeToken(); if (readToken() != 69) break label103;  consumeToken(); dimPositions[dim++] = (dimStart << 32L) + this.scanner.getCurrentTokenEndPosition(); }  } else if (readToken() == 120) { int dimStart = this.scanner.getCurrentTokenStartPosition(); dimPositions[dim++] = (dimStart << 32L) + this.scanner.getCurrentTokenEndPosition(); consumeToken(); isVarargs = true; }  argNamePos = -1L; if (readToken() == 19) { consumeToken(); if (firstArg ? (iToken != 1) : (iToken % modulo != 1)) break;  if (argName == null && !firstArg) break;  argName = this.scanner.getCurrentIdentifierSource(); argNamePos = (this.scanner.getCurrentTokenStartPosition() << 32L) + this.scanner.getCurrentTokenEndPosition(); iToken++; } else if (argName != null) { break; }  if (firstArg) { modulo = iToken + 1; } else if (iToken % modulo != modulo - 1) { break; }  int token = readToken(); name = (argName == null) ? CharOperation.NO_CHAR : argName; if (token == 32) { Object object = createArgumentReference(name, dim, isVarargs, typeRef, dimPositions, argNamePos); if (this.abort) { this.scanner.tokenizeWhiteSpace = tokenWhiteSpace; return null; }  arguments.add(object); consumeToken(); iToken++; continue; }  if (token == 26) { Object object2 = createArgumentReference(name, dim, isVarargs, typeRef, dimPositions, argNamePos); if (this.abort) { this.scanner.tokenizeWhiteSpace = tokenWhiteSpace; return null; }  arguments.add(object2); consumeToken(); Object object3 = createMethodReference(receiver, arguments); this.scanner.tokenizeWhiteSpace = tokenWhiteSpace; return object3; }  Object argument = createArgumentReference(name, dim, isVarargs, typeRef, dimPositions, argNamePos); Object object1 = syntaxRecoverArgumentType(receiver, arguments, argument); this.scanner.tokenizeWhiteSpace = tokenWhiteSpace; return object1; }  throw new InvalidInputException(); } finally { this.scanner.tokenizeWhiteSpace = tokenWhiteSpace; }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean parseParam() throws InvalidInputException {
/*  593 */     int startPosition = this.index;
/*  594 */     int endPosition = this.index;
/*  595 */     long namePosition = (startPosition << 32L) + endPosition;
/*  596 */     this.identifierPtr = -1;
/*  597 */     boolean valid = super.parseParam();
/*  598 */     if (this.identifierPtr > 2) return valid;
/*      */     
/*  600 */     char[] name = null;
/*  601 */     CompletionScanner completionScanner = (CompletionScanner)this.scanner;
/*  602 */     boolean isTypeParam = false;
/*  603 */     if (this.identifierPtr >= 0) {
/*  604 */       char[] identifier = null;
/*  605 */       switch (this.identifierPtr) {
/*      */         case 2:
/*  607 */           if (!valid && completionScanner.completionIdentifier != null && completionScanner.completionIdentifier.length == 0) {
/*  608 */             valid = pushParamName(true);
/*      */           }
/*      */         
/*      */         case 1:
/*  612 */           isTypeParam = (this.identifierStack[0][0] == '<');
/*  613 */           identifier = this.identifierStack[1];
/*  614 */           namePosition = this.identifierPositionStack[1];
/*      */           break;
/*      */         case 0:
/*  617 */           identifier = this.identifierStack[0];
/*  618 */           namePosition = this.identifierPositionStack[0];
/*  619 */           isTypeParam = (identifier.length > 0 && identifier[0] == '<');
/*      */           break;
/*      */       } 
/*  622 */       if (identifier != null && identifier.length > 0 && ScannerHelper.isJavaIdentifierPart(this.complianceLevel, identifier[0])) {
/*  623 */         name = identifier;
/*      */       }
/*  625 */       startPosition = (int)(this.identifierPositionStack[0] >> 32L);
/*  626 */       endPosition = (int)this.identifierPositionStack[this.identifierPtr];
/*      */     } 
/*  628 */     boolean inCompletion = !((startPosition > this.cursorLocation + 1 || this.cursorLocation > endPosition) && (
/*  629 */       startPosition != endPosition + 1 || endPosition != this.cursorLocation));
/*  630 */     if (inCompletion) {
/*  631 */       if (this.completionNode == null) {
/*  632 */         if (isTypeParam) {
/*  633 */           this.completionNode = new CompletionOnJavadocTypeParamReference(name, namePosition, startPosition, endPosition);
/*      */         } else {
/*  635 */           this.completionNode = new CompletionOnJavadocParamNameReference(name, namePosition, startPosition, endPosition);
/*      */         } 
/*  637 */         if (CompletionEngine.DEBUG) {
/*  638 */           System.out.println("\tcompletion param=" + this.completionNode);
/*      */         }
/*  640 */       } else if (this.completionNode instanceof CompletionOnJavadocParamNameReference) {
/*  641 */         CompletionOnJavadocParamNameReference paramNameRef = (CompletionOnJavadocParamNameReference)this.completionNode;
/*  642 */         int nameStart = (int)(namePosition >> 32L);
/*  643 */         paramNameRef.sourceStart = nameStart;
/*  644 */         int nameEnd = (int)namePosition;
/*  645 */         if (nameStart < this.cursorLocation && this.cursorLocation < nameEnd) {
/*  646 */           paramNameRef.sourceEnd = this.cursorLocation + 1;
/*      */         } else {
/*  648 */           paramNameRef.sourceEnd = nameEnd;
/*      */         } 
/*  650 */         paramNameRef.tagSourceStart = startPosition;
/*  651 */         paramNameRef.tagSourceEnd = endPosition;
/*  652 */       } else if (this.completionNode instanceof CompletionOnJavadocTypeParamReference) {
/*  653 */         CompletionOnJavadocTypeParamReference typeParamRef = (CompletionOnJavadocTypeParamReference)this.completionNode;
/*  654 */         int nameStart = (int)(namePosition >> 32L);
/*  655 */         typeParamRef.sourceStart = nameStart;
/*  656 */         int nameEnd = (int)namePosition;
/*  657 */         if (nameStart < this.cursorLocation && this.cursorLocation < nameEnd) {
/*  658 */           typeParamRef.sourceEnd = this.cursorLocation + 1;
/*      */         } else {
/*  660 */           typeParamRef.sourceEnd = nameEnd;
/*      */         } 
/*  662 */         typeParamRef.tagSourceStart = startPosition;
/*  663 */         typeParamRef.tagSourceEnd = endPosition;
/*      */       } 
/*      */     }
/*  666 */     return valid;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean parseReference() throws InvalidInputException {
/*  671 */     return parseReference(false);
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean parseReference(boolean allowModule) throws InvalidInputException {
/*  676 */     boolean completed = (this.completionNode != null);
/*  677 */     boolean valid = super.parseReference(allowModule);
/*  678 */     if (!completed && this.completionNode != null) {
/*  679 */       this.completionNode.addCompletionFlags(64);
/*      */     }
/*  681 */     return valid;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean parseTag(int previousPosition) throws InvalidInputException {
/*  686 */     int startPosition = this.inlineTagStarted ? this.inlineTagStart : previousPosition;
/*  687 */     boolean newLine = !this.lineStarted;
/*  688 */     boolean valid = false;
/*      */     try {
/*  690 */       valid = super.parseTag(previousPosition);
/*      */     }
/*  692 */     catch (InvalidCursorLocation invalidCursorLocation) {}
/*      */ 
/*      */     
/*  695 */     boolean inCompletion = !((this.tagSourceStart > this.cursorLocation + 1 || this.cursorLocation > this.tagSourceEnd) && (
/*  696 */       this.tagSourceStart != this.tagSourceEnd + 1 || this.tagSourceEnd != this.cursorLocation));
/*  697 */     if (inCompletion) {
/*  698 */       int end = this.tagSourceEnd;
/*  699 */       if (this.inlineTagStarted && this.scanner.currentCharacter == '}') {
/*  700 */         end = this.scanner.currentPosition;
/*      */       }
/*  702 */       long position = (startPosition << 32L) + end;
/*  703 */       int length = this.cursorLocation + 1 - this.tagSourceStart;
/*  704 */       char[] tag = new char[length];
/*  705 */       System.arraycopy(this.source, this.tagSourceStart, tag, 0, length);
/*  706 */       char[][][] tags = this.parsingSnippet ? possibleTags(tag, false, true) : possibleTags(tag, newLine, false);
/*  707 */       if (tags != null) {
/*  708 */         this.completionNode = new CompletionOnJavadocTag(tag, position, startPosition, end, tags, this.allPossibleTags);
/*      */       }
/*      */     } 
/*  711 */     return valid;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean parseSnippet() throws InvalidInputException {
/*  716 */     this.parsingSnippet = true;
/*  717 */     return super.parseSnippet();
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean lookForTagsInSnippets() {
/*  722 */     return this.parsingSnippet;
/*      */   }
/*      */   
/*      */   protected boolean parseThrows() {
/*      */     try {
/*  727 */       Object typeRef = parseQualifiedName(true);
/*  728 */       if (this.completionNode != null) {
/*  729 */         this.completionNode.addCompletionFlags(2);
/*      */       }
/*  731 */       return pushThrowName(typeRef);
/*  732 */     } catch (InvalidInputException invalidInputException) {
/*      */ 
/*      */       
/*  735 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean pushParamName(boolean isTypeParam) {
/*  743 */     if (super.pushParamName(isTypeParam)) {
/*  744 */       Expression expression = (Expression)this.astStack[this.astPtr];
/*      */       
/*  746 */       if (expression.sourceStart <= this.cursorLocation + 1 && this.cursorLocation <= expression.sourceEnd) {
/*  747 */         if (isTypeParam) {
/*  748 */           this.completionNode = new CompletionOnJavadocTypeParamReference((JavadocSingleTypeReference)expression);
/*      */         } else {
/*  750 */           this.completionNode = new CompletionOnJavadocParamNameReference((JavadocSingleNameReference)expression);
/*      */         } 
/*  752 */         if (CompletionEngine.DEBUG) {
/*  753 */           System.out.println("\tcompletion param=" + this.completionNode);
/*      */         }
/*      */       } 
/*  756 */       return true;
/*      */     } 
/*  758 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void pushText(int start, int end) {
/*  769 */     if (start <= this.cursorLocation && this.cursorLocation <= end) {
/*  770 */       this.scanner.resetTo(start, end);
/*  771 */       boolean tokenizeWhiteSpace = this.scanner.tokenizeWhiteSpace;
/*  772 */       this.scanner.tokenizeWhiteSpace = true;
/*      */       try {
/*  774 */         Object typeRef = null;
/*  775 */         this.pushText = true;
/*      */ 
/*      */         
/*  778 */         int previousToken = 1000;
/*  779 */         while (!this.scanner.atEnd() && this.completionNode == null && !this.abort) {
/*  780 */           int strStart, strEnd, token = readTokenSafely();
/*  781 */           switch (token) {
/*      */             case 60:
/*  783 */               strStart = 0; strEnd = 0;
/*  784 */               if ((strStart = this.scanner.getCurrentTokenStartPosition() + 1) <= this.cursorLocation && 
/*  785 */                 this.cursorLocation <= (strEnd = this.scanner.getCurrentTokenEndPosition() - 1))
/*      */               {
/*  787 */                 this.scanner.resetTo(strStart, strEnd);
/*      */               }
/*  789 */               consumeToken();
/*      */               break;
/*      */             case 138:
/*  792 */               consumeToken();
/*  793 */               if (this.scanner.currentCharacter == '#') {
/*  794 */                 Object member = null;
/*      */                 try {
/*  796 */                   this.scanner.tokenizeWhiteSpace = false;
/*  797 */                   member = parseMember(typeRef);
/*  798 */                 } catch (InvalidInputException invalidInputException) {
/*  799 */                   consumeToken();
/*      */                 } 
/*  801 */                 this.scanner.tokenizeWhiteSpace = true;
/*  802 */                 if (this.completionNode != null) {
/*  803 */                   int flags = this.inlineTagStarted ? 0 : 20;
/*  804 */                   if (member instanceof JavadocMessageSend) {
/*  805 */                     JavadocMessageSend msgSend = (JavadocMessageSend)member;
/*  806 */                     this.completionNode = new CompletionOnJavadocMessageSend(msgSend, this.memberStart, flags);
/*  807 */                     if (CompletionEngine.DEBUG)
/*  808 */                       System.out.println("\tnew completion method=" + this.completionNode);  break;
/*      */                   } 
/*  810 */                   if (member instanceof JavadocAllocationExpression) {
/*  811 */                     JavadocAllocationExpression alloc = (JavadocAllocationExpression)member;
/*  812 */                     this.completionNode = new CompletionOnJavadocAllocationExpression(alloc, this.memberStart, flags);
/*  813 */                     if (CompletionEngine.DEBUG)
/*  814 */                       System.out.println("\tnew completion method=" + this.completionNode); 
/*      */                     break;
/*      */                   } 
/*  817 */                   this.completionNode.addCompletionFlags(flags);
/*      */                 } 
/*      */               } 
/*      */               break;
/*      */             
/*      */             case 19:
/*      */               try {
/*  824 */                 this.scanner.tokenizeWhiteSpace = false;
/*  825 */                 typeRef = parseQualifiedName(true);
/*  826 */                 if (this.completionNode == null) {
/*  827 */                   consumeToken();
/*  828 */                   this.scanner.resetTo(this.tokenPreviousPosition, end);
/*  829 */                   this.index = this.tokenPreviousPosition;
/*      */                 }
/*      */               
/*  832 */               } catch (InvalidInputException invalidInputException) {
/*  833 */                 consumeToken();
/*      */               } finally {
/*      */                 
/*  836 */                 this.scanner.tokenizeWhiteSpace = true;
/*      */               } 
/*  838 */               if (previousToken != 1000) {
/*  839 */                 typeRef = null;
/*  840 */                 this.completionNode = null;
/*      */               } 
/*      */               break;
/*      */             case 34:
/*  844 */               consumeToken();
/*      */               try {
/*  846 */                 this.scanner.tokenizeWhiteSpace = false;
/*  847 */                 int startPosition = this.scanner.getCurrentTokenStartPosition();
/*  848 */                 parseTag(startPosition);
/*  849 */                 if (this.completionNode != null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               }
/*  900 */               catch (InvalidInputException invalidInputException) {
/*  901 */                 consumeToken();
/*      */               } 
/*  903 */               this.scanner.tokenizeWhiteSpace = true;
/*      */               break;
/*      */             default:
/*  906 */               consumeToken();
/*  907 */               typeRef = null;
/*      */               break;
/*      */           } 
/*  910 */           previousToken = token;
/*      */         } 
/*      */       } finally {
/*      */         
/*  914 */         this.scanner.tokenizeWhiteSpace = tokenizeWhiteSpace;
/*  915 */         this.pushText = false;
/*      */       } 
/*      */ 
/*      */       
/*  919 */       this.index = end;
/*  920 */       this.scanner.currentPosition = end;
/*  921 */       consumeToken();
/*      */       
/*  923 */       if (this.completionNode != null) {
/*  924 */         if (this.inlineTagStarted) {
/*  925 */           this.completionNode.addCompletionFlags(64);
/*      */         } else {
/*  927 */           this.completionNode.addCompletionFlags(4);
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected int readToken() throws InvalidInputException {
/*  935 */     int token = super.readToken();
/*  936 */     if (token == 19 && this.scanner.currentPosition == this.scanner.startPosition)
/*      */     {
/*  938 */       this.scanner.getCurrentIdentifierSource();
/*      */     }
/*  940 */     return token;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object syntaxRecoverQualifiedName(int primitiveToken) throws InvalidInputException {
/*  948 */     if (this.cursorLocation == (int)this.identifierPositionStack[this.identifierPtr])
/*      */     {
/*  950 */       return createTypeReference(primitiveToken);
/*      */     }
/*  952 */     int idLength = this.identifierLengthStack[this.identifierLengthPtr];
/*  953 */     char[][] tokens = new char[idLength][];
/*  954 */     int startPtr = this.identifierPtr - idLength + 1;
/*  955 */     System.arraycopy(this.identifierStack, startPtr, tokens, 0, idLength);
/*  956 */     long[] positions = new long[idLength + 1];
/*  957 */     System.arraycopy(this.identifierPositionStack, startPtr, positions, 0, idLength);
/*  958 */     positions[idLength] = (this.tokenPreviousPosition << 32L) + this.tokenPreviousPosition;
/*  959 */     this.completionNode = new CompletionOnJavadocQualifiedTypeReference(tokens, CharOperation.NO_CHAR, positions, this.tagSourceStart, this.tagSourceEnd);
/*      */     
/*  961 */     if (CompletionEngine.DEBUG) {
/*  962 */       System.out.println("\tcompletion partial qualified type=" + this.completionNode);
/*      */     }
/*  964 */     return this.completionNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object syntaxRecoverArgumentType(Object receiver, List<Object> arguments, Object argument) throws InvalidInputException {
/*  971 */     if (this.completionNode != null && !this.pushText) {
/*  972 */       this.completionNode.addCompletionFlags(8);
/*  973 */       if (this.completionNode instanceof CompletionOnJavadocSingleTypeReference) {
/*  974 */         char[] token = ((CompletionOnJavadocSingleTypeReference)this.completionNode).token;
/*  975 */         if (token != null && token.length > 0) {
/*  976 */           return this.completionNode;
/*      */         }
/*      */       } else {
/*  979 */         return this.completionNode;
/*      */       } 
/*      */     } 
/*      */     
/*  983 */     if (this.completionNode instanceof CompletionOnJavadocSingleTypeReference) {
/*  984 */       CompletionOnJavadocSingleTypeReference singleTypeReference = (CompletionOnJavadocSingleTypeReference)this.completionNode;
/*  985 */       if (singleTypeReference.token != null && singleTypeReference.token.length > 0) {
/*  986 */         arguments.add(argument);
/*      */       }
/*  988 */     } else if (this.completionNode instanceof CompletionOnJavadocQualifiedTypeReference) {
/*  989 */       CompletionOnJavadocQualifiedTypeReference qualifiedTypeReference = (CompletionOnJavadocQualifiedTypeReference)this.completionNode;
/*  990 */       if (qualifiedTypeReference.tokens != null && qualifiedTypeReference.tokens.length == qualifiedTypeReference.sourcePositions.length) {
/*  991 */         arguments.add(argument);
/*      */       }
/*      */     } else {
/*  994 */       arguments.add(argument);
/*      */     } 
/*  996 */     Object methodRef = super.createMethodReference(receiver, arguments);
/*  997 */     if (methodRef instanceof JavadocMessageSend) {
/*  998 */       JavadocMessageSend msgSend = (JavadocMessageSend)methodRef;
/*  999 */       if (this.index > this.cursorLocation) {
/* 1000 */         msgSend.sourceEnd = this.tokenPreviousPosition - 1;
/*      */       }
/* 1002 */       int nameStart = (int)(msgSend.nameSourcePosition >>> 32L);
/* 1003 */       int nameEnd = (int)msgSend.nameSourcePosition;
/* 1004 */       if (nameStart <= this.cursorLocation + 1 && this.cursorLocation <= nameEnd) {
/* 1005 */         this.completionNode = new CompletionOnJavadocFieldReference(msgSend, this.memberStart);
/*      */       } else {
/* 1007 */         this.completionNode = new CompletionOnJavadocMessageSend(msgSend, this.memberStart);
/*      */       } 
/* 1009 */     } else if (methodRef instanceof JavadocAllocationExpression) {
/* 1010 */       JavadocAllocationExpression allocExp = (JavadocAllocationExpression)methodRef;
/* 1011 */       if (this.index > this.cursorLocation) {
/* 1012 */         allocExp.sourceEnd = this.tokenPreviousPosition - 1;
/*      */       }
/* 1014 */       this.completionNode = new CompletionOnJavadocAllocationExpression(allocExp, this.memberStart);
/*      */     } 
/* 1016 */     if (CompletionEngine.DEBUG) {
/* 1017 */       System.out.println("\tcompletion method=" + this.completionNode);
/*      */     }
/* 1019 */     return this.completionNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object syntaxRecoverEmptyArgumentType(Object methodRef) throws InvalidInputException {
/* 1026 */     if (methodRef instanceof JavadocMessageSend) {
/* 1027 */       JavadocMessageSend msgSend = (JavadocMessageSend)methodRef;
/* 1028 */       if (this.index > this.cursorLocation) {
/* 1029 */         msgSend.sourceEnd = this.tokenPreviousPosition - 1;
/*      */       }
/* 1031 */       this.completionNode = new CompletionOnJavadocMessageSend(msgSend, this.memberStart);
/* 1032 */     } else if (methodRef instanceof JavadocAllocationExpression) {
/* 1033 */       JavadocAllocationExpression allocExp = (JavadocAllocationExpression)methodRef;
/* 1034 */       if (this.index > this.cursorLocation) {
/* 1035 */         allocExp.sourceEnd = this.tokenPreviousPosition - 1;
/*      */       }
/* 1037 */       this.completionNode = new CompletionOnJavadocAllocationExpression(allocExp, this.memberStart);
/*      */     } 
/* 1039 */     if (CompletionEngine.DEBUG) {
/* 1040 */       System.out.println("\tcompletion method=" + this.completionNode);
/*      */     }
/* 1042 */     return this.completionNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateDocComment() {
/* 1050 */     super.updateDocComment();
/* 1051 */     if (this.completionNode instanceof Expression && ((Expression)this.completionNode).isTrulyExpression()) {
/* 1052 */       (getCompletionParser()).assistNodeParent = (ASTNode)this.docComment;
/* 1053 */       (getCompletionParser()).assistNode = (ASTNode)this.completionNode;
/* 1054 */       (getCompletionJavadoc()).completionNode = (Expression)this.completionNode;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean verifySpaceOrEndComment() {
/* 1060 */     CompletionScanner completionScanner = (CompletionScanner)this.scanner;
/* 1061 */     if (completionScanner.completionIdentifier != null && completionScanner.completedIdentifierStart <= this.cursorLocation && this.cursorLocation <= completionScanner.completedIdentifierEnd)
/*      */     {
/* 1063 */       return true;
/*      */     }
/* 1065 */     return super.verifySpaceOrEndComment();
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionJavadocParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */