/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BodyDeclaration
/*     */   extends ASTNode
/*     */ {
/*  53 */   Javadoc optionalDocComment = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private int modifierFlags = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   ASTNode.NodeList modifiers = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract SimplePropertyDescriptor internalModifiersProperty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract ChildListPropertyDescriptor internalModifiers2Property();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ChildListPropertyDescriptor getModifiersProperty() {
/*  97 */     return internalModifiers2Property();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract ChildPropertyDescriptor internalJavadocProperty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ChildPropertyDescriptor getJavadocProperty() {
/* 116 */     return internalJavadocProperty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final ChildPropertyDescriptor internalJavadocPropertyFactory(Class nodeClass) {
/* 126 */     return new ChildPropertyDescriptor(nodeClass, "javadoc", Javadoc.class, false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final SimplePropertyDescriptor internalModifiersPropertyFactory(Class nodeClass) {
/* 137 */     return new SimplePropertyDescriptor(nodeClass, "modifiers", int.class, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final ChildListPropertyDescriptor internalModifiers2PropertyFactory(Class nodeClass) {
/* 147 */     return new ChildListPropertyDescriptor(nodeClass, "modifiers", IExtendedModifier.class, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BodyDeclaration(AST ast) {
/* 160 */     super(ast);
/* 161 */     if (ast.apiLevel >= 3) {
/* 162 */       this.modifiers = new ASTNode.NodeList(this, internalModifiers2Property());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Javadoc getJavadoc() {
/* 172 */     return this.optionalDocComment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJavadoc(Javadoc docComment) {
/* 182 */     ChildPropertyDescriptor p = internalJavadocProperty();
/* 183 */     ASTNode oldChild = this.optionalDocComment;
/* 184 */     preReplaceChild(oldChild, docComment, p);
/* 185 */     this.optionalDocComment = docComment;
/* 186 */     postReplaceChild(oldChild, docComment, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 201 */     if (this.modifiers == null)
/*     */     {
/* 203 */       return this.modifierFlags;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 208 */     int computedmodifierFlags = 0;
/* 209 */     for (Iterator it = modifiers().iterator(); it.hasNext(); ) {
/* 210 */       Object x = it.next();
/* 211 */       if (x instanceof Modifier) {
/* 212 */         computedmodifierFlags |= ((Modifier)x).getKeyword().toFlagValue();
/*     */       }
/*     */     } 
/* 215 */     return computedmodifierFlags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModifiers(int modifiers) {
/* 230 */     internalSetModifiers(modifiers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void internalSetModifiers(int pmodifiers) {
/* 240 */     if (this.modifiers != null) {
/* 241 */       supportedOnlyIn2();
/*     */     }
/* 243 */     SimplePropertyDescriptor p = internalModifiersProperty();
/* 244 */     preValueChange(p);
/* 245 */     this.modifierFlags = pmodifiers;
/* 246 */     postValueChange(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List modifiers() {
/* 261 */     if (this.modifiers == null) {
/* 262 */       unsupportedIn2();
/*     */     }
/* 264 */     return this.modifiers;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 269 */     return 52;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\BodyDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */