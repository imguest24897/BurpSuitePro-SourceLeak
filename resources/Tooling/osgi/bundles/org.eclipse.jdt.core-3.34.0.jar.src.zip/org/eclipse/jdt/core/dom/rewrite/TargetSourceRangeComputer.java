/*     */ package org.eclipse.jdt.core.dom.rewrite;
/*     */ 
/*     */ import org.eclipse.jdt.core.dom.ASTNode;
/*     */ import org.eclipse.jdt.core.dom.CompilationUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TargetSourceRangeComputer
/*     */ {
/*     */   public static final class SourceRange
/*     */   {
/*     */     private int startPosition;
/*     */     private int length;
/*     */     
/*     */     public SourceRange(int startPosition, int length) {
/*  71 */       this.startPosition = startPosition;
/*  72 */       this.length = length;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getStartPosition() {
/*  82 */       return this.startPosition;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getLength() {
/*  92 */       return this.length;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SourceRange computeSourceRange(ASTNode node) {
/* 130 */     ASTNode root = node.getRoot();
/* 131 */     if (root instanceof CompilationUnit) {
/* 132 */       CompilationUnit cu = (CompilationUnit)root;
/* 133 */       return new SourceRange(cu.getExtendedStartPosition(node), cu.getExtendedLength(node));
/*     */     } 
/* 135 */     return new SourceRange(node.getStartPosition(), node.getLength());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\rewrite\TargetSourceRangeComputer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */