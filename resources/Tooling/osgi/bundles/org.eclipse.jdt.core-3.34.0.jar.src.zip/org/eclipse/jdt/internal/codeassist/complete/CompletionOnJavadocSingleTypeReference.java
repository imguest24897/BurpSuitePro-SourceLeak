/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.JavadocSingleTypeReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnJavadocSingleTypeReference
/*    */   extends JavadocSingleTypeReference
/*    */   implements CompletionOnJavadoc
/*    */ {
/* 19 */   public int completionFlags = 1;
/*    */   
/*    */   public CompletionOnJavadocSingleTypeReference(char[] source, long pos, int tagStart, int tagEnd) {
/* 22 */     super(source, pos, tagStart, tagEnd);
/*    */   }
/*    */   
/*    */   public CompletionOnJavadocSingleTypeReference(JavadocSingleTypeReference typeRef) {
/* 26 */     super(typeRef.token, (typeRef.sourceStart << 32L) + typeRef.sourceEnd, typeRef.tagSourceStart, typeRef.tagSourceStart);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addCompletionFlags(int flags) {
/* 31 */     this.completionFlags |= flags;
/*    */   }
/*    */   
/*    */   public boolean completeAnException() {
/* 35 */     return ((this.completionFlags & 0x2) != 0);
/*    */   }
/*    */   
/*    */   public boolean completeInText() {
/* 39 */     return ((this.completionFlags & 0x4) != 0);
/*    */   }
/*    */   
/*    */   public boolean completeBaseTypes() {
/* 43 */     return ((this.completionFlags & 0x8) != 0);
/*    */   }
/*    */   
/*    */   public boolean completeFormalReference() {
/* 47 */     return ((this.completionFlags & 0x40) != 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getCompletionFlags() {
/* 52 */     return this.completionFlags;
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 57 */     output.append("<CompletionOnJavadocSingleTypeReference:");
/* 58 */     super.printExpression(indent, output);
/* 59 */     indent++;
/* 60 */     if (this.completionFlags > 0) {
/* 61 */       output.append('\n');
/* 62 */       for (int j = 0; j < indent; ) { output.append('\t'); j++; }
/* 63 */        output.append("infos:");
/* 64 */       char separator = Character.MIN_VALUE;
/* 65 */       if (completeAnException()) {
/* 66 */         output.append("exception");
/* 67 */         separator = ',';
/*    */       } 
/* 69 */       if (completeInText()) {
/* 70 */         if (separator != '\000') output.append(separator); 
/* 71 */         output.append("text");
/* 72 */         separator = ',';
/*    */       } 
/* 74 */       if (completeBaseTypes()) {
/* 75 */         if (separator != '\000') output.append(separator); 
/* 76 */         output.append("base types");
/* 77 */         separator = ',';
/*    */       } 
/* 79 */       if (completeFormalReference()) {
/* 80 */         if (separator != '\000') output.append(separator); 
/* 81 */         output.append("formal reference");
/* 82 */         separator = ',';
/*    */       } 
/* 84 */       output.append('\n');
/*    */     } 
/* 86 */     indent--;
/* 87 */     for (int i = 0; i < indent; ) { output.append('\t'); i++; }
/* 88 */      return output.append('>');
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnJavadocSingleTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */