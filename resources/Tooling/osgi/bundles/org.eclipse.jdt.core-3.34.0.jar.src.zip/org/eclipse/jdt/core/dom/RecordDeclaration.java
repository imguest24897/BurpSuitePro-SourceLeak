/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordDeclaration
/*     */   extends AbstractTypeDeclaration
/*     */ {
/*  54 */   public static final ChildPropertyDescriptor JAVADOC_PROPERTY = internalJavadocPropertyFactory(RecordDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public static final ChildListPropertyDescriptor MODIFIERS2_PROPERTY = internalModifiers2PropertyFactory(RecordDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public static final ChildPropertyDescriptor NAME_PROPERTY = internalNamePropertyFactory(RecordDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public static final ChildListPropertyDescriptor SUPER_INTERFACE_TYPES_PROPERTY = new ChildListPropertyDescriptor(RecordDeclaration.class, "superInterfaceTypes", Type.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public static final ChildListPropertyDescriptor TYPE_PARAMETERS_PROPERTY = new ChildListPropertyDescriptor(RecordDeclaration.class, "typeParameters", TypeParameter.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public static final ChildListPropertyDescriptor RECORD_COMPONENTS_PROPERTY = new ChildListPropertyDescriptor(RecordDeclaration.class, "recordComponents", SingleVariableDeclaration.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public static final ChildListPropertyDescriptor BODY_DECLARATIONS_PROPERTY = internalBodyDeclarationPropertyFactory(RecordDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   private int restrictedIdentifierStartPosition = -1;
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */   
/*     */   public void setRestrictedIdentifierStartPosition(int restrictedIdentifierStartPosition) {
/* 106 */     if (restrictedIdentifierStartPosition < 0) {
/* 107 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/* 111 */     checkModifiable();
/* 112 */     this.restrictedIdentifierStartPosition = restrictedIdentifierStartPosition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRestrictedIdentifierStartPosition() {
/* 120 */     return this.restrictedIdentifierStartPosition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 132 */     ArrayList propertyList = new ArrayList(8);
/* 133 */     createPropertyList(RecordDeclaration.class, propertyList);
/* 134 */     addProperty(JAVADOC_PROPERTY, propertyList);
/* 135 */     addProperty(MODIFIERS2_PROPERTY, propertyList);
/* 136 */     addProperty(NAME_PROPERTY, propertyList);
/* 137 */     addProperty(TYPE_PARAMETERS_PROPERTY, propertyList);
/* 138 */     addProperty(RECORD_COMPONENTS_PROPERTY, propertyList);
/* 139 */     addProperty(SUPER_INTERFACE_TYPES_PROPERTY, propertyList);
/* 140 */     addProperty(BODY_DECLARATIONS_PROPERTY, propertyList);
/*     */     
/* 142 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 157 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   private ASTNode.NodeList typeParameters = new ASTNode.NodeList(this, TYPE_PARAMETERS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   private ASTNode.NodeList superInterfaceTypes = new ASTNode.NodeList(this, SUPER_INTERFACE_TYPES_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   private ASTNode.NodeList recordComponents = new ASTNode.NodeList(this, RECORD_COMPONENTS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RecordDeclaration(AST ast) {
/* 198 */     super(ast);
/* 199 */     unsupportedBelow16();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 204 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 209 */     if (property == JAVADOC_PROPERTY) {
/* 210 */       if (get) {
/* 211 */         return getJavadoc();
/*     */       }
/* 213 */       setJavadoc((Javadoc)child);
/* 214 */       return null;
/*     */     } 
/*     */     
/* 217 */     if (property == NAME_PROPERTY) {
/* 218 */       if (get) {
/* 219 */         return getName();
/*     */       }
/* 221 */       setName((SimpleName)child);
/* 222 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 226 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 231 */     if (property == MODIFIERS2_PROPERTY) {
/* 232 */       return modifiers();
/*     */     }
/* 234 */     if (property == TYPE_PARAMETERS_PROPERTY) {
/* 235 */       return typeParameters();
/*     */     }
/* 237 */     if (property == RECORD_COMPONENTS_PROPERTY) {
/* 238 */       return recordComponents();
/*     */     }
/* 240 */     if (property == SUPER_INTERFACE_TYPES_PROPERTY) {
/* 241 */       return superInterfaceTypes();
/*     */     }
/* 243 */     if (property == BODY_DECLARATIONS_PROPERTY) {
/* 244 */       return bodyDeclarations();
/*     */     }
/*     */     
/* 247 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalJavadocProperty() {
/* 252 */     return JAVADOC_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalModifiers2Property() {
/* 257 */     return MODIFIERS2_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalNameProperty() {
/* 262 */     return NAME_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalBodyDeclarationsProperty() {
/* 267 */     return BODY_DECLARATIONS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 272 */     return 103;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 277 */     RecordDeclaration result = new RecordDeclaration(target);
/* 278 */     result.restrictedIdentifierStartPosition = getRestrictedIdentifierStartPosition();
/* 279 */     result.setSourceRange(getStartPosition(), getLength());
/* 280 */     result.setJavadoc(
/* 281 */         (Javadoc)ASTNode.copySubtree(target, getJavadoc()));
/* 282 */     result.setName((SimpleName)getName().clone(target));
/* 283 */     result.modifiers().addAll(ASTNode.copySubtrees(target, modifiers()));
/* 284 */     result.typeParameters().addAll(
/* 285 */         ASTNode.copySubtrees(target, typeParameters()));
/* 286 */     result.recordComponents().addAll(
/* 287 */         ASTNode.copySubtrees(target, recordComponents()));
/* 288 */     result.superInterfaceTypes().addAll(
/* 289 */         ASTNode.copySubtrees(target, superInterfaceTypes()));
/* 290 */     result.bodyDeclarations().addAll(
/* 291 */         ASTNode.copySubtrees(target, bodyDeclarations()));
/* 292 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 298 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 303 */     boolean visitChildren = visitor.visit(this);
/* 304 */     if (visitChildren) {
/*     */       
/* 306 */       acceptChild(visitor, getJavadoc());
/* 307 */       acceptChildren(visitor, this.modifiers);
/* 308 */       acceptChild(visitor, getName());
/* 309 */       acceptChildren(visitor, this.typeParameters);
/* 310 */       acceptChildren(visitor, this.recordComponents);
/* 311 */       acceptChildren(visitor, this.superInterfaceTypes);
/* 312 */       acceptChildren(visitor, this.bodyDeclarations);
/*     */     } 
/* 314 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List typeParameters() {
/* 326 */     return this.typeParameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List superInterfaceTypes() {
/* 341 */     return this.superInterfaceTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List recordComponents() {
/* 352 */     return this.recordComponents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldDeclaration[] getFields() {
/* 370 */     List bd = bodyDeclarations();
/* 371 */     int fieldCount = 0;
/* 372 */     for (Iterator it = bd.listIterator(); it.hasNext();) {
/* 373 */       if (it.next() instanceof FieldDeclaration) {
/* 374 */         fieldCount++;
/*     */       }
/*     */     } 
/* 377 */     FieldDeclaration[] fields = new FieldDeclaration[fieldCount];
/* 378 */     int next = 0;
/* 379 */     for (Iterator iterator1 = bd.listIterator(); iterator1.hasNext(); ) {
/* 380 */       Object decl = iterator1.next();
/* 381 */       if (decl instanceof FieldDeclaration) {
/* 382 */         fields[next++] = (FieldDeclaration)decl;
/*     */       }
/*     */     } 
/* 385 */     return fields;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodDeclaration[] getMethods() {
/* 402 */     List bd = bodyDeclarations();
/* 403 */     int methodCount = 0;
/* 404 */     for (Iterator it = bd.listIterator(); it.hasNext();) {
/* 405 */       if (it.next() instanceof MethodDeclaration) {
/* 406 */         methodCount++;
/*     */       }
/*     */     } 
/* 409 */     MethodDeclaration[] methods = new MethodDeclaration[methodCount];
/* 410 */     int next = 0;
/* 411 */     for (Iterator iterator1 = bd.listIterator(); iterator1.hasNext(); ) {
/* 412 */       Object decl = iterator1.next();
/* 413 */       if (decl instanceof MethodDeclaration) {
/* 414 */         methods[next++] = (MethodDeclaration)decl;
/*     */       }
/*     */     } 
/* 417 */     return methods;
/*     */   }
/*     */ 
/*     */   
/*     */   ITypeBinding internalResolveBinding() {
/* 422 */     return this.ast.getBindingResolver().resolveType(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 427 */     return super.memSize() + 16;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 432 */     return memSize() + (
/* 433 */       (this.optionalDocComment == null) ? 0 : getJavadoc().treeSize()) + (
/* 434 */       (this.modifiers == null) ? 0 : this.modifiers.listSize()) + (
/* 435 */       (this.typeName == null) ? 0 : getName().treeSize()) + (
/* 436 */       (this.typeParameters == null) ? 0 : this.typeParameters.listSize()) + (
/* 437 */       (this.superInterfaceTypes == null) ? 0 : this.superInterfaceTypes.listSize()) + (
/* 438 */       (this.recordComponents == null) ? 0 : this.recordComponents.listSize()) + 
/* 439 */       this.bodyDeclarations.listSize();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   SimplePropertyDescriptor internalModifiersProperty() {
/* 445 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\RecordDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */