/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BlockComment
/*     */   extends Comment
/*     */ {
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */   
/*     */   static {
/*  50 */     List properyList = new ArrayList(1);
/*  51 */     createPropertyList(BlockComment.class, properyList);
/*  52 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  67 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BlockComment(AST ast) {
/*  79 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  84 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/*  89 */     return 64;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/*  94 */     BlockComment result = new BlockComment(target);
/*  95 */     result.setSourceRange(getStartPosition(), getLength());
/*  96 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 102 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 107 */     visitor.visit(this);
/* 108 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 113 */     return super.memSize();
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 118 */     return memSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\BlockComment.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */