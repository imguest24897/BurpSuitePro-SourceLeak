package org.eclipse.jdt.core.jdom;

public interface IDOMFactory {
  IDOMCompilationUnit createCompilationUnit();
  
  IDOMCompilationUnit createCompilationUnit(char[] paramArrayOfchar, String paramString);
  
  IDOMCompilationUnit createCompilationUnit(String paramString1, String paramString2);
  
  IDOMField createField();
  
  IDOMField createField(String paramString);
  
  IDOMImport createImport();
  
  IDOMImport createImport(String paramString);
  
  IDOMInitializer createInitializer();
  
  IDOMInitializer createInitializer(String paramString);
  
  IDOMMethod createMethod();
  
  IDOMMethod createMethod(String paramString);
  
  IDOMPackage createPackage();
  
  IDOMPackage createPackage(String paramString);
  
  IDOMType createType();
  
  IDOMType createClass();
  
  IDOMType createInterface();
  
  IDOMType createType(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\jdom\IDOMFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */