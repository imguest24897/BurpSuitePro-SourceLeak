package org.eclipse.jdt.core.dom;

class NodeEventHandler {
  void preRemoveChildEvent(ASTNode node, ASTNode child, StructuralPropertyDescriptor property) {}
  
  void postRemoveChildEvent(ASTNode node, ASTNode child, StructuralPropertyDescriptor property) {}
  
  void preReplaceChildEvent(ASTNode node, ASTNode child, ASTNode newChild, StructuralPropertyDescriptor property) {}
  
  void postReplaceChildEvent(ASTNode node, ASTNode child, ASTNode newChild, StructuralPropertyDescriptor property) {}
  
  void preAddChildEvent(ASTNode node, ASTNode child, StructuralPropertyDescriptor property) {}
  
  void postAddChildEvent(ASTNode node, ASTNode child, StructuralPropertyDescriptor property) {}
  
  void preValueChangeEvent(ASTNode node, SimplePropertyDescriptor property) {}
  
  void postValueChangeEvent(ASTNode node, SimplePropertyDescriptor property) {}
  
  void preCloneNodeEvent(ASTNode node) {}
  
  void postCloneNodeEvent(ASTNode node, ASTNode clone) {}
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\NodeEventHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */