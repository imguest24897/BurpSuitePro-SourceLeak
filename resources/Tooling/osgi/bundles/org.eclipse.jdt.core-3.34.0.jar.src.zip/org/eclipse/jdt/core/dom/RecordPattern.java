/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.core.dom.util.DOMASTUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordPattern
/*     */   extends Pattern
/*     */ {
/*  40 */   public static final ChildListPropertyDescriptor PATTERNS_PROPERTY = new ChildListPropertyDescriptor(RecordPattern.class, "patterns", Pattern.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final ChildPropertyDescriptor PATTERN_TYPE_PROPERTY = new ChildPropertyDescriptor(RecordPattern.class, "patternType", Type.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public static final ChildPropertyDescriptor PATTERN_NAME_PROPERTY = new ChildPropertyDescriptor(RecordPattern.class, "patternName", SimpleName.class, false, true);
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */   
/*     */   private SimpleName optionalPatternName;
/*     */   
/*     */   private Type patternType;
/*     */   private ASTNode.NodeList patterns;
/*     */   
/*     */   static {
/*  62 */     List properyList = new ArrayList(5);
/*  63 */     createPropertyList(RecordPattern.class, properyList);
/*  64 */     addProperty(PATTERN_TYPE_PROPERTY, properyList);
/*  65 */     addProperty(PATTERNS_PROPERTY, properyList);
/*  66 */     addProperty(PATTERN_NAME_PROPERTY, properyList);
/*  67 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */   
/*     */   int getNodeType0() {
/*  72 */     return 113;
/*     */   }
/*     */   
/*     */   RecordPattern(AST ast) {
/*  76 */     super(ast);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     this.optionalPatternName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     this.patternType = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     this
/*  98 */       .patterns = new ASTNode.NodeList(this, PATTERNS_PROPERTY);
/*     */     supportedOnlyIn20();
/*     */     unsupportedWithoutPreviewError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 111 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel, boolean previewEnabled) {
/* 126 */     if (DOMASTUtil.isPatternSupported(apiLevel, previewEnabled)) {
/* 127 */       return PROPERTY_DESCRIPTORS;
/*     */     }
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 134 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel, boolean previewEnabled) {
/* 139 */     return propertyDescriptors(apiLevel, previewEnabled);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 144 */     if (property == PATTERN_TYPE_PROPERTY) {
/* 145 */       if (get) {
/* 146 */         return getPatternType();
/*     */       }
/* 148 */       setPatternType((Type)child);
/* 149 */       return null;
/*     */     } 
/* 151 */     if (property == PATTERN_NAME_PROPERTY) {
/* 152 */       if (get) {
/* 153 */         return getPatternName();
/*     */       }
/* 155 */       setPatternName((SimpleName)child);
/* 156 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 160 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 165 */     if (property == PATTERNS_PROPERTY) {
/* 166 */       return patterns();
/*     */     }
/*     */     
/* 169 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPatternName(SimpleName patternName) {
/* 187 */     supportedOnlyIn20();
/* 188 */     unsupportedWithoutPreviewError();
/* 189 */     if (patternName == null) {
/* 190 */       throw new IllegalArgumentException();
/*     */     }
/* 192 */     ASTNode oldChild = this.optionalPatternName;
/* 193 */     preReplaceChild(oldChild, patternName, PATTERN_NAME_PROPERTY);
/* 194 */     this.optionalPatternName = patternName;
/* 195 */     postReplaceChild(oldChild, patternName, PATTERN_NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPatternType(Type patternType) {
/* 213 */     supportedOnlyIn20();
/* 214 */     unsupportedWithoutPreviewError();
/* 215 */     if (patternType == null) {
/* 216 */       throw new IllegalArgumentException();
/*     */     }
/* 218 */     ASTNode oldChild = this.patternType;
/* 219 */     preReplaceChild(oldChild, patternType, PATTERN_TYPE_PROPERTY);
/* 220 */     this.patternType = patternType;
/* 221 */     postReplaceChild(oldChild, patternType, PATTERN_TYPE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getPatternName() {
/* 233 */     supportedOnlyIn20();
/* 234 */     unsupportedWithoutPreviewError();
/* 235 */     return this.optionalPatternName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getPatternType() {
/* 247 */     supportedOnlyIn20();
/* 248 */     unsupportedWithoutPreviewError();
/* 249 */     if (this.patternType == null)
/*     */     {
/* 251 */       synchronized (this) {
/* 252 */         if (this.patternType == null) {
/* 253 */           preLazyInit();
/* 254 */           this.patternType = this.ast.newPrimitiveType(PrimitiveType.INT);
/* 255 */           postLazyInit(this.patternType, PATTERN_TYPE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 259 */     return this.patternType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Pattern> patterns() {
/* 273 */     supportedOnlyIn20();
/* 274 */     unsupportedWithoutPreviewError();
/* 275 */     return this.patterns;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 281 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 286 */     RecordPattern result = new RecordPattern(target);
/* 287 */     result.setSourceRange(getStartPosition(), getLength());
/* 288 */     result.patterns().addAll(ASTNode.copySubtrees(target, patterns()));
/* 289 */     result.setPatternType((Type)getPatternType().clone(target));
/* 290 */     result.setPatternName((SimpleName)getPatternName().clone(target));
/* 291 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 296 */     boolean visitChildren = visitor.visit(this);
/* 297 */     if (visitChildren) {
/*     */       
/* 299 */       acceptChildren(visitor, this.patterns);
/* 300 */       acceptChild(visitor, getPatternType());
/* 301 */       acceptChild(visitor, getPatternName());
/*     */     } 
/* 303 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 309 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 314 */     return 
/* 315 */       memSize() + (
/* 316 */       (this.patternType == null) ? 0 : getPatternType().treeSize()) + (
/* 317 */       (this.optionalPatternName == null) ? 0 : getPatternName().treeSize()) + 
/* 318 */       this.patterns.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\RecordPattern.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */