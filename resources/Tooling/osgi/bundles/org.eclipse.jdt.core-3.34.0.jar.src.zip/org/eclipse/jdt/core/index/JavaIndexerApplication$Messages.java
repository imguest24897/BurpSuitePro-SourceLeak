/*    */ package org.eclipse.jdt.core.index;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class Messages
/*    */   extends NLS
/*    */ {
/*    */   private static final String MESSAGES_NAME = "org.eclipse.jdt.core.index.messages";
/*    */   public static String CommandLineProcessing;
/*    */   public static String CommandLineUsage;
/*    */   public static String CommandLineOnlyOneOutputError;
/*    */   public static String CommandLineOutputTakesArgs;
/*    */   public static String CommandLineOnlyOneJarError;
/*    */   public static String CommandLineJarNotSpecified;
/*    */   public static String CommandLineIndexFileNotSpecified;
/*    */   public static String CaughtException;
/*    */   public static String CommandLineJarFileNotExist;
/*    */   
/*    */   static {
/* 56 */     NLS.initializeMessages("org.eclipse.jdt.core.index.messages", Messages.class);
/*    */   }
/*    */   
/*    */   public static String bind(String message) {
/* 60 */     return bind(message, (Object[])null);
/*    */   }
/*    */   
/*    */   public static String bind(String message, Object binding) {
/* 64 */     return bind(message, new Object[] { binding });
/*    */   }
/*    */   
/*    */   public static String bind(String message, Object binding1, Object binding2) {
/* 68 */     return bind(message, new Object[] { binding1, binding2 });
/*    */   }
/*    */   
/*    */   public static String bind(String message, Object[] bindings) {
/* 72 */     return MessageFormat.format(message, bindings);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\index\JavaIndexerApplication$Messages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */