/*    */ package org.eclipse.jdt.core.provisional;
/*    */ 
/*    */ import org.eclipse.jdt.core.IJavaElement;
/*    */ import org.eclipse.jdt.core.IModuleDescription;
/*    */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*    */ import org.eclipse.jdt.core.JavaModelException;
/*    */ import org.eclipse.jdt.internal.core.JavaProject;
/*    */ import org.eclipse.jdt.internal.core.PackageFragmentRoot;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaModelAccess
/*    */ {
/*    */   @Deprecated
/*    */   public static String[] getRequiredModules(IModuleDescription module) throws JavaModelException {
/* 37 */     return module.getRequiredModuleNames();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static IModuleDescription getAutomaticModuleDescription(IJavaElement element) throws JavaModelException, IllegalArgumentException {
/* 57 */     switch (element.getElementType()) {
/*    */       case 2:
/* 59 */         return ((JavaProject)element).getAutomaticModuleDescription();
/*    */       case 3:
/* 61 */         return ((PackageFragmentRoot)element).getAutomaticModuleDescription();
/*    */     } 
/* 63 */     throw new IllegalArgumentException("Illegal kind of java element: " + element.getElementType());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public static boolean isSystemModule(IModuleDescription module) {
/* 78 */     IPackageFragmentRoot pfr = (IPackageFragmentRoot)module.getAncestor(3);
/* 79 */     return pfr instanceof org.eclipse.jdt.internal.core.JrtPackageFragmentRoot;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\provisional\JavaModelAccess.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */