/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ import org.eclipse.jdt.internal.compiler.ast.FieldDeclaration;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnFieldName
/*    */   extends FieldDeclaration
/*    */ {
/* 21 */   private static final char[] FAKENAMESUFFIX = " ".toCharArray();
/*    */   
/*    */   public CompletionOnFieldName(char[] name, int sourceStart, int sourceEnd) {
/* 24 */     super(CharOperation.concat(name, FAKENAMESUFFIX), sourceStart, sourceEnd);
/* 25 */     this.realName = name;
/*    */   }
/*    */   
/*    */   public char[] realName;
/*    */   
/*    */   public StringBuffer printStatement(int tab, StringBuffer output) {
/* 31 */     printIndent(tab, output).append("<CompleteOnFieldName:");
/* 32 */     if (this.type != null) this.type.print(0, output).append(' '); 
/* 33 */     output.append(this.realName);
/* 34 */     if (this.initialization != null) {
/* 35 */       output.append(" = ");
/* 36 */       this.initialization.printExpression(0, output);
/*    */     } 
/* 38 */     return output.append(">;");
/*    */   }
/*    */ 
/*    */   
/*    */   public void resolve(MethodScope initializationScope) {
/* 43 */     super.resolve(initializationScope);
/*    */     
/* 45 */     throw new CompletionNodeFound(this, initializationScope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnFieldName.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */