/*     */ package org.eclipse.jdt.core.util;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IFolder;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.core.dom.IMethodBinding;
/*     */ import org.eclipse.jdt.core.dom.ITypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.codegen.ConstantPool;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.SignatureWrapper;
/*     */ import org.eclipse.jdt.internal.core.util.KeyToSignature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExternalAnnotationUtil
/*     */ {
/*     */   public static final char NULLABLE = '0';
/*     */   public static final char NONNULL = '1';
/*     */   public static final char NO_ANNOTATION = '@';
/*     */   private static final int POSITION_RETURN_TYPE = -1;
/*     */   private static final int POSITION_FULL_SIGNATURE = -2;
/*     */   private static final int POSITION_TYPE_PARAMETER = -3;
/*     */   
/*     */   public enum MergeStrategy
/*     */   {
/*  69 */     REPLACE_SIGNATURE,
/*     */     
/*  71 */     OVERWRITE_ANNOTATIONS,
/*     */     
/*  73 */     ADD_ANNOTATIONS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String extractGenericSignature(IMethodBinding methodBinding) {
/*  88 */     KeyToSignature parser = new KeyToSignature(methodBinding.getKey(), 0, true);
/*  89 */     parser.parse();
/*  90 */     return parser.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String extractGenericTypeSignature(ITypeBinding type) {
/*  99 */     KeyToSignature parser = new KeyToSignature(type.getKey(), 0, true);
/* 100 */     parser.parse();
/* 101 */     return parser.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String extractGenericTypeParametersSignature(ITypeBinding type) {
/* 111 */     StringBuilder signature = (new StringBuilder()).append('<'); byte b; int i; ITypeBinding[] arrayOfITypeBinding;
/* 112 */     for (i = (arrayOfITypeBinding = type.getTypeParameters()).length, b = 0; b < i; ) { ITypeBinding typeParameter = arrayOfITypeBinding[b];
/* 113 */       signature.append(typeParameter.getName());
/*     */       
/* 115 */       signature.append(':');
/* 116 */       ITypeBinding superclass = typeParameter.getSuperclass();
/* 117 */       if (superclass != null) {
/* 118 */         String superclassSignature = extractGenericTypeSignature(superclass);
/* 119 */         boolean superIsRelevant = ((typeParameter.getInterfaces()).length == 0);
/* 120 */         int k = superIsRelevant | (superclassSignature.equals(new String(ConstantPool.JavaLangObjectSignature)) ? 0 : 1);
/* 121 */         if (k != 0)
/* 122 */           signature.append(superclassSignature); 
/*     */       }  byte b1;
/*     */       int j;
/*     */       ITypeBinding[] arrayOfITypeBinding1;
/* 126 */       for (j = (arrayOfITypeBinding1 = typeParameter.getInterfaces()).length, b1 = 0; b1 < j; ) { ITypeBinding superInterface = arrayOfITypeBinding1[b1];
/* 127 */         signature.append(':').append(extractGenericTypeSignature(superInterface)); b1++; }
/*     */        b++; }
/*     */     
/* 130 */     signature.append('>');
/* 131 */     return signature.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String insertReturnAnnotation(String methodSignature, char annotation, MergeStrategy mergeStrategy) {
/* 148 */     int close = methodSignature.indexOf(')');
/* 149 */     if (close == -1 || close > methodSignature.length() - 4)
/* 150 */       throw new IllegalArgumentException("Malformed method signature"); 
/* 151 */     switch (methodSignature.charAt(close + 1)) { case 'L': case 'T':
/*     */       case '[':
/* 153 */         return insertAt(methodSignature, close + 2, annotation, mergeStrategy); }
/*     */     
/* 155 */     throw new IllegalArgumentException("Return type is not a reference type");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String insertParameterAnnotation(String methodSignature, int paramIdx, char annotation, MergeStrategy mergeStrategy) {
/* 174 */     SignatureWrapper wrapper = new SignatureWrapper(methodSignature.toCharArray());
/* 175 */     wrapper.start = 1;
/* 176 */     for (int i = 0; i < paramIdx; i++)
/* 177 */       wrapper.start = wrapper.computeEnd() + 1; 
/* 178 */     int start = wrapper.start;
/* 179 */     switch (methodSignature.charAt(start)) { case 'L': case 'T':
/*     */       case '[':
/* 181 */         return insertAt(methodSignature, start + 1, annotation, mergeStrategy); }
/*     */     
/* 183 */     throw new IllegalArgumentException("Paramter type is not a reference type");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IFile getAnnotationFile(IJavaProject project, ITypeBinding type, IProgressMonitor monitor) throws CoreException {
/* 201 */     IType targetType = project.findType(type.getErasure().getQualifiedName());
/* 202 */     if (!targetType.exists()) {
/* 203 */       return null;
/*     */     }
/* 205 */     String binaryTypeName = targetType.getFullyQualifiedName('$').replace('.', '/');
/*     */     
/* 207 */     IPackageFragmentRoot packageRoot = (IPackageFragmentRoot)targetType.getAncestor(3);
/* 208 */     IClasspathEntry entry = packageRoot.getResolvedClasspathEntry();
/* 209 */     IPath annotationPath = entry.getExternalAnnotationPath(project.getProject(), false);
/*     */     
/* 211 */     if (annotationPath == null) {
/* 212 */       return null;
/*     */     }
/* 214 */     IWorkspaceRoot workspaceRoot = project.getProject().getWorkspace().getRoot();
/*     */     
/* 216 */     if (annotationPath.segmentCount() > 1) {
/* 217 */       IFile annotationZip = workspaceRoot.getFile(annotationPath);
/* 218 */       if (annotationZip.exists()) {
/* 219 */         return null;
/*     */       }
/*     */     } 
/* 222 */     annotationPath = annotationPath.append(binaryTypeName).addFileExtension("eea");
/* 223 */     return workspaceRoot.getFile(annotationPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void annotateMember(String typeName, IFile file, String selector, String originalSignature, String annotatedSignature, MergeStrategy mergeStrategy, IProgressMonitor monitor) throws CoreException, IOException {
/* 247 */     annotateMember(typeName, file, selector, originalSignature, annotatedSignature, -2, mergeStrategy, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void annotateTypeTypeParameter(String typeName, IFile file, String originalSignature, String annotatedTypeParameter, int rank, MergeStrategy mergeStrategy, IProgressMonitor monitor) throws CoreException, IOException, IllegalArgumentException {
/* 273 */     annotateMember(typeName, file, null, originalSignature, annotatedTypeParameter, -3 - rank, mergeStrategy, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void annotateMethodTypeParameter(String typeName, IFile file, String selector, String originalSignature, String annotatedTypeParameter, int rank, MergeStrategy mergeStrategy, IProgressMonitor monitor) throws CoreException, IOException, IllegalArgumentException {
/* 300 */     annotateMember(typeName, file, selector, originalSignature, annotatedTypeParameter, -3 - rank, mergeStrategy, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void annotateMethodReturnType(String typeName, IFile file, String selector, String originalSignature, String annotatedReturnType, MergeStrategy mergeStrategy, IProgressMonitor monitor) throws CoreException, IOException, IllegalArgumentException {
/* 325 */     annotateMember(typeName, file, selector, originalSignature, annotatedReturnType, -1, mergeStrategy, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void annotateMethodParameterType(String typeName, IFile file, String selector, String originalSignature, String annotatedParameterType, int paramIdx, MergeStrategy mergeStrategy, IProgressMonitor monitor) throws CoreException, IOException, IllegalArgumentException {
/* 351 */     annotateMember(typeName, file, selector, originalSignature, annotatedParameterType, paramIdx, mergeStrategy, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void annotateMember(String typeName, IFile file, String selector, String originalSignature, String annotatedSignature, int updatePosition, MergeStrategy mergeStrategy, IProgressMonitor monitor) throws CoreException, IOException, IllegalArgumentException {
/* 359 */     if (!file.exists()) {
/*     */       
/* 361 */       annotatedSignature = updateSignature(originalSignature, annotatedSignature, updatePosition, MergeStrategy.REPLACE_SIGNATURE);
/*     */       
/* 363 */       StringBuffer newContent = new StringBuffer();
/*     */       
/* 365 */       newContent.append("class ");
/* 366 */       newContent.append(typeName).append('\n');
/*     */       
/* 368 */       if (selector != null) {
/* 369 */         newContent.append(selector).append('\n');
/*     */       }
/* 371 */       newContent.append(' ').append(originalSignature).append('\n');
/* 372 */       newContent.append(' ').append(annotatedSignature).append('\n');
/*     */       
/* 374 */       createNewFile(file, newContent.toString(), monitor);
/*     */     } else {
/* 376 */       BufferedReader reader = new BufferedReader(new InputStreamReader(file.getContents()));
/* 377 */       StringBuffer newContent = new StringBuffer();
/*     */       
/*     */       try {
/* 380 */         String previousSignature = originalSignature;
/* 381 */         newContent.append(reader.readLine()).append('\n');
/*     */         String line;
/* 383 */         while ((line = reader.readLine()) != null) {
/* 384 */           if (selector == null) {
/* 385 */             if (line.trim().startsWith("<")) {
/* 386 */               line = reader.readLine();
/* 387 */               assert line.trim().startsWith("<");
/*     */ 
/*     */               
/* 390 */               previousSignature = line.trim();
/* 391 */               line = reader.readLine();
/*     */             } 
/*     */             break;
/*     */           } 
/* 395 */           if (line.isEmpty()) {
/* 396 */             newContent.append('\n');
/*     */             continue;
/*     */           } 
/* 399 */           if (!Character.isJavaIdentifierStart(line.charAt(0)) && line.charAt(0) != '<') {
/* 400 */             newContent.append(line).append('\n');
/*     */             
/*     */             continue;
/*     */           } 
/* 404 */           int relation = line.compareTo(selector);
/* 405 */           if (relation > 0) {
/*     */             break;
/*     */           }
/* 408 */           if (relation < 0) {
/* 409 */             newContent.append(line).append('\n');
/*     */             continue;
/*     */           } 
/* 412 */           if (relation == 0) {
/* 413 */             StringBuffer pending = (new StringBuffer(line)).append('\n');
/* 414 */             pending.append(line = reader.readLine());
/* 415 */             if (line == null) {
/*     */               break;
/*     */             }
/*     */             
/* 419 */             relation = line.trim().compareTo(originalSignature);
/* 420 */             if (relation > 0) {
/*     */               
/* 422 */               line = pending.toString();
/*     */               break;
/*     */             } 
/* 425 */             newContent.append(pending).append('\n');
/* 426 */             if (relation < 0)
/*     */               continue; 
/* 428 */             if (relation == 0) {
/*     */               
/* 430 */               String annotationLine = reader.readLine();
/* 431 */               String nextLine = null;
/* 432 */               if (annotationLine == null || annotationLine.isEmpty() || !annotationLine.startsWith(" ")) {
/* 433 */                 nextLine = annotationLine;
/* 434 */                 annotationLine = line;
/*     */               } 
/* 436 */               if (annotationLine.startsWith(" "))
/* 437 */                 switch (mergeStrategy) {
/*     */                   case REPLACE_SIGNATURE:
/*     */                     break;
/*     */                   case OVERWRITE_ANNOTATIONS:
/*     */                   case null:
/* 442 */                     annotatedSignature = updateSignature(annotationLine.trim(), annotatedSignature, updatePosition, mergeStrategy);
/*     */                     break;
/*     */                   default:
/* 445 */                     JavaCore.getJavaCore().getLog().log((IStatus)new Status(4, "org.eclipse.jdt.core", 
/* 446 */                           "Unexpected value for enum MergeStrategy"));
/*     */                     break;
/*     */                 }  
/* 449 */               writeFile(file, newContent, annotatedSignature, nextLine, reader, monitor);
/*     */               
/*     */               return;
/*     */             } 
/*     */           } 
/*     */         } 
/* 455 */         if (selector != null)
/* 456 */           newContent.append(selector).append('\n'); 
/* 457 */         newContent.append(' ').append(originalSignature).append('\n');
/* 458 */         annotatedSignature = updateSignature(previousSignature, annotatedSignature, updatePosition, mergeStrategy);
/* 459 */         writeFile(file, newContent, annotatedSignature, line, reader, monitor);
/*     */       } finally {
/* 461 */         reader.close();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String updateSignature(String originalSignature, String annotatedSignature, int updatePosition, MergeStrategy mergeStrategy) {
/* 467 */     StringBuffer buf = new StringBuffer();
/*     */     
/* 469 */     String postfix = null;
/* 470 */     if (updatePosition <= -3) {
/*     */       
/* 472 */       assert originalSignature.charAt(0) == '<' : "generic signature must start with '<'";
/* 473 */       SignatureWrapper wrapper = new SignatureWrapper(originalSignature.toCharArray(), true, true);
/* 474 */       wrapper.start = 1;
/*     */       
/* 476 */       for (int i = 0; i < -updatePosition + -3; i++) {
/* 477 */         wrapper.skipTypeParameter();
/*     */       }
/* 479 */       int start = wrapper.start;
/*     */       
/* 481 */       buf.append(originalSignature, 0, start);
/*     */       
/* 483 */       int end = wrapper.skipTypeParameter();
/* 484 */       String signatureToReplace = originalSignature.substring(start, end);
/* 485 */       updateTypeParameter(buf, signatureToReplace.toCharArray(), annotatedSignature.toCharArray(), mergeStrategy);
/*     */       
/* 487 */       postfix = originalSignature.substring(end, originalSignature.length());
/*     */     } else {
/* 489 */       String signatureToReplace; int close; SignatureWrapper wrapper; int i, start, end; switch (updatePosition) {
/*     */         case -2:
/* 491 */           signatureToReplace = originalSignature;
/*     */           break;
/*     */         case -1:
/* 494 */           assert originalSignature.charAt(0) == '(' || originalSignature.charAt(0) == '<' : "signature must start with '(' or '<'";
/* 495 */           close = originalSignature.indexOf(')');
/* 496 */           buf.append(originalSignature, 0, close + 1);
/* 497 */           signatureToReplace = originalSignature.substring(close + 1);
/*     */           break;
/*     */         default:
/* 500 */           wrapper = new SignatureWrapper(originalSignature.toCharArray(), true, true);
/* 501 */           wrapper.start = CharOperation.indexOf('(', wrapper.signature) + 1;
/* 502 */           for (i = 0; i < updatePosition; i++)
/* 503 */             wrapper.start = wrapper.skipAngleContents(wrapper.computeEnd()) + 1; 
/* 504 */           start = wrapper.start;
/* 505 */           end = wrapper.skipAngleContents(wrapper.computeEnd());
/* 506 */           buf.append(originalSignature, 0, start);
/* 507 */           signatureToReplace = originalSignature.substring(start, end + 1);
/* 508 */           postfix = originalSignature.substring(end + 1, originalSignature.length()); break;
/*     */       } 
/* 510 */       updateType(buf, signatureToReplace.toCharArray(), annotatedSignature.toCharArray(), mergeStrategy);
/*     */     } 
/* 512 */     if (postfix != null)
/* 513 */       buf.append(postfix); 
/* 514 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String insertAt(String signature, int position, char annotation, MergeStrategy mergeStrategy) {
/* 523 */     StringBuilder result = new StringBuilder();
/* 524 */     result.append(signature, 0, position);
/* 525 */     result.append(annotation);
/* 526 */     char next = signature.charAt(position);
/* 527 */     switch (next) { case '0':
/*     */       case '1':
/* 529 */         if (mergeStrategy == MergeStrategy.ADD_ANNOTATIONS)
/* 530 */           return signature; 
/* 531 */         position++; break; }
/*     */     
/* 533 */     result.append(signature, position, signature.length());
/* 534 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean updateType(StringBuffer buf, char[] oldType, char[] newType, MergeStrategy mergeStrategy) {
/* 542 */     if (mergeStrategy == MergeStrategy.REPLACE_SIGNATURE) {
/* 543 */       buf.append(newType);
/* 544 */       return false;
/*     */     } 
/*     */     try {
/* 547 */       SignatureWrapper oWrap = new SignatureWrapper(oldType, true, true);
/* 548 */       SignatureWrapper nWrap = new SignatureWrapper(newType, true, true);
/* 549 */       if (match(buf, oWrap, nWrap, 'L', false) || 
/* 550 */         match(buf, oWrap, nWrap, 'T', false))
/*     */       
/* 552 */       { mergeAnnotation(buf, oWrap, nWrap, mergeStrategy);
/* 553 */         buf.append(oWrap.nextName());
/* 554 */         nWrap.nextName();
/* 555 */         if (match(buf, oWrap, nWrap, '<', false)) {
/*     */           do {
/* 557 */             int oStart = oWrap.start;
/* 558 */             int nStart = nWrap.start;
/* 559 */             oWrap.computeEnd();
/* 560 */             nWrap.computeEnd();
/* 561 */             if (!updateType(buf, oWrap.getFrom(oStart), nWrap.getFrom(nStart), mergeStrategy))
/* 562 */               continue;  mergeAnnotation(buf, oWrap, nWrap, mergeStrategy);
/* 563 */           } while (!match(buf, oWrap, nWrap, '>', false));
/*     */         }
/* 565 */         match(buf, oWrap, nWrap, ';', true); }
/* 566 */       else if (match(buf, oWrap, nWrap, '[', false))
/* 567 */       { mergeAnnotation(buf, oWrap, nWrap, mergeStrategy);
/* 568 */         updateType(buf, oWrap.tail(), nWrap.tail(), mergeStrategy); }
/* 569 */       else { if (match(buf, oWrap, nWrap, '*', false) || 
/* 570 */           match(buf, oWrap, nWrap, '+', false) || 
/* 571 */           match(buf, oWrap, nWrap, '-', false))
/*     */         {
/* 573 */           return true;
/*     */         }
/* 575 */         buf.append(oldType); }
/*     */     
/* 577 */     } catch (ArrayIndexOutOfBoundsException aioobe) {
/* 578 */       StringBuilder msg = (new StringBuilder("Structural mismatch between ")).append(oldType).append(" and ").append(newType);
/* 579 */       throw new IllegalArgumentException(msg.toString(), aioobe);
/*     */     } 
/* 581 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean updateTypeParameter(StringBuffer buf, char[] oldType, char[] newType, MergeStrategy mergeStrategy) {
/* 588 */     if (mergeStrategy == MergeStrategy.REPLACE_SIGNATURE) {
/* 589 */       buf.append(newType);
/* 590 */       return false;
/*     */     } 
/*     */     try {
/* 593 */       SignatureWrapper oWrap = new SignatureWrapper(oldType, true, true);
/* 594 */       SignatureWrapper nWrap = new SignatureWrapper(newType, true, true);
/*     */       
/* 596 */       mergeAnnotation(buf, oWrap, nWrap, mergeStrategy);
/*     */       
/* 598 */       char[] oName = oWrap.wordUntil(':');
/* 599 */       char[] nName = nWrap.wordUntil(':');
/* 600 */       if (!CharOperation.equals(oName, nName)) {
/* 601 */         StringBuilder msg = (new StringBuilder("Structural mismatch between type parameters ")).append(oName).append(" and ").append(nName);
/* 602 */         throw new IllegalArgumentException(msg.toString());
/*     */       } 
/* 604 */       buf.append(oName);
/*     */       
/* 606 */       while (match(buf, oWrap, nWrap, ':', false)) {
/* 607 */         char[] oType; int oStart = oWrap.start;
/* 608 */         int nStart = nWrap.start;
/* 609 */         nWrap.skipAngleContents(nWrap.computeEnd());
/* 610 */         char[] nType = nWrap.getFrom(nStart);
/*     */         
/* 612 */         if (oWrap.charAtStart() == ':') {
/*     */           
/* 614 */           if (CharOperation.equals(nType, new char[] { ':' })) {
/* 615 */             nWrap.start--;
/*     */             continue;
/*     */           } 
/* 618 */           if (CharOperation.equals(nType, ConstantPool.JavaLangObjectSignature)) {
/*     */             continue;
/*     */           }
/*     */ 
/*     */           
/* 623 */           oType = ConstantPool.JavaLangObjectSignature;
/*     */         } else {
/* 625 */           oWrap.skipAngleContents(oWrap.computeEnd());
/* 626 */           oType = oWrap.getFrom(oStart);
/*     */         } 
/* 628 */         if (updateType(buf, oType, nType, mergeStrategy))
/* 629 */           mergeAnnotation(buf, oWrap, nWrap, mergeStrategy); 
/* 630 */         if (oWrap.atEnd() || nWrap.atEnd())
/* 631 */           return false; 
/*     */       } 
/* 633 */     } catch (ArrayIndexOutOfBoundsException aioobe) {
/* 634 */       StringBuilder msg = (new StringBuilder("Structural mismatch between ")).append(oldType).append(" and ").append(newType);
/* 635 */       throw new IllegalArgumentException(msg.toString(), aioobe);
/*     */     } 
/* 637 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean match(StringBuffer buf, SignatureWrapper sig1, SignatureWrapper sig2, char expected, boolean force) {
/* 645 */     boolean match1 = (sig1.signature[sig1.start] == expected);
/* 646 */     boolean match2 = (sig2.signature[sig2.start] == expected);
/* 647 */     if (match1 != match2) {
/* 648 */       StringBuilder msg = (new StringBuilder("Mismatching type structures "))
/* 649 */         .append(sig1.signature).append(" vs ").append(sig2.signature);
/* 650 */       throw new IllegalArgumentException(msg.toString());
/*     */     } 
/* 652 */     if (match1) {
/* 653 */       buf.append(expected);
/* 654 */       sig1.start++;
/* 655 */       sig2.start++;
/* 656 */       return true;
/* 657 */     }  if (force) {
/* 658 */       throw new IllegalArgumentException("Expected char " + expected + " not found in " + new String(sig1.signature));
/*     */     }
/* 660 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void mergeAnnotation(StringBuffer buf, SignatureWrapper oldS, SignatureWrapper newS, MergeStrategy mergeStrategy) {
/* 670 */     char oldAnn = !oldS.atEnd() ? oldS.signature[oldS.start] : Character.MIN_VALUE;
/* 671 */     char newAnn = !newS.atEnd() ? newS.signature[newS.start] : Character.MIN_VALUE;
/* 672 */     switch (mergeStrategy) {
/*     */       case null:
/* 674 */         switch (oldAnn) { case '0':
/*     */           case '1':
/* 676 */             oldS.start++;
/* 677 */             buf.append(oldAnn);
/* 678 */             switch (newAnn) { case '0': case '1': newS.start++; break; }
/*     */             
/*     */             return; }
/*     */       
/*     */       case OVERWRITE_ANNOTATIONS:
/* 683 */         switch (newAnn) { case '0':
/*     */           case '1':
/* 685 */             newS.start++;
/* 686 */             buf.append(newAnn);
/* 687 */             switch (oldAnn) { case '0': case '1': oldS.start++; break; }
/*     */              return;
/*     */           case '@':
/* 690 */             newS.start++;
/* 691 */             switch (oldAnn) { case '0': case '1': oldS.start++; break; }
/*     */              return; }
/*     */         
/* 694 */         switch (oldAnn) { case '0':
/*     */           case '1':
/* 696 */             oldS.start++;
/* 697 */             buf.append(oldAnn);
/*     */             break; }
/*     */         
/*     */         return;
/*     */     } 
/* 702 */     throw new IllegalArgumentException("Unexpected merge strategy");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void writeFile(IFile annotationFile, StringBuffer head, String annotatedSignature, String nextLines, BufferedReader tailReader, IProgressMonitor monitor) throws CoreException, IOException {
/* 717 */     head.append(' ').append(annotatedSignature).append('\n');
/* 718 */     if (nextLines != null)
/* 719 */       head.append(nextLines).append('\n'); 
/*     */     String line;
/* 721 */     while ((line = tailReader.readLine()) != null)
/* 722 */       head.append(line).append('\n'); 
/* 723 */     ByteArrayInputStream newContent = new ByteArrayInputStream(head.toString().getBytes("UTF-8"));
/* 724 */     annotationFile.setContents(newContent, 2, monitor);
/*     */   }
/*     */   
/*     */   private static void createNewFile(IFile file, String newContent, IProgressMonitor monitor) throws CoreException {
/* 728 */     ensureExists(file.getParent(), monitor);
/*     */     
/*     */     try {
/* 731 */       file.create(new ByteArrayInputStream(newContent.getBytes("UTF-8")), false, monitor);
/* 732 */     } catch (UnsupportedEncodingException e) {
/* 733 */       throw new CoreException(new Status(4, "org.eclipse.jdt.core", e.getMessage(), e));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void ensureExists(IContainer container, IProgressMonitor monitor) throws CoreException {
/* 738 */     if (container.exists())
/* 739 */       return;  if (!(container instanceof IFolder)) throw new CoreException(new Status(4, "org.eclipse.jdt.core", "not a folder: " + container)); 
/* 740 */     IContainer parent = container.getParent();
/* 741 */     if (parent instanceof IFolder) {
/* 742 */       ensureExists(parent, monitor);
/*     */     }
/* 744 */     ((IFolder)container).create(false, true, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getAnnotatedSignature(String typeName, IFile file, String selector, String originalSignature) {
/* 756 */     if (file.exists()) {
/* 757 */       try { Exception exception1 = null, exception2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         try {  }
/*     */         finally
/* 781 */         { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (IOException|CoreException iOException)
/* 782 */       { return null; }
/*     */     
/*     */     }
/* 785 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] annotateType(String originalSignature, String annotatedType, MergeStrategy mergeStrategy) {
/* 804 */     String[] result = new String[4];
/*     */     
/* 806 */     result[0] = "";
/* 807 */     StringBuffer buf = new StringBuffer();
/* 808 */     result[1] = originalSignature;
/* 809 */     updateType(buf, originalSignature.toCharArray(), annotatedType.toCharArray(), mergeStrategy);
/* 810 */     result[2] = buf.toString();
/* 811 */     result[3] = "";
/* 812 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] annotateReturnType(String originalSignature, String annotatedType, MergeStrategy mergeStrategy) {
/* 831 */     String[] result = new String[4];
/*     */     
/* 833 */     assert originalSignature.charAt(0) == '(' || originalSignature.charAt(0) == '<' : "signature must start with '(' or '<'";
/* 834 */     int close = originalSignature.indexOf(')');
/* 835 */     result[0] = originalSignature.substring(0, close + 1);
/* 836 */     StringBuffer buf = new StringBuffer();
/* 837 */     result[1] = originalSignature.substring(close + 1);
/* 838 */     updateType(buf, result[1].toCharArray(), annotatedType.toCharArray(), mergeStrategy);
/* 839 */     result[2] = buf.toString();
/* 840 */     result[3] = "";
/* 841 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] annotateParameterType(String originalSignature, String annotatedType, int paramIdx, MergeStrategy mergeStrategy) {
/* 862 */     String[] result = new String[4];
/*     */     
/* 864 */     SignatureWrapper wrapper = new SignatureWrapper(originalSignature.toCharArray(), true, true);
/* 865 */     wrapper.start = CharOperation.indexOf('(', wrapper.signature) + 1;
/* 866 */     for (int i = 0; i < paramIdx; i++)
/* 867 */       wrapper.start = wrapper.skipAngleContents(wrapper.computeEnd()) + 1; 
/* 868 */     int start = wrapper.start;
/* 869 */     int end = wrapper.skipAngleContents(wrapper.computeEnd());
/* 870 */     result[0] = originalSignature.substring(0, start);
/* 871 */     StringBuffer buf = new StringBuffer();
/* 872 */     result[1] = originalSignature.substring(start, end + 1);
/* 873 */     updateType(buf, result[1].toCharArray(), annotatedType.toCharArray(), mergeStrategy);
/* 874 */     result[2] = buf.toString();
/* 875 */     result[3] = originalSignature.substring(end + 1, originalSignature.length());
/* 876 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] annotateTypeParameter(String originalSignature, String annotatedType, int rank, MergeStrategy mergeStrategy) {
/* 897 */     String[] result = new String[4];
/* 898 */     StringBuffer buf = new StringBuffer();
/* 899 */     SignatureWrapper wrapper = new SignatureWrapper(originalSignature.toCharArray(), true, true);
/* 900 */     wrapper.start = 1;
/*     */     
/* 902 */     for (int i = 0; i < rank; i++) {
/* 903 */       wrapper.skipTypeParameter();
/*     */     }
/* 905 */     int start = wrapper.start;
/* 906 */     result[0] = originalSignature.substring(0, start);
/*     */     
/* 908 */     int end = wrapper.skipTypeParameter();
/* 909 */     result[1] = originalSignature.substring(start, end);
/*     */     
/* 911 */     SignatureWrapper oWrap = new SignatureWrapper(result[1].toCharArray());
/* 912 */     SignatureWrapper nWrap = new SignatureWrapper(annotatedType.toCharArray());
/* 913 */     mergeAnnotation(buf, oWrap, nWrap, mergeStrategy);
/* 914 */     updateTypeParameter(buf, oWrap.tail(), nWrap.tail(), mergeStrategy);
/* 915 */     result[2] = buf.toString();
/*     */     
/* 917 */     result[3] = originalSignature.substring(end, originalSignature.length());
/* 918 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\cor\\util\ExternalAnnotationUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */