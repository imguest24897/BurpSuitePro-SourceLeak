/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CatchClause
/*     */   extends ASTNode
/*     */ {
/*  40 */   public static final ChildPropertyDescriptor EXCEPTION_PROPERTY = new ChildPropertyDescriptor(CatchClause.class, "exception", SingleVariableDeclaration.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   public static final ChildPropertyDescriptor BODY_PROPERTY = new ChildPropertyDescriptor(CatchClause.class, "body", Block.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  57 */     List properyList = new ArrayList(3);
/*  58 */     createPropertyList(CatchClause.class, properyList);
/*  59 */     addProperty(EXCEPTION_PROPERTY, properyList);
/*  60 */     addProperty(BODY_PROPERTY, properyList);
/*  61 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  76 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private Block body = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private SingleVariableDeclaration exceptionDecl = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CatchClause(AST ast) {
/* 101 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 106 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 111 */     if (property == EXCEPTION_PROPERTY) {
/* 112 */       if (get) {
/* 113 */         return getException();
/*     */       }
/* 115 */       setException((SingleVariableDeclaration)child);
/* 116 */       return null;
/*     */     } 
/*     */     
/* 119 */     if (property == BODY_PROPERTY) {
/* 120 */       if (get) {
/* 121 */         return getBody();
/*     */       }
/* 123 */       setBody((Block)child);
/* 124 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 128 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 133 */     return 12;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 138 */     CatchClause result = new CatchClause(target);
/* 139 */     result.setSourceRange(getStartPosition(), getLength());
/* 140 */     result.setBody((Block)getBody().clone(target));
/* 141 */     result.setException(
/* 142 */         (SingleVariableDeclaration)ASTNode.copySubtree(target, getException()));
/* 143 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 149 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 154 */     boolean visitChildren = visitor.visit(this);
/* 155 */     if (visitChildren) {
/*     */       
/* 157 */       acceptChild(visitor, getException());
/* 158 */       acceptChild(visitor, getBody());
/*     */     } 
/* 160 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SingleVariableDeclaration getException() {
/* 169 */     if (this.exceptionDecl == null)
/*     */     {
/* 171 */       synchronized (this) {
/* 172 */         if (this.exceptionDecl == null) {
/* 173 */           preLazyInit();
/* 174 */           this.exceptionDecl = new SingleVariableDeclaration(this.ast);
/* 175 */           postLazyInit(this.exceptionDecl, EXCEPTION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 179 */     return this.exceptionDecl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setException(SingleVariableDeclaration exception) {
/* 194 */     if (exception == null) {
/* 195 */       throw new IllegalArgumentException();
/*     */     }
/* 197 */     ASTNode oldChild = this.exceptionDecl;
/* 198 */     preReplaceChild(oldChild, exception, EXCEPTION_PROPERTY);
/* 199 */     this.exceptionDecl = exception;
/* 200 */     postReplaceChild(oldChild, exception, EXCEPTION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Block getBody() {
/* 209 */     if (this.body == null)
/*     */     {
/* 211 */       synchronized (this) {
/* 212 */         if (this.body == null) {
/* 213 */           preLazyInit();
/* 214 */           this.body = new Block(this.ast);
/* 215 */           postLazyInit(this.body, BODY_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 219 */     return this.body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBody(Block body) {
/* 234 */     if (body == null) {
/* 235 */       throw new IllegalArgumentException();
/*     */     }
/* 237 */     ASTNode oldChild = this.body;
/* 238 */     preReplaceChild(oldChild, body, BODY_PROPERTY);
/* 239 */     this.body = body;
/* 240 */     postReplaceChild(oldChild, body, BODY_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 246 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 251 */     return 
/* 252 */       memSize() + (
/* 253 */       (this.exceptionDecl == null) ? 0 : getException().treeSize()) + (
/* 254 */       (this.body == null) ? 0 : getBody().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\CatchClause.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */