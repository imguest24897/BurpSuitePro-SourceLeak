/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VariableDeclarationStatement
/*     */   extends Statement
/*     */ {
/*  52 */   public static final SimplePropertyDescriptor MODIFIERS_PROPERTY = new SimplePropertyDescriptor(VariableDeclarationStatement.class, "modifiers", int.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   public static final ChildListPropertyDescriptor MODIFIERS2_PROPERTY = new ChildListPropertyDescriptor(VariableDeclarationStatement.class, "modifiers", IExtendedModifier.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public static final ChildPropertyDescriptor TYPE_PROPERTY = new ChildPropertyDescriptor(VariableDeclarationStatement.class, "type", Type.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public static final ChildListPropertyDescriptor FRAGMENTS_PROPERTY = new ChildListPropertyDescriptor(VariableDeclarationStatement.class, "fragments", VariableDeclarationFragment.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  92 */     List propertyList = new ArrayList(4);
/*  93 */     createPropertyList(VariableDeclarationStatement.class, propertyList);
/*  94 */     addProperty(MODIFIERS_PROPERTY, propertyList);
/*  95 */     addProperty(TYPE_PROPERTY, propertyList);
/*  96 */     addProperty(FRAGMENTS_PROPERTY, propertyList);
/*  97 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(propertyList);
/*     */     
/*  99 */     propertyList = new ArrayList(4);
/* 100 */     createPropertyList(VariableDeclarationStatement.class, propertyList);
/* 101 */     addProperty(MODIFIERS2_PROPERTY, propertyList);
/* 102 */     addProperty(TYPE_PROPERTY, propertyList);
/* 103 */     addProperty(FRAGMENTS_PROPERTY, propertyList);
/* 104 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 119 */     if (apiLevel == 2) {
/* 120 */       return PROPERTY_DESCRIPTORS_2_0;
/*     */     }
/* 122 */     return PROPERTY_DESCRIPTORS_3_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   private ASTNode.NodeList modifiers = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   private int modifierFlags = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   private Type baseType = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 151 */   private ASTNode.NodeList variableDeclarationFragments = new ASTNode.NodeList(this, FRAGMENTS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   VariableDeclarationStatement(AST ast) {
/* 165 */     super(ast);
/* 166 */     if (ast.apiLevel >= 3) {
/* 167 */       this.modifiers = new ASTNode.NodeList(this, MODIFIERS2_PROPERTY);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 173 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final int internalGetSetIntProperty(SimplePropertyDescriptor property, boolean get, int value) {
/* 178 */     if (property == MODIFIERS_PROPERTY) {
/* 179 */       if (get) {
/* 180 */         return getModifiers();
/*     */       }
/* 182 */       setModifiers(value);
/* 183 */       return 0;
/*     */     } 
/*     */ 
/*     */     
/* 187 */     return super.internalGetSetIntProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 192 */     if (property == TYPE_PROPERTY) {
/* 193 */       if (get) {
/* 194 */         return getType();
/*     */       }
/* 196 */       setType((Type)child);
/* 197 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 201 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 206 */     if (property == MODIFIERS2_PROPERTY) {
/* 207 */       return modifiers();
/*     */     }
/* 209 */     if (property == FRAGMENTS_PROPERTY) {
/* 210 */       return fragments();
/*     */     }
/*     */     
/* 213 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 218 */     return 60;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 223 */     VariableDeclarationStatement result = 
/* 224 */       new VariableDeclarationStatement(target);
/* 225 */     result.setSourceRange(getStartPosition(), getLength());
/* 226 */     result.copyLeadingComment(this);
/* 227 */     if (this.ast.apiLevel == 2) {
/* 228 */       result.setModifiers(getModifiers());
/*     */     }
/* 230 */     if (this.ast.apiLevel >= 3) {
/* 231 */       result.modifiers().addAll(ASTNode.copySubtrees(target, modifiers()));
/*     */     }
/* 233 */     result.setType((Type)getType().clone(target));
/* 234 */     result.fragments().addAll(
/* 235 */         ASTNode.copySubtrees(target, fragments()));
/* 236 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 242 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 247 */     boolean visitChildren = visitor.visit(this);
/* 248 */     if (visitChildren) {
/*     */       
/* 250 */       if (this.ast.apiLevel >= 3) {
/* 251 */         acceptChildren(visitor, this.modifiers);
/*     */       }
/* 253 */       acceptChild(visitor, getType());
/* 254 */       acceptChildren(visitor, this.variableDeclarationFragments);
/*     */     } 
/* 256 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List modifiers() {
/* 275 */     if (this.modifiers == null) {
/* 276 */       unsupportedIn2();
/*     */     }
/* 278 */     return this.modifiers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 293 */     if (this.modifiers == null)
/*     */     {
/* 295 */       return this.modifierFlags;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 300 */     int computedModifierFlags = 0;
/* 301 */     for (Iterator it = modifiers().iterator(); it.hasNext(); ) {
/* 302 */       Object x = it.next();
/* 303 */       if (x instanceof Modifier) {
/* 304 */         computedModifierFlags |= ((Modifier)x).getKeyword().toFlagValue();
/*     */       }
/*     */     } 
/* 307 */     return computedModifierFlags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModifiers(int modifiers) {
/* 326 */     internalSetModifiers(modifiers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void internalSetModifiers(int pmodifiers) {
/* 335 */     supportedOnlyIn2();
/* 336 */     preValueChange(MODIFIERS_PROPERTY);
/* 337 */     this.modifierFlags = pmodifiers;
/* 338 */     postValueChange(MODIFIERS_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 352 */     if (this.baseType == null)
/*     */     {
/* 354 */       synchronized (this) {
/* 355 */         if (this.baseType == null) {
/* 356 */           preLazyInit();
/* 357 */           this.baseType = this.ast.newPrimitiveType(PrimitiveType.INT);
/* 358 */           postLazyInit(this.baseType, TYPE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 362 */     return this.baseType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(Type type) {
/* 377 */     if (type == null) {
/* 378 */       throw new IllegalArgumentException();
/*     */     }
/* 380 */     ASTNode oldChild = this.baseType;
/* 381 */     preReplaceChild(oldChild, type, TYPE_PROPERTY);
/* 382 */     this.baseType = type;
/* 383 */     postReplaceChild(oldChild, type, TYPE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List fragments() {
/* 397 */     return this.variableDeclarationFragments;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 402 */     return super.memSize() + 16;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 407 */     return 
/* 408 */       memSize() + (
/* 409 */       (this.modifiers == null) ? 0 : this.modifiers.listSize()) + (
/* 410 */       (this.baseType == null) ? 0 : getType().treeSize()) + 
/* 411 */       this.variableDeclarationFragments.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\VariableDeclarationStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */