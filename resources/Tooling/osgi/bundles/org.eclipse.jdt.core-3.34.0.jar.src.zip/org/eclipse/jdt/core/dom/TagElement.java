/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.core.dom.util.DOMASTUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TagElement
/*     */   extends AbstractTagElement
/*     */ {
/*  51 */   public static final SimplePropertyDescriptor TAG_NAME_PROPERTY = internalTagNamePropertyFactory(TagElement.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   public static final ChildListPropertyDescriptor FRAGMENTS_PROPERTY = internalFragmentsPropertyFactory(TagElement.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   public static final ChildListPropertyDescriptor TAG_PROPERTIES_PROPERTY = new ChildListPropertyDescriptor(TagElement.class, "tagProperties", TagProperty.class, true);
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_18;
/*     */   public static final String TAG_AUTHOR = "@author";
/*     */   public static final String TAG_CODE = "@code";
/*     */   public static final String TAG_DEPRECATED = "@deprecated";
/*     */   public static final String TAG_DOCROOT = "@docRoot";
/*     */   public static final String TAG_EXCEPTION = "@exception";
/*     */   public static final String TAG_HIDDEN = "@hidden";
/*     */   public static final String TAG_INDEX = "@index";
/*     */   public static final String TAG_INHERITDOC = "@inheritDoc";
/*     */   public static final String TAG_LINK = "@link";
/*     */   public static final String TAG_LINKPLAIN = "@linkplain";
/*     */   public static final String TAG_LITERAL = "@literal";
/*     */   public static final String TAG_PARAM = "@param";
/*     */   public static final String TAG_PROVIDES = "@provides";
/*     */   public static final String TAG_RETURN = "@return";
/*     */   
/*     */   static {
/*  84 */     List propertyList = new ArrayList(3);
/*  85 */     createPropertyList(TagElement.class, propertyList);
/*  86 */     addProperty(TAG_NAME_PROPERTY, propertyList);
/*  87 */     addProperty(FRAGMENTS_PROPERTY, propertyList);
/*  88 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */     
/*  90 */     propertyList = new ArrayList(4);
/*  91 */     createPropertyList(TagElement.class, propertyList);
/*  92 */     addProperty(TAG_NAME_PROPERTY, propertyList);
/*  93 */     addProperty(FRAGMENTS_PROPERTY, propertyList);
/*  94 */     addProperty(TAG_PROPERTIES_PROPERTY, propertyList);
/*     */     
/*  96 */     PROPERTY_DESCRIPTORS_18 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final String TAG_SEE = "@see";
/*     */   public static final String TAG_SERIAL = "@serial";
/*     */   public static final String TAG_SERIALDATA = "@serialData";
/*     */   public static final String TAG_SERIALFIELD = "@serialField";
/*     */   public static final String TAG_SINCE = "@since";
/*     */   public static final String TAG_SUMMARY = "@summary";
/*     */   public static final String TAG_THROWS = "@throws";
/*     */   public static final String TAG_USES = "@uses";
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 110 */     if (DOMASTUtil.isJavaDocCodeSnippetSupported(apiLevel)) {
/* 111 */       return PROPERTY_DESCRIPTORS_18;
/*     */     }
/* 113 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */   public static final String TAG_VALUE = "@value"; public static final String TAG_VERSION = "@version"; public static final String TAG_API_NOTE = "@apiNote"; public static final String TAG_IMPL_SPEC = "@implSpec"; public static final String TAG_IMPL_NOTE = "@implNote"; public static final String TAG_SNIPPET = "@snippet"; public static final String TAG_HIGHLIGHT = "@highlight"; public static final String TAG_REPLACE = "@replace";
/*     */   final ChildListPropertyDescriptor internalFragmentsPropertyFactory() {
/* 117 */     return FRAGMENTS_PROPERTY;
/*     */   }
/*     */   
/*     */   final SimplePropertyDescriptor internalTagNamePropertyFactory() {
/* 121 */     return TAG_NAME_PROPERTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 312 */   private ASTNode.NodeList tagProperties = new ASTNode.NodeList(this, TAG_PROPERTIES_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TagElement(AST ast) {
/* 326 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 331 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 337 */     if (property == FRAGMENTS_PROPERTY)
/* 338 */       return fragments(); 
/* 339 */     if (property == TAG_PROPERTIES_PROPERTY) {
/* 340 */       return tagProperties();
/*     */     }
/*     */     
/* 343 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 348 */     return 65;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 353 */     TagElement result = new TagElement(target);
/* 354 */     result.setSourceRange(getStartPosition(), getLength());
/* 355 */     result.setTagName(getTagName());
/* 356 */     result.fragments().addAll(ASTNode.copySubtrees(target, fragments()));
/* 357 */     if (DOMASTUtil.isJavaDocCodeSnippetSupported(target.apiLevel)) {
/* 358 */       result.tagProperties().addAll(ASTNode.copySubtrees(target, tagProperties()));
/*     */     }
/* 360 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 366 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 371 */     boolean visitChildren = visitor.visit(this);
/* 372 */     if (visitChildren) {
/* 373 */       acceptChildren(visitor, this.fragments);
/* 374 */       if (DOMASTUtil.isJavaDocCodeSnippetSupported((getAST()).apiLevel)) {
/* 375 */         acceptChildren(visitor, this.tagProperties);
/*     */       }
/*     */     } 
/* 378 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List tagProperties() {
/* 390 */     unsupportedBelow18();
/* 391 */     return this.tagProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List tagRegions() {
/* 403 */     unsupportedBelow18();
/* 404 */     List<JavaDocRegion> regions = new ArrayList<>();
/* 405 */     List<Object> frags = fragments();
/* 406 */     if (frags != null) {
/* 407 */       for (Object fragment : frags) {
/* 408 */         if (fragment instanceof JavaDocRegion && 
/* 409 */           !((JavaDocRegion)fragment).isDummyRegion()) {
/* 410 */           regions.add((JavaDocRegion)fragment);
/*     */         }
/*     */       } 
/*     */     }
/* 414 */     return regions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List tagRegionsContainingTextElement(ASTNode docElem) {
/* 426 */     unsupportedBelow18();
/* 427 */     List<JavaDocRegion> regions = new ArrayList<>();
/* 428 */     if (docElem == null || !(docElem instanceof IDocElement)) {
/* 429 */       return regions;
/*     */     }
/* 431 */     int textElemStart = docElem.getStartPosition();
/* 432 */     int textElemEnd = textElemStart + docElem.getLength();
/* 433 */     List<JavaDocRegion> javaDocRegions = tagRegions();
/* 434 */     for (JavaDocRegion region : javaDocRegions) {
/* 435 */       int regionStart = region.getStartPosition();
/* 436 */       int regionEnd = regionStart + region.getLength();
/* 437 */       if (regionStart <= textElemStart && regionEnd >= textElemEnd) {
/* 438 */         regions.add(region);
/*     */       }
/*     */     } 
/*     */     
/* 442 */     return regions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List tagRegionsStartingAtTextElement(ASTNode docElem) {
/* 454 */     unsupportedBelow18();
/* 455 */     List<JavaDocRegion> regions = new ArrayList<>();
/* 456 */     if (docElem == null || !(docElem instanceof AbstractTextElement)) {
/* 457 */       return regions;
/*     */     }
/* 459 */     AbstractTextElement textElem = (AbstractTextElement)docElem;
/* 460 */     List<JavaDocRegion> javaDocRegions = tagRegions();
/* 461 */     for (JavaDocRegion region : javaDocRegions) {
/* 462 */       if (!region.isDummyRegion()) {
/* 463 */         Object textObj = region.getProperty("SnippetRegionTextElement");
/* 464 */         if (textElem.equals(textObj)) {
/* 465 */           regions.add(region);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 470 */     return regions;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 475 */     return super.memSize();
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 480 */     return memSize() + (DOMASTUtil.isJavaDocCodeSnippetSupported((getAST()).apiLevel) ? this.tagProperties.listSize() : 0);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\TagElement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */