/*     */ package org.eclipse.jdt.core;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.jdt.internal.core.JavaModelStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaModelException
/*     */   extends CoreException
/*     */ {
/*     */   private static final long serialVersionUID = -760398656505871287L;
/*     */   CoreException nestedCoreException;
/*     */   
/*     */   public JavaModelException(Throwable e, int code) {
/*  56 */     this((IJavaModelStatus)new JavaModelStatus(code, e));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaModelException(CoreException exception) {
/*  66 */     super(exception.getStatus());
/*  67 */     this.nestedCoreException = exception;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaModelException(IJavaModelStatus status) {
/*  75 */     super(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaModelException(IStatus status) {
/*  84 */     super(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getException() {
/*  93 */     if (this.nestedCoreException == null) {
/*  94 */       return getStatus().getException();
/*     */     }
/*  96 */     return (Throwable)this.nestedCoreException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IJavaModelStatus getJavaModelStatus() {
/* 106 */     IStatus status = getStatus();
/* 107 */     if (status instanceof IJavaModelStatus) {
/* 108 */       return (IJavaModelStatus)status;
/*     */     }
/*     */ 
/*     */     
/* 112 */     return (IJavaModelStatus)new JavaModelStatus(this.nestedCoreException);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDoesNotExist() {
/* 129 */     IJavaModelStatus javaModelStatus = getJavaModelStatus();
/* 130 */     return (javaModelStatus != null && javaModelStatus.isDoesNotExist());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintStream output) {
/* 141 */     synchronized (output) {
/* 142 */       super.printStackTrace(output);
/* 143 */       Throwable throwable = getException();
/* 144 */       if (throwable != null) {
/* 145 */         output.print("Caused by: ");
/* 146 */         throwable.printStackTrace(output);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintWriter output) {
/* 159 */     synchronized (output) {
/* 160 */       super.printStackTrace(output);
/* 161 */       Throwable throwable = getException();
/* 162 */       if (throwable != null) {
/* 163 */         output.print("Caused by: ");
/* 164 */         throwable.printStackTrace(output);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 174 */     StringBuilder buffer = new StringBuilder();
/* 175 */     buffer.append("Java Model Exception: ");
/* 176 */     if (getException() != null) {
/* 177 */       if (getException() instanceof CoreException) {
/* 178 */         CoreException c = (CoreException)getException();
/* 179 */         buffer.append("Core Exception [code ");
/* 180 */         buffer.append(c.getStatus().getCode());
/* 181 */         buffer.append("] ");
/* 182 */         buffer.append(c.getStatus().getMessage());
/*     */       } else {
/* 184 */         buffer.append(getException().toString());
/*     */       } 
/*     */     } else {
/* 187 */       buffer.append(getStatus().toString());
/*     */     } 
/* 189 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\JavaModelException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */