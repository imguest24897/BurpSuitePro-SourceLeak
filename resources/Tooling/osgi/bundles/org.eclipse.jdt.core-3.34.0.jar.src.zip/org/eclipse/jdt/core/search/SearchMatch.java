/*     */ package org.eclipse.jdt.core.search;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.internal.core.JavaElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SearchMatch
/*     */ {
/*     */   public static final int A_ACCURATE = 0;
/*     */   public static final int A_INACCURATE = 1;
/*     */   private Object element;
/*     */   private int length;
/*     */   private int offset;
/*     */   private int accuracy;
/*     */   private SearchParticipant participant;
/*     */   private IResource resource;
/*     */   private boolean insideDocComment = false;
/*     */   private static final int ALL_GENERIC_FLAVORS = 112;
/*  66 */   private int rule = 112;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean raw = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean implicit = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SearchMatch(IJavaElement element, int accuracy, int offset, int length, SearchParticipant participant, IResource resource) {
/*  93 */     this.element = element;
/*  94 */     this.offset = offset;
/*  95 */     this.length = length;
/*  96 */     this.accuracy = accuracy & 0x1;
/*  97 */     if (accuracy > 1) {
/*  98 */       int genericFlavors = accuracy & 0x70;
/*  99 */       if (genericFlavors > 0) {
/* 100 */         this.rule &= 0xFFFFFF8F;
/*     */       }
/* 102 */       this.rule |= accuracy & 0xFFFFFFFE;
/*     */     } 
/* 104 */     this.participant = participant;
/* 105 */     this.resource = resource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getAccuracy() {
/* 114 */     return this.accuracy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getElement() {
/* 125 */     return this.element;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getLength() {
/* 134 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getOffset() {
/* 143 */     return this.offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SearchParticipant getParticipant() {
/* 152 */     return this.participant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IResource getResource() {
/* 161 */     return this.resource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRule() {
/* 172 */     return this.rule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEquivalent() {
/* 184 */     return (isErasure() && (this.rule & 0x20) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isErasure() {
/* 197 */     return ((this.rule & 0x10) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isExact() {
/* 209 */     return (isEquivalent() && (this.rule & 0x40) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isImplicit() {
/* 223 */     return this.implicit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isRaw() {
/* 234 */     return this.raw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isInsideDocComment() {
/* 246 */     return this.insideDocComment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setAccuracy(int accuracy) {
/* 255 */     this.accuracy = accuracy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setElement(Object element) {
/* 265 */     this.element = element;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setInsideDocComment(boolean insideDoc) {
/* 276 */     this.insideDocComment = insideDoc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setImplicit(boolean implicit) {
/* 289 */     this.implicit = implicit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setLength(int length) {
/* 298 */     this.length = length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setOffset(int offset) {
/* 307 */     this.offset = offset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setParticipant(SearchParticipant participant) {
/* 316 */     this.participant = participant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setResource(IResource resource) {
/* 325 */     this.resource = resource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setRule(int rule) {
/* 336 */     this.rule = rule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setRaw(boolean raw) {
/* 347 */     this.raw = raw;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 352 */     StringBuilder buffer = new StringBuilder();
/* 353 */     buffer.append("Search match");
/* 354 */     buffer.append("\n  accuracy=");
/* 355 */     buffer.append((this.accuracy == 0) ? "ACCURATE" : "INACCURATE");
/* 356 */     buffer.append("\n  rule=");
/* 357 */     if ((this.rule & 0x40) != 0) {
/* 358 */       buffer.append("EXACT");
/* 359 */     } else if ((this.rule & 0x20) != 0) {
/* 360 */       buffer.append("EQUIVALENT");
/* 361 */     } else if ((this.rule & 0x10) != 0) {
/* 362 */       buffer.append("ERASURE");
/*     */     } 
/* 364 */     buffer.append("\n  raw=");
/* 365 */     buffer.append(this.raw);
/* 366 */     buffer.append("\n  offset=");
/* 367 */     buffer.append(this.offset);
/* 368 */     buffer.append("\n  length=");
/* 369 */     buffer.append(this.length);
/* 370 */     if (this.element != null) {
/* 371 */       buffer.append("\n  element=");
/* 372 */       buffer.append(((JavaElement)getElement()).toStringWithAncestors());
/*     */     } 
/* 374 */     buffer.append("\n");
/* 375 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\search\SearchMatch.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */