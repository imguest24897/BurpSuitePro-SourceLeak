/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParenthesizedExpression
/*     */   extends Expression
/*     */ {
/*  39 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(ParenthesizedExpression.class, "expression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  49 */     List propertyList = new ArrayList(2);
/*  50 */     createPropertyList(ParenthesizedExpression.class, propertyList);
/*  51 */     addProperty(EXPRESSION_PROPERTY, propertyList);
/*  52 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  66 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   private Expression expression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ParenthesizedExpression(AST ast) {
/*  86 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  91 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/*  96 */     if (property == EXPRESSION_PROPERTY) {
/*  97 */       if (get) {
/*  98 */         return getExpression();
/*     */       }
/* 100 */       setExpression((Expression)child);
/* 101 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 105 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 110 */     return 36;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 115 */     ParenthesizedExpression result = new ParenthesizedExpression(target);
/* 116 */     result.setSourceRange(getStartPosition(), getLength());
/* 117 */     result.setExpression((Expression)getExpression().clone(target));
/* 118 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 124 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 129 */     boolean visitChildren = visitor.visit(this);
/* 130 */     if (visitChildren) {
/* 131 */       acceptChild(visitor, getExpression());
/*     */     }
/* 133 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 142 */     if (this.expression == null)
/*     */     {
/* 144 */       synchronized (this) {
/* 145 */         if (this.expression == null) {
/* 146 */           preLazyInit();
/* 147 */           this.expression = new SimpleName(this.ast);
/* 148 */           postLazyInit(this.expression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 152 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 167 */     if (expression == null) {
/* 168 */       throw new IllegalArgumentException();
/*     */     }
/* 170 */     ASTNode oldChild = this.expression;
/* 171 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 172 */     this.expression = expression;
/* 173 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 178 */     return 44;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 183 */     return 
/* 184 */       memSize() + (
/* 185 */       (this.expression == null) ? 0 : getExpression().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ParenthesizedExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */