/*    */ package org.eclipse.jdt.core.dom;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultValuePairBinding
/*    */   extends MemberValuePairBinding
/*    */ {
/*    */   private MethodBinding method;
/*    */   
/*    */   DefaultValuePairBinding(MethodBinding binding, BindingResolver resolver) {
/* 27 */     super(null, resolver);
/* 28 */     this.method = binding;
/* 29 */     this.value = MemberValuePairBinding.buildDOMValue(binding.getDefaultValue(), resolver);
/* 30 */     if (binding.returnType != null && binding.returnType.isArrayType())
/*    */     {
/* 32 */       if (this.value == null) {
/* 33 */         this.value = new Object[0];
/* 34 */       } else if (!this.value.getClass().isArray()) {
/* 35 */         this.value = new Object[] { this.value };
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public IMethodBinding getMethodBinding() {
/* 42 */     return this.bindingResolver.getMethodBinding(this.method);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 47 */     return new String(this.method.selector);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getValue() {
/* 52 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDefault() {
/* 57 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isDeprecated() {
/* 62 */     return this.method.isDeprecated();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\DefaultValuePairBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */