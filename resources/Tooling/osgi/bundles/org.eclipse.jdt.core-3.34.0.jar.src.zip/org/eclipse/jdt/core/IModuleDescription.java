/*    */ package org.eclipse.jdt.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IModuleDescription
/*    */   extends IMember, IAnnotatable
/*    */ {
/*    */   String[] getRequiredModuleNames() throws JavaModelException;
/*    */   
/*    */   String[] getProvidedServiceNames() throws JavaModelException;
/*    */   
/*    */   String[] getUsedServiceNames() throws JavaModelException;
/*    */   
/*    */   String[] getExportedPackageNames(IModuleDescription paramIModuleDescription) throws JavaModelException;
/*    */   
/*    */   String[] getOpenedPackageNames(IModuleDescription paramIModuleDescription) throws JavaModelException;
/*    */   
/*    */   default boolean isAutoModule() {
/* 84 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default boolean isSystemModule() {
/* 92 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IModuleDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */