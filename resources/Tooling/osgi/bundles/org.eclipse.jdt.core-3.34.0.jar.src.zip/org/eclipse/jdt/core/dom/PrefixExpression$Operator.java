/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Operator
/*     */ {
/*     */   private String token;
/*     */   
/*     */   private Operator(String token) {
/*  65 */     this.token = token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  75 */     return this.token;
/*     */   }
/*     */ 
/*     */   
/*  79 */   public static final Operator INCREMENT = new Operator("++");
/*     */   
/*  81 */   public static final Operator DECREMENT = new Operator("--");
/*     */   
/*  83 */   public static final Operator PLUS = new Operator("+");
/*     */   
/*  85 */   public static final Operator MINUS = new Operator("-");
/*     */   
/*  87 */   public static final Operator COMPLEMENT = new Operator("~");
/*     */   
/*  89 */   public static final Operator NOT = new Operator("!");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   private static final Map CODES = new HashMap<>(20); static {
/*  98 */     Operator[] ops = {
/*  99 */         INCREMENT, 
/* 100 */         DECREMENT, 
/* 101 */         PLUS, 
/* 102 */         MINUS, 
/* 103 */         COMPLEMENT, 
/* 104 */         NOT
/*     */       };
/* 106 */     for (int i = 0; i < ops.length; i++) {
/* 107 */       CODES.put(ops[i].toString(), ops[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Operator toOperator(String token) {
/* 124 */     return (Operator)CODES.get(token);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\PrefixExpression$Operator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */