package org.eclipse.jdt.core;

import org.eclipse.core.runtime.IProgressMonitor;

public interface ISourceManipulation {
  void copy(IJavaElement paramIJavaElement1, IJavaElement paramIJavaElement2, String paramString, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void delete(boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void move(IJavaElement paramIJavaElement1, IJavaElement paramIJavaElement2, String paramString, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void rename(String paramString, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\ISourceManipulation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */