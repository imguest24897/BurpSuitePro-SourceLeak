/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.ModuleDeclaration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnKeywordModuleDeclaration
/*    */   extends ModuleDeclaration
/*    */   implements CompletionOnKeyword
/*    */ {
/*    */   private char[] token;
/*    */   private char[][] possibleKeywords;
/*    */   
/*    */   public CompletionOnKeywordModuleDeclaration(char[] token, long pos, char[][] possibleKeywords) {
/* 25 */     super(null, new char[][] { token }, new long[] { pos });
/* 26 */     this.token = token;
/* 27 */     this.possibleKeywords = possibleKeywords;
/*    */   }
/*    */ 
/*    */   
/*    */   public char[] getToken() {
/* 32 */     return this.token;
/*    */   }
/*    */ 
/*    */   
/*    */   public char[][] getPossibleKeywords() {
/* 37 */     return this.possibleKeywords;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnKeywordModuleDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */