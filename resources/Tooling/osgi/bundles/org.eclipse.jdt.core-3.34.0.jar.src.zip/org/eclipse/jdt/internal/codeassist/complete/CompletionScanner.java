/*      */ package org.eclipse.jdt.internal.codeassist.complete;
/*      */ 
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*      */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*      */ import org.eclipse.jdt.internal.compiler.parser.ScannerHelper;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CompletionScanner
/*      */   extends Scanner
/*      */ {
/*      */   public char[] completionIdentifier;
/*      */   public int cursorLocation;
/*   36 */   public int endOfEmptyToken = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   42 */   public int completedIdentifierStart = 0;
/*   43 */   public int completedIdentifierEnd = -1;
/*      */   
/*      */   public int unicodeCharSize;
/*   46 */   public static final char[] EmptyCompletionIdentifier = new char[0];
/*      */ 
/*      */ 
/*      */   
/*      */   public CompletionScanner(long sourceLevel) {
/*   51 */     this(sourceLevel, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CompletionScanner(long sourceLevel, boolean previewEnabled) {
/*   62 */     super(false, false, false, sourceLevel, null, null, true, previewEnabled);
/*      */   }
/*      */   
/*      */   protected boolean isAtAssistIdentifier() {
/*   66 */     if (this.cursorLocation < this.startPosition && this.currentPosition == this.startPosition) {
/*   67 */       return true;
/*      */     }
/*   69 */     if (this.cursorLocation + 1 >= this.startPosition && this.cursorLocation < this.currentPosition) {
/*   70 */       return true;
/*      */     }
/*   72 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getCurrentIdentifierSource() {
/*   82 */     if (this.completionIdentifier == null) {
/*   83 */       if (this.cursorLocation < this.startPosition && this.currentPosition == this.startPosition) {
/*      */         
/*   85 */         this.completedIdentifierStart = this.startPosition;
/*   86 */         this.completedIdentifierEnd = this.completedIdentifierStart - 1;
/*   87 */         return this.completionIdentifier = EmptyCompletionIdentifier;
/*      */       } 
/*   89 */       if (this.cursorLocation + 1 >= this.startPosition && this.cursorLocation < this.currentPosition) {
/*      */         
/*   91 */         this.completedIdentifierStart = this.startPosition;
/*   92 */         this.completedIdentifierEnd = this.currentPosition - 1;
/*   93 */         if (this.withoutUnicodePtr != 0) {
/*   94 */           int length = this.cursorLocation + 1 - this.startPosition - this.unicodeCharSize;
/*   95 */           System.arraycopy(this.withoutUnicodeBuffer, 1, this.completionIdentifier = new char[length], 0, length);
/*      */         } else {
/*      */           
/*   98 */           int length = this.cursorLocation + 1 - this.startPosition;
/*   99 */           System.arraycopy(this.source, this.startPosition, this.completionIdentifier = new char[length], 0, length);
/*      */         } 
/*  101 */         return this.completionIdentifier;
/*      */       } 
/*      */     } 
/*  104 */     return super.getCurrentIdentifierSource();
/*      */   }
/*      */ 
/*      */   
/*      */   public char[] getCurrentTokenSourceString() {
/*  109 */     if (this.completionIdentifier == null && 
/*  110 */       this.cursorLocation + 1 >= this.startPosition && this.cursorLocation < this.currentPosition) {
/*      */       
/*  112 */       this.completedIdentifierStart = this.startPosition;
/*  113 */       this.completedIdentifierEnd = this.currentPosition - 1;
/*  114 */       if (this.withoutUnicodePtr != 0) {
/*  115 */         int length = this.cursorLocation - this.startPosition - this.unicodeCharSize;
/*  116 */         System.arraycopy(this.withoutUnicodeBuffer, 2, this.completionIdentifier = new char[length], 0, length);
/*      */       } else {
/*      */         
/*  119 */         int length = this.cursorLocation - this.startPosition;
/*  120 */         System.arraycopy(this.source, this.startPosition + 1, this.completionIdentifier = new char[length], 0, length);
/*      */       } 
/*  122 */       return this.completionIdentifier;
/*      */     } 
/*      */     
/*  125 */     return super.getCurrentTokenSourceString();
/*      */   }
/*      */ 
/*      */   
/*      */   protected int getNextToken0() throws InvalidInputException {
/*  130 */     this.wasAcr = false;
/*  131 */     this.unicodeCharSize = 0;
/*  132 */     if (this.diet) {
/*  133 */       jumpOverMethodBody();
/*  134 */       this.diet = false;
/*  135 */       return (this.currentPosition > this.eofPosition) ? 64 : 33;
/*      */     } 
/*  137 */     int whiteStart = 0; try {
/*      */       boolean isJavaIdStart; while (true) {
/*      */         int temp, test, lookAhead; boolean isTextBlock; int i;
/*  140 */         this.withoutUnicodePtr = 0;
/*      */ 
/*      */ 
/*      */         
/*  144 */         whiteStart = this.currentPosition;
/*  145 */         boolean hasWhiteSpaces = false;
/*  146 */         int offset = 0; while (true) {
/*      */           boolean isWhiteSpace;
/*  148 */           this.startPosition = this.currentPosition;
/*  149 */           boolean checkIfUnicode = false;
/*      */           try {
/*  151 */             checkIfUnicode = ((this.currentCharacter = this.source[this.currentPosition++]) == '\\' && 
/*  152 */               this.source[this.currentPosition] == 'u');
/*  153 */           } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/*  154 */             if (this.tokenizeWhiteSpace && whiteStart != this.currentPosition - 1) {
/*      */               
/*  156 */               this.currentPosition--;
/*  157 */               this.startPosition = whiteStart;
/*  158 */               return 1000;
/*      */             } 
/*  160 */             if (this.currentPosition > this.eofPosition) {
/*      */               
/*  162 */               if (this.completionIdentifier == null && 
/*  163 */                 this.startPosition == this.cursorLocation + 1) {
/*  164 */                 this.currentPosition = this.startPosition;
/*  165 */                 return 19;
/*      */               } 
/*  167 */               return 64;
/*      */             } 
/*      */           } 
/*  170 */           if (checkIfUnicode) {
/*  171 */             isWhiteSpace = jumpOverUnicodeWhiteSpace();
/*  172 */             offset = 6;
/*      */           } else {
/*  174 */             offset = 1;
/*  175 */             if (this.currentCharacter == '\r' || this.currentCharacter == '\n')
/*      */             {
/*  177 */               if (this.recordLineSeparator) {
/*  178 */                 pushLineSeparator();
/*      */               }
/*      */             }
/*  181 */             isWhiteSpace = 
/*  182 */               !(this.currentCharacter != ' ' && !CharOperation.isWhitespace(this.currentCharacter));
/*      */           } 
/*  184 */           if (isWhiteSpace) {
/*  185 */             hasWhiteSpaces = true;
/*      */           }
/*      */           
/*  188 */           if (whiteStart != this.currentPosition)
/*      */           {
/*  190 */             if (this.completionIdentifier == null && 
/*  191 */               whiteStart <= this.cursorLocation + 1 && 
/*  192 */               this.cursorLocation < this.startPosition && 
/*  193 */               !ScannerHelper.isJavaIdentifierStart(this.complianceLevel, this.currentCharacter)) {
/*  194 */               this.currentPosition = this.startPosition;
/*  195 */               return 19;
/*      */             }  } 
/*  197 */           if (!isWhiteSpace) {
/*  198 */             if (this.tokenizeWhiteSpace && hasWhiteSpaces) {
/*      */               
/*  200 */               this.currentPosition -= offset;
/*  201 */               this.startPosition = whiteStart;
/*  202 */               return 1000;
/*      */             } 
/*      */             
/*  205 */             if (this.currentPosition > this.eofPosition) {
/*      */               
/*  207 */               if (this.completionIdentifier == null && 
/*  208 */                 this.startPosition == this.cursorLocation + 1) {
/*      */ 
/*      */ 
/*      */                 
/*  212 */                 int j = this.eofPosition;
/*  213 */                 this.eofPosition = this.source.length; do {  }
/*  214 */                 while (getNextCharAsJavaIdentifierPart());
/*  215 */                 this.eofPosition = j;
/*  216 */                 this.endOfEmptyToken = this.currentPosition - 1;
/*  217 */                 this.currentPosition = this.startPosition;
/*  218 */                 return 19;
/*      */               } 
/*  220 */               this.currentPosition = this.startPosition;
/*  221 */               return 64;
/*      */             } 
/*      */             break;
/*      */           } 
/*      */         } 
/*  226 */         switch (this.currentCharacter) {
/*      */           case '@':
/*  228 */             return 34;
/*      */           case '(':
/*  230 */             return 23;
/*      */           case ')':
/*  232 */             return 26;
/*      */           case '{':
/*  234 */             return 40;
/*      */           case '}':
/*  236 */             return 33;
/*      */           case '[':
/*  238 */             return 6;
/*      */           case ']':
/*  240 */             return 69;
/*      */           case ';':
/*  242 */             return 24;
/*      */           case ',':
/*  244 */             return 32;
/*      */           case '.':
/*  246 */             if (this.startPosition <= this.cursorLocation && 
/*  247 */               this.cursorLocation < this.currentPosition) {
/*  248 */               return 1;
/*      */             }
/*  250 */             if (getNextCharAsDigit()) {
/*  251 */               return scanNumber(true);
/*      */             }
/*  253 */             temp = this.currentPosition;
/*  254 */             if (getNextChar('.')) {
/*  255 */               if (getNextChar('.')) {
/*  256 */                 return 120;
/*      */               }
/*  258 */               this.currentPosition = temp;
/*  259 */               return 1;
/*      */             } 
/*      */             
/*  262 */             this.currentPosition = temp;
/*  263 */             return 1;
/*      */ 
/*      */ 
/*      */           
/*      */           case '+':
/*  268 */             if ((test = getNextChar('+', '=')) == 0)
/*  269 */               return 2; 
/*  270 */             if (test > 0)
/*  271 */               return 93; 
/*  272 */             return 4;
/*      */ 
/*      */ 
/*      */           
/*      */           case '-':
/*  277 */             if ((test = getNextChar('-', '=')) == 0)
/*  278 */               return 3; 
/*  279 */             if (test > 0)
/*  280 */               return 94; 
/*  281 */             if (getNextChar('>'))
/*  282 */               return 104; 
/*  283 */             return 5;
/*      */           
/*      */           case '~':
/*  286 */             return 67;
/*      */           case '!':
/*  288 */             if (getNextChar('='))
/*  289 */               return 21; 
/*  290 */             return 66;
/*      */           case '*':
/*  292 */             if (getNextChar('='))
/*  293 */               return 95; 
/*  294 */             return 8;
/*      */           case '%':
/*  296 */             if (getNextChar('='))
/*  297 */               return 100; 
/*  298 */             return 9;
/*      */ 
/*      */           
/*      */           case '<':
/*  302 */             if ((test = getNextChar('=', '<')) == 0)
/*  303 */               return 12; 
/*  304 */             if (test > 0) {
/*  305 */               if (getNextChar('='))
/*  306 */                 return 101; 
/*  307 */               return 18;
/*      */             } 
/*  309 */             return 11;
/*      */ 
/*      */ 
/*      */           
/*      */           case '>':
/*  314 */             if (this.returnOnlyGreater) {
/*  315 */               return 15;
/*      */             }
/*  317 */             if ((test = getNextChar('=', '>')) == 0)
/*  318 */               return 13; 
/*  319 */             if (test > 0) {
/*  320 */               if ((test = getNextChar('=', '>')) == 0)
/*  321 */                 return 102; 
/*  322 */               if (test > 0) {
/*  323 */                 if (getNextChar('='))
/*  324 */                   return 103; 
/*  325 */                 return 16;
/*      */               } 
/*  327 */               return 14;
/*      */             } 
/*  329 */             return 15;
/*      */           
/*      */           case '=':
/*  332 */             if (getNextChar('='))
/*  333 */               return 20; 
/*  334 */             return 77;
/*      */ 
/*      */           
/*      */           case '&':
/*  338 */             if ((test = getNextChar('&', '=')) == 0)
/*  339 */               return 30; 
/*  340 */             if (test > 0)
/*  341 */               return 97; 
/*  342 */             return 22;
/*      */ 
/*      */ 
/*      */           
/*      */           case '|':
/*  347 */             if ((test = getNextChar('|', '=')) == 0)
/*  348 */               return 31; 
/*  349 */             if (test > 0)
/*  350 */               return 98; 
/*  351 */             return 28;
/*      */           
/*      */           case '^':
/*  354 */             if (getNextChar('='))
/*  355 */               return 99; 
/*  356 */             return 25;
/*      */           case '?':
/*  358 */             return 29;
/*      */           case ':':
/*  360 */             if (getNextChar(':'))
/*  361 */               return 7; 
/*  362 */             return 65;
/*      */ 
/*      */           
/*      */           case '\'':
/*  366 */             if ((test = getNextChar('\n', '\r')) == 0) {
/*  367 */               throw new InvalidInputException("Invalid_Character_Constant");
/*      */             }
/*  369 */             if (test > 0) {
/*      */               
/*  371 */               for (int j = 0; j < 3 && 
/*  372 */                 this.currentPosition + j != this.eofPosition; j++) {
/*      */                 
/*  374 */                 if (this.source[this.currentPosition + j] == '\n')
/*      */                   break; 
/*  376 */                 if (this.source[this.currentPosition + j] == '\'') {
/*  377 */                   this.currentPosition += j + 1;
/*      */                   break;
/*      */                 } 
/*      */               } 
/*  381 */               throw new InvalidInputException("Invalid_Character_Constant");
/*      */             } 
/*      */             
/*  384 */             if (getNextChar('\'')) {
/*      */               
/*  386 */               for (int j = 0; j < 3 && 
/*  387 */                 this.currentPosition + j != this.eofPosition; j++) {
/*      */                 
/*  389 */                 if (this.source[this.currentPosition + j] == '\n')
/*      */                   break; 
/*  391 */                 if (this.source[this.currentPosition + j] == '\'') {
/*  392 */                   this.currentPosition += j + 1;
/*      */                   break;
/*      */                 } 
/*      */               } 
/*  396 */               throw new InvalidInputException("Invalid_Character_Constant");
/*      */             } 
/*  398 */             if (getNextChar('\\')) {
/*  399 */               if (this.unicodeAsBackSlash) {
/*      */                 
/*  401 */                 this.unicodeAsBackSlash = false;
/*  402 */                 if ((this.currentCharacter = this.source[this.currentPosition++]) == '\\' && this.source[this.currentPosition] == 'u') {
/*  403 */                   getNextUnicodeChar();
/*      */                 }
/*  405 */                 else if (this.withoutUnicodePtr != 0) {
/*  406 */                   unicodeStore();
/*      */                 } 
/*      */               } else {
/*      */                 
/*  410 */                 this.currentCharacter = this.source[this.currentPosition++];
/*      */               } 
/*  412 */               scanEscapeCharacter();
/*      */             } else {
/*  414 */               this.unicodeAsBackSlash = false;
/*  415 */               boolean checkIfUnicode = false;
/*      */               try {
/*  417 */                 checkIfUnicode = ((this.currentCharacter = this.source[this.currentPosition++]) == '\\' && 
/*  418 */                   this.source[this.currentPosition] == 'u');
/*  419 */               } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/*  420 */                 this.currentPosition--;
/*  421 */                 throw new InvalidInputException("Invalid_Character_Constant");
/*      */               } 
/*  423 */               if (checkIfUnicode) {
/*  424 */                 getNextUnicodeChar();
/*      */               }
/*  426 */               else if (this.withoutUnicodePtr != 0) {
/*  427 */                 unicodeStore();
/*      */               } 
/*      */             } 
/*      */             
/*  431 */             if (getNextChar('\'')) {
/*  432 */               return 59;
/*      */             }
/*  434 */             for (lookAhead = 0; lookAhead < 20 && 
/*  435 */               this.currentPosition + lookAhead != this.eofPosition; lookAhead++) {
/*      */               
/*  437 */               if (this.source[this.currentPosition + lookAhead] == '\n')
/*      */                 break; 
/*  439 */               if (this.source[this.currentPosition + lookAhead] == '\'') {
/*  440 */                 this.currentPosition += lookAhead + 1;
/*      */                 break;
/*      */               } 
/*      */             } 
/*  444 */             throw new InvalidInputException("Invalid_Character_Constant");
/*      */           case '"':
/*  446 */             isTextBlock = scanForTextBlockBeginning();
/*  447 */             if (isTextBlock) {
/*  448 */               return scanForTextBlock();
/*      */             }
/*      */             
/*      */             try {
/*  452 */               this.unicodeAsBackSlash = false;
/*  453 */               boolean isUnicode = false;
/*  454 */               if ((this.currentCharacter = this.source[this.currentPosition++]) == '\\' && 
/*  455 */                 this.source[this.currentPosition] == 'u') {
/*  456 */                 getNextUnicodeChar();
/*  457 */                 isUnicode = true;
/*      */               }
/*  459 */               else if (this.withoutUnicodePtr != 0) {
/*  460 */                 unicodeStore();
/*      */               } 
/*      */ 
/*      */               
/*  464 */               while (this.currentCharacter != '"')
/*      */               {
/*  466 */                 if (this.currentCharacter == '\n' || this.currentCharacter == '\r') {
/*  467 */                   if (isUnicode) {
/*  468 */                     int start = this.currentPosition - 5;
/*  469 */                     while (this.source[start] != '\\') {
/*  470 */                       start--;
/*      */                     }
/*  472 */                     if (this.startPosition <= this.cursorLocation && 
/*  473 */                       this.cursorLocation <= this.currentPosition - 1) {
/*  474 */                       this.currentPosition = start;
/*      */                       
/*  476 */                       return 60;
/*      */                     } 
/*  478 */                     start = this.currentPosition;
/*  479 */                     for (int j = 0; j < 50; j++) {
/*  480 */                       if (this.currentPosition >= this.eofPosition) {
/*  481 */                         this.currentPosition = start;
/*      */                         break;
/*      */                       } 
/*  484 */                       if ((this.currentCharacter = this.source[this.currentPosition++]) == '\\' && this.source[this.currentPosition] == 'u') {
/*  485 */                         isUnicode = true;
/*  486 */                         getNextUnicodeChar();
/*      */                       } else {
/*  488 */                         isUnicode = false;
/*      */                       } 
/*  490 */                       if (!isUnicode && this.currentCharacter == '\n') {
/*  491 */                         this.currentPosition--;
/*      */                         break;
/*      */                       } 
/*  494 */                       if (this.currentCharacter == '"') {
/*  495 */                         throw new InvalidInputException("Invalid_Char_In_String");
/*      */                       }
/*      */                     } 
/*      */                   } else {
/*  499 */                     this.currentPosition--;
/*  500 */                     if (this.startPosition <= this.cursorLocation && 
/*  501 */                       this.cursorLocation <= this.currentPosition - 1)
/*      */                     {
/*  503 */                       return 60;
/*      */                     }
/*      */                   } 
/*  506 */                   throw new InvalidInputException("Invalid_Char_In_String");
/*      */                 } 
/*  508 */                 if (this.currentCharacter == '\\') {
/*  509 */                   if (this.unicodeAsBackSlash) {
/*  510 */                     this.withoutUnicodePtr--;
/*      */                     
/*  512 */                     this.unicodeAsBackSlash = false;
/*  513 */                     if ((this.currentCharacter = this.source[this.currentPosition++]) == '\\' && this.source[this.currentPosition] == 'u') {
/*  514 */                       getNextUnicodeChar();
/*  515 */                       isUnicode = true;
/*  516 */                       this.withoutUnicodePtr--;
/*      */                     } else {
/*  518 */                       isUnicode = false;
/*      */                     } 
/*      */                   } else {
/*  521 */                     if (this.withoutUnicodePtr == 0) {
/*  522 */                       unicodeInitializeBuffer(this.currentPosition - this.startPosition);
/*      */                     }
/*  524 */                     this.withoutUnicodePtr--;
/*  525 */                     this.currentCharacter = this.source[this.currentPosition++];
/*      */                   } 
/*      */                   
/*  528 */                   scanEscapeCharacter();
/*  529 */                   if (this.withoutUnicodePtr != 0) {
/*  530 */                     unicodeStore();
/*      */                   }
/*      */                 } 
/*      */                 
/*  534 */                 this.unicodeAsBackSlash = false;
/*  535 */                 if ((this.currentCharacter = this.source[this.currentPosition++]) == '\\' && 
/*  536 */                   this.source[this.currentPosition] == 'u') {
/*  537 */                   getNextUnicodeChar();
/*  538 */                   isUnicode = true; continue;
/*      */                 } 
/*  540 */                 isUnicode = false;
/*  541 */                 if (this.withoutUnicodePtr != 0) {
/*  542 */                   unicodeStore();
/*      */                 }
/*      */               }
/*      */             
/*      */             }
/*  547 */             catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/*  548 */               this.currentPosition--;
/*  549 */               if (this.startPosition <= this.cursorLocation && 
/*  550 */                 this.cursorLocation < this.currentPosition)
/*      */               {
/*  552 */                 return 60;
/*      */               }
/*  554 */               throw new InvalidInputException("Unterminated_String");
/*  555 */             } catch (InvalidInputException e) {
/*  556 */               if (e.getMessage().equals("Invalid_Escape"))
/*      */               {
/*  558 */                 for (int j = 0; j < 50 && 
/*  559 */                   this.currentPosition + j != this.eofPosition; j++) {
/*      */                   
/*  561 */                   if (this.source[this.currentPosition + j] == '\n')
/*      */                     break; 
/*  563 */                   if (this.source[this.currentPosition + j] == '"') {
/*  564 */                     this.currentPosition += j + 1;
/*      */                     
/*      */                     break;
/*      */                   } 
/*      */                 } 
/*      */               }
/*  570 */               throw e;
/*      */             } 
/*  572 */             return 60;
/*      */ 
/*      */           
/*      */           case '/':
/*  576 */             if ((i = getNextChar('/', '*')) == 0) {
/*  577 */               this.lastCommentLinePosition = this.currentPosition;
/*      */               try {
/*  579 */                 if ((this.currentCharacter = this.source[this.currentPosition++]) == '\\' && 
/*  580 */                   this.source[this.currentPosition] == 'u') {
/*      */                   
/*  582 */                   int c1 = 0, c2 = 0, c3 = 0, c4 = 0;
/*  583 */                   this.currentPosition++;
/*  584 */                   while (this.source[this.currentPosition] == 'u') {
/*  585 */                     this.currentPosition++;
/*      */                   }
/*  587 */                   if ((c1 = ScannerHelper.getHexadecimalValue(this.source[this.currentPosition++])) > 15 || 
/*  588 */                     c1 < 0 || (
/*  589 */                     c2 = ScannerHelper.getHexadecimalValue(this.source[this.currentPosition++])) > 15 || 
/*  590 */                     c2 < 0 || (
/*  591 */                     c3 = ScannerHelper.getHexadecimalValue(this.source[this.currentPosition++])) > 15 || 
/*  592 */                     c3 < 0 || (
/*  593 */                     c4 = ScannerHelper.getHexadecimalValue(this.source[this.currentPosition++])) > 15 || 
/*  594 */                     c4 < 0) {
/*  595 */                     throw new InvalidInputException("Invalid_Unicode_Escape");
/*      */                   }
/*  597 */                   this.currentCharacter = (char)(((c1 * 16 + c2) * 16 + c3) * 16 + c4);
/*      */                 } 
/*      */ 
/*      */ 
/*      */                 
/*  602 */                 if (this.currentCharacter == '\\' && 
/*  603 */                   this.source[this.currentPosition] == '\\') {
/*  604 */                   this.currentPosition++;
/*      */                 }
/*  606 */                 boolean isUnicode = false;
/*  607 */                 while (this.currentCharacter != '\r' && this.currentCharacter != '\n') {
/*  608 */                   this.lastCommentLinePosition = this.currentPosition;
/*      */                   
/*  610 */                   isUnicode = false;
/*  611 */                   if ((this.currentCharacter = this.source[this.currentPosition++]) == '\\' && 
/*  612 */                     this.source[this.currentPosition] == 'u') {
/*  613 */                     isUnicode = true;
/*      */                     
/*  615 */                     int c1 = 0, c2 = 0, c3 = 0, c4 = 0;
/*  616 */                     this.currentPosition++;
/*  617 */                     while (this.source[this.currentPosition] == 'u') {
/*  618 */                       this.currentPosition++;
/*      */                     }
/*  620 */                     if ((c1 = ScannerHelper.getHexadecimalValue(this.source[this.currentPosition++])) > 15 || 
/*  621 */                       c1 < 0 || (
/*  622 */                       c2 = ScannerHelper.getHexadecimalValue(this.source[this.currentPosition++])) > 15 || 
/*  623 */                       c2 < 0 || (
/*  624 */                       c3 = ScannerHelper.getHexadecimalValue(this.source[this.currentPosition++])) > 15 || 
/*  625 */                       c3 < 0 || (
/*  626 */                       c4 = ScannerHelper.getHexadecimalValue(this.source[this.currentPosition++])) > 15 || 
/*  627 */                       c4 < 0) {
/*  628 */                       throw new InvalidInputException("Invalid_Unicode_Escape");
/*      */                     }
/*  630 */                     this.currentCharacter = (char)(((c1 * 16 + c2) * 16 + c3) * 16 + c4);
/*      */                   } 
/*      */ 
/*      */                   
/*  634 */                   if (this.currentCharacter == '\\' && 
/*  635 */                     this.source[this.currentPosition] == '\\') {
/*  636 */                     this.currentPosition++;
/*      */                   }
/*      */                 } 
/*      */ 
/*      */ 
/*      */                 
/*  642 */                 if (this.currentCharacter == '\r' && 
/*  643 */                   this.eofPosition > this.currentPosition) {
/*  644 */                   if (this.source[this.currentPosition] == '\n') {
/*  645 */                     this.currentPosition++;
/*  646 */                     this.currentCharacter = '\n';
/*  647 */                   } else if (this.source[this.currentPosition] == '\\' && 
/*  648 */                     this.source[this.currentPosition + 1] == 'u') {
/*  649 */                     isUnicode = true;
/*      */                     
/*  651 */                     int index = this.currentPosition + 1;
/*  652 */                     index++;
/*  653 */                     while (this.source[index] == 'u') {
/*  654 */                       index++;
/*      */                     }
/*      */                     
/*  657 */                     int c1 = 0, c2 = 0, c3 = 0, c4 = 0;
/*  658 */                     if ((c1 = ScannerHelper.getHexadecimalValue(this.source[index++])) > 15 || 
/*  659 */                       c1 < 0 || (
/*  660 */                       c2 = ScannerHelper.getHexadecimalValue(this.source[index++])) > 15 || 
/*  661 */                       c2 < 0 || (
/*  662 */                       c3 = ScannerHelper.getHexadecimalValue(this.source[index++])) > 15 || 
/*  663 */                       c3 < 0 || (
/*  664 */                       c4 = ScannerHelper.getHexadecimalValue(this.source[index++])) > 15 || 
/*  665 */                       c4 < 0) {
/*  666 */                       this.currentPosition = index;
/*  667 */                       throw new InvalidInputException("Invalid_Unicode_Escape");
/*      */                     } 
/*  669 */                     char unicodeChar = (char)(((c1 * 16 + c2) * 16 + c3) * 16 + c4);
/*      */                     
/*  671 */                     if (unicodeChar == '\n') {
/*  672 */                       this.currentPosition = index;
/*  673 */                       this.currentCharacter = '\n';
/*      */                     } 
/*      */                   } 
/*      */                 }
/*  677 */                 recordComment(1001);
/*  678 */                 if (this.startPosition <= this.cursorLocation && this.cursorLocation < this.currentPosition - 1) {
/*  679 */                   throw new InvalidCursorLocation("No Completion Inside Comment");
/*      */                 }
/*  681 */                 if (this.taskTags != null) checkTaskTag(this.startPosition, this.currentPosition); 
/*  682 */                 if (this.currentCharacter == '\r' || this.currentCharacter == '\n')
/*      */                 {
/*  684 */                   if (this.recordLineSeparator) {
/*  685 */                     if (isUnicode) {
/*  686 */                       pushUnicodeLineSeparator();
/*      */                     } else {
/*  688 */                       pushLineSeparator();
/*      */                     } 
/*      */                   }
/*      */                 }
/*  692 */                 if (this.tokenizeComments) {
/*  693 */                   return 1001;
/*      */                 }
/*  695 */               } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/*  696 */                 this.currentPosition--;
/*  697 */                 recordComment(1001);
/*  698 */                 if (this.taskTags != null) checkTaskTag(this.startPosition, this.currentPosition); 
/*  699 */                 if (this.tokenizeComments) {
/*  700 */                   return 1001;
/*      */                 }
/*  702 */                 this.currentPosition++;
/*      */               } 
/*      */               
/*      */               continue;
/*      */             } 
/*  707 */             if (i > 0) {
/*      */               try {
/*  709 */                 boolean isJavadoc = false, star = false;
/*  710 */                 boolean isUnicode = false;
/*      */ 
/*      */                 
/*  713 */                 this.unicodeAsBackSlash = false;
/*  714 */                 if ((this.currentCharacter = this.source[this.currentPosition++]) == '\\' && 
/*  715 */                   this.source[this.currentPosition] == 'u') {
/*  716 */                   getNextUnicodeChar();
/*  717 */                   isUnicode = true;
/*      */                 } else {
/*  719 */                   isUnicode = false;
/*  720 */                   if (this.withoutUnicodePtr != 0) {
/*  721 */                     unicodeStore();
/*      */                   }
/*      */                 } 
/*      */                 
/*  725 */                 if (this.currentCharacter == '*') {
/*  726 */                   isJavadoc = true;
/*  727 */                   star = true;
/*      */                 } 
/*  729 */                 if (this.currentCharacter == '\r' || this.currentCharacter == '\n')
/*      */                 {
/*  731 */                   if (this.recordLineSeparator && 
/*  732 */                     !isUnicode) {
/*  733 */                     pushLineSeparator();
/*      */                   }
/*      */                 }
/*      */                 
/*  737 */                 isUnicode = false;
/*  738 */                 int previous = this.currentPosition;
/*  739 */                 if ((this.currentCharacter = this.source[this.currentPosition++]) == '\\' && 
/*  740 */                   this.source[this.currentPosition] == 'u') {
/*      */                   
/*  742 */                   getNextUnicodeChar();
/*  743 */                   isUnicode = true;
/*      */                 } else {
/*  745 */                   isUnicode = false;
/*      */                 } 
/*      */                 
/*  748 */                 if (this.currentCharacter == '\\' && 
/*  749 */                   this.source[this.currentPosition] == '\\') {
/*  750 */                   this.currentPosition++;
/*      */                 }
/*      */                 
/*  753 */                 if (this.currentCharacter == '/') {
/*  754 */                   isJavadoc = false;
/*      */                 }
/*      */                 
/*  757 */                 int firstTag = 0;
/*  758 */                 while (this.currentCharacter != '/' || !star) {
/*  759 */                   if (this.currentCharacter == '\r' || this.currentCharacter == '\n')
/*      */                   {
/*  761 */                     if (this.recordLineSeparator && 
/*  762 */                       !isUnicode) {
/*  763 */                       pushLineSeparator();
/*      */                     }
/*      */                   }
/*      */                   
/*  767 */                   switch (this.currentCharacter) {
/*      */                     case '*':
/*  769 */                       star = true;
/*      */                       break;
/*      */                     case '@':
/*  772 */                       if (firstTag == 0 && isFirstTag()) {
/*  773 */                         firstTag = previous;
/*      */                       }
/*      */                     
/*      */                     default:
/*  777 */                       star = false;
/*      */                       break;
/*      */                   } 
/*  780 */                   previous = this.currentPosition;
/*  781 */                   if ((this.currentCharacter = this.source[this.currentPosition++]) == '\\' && 
/*  782 */                     this.source[this.currentPosition] == 'u') {
/*      */                     
/*  784 */                     getNextUnicodeChar();
/*  785 */                     isUnicode = true;
/*      */                   } else {
/*  787 */                     isUnicode = false;
/*      */                   } 
/*      */                   
/*  790 */                   if (this.currentCharacter == '\\' && 
/*  791 */                     this.source[this.currentPosition] == '\\') {
/*  792 */                     this.currentPosition++;
/*      */                   }
/*      */                 } 
/*  795 */                 int token = isJavadoc ? 1003 : 1002;
/*  796 */                 recordComment(token);
/*  797 */                 this.commentTagStarts[this.commentPtr] = firstTag;
/*  798 */                 if (!isJavadoc && this.startPosition <= this.cursorLocation && this.cursorLocation < this.currentPosition - 1) {
/*  799 */                   throw new InvalidCursorLocation("No Completion Inside Comment");
/*      */                 }
/*  801 */                 if (this.taskTags != null) checkTaskTag(this.startPosition, this.currentPosition); 
/*  802 */                 if (this.tokenizeComments)
/*      */                 {
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*  808 */                   return token;
/*      */                 }
/*  810 */               } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/*  811 */                 this.currentPosition--;
/*  812 */                 throw new InvalidInputException("Unterminated_Comment");
/*      */               } 
/*      */               continue;
/*      */             } 
/*  816 */             if (getNextChar('='))
/*  817 */               return 96; 
/*  818 */             return 10;
/*      */           
/*      */           case '\032':
/*  821 */             if (atEnd()) {
/*  822 */               return 64;
/*      */             }
/*  824 */             throw new InvalidInputException("Ctrl-Z");
/*      */         }  break;
/*      */       } 
/*  827 */       char c = this.currentCharacter;
/*  828 */       if (c < '') {
/*  829 */         if ((ScannerHelper.OBVIOUS_IDENT_CHAR_NATURES[c] & 0x40) != 0)
/*  830 */           return scanIdentifierOrKeyword(); 
/*  831 */         if ((ScannerHelper.OBVIOUS_IDENT_CHAR_NATURES[c] & 0x4) != 0) {
/*  832 */           return scanNumber(false);
/*      */         }
/*  834 */         return 138;
/*      */       } 
/*      */ 
/*      */       
/*  838 */       if (c >= '?' && c <= '?') {
/*  839 */         if (this.complianceLevel < 3211264L) {
/*  840 */           throw new InvalidInputException("Invalid_Unicode_Escape");
/*      */         }
/*      */         
/*  843 */         char low = (char)getNextChar();
/*  844 */         if (low < '?' || low > '?')
/*      */         {
/*  846 */           throw new InvalidInputException("Invalid_Low_Surrogate");
/*      */         }
/*  848 */         isJavaIdStart = ScannerHelper.isJavaIdentifierStart(this.complianceLevel, c, low);
/*      */       } else {
/*  850 */         if (c >= '?' && c <= '?') {
/*  851 */           if (this.complianceLevel < 3211264L) {
/*  852 */             throw new InvalidInputException("Invalid_Unicode_Escape");
/*      */           }
/*  854 */           throw new InvalidInputException("Invalid_High_Surrogate");
/*      */         } 
/*      */         
/*  857 */         isJavaIdStart = Character.isJavaIdentifierStart(c);
/*      */       } 
/*  859 */       if (isJavaIdStart)
/*  860 */         return scanIdentifierOrKeyword(); 
/*  861 */       if (ScannerHelper.isDigit(this.currentCharacter)) {
/*  862 */         return scanNumber(false);
/*      */       }
/*  864 */       return 138;
/*      */ 
/*      */     
/*      */     }
/*  868 */     catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/*  869 */       if (this.tokenizeWhiteSpace && whiteStart != this.currentPosition - 1) {
/*      */         
/*  871 */         this.currentPosition--;
/*  872 */         this.startPosition = whiteStart;
/*  873 */         return 1000;
/*      */       } 
/*      */ 
/*      */       
/*  877 */       if (this.completionIdentifier == null && 
/*  878 */         this.startPosition == this.cursorLocation + 1) {
/*  879 */         this.endOfEmptyToken = this.currentPosition - 1;
/*  880 */         this.currentPosition = this.startPosition;
/*  881 */         return 19;
/*      */       } 
/*  883 */       return 64;
/*      */     } 
/*      */   }
/*      */   protected int getNextNotFakedToken() throws InvalidInputException {
/*      */     int token;
/*  888 */     boolean fromUnget = false;
/*  889 */     if (this.nextToken != 0) {
/*  890 */       token = this.nextToken;
/*  891 */       this.nextToken = 0;
/*  892 */       fromUnget = true;
/*      */     } else {
/*  894 */       token = getNextToken();
/*      */     } 
/*  896 */     if (this.currentPosition == this.startPosition) {
/*  897 */       if (!fromUnget)
/*  898 */         this.currentPosition++; 
/*  899 */       return -1;
/*      */     } 
/*  901 */     return token;
/*      */   }
/*      */   
/*      */   protected int scanForTextBlock() throws InvalidInputException {
/*  905 */     int lastQuotePos = 0;
/*      */     try {
/*  907 */       this.rawStart = this.currentPosition - this.startPosition;
/*  908 */       while (this.currentPosition <= this.eofPosition) {
/*      */ 
/*      */ 
/*      */         
/*  912 */         int start = this.currentPosition;
/*  913 */         if (this.startPosition <= this.cursorLocation && 
/*  914 */           this.cursorLocation <= this.currentPosition - 1) {
/*  915 */           this.currentPosition = start;
/*      */           
/*  917 */           return 60;
/*      */         } 
/*      */         
/*  920 */         start = this.currentPosition;
/*  921 */         if (this.currentCharacter == '"') {
/*  922 */           lastQuotePos = this.currentPosition;
/*      */           
/*  924 */           if (scanForTextBlockClose()) {
/*  925 */             this.currentPosition += 2;
/*  926 */             return 60;
/*      */           } 
/*  928 */           if (this.withoutUnicodePtr != 0) {
/*  929 */             unicodeStore();
/*      */           }
/*      */         }
/*  932 */         else if ((this.currentCharacter == '\r' || this.currentCharacter == '\n') && 
/*  933 */           this.recordLineSeparator) {
/*  934 */           pushLineSeparator();
/*      */         } 
/*      */ 
/*      */         
/*  938 */         if (this.currentCharacter == '\\')
/*  939 */           switch (this.source[this.currentPosition]) {
/*      */             case 'f':
/*      */             case 'n':
/*      */             case 'r':
/*      */               break;
/*      */             case '\n':
/*      */             case '\r':
/*  946 */               this.currentCharacter = '\\';
/*  947 */               this.currentPosition++;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  984 */               if (this.withoutUnicodePtr != 0)
/*  985 */                 unicodeStore();  break;case '\\': this.currentPosition++; if (this.withoutUnicodePtr != 0) unicodeStore();  break;
/*      */             default:
/*      */             
/*      */           }  
/*  989 */         this.unicodeAsBackSlash = false;
/*  990 */         if ((this.currentCharacter = this.source[this.currentPosition++]) == '\\' && 
/*  991 */           this.source[this.currentPosition] == 'u') {
/*  992 */           getNextUnicodeChar(); continue;
/*      */         } 
/*  994 */         if (this.currentCharacter == '"')
/*      */           continue; 
/*  996 */         if (this.withoutUnicodePtr != 0) {
/*  997 */           unicodeStore();
/*      */         }
/*      */       } 
/*      */       
/* 1001 */       if (lastQuotePos > 0)
/* 1002 */         this.currentPosition = lastQuotePos; 
/* 1003 */       this.currentPosition = (lastQuotePos > 0) ? lastQuotePos : (this.startPosition + this.rawStart);
/* 1004 */       throw new InvalidInputException("Unterminated_Text_Block");
/* 1005 */     } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/* 1006 */       this.currentPosition = (lastQuotePos > 0) ? lastQuotePos : (this.startPosition + this.rawStart);
/* 1007 */       if (this.startPosition <= this.cursorLocation && 
/* 1008 */         this.cursorLocation < this.currentPosition)
/*      */       {
/* 1010 */         return 60;
/*      */       }
/* 1012 */       throw new InvalidInputException("Unterminated_Text_Block");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void getNextUnicodeChar() throws InvalidInputException {
/* 1018 */     int temp = this.currentPosition;
/* 1019 */     super.getNextUnicodeChar();
/* 1020 */     if (this.cursorLocation > temp) {
/* 1021 */       this.unicodeCharSize += this.currentPosition - temp;
/*      */     }
/* 1023 */     if (temp < this.cursorLocation && this.cursorLocation < this.currentPosition - 1) {
/* 1024 */       throw new InvalidCursorLocation("No Completion Inside Unicode");
/*      */     }
/*      */   }
/*      */   
/*      */   protected boolean isFirstTag() {
/* 1029 */     return 
/* 1030 */       (getNextChar('d') && 
/* 1031 */       getNextChar('e') && 
/* 1032 */       getNextChar('p') && 
/* 1033 */       getNextChar('r') && 
/* 1034 */       getNextChar('e') && 
/* 1035 */       getNextChar('c') && 
/* 1036 */       getNextChar('a') && 
/* 1037 */       getNextChar('t') && 
/* 1038 */       getNextChar('e') && 
/* 1039 */       getNextChar('d'));
/*      */   }
/*      */   public final void jumpOverBlock() {
/* 1042 */     jumpOverMethodBody();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int scanIdentifierOrKeyword() {
/* 1051 */     int id = super.scanIdentifierOrKeyword();
/*      */     
/* 1053 */     if (this.startPosition <= this.cursorLocation + 1 && 
/* 1054 */       this.cursorLocation < this.currentPosition) {
/*      */ 
/*      */       
/* 1057 */       if (this.cursorLocation + 1 == this.eofPosition) {
/* 1058 */         int temp = this.eofPosition;
/* 1059 */         this.eofPosition = this.source.length; do {  }
/* 1060 */         while (getNextCharAsJavaIdentifierPart());
/* 1061 */         this.eofPosition = temp;
/*      */       } 
/*      */       
/* 1064 */       return 19;
/*      */     } 
/* 1066 */     return id;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int scanNumber(boolean dotPrefix) throws InvalidInputException {
/* 1072 */     int token = super.scanNumber(dotPrefix);
/*      */ 
/*      */     
/* 1075 */     if (this.startPosition <= this.cursorLocation && this.cursorLocation < this.currentPosition) {
/* 1076 */       throw new InvalidCursorLocation("No Completion Inside Number");
/*      */     }
/* 1078 */     return token;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionScanner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */