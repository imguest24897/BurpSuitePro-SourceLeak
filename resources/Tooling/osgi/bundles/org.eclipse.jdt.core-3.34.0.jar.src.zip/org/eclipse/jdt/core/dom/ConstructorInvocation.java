/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstructorInvocation
/*     */   extends Statement
/*     */ {
/*  39 */   public static final ChildListPropertyDescriptor TYPE_ARGUMENTS_PROPERTY = new ChildListPropertyDescriptor(ConstructorInvocation.class, "typeArguments", Type.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final ChildListPropertyDescriptor ARGUMENTS_PROPERTY = new ChildListPropertyDescriptor(ConstructorInvocation.class, "arguments", Expression.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  65 */     List properyList = new ArrayList(2);
/*  66 */     createPropertyList(ConstructorInvocation.class, properyList);
/*  67 */     addProperty(ARGUMENTS_PROPERTY, properyList);
/*  68 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(properyList);
/*     */     
/*  70 */     properyList = new ArrayList(3);
/*  71 */     createPropertyList(ConstructorInvocation.class, properyList);
/*  72 */     addProperty(TYPE_ARGUMENTS_PROPERTY, properyList);
/*  73 */     addProperty(ARGUMENTS_PROPERTY, properyList);
/*  74 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  89 */     if (apiLevel == 2) {
/*  90 */       return PROPERTY_DESCRIPTORS_2_0;
/*     */     }
/*  92 */     return PROPERTY_DESCRIPTORS_3_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   private ASTNode.NodeList typeArguments = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private ASTNode.NodeList arguments = new ASTNode.NodeList(this, ARGUMENTS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConstructorInvocation(AST ast) {
/* 118 */     super(ast);
/* 119 */     if (ast.apiLevel >= 3) {
/* 120 */       this.typeArguments = new ASTNode.NodeList(this, TYPE_ARGUMENTS_PROPERTY);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 126 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 131 */     if (property == ARGUMENTS_PROPERTY) {
/* 132 */       return arguments();
/*     */     }
/* 134 */     if (property == TYPE_ARGUMENTS_PROPERTY) {
/* 135 */       return typeArguments();
/*     */     }
/*     */     
/* 138 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 143 */     return 17;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 148 */     ConstructorInvocation result = new ConstructorInvocation(target);
/* 149 */     result.setSourceRange(getStartPosition(), getLength());
/* 150 */     result.copyLeadingComment(this);
/* 151 */     if (this.ast.apiLevel >= 3) {
/* 152 */       result.typeArguments().addAll(ASTNode.copySubtrees(target, typeArguments()));
/*     */     }
/* 154 */     result.arguments().addAll(ASTNode.copySubtrees(target, arguments()));
/* 155 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 161 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 166 */     boolean visitChildren = visitor.visit(this);
/* 167 */     if (visitChildren) {
/* 168 */       if (this.ast.apiLevel >= 3) {
/* 169 */         acceptChildren(visitor, this.typeArguments);
/*     */       }
/* 171 */       acceptChildren(visitor, this.arguments);
/*     */     } 
/* 173 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List typeArguments() {
/* 188 */     if (this.typeArguments == null) {
/* 189 */       unsupportedIn2();
/*     */     }
/* 191 */     return this.typeArguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List arguments() {
/* 202 */     return this.arguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMethodBinding resolveConstructorBinding() {
/* 217 */     return this.ast.getBindingResolver().resolveConstructor(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 223 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 228 */     return 
/* 229 */       memSize() + (
/* 230 */       (this.typeArguments == null) ? 0 : this.typeArguments.listSize()) + (
/* 231 */       (this.arguments == null) ? 0 : this.arguments.listSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ConstructorInvocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */