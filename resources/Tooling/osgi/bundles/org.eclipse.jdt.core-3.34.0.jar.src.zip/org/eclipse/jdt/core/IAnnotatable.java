package org.eclipse.jdt.core;

public interface IAnnotatable {
  IAnnotation getAnnotation(String paramString);
  
  IAnnotation[] getAnnotations() throws JavaModelException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IAnnotatable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */