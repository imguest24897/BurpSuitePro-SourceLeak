/*      */ package org.eclipse.jdt.core.search;
/*      */ 
/*      */ import org.eclipse.core.resources.IResource;
/*      */ import org.eclipse.core.resources.IWorkspace;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.jdt.core.Flags;
/*      */ import org.eclipse.jdt.core.ICompilationUnit;
/*      */ import org.eclipse.jdt.core.IJavaElement;
/*      */ import org.eclipse.jdt.core.IJavaProject;
/*      */ import org.eclipse.jdt.core.IMethod;
/*      */ import org.eclipse.jdt.core.IType;
/*      */ import org.eclipse.jdt.core.IWorkingCopy;
/*      */ import org.eclipse.jdt.core.JavaCore;
/*      */ import org.eclipse.jdt.core.JavaModelException;
/*      */ import org.eclipse.jdt.core.WorkingCopyOwner;
/*      */ import org.eclipse.jdt.internal.compiler.env.AccessRestriction;
/*      */ import org.eclipse.jdt.internal.core.search.BasicSearchEngine;
/*      */ import org.eclipse.jdt.internal.core.search.IRestrictedAccessMethodRequestor;
/*      */ import org.eclipse.jdt.internal.core.search.IRestrictedAccessTypeRequestor;
/*      */ import org.eclipse.jdt.internal.core.search.MethodNameMatchRequestorWrapper;
/*      */ import org.eclipse.jdt.internal.core.search.MethodNameRequestorWrapper;
/*      */ import org.eclipse.jdt.internal.core.search.TypeNameMatchRequestorWrapper;
/*      */ import org.eclipse.jdt.internal.core.search.TypeNameRequestorWrapper;
/*      */ import org.eclipse.jdt.internal.core.search.matching.DeclarationOfAccessedFieldsPattern;
/*      */ import org.eclipse.jdt.internal.core.search.matching.DeclarationOfReferencedMethodsPattern;
/*      */ import org.eclipse.jdt.internal.core.search.matching.DeclarationOfReferencedTypesPattern;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SearchEngine
/*      */ {
/*      */   private BasicSearchEngine basicEngine;
/*      */   
/*      */   static class SearchPatternAdapter
/*      */     implements ISearchPattern
/*      */   {
/*      */     SearchPattern pattern;
/*      */     
/*      */     SearchPatternAdapter(SearchPattern pattern) {
/*   50 */       this.pattern = pattern;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class ResultCollectorAdapter
/*      */     extends SearchRequestor
/*      */   {
/*      */     IJavaSearchResultCollector resultCollector;
/*      */     
/*      */     ResultCollectorAdapter(IJavaSearchResultCollector resultCollector) {
/*   61 */       this.resultCollector = resultCollector;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void acceptSearchMatch(SearchMatch match) throws CoreException {
/*   68 */       this.resultCollector.accept(
/*   69 */           match.getResource(), 
/*   70 */           match.getOffset(), 
/*   71 */           match.getOffset() + match.getLength(), 
/*   72 */           (IJavaElement)match.getElement(), 
/*   73 */           match.getAccuracy());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void beginReporting() {
/*   81 */       this.resultCollector.aboutToStart();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void endReporting() {
/*   88 */       this.resultCollector.done();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class TypeNameRequestorAdapter
/*      */     implements IRestrictedAccessTypeRequestor
/*      */   {
/*      */     ITypeNameRequestor nameRequestor;
/*      */     
/*      */     TypeNameRequestorAdapter(ITypeNameRequestor requestor) {
/*   99 */       this.nameRequestor = requestor;
/*      */     }
/*      */     
/*      */     public void acceptType(int modifiers, char[] packageName, char[] simpleTypeName, char[][] enclosingTypeNames, String path, AccessRestriction access) {
/*  103 */       if (Flags.isInterface(modifiers)) {
/*  104 */         this.nameRequestor.acceptInterface(packageName, simpleTypeName, enclosingTypeNames, path);
/*      */       } else {
/*  106 */         this.nameRequestor.acceptClass(packageName, simpleTypeName, enclosingTypeNames, path);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SearchEngine() {
/*  118 */     this.basicEngine = new BasicSearchEngine();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SearchEngine(ICompilationUnit[] workingCopies) {
/*  134 */     this.basicEngine = new BasicSearchEngine(workingCopies);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SearchEngine(IWorkingCopy[] workingCopies) {
/*  150 */     int length = workingCopies.length;
/*  151 */     ICompilationUnit[] units = new ICompilationUnit[length];
/*  152 */     System.arraycopy(workingCopies, 0, units, 0, length);
/*  153 */     this.basicEngine = new BasicSearchEngine(units);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SearchEngine(WorkingCopyOwner workingCopyOwner) {
/*  165 */     this.basicEngine = new BasicSearchEngine(workingCopyOwner);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaSearchScope createHierarchyScope(IType type) throws JavaModelException {
/*  178 */     return BasicSearchEngine.createHierarchyScope(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaSearchScope createHierarchyScope(IType type, WorkingCopyOwner owner) throws JavaModelException {
/*  195 */     return BasicSearchEngine.createHierarchyScope(type, owner);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaSearchScope createStrictHierarchyScope(IJavaProject project, IType type, boolean onlySubtypes, boolean includeFocusType, WorkingCopyOwner owner) throws JavaModelException {
/*  225 */     return BasicSearchEngine.createStrictHierarchyScope(project, type, onlySubtypes, includeFocusType, owner);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaSearchScope createJavaSearchScope(IResource[] resources) {
/*  242 */     int length = resources.length;
/*  243 */     IJavaElement[] elements = new IJavaElement[length];
/*  244 */     for (int i = 0; i < length; i++) {
/*  245 */       elements[i] = JavaCore.create(resources[i]);
/*      */     }
/*  247 */     return createJavaSearchScope(elements);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaSearchScope createJavaSearchScope(IJavaElement[] elements) {
/*  271 */     return BasicSearchEngine.createJavaSearchScope(elements);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaSearchScope createJavaSearchScope(IJavaElement[] elements, boolean includeReferencedProjects) {
/*  295 */     return BasicSearchEngine.createJavaSearchScope(elements, includeReferencedProjects);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaSearchScope createJavaSearchScope(boolean excludeTestCode, IJavaElement[] elements, boolean includeReferencedProjects) {
/*  320 */     return BasicSearchEngine.createJavaSearchScope(excludeTestCode, elements, includeReferencedProjects);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaSearchScope createJavaSearchScope(IJavaElement[] elements, int includeMask) {
/*  357 */     return BasicSearchEngine.createJavaSearchScope(elements, includeMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaSearchScope createJavaSearchScope(boolean excludeTestCode, IJavaElement[] elements, int includeMask) {
/*  395 */     return BasicSearchEngine.createJavaSearchScope(excludeTestCode, elements, includeMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ISearchPattern createOrSearchPattern(ISearchPattern leftPattern, ISearchPattern rightPattern) {
/*  408 */     SearchPattern left = ((SearchPatternAdapter)leftPattern).pattern;
/*  409 */     SearchPattern right = ((SearchPatternAdapter)rightPattern).pattern;
/*  410 */     SearchPattern pattern = SearchPattern.createOrPattern(left, right);
/*  411 */     return new SearchPatternAdapter(pattern);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ISearchPattern createSearchPattern(String stringPattern, int searchFor, int limitTo, boolean isCaseSensitive) {
/*  462 */     int matchMode = (stringPattern.indexOf('*') != -1 || stringPattern.indexOf('?') != -1) ? 
/*  463 */       2 : 
/*  464 */       0;
/*  465 */     int matchRule = isCaseSensitive ? (matchMode | 0x8) : matchMode;
/*  466 */     return new SearchPatternAdapter(SearchPattern.createPattern(stringPattern, searchFor, limitTo, matchRule));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ISearchPattern createSearchPattern(IJavaElement element, int limitTo) {
/*  492 */     return new SearchPatternAdapter(SearchPattern.createPattern(element, limitTo));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TypeNameMatch createTypeNameMatch(IType type, int modifiers) {
/*  504 */     return BasicSearchEngine.createTypeNameMatch(type, modifiers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MethodNameMatch createMethodNameMatch(IMethod method, int modifiers) {
/*  520 */     return BasicSearchEngine.createMethodNameMatch(method, modifiers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaSearchScope createWorkspaceScope() {
/*  529 */     return BasicSearchEngine.createWorkspaceScope();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SearchParticipant getDefaultSearchParticipant() {
/*  538 */     return BasicSearchEngine.getDefaultSearchParticipant();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void search(IWorkspace workspace, String patternString, int searchFor, int limitTo, IJavaSearchScope scope, IJavaSearchResultCollector resultCollector) throws JavaModelException {
/*      */     try {
/*  578 */       int matchMode = (patternString.indexOf('*') != -1 || patternString.indexOf('?') != -1) ? 
/*  579 */         2 : 
/*  580 */         0;
/*  581 */       search(
/*  582 */           SearchPattern.createPattern(patternString, searchFor, limitTo, matchMode | 0x8), 
/*  583 */           new SearchParticipant[] { getDefaultSearchParticipant()
/*  584 */           }, scope, 
/*  585 */           new ResultCollectorAdapter(resultCollector), 
/*  586 */           resultCollector.getProgressMonitor());
/*  587 */     } catch (CoreException e) {
/*  588 */       if (e instanceof JavaModelException)
/*  589 */         throw (JavaModelException)e; 
/*  590 */       throw new JavaModelException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void search(IWorkspace workspace, IJavaElement element, int limitTo, IJavaSearchScope scope, IJavaSearchResultCollector resultCollector) throws JavaModelException {
/*  620 */     search(workspace, createSearchPattern(element, limitTo), scope, resultCollector);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void search(IWorkspace workspace, ISearchPattern searchPattern, IJavaSearchScope scope, IJavaSearchResultCollector resultCollector) throws JavaModelException {
/*      */     try {
/*  640 */       search(
/*  641 */           ((SearchPatternAdapter)searchPattern).pattern, 
/*  642 */           new SearchParticipant[] { getDefaultSearchParticipant()
/*  643 */           }, scope, 
/*  644 */           new ResultCollectorAdapter(resultCollector), 
/*  645 */           resultCollector.getProgressMonitor());
/*  646 */     } catch (CoreException e) {
/*  647 */       if (e instanceof JavaModelException)
/*  648 */         throw (JavaModelException)e; 
/*  649 */       throw new JavaModelException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void search(SearchPattern pattern, SearchParticipant[] participants, IJavaSearchScope scope, SearchRequestor requestor, IProgressMonitor monitor) throws CoreException {
/*  670 */     this.basicEngine.search(pattern, participants, scope, requestor, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchAllMethodNames(char[] packageName, int pkgMatchRule, char[] declaringQualification, int declQualificationMatchRule, char[] declaringSimpleName, int declSimpleNameMatchRule, char[] methodName, int methodMatchRule, IJavaSearchScope scope, MethodNameRequestor nameRequestor, int waitingPolicy, IProgressMonitor progressMonitor) throws JavaModelException {
/*  721 */     MethodNameRequestorWrapper requestorWrapper = new MethodNameRequestorWrapper(nameRequestor);
/*  722 */     this.basicEngine.searchAllMethodNames(
/*  723 */         packageName, pkgMatchRule, 
/*  724 */         declaringQualification, declQualificationMatchRule, 
/*  725 */         declaringSimpleName, declSimpleNameMatchRule, 
/*  726 */         methodName, methodMatchRule, 
/*  727 */         scope, (IRestrictedAccessMethodRequestor)requestorWrapper, 
/*  728 */         waitingPolicy, progressMonitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchAllMethodNames(char[] packageName, int pkgMatchRule, char[] declaringQualification, int declQualificationMatchRule, char[] declaringSimpleName, int declSimpleNameMatchRule, char[] methodName, int methodMatchRule, IJavaSearchScope scope, MethodNameMatchRequestor nameRequestor, int waitingPolicy, IProgressMonitor progressMonitor) throws JavaModelException {
/*  783 */     MethodNameMatchRequestorWrapper requestorWrapper = new MethodNameMatchRequestorWrapper(nameRequestor, scope);
/*  784 */     this.basicEngine.searchAllMethodNames(
/*  785 */         packageName, pkgMatchRule, 
/*  786 */         declaringQualification, declQualificationMatchRule, 
/*  787 */         declaringSimpleName, declSimpleNameMatchRule, 
/*  788 */         methodName, methodMatchRule, 
/*  789 */         scope, (IRestrictedAccessMethodRequestor)requestorWrapper, 
/*  790 */         waitingPolicy, progressMonitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchAllMethodNames(char[] qualifier, int qualifierMatchRule, char[] methodName, int methodMatchRule, IJavaSearchScope scope, MethodNameRequestor nameRequestor, int waitingPolicy, IProgressMonitor progressMonitor) throws JavaModelException {
/*  858 */     MethodNameRequestorWrapper requestorWrapper = new MethodNameRequestorWrapper(nameRequestor);
/*  859 */     this.basicEngine.searchAllMethodNames(
/*  860 */         qualifier, qualifierMatchRule, 
/*  861 */         methodName, methodMatchRule, 
/*  862 */         scope, (IRestrictedAccessMethodRequestor)requestorWrapper, 
/*  863 */         waitingPolicy, progressMonitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchAllMethodNames(char[] qualifier, int qualifierMatchRule, char[] methodName, int methodMatchRule, IJavaSearchScope scope, MethodNameMatchRequestor nameRequestor, int waitingPolicy, IProgressMonitor progressMonitor) throws JavaModelException {
/*  934 */     MethodNameMatchRequestorWrapper requestorWrapper = new MethodNameMatchRequestorWrapper(nameRequestor, scope);
/*  935 */     this.basicEngine.searchAllMethodNames(
/*  936 */         qualifier, qualifierMatchRule, 
/*  937 */         methodName, methodMatchRule, 
/*  938 */         scope, (IRestrictedAccessMethodRequestor)requestorWrapper, 
/*  939 */         waitingPolicy, progressMonitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchAllTypeNames(char[] packageExactName, char[] typeName, int matchRule, int searchFor, IJavaSearchScope scope, TypeNameRequestor nameRequestor, int waitingPolicy, IProgressMonitor progressMonitor) throws JavaModelException {
/* 1011 */     searchAllTypeNames(packageExactName, 0, typeName, matchRule, searchFor, scope, nameRequestor, waitingPolicy, progressMonitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchAllTypeNames(char[] packageName, int packageMatchRule, char[] typeName, int typeMatchRule, int searchFor, IJavaSearchScope scope, TypeNameRequestor nameRequestor, int waitingPolicy, IProgressMonitor progressMonitor) throws JavaModelException {
/* 1099 */     TypeNameRequestorWrapper requestorWrapper = new TypeNameRequestorWrapper(nameRequestor);
/* 1100 */     this.basicEngine.searchAllTypeNames(packageName, 
/* 1101 */         packageMatchRule, 
/* 1102 */         typeName, 
/* 1103 */         typeMatchRule, 
/* 1104 */         searchFor, 
/* 1105 */         scope, 
/* 1106 */         (IRestrictedAccessTypeRequestor)requestorWrapper, 
/* 1107 */         waitingPolicy, 
/* 1108 */         progressMonitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchAllTypeNames(char[] packageName, int packageMatchRule, char[] typeName, int typeMatchRule, int searchFor, IJavaSearchScope scope, TypeNameMatchRequestor nameMatchRequestor, int waitingPolicy, IProgressMonitor progressMonitor) throws JavaModelException {
/* 1201 */     TypeNameMatchRequestorWrapper requestorWrapper = new TypeNameMatchRequestorWrapper(nameMatchRequestor, scope);
/* 1202 */     this.basicEngine.searchAllTypeNames(packageName, 
/* 1203 */         packageMatchRule, 
/* 1204 */         typeName, 
/* 1205 */         typeMatchRule, 
/* 1206 */         searchFor, 
/* 1207 */         scope, 
/* 1208 */         (IRestrictedAccessTypeRequestor)requestorWrapper, 
/* 1209 */         waitingPolicy, 
/* 1210 */         progressMonitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchAllTypeNames(char[][] qualifications, char[][] typeNames, IJavaSearchScope scope, TypeNameRequestor nameRequestor, int waitingPolicy, IProgressMonitor progressMonitor) throws JavaModelException {
/* 1247 */     TypeNameRequestorWrapper requestorWrapper = new TypeNameRequestorWrapper(nameRequestor);
/* 1248 */     this.basicEngine.searchAllTypeNames(
/* 1249 */         qualifications, 
/* 1250 */         typeNames, 
/* 1251 */         8, 
/* 1252 */         0, 
/* 1253 */         scope, 
/* 1254 */         (IRestrictedAccessTypeRequestor)requestorWrapper, 
/* 1255 */         waitingPolicy, 
/* 1256 */         progressMonitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchAllTypeNames(char[][] qualifications, char[][] typeNames, IJavaSearchScope scope, TypeNameMatchRequestor nameMatchRequestor, int waitingPolicy, IProgressMonitor progressMonitor) throws JavaModelException {
/* 1298 */     TypeNameMatchRequestorWrapper requestorWrapper = new TypeNameMatchRequestorWrapper(nameMatchRequestor, scope);
/* 1299 */     this.basicEngine.searchAllTypeNames(
/* 1300 */         qualifications, 
/* 1301 */         typeNames, 
/* 1302 */         8, 
/* 1303 */         0, 
/* 1304 */         scope, 
/* 1305 */         (IRestrictedAccessTypeRequestor)requestorWrapper, 
/* 1306 */         waitingPolicy, 
/* 1307 */         progressMonitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchAllTypeNames(char[] packageName, char[] typeName, int matchRule, int searchFor, IJavaSearchScope scope, ITypeNameRequestor nameRequestor, int waitingPolicy, IProgressMonitor progressMonitor) throws JavaModelException {
/* 1366 */     TypeNameRequestorAdapter requestorAdapter = new TypeNameRequestorAdapter(nameRequestor);
/* 1367 */     this.basicEngine.searchAllTypeNames(packageName, 0, typeName, matchRule, searchFor, scope, requestorAdapter, waitingPolicy, progressMonitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchAllTypeNames(IWorkspace workspace, char[] packageName, char[] typeName, int matchMode, boolean isCaseSensitive, int searchFor, IJavaSearchScope scope, ITypeNameRequestor nameRequestor, int waitingPolicy, IProgressMonitor progressMonitor) throws JavaModelException {
/* 1426 */     searchAllTypeNames(
/* 1427 */         packageName, 
/* 1428 */         typeName, 
/* 1429 */         isCaseSensitive ? (matchMode | 0x8) : matchMode, 
/* 1430 */         searchFor, 
/* 1431 */         scope, 
/* 1432 */         nameRequestor, 
/* 1433 */         waitingPolicy, 
/* 1434 */         progressMonitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchDeclarationsOfAccessedFields(IJavaElement enclosingElement, SearchRequestor requestor, IProgressMonitor monitor) throws JavaModelException {
/* 1477 */     this.basicEngine.searchDeclarationsOfAccessedFields(enclosingElement, requestor, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchDeclarationsOfAccessedFields(IWorkspace workspace, IJavaElement enclosingElement, IJavaSearchResultCollector resultCollector) throws JavaModelException {
/* 1519 */     DeclarationOfAccessedFieldsPattern declarationOfAccessedFieldsPattern = new DeclarationOfAccessedFieldsPattern(enclosingElement);
/* 1520 */     this.basicEngine.searchDeclarations(enclosingElement, new ResultCollectorAdapter(resultCollector), (SearchPattern)declarationOfAccessedFieldsPattern, resultCollector.getProgressMonitor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchDeclarationsOfReferencedTypes(IJavaElement enclosingElement, SearchRequestor requestor, IProgressMonitor monitor) throws JavaModelException {
/* 1563 */     this.basicEngine.searchDeclarationsOfReferencedTypes(enclosingElement, requestor, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchDeclarationsOfReferencedTypes(IWorkspace workspace, IJavaElement enclosingElement, IJavaSearchResultCollector resultCollector) throws JavaModelException {
/* 1605 */     DeclarationOfReferencedTypesPattern declarationOfReferencedTypesPattern = new DeclarationOfReferencedTypesPattern(enclosingElement);
/* 1606 */     this.basicEngine.searchDeclarations(enclosingElement, new ResultCollectorAdapter(resultCollector), (SearchPattern)declarationOfReferencedTypesPattern, resultCollector.getProgressMonitor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchDeclarationsOfSentMessages(IJavaElement enclosingElement, SearchRequestor requestor, IProgressMonitor monitor) throws JavaModelException {
/* 1652 */     this.basicEngine.searchDeclarationsOfSentMessages(enclosingElement, requestor, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void searchDeclarationsOfSentMessages(IWorkspace workspace, IJavaElement enclosingElement, IJavaSearchResultCollector resultCollector) throws JavaModelException {
/* 1697 */     DeclarationOfReferencedMethodsPattern declarationOfReferencedMethodsPattern = new DeclarationOfReferencedMethodsPattern(enclosingElement);
/* 1698 */     this.basicEngine.searchDeclarations(enclosingElement, new ResultCollectorAdapter(resultCollector), (SearchPattern)declarationOfReferencedMethodsPattern, resultCollector.getProgressMonitor());
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\search\SearchEngine.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */