/*    */ package org.eclipse.jdt.core.jdom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DOMException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 2536853590795032028L;
/*    */   
/*    */   public DOMException() {}
/*    */   
/*    */   public DOMException(String message) {
/* 41 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\jdom\DOMException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */