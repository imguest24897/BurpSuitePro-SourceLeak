package org.eclipse.jdt.core.jdom;

public interface IDOMField extends IDOMMember {
  String getInitializer();
  
  String getName();
  
  String getType();
  
  void setInitializer(String paramString);
  
  void setName(String paramString) throws IllegalArgumentException;
  
  void setType(String paramString) throws IllegalArgumentException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\jdom\IDOMField.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */