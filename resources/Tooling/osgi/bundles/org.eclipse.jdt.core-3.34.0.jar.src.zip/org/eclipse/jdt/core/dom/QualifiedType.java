/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QualifiedType
/*     */   extends AnnotatableType
/*     */ {
/*     */   int index;
/*  83 */   public static final ChildPropertyDescriptor QUALIFIER_PROPERTY = new ChildPropertyDescriptor(QualifiedType.class, "qualifier", Type.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public static final ChildListPropertyDescriptor ANNOTATIONS_PROPERTY = internalAnnotationsPropertyFactory(QualifiedType.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(QualifiedType.class, "name", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_8_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 113 */     List propertyList = new ArrayList(3);
/* 114 */     createPropertyList(QualifiedType.class, propertyList);
/* 115 */     addProperty(QUALIFIER_PROPERTY, propertyList);
/* 116 */     addProperty(NAME_PROPERTY, propertyList);
/* 117 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */     
/* 119 */     propertyList = new ArrayList(4);
/* 120 */     createPropertyList(QualifiedType.class, propertyList);
/* 121 */     addProperty(QUALIFIER_PROPERTY, propertyList);
/* 122 */     addProperty(ANNOTATIONS_PROPERTY, propertyList);
/* 123 */     addProperty(NAME_PROPERTY, propertyList);
/* 124 */     PROPERTY_DESCRIPTORS_8_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 137 */     switch (apiLevel) {
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/* 141 */         return PROPERTY_DESCRIPTORS;
/*     */     } 
/* 143 */     return PROPERTY_DESCRIPTORS_8_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 151 */   private Type qualifier = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 157 */   private SimpleName name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   QualifiedType(AST ast) {
/* 169 */     super(ast);
/* 170 */     unsupportedIn2();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalAnnotationsProperty() {
/* 179 */     return ANNOTATIONS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 184 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 189 */     if (property == ANNOTATIONS_PROPERTY) {
/* 190 */       return annotations();
/*     */     }
/*     */     
/* 193 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 198 */     if (property == QUALIFIER_PROPERTY) {
/* 199 */       if (get) {
/* 200 */         return getQualifier();
/*     */       }
/* 202 */       setQualifier((Type)child);
/* 203 */       return null;
/*     */     } 
/*     */     
/* 206 */     if (property == NAME_PROPERTY) {
/* 207 */       if (get) {
/* 208 */         return getName();
/*     */       }
/* 210 */       setName((SimpleName)child);
/* 211 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 215 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 220 */     return 75;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 225 */     QualifiedType result = new QualifiedType(target);
/* 226 */     result.setSourceRange(getStartPosition(), getLength());
/* 227 */     result.setQualifier((Type)getQualifier().clone(target));
/* 228 */     if (this.ast.apiLevel >= 8) {
/* 229 */       result.annotations().addAll(
/* 230 */           ASTNode.copySubtrees(target, annotations()));
/*     */     }
/* 232 */     result.setName((SimpleName)getName().clone(target));
/* 233 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 239 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 244 */     boolean visitChildren = visitor.visit(this);
/* 245 */     if (visitChildren) {
/*     */       
/* 247 */       acceptChild(visitor, getQualifier());
/* 248 */       if (this.ast.apiLevel >= 8) {
/* 249 */         acceptChildren(visitor, this.annotations);
/*     */       }
/* 251 */       acceptChild(visitor, getName());
/*     */     } 
/* 253 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getQualifier() {
/* 262 */     if (this.qualifier == null)
/*     */     {
/* 264 */       synchronized (this) {
/* 265 */         if (this.qualifier == null) {
/* 266 */           preLazyInit();
/* 267 */           this.qualifier = new SimpleType(this.ast);
/* 268 */           postLazyInit(this.qualifier, QUALIFIER_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 272 */     return this.qualifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQualifier(Type type) {
/* 286 */     if (type == null) {
/* 287 */       throw new IllegalArgumentException();
/*     */     }
/* 289 */     ASTNode oldChild = this.qualifier;
/* 290 */     preReplaceChild(oldChild, type, QUALIFIER_PROPERTY);
/* 291 */     this.qualifier = type;
/* 292 */     postReplaceChild(oldChild, type, QUALIFIER_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 301 */     if (this.name == null)
/*     */     {
/* 303 */       synchronized (this) {
/* 304 */         if (this.name == null) {
/* 305 */           preLazyInit();
/* 306 */           this.name = new SimpleName(this.ast);
/* 307 */           postLazyInit(this.name, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 311 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName name) {
/* 325 */     if (name == null) {
/* 326 */       throw new IllegalArgumentException();
/*     */     }
/* 328 */     ASTNode oldChild = this.name;
/* 329 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 330 */     this.name = name;
/* 331 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 337 */     return 56;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 342 */     return 
/* 343 */       memSize() + (
/* 344 */       (this.qualifier == null) ? 0 : getQualifier().treeSize()) + (
/* 345 */       (this.annotations == null) ? 0 : this.annotations.listSize()) + (
/* 346 */       (this.name == null) ? 0 : getName().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\QualifiedType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */