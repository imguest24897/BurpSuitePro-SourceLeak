/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.ExplicitConstructorCall;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.SourceTypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnExplicitConstructorCall
/*    */   extends ExplicitConstructorCall
/*    */ {
/*    */   public CompletionOnExplicitConstructorCall(int accessMode) {
/* 44 */     super(accessMode);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public StringBuffer printStatement(int tab, StringBuffer output) {
/* 50 */     printIndent(tab, output);
/* 51 */     output.append("<CompleteOnExplicitConstructorCall:");
/* 52 */     if (this.qualification != null) this.qualification.printExpression(0, output).append('.'); 
/* 53 */     if (this.accessMode == 3) {
/* 54 */       output.append("this(");
/*    */     } else {
/* 56 */       output.append("super(");
/*    */     } 
/* 58 */     if (this.arguments != null) {
/* 59 */       for (int i = 0; i < this.arguments.length; i++) {
/* 60 */         if (i > 0) output.append(", "); 
/* 61 */         this.arguments[i].printExpression(0, output);
/*    */       } 
/*    */     }
/* 64 */     return output.append(")>;");
/*    */   }
/*    */ 
/*    */   
/*    */   public void resolve(BlockScope scope) {
/*    */     ReferenceBinding referenceBinding;
/* 70 */     SourceTypeBinding sourceTypeBinding = scope.enclosingSourceType();
/*    */     
/* 72 */     if (this.arguments != null) {
/* 73 */       int argsLength = this.arguments.length;
/* 74 */       for (int a = argsLength; --a >= 0;) {
/* 75 */         this.arguments[a].resolveType(scope);
/*    */       }
/*    */     } 
/* 78 */     if (this.accessMode != 3 && sourceTypeBinding != null) {
/* 79 */       if (sourceTypeBinding.isHierarchyInconsistent())
/* 80 */         throw new CompletionNodeFound(); 
/* 81 */       referenceBinding = sourceTypeBinding.superclass();
/*    */     } 
/* 83 */     if (referenceBinding == null) {
/* 84 */       throw new CompletionNodeFound();
/*    */     }
/* 86 */     throw new CompletionNodeFound(this, referenceBinding, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnExplicitConstructorCall.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */