package org.eclipse.jdt.core;

import org.eclipse.jdt.core.search.TypeNameRequestor;

class null extends TypeNameRequestor {
  public void acceptType(int modifiers, char[] packageName, char[] simpleTypeName, char[][] enclosingTypeNames, String path) {}
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\JavaCore$2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */