/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodRef
/*     */   extends ASTNode
/*     */   implements IDocElement
/*     */ {
/*  42 */   public static final ChildPropertyDescriptor QUALIFIER_PROPERTY = new ChildPropertyDescriptor(MethodRef.class, "qualifier", Name.class, false, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(MethodRef.class, "name", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   public static final ChildListPropertyDescriptor PARAMETERS_PROPERTY = new ChildListPropertyDescriptor(MethodRef.class, "parameters", MethodRefParameter.class, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  66 */     List properyList = new ArrayList(4);
/*  67 */     createPropertyList(MethodRef.class, properyList);
/*  68 */     addProperty(QUALIFIER_PROPERTY, properyList);
/*  69 */     addProperty(NAME_PROPERTY, properyList);
/*  70 */     addProperty(PARAMETERS_PROPERTY, properyList);
/*  71 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  84 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   private Name optionalQualifier = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   private SimpleName methodName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   private ASTNode.NodeList parameters = new ASTNode.NodeList(this, PARAMETERS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MethodRef(AST ast) {
/* 121 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 126 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 131 */     if (property == QUALIFIER_PROPERTY) {
/* 132 */       if (get) {
/* 133 */         return getQualifier();
/*     */       }
/* 135 */       setQualifier((Name)child);
/* 136 */       return null;
/*     */     } 
/*     */     
/* 139 */     if (property == NAME_PROPERTY) {
/* 140 */       if (get) {
/* 141 */         return getName();
/*     */       }
/* 143 */       setName((SimpleName)child);
/* 144 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 148 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 153 */     if (property == PARAMETERS_PROPERTY) {
/* 154 */       return parameters();
/*     */     }
/*     */     
/* 157 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 162 */     return 68;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 167 */     MethodRef result = new MethodRef(target);
/* 168 */     result.setSourceRange(getStartPosition(), getLength());
/* 169 */     result.setQualifier((Name)ASTNode.copySubtree(target, getQualifier()));
/* 170 */     result.setName((SimpleName)ASTNode.copySubtree(target, getName()));
/* 171 */     result.parameters().addAll(
/* 172 */         ASTNode.copySubtrees(target, parameters()));
/* 173 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 179 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 184 */     boolean visitChildren = visitor.visit(this);
/* 185 */     if (visitChildren) {
/*     */       
/* 187 */       acceptChild(visitor, getQualifier());
/* 188 */       acceptChild(visitor, getName());
/* 189 */       acceptChildren(visitor, this.parameters);
/*     */     } 
/* 191 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getQualifier() {
/* 201 */     return this.optionalQualifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQualifier(Name name) {
/* 216 */     ASTNode oldChild = this.optionalQualifier;
/* 217 */     preReplaceChild(oldChild, name, QUALIFIER_PROPERTY);
/* 218 */     this.optionalQualifier = name;
/* 219 */     postReplaceChild(oldChild, name, QUALIFIER_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 228 */     if (this.methodName == null)
/*     */     {
/* 230 */       synchronized (this) {
/* 231 */         if (this.methodName == null) {
/* 232 */           preLazyInit();
/* 233 */           this.methodName = new SimpleName(this.ast);
/* 234 */           postLazyInit(this.methodName, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 238 */     return this.methodName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName name) {
/* 254 */     if (name == null) {
/* 255 */       throw new IllegalArgumentException();
/*     */     }
/* 257 */     ASTNode oldChild = this.methodName;
/* 258 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 259 */     this.methodName = name;
/* 260 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List parameters() {
/* 271 */     return this.parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IBinding resolveBinding() {
/* 286 */     return this.ast.getBindingResolver().resolveReference(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 291 */     return 52;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 296 */     return 
/* 297 */       memSize() + (
/* 298 */       (this.optionalQualifier == null) ? 0 : getQualifier().treeSize()) + (
/* 299 */       (this.methodName == null) ? 0 : getName().treeSize()) + 
/* 300 */       this.parameters.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\MethodRef.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */