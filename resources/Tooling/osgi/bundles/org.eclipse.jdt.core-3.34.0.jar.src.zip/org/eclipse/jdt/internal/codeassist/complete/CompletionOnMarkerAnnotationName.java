/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*    */ import org.eclipse.jdt.internal.compiler.ast.MarkerAnnotation;
/*    */ import org.eclipse.jdt.internal.compiler.ast.QualifiedTypeReference;
/*    */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnMarkerAnnotationName
/*    */   extends MarkerAnnotation
/*    */ {
/*    */   public CompletionOnMarkerAnnotationName(TypeReference type, int sourceStart) {
/* 25 */     super(type, sourceStart);
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeBinding resolveType(BlockScope scope) {
/* 30 */     if (this.type instanceof QualifiedTypeReference) {
/* 31 */       QualifiedTypeReference qualifiedTypeReference = (QualifiedTypeReference)this.type;
/* 32 */       Binding binding = scope.parent.getTypeOrPackage(qualifiedTypeReference.tokens);
/* 33 */       if (!binding.isValidBinding()) {
/* 34 */         scope.problemReporter().invalidType((ASTNode)this, (TypeBinding)binding);
/* 35 */         throw new CompletionNodeFound();
/*    */       } 
/* 37 */       throw new CompletionNodeFound(this, binding, scope);
/*    */     } 
/* 39 */     throw new CompletionNodeFound(this, null, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnMarkerAnnotationName.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */