/*     */ package org.eclipse.jdt.core.dom.rewrite;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.jdt.core.ICompilationUnit;
/*     */ import org.eclipse.jdt.core.ITypeRoot;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.core.dom.AST;
/*     */ import org.eclipse.jdt.core.dom.ASTNode;
/*     */ import org.eclipse.jdt.core.dom.ASTVisitor;
/*     */ import org.eclipse.jdt.core.dom.Block;
/*     */ import org.eclipse.jdt.core.dom.ChildListPropertyDescriptor;
/*     */ import org.eclipse.jdt.core.dom.ChildPropertyDescriptor;
/*     */ import org.eclipse.jdt.core.dom.CompilationUnit;
/*     */ import org.eclipse.jdt.core.dom.SimplePropertyDescriptor;
/*     */ import org.eclipse.jdt.core.dom.StructuralPropertyDescriptor;
/*     */ import org.eclipse.jdt.internal.compiler.parser.RecoveryScannerData;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.ASTRewriteAnalyzer;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.LineInformation;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.NodeInfoStore;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.NodeRewriteEvent;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.RewriteEvent;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.RewriteEventStore;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.TrackedNodePosition;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.TextUtilities;
/*     */ import org.eclipse.text.edits.MultiTextEdit;
/*     */ import org.eclipse.text.edits.TextEdit;
/*     */ import org.eclipse.text.edits.TextEditGroup;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASTRewrite
/*     */ {
/*     */   private final AST ast;
/*     */   private final RewriteEventStore eventStore;
/*     */   private final NodeInfoStore nodeStore;
/* 120 */   private TargetSourceRangeComputer targetSourceRangeComputer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   private Object property1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   private Object property2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ASTRewrite create(AST ast) {
/* 150 */     return new ASTRewrite(ast);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ASTRewrite(AST ast) {
/* 160 */     this.ast = ast;
/* 161 */     this.eventStore = new RewriteEventStore();
/* 162 */     this.nodeStore = new NodeInfoStore(ast);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final AST getAST() {
/* 171 */     return this.ast;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final RewriteEventStore getRewriteEventStore() {
/* 180 */     return this.eventStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final NodeInfoStore getNodeStore() {
/* 189 */     return this.nodeStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextEdit rewriteAST(IDocument document, Map options) throws IllegalArgumentException {
/* 221 */     if (document == null) {
/* 222 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 225 */     ASTNode rootNode = getRootNode();
/* 226 */     if (rootNode == null) {
/* 227 */       return (TextEdit)new MultiTextEdit();
/*     */     }
/*     */     
/* 230 */     char[] content = document.get().toCharArray();
/* 231 */     LineInformation lineInfo = LineInformation.create(document);
/* 232 */     String lineDelim = TextUtilities.getDefaultLineDelimiter(document);
/*     */     
/* 234 */     ASTNode astRoot = rootNode.getRoot();
/* 235 */     List commentNodes = (astRoot instanceof CompilationUnit) ? ((CompilationUnit)astRoot).getCommentList() : null;
/* 236 */     Map currentOptions = (options == null) ? JavaCore.getOptions() : options;
/* 237 */     return internalRewriteAST(content, lineInfo, lineDelim, commentNodes, currentOptions, rootNode, (RecoveryScannerData)((CompilationUnit)astRoot).getStatementsRecoveryData());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextEdit rewriteAST() throws JavaModelException, IllegalArgumentException {
/* 275 */     ASTNode rootNode = getRootNode();
/* 276 */     if (rootNode == null) {
/* 277 */       return (TextEdit)new MultiTextEdit();
/*     */     }
/*     */     
/* 280 */     ASTNode root = rootNode.getRoot();
/* 281 */     if (!(root instanceof CompilationUnit)) {
/* 282 */       throw new IllegalArgumentException("This API can only be used if the AST is created from a compilation unit or class file");
/*     */     }
/* 284 */     CompilationUnit astRoot = (CompilationUnit)root;
/* 285 */     ITypeRoot typeRoot = astRoot.getTypeRoot();
/* 286 */     if (typeRoot == null || typeRoot.getBuffer() == null) {
/* 287 */       throw new IllegalArgumentException("This API can only be used if the AST is created from a compilation unit or class file");
/*     */     }
/*     */     
/* 290 */     char[] content = typeRoot.getBuffer().getCharacters();
/* 291 */     LineInformation lineInfo = LineInformation.create(astRoot);
/* 292 */     String lineDelim = typeRoot.findRecommendedLineSeparator();
/* 293 */     Map options = (typeRoot instanceof ICompilationUnit) ? ((ICompilationUnit)typeRoot).getOptions(true) : 
/* 294 */       typeRoot.getJavaProject().getOptions(true);
/*     */     
/* 296 */     return internalRewriteAST(content, lineInfo, lineDelim, astRoot.getCommentList(), options, rootNode, (RecoveryScannerData)astRoot.getStatementsRecoveryData());
/*     */   }
/*     */   
/*     */   private TextEdit internalRewriteAST(char[] content, LineInformation lineInfo, String lineDelim, List commentNodes, Map options, ASTNode rootNode, RecoveryScannerData recoveryScannerData) {
/* 300 */     MultiTextEdit multiTextEdit = new MultiTextEdit();
/*     */ 
/*     */     
/* 303 */     TargetSourceRangeComputer sourceRangeComputer = getExtendedSourceRangeComputer();
/* 304 */     this.eventStore.prepareMovedNodes(sourceRangeComputer);
/*     */     
/* 306 */     ASTRewriteAnalyzer visitor = new ASTRewriteAnalyzer(content, lineInfo, lineDelim, (TextEdit)multiTextEdit, this.eventStore, this.nodeStore, commentNodes, options, sourceRangeComputer, recoveryScannerData);
/* 307 */     rootNode.accept((ASTVisitor)visitor);
/*     */     
/* 309 */     this.eventStore.revertMovedNodes();
/* 310 */     return (TextEdit)multiTextEdit;
/*     */   }
/*     */   
/*     */   private ASTNode getRootNode() {
/* 314 */     ASTNode node = null;
/* 315 */     int start = -1;
/* 316 */     int end = -1;
/*     */     
/* 318 */     for (Iterator<ASTNode> iter = getRewriteEventStore().getChangeRootIterator(); iter.hasNext(); ) {
/* 319 */       ASTNode curr = iter.next();
/* 320 */       if (!RewriteEventStore.isNewNode(curr)) {
/* 321 */         int currStart = curr.getStartPosition();
/* 322 */         int currEnd = currStart + curr.getLength();
/* 323 */         if (node == null || (currStart < start && currEnd > end)) {
/* 324 */           start = currStart;
/* 325 */           end = currEnd;
/* 326 */           node = curr; continue;
/* 327 */         }  if (currStart < start) {
/* 328 */           start = currStart; continue;
/* 329 */         }  if (currEnd > end) {
/* 330 */           end = currEnd;
/*     */         }
/*     */       } 
/*     */     } 
/* 334 */     if (node != null) {
/* 335 */       int currStart = node.getStartPosition();
/* 336 */       int currEnd = currStart + node.getLength();
/* 337 */       while (start < currStart || end > currEnd) {
/* 338 */         node = node.getParent();
/* 339 */         currStart = node.getStartPosition();
/* 340 */         currEnd = currStart + node.getLength();
/*     */       } 
/* 342 */       ASTNode parent = node.getParent();
/* 343 */       while (parent != null && parent.getStartPosition() == node.getStartPosition() && parent.getLength() == node.getLength()) {
/* 344 */         node = parent;
/* 345 */         parent = node.getParent();
/*     */       } 
/*     */     } 
/* 348 */     return node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void remove(ASTNode node, TextEditGroup editGroup) {
/*     */     StructuralPropertyDescriptor property;
/*     */     ASTNode parent;
/* 379 */     if (node == null) {
/* 380 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 385 */     if (RewriteEventStore.isNewNode(node)) {
/* 386 */       RewriteEventStore.PropertyLocation location = this.eventStore.getPropertyLocation(node, 1);
/* 387 */       if (location != null) {
/* 388 */         property = location.getProperty();
/* 389 */         parent = location.getParent();
/*     */       } else {
/* 391 */         throw new IllegalArgumentException("Node is not part of the rewriter's AST");
/*     */       } 
/*     */     } else {
/* 394 */       property = node.getLocationInParent();
/* 395 */       parent = node.getParent();
/*     */     } 
/*     */     
/* 398 */     if (property.isChildListProperty()) {
/* 399 */       getListRewrite(parent, (ChildListPropertyDescriptor)property).remove(node, editGroup);
/*     */     } else {
/* 401 */       set(parent, property, null, editGroup);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void replace(ASTNode node, ASTNode replacement, TextEditGroup editGroup) {
/*     */     StructuralPropertyDescriptor property;
/*     */     ASTNode parent;
/* 424 */     if (node == null) {
/* 425 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 430 */     if (RewriteEventStore.isNewNode(node)) {
/* 431 */       RewriteEventStore.PropertyLocation location = this.eventStore.getPropertyLocation(node, 1);
/* 432 */       if (location != null) {
/* 433 */         property = location.getProperty();
/* 434 */         parent = location.getParent();
/*     */       } else {
/* 436 */         throw new IllegalArgumentException("Node is not part of the rewriter's AST");
/*     */       } 
/*     */     } else {
/* 439 */       property = node.getLocationInParent();
/* 440 */       parent = node.getParent();
/*     */     } 
/*     */     
/* 443 */     if (property.isChildListProperty()) {
/* 444 */       getListRewrite(parent, (ChildListPropertyDescriptor)property).replace(node, replacement, editGroup);
/*     */     } else {
/* 446 */       set(parent, property, replacement, editGroup);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void set(ASTNode node, StructuralPropertyDescriptor property, Object value, TextEditGroup editGroup) {
/* 472 */     if (node == null || property == null) {
/* 473 */       throw new IllegalArgumentException();
/*     */     }
/* 475 */     validateIsCorrectAST(node);
/* 476 */     validatePropertyType(property, value);
/* 477 */     validateIsPropertyOfNode(property, node);
/*     */     
/* 479 */     NodeRewriteEvent nodeEvent = this.eventStore.getNodeEvent(node, property, true);
/* 480 */     nodeEvent.setNewValue(value);
/* 481 */     if (editGroup != null) {
/* 482 */       this.eventStore.setEventEditGroup((RewriteEvent)nodeEvent, editGroup);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(ASTNode node, StructuralPropertyDescriptor property) {
/* 501 */     if (node == null || property == null) {
/* 502 */       throw new IllegalArgumentException();
/*     */     }
/* 504 */     if (property.isChildListProperty()) {
/* 505 */       throw new IllegalArgumentException("Use the list rewriter to access nodes in a list");
/*     */     }
/* 507 */     return this.eventStore.getNewValue(node, property);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ListRewrite getListRewrite(ASTNode node, ChildListPropertyDescriptor property) {
/* 522 */     if (node == null || property == null) {
/* 523 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 526 */     validateIsCorrectAST(node);
/* 527 */     validateIsListProperty((StructuralPropertyDescriptor)property);
/* 528 */     validateIsPropertyOfNode((StructuralPropertyDescriptor)property, node);
/*     */     
/* 530 */     return new ListRewrite(this, node, property);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getProperty(String propertyName) {
/* 543 */     if (propertyName == null) {
/* 544 */       throw new IllegalArgumentException();
/*     */     }
/* 546 */     if (this.property1 == null)
/*     */     {
/* 548 */       return null;
/*     */     }
/* 550 */     if (this.property1 instanceof String) {
/*     */       
/* 552 */       if (propertyName.equals(this.property1)) {
/* 553 */         return this.property2;
/*     */       }
/* 555 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 559 */     Map m = (Map)this.property1;
/* 560 */     return m.get(propertyName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ITrackedNodePosition track(ASTNode node) {
/* 577 */     if (node == null) {
/* 578 */       throw new IllegalArgumentException();
/*     */     }
/* 580 */     TextEditGroup group = this.eventStore.getTrackedNodeData(node);
/* 581 */     if (group == null) {
/* 582 */       group = new TextEditGroup("internal");
/* 583 */       this.eventStore.setTrackedNodeData(node, group);
/*     */     } 
/* 585 */     return (ITrackedNodePosition)new TrackedNodePosition(group, node);
/*     */   }
/*     */   
/*     */   private void validateIsExistingNode(ASTNode node) {
/* 589 */     if (node.getStartPosition() == -1) {
/* 590 */       throw new IllegalArgumentException("Node is not an existing node");
/*     */     }
/*     */   }
/*     */   
/*     */   private void validateIsCorrectAST(ASTNode node) {
/* 595 */     if (node.getAST() != getAST()) {
/* 596 */       throw new IllegalArgumentException("Node is not inside the AST");
/*     */     }
/*     */   }
/*     */   
/*     */   private void validateIsListProperty(StructuralPropertyDescriptor property) {
/* 601 */     if (!property.isChildListProperty()) {
/* 602 */       String message = String.valueOf(property.getId()) + " is not a list property";
/* 603 */       throw new IllegalArgumentException(message);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void validateIsPropertyOfNode(StructuralPropertyDescriptor property, ASTNode node) {
/* 608 */     if (!property.getNodeClass().isInstance(node)) {
/* 609 */       String message = String.valueOf(property.getId()) + " is not a property of type " + node.getClass().getName();
/* 610 */       throw new IllegalArgumentException(message);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void validatePropertyType(StructuralPropertyDescriptor prop, Object value) {
/* 615 */     if (prop.isChildListProperty()) {
/* 616 */       String message = "Can not modify a list property, use getListRewrite()";
/* 617 */       throw new IllegalArgumentException(message);
/*     */     } 
/* 619 */     if (!RewriteEventStore.DEBUG) {
/*     */       return;
/*     */     }
/*     */     
/* 623 */     if (value == null) {
/* 624 */       if ((prop.isSimpleProperty() && ((SimplePropertyDescriptor)prop).isMandatory()) || (
/* 625 */         prop.isChildProperty() && ((ChildPropertyDescriptor)prop).isMandatory())) {
/* 626 */         String message = "Can not remove property " + prop.getId();
/* 627 */         throw new IllegalArgumentException(message);
/*     */       } 
/*     */     } else {
/*     */       Class valueType;
/*     */       
/* 632 */       if (prop.isSimpleProperty()) {
/* 633 */         SimplePropertyDescriptor p = (SimplePropertyDescriptor)prop;
/* 634 */         Class<int> clazz = p.getValueType();
/* 635 */         if (clazz == int.class) {
/* 636 */           valueType = Integer.class;
/* 637 */         } else if (valueType == boolean.class) {
/* 638 */           Class<Boolean> clazz1 = Boolean.class;
/*     */         } 
/*     */       } else {
/* 641 */         ChildPropertyDescriptor p = (ChildPropertyDescriptor)prop;
/* 642 */         valueType = p.getChildType();
/*     */       } 
/* 644 */       if (!valueType.isAssignableFrom(value.getClass())) {
/* 645 */         String message = String.valueOf(value.getClass().getName()) + " is not a valid type for " + prop.getNodeClass().getName() + 
/* 646 */           " property '" + prop.getId() + '\'';
/* 647 */         throw new IllegalArgumentException(message);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ASTNode createStringPlaceholder(String code, int nodeType) {
/* 666 */     if (code == null) {
/* 667 */       throw new IllegalArgumentException();
/*     */     }
/* 669 */     ASTNode placeholder = getNodeStore().newPlaceholderNode(nodeType);
/* 670 */     if (placeholder == null) {
/* 671 */       throw new IllegalArgumentException("String placeholder is not supported for type" + nodeType);
/*     */     }
/*     */     
/* 674 */     getNodeStore().markAsStringPlaceholder(placeholder, code);
/* 675 */     return placeholder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ASTNode createGroupNode(ASTNode[] targetNodes) {
/* 695 */     if (targetNodes == null || targetNodes.length == 0) {
/* 696 */       throw new IllegalArgumentException();
/*     */     }
/* 698 */     Block res = getNodeStore().createCollapsePlaceholder();
/* 699 */     ListRewrite listRewrite = getListRewrite((ASTNode)res, Block.STATEMENTS_PROPERTY);
/* 700 */     for (int i = 0; i < targetNodes.length; i++) {
/* 701 */       listRewrite.insertLast(targetNodes[i], null);
/*     */     }
/* 703 */     return (ASTNode)res;
/*     */   }
/*     */ 
/*     */   
/*     */   private ASTNode createTargetNode(ASTNode node, boolean isMove) {
/* 708 */     if (node == null) {
/* 709 */       throw new IllegalArgumentException();
/*     */     }
/* 711 */     validateIsExistingNode(node);
/* 712 */     validateIsCorrectAST(node);
/* 713 */     RewriteEventStore.CopySourceInfo info = getRewriteEventStore().markAsCopySource(node.getParent(), node.getLocationInParent(), node, isMove);
/*     */     
/* 715 */     ASTNode placeholder = getNodeStore().newPlaceholderNode(node.getNodeType());
/* 716 */     if (placeholder == null) {
/* 717 */       throw new IllegalArgumentException("Creating a target node is not supported for nodes of type" + node.getClass().getName());
/*     */     }
/* 719 */     getNodeStore().markAsCopyTarget(placeholder, info);
/*     */     
/* 721 */     return placeholder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ASTNode createCopyTarget(ASTNode node) {
/* 737 */     return createTargetNode(node, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ASTNode createMoveTarget(ASTNode node) {
/* 755 */     return createTargetNode(node, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final TargetSourceRangeComputer getExtendedSourceRangeComputer() {
/* 767 */     if (this.targetSourceRangeComputer == null)
/*     */     {
/* 769 */       this.targetSourceRangeComputer = new TargetSourceRangeComputer();
/*     */     }
/* 771 */     return this.targetSourceRangeComputer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setProperty(String propertyName, Object data) {
/* 796 */     if (propertyName == null) {
/* 797 */       throw new IllegalArgumentException();
/*     */     }
/* 799 */     if (this.property1 == null) {
/*     */       
/* 801 */       if (data == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 806 */       this.property1 = propertyName;
/* 807 */       this.property2 = data;
/*     */       return;
/*     */     } 
/* 810 */     if (this.property1 instanceof String) {
/*     */       
/* 812 */       if (propertyName.equals(this.property1)) {
/*     */         
/* 814 */         if (data == null) {
/*     */           
/* 816 */           this.property1 = null;
/* 817 */           this.property2 = null;
/*     */         } else {
/* 819 */           this.property2 = data;
/*     */         } 
/*     */         return;
/*     */       } 
/* 823 */       if (data == null) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 829 */       Map<Object, Object> map = new HashMap<>(3);
/* 830 */       map.put(this.property1, this.property2);
/* 831 */       map.put(propertyName, data);
/* 832 */       this.property1 = map;
/* 833 */       this.property2 = null;
/*     */       
/*     */       return;
/*     */     } 
/* 837 */     Map<String, Object> m = (Map)this.property1;
/* 838 */     if (data == null) {
/* 839 */       m.remove(propertyName);
/*     */       
/* 841 */       if (m.size() == 1) {
/*     */         
/* 843 */         Map.Entry[] entries = (Map.Entry[])m.entrySet().toArray((Object[])new Map.Entry[1]);
/* 844 */         this.property1 = entries[0].getKey();
/* 845 */         this.property2 = entries[0].getValue();
/*     */       } 
/*     */       return;
/*     */     } 
/* 849 */     m.put(propertyName, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setTargetSourceRangeComputer(TargetSourceRangeComputer computer) {
/* 867 */     this.targetSourceRangeComputer = computer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 877 */     StringBuilder buf = new StringBuilder();
/* 878 */     buf.append("Events:\n");
/*     */     
/* 880 */     if (this.eventStore != null) {
/* 881 */       buf.append(this.eventStore.toString());
/*     */     }
/* 883 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\rewrite\ASTRewrite.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */