/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AssertStatement
/*     */   extends Statement
/*     */ {
/*  39 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(AssertStatement.class, "expression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final ChildPropertyDescriptor MESSAGE_PROPERTY = new ChildPropertyDescriptor(AssertStatement.class, "message", Expression.class, false, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  56 */     List properyList = new ArrayList(3);
/*  57 */     createPropertyList(AssertStatement.class, properyList);
/*  58 */     addProperty(EXPRESSION_PROPERTY, properyList);
/*  59 */     addProperty(MESSAGE_PROPERTY, properyList);
/*  60 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  75 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private Expression expression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private Expression optionalMessageExpression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AssertStatement(AST ast) {
/* 100 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 105 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 110 */     if (property == EXPRESSION_PROPERTY) {
/* 111 */       if (get) {
/* 112 */         return getExpression();
/*     */       }
/* 114 */       setExpression((Expression)child);
/* 115 */       return null;
/*     */     } 
/*     */     
/* 118 */     if (property == MESSAGE_PROPERTY) {
/* 119 */       if (get) {
/* 120 */         return getMessage();
/*     */       }
/* 122 */       setMessage((Expression)child);
/* 123 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 127 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 132 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 137 */     AssertStatement result = new AssertStatement(target);
/* 138 */     result.setSourceRange(getStartPosition(), getLength());
/* 139 */     result.copyLeadingComment(this);
/* 140 */     result.setExpression(
/* 141 */         (Expression)ASTNode.copySubtree(target, getExpression()));
/* 142 */     result.setMessage(
/* 143 */         (Expression)ASTNode.copySubtree(target, getMessage()));
/* 144 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 150 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 155 */     boolean visitChildren = visitor.visit(this);
/* 156 */     if (visitChildren) {
/*     */       
/* 158 */       acceptChild(visitor, getExpression());
/* 159 */       acceptChild(visitor, getMessage());
/*     */     } 
/* 161 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 170 */     if (this.expression == null)
/*     */     {
/* 172 */       synchronized (this) {
/* 173 */         if (this.expression == null) {
/* 174 */           preLazyInit();
/* 175 */           this.expression = new SimpleName(this.ast);
/* 176 */           postLazyInit(this.expression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 180 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 195 */     if (expression == null) {
/* 196 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 199 */     ASTNode oldChild = this.expression;
/* 200 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 201 */     this.expression = expression;
/* 202 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getMessage() {
/* 213 */     return this.optionalMessageExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessage(Expression expression) {
/* 230 */     ASTNode oldChild = this.optionalMessageExpression;
/* 231 */     preReplaceChild(oldChild, expression, MESSAGE_PROPERTY);
/* 232 */     this.optionalMessageExpression = expression;
/* 233 */     postReplaceChild(oldChild, expression, MESSAGE_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 238 */     return super.memSize() + 8;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 243 */     return 
/* 244 */       memSize() + (
/* 245 */       (this.expression == null) ? 0 : getExpression().treeSize()) + (
/* 246 */       (this.optionalMessageExpression == null) ? 0 : getMessage().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\AssertStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */