/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.ExportsStatement;
/*    */ import org.eclipse.jdt.internal.compiler.ast.ImportReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnKeywordModuleInfo
/*    */   extends ExportsStatement
/*    */   implements CompletionOnKeyword
/*    */ {
/*    */   private char[] token;
/*    */   private char[][] possibleKeywords;
/*    */   
/*    */   public CompletionOnKeywordModuleInfo(char[] token, long pos, char[][] possibleKeywords) {
/* 31 */     super(new ImportReference(new char[][] { token }, new long[] { pos }, false, 0), null);
/* 32 */     this.token = token;
/* 33 */     this.possibleKeywords = possibleKeywords;
/* 34 */     this.sourceStart = (int)(pos >>> 32L);
/* 35 */     this.sourceEnd = (int)(pos & 0xFFFFFFFFL);
/*    */   }
/*    */ 
/*    */   
/*    */   public char[] getToken() {
/* 40 */     return this.token;
/*    */   }
/*    */ 
/*    */   
/*    */   public char[][] getPossibleKeywords() {
/* 45 */     return this.possibleKeywords;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnKeywordModuleInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */