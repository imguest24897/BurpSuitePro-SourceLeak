/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IfStatement
/*     */   extends Statement
/*     */ {
/*  38 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(IfStatement.class, "expression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public static final ChildPropertyDescriptor THEN_STATEMENT_PROPERTY = new ChildPropertyDescriptor(IfStatement.class, "thenStatement", Statement.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public static final ChildPropertyDescriptor ELSE_STATEMENT_PROPERTY = new ChildPropertyDescriptor(IfStatement.class, "elseStatement", Statement.class, false, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  62 */     List properyList = new ArrayList(4);
/*  63 */     createPropertyList(IfStatement.class, properyList);
/*  64 */     addProperty(EXPRESSION_PROPERTY, properyList);
/*  65 */     addProperty(THEN_STATEMENT_PROPERTY, properyList);
/*  66 */     addProperty(ELSE_STATEMENT_PROPERTY, properyList);
/*  67 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  82 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   private Expression expression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   private Statement thenStatement = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private Statement optionalElseStatement = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IfStatement(AST ast) {
/* 114 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 119 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 124 */     if (property == EXPRESSION_PROPERTY) {
/* 125 */       if (get) {
/* 126 */         return getExpression();
/*     */       }
/* 128 */       setExpression((Expression)child);
/* 129 */       return null;
/*     */     } 
/*     */     
/* 132 */     if (property == THEN_STATEMENT_PROPERTY) {
/* 133 */       if (get) {
/* 134 */         return getThenStatement();
/*     */       }
/* 136 */       setThenStatement((Statement)child);
/* 137 */       return null;
/*     */     } 
/*     */     
/* 140 */     if (property == ELSE_STATEMENT_PROPERTY) {
/* 141 */       if (get) {
/* 142 */         return getElseStatement();
/*     */       }
/* 144 */       setElseStatement((Statement)child);
/* 145 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 149 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 154 */     return 25;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 159 */     IfStatement result = new IfStatement(target);
/* 160 */     result.setSourceRange(getStartPosition(), getLength());
/* 161 */     result.copyLeadingComment(this);
/* 162 */     result.setExpression((Expression)getExpression().clone(target));
/* 163 */     result.setThenStatement(
/* 164 */         (Statement)getThenStatement().clone(target));
/* 165 */     result.setElseStatement(
/* 166 */         (Statement)ASTNode.copySubtree(target, getElseStatement()));
/* 167 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 173 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 178 */     boolean visitChildren = visitor.visit(this);
/* 179 */     if (visitChildren) {
/*     */       
/* 181 */       acceptChild(visitor, getExpression());
/* 182 */       acceptChild(visitor, getThenStatement());
/* 183 */       acceptChild(visitor, getElseStatement());
/*     */     } 
/* 185 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 194 */     if (this.expression == null)
/*     */     {
/* 196 */       synchronized (this) {
/* 197 */         if (this.expression == null) {
/* 198 */           preLazyInit();
/* 199 */           this.expression = new SimpleName(this.ast);
/* 200 */           postLazyInit(this.expression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 204 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 219 */     if (expression == null) {
/* 220 */       throw new IllegalArgumentException();
/*     */     }
/* 222 */     ASTNode oldChild = this.expression;
/* 223 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 224 */     this.expression = expression;
/* 225 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement getThenStatement() {
/* 234 */     if (this.thenStatement == null)
/*     */     {
/* 236 */       synchronized (this) {
/* 237 */         if (this.thenStatement == null) {
/* 238 */           preLazyInit();
/* 239 */           this.thenStatement = new Block(this.ast);
/* 240 */           postLazyInit(this.thenStatement, THEN_STATEMENT_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 244 */     return this.thenStatement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setThenStatement(Statement statement) {
/* 267 */     if (statement == null) {
/* 268 */       throw new IllegalArgumentException();
/*     */     }
/* 270 */     ASTNode oldChild = this.thenStatement;
/* 271 */     preReplaceChild(oldChild, statement, THEN_STATEMENT_PROPERTY);
/* 272 */     this.thenStatement = statement;
/* 273 */     postReplaceChild(oldChild, statement, THEN_STATEMENT_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement getElseStatement() {
/* 287 */     return this.optionalElseStatement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setElseStatement(Statement statement) {
/* 316 */     ASTNode oldChild = this.optionalElseStatement;
/* 317 */     preReplaceChild(oldChild, statement, ELSE_STATEMENT_PROPERTY);
/* 318 */     this.optionalElseStatement = statement;
/* 319 */     postReplaceChild(oldChild, statement, ELSE_STATEMENT_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 324 */     return super.memSize() + 12;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 329 */     return 
/* 330 */       memSize() + (
/* 331 */       (this.expression == null) ? 0 : getExpression().treeSize()) + (
/* 332 */       (this.thenStatement == null) ? 0 : getThenStatement().treeSize()) + (
/* 333 */       (this.optionalElseStatement == null) ? 0 : getElseStatement().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\IfStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */