/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayCreation
/*     */   extends Expression
/*     */ {
/*  50 */   public static final ChildPropertyDescriptor TYPE_PROPERTY = new ChildPropertyDescriptor(ArrayCreation.class, "type", ArrayType.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public static final ChildListPropertyDescriptor DIMENSIONS_PROPERTY = new ChildListPropertyDescriptor(ArrayCreation.class, "dimensions", Expression.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public static final ChildPropertyDescriptor INITIALIZER_PROPERTY = new ChildPropertyDescriptor(ArrayCreation.class, "initializer", ArrayInitializer.class, false, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  74 */     List properyList = new ArrayList(4);
/*  75 */     createPropertyList(ArrayCreation.class, properyList);
/*  76 */     addProperty(TYPE_PROPERTY, properyList);
/*  77 */     addProperty(DIMENSIONS_PROPERTY, properyList);
/*  78 */     addProperty(INITIALIZER_PROPERTY, properyList);
/*  79 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  94 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   private ArrayType arrayType = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   private ASTNode.NodeList dimensions = new ASTNode.NodeList(this, DIMENSIONS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   private ArrayInitializer optionalInitializer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ArrayCreation(AST ast) {
/* 125 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 130 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 135 */     if (property == INITIALIZER_PROPERTY) {
/* 136 */       if (get) {
/* 137 */         return getInitializer();
/*     */       }
/* 139 */       setInitializer((ArrayInitializer)child);
/* 140 */       return null;
/*     */     } 
/*     */     
/* 143 */     if (property == TYPE_PROPERTY) {
/* 144 */       if (get) {
/* 145 */         return getType();
/*     */       }
/* 147 */       setType((ArrayType)child);
/* 148 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 152 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 157 */     if (property == DIMENSIONS_PROPERTY) {
/* 158 */       return dimensions();
/*     */     }
/*     */     
/* 161 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 166 */     return 3;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 171 */     ArrayCreation result = new ArrayCreation(target);
/* 172 */     result.setSourceRange(getStartPosition(), getLength());
/* 173 */     result.setType((ArrayType)getType().clone(target));
/* 174 */     result.dimensions().addAll(ASTNode.copySubtrees(target, dimensions()));
/* 175 */     result.setInitializer(
/* 176 */         (ArrayInitializer)ASTNode.copySubtree(target, getInitializer()));
/* 177 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 183 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 188 */     boolean visitChildren = visitor.visit(this);
/* 189 */     if (visitChildren) {
/*     */       
/* 191 */       acceptChild(visitor, getType());
/* 192 */       acceptChildren(visitor, this.dimensions);
/* 193 */       acceptChild(visitor, getInitializer());
/*     */     } 
/* 195 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayType getType() {
/* 204 */     if (this.arrayType == null)
/*     */     {
/* 206 */       synchronized (this) {
/* 207 */         if (this.arrayType == null) {
/* 208 */           preLazyInit();
/* 209 */           this.arrayType = this.ast.newArrayType(
/* 210 */               this.ast.newPrimitiveType(PrimitiveType.INT));
/* 211 */           postLazyInit(this.arrayType, TYPE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 215 */     return this.arrayType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(ArrayType type) {
/* 229 */     if (type == null) {
/* 230 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 233 */     ASTNode oldChild = this.arrayType;
/* 234 */     preReplaceChild(oldChild, type, TYPE_PROPERTY);
/* 235 */     this.arrayType = type;
/* 236 */     postReplaceChild(oldChild, type, TYPE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List dimensions() {
/* 247 */     return this.dimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayInitializer getInitializer() {
/* 258 */     return this.optionalInitializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInitializer(ArrayInitializer initializer) {
/* 276 */     ASTNode oldChild = this.optionalInitializer;
/* 277 */     preReplaceChild(oldChild, initializer, INITIALIZER_PROPERTY);
/* 278 */     this.optionalInitializer = initializer;
/* 279 */     postReplaceChild(oldChild, initializer, INITIALIZER_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 284 */     return 52;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 289 */     int size = memSize() + (
/* 290 */       (this.arrayType == null) ? 0 : getType().treeSize()) + (
/* 291 */       (this.optionalInitializer == null) ? 0 : getInitializer().treeSize()) + 
/* 292 */       this.dimensions.listSize();
/* 293 */     return size;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ArrayCreation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */