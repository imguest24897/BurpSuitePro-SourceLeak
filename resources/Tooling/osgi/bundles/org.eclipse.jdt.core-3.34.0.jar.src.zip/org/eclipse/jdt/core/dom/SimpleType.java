/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleType
/*     */   extends AnnotatableType
/*     */ {
/*  51 */   public static final ChildListPropertyDescriptor ANNOTATIONS_PROPERTY = internalAnnotationsPropertyFactory(SimpleType.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(SimpleType.class, "name", Name.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_8_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  75 */     List propertyList = new ArrayList(2);
/*  76 */     createPropertyList(SimpleType.class, propertyList);
/*  77 */     addProperty(NAME_PROPERTY, propertyList);
/*  78 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */     
/*  80 */     propertyList = new ArrayList(3);
/*  81 */     createPropertyList(SimpleType.class, propertyList);
/*  82 */     addProperty(ANNOTATIONS_PROPERTY, propertyList);
/*  83 */     addProperty(NAME_PROPERTY, propertyList);
/*  84 */     PROPERTY_DESCRIPTORS_8_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  98 */     switch (apiLevel) {
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/* 102 */         return PROPERTY_DESCRIPTORS;
/*     */     } 
/* 104 */     return PROPERTY_DESCRIPTORS_8_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   private Name typeName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SimpleType(AST ast) {
/* 124 */     super(ast);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalAnnotationsProperty() {
/* 133 */     return ANNOTATIONS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 138 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 143 */     if (property == ANNOTATIONS_PROPERTY) {
/* 144 */       return annotations();
/*     */     }
/*     */     
/* 147 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 152 */     if (property == NAME_PROPERTY) {
/* 153 */       if (get) {
/* 154 */         return getName();
/*     */       }
/* 156 */       setName((Name)child);
/* 157 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 161 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 166 */     return 43;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 171 */     SimpleType result = new SimpleType(target);
/* 172 */     result.setSourceRange(getStartPosition(), getLength());
/* 173 */     if (this.ast.apiLevel >= 8) {
/* 174 */       result.annotations().addAll(
/* 175 */           ASTNode.copySubtrees(target, annotations()));
/*     */     }
/* 177 */     result.setName((Name)getName().clone(target));
/* 178 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 184 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 189 */     boolean visitChildren = visitor.visit(this);
/* 190 */     if (visitChildren) {
/*     */       
/* 192 */       if (this.ast.apiLevel >= 8) {
/* 193 */         acceptChildren(visitor, this.annotations);
/*     */       }
/* 195 */       acceptChild(visitor, getName());
/*     */     } 
/* 197 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getName() {
/* 206 */     if (this.typeName == null)
/*     */     {
/* 208 */       synchronized (this) {
/* 209 */         if (this.typeName == null) {
/* 210 */           preLazyInit();
/* 211 */           this.typeName = new SimpleName(this.ast);
/* 212 */           postLazyInit(this.typeName, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 216 */     return this.typeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(Name typeName) {
/* 230 */     if (typeName == null) {
/* 231 */       throw new IllegalArgumentException();
/*     */     }
/* 233 */     ASTNode oldChild = this.typeName;
/* 234 */     preReplaceChild(oldChild, typeName, NAME_PROPERTY);
/* 235 */     this.typeName = typeName;
/* 236 */     postReplaceChild(oldChild, typeName, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVar() {
/* 245 */     unsupportedBelow10();
/* 246 */     if (Long.compare(this.ast.scanner.complianceLevel, 3538944L) < 0)
/* 247 */       return false; 
/* 248 */     if (this.typeName == null) getName(); 
/* 249 */     String qName = this.typeName.getFullyQualifiedName();
/* 250 */     return (qName != null && qName.equals("var"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 258 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 263 */     return 
/* 264 */       memSize() + (
/* 265 */       (this.annotations == null) ? 0 : this.annotations.listSize()) + (
/* 266 */       (this.typeName == null) ? 0 : getName().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\SimpleType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */