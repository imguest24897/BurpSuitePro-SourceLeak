/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.core.dom.util.DOMASTUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaDocRegion
/*     */   extends AbstractTagElement
/*     */ {
/*     */   JavaDocRegion(AST ast) {
/*  38 */     super(ast);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     this.tags = new ASTNode.NodeList(this, TAGS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     this.dummyRegion = Boolean.TRUE.booleanValue();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     this.validSnippet = Boolean.TRUE.booleanValue();
/*     */     unsupportedBelow18();
/*     */   }
/*     */   
/*     */   public static final SimplePropertyDescriptor TAG_NAME_PROPERTY = internalTagNamePropertyFactory(JavaDocRegion.class); public static final ChildListPropertyDescriptor FRAGMENTS_PROPERTY = internalFragmentsPropertyFactory(JavaDocRegion.class); public static final ChildListPropertyDescriptor TAGS_PROPERTY = new ChildListPropertyDescriptor(JavaDocRegion.class, "tags", TagElement.class, true); public static final SimplePropertyDescriptor DUMMY_REGION_PROPERTY = new SimplePropertyDescriptor(JavaDocRegion.class, "dummyRegion", boolean.class, true); public static final SimplePropertyDescriptor VALID_SNIPPET_PROPERTY = new SimplePropertyDescriptor(JavaDocRegion.class, "validSnippet", boolean.class, true);
/*     */   static final String REGION_ENDED = "Region Ended";
/*     */   
/* 114 */   List internalStructuralPropertiesForType(int apiLevel) { return propertyDescriptors(apiLevel); }
/*     */   static final String REGION_TO_BE_ENDED = "Region To Be Ended"; private static final List PROPERTY_DESCRIPTORS; private ASTNode.NodeList tags; private boolean dummyRegion; private boolean validSnippet; static { List propertyList = new ArrayList(6); createPropertyList(JavaDocRegion.class, propertyList); addProperty(TAG_NAME_PROPERTY, propertyList); addProperty(FRAGMENTS_PROPERTY, propertyList);
/*     */     addProperty(TAGS_PROPERTY, propertyList);
/*     */     addProperty(DUMMY_REGION_PROPERTY, propertyList);
/*     */     addProperty(VALID_SNIPPET_PROPERTY, propertyList);
/* 119 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList); } final boolean internalGetSetBooleanProperty(SimplePropertyDescriptor property, boolean get, boolean newValue) { if (property == DUMMY_REGION_PROPERTY) {
/* 120 */       if (get) {
/* 121 */         return isDummyRegion();
/*     */       }
/* 123 */       setDummyRegion(newValue);
/* 124 */       return false;
/*     */     } 
/* 126 */     if (property == VALID_SNIPPET_PROPERTY) {
/* 127 */       if (get) {
/* 128 */         return isValidSnippet();
/*     */       }
/* 130 */       setValidSnippet(newValue);
/* 131 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 135 */     return super.internalGetSetBooleanProperty(property, get, newValue); }
/*     */ 
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 140 */     if (property == FRAGMENTS_PROPERTY)
/* 141 */       return fragments(); 
/* 142 */     if (property == TAGS_PROPERTY) {
/* 143 */       return tags();
/*     */     }
/*     */     
/* 146 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   int getNodeType0() {
/* 151 */     return 111;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 156 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 162 */     JavaDocRegion result = new JavaDocRegion(target);
/* 163 */     result.setSourceRange(getStartPosition(), getLength());
/* 164 */     result.setTagName(getTagName());
/* 165 */     result.setDummyRegion(isDummyRegion());
/* 166 */     result.setValidSnippet(isValidSnippet());
/* 167 */     result.tags().addAll(
/* 168 */         ASTNode.copySubtrees(target, tags()));
/* 169 */     result.fragments().addAll(
/* 170 */         ASTNode.copySubtrees(target, fragments()));
/* 171 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 176 */     visitor.visit(this);
/* 177 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 183 */     return super.memSize() + 12;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 188 */     return memSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 203 */     if (DOMASTUtil.isJavaDocCodeSnippetSupported(apiLevel)) {
/* 204 */       return PROPERTY_DESCRIPTORS;
/*     */     }
/* 206 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List tags() {
/* 218 */     unsupportedBelow18();
/* 219 */     return this.tags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDummyRegion() {
/* 228 */     unsupportedBelow18();
/* 229 */     return this.dummyRegion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDummyRegion(boolean dummyRegion) {
/* 238 */     unsupportedBelow18();
/* 239 */     preValueChange(DUMMY_REGION_PROPERTY);
/* 240 */     this.dummyRegion = dummyRegion;
/* 241 */     postValueChange(DUMMY_REGION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValidSnippet() {
/* 250 */     unsupportedBelow18();
/* 251 */     return this.validSnippet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValidSnippet(boolean validSnippet) {
/* 260 */     unsupportedBelow18();
/* 261 */     preValueChange(VALID_SNIPPET_PROPERTY);
/* 262 */     this.validSnippet = validSnippet;
/* 263 */     postValueChange(VALID_SNIPPET_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   ChildListPropertyDescriptor internalFragmentsPropertyFactory() {
/* 268 */     return FRAGMENTS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   SimplePropertyDescriptor internalTagNamePropertyFactory() {
/* 273 */     return TAG_NAME_PROPERTY;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\JavaDocRegion.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */