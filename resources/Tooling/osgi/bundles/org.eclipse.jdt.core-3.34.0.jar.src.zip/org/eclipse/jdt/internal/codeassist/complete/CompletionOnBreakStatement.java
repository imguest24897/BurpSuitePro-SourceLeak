/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.BreakStatement;
/*    */ import org.eclipse.jdt.internal.compiler.flow.FlowContext;
/*    */ import org.eclipse.jdt.internal.compiler.flow.FlowInfo;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnBreakStatement
/*    */   extends BreakStatement
/*    */ {
/*    */   public char[][] possibleLabels;
/*    */   
/*    */   public CompletionOnBreakStatement(char[] l, int s, int e, char[][] possibleLabels) {
/* 26 */     super(l, s, e);
/* 27 */     this.possibleLabels = possibleLabels;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FlowInfo analyseCode(BlockScope currentScope, FlowContext flowContext, FlowInfo flowInfo) {
/* 34 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void resolve(BlockScope scope) {
/* 39 */     throw new CompletionNodeFound(this, scope);
/*    */   }
/*    */   
/*    */   public StringBuffer printStatement(int indent, StringBuffer output) {
/* 43 */     printIndent(indent, output);
/* 44 */     output.append("break ");
/* 45 */     output.append("<CompleteOnLabel:");
/* 46 */     output.append(this.label);
/* 47 */     return output.append(">;");
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnBreakStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */