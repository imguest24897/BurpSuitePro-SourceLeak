package org.eclipse.jdt.core.jdom;

public interface IDOMCompilationUnit extends IDOMNode {
  String getHeader();
  
  String getName();
  
  void setHeader(String paramString);
  
  void setName(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\jdom\IDOMCompilationUnit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */