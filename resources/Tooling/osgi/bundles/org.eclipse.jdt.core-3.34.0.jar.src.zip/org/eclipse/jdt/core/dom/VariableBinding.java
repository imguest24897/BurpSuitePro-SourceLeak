/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.impl.ReferenceContext;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LocalVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RecordComponentBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.core.JavaElement;
/*     */ import org.eclipse.jdt.internal.core.LocalVariable;
/*     */ import org.eclipse.jdt.internal.core.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class VariableBinding
/*     */   implements IVariableBinding
/*     */ {
/*     */   private static final int VALID_MODIFIERS = 223;
/*     */   private org.eclipse.jdt.internal.compiler.lookup.VariableBinding binding;
/*     */   private ITypeBinding declaringClass;
/*     */   private String key;
/*     */   private String name;
/*     */   private BindingResolver resolver;
/*     */   private ITypeBinding type;
/*     */   private IAnnotationBinding[] annotations;
/*     */   
/*     */   VariableBinding(BindingResolver resolver, org.eclipse.jdt.internal.compiler.lookup.VariableBinding binding) {
/*  53 */     this.resolver = resolver;
/*  54 */     this.binding = binding;
/*     */   }
/*     */ 
/*     */   
/*     */   public IAnnotationBinding[] getAnnotations() {
/*  59 */     if (this.annotations != null) {
/*  60 */       return this.annotations;
/*     */     }
/*  62 */     AnnotationBinding[] internalAnnotations = this.binding.getAnnotations();
/*  63 */     int length = (internalAnnotations == null) ? 0 : internalAnnotations.length;
/*  64 */     if (length != 0) {
/*  65 */       IAnnotationBinding[] tempAnnotations = new IAnnotationBinding[length];
/*  66 */       int convertedAnnotationCount = 0;
/*  67 */       for (int i = 0; i < length; i++) {
/*  68 */         AnnotationBinding internalAnnotation = internalAnnotations[i];
/*  69 */         IAnnotationBinding annotationInstance = this.resolver.getAnnotationInstance(internalAnnotation);
/*  70 */         if (annotationInstance != null)
/*     */         {
/*     */           
/*  73 */           tempAnnotations[convertedAnnotationCount++] = annotationInstance; } 
/*     */       } 
/*  75 */       if (convertedAnnotationCount != length) {
/*  76 */         if (convertedAnnotationCount == 0) {
/*  77 */           return this.annotations = (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */         }
/*  79 */         System.arraycopy(tempAnnotations, 0, tempAnnotations = new IAnnotationBinding[convertedAnnotationCount], 0, convertedAnnotationCount);
/*     */       } 
/*  81 */       return this.annotations = tempAnnotations;
/*     */     } 
/*  83 */     return this.annotations = (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getConstantValue() {
/*  88 */     Constant c = this.binding.constant();
/*  89 */     if (c == null || c == Constant.NotAConstant) return null; 
/*  90 */     switch (c.typeID()) {
/*     */       case 5:
/*  92 */         return Boolean.valueOf(c.booleanValue());
/*     */       case 3:
/*  94 */         return Byte.valueOf(c.byteValue());
/*     */       case 2:
/*  96 */         return Character.valueOf(c.charValue());
/*     */       case 8:
/*  98 */         return Double.valueOf(c.doubleValue());
/*     */       case 9:
/* 100 */         return Float.valueOf(c.floatValue());
/*     */       case 10:
/* 102 */         return Integer.valueOf(c.intValue());
/*     */       case 7:
/* 104 */         return Long.valueOf(c.longValue());
/*     */       case 4:
/* 106 */         return Short.valueOf(c.shortValue());
/*     */       case 11:
/* 108 */         return c.stringValue();
/*     */     } 
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding getDeclaringClass() {
/* 115 */     if (isField()) {
/* 116 */       if (this.declaringClass == null) {
/* 117 */         FieldBinding fieldBinding = (FieldBinding)this.binding;
/* 118 */         this.declaringClass = this.resolver.getTypeBinding((TypeBinding)fieldBinding.declaringClass);
/*     */       } 
/* 120 */       return this.declaringClass;
/*     */     } 
/* 122 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IMethodBinding getDeclaringMethod() {
/* 128 */     if (!isField()) {
/* 129 */       ASTNode node = this.resolver.findDeclaringNode(this); while (true) {
/*     */         MethodDeclaration methodDeclaration; LambdaExpression lambdaExpression;
/* 131 */         if (node == null) {
/* 132 */           if (this.binding instanceof LocalVariableBinding) {
/* 133 */             LocalVariableBinding localVariableBinding = (LocalVariableBinding)this.binding;
/* 134 */             MethodBinding enclosingMethod = localVariableBinding.getEnclosingMethod();
/* 135 */             if (enclosingMethod != null)
/* 136 */               return this.resolver.getMethodBinding(enclosingMethod); 
/*     */           } 
/* 138 */           return null;
/*     */         } 
/* 140 */         switch (node.getNodeType()) {
/*     */           case 28:
/* 142 */             return null;
/*     */           case 31:
/* 144 */             methodDeclaration = (MethodDeclaration)node;
/* 145 */             return methodDeclaration.resolveBinding();
/*     */           case 86:
/* 147 */             lambdaExpression = (LambdaExpression)node;
/* 148 */             return lambdaExpression.resolveMethodBinding();
/*     */         } 
/* 150 */         node = node.getParent();
/*     */       } 
/*     */     } 
/*     */     
/* 154 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IJavaElement getJavaElement() {
/* 159 */     JavaElement element = getUnresolvedJavaElement();
/* 160 */     if (element == null)
/* 161 */       return null; 
/* 162 */     return (IJavaElement)element.resolved((Binding)this.binding);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 167 */     if (this.key == null) {
/* 168 */       this.key = new String(this.binding.computeUniqueKey());
/*     */     }
/* 170 */     return this.key;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getKind() {
/* 175 */     return 3;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 180 */     if (isField()) {
/* 181 */       return ((FieldBinding)this.binding).getAccessFlags() & 0xDF;
/*     */     }
/* 183 */     if (this.binding.isFinal()) {
/* 184 */       return 16;
/*     */     }
/* 186 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 191 */     if (this.name == null) {
/* 192 */       this.name = new String(this.binding.name);
/*     */     }
/* 194 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding getType() {
/* 199 */     if (this.type == null) {
/* 200 */       this.type = this.resolver.getTypeBinding(this.binding.type);
/*     */     }
/* 202 */     return this.type;
/*     */   }
/*     */   private JavaElement getUnresolvedJavaElement() {
/*     */     int sourceStart, sourceLength;
/* 206 */     if (JavaCore.getPlugin() == null) {
/* 207 */       return null;
/*     */     }
/* 209 */     if (isField()) {
/* 210 */       if (this.resolver instanceof DefaultBindingResolver) {
/* 211 */         DefaultBindingResolver defaultBindingResolver1 = (DefaultBindingResolver)this.resolver;
/* 212 */         if (!defaultBindingResolver1.fromJavaProject) return null; 
/* 213 */         return Util.getUnresolvedJavaElement(
/* 214 */             (FieldBinding)this.binding, 
/* 215 */             defaultBindingResolver1.workingCopyOwner, 
/* 216 */             defaultBindingResolver1.getBindingsToNodesMap());
/*     */       } 
/* 218 */       return null;
/* 219 */     }  if (isRecordComponent()) {
/* 220 */       if (this.resolver instanceof DefaultBindingResolver) {
/* 221 */         DefaultBindingResolver defaultBindingResolver1 = (DefaultBindingResolver)this.resolver;
/* 222 */         if (!defaultBindingResolver1.fromJavaProject) return null; 
/* 223 */         return Util.getUnresolvedJavaElement(
/* 224 */             (RecordComponentBinding)this.binding, 
/* 225 */             defaultBindingResolver1.workingCopyOwner, 
/* 226 */             defaultBindingResolver1.getBindingsToNodesMap());
/*     */       } 
/* 228 */       return null;
/*     */     } 
/*     */     
/* 231 */     if (!(this.resolver instanceof DefaultBindingResolver)) return null; 
/* 232 */     DefaultBindingResolver defaultBindingResolver = (DefaultBindingResolver)this.resolver;
/* 233 */     if (!defaultBindingResolver.fromJavaProject) return null; 
/* 234 */     VariableDeclaration localVar = (VariableDeclaration)defaultBindingResolver.bindingsToAstNodes.get(this);
/* 235 */     if (localVar == null) return null; 
/* 236 */     SimpleName localName = localVar.getName();
/* 237 */     int nameStart = localName.getStartPosition();
/* 238 */     int nameLength = localName.getLength();
/*     */ 
/*     */     
/* 241 */     int modifiers = 0;
/* 242 */     if (localVar instanceof SingleVariableDeclaration) {
/* 243 */       sourceStart = localVar.getStartPosition();
/* 244 */       sourceLength = localVar.getLength();
/* 245 */       SingleVariableDeclaration singleVariableDeclaration = (SingleVariableDeclaration)localVar;
/* 246 */       modifiers = singleVariableDeclaration.getModifiers();
/*     */     } else {
/* 248 */       VariableDeclarationExpression expression; VariableDeclarationStatement statement; FieldDeclaration fieldDeclaration; ASTNode node = localVar.getParent();
/* 249 */       sourceStart = node.getStartPosition();
/* 250 */       sourceLength = node.getLength();
/* 251 */       VariableDeclarationFragment fragment = (VariableDeclarationFragment)localVar;
/* 252 */       ASTNode aSTNode1 = fragment.getParent();
/* 253 */       switch (aSTNode1.getNodeType()) {
/*     */         case 58:
/* 255 */           expression = (VariableDeclarationExpression)aSTNode1;
/* 256 */           modifiers = expression.getModifiers();
/*     */           break;
/*     */         case 60:
/* 259 */           statement = (VariableDeclarationStatement)aSTNode1;
/* 260 */           modifiers = statement.getModifiers();
/*     */           break;
/*     */         case 23:
/* 263 */           fieldDeclaration = (FieldDeclaration)aSTNode1;
/* 264 */           modifiers = fieldDeclaration.getModifiers();
/*     */           break;
/*     */       } 
/*     */     } 
/* 268 */     int sourceEnd = sourceStart + sourceLength - 1;
/* 269 */     char[] typeSig = this.binding.type.genericTypeSignature();
/* 270 */     JavaElement parent = null;
/* 271 */     IMethodBinding declaringMethod = getDeclaringMethod();
/* 272 */     if (this.binding instanceof RecordComponentBinding) {
/* 273 */       return null;
/*     */     }
/* 275 */     LocalVariableBinding localVariableBinding = (LocalVariableBinding)this.binding;
/* 276 */     if (declaringMethod == null) {
/* 277 */       ReferenceContext referenceContext = localVariableBinding.declaringScope.referenceContext();
/* 278 */       if (referenceContext instanceof TypeDeclaration) {
/*     */         
/* 280 */         TypeDeclaration typeDeclaration = (TypeDeclaration)referenceContext;
/* 281 */         JavaElement typeHandle = null;
/* 282 */         typeHandle = Util.getUnresolvedJavaElement(
/* 283 */             (TypeBinding)typeDeclaration.binding, 
/* 284 */             defaultBindingResolver.workingCopyOwner, 
/* 285 */             defaultBindingResolver.getBindingsToNodesMap());
/* 286 */         parent = Util.getUnresolvedJavaElement(sourceStart, sourceEnd, typeHandle);
/*     */       } else {
/* 288 */         return null;
/*     */       } 
/*     */     } else {
/* 291 */       parent = (JavaElement)declaringMethod.getJavaElement();
/*     */     } 
/* 293 */     if (parent == null) return null; 
/* 294 */     return (JavaElement)new LocalVariable(
/* 295 */         parent, 
/* 296 */         localName.getIdentifier(), 
/* 297 */         sourceStart, 
/* 298 */         sourceEnd, 
/* 299 */         nameStart, 
/* 300 */         nameStart + nameLength - 1, 
/* 301 */         new String(typeSig), 
/* 302 */         localVariableBinding.declaration.annotations, 
/* 303 */         modifiers, 
/* 304 */         ((localVariableBinding.tagBits & 0x400L) != 0L));
/*     */   }
/*     */ 
/*     */   
/*     */   public IVariableBinding getVariableDeclaration() {
/* 309 */     if (isField()) {
/* 310 */       FieldBinding fieldBinding = (FieldBinding)this.binding;
/* 311 */       return this.resolver.getVariableBinding((org.eclipse.jdt.internal.compiler.lookup.VariableBinding)fieldBinding.original());
/*     */     } 
/* 313 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getVariableId() {
/* 318 */     return this.binding.id;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isParameter() {
/* 323 */     return ((this.binding.tagBits & 0x400L) != 0L);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDeprecated() {
/* 328 */     if (isField()) {
/* 329 */       return ((FieldBinding)this.binding).isDeprecated();
/*     */     }
/* 331 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnumConstant() {
/* 336 */     return ((this.binding.modifiers & 0x4000) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEqualTo(IBinding other) {
/* 341 */     if (other == this)
/*     */     {
/* 343 */       return true;
/*     */     }
/* 345 */     if (other == null)
/*     */     {
/* 347 */       return false;
/*     */     }
/* 349 */     if (!(other instanceof VariableBinding)) {
/* 350 */       return false;
/*     */     }
/* 352 */     org.eclipse.jdt.internal.compiler.lookup.VariableBinding otherBinding = ((VariableBinding)other).binding;
/* 353 */     if (this.binding instanceof FieldBinding) {
/* 354 */       if (otherBinding instanceof FieldBinding) {
/* 355 */         return BindingComparator.isEqual((FieldBinding)this.binding, (FieldBinding)otherBinding);
/*     */       }
/* 357 */       return false;
/*     */     } 
/*     */     
/* 360 */     if (BindingComparator.isEqual(this.binding, otherBinding)) {
/* 361 */       IMethodBinding declaringMethod = getDeclaringMethod();
/* 362 */       IMethodBinding otherDeclaringMethod = ((VariableBinding)other).getDeclaringMethod();
/* 363 */       if (declaringMethod == null) {
/* 364 */         if (otherDeclaringMethod != null) {
/* 365 */           return false;
/*     */         }
/* 367 */         return true;
/*     */       } 
/* 369 */       return declaringMethod.isEqualTo(otherDeclaringMethod);
/*     */     } 
/* 371 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isField() {
/* 377 */     return this.binding instanceof FieldBinding;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSynthetic() {
/* 382 */     if (isField()) {
/* 383 */       return ((FieldBinding)this.binding).isSynthetic();
/*     */     }
/* 385 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRecovered() {
/* 390 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEffectivelyFinal() {
/* 395 */     return (!this.binding.isFinal() && this.binding.isEffectivelyFinal());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRecordComponent() {
/* 400 */     return this.binding instanceof RecordComponentBinding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 409 */     return this.binding.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\VariableBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */