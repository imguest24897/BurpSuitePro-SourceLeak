/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CastExpression
/*     */   extends Expression
/*     */ {
/*  39 */   public static final ChildPropertyDescriptor TYPE_PROPERTY = new ChildPropertyDescriptor(CastExpression.class, "type", Type.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(CastExpression.class, "expression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  56 */     List properyList = new ArrayList(3);
/*  57 */     createPropertyList(CastExpression.class, properyList);
/*  58 */     addProperty(TYPE_PROPERTY, properyList);
/*  59 */     addProperty(EXPRESSION_PROPERTY, properyList);
/*  60 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  74 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private Type type = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private Expression expression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CastExpression(AST ast) {
/*  99 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 104 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 109 */     if (property == EXPRESSION_PROPERTY) {
/* 110 */       if (get) {
/* 111 */         return getExpression();
/*     */       }
/* 113 */       setExpression((Expression)child);
/* 114 */       return null;
/*     */     } 
/*     */     
/* 117 */     if (property == TYPE_PROPERTY) {
/* 118 */       if (get) {
/* 119 */         return getType();
/*     */       }
/* 121 */       setType((Type)child);
/* 122 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 126 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 131 */     return 11;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 136 */     CastExpression result = new CastExpression(target);
/* 137 */     result.setSourceRange(getStartPosition(), getLength());
/* 138 */     result.setType((Type)getType().clone(target));
/* 139 */     result.setExpression((Expression)getExpression().clone(target));
/* 140 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 146 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 151 */     boolean visitChildren = visitor.visit(this);
/* 152 */     if (visitChildren) {
/*     */       
/* 154 */       acceptChild(visitor, getType());
/* 155 */       acceptChild(visitor, getExpression());
/*     */     } 
/* 157 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 166 */     if (this.type == null)
/*     */     {
/* 168 */       synchronized (this) {
/* 169 */         if (this.type == null) {
/* 170 */           preLazyInit();
/* 171 */           this.type = this.ast.newPrimitiveType(PrimitiveType.INT);
/* 172 */           postLazyInit(this.type, TYPE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 176 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(Type type) {
/* 190 */     if (type == null) {
/* 191 */       throw new IllegalArgumentException();
/*     */     }
/* 193 */     ASTNode oldChild = this.type;
/* 194 */     preReplaceChild(oldChild, type, TYPE_PROPERTY);
/* 195 */     this.type = type;
/* 196 */     postReplaceChild(oldChild, type, TYPE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 205 */     if (this.expression == null)
/*     */     {
/* 207 */       synchronized (this) {
/* 208 */         if (this.expression == null) {
/* 209 */           preLazyInit();
/* 210 */           this.expression = new SimpleName(this.ast);
/* 211 */           postLazyInit(this.expression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 215 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 230 */     if (expression == null) {
/* 231 */       throw new IllegalArgumentException();
/*     */     }
/* 233 */     ASTNode oldChild = this.expression;
/* 234 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 235 */     this.expression = expression;
/* 236 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 242 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 247 */     return 
/* 248 */       memSize() + (
/* 249 */       (this.expression == null) ? 0 : getExpression().treeSize()) + (
/* 250 */       (this.type == null) ? 0 : getType().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\CastExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */