/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*    */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*    */ import org.eclipse.jdt.internal.compiler.ast.Annotation;
/*    */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnAnnotationOfType
/*    */   extends TypeDeclaration
/*    */ {
/*    */   public ASTNode potentialAnnotatedNode;
/*    */   public boolean isParameter;
/*    */   
/*    */   public CompletionOnAnnotationOfType(char[] typeName, CompilationResult compilationResult, Annotation annotation) {
/* 28 */     super(compilationResult);
/* 29 */     this.sourceEnd = annotation.sourceEnd;
/* 30 */     this.sourceStart = annotation.sourceEnd;
/* 31 */     this.name = typeName;
/* 32 */     this.annotations = new Annotation[] { annotation };
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer print(int indent, StringBuffer output) {
/* 37 */     return this.annotations[0].print(indent, output);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnAnnotationOfType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */