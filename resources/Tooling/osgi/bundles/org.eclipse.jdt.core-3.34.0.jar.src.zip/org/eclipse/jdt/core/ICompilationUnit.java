/*     */ package org.eclipse.jdt.core;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.jdt.core.dom.CompilationUnit;
/*     */ import org.eclipse.text.edits.TextEdit;
/*     */ import org.eclipse.text.edits.UndoEdit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ICompilationUnit
/*     */   extends ITypeRoot, IWorkingCopy, ISourceManipulation
/*     */ {
/*     */   public static final int NO_AST = 0;
/*     */   public static final int FORCE_PROBLEM_DETECTION = 1;
/*     */   public static final int ENABLE_STATEMENTS_RECOVERY = 2;
/*     */   public static final int ENABLE_BINDINGS_RECOVERY = 4;
/*     */   public static final int IGNORE_METHOD_BODIES = 8;
/*     */   
/*     */   UndoEdit applyTextEdit(TextEdit paramTextEdit, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
/*     */   
/*     */   void becomeWorkingCopy(IProblemRequestor paramIProblemRequestor, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
/*     */   
/*     */   void becomeWorkingCopy(IProgressMonitor paramIProgressMonitor) throws JavaModelException;
/*     */   
/*     */   void commitWorkingCopy(boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
/*     */   
/*     */   IImportDeclaration createImport(String paramString, IJavaElement paramIJavaElement, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
/*     */   
/*     */   IImportDeclaration createImport(String paramString, IJavaElement paramIJavaElement, int paramInt, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
/*     */   
/*     */   IPackageDeclaration createPackageDeclaration(String paramString, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
/*     */   
/*     */   IType createType(String paramString, IJavaElement paramIJavaElement, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
/*     */   
/*     */   void discardWorkingCopy() throws JavaModelException;
/*     */   
/*     */   IJavaElement[] findElements(IJavaElement paramIJavaElement);
/*     */   
/*     */   ICompilationUnit findWorkingCopy(WorkingCopyOwner paramWorkingCopyOwner);
/*     */   
/*     */   IType[] getAllTypes() throws JavaModelException;
/*     */   
/*     */   IImportDeclaration getImport(String paramString);
/*     */   
/*     */   IImportContainer getImportContainer();
/*     */   
/*     */   IImportDeclaration[] getImports() throws JavaModelException;
/*     */   
/*     */   ICompilationUnit getPrimary();
/*     */   
/*     */   WorkingCopyOwner getOwner();
/*     */   
/*     */   IPackageDeclaration getPackageDeclaration(String paramString);
/*     */   
/*     */   IPackageDeclaration[] getPackageDeclarations() throws JavaModelException;
/*     */   
/*     */   IType getType(String paramString);
/*     */   
/*     */   IType[] getTypes() throws JavaModelException;
/*     */   
/*     */   ICompilationUnit getWorkingCopy(IProgressMonitor paramIProgressMonitor) throws JavaModelException;
/*     */   
/*     */   ICompilationUnit getWorkingCopy(WorkingCopyOwner paramWorkingCopyOwner, IProblemRequestor paramIProblemRequestor, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
/*     */   
/*     */   boolean hasResourceChanged();
/*     */   
/*     */   boolean isWorkingCopy();
/*     */   
/*     */   default void setOptions(Map<String, String> newOptions) {}
/*     */   
/*     */   default Map<String, String> getCustomOptions() {
/* 588 */     return Collections.emptyMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Map<String, String> getOptions(boolean inheritJavaCoreOptions) {
/* 605 */     IJavaProject parentProject = getJavaProject();
/* 606 */     Map<String, String> options = (parentProject == null) ? JavaCore.getOptions() : parentProject.getOptions(inheritJavaCoreOptions);
/* 607 */     Map<String, String> customOptions = getCustomOptions();
/* 608 */     if (customOptions != null) {
/* 609 */       options.putAll(customOptions);
/*     */     }
/*     */     
/* 612 */     return options;
/*     */   }
/*     */   
/*     */   CompilationUnit reconcile(int paramInt, boolean paramBoolean, WorkingCopyOwner paramWorkingCopyOwner, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
/*     */   
/*     */   CompilationUnit reconcile(int paramInt, boolean paramBoolean1, boolean paramBoolean2, WorkingCopyOwner paramWorkingCopyOwner, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
/*     */   
/*     */   CompilationUnit reconcile(int paramInt1, int paramInt2, WorkingCopyOwner paramWorkingCopyOwner, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
/*     */   
/*     */   void restore() throws JavaModelException;
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\ICompilationUnit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */