package org.eclipse.jdt.core.dom;

public interface IMethodBinding extends IBinding {
  boolean isConstructor();
  
  boolean isCompactConstructor();
  
  boolean isCanonicalConstructor();
  
  boolean isDefaultConstructor();
  
  String getName();
  
  ITypeBinding getDeclaringClass();
  
  IBinding getDeclaringMember();
  
  Object getDefaultValue();
  
  IAnnotationBinding[] getParameterAnnotations(int paramInt);
  
  ITypeBinding[] getParameterTypes();
  
  ITypeBinding getDeclaredReceiverType();
  
  ITypeBinding getReturnType();
  
  ITypeBinding[] getExceptionTypes();
  
  ITypeBinding[] getTypeParameters();
  
  boolean isAnnotationMember();
  
  boolean isGenericMethod();
  
  boolean isParameterizedMethod();
  
  ITypeBinding[] getTypeArguments();
  
  IMethodBinding getMethodDeclaration();
  
  boolean isRawMethod();
  
  boolean isSubsignature(IMethodBinding paramIMethodBinding);
  
  boolean isVarargs();
  
  boolean overrides(IMethodBinding paramIMethodBinding);
  
  IVariableBinding[] getSyntheticOuterLocals();
  
  boolean isSyntheticRecordMethod();
  
  String[] getParameterNames();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\IMethodBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */