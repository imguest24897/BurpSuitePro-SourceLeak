/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThrowStatement
/*     */   extends Statement
/*     */ {
/*  39 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(ThrowStatement.class, "expression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  49 */     List propertyList = new ArrayList(2);
/*  50 */     createPropertyList(ThrowStatement.class, propertyList);
/*  51 */     addProperty(EXPRESSION_PROPERTY, propertyList);
/*  52 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  67 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private Expression expression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ThrowStatement(AST ast) {
/*  87 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  92 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/*  97 */     if (property == EXPRESSION_PROPERTY) {
/*  98 */       if (get) {
/*  99 */         return getExpression();
/*     */       }
/* 101 */       setExpression((Expression)child);
/* 102 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 106 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 111 */     return 53;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 116 */     ThrowStatement result = new ThrowStatement(target);
/* 117 */     result.setSourceRange(getStartPosition(), getLength());
/* 118 */     result.copyLeadingComment(this);
/* 119 */     result.setExpression((Expression)getExpression().clone(target));
/* 120 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 126 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 131 */     boolean visitChildren = visitor.visit(this);
/* 132 */     if (visitChildren) {
/* 133 */       acceptChild(visitor, getExpression());
/*     */     }
/* 135 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 144 */     if (this.expression == null)
/*     */     {
/* 146 */       synchronized (this) {
/* 147 */         if (this.expression == null) {
/* 148 */           preLazyInit();
/* 149 */           this.expression = new SimpleName(this.ast);
/* 150 */           postLazyInit(this.expression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 154 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 169 */     if (expression == null) {
/* 170 */       throw new IllegalArgumentException();
/*     */     }
/* 172 */     ASTNode oldChild = this.expression;
/* 173 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 174 */     this.expression = expression;
/* 175 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 180 */     return super.memSize() + 4;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 185 */     return 
/* 186 */       memSize() + (
/* 187 */       (this.expression == null) ? 0 : getExpression().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ThrowStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */