/*    */ package org.eclipse.jdt.core.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassFormatException
/*    */   extends Exception
/*    */ {
/*    */   public static final int ERROR_MALFORMED_UTF8 = 1;
/*    */   public static final int ERROR_TRUNCATED_INPUT = 2;
/*    */   public static final int INVALID_CONSTANT_POOL_ENTRY = 3;
/*    */   public static final int TOO_MANY_BYTES = 4;
/*    */   public static final int INVALID_ARGUMENTS_FOR_INVOKEINTERFACE = 5;
/*    */   public static final int INVALID_BYTECODE = 6;
/*    */   public static final int INVALID_TAG_CONSTANT = 7;
/*    */   public static final int INVALID_MAGIC_NUMBER = 8;
/*    */   private static final long serialVersionUID = 6582900558320612988L;
/*    */   
/*    */   public ClassFormatException(int errorID) {}
/*    */   
/*    */   public ClassFormatException(String message) {
/* 56 */     super(message);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ClassFormatException(String message, Throwable cause) {
/* 66 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\cor\\util\ClassFormatException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */