/*    */ package org.eclipse.jdt.internal.codeassist.impl;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.jdt.core.IType;
/*    */ import org.eclipse.jdt.core.JavaModelException;
/*    */ import org.eclipse.jdt.internal.core.Initializer;
/*    */ import org.eclipse.jdt.internal.core.JavaElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AssistInitializer
/*    */   extends Initializer
/*    */ {
/*    */   private Map bindingCache;
/*    */   private Map infoCache;
/*    */   
/*    */   public AssistInitializer(JavaElement parent, int count, Map bindingCache, Map infoCache) {
/* 29 */     super(parent, count);
/* 30 */     this.bindingCache = bindingCache;
/* 31 */     this.infoCache = infoCache;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getElementInfo(IProgressMonitor monitor) throws JavaModelException {
/* 36 */     return this.infoCache.get(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public IType getType(String typeName, int count) {
/* 41 */     AssistSourceType type = new AssistSourceType((JavaElement)this, typeName, this.bindingCache, this.infoCache);
/* 42 */     type.occurrenceCount = count;
/* 43 */     return (IType)type;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\impl\AssistInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */