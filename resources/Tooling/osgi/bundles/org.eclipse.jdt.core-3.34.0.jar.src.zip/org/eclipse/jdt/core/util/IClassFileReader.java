/*     */ package org.eclipse.jdt.core.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IClassFileReader
/*     */ {
/*     */   public static final int ALL = 65535;
/*     */   public static final int CONSTANT_POOL = 1;
/*     */   public static final int METHOD_INFOS = 3;
/*     */   public static final int FIELD_INFOS = 5;
/*     */   public static final int SUPER_INTERFACES = 9;
/*     */   public static final int CLASSFILE_ATTRIBUTES = 17;
/*     */   public static final int METHOD_BODIES = 32;
/*     */   public static final int ALL_BUT_METHOD_BODIES = 65503;
/*     */   
/*     */   int getAccessFlags();
/*     */   
/*     */   IFieldInfo[] getFieldInfos();
/*     */   
/*     */   char[][] getInterfaceNames();
/*     */   
/*     */   int[] getInterfaceIndexes();
/*     */   
/*     */   IInnerClassesAttribute getInnerClassesAttribute();
/*     */   
/*     */   default INestMembersAttribute getNestMembersAttribute() {
/* 126 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default IRecordAttribute getRecordAttribute() {
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default IPermittedSubclassesAttribute getPermittedSubclassesAttribute() {
/* 146 */     return null;
/*     */   }
/*     */   
/*     */   IMethodInfo[] getMethodInfos();
/*     */   
/*     */   char[] getClassName();
/*     */   
/*     */   int getClassIndex();
/*     */   
/*     */   char[] getSuperclassName();
/*     */   
/*     */   int getSuperclassIndex();
/*     */   
/*     */   boolean isClass();
/*     */   
/*     */   boolean isInterface();
/*     */   
/*     */   ISourceAttribute getSourceFileAttribute();
/*     */   
/*     */   IConstantPool getConstantPool();
/*     */   
/*     */   int getMinorVersion();
/*     */   
/*     */   int getMajorVersion();
/*     */   
/*     */   int getAttributeCount();
/*     */   
/*     */   IClassFileAttribute[] getAttributes();
/*     */   
/*     */   int getMagic();
/*     */   
/*     */   int getFieldsCount();
/*     */   
/*     */   int getMethodsCount();
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\cor\\util\IClassFileReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */