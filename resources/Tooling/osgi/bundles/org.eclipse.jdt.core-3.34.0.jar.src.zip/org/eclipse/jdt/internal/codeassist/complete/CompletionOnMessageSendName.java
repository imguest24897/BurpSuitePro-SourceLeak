/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.MessageSend;
/*    */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnMessageSendName
/*    */   extends MessageSend
/*    */ {
/*    */   public boolean nextIsCast;
/*    */   
/*    */   public CompletionOnMessageSendName(char[] selector, int start, int end, boolean nextIsCast) {
/* 33 */     this.selector = selector;
/* 34 */     this.sourceStart = start;
/* 35 */     this.sourceEnd = end;
/* 36 */     this.nameSourcePosition = end;
/* 37 */     this.nextIsCast = nextIsCast;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeBinding resolveType(BlockScope scope) {
/* 43 */     this.constant = Constant.NotAConstant;
/*    */     
/* 45 */     this.actualReceiverType = this.receiver.resolveType(scope);
/* 46 */     if (this.actualReceiverType == null || this.actualReceiverType.isBaseType() || this.actualReceiverType.isArrayType()) {
/* 47 */       throw new CompletionNodeFound();
/*    */     }
/*    */     
/* 50 */     if (this.typeArguments != null) {
/* 51 */       int length = this.typeArguments.length;
/* 52 */       this.genericTypeArguments = new TypeBinding[length];
/* 53 */       for (int i = 0; i < length; i++) {
/* 54 */         this.genericTypeArguments[i] = this.typeArguments[i].resolveType(scope, true);
/*    */       }
/*    */     } 
/*    */     
/* 58 */     throw new CompletionNodeFound(this, this.actualReceiverType, scope);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 64 */     output.append("<CompleteOnMessageSendName:");
/* 65 */     if (!this.receiver.isImplicitThis()) this.receiver.printExpression(0, output).append('.'); 
/* 66 */     if (this.typeArguments != null) {
/* 67 */       output.append('<');
/* 68 */       int max = this.typeArguments.length - 1;
/* 69 */       for (int j = 0; j < max; j++) {
/* 70 */         this.typeArguments[j].print(0, output);
/* 71 */         output.append(", ");
/*    */       } 
/* 73 */       this.typeArguments[max].print(0, output);
/* 74 */       output.append('>');
/*    */     } 
/* 76 */     output.append(this.selector).append('(');
/* 77 */     return output.append(")>");
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnMessageSendName.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */