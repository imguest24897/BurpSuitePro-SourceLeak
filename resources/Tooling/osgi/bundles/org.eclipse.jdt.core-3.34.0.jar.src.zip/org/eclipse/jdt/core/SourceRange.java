/*    */ package org.eclipse.jdt.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SourceRange
/*    */   implements ISourceRange
/*    */ {
/*    */   private int offset;
/*    */   private int length;
/*    */   
/*    */   public static boolean isAvailable(ISourceRange range) {
/* 37 */     return (range != null && range.getOffset() != -1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SourceRange(int offset, int length) {
/* 50 */     this.offset = offset;
/* 51 */     this.length = length;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 56 */     if (!(obj instanceof ISourceRange))
/* 57 */       return false; 
/* 58 */     ISourceRange sourceRange = (ISourceRange)obj;
/* 59 */     return (sourceRange.getOffset() == this.offset && sourceRange.getLength() == this.length);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getLength() {
/* 66 */     return this.length;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getOffset() {
/* 73 */     return this.offset;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 78 */     return this.length ^ this.offset;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 83 */     StringBuilder buffer = new StringBuilder();
/* 84 */     buffer.append("[offset=");
/* 85 */     buffer.append(this.offset);
/* 86 */     buffer.append(", length=");
/* 87 */     buffer.append(this.length);
/* 88 */     buffer.append("]");
/* 89 */     return buffer.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\SourceRange.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */