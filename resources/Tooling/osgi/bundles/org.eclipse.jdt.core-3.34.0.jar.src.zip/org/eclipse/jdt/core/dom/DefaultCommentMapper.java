/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultCommentMapper
/*     */ {
/*     */   Comment[] comments;
/*     */   Scanner scanner;
/*     */   int leadingPtr;
/*     */   ASTNode[] leadingNodes;
/*     */   long[] leadingIndexes;
/*     */   int trailingPtr;
/*     */   int lastTrailingPtr;
/*     */   ASTNode[] trailingNodes;
/*     */   long[] trailingIndexes;
/*     */   static final int STORAGE_INCREMENT = 16;
/*     */   
/*     */   DefaultCommentMapper(Comment[] table) {
/*  44 */     this.comments = table;
/*     */   }
/*     */   
/*     */   boolean hasSameTable(Comment[] table) {
/*  48 */     return (this.comments == table);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Comment getComment(int position) {
/*  59 */     if (this.comments == null) {
/*  60 */       return null;
/*     */     }
/*  62 */     int size = this.comments.length;
/*  63 */     if (size == 0) {
/*  64 */       return null;
/*     */     }
/*  66 */     int index = getCommentIndex(0, position, 0);
/*  67 */     if (index < 0) {
/*  68 */       return null;
/*     */     }
/*  70 */     return this.comments[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getCommentIndex(int start, int position, int exact) {
/*  81 */     if (position == 0) {
/*  82 */       if (this.comments.length > 0 && this.comments[0].getStartPosition() == 0) {
/*  83 */         return 0;
/*     */       }
/*  85 */       return -1;
/*     */     } 
/*  87 */     int bottom = start, top = this.comments.length - 1;
/*  88 */     int i = 0, index = -1;
/*  89 */     Comment comment = null;
/*  90 */     while (bottom <= top) {
/*  91 */       i = bottom + (top - bottom) / 2;
/*  92 */       comment = this.comments[i];
/*  93 */       int commentStart = comment.getStartPosition();
/*  94 */       if (position < commentStart) {
/*  95 */         top = i - 1; continue;
/*  96 */       }  if (position >= commentStart + comment.getLength()) {
/*  97 */         bottom = i + 1; continue;
/*     */       } 
/*  99 */       index = i;
/*     */       
/*     */       break;
/*     */     } 
/* 103 */     if (index < 0 && exact != 0) {
/* 104 */       comment = this.comments[i];
/* 105 */       if (position < comment.getStartPosition()) {
/* 106 */         return (exact < 0) ? (i - 1) : i;
/*     */       }
/* 108 */       return (exact < 0) ? i : (i + 1);
/*     */     } 
/*     */     
/* 111 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getExtendedStartPosition(ASTNode node) {
/* 127 */     if (this.leadingPtr >= 0) {
/* 128 */       long range = -1L;
/* 129 */       for (int i = 0; range < 0L && i <= this.leadingPtr; i++) {
/* 130 */         if (this.leadingNodes[i] == node) range = this.leadingIndexes[i]; 
/*     */       } 
/* 132 */       if (range >= 0L) {
/* 133 */         return this.comments[(int)(range >> 32L)].getStartPosition();
/*     */       }
/*     */     } 
/* 136 */     return node.getStartPosition();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getLineNumber(int position, int[] lineRange) {
/* 147 */     int[] lineEnds = this.scanner.lineEnds;
/* 148 */     int length = lineEnds.length;
/* 149 */     return Util.getLineNumber(position, lineEnds, ((lineRange[0] > length) ? length : lineRange[0]) - 1, ((lineRange[1] > length) ? length : lineRange[1]) - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getExtendedEnd(ASTNode node) {
/* 156 */     int end = node.getStartPosition() + node.getLength();
/* 157 */     if (this.trailingPtr >= 0) {
/* 158 */       long range = -1L;
/* 159 */       for (int i = 0; range < 0L && i <= this.trailingPtr; i++) {
/* 160 */         if (this.trailingNodes[i] == node) range = this.trailingIndexes[i]; 
/*     */       } 
/* 162 */       if (range >= 0L) {
/* 163 */         Comment lastComment = this.comments[(int)range];
/* 164 */         end = lastComment.getStartPosition() + lastComment.getLength();
/*     */       } 
/*     */     } 
/* 167 */     return end - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getExtendedLength(ASTNode node) {
/* 184 */     return getExtendedEnd(node) - getExtendedStartPosition(node) + 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int firstLeadingCommentIndex(ASTNode node) {
/* 194 */     if (this.leadingPtr >= 0) {
/* 195 */       for (int i = 0; i <= this.leadingPtr; i++) {
/* 196 */         if (this.leadingNodes[i] == node) {
/* 197 */           return (int)(this.leadingIndexes[i] >> 32L);
/*     */         }
/*     */       } 
/*     */     }
/* 201 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int lastTrailingCommentIndex(ASTNode node) {
/* 211 */     if (this.trailingPtr >= 0) {
/* 212 */       for (int i = 0; i <= this.trailingPtr; i++) {
/* 213 */         if (this.trailingNodes[i] == node) {
/* 214 */           return (int)this.trailingIndexes[i];
/*     */         }
/*     */       } 
/*     */     }
/* 218 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initialize(CompilationUnit unit, Scanner sc) {
/* 230 */     this.leadingPtr = -1;
/* 231 */     this.trailingPtr = -1;
/*     */ 
/*     */     
/* 234 */     this.comments = unit.optionalCommentTable;
/* 235 */     if (this.comments == null) {
/*     */       return;
/*     */     }
/* 238 */     int size = this.comments.length;
/* 239 */     if (size == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 244 */     this.scanner = sc;
/* 245 */     this.scanner.tokenizeWhiteSpace = true;
/*     */ 
/*     */     
/* 248 */     DefaultASTVisitor commentVisitor = new CommentMapperVisitor();
/* 249 */     unit.accept(commentVisitor);
/*     */ 
/*     */     
/* 252 */     int leadingCount = this.leadingPtr + 1;
/* 253 */     if (leadingCount > 0 && leadingCount < this.leadingIndexes.length) {
/* 254 */       System.arraycopy(this.leadingNodes, 0, this.leadingNodes = new ASTNode[leadingCount], 0, leadingCount);
/* 255 */       System.arraycopy(this.leadingIndexes, 0, this.leadingIndexes = new long[leadingCount], 0, leadingCount);
/*     */     } 
/*     */ 
/*     */     
/* 259 */     if (this.trailingPtr >= 0) {
/*     */       
/* 261 */       while (this.trailingIndexes[this.trailingPtr] == -1L) {
/* 262 */         this.trailingPtr--;
/* 263 */         if (this.trailingPtr < 0) {
/* 264 */           this.trailingIndexes = null;
/* 265 */           this.trailingNodes = null;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 271 */       int trailingCount = this.trailingPtr + 1;
/* 272 */       if (trailingCount > 0 && trailingCount < this.trailingIndexes.length) {
/* 273 */         System.arraycopy(this.trailingNodes, 0, this.trailingNodes = new ASTNode[trailingCount], 0, trailingCount);
/* 274 */         System.arraycopy(this.trailingIndexes, 0, this.trailingIndexes = new long[trailingCount], 0, trailingCount);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 279 */     this.scanner = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int storeLeadingComments(ASTNode node, int previousEnd, int[] parentLineRange) {
/* 305 */     int nodeStart = node.getStartPosition();
/* 306 */     int extended = nodeStart;
/*     */ 
/*     */     
/* 309 */     int previousEndLine = getLineNumber(previousEnd, parentLineRange);
/* 310 */     int nodeStartLine = getLineNumber(nodeStart, parentLineRange);
/*     */ 
/*     */     
/* 313 */     int idx = getCommentIndex(0, nodeStart, -1);
/* 314 */     if (idx == -1) {
/* 315 */       return nodeStart;
/*     */     }
/*     */ 
/*     */     
/* 319 */     int startIdx = -1;
/* 320 */     int endIdx = idx;
/* 321 */     int previousStart = nodeStart;
/* 322 */     while (idx >= 0 && previousStart >= previousEnd) {
/*     */       
/* 324 */       Comment comment = this.comments[idx];
/* 325 */       int commentStart = comment.getStartPosition();
/* 326 */       int end = commentStart + comment.getLength() - 1;
/* 327 */       int commentLine = getLineNumber(commentStart, parentLineRange);
/* 328 */       if (end <= previousEnd || (commentLine == previousEndLine && commentLine != nodeStartLine)) {
/*     */         break;
/*     */       }
/* 331 */       if (end + 1 < previousStart) {
/* 332 */         this.scanner.resetTo(end + 1, previousStart);
/*     */         try {
/* 334 */           int token = this.scanner.getNextToken();
/* 335 */           if (token != 1000 || this.scanner.currentPosition != previousStart) {
/*     */ 
/*     */             
/* 338 */             if (idx == endIdx) {
/* 339 */               return nodeStart;
/*     */             }
/*     */             break;
/*     */           } 
/* 343 */         } catch (InvalidInputException invalidInputException) {
/*     */           
/* 345 */           return nodeStart;
/*     */         } 
/*     */         
/* 348 */         char[] gap = this.scanner.getCurrentIdentifierSource();
/* 349 */         int nbrLine = 0;
/* 350 */         int pos = -1;
/* 351 */         while ((pos = CharOperation.indexOf('\n', gap, pos + 1)) >= 0) {
/* 352 */           nbrLine++;
/*     */         }
/* 354 */         if (nbrLine > 1) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 360 */       previousStart = commentStart;
/* 361 */       startIdx = idx--;
/*     */     } 
/* 363 */     if (startIdx != -1) {
/*     */       
/* 365 */       int commentStart = this.comments[startIdx].getStartPosition();
/* 366 */       if (previousEnd < commentStart && previousEndLine != nodeStartLine) {
/* 367 */         int lastTokenEnd = previousEnd;
/* 368 */         this.scanner.resetTo(previousEnd, commentStart);
/*     */         try {
/* 370 */           while (this.scanner.currentPosition < commentStart) {
/* 371 */             if (this.scanner.getNextToken() != 1000) {
/* 372 */               lastTokenEnd = this.scanner.getCurrentTokenEndPosition();
/*     */             }
/*     */           } 
/* 375 */         } catch (InvalidInputException invalidInputException) {}
/*     */ 
/*     */         
/* 378 */         int lastTokenLine = getLineNumber(lastTokenEnd, parentLineRange);
/* 379 */         int length = this.comments.length;
/* 380 */         while (startIdx < length && lastTokenLine == getLineNumber(this.comments[startIdx].getStartPosition(), parentLineRange) && nodeStartLine != lastTokenLine) {
/* 381 */           startIdx++;
/*     */         }
/*     */       } 
/*     */       
/* 385 */       if (startIdx <= endIdx) {
/* 386 */         if (++this.leadingPtr == 0) {
/* 387 */           this.leadingNodes = new ASTNode[16];
/* 388 */           this.leadingIndexes = new long[16];
/* 389 */         } else if (this.leadingPtr == this.leadingNodes.length) {
/* 390 */           int newLength = this.leadingPtr * 3 / 2 + 16;
/* 391 */           System.arraycopy(this.leadingNodes, 0, this.leadingNodes = new ASTNode[newLength], 0, this.leadingPtr);
/* 392 */           System.arraycopy(this.leadingIndexes, 0, this.leadingIndexes = new long[newLength], 0, this.leadingPtr);
/*     */         } 
/* 394 */         this.leadingNodes[this.leadingPtr] = node;
/* 395 */         this.leadingIndexes[this.leadingPtr] = (startIdx << 32L) + endIdx;
/* 396 */         extended = this.comments[endIdx].getStartPosition();
/*     */       } 
/*     */     } 
/* 399 */     return extended;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int storeTrailingComments(ASTNode node, int nextStart, boolean lastChild, int[] parentLineRange) {
/* 426 */     int nodeEnd = node.getStartPosition() + node.getLength() - 1;
/* 427 */     if (nodeEnd == nextStart) {
/*     */       
/* 429 */       if (++this.trailingPtr == 0) {
/* 430 */         this.trailingNodes = new ASTNode[16];
/* 431 */         this.trailingIndexes = new long[16];
/* 432 */         this.lastTrailingPtr = -1;
/* 433 */       } else if (this.trailingPtr == this.trailingNodes.length) {
/* 434 */         int newLength = this.trailingPtr * 3 / 2 + 16;
/* 435 */         System.arraycopy(this.trailingNodes, 0, this.trailingNodes = new ASTNode[newLength], 0, this.trailingPtr);
/* 436 */         System.arraycopy(this.trailingIndexes, 0, this.trailingIndexes = new long[newLength], 0, this.trailingPtr);
/*     */       } 
/* 438 */       this.trailingNodes[this.trailingPtr] = node;
/* 439 */       this.trailingIndexes[this.trailingPtr] = -1L;
/* 440 */       return nodeEnd;
/*     */     } 
/* 442 */     int extended = nodeEnd;
/*     */ 
/*     */     
/* 445 */     int nodeEndLine = getLineNumber(nodeEnd, parentLineRange);
/*     */ 
/*     */     
/* 448 */     int idx = getCommentIndex(0, nodeEnd, 1);
/* 449 */     if (idx == -1) {
/* 450 */       return nodeEnd;
/*     */     }
/*     */ 
/*     */     
/* 454 */     int startIdx = idx;
/* 455 */     int endIdx = -1;
/* 456 */     int length = this.comments.length;
/* 457 */     int commentStart = extended + 1;
/* 458 */     int previousEnd = nodeEnd + 1;
/* 459 */     int sameLineIdx = -1;
/* 460 */     while (idx < length && commentStart < nextStart) {
/*     */       
/* 462 */       Comment comment = this.comments[idx];
/* 463 */       commentStart = comment.getStartPosition();
/*     */       
/* 465 */       if (commentStart >= nextStart) {
/*     */         break;
/*     */       }
/* 468 */       if (previousEnd < commentStart) {
/* 469 */         this.scanner.resetTo(previousEnd, commentStart);
/*     */         try {
/* 471 */           int token = this.scanner.getNextToken();
/* 472 */           if (token != 1000 || this.scanner.currentPosition != commentStart) {
/*     */ 
/*     */             
/* 475 */             if (idx == startIdx) {
/* 476 */               return nodeEnd;
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/* 481 */         } catch (InvalidInputException invalidInputException) {
/*     */           
/* 483 */           return nodeEnd;
/*     */         } 
/*     */         
/* 486 */         char[] gap = this.scanner.getCurrentIdentifierSource();
/* 487 */         int nbrLine = 0;
/* 488 */         int pos = -1;
/* 489 */         while ((pos = CharOperation.indexOf('\n', gap, pos + 1)) >= 0) {
/* 490 */           nbrLine++;
/*     */         }
/* 492 */         if (nbrLine > 1) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 498 */       int commentLine = getLineNumber(commentStart, parentLineRange);
/* 499 */       if (commentLine == nodeEndLine) {
/* 500 */         sameLineIdx = idx;
/*     */       }
/*     */       
/* 503 */       previousEnd = commentStart + comment.getLength();
/* 504 */       endIdx = idx++;
/*     */     } 
/* 506 */     if (endIdx != -1) {
/*     */       
/* 508 */       if (!lastChild) {
/* 509 */         int nextLine = getLineNumber(nextStart, parentLineRange);
/* 510 */         int previousLine = getLineNumber(previousEnd, parentLineRange);
/* 511 */         if (nextLine - previousLine <= 1) {
/* 512 */           if (sameLineIdx == -1) return nodeEnd; 
/* 513 */           endIdx = sameLineIdx;
/*     */         } 
/*     */       } 
/*     */       
/* 517 */       if (++this.trailingPtr == 0) {
/* 518 */         this.trailingNodes = new ASTNode[16];
/* 519 */         this.trailingIndexes = new long[16];
/* 520 */         this.lastTrailingPtr = -1;
/* 521 */       } else if (this.trailingPtr == this.trailingNodes.length) {
/* 522 */         int newLength = this.trailingPtr * 3 / 2 + 16;
/* 523 */         System.arraycopy(this.trailingNodes, 0, this.trailingNodes = new ASTNode[newLength], 0, this.trailingPtr);
/* 524 */         System.arraycopy(this.trailingIndexes, 0, this.trailingIndexes = new long[newLength], 0, this.trailingPtr);
/*     */       } 
/* 526 */       this.trailingNodes[this.trailingPtr] = node;
/* 527 */       long nodeRange = (startIdx << 32L) + endIdx;
/* 528 */       this.trailingIndexes[this.trailingPtr] = nodeRange;
/*     */       
/* 530 */       extended = this.comments[endIdx].getStartPosition() + this.comments[endIdx].getLength() - 1;
/*     */       
/* 532 */       ASTNode previousNode = node;
/* 533 */       int ptr = this.trailingPtr - 1;
/* 534 */       while (ptr >= 0) {
/* 535 */         long range = this.trailingIndexes[ptr];
/* 536 */         if (range != -1L)
/* 537 */           break;  ASTNode unresolved = this.trailingNodes[ptr];
/* 538 */         if (previousNode != unresolved.getParent())
/* 539 */           break;  this.trailingIndexes[ptr] = nodeRange;
/* 540 */         previousNode = unresolved;
/* 541 */         ptr--;
/*     */       } 
/*     */       
/* 544 */       if (ptr > this.lastTrailingPtr) {
/* 545 */         int offset = ptr - this.lastTrailingPtr;
/* 546 */         for (int i = ptr + 1; i <= this.trailingPtr; i++) {
/* 547 */           this.trailingNodes[i - offset] = this.trailingNodes[i];
/* 548 */           this.trailingIndexes[i - offset] = this.trailingIndexes[i];
/*     */         } 
/* 550 */         this.trailingPtr -= offset;
/*     */       } 
/* 552 */       this.lastTrailingPtr = this.trailingPtr;
/*     */     } 
/* 554 */     return extended;
/*     */   }
/*     */   
/*     */   class CommentMapperVisitor
/*     */     extends DefaultASTVisitor {
/* 559 */     ASTNode topSiblingParent = null;
/* 560 */     ASTNode[] siblings = new ASTNode[10];
/* 561 */     int[][] parentLineRange = new int[10][];
/* 562 */     int siblingPtr = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected boolean visitNode(ASTNode node) {
/* 568 */       ASTNode parent = node.getParent();
/* 569 */       int previousEnd = parent.getStartPosition();
/*     */ 
/*     */       
/* 572 */       ASTNode sibling = (parent == this.topSiblingParent) ? this.siblings[this.siblingPtr] : null;
/* 573 */       if (sibling != null) {
/*     */         
/*     */         try {
/* 576 */           previousEnd = DefaultCommentMapper.this.storeTrailingComments(sibling, node.getStartPosition(), false, this.parentLineRange[this.siblingPtr]);
/* 577 */         } catch (Exception exception) {}
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 583 */       if ((node.typeAndFlags & 0x1) != 0) {
/* 584 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 588 */       (new int[2])[0] = 1; (new int[2])[1] = DefaultCommentMapper.this.scanner.linePtr + 1; int[] previousLineRange = (this.siblingPtr > -1) ? this.parentLineRange[this.siblingPtr] : new int[2];
/*     */       try {
/* 590 */         DefaultCommentMapper.this.storeLeadingComments(node, previousEnd, previousLineRange);
/* 591 */       } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 596 */       if (this.topSiblingParent != parent) {
/* 597 */         if (this.siblings.length == ++this.siblingPtr) {
/* 598 */           System.arraycopy(this.siblings, 0, this.siblings = new ASTNode[this.siblingPtr * 2], 0, this.siblingPtr);
/* 599 */           System.arraycopy(this.parentLineRange, 0, this.parentLineRange = new int[this.siblingPtr * 2][], 0, this.siblingPtr);
/*     */         } 
/* 601 */         if (this.topSiblingParent == null) {
/*     */           
/* 603 */           this.parentLineRange[this.siblingPtr] = previousLineRange;
/*     */         } else {
/* 605 */           int parentStart = parent.getStartPosition();
/* 606 */           int firstLine = DefaultCommentMapper.this.getLineNumber(parentStart, previousLineRange);
/* 607 */           int lastLine = DefaultCommentMapper.this.getLineNumber(parentStart + parent.getLength() - 1, previousLineRange);
/* 608 */           if (this.parentLineRange[this.siblingPtr] == null) {
/* 609 */             (new int[2])[0] = firstLine; (new int[2])[1] = lastLine; this.parentLineRange[this.siblingPtr] = new int[2];
/*     */           } else {
/* 611 */             int[] lineRange = this.parentLineRange[this.siblingPtr];
/* 612 */             lineRange[0] = firstLine;
/* 613 */             lineRange[1] = lastLine;
/*     */           } 
/*     */         } 
/* 616 */         this.topSiblingParent = parent;
/*     */       } 
/* 618 */       this.siblings[this.siblingPtr] = node;
/*     */ 
/*     */       
/* 621 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void endVisitNode(ASTNode node) {
/* 628 */       ASTNode sibling = (this.topSiblingParent == node) ? this.siblings[this.siblingPtr] : null;
/* 629 */       if (sibling != null) {
/*     */         try {
/* 631 */           DefaultCommentMapper.this.storeTrailingComments(sibling, node.getStartPosition() + node.getLength() - 1, true, this.parentLineRange[this.siblingPtr]);
/* 632 */         } catch (Exception exception) {}
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 637 */       if (this.topSiblingParent != null && 
/* 638 */         this.topSiblingParent == node) {
/* 639 */         this.siblingPtr--;
/* 640 */         this.topSiblingParent = node.getParent();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean visit(Modifier modifier) {
/* 647 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean visit(CompilationUnit node) {
/* 652 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\DefaultCommentMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */