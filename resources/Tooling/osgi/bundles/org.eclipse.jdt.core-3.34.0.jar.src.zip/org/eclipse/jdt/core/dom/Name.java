/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Name
/*     */   extends Expression
/*     */   implements IDocElement
/*     */ {
/*     */   static final int BASE_NAME_NODE_SIZE = 44;
/*     */   int index;
/*     */   
/*     */   Name(AST ast) {
/*  52 */     super(ast);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSimpleName() {
/*  63 */     return this instanceof SimpleName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isQualifiedName() {
/*  74 */     return this instanceof QualifiedName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IBinding resolveBinding() {
/*  88 */     return this.ast.getBindingResolver().resolveName(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getFullyQualifiedName() {
/* 102 */     if (isSimpleName())
/*     */     {
/* 104 */       return ((SimpleName)this).getIdentifier();
/*     */     }
/* 106 */     StringBuffer buffer = new StringBuffer(50);
/* 107 */     appendName(buffer);
/* 108 */     return new String(buffer);
/*     */   }
/*     */   
/*     */   abstract void appendName(StringBuffer paramStringBuffer);
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\Name.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */