/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParameterizedType
/*     */   extends Type
/*     */ {
/*     */   int index;
/*  45 */   public static final ChildPropertyDescriptor TYPE_PROPERTY = new ChildPropertyDescriptor(ParameterizedType.class, "type", Type.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public static final ChildListPropertyDescriptor TYPE_ARGUMENTS_PROPERTY = new ChildListPropertyDescriptor(ParameterizedType.class, "typeArguments", Type.class, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  61 */     List propertyList = new ArrayList(3);
/*  62 */     createPropertyList(ParameterizedType.class, propertyList);
/*  63 */     addProperty(TYPE_PROPERTY, propertyList);
/*  64 */     addProperty(TYPE_ARGUMENTS_PROPERTY, propertyList);
/*  65 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  79 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   private Type type = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   private ASTNode.NodeList typeArguments = new ASTNode.NodeList(this, TYPE_ARGUMENTS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ParameterizedType(AST ast) {
/* 106 */     super(ast);
/* 107 */     unsupportedIn2();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 112 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 117 */     if (property == TYPE_PROPERTY) {
/* 118 */       if (get) {
/* 119 */         return getType();
/*     */       }
/* 121 */       setType((Type)child);
/* 122 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 126 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 131 */     if (property == TYPE_ARGUMENTS_PROPERTY) {
/* 132 */       return typeArguments();
/*     */     }
/*     */     
/* 135 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 140 */     return 74;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 145 */     ParameterizedType result = new ParameterizedType(target);
/* 146 */     result.setSourceRange(getStartPosition(), getLength());
/* 147 */     result.setType((Type)getType().clone(target));
/* 148 */     result.typeArguments().addAll(
/* 149 */         ASTNode.copySubtrees(target, typeArguments()));
/* 150 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 156 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 161 */     boolean visitChildren = visitor.visit(this);
/* 162 */     if (visitChildren) {
/*     */       
/* 164 */       acceptChild(visitor, getType());
/* 165 */       acceptChildren(visitor, this.typeArguments);
/*     */     } 
/* 167 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 176 */     if (this.type == null)
/*     */     {
/* 178 */       synchronized (this) {
/* 179 */         if (this.type == null) {
/* 180 */           preLazyInit();
/* 181 */           this.type = new SimpleType(this.ast);
/* 182 */           postLazyInit(this.type, TYPE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 186 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(Type type) {
/* 200 */     if (type == null) {
/* 201 */       throw new IllegalArgumentException();
/*     */     }
/* 203 */     ASTNode oldChild = this.type;
/* 204 */     preReplaceChild(oldChild, type, TYPE_PROPERTY);
/* 205 */     this.type = type;
/* 206 */     postReplaceChild(oldChild, type, TYPE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List typeArguments() {
/* 222 */     return this.typeArguments;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 228 */     return 52;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 233 */     return 
/* 234 */       memSize() + (
/* 235 */       (this.type == null) ? 0 : getType().treeSize()) + 
/* 236 */       this.typeArguments.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ParameterizedType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */