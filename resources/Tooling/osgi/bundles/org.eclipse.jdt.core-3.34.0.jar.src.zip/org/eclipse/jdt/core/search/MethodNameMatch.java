package org.eclipse.jdt.core.search;

import org.eclipse.jdt.core.IMethod;

public abstract class MethodNameMatch {
  public abstract int getAccessibility();
  
  public abstract int getModifiers();
  
  public abstract IMethod getMethod();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\search\MethodNameMatch.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */