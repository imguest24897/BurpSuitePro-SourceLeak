/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MethodInvocation
/*     */   extends Expression
/*     */ {
/*  39 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(MethodInvocation.class, "expression", Expression.class, false, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final ChildListPropertyDescriptor TYPE_ARGUMENTS_PROPERTY = new ChildListPropertyDescriptor(MethodInvocation.class, "typeArguments", Type.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(MethodInvocation.class, "name", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public static final ChildListPropertyDescriptor ARGUMENTS_PROPERTY = new ChildListPropertyDescriptor(MethodInvocation.class, "arguments", Expression.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  79 */     List properyList = new ArrayList(4);
/*  80 */     createPropertyList(MethodInvocation.class, properyList);
/*  81 */     addProperty(EXPRESSION_PROPERTY, properyList);
/*  82 */     addProperty(NAME_PROPERTY, properyList);
/*  83 */     addProperty(ARGUMENTS_PROPERTY, properyList);
/*  84 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(properyList);
/*     */     
/*  86 */     properyList = new ArrayList(5);
/*  87 */     createPropertyList(MethodInvocation.class, properyList);
/*  88 */     addProperty(EXPRESSION_PROPERTY, properyList);
/*  89 */     addProperty(TYPE_ARGUMENTS_PROPERTY, properyList);
/*  90 */     addProperty(NAME_PROPERTY, properyList);
/*  91 */     addProperty(ARGUMENTS_PROPERTY, properyList);
/*  92 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 107 */     if (apiLevel == 2) {
/* 108 */       return PROPERTY_DESCRIPTORS_2_0;
/*     */     }
/* 110 */     return PROPERTY_DESCRIPTORS_3_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   private Expression optionalExpression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   private ASTNode.NodeList typeArguments = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   private SimpleName methodName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   private ASTNode.NodeList arguments = new ASTNode.NodeList(this, ARGUMENTS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MethodInvocation(AST ast) {
/* 148 */     super(ast);
/* 149 */     if (ast.apiLevel >= 3) {
/* 150 */       this.typeArguments = new ASTNode.NodeList(this, TYPE_ARGUMENTS_PROPERTY);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 156 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 161 */     if (property == NAME_PROPERTY) {
/* 162 */       if (get) {
/* 163 */         return getName();
/*     */       }
/* 165 */       setName((SimpleName)child);
/* 166 */       return null;
/*     */     } 
/*     */     
/* 169 */     if (property == EXPRESSION_PROPERTY) {
/* 170 */       if (get) {
/* 171 */         return getExpression();
/*     */       }
/* 173 */       setExpression((Expression)child);
/* 174 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 178 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 183 */     if (property == ARGUMENTS_PROPERTY) {
/* 184 */       return arguments();
/*     */     }
/* 186 */     if (property == TYPE_ARGUMENTS_PROPERTY) {
/* 187 */       return typeArguments();
/*     */     }
/*     */     
/* 190 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 195 */     return 32;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 200 */     MethodInvocation result = new MethodInvocation(target);
/* 201 */     result.setSourceRange(getStartPosition(), getLength());
/* 202 */     result.setName((SimpleName)getName().clone(target));
/* 203 */     result.setExpression(
/* 204 */         (Expression)ASTNode.copySubtree(target, getExpression()));
/* 205 */     if (this.ast.apiLevel >= 3) {
/* 206 */       result.typeArguments().addAll(ASTNode.copySubtrees(target, typeArguments()));
/*     */     }
/* 208 */     result.arguments().addAll(ASTNode.copySubtrees(target, arguments()));
/* 209 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 215 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 220 */     boolean visitChildren = visitor.visit(this);
/* 221 */     if (visitChildren) {
/*     */       
/* 223 */       acceptChild(visitor, getExpression());
/* 224 */       if (this.ast.apiLevel >= 3) {
/* 225 */         acceptChildren(visitor, this.typeArguments);
/*     */       }
/* 227 */       acceptChild(visitor, getName());
/* 228 */       acceptChildren(visitor, this.arguments);
/*     */     } 
/* 230 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 240 */     return this.optionalExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isResolvedTypeInferredFromExpectedType() {
/* 255 */     return this.ast.getBindingResolver().isResolvedTypeInferredFromExpectedType(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 271 */     ASTNode oldChild = this.optionalExpression;
/* 272 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 273 */     this.optionalExpression = expression;
/* 274 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List typeArguments() {
/* 289 */     if (this.typeArguments == null) {
/* 290 */       unsupportedIn2();
/*     */     }
/* 292 */     return this.typeArguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 301 */     if (this.methodName == null)
/*     */     {
/* 303 */       synchronized (this) {
/* 304 */         if (this.methodName == null) {
/* 305 */           preLazyInit();
/* 306 */           this.methodName = new SimpleName(this.ast);
/* 307 */           postLazyInit(this.methodName, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 311 */     return this.methodName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName name) {
/* 326 */     if (name == null) {
/* 327 */       throw new IllegalArgumentException();
/*     */     }
/* 329 */     ASTNode oldChild = this.methodName;
/* 330 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 331 */     this.methodName = name;
/* 332 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List arguments() {
/* 343 */     return this.arguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMethodBinding resolveMethodBinding() {
/* 359 */     return this.ast.getBindingResolver().resolveMethod(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 365 */     return 56;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 370 */     return 
/* 371 */       memSize() + (
/* 372 */       (this.optionalExpression == null) ? 0 : getExpression().treeSize()) + (
/* 373 */       (this.typeArguments == null) ? 0 : this.typeArguments.listSize()) + (
/* 374 */       (this.methodName == null) ? 0 : getName().treeSize()) + (
/* 375 */       (this.arguments == null) ? 0 : this.arguments.listSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\MethodInvocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */