package org.eclipse.jdt.core;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.text.edits.TextEdit;
import org.eclipse.text.edits.UndoEdit;

public interface IBuffer {
  void addBufferChangedListener(IBufferChangedListener paramIBufferChangedListener);
  
  void append(char[] paramArrayOfchar);
  
  void append(String paramString);
  
  void close();
  
  char getChar(int paramInt);
  
  char[] getCharacters();
  
  String getContents();
  
  int getLength();
  
  IOpenable getOwner();
  
  String getText(int paramInt1, int paramInt2) throws IndexOutOfBoundsException;
  
  IResource getUnderlyingResource();
  
  boolean hasUnsavedChanges();
  
  boolean isClosed();
  
  boolean isReadOnly();
  
  void removeBufferChangedListener(IBufferChangedListener paramIBufferChangedListener);
  
  void replace(int paramInt1, int paramInt2, char[] paramArrayOfchar);
  
  void replace(int paramInt1, int paramInt2, String paramString);
  
  void save(IProgressMonitor paramIProgressMonitor, boolean paramBoolean) throws JavaModelException;
  
  void setContents(char[] paramArrayOfchar);
  
  void setContents(String paramString);
  
  public static interface ITextEditCapability {
    UndoEdit applyTextEdit(TextEdit param1TextEdit, IProgressMonitor param1IProgressMonitor) throws JavaModelException;
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IBuffer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */