/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeMethodReference
/*     */   extends MethodReference
/*     */ {
/*  38 */   public static final ChildPropertyDescriptor TYPE_PROPERTY = new ChildPropertyDescriptor(TypeMethodReference.class, "type", Type.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   public static final ChildListPropertyDescriptor TYPE_ARGUMENTS_PROPERTY = internalTypeArgumentsFactory(TypeMethodReference.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(TypeMethodReference.class, "name", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_8_0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  60 */     List propertyList = new ArrayList(4);
/*  61 */     createPropertyList(TypeMethodReference.class, propertyList);
/*  62 */     addProperty(TYPE_PROPERTY, propertyList);
/*  63 */     addProperty(TYPE_ARGUMENTS_PROPERTY, propertyList);
/*  64 */     addProperty(NAME_PROPERTY, propertyList);
/*  65 */     PROPERTY_DESCRIPTORS_8_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  77 */     return PROPERTY_DESCRIPTORS_8_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   private Type type = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   private SimpleName methodName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TypeMethodReference(AST ast) {
/* 103 */     super(ast);
/* 104 */     unsupportedIn2_3_4();
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalTypeArgumentsProperty() {
/* 109 */     return TYPE_ARGUMENTS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 114 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 119 */     if (property == NAME_PROPERTY) {
/* 120 */       if (get) {
/* 121 */         return getName();
/*     */       }
/* 123 */       setName((SimpleName)child);
/* 124 */       return null;
/*     */     } 
/*     */     
/* 127 */     if (property == TYPE_PROPERTY) {
/* 128 */       if (get) {
/* 129 */         return getType();
/*     */       }
/* 131 */       setType((Type)child);
/* 132 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 136 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 141 */     if (property == TYPE_ARGUMENTS_PROPERTY) {
/* 142 */       return typeArguments();
/*     */     }
/*     */     
/* 145 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 150 */     return 92;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 155 */     TypeMethodReference result = new TypeMethodReference(target);
/* 156 */     result.setSourceRange(getStartPosition(), getLength());
/* 157 */     result.setType((Type)ASTNode.copySubtree(target, getType()));
/* 158 */     result.typeArguments().addAll(ASTNode.copySubtrees(target, typeArguments()));
/* 159 */     result.setName((SimpleName)getName().clone(target));
/* 160 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 166 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 171 */     boolean visitChildren = visitor.visit(this);
/* 172 */     if (visitChildren) {
/*     */       
/* 174 */       acceptChild(visitor, getType());
/* 175 */       acceptChildren(visitor, this.typeArguments);
/* 176 */       acceptChild(visitor, getName());
/*     */     } 
/* 178 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 187 */     if (this.type == null)
/*     */     {
/* 189 */       synchronized (this) {
/* 190 */         if (this.type == null) {
/* 191 */           preLazyInit();
/* 192 */           this.type = new SimpleType(this.ast);
/* 193 */           postLazyInit(this.type, TYPE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 197 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(Type type) {
/* 211 */     if (type == null) {
/* 212 */       throw new IllegalArgumentException();
/*     */     }
/* 214 */     ASTNode oldChild = this.type;
/* 215 */     preReplaceChild(oldChild, type, TYPE_PROPERTY);
/* 216 */     this.type = type;
/* 217 */     postReplaceChild(oldChild, type, TYPE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List typeArguments() {
/* 228 */     return this.typeArguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 237 */     if (this.methodName == null)
/*     */     {
/* 239 */       synchronized (this) {
/* 240 */         if (this.methodName == null) {
/* 241 */           preLazyInit();
/* 242 */           this.methodName = new SimpleName(this.ast);
/* 243 */           postLazyInit(this.methodName, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 247 */     return this.methodName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName name) {
/* 262 */     if (name == null) {
/* 263 */       throw new IllegalArgumentException();
/*     */     }
/* 265 */     ASTNode oldChild = this.methodName;
/* 266 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 267 */     this.methodName = name;
/* 268 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 274 */     return 52;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 279 */     return 
/* 280 */       memSize() + (
/* 281 */       (this.type == null) ? 0 : getType().treeSize()) + (
/* 282 */       (this.typeArguments == null) ? 0 : this.typeArguments.listSize()) + (
/* 283 */       (this.methodName == null) ? 0 : getName().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\TypeMethodReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */