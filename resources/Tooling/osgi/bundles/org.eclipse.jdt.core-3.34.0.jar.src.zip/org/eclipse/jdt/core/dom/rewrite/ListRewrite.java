/*     */ package org.eclipse.jdt.core.dom.rewrite;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.dom.ASTNode;
/*     */ import org.eclipse.jdt.core.dom.Block;
/*     */ import org.eclipse.jdt.core.dom.ChildListPropertyDescriptor;
/*     */ import org.eclipse.jdt.core.dom.StructuralPropertyDescriptor;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.ListRewriteEvent;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.NodeInfoStore;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.RewriteEvent;
/*     */ import org.eclipse.jdt.internal.core.dom.rewrite.RewriteEventStore;
/*     */ import org.eclipse.text.edits.TextEditGroup;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ListRewrite
/*     */ {
/*     */   private ASTNode parent;
/*     */   private ChildListPropertyDescriptor childListProperty;
/*     */   private ASTRewrite rewriter;
/*     */   
/*     */   ListRewrite(ASTRewrite rewriter, ASTNode parent, ChildListPropertyDescriptor childProperty) {
/*  49 */     this.rewriter = rewriter;
/*  50 */     this.parent = parent;
/*  51 */     this.childListProperty = childProperty;
/*     */   }
/*     */   
/*     */   private RewriteEventStore getRewriteStore() {
/*  55 */     return this.rewriter.getRewriteEventStore();
/*     */   }
/*     */   
/*     */   private ListRewriteEvent getEvent() {
/*  59 */     return getRewriteStore().getListEvent(this.parent, (StructuralPropertyDescriptor)this.childListProperty, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ASTNode getParent() {
/*  70 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StructuralPropertyDescriptor getLocationInParent() {
/*  81 */     return (StructuralPropertyDescriptor)this.childListProperty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(ASTNode node, TextEditGroup editGroup) {
/*  99 */     if (node == null) {
/* 100 */       throw new IllegalArgumentException();
/*     */     }
/* 102 */     RewriteEvent event = getEvent().removeEntry(node);
/* 103 */     if (editGroup != null) {
/* 104 */       getRewriteStore().setEventEditGroup(event, editGroup);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ASTRewrite getASTRewrite() {
/* 114 */     return this.rewriter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replace(ASTNode node, ASTNode replacement, TextEditGroup editGroup) {
/* 141 */     if (node == null) {
/* 142 */       throw new IllegalArgumentException();
/*     */     }
/* 144 */     validatePropertyType(node);
/* 145 */     RewriteEvent event = getEvent().replaceEntry(node, replacement);
/* 146 */     if (editGroup != null) {
/* 147 */       getRewriteStore().setEventEditGroup(event, editGroup);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertAfter(ASTNode node, ASTNode previousElement, TextEditGroup editGroup) {
/* 174 */     if (node == null || previousElement == null) {
/* 175 */       throw new IllegalArgumentException();
/*     */     }
/* 177 */     int index = getEvent().getIndex(previousElement, 3);
/* 178 */     if (index == -1) {
/* 179 */       throw new IllegalArgumentException("Node does not exist");
/*     */     }
/* 181 */     internalInsertAt(node, index + 1, true, editGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertBefore(ASTNode node, ASTNode nextElement, TextEditGroup editGroup) {
/* 207 */     if (node == null || nextElement == null) {
/* 208 */       throw new IllegalArgumentException();
/*     */     }
/* 210 */     int index = getEvent().getIndex(nextElement, 3);
/* 211 */     if (index == -1) {
/* 212 */       throw new IllegalArgumentException("Node does not exist");
/*     */     }
/* 214 */     internalInsertAt(node, index, false, editGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertFirst(ASTNode node, TextEditGroup editGroup) {
/* 231 */     if (node == null) {
/* 232 */       throw new IllegalArgumentException();
/*     */     }
/* 234 */     internalInsertAt(node, 0, false, editGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertLast(ASTNode node, TextEditGroup editGroup) {
/* 251 */     if (node == null) {
/* 252 */       throw new IllegalArgumentException();
/*     */     }
/* 254 */     internalInsertAt(node, -1, true, editGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertAt(ASTNode node, int index, TextEditGroup editGroup) {
/* 282 */     if (node == null) {
/* 283 */       throw new IllegalArgumentException();
/*     */     }
/* 285 */     internalInsertAt(node, index, isInsertBoundToPreviousByDefault(node), editGroup);
/*     */   }
/*     */   
/*     */   private void internalInsertAt(ASTNode node, int index, boolean boundToPrevious, TextEditGroup editGroup) {
/* 289 */     validatePropertyType(node);
/* 290 */     RewriteEvent event = getEvent().insert(node, index);
/* 291 */     if (boundToPrevious) {
/* 292 */       getRewriteStore().setInsertBoundToPrevious(node);
/*     */     }
/* 294 */     if (editGroup != null) {
/* 295 */       getRewriteStore().setEventEditGroup(event, editGroup);
/*     */     }
/*     */   }
/*     */   
/*     */   private void validatePropertyType(ASTNode node) {
/* 300 */     if (!RewriteEventStore.DEBUG) {
/*     */       return;
/*     */     }
/* 303 */     if (!this.childListProperty.getElementType().isAssignableFrom(node.getClass())) {
/* 304 */       String message = String.valueOf(node.getClass().getName()) + " is not a valid type for " + this.childListProperty.getNodeClass().getName() + 
/* 305 */         " property '" + this.childListProperty.getId() + "'. Must be " + this.childListProperty.getElementType().getName();
/* 306 */       throw new IllegalArgumentException(message);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private ASTNode createTargetNode(ASTNode first, ASTNode last, boolean isMove, ASTNode replacingNode, TextEditGroup editGroup) {
/* 312 */     if (first == null || last == null) {
/* 313 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 316 */     NodeInfoStore nodeStore = this.rewriter.getNodeStore();
/* 317 */     ASTNode placeholder = nodeStore.newPlaceholderNode(first.getNodeType());
/* 318 */     if (placeholder == null) {
/* 319 */       throw new IllegalArgumentException("Creating a target node is not supported for nodes of type" + first.getClass().getName());
/*     */     }
/*     */     
/* 322 */     Block internalPlaceHolder = nodeStore.createCollapsePlaceholder();
/* 323 */     RewriteEventStore.CopySourceInfo info = getRewriteStore().createRangeCopy(this.parent, (StructuralPropertyDescriptor)this.childListProperty, first, last, isMove, (ASTNode)internalPlaceHolder, replacingNode, editGroup);
/* 324 */     nodeStore.markAsCopyTarget(placeholder, info);
/*     */     
/* 326 */     return placeholder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ASTNode createCopyTarget(ASTNode first, ASTNode last) {
/* 346 */     if (first == last) {
/* 347 */       return this.rewriter.createCopyTarget(first);
/*     */     }
/* 349 */     return createTargetNode(first, last, false, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ASTNode createMoveTarget(ASTNode first, ASTNode last) {
/* 372 */     return createMoveTarget(first, last, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ASTNode createMoveTarget(ASTNode first, ASTNode last, ASTNode replacingNode, TextEditGroup editGroup) {
/* 400 */     if (first == last) {
/* 401 */       replace(first, replacingNode, editGroup);
/* 402 */       return this.rewriter.createMoveTarget(first);
/*     */     } 
/* 404 */     return createTargetNode(first, last, true, replacingNode, editGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isInsertBoundToPreviousByDefault(ASTNode node) {
/* 412 */     return !(!(node instanceof org.eclipse.jdt.core.dom.Statement) && !(node instanceof org.eclipse.jdt.core.dom.FieldDeclaration));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getOriginalList() {
/* 422 */     List<?> list = (List)getEvent().getOriginalValue();
/* 423 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List getRewrittenList() {
/* 434 */     List<?> list = (List)getEvent().getNewValue();
/* 435 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\rewrite\ListRewrite.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */