/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ import org.eclipse.jdt.internal.compiler.ast.LocalDeclaration;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnLocalName
/*    */   extends LocalDeclaration
/*    */ {
/* 22 */   private static final char[] FAKENAMESUFFIX = " ".toCharArray();
/*    */   
/*    */   public char[] realName;
/*    */   
/*    */   public CompletionOnLocalName(char[] name, int sourceStart, int sourceEnd) {
/* 27 */     super(CharOperation.concat(name, FAKENAMESUFFIX), sourceStart, sourceEnd);
/* 28 */     this.realName = name;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void resolve(BlockScope scope) {
/* 34 */     super.resolve(scope);
/* 35 */     throw new CompletionNodeFound(this, scope);
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printAsExpression(int indent, StringBuffer output) {
/* 40 */     printIndent(indent, output);
/* 41 */     output.append("<CompleteOnLocalName:");
/* 42 */     if (this.type != null) this.type.print(0, output).append(' '); 
/* 43 */     output.append(this.realName);
/* 44 */     if (this.initialization != null) {
/* 45 */       output.append(" = ");
/* 46 */       this.initialization.printExpression(0, output);
/*    */     } 
/* 48 */     return output.append('>');
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printStatement(int indent, StringBuffer output) {
/* 53 */     printAsExpression(indent, output);
/* 54 */     return output.append(';');
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnLocalName.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */