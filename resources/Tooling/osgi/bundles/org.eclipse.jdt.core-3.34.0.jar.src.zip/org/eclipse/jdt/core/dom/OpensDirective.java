/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpensDirective
/*     */   extends ModulePackageAccess
/*     */ {
/*  37 */   public static final ChildPropertyDescriptor NAME_PROPERTY = internalNamePropertyFactory(OpensDirective.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  42 */   public static final ChildListPropertyDescriptor MODULES_PROPERTY = internalModulesPropertyFactory(OpensDirective.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_9_0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  52 */     List properyList = new ArrayList(3);
/*  53 */     createPropertyList(OpensDirective.class, properyList);
/*  54 */     addProperty(NAME_PROPERTY, properyList);
/*  55 */     addProperty(MODULES_PROPERTY, properyList);
/*  56 */     PROPERTY_DESCRIPTORS_9_0 = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  70 */     return PROPERTY_DESCRIPTORS_9_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OpensDirective(AST ast) {
/*  86 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  91 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalNameProperty() {
/*  96 */     return NAME_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalModulesProperty() {
/* 101 */     return MODULES_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 106 */     return 96;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 111 */     return cloneHelper(target, new OpensDirective(target));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 117 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 122 */     boolean visitChildren = visitor.visit(this);
/* 123 */     acceptVisitChildren(visitChildren, visitor);
/* 124 */     visitor.endVisit(this);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\OpensDirective.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */