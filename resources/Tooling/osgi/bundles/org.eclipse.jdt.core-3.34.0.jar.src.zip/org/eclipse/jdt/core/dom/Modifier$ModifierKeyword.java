/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModifierKeyword
/*     */ {
/*  62 */   public static final ModifierKeyword ABSTRACT_KEYWORD = new ModifierKeyword("abstract", 1024);
/*     */ 
/*     */   
/*  65 */   public static final ModifierKeyword FINAL_KEYWORD = new ModifierKeyword("final", 16);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Map KEYWORDS;
/*     */ 
/*     */ 
/*     */   
/*  74 */   public static final ModifierKeyword NATIVE_KEYWORD = new ModifierKeyword("native", 256);
/*     */ 
/*     */   
/*  77 */   public static final ModifierKeyword PRIVATE_KEYWORD = new ModifierKeyword("private", 2);
/*     */ 
/*     */   
/*  80 */   public static final ModifierKeyword PROTECTED_KEYWORD = new ModifierKeyword("protected", 4);
/*     */ 
/*     */   
/*  83 */   public static final ModifierKeyword PUBLIC_KEYWORD = new ModifierKeyword("public", 1);
/*     */ 
/*     */   
/*  86 */   public static final ModifierKeyword STATIC_KEYWORD = new ModifierKeyword("static", 8);
/*     */ 
/*     */   
/*  89 */   public static final ModifierKeyword STRICTFP_KEYWORD = new ModifierKeyword("strictfp", 2048);
/*     */ 
/*     */   
/*  92 */   public static final ModifierKeyword SYNCHRONIZED_KEYWORD = new ModifierKeyword("synchronized", 32);
/*     */ 
/*     */   
/*  95 */   public static final ModifierKeyword TRANSIENT_KEYWORD = new ModifierKeyword("transient", 128);
/*     */ 
/*     */   
/*  98 */   public static final ModifierKeyword VOLATILE_KEYWORD = new ModifierKeyword("volatile", 64);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public static final ModifierKeyword DEFAULT_KEYWORD = new ModifierKeyword("default", 65536);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public static final ModifierKeyword SEALED_KEYWORD = new ModifierKeyword("sealed", 512);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public static final ModifierKeyword WHEN_KEYWORD = new ModifierKeyword("when", 8192);
/*     */ 
/*     */ 
/*     */   
/* 122 */   public static final ModifierKeyword NON_SEALED_KEYWORD = new ModifierKeyword("non-sealed", 4096);
/*     */   
/*     */   static {
/* 125 */     KEYWORDS = new HashMap<>(20);
/* 126 */     ModifierKeyword[] ops = { 
/* 127 */         PUBLIC_KEYWORD, 
/* 128 */         PROTECTED_KEYWORD, 
/* 129 */         PRIVATE_KEYWORD, 
/* 130 */         STATIC_KEYWORD, 
/* 131 */         ABSTRACT_KEYWORD, 
/* 132 */         FINAL_KEYWORD, 
/* 133 */         NATIVE_KEYWORD, 
/* 134 */         SYNCHRONIZED_KEYWORD, 
/* 135 */         TRANSIENT_KEYWORD, 
/* 136 */         VOLATILE_KEYWORD, 
/* 137 */         STRICTFP_KEYWORD, 
/* 138 */         DEFAULT_KEYWORD, 
/* 139 */         SEALED_KEYWORD, 
/* 140 */         NON_SEALED_KEYWORD };
/*     */     
/* 142 */     for (int i = 0; i < ops.length; i++) {
/* 143 */       KEYWORDS.put(ops[i].toString(), ops[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int flagValue;
/*     */ 
/*     */ 
/*     */   
/*     */   private String keyword;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ModifierKeyword fromFlagValue(int flagValue) {
/* 161 */     for (Iterator<ModifierKeyword> it = KEYWORDS.values().iterator(); it.hasNext(); ) {
/* 162 */       ModifierKeyword k = it.next();
/* 163 */       if (k.toFlagValue() == flagValue) {
/* 164 */         return k;
/*     */       }
/*     */     } 
/* 167 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ModifierKeyword toKeyword(String keyword) {
/* 184 */     return (ModifierKeyword)KEYWORDS.get(keyword);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ModifierKeyword(String keyword, int flagValue) {
/* 208 */     this.keyword = keyword;
/* 209 */     this.flagValue = flagValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int toFlagValue() {
/* 220 */     return this.flagValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 231 */     return this.keyword;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\Modifier$ModifierKeyword.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */