/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RecoveredVariableBinding
/*     */   implements IVariableBinding
/*     */ {
/*     */   private VariableDeclaration variableDeclaration;
/*     */   private BindingResolver resolver;
/*     */   
/*     */   RecoveredVariableBinding(BindingResolver resolver, VariableDeclaration variableDeclaration) {
/*  27 */     this.resolver = resolver;
/*  28 */     this.variableDeclaration = variableDeclaration;
/*     */   }
/*     */   
/*     */   public Object getConstantValue() {
/*  32 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding getDeclaringClass() {
/*  37 */     ASTNode parent = this.variableDeclaration.getParent();
/*  38 */     while (parent != null && parent.getNodeType() != 55) {
/*  39 */       parent = parent.getParent();
/*     */     }
/*  41 */     if (parent != null) {
/*  42 */       return ((TypeDeclaration)parent).resolveBinding();
/*     */     }
/*  44 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IMethodBinding getDeclaringMethod() {
/*  49 */     ASTNode parent = this.variableDeclaration.getParent();
/*  50 */     while (parent != null && parent.getNodeType() != 31) {
/*  51 */       parent = parent.getParent();
/*     */     }
/*  53 */     if (parent != null) {
/*  54 */       return ((MethodDeclaration)parent).resolveBinding();
/*     */     }
/*  56 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  61 */     return this.variableDeclaration.getName().getIdentifier();
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding getType() {
/*  66 */     return this.resolver.getTypeBinding(this.variableDeclaration);
/*     */   }
/*     */ 
/*     */   
/*     */   public IVariableBinding getVariableDeclaration() {
/*  71 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getVariableId() {
/*  76 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnumConstant() {
/*  81 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isField() {
/*  86 */     return this.variableDeclaration.getParent() instanceof FieldDeclaration;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isParameter() {
/*  91 */     return this.variableDeclaration instanceof SingleVariableDeclaration;
/*     */   }
/*     */ 
/*     */   
/*     */   public IAnnotationBinding[] getAnnotations() {
/*  96 */     return (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public IJavaElement getJavaElement() {
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 106 */     StringBuffer buffer = new StringBuffer();
/* 107 */     buffer.append("Recovered#");
/* 108 */     if (this.variableDeclaration != null) {
/* 109 */       buffer
/* 110 */         .append("variableDeclaration")
/* 111 */         .append(this.variableDeclaration.getClass())
/* 112 */         .append(this.variableDeclaration.getName().getIdentifier())
/* 113 */         .append(this.variableDeclaration.getExtraDimensions());
/*     */     }
/* 115 */     return String.valueOf(buffer);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getKind() {
/* 120 */     return 3;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 125 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDeprecated() {
/* 130 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEqualTo(IBinding binding) {
/* 135 */     if (binding.isRecovered() && binding.getKind() == 3) {
/* 136 */       return getKey().equals(binding.getKey());
/*     */     }
/* 138 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRecovered() {
/* 143 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSynthetic() {
/* 148 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isEffectivelyFinal() {
/* 152 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\RecoveredVariableBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */