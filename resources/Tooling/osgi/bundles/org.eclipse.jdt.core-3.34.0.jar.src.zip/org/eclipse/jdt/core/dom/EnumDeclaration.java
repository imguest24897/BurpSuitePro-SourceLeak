/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnumDeclaration
/*     */   extends AbstractTypeDeclaration
/*     */ {
/*  54 */   public static final ChildPropertyDescriptor JAVADOC_PROPERTY = internalJavadocPropertyFactory(EnumDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public static final ChildListPropertyDescriptor MODIFIERS2_PROPERTY = internalModifiers2PropertyFactory(EnumDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public static final ChildPropertyDescriptor NAME_PROPERTY = internalNamePropertyFactory(EnumDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public static final ChildListPropertyDescriptor SUPER_INTERFACE_TYPES_PROPERTY = new ChildListPropertyDescriptor(EnumDeclaration.class, "superInterfaceTypes", Type.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public static final ChildListPropertyDescriptor ENUM_CONSTANTS_PROPERTY = new ChildListPropertyDescriptor(EnumDeclaration.class, "enumConstants", EnumConstantDeclaration.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   public static final ChildListPropertyDescriptor BODY_DECLARATIONS_PROPERTY = internalBodyDeclarationPropertyFactory(EnumDeclaration.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  94 */     List properyList = new ArrayList(6);
/*  95 */     createPropertyList(EnumDeclaration.class, properyList);
/*  96 */     addProperty(JAVADOC_PROPERTY, properyList);
/*  97 */     addProperty(MODIFIERS2_PROPERTY, properyList);
/*  98 */     addProperty(NAME_PROPERTY, properyList);
/*  99 */     addProperty(SUPER_INTERFACE_TYPES_PROPERTY, properyList);
/* 100 */     addProperty(ENUM_CONSTANTS_PROPERTY, properyList);
/* 101 */     addProperty(BODY_DECLARATIONS_PROPERTY, properyList);
/* 102 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 116 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   private ASTNode.NodeList superInterfaceTypes = new ASTNode.NodeList(this, SUPER_INTERFACE_TYPES_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   private ASTNode.NodeList enumConstants = new ASTNode.NodeList(this, ENUM_CONSTANTS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   EnumDeclaration(AST ast) {
/* 148 */     super(ast);
/* 149 */     unsupportedIn2();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 154 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 159 */     if (property == JAVADOC_PROPERTY) {
/* 160 */       if (get) {
/* 161 */         return getJavadoc();
/*     */       }
/* 163 */       setJavadoc((Javadoc)child);
/* 164 */       return null;
/*     */     } 
/*     */     
/* 167 */     if (property == NAME_PROPERTY) {
/* 168 */       if (get) {
/* 169 */         return getName();
/*     */       }
/* 171 */       setName((SimpleName)child);
/* 172 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 176 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 181 */     if (property == MODIFIERS2_PROPERTY) {
/* 182 */       return modifiers();
/*     */     }
/* 184 */     if (property == SUPER_INTERFACE_TYPES_PROPERTY) {
/* 185 */       return superInterfaceTypes();
/*     */     }
/* 187 */     if (property == ENUM_CONSTANTS_PROPERTY) {
/* 188 */       return enumConstants();
/*     */     }
/* 190 */     if (property == BODY_DECLARATIONS_PROPERTY) {
/* 191 */       return bodyDeclarations();
/*     */     }
/*     */     
/* 194 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalJavadocProperty() {
/* 199 */     return JAVADOC_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalModifiers2Property() {
/* 204 */     return MODIFIERS2_PROPERTY;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final SimplePropertyDescriptor internalModifiersProperty() {
/* 210 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalNameProperty() {
/* 215 */     return NAME_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalBodyDeclarationsProperty() {
/* 220 */     return BODY_DECLARATIONS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 225 */     return 71;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 230 */     EnumDeclaration result = new EnumDeclaration(target);
/* 231 */     result.setSourceRange(getStartPosition(), getLength());
/* 232 */     result.setJavadoc(
/* 233 */         (Javadoc)ASTNode.copySubtree(target, getJavadoc()));
/* 234 */     result.modifiers().addAll(ASTNode.copySubtrees(target, modifiers()));
/* 235 */     result.setName((SimpleName)getName().clone(target));
/* 236 */     result.superInterfaceTypes().addAll(
/* 237 */         ASTNode.copySubtrees(target, superInterfaceTypes()));
/* 238 */     result.enumConstants().addAll(
/* 239 */         ASTNode.copySubtrees(target, enumConstants()));
/* 240 */     result.bodyDeclarations().addAll(
/* 241 */         ASTNode.copySubtrees(target, bodyDeclarations()));
/* 242 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 248 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 253 */     boolean visitChildren = visitor.visit(this);
/* 254 */     if (visitChildren) {
/*     */       
/* 256 */       acceptChild(visitor, getJavadoc());
/* 257 */       acceptChildren(visitor, this.modifiers);
/* 258 */       acceptChild(visitor, getName());
/* 259 */       acceptChildren(visitor, this.superInterfaceTypes);
/* 260 */       acceptChildren(visitor, this.enumConstants);
/* 261 */       acceptChildren(visitor, this.bodyDeclarations);
/*     */     } 
/* 263 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List superInterfaceTypes() {
/* 274 */     return this.superInterfaceTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List enumConstants() {
/* 285 */     return this.enumConstants;
/*     */   }
/*     */ 
/*     */   
/*     */   ITypeBinding internalResolveBinding() {
/* 290 */     return this.ast.getBindingResolver().resolveType(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 295 */     return super.memSize() + 8;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 300 */     return memSize() + (
/* 301 */       (this.optionalDocComment == null) ? 0 : getJavadoc().treeSize()) + 
/* 302 */       this.modifiers.listSize() + (
/* 303 */       (this.typeName == null) ? 0 : getName().treeSize()) + 
/* 304 */       this.superInterfaceTypes.listSize() + 
/* 305 */       this.enumConstants.listSize() + 
/* 306 */       this.bodyDeclarations.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\EnumDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */