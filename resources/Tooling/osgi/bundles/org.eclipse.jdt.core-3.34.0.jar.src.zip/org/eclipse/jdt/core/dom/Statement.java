/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Statement
/*     */   extends ASTNode
/*     */ {
/*  62 */   private String optionalLeadingComment = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Statement(AST ast) {
/*  73 */     super(ast);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLeadingComment() {
/*  99 */     return this.optionalLeadingComment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLeadingComment(String comment) {
/* 134 */     if (comment != null) {
/* 135 */       char[] source = comment.toCharArray();
/* 136 */       Scanner scanner = this.ast.scanner;
/* 137 */       scanner.resetTo(0, source.length);
/* 138 */       scanner.setSource(source);
/*     */       
/*     */       try {
/* 141 */         boolean onlyOneComment = false; int token;
/* 142 */         while ((token = scanner.getNextToken()) != 64) {
/* 143 */           switch (token) {
/*     */             case 1001:
/*     */             case 1002:
/*     */             case 1003:
/* 147 */               if (onlyOneComment) {
/* 148 */                 throw new IllegalArgumentException();
/*     */               }
/* 150 */               onlyOneComment = true;
/*     */               continue;
/*     */           } 
/* 153 */           onlyOneComment = false;
/*     */         } 
/*     */         
/* 156 */         if (!onlyOneComment) {
/* 157 */           throw new IllegalArgumentException();
/*     */         }
/* 159 */       } catch (InvalidInputException e) {
/* 160 */         InvalidInputException invalidInputException1; throw new IllegalArgumentException(invalidInputException1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 165 */     checkModifiable();
/* 166 */     this.optionalLeadingComment = comment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void copyLeadingComment(Statement source) {
/* 176 */     setLeadingComment(source.getLeadingComment());
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 181 */     int size = 44 + stringSize(getLeadingComment());
/* 182 */     return size;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\Statement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */