/*    */ package org.eclipse.jdt.core.dom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SimplePropertyDescriptor
/*    */   extends StructuralPropertyDescriptor
/*    */ {
/*    */   private final Class valueType;
/*    */   private final boolean mandatory;
/*    */   
/*    */   SimplePropertyDescriptor(Class nodeClass, String propertyId, Class<?> valueType, boolean mandatory) {
/* 56 */     super(nodeClass, propertyId);
/* 57 */     if (valueType == null || ASTNode.class.isAssignableFrom(valueType)) {
/* 58 */       throw new IllegalArgumentException();
/*    */     }
/* 60 */     this.valueType = valueType;
/* 61 */     this.mandatory = mandatory;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class getValueType() {
/* 74 */     return this.valueType;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isMandatory() {
/* 85 */     return this.mandatory;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\SimplePropertyDescriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */