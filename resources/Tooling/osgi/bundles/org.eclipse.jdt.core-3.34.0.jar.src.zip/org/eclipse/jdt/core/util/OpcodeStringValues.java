/*     */ package org.eclipse.jdt.core.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpcodeStringValues
/*     */   implements IOpcodeMnemonics
/*     */ {
/*  25 */   public static final String[] BYTECODE_NAMES = new String[256];
/*     */   static {
/*  27 */     BYTECODE_NAMES[0] = "nop";
/*  28 */     BYTECODE_NAMES[1] = "aconst_null";
/*  29 */     BYTECODE_NAMES[2] = "iconst_m1";
/*  30 */     BYTECODE_NAMES[3] = "iconst_0";
/*  31 */     BYTECODE_NAMES[4] = "iconst_1";
/*  32 */     BYTECODE_NAMES[5] = "iconst_2";
/*  33 */     BYTECODE_NAMES[6] = "iconst_3";
/*  34 */     BYTECODE_NAMES[7] = "iconst_4";
/*  35 */     BYTECODE_NAMES[8] = "iconst_5";
/*  36 */     BYTECODE_NAMES[9] = "lconst_0";
/*  37 */     BYTECODE_NAMES[10] = "lconst_1";
/*  38 */     BYTECODE_NAMES[11] = "fconst_0";
/*  39 */     BYTECODE_NAMES[12] = "fconst_1";
/*  40 */     BYTECODE_NAMES[13] = "fconst_2";
/*  41 */     BYTECODE_NAMES[14] = "dconst_0";
/*  42 */     BYTECODE_NAMES[15] = "dconst_1";
/*  43 */     BYTECODE_NAMES[16] = "bipush";
/*  44 */     BYTECODE_NAMES[17] = "sipush";
/*  45 */     BYTECODE_NAMES[18] = "ldc";
/*  46 */     BYTECODE_NAMES[19] = "ldc_w";
/*  47 */     BYTECODE_NAMES[20] = "ldc2_w";
/*  48 */     BYTECODE_NAMES[21] = "iload";
/*  49 */     BYTECODE_NAMES[22] = "lload";
/*  50 */     BYTECODE_NAMES[23] = "fload";
/*  51 */     BYTECODE_NAMES[24] = "dload";
/*  52 */     BYTECODE_NAMES[25] = "aload";
/*  53 */     BYTECODE_NAMES[26] = "iload_0";
/*  54 */     BYTECODE_NAMES[27] = "iload_1";
/*  55 */     BYTECODE_NAMES[28] = "iload_2";
/*  56 */     BYTECODE_NAMES[29] = "iload_3";
/*  57 */     BYTECODE_NAMES[30] = "lload_0";
/*  58 */     BYTECODE_NAMES[31] = "lload_1";
/*  59 */     BYTECODE_NAMES[32] = "lload_2";
/*  60 */     BYTECODE_NAMES[33] = "lload_3";
/*  61 */     BYTECODE_NAMES[34] = "fload_0";
/*  62 */     BYTECODE_NAMES[35] = "fload_1";
/*  63 */     BYTECODE_NAMES[36] = "fload_2";
/*  64 */     BYTECODE_NAMES[37] = "fload_3";
/*  65 */     BYTECODE_NAMES[38] = "dload_0";
/*  66 */     BYTECODE_NAMES[39] = "dload_1";
/*  67 */     BYTECODE_NAMES[40] = "dload_2";
/*  68 */     BYTECODE_NAMES[41] = "dload_3";
/*  69 */     BYTECODE_NAMES[42] = "aload_0";
/*  70 */     BYTECODE_NAMES[43] = "aload_1";
/*  71 */     BYTECODE_NAMES[44] = "aload_2";
/*  72 */     BYTECODE_NAMES[45] = "aload_3";
/*  73 */     BYTECODE_NAMES[46] = "iaload";
/*  74 */     BYTECODE_NAMES[47] = "laload";
/*  75 */     BYTECODE_NAMES[48] = "faload";
/*  76 */     BYTECODE_NAMES[49] = "daload";
/*  77 */     BYTECODE_NAMES[50] = "aaload";
/*  78 */     BYTECODE_NAMES[51] = "baload";
/*  79 */     BYTECODE_NAMES[52] = "caload";
/*  80 */     BYTECODE_NAMES[53] = "saload";
/*  81 */     BYTECODE_NAMES[54] = "istore";
/*  82 */     BYTECODE_NAMES[55] = "lstore";
/*  83 */     BYTECODE_NAMES[56] = "fstore";
/*  84 */     BYTECODE_NAMES[57] = "dstore";
/*  85 */     BYTECODE_NAMES[58] = "astore";
/*  86 */     BYTECODE_NAMES[59] = "istore_0";
/*  87 */     BYTECODE_NAMES[60] = "istore_1";
/*  88 */     BYTECODE_NAMES[61] = "istore_2";
/*  89 */     BYTECODE_NAMES[62] = "istore_3";
/*  90 */     BYTECODE_NAMES[63] = "lstore_0";
/*  91 */     BYTECODE_NAMES[64] = "lstore_1";
/*  92 */     BYTECODE_NAMES[65] = "lstore_2";
/*  93 */     BYTECODE_NAMES[66] = "lstore_3";
/*  94 */     BYTECODE_NAMES[67] = "fstore_0";
/*  95 */     BYTECODE_NAMES[68] = "fstore_1";
/*  96 */     BYTECODE_NAMES[69] = "fstore_2";
/*  97 */     BYTECODE_NAMES[70] = "fstore_3";
/*  98 */     BYTECODE_NAMES[71] = "dstore_0";
/*  99 */     BYTECODE_NAMES[72] = "dstore_1";
/* 100 */     BYTECODE_NAMES[73] = "dstore_2";
/* 101 */     BYTECODE_NAMES[74] = "dstore_3";
/* 102 */     BYTECODE_NAMES[75] = "astore_0";
/* 103 */     BYTECODE_NAMES[76] = "astore_1";
/* 104 */     BYTECODE_NAMES[77] = "astore_2";
/* 105 */     BYTECODE_NAMES[78] = "astore_3";
/* 106 */     BYTECODE_NAMES[79] = "iastore";
/* 107 */     BYTECODE_NAMES[80] = "lastore";
/* 108 */     BYTECODE_NAMES[81] = "fastore";
/* 109 */     BYTECODE_NAMES[82] = "dastore";
/* 110 */     BYTECODE_NAMES[83] = "aastore";
/* 111 */     BYTECODE_NAMES[84] = "bastore";
/* 112 */     BYTECODE_NAMES[85] = "castore";
/* 113 */     BYTECODE_NAMES[86] = "sastore";
/* 114 */     BYTECODE_NAMES[87] = "pop";
/* 115 */     BYTECODE_NAMES[88] = "pop2";
/* 116 */     BYTECODE_NAMES[89] = "dup";
/* 117 */     BYTECODE_NAMES[90] = "dup_x1";
/* 118 */     BYTECODE_NAMES[91] = "dup_x2";
/* 119 */     BYTECODE_NAMES[92] = "dup2";
/* 120 */     BYTECODE_NAMES[93] = "dup2_x1";
/* 121 */     BYTECODE_NAMES[94] = "dup2_x2";
/* 122 */     BYTECODE_NAMES[95] = "swap";
/* 123 */     BYTECODE_NAMES[96] = "iadd";
/* 124 */     BYTECODE_NAMES[97] = "ladd";
/* 125 */     BYTECODE_NAMES[98] = "fadd";
/* 126 */     BYTECODE_NAMES[99] = "dadd";
/* 127 */     BYTECODE_NAMES[100] = "isub";
/* 128 */     BYTECODE_NAMES[101] = "lsub";
/* 129 */     BYTECODE_NAMES[102] = "fsub";
/* 130 */     BYTECODE_NAMES[103] = "dsub";
/* 131 */     BYTECODE_NAMES[104] = "imul";
/* 132 */     BYTECODE_NAMES[105] = "lmul";
/* 133 */     BYTECODE_NAMES[106] = "fmul";
/* 134 */     BYTECODE_NAMES[107] = "dmul";
/* 135 */     BYTECODE_NAMES[108] = "idiv";
/* 136 */     BYTECODE_NAMES[109] = "ldiv";
/* 137 */     BYTECODE_NAMES[110] = "fdiv";
/* 138 */     BYTECODE_NAMES[111] = "ddiv";
/* 139 */     BYTECODE_NAMES[112] = "irem";
/* 140 */     BYTECODE_NAMES[113] = "lrem";
/* 141 */     BYTECODE_NAMES[114] = "frem";
/* 142 */     BYTECODE_NAMES[115] = "drem";
/* 143 */     BYTECODE_NAMES[116] = "ineg";
/* 144 */     BYTECODE_NAMES[117] = "lneg";
/* 145 */     BYTECODE_NAMES[118] = "fneg";
/* 146 */     BYTECODE_NAMES[119] = "dneg";
/* 147 */     BYTECODE_NAMES[120] = "ishl";
/* 148 */     BYTECODE_NAMES[121] = "lshl";
/* 149 */     BYTECODE_NAMES[122] = "ishr";
/* 150 */     BYTECODE_NAMES[123] = "lshr";
/* 151 */     BYTECODE_NAMES[124] = "iushr";
/* 152 */     BYTECODE_NAMES[125] = "lushr";
/* 153 */     BYTECODE_NAMES[126] = "iand";
/* 154 */     BYTECODE_NAMES[127] = "land";
/* 155 */     BYTECODE_NAMES[128] = "ior";
/* 156 */     BYTECODE_NAMES[129] = "lor";
/* 157 */     BYTECODE_NAMES[130] = "ixor";
/* 158 */     BYTECODE_NAMES[131] = "lxor";
/* 159 */     BYTECODE_NAMES[132] = "iinc";
/* 160 */     BYTECODE_NAMES[133] = "i2l";
/* 161 */     BYTECODE_NAMES[134] = "i2f";
/* 162 */     BYTECODE_NAMES[135] = "i2d";
/* 163 */     BYTECODE_NAMES[136] = "l2i";
/* 164 */     BYTECODE_NAMES[137] = "l2f";
/* 165 */     BYTECODE_NAMES[138] = "l2d";
/* 166 */     BYTECODE_NAMES[139] = "f2i";
/* 167 */     BYTECODE_NAMES[140] = "f2l";
/* 168 */     BYTECODE_NAMES[141] = "f2d";
/* 169 */     BYTECODE_NAMES[142] = "d2i";
/* 170 */     BYTECODE_NAMES[143] = "d2l";
/* 171 */     BYTECODE_NAMES[144] = "d2f";
/* 172 */     BYTECODE_NAMES[145] = "i2b";
/* 173 */     BYTECODE_NAMES[146] = "i2c";
/* 174 */     BYTECODE_NAMES[147] = "i2s";
/* 175 */     BYTECODE_NAMES[148] = "lcmp";
/* 176 */     BYTECODE_NAMES[149] = "fcmpl";
/* 177 */     BYTECODE_NAMES[150] = "fcmpg";
/* 178 */     BYTECODE_NAMES[151] = "dcmpl";
/* 179 */     BYTECODE_NAMES[152] = "dcmpg";
/* 180 */     BYTECODE_NAMES[153] = "ifeq";
/* 181 */     BYTECODE_NAMES[154] = "ifne";
/* 182 */     BYTECODE_NAMES[155] = "iflt";
/* 183 */     BYTECODE_NAMES[156] = "ifge";
/* 184 */     BYTECODE_NAMES[157] = "ifgt";
/* 185 */     BYTECODE_NAMES[158] = "ifle";
/* 186 */     BYTECODE_NAMES[159] = "if_icmpeq";
/* 187 */     BYTECODE_NAMES[160] = "if_icmpne";
/* 188 */     BYTECODE_NAMES[161] = "if_icmplt";
/* 189 */     BYTECODE_NAMES[162] = "if_icmpge";
/* 190 */     BYTECODE_NAMES[163] = "if_icmpgt";
/* 191 */     BYTECODE_NAMES[164] = "if_icmple";
/* 192 */     BYTECODE_NAMES[165] = "if_acmpeq";
/* 193 */     BYTECODE_NAMES[166] = "if_acmpne";
/* 194 */     BYTECODE_NAMES[167] = "goto";
/* 195 */     BYTECODE_NAMES[168] = "jsr";
/* 196 */     BYTECODE_NAMES[169] = "ret";
/* 197 */     BYTECODE_NAMES[170] = "tableswitch";
/* 198 */     BYTECODE_NAMES[171] = "lookupswitch";
/* 199 */     BYTECODE_NAMES[172] = "ireturn";
/* 200 */     BYTECODE_NAMES[173] = "lreturn";
/* 201 */     BYTECODE_NAMES[174] = "freturn";
/* 202 */     BYTECODE_NAMES[175] = "dreturn";
/* 203 */     BYTECODE_NAMES[176] = "areturn";
/* 204 */     BYTECODE_NAMES[177] = "return";
/* 205 */     BYTECODE_NAMES[178] = "getstatic";
/* 206 */     BYTECODE_NAMES[179] = "putstatic";
/* 207 */     BYTECODE_NAMES[180] = "getfield";
/* 208 */     BYTECODE_NAMES[181] = "putfield";
/* 209 */     BYTECODE_NAMES[182] = "invokevirtual";
/* 210 */     BYTECODE_NAMES[183] = "invokespecial";
/* 211 */     BYTECODE_NAMES[184] = "invokestatic";
/* 212 */     BYTECODE_NAMES[185] = "invokeinterface";
/* 213 */     BYTECODE_NAMES[186] = "invokedynamic";
/* 214 */     BYTECODE_NAMES[187] = "new";
/* 215 */     BYTECODE_NAMES[188] = "newarray";
/* 216 */     BYTECODE_NAMES[189] = "anewarray";
/* 217 */     BYTECODE_NAMES[190] = "arraylength";
/* 218 */     BYTECODE_NAMES[191] = "athrow";
/* 219 */     BYTECODE_NAMES[192] = "checkcast";
/* 220 */     BYTECODE_NAMES[193] = "instanceof";
/* 221 */     BYTECODE_NAMES[194] = "monitorenter";
/* 222 */     BYTECODE_NAMES[195] = "monitorexit";
/* 223 */     BYTECODE_NAMES[196] = "wide";
/* 224 */     BYTECODE_NAMES[197] = "multianewarray";
/* 225 */     BYTECODE_NAMES[198] = "ifnull";
/* 226 */     BYTECODE_NAMES[199] = "ifnonnull";
/* 227 */     BYTECODE_NAMES[200] = "goto_w";
/* 228 */     BYTECODE_NAMES[201] = "jsr_w";
/* 229 */     BYTECODE_NAMES[202] = "breakpoint";
/* 230 */     BYTECODE_NAMES[254] = "impdep1";
/* 231 */     BYTECODE_NAMES[255] = "impdep2";
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\cor\\util\OpcodeStringValues.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */