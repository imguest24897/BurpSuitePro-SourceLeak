/*     */ package org.eclipse.jdt.core.search;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.jdt.internal.core.JavaModel;
/*     */ import org.eclipse.jdt.internal.core.JavaModelManager;
/*     */ import org.eclipse.jdt.internal.core.index.FileIndexLocation;
/*     */ import org.eclipse.jdt.internal.core.index.IndexLocation;
/*     */ import org.eclipse.jdt.internal.core.search.indexing.IndexManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SearchParticipant
/*     */ {
/*     */   private IPath lastIndexLocation;
/*     */   
/*     */   public void beginSearching() {}
/*     */   
/*     */   public void doneSearching() {}
/*     */   
/*     */   public String getDescription() {
/*  98 */     return "Search participant";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract SearchDocument getDocument(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void indexDocument(SearchDocument paramSearchDocument, IPath paramIPath);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void indexResolvedDocument(SearchDocument document, IPath indexLocation) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void locateMatches(SearchDocument[] paramArrayOfSearchDocument, SearchPattern paramSearchPattern, IJavaSearchScope paramIJavaSearchScope, SearchRequestor paramSearchRequestor, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeIndex(IPath indexLocation) {
/* 210 */     IndexManager manager = JavaModelManager.getIndexManager();
/* 211 */     manager.removeIndexPath(indexLocation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolveDocument(SearchDocument document) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void scheduleDocumentIndexing(SearchDocument document, IPath indexPath) {
/*     */     IPath iPath;
/* 249 */     Path path1 = new Path(document.getPath());
/* 250 */     Object file = JavaModel.getTarget((IPath)path1, true);
/* 251 */     Path path2 = path1;
/* 252 */     if (file instanceof IResource) {
/* 253 */       iPath = ((IResource)file).getProject().getFullPath();
/* 254 */     } else if (file == null) {
/* 255 */       iPath = path1.removeLastSegments(1);
/*     */     } 
/* 257 */     IndexManager manager = JavaModelManager.getIndexManager();
/*     */ 
/*     */     
/* 260 */     FileIndexLocation fileIndexLocation = new FileIndexLocation(indexPath.toFile(), true);
/* 261 */     manager.ensureIndexExists((IndexLocation)fileIndexLocation, iPath);
/* 262 */     manager.scheduleDocumentIndexing(document, iPath, (IndexLocation)fileIndexLocation, this);
/* 263 */     if (!indexPath.equals(this.lastIndexLocation)) {
/* 264 */       manager.updateParticipant(indexPath, iPath);
/* 265 */       this.lastIndexLocation = indexPath;
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract IPath[] selectIndexes(SearchPattern paramSearchPattern, IJavaSearchScope paramIJavaSearchScope);
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\search\SearchParticipant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */