/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*     */ import org.eclipse.jdt.internal.compiler.parser.ScannerHelper;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharacterLiteral
/*     */   extends Expression
/*     */ {
/*  40 */   public static final SimplePropertyDescriptor ESCAPED_VALUE_PROPERTY = new SimplePropertyDescriptor(CharacterLiteral.class, "escapedValue", String.class, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  50 */     List properyList = new ArrayList(2);
/*  51 */     createPropertyList(CharacterLiteral.class, properyList);
/*  52 */     addProperty(ESCAPED_VALUE_PROPERTY, properyList);
/*  53 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  68 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   private String escapedValue = "'X'";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CharacterLiteral(AST ast) {
/*  87 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  92 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final Object internalGetSetObjectProperty(SimplePropertyDescriptor property, boolean get, Object value) {
/*  97 */     if (property == ESCAPED_VALUE_PROPERTY) {
/*  98 */       if (get) {
/*  99 */         return getEscapedValue();
/*     */       }
/* 101 */       setEscapedValue((String)value);
/* 102 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 106 */     return super.internalGetSetObjectProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 111 */     return 13;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 116 */     CharacterLiteral result = new CharacterLiteral(target);
/* 117 */     result.setSourceRange(getStartPosition(), getLength());
/* 118 */     result.setEscapedValue(getEscapedValue());
/* 119 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 125 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 130 */     visitor.visit(this);
/* 131 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEscapedValue() {
/* 143 */     return this.escapedValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEscapedValue(String value) {
/* 161 */     if (value == null) {
/* 162 */       throw new IllegalArgumentException();
/*     */     }
/* 164 */     Scanner scanner = this.ast.scanner;
/* 165 */     char[] source = value.toCharArray();
/* 166 */     scanner.setSource(source);
/* 167 */     scanner.resetTo(0, source.length);
/*     */     try {
/* 169 */       int tokenType = scanner.getNextToken();
/* 170 */       switch (tokenType) {
/*     */         case 59:
/*     */           break;
/*     */         default:
/* 174 */           throw new IllegalArgumentException();
/*     */       } 
/* 176 */     } catch (InvalidInputException invalidInputException) {
/* 177 */       throw new IllegalArgumentException();
/*     */     } 
/* 179 */     preValueChange(ESCAPED_VALUE_PROPERTY);
/* 180 */     this.escapedValue = value;
/* 181 */     postValueChange(ESCAPED_VALUE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void internalSetEscapedValue(String value) {
/* 189 */     preValueChange(ESCAPED_VALUE_PROPERTY);
/* 190 */     this.escapedValue = value;
/* 191 */     postValueChange(ESCAPED_VALUE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char charValue() {
/* 209 */     Scanner scanner = this.ast.scanner;
/* 210 */     char[] source = this.escapedValue.toCharArray();
/* 211 */     scanner.setSource(source);
/* 212 */     scanner.resetTo(0, source.length);
/* 213 */     int firstChar = scanner.getNextChar();
/* 214 */     int secondChar = scanner.getNextChar();
/*     */     
/* 216 */     if (firstChar == -1 || firstChar != 39) {
/* 217 */       throw new IllegalArgumentException("illegal character literal");
/*     */     }
/* 219 */     char value = (char)secondChar;
/* 220 */     int nextChar = scanner.getNextChar();
/* 221 */     if (secondChar == 92) {
/* 222 */       if (nextChar == -1) {
/* 223 */         throw new IllegalArgumentException("illegal character literal");
/*     */       }
/* 225 */       switch (nextChar) {
/*     */         case 98:
/* 227 */           value = '\b';
/*     */           break;
/*     */         case 116:
/* 230 */           value = '\t';
/*     */           break;
/*     */         case 110:
/* 233 */           value = '\n';
/*     */           break;
/*     */         case 102:
/* 236 */           value = '\f';
/*     */           break;
/*     */         case 114:
/* 239 */           value = '\r';
/*     */           break;
/*     */         case 34:
/* 242 */           value = '"';
/*     */           break;
/*     */         case 39:
/* 245 */           value = '\'';
/*     */           break;
/*     */         case 92:
/* 248 */           value = '\\';
/*     */           break;
/*     */         default:
/*     */           try {
/* 252 */             if (ScannerHelper.isDigit((char)nextChar)) {
/* 253 */               int number = ScannerHelper.getNumericValue((char)nextChar);
/* 254 */               nextChar = scanner.getNextChar();
/* 255 */               if (nextChar == -1) {
/* 256 */                 throw new IllegalArgumentException("illegal character literal");
/*     */               }
/* 258 */               if (nextChar != 39) {
/* 259 */                 if (!ScannerHelper.isDigit((char)nextChar)) {
/* 260 */                   throw new IllegalArgumentException("illegal character literal");
/*     */                 }
/* 262 */                 number = number * 8 + ScannerHelper.getNumericValue((char)nextChar);
/* 263 */                 nextChar = scanner.getNextChar();
/* 264 */                 if (nextChar == -1) {
/* 265 */                   throw new IllegalArgumentException("illegal character literal");
/*     */                 }
/* 267 */                 if (nextChar != 39) {
/* 268 */                   if (!ScannerHelper.isDigit((char)nextChar)) {
/* 269 */                     throw new IllegalArgumentException("illegal character literal");
/*     */                   }
/* 271 */                   number = number * 8 + ScannerHelper.getNumericValue((char)nextChar);
/*     */                 } 
/*     */               } 
/* 274 */               return (char)number;
/*     */             } 
/* 276 */             throw new IllegalArgumentException("illegal character literal");
/*     */           }
/* 278 */           catch (InvalidInputException e) {
/* 279 */             throw new IllegalArgumentException("illegal character literal", e);
/*     */           } 
/*     */       } 
/* 282 */       nextChar = scanner.getNextChar();
/* 283 */       if (nextChar == -1) {
/* 284 */         throw new IllegalArgumentException("illegal character literal");
/*     */       }
/*     */     } 
/* 287 */     if (nextChar == -1 || nextChar != 39) {
/* 288 */       throw new IllegalArgumentException("illegal character literal");
/*     */     }
/* 290 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCharValue(char value) {
/* 306 */     StringBuffer b = new StringBuffer(3);
/*     */     
/* 308 */     b.append('\'');
/* 309 */     Util.appendEscapedChar(b, value, false);
/* 310 */     b.append('\'');
/* 311 */     setEscapedValue(b.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 316 */     int size = 44 + stringSize(this.escapedValue);
/* 317 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 322 */     return memSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\CharacterLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */