/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*    */ import org.eclipse.jdt.internal.compiler.ast.NameReference;
/*    */ import org.eclipse.jdt.internal.compiler.ast.QualifiedNameReference;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.InvocationSite;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnQualifiedNameReference
/*    */   extends QualifiedNameReference
/*    */ {
/*    */   public char[] completionIdentifier;
/*    */   public boolean isInsideAnnotationAttribute;
/*    */   
/*    */   public CompletionOnQualifiedNameReference(char[][] previousIdentifiers, char[] completionIdentifier, long[] positions, boolean isInsideAnnotationAttribute) {
/* 46 */     super(previousIdentifiers, positions, (int)(positions[0] >>> 32L), (int)positions[positions.length - 1]);
/* 47 */     this.completionIdentifier = completionIdentifier;
/* 48 */     this.isInsideAnnotationAttribute = isInsideAnnotationAttribute;
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 53 */     output.append("<CompleteOnName:");
/* 54 */     for (int i = 0; i < this.tokens.length; i++) {
/* 55 */       output.append(this.tokens[i]);
/* 56 */       output.append('.');
/*    */     } 
/* 58 */     output.append(this.completionIdentifier).append('>');
/* 59 */     return output;
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeBinding resolveType(BlockScope scope) {
/* 64 */     this.binding = scope.getBinding(this.tokens, (InvocationSite)this);
/* 65 */     if (!this.binding.isValidBinding()) {
/* 66 */       if (this.binding instanceof org.eclipse.jdt.internal.compiler.lookup.ProblemFieldBinding) {
/* 67 */         scope.problemReporter().invalidField((NameReference)this, (FieldBinding)this.binding);
/* 68 */       } else if (this.binding instanceof org.eclipse.jdt.internal.compiler.lookup.ProblemReferenceBinding || this.binding instanceof org.eclipse.jdt.internal.compiler.lookup.MissingTypeBinding) {
/* 69 */         scope.problemReporter().invalidType((ASTNode)this, (TypeBinding)this.binding);
/*    */       } else {
/* 71 */         scope.problemReporter().unresolvableReference((NameReference)this, this.binding);
/*    */       } 
/*    */       
/* 74 */       if (this.binding.problemId() == 1) {
/* 75 */         throw new CompletionNodeFound(this, this.binding, scope);
/*    */       }
/*    */       
/* 78 */       throw new CompletionNodeFound();
/*    */     } 
/*    */     
/* 81 */     throw new CompletionNodeFound(this, this.binding, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnQualifiedNameReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */