/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeParameter
/*     */   extends ASTNode
/*     */ {
/*  39 */   public static final ChildListPropertyDescriptor MODIFIERS_PROPERTY = new ChildListPropertyDescriptor(TypeParameter.class, "modifiers", IExtendedModifier.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(TypeParameter.class, "name", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public static final ChildListPropertyDescriptor TYPE_BOUNDS_PROPERTY = new ChildListPropertyDescriptor(TypeParameter.class, "typeBounds", Type.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_8_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  68 */     List propertyList = new ArrayList(3);
/*  69 */     createPropertyList(TypeParameter.class, propertyList);
/*  70 */     addProperty(NAME_PROPERTY, propertyList);
/*  71 */     addProperty(TYPE_BOUNDS_PROPERTY, propertyList);
/*  72 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */     
/*  74 */     propertyList = new ArrayList(4);
/*  75 */     createPropertyList(TypeParameter.class, propertyList);
/*  76 */     addProperty(MODIFIERS_PROPERTY, propertyList);
/*  77 */     addProperty(NAME_PROPERTY, propertyList);
/*  78 */     addProperty(TYPE_BOUNDS_PROPERTY, propertyList);
/*  79 */     PROPERTY_DESCRIPTORS_8_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  93 */     switch (apiLevel) {
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/*  97 */         return PROPERTY_DESCRIPTORS;
/*     */     } 
/*  99 */     return PROPERTY_DESCRIPTORS_8_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   private SimpleName typeVariableName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   private ASTNode.NodeList typeBounds = new ASTNode.NodeList(this, TYPE_BOUNDS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   private ASTNode.NodeList modifiers = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TypeParameter(AST ast) {
/* 134 */     super(ast);
/* 135 */     unsupportedIn2();
/* 136 */     if (ast.apiLevel >= 8) {
/* 137 */       this.modifiers = new ASTNode.NodeList(this, MODIFIERS_PROPERTY);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 143 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 148 */     if (property == NAME_PROPERTY) {
/* 149 */       if (get) {
/* 150 */         return getName();
/*     */       }
/* 152 */       setName((SimpleName)child);
/* 153 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 157 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 162 */     if (property == MODIFIERS_PROPERTY) {
/* 163 */       return modifiers();
/*     */     }
/* 165 */     if (property == TYPE_BOUNDS_PROPERTY) {
/* 166 */       return typeBounds();
/*     */     }
/*     */     
/* 169 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 174 */     return 73;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 179 */     TypeParameter result = new TypeParameter(target);
/* 180 */     result.setSourceRange(getStartPosition(), getLength());
/* 181 */     if (this.ast.apiLevel >= 8) {
/* 182 */       result.modifiers().addAll(
/* 183 */           ASTNode.copySubtrees(target, modifiers()));
/*     */     }
/* 185 */     result.setName((SimpleName)getName().clone(target));
/* 186 */     result.typeBounds().addAll(
/* 187 */         ASTNode.copySubtrees(target, typeBounds()));
/* 188 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 194 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 199 */     boolean visitChildren = visitor.visit(this);
/* 200 */     if (visitChildren) {
/*     */       
/* 202 */       if (this.ast.apiLevel >= 8) {
/* 203 */         acceptChildren(visitor, this.modifiers);
/*     */       }
/* 205 */       acceptChild(visitor, getName());
/* 206 */       acceptChildren(visitor, this.typeBounds);
/*     */     } 
/* 208 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 217 */     if (this.typeVariableName == null)
/*     */     {
/* 219 */       synchronized (this) {
/* 220 */         if (this.typeVariableName == null) {
/* 221 */           preLazyInit();
/* 222 */           this.typeVariableName = new SimpleName(this.ast);
/* 223 */           postLazyInit(this.typeVariableName, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 227 */     return this.typeVariableName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ITypeBinding resolveBinding() {
/* 241 */     return this.ast.getBindingResolver().resolveTypeParameter(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName typeName) {
/* 256 */     if (typeName == null) {
/* 257 */       throw new IllegalArgumentException();
/*     */     }
/* 259 */     ASTNode oldChild = this.typeVariableName;
/* 260 */     preReplaceChild(oldChild, typeName, NAME_PROPERTY);
/* 261 */     this.typeVariableName = typeName;
/* 262 */     postReplaceChild(oldChild, typeName, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List typeBounds() {
/* 276 */     return this.typeBounds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List modifiers() {
/* 289 */     if (this.modifiers == null) {
/* 290 */       unsupportedIn2_3_4();
/*     */     }
/* 292 */     return this.modifiers;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 298 */     return 52;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 303 */     return 
/* 304 */       memSize() + (
/* 305 */       (this.modifiers == null) ? 0 : this.modifiers.listSize()) + (
/* 306 */       (this.typeVariableName == null) ? 0 : getName().treeSize()) + 
/* 307 */       this.typeBounds.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\TypeParameter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */