/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Message
/*     */ {
/*     */   private String message;
/*     */   private int startPosition;
/*     */   private int length;
/*     */   
/*     */   public Message(String message, int startPosition) {
/*  52 */     if (message == null) {
/*  53 */       throw new IllegalArgumentException();
/*     */     }
/*  55 */     if (startPosition < -1) {
/*  56 */       throw new IllegalArgumentException();
/*     */     }
/*  58 */     this.message = message;
/*  59 */     this.startPosition = startPosition;
/*  60 */     this.length = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Message(String message, int startPosition, int length) {
/*  77 */     if (message == null) {
/*  78 */       throw new IllegalArgumentException();
/*     */     }
/*  80 */     if (startPosition < -1) {
/*  81 */       throw new IllegalArgumentException();
/*     */     }
/*  83 */     this.message = message;
/*  84 */     this.startPosition = startPosition;
/*  85 */     if (length <= 0) {
/*  86 */       this.length = 0;
/*     */     } else {
/*  88 */       this.length = length;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/*  98 */     return this.message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSourcePosition() {
/* 111 */     return getStartPosition();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getStartPosition() {
/* 123 */     return this.startPosition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 135 */     return this.length;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\Message.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */