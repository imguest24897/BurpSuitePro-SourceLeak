/*    */ package org.eclipse.jdt.core.dom;
/*    */ 
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.OperationCanceledException;
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ import org.eclipse.jdt.internal.compiler.batch.ClasspathDirectory;
/*    */ import org.eclipse.jdt.internal.compiler.batch.FileSystem;
/*    */ import org.eclipse.jdt.internal.compiler.env.IModuleAwareNameEnvironment;
/*    */ import org.eclipse.jdt.internal.compiler.env.NameEnvironmentAnswer;
/*    */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilation;
/*    */ import org.eclipse.jdt.internal.core.INameEnvironmentWithProgress;
/*    */ import org.eclipse.jdt.internal.core.NameLookup;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NameEnvironmentWithProgress
/*    */   extends FileSystem
/*    */   implements INameEnvironmentWithProgress
/*    */ {
/*    */   IProgressMonitor monitor;
/*    */   
/*    */   public NameEnvironmentWithProgress(FileSystem.Classpath[] paths, String[] initialFileNames, IProgressMonitor monitor) {
/* 36 */     super(paths, initialFileNames, false);
/* 37 */     setMonitor(monitor);
/*    */   }
/*    */   private void checkCanceled() {
/* 40 */     if (this.monitor != null && this.monitor.isCanceled()) {
/* 41 */       if (NameLookup.VERBOSE) {
/* 42 */         System.out.println(Thread.currentThread() + " CANCELLING LOOKUP ");
/*    */       }
/* 44 */       throw new AbortCompilation(true, new OperationCanceledException());
/*    */     } 
/*    */   }
/*    */   
/*    */   public NameEnvironmentAnswer findType(char[] typeName, char[][] packageName, char[] moduleName) {
/* 49 */     return findType(typeName, packageName, true, moduleName);
/*    */   }
/*    */   
/*    */   public NameEnvironmentAnswer findType(char[] typeName, char[][] packageName, boolean searchWithSecondaryTypes, char[] moduleName) {
/* 53 */     checkCanceled();
/* 54 */     NameEnvironmentAnswer answer = super.findType(typeName, packageName, moduleName);
/* 55 */     if (answer == null && searchWithSecondaryTypes) {
/* 56 */       NameEnvironmentAnswer suggestedAnswer = null;
/* 57 */       String qualifiedPackageName = new String(CharOperation.concatWith(packageName, '/'));
/* 58 */       String qualifiedTypeName = new String(CharOperation.concatWith(packageName, typeName, '/'));
/* 59 */       String qualifiedBinaryFileName = String.valueOf(qualifiedTypeName) + ".class";
/* 60 */       for (int i = 0, length = this.classpaths.length; i < length; i++) {
/* 61 */         if (this.classpaths[i] instanceof ClasspathDirectory) {
/* 62 */           ClasspathDirectory classpathDirectory = (ClasspathDirectory)this.classpaths[i];
/* 63 */           IModuleAwareNameEnvironment.LookupStrategy strategy = IModuleAwareNameEnvironment.LookupStrategy.get(moduleName);
/* 64 */           if (strategy.matchesWithName(classpathDirectory, loc -> (loc.getModule() != null), loc -> loc.servesModule(paramArrayOfchar))) {
/*    */ 
/*    */ 
/*    */ 
/*    */             
/* 69 */             answer = classpathDirectory.findSecondaryInClass(typeName, qualifiedPackageName, qualifiedBinaryFileName);
/* 70 */             if (answer != null)
/* 71 */               if (!answer.ignoreIfBetter())
/* 72 */               { if (answer.isBetter(suggestedAnswer))
/* 73 */                   return answer;  }
/* 74 */               else if (answer.isBetter(suggestedAnswer))
/*    */               
/* 76 */               { suggestedAnswer = answer; }  
/*    */           } 
/*    */         } 
/*    */       } 
/* 80 */     }  return answer;
/*    */   }
/*    */ 
/*    */   
/*    */   public NameEnvironmentAnswer findType(char[][] compoundName) {
/* 85 */     checkCanceled();
/* 86 */     return super.findType(compoundName);
/*    */   }
/*    */   
/*    */   public boolean isPackage(char[][] compoundName, char[] packageName) {
/* 90 */     checkCanceled();
/* 91 */     return super.isPackage(compoundName, packageName);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setMonitor(IProgressMonitor monitor) {
/* 96 */     this.monitor = monitor;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\NameEnvironmentWithProgress.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */