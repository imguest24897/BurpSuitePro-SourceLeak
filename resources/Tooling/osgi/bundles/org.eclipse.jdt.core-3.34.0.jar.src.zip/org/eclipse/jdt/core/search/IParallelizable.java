/*    */ package org.eclipse.jdt.core.search;
/*    */ 
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.jdt.core.JavaModelException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IParallelizable
/*    */ {
/*    */   boolean isParallelSearchSupported();
/*    */   
/*    */   default void initBeforeSearch(IProgressMonitor monitor) throws JavaModelException {}
/*    */   
/*    */   static boolean isParallelSearchSupported(Object o) {
/* 54 */     return (o instanceof IParallelizable && ((IParallelizable)o).isParallelSearchSupported());
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\search\IParallelizable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */