/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WildcardType
/*     */   extends AnnotatableType
/*     */ {
/*  43 */   public static final ChildListPropertyDescriptor ANNOTATIONS_PROPERTY = internalAnnotationsPropertyFactory(WildcardType.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   public static final ChildPropertyDescriptor BOUND_PROPERTY = new ChildPropertyDescriptor(WildcardType.class, "bound", Type.class, false, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public static final SimplePropertyDescriptor UPPER_BOUND_PROPERTY = new SimplePropertyDescriptor(WildcardType.class, "upperBound", boolean.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_8_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  72 */     List propertyList = new ArrayList(3);
/*  73 */     createPropertyList(WildcardType.class, propertyList);
/*  74 */     addProperty(BOUND_PROPERTY, propertyList);
/*  75 */     addProperty(UPPER_BOUND_PROPERTY, propertyList);
/*  76 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */     
/*  78 */     propertyList = new ArrayList(4);
/*  79 */     createPropertyList(WildcardType.class, propertyList);
/*  80 */     addProperty(ANNOTATIONS_PROPERTY, propertyList);
/*  81 */     addProperty(BOUND_PROPERTY, propertyList);
/*  82 */     addProperty(UPPER_BOUND_PROPERTY, propertyList);
/*  83 */     PROPERTY_DESCRIPTORS_8_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  97 */     switch (apiLevel) {
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/* 101 */         return PROPERTY_DESCRIPTORS;
/*     */     } 
/* 103 */     return PROPERTY_DESCRIPTORS_8_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   private Type optionalBound = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isUpperBound = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WildcardType(AST ast) {
/* 130 */     super(ast);
/* 131 */     unsupportedIn2();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalAnnotationsProperty() {
/* 140 */     return ANNOTATIONS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 145 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final boolean internalGetSetBooleanProperty(SimplePropertyDescriptor property, boolean get, boolean value) {
/* 150 */     if (property == UPPER_BOUND_PROPERTY) {
/* 151 */       if (get) {
/* 152 */         return isUpperBound();
/*     */       }
/* 154 */       setUpperBound(value);
/* 155 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 159 */     return super.internalGetSetBooleanProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 164 */     if (property == ANNOTATIONS_PROPERTY) {
/* 165 */       return annotations();
/*     */     }
/*     */     
/* 168 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 173 */     if (property == BOUND_PROPERTY) {
/* 174 */       if (get) {
/* 175 */         return getBound();
/*     */       }
/* 177 */       setBound((Type)child);
/* 178 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 182 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 187 */     return 76;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 192 */     WildcardType result = new WildcardType(target);
/* 193 */     result.setSourceRange(getStartPosition(), getLength());
/* 194 */     if (this.ast.apiLevel >= 8) {
/* 195 */       result.annotations().addAll(
/* 196 */           ASTNode.copySubtrees(target, annotations()));
/*     */     }
/* 198 */     result.setBound((Type)ASTNode.copySubtree(target, getBound()), isUpperBound());
/* 199 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 205 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 210 */     boolean visitChildren = visitor.visit(this);
/* 211 */     if (visitChildren) {
/*     */       
/* 213 */       if (this.ast.apiLevel >= 8) {
/* 214 */         acceptChildren(visitor, this.annotations);
/*     */       }
/* 216 */       acceptChild(visitor, getBound());
/*     */     } 
/* 218 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUpperBound() {
/* 234 */     return this.isUpperBound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getBound() {
/* 248 */     return this.optionalBound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBound(Type type, boolean isUpperBound) {
/* 269 */     setBound(type);
/* 270 */     setUpperBound(isUpperBound);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBound(Type type) {
/* 286 */     ASTNode oldChild = this.optionalBound;
/* 287 */     preReplaceChild(oldChild, type, BOUND_PROPERTY);
/* 288 */     this.optionalBound = type;
/* 289 */     postReplaceChild(oldChild, type, BOUND_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUpperBound(boolean isUpperBound) {
/* 301 */     preValueChange(UPPER_BOUND_PROPERTY);
/* 302 */     this.isUpperBound = isUpperBound;
/* 303 */     postValueChange(UPPER_BOUND_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 308 */     return 52;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 313 */     return 
/* 314 */       memSize() + (
/* 315 */       (this.annotations == null) ? 0 : this.annotations.listSize()) + (
/* 316 */       (this.optionalBound == null) ? 0 : getBound().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\WildcardType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */