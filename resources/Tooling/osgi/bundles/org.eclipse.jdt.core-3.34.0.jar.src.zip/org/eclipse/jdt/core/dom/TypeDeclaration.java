/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.core.dom.util.DOMASTUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeDeclaration
/*     */   extends AbstractTypeDeclaration
/*     */ {
/*  64 */   public static final ChildPropertyDescriptor JAVADOC_PROPERTY = internalJavadocPropertyFactory(TypeDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public static final SimplePropertyDescriptor MODIFIERS_PROPERTY = internalModifiersPropertyFactory(TypeDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   public static final ChildListPropertyDescriptor MODIFIERS2_PROPERTY = internalModifiers2PropertyFactory(TypeDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public static final SimplePropertyDescriptor INTERFACE_PROPERTY = new SimplePropertyDescriptor(TypeDeclaration.class, "interface", boolean.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public static final ChildPropertyDescriptor NAME_PROPERTY = internalNamePropertyFactory(TypeDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public static final ChildPropertyDescriptor SUPERCLASS_PROPERTY = new ChildPropertyDescriptor(TypeDeclaration.class, "superclass", Name.class, false, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public static final ChildListPropertyDescriptor SUPER_INTERFACES_PROPERTY = new ChildListPropertyDescriptor(TypeDeclaration.class, "superInterfaces", Name.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public static final ChildPropertyDescriptor SUPERCLASS_TYPE_PROPERTY = new ChildPropertyDescriptor(TypeDeclaration.class, "superclassType", Type.class, false, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public static final ChildListPropertyDescriptor SUPER_INTERFACE_TYPES_PROPERTY = new ChildListPropertyDescriptor(TypeDeclaration.class, "superInterfaceTypes", Type.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public static final ChildListPropertyDescriptor TYPE_PARAMETERS_PROPERTY = new ChildListPropertyDescriptor(TypeDeclaration.class, "typeParameters", TypeParameter.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public static final ChildListPropertyDescriptor BODY_DECLARATIONS_PROPERTY = internalBodyDeclarationPropertyFactory(TypeDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public static final ChildListPropertyDescriptor PERMITS_TYPES_PROPERTY = new ChildListPropertyDescriptor(TypeDeclaration.class, "permitsTypes", Type.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_15;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 173 */     List propertyList = new ArrayList(8);
/* 174 */     createPropertyList(TypeDeclaration.class, propertyList);
/* 175 */     addProperty(JAVADOC_PROPERTY, propertyList);
/* 176 */     addProperty(MODIFIERS_PROPERTY, propertyList);
/* 177 */     addProperty(INTERFACE_PROPERTY, propertyList);
/* 178 */     addProperty(NAME_PROPERTY, propertyList);
/* 179 */     addProperty(SUPERCLASS_PROPERTY, propertyList);
/* 180 */     addProperty(SUPER_INTERFACES_PROPERTY, propertyList);
/* 181 */     addProperty(BODY_DECLARATIONS_PROPERTY, propertyList);
/* 182 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(propertyList);
/*     */     
/* 184 */     propertyList = new ArrayList(9);
/* 185 */     createPropertyList(TypeDeclaration.class, propertyList);
/* 186 */     addProperty(JAVADOC_PROPERTY, propertyList);
/* 187 */     addProperty(MODIFIERS2_PROPERTY, propertyList);
/* 188 */     addProperty(INTERFACE_PROPERTY, propertyList);
/* 189 */     addProperty(NAME_PROPERTY, propertyList);
/* 190 */     addProperty(TYPE_PARAMETERS_PROPERTY, propertyList);
/* 191 */     addProperty(SUPERCLASS_TYPE_PROPERTY, propertyList);
/* 192 */     addProperty(SUPER_INTERFACE_TYPES_PROPERTY, propertyList);
/* 193 */     addProperty(BODY_DECLARATIONS_PROPERTY, propertyList);
/* 194 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(propertyList);
/*     */     
/* 196 */     propertyList = new ArrayList(10);
/* 197 */     createPropertyList(TypeDeclaration.class, propertyList);
/* 198 */     addProperty(JAVADOC_PROPERTY, propertyList);
/* 199 */     addProperty(MODIFIERS2_PROPERTY, propertyList);
/* 200 */     addProperty(INTERFACE_PROPERTY, propertyList);
/* 201 */     addProperty(NAME_PROPERTY, propertyList);
/* 202 */     addProperty(TYPE_PARAMETERS_PROPERTY, propertyList);
/* 203 */     addProperty(SUPERCLASS_TYPE_PROPERTY, propertyList);
/* 204 */     addProperty(SUPER_INTERFACE_TYPES_PROPERTY, propertyList);
/* 205 */     addProperty(PERMITS_TYPES_PROPERTY, propertyList);
/* 206 */     addProperty(BODY_DECLARATIONS_PROPERTY, propertyList);
/* 207 */     PROPERTY_DESCRIPTORS_15 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 222 */     if (DOMASTUtil.isFeatureSupportedinAST(apiLevel, 512))
/* 223 */       return PROPERTY_DESCRIPTORS_15; 
/* 224 */     if (apiLevel == 2) {
/* 225 */       return PROPERTY_DESCRIPTORS_2_0;
/*     */     }
/* 227 */     return PROPERTY_DESCRIPTORS_3_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isInterface = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 242 */   private ASTNode.NodeList typeParameters = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 249 */   private Name optionalSuperclassName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 257 */   private ASTNode.NodeList superInterfaceNames = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 265 */   private Type optionalSuperclassType = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 273 */   private ASTNode.NodeList superInterfaceTypes = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 281 */   private ASTNode.NodeList permittedTypes = null; private int restrictedIdentifierStartPosition; final List internalStructuralPropertiesForType(int apiLevel) { return propertyDescriptors(apiLevel); }
/*     */   final int internalGetSetIntProperty(SimplePropertyDescriptor property, boolean get, int value) { if (property == MODIFIERS_PROPERTY) { if (get) return getModifiers();  internalSetModifiers(value); return 0; }  return super.internalGetSetIntProperty(property, get, value); }
/*     */   final boolean internalGetSetBooleanProperty(SimplePropertyDescriptor property, boolean get, boolean value) { if (property == INTERFACE_PROPERTY) { if (get) return isInterface();  setInterface(value); return false; }  return super.internalGetSetBooleanProperty(property, get, value); }
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) { if (property == JAVADOC_PROPERTY) { if (get) return getJavadoc();  setJavadoc((Javadoc)child); return null; }  if (property == NAME_PROPERTY) { if (get)
/*     */         return getName();  setName((SimpleName)child); return null; }  if (property == SUPERCLASS_PROPERTY) { if (get)
/*     */         return getSuperclass();  setSuperclass((Name)child); return null; }  if (property == SUPERCLASS_TYPE_PROPERTY) { if (get)
/*     */         return getSuperclassType();  setSuperclassType((Type)child); return null; }  return super.internalGetSetChildProperty(property, get, child); }
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) { if (property == MODIFIERS2_PROPERTY)
/*     */       return modifiers();  if (property == TYPE_PARAMETERS_PROPERTY)
/*     */       return typeParameters();  if (property == SUPER_INTERFACES_PROPERTY)
/*     */       return superInterfaces();  if (property == SUPER_INTERFACE_TYPES_PROPERTY)
/*     */       return superInterfaceTypes();  if (property == PERMITS_TYPES_PROPERTY)
/*     */       return permittedTypes();  if (property == BODY_DECLARATIONS_PROPERTY)
/*     */       return bodyDeclarations();  return super.internalGetChildListProperty(property); }
/*     */   final ChildPropertyDescriptor internalJavadocProperty() { return JAVADOC_PROPERTY; }
/*     */   final ChildListPropertyDescriptor internalModifiers2Property() { return MODIFIERS2_PROPERTY; }
/*     */   final SimplePropertyDescriptor internalModifiersProperty() { return MODIFIERS_PROPERTY; }
/* 298 */   TypeDeclaration(AST ast) { super(ast);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 861 */     this.restrictedIdentifierStartPosition = -1; if (ast.apiLevel == 2)
/*     */       this.superInterfaceNames = new ASTNode.NodeList(this, SUPER_INTERFACES_PROPERTY);  if (ast.apiLevel >= 3) { this.typeParameters = new ASTNode.NodeList(this, TYPE_PARAMETERS_PROPERTY); this.superInterfaceTypes = new ASTNode.NodeList(this, SUPER_INTERFACE_TYPES_PROPERTY); }  if (DOMASTUtil.isFeatureSupportedinAST(ast, 512))
/*     */       this.permittedTypes = new ASTNode.NodeList(this, PERMITS_TYPES_PROPERTY);  }
/*     */   final ChildPropertyDescriptor internalNameProperty() { return NAME_PROPERTY; }
/*     */   final ChildListPropertyDescriptor internalBodyDeclarationsProperty() { return BODY_DECLARATIONS_PROPERTY; }
/*     */   final int getNodeType0() { return 55; }
/*     */   ASTNode clone0(AST target) { TypeDeclaration result = new TypeDeclaration(target); result.setSourceRange(getStartPosition(), getLength()); result.setJavadoc((Javadoc)ASTNode.copySubtree(target, getJavadoc())); if (this.ast.apiLevel == 2) { result.internalSetModifiers(getModifiers()); result.setSuperclass((Name)ASTNode.copySubtree(target, getSuperclass())); result.superInterfaces().addAll(ASTNode.copySubtrees(target, superInterfaces())); }  result.setInterface(isInterface()); result.setName((SimpleName)getName().clone(target)); if (this.ast.apiLevel >= 3) { result.modifiers().addAll(ASTNode.copySubtrees(target, modifiers())); result.typeParameters().addAll(ASTNode.copySubtrees(target, typeParameters())); result.setSuperclassType((Type)ASTNode.copySubtree(target, getSuperclassType())); result.superInterfaceTypes().addAll(ASTNode.copySubtrees(target, superInterfaceTypes())); }
/*     */      if (DOMASTUtil.isFeatureSupportedinAST(this.ast, 512)) { result.permittedTypes().addAll(ASTNode.copySubtrees(target, permittedTypes())); result.restrictedIdentifierStartPosition = getRestrictedIdentifierStartPosition(); }
/* 869 */      result.bodyDeclarations().addAll(ASTNode.copySubtrees(target, bodyDeclarations())); return result; } public void setRestrictedIdentifierStartPosition(int restrictedIdentifierStartPosition) { if (restrictedIdentifierStartPosition < 0) {
/* 870 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/* 874 */     checkModifiable();
/* 875 */     this.restrictedIdentifierStartPosition = restrictedIdentifierStartPosition; }
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) { return matcher.match(this, other); }
/*     */   void accept0(ASTVisitor visitor) { boolean visitChildren = visitor.visit(this); if (visitChildren) { if (this.ast.apiLevel == 2) { acceptChild(visitor, getJavadoc()); acceptChild(visitor, getName()); acceptChild(visitor, getSuperclass()); acceptChildren(visitor, this.superInterfaceNames); acceptChildren(visitor, this.bodyDeclarations); }  if (this.ast.apiLevel >= 3) { acceptChild(visitor, getJavadoc()); acceptChildren(visitor, this.modifiers); acceptChild(visitor, getName()); acceptChildren(visitor, this.typeParameters); acceptChild(visitor, getSuperclassType()); acceptChildren(visitor, this.superInterfaceTypes); acceptChildren(visitor, this.bodyDeclarations); }  if (DOMASTUtil.isFeatureSupportedinAST(getAST(), 512)) acceptChildren(visitor, this.permittedTypes);  }  visitor.endVisit(this); }
/*     */   public boolean isInterface() { return this.isInterface; }
/*     */   public void setInterface(boolean isInterface) { preValueChange(INTERFACE_PROPERTY); this.isInterface = isInterface; postValueChange(INTERFACE_PROPERTY); }
/*     */   public List typeParameters() { if (this.typeParameters == null) unsupportedIn2();  return this.typeParameters; }
/*     */   public Name getSuperclass() { return internalGetSuperclass(); }
/*     */   final Name internalGetSuperclass() { supportedOnlyIn2(); return this.optionalSuperclassName; }
/*     */   public Type getSuperclassType() { unsupportedIn2(); return this.optionalSuperclassType; }
/* 884 */   public void setSuperclass(Name superclassName) { internalSetSuperclass(superclassName); } final void internalSetSuperclass(Name superclassName) { supportedOnlyIn2(); ASTNode oldChild = this.optionalSuperclassName; preReplaceChild(oldChild, superclassName, SUPERCLASS_PROPERTY); this.optionalSuperclassName = superclassName; postReplaceChild(oldChild, superclassName, SUPERCLASS_PROPERTY); } public void setSuperclassType(Type superclassType) { unsupportedIn2(); ASTNode oldChild = this.optionalSuperclassType; preReplaceChild(oldChild, superclassType, SUPERCLASS_TYPE_PROPERTY); this.optionalSuperclassType = superclassType; postReplaceChild(oldChild, superclassType, SUPERCLASS_TYPE_PROPERTY); } public List superInterfaces() { return internalSuperInterfaces(); } public int getRestrictedIdentifierStartPosition() { return this.restrictedIdentifierStartPosition; }
/*     */ 
/*     */   
/*     */   final List internalSuperInterfaces() {
/*     */     if (this.superInterfaceNames == null)
/*     */       supportedOnlyIn2(); 
/*     */     return this.superInterfaceNames;
/*     */   }
/*     */   
/*     */   public List superInterfaceTypes() {
/*     */     if (this.superInterfaceTypes == null)
/*     */       unsupportedIn2(); 
/*     */     return this.superInterfaceTypes;
/*     */   }
/*     */   
/*     */   public List permittedTypes() {
/*     */     if (this.permittedTypes == null)
/*     */       unsupportedBelow17(); 
/*     */     return this.permittedTypes;
/*     */   }
/*     */   
/*     */   public FieldDeclaration[] getFields() {
/*     */     List bd = bodyDeclarations();
/*     */     int fieldCount = 0;
/*     */     for (Iterator it = bd.listIterator(); it.hasNext();) {
/*     */       if (it.next() instanceof FieldDeclaration)
/*     */         fieldCount++; 
/*     */     } 
/*     */     FieldDeclaration[] fields = new FieldDeclaration[fieldCount];
/*     */     int next = 0;
/*     */     for (Iterator iterator1 = bd.listIterator(); iterator1.hasNext(); ) {
/*     */       Object decl = iterator1.next();
/*     */       if (decl instanceof FieldDeclaration)
/*     */         fields[next++] = (FieldDeclaration)decl; 
/*     */     } 
/*     */     return fields;
/*     */   }
/*     */   
/*     */   public MethodDeclaration[] getMethods() {
/*     */     List bd = bodyDeclarations();
/*     */     int methodCount = 0;
/*     */     for (Iterator it = bd.listIterator(); it.hasNext();) {
/*     */       if (it.next() instanceof MethodDeclaration)
/*     */         methodCount++; 
/*     */     } 
/*     */     MethodDeclaration[] methods = new MethodDeclaration[methodCount];
/*     */     int next = 0;
/*     */     for (Iterator iterator1 = bd.listIterator(); iterator1.hasNext(); ) {
/*     */       Object decl = iterator1.next();
/*     */       if (decl instanceof MethodDeclaration)
/*     */         methods[next++] = (MethodDeclaration)decl; 
/*     */     } 
/*     */     return methods;
/*     */   }
/*     */   
/*     */   public TypeDeclaration[] getTypes() {
/*     */     List bd = bodyDeclarations();
/*     */     int typeCount = 0;
/*     */     for (Iterator it = bd.listIterator(); it.hasNext();) {
/*     */       if (it.next() instanceof TypeDeclaration)
/*     */         typeCount++; 
/*     */     } 
/*     */     TypeDeclaration[] memberTypes = new TypeDeclaration[typeCount];
/*     */     int next = 0;
/*     */     for (Iterator iterator1 = bd.listIterator(); iterator1.hasNext(); ) {
/*     */       Object decl = iterator1.next();
/*     */       if (decl instanceof TypeDeclaration)
/*     */         memberTypes[next++] = (TypeDeclaration)decl; 
/*     */     } 
/*     */     return memberTypes;
/*     */   }
/*     */   
/*     */   ITypeBinding internalResolveBinding() {
/*     */     return this.ast.getBindingResolver().resolveType(this);
/*     */   }
/*     */   
/*     */   int memSize() {
/*     */     return super.memSize() + 1 + 28;
/*     */   }
/*     */   
/*     */   int treeSize() {
/*     */     return memSize() + ((this.optionalDocComment == null) ? 0 : getJavadoc().treeSize()) + ((this.modifiers == null) ? 0 : this.modifiers.listSize()) + ((this.typeName == null) ? 0 : getName().treeSize()) + ((this.typeParameters == null) ? 0 : this.typeParameters.listSize()) + ((this.optionalSuperclassName == null) ? 0 : getSuperclass().treeSize()) + ((this.optionalSuperclassType == null) ? 0 : getSuperclassType().treeSize()) + ((this.superInterfaceNames == null) ? 0 : this.superInterfaceNames.listSize()) + ((this.superInterfaceTypes == null) ? 0 : this.superInterfaceTypes.listSize()) + ((this.permittedTypes == null) ? 0 : this.permittedTypes.listSize()) + this.bodyDeclarations.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\TypeDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */