/*     */ package org.eclipse.jdt.core.compiler;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.jdt.core.ICompilationUnit;
/*     */ import org.eclipse.jdt.core.IJavaElementDelta;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.core.dom.ASTParser;
/*     */ import org.eclipse.jdt.core.dom.CompilationUnit;
/*     */ import org.eclipse.jdt.internal.core.CompilationUnit;
/*     */ import org.eclipse.jdt.internal.core.JavaProject;
/*     */ import org.eclipse.jdt.internal.core.ReconcileWorkingCopyOperation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReconcileContext
/*     */ {
/*     */   private ReconcileWorkingCopyOperation operation;
/*     */   private CompilationUnit workingCopy;
/*     */   
/*     */   public ReconcileContext(ReconcileWorkingCopyOperation operation, CompilationUnit workingCopy) {
/*  65 */     this.operation = operation;
/*  66 */     this.workingCopy = workingCopy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompilationUnit getAST3() throws JavaModelException {
/*  94 */     return getAST(3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompilationUnit getAST4() throws JavaModelException {
/* 123 */     return getAST(4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompilationUnit getAST8() throws JavaModelException {
/* 152 */     return getAST(8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompilationUnit getAST(int level) throws JavaModelException {
/* 181 */     if (this.operation.astLevel != level || !this.operation.resolveBindings) {
/*     */       
/* 183 */       ASTParser parser = ASTParser.newParser(level);
/* 184 */       parser.setCompilerOptions(this.workingCopy.getJavaProject().getOptions(true));
/* 185 */       if (JavaProject.hasJavaNature(this.workingCopy.getJavaProject().getProject()))
/* 186 */         parser.setResolveBindings(true); 
/* 187 */       parser.setStatementsRecovery(((this.operation.reconcileFlags & 0x2) != 0));
/* 188 */       parser.setBindingsRecovery(((this.operation.reconcileFlags & 0x4) != 0));
/* 189 */       parser.setSource((ICompilationUnit)this.workingCopy);
/* 190 */       parser.setIgnoreMethodBodies(((this.operation.reconcileFlags & 0x8) != 0));
/* 191 */       return (CompilationUnit)parser.createAST((IProgressMonitor)this.operation.progressMonitor);
/*     */     } 
/* 193 */     return this.operation.makeConsistent(this.workingCopy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getASTLevel() {
/* 203 */     return this.operation.astLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isResolvingBindings() {
/* 212 */     return this.operation.resolveBindings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getReconcileFlags() {
/* 226 */     return this.operation.reconcileFlags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IJavaElementDelta getDelta() {
/* 237 */     return (IJavaElementDelta)this.operation.deltaBuilder.delta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CategorizedProblem[] getProblems(String markerType) {
/* 249 */     if (this.operation.problems == null) return null; 
/* 250 */     return (CategorizedProblem[])this.operation.problems.get(markerType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ICompilationUnit getWorkingCopy() {
/* 259 */     return (ICompilationUnit)this.workingCopy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetAST() {
/* 275 */     this.operation.ast = null;
/* 276 */     putProblems("org.eclipse.jdt.core.problem", null);
/* 277 */     putProblems("org.eclipse.jdt.core.task", null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putProblems(String markerType, CategorizedProblem[] problems) {
/* 294 */     if (this.operation.problems == null)
/* 295 */       this.operation.problems = new HashMap<>(); 
/* 296 */     this.operation.problems.put(markerType, problems);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\compiler\ReconcileContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */