/*    */ package org.eclipse.jdt.core.dom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NodeFinderVisitor
/*    */   extends ASTVisitor
/*    */ {
/*    */   private int fStart;
/*    */   private int fEnd;
/*    */   private ASTNode fCoveringNode;
/*    */   private ASTNode fCoveredNode;
/*    */   
/*    */   NodeFinderVisitor(int offset, int length) {
/* 43 */     super(true);
/* 44 */     this.fStart = offset;
/* 45 */     this.fEnd = offset + length;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean preVisit2(ASTNode node) {
/* 50 */     int nodeStart = node.getStartPosition();
/* 51 */     int nodeEnd = nodeStart + node.getLength();
/* 52 */     if (nodeEnd < this.fStart || this.fEnd < nodeStart) {
/* 53 */       return false;
/*    */     }
/* 55 */     if (nodeStart <= this.fStart && this.fEnd <= nodeEnd) {
/* 56 */       this.fCoveringNode = node;
/*    */     }
/* 58 */     if (this.fStart <= nodeStart && nodeEnd <= this.fEnd) {
/* 59 */       if (this.fCoveringNode == node) {
/* 60 */         this.fCoveredNode = node;
/* 61 */         return true;
/* 62 */       }  if (this.fCoveredNode == null) {
/* 63 */         this.fCoveredNode = node;
/*    */       }
/* 65 */       return false;
/*    */     } 
/* 67 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ASTNode getCoveredNode() {
/* 75 */     return this.fCoveredNode;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ASTNode getCoveringNode() {
/* 84 */     return this.fCoveringNode;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\NodeFinder$NodeFinderVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */