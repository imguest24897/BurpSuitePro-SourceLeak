/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleName
/*     */   extends Name
/*     */ {
/*  45 */   public static final SimplePropertyDescriptor IDENTIFIER_PROPERTY = new SimplePropertyDescriptor(SimpleName.class, "identifier", String.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public static final SimplePropertyDescriptor VAR_PROPERTY = new SimplePropertyDescriptor(SimpleName.class, "var", boolean.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_10_0;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String MISSING_IDENTIFIER = "MISSING";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  71 */     List propertyList = new ArrayList(2);
/*  72 */     createPropertyList(SimpleName.class, propertyList);
/*  73 */     addProperty(IDENTIFIER_PROPERTY, propertyList);
/*  74 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */     
/*  76 */     propertyList = new ArrayList(3);
/*  77 */     createPropertyList(SimpleName.class, propertyList);
/*  78 */     addProperty(IDENTIFIER_PROPERTY, propertyList);
/*  79 */     addProperty(VAR_PROPERTY, propertyList);
/*  80 */     PROPERTY_DESCRIPTORS_10_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  93 */     if (apiLevel < 10) {
/*  94 */       return PROPERTY_DESCRIPTORS;
/*     */     }
/*  96 */     return PROPERTY_DESCRIPTORS_10_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   private String identifier = "MISSING";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isVarType = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SimpleName(AST ast) {
/* 130 */     super(ast);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 139 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final Object internalGetSetObjectProperty(SimplePropertyDescriptor property, boolean get, Object value) {
/* 144 */     if (property == IDENTIFIER_PROPERTY) {
/* 145 */       if (get) {
/* 146 */         return getIdentifier();
/*     */       }
/* 148 */       setIdentifier((String)value);
/* 149 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 153 */     return super.internalGetSetObjectProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final boolean internalGetSetBooleanProperty(SimplePropertyDescriptor property, boolean get, boolean value) {
/* 158 */     if (property == VAR_PROPERTY) {
/* 159 */       if (get) {
/* 160 */         return isVar();
/*     */       }
/* 162 */       if (Long.compare(this.ast.scanner.complianceLevel, 3538944L) < 0) {
/* 163 */         setVar(false);
/*     */       } else {
/* 165 */         setVar(value);
/*     */       } 
/* 167 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 171 */     return super.internalGetSetBooleanProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 176 */     return 42;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 181 */     SimpleName result = new SimpleName(target);
/* 182 */     result.setSourceRange(getStartPosition(), getLength());
/* 183 */     result.setIdentifier(getIdentifier());
/* 184 */     if (this.ast.apiLevel >= 10 && Long.compare(this.ast.scanner.complianceLevel, 10L) >= 0) {
/* 185 */       result.setVar(isVar());
/*     */     }
/* 187 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 193 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 198 */     visitor.visit(this);
/* 199 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIdentifier() {
/* 208 */     return this.identifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIdentifier(String identifier) {
/* 226 */     if (identifier == null) {
/* 227 */       throw new IllegalArgumentException();
/*     */     }
/* 229 */     Scanner scanner = this.ast.scanner;
/* 230 */     long sourceLevel = scanner.sourceLevel;
/* 231 */     long complianceLevel = scanner.complianceLevel;
/*     */     
/*     */     try {
/* 234 */       scanner.sourceLevel = 3080192L;
/* 235 */       scanner.complianceLevel = 3211264L;
/* 236 */       char[] source = identifier.toCharArray();
/* 237 */       scanner.setSource(source);
/* 238 */       int length = source.length;
/* 239 */       scanner.resetTo(0, length - 1);
/*     */       try {
/* 241 */         int tokenType = scanner.scanIdentifier();
/* 242 */         if (tokenType != 19) {
/* 243 */           throw new IllegalArgumentException("Invalid identifier : >" + identifier + "<");
/*     */         }
/* 245 */         if (scanner.currentPosition != length)
/*     */         {
/* 247 */           throw new IllegalArgumentException("Invalid identifier : >" + identifier + "<");
/*     */         }
/* 249 */       } catch (InvalidInputException e) {
/* 250 */         throw new IllegalArgumentException("Invalid identifier : >" + identifier + "<", e);
/*     */       } 
/*     */     } finally {
/* 253 */       this.ast.scanner.sourceLevel = sourceLevel;
/* 254 */       this.ast.scanner.complianceLevel = complianceLevel;
/*     */     } 
/* 256 */     preValueChange(IDENTIFIER_PROPERTY);
/* 257 */     this.identifier = identifier;
/* 258 */     postValueChange(IDENTIFIER_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVar() {
/* 271 */     unsupportedBelow10();
/* 272 */     return this.isVarType;
/*     */   }
/*     */   
/*     */   void setVar(boolean isVar) {
/* 276 */     unsupportedBelow10();
/* 277 */     preValueChange(VAR_PROPERTY);
/* 278 */     this.isVarType = isVar;
/* 279 */     postValueChange(VAR_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void internalSetIdentifier(String ident) {
/* 286 */     preValueChange(IDENTIFIER_PROPERTY);
/* 287 */     this.identifier = ident;
/* 288 */     postValueChange(IDENTIFIER_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDeclaration() {
/* 321 */     StructuralPropertyDescriptor d = getLocationInParent();
/* 322 */     if (d == null)
/*     */     {
/* 324 */       return false;
/*     */     }
/* 326 */     ASTNode parent = getParent();
/* 327 */     if (parent instanceof TypeDeclaration) {
/* 328 */       return (d == TypeDeclaration.NAME_PROPERTY);
/*     */     }
/* 330 */     if (parent instanceof MethodDeclaration) {
/* 331 */       MethodDeclaration p = (MethodDeclaration)parent;
/*     */       
/* 333 */       return (!p.isConstructor() && d == MethodDeclaration.NAME_PROPERTY);
/*     */     } 
/* 335 */     if (parent instanceof SingleVariableDeclaration) {
/* 336 */       return (d == SingleVariableDeclaration.NAME_PROPERTY);
/*     */     }
/* 338 */     if (parent instanceof VariableDeclarationFragment) {
/* 339 */       return (d == VariableDeclarationFragment.NAME_PROPERTY);
/*     */     }
/* 341 */     if (parent instanceof EnumDeclaration) {
/* 342 */       return (d == EnumDeclaration.NAME_PROPERTY);
/*     */     }
/* 344 */     if (parent instanceof EnumConstantDeclaration) {
/* 345 */       return (d == EnumConstantDeclaration.NAME_PROPERTY);
/*     */     }
/* 347 */     if (parent instanceof TypeParameter) {
/* 348 */       return (d == TypeParameter.NAME_PROPERTY);
/*     */     }
/* 350 */     if (parent instanceof AnnotationTypeDeclaration) {
/* 351 */       return (d == AnnotationTypeDeclaration.NAME_PROPERTY);
/*     */     }
/* 353 */     if (parent instanceof AnnotationTypeMemberDeclaration) {
/* 354 */       return (d == AnnotationTypeMemberDeclaration.NAME_PROPERTY);
/*     */     }
/* 356 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   void appendName(StringBuffer buffer) {
/* 361 */     buffer.append(getIdentifier());
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 366 */     int size = 56;
/* 367 */     if (this.identifier != "MISSING")
/*     */     {
/* 369 */       size += stringSize(this.identifier);
/*     */     }
/* 371 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 376 */     return memSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\SimpleName.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */