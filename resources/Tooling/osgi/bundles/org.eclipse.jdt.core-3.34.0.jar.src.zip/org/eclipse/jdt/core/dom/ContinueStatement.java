/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContinueStatement
/*     */   extends Statement
/*     */ {
/*  39 */   public static final ChildPropertyDescriptor LABEL_PROPERTY = new ChildPropertyDescriptor(ContinueStatement.class, "label", SimpleName.class, false, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  49 */     List properyList = new ArrayList(2);
/*  50 */     createPropertyList(ContinueStatement.class, properyList);
/*  51 */     addProperty(LABEL_PROPERTY, properyList);
/*  52 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  67 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   private SimpleName optionalLabel = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ContinueStatement(AST ast) {
/*  85 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  90 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/*  95 */     if (property == LABEL_PROPERTY) {
/*  96 */       if (get) {
/*  97 */         return getLabel();
/*     */       }
/*  99 */       setLabel((SimpleName)child);
/* 100 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 104 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 109 */     return 18;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 114 */     ContinueStatement result = new ContinueStatement(target);
/* 115 */     result.setSourceRange(getStartPosition(), getLength());
/* 116 */     result.copyLeadingComment(this);
/* 117 */     result.setLabel((SimpleName)ASTNode.copySubtree(target, getLabel()));
/* 118 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 124 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 129 */     boolean visitChildren = visitor.visit(this);
/* 130 */     if (visitChildren) {
/* 131 */       acceptChild(visitor, getLabel());
/*     */     }
/* 133 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getLabel() {
/* 143 */     return this.optionalLabel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabel(SimpleName label) {
/* 158 */     ASTNode oldChild = this.optionalLabel;
/* 159 */     preReplaceChild(oldChild, label, LABEL_PROPERTY);
/* 160 */     this.optionalLabel = label;
/* 161 */     postReplaceChild(oldChild, label, LABEL_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 166 */     return super.memSize() + 4;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 171 */     return 
/* 172 */       memSize() + (
/* 173 */       (this.optionalLabel == null) ? 0 : getLabel().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ContinueStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */