package org.eclipse.jdt.core.util;

public interface IConstantPoolConstant {
  public static final int CONSTANT_Class = 7;
  
  public static final int CONSTANT_Fieldref = 9;
  
  public static final int CONSTANT_Methodref = 10;
  
  public static final int CONSTANT_InterfaceMethodref = 11;
  
  public static final int CONSTANT_String = 8;
  
  public static final int CONSTANT_Integer = 3;
  
  public static final int CONSTANT_Float = 4;
  
  public static final int CONSTANT_Long = 5;
  
  public static final int CONSTANT_Double = 6;
  
  public static final int CONSTANT_NameAndType = 12;
  
  public static final int CONSTANT_Utf8 = 1;
  
  public static final int CONSTANT_MethodHandle = 15;
  
  public static final int CONSTANT_MethodType = 16;
  
  public static final int CONSTANT_InvokeDynamic = 18;
  
  public static final int CONSTANT_DynamicCallSite = 18;
  
  public static final int CONSTANT_Module = 19;
  
  public static final int CONSTANT_Package = 20;
  
  public static final int CONSTANT_Dynamic = 17;
  
  public static final int CONSTANT_Methodref_SIZE = 5;
  
  public static final int CONSTANT_Class_SIZE = 3;
  
  public static final int CONSTANT_Double_SIZE = 9;
  
  public static final int CONSTANT_Fieldref_SIZE = 5;
  
  public static final int CONSTANT_Float_SIZE = 5;
  
  public static final int CONSTANT_Integer_SIZE = 5;
  
  public static final int CONSTANT_InterfaceMethodref_SIZE = 5;
  
  public static final int CONSTANT_Long_SIZE = 9;
  
  public static final int CONSTANT_String_SIZE = 3;
  
  public static final int CONSTANT_Utf8_SIZE = 3;
  
  public static final int CONSTANT_NameAndType_SIZE = 5;
  
  public static final int CONSTANT_MethodHandle_SIZE = 4;
  
  public static final int CONSTANT_MethodType_SIZE = 3;
  
  public static final int CONSTANT_InvokeDynamic_SIZE = 5;
  
  public static final int CONSTANT_Dynamic_SIZE = 5;
  
  public static final int CONSTANT_Module_SIZE = 3;
  
  public static final int CONSTANT_Package_SIZE = 3;
  
  public static final int METHOD_TYPE_REF_GetField = 1;
  
  public static final int METHOD_TYPE_REF_GetStatic = 2;
  
  public static final int METHOD_TYPE_REF_PutField = 3;
  
  public static final int METHOD_TYPE_REF_PutStatic = 4;
  
  public static final int METHOD_TYPE_REF_InvokeVirtual = 5;
  
  public static final int METHOD_TYPE_REF_InvokeStatic = 6;
  
  public static final int METHOD_TYPE_REF_InvokeSpecial = 7;
  
  public static final int METHOD_TYPE_REF_NewInvokeSpecial = 8;
  
  public static final int METHOD_TYPE_REF_InvokeInterface = 9;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\cor\\util\IConstantPoolConstant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */