/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Modifier
/*     */   extends ASTNode
/*     */   implements IExtendedModifier
/*     */ {
/*     */   public static final int ABSTRACT = 1024;
/*     */   public static final int FINAL = 16;
/*     */   
/*     */   public static class ModifierKeyword
/*     */   {
/*  62 */     public static final ModifierKeyword ABSTRACT_KEYWORD = new ModifierKeyword("abstract", 1024);
/*     */ 
/*     */     
/*  65 */     public static final ModifierKeyword FINAL_KEYWORD = new ModifierKeyword("final", 16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final ModifierKeyword NATIVE_KEYWORD = new ModifierKeyword("native", 256);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 125 */     private static final Map KEYWORDS = new HashMap<>(20); static {
/* 126 */       ModifierKeyword[] ops = { 
/* 127 */           PUBLIC_KEYWORD, 
/* 128 */           PROTECTED_KEYWORD, 
/* 129 */           PRIVATE_KEYWORD, 
/* 130 */           STATIC_KEYWORD, 
/* 131 */           ABSTRACT_KEYWORD, 
/* 132 */           FINAL_KEYWORD, 
/* 133 */           NATIVE_KEYWORD, 
/* 134 */           SYNCHRONIZED_KEYWORD, 
/* 135 */           TRANSIENT_KEYWORD, 
/* 136 */           VOLATILE_KEYWORD, 
/* 137 */           STRICTFP_KEYWORD, 
/* 138 */           DEFAULT_KEYWORD, 
/* 139 */           SEALED_KEYWORD, 
/* 140 */           NON_SEALED_KEYWORD };
/*     */       
/* 142 */       for (int i = 0; i < ops.length; i++)
/* 143 */         KEYWORDS.put(ops[i].toString(), ops[i]); 
/*     */     }
/*     */     public static final ModifierKeyword PRIVATE_KEYWORD = new ModifierKeyword("private", 2);
/*     */     public static final ModifierKeyword PROTECTED_KEYWORD = new ModifierKeyword("protected", 4);
/*     */     public static final ModifierKeyword PUBLIC_KEYWORD = new ModifierKeyword("public", 1);
/*     */     public static final ModifierKeyword STATIC_KEYWORD = new ModifierKeyword("static", 8);
/*     */     public static final ModifierKeyword STRICTFP_KEYWORD = new ModifierKeyword("strictfp", 2048);
/*     */     public static final ModifierKeyword SYNCHRONIZED_KEYWORD = new ModifierKeyword("synchronized", 32);
/*     */     public static final ModifierKeyword TRANSIENT_KEYWORD = new ModifierKeyword("transient", 128);
/*     */     public static final ModifierKeyword VOLATILE_KEYWORD = new ModifierKeyword("volatile", 64);
/*     */     public static final ModifierKeyword DEFAULT_KEYWORD = new ModifierKeyword("default", 65536);
/*     */     public static final ModifierKeyword SEALED_KEYWORD = new ModifierKeyword("sealed", 512);
/*     */     public static final ModifierKeyword WHEN_KEYWORD = new ModifierKeyword("when", 8192);
/*     */     public static final ModifierKeyword NON_SEALED_KEYWORD = new ModifierKeyword("non-sealed", 4096);
/*     */     private int flagValue;
/*     */     private String keyword;
/*     */     
/*     */     public static ModifierKeyword fromFlagValue(int flagValue) {
/* 161 */       for (Iterator<ModifierKeyword> it = KEYWORDS.values().iterator(); it.hasNext(); ) {
/* 162 */         ModifierKeyword k = it.next();
/* 163 */         if (k.toFlagValue() == flagValue) {
/* 164 */           return k;
/*     */         }
/*     */       } 
/* 167 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ModifierKeyword toKeyword(String keyword) {
/* 184 */       return (ModifierKeyword)KEYWORDS.get(keyword);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ModifierKeyword(String keyword, int flagValue) {
/* 208 */       this.keyword = keyword;
/* 209 */       this.flagValue = flagValue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int toFlagValue() {
/* 220 */       return this.flagValue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 231 */       return this.keyword;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 254 */   public static final SimplePropertyDescriptor KEYWORD_PROPERTY = new SimplePropertyDescriptor(Modifier.class, "keyword", ModifierKeyword.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int NATIVE = 256;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int NONE = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int PRIVATE = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int PROTECTED = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int PUBLIC = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int STATIC = 8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int STRICTFP = 2048;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SYNCHRONIZED = 32;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int TRANSIENT = 128;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int VOLATILE = 64;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SEALED = 512;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int NON_SEALED = 4096;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int WHEN = 8192;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT = 65536;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 365 */     List properyList = new ArrayList(2);
/* 366 */     createPropertyList(Modifier.class, properyList);
/* 367 */     addProperty(KEYWORD_PROPERTY, properyList);
/* 368 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isAbstract(int flags) {
/* 381 */     return ((flags & 0x400) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isFinal(int flags) {
/* 394 */     return ((flags & 0x10) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNative(int flags) {
/* 407 */     return ((flags & 0x100) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPrivate(int flags) {
/* 420 */     return ((flags & 0x2) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isProtected(int flags) {
/* 433 */     return ((flags & 0x4) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPublic(int flags) {
/* 446 */     return ((flags & 0x1) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isStatic(int flags) {
/* 459 */     return ((flags & 0x8) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isStrictfp(int flags) {
/* 472 */     return ((flags & 0x800) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSynchronized(int flags) {
/* 485 */     return ((flags & 0x20) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTransient(int flags) {
/* 498 */     return ((flags & 0x80) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isVolatile(int flags) {
/* 511 */     return ((flags & 0x40) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDefault(int flags) {
/* 524 */     return ((flags & 0x10000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSealed(int flags) {
/* 537 */     return ((flags & 0x200) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNonSealed(int flags) {
/* 550 */     return ((flags & 0x1000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 565 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 572 */   private ModifierKeyword modifierKeyword = ModifierKeyword.PUBLIC_KEYWORD;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Modifier(AST ast) {
/* 585 */     super(ast);
/* 586 */     unsupportedIn2();
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 591 */     visitor.visit(this);
/* 592 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 597 */     Modifier result = new Modifier(target);
/* 598 */     result.setSourceRange(getStartPosition(), getLength());
/* 599 */     result.setKeyword(getKeyword());
/* 600 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierKeyword getKeyword() {
/* 610 */     return this.modifierKeyword;
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 615 */     return 83;
/*     */   }
/*     */ 
/*     */   
/*     */   final Object internalGetSetObjectProperty(SimplePropertyDescriptor property, boolean get, Object value) {
/* 620 */     if (property == KEYWORD_PROPERTY) {
/* 621 */       if (get) {
/* 622 */         return getKeyword();
/*     */       }
/* 624 */       setKeyword((ModifierKeyword)value);
/* 625 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 629 */     return super.internalGetSetObjectProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 634 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAbstract() {
/* 644 */     return (this.modifierKeyword == ModifierKeyword.ABSTRACT_KEYWORD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAnnotation() {
/* 652 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFinal() {
/* 662 */     return (this.modifierKeyword == ModifierKeyword.FINAL_KEYWORD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isModifier() {
/* 670 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNative() {
/* 680 */     return (this.modifierKeyword == ModifierKeyword.NATIVE_KEYWORD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPrivate() {
/* 690 */     return (this.modifierKeyword == ModifierKeyword.PRIVATE_KEYWORD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isProtected() {
/* 700 */     return (this.modifierKeyword == ModifierKeyword.PROTECTED_KEYWORD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPublic() {
/* 710 */     return (this.modifierKeyword == ModifierKeyword.PUBLIC_KEYWORD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStatic() {
/* 720 */     return (this.modifierKeyword == ModifierKeyword.STATIC_KEYWORD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStrictfp() {
/* 730 */     return (this.modifierKeyword == ModifierKeyword.STRICTFP_KEYWORD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSynchronized() {
/* 740 */     return (this.modifierKeyword == ModifierKeyword.SYNCHRONIZED_KEYWORD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTransient() {
/* 750 */     return (this.modifierKeyword == ModifierKeyword.TRANSIENT_KEYWORD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVolatile() {
/* 760 */     return (this.modifierKeyword == ModifierKeyword.VOLATILE_KEYWORD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefault() {
/* 769 */     return (this.modifierKeyword == ModifierKeyword.DEFAULT_KEYWORD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSealed() {
/* 779 */     return (this.modifierKeyword == ModifierKeyword.SEALED_KEYWORD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNonSealed() {
/* 789 */     return (this.modifierKeyword == ModifierKeyword.NON_SEALED_KEYWORD);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 795 */     return 44;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeyword(ModifierKeyword modifierKeyord) {
/* 806 */     if (modifierKeyord == null) {
/* 807 */       throw new IllegalArgumentException();
/*     */     }
/* 809 */     preValueChange(KEYWORD_PROPERTY);
/* 810 */     this.modifierKeyword = modifierKeyord;
/* 811 */     postValueChange(KEYWORD_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 817 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 822 */     return memSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\Modifier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */