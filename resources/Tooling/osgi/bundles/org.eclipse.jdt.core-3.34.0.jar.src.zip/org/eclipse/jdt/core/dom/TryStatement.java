/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TryStatement
/*     */   extends Statement
/*     */ {
/*  50 */   public static final ChildListPropertyDescriptor RESOURCES_PROPERTY = new ChildListPropertyDescriptor(TryStatement.class, "resources", VariableDeclarationExpression.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public static final ChildListPropertyDescriptor RESOURCES2_PROPERTY = new ChildListPropertyDescriptor(TryStatement.class, "resources", Expression.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public static final ChildPropertyDescriptor BODY_PROPERTY = new ChildPropertyDescriptor(TryStatement.class, "body", Block.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public static final ChildListPropertyDescriptor CATCH_CLAUSES_PROPERTY = new ChildListPropertyDescriptor(TryStatement.class, "catchClauses", CatchClause.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public static final ChildPropertyDescriptor FINALLY_PROPERTY = new ChildPropertyDescriptor(TryStatement.class, "finally", Block.class, false, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_4_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_9_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 104 */     List propertyList = new ArrayList(4);
/* 105 */     createPropertyList(TryStatement.class, propertyList);
/* 106 */     addProperty(BODY_PROPERTY, propertyList);
/* 107 */     addProperty(CATCH_CLAUSES_PROPERTY, propertyList);
/* 108 */     addProperty(FINALLY_PROPERTY, propertyList);
/* 109 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */     
/* 111 */     propertyList = new ArrayList(5);
/* 112 */     createPropertyList(TryStatement.class, propertyList);
/* 113 */     addProperty(RESOURCES_PROPERTY, propertyList);
/* 114 */     addProperty(BODY_PROPERTY, propertyList);
/* 115 */     addProperty(CATCH_CLAUSES_PROPERTY, propertyList);
/* 116 */     addProperty(FINALLY_PROPERTY, propertyList);
/* 117 */     PROPERTY_DESCRIPTORS_4_0 = reapPropertyList(propertyList);
/*     */     
/* 119 */     propertyList = new ArrayList(5);
/* 120 */     createPropertyList(TryStatement.class, propertyList);
/* 121 */     addProperty(RESOURCES2_PROPERTY, propertyList);
/* 122 */     addProperty(BODY_PROPERTY, propertyList);
/* 123 */     addProperty(CATCH_CLAUSES_PROPERTY, propertyList);
/* 124 */     addProperty(FINALLY_PROPERTY, propertyList);
/* 125 */     PROPERTY_DESCRIPTORS_9_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 139 */     switch (apiLevel) {
/*     */       case 2:
/*     */       case 3:
/* 142 */         return PROPERTY_DESCRIPTORS;
/*     */       case 4:
/*     */       case 8:
/* 145 */         return PROPERTY_DESCRIPTORS_4_0;
/*     */     } 
/* 147 */     return PROPERTY_DESCRIPTORS_9_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   private ASTNode.NodeList resources = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   private Block body = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 171 */   private ASTNode.NodeList catchClauses = new ASTNode.NodeList(this, CATCH_CLAUSES_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 177 */   private Block optionalFinallyBody = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TryStatement(AST ast) {
/* 191 */     super(ast);
/* 192 */     if (ast.apiLevel >= 9) {
/* 193 */       this.resources = new ASTNode.NodeList(this, RESOURCES2_PROPERTY);
/* 194 */     } else if (ast.apiLevel >= 4) {
/* 195 */       this.resources = new ASTNode.NodeList(this, RESOURCES_PROPERTY);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 201 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 206 */     if (property == BODY_PROPERTY) {
/* 207 */       if (get) {
/* 208 */         return getBody();
/*     */       }
/* 210 */       setBody((Block)child);
/* 211 */       return null;
/*     */     } 
/*     */     
/* 214 */     if (property == FINALLY_PROPERTY) {
/* 215 */       if (get) {
/* 216 */         return getFinally();
/*     */       }
/* 218 */       setFinally((Block)child);
/* 219 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 223 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 228 */     if (property == RESOURCES_PROPERTY || property == RESOURCES2_PROPERTY) {
/* 229 */       return resources();
/*     */     }
/* 231 */     if (property == CATCH_CLAUSES_PROPERTY) {
/* 232 */       return catchClauses();
/*     */     }
/*     */     
/* 235 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 240 */     return 54;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 245 */     TryStatement result = new TryStatement(target);
/* 246 */     result.setSourceRange(getStartPosition(), getLength());
/* 247 */     result.copyLeadingComment(this);
/* 248 */     if (this.ast.apiLevel >= 4) {
/* 249 */       result.resources().addAll(
/* 250 */           ASTNode.copySubtrees(target, resources()));
/*     */     }
/* 252 */     result.setBody((Block)getBody().clone(target));
/* 253 */     result.catchClauses().addAll(
/* 254 */         ASTNode.copySubtrees(target, catchClauses()));
/* 255 */     result.setFinally(
/* 256 */         (Block)ASTNode.copySubtree(target, getFinally()));
/* 257 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 263 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 268 */     boolean visitChildren = visitor.visit(this);
/* 269 */     if (visitChildren) {
/*     */       
/* 271 */       if (this.ast.apiLevel >= 4) {
/* 272 */         acceptChildren(visitor, this.resources);
/*     */       }
/* 274 */       acceptChild(visitor, getBody());
/* 275 */       acceptChildren(visitor, this.catchClauses);
/* 276 */       acceptChild(visitor, getFinally());
/*     */     } 
/* 278 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Block getBody() {
/* 287 */     if (this.body == null)
/*     */     {
/* 289 */       synchronized (this) {
/* 290 */         if (this.body == null) {
/* 291 */           preLazyInit();
/* 292 */           this.body = new Block(this.ast);
/* 293 */           postLazyInit(this.body, BODY_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 297 */     return this.body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBody(Block body) {
/* 312 */     if (body == null) {
/* 313 */       throw new IllegalArgumentException();
/*     */     }
/* 315 */     ASTNode oldChild = this.body;
/* 316 */     preReplaceChild(oldChild, body, BODY_PROPERTY);
/* 317 */     this.body = body;
/* 318 */     postReplaceChild(oldChild, body, BODY_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List catchClauses() {
/* 328 */     return this.catchClauses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Block getFinally() {
/* 339 */     return this.optionalFinallyBody;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFinally(Block block) {
/* 355 */     ASTNode oldChild = this.optionalFinallyBody;
/* 356 */     preReplaceChild(oldChild, block, FINALLY_PROPERTY);
/* 357 */     this.optionalFinallyBody = block;
/* 358 */     postReplaceChild(oldChild, block, FINALLY_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List resources() {
/* 375 */     if (this.resources == null) {
/* 376 */       unsupportedIn2_3();
/*     */     }
/* 378 */     return this.resources;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 383 */     return super.memSize() + 16;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 388 */     return 
/* 389 */       memSize() + (
/* 390 */       (this.resources == null) ? 0 : this.resources.listSize()) + (
/* 391 */       (this.body == null) ? 0 : getBody().treeSize()) + 
/* 392 */       this.catchClauses.listSize() + (
/* 393 */       (this.optionalFinallyBody == null) ? 0 : getFinally().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\TryStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */