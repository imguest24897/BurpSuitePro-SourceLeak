/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CaseDefaultExpression
/*     */   extends Expression
/*     */ {
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */   
/*     */   static {
/*  38 */     List propertyList = new ArrayList(1);
/*  39 */     createPropertyList(CaseDefaultExpression.class, propertyList);
/*  40 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  54 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CaseDefaultExpression(AST ast) {
/*  66 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  71 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/*  76 */     return 109;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/*  81 */     CaseDefaultExpression result = new CaseDefaultExpression(target);
/*  82 */     result.setSourceRange(getStartPosition(), getLength());
/*  83 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/*  89 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/*  94 */     visitor.visit(this);
/*  95 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 100 */     return 40;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 105 */     return memSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\CaseDefaultExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */