/*      */ package org.eclipse.jdt.core;
/*      */ 
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.parser.ScannerHelper;
/*      */ import org.eclipse.jdt.internal.core.INamingRequestor;
/*      */ import org.eclipse.jdt.internal.core.InternalNamingConventions;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class NamingConventions
/*      */ {
/*      */   static class NamingRequestor
/*      */     implements INamingRequestor
/*      */   {
/*      */     private static final int SIZE = 10;
/*   63 */     private char[][] firstPrefixAndFirstSuffixResults = new char[10][];
/*   64 */     private int firstPrefixAndFirstSuffixResultsCount = 0;
/*   65 */     private char[][] firstPrefixAndSuffixResults = new char[10][];
/*   66 */     private int firstPrefixAndSuffixResultsCount = 0;
/*   67 */     private char[][] prefixAndFirstSuffixResults = new char[10][];
/*   68 */     private int prefixAndFirstSuffixResultsCount = 0;
/*   69 */     private char[][] prefixAndSuffixResults = new char[10][];
/*   70 */     private int prefixAndSuffixResultsCount = 0;
/*      */ 
/*      */     
/*   73 */     private char[][] firstPrefixResults = new char[10][];
/*   74 */     private int firstPrefixResultsCount = 0;
/*   75 */     private char[][] prefixResults = new char[10][];
/*   76 */     private int prefixResultsCount = 0;
/*      */ 
/*      */     
/*   79 */     private char[][] firstSuffixResults = new char[10][];
/*   80 */     private int firstSuffixResultsCount = 0;
/*   81 */     private char[][] suffixResults = new char[10][];
/*   82 */     private int suffixResultsCount = 0;
/*      */ 
/*      */     
/*   85 */     private char[][] otherResults = new char[10][];
/*   86 */     private int otherResultsCount = 0;
/*      */     
/*      */     public void acceptNameWithoutPrefixAndSuffix(char[] name, int reusedCharacters) {
/*   89 */       int length = this.otherResults.length;
/*   90 */       if (length == this.otherResultsCount) {
/*   91 */         System.arraycopy(
/*   92 */             this.otherResults, 
/*   93 */             0, 
/*   94 */             this.otherResults = new char[length * 2][], 
/*   95 */             0, 
/*   96 */             length);
/*      */       }
/*   98 */       this.otherResults[this.otherResultsCount++] = name;
/*      */     }
/*      */ 
/*      */     
/*      */     public void acceptNameWithPrefix(char[] name, boolean isFirstPrefix, int reusedCharacters) {
/*  103 */       if (isFirstPrefix) {
/*  104 */         int length = this.firstPrefixResults.length;
/*  105 */         if (length == this.firstPrefixResultsCount) {
/*  106 */           System.arraycopy(
/*  107 */               this.firstPrefixResults, 
/*  108 */               0, 
/*  109 */               this.firstPrefixResults = new char[length * 2][], 
/*  110 */               0, 
/*  111 */               length);
/*      */         }
/*  113 */         this.firstPrefixResults[this.firstPrefixResultsCount++] = name;
/*      */       } else {
/*  115 */         int length = this.prefixResults.length;
/*  116 */         if (length == this.prefixResultsCount) {
/*  117 */           System.arraycopy(
/*  118 */               this.prefixResults, 
/*  119 */               0, 
/*  120 */               this.prefixResults = new char[length * 2][], 
/*  121 */               0, 
/*  122 */               length);
/*      */         }
/*  124 */         this.prefixResults[this.prefixResultsCount++] = name;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void acceptNameWithPrefixAndSuffix(char[] name, boolean isFirstPrefix, boolean isFirstSuffix, int reusedCharacters) {
/*  130 */       if (isFirstPrefix && isFirstSuffix) {
/*  131 */         int length = this.firstPrefixAndFirstSuffixResults.length;
/*  132 */         if (length == this.firstPrefixAndFirstSuffixResultsCount) {
/*  133 */           System.arraycopy(
/*  134 */               this.firstPrefixAndFirstSuffixResults, 
/*  135 */               0, 
/*  136 */               this.firstPrefixAndFirstSuffixResults = new char[length * 2][], 
/*  137 */               0, 
/*  138 */               length);
/*      */         }
/*  140 */         this.firstPrefixAndFirstSuffixResults[this.firstPrefixAndFirstSuffixResultsCount++] = name;
/*  141 */       } else if (isFirstPrefix) {
/*  142 */         int length = this.firstPrefixAndSuffixResults.length;
/*  143 */         if (length == this.firstPrefixAndSuffixResultsCount) {
/*  144 */           System.arraycopy(
/*  145 */               this.firstPrefixAndSuffixResults, 
/*  146 */               0, 
/*  147 */               this.firstPrefixAndSuffixResults = new char[length * 2][], 
/*  148 */               0, 
/*  149 */               length);
/*      */         }
/*  151 */         this.firstPrefixAndSuffixResults[this.firstPrefixAndSuffixResultsCount++] = name;
/*  152 */       } else if (isFirstSuffix) {
/*  153 */         int length = this.prefixAndFirstSuffixResults.length;
/*  154 */         if (length == this.prefixAndFirstSuffixResultsCount) {
/*  155 */           System.arraycopy(
/*  156 */               this.prefixAndFirstSuffixResults, 
/*  157 */               0, 
/*  158 */               this.prefixAndFirstSuffixResults = new char[length * 2][], 
/*  159 */               0, 
/*  160 */               length);
/*      */         }
/*  162 */         this.prefixAndFirstSuffixResults[this.prefixAndFirstSuffixResultsCount++] = name;
/*      */       } else {
/*  164 */         int length = this.prefixAndSuffixResults.length;
/*  165 */         if (length == this.prefixAndSuffixResultsCount) {
/*  166 */           System.arraycopy(
/*  167 */               this.prefixAndSuffixResults, 
/*  168 */               0, 
/*  169 */               this.prefixAndSuffixResults = new char[length * 2][], 
/*  170 */               0, 
/*  171 */               length);
/*      */         }
/*  173 */         this.prefixAndSuffixResults[this.prefixAndSuffixResultsCount++] = name;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void acceptNameWithSuffix(char[] name, boolean isFirstSuffix, int reusedCharacters) {
/*  179 */       if (isFirstSuffix) {
/*  180 */         int length = this.firstSuffixResults.length;
/*  181 */         if (length == this.firstSuffixResultsCount) {
/*  182 */           System.arraycopy(
/*  183 */               this.firstSuffixResults, 
/*  184 */               0, 
/*  185 */               this.firstSuffixResults = new char[length * 2][], 
/*  186 */               0, 
/*  187 */               length);
/*      */         }
/*  189 */         this.firstSuffixResults[this.firstSuffixResultsCount++] = name;
/*      */       } else {
/*  191 */         int length = this.suffixResults.length;
/*  192 */         if (length == this.suffixResultsCount) {
/*  193 */           System.arraycopy(
/*  194 */               this.suffixResults, 
/*  195 */               0, 
/*  196 */               this.suffixResults = new char[length * 2][], 
/*  197 */               0, 
/*  198 */               length);
/*      */         }
/*  200 */         this.suffixResults[this.suffixResultsCount++] = name;
/*      */       } 
/*      */     }
/*      */     public char[][] getResults() {
/*  204 */       int count = 
/*  205 */         this.firstPrefixAndFirstSuffixResultsCount + 
/*  206 */         this.firstPrefixAndSuffixResultsCount + 
/*  207 */         this.prefixAndFirstSuffixResultsCount + 
/*  208 */         this.prefixAndSuffixResultsCount + 
/*  209 */         this.firstPrefixResultsCount + 
/*  210 */         this.prefixResultsCount + 
/*  211 */         this.firstSuffixResultsCount + 
/*  212 */         this.suffixResultsCount + 
/*  213 */         this.otherResultsCount;
/*      */       
/*  215 */       char[][] results = new char[count][];
/*      */       
/*  217 */       int index = 0;
/*  218 */       System.arraycopy(this.firstPrefixAndFirstSuffixResults, 0, results, index, this.firstPrefixAndFirstSuffixResultsCount);
/*  219 */       index += this.firstPrefixAndFirstSuffixResultsCount;
/*  220 */       System.arraycopy(this.firstPrefixAndSuffixResults, 0, results, index, this.firstPrefixAndSuffixResultsCount);
/*  221 */       index += this.firstPrefixAndSuffixResultsCount;
/*  222 */       System.arraycopy(this.prefixAndFirstSuffixResults, 0, results, index, this.prefixAndFirstSuffixResultsCount);
/*  223 */       index += this.prefixAndFirstSuffixResultsCount;
/*  224 */       System.arraycopy(this.prefixAndSuffixResults, 0, results, index, this.prefixAndSuffixResultsCount);
/*  225 */       index += this.prefixAndSuffixResultsCount;
/*  226 */       System.arraycopy(this.firstPrefixResults, 0, results, index, this.firstPrefixResultsCount);
/*  227 */       index += this.firstPrefixResultsCount;
/*  228 */       System.arraycopy(this.prefixResults, 0, results, index, this.prefixResultsCount);
/*  229 */       index += this.prefixResultsCount;
/*  230 */       System.arraycopy(this.firstSuffixResults, 0, results, index, this.firstSuffixResultsCount);
/*  231 */       index += this.firstSuffixResultsCount;
/*  232 */       System.arraycopy(this.suffixResults, 0, results, index, this.suffixResultsCount);
/*  233 */       index += this.suffixResultsCount;
/*  234 */       System.arraycopy(this.otherResults, 0, results, index, this.otherResultsCount);
/*      */       
/*  236 */       return results;
/*      */     }
/*      */   }
/*  239 */   private static final char[] GETTER_BOOL_NAME = "is".toCharArray();
/*  240 */   private static final char[] GETTER_NAME = "get".toCharArray();
/*      */   
/*  242 */   private static final char[] SETTER_NAME = "set".toCharArray();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int VK_STATIC_FIELD = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int VK_INSTANCE_FIELD = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int VK_STATIC_FINAL_FIELD = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int VK_PARAMETER = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int VK_LOCAL = 5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int BK_NAME = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int BK_TYPE_NAME = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] convertCharsToString(char[][] c) {
/*  297 */     int length = (c == null) ? 0 : c.length;
/*  298 */     String[] s = new String[length];
/*  299 */     for (int i = 0; i < length; i++) {
/*  300 */       s[i] = String.valueOf(c[i]);
/*      */     }
/*  302 */     return s;
/*      */   }
/*      */   private static char[][] convertStringToChars(String[] s) {
/*  305 */     int length = (s == null) ? 0 : s.length;
/*  306 */     char[][] c = new char[length][];
/*  307 */     for (int i = 0; i < length; i++) {
/*  308 */       if (s[i] == null) {
/*  309 */         c[i] = CharOperation.NO_CHAR;
/*      */       } else {
/*  311 */         c[i] = s[i].toCharArray();
/*      */       } 
/*      */     } 
/*  314 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] removePrefixAndSuffixForArgumentName(IJavaProject javaProject, char[] argumentName) {
/*  343 */     return InternalNamingConventions.removeVariablePrefixAndSuffix(4, javaProject, argumentName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removePrefixAndSuffixForArgumentName(IJavaProject javaProject, String argumentName) {
/*  372 */     return String.valueOf(removePrefixAndSuffixForArgumentName(javaProject, argumentName.toCharArray()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] removePrefixAndSuffixForFieldName(IJavaProject javaProject, char[] fieldName, int modifiers) {
/*  405 */     return InternalNamingConventions.removeVariablePrefixAndSuffix(
/*  406 */         Flags.isStatic(modifiers) ? 1 : 2, 
/*  407 */         javaProject, 
/*  408 */         fieldName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removePrefixAndSuffixForFieldName(IJavaProject javaProject, String fieldName, int modifiers) {
/*  442 */     return String.valueOf(removePrefixAndSuffixForFieldName(javaProject, fieldName.toCharArray(), modifiers));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] removePrefixAndSuffixForLocalVariableName(IJavaProject javaProject, char[] localName) {
/*  471 */     return InternalNamingConventions.removeVariablePrefixAndSuffix(5, javaProject, localName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removePrefixAndSuffixForLocalVariableName(IJavaProject javaProject, String localName) {
/*  500 */     return String.valueOf(removePrefixAndSuffixForLocalVariableName(javaProject, localName.toCharArray()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getBaseName(int variableKind, String variableName, IJavaProject javaProject) {
/*  538 */     return String.valueOf(InternalNamingConventions.getBaseName(variableKind, javaProject, variableName.toCharArray(), true));
/*      */   }
/*      */   
/*      */   private static int getFieldVariableKind(int modifiers) {
/*  542 */     if (Flags.isStatic(modifiers)) {
/*  543 */       if (Flags.isFinal(modifiers)) {
/*  544 */         return 3;
/*      */       }
/*  546 */       return 1;
/*      */     } 
/*  548 */     return 2;
/*      */   }
/*      */   
/*      */   private static char[] suggestAccessorName(IJavaProject project, char[] fieldName, int modifiers) {
/*  552 */     char[] name = InternalNamingConventions.getBaseName(getFieldVariableKind(modifiers), project, fieldName, false);
/*  553 */     if (name.length > 0 && ScannerHelper.isLowerCase(name[0]) && (
/*  554 */       name.length == 1 || !ScannerHelper.isUpperCase(name[1]))) {
/*  555 */       name[0] = ScannerHelper.toUpperCase(name[0]);
/*      */     }
/*      */     
/*  558 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[][] suggestArgumentNames(IJavaProject javaProject, char[] packageName, char[] qualifiedTypeName, int dim, char[][] excludedNames) {
/*  592 */     if (qualifiedTypeName == null || qualifiedTypeName.length == 0) {
/*  593 */       return CharOperation.NO_CHAR_CHAR;
/*      */     }
/*  595 */     char[] typeName = CharOperation.lastSegment(qualifiedTypeName, '.');
/*      */     
/*  597 */     NamingRequestor requestor = new NamingRequestor();
/*  598 */     InternalNamingConventions.suggestVariableNames(
/*  599 */         4, 
/*  600 */         2, 
/*  601 */         typeName, 
/*  602 */         javaProject, 
/*  603 */         dim, 
/*  604 */         null, 
/*  605 */         excludedNames, 
/*  606 */         true, 
/*  607 */         requestor);
/*      */     
/*  609 */     return requestor.getResults();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] suggestArgumentNames(IJavaProject javaProject, String packageName, String qualifiedTypeName, int dim, String[] excludedNames) {
/*  643 */     return convertCharsToString(
/*  644 */         suggestArgumentNames(
/*  645 */           javaProject, 
/*  646 */           packageName.toCharArray(), 
/*  647 */           qualifiedTypeName.toCharArray(), 
/*  648 */           dim, 
/*  649 */           convertStringToChars(excludedNames)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[][] suggestFieldNames(IJavaProject javaProject, char[] packageName, char[] qualifiedTypeName, int dim, int modifiers, char[][] excludedNames) {
/*  688 */     if (qualifiedTypeName == null || qualifiedTypeName.length == 0) {
/*  689 */       return CharOperation.NO_CHAR_CHAR;
/*      */     }
/*  691 */     char[] typeName = CharOperation.lastSegment(qualifiedTypeName, '.');
/*      */     
/*  693 */     NamingRequestor requestor = new NamingRequestor();
/*  694 */     InternalNamingConventions.suggestVariableNames(
/*  695 */         Flags.isStatic(modifiers) ? 1 : 2, 
/*  696 */         2, 
/*  697 */         typeName, 
/*  698 */         javaProject, 
/*  699 */         dim, 
/*  700 */         null, 
/*  701 */         excludedNames, 
/*  702 */         true, 
/*  703 */         requestor);
/*      */     
/*  705 */     return requestor.getResults();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] suggestFieldNames(IJavaProject javaProject, String packageName, String qualifiedTypeName, int dim, int modifiers, String[] excludedNames) {
/*  744 */     return convertCharsToString(
/*  745 */         suggestFieldNames(
/*  746 */           javaProject, 
/*  747 */           packageName.toCharArray(), 
/*  748 */           qualifiedTypeName.toCharArray(), 
/*  749 */           dim, 
/*  750 */           modifiers, 
/*  751 */           convertStringToChars(excludedNames)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] suggestGetterName(IJavaProject project, char[] fieldName, int modifiers, boolean isBoolean, char[][] excludedNames) {
/*  786 */     if (isBoolean) {
/*  787 */       char[] name = InternalNamingConventions.getBaseName(getFieldVariableKind(modifiers), project, fieldName, false);
/*  788 */       int prefixLen = GETTER_BOOL_NAME.length;
/*  789 */       if (CharOperation.prefixEquals(GETTER_BOOL_NAME, name) && 
/*  790 */         name.length > prefixLen && ScannerHelper.isUpperCase(name[prefixLen])) {
/*  791 */         return suggestNewName(name, excludedNames);
/*      */       }
/*  793 */       return suggestNewName(
/*  794 */           CharOperation.concat(GETTER_BOOL_NAME, suggestAccessorName(project, fieldName, modifiers)), 
/*  795 */           excludedNames);
/*      */     } 
/*      */ 
/*      */     
/*  799 */     return suggestNewName(
/*  800 */         CharOperation.concat(GETTER_NAME, suggestAccessorName(project, fieldName, modifiers)), 
/*  801 */         excludedNames);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String suggestGetterName(IJavaProject project, String fieldName, int modifiers, boolean isBoolean, String[] excludedNames) {
/*  837 */     return String.valueOf(
/*  838 */         suggestGetterName(
/*  839 */           project, 
/*  840 */           fieldName.toCharArray(), 
/*  841 */           modifiers, 
/*  842 */           isBoolean, 
/*  843 */           convertStringToChars(excludedNames)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[][] suggestLocalVariableNames(IJavaProject javaProject, char[] packageName, char[] qualifiedTypeName, int dim, char[][] excludedNames) {
/*  876 */     if (qualifiedTypeName == null || qualifiedTypeName.length == 0) {
/*  877 */       return CharOperation.NO_CHAR_CHAR;
/*      */     }
/*  879 */     char[] typeName = CharOperation.lastSegment(qualifiedTypeName, '.');
/*      */     
/*  881 */     NamingRequestor requestor = new NamingRequestor();
/*  882 */     InternalNamingConventions.suggestVariableNames(
/*  883 */         5, 
/*  884 */         2, 
/*  885 */         typeName, 
/*  886 */         javaProject, 
/*  887 */         dim, 
/*  888 */         null, 
/*  889 */         excludedNames, 
/*  890 */         true, 
/*  891 */         requestor);
/*      */     
/*  893 */     return requestor.getResults();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] suggestLocalVariableNames(IJavaProject javaProject, String packageName, String qualifiedTypeName, int dim, String[] excludedNames) {
/*  927 */     return convertCharsToString(
/*  928 */         suggestLocalVariableNames(
/*  929 */           javaProject, 
/*  930 */           packageName.toCharArray(), 
/*  931 */           qualifiedTypeName.toCharArray(), 
/*  932 */           dim, 
/*  933 */           convertStringToChars(excludedNames)));
/*      */   }
/*      */   private static char[] suggestNewName(char[] name, char[][] excludedNames) {
/*  936 */     if (excludedNames == null) {
/*  937 */       return name;
/*      */     }
/*      */     
/*  940 */     char[] newName = name;
/*  941 */     int count = 2;
/*  942 */     int i = 0;
/*  943 */     while (i < excludedNames.length) {
/*  944 */       if (CharOperation.equals(newName, excludedNames[i], false)) {
/*  945 */         newName = CharOperation.concat(name, String.valueOf(count++).toCharArray());
/*  946 */         i = 0; continue;
/*      */       } 
/*  948 */       i++;
/*      */     } 
/*      */     
/*  951 */     return newName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] suggestSetterName(IJavaProject project, char[] fieldName, int modifiers, boolean isBoolean, char[][] excludedNames) {
/*  986 */     if (isBoolean) {
/*  987 */       char[] name = InternalNamingConventions.getBaseName(getFieldVariableKind(modifiers), project, fieldName, false);
/*  988 */       int prefixLen = GETTER_BOOL_NAME.length;
/*  989 */       if (CharOperation.prefixEquals(GETTER_BOOL_NAME, name) && 
/*  990 */         name.length > prefixLen && ScannerHelper.isUpperCase(name[prefixLen])) {
/*  991 */         name = CharOperation.subarray(name, prefixLen, name.length);
/*  992 */         return suggestNewName(
/*  993 */             CharOperation.concat(SETTER_NAME, suggestAccessorName(project, name, modifiers)), 
/*  994 */             excludedNames);
/*      */       } 
/*      */       
/*  997 */       return suggestNewName(
/*  998 */           CharOperation.concat(SETTER_NAME, suggestAccessorName(project, fieldName, modifiers)), 
/*  999 */           excludedNames);
/*      */     } 
/*      */ 
/*      */     
/* 1003 */     return suggestNewName(
/* 1004 */         CharOperation.concat(SETTER_NAME, suggestAccessorName(project, fieldName, modifiers)), 
/* 1005 */         excludedNames);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String suggestSetterName(IJavaProject project, String fieldName, int modifiers, boolean isBoolean, String[] excludedNames) {
/* 1040 */     return String.valueOf(
/* 1041 */         suggestSetterName(
/* 1042 */           project, 
/* 1043 */           fieldName.toCharArray(), 
/* 1044 */           modifiers, 
/* 1045 */           isBoolean, 
/* 1046 */           convertStringToChars(excludedNames)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] suggestVariableNames(int variableKind, int baseNameKind, String baseName, IJavaProject javaProject, int dim, String[] excluded, boolean evaluateDefault) {
/* 1131 */     NamingRequestor requestor = new NamingRequestor();
/* 1132 */     InternalNamingConventions.suggestVariableNames(
/* 1133 */         variableKind, 
/* 1134 */         baseNameKind, 
/* 1135 */         baseName.toCharArray(), 
/* 1136 */         javaProject, 
/* 1137 */         dim, 
/* 1138 */         null, 
/* 1139 */         convertStringToChars(excluded), 
/* 1140 */         evaluateDefault, 
/* 1141 */         requestor);
/*      */     
/* 1143 */     return convertCharsToString(requestor.getResults());
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\NamingConventions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */