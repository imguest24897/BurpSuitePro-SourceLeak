/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.ModuleReference;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnModuleReference
/*    */   extends ModuleReference
/*    */ {
/*    */   public CompletionOnModuleReference(char[] ident, long pos) {
/* 24 */     this(new char[][] { ident }, new long[] { pos });
/*    */   }
/*    */   public CompletionOnModuleReference(char[][] tokens, long[] sourcePositions) {
/* 27 */     super(tokens, sourcePositions);
/*    */   }
/*    */ 
/*    */   
/*    */   public ModuleBinding resolve(Scope scope) {
/* 32 */     super.resolve(scope);
/*    */ 
/*    */ 
/*    */     
/* 36 */     throw new CompletionNodeFound();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public StringBuffer print(int indent, StringBuffer output) {
/* 42 */     printIndent(indent, output).append("<CompleteOnModuleReference:");
/* 43 */     for (int i = 0; i < this.tokens.length; i++) {
/* 44 */       if (i > 0) output.append('.'); 
/* 45 */       output.append(this.tokens[i]);
/*    */     } 
/* 47 */     return output.append('>');
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnModuleReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */