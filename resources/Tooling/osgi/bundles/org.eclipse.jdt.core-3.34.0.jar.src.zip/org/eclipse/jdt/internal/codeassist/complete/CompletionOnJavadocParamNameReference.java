/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.JavadocSingleNameReference;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnJavadocParamNameReference
/*    */   extends JavadocSingleNameReference
/*    */   implements CompletionOnJavadoc
/*    */ {
/* 21 */   public int completionFlags = 1;
/*    */   public char[][] missingParams;
/*    */   public char[][] missingTypeParams;
/*    */   
/*    */   public CompletionOnJavadocParamNameReference(char[] name, long pos, int start, int end) {
/* 26 */     super(name, pos, start, end);
/*    */   }
/*    */   
/*    */   public CompletionOnJavadocParamNameReference(JavadocSingleNameReference nameRef) {
/* 30 */     super(nameRef.token, (nameRef.sourceStart << 32L) + nameRef.sourceEnd, nameRef.tagSourceStart, nameRef.tagSourceStart);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addCompletionFlags(int flags) {
/* 35 */     this.completionFlags |= flags;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getCompletionFlags() {
/* 40 */     return this.completionFlags;
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 45 */     output.append("<CompletionOnJavadocParamNameReference:");
/* 46 */     if (this.token != null) super.printExpression(indent, output); 
/* 47 */     return output.append('>');
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeBinding reportError(BlockScope scope) {
/* 52 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnJavadocParamNameReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */