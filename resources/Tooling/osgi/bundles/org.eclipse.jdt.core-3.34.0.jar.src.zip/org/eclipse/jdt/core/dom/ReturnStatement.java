/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReturnStatement
/*     */   extends Statement
/*     */ {
/*  39 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(ReturnStatement.class, "expression", Expression.class, false, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  49 */     List propertyList = new ArrayList(2);
/*  50 */     createPropertyList(ReturnStatement.class, propertyList);
/*  51 */     addProperty(EXPRESSION_PROPERTY, propertyList);
/*  52 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  66 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private Expression optionalExpression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ReturnStatement(AST ast) {
/*  81 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  86 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/*  91 */     if (property == EXPRESSION_PROPERTY) {
/*  92 */       if (get) {
/*  93 */         return getExpression();
/*     */       }
/*  95 */       setExpression((Expression)child);
/*  96 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 100 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 105 */     return 41;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 110 */     ReturnStatement result = new ReturnStatement(target);
/* 111 */     result.setSourceRange(getStartPosition(), getLength());
/* 112 */     result.copyLeadingComment(this);
/* 113 */     result.setExpression(
/* 114 */         (Expression)ASTNode.copySubtree(target, getExpression()));
/* 115 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 121 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 126 */     boolean visitChildren = visitor.visit(this);
/* 127 */     if (visitChildren) {
/* 128 */       acceptChild(visitor, getExpression());
/*     */     }
/* 130 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 140 */     return this.optionalExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 156 */     ASTNode oldChild = this.optionalExpression;
/* 157 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 158 */     this.optionalExpression = expression;
/* 159 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 164 */     return super.memSize() + 4;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 169 */     return 
/* 170 */       memSize() + (
/* 171 */       (this.optionalExpression == null) ? 0 : getExpression().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ReturnStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */