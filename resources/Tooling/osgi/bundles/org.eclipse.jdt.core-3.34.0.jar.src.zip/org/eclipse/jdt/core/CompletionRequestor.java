/*     */ package org.eclipse.jdt.core;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.IProblem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CompletionRequestor
/*     */ {
/*  66 */   private int ignoreSet = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] favoriteReferences;
/*     */ 
/*     */ 
/*     */   
/*  75 */   private int[] requiredProposalAllowSet = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean requireExtendedContext = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompletionRequestor() {
/*  87 */     this(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompletionRequestor(boolean ignoreAll) {
/* 104 */     this.ignoreSet = ignoreAll ? -1 : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIgnored(int completionProposalKind) {
/* 119 */     if (completionProposalKind < 1 || 
/* 120 */       completionProposalKind > 30) {
/* 121 */       throw new IllegalArgumentException("Unknown kind of completion proposal: " + completionProposalKind);
/*     */     }
/* 123 */     return ((this.ignoreSet & 1 << completionProposalKind) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnored(int completionProposalKind, boolean ignore) {
/* 138 */     if (completionProposalKind < 1 || 
/* 139 */       completionProposalKind > 30) {
/* 140 */       throw new IllegalArgumentException("Unknown kind of completion proposal: " + completionProposalKind);
/*     */     }
/* 142 */     if (ignore) {
/* 143 */       this.ignoreSet |= 1 << completionProposalKind;
/*     */     } else {
/* 145 */       this.ignoreSet &= 1 << completionProposalKind ^ 0xFFFFFFFF;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIgnored(char[] fullTypeName) {
/* 159 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAllowingRequiredProposals(int proposalKind, int requiredProposalKind) {
/* 182 */     if (proposalKind < 1 || 
/* 183 */       proposalKind > 30) {
/* 184 */       throw new IllegalArgumentException("Unknown kind of completion proposal: " + requiredProposalKind);
/*     */     }
/*     */     
/* 187 */     if (requiredProposalKind < 1 || 
/* 188 */       requiredProposalKind > 30) {
/* 189 */       throw new IllegalArgumentException("Unknown required kind of completion proposal: " + requiredProposalKind);
/*     */     }
/* 191 */     if (this.requiredProposalAllowSet == null) return false;
/*     */     
/* 193 */     return ((this.requiredProposalAllowSet[proposalKind] & 1 << requiredProposalKind) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAllowsRequiredProposals(int proposalKind, int requiredProposalKind, boolean allow) {
/* 220 */     if (proposalKind < 1 || 
/* 221 */       proposalKind > 30) {
/* 222 */       throw new IllegalArgumentException("Unknown kind of completion proposal: " + requiredProposalKind);
/*     */     }
/* 224 */     if (requiredProposalKind < 1 || 
/* 225 */       requiredProposalKind > 30) {
/* 226 */       throw new IllegalArgumentException("Unknown required kind of completion proposal: " + requiredProposalKind);
/*     */     }
/*     */     
/* 229 */     if (this.requiredProposalAllowSet == null) {
/* 230 */       this.requiredProposalAllowSet = new int[31];
/*     */     }
/*     */     
/* 233 */     if (allow) {
/* 234 */       this.requiredProposalAllowSet[proposalKind] = this.requiredProposalAllowSet[proposalKind] | 1 << requiredProposalKind;
/*     */     } else {
/* 236 */       this.requiredProposalAllowSet[proposalKind] = this.requiredProposalAllowSet[proposalKind] & (1 << requiredProposalKind ^ 0xFFFFFFFF);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getFavoriteReferences() {
/* 260 */     return this.favoriteReferences;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFavoriteReferences(String[] favoriteImports) {
/* 274 */     this.favoriteReferences = favoriteImports;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beginReporting() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endReporting() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void completionFailure(IProblem problem) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void accept(CompletionProposal paramCompletionProposal);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void acceptContext(CompletionContext context) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExtendedContextRequired() {
/* 360 */     return this.requireExtendedContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRequireExtendedContext(boolean require) {
/* 374 */     this.requireExtendedContext = require;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTestCodeExcluded() {
/* 385 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\CompletionRequestor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */