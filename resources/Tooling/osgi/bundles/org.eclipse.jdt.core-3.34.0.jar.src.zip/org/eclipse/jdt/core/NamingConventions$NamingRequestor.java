/*     */ package org.eclipse.jdt.core;
/*     */ 
/*     */ import org.eclipse.jdt.internal.core.INamingRequestor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NamingRequestor
/*     */   implements INamingRequestor
/*     */ {
/*     */   private static final int SIZE = 10;
/*  63 */   private char[][] firstPrefixAndFirstSuffixResults = new char[10][];
/*  64 */   private int firstPrefixAndFirstSuffixResultsCount = 0;
/*  65 */   private char[][] firstPrefixAndSuffixResults = new char[10][];
/*  66 */   private int firstPrefixAndSuffixResultsCount = 0;
/*  67 */   private char[][] prefixAndFirstSuffixResults = new char[10][];
/*  68 */   private int prefixAndFirstSuffixResultsCount = 0;
/*  69 */   private char[][] prefixAndSuffixResults = new char[10][];
/*  70 */   private int prefixAndSuffixResultsCount = 0;
/*     */ 
/*     */   
/*  73 */   private char[][] firstPrefixResults = new char[10][];
/*  74 */   private int firstPrefixResultsCount = 0;
/*  75 */   private char[][] prefixResults = new char[10][];
/*  76 */   private int prefixResultsCount = 0;
/*     */ 
/*     */   
/*  79 */   private char[][] firstSuffixResults = new char[10][];
/*  80 */   private int firstSuffixResultsCount = 0;
/*  81 */   private char[][] suffixResults = new char[10][];
/*  82 */   private int suffixResultsCount = 0;
/*     */ 
/*     */   
/*  85 */   private char[][] otherResults = new char[10][];
/*  86 */   private int otherResultsCount = 0;
/*     */   
/*     */   public void acceptNameWithoutPrefixAndSuffix(char[] name, int reusedCharacters) {
/*  89 */     int length = this.otherResults.length;
/*  90 */     if (length == this.otherResultsCount) {
/*  91 */       System.arraycopy(
/*  92 */           this.otherResults, 
/*  93 */           0, 
/*  94 */           this.otherResults = new char[length * 2][], 
/*  95 */           0, 
/*  96 */           length);
/*     */     }
/*  98 */     this.otherResults[this.otherResultsCount++] = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public void acceptNameWithPrefix(char[] name, boolean isFirstPrefix, int reusedCharacters) {
/* 103 */     if (isFirstPrefix) {
/* 104 */       int length = this.firstPrefixResults.length;
/* 105 */       if (length == this.firstPrefixResultsCount) {
/* 106 */         System.arraycopy(
/* 107 */             this.firstPrefixResults, 
/* 108 */             0, 
/* 109 */             this.firstPrefixResults = new char[length * 2][], 
/* 110 */             0, 
/* 111 */             length);
/*     */       }
/* 113 */       this.firstPrefixResults[this.firstPrefixResultsCount++] = name;
/*     */     } else {
/* 115 */       int length = this.prefixResults.length;
/* 116 */       if (length == this.prefixResultsCount) {
/* 117 */         System.arraycopy(
/* 118 */             this.prefixResults, 
/* 119 */             0, 
/* 120 */             this.prefixResults = new char[length * 2][], 
/* 121 */             0, 
/* 122 */             length);
/*     */       }
/* 124 */       this.prefixResults[this.prefixResultsCount++] = name;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void acceptNameWithPrefixAndSuffix(char[] name, boolean isFirstPrefix, boolean isFirstSuffix, int reusedCharacters) {
/* 130 */     if (isFirstPrefix && isFirstSuffix) {
/* 131 */       int length = this.firstPrefixAndFirstSuffixResults.length;
/* 132 */       if (length == this.firstPrefixAndFirstSuffixResultsCount) {
/* 133 */         System.arraycopy(
/* 134 */             this.firstPrefixAndFirstSuffixResults, 
/* 135 */             0, 
/* 136 */             this.firstPrefixAndFirstSuffixResults = new char[length * 2][], 
/* 137 */             0, 
/* 138 */             length);
/*     */       }
/* 140 */       this.firstPrefixAndFirstSuffixResults[this.firstPrefixAndFirstSuffixResultsCount++] = name;
/* 141 */     } else if (isFirstPrefix) {
/* 142 */       int length = this.firstPrefixAndSuffixResults.length;
/* 143 */       if (length == this.firstPrefixAndSuffixResultsCount) {
/* 144 */         System.arraycopy(
/* 145 */             this.firstPrefixAndSuffixResults, 
/* 146 */             0, 
/* 147 */             this.firstPrefixAndSuffixResults = new char[length * 2][], 
/* 148 */             0, 
/* 149 */             length);
/*     */       }
/* 151 */       this.firstPrefixAndSuffixResults[this.firstPrefixAndSuffixResultsCount++] = name;
/* 152 */     } else if (isFirstSuffix) {
/* 153 */       int length = this.prefixAndFirstSuffixResults.length;
/* 154 */       if (length == this.prefixAndFirstSuffixResultsCount) {
/* 155 */         System.arraycopy(
/* 156 */             this.prefixAndFirstSuffixResults, 
/* 157 */             0, 
/* 158 */             this.prefixAndFirstSuffixResults = new char[length * 2][], 
/* 159 */             0, 
/* 160 */             length);
/*     */       }
/* 162 */       this.prefixAndFirstSuffixResults[this.prefixAndFirstSuffixResultsCount++] = name;
/*     */     } else {
/* 164 */       int length = this.prefixAndSuffixResults.length;
/* 165 */       if (length == this.prefixAndSuffixResultsCount) {
/* 166 */         System.arraycopy(
/* 167 */             this.prefixAndSuffixResults, 
/* 168 */             0, 
/* 169 */             this.prefixAndSuffixResults = new char[length * 2][], 
/* 170 */             0, 
/* 171 */             length);
/*     */       }
/* 173 */       this.prefixAndSuffixResults[this.prefixAndSuffixResultsCount++] = name;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void acceptNameWithSuffix(char[] name, boolean isFirstSuffix, int reusedCharacters) {
/* 179 */     if (isFirstSuffix) {
/* 180 */       int length = this.firstSuffixResults.length;
/* 181 */       if (length == this.firstSuffixResultsCount) {
/* 182 */         System.arraycopy(
/* 183 */             this.firstSuffixResults, 
/* 184 */             0, 
/* 185 */             this.firstSuffixResults = new char[length * 2][], 
/* 186 */             0, 
/* 187 */             length);
/*     */       }
/* 189 */       this.firstSuffixResults[this.firstSuffixResultsCount++] = name;
/*     */     } else {
/* 191 */       int length = this.suffixResults.length;
/* 192 */       if (length == this.suffixResultsCount) {
/* 193 */         System.arraycopy(
/* 194 */             this.suffixResults, 
/* 195 */             0, 
/* 196 */             this.suffixResults = new char[length * 2][], 
/* 197 */             0, 
/* 198 */             length);
/*     */       }
/* 200 */       this.suffixResults[this.suffixResultsCount++] = name;
/*     */     } 
/*     */   }
/*     */   public char[][] getResults() {
/* 204 */     int count = 
/* 205 */       this.firstPrefixAndFirstSuffixResultsCount + 
/* 206 */       this.firstPrefixAndSuffixResultsCount + 
/* 207 */       this.prefixAndFirstSuffixResultsCount + 
/* 208 */       this.prefixAndSuffixResultsCount + 
/* 209 */       this.firstPrefixResultsCount + 
/* 210 */       this.prefixResultsCount + 
/* 211 */       this.firstSuffixResultsCount + 
/* 212 */       this.suffixResultsCount + 
/* 213 */       this.otherResultsCount;
/*     */     
/* 215 */     char[][] results = new char[count][];
/*     */     
/* 217 */     int index = 0;
/* 218 */     System.arraycopy(this.firstPrefixAndFirstSuffixResults, 0, results, index, this.firstPrefixAndFirstSuffixResultsCount);
/* 219 */     index += this.firstPrefixAndFirstSuffixResultsCount;
/* 220 */     System.arraycopy(this.firstPrefixAndSuffixResults, 0, results, index, this.firstPrefixAndSuffixResultsCount);
/* 221 */     index += this.firstPrefixAndSuffixResultsCount;
/* 222 */     System.arraycopy(this.prefixAndFirstSuffixResults, 0, results, index, this.prefixAndFirstSuffixResultsCount);
/* 223 */     index += this.prefixAndFirstSuffixResultsCount;
/* 224 */     System.arraycopy(this.prefixAndSuffixResults, 0, results, index, this.prefixAndSuffixResultsCount);
/* 225 */     index += this.prefixAndSuffixResultsCount;
/* 226 */     System.arraycopy(this.firstPrefixResults, 0, results, index, this.firstPrefixResultsCount);
/* 227 */     index += this.firstPrefixResultsCount;
/* 228 */     System.arraycopy(this.prefixResults, 0, results, index, this.prefixResultsCount);
/* 229 */     index += this.prefixResultsCount;
/* 230 */     System.arraycopy(this.firstSuffixResults, 0, results, index, this.firstSuffixResultsCount);
/* 231 */     index += this.firstSuffixResultsCount;
/* 232 */     System.arraycopy(this.suffixResults, 0, results, index, this.suffixResultsCount);
/* 233 */     index += this.suffixResultsCount;
/* 234 */     System.arraycopy(this.otherResults, 0, results, index, this.otherResultsCount);
/*     */     
/* 236 */     return results;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\NamingConventions$NamingRequestor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */