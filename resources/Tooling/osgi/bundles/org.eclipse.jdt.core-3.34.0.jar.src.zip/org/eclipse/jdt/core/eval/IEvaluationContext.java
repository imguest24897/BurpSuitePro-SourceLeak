package org.eclipse.jdt.core.eval;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.CompletionRequestor;
import org.eclipse.jdt.core.ICodeCompletionRequestor;
import org.eclipse.jdt.core.ICompletionRequestor;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.WorkingCopyOwner;

public interface IEvaluationContext {
  IGlobalVariable[] allVariables();
  
  void codeComplete(String paramString, int paramInt, ICompletionRequestor paramICompletionRequestor) throws JavaModelException;
  
  void codeComplete(String paramString, int paramInt, ICompletionRequestor paramICompletionRequestor, WorkingCopyOwner paramWorkingCopyOwner) throws JavaModelException;
  
  void codeComplete(String paramString, int paramInt, CompletionRequestor paramCompletionRequestor) throws JavaModelException;
  
  void codeComplete(String paramString, int paramInt, CompletionRequestor paramCompletionRequestor, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void codeComplete(String paramString, int paramInt, CompletionRequestor paramCompletionRequestor, WorkingCopyOwner paramWorkingCopyOwner) throws JavaModelException;
  
  void codeComplete(String paramString, int paramInt, CompletionRequestor paramCompletionRequestor, WorkingCopyOwner paramWorkingCopyOwner, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  IJavaElement[] codeSelect(String paramString, int paramInt1, int paramInt2) throws JavaModelException;
  
  IJavaElement[] codeSelect(String paramString, int paramInt1, int paramInt2, WorkingCopyOwner paramWorkingCopyOwner) throws JavaModelException;
  
  void deleteVariable(IGlobalVariable paramIGlobalVariable);
  
  void evaluateCodeSnippet(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2, int[] paramArrayOfint, IType paramIType, boolean paramBoolean1, boolean paramBoolean2, ICodeSnippetRequestor paramICodeSnippetRequestor, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void evaluateCodeSnippet(String paramString, ICodeSnippetRequestor paramICodeSnippetRequestor, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void evaluateVariable(IGlobalVariable paramIGlobalVariable, ICodeSnippetRequestor paramICodeSnippetRequestor, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  String[] getImports();
  
  String getPackageName();
  
  IJavaProject getProject();
  
  IGlobalVariable newVariable(String paramString1, String paramString2, String paramString3);
  
  void setImports(String[] paramArrayOfString);
  
  void setPackageName(String paramString);
  
  void validateImports(ICodeSnippetRequestor paramICodeSnippetRequestor) throws JavaModelException;
  
  void codeComplete(String paramString, int paramInt, ICodeCompletionRequestor paramICodeCompletionRequestor) throws JavaModelException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\eval\IEvaluationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */