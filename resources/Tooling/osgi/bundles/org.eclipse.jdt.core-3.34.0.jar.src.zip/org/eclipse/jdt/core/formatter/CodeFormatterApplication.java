/*     */ package org.eclipse.jdt.core.formatter;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.eclipse.equinox.app.IApplication;
/*     */ import org.eclipse.equinox.app.IApplicationContext;
/*     */ import org.eclipse.jdt.core.ToolFactory;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ import org.eclipse.jdt.internal.core.util.Util;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.Document;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.text.edits.TextEdit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodeFormatterApplication
/*     */   implements IApplication
/*     */ {
/*     */   private static final String ARG_CONFIG = "-config";
/*     */   private static final String ARG_HELP = "-help";
/*     */   private static final String ARG_QUIET = "-quiet";
/*     */   private static final String ARG_VERBOSE = "-verbose";
/*     */   private String configName;
/*     */   
/*     */   private static final class Messages
/*     */     extends NLS
/*     */   {
/*     */     private static final String BUNDLE_NAME = "org.eclipse.jdt.core.formatter.messages";
/*     */     public static String CommandLineConfigFile;
/*     */     public static String CommandLineDone;
/*     */     public static String CommandLineErrorConfig;
/*     */     public static String CommandLineErrorFileTryFullPath;
/*     */     public static String CommandLineErrorFile;
/*     */     public static String CommandLineErrorFileDir;
/*     */     public static String CommandLineErrorQuietVerbose;
/*     */     public static String CommandLineErrorNoConfigFile;
/*     */     public static String CommandLineFormatting;
/*     */     public static String CommandLineStart;
/*     */     public static String CommandLineUsage;
/*     */     public static String ConfigFileNotFoundErrorTryFullPath;
/*     */     public static String ConfigFileReadingError;
/*     */     public static String FormatProblem;
/*     */     public static String CaughtException;
/*     */     public static String ExceptionSkip;
/*     */     
/*     */     static {
/*  99 */       NLS.initializeMessages("org.eclipse.jdt.core.formatter.messages", Messages.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static String bind(String message) {
/* 111 */       return bind(message, (Object[])null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static String bind(String message, Object binding) {
/* 125 */       return bind(message, new Object[] {
/* 126 */             binding
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static String bind(String message, Object binding1, Object binding2) {
/* 143 */       return bind(message, new Object[] {
/* 144 */             binding1, binding2
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static String bind(String message, Object[] bindings) {
/* 159 */       return MessageFormat.format(message, bindings);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   private Map options = null;
/*     */ 
/*     */   
/*     */   private static final String PDE_LAUNCH = "-pdelaunch";
/*     */ 
/*     */   
/*     */   private boolean quiet = false;
/*     */   
/*     */   private boolean verbose = false;
/*     */ 
/*     */   
/*     */   private void displayHelp() {
/* 185 */     System.out.println(Messages.bind(Messages.CommandLineUsage));
/*     */   }
/*     */   
/*     */   private void displayHelp(String message) {
/* 189 */     System.err.println(message);
/* 190 */     System.out.println();
/* 191 */     displayHelp();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void formatDirTree(File dir, CodeFormatter codeFormatter) {
/* 200 */     File[] files = dir.listFiles();
/* 201 */     if (files == null) {
/*     */       return;
/*     */     }
/* 204 */     for (int i = 0; i < files.length; i++) {
/* 205 */       File file = files[i];
/* 206 */       if (file.isDirectory()) {
/* 207 */         formatDirTree(file, codeFormatter);
/* 208 */       } else if (Util.isJavaLikeFileName(file.getPath())) {
/* 209 */         formatFile(file, codeFormatter);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void formatFile(File file, CodeFormatter codeFormatter) {
/* 218 */     Document document = new Document();
/*     */     
/*     */     try {
/* 221 */       if (this.verbose) {
/* 222 */         System.out.println(Messages.bind(Messages.CommandLineFormatting, file.getAbsolutePath()));
/*     */       }
/* 224 */       String contents = new String(Util.getFileCharContent(file, null));
/*     */       
/* 226 */       document.set(contents);
/* 227 */       int kind = (file.getName().equals("module-info.java") ? 128 : 
/* 228 */         8) | 0x1000;
/* 229 */       TextEdit edit = codeFormatter.format(kind, contents, 0, contents.length(), 0, null);
/* 230 */       if (edit != null) {
/* 231 */         edit.apply((IDocument)document);
/*     */       } else {
/* 233 */         System.err.println(Messages.bind(Messages.FormatProblem, file.getAbsolutePath()));
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 238 */       BufferedWriter out = new BufferedWriter(new FileWriter(file));
/*     */       try {
/* 240 */         out.write(document.get());
/* 241 */         out.flush();
/*     */       } finally {
/*     */         try {
/* 244 */           out.close();
/* 245 */         } catch (IOException iOException) {}
/*     */       }
/*     */     
/*     */     }
/* 249 */     catch (IOException e) {
/* 250 */       String errorMessage = Messages.bind(Messages.CaughtException, "IOException", e.getLocalizedMessage());
/* 251 */       Util.log(e, errorMessage);
/* 252 */       System.err.println(Messages.bind(Messages.ExceptionSkip, errorMessage));
/* 253 */     } catch (BadLocationException e) {
/* 254 */       String errorMessage = Messages.bind(Messages.CaughtException, "BadLocationException", e.getLocalizedMessage());
/* 255 */       Util.log((Throwable)e, errorMessage);
/* 256 */       System.err.println(Messages.bind(Messages.ExceptionSkip, errorMessage));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private File[] processCommandLine(String[] argsArray) {
/* 262 */     int index = 0;
/* 263 */     int argCount = argsArray.length;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 268 */     int mode = 0;
/*     */     
/* 270 */     int fileCounter = 0;
/*     */     
/* 272 */     File[] filesToFormat = new File[1];
/*     */     
/* 274 */     while (index < argCount) {
/* 275 */       File file; String canonicalPath, errorMsg, currentArg = argsArray[index++];
/*     */       
/* 277 */       switch (mode) {
/*     */         case 0:
/* 279 */           if ("-pdelaunch".equals(currentArg)) {
/*     */             continue;
/*     */           }
/* 282 */           if ("-help".equals(currentArg)) {
/* 283 */             displayHelp();
/* 284 */             return null;
/*     */           } 
/* 286 */           if ("-verbose".equals(currentArg)) {
/* 287 */             this.verbose = true;
/*     */             continue;
/*     */           } 
/* 290 */           if ("-quiet".equals(currentArg)) {
/* 291 */             this.quiet = true;
/*     */             continue;
/*     */           } 
/* 294 */           if ("-config".equals(currentArg)) {
/* 295 */             mode = 1;
/*     */             
/*     */             continue;
/*     */           } 
/* 299 */           file = new File(currentArg);
/* 300 */           if (file.exists()) {
/* 301 */             if (filesToFormat.length == fileCounter) {
/* 302 */               System.arraycopy(filesToFormat, 0, filesToFormat = new File[fileCounter * 2], 0, fileCounter);
/*     */             }
/* 304 */             filesToFormat[fileCounter++] = file;
/*     */             continue;
/*     */           } 
/*     */           try {
/* 308 */             canonicalPath = file.getCanonicalPath();
/* 309 */           } catch (IOException iOException) {
/* 310 */             canonicalPath = file.getAbsolutePath();
/*     */           } 
/* 312 */           errorMsg = file.isAbsolute() ? 
/* 313 */             Messages.bind(Messages.CommandLineErrorFile, canonicalPath) : 
/* 314 */             Messages.bind(Messages.CommandLineErrorFileTryFullPath, canonicalPath);
/* 315 */           displayHelp(errorMsg);
/* 316 */           return null;
/*     */ 
/*     */         
/*     */         case 1:
/* 320 */           this.configName = currentArg;
/* 321 */           this.options = readConfig(currentArg);
/* 322 */           if (this.options == null) {
/* 323 */             displayHelp(Messages.bind(Messages.CommandLineErrorConfig, currentArg));
/* 324 */             return null;
/*     */           } 
/* 326 */           mode = 0;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 331 */     if (mode == 1 || this.options == null) {
/* 332 */       displayHelp(Messages.bind(Messages.CommandLineErrorNoConfigFile));
/* 333 */       return null;
/*     */     } 
/* 335 */     if (this.quiet && this.verbose) {
/* 336 */       displayHelp(
/* 337 */           Messages.bind(
/* 338 */             Messages.CommandLineErrorQuietVerbose, 
/* 339 */             (Object[])new String[] { "-quiet", "-verbose" }));
/*     */       
/* 341 */       return null;
/*     */     } 
/* 343 */     if (fileCounter == 0) {
/* 344 */       displayHelp(Messages.bind(Messages.CommandLineErrorFileDir));
/* 345 */       return null;
/*     */     } 
/* 347 */     if (filesToFormat.length != fileCounter) {
/* 348 */       System.arraycopy(filesToFormat, 0, filesToFormat = new File[fileCounter], 0, fileCounter);
/*     */     }
/* 350 */     return filesToFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Properties readConfig(String filename) {
/* 358 */     BufferedInputStream stream = null;
/* 359 */     File configFile = new File(filename);
/*     */     try {
/* 361 */       stream = new BufferedInputStream(new FileInputStream(configFile));
/* 362 */       Properties formatterOptions = new Properties();
/* 363 */       formatterOptions.load(stream);
/* 364 */       return formatterOptions;
/* 365 */     } catch (IOException e) {
/* 366 */       String errorMessage, canonicalPath = null;
/*     */       try {
/* 368 */         canonicalPath = configFile.getCanonicalPath();
/* 369 */       } catch (IOException iOException) {
/* 370 */         canonicalPath = configFile.getAbsolutePath();
/*     */       } 
/*     */       
/* 373 */       if (!configFile.exists() && !configFile.isAbsolute()) {
/* 374 */         errorMessage = Messages.bind(Messages.ConfigFileNotFoundErrorTryFullPath, new Object[] {
/* 375 */               canonicalPath, 
/* 376 */               System.getProperty("user.dir")
/*     */             });
/*     */       } else {
/*     */         
/* 380 */         errorMessage = Messages.bind(Messages.ConfigFileReadingError, canonicalPath);
/*     */       } 
/* 382 */       Util.log(e, errorMessage);
/* 383 */       System.err.println(errorMessage);
/*     */     } finally {
/* 385 */       if (stream != null) {
/*     */         try {
/* 387 */           stream.close();
/* 388 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 393 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object start(IApplicationContext context) throws Exception {
/* 401 */     File[] filesToFormat = processCommandLine((String[])context.getArguments().get("application.args"));
/*     */     
/* 403 */     if (filesToFormat == null) {
/* 404 */       return IApplication.EXIT_OK;
/*     */     }
/*     */     
/* 407 */     if (!this.quiet) {
/* 408 */       if (this.configName != null) {
/* 409 */         System.out.println(Messages.bind(Messages.CommandLineConfigFile, this.configName));
/*     */       }
/* 411 */       System.out.println(Messages.bind(Messages.CommandLineStart));
/*     */     } 
/*     */     
/* 414 */     CodeFormatter codeFormatter = ToolFactory.createCodeFormatter(this.options, 
/* 415 */         ToolFactory.M_FORMAT_EXISTING);
/*     */     
/* 417 */     for (int i = 0, max = filesToFormat.length; i < max; i++) {
/* 418 */       File file = filesToFormat[i];
/* 419 */       if (file.isDirectory()) {
/* 420 */         formatDirTree(file, codeFormatter);
/* 421 */       } else if (Util.isJavaLikeFileName(file.getPath())) {
/* 422 */         formatFile(file, codeFormatter);
/*     */       } 
/*     */     } 
/* 425 */     if (!this.quiet) {
/* 426 */       System.out.println(Messages.bind(Messages.CommandLineDone));
/*     */     }
/*     */     
/* 429 */     return IApplication.EXIT_OK;
/*     */   }
/*     */   
/*     */   public void stop() {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\formatter\CodeFormatterApplication.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */