/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JavaDocTextElement
/*     */   extends AbstractTextElement
/*     */ {
/*  41 */   public static final SimplePropertyDescriptor TEXT_PROPERTY = internalTextPropertyFactory(JavaDocTextElement.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  51 */     List propertyList = new ArrayList(2);
/*  52 */     createPropertyList(JavaDocTextElement.class, propertyList);
/*  53 */     addProperty(TEXT_PROPERTY, propertyList);
/*  54 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  67 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final SimplePropertyDescriptor internalTextPropertyFactory() {
/*  73 */     return TEXT_PROPERTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JavaDocTextElement(AST ast) {
/*  88 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  93 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/*  99 */     return 112;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 104 */     JavaDocTextElement result = new JavaDocTextElement(target);
/* 105 */     result.setSourceRange(getStartPosition(), getLength());
/* 106 */     result.setText(getText());
/* 107 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 113 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 118 */     visitor.visit(this);
/* 119 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(String text) {
/* 136 */     super.setText(text);
/* 137 */     preValueChange(TEXT_PROPERTY);
/* 138 */     this.text = text;
/* 139 */     postValueChange(TEXT_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 144 */     int size = 44;
/* 145 */     if (this.text != Util.EMPTY_STRING)
/*     */     {
/* 147 */       size += stringSize(this.text);
/*     */     }
/* 149 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 154 */     return memSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\JavaDocTextElement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */