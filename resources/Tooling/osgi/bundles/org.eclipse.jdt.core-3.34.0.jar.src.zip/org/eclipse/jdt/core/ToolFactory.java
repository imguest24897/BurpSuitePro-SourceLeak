/*     */ package org.eclipse.jdt.core;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Plugin;
/*     */ import org.eclipse.jdt.core.compiler.IScanner;
/*     */ import org.eclipse.jdt.core.formatter.CodeFormatter;
/*     */ import org.eclipse.jdt.core.util.ClassFileBytesDisassembler;
/*     */ import org.eclipse.jdt.core.util.ClassFormatException;
/*     */ import org.eclipse.jdt.core.util.IClassFileDisassembler;
/*     */ import org.eclipse.jdt.core.util.IClassFileReader;
/*     */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ import org.eclipse.jdt.internal.core.JarPackageFragmentRoot;
/*     */ import org.eclipse.jdt.internal.core.JavaElement;
/*     */ import org.eclipse.jdt.internal.core.JavaModelManager;
/*     */ import org.eclipse.jdt.internal.core.PackageFragment;
/*     */ import org.eclipse.jdt.internal.core.util.ClassFileReader;
/*     */ import org.eclipse.jdt.internal.core.util.Disassembler;
/*     */ import org.eclipse.jdt.internal.core.util.PublicScanner;
/*     */ import org.eclipse.jdt.internal.core.util.Util;
/*     */ import org.eclipse.jdt.internal.formatter.DefaultCodeFormatter;
/*     */ import org.eclipse.jdt.internal.formatter.old.CodeFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ToolFactory
/*     */ {
/*  79 */   public static final int M_FORMAT_NEW = Integer.valueOf(0).intValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public static final int M_FORMAT_EXISTING = Integer.valueOf(1).intValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ICodeFormatter createCodeFormatter() {
/* 107 */     Plugin jdtCorePlugin = JavaCore.getPlugin();
/* 108 */     if (jdtCorePlugin == null) return null;
/*     */     
/* 110 */     IExtensionPoint extension = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.jdt.core", "codeFormatter");
/* 111 */     if (extension != null) {
/* 112 */       IExtension[] extensions = extension.getExtensions();
/* 113 */       for (int i = 0; i < extensions.length; i++) {
/* 114 */         IConfigurationElement[] configElements = extensions[i].getConfigurationElements();
/* 115 */         for (int j = 0; j < configElements.length; j++) {
/*     */           try {
/* 117 */             Object execExt = configElements[j].createExecutableExtension("class");
/* 118 */             if (execExt instanceof ICodeFormatter)
/*     */             {
/* 120 */               return (ICodeFormatter)execExt;
/*     */             }
/* 122 */           } catch (CoreException coreException) {}
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 129 */     return createDefaultCodeFormatter(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CodeFormatter createCodeFormatter(Map options) {
/* 151 */     return createCodeFormatter(options, M_FORMAT_NEW);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CodeFormatter createCodeFormatter(Map<String, String> options, int mode) {
/* 179 */     if (options == null) options = JavaCore.getOptions(); 
/* 180 */     Map<String, String> currentOptions = new HashMap<>(options);
/* 181 */     if (mode == M_FORMAT_NEW) {
/*     */       
/* 183 */       currentOptions.put("org.eclipse.jdt.core.formatter.format_line_comment_starting_on_first_column", "true");
/*     */       
/* 185 */       currentOptions.put("org.eclipse.jdt.core.formatter.never_indent_block_comments_on_first_column", "false");
/* 186 */       currentOptions.put("org.eclipse.jdt.core.formatter.never_indent_line_comments_on_first_column", "false");
/*     */     } 
/* 188 */     String formatterId = options.get("org.eclipse.jdt.core.javaFormatter");
/* 189 */     if (formatterId != null) {
/* 190 */       IExtensionPoint extension = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.jdt.core", 
/* 191 */           "javaFormatter");
/* 192 */       if (extension != null) {
/* 193 */         IExtension[] extensions = extension.getExtensions();
/* 194 */         for (int i = 0; i < extensions.length; i++) {
/* 195 */           IConfigurationElement[] configElements = extensions[i].getConfigurationElements();
/* 196 */           for (int j = 0; j < configElements.length; j++) {
/* 197 */             String initializerID = configElements[j].getAttribute("id");
/* 198 */             if (initializerID != null && initializerID.equals(formatterId)) {
/*     */               try {
/* 200 */                 Object execExt = configElements[j].createExecutableExtension("class");
/* 201 */                 if (execExt instanceof CodeFormatter) {
/* 202 */                   CodeFormatter formatter = (CodeFormatter)execExt;
/* 203 */                   formatter.setOptions(currentOptions);
/* 204 */                   return formatter;
/*     */                 } 
/* 206 */               } catch (CoreException e) {
/* 207 */                 Util.log(e.getStatus());
/*     */                 break;
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 214 */       Util.log(2, 
/* 215 */           "Unable to instantiate formatter extension '" + formatterId + "', returning built-in formatter.");
/*     */     } 
/* 217 */     return (CodeFormatter)new DefaultCodeFormatter(currentOptions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassFileBytesDisassembler createDefaultClassFileBytesDisassembler() {
/* 228 */     return (ClassFileBytesDisassembler)new Disassembler();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IClassFileDisassembler createDefaultClassFileDisassembler() {
/*     */     class DeprecatedDisassembler
/*     */       extends Disassembler
/*     */       implements IClassFileDisassembler {};
/* 242 */     return new DeprecatedDisassembler();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IClassFileReader createDefaultClassFileReader(IClassFile classfile, int decodingFlag) {
/* 261 */     IPackageFragmentRoot root = (IPackageFragmentRoot)classfile.getAncestor(3);
/* 262 */     if (root != null) {
/*     */       try {
/* 264 */         if (root instanceof JarPackageFragmentRoot) {
/* 265 */           String archiveName = null;
/* 266 */           ZipFile jar = null;
/*     */           try {
/* 268 */             jar = ((JarPackageFragmentRoot)root).getJar();
/* 269 */             archiveName = jar.getName();
/*     */           } finally {
/* 271 */             JavaModelManager.getJavaModelManager().closeZipFile(jar);
/*     */           } 
/* 273 */           PackageFragment packageFragment = (PackageFragment)classfile.getParent();
/* 274 */           String classFileName = classfile.getElementName();
/* 275 */           String entryName = Util.concatWith(packageFragment.names, classFileName, '/');
/* 276 */           return createDefaultClassFileReader(archiveName, entryName, decodingFlag);
/*     */         } 
/* 278 */         InputStream in = null;
/*     */         try {
/* 280 */           in = ((IFile)((JavaElement)classfile).resource()).getContents();
/* 281 */           return createDefaultClassFileReader(in, decodingFlag);
/*     */         } finally {
/* 283 */           if (in != null) {
/*     */             try {
/* 285 */               in.close();
/* 286 */             } catch (IOException iOException) {}
/*     */           }
/*     */         }
/*     */       
/*     */       }
/* 291 */       catch (CoreException coreException) {}
/*     */     }
/*     */ 
/*     */     
/* 295 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IClassFileReader createDefaultClassFileReader(InputStream stream, int decodingFlag) {
/*     */     try {
/* 314 */       return (IClassFileReader)new ClassFileReader(Util.getInputStreamAsByteArray(stream), decodingFlag);
/* 315 */     } catch (ClassFormatException|IOException classFormatException) {
/* 316 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IClassFileReader createDefaultClassFileReader(String fileName, int decodingFlag) {
/*     */     try {
/* 336 */       return (IClassFileReader)new ClassFileReader(Util.getFileByteContent(new File(fileName)), decodingFlag);
/* 337 */     } catch (ClassFormatException|IOException classFormatException) {
/* 338 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IClassFileReader createDefaultClassFileReader(String zipFileName, String zipEntryName, int decodingFlag) {
/* 358 */     ZipFile zipFile = null;
/*     */     try {
/* 360 */       if (JavaModelManager.ZIP_ACCESS_VERBOSE) {
/* 361 */         System.out.println("(" + Thread.currentThread() + ") [ToolFactory.createDefaultClassFileReader()] Creating ZipFile on " + zipFileName);
/*     */       }
/* 363 */       zipFile = new ZipFile(zipFileName);
/* 364 */       ZipEntry zipEntry = zipFile.getEntry(zipEntryName);
/* 365 */       if (zipEntry == null) {
/* 366 */         return null;
/*     */       }
/* 368 */       if (!zipEntryName.toLowerCase().endsWith(".class")) {
/* 369 */         return null;
/*     */       }
/* 371 */       byte[] classFileBytes = Util.getZipEntryByteContent(zipEntry, zipFile);
/* 372 */       return (IClassFileReader)new ClassFileReader(classFileBytes, decodingFlag);
/* 373 */     } catch (ClassFormatException|IOException classFormatException) {
/* 374 */       return null;
/*     */     } finally {
/* 376 */       if (zipFile != null) {
/*     */         try {
/* 378 */           zipFile.close();
/* 379 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ICodeFormatter createDefaultCodeFormatter(Map<String, String> options) {
/* 399 */     if (options == null) options = JavaCore.getOptions(); 
/* 400 */     return (ICodeFormatter)new CodeFormatter(options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IScanner createScanner(boolean tokenizeComments, boolean tokenizeWhiteSpace, boolean assertMode, boolean recordLineSeparator) {
/* 441 */     long complianceLevelValue = CompilerOptions.versionToJdkLevel(JavaCore.getOption("org.eclipse.jdt.core.compiler.compliance"));
/* 442 */     if (complianceLevelValue == 0L) complianceLevelValue = 3145728L; 
/* 443 */     PublicScanner scanner = 
/* 444 */       new PublicScanner(
/* 445 */         tokenizeComments, 
/* 446 */         tokenizeWhiteSpace, 
/* 447 */         false, 
/* 448 */         assertMode ? 3145728L : 3080192L, 
/* 449 */         complianceLevelValue, 
/* 450 */         null, 
/* 451 */         null, 
/* 452 */         true, 
/* 453 */         true, 
/* 454 */         recordLineSeparator);
/* 455 */     return (IScanner)scanner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IScanner createScanner(boolean tokenizeComments, boolean tokenizeWhiteSpace, boolean recordLineSeparator, String sourceLevel) {
/* 497 */     long complianceLevelValue = CompilerOptions.versionToJdkLevel(JavaCore.getOption("org.eclipse.jdt.core.compiler.compliance"));
/* 498 */     if (complianceLevelValue == 0L) complianceLevelValue = 3145728L; 
/* 499 */     long sourceLevelValue = CompilerOptions.versionToJdkLevel(sourceLevel);
/* 500 */     if (sourceLevelValue == 0L) sourceLevelValue = 3080192L; 
/* 501 */     PublicScanner scanner = 
/* 502 */       new PublicScanner(
/* 503 */         tokenizeComments, 
/* 504 */         tokenizeWhiteSpace, 
/* 505 */         false, 
/* 506 */         sourceLevelValue, 
/* 507 */         complianceLevelValue, 
/* 508 */         null, 
/* 509 */         null, 
/* 510 */         true, 
/* 511 */         true, 
/* 512 */         recordLineSeparator);
/* 513 */     return (IScanner)scanner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IScanner createScanner(boolean tokenizeComments, boolean tokenizeWhiteSpace, boolean recordLineSeparator, String sourceLevel, String complianceLevel) {
/* 552 */     return createScanner(tokenizeComments, tokenizeWhiteSpace, recordLineSeparator, sourceLevel, complianceLevel, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IScanner createScanner(boolean tokenizeComments, boolean tokenizeWhiteSpace, boolean recordLineSeparator, String sourceLevel, String complianceLevel, boolean enablePreview) {
/* 591 */     PublicScanner scanner = null;
/* 592 */     long sourceLevelValue = CompilerOptions.versionToJdkLevel(sourceLevel);
/* 593 */     if (sourceLevelValue == 0L) sourceLevelValue = 3080192L; 
/* 594 */     long complianceLevelValue = CompilerOptions.versionToJdkLevel(complianceLevel);
/* 595 */     if (complianceLevelValue == 0L) complianceLevelValue = 3145728L; 
/* 596 */     scanner = new PublicScanner(tokenizeComments, tokenizeWhiteSpace, 
/* 597 */         false, sourceLevelValue, complianceLevelValue, 
/* 598 */         null, null, true, 
/* 599 */         enablePreview, recordLineSeparator);
/* 600 */     return (IScanner)scanner;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\ToolFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */