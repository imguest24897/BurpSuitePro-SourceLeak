/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RequiresDirective
/*     */   extends ModuleDirective
/*     */ {
/*  37 */   public static final ChildListPropertyDescriptor MODIFIERS_PROPERTY = new ChildListPropertyDescriptor(RequiresDirective.class, "modifiers", ModuleModifier.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(RequiresDirective.class, "name", Name.class, false, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_9_0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  53 */     List propertyList = new ArrayList(3);
/*  54 */     createPropertyList(RequiresDirective.class, propertyList);
/*  55 */     addProperty(MODIFIERS_PROPERTY, propertyList);
/*  56 */     addProperty(NAME_PROPERTY, propertyList);
/*  57 */     PROPERTY_DESCRIPTORS_9_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  71 */     return PROPERTY_DESCRIPTORS_9_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private ASTNode.NodeList modifiers = new ASTNode.NodeList(this, MODIFIERS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private Name name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RequiresDirective(AST ast) {
/*  99 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 104 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 109 */     if (property == NAME_PROPERTY) {
/* 110 */       if (get) {
/* 111 */         return getName();
/*     */       }
/* 113 */       setName((Name)child);
/* 114 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 119 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 124 */     if (property == MODIFIERS_PROPERTY) {
/* 125 */       return modifiers();
/*     */     }
/*     */ 
/*     */     
/* 129 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 134 */     return 94;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 139 */     RequiresDirective result = new RequiresDirective(target);
/* 140 */     result.modifiers().addAll(ASTNode.copySubtrees(target, modifiers()));
/* 141 */     result.setName((Name)getName().clone(target));
/* 142 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 148 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 153 */     boolean visitChildren = visitor.visit(this);
/* 154 */     if (visitChildren) {
/* 155 */       acceptChildren(visitor, this.modifiers);
/* 156 */       acceptChild(visitor, getName());
/*     */     } 
/* 158 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List modifiers() {
/* 172 */     return this.modifiers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 188 */     int computedModifierFlags = 0;
/* 189 */     for (Iterator it = modifiers().iterator(); it.hasNext(); ) {
/* 190 */       Object x = it.next();
/* 191 */       if (x instanceof ModuleModifier) {
/* 192 */         computedModifierFlags |= ((ModuleModifier)x).getKeyword().toFlagValue();
/*     */       }
/*     */     } 
/* 195 */     return computedModifierFlags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getName() {
/* 204 */     if (this.name == null)
/*     */     {
/* 206 */       synchronized (this) {
/* 207 */         if (this.name == null) {
/* 208 */           preLazyInit();
/* 209 */           this.name = this.ast.newQualifiedName(
/* 210 */               new SimpleName(this.ast), new SimpleName(this.ast));
/* 211 */           postLazyInit(this.name, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 215 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(Name name) {
/* 229 */     if (name == null) {
/* 230 */       throw new IllegalArgumentException();
/*     */     }
/* 232 */     ASTNode oldChild = this.name;
/* 233 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 234 */     this.name = name;
/* 235 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 240 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 245 */     return 
/* 246 */       memSize() + (
/* 247 */       (this.modifiers == null) ? 0 : this.modifiers.listSize()) + (
/* 248 */       (this.name == null) ? 0 : getName().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\RequiresDirective.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */