/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BooleanLiteral
/*     */   extends Expression
/*     */ {
/*  40 */   public static final SimplePropertyDescriptor BOOLEAN_VALUE_PROPERTY = new SimplePropertyDescriptor(BooleanLiteral.class, "booleanValue", boolean.class, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  50 */     List properyList = new ArrayList(2);
/*  51 */     createPropertyList(BooleanLiteral.class, properyList);
/*  52 */     addProperty(BOOLEAN_VALUE_PROPERTY, properyList);
/*  53 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  68 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean value = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BooleanLiteral(AST ast) {
/*  85 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  90 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final boolean internalGetSetBooleanProperty(SimplePropertyDescriptor property, boolean get, boolean newValue) {
/*  95 */     if (property == BOOLEAN_VALUE_PROPERTY) {
/*  96 */       if (get) {
/*  97 */         return booleanValue();
/*     */       }
/*  99 */       setBooleanValue(newValue);
/* 100 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 104 */     return super.internalGetSetBooleanProperty(property, get, newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 109 */     return 9;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 114 */     BooleanLiteral result = new BooleanLiteral(target);
/* 115 */     result.setSourceRange(getStartPosition(), getLength());
/* 116 */     result.setBooleanValue(booleanValue());
/* 117 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 123 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 128 */     visitor.visit(this);
/* 129 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean booleanValue() {
/* 140 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBooleanValue(boolean value) {
/* 151 */     preValueChange(BOOLEAN_VALUE_PROPERTY);
/* 152 */     this.value = value;
/* 153 */     postValueChange(BOOLEAN_VALUE_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 158 */     return 44;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 163 */     return memSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\BooleanLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */