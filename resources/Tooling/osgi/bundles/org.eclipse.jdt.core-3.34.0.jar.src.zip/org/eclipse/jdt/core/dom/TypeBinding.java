/*      */ package org.eclipse.jdt.core.dom;
/*      */ 
/*      */ import org.eclipse.jdt.core.IJavaElement;
/*      */ import org.eclipse.jdt.core.JavaCore;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.internal.compiler.ast.StringLiteral;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ArrayBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BaseTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.CaptureBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.CaptureBinding18;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.CompilationUnitScope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.IntersectionTypeBinding18;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.RawTypeBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.WildcardBinding;
/*      */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilation;
/*      */ import org.eclipse.jdt.internal.core.JavaElement;
/*      */ import org.eclipse.jdt.internal.core.PackageFragment;
/*      */ import org.eclipse.jdt.internal.core.util.Util;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class TypeBinding
/*      */   implements ITypeBinding
/*      */ {
/*   53 */   private static final StringLiteral EXPRESSION = new StringLiteral(0, 0);
/*      */   
/*   55 */   protected static final IMethodBinding[] NO_METHOD_BINDINGS = new IMethodBinding[0];
/*      */   
/*      */   private static final String NO_NAME = "";
/*   58 */   protected static final ITypeBinding[] NO_TYPE_BINDINGS = new ITypeBinding[0];
/*   59 */   protected static final IVariableBinding[] NO_VARIABLE_BINDINGS = new IVariableBinding[0];
/*      */   
/*      */   private static final int VALID_MODIFIERS = 3103;
/*      */   
/*      */   org.eclipse.jdt.internal.compiler.lookup.TypeBinding binding;
/*      */   
/*   65 */   private TypeBinding prototype = null;
/*      */   
/*      */   private String key;
/*      */   
/*      */   protected BindingResolver resolver;
/*      */   
/*      */   private IVariableBinding[] fields;
/*      */   
/*      */   private IAnnotationBinding[] annotations;
/*      */   
/*      */   private IAnnotationBinding[] typeAnnotations;
/*      */   
/*      */   private IMethodBinding[] methods;
/*      */   private ITypeBinding[] members;
/*      */   private ITypeBinding[] interfaces;
/*      */   private ITypeBinding[] typeArguments;
/*      */   private ITypeBinding[] bounds;
/*      */   private ITypeBinding[] typeParameters;
/*      */   
/*      */   public static TypeBinding createTypeBinding(BindingResolver resolver, org.eclipse.jdt.internal.compiler.lookup.TypeBinding referenceBinding, IBinding declaringMember) {
/*   85 */     return (declaringMember != null) ? 
/*   86 */       new LocalTypeBinding(resolver, referenceBinding, declaringMember) : 
/*   87 */       new TypeBinding(resolver, referenceBinding);
/*      */   }
/*      */   
/*      */   public TypeBinding(BindingResolver resolver, org.eclipse.jdt.internal.compiler.lookup.TypeBinding binding) {
/*   91 */     this.binding = binding;
/*   92 */     this.resolver = resolver;
/*   93 */     org.eclipse.jdt.internal.compiler.lookup.TypeBinding compilerPrototype = binding.prototype();
/*   94 */     this.prototype = (compilerPrototype == null || compilerPrototype == binding) ? null : (TypeBinding)resolver.getTypeBinding(compilerPrototype);
/*      */   }
/*      */ 
/*      */   
/*      */   public ITypeBinding createArrayType(int dimension) {
/*   99 */     int realDimensions = dimension;
/*  100 */     realDimensions += getDimensions();
/*  101 */     if (realDimensions < 1 || realDimensions > 255) {
/*  102 */       throw new IllegalArgumentException();
/*      */     }
/*  104 */     return this.resolver.resolveArrayType(this, dimension);
/*      */   }
/*      */ 
/*      */   
/*      */   public IAnnotationBinding[] getAnnotations() {
/*  109 */     if (this.prototype != null) {
/*  110 */       return this.prototype.getAnnotations();
/*      */     }
/*  112 */     if (this.annotations != null) {
/*  113 */       return this.annotations;
/*      */     }
/*  115 */     ReferenceBinding refType = null;
/*  116 */     if (this.binding instanceof ParameterizedTypeBinding) {
/*  117 */       refType = ((ParameterizedTypeBinding)this.binding).genericType();
/*  118 */     } else if (this.binding.isAnnotationType() || this.binding.isClass() || this.binding.isEnum() || this.binding.isInterface()) {
/*  119 */       refType = (ReferenceBinding)this.binding;
/*      */     } 
/*  121 */     if (refType != null) {
/*  122 */       return this.annotations = resolveAnnotationBindings(refType.getAnnotations(), false);
/*      */     }
/*  124 */     return this.annotations = (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*      */   }
/*      */   private IAnnotationBinding[] resolveAnnotationBindings(AnnotationBinding[] internalAnnotations, boolean isTypeUse) {
/*  127 */     int length = (internalAnnotations == null) ? 0 : internalAnnotations.length;
/*  128 */     if (length != 0) {
/*  129 */       IAnnotationBinding[] tempAnnotations = new IAnnotationBinding[length];
/*  130 */       int convertedAnnotationCount = 0;
/*  131 */       for (int i = 0; i < length; i++) {
/*  132 */         AnnotationBinding internalAnnotation = internalAnnotations[i];
/*  133 */         if (isTypeUse && internalAnnotation == null) {
/*      */           break;
/*      */         }
/*  136 */         IAnnotationBinding annotationInstance = this.resolver.getAnnotationInstance(internalAnnotation);
/*  137 */         if (annotationInstance != null)
/*      */         {
/*      */           
/*  140 */           tempAnnotations[convertedAnnotationCount++] = annotationInstance; } 
/*      */       } 
/*  142 */       if (convertedAnnotationCount != length) {
/*  143 */         if (convertedAnnotationCount == 0) {
/*  144 */           return this.annotations = (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*      */         }
/*  146 */         System.arraycopy(tempAnnotations, 0, tempAnnotations = new IAnnotationBinding[convertedAnnotationCount], 0, convertedAnnotationCount);
/*      */       } 
/*  148 */       return tempAnnotations;
/*      */     } 
/*  150 */     return (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getBinaryName() {
/*  155 */     if (this.binding.isCapture())
/*  156 */       return null; 
/*  157 */     if (this.binding.isTypeVariable()) {
/*  158 */       MethodBinding methodBinding; TypeVariableBinding typeVariableBinding = (TypeVariableBinding)this.binding;
/*  159 */       Binding declaring = typeVariableBinding.declaringElement;
/*  160 */       StringBuffer binaryName = new StringBuffer();
/*  161 */       switch (declaring.kind())
/*      */       { case 8:
/*  163 */           methodBinding = (MethodBinding)declaring;
/*  164 */           arrayOfChar = methodBinding.declaringClass.constantPoolName();
/*  165 */           if (arrayOfChar == null) return null; 
/*  166 */           binaryName
/*  167 */             .append(CharOperation.replaceOnCopy(arrayOfChar, '/', '.'))
/*  168 */             .append('$')
/*  169 */             .append(methodBinding.signature())
/*  170 */             .append('$')
/*  171 */             .append(typeVariableBinding.sourceName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  182 */           return String.valueOf(binaryName); }  org.eclipse.jdt.internal.compiler.lookup.TypeBinding typeBinding = (org.eclipse.jdt.internal.compiler.lookup.TypeBinding)declaring; char[] arrayOfChar = typeBinding.constantPoolName(); if (arrayOfChar == null) return null;  binaryName.append(CharOperation.replaceOnCopy(arrayOfChar, '/', '.')).append('$').append(typeVariableBinding.sourceName); return String.valueOf(binaryName);
/*      */     } 
/*  184 */     char[] constantPoolName = this.binding.constantPoolName();
/*  185 */     if (constantPoolName == null) return null; 
/*  186 */     char[] dotSeparated = CharOperation.replaceOnCopy(constantPoolName, '/', '.');
/*  187 */     return new String(dotSeparated);
/*      */   }
/*      */   
/*      */   public ITypeBinding getBound() {
/*      */     WildcardBinding wildcardBinding;
/*  192 */     switch (this.binding.kind()) {
/*      */       case 516:
/*      */       case 8196:
/*  195 */         wildcardBinding = (WildcardBinding)this.binding;
/*  196 */         if (wildcardBinding.bound != null) {
/*  197 */           return this.resolver.getTypeBinding(wildcardBinding.bound);
/*      */         }
/*      */         break;
/*      */     } 
/*  201 */     return null;
/*      */   }
/*      */   
/*      */   public ITypeBinding getGenericTypeOfWildcardType() {
/*      */     WildcardBinding wildcardBinding;
/*  206 */     switch (this.binding.kind()) {
/*      */       case 516:
/*  208 */         wildcardBinding = (WildcardBinding)this.binding;
/*  209 */         if (wildcardBinding.genericType != null) {
/*  210 */           return this.resolver.getTypeBinding((org.eclipse.jdt.internal.compiler.lookup.TypeBinding)wildcardBinding.genericType);
/*      */         }
/*      */         break;
/*      */     } 
/*  214 */     return null;
/*      */   }
/*      */   
/*      */   public int getRank() {
/*      */     WildcardBinding wildcardBinding;
/*  219 */     switch (this.binding.kind()) {
/*      */       case 516:
/*      */       case 8196:
/*  222 */         wildcardBinding = (WildcardBinding)this.binding;
/*  223 */         return wildcardBinding.rank;
/*      */     } 
/*  225 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ITypeBinding getComponentType() {
/*  231 */     if (!isArray()) {
/*  232 */       return null;
/*      */     }
/*  234 */     ArrayBinding arrayBinding = (ArrayBinding)this.binding;
/*  235 */     return this.resolver.getTypeBinding(arrayBinding.elementsType());
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized IVariableBinding[] getDeclaredFields() {
/*  240 */     if (this.prototype != null) {
/*  241 */       return this.prototype.getDeclaredFields();
/*      */     }
/*  243 */     if (this.fields != null) {
/*  244 */       return this.fields;
/*      */     }
/*      */     try {
/*  247 */       if (isClass() || isInterface() || isEnum()) {
/*  248 */         ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/*  249 */         FieldBinding[] fieldBindings = referenceBinding.availableFields();
/*  250 */         int length = fieldBindings.length;
/*  251 */         if (length != 0) {
/*  252 */           int convertedFieldCount = 0;
/*  253 */           IVariableBinding[] newFields = new IVariableBinding[length];
/*  254 */           for (int i = 0; i < length; i++) {
/*  255 */             FieldBinding fieldBinding = fieldBindings[i];
/*  256 */             IVariableBinding variableBinding = this.resolver.getVariableBinding((VariableBinding)fieldBinding);
/*  257 */             if (variableBinding != null) {
/*  258 */               newFields[convertedFieldCount++] = variableBinding;
/*      */             }
/*      */           } 
/*      */           
/*  262 */           if (convertedFieldCount != length) {
/*  263 */             if (convertedFieldCount == 0) {
/*  264 */               return this.fields = NO_VARIABLE_BINDINGS;
/*      */             }
/*  266 */             System.arraycopy(newFields, 0, newFields = new IVariableBinding[convertedFieldCount], 0, convertedFieldCount);
/*      */           } 
/*  268 */           return this.fields = newFields;
/*      */         } 
/*      */       } 
/*  271 */     } catch (RuntimeException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  277 */       Util.log(e, "Could not retrieve declared fields");
/*      */     } 
/*  279 */     return this.fields = NO_VARIABLE_BINDINGS;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized IMethodBinding[] getDeclaredMethods() {
/*  284 */     if (this.prototype != null) {
/*  285 */       return this.prototype.getDeclaredMethods();
/*      */     }
/*  287 */     if (this.methods != null) {
/*  288 */       return this.methods;
/*      */     }
/*      */     try {
/*  291 */       if (isClass() || isInterface() || isEnum()) {
/*  292 */         ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/*  293 */         MethodBinding[] internalMethods = referenceBinding.availableMethods();
/*  294 */         int length = internalMethods.length;
/*  295 */         if (length != 0) {
/*  296 */           int convertedMethodCount = 0;
/*  297 */           IMethodBinding[] newMethods = new IMethodBinding[length];
/*  298 */           for (int i = 0; i < length; i++) {
/*  299 */             MethodBinding methodBinding = internalMethods[i];
/*  300 */             if (!methodBinding.isDefaultAbstract() && !methodBinding.isSynthetic() && (!methodBinding.isConstructor() || !isInterface())) {
/*      */ 
/*      */               
/*  303 */               IMethodBinding methodBinding2 = this.resolver.getMethodBinding(methodBinding);
/*  304 */               if (methodBinding2 != null)
/*  305 */                 newMethods[convertedMethodCount++] = methodBinding2; 
/*      */             } 
/*      */           } 
/*  308 */           if (convertedMethodCount != length) {
/*  309 */             if (convertedMethodCount == 0) {
/*  310 */               return this.methods = NO_METHOD_BINDINGS;
/*      */             }
/*  312 */             System.arraycopy(newMethods, 0, newMethods = new IMethodBinding[convertedMethodCount], 0, convertedMethodCount);
/*      */           } 
/*  314 */           return this.methods = newMethods;
/*      */         } 
/*      */       } 
/*  317 */     } catch (RuntimeException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  323 */       Util.log(e, "Could not retrieve declared methods");
/*      */     } 
/*  325 */     return this.methods = NO_METHOD_BINDINGS;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDeclaredModifiers() {
/*  334 */     return getModifiers();
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized ITypeBinding[] getDeclaredTypes() {
/*  339 */     if (this.members != null) {
/*  340 */       return this.members;
/*      */     }
/*      */     try {
/*  343 */       if (isClass() || isInterface() || isEnum()) {
/*  344 */         ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/*  345 */         ReferenceBinding[] internalMembers = referenceBinding.memberTypes();
/*  346 */         int length = internalMembers.length;
/*  347 */         if (length != 0) {
/*  348 */           ITypeBinding[] newMembers = new ITypeBinding[length];
/*  349 */           for (int i = 0; i < length; i++) {
/*  350 */             ITypeBinding typeBinding = this.resolver.getTypeBinding((org.eclipse.jdt.internal.compiler.lookup.TypeBinding)internalMembers[i]);
/*  351 */             if (typeBinding == null) {
/*  352 */               return this.members = NO_TYPE_BINDINGS;
/*      */             }
/*  354 */             newMembers[i] = typeBinding;
/*      */           } 
/*  356 */           return this.members = newMembers;
/*      */         } 
/*      */       } 
/*  359 */     } catch (RuntimeException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  365 */       Util.log(e, "Could not retrieve declared methods");
/*      */     } 
/*  367 */     return this.members = NO_TYPE_BINDINGS;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized IMethodBinding getDeclaringMethod() {
/*  372 */     if (this.binding instanceof org.eclipse.jdt.internal.compiler.lookup.LocalTypeBinding) {
/*  373 */       org.eclipse.jdt.internal.compiler.lookup.LocalTypeBinding localTypeBinding = (org.eclipse.jdt.internal.compiler.lookup.LocalTypeBinding)this.binding;
/*  374 */       MethodBinding methodBinding = localTypeBinding.enclosingMethod;
/*  375 */       if (methodBinding != null) {
/*      */         try {
/*  377 */           return this.resolver.getMethodBinding(localTypeBinding.enclosingMethod);
/*  378 */         } catch (RuntimeException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  384 */           Util.log(e, "Could not retrieve declaring method");
/*      */         } 
/*      */       }
/*  387 */     } else if (this.binding.isTypeVariable()) {
/*  388 */       TypeVariableBinding typeVariableBinding = (TypeVariableBinding)this.binding;
/*  389 */       Binding declaringElement = typeVariableBinding.declaringElement;
/*  390 */       if (declaringElement instanceof MethodBinding) {
/*      */         try {
/*  392 */           return this.resolver.getMethodBinding((MethodBinding)declaringElement);
/*  393 */         } catch (RuntimeException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  399 */           Util.log(e, "Could not retrieve declaring method");
/*      */         } 
/*      */       }
/*      */     } 
/*  403 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized ITypeBinding getDeclaringClass() {
/*  408 */     if (isClass() || isInterface() || isEnum()) {
/*  409 */       ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/*  410 */       if (referenceBinding.isNestedType()) {
/*      */         try {
/*  412 */           return this.resolver.getTypeBinding((org.eclipse.jdt.internal.compiler.lookup.TypeBinding)referenceBinding.enclosingType());
/*  413 */         } catch (RuntimeException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  419 */           Util.log(e, "Could not retrieve declaring class");
/*      */         } 
/*      */       }
/*  422 */     } else if (this.binding.isTypeVariable()) {
/*  423 */       TypeVariableBinding typeVariableBinding = (TypeVariableBinding)this.binding;
/*  424 */       Binding declaringElement = typeVariableBinding.isCapture() ? (Binding)((CaptureBinding)typeVariableBinding).sourceType : typeVariableBinding.declaringElement;
/*  425 */       if (declaringElement instanceof ReferenceBinding) {
/*      */         try {
/*  427 */           return this.resolver.getTypeBinding((org.eclipse.jdt.internal.compiler.lookup.TypeBinding)declaringElement);
/*  428 */         } catch (RuntimeException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  434 */           Util.log(e, "Could not retrieve declaring class");
/*      */         } 
/*      */       }
/*      */     } 
/*  438 */     return null;
/*      */   }
/*      */   
/*      */   public IModuleBinding getModule() {
/*  442 */     if (this.binding instanceof ReferenceBinding && !this.binding.isTypeVariable()) {
/*  443 */       IPackageBinding packageBinding = this.resolver.getPackageBinding(((ReferenceBinding)this.binding).getPackage());
/*  444 */       return (packageBinding != null) ? packageBinding.getModule() : null;
/*      */     } 
/*  446 */     return null;
/*      */   }
/*      */   
/*      */   public IBinding getDeclaringMember() {
/*  450 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getDimensions() {
/*  455 */     if (!isArray()) {
/*  456 */       return 0;
/*      */     }
/*  458 */     ArrayBinding arrayBinding = (ArrayBinding)this.binding;
/*  459 */     return arrayBinding.dimensions;
/*      */   }
/*      */ 
/*      */   
/*      */   public ITypeBinding getElementType() {
/*  464 */     if (!isArray()) {
/*  465 */       return null;
/*      */     }
/*  467 */     ArrayBinding arrayBinding = (ArrayBinding)this.binding;
/*  468 */     return this.resolver.getTypeBinding(arrayBinding.leafComponentType);
/*      */   }
/*      */ 
/*      */   
/*      */   public ITypeBinding getTypeDeclaration() {
/*  473 */     if (this.binding instanceof ParameterizedTypeBinding)
/*  474 */       return this.resolver.getTypeBinding((org.eclipse.jdt.internal.compiler.lookup.TypeBinding)((ParameterizedTypeBinding)this.binding).genericType()); 
/*  475 */     return this.resolver.getTypeBinding(this.binding.unannotated());
/*      */   }
/*      */ 
/*      */   
/*      */   public ITypeBinding getErasure() {
/*  480 */     return this.resolver.getTypeBinding(this.binding.erasure());
/*      */   }
/*      */ 
/*      */   
/*      */   public IMethodBinding getFunctionalInterfaceMethod() {
/*  485 */     CompilationUnitScope compilationUnitScope = this.resolver.scope();
/*  486 */     if (this.binding == null || compilationUnitScope == null)
/*  487 */       return null; 
/*  488 */     MethodBinding sam = this.binding.getSingleAbstractMethod((Scope)compilationUnitScope, true);
/*  489 */     if (sam == null || !sam.isValidBinding())
/*  490 */       return null; 
/*  491 */     return this.resolver.getMethodBinding(sam);
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized ITypeBinding[] getInterfaces() {
/*  496 */     if (this.prototype != null) {
/*  497 */       return this.prototype.getInterfaces();
/*      */     }
/*  499 */     if (this.interfaces != null) {
/*  500 */       return this.interfaces;
/*      */     }
/*  502 */     if (this.binding == null)
/*  503 */       return this.interfaces = NO_TYPE_BINDINGS; 
/*  504 */     switch (this.binding.kind()) {
/*      */       case 68:
/*      */       case 132:
/*  507 */         return this.interfaces = NO_TYPE_BINDINGS;
/*      */     } 
/*  509 */     ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/*  510 */     ReferenceBinding[] internalInterfaces = null;
/*      */     try {
/*  512 */       internalInterfaces = referenceBinding.superInterfaces();
/*  513 */     } catch (RuntimeException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  519 */       Util.log(e, "Could not retrieve interfaces");
/*      */     } 
/*  521 */     int length = (internalInterfaces == null) ? 0 : internalInterfaces.length;
/*  522 */     if (length != 0) {
/*  523 */       ITypeBinding[] newInterfaces = new ITypeBinding[length];
/*  524 */       int interfacesCounter = 0;
/*  525 */       for (int i = 0; i < length; i++) {
/*  526 */         ITypeBinding typeBinding = this.resolver.getTypeBinding((org.eclipse.jdt.internal.compiler.lookup.TypeBinding)internalInterfaces[i]);
/*  527 */         if (typeBinding != null)
/*      */         {
/*      */           
/*  530 */           newInterfaces[interfacesCounter++] = typeBinding; } 
/*      */       } 
/*  532 */       if (length != interfacesCounter) {
/*  533 */         System.arraycopy(newInterfaces, 0, newInterfaces = new ITypeBinding[interfacesCounter], 0, interfacesCounter);
/*      */       }
/*  535 */       return this.interfaces = newInterfaces;
/*      */     } 
/*  537 */     return this.interfaces = NO_TYPE_BINDINGS;
/*      */   }
/*      */   
/*      */   private ITypeBinding[] getIntersectingTypes() {
/*  541 */     ITypeBinding[] intersectionBindings = NO_TYPE_BINDINGS;
/*  542 */     ReferenceBinding[] intersectingTypes = this.binding.getIntersectingTypes();
/*  543 */     int l = intersectingTypes.length;
/*  544 */     intersectionBindings = new ITypeBinding[l];
/*  545 */     for (int i = 0; i < l; i++) {
/*  546 */       intersectionBindings[i] = this.resolver.getTypeBinding((org.eclipse.jdt.internal.compiler.lookup.TypeBinding)intersectingTypes[i]);
/*      */     }
/*  548 */     return intersectionBindings;
/*      */   }
/*      */ 
/*      */   
/*      */   public IJavaElement getJavaElement() {
/*  553 */     JavaElement element = getUnresolvedJavaElement();
/*  554 */     if (element != null)
/*  555 */       return (IJavaElement)element.resolved((Binding)this.binding); 
/*  556 */     if (isRecovered()) {
/*  557 */       IPackageBinding packageBinding = getPackage();
/*  558 */       if (packageBinding != null) {
/*  559 */         IJavaElement javaElement = packageBinding.getJavaElement();
/*  560 */         if (javaElement != null && javaElement.getElementType() == 4)
/*      */         {
/*  562 */           return (IJavaElement)((PackageFragment)javaElement).getCompilationUnit(String.valueOf(new String(this.binding.sourceName())) + ".java").getType(getName());
/*      */         }
/*      */       } 
/*  565 */       return null;
/*      */     } 
/*  567 */     return null;
/*      */   }
/*      */   
/*      */   private JavaElement getUnresolvedJavaElement() {
/*  571 */     return getUnresolvedJavaElement(this.binding);
/*      */   }
/*      */   private JavaElement getUnresolvedJavaElement(org.eclipse.jdt.internal.compiler.lookup.TypeBinding typeBinding) {
/*  574 */     if (JavaCore.getPlugin() == null) {
/*  575 */       return null;
/*      */     }
/*  577 */     if (this.resolver instanceof DefaultBindingResolver) {
/*  578 */       DefaultBindingResolver defaultBindingResolver = (DefaultBindingResolver)this.resolver;
/*  579 */       if (!defaultBindingResolver.fromJavaProject) return null; 
/*  580 */       return Util.getUnresolvedJavaElement(
/*  581 */           typeBinding, 
/*  582 */           defaultBindingResolver.workingCopyOwner, 
/*  583 */           defaultBindingResolver.getBindingsToNodesMap());
/*      */     } 
/*  585 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getKey() {
/*  590 */     if (this.key == null) {
/*  591 */       this.key = new String(this.binding.computeUniqueKey());
/*      */     }
/*  593 */     return this.key;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getKind() {
/*  598 */     return 2;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getModifiers() {
/*  603 */     if (isClass()) {
/*  604 */       ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/*  605 */       int accessFlags = referenceBinding.getAccessFlags() & 0xC1F;
/*  606 */       if (referenceBinding.isAnonymousType()) {
/*  607 */         return accessFlags & 0xFFFFFFEF;
/*      */       }
/*  609 */       return accessFlags;
/*  610 */     }  if (isAnnotation()) {
/*  611 */       ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/*  612 */       int accessFlags = referenceBinding.getAccessFlags() & 0xC1F;
/*      */       
/*  614 */       return accessFlags & 0xFFFFD9FF;
/*  615 */     }  if (isInterface()) {
/*  616 */       ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/*  617 */       int accessFlags = referenceBinding.getAccessFlags() & 0xC1F;
/*      */       
/*  619 */       return accessFlags & 0xFFFFF9FF;
/*  620 */     }  if (isEnum()) {
/*  621 */       ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/*  622 */       int accessFlags = referenceBinding.getAccessFlags() & 0xC1F;
/*      */       
/*  624 */       return accessFlags & 0xFFFFBFFF;
/*      */     } 
/*  626 */     return 0; } public String getName() { StringBuffer buffer; WildcardBinding wildcardBinding; TypeVariableBinding typeVariableBinding; ParameterizedTypeBinding parameterizedTypeBinding;
/*      */     ITypeBinding[] tArguments;
/*      */     int typeArgumentsLength;
/*      */     ITypeBinding elementType;
/*      */     int dimensions;
/*      */     char[] brackets;
/*      */     int i;
/*  633 */     switch (this.binding.kind()) {
/*      */       
/*      */       case 516:
/*      */       case 8196:
/*  637 */         wildcardBinding = (WildcardBinding)this.binding;
/*  638 */         buffer = new StringBuffer();
/*  639 */         buffer.append(TypeConstants.WILDCARD_NAME);
/*  640 */         if (wildcardBinding.bound != null) {
/*  641 */           switch (wildcardBinding.boundKind) {
/*      */             case 2:
/*  643 */               buffer.append(TypeConstants.WILDCARD_SUPER);
/*      */               break;
/*      */             case 1:
/*  646 */               buffer.append(TypeConstants.WILDCARD_EXTENDS); break;
/*      */           } 
/*  648 */           buffer.append(getBound().getName());
/*      */         } 
/*  650 */         return String.valueOf(buffer);
/*      */       
/*      */       case 4100:
/*  653 */         if (isCapture()) {
/*  654 */           return "";
/*      */         }
/*  656 */         typeVariableBinding = (TypeVariableBinding)this.binding;
/*  657 */         return new String(typeVariableBinding.sourceName);
/*      */       
/*      */       case 260:
/*  660 */         parameterizedTypeBinding = (ParameterizedTypeBinding)this.binding;
/*  661 */         buffer = new StringBuffer();
/*  662 */         buffer.append(parameterizedTypeBinding.sourceName());
/*  663 */         tArguments = getTypeArguments();
/*  664 */         typeArgumentsLength = tArguments.length;
/*  665 */         if (typeArgumentsLength != 0) {
/*  666 */           buffer.append('<');
/*  667 */           for (int j = 0; j < typeArgumentsLength; j++) {
/*  668 */             if (j > 0) {
/*  669 */               buffer.append(',');
/*      */             }
/*  671 */             buffer.append(tArguments[j].getName());
/*      */           } 
/*  673 */           buffer.append('>');
/*      */         } 
/*  675 */         return String.valueOf(buffer);
/*      */       
/*      */       case 1028:
/*  678 */         return getTypeDeclaration().getName();
/*      */       
/*      */       case 68:
/*  681 */         elementType = getElementType();
/*  682 */         if (elementType.isLocal() || elementType.isAnonymous() || elementType.isCapture()) {
/*  683 */           return "";
/*      */         }
/*  685 */         dimensions = getDimensions();
/*  686 */         brackets = new char[dimensions * 2];
/*  687 */         for (i = dimensions * 2 - 1; i >= 0; i -= 2) {
/*  688 */           brackets[i] = ']';
/*  689 */           brackets[i - 1] = '[';
/*      */         } 
/*  691 */         buffer = new StringBuffer(elementType.getName());
/*  692 */         buffer.append(brackets);
/*  693 */         return String.valueOf(buffer);
/*      */ 
/*      */       
/*      */       case 32772:
/*  697 */         return new String(((IntersectionTypeBinding18)this.binding).getIntersectingTypes()[0].sourceName());
/*      */     } 
/*      */     
/*  700 */     if (isPrimitive() || isNullType()) {
/*  701 */       BaseTypeBinding baseTypeBinding = (BaseTypeBinding)this.binding;
/*  702 */       return new String(baseTypeBinding.simpleName);
/*      */     } 
/*  704 */     if (isAnonymous()) {
/*  705 */       return "";
/*      */     }
/*  707 */     return new String(this.binding.sourceName()); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPackageBinding getPackage() {
/*  713 */     switch (this.binding.kind()) {
/*      */       case 68:
/*      */       case 132:
/*      */       case 516:
/*      */       case 4100:
/*      */       case 8196:
/*      */       case 32772:
/*  720 */         return null;
/*      */     } 
/*  722 */     ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/*  723 */     return this.resolver.getPackageBinding(referenceBinding.getPackage()); } public String getQualifiedName() {
/*      */     WildcardBinding wildcardBinding;
/*      */     ITypeBinding bound, elementType;
/*      */     int dimensions;
/*      */     char[] brackets;
/*      */     int i;
/*      */     TypeVariableBinding typeVariableBinding;
/*      */     ITypeBinding[] tArguments;
/*      */     int typeArgumentsLength;
/*  732 */     switch (this.binding.kind()) {
/*      */       
/*      */       case 516:
/*      */       case 8196:
/*  736 */         wildcardBinding = (WildcardBinding)this.binding;
/*  737 */         buffer = new StringBuffer();
/*  738 */         buffer.append(TypeConstants.WILDCARD_NAME);
/*  739 */         bound = getBound();
/*  740 */         if (bound != null) {
/*  741 */           switch (wildcardBinding.boundKind) {
/*      */             case 2:
/*  743 */               buffer.append(TypeConstants.WILDCARD_SUPER);
/*      */               break;
/*      */             case 1:
/*  746 */               buffer.append(TypeConstants.WILDCARD_EXTENDS); break;
/*      */           } 
/*  748 */           buffer.append(bound.getQualifiedName());
/*      */         } 
/*  750 */         return String.valueOf(buffer);
/*      */       
/*      */       case 1028:
/*  753 */         return getTypeDeclaration().getQualifiedName();
/*      */       
/*      */       case 68:
/*  756 */         elementType = getElementType();
/*  757 */         if (elementType.isLocal() || elementType.isAnonymous() || elementType.isCapture()) {
/*  758 */           return elementType.getQualifiedName();
/*      */         }
/*  760 */         dimensions = getDimensions();
/*  761 */         brackets = new char[dimensions * 2];
/*  762 */         for (i = dimensions * 2 - 1; i >= 0; i -= 2) {
/*  763 */           brackets[i] = ']';
/*  764 */           brackets[i - 1] = '[';
/*      */         } 
/*  766 */         buffer = new StringBuffer(elementType.getQualifiedName());
/*  767 */         buffer.append(brackets);
/*  768 */         return String.valueOf(buffer);
/*      */       
/*      */       case 4100:
/*  771 */         if (isCapture()) {
/*  772 */           return "";
/*      */         }
/*  774 */         typeVariableBinding = (TypeVariableBinding)this.binding;
/*  775 */         return new String(typeVariableBinding.sourceName);
/*      */       
/*      */       case 260:
/*  778 */         if (this.binding.isLocalType()) {
/*  779 */           return "";
/*      */         }
/*  781 */         buffer = new StringBuffer();
/*  782 */         if (isMember()) {
/*  783 */           buffer
/*  784 */             .append(getDeclaringClass().getQualifiedName())
/*  785 */             .append('.');
/*  786 */           ParameterizedTypeBinding parameterizedTypeBinding = (ParameterizedTypeBinding)this.binding;
/*  787 */           buffer.append(parameterizedTypeBinding.sourceName());
/*  788 */           ITypeBinding[] arrayOfITypeBinding = getTypeArguments();
/*  789 */           int j = arrayOfITypeBinding.length;
/*  790 */           if (j != 0) {
/*  791 */             buffer.append('<');
/*  792 */             for (int k = 0; k < j; k++) {
/*  793 */               if (k > 0) {
/*  794 */                 buffer.append(',');
/*      */               }
/*  796 */               buffer.append(arrayOfITypeBinding[k].getQualifiedName());
/*      */             } 
/*  798 */             buffer.append('>');
/*      */           } 
/*  800 */           return String.valueOf(buffer);
/*      */         } 
/*  802 */         buffer.append(getTypeDeclaration().getQualifiedName());
/*  803 */         tArguments = getTypeArguments();
/*  804 */         typeArgumentsLength = tArguments.length;
/*  805 */         if (typeArgumentsLength != 0) {
/*  806 */           buffer.append('<');
/*  807 */           for (int j = 0; j < typeArgumentsLength; j++) {
/*  808 */             if (j > 0) {
/*  809 */               buffer.append(',');
/*      */             }
/*  811 */             buffer.append(tArguments[j].getQualifiedName());
/*      */           } 
/*  813 */           buffer.append('>');
/*      */         } 
/*  815 */         return String.valueOf(buffer);
/*      */     } 
/*  817 */     if (isAnonymous() || this.binding.isLocalType() || this.binding.isIntersectionType18()) {
/*  818 */       return "";
/*      */     }
/*  820 */     if (isPrimitive() || isNullType()) {
/*  821 */       BaseTypeBinding baseTypeBinding = (BaseTypeBinding)this.binding;
/*  822 */       return new String(baseTypeBinding.simpleName);
/*      */     } 
/*  824 */     if (isMember()) {
/*  825 */       buffer = new StringBuffer();
/*  826 */       buffer
/*  827 */         .append(getDeclaringClass().getQualifiedName())
/*  828 */         .append('.');
/*  829 */       buffer.append(getName());
/*  830 */       return String.valueOf(buffer);
/*      */     } 
/*  832 */     PackageBinding packageBinding = this.binding.getPackage();
/*  833 */     StringBuffer buffer = new StringBuffer();
/*  834 */     if (packageBinding != null && packageBinding.compoundName != CharOperation.NO_CHAR_CHAR) {
/*  835 */       buffer.append(CharOperation.concatWith(packageBinding.compoundName, '.')).append('.');
/*      */     }
/*  837 */     buffer.append(getName());
/*  838 */     return String.valueOf(buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized ITypeBinding getSuperclass() {
/*  844 */     if (this.binding == null)
/*  845 */       return null; 
/*  846 */     switch (this.binding.kind()) {
/*      */       case 68:
/*      */       case 132:
/*  849 */         return null;
/*      */     } 
/*      */     
/*  852 */     if (this.binding.isInterface()) {
/*  853 */       return null;
/*      */     }
/*  855 */     ReferenceBinding superclass = null;
/*      */     try {
/*  857 */       superclass = ((ReferenceBinding)this.binding).superclass();
/*  858 */     } catch (RuntimeException e) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  864 */       Util.log(e, "Could not retrieve superclass");
/*  865 */       return this.resolver.resolveWellKnownType("java.lang.Object");
/*      */     } 
/*  867 */     if (superclass == null) {
/*  868 */       return null;
/*      */     }
/*  870 */     return this.resolver.getTypeBinding((org.eclipse.jdt.internal.compiler.lookup.TypeBinding)superclass);
/*      */   }
/*      */ 
/*      */   
/*      */   public ITypeBinding[] getTypeArguments() {
/*  875 */     if (this.prototype != null) {
/*  876 */       return this.prototype.getTypeArguments();
/*      */     }
/*  878 */     if (this.typeArguments != null) {
/*  879 */       return this.typeArguments;
/*      */     }
/*  881 */     if (this.binding.isParameterizedTypeWithActualArguments()) {
/*  882 */       ParameterizedTypeBinding parameterizedTypeBinding = (ParameterizedTypeBinding)this.binding;
/*  883 */       org.eclipse.jdt.internal.compiler.lookup.TypeBinding[] arguments = parameterizedTypeBinding.arguments;
/*  884 */       int argumentsLength = arguments.length;
/*  885 */       ITypeBinding[] newTypeArguments = new ITypeBinding[argumentsLength];
/*  886 */       for (int i = 0; i < argumentsLength; i++) {
/*  887 */         ITypeBinding typeBinding = this.resolver.getTypeBinding(arguments[i]);
/*  888 */         if (typeBinding == null) {
/*  889 */           return this.typeArguments = NO_TYPE_BINDINGS;
/*      */         }
/*  891 */         newTypeArguments[i] = typeBinding;
/*      */       } 
/*  893 */       return this.typeArguments = newTypeArguments;
/*      */     } 
/*  895 */     return this.typeArguments = NO_TYPE_BINDINGS;
/*      */   }
/*      */ 
/*      */   
/*      */   public ITypeBinding[] getTypeBounds() {
/*  900 */     if (this.prototype != null) {
/*  901 */       return this.prototype.getTypeBounds();
/*      */     }
/*  903 */     if (this.bounds != null) {
/*  904 */       return this.bounds;
/*      */     }
/*  906 */     TypeVariableBinding typeVariableBinding = null;
/*  907 */     if (this.binding instanceof TypeVariableBinding) {
/*  908 */       typeVariableBinding = (TypeVariableBinding)this.binding;
/*  909 */     } else if (this.binding instanceof WildcardBinding) {
/*  910 */       WildcardBinding wildcardBinding = (WildcardBinding)this.binding;
/*  911 */       typeVariableBinding = wildcardBinding.typeVariable();
/*  912 */       if (typeVariableBinding == null) {
/*  913 */         org.eclipse.jdt.internal.compiler.lookup.TypeBinding allBounds = wildcardBinding.allBounds();
/*  914 */         if (allBounds instanceof IntersectionTypeBinding18) {
/*  915 */           ITypeBinding typeBinding = this.resolver.getTypeBinding(allBounds);
/*  916 */           if (typeBinding instanceof TypeBinding) {
/*  917 */             return ((TypeBinding)typeBinding).getIntersectingTypes();
/*      */           }
/*      */         } 
/*      */       } 
/*  921 */     } else if (this.binding instanceof IntersectionTypeBinding18) {
/*  922 */       return this.bounds = getIntersectingTypes();
/*      */     } 
/*  924 */     if (typeVariableBinding != null) {
/*  925 */       ReferenceBinding referenceBinding1, varSuperclass = typeVariableBinding.superclass();
/*  926 */       org.eclipse.jdt.internal.compiler.lookup.TypeBinding firstClassOrArrayBound = typeVariableBinding.firstBound;
/*  927 */       int boundsLength = 0;
/*  928 */       if (firstClassOrArrayBound == null) {
/*  929 */         if (varSuperclass != null && varSuperclass.id != 1) {
/*  930 */           referenceBinding1 = varSuperclass;
/*  931 */           boundsLength++;
/*      */         }
/*      */       
/*  934 */       } else if (org.eclipse.jdt.internal.compiler.lookup.TypeBinding.equalsEquals((org.eclipse.jdt.internal.compiler.lookup.TypeBinding)referenceBinding1, (org.eclipse.jdt.internal.compiler.lookup.TypeBinding)varSuperclass)) {
/*  935 */         boundsLength++;
/*  936 */       } else if (referenceBinding1.isArrayType()) {
/*  937 */         boundsLength++;
/*      */       } else {
/*  939 */         referenceBinding1 = null;
/*      */       } 
/*      */       
/*  942 */       ReferenceBinding[] superinterfaces = typeVariableBinding.superInterfaces();
/*  943 */       int superinterfacesLength = 0;
/*  944 */       if (superinterfaces != null) {
/*  945 */         superinterfacesLength = superinterfaces.length;
/*  946 */         boundsLength += superinterfacesLength;
/*      */       } 
/*  948 */       if (boundsLength != 0) {
/*  949 */         ITypeBinding[] typeBounds = new ITypeBinding[boundsLength];
/*  950 */         int boundsIndex = 0;
/*  951 */         if (referenceBinding1 != null) {
/*  952 */           ITypeBinding typeBinding = this.resolver.getTypeBinding((org.eclipse.jdt.internal.compiler.lookup.TypeBinding)referenceBinding1);
/*  953 */           if (typeBinding == null) {
/*  954 */             return this.bounds = NO_TYPE_BINDINGS;
/*      */           }
/*  956 */           typeBounds[boundsIndex++] = typeBinding;
/*      */         } 
/*  958 */         if (superinterfaces != null) {
/*  959 */           for (int i = 0; i < superinterfacesLength; i++, boundsIndex++) {
/*  960 */             ITypeBinding typeBinding = this.resolver.getTypeBinding((org.eclipse.jdt.internal.compiler.lookup.TypeBinding)superinterfaces[i]);
/*  961 */             if (typeBinding == null) {
/*  962 */               return this.bounds = NO_TYPE_BINDINGS;
/*      */             }
/*  964 */             typeBounds[boundsIndex] = typeBinding;
/*      */           } 
/*      */         }
/*  967 */         return this.bounds = typeBounds;
/*      */       } 
/*      */     } 
/*  970 */     return this.bounds = NO_TYPE_BINDINGS;
/*      */   }
/*      */ 
/*      */   
/*      */   public ITypeBinding[] getTypeParameters() {
/*  975 */     if (this.prototype != null) {
/*  976 */       return this.prototype.getTypeParameters();
/*      */     }
/*  978 */     if (this.typeParameters != null) {
/*  979 */       return this.typeParameters;
/*      */     }
/*  981 */     switch (this.binding.kind()) {
/*      */       case 260:
/*      */       case 1028:
/*  984 */         return this.typeParameters = NO_TYPE_BINDINGS;
/*      */     } 
/*  986 */     TypeVariableBinding[] typeVariableBindings = this.binding.typeVariables();
/*  987 */     int typeVariableBindingsLength = (typeVariableBindings == null) ? 0 : typeVariableBindings.length;
/*  988 */     if (typeVariableBindingsLength != 0) {
/*  989 */       ITypeBinding[] newTypeParameters = new ITypeBinding[typeVariableBindingsLength];
/*  990 */       for (int i = 0; i < typeVariableBindingsLength; i++) {
/*  991 */         ITypeBinding typeBinding = this.resolver.getTypeBinding((org.eclipse.jdt.internal.compiler.lookup.TypeBinding)typeVariableBindings[i]);
/*  992 */         if (typeBinding == null) {
/*  993 */           return this.typeParameters = NO_TYPE_BINDINGS;
/*      */         }
/*  995 */         newTypeParameters[i] = typeBinding;
/*      */       } 
/*  997 */       return this.typeParameters = newTypeParameters;
/*      */     } 
/*  999 */     return this.typeParameters = NO_TYPE_BINDINGS;
/*      */   }
/*      */ 
/*      */   
/*      */   public ITypeBinding getWildcard() {
/* 1004 */     if (this.binding instanceof CaptureBinding) {
/* 1005 */       CaptureBinding captureBinding = (CaptureBinding)this.binding;
/* 1006 */       return this.resolver.getTypeBinding((org.eclipse.jdt.internal.compiler.lookup.TypeBinding)captureBinding.wildcard);
/*      */     } 
/* 1008 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isGenericType() {
/* 1014 */     if (isRawType()) {
/* 1015 */       return false;
/*      */     }
/* 1017 */     TypeVariableBinding[] typeVariableBindings = this.binding.typeVariables();
/* 1018 */     return (typeVariableBindings != null && typeVariableBindings.length > 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAnnotation() {
/* 1023 */     return this.binding.isAnnotationType();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAnonymous() {
/* 1028 */     if (isClass() || isInterface() || isEnum()) {
/* 1029 */       ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/* 1030 */       return referenceBinding.isAnonymousType();
/*      */     } 
/* 1032 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isArray() {
/* 1037 */     return this.binding.isArrayType();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAssignmentCompatible(ITypeBinding type) {
/*      */     try {
/* 1043 */       if (this == type) return true; 
/* 1044 */       if (!(type instanceof TypeBinding)) return false; 
/* 1045 */       TypeBinding other = (TypeBinding)type;
/* 1046 */       CompilationUnitScope compilationUnitScope = this.resolver.scope();
/* 1047 */       if (compilationUnitScope == null) return false; 
/* 1048 */       return !(!this.binding.isCompatibleWith(other.binding) && !compilationUnitScope.isBoxingCompatibleWith(this.binding, other.binding));
/* 1049 */     } catch (AbortCompilation abortCompilation) {
/*      */ 
/*      */       
/* 1052 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCapture() {
/* 1058 */     return (this.binding.isCapture() && !(this.binding instanceof CaptureBinding18));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCastCompatible(ITypeBinding type) {
/*      */     try {
/* 1064 */       CompilationUnitScope compilationUnitScope = this.resolver.scope();
/* 1065 */       if (compilationUnitScope == null) return false; 
/* 1066 */       if (!(type instanceof TypeBinding)) return false; 
/* 1067 */       org.eclipse.jdt.internal.compiler.lookup.TypeBinding expressionType = ((TypeBinding)type).binding;
/*      */       
/* 1069 */       expressionType = expressionType.capture((Scope)compilationUnitScope, 0, 0);
/* 1070 */       return EXPRESSION.checkCastTypesCompatibility((Scope)compilationUnitScope, this.binding, expressionType, null, true);
/* 1071 */     } catch (AbortCompilation abortCompilation) {
/*      */ 
/*      */       
/* 1074 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isClass() {
/* 1080 */     switch (this.binding.kind()) {
/*      */       case 516:
/*      */       case 4100:
/*      */       case 8196:
/* 1084 */         return false;
/*      */     } 
/* 1086 */     return this.binding.isClass();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDeprecated() {
/* 1091 */     if (isClass() || isInterface() || isEnum()) {
/* 1092 */       ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/* 1093 */       return referenceBinding.isDeprecated();
/*      */     } 
/* 1095 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isEnum() {
/* 1100 */     return this.binding.isEnum();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isRecord() {
/* 1105 */     return this.binding.isRecord();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isEqualTo(IBinding other) {
/* 1110 */     if (other == this)
/*      */     {
/* 1112 */       return true;
/*      */     }
/* 1114 */     if (other == null)
/*      */     {
/* 1116 */       return false;
/*      */     }
/* 1118 */     if (!(other instanceof TypeBinding)) {
/* 1119 */       return false;
/*      */     }
/* 1121 */     org.eclipse.jdt.internal.compiler.lookup.TypeBinding otherBinding = ((TypeBinding)other).binding;
/* 1122 */     if (org.eclipse.jdt.internal.compiler.lookup.TypeBinding.equalsEquals(otherBinding.unannotated(), this.binding.unannotated())) {
/* 1123 */       return true;
/*      */     }
/*      */     
/* 1126 */     return BindingComparator.isEqual(this.binding, otherBinding);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isFromSource() {
/* 1131 */     if (isClass() || isInterface() || isEnum()) {
/* 1132 */       ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/* 1133 */       if (referenceBinding.isRawType())
/* 1134 */         return !((RawTypeBinding)referenceBinding).genericType().isBinaryBinding(); 
/* 1135 */       if (referenceBinding.isParameterizedType()) {
/* 1136 */         ParameterizedTypeBinding parameterizedTypeBinding = (ParameterizedTypeBinding)referenceBinding;
/* 1137 */         org.eclipse.jdt.internal.compiler.lookup.TypeBinding erasure = parameterizedTypeBinding.erasure();
/* 1138 */         if (erasure instanceof ReferenceBinding) {
/* 1139 */           return !((ReferenceBinding)erasure).isBinaryBinding();
/*      */         }
/* 1141 */         return false;
/*      */       } 
/* 1143 */       return !referenceBinding.isBinaryBinding();
/*      */     } 
/* 1145 */     if (isTypeVariable()) {
/* 1146 */       TypeVariableBinding typeVariableBinding = (TypeVariableBinding)this.binding;
/* 1147 */       Binding declaringElement = typeVariableBinding.declaringElement;
/* 1148 */       if (declaringElement instanceof MethodBinding) {
/* 1149 */         MethodBinding methodBinding = (MethodBinding)declaringElement;
/* 1150 */         return !methodBinding.declaringClass.isBinaryBinding();
/*      */       } 
/* 1152 */       org.eclipse.jdt.internal.compiler.lookup.TypeBinding typeBinding = (org.eclipse.jdt.internal.compiler.lookup.TypeBinding)declaringElement;
/* 1153 */       if (typeBinding instanceof ReferenceBinding)
/* 1154 */         return !((ReferenceBinding)typeBinding).isBinaryBinding(); 
/* 1155 */       if (typeBinding instanceof ArrayBinding) {
/* 1156 */         ArrayBinding arrayBinding = (ArrayBinding)typeBinding;
/* 1157 */         org.eclipse.jdt.internal.compiler.lookup.TypeBinding leafComponentType = arrayBinding.leafComponentType;
/* 1158 */         if (leafComponentType instanceof ReferenceBinding) {
/* 1159 */           return !((ReferenceBinding)leafComponentType).isBinaryBinding();
/*      */         }
/*      */       }
/*      */     
/*      */     }
/* 1164 */     else if (isCapture()) {
/* 1165 */       CaptureBinding captureBinding = (CaptureBinding)this.binding;
/* 1166 */       return !captureBinding.sourceType.isBinaryBinding();
/*      */     } 
/* 1168 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isInterface() {
/* 1173 */     switch (this.binding.kind()) {
/*      */       case 516:
/*      */       case 4100:
/*      */       case 8196:
/* 1177 */         return false;
/*      */     } 
/* 1179 */     return this.binding.isInterface();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isIntersectionType() {
/* 1184 */     int kind = this.binding.kind();
/* 1185 */     return !(kind != 32772 && kind != 8196);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isLocal() {
/* 1190 */     if (isClass() || isInterface() || isEnum()) {
/* 1191 */       ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/* 1192 */       return (referenceBinding.isLocalType() && !referenceBinding.isMemberType());
/*      */     } 
/* 1194 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isMember() {
/* 1199 */     if (isClass() || isInterface() || isEnum()) {
/* 1200 */       ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/* 1201 */       return referenceBinding.isMemberType();
/*      */     } 
/* 1203 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isNested() {
/* 1208 */     if (isClass() || isInterface() || isEnum()) {
/* 1209 */       ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/* 1210 */       return referenceBinding.isNestedType();
/*      */     } 
/* 1212 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNullType() {
/* 1220 */     return (this.binding == org.eclipse.jdt.internal.compiler.lookup.TypeBinding.NULL);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isParameterizedType() {
/* 1225 */     return this.binding.isParameterizedTypeWithActualArguments();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isPrimitive() {
/* 1230 */     return (!isNullType() && this.binding.isBaseType());
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isRawType() {
/* 1235 */     return this.binding.isRawType();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isRecovered() {
/* 1240 */     return ((this.binding.tagBits & 0x80L) != 0L);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isSubTypeCompatible(ITypeBinding type) {
/*      */     try {
/* 1246 */       if (this == type) return true; 
/* 1247 */       if (this.binding.isBaseType()) return false; 
/* 1248 */       if (!(type instanceof TypeBinding)) return false; 
/* 1249 */       TypeBinding other = (TypeBinding)type;
/* 1250 */       if (other.binding.isBaseType()) return false; 
/* 1251 */       return this.binding.isCompatibleWith(other.binding);
/* 1252 */     } catch (AbortCompilation abortCompilation) {
/*      */ 
/*      */       
/* 1255 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSynthetic() {
/* 1264 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTopLevel() {
/* 1269 */     if (isClass() || isInterface() || isEnum()) {
/* 1270 */       ReferenceBinding referenceBinding = (ReferenceBinding)this.binding;
/* 1271 */       return !referenceBinding.isNestedType();
/*      */     } 
/* 1273 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTypeVariable() {
/* 1278 */     return (this.binding.isTypeVariable() && !this.binding.isCapture());
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isUpperbound() {
/* 1283 */     switch (this.binding.kind()) {
/*      */       case 516:
/* 1285 */         return (((WildcardBinding)this.binding).boundKind == 1);
/*      */       case 8196:
/* 1287 */         return true;
/*      */       case 4100:
/* 1289 */         if (this.binding instanceof CaptureBinding18) {
/* 1290 */           CaptureBinding18 captureBinding18 = (CaptureBinding18)this.binding;
/* 1291 */           org.eclipse.jdt.internal.compiler.lookup.TypeBinding upperBound = captureBinding18.upperBound();
/* 1292 */           if (upperBound != null && upperBound.id != 1) {
/* 1293 */             return true;
/*      */           }
/*      */         } 
/* 1296 */         return false;
/*      */     } 
/* 1298 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWildcardType() {
/* 1303 */     return !(!this.binding.isWildcard() && !(this.binding instanceof CaptureBinding18));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1312 */     return this.binding.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public IAnnotationBinding[] getTypeAnnotations() {
/* 1317 */     if (this.typeAnnotations != null) {
/* 1318 */       return this.typeAnnotations;
/*      */     }
/* 1320 */     this.typeAnnotations = resolveAnnotationBindings(this.binding.getTypeAnnotations(), true);
/* 1321 */     return this.typeAnnotations;
/*      */   }
/*      */ 
/*      */   
/*      */   static class LocalTypeBinding
/*      */     extends TypeBinding
/*      */   {
/*      */     private IBinding declaringMember;
/*      */ 
/*      */     
/*      */     public LocalTypeBinding(BindingResolver resolver, org.eclipse.jdt.internal.compiler.lookup.TypeBinding binding, IBinding declaringMember) {
/* 1332 */       super(resolver, binding);
/* 1333 */       this.declaringMember = declaringMember;
/*      */     }
/*      */ 
/*      */     
/*      */     public IBinding getDeclaringMember() {
/* 1338 */       return this.declaringMember;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\TypeBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */