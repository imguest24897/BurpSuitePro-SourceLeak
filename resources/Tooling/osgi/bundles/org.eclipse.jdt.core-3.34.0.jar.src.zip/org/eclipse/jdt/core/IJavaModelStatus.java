package org.eclipse.jdt.core;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IStatus;

public interface IJavaModelStatus extends IStatus {
  IJavaElement[] getElements();
  
  IPath getPath();
  
  String getString();
  
  boolean isDoesNotExist();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IJavaModelStatus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */