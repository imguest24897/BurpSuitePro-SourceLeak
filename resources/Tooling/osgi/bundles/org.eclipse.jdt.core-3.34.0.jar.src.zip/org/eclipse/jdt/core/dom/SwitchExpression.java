/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwitchExpression
/*     */   extends Expression
/*     */ {
/*  43 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(SwitchExpression.class, "expression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public static final ChildListPropertyDescriptor STATEMENTS_PROPERTY = new ChildListPropertyDescriptor(SwitchExpression.class, "statements", Statement.class, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  60 */     List propertyList = new ArrayList(3);
/*  61 */     createPropertyList(SwitchExpression.class, propertyList);
/*  62 */     addProperty(EXPRESSION_PROPERTY, propertyList);
/*  63 */     addProperty(STATEMENTS_PROPERTY, propertyList);
/*  64 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  78 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   private Expression expression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   private ASTNode.NodeList statements = new ASTNode.NodeList(this, STATEMENTS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SwitchExpression(AST ast) {
/* 107 */     super(ast);
/* 108 */     unsupportedBelow14();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 113 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 118 */     if (property == EXPRESSION_PROPERTY) {
/* 119 */       if (get) {
/* 120 */         return getExpression();
/*     */       }
/* 122 */       setExpression((Expression)child);
/* 123 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 127 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 132 */     if (property == STATEMENTS_PROPERTY) {
/* 133 */       return statements();
/*     */     }
/*     */     
/* 136 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 141 */     return 100;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 146 */     SwitchExpression result = new SwitchExpression(target);
/* 147 */     result.setSourceRange(getStartPosition(), getLength());
/* 148 */     result.setExpression((Expression)getExpression().clone(target));
/* 149 */     result.statements().addAll(ASTNode.copySubtrees(target, statements()));
/* 150 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 156 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 161 */     boolean visitChildren = visitor.visit(this);
/* 162 */     if (visitChildren) {
/*     */       
/* 164 */       acceptChild(visitor, getExpression());
/* 165 */       acceptChildren(visitor, this.statements);
/*     */     } 
/* 167 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 177 */     if (this.expression == null)
/*     */     {
/* 179 */       synchronized (this) {
/* 180 */         if (this.expression == null) {
/* 181 */           preLazyInit();
/* 182 */           this.expression = new SimpleName(this.ast);
/* 183 */           postLazyInit(this.expression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 187 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 203 */     if (expression == null) {
/* 204 */       throw new IllegalArgumentException();
/*     */     }
/* 206 */     ASTNode oldChild = this.expression;
/* 207 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 208 */     this.expression = expression;
/* 209 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List statements() {
/* 222 */     return this.statements;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 227 */     return 52;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 232 */     return 
/* 233 */       memSize() + (
/* 234 */       (this.expression == null) ? 0 : getExpression().treeSize()) + 
/* 235 */       this.statements.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\SwitchExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */