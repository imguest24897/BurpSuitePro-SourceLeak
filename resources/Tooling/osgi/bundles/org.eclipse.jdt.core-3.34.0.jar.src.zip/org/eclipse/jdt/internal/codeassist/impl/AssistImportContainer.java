/*    */ package org.eclipse.jdt.internal.codeassist.impl;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.jdt.core.JavaModelException;
/*    */ import org.eclipse.jdt.internal.core.CompilationUnit;
/*    */ import org.eclipse.jdt.internal.core.ImportContainer;
/*    */ import org.eclipse.jdt.internal.core.ImportDeclaration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AssistImportContainer
/*    */   extends ImportContainer
/*    */ {
/*    */   private Map infoCache;
/*    */   
/*    */   public AssistImportContainer(CompilationUnit parent, Map infoCache) {
/* 28 */     super(parent);
/* 29 */     this.infoCache = infoCache;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getElementInfo(IProgressMonitor monitor) throws JavaModelException {
/* 34 */     return this.infoCache.get(this);
/*    */   }
/*    */ 
/*    */   
/*    */   protected ImportDeclaration getImport(String importName, boolean isOnDemand) {
/* 39 */     return new AssistImportDeclaration(this, importName, isOnDemand, this.infoCache);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\impl\AssistImportContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */