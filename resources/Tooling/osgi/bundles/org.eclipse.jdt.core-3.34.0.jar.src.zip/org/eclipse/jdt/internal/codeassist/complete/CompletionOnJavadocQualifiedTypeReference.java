/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ import org.eclipse.jdt.internal.compiler.ast.JavadocQualifiedTypeReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnJavadocQualifiedTypeReference
/*    */   extends JavadocQualifiedTypeReference
/*    */   implements CompletionOnJavadoc
/*    */ {
/* 20 */   public int completionFlags = 1;
/*    */   public char[] completionIdentifier;
/*    */   
/*    */   public CompletionOnJavadocQualifiedTypeReference(char[][] sources, char[] identifier, long[] pos, int tagStart, int tagEnd) {
/* 24 */     super(sources, pos, tagStart, tagEnd);
/* 25 */     this.completionIdentifier = identifier;
/*    */   }
/*    */   
/*    */   public CompletionOnJavadocQualifiedTypeReference(JavadocQualifiedTypeReference typeRef) {
/* 29 */     super(typeRef.tokens, typeRef.sourcePositions, typeRef.tagSourceStart, typeRef.tagSourceStart);
/* 30 */     this.completionIdentifier = CharOperation.NO_CHAR;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addCompletionFlags(int flags) {
/* 35 */     this.completionFlags |= flags;
/*    */   }
/*    */   
/*    */   public boolean completeAnException() {
/* 39 */     return ((this.completionFlags & 0x2) != 0);
/*    */   }
/*    */   
/*    */   public boolean completeInText() {
/* 43 */     return ((this.completionFlags & 0x4) != 0);
/*    */   }
/*    */   
/*    */   public boolean completeBaseTypes() {
/* 47 */     return ((this.completionFlags & 0x8) != 0);
/*    */   }
/*    */   
/*    */   public boolean completeFormalReference() {
/* 51 */     return ((this.completionFlags & 0x40) != 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getCompletionFlags() {
/* 56 */     return this.completionFlags;
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 61 */     output.append("<CompletionOnJavadocQualifiedTypeReference:");
/* 62 */     super.printExpression(indent, output);
/* 63 */     indent++;
/* 64 */     if (this.completionFlags > 0) {
/* 65 */       output.append('\n');
/* 66 */       for (int j = 0; j < indent; ) { output.append('\t'); j++; }
/* 67 */        output.append("infos:");
/* 68 */       char separator = Character.MIN_VALUE;
/* 69 */       if (completeAnException()) {
/* 70 */         output.append("exception");
/* 71 */         separator = ',';
/*    */       } 
/* 73 */       if (completeInText()) {
/* 74 */         if (separator != '\000') output.append(separator); 
/* 75 */         output.append("text");
/* 76 */         separator = ',';
/*    */       } 
/* 78 */       if (completeBaseTypes()) {
/* 79 */         if (separator != '\000') output.append(separator); 
/* 80 */         output.append("base types");
/* 81 */         separator = ',';
/*    */       } 
/* 83 */       if (completeFormalReference()) {
/* 84 */         if (separator != '\000') output.append(separator); 
/* 85 */         output.append("formal reference");
/* 86 */         separator = ',';
/*    */       } 
/* 88 */       output.append('\n');
/*    */     } 
/* 90 */     indent--;
/* 91 */     for (int i = 0; i < indent; ) { output.append('\t'); i++; }
/* 92 */      return output.append('>');
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnJavadocQualifiedTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */