/*     */ package org.eclipse.jdt.internal.codeassist.complete;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ast.ParameterizedQualifiedTypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompletionOnParameterizedQualifiedTypeReference
/*     */   extends ParameterizedQualifiedTypeReference
/*     */ {
/*     */   public static final int K_TYPE = 0;
/*     */   public static final int K_CLASS = 1;
/*     */   public static final int K_INTERFACE = 2;
/*     */   public static final int K_EXCEPTION = 3;
/*  45 */   private int kind = 0;
/*     */ 
/*     */   
/*     */   public char[] completionIdentifier;
/*     */ 
/*     */ 
/*     */   
/*     */   public CompletionOnParameterizedQualifiedTypeReference(char[][] tokens, TypeReference[][] typeArguments, char[] completionIdentifier, long[] positions) {
/*  53 */     this(tokens, typeArguments, completionIdentifier, positions, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompletionOnParameterizedQualifiedTypeReference(char[][] tokens, TypeReference[][] typeArguments, char[] completionIdentifier, long[] positions, int kind) {
/*  63 */     super(tokens, typeArguments, 0, positions);
/*  64 */     this.completionIdentifier = completionIdentifier;
/*  65 */     this.kind = kind;
/*     */   }
/*     */   
/*     */   public boolean isClass() {
/*  69 */     return (this.kind == 1);
/*     */   }
/*     */   
/*     */   public boolean isInterface() {
/*  73 */     return (this.kind == 2);
/*     */   }
/*     */   
/*     */   public boolean isException() {
/*  77 */     return (this.kind == 3);
/*     */   }
/*     */   
/*     */   public boolean isSuperType() {
/*  81 */     return !(this.kind != 1 && this.kind != 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(BlockScope scope, boolean checkBounds, int location) {
/*  86 */     super.resolveType(scope, checkBounds, location);
/*  87 */     throw new CompletionNodeFound(this, this.resolvedType, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeBinding resolveType(ClassScope scope, int location) {
/*  92 */     super.resolveType(scope, location);
/*  93 */     throw new CompletionNodeFound(this, this.resolvedType, scope);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/*  98 */     switch (this.kind) {
/*     */       case 1:
/* 100 */         output.append("<CompleteOnClass:");
/*     */         break;
/*     */       case 2:
/* 103 */         output.append("<CompleteOnInterface:");
/*     */         break;
/*     */       case 3:
/* 106 */         output.append("<CompleteOnException:");
/*     */         break;
/*     */       default:
/* 109 */         output.append("<CompleteOnType:");
/*     */         break;
/*     */     } 
/* 112 */     int length = this.tokens.length;
/* 113 */     for (int i = 0; i < length - 1; i++) {
/* 114 */       output.append(this.tokens[i]);
/* 115 */       TypeReference[] arrayOfTypeReference = this.typeArguments[i];
/* 116 */       if (arrayOfTypeReference != null) {
/* 117 */         output.append('<');
/* 118 */         int max = arrayOfTypeReference.length - 1;
/* 119 */         for (int j = 0; j < max; j++) {
/* 120 */           arrayOfTypeReference[j].print(0, output);
/* 121 */           output.append(", ");
/*     */         } 
/* 123 */         arrayOfTypeReference[max].print(0, output);
/* 124 */         output.append('>');
/*     */       } 
/* 126 */       output.append('.');
/*     */     } 
/* 128 */     output.append(this.tokens[length - 1]);
/* 129 */     TypeReference[] typeArgument = this.typeArguments[length - 1];
/* 130 */     if (typeArgument != null) {
/* 131 */       output.append('<');
/* 132 */       int max = typeArgument.length - 1;
/* 133 */       for (int j = 0; j < max; j++) {
/* 134 */         typeArgument[j].print(0, output);
/* 135 */         output.append(", ");
/*     */       } 
/* 137 */       typeArgument[max].print(0, output);
/* 138 */       output.append('>');
/*     */     } 
/* 140 */     output.append('.').append(this.completionIdentifier).append('>');
/* 141 */     return output;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnParameterizedQualifiedTypeReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */