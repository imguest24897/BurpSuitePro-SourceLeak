/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldAccess
/*     */   extends Expression
/*     */ {
/*  69 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(FieldAccess.class, "expression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(FieldAccess.class, "name", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  86 */     List properyList = new ArrayList(3);
/*  87 */     createPropertyList(FieldAccess.class, properyList);
/*  88 */     addProperty(EXPRESSION_PROPERTY, properyList);
/*  89 */     addProperty(NAME_PROPERTY, properyList);
/*  90 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 105 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   private Expression expression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   private SimpleName fieldName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FieldAccess(AST ast) {
/* 131 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 136 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 141 */     if (property == EXPRESSION_PROPERTY) {
/* 142 */       if (get) {
/* 143 */         return getExpression();
/*     */       }
/* 145 */       setExpression((Expression)child);
/* 146 */       return null;
/*     */     } 
/*     */     
/* 149 */     if (property == NAME_PROPERTY) {
/* 150 */       if (get) {
/* 151 */         return getName();
/*     */       }
/* 153 */       setName((SimpleName)child);
/* 154 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 158 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 163 */     return 22;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 168 */     FieldAccess result = new FieldAccess(target);
/* 169 */     result.setSourceRange(getStartPosition(), getLength());
/* 170 */     result.setExpression((Expression)getExpression().clone(target));
/* 171 */     result.setName((SimpleName)getName().clone(target));
/* 172 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 178 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 183 */     boolean visitChildren = visitor.visit(this);
/* 184 */     if (visitChildren) {
/*     */       
/* 186 */       acceptChild(visitor, getExpression());
/* 187 */       acceptChild(visitor, getName());
/*     */     } 
/* 189 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 198 */     if (this.expression == null)
/*     */     {
/* 200 */       synchronized (this) {
/* 201 */         if (this.expression == null) {
/* 202 */           preLazyInit();
/* 203 */           this.expression = new SimpleName(this.ast);
/* 204 */           postLazyInit(this.expression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 208 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 223 */     if (expression == null) {
/* 224 */       throw new IllegalArgumentException();
/*     */     }
/* 226 */     ASTNode oldChild = this.expression;
/* 227 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 228 */     this.expression = expression;
/* 229 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 238 */     if (this.fieldName == null)
/*     */     {
/* 240 */       synchronized (this) {
/* 241 */         if (this.fieldName == null) {
/* 242 */           preLazyInit();
/* 243 */           this.fieldName = new SimpleName(this.ast);
/* 244 */           postLazyInit(this.fieldName, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 248 */     return this.fieldName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName fieldName) {
/* 262 */     if (fieldName == null) {
/* 263 */       throw new IllegalArgumentException();
/*     */     }
/* 265 */     ASTNode oldChild = this.fieldName;
/* 266 */     preReplaceChild(oldChild, fieldName, NAME_PROPERTY);
/* 267 */     this.fieldName = fieldName;
/* 268 */     postReplaceChild(oldChild, fieldName, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 274 */     return 48;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IVariableBinding resolveFieldBinding() {
/* 290 */     return this.ast.getBindingResolver().resolveField(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 295 */     return 
/* 296 */       memSize() + (
/* 297 */       (this.expression == null) ? 0 : getExpression().treeSize()) + (
/* 298 */       (this.fieldName == null) ? 0 : getName().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\FieldAccess.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */