/*    */ package org.eclipse.jdt.core.search;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.jdt.core.IJavaElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ResultCollectorAdapter
/*    */   extends SearchRequestor
/*    */ {
/*    */   IJavaSearchResultCollector resultCollector;
/*    */   
/*    */   ResultCollectorAdapter(IJavaSearchResultCollector resultCollector) {
/* 61 */     this.resultCollector = resultCollector;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void acceptSearchMatch(SearchMatch match) throws CoreException {
/* 68 */     this.resultCollector.accept(
/* 69 */         match.getResource(), 
/* 70 */         match.getOffset(), 
/* 71 */         match.getOffset() + match.getLength(), 
/* 72 */         (IJavaElement)match.getElement(), 
/* 73 */         match.getAccuracy());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void beginReporting() {
/* 81 */     this.resultCollector.aboutToStart();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void endReporting() {
/* 88 */     this.resultCollector.done();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\search\SearchEngine$ResultCollectorAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */