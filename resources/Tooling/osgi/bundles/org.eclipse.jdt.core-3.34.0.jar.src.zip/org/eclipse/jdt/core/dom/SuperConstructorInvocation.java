/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SuperConstructorInvocation
/*     */   extends Statement
/*     */ {
/*  40 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(SuperConstructorInvocation.class, "expression", Expression.class, false, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   public static final ChildListPropertyDescriptor TYPE_ARGUMENTS_PROPERTY = new ChildListPropertyDescriptor(SuperConstructorInvocation.class, "typeArguments", Type.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final ChildListPropertyDescriptor ARGUMENTS_PROPERTY = new ChildListPropertyDescriptor(SuperConstructorInvocation.class, "arguments", Expression.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  73 */     List propertyList = new ArrayList(3);
/*  74 */     createPropertyList(SuperConstructorInvocation.class, propertyList);
/*  75 */     addProperty(EXPRESSION_PROPERTY, propertyList);
/*  76 */     addProperty(ARGUMENTS_PROPERTY, propertyList);
/*  77 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(propertyList);
/*     */     
/*  79 */     propertyList = new ArrayList(4);
/*  80 */     createPropertyList(SuperConstructorInvocation.class, propertyList);
/*  81 */     addProperty(EXPRESSION_PROPERTY, propertyList);
/*  82 */     addProperty(TYPE_ARGUMENTS_PROPERTY, propertyList);
/*  83 */     addProperty(ARGUMENTS_PROPERTY, propertyList);
/*  84 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  99 */     if (apiLevel == 2) {
/* 100 */       return PROPERTY_DESCRIPTORS_2_0;
/*     */     }
/* 102 */     return PROPERTY_DESCRIPTORS_3_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private Expression optionalExpression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   private ASTNode.NodeList typeArguments = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   private ASTNode.NodeList arguments = new ASTNode.NodeList(this, ARGUMENTS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SuperConstructorInvocation(AST ast) {
/* 134 */     super(ast);
/* 135 */     if (ast.apiLevel >= 3) {
/* 136 */       this.typeArguments = new ASTNode.NodeList(this, TYPE_ARGUMENTS_PROPERTY);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 142 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 147 */     if (property == EXPRESSION_PROPERTY) {
/* 148 */       if (get) {
/* 149 */         return getExpression();
/*     */       }
/* 151 */       setExpression((Expression)child);
/* 152 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 156 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 161 */     if (property == ARGUMENTS_PROPERTY) {
/* 162 */       return arguments();
/*     */     }
/* 164 */     if (property == TYPE_ARGUMENTS_PROPERTY) {
/* 165 */       return typeArguments();
/*     */     }
/*     */     
/* 168 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 173 */     return 46;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 178 */     SuperConstructorInvocation result = new SuperConstructorInvocation(target);
/* 179 */     result.setSourceRange(getStartPosition(), getLength());
/* 180 */     result.copyLeadingComment(this);
/* 181 */     result.setExpression(
/* 182 */         (Expression)ASTNode.copySubtree(target, getExpression()));
/* 183 */     if (this.ast.apiLevel >= 3) {
/* 184 */       result.typeArguments().addAll(ASTNode.copySubtrees(target, typeArguments()));
/*     */     }
/* 186 */     result.arguments().addAll(ASTNode.copySubtrees(target, arguments()));
/* 187 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 193 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 198 */     boolean visitChildren = visitor.visit(this);
/* 199 */     if (visitChildren) {
/*     */       
/* 201 */       acceptChild(visitor, getExpression());
/* 202 */       if (this.ast.apiLevel >= 3) {
/* 203 */         acceptChildren(visitor, this.typeArguments);
/*     */       }
/* 205 */       acceptChildren(visitor, this.arguments);
/*     */     } 
/* 207 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 217 */     return this.optionalExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 234 */     ASTNode oldChild = this.optionalExpression;
/* 235 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 236 */     this.optionalExpression = expression;
/* 237 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List typeArguments() {
/* 252 */     if (this.typeArguments == null) {
/* 253 */       unsupportedIn2();
/*     */     }
/* 255 */     return this.typeArguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List arguments() {
/* 266 */     return this.arguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMethodBinding resolveConstructorBinding() {
/* 281 */     return this.ast.getBindingResolver().resolveConstructor(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 287 */     return 52;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 292 */     return memSize() + (
/* 293 */       (this.optionalExpression == null) ? 0 : getExpression().treeSize()) + (
/* 294 */       (this.typeArguments == null) ? 0 : this.typeArguments.listSize()) + (
/* 295 */       (this.arguments == null) ? 0 : this.arguments.listSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\SuperConstructorInvocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */