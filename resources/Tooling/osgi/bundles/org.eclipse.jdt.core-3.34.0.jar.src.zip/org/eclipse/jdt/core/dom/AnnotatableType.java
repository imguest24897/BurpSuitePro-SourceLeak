/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AnnotatableType
/*     */   extends Type
/*     */ {
/*  41 */   ASTNode.NodeList annotations = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final ChildListPropertyDescriptor internalAnnotationsPropertyFactory(Class nodeClass) {
/*  50 */     return new ChildListPropertyDescriptor(nodeClass, "annotations", Annotation.class, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract ChildListPropertyDescriptor internalAnnotationsProperty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ChildListPropertyDescriptor getAnnotationsProperty() {
/*  68 */     return internalAnnotationsProperty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotatableType(AST ast) {
/*  80 */     super(ast);
/*  81 */     if (ast.apiLevel >= 8) {
/*  82 */       this.annotations = new ASTNode.NodeList(this, getAnnotationsProperty());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List annotations() {
/* 101 */     if (this.annotations == null) {
/* 102 */       unsupportedIn2_3_4();
/*     */     }
/* 104 */     return this.annotations;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\AnnotatableType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */