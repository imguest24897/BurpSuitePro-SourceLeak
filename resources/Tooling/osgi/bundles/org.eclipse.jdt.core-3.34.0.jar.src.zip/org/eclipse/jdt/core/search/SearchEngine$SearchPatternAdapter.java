/*    */ package org.eclipse.jdt.core.search;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SearchPatternAdapter
/*    */   implements ISearchPattern
/*    */ {
/*    */   SearchPattern pattern;
/*    */   
/*    */   SearchPatternAdapter(SearchPattern pattern) {
/* 50 */     this.pattern = pattern;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\search\SearchEngine$SearchPatternAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */