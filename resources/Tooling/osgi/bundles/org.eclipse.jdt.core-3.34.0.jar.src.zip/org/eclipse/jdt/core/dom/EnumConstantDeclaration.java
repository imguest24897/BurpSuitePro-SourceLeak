/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnumConstantDeclaration
/*     */   extends BodyDeclaration
/*     */ {
/*  52 */   public static final ChildPropertyDescriptor JAVADOC_PROPERTY = internalJavadocPropertyFactory(EnumConstantDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   public static final ChildListPropertyDescriptor MODIFIERS2_PROPERTY = internalModifiers2PropertyFactory(EnumConstantDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(EnumConstantDeclaration.class, "name", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public static final ChildListPropertyDescriptor ARGUMENTS_PROPERTY = new ChildListPropertyDescriptor(EnumConstantDeclaration.class, "arguments", Expression.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public static final ChildPropertyDescriptor ANONYMOUS_CLASS_DECLARATION_PROPERTY = new ChildPropertyDescriptor(EnumConstantDeclaration.class, "anonymousClassDeclaration", AnonymousClassDeclaration.class, false, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  86 */     List properyList = new ArrayList(6);
/*  87 */     createPropertyList(EnumConstantDeclaration.class, properyList);
/*  88 */     addProperty(JAVADOC_PROPERTY, properyList);
/*  89 */     addProperty(MODIFIERS2_PROPERTY, properyList);
/*  90 */     addProperty(NAME_PROPERTY, properyList);
/*  91 */     addProperty(ARGUMENTS_PROPERTY, properyList);
/*  92 */     addProperty(ANONYMOUS_CLASS_DECLARATION_PROPERTY, properyList);
/*  93 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 107 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   private SimpleName constantName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   private ASTNode.NodeList arguments = new ASTNode.NodeList(this, ARGUMENTS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   private AnonymousClassDeclaration optionalAnonymousClassDeclaration = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   EnumConstantDeclaration(AST ast) {
/* 143 */     super(ast);
/* 144 */     unsupportedIn2();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 149 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 154 */     if (property == JAVADOC_PROPERTY) {
/* 155 */       if (get) {
/* 156 */         return getJavadoc();
/*     */       }
/* 158 */       setJavadoc((Javadoc)child);
/* 159 */       return null;
/*     */     } 
/*     */     
/* 162 */     if (property == NAME_PROPERTY) {
/* 163 */       if (get) {
/* 164 */         return getName();
/*     */       }
/* 166 */       setName((SimpleName)child);
/* 167 */       return null;
/*     */     } 
/*     */     
/* 170 */     if (property == ANONYMOUS_CLASS_DECLARATION_PROPERTY) {
/* 171 */       if (get) {
/* 172 */         return getAnonymousClassDeclaration();
/*     */       }
/* 174 */       setAnonymousClassDeclaration((AnonymousClassDeclaration)child);
/* 175 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 179 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 184 */     if (property == MODIFIERS2_PROPERTY) {
/* 185 */       return modifiers();
/*     */     }
/* 187 */     if (property == ARGUMENTS_PROPERTY) {
/* 188 */       return arguments();
/*     */     }
/*     */     
/* 191 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalJavadocProperty() {
/* 196 */     return JAVADOC_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalModifiers2Property() {
/* 201 */     return MODIFIERS2_PROPERTY;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final SimplePropertyDescriptor internalModifiersProperty() {
/* 207 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 212 */     return 72;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 217 */     EnumConstantDeclaration result = new EnumConstantDeclaration(target);
/* 218 */     result.setSourceRange(getStartPosition(), getLength());
/* 219 */     result.setJavadoc(
/* 220 */         (Javadoc)ASTNode.copySubtree(target, getJavadoc()));
/* 221 */     result.modifiers().addAll(ASTNode.copySubtrees(target, modifiers()));
/* 222 */     result.setName((SimpleName)getName().clone(target));
/* 223 */     result.arguments().addAll(ASTNode.copySubtrees(target, arguments()));
/* 224 */     result.setAnonymousClassDeclaration(
/* 225 */         (AnonymousClassDeclaration)ASTNode.copySubtree(target, getAnonymousClassDeclaration()));
/* 226 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 232 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 237 */     boolean visitChildren = visitor.visit(this);
/* 238 */     if (visitChildren) {
/*     */       
/* 240 */       acceptChild(visitor, getJavadoc());
/* 241 */       acceptChildren(visitor, this.modifiers);
/* 242 */       acceptChild(visitor, getName());
/* 243 */       acceptChildren(visitor, this.arguments);
/* 244 */       acceptChild(visitor, getAnonymousClassDeclaration());
/*     */     } 
/* 246 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 255 */     if (this.constantName == null)
/*     */     {
/* 257 */       synchronized (this) {
/* 258 */         if (this.constantName == null) {
/* 259 */           preLazyInit();
/* 260 */           this.constantName = new SimpleName(this.ast);
/* 261 */           postLazyInit(this.constantName, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 265 */     return this.constantName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName constantName) {
/* 280 */     if (constantName == null) {
/* 281 */       throw new IllegalArgumentException();
/*     */     }
/* 283 */     ASTNode oldChild = this.constantName;
/* 284 */     preReplaceChild(oldChild, constantName, NAME_PROPERTY);
/* 285 */     this.constantName = constantName;
/* 286 */     postReplaceChild(oldChild, constantName, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List arguments() {
/* 298 */     return this.arguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnonymousClassDeclaration getAnonymousClassDeclaration() {
/* 308 */     return this.optionalAnonymousClassDeclaration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAnonymousClassDeclaration(AnonymousClassDeclaration decl) {
/* 319 */     ASTNode oldChild = this.optionalAnonymousClassDeclaration;
/* 320 */     preReplaceChild(oldChild, decl, ANONYMOUS_CLASS_DECLARATION_PROPERTY);
/* 321 */     this.optionalAnonymousClassDeclaration = decl;
/* 322 */     postReplaceChild(oldChild, decl, ANONYMOUS_CLASS_DECLARATION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMethodBinding resolveConstructorBinding() {
/* 337 */     return this.ast.getBindingResolver().resolveConstructor(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IVariableBinding resolveVariable() {
/* 351 */     return this.ast.getBindingResolver().resolveVariable(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 356 */     return super.memSize() + 12;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 361 */     return 
/* 362 */       memSize() + (
/* 363 */       (this.optionalDocComment == null) ? 0 : getJavadoc().treeSize()) + 
/* 364 */       this.modifiers.listSize() + (
/* 365 */       (this.constantName == null) ? 0 : getName().treeSize()) + 
/* 366 */       this.arguments.listSize() + (
/* 367 */       (this.optionalAnonymousClassDeclaration == null) ? 0 : getAnonymousClassDeclaration().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\EnumConstantDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */