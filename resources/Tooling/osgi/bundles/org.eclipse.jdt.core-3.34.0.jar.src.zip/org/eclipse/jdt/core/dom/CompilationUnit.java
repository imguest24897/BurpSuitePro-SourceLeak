/*      */ package org.eclipse.jdt.core.dom;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.eclipse.jdt.core.IJavaElement;
/*      */ import org.eclipse.jdt.core.ITypeRoot;
/*      */ import org.eclipse.jdt.core.compiler.IProblem;
/*      */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*      */ import org.eclipse.jdt.internal.compiler.util.Util;
/*      */ import org.eclipse.jface.text.IDocument;
/*      */ import org.eclipse.text.edits.TextEdit;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CompilationUnit
/*      */   extends ASTNode
/*      */ {
/*   64 */   private static final Message[] EMPTY_MESSAGES = new Message[0];
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   69 */   private static final IProblem[] EMPTY_PROBLEMS = new IProblem[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   77 */   public static final ChildListPropertyDescriptor IMPORTS_PROPERTY = new ChildListPropertyDescriptor(CompilationUnit.class, "imports", ImportDeclaration.class, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   85 */   public static final ChildPropertyDescriptor PACKAGE_PROPERTY = new ChildPropertyDescriptor(CompilationUnit.class, "package", PackageDeclaration.class, false, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   93 */   public static final ChildPropertyDescriptor MODULE_PROPERTY = new ChildPropertyDescriptor(CompilationUnit.class, "module", ModuleDeclaration.class, false, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final List PROPERTY_DESCRIPTORS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final List PROPERTY_DESCRIPTORS_9_0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  117 */   public static final ChildListPropertyDescriptor TYPES_PROPERTY = new ChildListPropertyDescriptor(CompilationUnit.class, "types", AbstractTypeDeclaration.class, true);
/*      */   
/*      */   static {
/*  120 */     List properyList = new ArrayList(4);
/*  121 */     createPropertyList(CompilationUnit.class, properyList);
/*  122 */     addProperty(PACKAGE_PROPERTY, properyList);
/*  123 */     addProperty(IMPORTS_PROPERTY, properyList);
/*  124 */     addProperty(TYPES_PROPERTY, properyList);
/*  125 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*      */     
/*  127 */     properyList = new ArrayList(5);
/*  128 */     createPropertyList(CompilationUnit.class, properyList);
/*  129 */     addProperty(PACKAGE_PROPERTY, properyList);
/*  130 */     addProperty(IMPORTS_PROPERTY, properyList);
/*  131 */     addProperty(TYPES_PROPERTY, properyList);
/*  132 */     addProperty(MODULE_PROPERTY, properyList);
/*  133 */     PROPERTY_DESCRIPTORS_9_0 = reapPropertyList(properyList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List propertyDescriptors(int apiLevel) {
/*  148 */     if (apiLevel < 9) {
/*  149 */       return PROPERTY_DESCRIPTORS;
/*      */     }
/*  151 */     return PROPERTY_DESCRIPTORS_9_0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  159 */   private DefaultCommentMapper commentMapper = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  165 */   private ITypeRoot typeRoot = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  172 */   private ASTNode.NodeList imports = new ASTNode.NodeList(this, IMPORTS_PROPERTY);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  182 */   private int[] lineEndTable = Util.EMPTY_INT_ARRAY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Message[] messages;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  194 */   private List optionalCommentList = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  202 */   Comment[] optionalCommentTable = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  208 */   private PackageDeclaration optionalPackageDeclaration = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  214 */   private ModuleDeclaration module = null;
/*      */ 
/*      */ 
/*      */   
/*  218 */   private IProblem[] problems = EMPTY_PROBLEMS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object statementsRecoveryData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  230 */   private ASTNode.NodeList types = new ASTNode.NodeList(this, TYPES_PROPERTY);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   CompilationUnit(AST ast) {
/*  245 */     super(ast);
/*      */   }
/*      */ 
/*      */   
/*      */   void accept0(ASTVisitor visitor) {
/*  250 */     boolean visitChildren = visitor.visit(this);
/*  251 */     if (visitChildren) {
/*      */       
/*  253 */       if (this.ast.apiLevel >= 9) {
/*  254 */         acceptChild(visitor, getModule());
/*      */       }
/*  256 */       acceptChild(visitor, getPackage());
/*  257 */       acceptChildren(visitor, this.imports);
/*  258 */       acceptChildren(visitor, this.types);
/*      */     } 
/*  260 */     visitor.endVisit(this);
/*      */   }
/*      */ 
/*      */   
/*      */   ASTNode clone0(AST target) {
/*  265 */     CompilationUnit result = new CompilationUnit(target);
/*      */     
/*  267 */     result.setSourceRange(getStartPosition(), getLength());
/*  268 */     if (this.ast.apiLevel >= 9) {
/*  269 */       result.setModule((ModuleDeclaration)ASTNode.copySubtree(target, getModule()));
/*      */     }
/*  271 */     result.setPackage(
/*  272 */         (PackageDeclaration)ASTNode.copySubtree(target, getPackage()));
/*  273 */     result.imports().addAll(ASTNode.copySubtrees(target, imports()));
/*  274 */     result.types().addAll(ASTNode.copySubtrees(target, types()));
/*  275 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getColumnNumber(int position) {
/*  295 */     if (this.lineEndTable == null) return -2; 
/*  296 */     int line = getLineNumber(position);
/*  297 */     if (line == -1) {
/*  298 */       return -1;
/*      */     }
/*  300 */     if (line == 1) {
/*  301 */       if (position >= getStartPosition() + getLength()) return -1; 
/*  302 */       return position;
/*      */     } 
/*      */     
/*  305 */     int length = this.lineEndTable.length;
/*      */ 
/*      */     
/*  308 */     int previousLineOffset = this.lineEndTable[line - 2];
/*      */     
/*  310 */     int offsetForLine = previousLineOffset + 1;
/*  311 */     int currentLineEnd = (line == length + 1) ? (getStartPosition() + getLength() - 1) : this.lineEndTable[line - 1];
/*  312 */     if (offsetForLine > currentLineEnd) {
/*  313 */       return -1;
/*      */     }
/*  315 */     return position - offsetForLine;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ASTNode findDeclaringNode(IBinding binding) {
/*  373 */     return this.ast.getBindingResolver().findDeclaringNode(binding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ASTNode findDeclaringNode(String key) {
/*  421 */     return this.ast.getBindingResolver().findDeclaringNode(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List getCommentList() {
/*  473 */     return this.optionalCommentList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   DefaultCommentMapper getCommentMapper() {
/*  483 */     return this.commentMapper;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getExtendedLength(ASTNode node) {
/*  499 */     if (node == null) {
/*  500 */       throw new IllegalArgumentException();
/*      */     }
/*  502 */     if (this.commentMapper == null || node.getAST() != getAST())
/*      */     {
/*  504 */       return node.getLength();
/*      */     }
/*  506 */     return this.commentMapper.getExtendedLength(node);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getExtendedStartPosition(ASTNode node) {
/*  523 */     if (node == null) {
/*  524 */       throw new IllegalArgumentException();
/*      */     }
/*  526 */     if (this.commentMapper == null || node.getAST() != getAST())
/*      */     {
/*  528 */       return node.getStartPosition();
/*      */     }
/*  530 */     return this.commentMapper.getExtendedStartPosition(node);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IJavaElement getJavaElement() {
/*  543 */     return (IJavaElement)this.typeRoot;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Message[] getMessages() {
/*  562 */     if (this.messages == null) {
/*  563 */       int problemLength = this.problems.length;
/*  564 */       if (problemLength == 0) {
/*  565 */         this.messages = EMPTY_MESSAGES;
/*      */       } else {
/*  567 */         this.messages = new Message[problemLength];
/*  568 */         for (int i = 0; i < problemLength; i++) {
/*  569 */           IProblem problem = this.problems[i];
/*  570 */           int start = problem.getSourceStart();
/*  571 */           int end = problem.getSourceEnd();
/*  572 */           this.messages[i] = new Message(problem.getMessage(), start, end - start + 1);
/*      */         } 
/*      */       } 
/*      */     } 
/*  576 */     return this.messages;
/*      */   }
/*      */ 
/*      */   
/*      */   final int getNodeType0() {
/*  581 */     return 15;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ModuleDeclaration getModule() {
/*  593 */     unsupportedBelow9();
/*  594 */     return this.module;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PackageDeclaration getPackage() {
/*  605 */     return this.optionalPackageDeclaration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPosition(int line, int column) {
/*  627 */     if (this.lineEndTable == null) return -2; 
/*  628 */     if (line < 1 || column < 0) return -1; 
/*      */     int length;
/*  630 */     if ((length = this.lineEndTable.length) == 0) {
/*  631 */       if (line != 1) return -1; 
/*  632 */       return (column >= getStartPosition() + getLength()) ? -1 : column;
/*      */     } 
/*  634 */     if (line == 1) {
/*  635 */       int endOfLine = this.lineEndTable[0];
/*  636 */       return (column > endOfLine) ? -1 : column;
/*  637 */     }  if (line > length + 1)
/*      */     {
/*  639 */       return -1;
/*      */     }
/*      */ 
/*      */     
/*  643 */     int previousLineOffset = this.lineEndTable[line - 2];
/*      */     
/*  645 */     int offsetForLine = previousLineOffset + 1;
/*  646 */     int currentLineEnd = (line == length + 1) ? (getStartPosition() + getLength() - 1) : this.lineEndTable[line - 1];
/*  647 */     if (offsetForLine + column > currentLineEnd) {
/*  648 */       return -1;
/*      */     }
/*  650 */     return offsetForLine + column;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IProblem[] getProblems() {
/*  670 */     return this.problems;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getStatementsRecoveryData() {
/*  684 */     return this.statementsRecoveryData;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ITypeRoot getTypeRoot() {
/*  695 */     return this.typeRoot;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List imports() {
/*  706 */     return this.imports;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int firstLeadingCommentIndex(ASTNode node) {
/*  719 */     if (node == null) {
/*  720 */       throw new IllegalArgumentException();
/*      */     }
/*  722 */     if (this.commentMapper == null || node.getAST() != getAST()) {
/*  723 */       return -1;
/*      */     }
/*  725 */     return this.commentMapper.firstLeadingCommentIndex(node);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int lastTrailingCommentIndex(ASTNode node) {
/*  738 */     if (node == null) {
/*  739 */       throw new IllegalArgumentException();
/*      */     }
/*  741 */     if (this.commentMapper == null || node.getAST() != getAST()) {
/*  742 */       return -1;
/*      */     }
/*  744 */     return this.commentMapper.lastTrailingCommentIndex(node);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initCommentMapper(Scanner scanner) {
/*  755 */     this.commentMapper = new DefaultCommentMapper(this.optionalCommentTable);
/*  756 */     this.commentMapper.initialize(this, scanner);
/*      */   }
/*      */ 
/*      */   
/*      */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/*  761 */     if (property == IMPORTS_PROPERTY) {
/*  762 */       return imports();
/*      */     }
/*  764 */     if (property == TYPES_PROPERTY) {
/*  765 */       return types();
/*      */     }
/*      */     
/*  768 */     return super.internalGetChildListProperty(property);
/*      */   }
/*      */ 
/*      */   
/*      */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/*  773 */     if (property == MODULE_PROPERTY) {
/*  774 */       if (get) {
/*  775 */         return getModule();
/*      */       }
/*  777 */       setModule((ModuleDeclaration)child);
/*  778 */       return null;
/*      */     } 
/*      */     
/*  781 */     if (property == PACKAGE_PROPERTY) {
/*  782 */       if (get) {
/*  783 */         return getPackage();
/*      */       }
/*  785 */       setPackage((PackageDeclaration)child);
/*  786 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  790 */     return super.internalGetSetChildProperty(property, get, child);
/*      */   }
/*      */ 
/*      */   
/*      */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  795 */     return propertyDescriptors(apiLevel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int lineNumber(int position) {
/*  821 */     int lineNumber = getLineNumber(position);
/*  822 */     return (lineNumber < 1) ? 1 : lineNumber;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLineNumber(int position) {
/*  847 */     if (this.lineEndTable == null) return -2; 
/*      */     int length;
/*  849 */     if ((length = this.lineEndTable.length) == 0) {
/*  850 */       if (position >= getStartPosition() + getLength()) {
/*  851 */         return -1;
/*      */       }
/*  853 */       return 1;
/*      */     } 
/*  855 */     int low = 0;
/*  856 */     if (position < 0)
/*      */     {
/*  858 */       return -1;
/*      */     }
/*  860 */     if (position <= this.lineEndTable[low])
/*      */     {
/*  862 */       return 1;
/*      */     }
/*      */     
/*  865 */     int hi = length - 1;
/*  866 */     if (position > this.lineEndTable[hi]) {
/*      */       
/*  868 */       if (position >= getStartPosition() + getLength())
/*      */       {
/*  870 */         return -1;
/*      */       }
/*  872 */       return length + 1;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  883 */       if (low + 1 == hi)
/*      */       {
/*      */         
/*  886 */         return low + 2;
/*      */       }
/*      */       
/*  889 */       int mid = low + (hi - low) / 2;
/*      */       
/*  891 */       if (position <= this.lineEndTable[mid]) {
/*      */ 
/*      */         
/*  894 */         hi = mid;
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  899 */       low = mid;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int memSize() {
/*  907 */     int size = 72;
/*  908 */     if (this.lineEndTable != null) {
/*  909 */       size += 12 + 4 * this.lineEndTable.length;
/*      */     }
/*  911 */     if (this.optionalCommentTable != null) {
/*  912 */       size += 12 + 4 * this.optionalCommentTable.length;
/*      */     }
/*      */     
/*  915 */     return size;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void recordModifications() {
/*  946 */     getAST().recordModifications(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TextEdit rewrite(IDocument document, Map options) {
/*  986 */     return getAST().rewrite(document, options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setCommentTable(Comment[] commentTable) {
/* 1005 */     if (commentTable == null) {
/* 1006 */       this.optionalCommentList = null;
/* 1007 */       this.optionalCommentTable = null;
/*      */     } else {
/* 1009 */       int nextAvailablePosition = 0;
/* 1010 */       for (int i = 0; i < commentTable.length; i++) {
/* 1011 */         Comment comment = commentTable[i];
/* 1012 */         if (comment == null) {
/* 1013 */           throw new IllegalArgumentException();
/*      */         }
/* 1015 */         int start = comment.getStartPosition();
/* 1016 */         int length = comment.getLength();
/* 1017 */         if (start < 0 || length < 0 || start < nextAvailablePosition) {
/* 1018 */           throw new IllegalArgumentException();
/*      */         }
/* 1020 */         nextAvailablePosition = comment.getStartPosition() + comment.getLength();
/*      */       } 
/* 1022 */       this.optionalCommentTable = commentTable;
/* 1023 */       List<Comment> commentList = Arrays.asList(commentTable);
/*      */       
/* 1025 */       this.optionalCommentList = Collections.unmodifiableList(commentList);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setTypeRoot(ITypeRoot typeRoot) {
/* 1036 */     this.typeRoot = typeRoot;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setLineEndTable(int[] lineEndTable) {
/* 1050 */     if (lineEndTable == null) {
/* 1051 */       throw new NullPointerException();
/*      */     }
/*      */ 
/*      */     
/* 1055 */     checkModifiable();
/* 1056 */     this.lineEndTable = lineEndTable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setModule(ModuleDeclaration module) {
/* 1074 */     unsupportedBelow9();
/* 1075 */     ASTNode oldChild = this.module;
/* 1076 */     preReplaceChild(oldChild, module, MODULE_PROPERTY);
/* 1077 */     this.module = module;
/* 1078 */     postReplaceChild(oldChild, module, MODULE_PROPERTY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPackage(PackageDeclaration pkgDecl) {
/* 1095 */     ASTNode oldChild = this.optionalPackageDeclaration;
/* 1096 */     preReplaceChild(oldChild, pkgDecl, PACKAGE_PROPERTY);
/* 1097 */     this.optionalPackageDeclaration = pkgDecl;
/* 1098 */     postReplaceChild(oldChild, pkgDecl, PACKAGE_PROPERTY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setProblems(IProblem[] problems) {
/* 1109 */     if (problems == null) {
/* 1110 */       throw new IllegalArgumentException();
/*      */     }
/* 1112 */     this.problems = problems;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setStatementsRecoveryData(Object data) {
/* 1124 */     this.statementsRecoveryData = data;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 1130 */     return matcher.match(this, other);
/*      */   }
/*      */ 
/*      */   
/*      */   int treeSize() {
/* 1135 */     int size = memSize();
/* 1136 */     if (this.module != null) {
/* 1137 */       size += getModule().treeSize();
/*      */     }
/* 1139 */     if (this.optionalPackageDeclaration != null) {
/* 1140 */       size += getPackage().treeSize();
/*      */     }
/* 1142 */     size += this.imports.listSize();
/* 1143 */     size += this.types.listSize();
/*      */     
/* 1145 */     if (this.optionalCommentList != null) {
/* 1146 */       for (int i = 0; i < this.optionalCommentList.size(); i++) {
/* 1147 */         Comment comment = this.optionalCommentList.get(i);
/* 1148 */         if (comment != null && comment.getParent() == null) {
/* 1149 */           size += comment.treeSize();
/*      */         }
/*      */       } 
/*      */     }
/* 1153 */     return size;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List types() {
/* 1169 */     return this.types;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\CompilationUnit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */