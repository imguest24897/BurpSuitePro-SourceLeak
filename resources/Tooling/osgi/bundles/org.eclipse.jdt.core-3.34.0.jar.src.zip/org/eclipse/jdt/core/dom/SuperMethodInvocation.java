/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SuperMethodInvocation
/*     */   extends Expression
/*     */ {
/*  40 */   public static final ChildPropertyDescriptor QUALIFIER_PROPERTY = new ChildPropertyDescriptor(SuperMethodInvocation.class, "qualifier", Name.class, false, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   public static final ChildListPropertyDescriptor TYPE_ARGUMENTS_PROPERTY = new ChildListPropertyDescriptor(SuperMethodInvocation.class, "typeArguments", Type.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(SuperMethodInvocation.class, "name", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   public static final ChildListPropertyDescriptor ARGUMENTS_PROPERTY = new ChildListPropertyDescriptor(SuperMethodInvocation.class, "arguments", Expression.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  80 */     List propertyList = new ArrayList(4);
/*  81 */     createPropertyList(SuperMethodInvocation.class, propertyList);
/*  82 */     addProperty(QUALIFIER_PROPERTY, propertyList);
/*  83 */     addProperty(NAME_PROPERTY, propertyList);
/*  84 */     addProperty(ARGUMENTS_PROPERTY, propertyList);
/*  85 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(propertyList);
/*     */     
/*  87 */     propertyList = new ArrayList(5);
/*  88 */     createPropertyList(SuperMethodInvocation.class, propertyList);
/*  89 */     addProperty(QUALIFIER_PROPERTY, propertyList);
/*  90 */     addProperty(TYPE_ARGUMENTS_PROPERTY, propertyList);
/*  91 */     addProperty(NAME_PROPERTY, propertyList);
/*  92 */     addProperty(ARGUMENTS_PROPERTY, propertyList);
/*  93 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 108 */     if (apiLevel == 2) {
/* 109 */       return PROPERTY_DESCRIPTORS_2_0;
/*     */     }
/* 111 */     return PROPERTY_DESCRIPTORS_3_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   private Name optionalQualifier = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   private ASTNode.NodeList typeArguments = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   private SimpleName methodName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   private ASTNode.NodeList arguments = new ASTNode.NodeList(this, ARGUMENTS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SuperMethodInvocation(AST ast) {
/* 149 */     super(ast);
/* 150 */     if (ast.apiLevel >= 3) {
/* 151 */       this.typeArguments = new ASTNode.NodeList(this, TYPE_ARGUMENTS_PROPERTY);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 157 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 162 */     if (property == QUALIFIER_PROPERTY) {
/* 163 */       if (get) {
/* 164 */         return getQualifier();
/*     */       }
/* 166 */       setQualifier((Name)child);
/* 167 */       return null;
/*     */     } 
/*     */     
/* 170 */     if (property == NAME_PROPERTY) {
/* 171 */       if (get) {
/* 172 */         return getName();
/*     */       }
/* 174 */       setName((SimpleName)child);
/* 175 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 179 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 184 */     if (property == ARGUMENTS_PROPERTY) {
/* 185 */       return arguments();
/*     */     }
/* 187 */     if (property == TYPE_ARGUMENTS_PROPERTY) {
/* 188 */       return typeArguments();
/*     */     }
/*     */     
/* 191 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 196 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 201 */     SuperMethodInvocation result = new SuperMethodInvocation(target);
/* 202 */     result.setSourceRange(getStartPosition(), getLength());
/* 203 */     result.setName((SimpleName)getName().clone(target));
/* 204 */     result.setQualifier((Name)ASTNode.copySubtree(target, getQualifier()));
/* 205 */     if (this.ast.apiLevel >= 3) {
/* 206 */       result.typeArguments().addAll(ASTNode.copySubtrees(target, typeArguments()));
/*     */     }
/* 208 */     result.arguments().addAll(ASTNode.copySubtrees(target, arguments()));
/* 209 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 215 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 220 */     boolean visitChildren = visitor.visit(this);
/* 221 */     if (visitChildren) {
/*     */       
/* 223 */       acceptChild(visitor, getQualifier());
/* 224 */       if (this.ast.apiLevel >= 3) {
/* 225 */         acceptChildren(visitor, this.typeArguments);
/*     */       }
/* 227 */       acceptChild(visitor, getName());
/* 228 */       acceptChildren(visitor, this.arguments);
/*     */     } 
/* 230 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getQualifier() {
/* 240 */     return this.optionalQualifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isResolvedTypeInferredFromExpectedType() {
/* 253 */     return this.ast.getBindingResolver().isResolvedTypeInferredFromExpectedType(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQualifier(Name name) {
/* 269 */     ASTNode oldChild = this.optionalQualifier;
/* 270 */     preReplaceChild(oldChild, name, QUALIFIER_PROPERTY);
/* 271 */     this.optionalQualifier = name;
/* 272 */     postReplaceChild(oldChild, name, QUALIFIER_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List typeArguments() {
/* 287 */     if (this.typeArguments == null) {
/* 288 */       unsupportedIn2();
/*     */     }
/* 290 */     return this.typeArguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 299 */     if (this.methodName == null)
/*     */     {
/* 301 */       synchronized (this) {
/* 302 */         if (this.methodName == null) {
/* 303 */           preLazyInit();
/* 304 */           this.methodName = new SimpleName(this.ast);
/* 305 */           postLazyInit(this.methodName, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 309 */     return this.methodName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName name) {
/* 324 */     if (name == null) {
/* 325 */       throw new IllegalArgumentException();
/*     */     }
/* 327 */     ASTNode oldChild = this.methodName;
/* 328 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 329 */     this.methodName = name;
/* 330 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List arguments() {
/* 341 */     return this.arguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMethodBinding resolveMethodBinding() {
/* 357 */     return this.ast.getBindingResolver().resolveMethod(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 363 */     return 56;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 368 */     return 
/* 369 */       memSize() + (
/* 370 */       (this.optionalQualifier == null) ? 0 : getQualifier().treeSize()) + (
/* 371 */       (this.typeArguments == null) ? 0 : this.typeArguments.listSize()) + (
/* 372 */       (this.methodName == null) ? 0 : getName().treeSize()) + (
/* 373 */       (this.arguments == null) ? 0 : this.arguments.listSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\SuperMethodInvocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */