package org.eclipse.jdt.core.compiler;

public interface ITerminalSymbols {
  public static final int TokenNameWHITESPACE = 1000;
  
  public static final int TokenNameCOMMENT_LINE = 1001;
  
  public static final int TokenNameCOMMENT_BLOCK = 1002;
  
  public static final int TokenNameCOMMENT_JAVADOC = 1003;
  
  @Deprecated
  public static final int TokenNameIdentifier = 5;
  
  public static final int TokenNameabstract = 98;
  
  public static final int TokenNameassert = 118;
  
  public static final int TokenNameboolean = 18;
  
  public static final int TokenNamebreak = 119;
  
  public static final int TokenNamebyte = 19;
  
  public static final int TokenNamecase = 211;
  
  public static final int TokenNamecatch = 225;
  
  public static final int TokenNamechar = 20;
  
  public static final int TokenNameclass = 165;
  
  public static final int TokenNamecontinue = 120;
  
  public static final int TokenNamedefault = 212;
  
  public static final int TokenNamedo = 121;
  
  public static final int TokenNamedouble = 21;
  
  public static final int TokenNameelse = 213;
  
  public static final int TokenNameextends = 243;
  
  public static final int TokenNamefalse = 37;
  
  public static final int TokenNamefinal = 99;
  
  public static final int TokenNamefinally = 226;
  
  public static final int TokenNamefloat = 22;
  
  public static final int TokenNamefor = 122;
  
  public static final int TokenNameif = 123;
  
  public static final int TokenNameimplements = 268;
  
  public static final int TokenNameimport = 191;
  
  public static final int TokenNameinstanceof = 65;
  
  public static final int TokenNameint = 23;
  
  public static final int TokenNameinterface = 180;
  
  public static final int TokenNamelong = 24;
  
  public static final int TokenNamenative = 100;
  
  public static final int TokenNamenew = 32;
  
  public static final int TokenNamenull = 38;
  
  public static final int TokenNamepackage = 214;
  
  public static final int TokenNameprivate = 101;
  
  public static final int TokenNameprotected = 102;
  
  public static final int TokenNamepublic = 103;
  
  public static final int TokenNamereturn = 124;
  
  public static final int TokenNameshort = 25;
  
  public static final int TokenNamestatic = 94;
  
  public static final int TokenNamestrictfp = 104;
  
  public static final int TokenNamesuper = 33;
  
  public static final int TokenNameswitch = 125;
  
  public static final int TokenNamesynchronized = 85;
  
  public static final int TokenNamethis = 34;
  
  public static final int TokenNamethrow = 126;
  
  public static final int TokenNamethrows = 227;
  
  public static final int TokenNametransient = 105;
  
  public static final int TokenNametrue = 39;
  
  public static final int TokenNametry = 127;
  
  public static final int TokenNamevoid = 26;
  
  public static final int TokenNamevolatile = 106;
  
  public static final int TokenNamewhile = 117;
  
  public static final int TokenNameIntegerLiteral = 40;
  
  public static final int TokenNameLongLiteral = 41;
  
  public static final int TokenNameFloatingPointLiteral = 42;
  
  public static final int TokenNameDoubleLiteral = 43;
  
  public static final int TokenNameCharacterLiteral = 44;
  
  public static final int TokenNameStringLiteral = 45;
  
  public static final int TokenNameTextBlock = 46;
  
  public static final int TokenNamePLUS_PLUS = 1;
  
  public static final int TokenNameMINUS_MINUS = 2;
  
  public static final int TokenNameEQUAL_EQUAL = 35;
  
  public static final int TokenNameLESS_EQUAL = 66;
  
  public static final int TokenNameGREATER_EQUAL = 67;
  
  public static final int TokenNameNOT_EQUAL = 36;
  
  public static final int TokenNameLEFT_SHIFT = 14;
  
  public static final int TokenNameRIGHT_SHIFT = 11;
  
  public static final int TokenNameUNSIGNED_RIGHT_SHIFT = 12;
  
  public static final int TokenNamePLUS_EQUAL = 168;
  
  public static final int TokenNameMINUS_EQUAL = 169;
  
  public static final int TokenNameMULTIPLY_EQUAL = 170;
  
  public static final int TokenNameDIVIDE_EQUAL = 171;
  
  public static final int TokenNameAND_EQUAL = 172;
  
  public static final int TokenNameOR_EQUAL = 173;
  
  public static final int TokenNameXOR_EQUAL = 174;
  
  public static final int TokenNameREMAINDER_EQUAL = 175;
  
  public static final int TokenNameLEFT_SHIFT_EQUAL = 176;
  
  public static final int TokenNameRIGHT_SHIFT_EQUAL = 177;
  
  public static final int TokenNameUNSIGNED_RIGHT_SHIFT_EQUAL = 178;
  
  public static final int TokenNameOR_OR = 80;
  
  public static final int TokenNameAND_AND = 79;
  
  public static final int TokenNamePLUS = 3;
  
  public static final int TokenNameMINUS = 4;
  
  public static final int TokenNameNOT = 71;
  
  public static final int TokenNameREMAINDER = 9;
  
  public static final int TokenNameXOR = 63;
  
  public static final int TokenNameAND = 62;
  
  public static final int TokenNameMULTIPLY = 8;
  
  public static final int TokenNameOR = 70;
  
  public static final int TokenNameTWIDDLE = 72;
  
  public static final int TokenNameDIVIDE = 10;
  
  public static final int TokenNameGREATER = 68;
  
  public static final int TokenNameLESS = 69;
  
  public static final int TokenNameLPAREN = 7;
  
  public static final int TokenNameRPAREN = 86;
  
  public static final int TokenNameLBRACE = 110;
  
  public static final int TokenNameRBRACE = 95;
  
  public static final int TokenNameLBRACKET = 15;
  
  public static final int TokenNameRBRACKET = 166;
  
  public static final int TokenNameSEMICOLON = 64;
  
  public static final int TokenNameQUESTION = 81;
  
  public static final int TokenNameCOLON = 154;
  
  public static final int TokenNameCOMMA = 90;
  
  public static final int TokenNameDOT = 6;
  
  public static final int TokenNameEQUAL = 167;
  
  public static final int TokenNameEOF = 158;
  
  public static final int TokenNameERROR = 309;
  
  public static final int TokenNameenum = 400;
  
  public static final int TokenNameAT = 401;
  
  public static final int TokenNameELLIPSIS = 402;
  
  public static final int TokenNameconst = 403;
  
  public static final int TokenNamegoto = 404;
  
  public static final int TokenNameARROW = 405;
  
  public static final int TokenNameCOLON_COLON = 406;
  
  public static final int TokenNameNotAToken = 408;
  
  public static final int TokenNameRestrictedIdentifierYield = 409;
  
  public static final int TokenNameRestrictedIdentifierpermits = 410;
  
  public static final int TokenNameRestrictedIdentifierrecord = 411;
  
  public static final int TokenNameRestrictedIdentifiersealed = 412;
  
  public static final int TokenNameSingleQuoteStringLiteral = 413;
  
  public static final int TokenNamenon_sealed = 414;
  
  public static final int TokenNameRestrictedIdentifierWhen = 415;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\compiler\ITerminalSymbols.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */