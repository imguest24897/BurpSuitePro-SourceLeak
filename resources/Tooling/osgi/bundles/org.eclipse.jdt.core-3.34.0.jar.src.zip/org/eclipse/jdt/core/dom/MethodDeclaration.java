/*      */ package org.eclipse.jdt.core.dom;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import org.eclipse.jdt.internal.core.dom.util.DOMASTUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MethodDeclaration
/*      */   extends BodyDeclaration
/*      */ {
/*   74 */   public static final ChildPropertyDescriptor JAVADOC_PROPERTY = internalJavadocPropertyFactory(MethodDeclaration.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   82 */   public static final SimplePropertyDescriptor MODIFIERS_PROPERTY = internalModifiersPropertyFactory(MethodDeclaration.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   89 */   public static final ChildListPropertyDescriptor MODIFIERS2_PROPERTY = internalModifiers2PropertyFactory(MethodDeclaration.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   96 */   public static final SimplePropertyDescriptor CONSTRUCTOR_PROPERTY = new SimplePropertyDescriptor(MethodDeclaration.class, "constructor", boolean.class, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  103 */   public static final SimplePropertyDescriptor COMPACT_CONSTRUCTOR_PROPERTY = new SimplePropertyDescriptor(MethodDeclaration.class, "compactConstructor", boolean.class, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  110 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(MethodDeclaration.class, "name", SimpleName.class, true, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  118 */   public static final ChildPropertyDescriptor RETURN_TYPE_PROPERTY = new ChildPropertyDescriptor(MethodDeclaration.class, "returnType", Type.class, true, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  125 */   public static final ChildPropertyDescriptor RETURN_TYPE2_PROPERTY = new ChildPropertyDescriptor(MethodDeclaration.class, "returnType2", Type.class, false, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  134 */   public static final SimplePropertyDescriptor EXTRA_DIMENSIONS_PROPERTY = new SimplePropertyDescriptor(MethodDeclaration.class, "extraDimensions", int.class, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  141 */   public static final ChildListPropertyDescriptor EXTRA_DIMENSIONS2_PROPERTY = new ChildListPropertyDescriptor(MethodDeclaration.class, "extraDimensions2", Dimension.class, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  148 */   public static final ChildListPropertyDescriptor TYPE_PARAMETERS_PROPERTY = new ChildListPropertyDescriptor(MethodDeclaration.class, "typeParameters", TypeParameter.class, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  155 */   public static final ChildListPropertyDescriptor PARAMETERS_PROPERTY = new ChildListPropertyDescriptor(MethodDeclaration.class, "parameters", SingleVariableDeclaration.class, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  162 */   public static final ChildPropertyDescriptor RECEIVER_TYPE_PROPERTY = new ChildPropertyDescriptor(MethodDeclaration.class, "receiverType", Type.class, false, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  169 */   public static final ChildPropertyDescriptor RECEIVER_QUALIFIER_PROPERTY = new ChildPropertyDescriptor(MethodDeclaration.class, "receiverQualifier", SimpleName.class, false, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  177 */   public static final ChildListPropertyDescriptor THROWN_EXCEPTIONS_PROPERTY = new ChildListPropertyDescriptor(MethodDeclaration.class, "thrownExceptions", Name.class, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  184 */   public static final ChildListPropertyDescriptor THROWN_EXCEPTION_TYPES_PROPERTY = new ChildListPropertyDescriptor(MethodDeclaration.class, "thrownExceptionTypes", Type.class, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  191 */   public static final ChildPropertyDescriptor BODY_PROPERTY = new ChildPropertyDescriptor(MethodDeclaration.class, "body", Block.class, false, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final List PROPERTY_DESCRIPTORS_8_0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final List PROPERTY_DESCRIPTORS_9_0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  226 */     List propertyList = new ArrayList(10);
/*  227 */     createPropertyList(MethodDeclaration.class, propertyList);
/*  228 */     addProperty(JAVADOC_PROPERTY, propertyList);
/*  229 */     addProperty(MODIFIERS_PROPERTY, propertyList);
/*  230 */     addProperty(CONSTRUCTOR_PROPERTY, propertyList);
/*  231 */     addProperty(RETURN_TYPE_PROPERTY, propertyList);
/*  232 */     addProperty(NAME_PROPERTY, propertyList);
/*  233 */     addProperty(PARAMETERS_PROPERTY, propertyList);
/*  234 */     addProperty(EXTRA_DIMENSIONS_PROPERTY, propertyList);
/*  235 */     addProperty(THROWN_EXCEPTIONS_PROPERTY, propertyList);
/*  236 */     addProperty(BODY_PROPERTY, propertyList);
/*  237 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(propertyList);
/*      */     
/*  239 */     propertyList = new ArrayList(11);
/*  240 */     createPropertyList(MethodDeclaration.class, propertyList);
/*  241 */     addProperty(JAVADOC_PROPERTY, propertyList);
/*  242 */     addProperty(MODIFIERS2_PROPERTY, propertyList);
/*  243 */     addProperty(CONSTRUCTOR_PROPERTY, propertyList);
/*  244 */     addProperty(TYPE_PARAMETERS_PROPERTY, propertyList);
/*  245 */     addProperty(RETURN_TYPE2_PROPERTY, propertyList);
/*  246 */     addProperty(NAME_PROPERTY, propertyList);
/*  247 */     addProperty(PARAMETERS_PROPERTY, propertyList);
/*  248 */     addProperty(EXTRA_DIMENSIONS_PROPERTY, propertyList);
/*  249 */     addProperty(THROWN_EXCEPTIONS_PROPERTY, propertyList);
/*  250 */     addProperty(BODY_PROPERTY, propertyList);
/*  251 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(propertyList);
/*      */     
/*  253 */     propertyList = new ArrayList(13);
/*  254 */     createPropertyList(MethodDeclaration.class, propertyList);
/*  255 */     addProperty(JAVADOC_PROPERTY, propertyList);
/*  256 */     addProperty(MODIFIERS2_PROPERTY, propertyList);
/*  257 */     addProperty(CONSTRUCTOR_PROPERTY, propertyList);
/*  258 */     addProperty(TYPE_PARAMETERS_PROPERTY, propertyList);
/*  259 */     addProperty(RETURN_TYPE2_PROPERTY, propertyList);
/*  260 */     addProperty(NAME_PROPERTY, propertyList);
/*  261 */     addProperty(RECEIVER_TYPE_PROPERTY, propertyList);
/*  262 */     addProperty(RECEIVER_QUALIFIER_PROPERTY, propertyList);
/*  263 */     addProperty(PARAMETERS_PROPERTY, propertyList);
/*  264 */     addProperty(EXTRA_DIMENSIONS2_PROPERTY, propertyList);
/*  265 */     addProperty(THROWN_EXCEPTION_TYPES_PROPERTY, propertyList);
/*  266 */     addProperty(BODY_PROPERTY, propertyList);
/*  267 */     PROPERTY_DESCRIPTORS_8_0 = reapPropertyList(propertyList);
/*      */     
/*  269 */     propertyList = new ArrayList(14);
/*  270 */     createPropertyList(MethodDeclaration.class, propertyList);
/*  271 */     addProperty(JAVADOC_PROPERTY, propertyList);
/*  272 */     addProperty(MODIFIERS2_PROPERTY, propertyList);
/*  273 */     addProperty(CONSTRUCTOR_PROPERTY, propertyList);
/*  274 */     addProperty(TYPE_PARAMETERS_PROPERTY, propertyList);
/*  275 */     addProperty(RETURN_TYPE2_PROPERTY, propertyList);
/*  276 */     addProperty(NAME_PROPERTY, propertyList);
/*  277 */     addProperty(RECEIVER_TYPE_PROPERTY, propertyList);
/*  278 */     addProperty(RECEIVER_QUALIFIER_PROPERTY, propertyList);
/*  279 */     addProperty(PARAMETERS_PROPERTY, propertyList);
/*  280 */     addProperty(EXTRA_DIMENSIONS2_PROPERTY, propertyList);
/*  281 */     addProperty(THROWN_EXCEPTION_TYPES_PROPERTY, propertyList);
/*  282 */     addProperty(BODY_PROPERTY, propertyList);
/*  283 */     addProperty(COMPACT_CONSTRUCTOR_PROPERTY, propertyList);
/*  284 */     PROPERTY_DESCRIPTORS_9_0 = reapPropertyList(propertyList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List propertyDescriptors(int apiLevel) {
/*  297 */     if (apiLevel == 2)
/*  298 */       return PROPERTY_DESCRIPTORS_2_0; 
/*  299 */     if (apiLevel < 8)
/*  300 */       return PROPERTY_DESCRIPTORS_3_0; 
/*  301 */     if (DOMASTUtil.isRecordDeclarationSupported(apiLevel)) {
/*  302 */       return PROPERTY_DESCRIPTORS_9_0;
/*      */     }
/*  304 */     return PROPERTY_DESCRIPTORS_8_0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isConstructor = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isCompactConstructor = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  325 */   private SimpleName methodName = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  332 */   private Type optionalReceiverType = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  339 */   private SimpleName optionalReceiverQualifier = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  347 */   private ASTNode.NodeList parameters = new ASTNode.NodeList(this, PARAMETERS_PROPERTY);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  355 */   private Type returnType = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean returnType2Initialized = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  369 */   private ASTNode.NodeList typeParameters = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  378 */   private int extraArrayDimensions = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  388 */   private ASTNode.NodeList extraDimensions = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  396 */   private ASTNode.NodeList thrownExceptions = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  405 */   private ASTNode.NodeList thrownExceptionTypes = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  411 */   private Block optionalBody = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MethodDeclaration(AST ast) {
/*  429 */     super(ast);
/*  430 */     if (ast.apiLevel >= 3) {
/*  431 */       this.typeParameters = new ASTNode.NodeList(this, TYPE_PARAMETERS_PROPERTY);
/*      */     }
/*  433 */     if (ast.apiLevel < 8) {
/*  434 */       this.thrownExceptions = new ASTNode.NodeList(this, THROWN_EXCEPTIONS_PROPERTY);
/*      */     } else {
/*  436 */       this.extraDimensions = new ASTNode.NodeList(this, EXTRA_DIMENSIONS2_PROPERTY);
/*  437 */       this.thrownExceptionTypes = new ASTNode.NodeList(this, THROWN_EXCEPTION_TYPES_PROPERTY);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  447 */     return propertyDescriptors(apiLevel);
/*      */   }
/*      */ 
/*      */   
/*      */   final int internalGetSetIntProperty(SimplePropertyDescriptor property, boolean get, int value) {
/*  452 */     if (property == MODIFIERS_PROPERTY) {
/*  453 */       if (get) {
/*  454 */         return getModifiers();
/*      */       }
/*  456 */       internalSetModifiers(value);
/*  457 */       return 0;
/*      */     } 
/*      */     
/*  460 */     if (property == EXTRA_DIMENSIONS_PROPERTY) {
/*  461 */       if (get) {
/*  462 */         return getExtraDimensions();
/*      */       }
/*  464 */       setExtraDimensions(value);
/*  465 */       return 0;
/*      */     } 
/*      */ 
/*      */     
/*  469 */     return super.internalGetSetIntProperty(property, get, value);
/*      */   }
/*      */ 
/*      */   
/*      */   final boolean internalGetSetBooleanProperty(SimplePropertyDescriptor property, boolean get, boolean value) {
/*  474 */     if (property == CONSTRUCTOR_PROPERTY) {
/*  475 */       if (get) {
/*  476 */         return isConstructor();
/*      */       }
/*  478 */       setConstructor(value);
/*  479 */       return false;
/*      */     } 
/*  481 */     if (property == COMPACT_CONSTRUCTOR_PROPERTY) {
/*  482 */       if (get) {
/*  483 */         return isCompactConstructor();
/*      */       }
/*  485 */       setCompactConstructor(value);
/*  486 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  490 */     return super.internalGetSetBooleanProperty(property, get, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/*  497 */     if (property == JAVADOC_PROPERTY) {
/*  498 */       if (get) {
/*  499 */         return getJavadoc();
/*      */       }
/*  501 */       setJavadoc((Javadoc)child);
/*  502 */       return null;
/*      */     } 
/*      */     
/*  505 */     if (property == NAME_PROPERTY) {
/*  506 */       if (get) {
/*  507 */         return getName();
/*      */       }
/*  509 */       setName((SimpleName)child);
/*  510 */       return null;
/*      */     } 
/*      */     
/*  513 */     if (property == RETURN_TYPE_PROPERTY) {
/*  514 */       if (get) {
/*  515 */         return getReturnType();
/*      */       }
/*  517 */       setReturnType((Type)child);
/*  518 */       return null;
/*      */     } 
/*      */     
/*  521 */     if (property == RETURN_TYPE2_PROPERTY) {
/*  522 */       if (get) {
/*  523 */         return getReturnType2();
/*      */       }
/*  525 */       setReturnType2((Type)child);
/*  526 */       return null;
/*      */     } 
/*      */     
/*  529 */     if (property == RECEIVER_TYPE_PROPERTY) {
/*  530 */       if (get) {
/*  531 */         return getReceiverType();
/*      */       }
/*  533 */       setReceiverType((Type)child);
/*  534 */       return null;
/*      */     } 
/*      */     
/*  537 */     if (property == RECEIVER_QUALIFIER_PROPERTY) {
/*  538 */       if (get) {
/*  539 */         return getReceiverQualifier();
/*      */       }
/*  541 */       setReceiverQualifier((SimpleName)child);
/*  542 */       return null;
/*      */     } 
/*      */     
/*  545 */     if (property == BODY_PROPERTY) {
/*  546 */       if (get) {
/*  547 */         return getBody();
/*      */       }
/*  549 */       setBody((Block)child);
/*  550 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  554 */     return super.internalGetSetChildProperty(property, get, child);
/*      */   }
/*      */ 
/*      */   
/*      */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/*  559 */     if (property == MODIFIERS2_PROPERTY) {
/*  560 */       return modifiers();
/*      */     }
/*  562 */     if (property == TYPE_PARAMETERS_PROPERTY) {
/*  563 */       return typeParameters();
/*      */     }
/*  565 */     if (property == PARAMETERS_PROPERTY) {
/*  566 */       return parameters();
/*      */     }
/*  568 */     if (property == THROWN_EXCEPTIONS_PROPERTY) {
/*  569 */       return thrownExceptions();
/*      */     }
/*  571 */     if (property == THROWN_EXCEPTION_TYPES_PROPERTY) {
/*  572 */       return thrownExceptionTypes();
/*      */     }
/*  574 */     if (property == EXTRA_DIMENSIONS2_PROPERTY) {
/*  575 */       return extraDimensions();
/*      */     }
/*      */     
/*  578 */     return super.internalGetChildListProperty(property);
/*      */   }
/*      */ 
/*      */   
/*      */   final ChildPropertyDescriptor internalJavadocProperty() {
/*  583 */     return JAVADOC_PROPERTY;
/*      */   }
/*      */ 
/*      */   
/*      */   final ChildListPropertyDescriptor internalModifiers2Property() {
/*  588 */     return MODIFIERS2_PROPERTY;
/*      */   }
/*      */ 
/*      */   
/*      */   final SimplePropertyDescriptor internalModifiersProperty() {
/*  593 */     return MODIFIERS_PROPERTY;
/*      */   }
/*      */ 
/*      */   
/*      */   final int getNodeType0() {
/*  598 */     return 31;
/*      */   }
/*      */ 
/*      */   
/*      */   ASTNode clone0(AST target) {
/*  603 */     MethodDeclaration result = new MethodDeclaration(target);
/*  604 */     result.setSourceRange(getStartPosition(), getLength());
/*  605 */     result.setJavadoc(
/*  606 */         (Javadoc)ASTNode.copySubtree(target, getJavadoc()));
/*  607 */     if (this.ast.apiLevel == 2) {
/*  608 */       result.internalSetModifiers(getModifiers());
/*  609 */       result.setReturnType(
/*  610 */           (Type)ASTNode.copySubtree(target, getReturnType()));
/*      */     } 
/*  612 */     if (this.ast.apiLevel >= 3) {
/*  613 */       result.modifiers().addAll(ASTNode.copySubtrees(target, modifiers()));
/*  614 */       result.typeParameters().addAll(
/*  615 */           ASTNode.copySubtrees(target, typeParameters()));
/*  616 */       result.setReturnType2(
/*  617 */           (Type)ASTNode.copySubtree(target, getReturnType2()));
/*      */     } 
/*  619 */     result.setConstructor(isConstructor());
/*  620 */     result.setName((SimpleName)getName().clone(target));
/*  621 */     if (this.ast.apiLevel >= 8) {
/*  622 */       result.setReceiverType((Type)ASTNode.copySubtree(target, getReceiverType()));
/*  623 */       result.setReceiverQualifier((SimpleName)ASTNode.copySubtree(target, getReceiverQualifier()));
/*      */     } 
/*  625 */     result.parameters().addAll(
/*  626 */         ASTNode.copySubtrees(target, parameters()));
/*  627 */     if (this.ast.apiLevel >= 8) {
/*  628 */       result.extraDimensions().addAll(ASTNode.copySubtrees(target, extraDimensions()));
/*      */     } else {
/*  630 */       result.setExtraDimensions(getExtraDimensions());
/*      */     } 
/*  632 */     if (this.ast.apiLevel() >= 8) {
/*  633 */       result.thrownExceptionTypes().addAll(ASTNode.copySubtrees(target, thrownExceptionTypes()));
/*      */     } else {
/*  635 */       result.thrownExceptions().addAll(ASTNode.copySubtrees(target, thrownExceptions()));
/*      */     } 
/*  637 */     if (DOMASTUtil.isRecordDeclarationSupported(this.ast)) {
/*  638 */       result.setCompactConstructor(isCompactConstructor());
/*      */     }
/*  640 */     result.setBody(
/*  641 */         (Block)ASTNode.copySubtree(target, getBody()));
/*  642 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/*  648 */     return matcher.match(this, other);
/*      */   }
/*      */ 
/*      */   
/*      */   void accept0(ASTVisitor visitor) {
/*  653 */     boolean visitChildren = visitor.visit(this);
/*  654 */     if (visitChildren) {
/*      */       
/*  656 */       acceptChild(visitor, getJavadoc());
/*  657 */       if (this.ast.apiLevel == 2) {
/*  658 */         acceptChild(visitor, getReturnType());
/*      */       } else {
/*  660 */         acceptChildren(visitor, this.modifiers);
/*  661 */         acceptChildren(visitor, this.typeParameters);
/*  662 */         acceptChild(visitor, getReturnType2());
/*      */       } 
/*      */       
/*  665 */       acceptChild(visitor, getName());
/*  666 */       if (this.ast.apiLevel >= 8) {
/*  667 */         acceptChild(visitor, this.optionalReceiverType);
/*  668 */         acceptChild(visitor, this.optionalReceiverQualifier);
/*      */       } 
/*  670 */       acceptChildren(visitor, this.parameters);
/*  671 */       if (this.ast.apiLevel() >= 8) {
/*  672 */         acceptChildren(visitor, this.extraDimensions);
/*  673 */         acceptChildren(visitor, this.thrownExceptionTypes);
/*      */       } else {
/*  675 */         acceptChildren(visitor, this.thrownExceptions);
/*      */       } 
/*  677 */       acceptChild(visitor, getBody());
/*      */     } 
/*  679 */     visitor.endVisit(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isConstructor() {
/*  689 */     return this.isConstructor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConstructor(boolean isConstructor) {
/*  699 */     preValueChange(CONSTRUCTOR_PROPERTY);
/*  700 */     this.isConstructor = isConstructor;
/*  701 */     postValueChange(CONSTRUCTOR_PROPERTY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCompactConstructor() {
/*  714 */     unsupportedBelow16();
/*  715 */     return this.isCompactConstructor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCompactConstructor(boolean isCompactConstructor) {
/*  728 */     unsupportedBelow16();
/*  729 */     preValueChange(COMPACT_CONSTRUCTOR_PROPERTY);
/*  730 */     this.isCompactConstructor = isCompactConstructor;
/*  731 */     postValueChange(COMPACT_CONSTRUCTOR_PROPERTY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List typeParameters() {
/*  746 */     if (this.typeParameters == null) {
/*  747 */       unsupportedIn2();
/*      */     }
/*  749 */     return this.typeParameters;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SimpleName getName() {
/*  760 */     if (this.methodName == null)
/*      */     {
/*  762 */       synchronized (this) {
/*  763 */         if (this.methodName == null) {
/*  764 */           preLazyInit();
/*  765 */           this.methodName = new SimpleName(this.ast);
/*  766 */           postLazyInit(this.methodName, NAME_PROPERTY);
/*      */         } 
/*      */       } 
/*      */     }
/*  770 */     return this.methodName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setName(SimpleName methodName) {
/*  786 */     if (methodName == null) {
/*  787 */       throw new IllegalArgumentException();
/*      */     }
/*  789 */     ASTNode oldChild = this.methodName;
/*  790 */     preReplaceChild(oldChild, methodName, NAME_PROPERTY);
/*  791 */     this.methodName = methodName;
/*  792 */     postReplaceChild(oldChild, methodName, NAME_PROPERTY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Type getReceiverType() {
/*  807 */     unsupportedIn2_3_4();
/*  808 */     return this.optionalReceiverType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReceiverType(Type receiverType) {
/*  822 */     unsupportedIn2_3_4();
/*  823 */     ASTNode oldChild = this.optionalReceiverType;
/*  824 */     preReplaceChild(oldChild, receiverType, RECEIVER_TYPE_PROPERTY);
/*  825 */     this.optionalReceiverType = receiverType;
/*  826 */     postReplaceChild(oldChild, receiverType, RECEIVER_TYPE_PROPERTY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SimpleName getReceiverQualifier() {
/*  840 */     unsupportedIn2_3_4();
/*  841 */     return this.optionalReceiverQualifier;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReceiverQualifier(SimpleName receiverQualifier) {
/*  852 */     unsupportedIn2_3_4();
/*  853 */     ASTNode oldChild = this.optionalReceiverQualifier;
/*  854 */     preReplaceChild(oldChild, receiverQualifier, RECEIVER_QUALIFIER_PROPERTY);
/*  855 */     this.optionalReceiverQualifier = receiverQualifier;
/*  856 */     postReplaceChild(oldChild, receiverQualifier, RECEIVER_QUALIFIER_PROPERTY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List parameters() {
/*  867 */     return this.parameters;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isVarargs() {
/*  884 */     if (this.modifiers == null) {
/*  885 */       unsupportedIn2();
/*      */     }
/*  887 */     if (parameters().isEmpty()) {
/*  888 */       return false;
/*      */     }
/*  890 */     SingleVariableDeclaration v = parameters().get(parameters().size() - 1);
/*  891 */     return v.isVarargs();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List thrownExceptions() {
/*  906 */     return internalThrownExceptions();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   List internalThrownExceptions() {
/*  918 */     if (this.thrownExceptions == null) {
/*  919 */       supportedOnlyIn2_3_4();
/*      */     }
/*  921 */     return this.thrownExceptions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List thrownExceptionTypes() {
/*  935 */     if (this.thrownExceptionTypes == null) {
/*  936 */       unsupportedIn2_3_4();
/*      */     }
/*  938 */     return this.thrownExceptionTypes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Type getReturnType() {
/*  959 */     return internalGetReturnType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Type internalGetReturnType() {
/*  970 */     supportedOnlyIn2();
/*  971 */     if (this.returnType == null)
/*      */     {
/*  973 */       synchronized (this) {
/*  974 */         if (this.returnType == null) {
/*  975 */           preLazyInit();
/*  976 */           this.returnType = this.ast.newPrimitiveType(PrimitiveType.VOID);
/*  977 */           postLazyInit(this.returnType, RETURN_TYPE_PROPERTY);
/*      */         } 
/*      */       } 
/*      */     }
/*  981 */     return this.returnType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReturnType(Type type) {
/* 1005 */     internalSetReturnType(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void internalSetReturnType(Type type) {
/* 1014 */     supportedOnlyIn2();
/* 1015 */     if (type == null) {
/* 1016 */       throw new IllegalArgumentException();
/*      */     }
/* 1018 */     ASTNode oldChild = this.returnType;
/* 1019 */     preReplaceChild(oldChild, type, RETURN_TYPE_PROPERTY);
/* 1020 */     this.returnType = type;
/* 1021 */     postReplaceChild(oldChild, type, RETURN_TYPE_PROPERTY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Type getReturnType2() {
/* 1043 */     unsupportedIn2();
/* 1044 */     if (this.returnType == null && !this.returnType2Initialized)
/*      */     {
/* 1046 */       synchronized (this) {
/* 1047 */         if (this.returnType == null && !this.returnType2Initialized) {
/* 1048 */           preLazyInit();
/* 1049 */           this.returnType = this.ast.newPrimitiveType(PrimitiveType.VOID);
/* 1050 */           this.returnType2Initialized = true;
/* 1051 */           postLazyInit(this.returnType, RETURN_TYPE2_PROPERTY);
/*      */         } 
/*      */       } 
/*      */     }
/* 1055 */     return this.returnType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReturnType2(Type type) {
/* 1081 */     unsupportedIn2();
/* 1082 */     this.returnType2Initialized = true;
/* 1083 */     ASTNode oldChild = this.returnType;
/* 1084 */     preReplaceChild(oldChild, type, RETURN_TYPE2_PROPERTY);
/* 1085 */     this.returnType = type;
/* 1086 */     postReplaceChild(oldChild, type, RETURN_TYPE2_PROPERTY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getExtraDimensions() {
/* 1110 */     if (this.extraDimensions == null)
/*      */     {
/* 1112 */       return this.extraArrayDimensions;
/*      */     }
/* 1114 */     return this.extraDimensions.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExtraDimensions(int dimensions) {
/* 1141 */     if (this.extraDimensions != null) {
/* 1142 */       supportedOnlyIn2_3_4();
/*      */     }
/* 1144 */     if (dimensions < 0) {
/* 1145 */       throw new IllegalArgumentException();
/*      */     }
/* 1147 */     preValueChange(EXTRA_DIMENSIONS_PROPERTY);
/* 1148 */     this.extraArrayDimensions = dimensions;
/* 1149 */     postValueChange(EXTRA_DIMENSIONS_PROPERTY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List extraDimensions() {
/* 1161 */     if (this.extraDimensions == null) {
/* 1162 */       unsupportedIn2_3_4();
/*      */     }
/* 1164 */     return this.extraDimensions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Block getBody() {
/* 1179 */     return this.optionalBody;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBody(Block body) {
/* 1202 */     ASTNode oldChild = this.optionalBody;
/* 1203 */     preReplaceChild(oldChild, body, BODY_PROPERTY);
/* 1204 */     this.optionalBody = body;
/* 1205 */     postReplaceChild(oldChild, body, BODY_PROPERTY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IMethodBinding resolveBinding() {
/* 1220 */     return this.ast.getBindingResolver().resolveMethod(this);
/*      */   }
/*      */ 
/*      */   
/*      */   int memSize() {
/* 1225 */     return super.memSize() + 52;
/*      */   }
/*      */ 
/*      */   
/*      */   int treeSize() {
/* 1230 */     return 
/* 1231 */       memSize() + (
/* 1232 */       (this.optionalDocComment == null) ? 0 : getJavadoc().treeSize()) + (
/* 1233 */       (this.modifiers == null) ? 0 : this.modifiers.listSize()) + (
/* 1234 */       (this.typeParameters == null) ? 0 : this.typeParameters.listSize()) + (
/* 1235 */       (this.methodName == null) ? 0 : getName().treeSize()) + (
/* 1236 */       (this.optionalReceiverType == null) ? 0 : this.optionalReceiverType.treeSize()) + (
/* 1237 */       (this.optionalReceiverQualifier == null) ? 0 : this.optionalReceiverQualifier.treeSize()) + (
/* 1238 */       (this.returnType == null) ? 0 : this.returnType.treeSize()) + 
/* 1239 */       this.parameters.listSize() + (
/* 1240 */       (this.ast.apiLevel < 8) ? 
/* 1241 */       this.thrownExceptions.listSize() : (
/* 1242 */       this.extraDimensions.listSize() + this.thrownExceptionTypes.listSize())) + (
/* 1243 */       (this.optionalBody == null) ? 0 : getBody().treeSize());
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\MethodDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */