/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Annotation
/*     */   extends Expression
/*     */   implements IExtendedModifier
/*     */ {
/*     */   abstract ChildPropertyDescriptor internalTypeNameProperty();
/*     */   
/*     */   public final ChildPropertyDescriptor getTypeNameProperty() {
/*  44 */     return internalTypeNameProperty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final ChildPropertyDescriptor internalTypeNamePropertyFactory(Class nodeClass) {
/*  54 */     return new ChildPropertyDescriptor(nodeClass, "typeName", Name.class, true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   Name typeName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Annotation(AST ast) {
/*  73 */     super(ast);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isModifier() {
/*  81 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAnnotation() {
/*  89 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getTypeName() {
/*  98 */     if (this.typeName == null)
/*     */     {
/* 100 */       synchronized (this) {
/* 101 */         if (this.typeName == null) {
/* 102 */           preLazyInit();
/* 103 */           this.typeName = new SimpleName(this.ast);
/* 104 */           postLazyInit(this.typeName, internalTypeNameProperty());
/*     */         } 
/*     */       } 
/*     */     }
/* 108 */     return this.typeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTypeName(Name typeName) {
/* 122 */     if (typeName == null) {
/* 123 */       throw new IllegalArgumentException();
/*     */     }
/* 125 */     ChildPropertyDescriptor p = internalTypeNameProperty();
/* 126 */     ASTNode oldChild = this.typeName;
/* 127 */     preReplaceChild(oldChild, typeName, p);
/* 128 */     this.typeName = typeName;
/* 129 */     postReplaceChild(oldChild, typeName, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNormalAnnotation() {
/* 140 */     return this instanceof NormalAnnotation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMarkerAnnotation() {
/* 151 */     return this instanceof MarkerAnnotation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSingleMemberAnnotation() {
/* 162 */     return this instanceof SingleMemberAnnotation;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 167 */     return 44;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IAnnotationBinding resolveAnnotationBinding() {
/* 181 */     return this.ast.getBindingResolver().resolveAnnotation(this);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\Annotation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */