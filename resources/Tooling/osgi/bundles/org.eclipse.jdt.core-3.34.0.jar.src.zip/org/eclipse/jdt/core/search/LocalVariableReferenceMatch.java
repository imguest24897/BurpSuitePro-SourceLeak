/*    */ package org.eclipse.jdt.core.search;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.jdt.core.IJavaElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalVariableReferenceMatch
/*    */   extends SearchMatch
/*    */ {
/*    */   private boolean isReadAccess;
/*    */   private boolean isWriteAccess;
/*    */   
/*    */   public LocalVariableReferenceMatch(IJavaElement enclosingElement, int accuracy, int offset, int length, boolean isReadAccess, boolean isWriteAccess, boolean insideDocComment, SearchParticipant participant, IResource resource) {
/* 48 */     super(enclosingElement, accuracy, offset, length, participant, resource);
/* 49 */     this.isReadAccess = isReadAccess;
/* 50 */     this.isWriteAccess = isWriteAccess;
/* 51 */     setInsideDocComment(insideDocComment);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean isReadAccess() {
/* 61 */     return this.isReadAccess;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final boolean isWriteAccess() {
/* 71 */     return this.isWriteAccess;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\search\LocalVariableReferenceMatch.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */