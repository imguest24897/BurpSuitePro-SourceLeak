/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ModuleModifier
/*     */   extends ASTNode
/*     */ {
/*     */   public static class ModuleModifierKeyword
/*     */   {
/*  46 */     public static final ModuleModifierKeyword STATIC_KEYWORD = new ModuleModifierKeyword("static", 64);
/*     */ 
/*     */     
/*  49 */     public static final ModuleModifierKeyword TRANSITIVE_KEYWORD = new ModuleModifierKeyword("transitive", 128);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  59 */     private static final Map KEYWORDS = new HashMap<>(2); static {
/*  60 */       ModuleModifierKeyword[] ops = {
/*  61 */           STATIC_KEYWORD, 
/*  62 */           TRANSITIVE_KEYWORD
/*     */         };
/*  64 */       for (int i = 0; i < ops.length; i++) {
/*  65 */         KEYWORDS.put(ops[i].toString(), ops[i]);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int flagValue;
/*     */ 
/*     */ 
/*     */     
/*     */     private String keyword;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ModuleModifierKeyword fromFlagValue(int flagValue) {
/*  83 */       for (Iterator<ModuleModifierKeyword> it = KEYWORDS.values().iterator(); it.hasNext(); ) {
/*  84 */         ModuleModifierKeyword k = it.next();
/*  85 */         if (k.toFlagValue() == flagValue) {
/*  86 */           return k;
/*     */         }
/*     */       } 
/*  89 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ModuleModifierKeyword toKeyword(String keyword) {
/* 106 */       return (ModuleModifierKeyword)KEYWORDS.get(keyword);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ModuleModifierKeyword(String keyword, int flagValue) {
/* 130 */       this.keyword = keyword;
/* 131 */       this.flagValue = flagValue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int toFlagValue() {
/* 142 */       return this.flagValue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 153 */       return this.keyword;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public static final SimplePropertyDescriptor KEYWORD_PROPERTY = new SimplePropertyDescriptor(ModuleModifier.class, "keyword", ModuleModifierKeyword.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int NONE = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int STATIC_PHASE = 64;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int TRANSITIVE = 128;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 191 */     List properyList = new ArrayList(2);
/* 192 */     createPropertyList(ModuleModifier.class, properyList);
/* 193 */     addProperty(KEYWORD_PROPERTY, properyList);
/* 194 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isTransitive(int flags) {
/* 205 */     return ((flags & 0x80) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isStatic(int flags) {
/* 216 */     return ((flags & 0x40) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 230 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 236 */   private ModuleModifierKeyword modifierKeyword = ModuleModifierKeyword.STATIC_KEYWORD;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ModuleModifier(AST ast) {
/* 248 */     super(ast);
/* 249 */     unsupportedBelow9();
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 254 */     visitor.visit(this);
/* 255 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 260 */     ModuleModifier result = new ModuleModifier(target);
/* 261 */     result.setSourceRange(getStartPosition(), getLength());
/* 262 */     result.setKeyword(getKeyword());
/* 263 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModuleModifierKeyword getKeyword() {
/* 272 */     return this.modifierKeyword;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeyword(ModuleModifierKeyword modifierKeyord) {
/* 282 */     if (modifierKeyord == null) {
/* 283 */       throw new IllegalArgumentException();
/*     */     }
/* 285 */     preValueChange(KEYWORD_PROPERTY);
/* 286 */     this.modifierKeyword = modifierKeyord;
/* 287 */     postValueChange(KEYWORD_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 292 */     return 99;
/*     */   }
/*     */ 
/*     */   
/*     */   final Object internalGetSetObjectProperty(SimplePropertyDescriptor property, boolean get, Object value) {
/* 297 */     if (property == KEYWORD_PROPERTY) {
/* 298 */       if (get) {
/* 299 */         return getKeyword();
/*     */       }
/* 301 */       setKeyword((ModuleModifierKeyword)value);
/* 302 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 306 */     return super.internalGetSetObjectProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 311 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStatic() {
/* 320 */     return (this.modifierKeyword == ModuleModifierKeyword.STATIC_KEYWORD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTransitive() {
/* 329 */     return (this.modifierKeyword == ModuleModifierKeyword.TRANSITIVE_KEYWORD);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 335 */     return 44;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 341 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 346 */     return memSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ModuleModifier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */