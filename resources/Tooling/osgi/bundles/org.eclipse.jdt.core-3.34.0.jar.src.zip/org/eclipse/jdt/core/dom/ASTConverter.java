/*      */ package org.eclipse.jdt.core.dom;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.TreeSet;
/*      */ import org.eclipse.jdt.core.compiler.CategorizedProblem;
/*      */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*      */ import org.eclipse.jdt.internal.compiler.ast.AND_AND_Expression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*      */ import org.eclipse.jdt.internal.compiler.ast.AbstractMethodDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.AllocationExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Annotation;
/*      */ import org.eclipse.jdt.internal.compiler.ast.AnnotationMethodDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Argument;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ArrayAllocationExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ArrayInitializer;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ArrayReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.BinaryExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Block;
/*      */ import org.eclipse.jdt.internal.compiler.ast.BreakStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.CaseStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.CastExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ClassLiteralAccess;
/*      */ import org.eclipse.jdt.internal.compiler.ast.CompilationUnitDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.CompoundAssignment;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ConditionalExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ContinueStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.DoStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ExplicitConstructorCall;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ExtendedStringLiteral;
/*      */ import org.eclipse.jdt.internal.compiler.ast.FieldDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.FieldReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ForStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ForeachStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.GuardedPattern;
/*      */ import org.eclipse.jdt.internal.compiler.ast.IfStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ImportReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Initializer;
/*      */ import org.eclipse.jdt.internal.compiler.ast.InstanceOfExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Javadoc;
/*      */ import org.eclipse.jdt.internal.compiler.ast.JavadocModuleReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.LabeledStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.LambdaExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.LocalDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.MemberValuePair;
/*      */ import org.eclipse.jdt.internal.compiler.ast.MessageSend;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ModuleDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ModuleReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.NameReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.NormalAnnotation;
/*      */ import org.eclipse.jdt.internal.compiler.ast.OR_OR_Expression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.PackageVisibilityStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ParameterizedQualifiedTypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Pattern;
/*      */ import org.eclipse.jdt.internal.compiler.ast.PostfixExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.PrefixExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.QualifiedAllocationExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.QualifiedThisReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.QualifiedTypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Receiver;
/*      */ import org.eclipse.jdt.internal.compiler.ast.RecordComponent;
/*      */ import org.eclipse.jdt.internal.compiler.ast.RecordPattern;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Reference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ReferenceExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.RequiresStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ReturnStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.SingleMemberAnnotation;
/*      */ import org.eclipse.jdt.internal.compiler.ast.SingleNameReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.SingleTypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Statement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.StringLiteral;
/*      */ import org.eclipse.jdt.internal.compiler.ast.StringLiteralConcatenation;
/*      */ import org.eclipse.jdt.internal.compiler.ast.SwitchExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.SwitchStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.SynchronizedStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TextBlock;
/*      */ import org.eclipse.jdt.internal.compiler.ast.ThisReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TrueLiteral;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TryStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeParameter;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypePattern;
/*      */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*      */ import org.eclipse.jdt.internal.compiler.ast.UnaryExpression;
/*      */ import org.eclipse.jdt.internal.compiler.ast.WhileStatement;
/*      */ import org.eclipse.jdt.internal.compiler.ast.Wildcard;
/*      */ import org.eclipse.jdt.internal.compiler.ast.YieldStatement;
/*      */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*      */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*      */ 
/*      */ class ASTConverter {
/*      */   protected AST ast;
/*      */   private ASTNode referenceContext;
/*      */   protected Comment[] commentsTable;
/*      */   char[] compilationUnitSource;
/*      */   int compilationUnitSourceLength;
/*      */   protected DocCommentParser docParser;
/*      */   
/*      */   public ASTConverter(Map<String, String> options, boolean resolveBindings, IProgressMonitor monitor) {
/*  100 */     this.resolveBindings = resolveBindings;
/*  101 */     this.referenceContext = null;
/*  102 */     String sourceModeSetting = options.get("org.eclipse.jdt.core.compiler.source");
/*  103 */     long sourceLevel = CompilerOptions.versionToJdkLevel(sourceModeSetting);
/*  104 */     if (sourceLevel == 0L)
/*      */     {
/*  106 */       sourceLevel = 3080192L;
/*      */     }
/*  108 */     this.scanner = new Scanner(
/*  109 */         true, 
/*  110 */         false, 
/*  111 */         false, 
/*  112 */         sourceLevel, 
/*  113 */         null, 
/*  114 */         null, 
/*  115 */         true, 
/*  116 */         "enabled".equals(options.get("org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures")));
/*  117 */     this.monitor = monitor;
/*  118 */     this.insideComments = "enabled".equals(options.get("org.eclipse.jdt.core.compiler.doc.comment.support"));
/*      */   }
/*      */   protected boolean insideComments; protected IProgressMonitor monitor; protected Set pendingNameScopeResolution; protected Set pendingThisExpressionScopeResolution; protected boolean resolveBindings; Scanner scanner; private DefaultCommentMapper commentMapper;
/*      */   protected void adjustSourcePositionsForParent(Expression expression) {
/*  122 */     int start = expression.sourceStart;
/*  123 */     int end = expression.sourceEnd;
/*  124 */     int leftParentCount = 1;
/*  125 */     int rightParentCount = 0;
/*  126 */     this.scanner.resetTo(start, end);
/*      */     try {
/*  128 */       int token = this.scanner.getNextToken();
/*  129 */       expression.sourceStart = this.scanner.currentPosition;
/*  130 */       boolean stop = false;
/*  131 */       while (!stop && (token = this.scanner.getNextToken()) != 64) {
/*  132 */         switch (token) {
/*      */           case 23:
/*  134 */             leftParentCount++;
/*      */           
/*      */           case 26:
/*  137 */             rightParentCount++;
/*  138 */             if (rightParentCount == leftParentCount)
/*      */             {
/*  140 */               stop = true;
/*      */             }
/*      */         } 
/*      */       } 
/*  144 */       expression.sourceEnd = this.scanner.startPosition - 1;
/*  145 */     } catch (InvalidInputException invalidInputException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void buildBodyDeclarations(TypeDeclaration typeDeclaration, AbstractTypeDeclaration typeDecl, boolean isInterface) {
/*  155 */     TypeDeclaration[] members = typeDeclaration.memberTypes;
/*  156 */     FieldDeclaration[] fields = typeDeclaration.fields;
/*  157 */     AbstractMethodDeclaration[] methods = typeDeclaration.methods;
/*      */     
/*  159 */     int fieldsLength = (fields == null) ? 0 : fields.length;
/*  160 */     int methodsLength = (methods == null) ? 0 : methods.length;
/*  161 */     int membersLength = (members == null) ? 0 : members.length;
/*  162 */     int fieldsIndex = 0;
/*  163 */     int methodsIndex = 0;
/*  164 */     int membersIndex = 0;
/*      */     
/*  166 */     while (fieldsIndex < fieldsLength || 
/*  167 */       membersIndex < membersLength || 
/*  168 */       methodsIndex < methodsLength) {
/*  169 */       ASTNode node; FieldDeclaration nextFieldDeclaration = null;
/*  170 */       AbstractMethodDeclaration nextMethodDeclaration = null;
/*  171 */       TypeDeclaration nextMemberDeclaration = null;
/*      */       
/*  173 */       int position = Integer.MAX_VALUE;
/*  174 */       int nextDeclarationType = -1;
/*  175 */       if (fieldsIndex < fieldsLength) {
/*  176 */         nextFieldDeclaration = fields[fieldsIndex];
/*  177 */         if (nextFieldDeclaration.declarationSourceStart < position) {
/*  178 */           position = nextFieldDeclaration.declarationSourceStart;
/*  179 */           nextDeclarationType = 0;
/*      */         } 
/*      */       } 
/*  182 */       if (methodsIndex < methodsLength) {
/*  183 */         nextMethodDeclaration = methods[methodsIndex];
/*  184 */         if (nextMethodDeclaration.declarationSourceStart < position) {
/*  185 */           position = nextMethodDeclaration.declarationSourceStart;
/*  186 */           nextDeclarationType = 1;
/*      */         } 
/*      */       } 
/*  189 */       if (membersIndex < membersLength) {
/*  190 */         nextMemberDeclaration = members[membersIndex];
/*  191 */         if (nextMemberDeclaration.declarationSourceStart < position) {
/*  192 */           position = nextMemberDeclaration.declarationSourceStart;
/*  193 */           nextDeclarationType = 2;
/*      */         } 
/*      */       } 
/*  196 */       switch (nextDeclarationType) {
/*      */         case 0:
/*  198 */           if (nextFieldDeclaration.getKind() == 3) {
/*  199 */             typeDecl.bodyDeclarations().add(convert(nextFieldDeclaration));
/*      */           } else {
/*  201 */             checkAndAddMultipleFieldDeclaration(fields, fieldsIndex, typeDecl.bodyDeclarations());
/*      */           } 
/*  203 */           fieldsIndex++;
/*      */         
/*      */         case 1:
/*  206 */           methodsIndex++;
/*  207 */           if (!nextMethodDeclaration.isDefaultConstructor() && !nextMethodDeclaration.isClinit()) {
/*  208 */             typeDecl.bodyDeclarations().add(convert(isInterface, nextMethodDeclaration));
/*      */           }
/*      */         
/*      */         case 2:
/*  212 */           membersIndex++;
/*  213 */           node = convert(nextMemberDeclaration);
/*  214 */           if (node == null) {
/*  215 */             typeDecl.setFlags(typeDecl.getFlags() | 0x1); continue;
/*      */           } 
/*  217 */           typeDecl.bodyDeclarations().add(node);
/*      */       } 
/*      */ 
/*      */     
/*      */     } 
/*  222 */     convert(typeDeclaration.javadoc, typeDecl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void buildBodyDeclarations(TypeDeclaration typeDeclaration, RecordDeclaration recordDeclaration, boolean isInterface) {
/*  230 */     TypeDeclaration[] members = typeDeclaration.memberTypes;
/*  231 */     FieldDeclaration[] fields = typeDeclaration.fields;
/*  232 */     AbstractMethodDeclaration[] methods = typeDeclaration.methods;
/*      */     
/*  234 */     int fieldsLength = (fields == null) ? 0 : fields.length;
/*  235 */     int methodsLength = (methods == null) ? 0 : methods.length;
/*  236 */     int membersLength = (members == null) ? 0 : members.length;
/*  237 */     int fieldsIndex = 0;
/*  238 */     int methodsIndex = 0;
/*  239 */     int membersIndex = 0;
/*      */     
/*  241 */     while (fieldsIndex < fieldsLength || 
/*  242 */       membersIndex < membersLength || 
/*  243 */       methodsIndex < methodsLength) {
/*  244 */       ASTNode node; FieldDeclaration nextFieldDeclaration = null;
/*  245 */       AbstractMethodDeclaration nextMethodDeclaration = null;
/*  246 */       TypeDeclaration nextMemberDeclaration = null;
/*      */       
/*  248 */       int position = Integer.MAX_VALUE;
/*  249 */       int nextDeclarationType = -1;
/*  250 */       if (fieldsIndex < fieldsLength) {
/*  251 */         nextFieldDeclaration = fields[fieldsIndex];
/*  252 */         if (!nextFieldDeclaration.isARecordComponent) {
/*  253 */           if (nextFieldDeclaration.declarationSourceStart < position) {
/*  254 */             position = nextFieldDeclaration.declarationSourceStart;
/*  255 */             nextDeclarationType = 0;
/*      */           } 
/*      */         } else {
/*  258 */           fieldsIndex++;
/*      */         } 
/*      */       } 
/*      */       
/*  262 */       if (methodsIndex < methodsLength) {
/*  263 */         nextMethodDeclaration = methods[methodsIndex];
/*  264 */         if ((nextMethodDeclaration.bits & 0x400) == 0) {
/*  265 */           if (nextMethodDeclaration.declarationSourceStart < position) {
/*  266 */             position = nextMethodDeclaration.declarationSourceStart;
/*  267 */             nextDeclarationType = 1;
/*      */           } 
/*      */         } else {
/*      */           
/*  271 */           methodsIndex++;
/*      */         } 
/*      */       } 
/*      */       
/*  275 */       if (membersIndex < membersLength) {
/*  276 */         nextMemberDeclaration = members[membersIndex];
/*  277 */         if (nextMemberDeclaration.declarationSourceStart < position) {
/*  278 */           position = nextMemberDeclaration.declarationSourceStart;
/*  279 */           nextDeclarationType = 2;
/*      */         } 
/*      */       } 
/*  282 */       switch (nextDeclarationType) {
/*      */         case 0:
/*  284 */           checkAndAddMultipleFieldDeclaration(fields, fieldsIndex, recordDeclaration.bodyDeclarations());
/*  285 */           fieldsIndex++;
/*      */         
/*      */         case 1:
/*  288 */           methodsIndex++;
/*  289 */           if (!nextMethodDeclaration.isDefaultConstructor() && !nextMethodDeclaration.isClinit()) {
/*  290 */             recordDeclaration.bodyDeclarations().add(convert(isInterface, nextMethodDeclaration));
/*      */           }
/*      */         
/*      */         case 2:
/*  294 */           membersIndex++;
/*  295 */           node = convert(nextMemberDeclaration);
/*  296 */           if (node == null) {
/*  297 */             recordDeclaration.setFlags(recordDeclaration.getFlags() | 0x1); continue;
/*      */           } 
/*  299 */           recordDeclaration.bodyDeclarations().add(node);
/*      */       } 
/*      */ 
/*      */     
/*      */     } 
/*  304 */     convert(typeDeclaration.javadoc, recordDeclaration);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void buildBodyDeclarations(TypeDeclaration enumDeclaration2, EnumDeclaration enumDeclaration) {
/*  309 */     TypeDeclaration[] members = enumDeclaration2.memberTypes;
/*  310 */     FieldDeclaration[] fields = enumDeclaration2.fields;
/*  311 */     AbstractMethodDeclaration[] methods = enumDeclaration2.methods;
/*      */     
/*  313 */     int fieldsLength = (fields == null) ? 0 : fields.length;
/*  314 */     int methodsLength = (methods == null) ? 0 : methods.length;
/*  315 */     int membersLength = (members == null) ? 0 : members.length;
/*  316 */     int fieldsIndex = 0;
/*  317 */     int methodsIndex = 0;
/*  318 */     int membersIndex = 0;
/*      */     
/*  320 */     while (fieldsIndex < fieldsLength || 
/*  321 */       membersIndex < membersLength || 
/*  322 */       methodsIndex < methodsLength) {
/*  323 */       FieldDeclaration nextFieldDeclaration = null;
/*  324 */       AbstractMethodDeclaration nextMethodDeclaration = null;
/*  325 */       TypeDeclaration nextMemberDeclaration = null;
/*      */       
/*  327 */       int position = Integer.MAX_VALUE;
/*  328 */       int nextDeclarationType = -1;
/*  329 */       if (fieldsIndex < fieldsLength) {
/*  330 */         nextFieldDeclaration = fields[fieldsIndex];
/*  331 */         if (nextFieldDeclaration.declarationSourceStart < position) {
/*  332 */           position = nextFieldDeclaration.declarationSourceStart;
/*  333 */           nextDeclarationType = 0;
/*      */         } 
/*      */       } 
/*  336 */       if (methodsIndex < methodsLength) {
/*  337 */         nextMethodDeclaration = methods[methodsIndex];
/*  338 */         if (nextMethodDeclaration.declarationSourceStart < position) {
/*  339 */           position = nextMethodDeclaration.declarationSourceStart;
/*  340 */           nextDeclarationType = 1;
/*      */         } 
/*      */       } 
/*  343 */       if (membersIndex < membersLength) {
/*  344 */         nextMemberDeclaration = members[membersIndex];
/*  345 */         if (nextMemberDeclaration.declarationSourceStart < position) {
/*  346 */           position = nextMemberDeclaration.declarationSourceStart;
/*  347 */           nextDeclarationType = 2;
/*      */         } 
/*      */       } 
/*  350 */       switch (nextDeclarationType) {
/*      */         case 0:
/*  352 */           if (nextFieldDeclaration.getKind() == 3) {
/*  353 */             enumDeclaration.enumConstants().add(convert(nextFieldDeclaration));
/*      */           } else {
/*  355 */             checkAndAddMultipleFieldDeclaration(fields, fieldsIndex, enumDeclaration.bodyDeclarations());
/*      */           } 
/*  357 */           fieldsIndex++;
/*      */         
/*      */         case 1:
/*  360 */           methodsIndex++;
/*  361 */           if (!nextMethodDeclaration.isDefaultConstructor() && !nextMethodDeclaration.isClinit()) {
/*  362 */             enumDeclaration.bodyDeclarations().add(convert(false, nextMethodDeclaration));
/*      */           }
/*      */         
/*      */         case 2:
/*  366 */           membersIndex++;
/*  367 */           enumDeclaration.bodyDeclarations().add(convert(nextMemberDeclaration));
/*      */       } 
/*      */     
/*      */     } 
/*  371 */     convert(enumDeclaration2.javadoc, enumDeclaration);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void buildBodyDeclarations(TypeDeclaration expression, AnonymousClassDeclaration anonymousClassDeclaration) {
/*  376 */     TypeDeclaration[] members = expression.memberTypes;
/*  377 */     FieldDeclaration[] fields = expression.fields;
/*  378 */     AbstractMethodDeclaration[] methods = expression.methods;
/*      */     
/*  380 */     int fieldsLength = (fields == null) ? 0 : fields.length;
/*  381 */     int methodsLength = (methods == null) ? 0 : methods.length;
/*  382 */     int membersLength = (members == null) ? 0 : members.length;
/*  383 */     int fieldsIndex = 0;
/*  384 */     int methodsIndex = 0;
/*  385 */     int membersIndex = 0;
/*      */     
/*  387 */     while (fieldsIndex < fieldsLength || 
/*  388 */       membersIndex < membersLength || 
/*  389 */       methodsIndex < methodsLength) {
/*  390 */       ASTNode node; FieldDeclaration nextFieldDeclaration = null;
/*  391 */       AbstractMethodDeclaration nextMethodDeclaration = null;
/*  392 */       TypeDeclaration nextMemberDeclaration = null;
/*      */       
/*  394 */       int position = Integer.MAX_VALUE;
/*  395 */       int nextDeclarationType = -1;
/*  396 */       if (fieldsIndex < fieldsLength) {
/*  397 */         nextFieldDeclaration = fields[fieldsIndex];
/*  398 */         if (nextFieldDeclaration.declarationSourceStart < position) {
/*  399 */           position = nextFieldDeclaration.declarationSourceStart;
/*  400 */           nextDeclarationType = 0;
/*      */         } 
/*      */       } 
/*  403 */       if (methodsIndex < methodsLength) {
/*  404 */         nextMethodDeclaration = methods[methodsIndex];
/*  405 */         if (nextMethodDeclaration.declarationSourceStart < position) {
/*  406 */           position = nextMethodDeclaration.declarationSourceStart;
/*  407 */           nextDeclarationType = 1;
/*      */         } 
/*      */       } 
/*  410 */       if (membersIndex < membersLength) {
/*  411 */         nextMemberDeclaration = members[membersIndex];
/*  412 */         if (nextMemberDeclaration.declarationSourceStart < position) {
/*  413 */           position = nextMemberDeclaration.declarationSourceStart;
/*  414 */           nextDeclarationType = 2;
/*      */         } 
/*      */       } 
/*  417 */       switch (nextDeclarationType) {
/*      */         case 0:
/*  419 */           if (nextFieldDeclaration.getKind() == 3) {
/*  420 */             anonymousClassDeclaration.bodyDeclarations().add(convert(nextFieldDeclaration));
/*      */           } else {
/*  422 */             checkAndAddMultipleFieldDeclaration(fields, fieldsIndex, anonymousClassDeclaration.bodyDeclarations());
/*      */           } 
/*  424 */           fieldsIndex++;
/*      */         
/*      */         case 1:
/*  427 */           methodsIndex++;
/*  428 */           if (!nextMethodDeclaration.isDefaultConstructor() && !nextMethodDeclaration.isClinit()) {
/*  429 */             anonymousClassDeclaration.bodyDeclarations().add(convert(false, nextMethodDeclaration));
/*      */           }
/*      */         
/*      */         case 2:
/*  433 */           membersIndex++;
/*  434 */           node = convert(nextMemberDeclaration);
/*  435 */           if (node == null) {
/*  436 */             anonymousClassDeclaration.setFlags(anonymousClassDeclaration.getFlags() | 0x1); continue;
/*      */           } 
/*  438 */           anonymousClassDeclaration.bodyDeclarations().add(node);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkAndSetMalformed(ASTNode spannedNode, ASTNode spanningNode) {
/*  445 */     if ((spannedNode.getFlags() & 0x1) != 0) {
/*  446 */       spanningNode.setFlags(spanningNode.getFlags() | 0x1);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void internalSetExpression(SwitchCase switchCase, Expression exp) {
/*  456 */     switchCase.setExpression(exp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void internalSetExtraDimensions(SingleVariableDeclaration node, int dimensions) {
/*  466 */     node.setExtraDimensions(dimensions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void internalSetExtraDimensions(VariableDeclarationFragment node, int dimensions) {
/*  476 */     node.setExtraDimensions(dimensions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void internalSetExtraDimensions(MethodDeclaration node, int dimensions) {
/*  486 */     node.setExtraDimensions(dimensions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static List internalThownExceptions(MethodDeclaration node) {
/*  495 */     return node.thrownExceptions();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void buildCommentsTable(CompilationUnit compilationUnit, int[][] comments) {
/*  504 */     this.commentsTable = new Comment[comments.length];
/*  505 */     int nbr = 0;
/*  506 */     for (int i = 0; i < comments.length; i++) {
/*  507 */       Comment comment = createComment(comments[i]);
/*  508 */       if (comment != null) {
/*  509 */         comment.setAlternateRoot(compilationUnit);
/*  510 */         this.commentsTable[nbr++] = comment;
/*      */       } 
/*      */     } 
/*      */     
/*  514 */     if (nbr < comments.length) {
/*  515 */       Comment[] newCommentsTable = new Comment[nbr];
/*  516 */       System.arraycopy(this.commentsTable, 0, newCommentsTable, 0, nbr);
/*  517 */       this.commentsTable = newCommentsTable;
/*      */     } 
/*  519 */     compilationUnit.setCommentTable(this.commentsTable);
/*      */   }
/*      */   
/*      */   protected void checkAndAddMultipleFieldDeclaration(FieldDeclaration[] fields, int index, List<Initializer> bodyDeclarations) {
/*  523 */     if (fields[index] instanceof Initializer) {
/*  524 */       Initializer oldInitializer = (Initializer)fields[index];
/*  525 */       Initializer initializer = new Initializer(this.ast);
/*  526 */       initializer.setBody(convert(oldInitializer.block));
/*  527 */       setModifiers(initializer, oldInitializer);
/*  528 */       initializer.setSourceRange(oldInitializer.declarationSourceStart, oldInitializer.sourceEnd - oldInitializer.declarationSourceStart + 1);
/*      */       
/*  530 */       convert(oldInitializer.javadoc, initializer);
/*  531 */       bodyDeclarations.add(initializer);
/*      */       return;
/*      */     } 
/*  534 */     if (index > 0 && (fields[index - 1]).declarationSourceStart == (fields[index]).declarationSourceStart) {
/*      */ 
/*      */       
/*  537 */       FieldDeclaration fieldDeclaration = (FieldDeclaration)bodyDeclarations.get(bodyDeclarations.size() - 1);
/*  538 */       fieldDeclaration.fragments().add(convertToVariableDeclarationFragment(fields[index]));
/*      */     } else {
/*      */       
/*  541 */       bodyDeclarations.add(convertToFieldDeclaration(fields[index]));
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void checkAndAddMultipleLocalDeclaration(Statement[] stmts, int index, List<VariableDeclarationStatement> blockStatements) {
/*  546 */     if (index > 0 && 
/*  547 */       stmts[index - 1] instanceof LocalDeclaration) {
/*  548 */       LocalDeclaration local1 = (LocalDeclaration)stmts[index - 1];
/*  549 */       LocalDeclaration local2 = (LocalDeclaration)stmts[index];
/*  550 */       if (local1.declarationSourceStart == local2.declarationSourceStart) {
/*      */ 
/*      */         
/*  553 */         VariableDeclarationStatement variableDeclarationStatement = blockStatements.get(blockStatements.size() - 1);
/*  554 */         variableDeclarationStatement.fragments().add(convertToVariableDeclarationFragment((LocalDeclaration)stmts[index]));
/*      */       } else {
/*      */         
/*  557 */         blockStatements.add(convertToVariableDeclarationStatement((LocalDeclaration)stmts[index]));
/*      */       } 
/*      */     } else {
/*      */       
/*  561 */       blockStatements.add(convertToVariableDeclarationStatement((LocalDeclaration)stmts[index]));
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void checkCanceled() {
/*  566 */     if (this.monitor != null && this.monitor.isCanceled())
/*  567 */       throw new OperationCanceledException(); 
/*      */   }
/*      */   
/*      */   private int checkLength(int start, int end) {
/*  571 */     int len = end - start + 1;
/*  572 */     return (len > 0) ? len : 0;
/*      */   }
/*      */   protected void completeRecord(ArrayType arrayType, ASTNode astNode) {
/*  575 */     ArrayType array = arrayType;
/*  576 */     recordNodes(arrayType, astNode);
/*  577 */     if (this.ast.apiLevel() >= 8) {
/*  578 */       recordNodes(arrayType.getElementType(), astNode);
/*      */       return;
/*      */     } 
/*  581 */     int dimensions = array.getDimensions();
/*  582 */     for (int i = 0; i < dimensions; i++) {
/*  583 */       Type componentType = componentType(array);
/*  584 */       recordNodes(componentType, astNode);
/*  585 */       if (componentType.isArrayType()) {
/*  586 */         array = (ArrayType)componentType;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Type componentType(ArrayType array) {
/*  595 */     return array.getComponentType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ASTNode convert(boolean isInterface, AbstractMethodDeclaration methodDeclaration) {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokevirtual checkCanceled : ()V
/*      */     //   4: aload_2
/*      */     //   5: instanceof org/eclipse/jdt/internal/compiler/ast/AnnotationMethodDeclaration
/*      */     //   8: ifeq -> 20
/*      */     //   11: aload_0
/*      */     //   12: aload_2
/*      */     //   13: checkcast org/eclipse/jdt/internal/compiler/ast/AnnotationMethodDeclaration
/*      */     //   16: invokevirtual convert : (Lorg/eclipse/jdt/internal/compiler/ast/AnnotationMethodDeclaration;)Lorg/eclipse/jdt/core/dom/ASTNode;
/*      */     //   19: areturn
/*      */     //   20: new org/eclipse/jdt/core/dom/MethodDeclaration
/*      */     //   23: dup
/*      */     //   24: aload_0
/*      */     //   25: getfield ast : Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   28: invokespecial <init> : (Lorg/eclipse/jdt/core/dom/AST;)V
/*      */     //   31: astore_3
/*      */     //   32: aload_0
/*      */     //   33: getfield referenceContext : Lorg/eclipse/jdt/core/dom/ASTNode;
/*      */     //   36: astore #4
/*      */     //   38: aload_0
/*      */     //   39: aload_3
/*      */     //   40: putfield referenceContext : Lorg/eclipse/jdt/core/dom/ASTNode;
/*      */     //   43: aload_0
/*      */     //   44: aload_3
/*      */     //   45: aload_2
/*      */     //   46: invokevirtual setModifiers : (Lorg/eclipse/jdt/core/dom/MethodDeclaration;Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;)V
/*      */     //   49: aload_2
/*      */     //   50: invokevirtual isConstructor : ()Z
/*      */     //   53: istore #5
/*      */     //   55: aload_3
/*      */     //   56: iload #5
/*      */     //   58: invokevirtual setConstructor : (Z)V
/*      */     //   61: new org/eclipse/jdt/core/dom/SimpleName
/*      */     //   64: dup
/*      */     //   65: aload_0
/*      */     //   66: getfield ast : Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   69: invokespecial <init> : (Lorg/eclipse/jdt/core/dom/AST;)V
/*      */     //   72: astore #6
/*      */     //   74: aload #6
/*      */     //   76: new java/lang/String
/*      */     //   79: dup
/*      */     //   80: aload_2
/*      */     //   81: getfield selector : [C
/*      */     //   84: invokespecial <init> : ([C)V
/*      */     //   87: invokevirtual internalSetIdentifier : (Ljava/lang/String;)V
/*      */     //   90: aload_2
/*      */     //   91: getfield sourceStart : I
/*      */     //   94: istore #7
/*      */     //   96: aload_0
/*      */     //   97: getfield ast : Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   100: invokestatic isRecordDeclarationSupported : (Lorg/eclipse/jdt/core/dom/AST;)Z
/*      */     //   103: ifeq -> 133
/*      */     //   106: aload_2
/*      */     //   107: instanceof org/eclipse/jdt/internal/compiler/ast/CompactConstructorDeclaration
/*      */     //   110: ifeq -> 133
/*      */     //   113: aload_3
/*      */     //   114: iconst_1
/*      */     //   115: invokevirtual setCompactConstructor : (Z)V
/*      */     //   118: iload #7
/*      */     //   120: aload_2
/*      */     //   121: getfield selector : [C
/*      */     //   124: arraylength
/*      */     //   125: iadd
/*      */     //   126: iconst_1
/*      */     //   127: isub
/*      */     //   128: istore #8
/*      */     //   130: goto -> 162
/*      */     //   133: aload_0
/*      */     //   134: iload #7
/*      */     //   136: aload_2
/*      */     //   137: getfield sourceEnd : I
/*      */     //   140: invokevirtual retrieveIdentifierEndPosition : (II)I
/*      */     //   143: istore #8
/*      */     //   145: iload #8
/*      */     //   147: iload #7
/*      */     //   149: if_icmpge -> 162
/*      */     //   152: iload #7
/*      */     //   154: aload_2
/*      */     //   155: getfield selector : [C
/*      */     //   158: arraylength
/*      */     //   159: iadd
/*      */     //   160: istore #8
/*      */     //   162: aload #6
/*      */     //   164: iload #7
/*      */     //   166: iload #8
/*      */     //   168: iload #7
/*      */     //   170: isub
/*      */     //   171: iconst_1
/*      */     //   172: iadd
/*      */     //   173: invokevirtual setSourceRange : (II)V
/*      */     //   176: aload_3
/*      */     //   177: aload #6
/*      */     //   179: invokevirtual setName : (Lorg/eclipse/jdt/core/dom/SimpleName;)V
/*      */     //   182: aload_2
/*      */     //   183: getfield thrownExceptions : [Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   186: astore #9
/*      */     //   188: aload_2
/*      */     //   189: getfield sourceEnd : I
/*      */     //   192: istore #10
/*      */     //   194: aload #9
/*      */     //   196: ifnonnull -> 203
/*      */     //   199: iconst_0
/*      */     //   200: goto -> 206
/*      */     //   203: aload #9
/*      */     //   205: arraylength
/*      */     //   206: istore #11
/*      */     //   208: iload #11
/*      */     //   210: ifle -> 359
/*      */     //   213: aload_0
/*      */     //   214: getfield ast : Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   217: invokevirtual apiLevel : ()I
/*      */     //   220: bipush #8
/*      */     //   222: if_icmpge -> 310
/*      */     //   225: iconst_0
/*      */     //   226: istore #13
/*      */     //   228: aload #9
/*      */     //   230: iload #13
/*      */     //   232: iinc #13, 1
/*      */     //   235: aaload
/*      */     //   236: astore #14
/*      */     //   238: aload_0
/*      */     //   239: aload #14
/*      */     //   241: invokevirtual convert : (Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;)Lorg/eclipse/jdt/core/dom/Name;
/*      */     //   244: astore #12
/*      */     //   246: aload #14
/*      */     //   248: getfield annotations : [[Lorg/eclipse/jdt/internal/compiler/ast/Annotation;
/*      */     //   251: ifnull -> 275
/*      */     //   254: aload #14
/*      */     //   256: getfield annotations : [[Lorg/eclipse/jdt/internal/compiler/ast/Annotation;
/*      */     //   259: arraylength
/*      */     //   260: ifle -> 275
/*      */     //   263: aload #12
/*      */     //   265: aload #12
/*      */     //   267: invokevirtual getFlags : ()I
/*      */     //   270: iconst_1
/*      */     //   271: ior
/*      */     //   272: invokevirtual setFlags : (I)V
/*      */     //   275: aload_3
/*      */     //   276: invokestatic internalThownExceptions : (Lorg/eclipse/jdt/core/dom/MethodDeclaration;)Ljava/util/List;
/*      */     //   279: aload #12
/*      */     //   281: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   286: pop
/*      */     //   287: iload #13
/*      */     //   289: iload #11
/*      */     //   291: if_icmplt -> 228
/*      */     //   294: aload #12
/*      */     //   296: invokevirtual getStartPosition : ()I
/*      */     //   299: aload #12
/*      */     //   301: invokevirtual getLength : ()I
/*      */     //   304: iadd
/*      */     //   305: istore #10
/*      */     //   307: goto -> 359
/*      */     //   310: iconst_0
/*      */     //   311: istore #13
/*      */     //   313: aload_0
/*      */     //   314: aload #9
/*      */     //   316: iload #13
/*      */     //   318: iinc #13, 1
/*      */     //   321: aaload
/*      */     //   322: invokevirtual convertType : (Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;)Lorg/eclipse/jdt/core/dom/Type;
/*      */     //   325: astore #12
/*      */     //   327: aload_3
/*      */     //   328: invokevirtual thrownExceptionTypes : ()Ljava/util/List;
/*      */     //   331: aload #12
/*      */     //   333: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   338: pop
/*      */     //   339: iload #13
/*      */     //   341: iload #11
/*      */     //   343: if_icmplt -> 313
/*      */     //   346: aload #12
/*      */     //   348: invokevirtual getStartPosition : ()I
/*      */     //   351: aload #12
/*      */     //   353: invokevirtual getLength : ()I
/*      */     //   356: iadd
/*      */     //   357: istore #10
/*      */     //   359: aload_2
/*      */     //   360: getfield receiver : Lorg/eclipse/jdt/internal/compiler/ast/Receiver;
/*      */     //   363: ifnull -> 397
/*      */     //   366: aload_0
/*      */     //   367: getfield ast : Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   370: getfield apiLevel : I
/*      */     //   373: bipush #8
/*      */     //   375: if_icmplt -> 387
/*      */     //   378: aload_0
/*      */     //   379: aload_2
/*      */     //   380: aload_3
/*      */     //   381: invokevirtual convertAndSetReceiver : (Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;Lorg/eclipse/jdt/core/dom/MethodDeclaration;)V
/*      */     //   384: goto -> 397
/*      */     //   387: aload_3
/*      */     //   388: aload_3
/*      */     //   389: invokevirtual getFlags : ()I
/*      */     //   392: iconst_1
/*      */     //   393: ior
/*      */     //   394: invokevirtual setFlags : (I)V
/*      */     //   397: aload_2
/*      */     //   398: getfield arguments : [Lorg/eclipse/jdt/internal/compiler/ast/Argument;
/*      */     //   401: astore #12
/*      */     //   403: aload #12
/*      */     //   405: ifnonnull -> 412
/*      */     //   408: iconst_0
/*      */     //   409: goto -> 415
/*      */     //   412: aload #12
/*      */     //   414: arraylength
/*      */     //   415: istore #13
/*      */     //   417: iload #13
/*      */     //   419: ifle -> 493
/*      */     //   422: aload_0
/*      */     //   423: getfield ast : Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   426: invokestatic isRecordDeclarationSupported : (Lorg/eclipse/jdt/core/dom/AST;)Z
/*      */     //   429: ifeq -> 439
/*      */     //   432: aload_3
/*      */     //   433: invokevirtual isCompactConstructor : ()Z
/*      */     //   436: ifne -> 493
/*      */     //   439: iconst_0
/*      */     //   440: istore #15
/*      */     //   442: aload_0
/*      */     //   443: aload #12
/*      */     //   445: iload #15
/*      */     //   447: iinc #15, 1
/*      */     //   450: aaload
/*      */     //   451: invokevirtual convert : (Lorg/eclipse/jdt/internal/compiler/ast/Argument;)Lorg/eclipse/jdt/core/dom/SingleVariableDeclaration;
/*      */     //   454: astore #14
/*      */     //   456: aload_3
/*      */     //   457: invokevirtual parameters : ()Ljava/util/List;
/*      */     //   460: aload #14
/*      */     //   462: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   467: pop
/*      */     //   468: iload #15
/*      */     //   470: iload #13
/*      */     //   472: if_icmplt -> 442
/*      */     //   475: iload #11
/*      */     //   477: ifne -> 493
/*      */     //   480: aload #14
/*      */     //   482: invokevirtual getStartPosition : ()I
/*      */     //   485: aload #14
/*      */     //   487: invokevirtual getLength : ()I
/*      */     //   490: iadd
/*      */     //   491: istore #10
/*      */     //   493: aconst_null
/*      */     //   494: astore #14
/*      */     //   496: iload #5
/*      */     //   498: ifeq -> 600
/*      */     //   501: iload_1
/*      */     //   502: ifeq -> 515
/*      */     //   505: aload_3
/*      */     //   506: aload_3
/*      */     //   507: invokevirtual getFlags : ()I
/*      */     //   510: iconst_1
/*      */     //   511: ior
/*      */     //   512: invokevirtual setFlags : (I)V
/*      */     //   515: aload_2
/*      */     //   516: checkcast org/eclipse/jdt/internal/compiler/ast/ConstructorDeclaration
/*      */     //   519: astore #15
/*      */     //   521: aload #15
/*      */     //   523: getfield constructorCall : Lorg/eclipse/jdt/internal/compiler/ast/ExplicitConstructorCall;
/*      */     //   526: astore #14
/*      */     //   528: aload_0
/*      */     //   529: getfield ast : Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   532: getfield apiLevel : I
/*      */     //   535: tableswitch default -> 592, 2 -> 552
/*      */     //   552: new org/eclipse/jdt/core/dom/PrimitiveType
/*      */     //   555: dup
/*      */     //   556: aload_0
/*      */     //   557: getfield ast : Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   560: invokespecial <init> : (Lorg/eclipse/jdt/core/dom/AST;)V
/*      */     //   563: astore #16
/*      */     //   565: aload #16
/*      */     //   567: getstatic org/eclipse/jdt/core/dom/PrimitiveType.VOID : Lorg/eclipse/jdt/core/dom/PrimitiveType$Code;
/*      */     //   570: invokevirtual setPrimitiveTypeCode : (Lorg/eclipse/jdt/core/dom/PrimitiveType$Code;)V
/*      */     //   573: aload #16
/*      */     //   575: aload_2
/*      */     //   576: getfield sourceStart : I
/*      */     //   579: iconst_0
/*      */     //   580: invokevirtual setSourceRange : (II)V
/*      */     //   583: aload_3
/*      */     //   584: aload #16
/*      */     //   586: invokevirtual internalSetReturnType : (Lorg/eclipse/jdt/core/dom/Type;)V
/*      */     //   589: goto -> 748
/*      */     //   592: aload_3
/*      */     //   593: aconst_null
/*      */     //   594: invokevirtual setReturnType2 : (Lorg/eclipse/jdt/core/dom/Type;)V
/*      */     //   597: goto -> 748
/*      */     //   600: aload_2
/*      */     //   601: instanceof org/eclipse/jdt/internal/compiler/ast/MethodDeclaration
/*      */     //   604: ifeq -> 748
/*      */     //   607: aload_2
/*      */     //   608: checkcast org/eclipse/jdt/internal/compiler/ast/MethodDeclaration
/*      */     //   611: astore #15
/*      */     //   613: aload #15
/*      */     //   615: getfield returnType : Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   618: astore #16
/*      */     //   620: aload #16
/*      */     //   622: ifnull -> 705
/*      */     //   625: aload_0
/*      */     //   626: aload #16
/*      */     //   628: invokevirtual convertType : (Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;)Lorg/eclipse/jdt/core/dom/Type;
/*      */     //   631: astore #17
/*      */     //   633: aload_0
/*      */     //   634: iload #8
/*      */     //   636: aload #15
/*      */     //   638: getfield bodyEnd : I
/*      */     //   641: invokevirtual retrieveEndOfRightParenthesisPosition : (II)I
/*      */     //   644: istore #18
/*      */     //   646: aload #16
/*      */     //   648: invokevirtual extraDimensions : ()I
/*      */     //   651: istore #19
/*      */     //   653: aload_0
/*      */     //   654: getfield ast : Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   657: getfield apiLevel : I
/*      */     //   660: bipush #8
/*      */     //   662: if_icmplt -> 687
/*      */     //   665: aload_0
/*      */     //   666: iload #18
/*      */     //   668: aload #15
/*      */     //   670: getfield bodyEnd : I
/*      */     //   673: aload #16
/*      */     //   675: aload_3
/*      */     //   676: invokevirtual extraDimensions : ()Ljava/util/List;
/*      */     //   679: iload #19
/*      */     //   681: invokevirtual setExtraAnnotatedDimensions : (IILorg/eclipse/jdt/internal/compiler/ast/TypeReference;Ljava/util/List;I)V
/*      */     //   684: goto -> 693
/*      */     //   687: aload_3
/*      */     //   688: iload #19
/*      */     //   690: invokestatic internalSetExtraDimensions : (Lorg/eclipse/jdt/core/dom/MethodDeclaration;I)V
/*      */     //   693: aload_0
/*      */     //   694: aload_3
/*      */     //   695: aload #17
/*      */     //   697: iload #19
/*      */     //   699: invokevirtual setTypeForMethodDeclaration : (Lorg/eclipse/jdt/core/dom/MethodDeclaration;Lorg/eclipse/jdt/core/dom/Type;I)V
/*      */     //   702: goto -> 748
/*      */     //   705: aload_3
/*      */     //   706: aload_3
/*      */     //   707: invokevirtual getFlags : ()I
/*      */     //   710: iconst_1
/*      */     //   711: ior
/*      */     //   712: invokevirtual setFlags : (I)V
/*      */     //   715: aload_0
/*      */     //   716: getfield ast : Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   719: getfield apiLevel : I
/*      */     //   722: tableswitch default -> 743, 2 -> 740
/*      */     //   740: goto -> 748
/*      */     //   743: aload_3
/*      */     //   744: aconst_null
/*      */     //   745: invokevirtual setReturnType2 : (Lorg/eclipse/jdt/core/dom/Type;)V
/*      */     //   748: aload_2
/*      */     //   749: getfield declarationSourceStart : I
/*      */     //   752: istore #15
/*      */     //   754: aload_2
/*      */     //   755: getfield bodyEnd : I
/*      */     //   758: istore #16
/*      */     //   760: aload_3
/*      */     //   761: iload #15
/*      */     //   763: aload_0
/*      */     //   764: iload #15
/*      */     //   766: iload #16
/*      */     //   768: invokevirtual checkLength : (II)I
/*      */     //   771: invokevirtual setSourceRange : (II)V
/*      */     //   774: aload_2
/*      */     //   775: getfield declarationSourceEnd : I
/*      */     //   778: istore #17
/*      */     //   780: iload #16
/*      */     //   782: iload #17
/*      */     //   784: if_icmpne -> 792
/*      */     //   787: iload #16
/*      */     //   789: goto -> 796
/*      */     //   792: iload #16
/*      */     //   794: iconst_1
/*      */     //   795: iadd
/*      */     //   796: istore #18
/*      */     //   798: aload_0
/*      */     //   799: iload #18
/*      */     //   801: iload #17
/*      */     //   803: invokevirtual retrieveRightBraceOrSemiColonPosition : (II)I
/*      */     //   806: istore #19
/*      */     //   808: iload #19
/*      */     //   810: iconst_m1
/*      */     //   811: if_icmpeq -> 1144
/*      */     //   814: aload_3
/*      */     //   815: invokevirtual getStartPosition : ()I
/*      */     //   818: istore #20
/*      */     //   820: aload_3
/*      */     //   821: iload #20
/*      */     //   823: iload #19
/*      */     //   825: iload #20
/*      */     //   827: isub
/*      */     //   828: iconst_1
/*      */     //   829: iadd
/*      */     //   830: invokevirtual setSourceRange : (II)V
/*      */     //   833: aload_2
/*      */     //   834: getfield statements : [Lorg/eclipse/jdt/internal/compiler/ast/Statement;
/*      */     //   837: astore #21
/*      */     //   839: aload_0
/*      */     //   840: iload #10
/*      */     //   842: aload_2
/*      */     //   843: getfield bodyStart : I
/*      */     //   846: invokevirtual retrieveStartBlockPosition : (II)I
/*      */     //   849: istore #7
/*      */     //   851: iload #7
/*      */     //   853: iconst_m1
/*      */     //   854: if_icmpne -> 863
/*      */     //   857: aload_2
/*      */     //   858: getfield bodyStart : I
/*      */     //   861: istore #7
/*      */     //   863: aload_0
/*      */     //   864: aload_2
/*      */     //   865: getfield bodyEnd : I
/*      */     //   868: iconst_1
/*      */     //   869: iadd
/*      */     //   870: iload #17
/*      */     //   872: invokevirtual retrieveRightBrace : (II)I
/*      */     //   875: istore #8
/*      */     //   877: aconst_null
/*      */     //   878: astore #22
/*      */     //   880: iload #7
/*      */     //   882: iconst_m1
/*      */     //   883: if_icmpeq -> 925
/*      */     //   886: iload #8
/*      */     //   888: iconst_m1
/*      */     //   889: if_icmpeq -> 925
/*      */     //   892: new org/eclipse/jdt/core/dom/Block
/*      */     //   895: dup
/*      */     //   896: aload_0
/*      */     //   897: getfield ast : Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   900: invokespecial <init> : (Lorg/eclipse/jdt/core/dom/AST;)V
/*      */     //   903: astore #22
/*      */     //   905: aload #22
/*      */     //   907: iload #7
/*      */     //   909: iload #19
/*      */     //   911: iload #7
/*      */     //   913: isub
/*      */     //   914: iconst_1
/*      */     //   915: iadd
/*      */     //   916: invokevirtual setSourceRange : (II)V
/*      */     //   919: aload_3
/*      */     //   920: aload #22
/*      */     //   922: invokevirtual setBody : (Lorg/eclipse/jdt/core/dom/Block;)V
/*      */     //   925: aload #22
/*      */     //   927: ifnull -> 1070
/*      */     //   930: aload #21
/*      */     //   932: ifnonnull -> 940
/*      */     //   935: aload #14
/*      */     //   937: ifnull -> 1070
/*      */     //   940: aload #14
/*      */     //   942: ifnull -> 971
/*      */     //   945: aload #14
/*      */     //   947: getfield accessMode : I
/*      */     //   950: iconst_1
/*      */     //   951: if_icmpeq -> 971
/*      */     //   954: aload #22
/*      */     //   956: invokevirtual statements : ()Ljava/util/List;
/*      */     //   959: aload_0
/*      */     //   960: aload #14
/*      */     //   962: invokevirtual convert : (Lorg/eclipse/jdt/internal/compiler/ast/ExplicitConstructorCall;)Lorg/eclipse/jdt/core/dom/Statement;
/*      */     //   965: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   970: pop
/*      */     //   971: aload #21
/*      */     //   973: ifnonnull -> 980
/*      */     //   976: iconst_0
/*      */     //   977: goto -> 983
/*      */     //   980: aload #21
/*      */     //   982: arraylength
/*      */     //   983: istore #23
/*      */     //   985: iconst_0
/*      */     //   986: istore #24
/*      */     //   988: goto -> 1063
/*      */     //   991: aload #21
/*      */     //   993: iload #24
/*      */     //   995: aaload
/*      */     //   996: astore #25
/*      */     //   998: aload #25
/*      */     //   1000: instanceof org/eclipse/jdt/internal/compiler/ast/LocalDeclaration
/*      */     //   1003: ifeq -> 1022
/*      */     //   1006: aload_0
/*      */     //   1007: aload #21
/*      */     //   1009: iload #24
/*      */     //   1011: aload #22
/*      */     //   1013: invokevirtual statements : ()Ljava/util/List;
/*      */     //   1016: invokevirtual checkAndAddMultipleLocalDeclaration : ([Lorg/eclipse/jdt/internal/compiler/ast/Statement;ILjava/util/List;)V
/*      */     //   1019: goto -> 1060
/*      */     //   1022: aload #25
/*      */     //   1024: getfield bits : I
/*      */     //   1027: sipush #1024
/*      */     //   1030: iand
/*      */     //   1031: ifne -> 1060
/*      */     //   1034: aload_0
/*      */     //   1035: aload #25
/*      */     //   1037: invokevirtual convert : (Lorg/eclipse/jdt/internal/compiler/ast/Statement;)Lorg/eclipse/jdt/core/dom/Statement;
/*      */     //   1040: astore #26
/*      */     //   1042: aload #26
/*      */     //   1044: ifnull -> 1060
/*      */     //   1047: aload #22
/*      */     //   1049: invokevirtual statements : ()Ljava/util/List;
/*      */     //   1052: aload #26
/*      */     //   1054: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   1059: pop
/*      */     //   1060: iinc #24, 1
/*      */     //   1063: iload #24
/*      */     //   1065: iload #23
/*      */     //   1067: if_icmplt -> 991
/*      */     //   1070: aload #22
/*      */     //   1072: ifnull -> 1339
/*      */     //   1075: aload_2
/*      */     //   1076: getfield modifiers : I
/*      */     //   1079: sipush #1280
/*      */     //   1082: iand
/*      */     //   1083: ifne -> 1131
/*      */     //   1086: iload_1
/*      */     //   1087: ifeq -> 1339
/*      */     //   1090: aload_0
/*      */     //   1091: getfield ast : Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   1094: getfield apiLevel : I
/*      */     //   1097: bipush #8
/*      */     //   1099: if_icmplt -> 1131
/*      */     //   1102: aload_2
/*      */     //   1103: getfield modifiers : I
/*      */     //   1106: ldc_w 65544
/*      */     //   1109: aload_0
/*      */     //   1110: getfield ast : Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   1113: getfield apiLevel : I
/*      */     //   1116: bipush #8
/*      */     //   1118: if_icmple -> 1125
/*      */     //   1121: iconst_2
/*      */     //   1122: goto -> 1126
/*      */     //   1125: iconst_0
/*      */     //   1126: ior
/*      */     //   1127: iand
/*      */     //   1128: ifne -> 1339
/*      */     //   1131: aload_3
/*      */     //   1132: aload_3
/*      */     //   1133: invokevirtual getFlags : ()I
/*      */     //   1136: iconst_1
/*      */     //   1137: ior
/*      */     //   1138: invokevirtual setFlags : (I)V
/*      */     //   1141: goto -> 1339
/*      */     //   1144: aload_3
/*      */     //   1145: aload_3
/*      */     //   1146: invokevirtual getFlags : ()I
/*      */     //   1149: iconst_1
/*      */     //   1150: ior
/*      */     //   1151: invokevirtual setFlags : (I)V
/*      */     //   1154: aload_2
/*      */     //   1155: invokevirtual isNative : ()Z
/*      */     //   1158: ifne -> 1339
/*      */     //   1161: aload_2
/*      */     //   1162: invokevirtual isAbstract : ()Z
/*      */     //   1165: ifne -> 1339
/*      */     //   1168: aload_0
/*      */     //   1169: iload #10
/*      */     //   1171: iload #16
/*      */     //   1173: invokevirtual retrieveStartBlockPosition : (II)I
/*      */     //   1176: istore #7
/*      */     //   1178: iload #7
/*      */     //   1180: iconst_m1
/*      */     //   1181: if_icmpne -> 1190
/*      */     //   1184: aload_2
/*      */     //   1185: getfield bodyStart : I
/*      */     //   1188: istore #7
/*      */     //   1190: aload_2
/*      */     //   1191: getfield bodyEnd : I
/*      */     //   1194: istore #8
/*      */     //   1196: aload_2
/*      */     //   1197: invokevirtual compilationResult : ()Lorg/eclipse/jdt/internal/compiler/CompilationResult;
/*      */     //   1200: getfield problems : [Lorg/eclipse/jdt/core/compiler/CategorizedProblem;
/*      */     //   1203: astore #20
/*      */     //   1205: aload #20
/*      */     //   1207: ifnull -> 1273
/*      */     //   1210: iconst_0
/*      */     //   1211: istore #21
/*      */     //   1213: aload_2
/*      */     //   1214: invokevirtual compilationResult : ()Lorg/eclipse/jdt/internal/compiler/CompilationResult;
/*      */     //   1217: getfield problemCount : I
/*      */     //   1220: istore #22
/*      */     //   1222: goto -> 1266
/*      */     //   1225: aload #20
/*      */     //   1227: iload #21
/*      */     //   1229: aaload
/*      */     //   1230: astore #23
/*      */     //   1232: aload #23
/*      */     //   1234: invokevirtual getSourceStart : ()I
/*      */     //   1237: iload #7
/*      */     //   1239: if_icmpne -> 1263
/*      */     //   1242: aload #23
/*      */     //   1244: invokevirtual getID : ()I
/*      */     //   1247: ldc_w 1610612976
/*      */     //   1250: if_icmpne -> 1263
/*      */     //   1253: aload #23
/*      */     //   1255: invokevirtual getSourceEnd : ()I
/*      */     //   1258: istore #8
/*      */     //   1260: goto -> 1273
/*      */     //   1263: iinc #21, 1
/*      */     //   1266: iload #21
/*      */     //   1268: iload #22
/*      */     //   1270: if_icmplt -> 1225
/*      */     //   1273: aload_3
/*      */     //   1274: invokevirtual getStartPosition : ()I
/*      */     //   1277: istore #21
/*      */     //   1279: aload_3
/*      */     //   1280: iload #21
/*      */     //   1282: aload_0
/*      */     //   1283: iload #21
/*      */     //   1285: iload #8
/*      */     //   1287: invokevirtual checkLength : (II)I
/*      */     //   1290: invokevirtual setSourceRange : (II)V
/*      */     //   1293: iload #7
/*      */     //   1295: iconst_m1
/*      */     //   1296: if_icmpeq -> 1339
/*      */     //   1299: iload #8
/*      */     //   1301: iconst_m1
/*      */     //   1302: if_icmpeq -> 1339
/*      */     //   1305: new org/eclipse/jdt/core/dom/Block
/*      */     //   1308: dup
/*      */     //   1309: aload_0
/*      */     //   1310: getfield ast : Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   1313: invokespecial <init> : (Lorg/eclipse/jdt/core/dom/AST;)V
/*      */     //   1316: astore #22
/*      */     //   1318: aload #22
/*      */     //   1320: iload #7
/*      */     //   1322: aload_0
/*      */     //   1323: iload #7
/*      */     //   1325: iload #8
/*      */     //   1327: invokevirtual checkLength : (II)I
/*      */     //   1330: invokevirtual setSourceRange : (II)V
/*      */     //   1333: aload_3
/*      */     //   1334: aload #22
/*      */     //   1336: invokevirtual setBody : (Lorg/eclipse/jdt/core/dom/Block;)V
/*      */     //   1339: aload_2
/*      */     //   1340: invokevirtual typeParameters : ()[Lorg/eclipse/jdt/internal/compiler/ast/TypeParameter;
/*      */     //   1343: astore #20
/*      */     //   1345: aload #20
/*      */     //   1347: ifnull -> 1429
/*      */     //   1350: aload_0
/*      */     //   1351: getfield ast : Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   1354: getfield apiLevel : I
/*      */     //   1357: tableswitch default -> 1389, 2 -> 1376
/*      */     //   1376: aload_3
/*      */     //   1377: aload_3
/*      */     //   1378: invokevirtual getFlags : ()I
/*      */     //   1381: iconst_1
/*      */     //   1382: ior
/*      */     //   1383: invokevirtual setFlags : (I)V
/*      */     //   1386: goto -> 1429
/*      */     //   1389: iconst_0
/*      */     //   1390: istore #21
/*      */     //   1392: aload #20
/*      */     //   1394: arraylength
/*      */     //   1395: istore #22
/*      */     //   1397: goto -> 1422
/*      */     //   1400: aload_3
/*      */     //   1401: invokevirtual typeParameters : ()Ljava/util/List;
/*      */     //   1404: aload_0
/*      */     //   1405: aload #20
/*      */     //   1407: iload #21
/*      */     //   1409: aaload
/*      */     //   1410: invokevirtual convert : (Lorg/eclipse/jdt/internal/compiler/ast/TypeParameter;)Lorg/eclipse/jdt/core/dom/TypeParameter;
/*      */     //   1413: invokeinterface add : (Ljava/lang/Object;)Z
/*      */     //   1418: pop
/*      */     //   1419: iinc #21, 1
/*      */     //   1422: iload #21
/*      */     //   1424: iload #22
/*      */     //   1426: if_icmplt -> 1400
/*      */     //   1429: aload_0
/*      */     //   1430: aload_2
/*      */     //   1431: getfield javadoc : Lorg/eclipse/jdt/internal/compiler/ast/Javadoc;
/*      */     //   1434: aload_3
/*      */     //   1435: invokevirtual convert : (Lorg/eclipse/jdt/internal/compiler/ast/Javadoc;Lorg/eclipse/jdt/core/dom/BodyDeclaration;)V
/*      */     //   1438: aload_0
/*      */     //   1439: getfield resolveBindings : Z
/*      */     //   1442: ifeq -> 1463
/*      */     //   1445: aload_0
/*      */     //   1446: aload_3
/*      */     //   1447: aload_2
/*      */     //   1448: invokevirtual recordNodes : (Lorg/eclipse/jdt/core/dom/ASTNode;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;)V
/*      */     //   1451: aload_0
/*      */     //   1452: aload #6
/*      */     //   1454: aload_2
/*      */     //   1455: invokevirtual recordNodes : (Lorg/eclipse/jdt/core/dom/ASTNode;Lorg/eclipse/jdt/internal/compiler/ast/ASTNode;)V
/*      */     //   1458: aload_3
/*      */     //   1459: invokevirtual resolveBinding : ()Lorg/eclipse/jdt/core/dom/IMethodBinding;
/*      */     //   1462: pop
/*      */     //   1463: aload_0
/*      */     //   1464: aload #4
/*      */     //   1466: putfield referenceContext : Lorg/eclipse/jdt/core/dom/ASTNode;
/*      */     //   1469: aload_3
/*      */     //   1470: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #599	-> 0
/*      */     //   #600	-> 4
/*      */     //   #601	-> 11
/*      */     //   #603	-> 20
/*      */     //   #604	-> 32
/*      */     //   #605	-> 38
/*      */     //   #606	-> 43
/*      */     //   #607	-> 49
/*      */     //   #608	-> 55
/*      */     //   #609	-> 61
/*      */     //   #610	-> 74
/*      */     //   #611	-> 90
/*      */     //   #613	-> 96
/*      */     //   #614	-> 113
/*      */     //   #615	-> 118
/*      */     //   #616	-> 130
/*      */     //   #617	-> 133
/*      */     //   #618	-> 145
/*      */     //   #619	-> 152
/*      */     //   #621	-> 162
/*      */     //   #622	-> 176
/*      */     //   #623	-> 182
/*      */     //   #624	-> 188
/*      */     //   #625	-> 194
/*      */     //   #626	-> 208
/*      */     //   #627	-> 213
/*      */     //   #629	-> 225
/*      */     //   #631	-> 228
/*      */     //   #632	-> 238
/*      */     //   #633	-> 246
/*      */     //   #634	-> 263
/*      */     //   #636	-> 275
/*      */     //   #637	-> 287
/*      */     //   #630	-> 291
/*      */     //   #638	-> 294
/*      */     //   #639	-> 307
/*      */     //   #641	-> 310
/*      */     //   #643	-> 313
/*      */     //   #644	-> 327
/*      */     //   #645	-> 339
/*      */     //   #642	-> 343
/*      */     //   #646	-> 346
/*      */     //   #650	-> 359
/*      */     //   #651	-> 366
/*      */     //   #652	-> 378
/*      */     //   #653	-> 384
/*      */     //   #654	-> 387
/*      */     //   #657	-> 397
/*      */     //   #658	-> 403
/*      */     //   #659	-> 417
/*      */     //   #660	-> 422
/*      */     //   #662	-> 439
/*      */     //   #664	-> 442
/*      */     //   #665	-> 456
/*      */     //   #666	-> 468
/*      */     //   #663	-> 472
/*      */     //   #667	-> 475
/*      */     //   #668	-> 480
/*      */     //   #672	-> 493
/*      */     //   #673	-> 496
/*      */     //   #674	-> 501
/*      */     //   #676	-> 505
/*      */     //   #678	-> 515
/*      */     //   #679	-> 521
/*      */     //   #680	-> 528
/*      */     //   #683	-> 552
/*      */     //   #684	-> 565
/*      */     //   #685	-> 573
/*      */     //   #686	-> 583
/*      */     //   #687	-> 589
/*      */     //   #689	-> 592
/*      */     //   #691	-> 597
/*      */     //   #692	-> 607
/*      */     //   #693	-> 613
/*      */     //   #694	-> 620
/*      */     //   #695	-> 625
/*      */     //   #697	-> 633
/*      */     //   #698	-> 646
/*      */     //   #699	-> 653
/*      */     //   #700	-> 665
/*      */     //   #701	-> 675
/*      */     //   #700	-> 681
/*      */     //   #702	-> 684
/*      */     //   #703	-> 687
/*      */     //   #705	-> 693
/*      */     //   #706	-> 702
/*      */     //   #708	-> 705
/*      */     //   #709	-> 715
/*      */     //   #711	-> 740
/*      */     //   #713	-> 743
/*      */     //   #717	-> 748
/*      */     //   #718	-> 754
/*      */     //   #719	-> 760
/*      */     //   #720	-> 774
/*      */     //   #721	-> 780
/*      */     //   #722	-> 798
/*      */     //   #723	-> 808
/*      */     //   #724	-> 814
/*      */     //   #725	-> 820
/*      */     //   #727	-> 833
/*      */     //   #729	-> 839
/*      */     //   #730	-> 851
/*      */     //   #731	-> 863
/*      */     //   #732	-> 877
/*      */     //   #733	-> 880
/*      */     //   #737	-> 892
/*      */     //   #738	-> 905
/*      */     //   #739	-> 919
/*      */     //   #741	-> 925
/*      */     //   #742	-> 940
/*      */     //   #743	-> 954
/*      */     //   #745	-> 971
/*      */     //   #746	-> 985
/*      */     //   #747	-> 991
/*      */     //   #748	-> 998
/*      */     //   #749	-> 1006
/*      */     //   #750	-> 1019
/*      */     //   #751	-> 1034
/*      */     //   #752	-> 1042
/*      */     //   #753	-> 1047
/*      */     //   #746	-> 1060
/*      */     //   #758	-> 1070
/*      */     //   #759	-> 1075
/*      */     //   #760	-> 1086
/*      */     //   #761	-> 1102
/*      */     //   #762	-> 1109
/*      */     //   #761	-> 1127
/*      */     //   #763	-> 1131
/*      */     //   #766	-> 1141
/*      */     //   #768	-> 1144
/*      */     //   #769	-> 1154
/*      */     //   #770	-> 1168
/*      */     //   #771	-> 1178
/*      */     //   #772	-> 1190
/*      */     //   #774	-> 1196
/*      */     //   #775	-> 1205
/*      */     //   #776	-> 1210
/*      */     //   #777	-> 1225
/*      */     //   #778	-> 1232
/*      */     //   #779	-> 1253
/*      */     //   #780	-> 1260
/*      */     //   #776	-> 1263
/*      */     //   #784	-> 1273
/*      */     //   #785	-> 1279
/*      */     //   #786	-> 1293
/*      */     //   #790	-> 1305
/*      */     //   #791	-> 1318
/*      */     //   #792	-> 1333
/*      */     //   #797	-> 1339
/*      */     //   #798	-> 1345
/*      */     //   #799	-> 1350
/*      */     //   #801	-> 1376
/*      */     //   #802	-> 1386
/*      */     //   #804	-> 1389
/*      */     //   #805	-> 1400
/*      */     //   #804	-> 1419
/*      */     //   #811	-> 1429
/*      */     //   #812	-> 1438
/*      */     //   #813	-> 1445
/*      */     //   #814	-> 1451
/*      */     //   #815	-> 1458
/*      */     //   #817	-> 1463
/*      */     //   #818	-> 1469
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	1471	0	this	Lorg/eclipse/jdt/core/dom/ASTConverter;
/*      */     //   0	1471	1	isInterface	Z
/*      */     //   0	1471	2	methodDeclaration	Lorg/eclipse/jdt/internal/compiler/ast/AbstractMethodDeclaration;
/*      */     //   32	1439	3	methodDecl	Lorg/eclipse/jdt/core/dom/MethodDeclaration;
/*      */     //   38	1433	4	oldReferenceContext	Lorg/eclipse/jdt/core/dom/ASTNode;
/*      */     //   55	1416	5	isConstructor	Z
/*      */     //   74	1397	6	methodName	Lorg/eclipse/jdt/core/dom/SimpleName;
/*      */     //   96	1375	7	start	I
/*      */     //   130	3	8	end	I
/*      */     //   145	1326	8	end	I
/*      */     //   188	1283	9	thrownExceptions	[Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   194	1277	10	methodHeaderEnd	I
/*      */     //   208	1263	11	thrownExceptionsLength	I
/*      */     //   246	61	12	thrownException	Lorg/eclipse/jdt/core/dom/Name;
/*      */     //   228	79	13	i	I
/*      */     //   238	49	14	typeRef	Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   327	32	12	thrownExceptionType	Lorg/eclipse/jdt/core/dom/Type;
/*      */     //   313	46	13	i	I
/*      */     //   403	1068	12	parameters	[Lorg/eclipse/jdt/internal/compiler/ast/Argument;
/*      */     //   417	1054	13	parametersLength	I
/*      */     //   456	37	14	parameter	Lorg/eclipse/jdt/core/dom/SingleVariableDeclaration;
/*      */     //   442	51	15	i	I
/*      */     //   496	975	14	explicitConstructorCall	Lorg/eclipse/jdt/internal/compiler/ast/ExplicitConstructorCall;
/*      */     //   521	76	15	constructorDeclaration	Lorg/eclipse/jdt/internal/compiler/ast/ConstructorDeclaration;
/*      */     //   565	27	16	returnType	Lorg/eclipse/jdt/core/dom/PrimitiveType;
/*      */     //   613	135	15	method	Lorg/eclipse/jdt/internal/compiler/ast/MethodDeclaration;
/*      */     //   620	128	16	typeReference	Lorg/eclipse/jdt/internal/compiler/ast/TypeReference;
/*      */     //   633	69	17	returnType	Lorg/eclipse/jdt/core/dom/Type;
/*      */     //   646	56	18	rightParenthesisPosition	I
/*      */     //   653	49	19	extraDimensions	I
/*      */     //   754	717	15	declarationSourceStart	I
/*      */     //   760	711	16	bodyEnd	I
/*      */     //   780	691	17	declarationSourceEnd	I
/*      */     //   798	673	18	rightBraceOrSemiColonPositionStart	I
/*      */     //   808	663	19	closingPosition	I
/*      */     //   820	321	20	startPosition	I
/*      */     //   839	302	21	statements	[Lorg/eclipse/jdt/internal/compiler/ast/Statement;
/*      */     //   880	261	22	block	Lorg/eclipse/jdt/core/dom/Block;
/*      */     //   985	85	23	statementsLength	I
/*      */     //   988	82	24	i	I
/*      */     //   998	62	25	astStatement	Lorg/eclipse/jdt/internal/compiler/ast/Statement;
/*      */     //   1042	18	26	statement	Lorg/eclipse/jdt/core/dom/Statement;
/*      */     //   1205	134	20	problems	[Lorg/eclipse/jdt/core/compiler/CategorizedProblem;
/*      */     //   1213	60	21	i	I
/*      */     //   1222	51	22	max	I
/*      */     //   1232	31	23	currentProblem	Lorg/eclipse/jdt/core/compiler/CategorizedProblem;
/*      */     //   1279	60	21	startPosition	I
/*      */     //   1318	21	22	block	Lorg/eclipse/jdt/core/dom/Block;
/*      */     //   1345	126	20	typeParameters	[Lorg/eclipse/jdt/internal/compiler/ast/TypeParameter;
/*      */     //   1392	37	21	i	I
/*      */     //   1397	32	22	max	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClassInstanceCreation convert(AllocationExpression expression) {
/*  822 */     ClassInstanceCreation classInstanceCreation = new ClassInstanceCreation(this.ast);
/*  823 */     if (this.resolveBindings) {
/*  824 */       recordNodes(classInstanceCreation, (ASTNode)expression);
/*      */     }
/*  826 */     if (expression.typeArguments != null) {
/*  827 */       int i; int max; switch (this.ast.apiLevel) {
/*      */         case 2:
/*  829 */           classInstanceCreation.setFlags(classInstanceCreation.getFlags() | 0x1);
/*      */           break;
/*      */         default:
/*  832 */           for (i = 0, max = expression.typeArguments.length; i < max; i++)
/*  833 */             classInstanceCreation.typeArguments().add(convertType(expression.typeArguments[i])); 
/*      */           break;
/*      */       } 
/*      */     } 
/*  837 */     switch (this.ast.apiLevel) {
/*      */       case 2:
/*  839 */         classInstanceCreation.internalSetName(convert(expression.type));
/*      */         break;
/*      */       default:
/*  842 */         classInstanceCreation.setType(convertType(expression.type)); break;
/*      */     } 
/*  844 */     classInstanceCreation.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/*  845 */     Expression[] arguments = expression.arguments;
/*  846 */     if (arguments != null) {
/*  847 */       int length = arguments.length;
/*  848 */       for (int i = 0; i < length; i++) {
/*  849 */         classInstanceCreation.arguments().add(convert(arguments[i]));
/*      */       }
/*      */     } 
/*  852 */     return classInstanceCreation;
/*      */   }
/*      */   
/*      */   public Expression convert(AND_AND_Expression expression) {
/*  856 */     InfixExpression infixExpression = new InfixExpression(this.ast);
/*  857 */     infixExpression.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
/*  858 */     if (this.resolveBindings) {
/*  859 */       recordNodes(infixExpression, (ASTNode)expression);
/*      */     }
/*  861 */     int expressionOperatorID = (expression.bits & 0x3F00) >> 8;
/*  862 */     if (expression.left instanceof BinaryExpression && (
/*  863 */       expression.left.bits & 0x1FE00000) == 0) {
/*      */       
/*  865 */       infixExpression.extendedOperands().add(convert(expression.right));
/*  866 */       Expression leftOperand = expression.left;
/*  867 */       Expression rightOperand = null;
/*      */       do {
/*  869 */         rightOperand = ((BinaryExpression)leftOperand).right;
/*  870 */         if (((leftOperand.bits & 0x3F00) >> 8 != expressionOperatorID && (
/*  871 */           leftOperand.bits & 0x1FE00000) == 0) || (
/*  872 */           rightOperand instanceof BinaryExpression && (
/*  873 */           rightOperand.bits & 0x3F00) >> 8 != expressionOperatorID && (
/*  874 */           rightOperand.bits & 0x1FE00000) == 0)) {
/*  875 */           List<Expression> extendedOperands = infixExpression.extendedOperands();
/*  876 */           InfixExpression temp = new InfixExpression(this.ast);
/*  877 */           if (this.resolveBindings) {
/*  878 */             recordNodes(temp, (ASTNode)expression);
/*      */           }
/*  880 */           temp.setOperator(getOperatorFor(expressionOperatorID));
/*  881 */           Expression leftSide = convert(leftOperand);
/*  882 */           temp.setLeftOperand(leftSide);
/*  883 */           temp.setSourceRange(leftSide.getStartPosition(), leftSide.getLength());
/*  884 */           int size = extendedOperands.size(); int i;
/*  885 */           for (i = 0; i < size - 1; i++) {
/*  886 */             Expression expr = temp;
/*  887 */             temp = new InfixExpression(this.ast);
/*      */             
/*  889 */             if (this.resolveBindings) {
/*  890 */               recordNodes(temp, (ASTNode)expression);
/*      */             }
/*  892 */             temp.setLeftOperand(expr);
/*  893 */             temp.setOperator(getOperatorFor(expressionOperatorID));
/*  894 */             temp.setSourceRange(expr.getStartPosition(), expr.getLength());
/*      */           } 
/*  896 */           infixExpression = temp;
/*  897 */           for (i = 0; i < size; i++) {
/*  898 */             Expression extendedOperand = extendedOperands.remove(size - 1 - i);
/*  899 */             temp.setRightOperand(extendedOperand);
/*  900 */             int startPosition = temp.getLeftOperand().getStartPosition();
/*  901 */             temp.setSourceRange(startPosition, extendedOperand.getStartPosition() + extendedOperand.getLength() - startPosition);
/*  902 */             if (temp.getLeftOperand().getNodeType() == 27) {
/*  903 */               temp = (InfixExpression)temp.getLeftOperand();
/*      */             }
/*      */           } 
/*  906 */           setInfixSourcePositions(infixExpression, expression.sourceStart);
/*  907 */           if (this.resolveBindings) {
/*  908 */             recordNodes(infixExpression, (ASTNode)expression);
/*      */           }
/*  910 */           return infixExpression;
/*      */         } 
/*  912 */         infixExpression.extendedOperands().add(0, convert(rightOperand));
/*  913 */         leftOperand = ((BinaryExpression)leftOperand).left;
/*  914 */       } while (leftOperand instanceof BinaryExpression && (leftOperand.bits & 0x1FE00000) == 0);
/*  915 */       Expression expression1 = convert(leftOperand);
/*  916 */       infixExpression.setLeftOperand(expression1);
/*  917 */       infixExpression.setRightOperand(infixExpression.extendedOperands().remove(0));
/*  918 */       setInfixSourcePositions(infixExpression, expression.sourceStart);
/*  919 */       return infixExpression;
/*      */     } 
/*  921 */     Expression leftExpression = convert(expression.left);
/*  922 */     infixExpression.setLeftOperand(leftExpression);
/*  923 */     infixExpression.setRightOperand(convert(expression.right));
/*  924 */     infixExpression.setOperator(InfixExpression.Operator.CONDITIONAL_AND);
/*  925 */     setInfixSourcePositions(infixExpression, expression.sourceStart);
/*  926 */     return infixExpression;
/*      */   }
/*      */   
/*      */   private AnnotationTypeDeclaration convertToAnnotationDeclaration(TypeDeclaration typeDeclaration) {
/*  930 */     checkCanceled();
/*  931 */     if (this.scanner.sourceLevel < 3211264L) return null; 
/*  932 */     AnnotationTypeDeclaration typeDecl = this.ast.newAnnotationTypeDeclaration();
/*  933 */     setModifiers(typeDecl, typeDeclaration);
/*  934 */     SimpleName typeName = new SimpleName(this.ast);
/*  935 */     typeName.internalSetIdentifier(new String(typeDeclaration.name));
/*  936 */     typeName.setSourceRange(typeDeclaration.sourceStart, typeDeclaration.sourceEnd - typeDeclaration.sourceStart + 1);
/*  937 */     typeDecl.setName(typeName);
/*  938 */     typeDecl.setSourceRange(typeDeclaration.declarationSourceStart, typeDeclaration.bodyEnd - typeDeclaration.declarationSourceStart + 1);
/*      */     
/*  940 */     buildBodyDeclarations(typeDeclaration, typeDecl, false);
/*      */     
/*  942 */     if (this.resolveBindings) {
/*  943 */       recordNodes(typeDecl, (ASTNode)typeDeclaration);
/*  944 */       recordNodes(typeName, (ASTNode)typeDeclaration);
/*  945 */       typeDecl.resolveBinding();
/*      */     } 
/*  947 */     return typeDecl;
/*      */   }
/*      */   
/*      */   public ASTNode convert(AnnotationMethodDeclaration annotationTypeMemberDeclaration) {
/*  951 */     checkCanceled();
/*  952 */     if (this.ast.apiLevel == 2) {
/*  953 */       return null;
/*      */     }
/*  955 */     AnnotationTypeMemberDeclaration annotationTypeMemberDeclaration2 = new AnnotationTypeMemberDeclaration(this.ast);
/*  956 */     setModifiers(annotationTypeMemberDeclaration2, annotationTypeMemberDeclaration);
/*  957 */     SimpleName methodName = new SimpleName(this.ast);
/*  958 */     methodName.internalSetIdentifier(new String(annotationTypeMemberDeclaration.selector));
/*  959 */     int start = annotationTypeMemberDeclaration.sourceStart;
/*  960 */     int end = retrieveIdentifierEndPosition(start, annotationTypeMemberDeclaration.sourceEnd);
/*  961 */     methodName.setSourceRange(start, end - start + 1);
/*  962 */     annotationTypeMemberDeclaration2.setName(methodName);
/*  963 */     TypeReference typeReference = annotationTypeMemberDeclaration.returnType;
/*  964 */     if (typeReference != null) {
/*  965 */       Type returnType = convertType(typeReference);
/*  966 */       setTypeForMethodDeclaration(annotationTypeMemberDeclaration2, returnType, 0);
/*      */     } 
/*  968 */     int declarationSourceStart = annotationTypeMemberDeclaration.declarationSourceStart;
/*  969 */     int declarationSourceEnd = annotationTypeMemberDeclaration.bodyEnd;
/*  970 */     annotationTypeMemberDeclaration2.setSourceRange(declarationSourceStart, declarationSourceEnd - declarationSourceStart + 1);
/*      */     
/*  972 */     convert(annotationTypeMemberDeclaration.javadoc, annotationTypeMemberDeclaration2);
/*  973 */     Expression memberValue = annotationTypeMemberDeclaration.defaultValue;
/*  974 */     if (memberValue != null) {
/*  975 */       annotationTypeMemberDeclaration2.setDefault(convert(memberValue));
/*      */     }
/*  977 */     if (this.resolveBindings) {
/*  978 */       recordNodes(annotationTypeMemberDeclaration2, (ASTNode)annotationTypeMemberDeclaration);
/*  979 */       recordNodes(methodName, (ASTNode)annotationTypeMemberDeclaration);
/*  980 */       annotationTypeMemberDeclaration2.resolveBinding();
/*      */     } 
/*  982 */     return annotationTypeMemberDeclaration2;
/*      */   }
/*      */   
/*      */   private void convertAndSetReceiver(AbstractMethodDeclaration method, MethodDeclaration methodDecl) {
/*  986 */     Receiver receiver = method.receiver;
/*  987 */     if (receiver.qualifyingName != null) {
/*  988 */       SimpleName name = new SimpleName(this.ast);
/*  989 */       name.internalSetIdentifier(new String(receiver.qualifyingName.getName()[0]));
/*  990 */       int start = receiver.qualifyingName.sourceStart;
/*  991 */       int nameEnd = receiver.qualifyingName.sourceEnd;
/*  992 */       name.setSourceRange(start, nameEnd - start + 1);
/*  993 */       methodDecl.setReceiverQualifier(name);
/*  994 */       if (this.resolveBindings) {
/*  995 */         recordNodes(name, (ASTNode)receiver);
/*      */       }
/*      */     } 
/*  998 */     Type type = convertType(receiver.type);
/*  999 */     methodDecl.setReceiverType(type);
/* 1000 */     if (receiver.modifiers != 0) {
/* 1001 */       methodDecl.setFlags(methodDecl.getFlags() | 0x1);
/*      */     }
/* 1003 */     if (this.resolveBindings) {
/* 1004 */       recordNodes(type, (ASTNode)receiver);
/* 1005 */       type.resolveBinding();
/*      */     } 
/*      */   }
/*      */   
/*      */   public SingleVariableDeclaration convert(Argument argument) {
/* 1010 */     SingleVariableDeclaration variableDecl = new SingleVariableDeclaration(this.ast);
/* 1011 */     setModifiers(variableDecl, argument);
/* 1012 */     SimpleName name = new SimpleName(this.ast);
/* 1013 */     name.internalSetIdentifier(new String(argument.name));
/* 1014 */     if (argument instanceof Receiver) {
/* 1015 */       name.setFlags(name.getFlags() | 0x1);
/*      */     }
/* 1017 */     int start = argument.sourceStart;
/* 1018 */     int nameEnd = argument.sourceEnd;
/* 1019 */     name.setSourceRange(start, nameEnd - start + 1);
/* 1020 */     variableDecl.setName(name);
/* 1021 */     int typeSourceEnd = argument.type.sourceEnd;
/* 1022 */     TypeReference typeReference = argument.type;
/* 1023 */     int extraDimensions = typeReference.extraDimensions();
/* 1024 */     if (this.ast.apiLevel >= 8) {
/* 1025 */       setExtraAnnotatedDimensions(nameEnd + 1, typeSourceEnd, typeReference, 
/* 1026 */           variableDecl.extraDimensions(), extraDimensions);
/*      */     } else {
/* 1028 */       internalSetExtraDimensions(variableDecl, extraDimensions);
/*      */     } 
/* 1030 */     boolean isVarArgs = argument.isVarArgs();
/* 1031 */     if (isVarArgs && extraDimensions == 0)
/*      */     {
/* 1033 */       argument.type.sourceEnd = retrieveEllipsisStartPosition(argument.type.sourceStart, typeSourceEnd);
/*      */     }
/* 1035 */     Type type = convertType(argument.type);
/* 1036 */     int typeEnd = type.getStartPosition() + type.getLength() - 1;
/* 1037 */     int rightEnd = Math.max(typeEnd, argument.declarationSourceEnd);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1042 */     if (isVarArgs) {
/* 1043 */       Dimension lastDimension = null;
/* 1044 */       if (this.ast.apiLevel() >= 8 && 
/* 1045 */         type.isArrayType()) {
/* 1046 */         List<Dimension> dimensions = ((ArrayType)type).dimensions();
/* 1047 */         if (!dimensions.isEmpty()) {
/* 1048 */           lastDimension = dimensions.get(dimensions.size() - 1);
/*      */         }
/*      */       } 
/*      */       
/* 1052 */       setTypeForSingleVariableDeclaration(variableDecl, type, extraDimensions + 1);
/*      */       
/* 1054 */       if (this.ast.apiLevel() >= 8 && 
/* 1055 */         lastDimension != null) {
/* 1056 */         List annotations = lastDimension.annotations();
/* 1057 */         Iterator<Annotation> iter = annotations.iterator();
/* 1058 */         while (iter.hasNext()) {
/* 1059 */           Annotation annotation = iter.next();
/* 1060 */           annotation.setParent(null, null);
/* 1061 */           variableDecl.varargsAnnotations().add(annotation);
/*      */         } 
/*      */       } 
/*      */       
/* 1065 */       if (extraDimensions != 0) {
/* 1066 */         variableDecl.setFlags(variableDecl.getFlags() | 0x1);
/*      */       }
/*      */     } else {
/* 1069 */       setTypeForSingleVariableDeclaration(variableDecl, type, extraDimensions);
/*      */     } 
/* 1071 */     variableDecl.setSourceRange(argument.declarationSourceStart, rightEnd - argument.declarationSourceStart + 1);
/*      */     
/* 1073 */     if (isVarArgs)
/* 1074 */       switch (this.ast.apiLevel) {
/*      */         case 2:
/* 1076 */           variableDecl.setFlags(variableDecl.getFlags() | 0x1);
/*      */           break;
/*      */         default:
/* 1079 */           variableDecl.setVarargs(true);
/*      */           break;
/*      */       }  
/* 1082 */     if (this.resolveBindings) {
/* 1083 */       recordNodes(name, (ASTNode)argument);
/* 1084 */       recordNodes(variableDecl, (ASTNode)argument);
/* 1085 */       variableDecl.resolveBinding();
/*      */     } 
/* 1087 */     return variableDecl;
/*      */   }
/*      */ 
/*      */   
/*      */   public Annotation convert(Annotation annotation) {
/* 1092 */     if (annotation instanceof SingleMemberAnnotation)
/* 1093 */       return convert((SingleMemberAnnotation)annotation); 
/* 1094 */     if (annotation instanceof MarkerAnnotation) {
/* 1095 */       return convert((MarkerAnnotation)annotation);
/*      */     }
/* 1097 */     return convert((NormalAnnotation)annotation);
/*      */   }
/*      */ 
/*      */   
/*      */   public ArrayCreation convert(ArrayAllocationExpression expression) {
/* 1102 */     ArrayCreation arrayCreation = new ArrayCreation(this.ast);
/* 1103 */     if (this.resolveBindings) {
/* 1104 */       recordNodes(arrayCreation, (ASTNode)expression);
/*      */     }
/* 1106 */     arrayCreation.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 1107 */     Expression[] dimensions = expression.dimensions;
/*      */     
/* 1109 */     int dimensionsLength = dimensions.length;
/* 1110 */     for (int i = 0; i < dimensionsLength; i++) {
/* 1111 */       if (dimensions[i] != null) {
/* 1112 */         Expression dimension = convert(dimensions[i]);
/* 1113 */         if (this.resolveBindings) {
/* 1114 */           recordNodes(dimension, (ASTNode)dimensions[i]);
/*      */         }
/* 1116 */         arrayCreation.dimensions().add(dimension);
/*      */       } 
/*      */     } 
/* 1119 */     Type type = convertType(expression.type);
/* 1120 */     if (this.resolveBindings) {
/* 1121 */       recordNodes(type, (ASTNode)expression.type);
/*      */     }
/* 1123 */     ArrayType arrayType = null;
/* 1124 */     if (type.isArrayType()) {
/* 1125 */       arrayType = (ArrayType)type;
/* 1126 */       if (expression.annotationsOnDimensions != null) {
/* 1127 */         if (this.ast.apiLevel() < 8) {
/* 1128 */           arrayType.setFlags(arrayType.getFlags() | 0x1);
/*      */         } else {
/* 1130 */           setTypeAnnotationsAndSourceRangeOnArray(arrayType, expression.annotationsOnDimensions);
/*      */         } 
/*      */       }
/*      */     } else {
/* 1134 */       arrayType = convertToArray(type, type.getStartPosition(), -1, dimensionsLength, expression.annotationsOnDimensions);
/*      */     } 
/* 1136 */     arrayCreation.setType(arrayType);
/* 1137 */     if (this.resolveBindings) {
/* 1138 */       completeRecord(arrayType, (ASTNode)expression);
/*      */     }
/* 1140 */     if (expression.initializer != null) {
/* 1141 */       arrayCreation.setInitializer(convert(expression.initializer));
/*      */     }
/* 1143 */     return arrayCreation;
/*      */   }
/*      */   
/*      */   public ArrayInitializer convert(ArrayInitializer expression) {
/* 1147 */     ArrayInitializer arrayInitializer = new ArrayInitializer(this.ast);
/* 1148 */     if (this.resolveBindings) {
/* 1149 */       recordNodes(arrayInitializer, (ASTNode)expression);
/*      */     }
/* 1151 */     arrayInitializer.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 1152 */     Expression[] expressions = expression.expressions;
/* 1153 */     if (expressions != null) {
/* 1154 */       int length = expressions.length;
/* 1155 */       for (int i = 0; i < length; i++) {
/* 1156 */         Expression expr = convert(expressions[i]);
/* 1157 */         if (this.resolveBindings) {
/* 1158 */           recordNodes(expr, (ASTNode)expressions[i]);
/*      */         }
/* 1160 */         arrayInitializer.expressions().add(expr);
/*      */       } 
/*      */     } 
/* 1163 */     return arrayInitializer;
/*      */   }
/*      */   
/*      */   public ArrayAccess convert(ArrayReference reference) {
/* 1167 */     ArrayAccess arrayAccess = new ArrayAccess(this.ast);
/* 1168 */     if (this.resolveBindings) {
/* 1169 */       recordNodes(arrayAccess, (ASTNode)reference);
/*      */     }
/* 1171 */     arrayAccess.setSourceRange(reference.sourceStart, reference.sourceEnd - reference.sourceStart + 1);
/* 1172 */     arrayAccess.setArray(convert(reference.receiver));
/* 1173 */     arrayAccess.setIndex(convert(reference.position));
/* 1174 */     return arrayAccess;
/*      */   }
/*      */   
/*      */   public AssertStatement convert(AssertStatement statement) {
/* 1178 */     AssertStatement assertStatement = new AssertStatement(this.ast);
/* 1179 */     Expression assertExpression = convert(statement.assertExpression);
/* 1180 */     Expression searchingNode = assertExpression;
/* 1181 */     assertStatement.setExpression(assertExpression);
/* 1182 */     Expression exceptionArgument = statement.exceptionArgument;
/* 1183 */     if (exceptionArgument != null) {
/* 1184 */       Expression exceptionMessage = convert(exceptionArgument);
/* 1185 */       assertStatement.setMessage(exceptionMessage);
/* 1186 */       searchingNode = exceptionMessage;
/*      */     } 
/* 1188 */     int start = statement.sourceStart;
/* 1189 */     int sourceEnd = retrieveSemiColonPosition(searchingNode);
/* 1190 */     if (sourceEnd == -1) {
/* 1191 */       sourceEnd = searchingNode.getStartPosition() + searchingNode.getLength() - 1;
/* 1192 */       assertStatement.setSourceRange(start, sourceEnd - start + 1);
/*      */     } else {
/* 1194 */       assertStatement.setSourceRange(start, sourceEnd - start + 1);
/*      */     } 
/* 1196 */     return assertStatement;
/*      */   }
/*      */   
/*      */   public Assignment convert(Assignment expression) {
/* 1200 */     Assignment assignment = new Assignment(this.ast);
/* 1201 */     if (this.resolveBindings) {
/* 1202 */       recordNodes(assignment, (ASTNode)expression);
/*      */     }
/* 1204 */     Expression lhs = convert(expression.lhs);
/* 1205 */     assignment.setLeftHandSide(lhs);
/* 1206 */     assignment.setOperator(Assignment.Operator.ASSIGN);
/* 1207 */     Expression rightHandSide = convert(expression.expression);
/* 1208 */     assignment.setRightHandSide(rightHandSide);
/* 1209 */     int start = lhs.getStartPosition();
/* 1210 */     int end = rightHandSide.getStartPosition() + rightHandSide.getLength() - 1;
/* 1211 */     assignment.setSourceRange(start, end - start + 1);
/* 1212 */     return assignment;
/*      */   }
/*      */   
/*      */   public RecordDeclaration convertToRecord(ASTNode[] nodes) {
/* 1216 */     RecordDeclaration typeDecl = new RecordDeclaration(this.ast);
/* 1217 */     ASTNode oldReferenceContext = this.referenceContext;
/* 1218 */     this.referenceContext = typeDecl;
/* 1219 */     getAbstractTypeDeclarationDetails(nodes, typeDecl);
/* 1220 */     this.referenceContext = oldReferenceContext;
/* 1221 */     return typeDecl;
/*      */   }
/*      */ 
/*      */   
/*      */   private void getAbstractTypeDeclarationDetails(ASTNode[] nodes, AbstractTypeDeclaration typeDecl) {
/* 1226 */     int nodesLength = nodes.length;
/* 1227 */     for (int i = 0; i < nodesLength; i++) {
/* 1228 */       ASTNode node = nodes[i];
/* 1229 */       if (node instanceof Initializer) {
/* 1230 */         Initializer oldInitializer = (Initializer)node;
/* 1231 */         Initializer initializer = new Initializer(this.ast);
/* 1232 */         initializer.setBody(convert(oldInitializer.block));
/* 1233 */         setModifiers(initializer, oldInitializer);
/* 1234 */         initializer.setSourceRange(oldInitializer.declarationSourceStart, oldInitializer.sourceEnd - oldInitializer.declarationSourceStart + 1);
/* 1235 */         convert(oldInitializer.javadoc, initializer);
/* 1236 */         typeDecl.bodyDeclarations().add(initializer);
/* 1237 */       } else if (node instanceof FieldDeclaration) {
/* 1238 */         FieldDeclaration fieldDeclaration = (FieldDeclaration)node;
/* 1239 */         if (i > 0 && 
/* 1240 */           nodes[i - 1] instanceof FieldDeclaration && 
/* 1241 */           ((FieldDeclaration)nodes[i - 1]).declarationSourceStart == fieldDeclaration.declarationSourceStart) {
/*      */ 
/*      */           
/* 1244 */           FieldDeclaration currentFieldDeclaration = typeDecl.bodyDeclarations().get(typeDecl.bodyDeclarations().size() - 1);
/* 1245 */           currentFieldDeclaration.fragments().add(convertToVariableDeclarationFragment(fieldDeclaration));
/*      */         } else {
/*      */           
/* 1248 */           typeDecl.bodyDeclarations().add(convertToFieldDeclaration(fieldDeclaration));
/*      */         } 
/* 1250 */       } else if (node instanceof AbstractMethodDeclaration) {
/* 1251 */         AbstractMethodDeclaration nextMethodDeclaration = (AbstractMethodDeclaration)node;
/* 1252 */         if (!nextMethodDeclaration.isDefaultConstructor() && !nextMethodDeclaration.isClinit()) {
/* 1253 */           typeDecl.bodyDeclarations().add(convert(false, nextMethodDeclaration));
/*      */         }
/* 1255 */       } else if (node instanceof TypeDeclaration) {
/* 1256 */         TypeDeclaration nextMemberDeclaration = (TypeDeclaration)node;
/* 1257 */         ASTNode nextMemberDeclarationNode = convert(nextMemberDeclaration);
/* 1258 */         if (nextMemberDeclarationNode == null) {
/* 1259 */           typeDecl.setFlags(typeDecl.getFlags() | 0x1);
/*      */         } else {
/* 1261 */           typeDecl.bodyDeclarations().add(nextMemberDeclarationNode);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeDeclaration convert(ASTNode[] nodes) {
/* 1271 */     TypeDeclaration typeDecl = new TypeDeclaration(this.ast);
/* 1272 */     ASTNode oldReferenceContext = this.referenceContext;
/* 1273 */     this.referenceContext = typeDecl;
/* 1274 */     typeDecl.setInterface(false);
/* 1275 */     getAbstractTypeDeclarationDetails(nodes, typeDecl);
/* 1276 */     this.referenceContext = oldReferenceContext;
/* 1277 */     return typeDecl;
/*      */   }
/*      */   
/*      */   public Expression convert(BinaryExpression expression) {
/* 1281 */     InfixExpression infixExpression = new InfixExpression(this.ast);
/* 1282 */     if (this.resolveBindings) {
/* 1283 */       recordNodes(infixExpression, (ASTNode)expression);
/*      */     }
/*      */     
/* 1286 */     int expressionOperatorID = (expression.bits & 0x3F00) >> 8;
/* 1287 */     infixExpression.setOperator(getOperatorFor(expressionOperatorID));
/*      */     
/* 1289 */     if (expression.left instanceof BinaryExpression && (
/* 1290 */       expression.left.bits & 0x1FE00000) == 0) {
/*      */       
/* 1292 */       infixExpression.extendedOperands().add(convert(expression.right));
/* 1293 */       Expression leftOperand = expression.left;
/* 1294 */       Expression rightOperand = null;
/*      */       do {
/* 1296 */         rightOperand = ((BinaryExpression)leftOperand).right;
/* 1297 */         if (((leftOperand.bits & 0x3F00) >> 8 != expressionOperatorID && (
/* 1298 */           leftOperand.bits & 0x1FE00000) == 0) || (
/* 1299 */           rightOperand instanceof BinaryExpression && (
/* 1300 */           rightOperand.bits & 0x3F00) >> 8 != expressionOperatorID && (
/* 1301 */           rightOperand.bits & 0x1FE00000) == 0)) {
/* 1302 */           List<Expression> extendedOperands = infixExpression.extendedOperands();
/* 1303 */           InfixExpression temp = new InfixExpression(this.ast);
/* 1304 */           if (this.resolveBindings) {
/* 1305 */             recordNodes(temp, (ASTNode)expression);
/*      */           }
/* 1307 */           temp.setOperator(getOperatorFor(expressionOperatorID));
/* 1308 */           Expression leftSide = convert(leftOperand);
/* 1309 */           temp.setLeftOperand(leftSide);
/* 1310 */           temp.setSourceRange(leftSide.getStartPosition(), leftSide.getLength());
/* 1311 */           int size = extendedOperands.size(); int j;
/* 1312 */           for (j = 0; j < size - 1; j++) {
/* 1313 */             Expression expr = temp;
/* 1314 */             temp = new InfixExpression(this.ast);
/*      */             
/* 1316 */             if (this.resolveBindings) {
/* 1317 */               recordNodes(temp, (ASTNode)expression);
/*      */             }
/* 1319 */             temp.setLeftOperand(expr);
/* 1320 */             temp.setOperator(getOperatorFor(expressionOperatorID));
/* 1321 */             temp.setSourceRange(expr.getStartPosition(), expr.getLength());
/*      */           } 
/* 1323 */           infixExpression = temp;
/* 1324 */           for (j = 0; j < size; j++) {
/* 1325 */             Expression extendedOperand = extendedOperands.remove(size - 1 - j);
/* 1326 */             temp.setRightOperand(extendedOperand);
/* 1327 */             int k = temp.getLeftOperand().getStartPosition();
/* 1328 */             temp.setSourceRange(k, extendedOperand.getStartPosition() + extendedOperand.getLength() - k);
/* 1329 */             if (temp.getLeftOperand().getNodeType() == 27) {
/* 1330 */               temp = (InfixExpression)temp.getLeftOperand();
/*      */             }
/*      */           } 
/* 1333 */           setInfixSourcePositions(infixExpression, infixExpression.getLeftOperand().getStartPosition());
/* 1334 */           if (this.resolveBindings) {
/* 1335 */             recordNodes(infixExpression, (ASTNode)expression);
/*      */           }
/* 1337 */           return infixExpression;
/*      */         } 
/* 1339 */         infixExpression.extendedOperands().add(0, convert(rightOperand));
/* 1340 */         leftOperand = ((BinaryExpression)leftOperand).left;
/* 1341 */       } while (leftOperand instanceof BinaryExpression && (leftOperand.bits & 0x1FE00000) == 0);
/* 1342 */       Expression expression1 = convert(leftOperand);
/* 1343 */       infixExpression.setLeftOperand(expression1);
/* 1344 */       infixExpression.setRightOperand(infixExpression.extendedOperands().remove(0));
/* 1345 */       int i = expression1.getStartPosition();
/* 1346 */       setInfixSourcePositions(infixExpression, i);
/* 1347 */       return infixExpression;
/* 1348 */     }  if (expression.left instanceof StringLiteralConcatenation && (
/* 1349 */       expression.left.bits & 0x1FE00000) == 0 && 
/* 1350 */       14 == expressionOperatorID) {
/* 1351 */       StringLiteralConcatenation literal = (StringLiteralConcatenation)expression.left;
/* 1352 */       Expression[] stringLiterals = literal.literals;
/* 1353 */       infixExpression.setLeftOperand(convert(stringLiterals[0]));
/* 1354 */       infixExpression.setRightOperand(convert(stringLiterals[1]));
/* 1355 */       for (int i = 2; i < literal.counter; i++) {
/* 1356 */         infixExpression.extendedOperands().add(convert(stringLiterals[i]));
/*      */       }
/* 1358 */       infixExpression.extendedOperands().add(convert(expression.right));
/* 1359 */       int j = literal.sourceStart;
/* 1360 */       setInfixSourcePositions(infixExpression, j);
/* 1361 */       return infixExpression;
/*      */     } 
/* 1363 */     Expression leftExpression = convert(expression.left);
/* 1364 */     infixExpression.setLeftOperand(leftExpression);
/* 1365 */     infixExpression.setRightOperand(convert(expression.right));
/* 1366 */     int startPosition = leftExpression.getStartPosition();
/* 1367 */     setInfixSourcePositions(infixExpression, startPosition);
/* 1368 */     return infixExpression;
/*      */   }
/*      */   
/*      */   public Block convert(Block statement) {
/* 1372 */     Block block = new Block(this.ast);
/* 1373 */     if (statement.sourceEnd > 0) {
/* 1374 */       block.setSourceRange(statement.sourceStart, statement.sourceEnd - statement.sourceStart + 1);
/*      */     }
/* 1376 */     Statement[] statements = statement.statements;
/* 1377 */     if (statements != null) {
/* 1378 */       int statementsLength = statements.length;
/* 1379 */       for (int i = 0; i < statementsLength; i++) {
/* 1380 */         if (statements[i] instanceof LocalDeclaration) {
/* 1381 */           checkAndAddMultipleLocalDeclaration(statements, i, block.statements());
/*      */         } else {
/* 1383 */           Statement statement2 = convert(statements[i]);
/* 1384 */           if (statement2 != null) {
/* 1385 */             block.statements().add(statement2);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 1390 */     return block;
/*      */   }
/*      */   
/*      */   public BreakStatement convert(BreakStatement statement) {
/* 1394 */     BreakStatement breakStatement = new BreakStatement(this.ast);
/* 1395 */     breakStatement.setSourceRange(statement.sourceStart, statement.sourceEnd - statement.sourceStart + 1);
/* 1396 */     if (statement.label != null) {
/* 1397 */       SimpleName name = new SimpleName(this.ast);
/* 1398 */       name.internalSetIdentifier(new String(statement.label));
/* 1399 */       retrieveIdentifierAndSetPositions(statement.sourceStart, statement.sourceEnd, name);
/* 1400 */       breakStatement.setLabel(name);
/*      */     } 
/* 1402 */     return breakStatement;
/*      */   }
/*      */   
/*      */   public SwitchCase convert(CaseStatement statement) {
/* 1406 */     SwitchCase switchCase = new SwitchCase(this.ast);
/* 1407 */     if (this.ast.apiLevel >= 14) {
/* 1408 */       Expression[] expressions = statement.constantExpressions;
/* 1409 */       if (expressions == null || expressions.length == 0) {
/* 1410 */         switchCase.expressions().clear();
/* 1411 */       } else if (expressions.length == 1 && expressions[0] instanceof FakeDefaultLiteral) {
/* 1412 */         switchCase.expressions().add(convert((FakeDefaultLiteral)expressions[0]));
/*      */       } else {
/* 1414 */         byte b; int i; Expression[] arrayOfExpression; for (i = (arrayOfExpression = expressions).length, b = 0; b < i; ) { Expression expression = arrayOfExpression[b];
/* 1415 */           switchCase.expressions().add(convert(expression)); b++; }
/*      */       
/*      */       } 
/*      */     } else {
/* 1419 */       Expression[] constantExpressions = statement.constantExpressions;
/* 1420 */       Expression constantExpression = 
/* 1421 */         (constantExpressions != null && constantExpressions.length > 0) ? constantExpressions[0] : null;
/* 1422 */       if (constantExpression == null) {
/* 1423 */         internalSetExpression(switchCase, null);
/*      */       } else {
/* 1425 */         internalSetExpression(switchCase, convert(constantExpression));
/*      */       } 
/*      */     } 
/* 1428 */     if (this.ast.apiLevel >= 14) {
/* 1429 */       switchCase.setSwitchLabeledRule(statement.isExpr);
/*      */     }
/* 1431 */     switchCase.setSourceRange(statement.sourceStart, statement.sourceEnd - statement.sourceStart + 1);
/* 1432 */     if (statement.isExpr) {
/* 1433 */       retrieveArrowPosition(switchCase);
/*      */     } else {
/* 1435 */       retrieveColonPosition(switchCase);
/*      */     } 
/* 1437 */     return switchCase;
/*      */   }
/*      */   
/*      */   public Expression convert(FakeDefaultLiteral fakeDefaultLiteral) {
/* 1441 */     CaseDefaultExpression caseDefaultExpression = new CaseDefaultExpression(this.ast);
/* 1442 */     caseDefaultExpression.setSourceRange(fakeDefaultLiteral.sourceStart, fakeDefaultLiteral.sourceEnd - fakeDefaultLiteral.sourceStart + 1);
/* 1443 */     return caseDefaultExpression;
/*      */   }
/*      */   
/*      */   public CastExpression convert(CastExpression expression) {
/* 1447 */     CastExpression castExpression = new CastExpression(this.ast);
/* 1448 */     castExpression.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 1449 */     TypeReference type = expression.type;
/* 1450 */     trimWhiteSpacesAndComments((Expression)type);
/* 1451 */     castExpression.setType(convertType(type));
/* 1452 */     castExpression.setExpression(convert(expression.expression));
/* 1453 */     if (this.resolveBindings) {
/* 1454 */       recordNodes(castExpression, (ASTNode)expression);
/*      */     }
/* 1456 */     return castExpression;
/*      */   }
/*      */   
/*      */   public CharacterLiteral convert(CharLiteral expression) {
/* 1460 */     int length = expression.sourceEnd - expression.sourceStart + 1;
/* 1461 */     int sourceStart = expression.sourceStart;
/* 1462 */     CharacterLiteral literal = new CharacterLiteral(this.ast);
/* 1463 */     if (this.resolveBindings) {
/* 1464 */       recordNodes(literal, (ASTNode)expression);
/*      */     }
/* 1466 */     literal.internalSetEscapedValue(new String(this.compilationUnitSource, sourceStart, length));
/* 1467 */     literal.setSourceRange(sourceStart, length);
/* 1468 */     removeLeadingAndTrailingCommentsFromLiteral(literal);
/* 1469 */     return literal;
/*      */   }
/*      */   public Expression convert(ClassLiteralAccess expression) {
/* 1472 */     TypeLiteral typeLiteral = new TypeLiteral(this.ast);
/* 1473 */     if (this.resolveBindings) {
/* 1474 */       recordNodes(typeLiteral, (ASTNode)expression);
/*      */     }
/* 1476 */     typeLiteral.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 1477 */     typeLiteral.setType(convertType(expression.type));
/* 1478 */     return typeLiteral;
/*      */   }
/*      */   
/*      */   public CompilationUnit convert(CompilationUnitDeclaration unit, char[] source) {
/*      */     try {
/* 1483 */       if (unit.compilationResult.recoveryScannerData != null) {
/* 1484 */         RecoveryScanner recoveryScanner = new RecoveryScanner(this.scanner, unit.compilationResult.recoveryScannerData.removeUnused());
/* 1485 */         this.scanner = (Scanner)recoveryScanner;
/* 1486 */         this.docParser.scanner = this.scanner;
/*      */       } 
/* 1488 */       this.compilationUnitSource = source;
/* 1489 */       this.compilationUnitSourceLength = source.length;
/* 1490 */       this.scanner.setSource(source, unit.compilationResult);
/* 1491 */       CompilationUnit compilationUnit = new CompilationUnit(this.ast);
/* 1492 */       compilationUnit.setStatementsRecoveryData(unit.compilationResult.recoveryScannerData);
/*      */ 
/*      */       
/* 1495 */       int[][] comments = unit.comments;
/* 1496 */       if (comments != null) {
/* 1497 */         buildCommentsTable(compilationUnit, comments);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1502 */       if (this.resolveBindings) {
/* 1503 */         recordNodes(compilationUnit, (ASTNode)unit);
/*      */       }
/* 1505 */       if (unit.currentPackage != null) {
/* 1506 */         PackageDeclaration packageDeclaration = convertPackage(unit);
/* 1507 */         compilationUnit.setPackage(packageDeclaration);
/*      */       } 
/* 1509 */       ImportReference[] imports = unit.imports;
/* 1510 */       if (imports != null) {
/* 1511 */         int importLength = imports.length;
/* 1512 */         for (int i = 0; i < importLength; i++) {
/* 1513 */           compilationUnit.imports().add(convertImport(imports[i]));
/*      */         }
/*      */       } 
/*      */       
/* 1517 */       ModuleDeclaration mod = unit.moduleDeclaration;
/* 1518 */       if (mod != null) {
/* 1519 */         ASTNode declaration = convertToModuleDeclaration(mod);
/* 1520 */         if (declaration == null) {
/* 1521 */           compilationUnit.setFlags(compilationUnit.getFlags() | 0x1);
/*      */         } else {
/* 1523 */           compilationUnit.setModule((ModuleDeclaration)declaration);
/*      */         } 
/*      */       } else {
/* 1526 */         TypeDeclaration[] types = unit.types;
/* 1527 */         if (types != null) {
/* 1528 */           int typesLength = types.length;
/* 1529 */           for (int i = 0; i < typesLength; i++) {
/* 1530 */             TypeDeclaration declaration = types[i];
/* 1531 */             if (!CharOperation.equals(declaration.name, TypeConstants.PACKAGE_INFO_NAME)) {
/*      */ 
/*      */               
/* 1534 */               ASTNode type = convert(declaration);
/* 1535 */               if (type == null) {
/* 1536 */                 compilationUnit.setFlags(compilationUnit.getFlags() | 0x1);
/*      */               }
/* 1538 */               else if (type instanceof ModuleDeclaration) {
/* 1539 */                 compilationUnit.setModule((ModuleDeclaration)type);
/*      */               } else {
/* 1541 */                 compilationUnit.types().add(type);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/* 1546 */       }  compilationUnit.setSourceRange(unit.sourceStart, unit.sourceEnd - unit.sourceStart + 1);
/*      */       
/* 1548 */       int problemLength = unit.compilationResult.problemCount;
/* 1549 */       if (problemLength != 0) {
/* 1550 */         CategorizedProblem[] resizedProblems = null;
/* 1551 */         CategorizedProblem[] problems = unit.compilationResult.getProblems();
/* 1552 */         int realProblemLength = problems.length;
/* 1553 */         if (realProblemLength == problemLength) {
/* 1554 */           resizedProblems = problems;
/*      */         } else {
/* 1556 */           System.arraycopy(problems, 0, resizedProblems = new CategorizedProblem[realProblemLength], 0, realProblemLength);
/*      */         } 
/* 1558 */         ASTSyntaxErrorPropagator syntaxErrorPropagator = new ASTSyntaxErrorPropagator(resizedProblems);
/* 1559 */         compilationUnit.accept(syntaxErrorPropagator);
/* 1560 */         ASTRecoveryPropagator recoveryPropagator = 
/* 1561 */           new ASTRecoveryPropagator(resizedProblems, unit.compilationResult.recoveryScannerData);
/* 1562 */         compilationUnit.accept(recoveryPropagator);
/* 1563 */         compilationUnit.setProblems((IProblem[])resizedProblems);
/*      */       } 
/* 1565 */       if (this.resolveBindings) {
/* 1566 */         lookupForScopes();
/*      */       }
/* 1568 */       compilationUnit.initCommentMapper(this.scanner);
/* 1569 */       if (SourceRangeVerifier.DEBUG) {
/* 1570 */         String bugs = (new SourceRangeVerifier()).process(compilationUnit);
/* 1571 */         if (bugs != null) {
/* 1572 */           StringBuilder message = new StringBuilder("Bad AST node structure:");
/* 1573 */           String lineDelimiter = Util.findLineSeparator(source);
/* 1574 */           if (lineDelimiter == null) lineDelimiter = System.getProperty("line.separator"); 
/* 1575 */           message.append(lineDelimiter);
/* 1576 */           message.append(bugs.replace("\n", lineDelimiter));
/* 1577 */           message.append(lineDelimiter);
/* 1578 */           message.append("----------------------------------- SOURCE BEGIN -------------------------------------");
/* 1579 */           message.append(lineDelimiter);
/* 1580 */           message.append(source);
/* 1581 */           message.append(lineDelimiter);
/* 1582 */           message.append("----------------------------------- SOURCE END -------------------------------------");
/* 1583 */           Util.log(new IllegalStateException("Bad AST node structure"), message.toString());
/* 1584 */           if (SourceRangeVerifier.DEBUG_THROW) {
/* 1585 */             throw new IllegalStateException(message.toString());
/*      */           }
/*      */         } 
/*      */       } 
/* 1589 */       return compilationUnit;
/* 1590 */     } catch (IllegalArgumentException e) {
/* 1591 */       StringBuilder message = new StringBuilder("Exception occurred during compilation unit conversion:");
/* 1592 */       String lineDelimiter = Util.findLineSeparator(source);
/* 1593 */       if (lineDelimiter == null) lineDelimiter = System.getProperty("line.separator"); 
/* 1594 */       message.append(lineDelimiter);
/* 1595 */       message.append("----------------------------------- SOURCE BEGIN -------------------------------------");
/* 1596 */       message.append(lineDelimiter);
/* 1597 */       message.append(source);
/* 1598 */       message.append(lineDelimiter);
/* 1599 */       message.append("----------------------------------- SOURCE END -------------------------------------");
/* 1600 */       Util.log(e, message.toString());
/* 1601 */       throw e;
/*      */     } 
/*      */   }
/*      */   
/*      */   public SingleVariableDeclaration convert(RecordComponent component) {
/* 1606 */     SingleVariableDeclaration variableDecl = new SingleVariableDeclaration(this.ast);
/* 1607 */     setModifiers(variableDecl, component);
/* 1608 */     SimpleName name = new SimpleName(this.ast);
/* 1609 */     name.internalSetIdentifier(new String(component.name));
/* 1610 */     int start = component.sourceStart;
/* 1611 */     int nameEnd = component.sourceEnd;
/* 1612 */     name.setSourceRange(start, nameEnd - start + 1);
/* 1613 */     variableDecl.setName(name);
/* 1614 */     int typeSourceEnd = component.type.sourceEnd;
/* 1615 */     TypeReference typeReference = component.type;
/* 1616 */     int extraDimensions = typeReference.extraDimensions();
/* 1617 */     if (this.ast.apiLevel >= 8) {
/* 1618 */       setExtraAnnotatedDimensions(nameEnd + 1, typeSourceEnd, typeReference, 
/* 1619 */           variableDecl.extraDimensions(), extraDimensions);
/*      */     } else {
/* 1621 */       internalSetExtraDimensions(variableDecl, extraDimensions);
/*      */     } 
/* 1623 */     boolean isVarArgs = component.isVarArgs();
/* 1624 */     if (isVarArgs && extraDimensions == 0)
/*      */     {
/* 1626 */       component.type.sourceEnd = retrieveEllipsisStartPosition(component.type.sourceStart, typeSourceEnd);
/*      */     }
/* 1628 */     Type type = convertType(component.type);
/* 1629 */     int typeEnd = type.getStartPosition() + type.getLength() - 1;
/* 1630 */     int rightEnd = Math.max(typeEnd, component.declarationSourceEnd);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1635 */     if (isVarArgs) {
/* 1636 */       Dimension lastDimension = null;
/* 1637 */       if (this.ast.apiLevel() >= 8 && 
/* 1638 */         type.isArrayType()) {
/* 1639 */         List<Dimension> dimensions = ((ArrayType)type).dimensions();
/* 1640 */         if (!dimensions.isEmpty()) {
/* 1641 */           lastDimension = dimensions.get(dimensions.size() - 1);
/*      */         }
/*      */       } 
/*      */       
/* 1645 */       setTypeForSingleVariableDeclaration(variableDecl, type, extraDimensions + 1);
/*      */       
/* 1647 */       if (this.ast.apiLevel() >= 8 && 
/* 1648 */         lastDimension != null) {
/* 1649 */         List annotations = lastDimension.annotations();
/* 1650 */         Iterator<Annotation> iter = annotations.iterator();
/* 1651 */         while (iter.hasNext()) {
/* 1652 */           Annotation annotation = iter.next();
/* 1653 */           annotation.setParent(null, null);
/* 1654 */           variableDecl.varargsAnnotations().add(annotation);
/*      */         } 
/*      */       } 
/*      */       
/* 1658 */       if (extraDimensions != 0) {
/* 1659 */         variableDecl.setFlags(variableDecl.getFlags() | 0x1);
/*      */       }
/*      */     } else {
/* 1662 */       setTypeForSingleVariableDeclaration(variableDecl, type, extraDimensions);
/*      */     } 
/* 1664 */     variableDecl.setSourceRange(component.declarationSourceStart, rightEnd - component.declarationSourceStart + 1);
/*      */     
/* 1666 */     if (isVarArgs)
/* 1667 */       switch (this.ast.apiLevel) {
/*      */         case 2:
/* 1669 */           variableDecl.setFlags(variableDecl.getFlags() | 0x1);
/*      */           break;
/*      */         default:
/* 1672 */           variableDecl.setVarargs(true);
/*      */           break;
/*      */       }  
/* 1675 */     if (this.resolveBindings) {
/* 1676 */       recordNodes(name, (ASTNode)component);
/* 1677 */       recordNodes(variableDecl, (ASTNode)component);
/* 1678 */       variableDecl.resolveBinding();
/*      */     } 
/* 1680 */     return variableDecl;
/*      */   }
/*      */   
/*      */   public Assignment convert(CompoundAssignment expression) {
/* 1684 */     Assignment assignment = new Assignment(this.ast);
/* 1685 */     Expression lhs = convert(expression.lhs);
/* 1686 */     assignment.setLeftHandSide(lhs);
/* 1687 */     int start = lhs.getStartPosition();
/* 1688 */     assignment.setSourceRange(start, expression.sourceEnd - start + 1);
/* 1689 */     switch (expression.operator) {
/*      */       case 14:
/* 1691 */         assignment.setOperator(Assignment.Operator.PLUS_ASSIGN);
/*      */         break;
/*      */       case 13:
/* 1694 */         assignment.setOperator(Assignment.Operator.MINUS_ASSIGN);
/*      */         break;
/*      */       case 15:
/* 1697 */         assignment.setOperator(Assignment.Operator.TIMES_ASSIGN);
/*      */         break;
/*      */       case 9:
/* 1700 */         assignment.setOperator(Assignment.Operator.DIVIDE_ASSIGN);
/*      */         break;
/*      */       case 2:
/* 1703 */         assignment.setOperator(Assignment.Operator.BIT_AND_ASSIGN);
/*      */         break;
/*      */       case 3:
/* 1706 */         assignment.setOperator(Assignment.Operator.BIT_OR_ASSIGN);
/*      */         break;
/*      */       case 8:
/* 1709 */         assignment.setOperator(Assignment.Operator.BIT_XOR_ASSIGN);
/*      */         break;
/*      */       case 16:
/* 1712 */         assignment.setOperator(Assignment.Operator.REMAINDER_ASSIGN);
/*      */         break;
/*      */       case 10:
/* 1715 */         assignment.setOperator(Assignment.Operator.LEFT_SHIFT_ASSIGN);
/*      */         break;
/*      */       case 17:
/* 1718 */         assignment.setOperator(Assignment.Operator.RIGHT_SHIFT_SIGNED_ASSIGN);
/*      */         break;
/*      */       case 19:
/* 1721 */         assignment.setOperator(Assignment.Operator.RIGHT_SHIFT_UNSIGNED_ASSIGN);
/*      */         break;
/*      */     } 
/* 1724 */     assignment.setRightHandSide(convert(expression.expression));
/* 1725 */     if (this.resolveBindings) {
/* 1726 */       recordNodes(assignment, (ASTNode)expression);
/*      */     }
/* 1728 */     return assignment;
/*      */   }
/*      */   
/*      */   public ConditionalExpression convert(ConditionalExpression expression) {
/* 1732 */     ConditionalExpression conditionalExpression = new ConditionalExpression(this.ast);
/* 1733 */     if (this.resolveBindings) {
/* 1734 */       recordNodes(conditionalExpression, (ASTNode)expression);
/*      */     }
/* 1736 */     conditionalExpression.setExpression(convert(expression.condition));
/* 1737 */     conditionalExpression.setThenExpression(convert(expression.valueIfTrue));
/* 1738 */     Expression elseExpression = convert(expression.valueIfFalse);
/* 1739 */     conditionalExpression.setElseExpression(elseExpression);
/* 1740 */     conditionalExpression.setSourceRange(expression.sourceStart, elseExpression.getStartPosition() + elseExpression.getLength() - expression.sourceStart);
/* 1741 */     return conditionalExpression;
/*      */   }
/*      */   
/*      */   public ContinueStatement convert(ContinueStatement statement) {
/* 1745 */     ContinueStatement continueStatement = new ContinueStatement(this.ast);
/* 1746 */     continueStatement.setSourceRange(statement.sourceStart, statement.sourceEnd - statement.sourceStart + 1);
/* 1747 */     if (statement.label != null) {
/* 1748 */       SimpleName name = new SimpleName(this.ast);
/* 1749 */       name.internalSetIdentifier(new String(statement.label));
/* 1750 */       retrieveIdentifierAndSetPositions(statement.sourceStart, statement.sourceEnd, name);
/* 1751 */       continueStatement.setLabel(name);
/*      */     } 
/* 1753 */     return continueStatement;
/*      */   }
/*      */   
/*      */   public DoStatement convert(DoStatement statement) {
/* 1757 */     DoStatement doStatement = new DoStatement(this.ast);
/* 1758 */     doStatement.setSourceRange(statement.sourceStart, statement.sourceEnd - statement.sourceStart + 1);
/* 1759 */     doStatement.setExpression(convert(statement.condition));
/* 1760 */     Statement action = convert(statement.action);
/* 1761 */     if (action == null) return null; 
/* 1762 */     doStatement.setBody(action);
/* 1763 */     return doStatement;
/*      */   }
/*      */   
/*      */   public NumberLiteral convert(DoubleLiteral expression) {
/* 1767 */     int length = expression.sourceEnd - expression.sourceStart + 1;
/* 1768 */     int sourceStart = expression.sourceStart;
/* 1769 */     NumberLiteral literal = new NumberLiteral(this.ast);
/* 1770 */     literal.internalSetToken(new String(this.compilationUnitSource, sourceStart, length));
/* 1771 */     if (this.resolveBindings) {
/* 1772 */       recordNodes(literal, (ASTNode)expression);
/*      */     }
/* 1774 */     literal.setSourceRange(sourceStart, length);
/* 1775 */     removeLeadingAndTrailingCommentsFromLiteral(literal);
/* 1776 */     return literal;
/*      */   }
/*      */   
/*      */   public EmptyStatement convert(EmptyStatement statement) {
/* 1780 */     EmptyStatement emptyStatement = new EmptyStatement(this.ast);
/* 1781 */     emptyStatement.setSourceRange(statement.sourceStart, statement.sourceEnd - statement.sourceStart + 1);
/* 1782 */     return emptyStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   public EnumConstantDeclaration convert(FieldDeclaration enumConstant) {
/* 1787 */     checkCanceled();
/* 1788 */     EnumConstantDeclaration enumConstantDeclaration = new EnumConstantDeclaration(this.ast);
/* 1789 */     SimpleName typeName = new SimpleName(this.ast);
/* 1790 */     typeName.internalSetIdentifier(new String(enumConstant.name));
/* 1791 */     typeName.setSourceRange(enumConstant.sourceStart, enumConstant.sourceEnd - enumConstant.sourceStart + 1);
/* 1792 */     enumConstantDeclaration.setName(typeName);
/* 1793 */     int declarationSourceStart = enumConstant.declarationSourceStart;
/* 1794 */     int declarationSourceEnd = enumConstant.declarationSourceEnd;
/* 1795 */     Expression initialization = enumConstant.initialization;
/* 1796 */     if (initialization != null) {
/* 1797 */       if (initialization instanceof QualifiedAllocationExpression) {
/* 1798 */         TypeDeclaration anonymousType = ((QualifiedAllocationExpression)initialization).anonymousType;
/* 1799 */         if (anonymousType != null) {
/* 1800 */           AnonymousClassDeclaration anonymousClassDeclaration = new AnonymousClassDeclaration(this.ast);
/* 1801 */           int start = retrieveStartBlockPosition(anonymousType.sourceEnd, anonymousType.bodyEnd);
/* 1802 */           int end = retrieveRightBrace(anonymousType.bodyEnd + 1, declarationSourceEnd);
/* 1803 */           if (end == -1) end = anonymousType.bodyEnd; 
/* 1804 */           anonymousClassDeclaration.setSourceRange(start, end - start + 1);
/* 1805 */           enumConstantDeclaration.setAnonymousClassDeclaration(anonymousClassDeclaration);
/* 1806 */           buildBodyDeclarations(anonymousType, anonymousClassDeclaration);
/* 1807 */           if (this.resolveBindings) {
/* 1808 */             recordNodes(anonymousClassDeclaration, (ASTNode)anonymousType);
/* 1809 */             anonymousClassDeclaration.resolveBinding();
/*      */           } 
/* 1811 */           enumConstantDeclaration.setSourceRange(declarationSourceStart, end - declarationSourceStart + 1);
/*      */         } 
/*      */       } else {
/* 1814 */         enumConstantDeclaration.setSourceRange(declarationSourceStart, declarationSourceEnd - declarationSourceStart + 1);
/*      */       } 
/* 1816 */       Expression[] arguments = ((AllocationExpression)initialization).arguments;
/* 1817 */       if (arguments != null) {
/* 1818 */         for (int i = 0, max = arguments.length; i < max; i++) {
/* 1819 */           enumConstantDeclaration.arguments().add(convert(arguments[i]));
/*      */         }
/*      */       }
/*      */     } else {
/* 1823 */       enumConstantDeclaration.setSourceRange(declarationSourceStart, declarationSourceEnd - declarationSourceStart + 1);
/*      */     } 
/* 1825 */     setModifiers(enumConstantDeclaration, enumConstant);
/* 1826 */     if (this.resolveBindings) {
/* 1827 */       recordNodes(enumConstantDeclaration, (ASTNode)enumConstant);
/* 1828 */       recordNodes(typeName, (ASTNode)enumConstant);
/* 1829 */       enumConstantDeclaration.resolveVariable();
/*      */     } 
/* 1831 */     convert(enumConstant.javadoc, enumConstantDeclaration);
/* 1832 */     return enumConstantDeclaration;
/*      */   }
/*      */   
/*      */   public Expression convert(EqualExpression expression) {
/* 1836 */     InfixExpression infixExpression = new InfixExpression(this.ast);
/* 1837 */     if (this.resolveBindings) {
/* 1838 */       recordNodes(infixExpression, (ASTNode)expression);
/*      */     }
/* 1840 */     Expression leftExpression = convert(expression.left);
/* 1841 */     infixExpression.setLeftOperand(leftExpression);
/* 1842 */     infixExpression.setRightOperand(convert(expression.right));
/* 1843 */     int startPosition = leftExpression.getStartPosition();
/* 1844 */     setInfixSourcePositions(infixExpression, startPosition);
/* 1845 */     switch ((expression.bits & 0x3F00) >> 8) {
/*      */       case 18:
/* 1847 */         infixExpression.setOperator(InfixExpression.Operator.EQUALS);
/*      */         break;
/*      */       case 29:
/* 1850 */         infixExpression.setOperator(InfixExpression.Operator.NOT_EQUALS); break;
/*      */     } 
/* 1852 */     return infixExpression;
/*      */   }
/*      */ 
/*      */   
/*      */   public Statement convert(ExplicitConstructorCall statement) {
/*      */     Statement newStatement;
/* 1858 */     int sourceStart = statement.sourceStart;
/* 1859 */     if (statement.isSuperAccess() || statement.isSuper()) {
/* 1860 */       SuperConstructorInvocation superConstructorInvocation = new SuperConstructorInvocation(this.ast);
/* 1861 */       if (statement.qualification != null) {
/* 1862 */         superConstructorInvocation.setExpression(convert(statement.qualification));
/*      */       }
/* 1864 */       Expression[] arguments = statement.arguments;
/* 1865 */       if (arguments != null) {
/* 1866 */         int length = arguments.length;
/* 1867 */         for (int i = 0; i < length; i++) {
/* 1868 */           superConstructorInvocation.arguments().add(convert(arguments[i]));
/*      */         }
/*      */       } 
/* 1871 */       if (statement.typeArguments != null) {
/* 1872 */         int i; int max; if (sourceStart > statement.typeArgumentsSourceStart) {
/* 1873 */           sourceStart = statement.typeArgumentsSourceStart;
/*      */         }
/* 1875 */         switch (this.ast.apiLevel) {
/*      */           case 2:
/* 1877 */             superConstructorInvocation.setFlags(superConstructorInvocation.getFlags() | 0x1);
/*      */             break;
/*      */           default:
/* 1880 */             for (i = 0, max = statement.typeArguments.length; i < max; i++) {
/* 1881 */               superConstructorInvocation.typeArguments().add(convertType(statement.typeArguments[i]));
/*      */             }
/*      */             break;
/*      */         } 
/*      */       } 
/* 1886 */       newStatement = superConstructorInvocation;
/*      */     } else {
/* 1888 */       ConstructorInvocation constructorInvocation = new ConstructorInvocation(this.ast);
/* 1889 */       Expression[] arguments = statement.arguments;
/* 1890 */       if (arguments != null) {
/* 1891 */         int length = arguments.length;
/* 1892 */         for (int i = 0; i < length; i++) {
/* 1893 */           constructorInvocation.arguments().add(convert(arguments[i]));
/*      */         }
/*      */       } 
/* 1896 */       if (statement.typeArguments != null) {
/* 1897 */         int i; int max; if (sourceStart > statement.typeArgumentsSourceStart) {
/* 1898 */           sourceStart = statement.typeArgumentsSourceStart;
/*      */         }
/* 1900 */         switch (this.ast.apiLevel) {
/*      */           case 2:
/* 1902 */             constructorInvocation.setFlags(constructorInvocation.getFlags() | 0x1);
/*      */             break;
/*      */           default:
/* 1905 */             for (i = 0, max = statement.typeArguments.length; i < max; i++)
/* 1906 */               constructorInvocation.typeArguments().add(convertType(statement.typeArguments[i]));  break;
/*      */         } 
/* 1908 */       }  if (statement
/*      */ 
/*      */         
/* 1911 */         .qualification != null)
/*      */       {
/* 1913 */         constructorInvocation.setFlags(constructorInvocation.getFlags() | 0x1);
/*      */       }
/* 1915 */       newStatement = constructorInvocation;
/*      */     } 
/* 1917 */     newStatement.setSourceRange(sourceStart, statement.sourceEnd - sourceStart + 1);
/* 1918 */     if (this.resolveBindings) {
/* 1919 */       recordNodes(newStatement, (ASTNode)statement);
/*      */     }
/* 1921 */     return newStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   private ModulePackageAccess getPackageVisibilityStatement(PackageVisibilityStatement pvsStmt, ModulePackageAccess stmt) {
/* 1926 */     int sourceEnd = pvsStmt.declarationSourceEnd;
/* 1927 */     if (pvsStmt.declarationEnd > sourceEnd) sourceEnd = pvsStmt.declarationEnd; 
/* 1928 */     Name name = getImportName(pvsStmt.pkgRef);
/* 1929 */     stmt.setName(name);
/* 1930 */     if (this.resolveBindings) {
/* 1931 */       recordNodes(name, (ASTNode)pvsStmt.pkgRef);
/*      */     }
/* 1933 */     int tmp = sourceEnd;
/* 1934 */     if (pvsStmt.targets != null && pvsStmt.targets.length > 0) {
/* 1935 */       List<Name> modules = stmt.modules(); byte b; int i; ModuleReference[] arrayOfModuleReference;
/* 1936 */       for (i = (arrayOfModuleReference = pvsStmt.getTargetedModules()).length, b = 0; b < i; ) { ModuleReference moduleRef = arrayOfModuleReference[b];
/* 1937 */         Name target = getName((ASTNode)moduleRef, CharOperation.splitOn('.', moduleRef.moduleName), moduleRef.sourcePositions);
/* 1938 */         modules.add(target);
/* 1939 */         if (tmp < moduleRef.sourceEnd) tmp = moduleRef.sourceEnd; 
/* 1940 */         if (this.resolveBindings) {
/* 1941 */           recordNodes(target, (ASTNode)moduleRef);
/*      */         }
/*      */         b++; }
/*      */     
/*      */     } 
/* 1946 */     if (tmp > sourceEnd) sourceEnd = tmp; 
/* 1947 */     stmt.setSourceRange(pvsStmt.declarationSourceStart, sourceEnd - pvsStmt.declarationSourceStart + 1);
/* 1948 */     return stmt;
/*      */   }
/*      */   
/*      */   public Expression convert(Expression expression) {
/* 1952 */     if ((expression.bits & 0x1FE00000) != 0) {
/* 1953 */       return convertToParenthesizedExpression(expression);
/*      */     }
/* 1955 */     if (expression instanceof Annotation) {
/* 1956 */       return convert((Annotation)expression);
/*      */     }
/* 1958 */     if (expression instanceof CastExpression) {
/* 1959 */       return convert((CastExpression)expression);
/*      */     }
/*      */     
/* 1962 */     if (expression instanceof ArrayAllocationExpression) {
/* 1963 */       return convert((ArrayAllocationExpression)expression);
/*      */     }
/* 1965 */     if (expression instanceof QualifiedAllocationExpression) {
/* 1966 */       return convert((QualifiedAllocationExpression)expression);
/*      */     }
/* 1968 */     if (expression instanceof AllocationExpression) {
/* 1969 */       return convert((AllocationExpression)expression);
/*      */     }
/* 1971 */     if (expression instanceof ArrayInitializer) {
/* 1972 */       return convert((ArrayInitializer)expression);
/*      */     }
/* 1974 */     if (expression instanceof FakeDefaultLiteral) {
/* 1975 */       return convert((FakeDefaultLiteral)expression);
/*      */     }
/* 1977 */     if (expression instanceof Pattern) {
/* 1978 */       return convert((Pattern)expression);
/*      */     }
/* 1980 */     if (expression instanceof PrefixExpression) {
/* 1981 */       return convert((PrefixExpression)expression);
/*      */     }
/* 1983 */     if (expression instanceof PostfixExpression) {
/* 1984 */       return convert((PostfixExpression)expression);
/*      */     }
/* 1986 */     if (expression instanceof CompoundAssignment) {
/* 1987 */       return convert((CompoundAssignment)expression);
/*      */     }
/* 1989 */     if (expression instanceof Assignment) {
/* 1990 */       return convert((Assignment)expression);
/*      */     }
/* 1992 */     if (expression instanceof ClassLiteralAccess) {
/* 1993 */       return convert((ClassLiteralAccess)expression);
/*      */     }
/* 1995 */     if (expression instanceof FalseLiteral) {
/* 1996 */       return convert((FalseLiteral)expression);
/*      */     }
/* 1998 */     if (expression instanceof TrueLiteral) {
/* 1999 */       return convert((TrueLiteral)expression);
/*      */     }
/* 2001 */     if (expression instanceof NullLiteral) {
/* 2002 */       return convert((NullLiteral)expression);
/*      */     }
/* 2004 */     if (expression instanceof CharLiteral) {
/* 2005 */       return convert((CharLiteral)expression);
/*      */     }
/* 2007 */     if (expression instanceof DoubleLiteral) {
/* 2008 */       return convert((DoubleLiteral)expression);
/*      */     }
/* 2010 */     if (expression instanceof FloatLiteral) {
/* 2011 */       return convert((FloatLiteral)expression);
/*      */     }
/* 2013 */     if (expression instanceof IntLiteralMinValue) {
/* 2014 */       return convert((IntLiteralMinValue)expression);
/*      */     }
/* 2016 */     if (expression instanceof IntLiteral) {
/* 2017 */       return convert((IntLiteral)expression);
/*      */     }
/* 2019 */     if (expression instanceof LongLiteralMinValue) {
/* 2020 */       return convert((LongLiteralMinValue)expression);
/*      */     }
/* 2022 */     if (expression instanceof LongLiteral) {
/* 2023 */       return convert((LongLiteral)expression);
/*      */     }
/* 2025 */     if (expression instanceof StringLiteralConcatenation) {
/* 2026 */       return convert((StringLiteralConcatenation)expression);
/*      */     }
/* 2028 */     if (expression instanceof ExtendedStringLiteral) {
/* 2029 */       return convert((ExtendedStringLiteral)expression);
/*      */     }
/* 2031 */     if (expression instanceof TextBlock) {
/* 2032 */       return convert((TextBlock)expression);
/*      */     }
/* 2034 */     if (expression instanceof StringLiteral) {
/* 2035 */       return convert((StringLiteral)expression);
/*      */     }
/* 2037 */     if (expression instanceof AND_AND_Expression) {
/* 2038 */       return convert((AND_AND_Expression)expression);
/*      */     }
/* 2040 */     if (expression instanceof OR_OR_Expression) {
/* 2041 */       return convert((OR_OR_Expression)expression);
/*      */     }
/* 2043 */     if (expression instanceof EqualExpression) {
/* 2044 */       return convert((EqualExpression)expression);
/*      */     }
/* 2046 */     if (expression instanceof BinaryExpression) {
/* 2047 */       return convert((BinaryExpression)expression);
/*      */     }
/* 2049 */     if (expression instanceof InstanceOfExpression) {
/* 2050 */       return convert((InstanceOfExpression)expression);
/*      */     }
/* 2052 */     if (expression instanceof UnaryExpression) {
/* 2053 */       return convert((UnaryExpression)expression);
/*      */     }
/* 2055 */     if (expression instanceof ConditionalExpression) {
/* 2056 */       return convert((ConditionalExpression)expression);
/*      */     }
/* 2058 */     if (expression instanceof MessageSend) {
/* 2059 */       return convert((MessageSend)expression);
/*      */     }
/* 2061 */     if (expression instanceof Reference) {
/* 2062 */       return convert((Reference)expression);
/*      */     }
/* 2064 */     if (expression instanceof TypeReference) {
/* 2065 */       return convert((TypeReference)expression);
/*      */     }
/* 2067 */     if (expression instanceof LambdaExpression) {
/* 2068 */       return convert((LambdaExpression)expression);
/*      */     }
/* 2070 */     if (expression instanceof ReferenceExpression) {
/* 2071 */       return convert((ReferenceExpression)expression);
/*      */     }
/* 2073 */     if (expression instanceof SwitchExpression) {
/* 2074 */       return convert((SwitchExpression)expression);
/*      */     }
/* 2076 */     return null;
/*      */   }
/*      */   
/*      */   public StringLiteral convert(ExtendedStringLiteral expression) {
/* 2080 */     expression.computeConstant();
/* 2081 */     StringLiteral literal = new StringLiteral(this.ast);
/* 2082 */     if (this.resolveBindings) {
/* 2083 */       recordNodes(literal, (ASTNode)expression);
/*      */     }
/* 2085 */     literal.setLiteralValue(expression.constant.stringValue());
/* 2086 */     literal.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 2087 */     return literal;
/*      */   }
/*      */   
/*      */   public BooleanLiteral convert(FalseLiteral expression) {
/* 2091 */     BooleanLiteral literal = new BooleanLiteral(this.ast);
/* 2092 */     literal.setBooleanValue(false);
/* 2093 */     if (this.resolveBindings) {
/* 2094 */       recordNodes(literal, (ASTNode)expression);
/*      */     }
/* 2096 */     literal.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 2097 */     return literal;
/*      */   }
/*      */   
/*      */   public Expression convert(FieldReference reference) {
/* 2101 */     if (reference.receiver.isSuper()) {
/* 2102 */       SuperFieldAccess superFieldAccess = new SuperFieldAccess(this.ast);
/* 2103 */       if (this.resolveBindings) {
/* 2104 */         recordNodes(superFieldAccess, (ASTNode)reference);
/*      */       }
/* 2106 */       if (reference.receiver instanceof QualifiedSuperReference) {
/* 2107 */         Name qualifier = convert((QualifiedSuperReference)reference.receiver);
/* 2108 */         superFieldAccess.setQualifier(qualifier);
/* 2109 */         if (this.resolveBindings) {
/* 2110 */           recordNodes(qualifier, (ASTNode)reference.receiver);
/*      */         }
/*      */       } 
/* 2113 */       SimpleName simpleName1 = new SimpleName(this.ast);
/* 2114 */       simpleName1.internalSetIdentifier(new String(reference.token));
/* 2115 */       int i = (int)(reference.nameSourcePosition >>> 32L);
/* 2116 */       int j = (int)(reference.nameSourcePosition & 0xFFFFFFFFFFFFFFFFL) - i + 1;
/* 2117 */       simpleName1.setSourceRange(i, j);
/* 2118 */       superFieldAccess.setName(simpleName1);
/* 2119 */       if (this.resolveBindings) {
/* 2120 */         recordNodes(simpleName1, (ASTNode)reference);
/*      */       }
/* 2122 */       superFieldAccess.setSourceRange(reference.receiver.sourceStart, reference.sourceEnd - reference.receiver.sourceStart + 1);
/* 2123 */       return superFieldAccess;
/*      */     } 
/* 2125 */     FieldAccess fieldAccess = new FieldAccess(this.ast);
/* 2126 */     if (this.resolveBindings) {
/* 2127 */       recordNodes(fieldAccess, (ASTNode)reference);
/*      */     }
/* 2129 */     Expression receiver = convert(reference.receiver);
/* 2130 */     fieldAccess.setExpression(receiver);
/* 2131 */     SimpleName simpleName = new SimpleName(this.ast);
/* 2132 */     simpleName.internalSetIdentifier(new String(reference.token));
/* 2133 */     int sourceStart = (int)(reference.nameSourcePosition >>> 32L);
/* 2134 */     int length = (int)(reference.nameSourcePosition & 0xFFFFFFFFFFFFFFFFL) - sourceStart + 1;
/* 2135 */     simpleName.setSourceRange(sourceStart, length);
/* 2136 */     fieldAccess.setName(simpleName);
/* 2137 */     if (this.resolveBindings) {
/* 2138 */       recordNodes(simpleName, (ASTNode)reference);
/*      */     }
/* 2140 */     fieldAccess.setSourceRange(receiver.getStartPosition(), reference.sourceEnd - receiver.getStartPosition() + 1);
/* 2141 */     return fieldAccess;
/*      */   }
/*      */ 
/*      */   
/*      */   public NumberLiteral convert(FloatLiteral expression) {
/* 2146 */     int length = expression.sourceEnd - expression.sourceStart + 1;
/* 2147 */     int sourceStart = expression.sourceStart;
/* 2148 */     NumberLiteral literal = new NumberLiteral(this.ast);
/* 2149 */     literal.internalSetToken(new String(this.compilationUnitSource, sourceStart, length));
/* 2150 */     if (this.resolveBindings) {
/* 2151 */       recordNodes(literal, (ASTNode)expression);
/*      */     }
/* 2153 */     literal.setSourceRange(sourceStart, length);
/* 2154 */     removeLeadingAndTrailingCommentsFromLiteral(literal);
/* 2155 */     return literal;
/*      */   }
/*      */   
/*      */   public Statement convert(ForeachStatement statement) {
/* 2159 */     switch (this.ast.apiLevel) {
/*      */       case 2:
/* 2161 */         return createFakeEmptyStatement((Statement)statement);
/*      */     } 
/* 2163 */     if (statement.pattern != null) {
/* 2164 */       if (!this.ast.isPreviewEnabled()) {
/* 2165 */         return createFakeEmptyStatement((Statement)statement);
/*      */       }
/* 2167 */       EnhancedForWithRecordPattern enhancedFor = new EnhancedForWithRecordPattern(this.ast);
/* 2168 */       enhancedFor.setPattern((RecordPattern)convert(statement.pattern));
/* 2169 */       Expression expression = statement.collection;
/* 2170 */       if (expression == null) return null; 
/* 2171 */       enhancedFor.setExpression(convert(expression));
/* 2172 */       Statement statement1 = convert(statement.originalAction);
/* 2173 */       if (statement1 == null) return null; 
/* 2174 */       enhancedFor.setBody(statement1);
/* 2175 */       int i = statement.sourceStart;
/* 2176 */       int j = statement.sourceEnd;
/* 2177 */       enhancedFor.setSourceRange(i, j - i + 1);
/* 2178 */       return enhancedFor;
/*      */     } 
/* 2180 */     EnhancedForStatement enhancedForStatement = new EnhancedForStatement(this.ast);
/* 2181 */     enhancedForStatement.setParameter(convertToSingleVariableDeclaration(statement.elementVariable));
/* 2182 */     Expression collection = statement.collection;
/* 2183 */     if (collection == null) return null; 
/* 2184 */     enhancedForStatement.setExpression(convert(collection));
/* 2185 */     Statement action = convert(statement.action);
/* 2186 */     if (action == null) return null; 
/* 2187 */     enhancedForStatement.setBody(action);
/* 2188 */     int start = statement.sourceStart;
/* 2189 */     int end = statement.sourceEnd;
/* 2190 */     enhancedForStatement.setSourceRange(start, end - start + 1);
/* 2191 */     return enhancedForStatement;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ForStatement convert(ForStatement statement) {
/* 2197 */     ForStatement forStatement = new ForStatement(this.ast);
/* 2198 */     forStatement.setSourceRange(statement.sourceStart, statement.sourceEnd - statement.sourceStart + 1);
/* 2199 */     Statement[] initializations = statement.initializations;
/* 2200 */     if (initializations != null)
/*      */     {
/* 2202 */       if (initializations[0] instanceof LocalDeclaration) {
/* 2203 */         LocalDeclaration initialization = (LocalDeclaration)initializations[0];
/* 2204 */         VariableDeclarationExpression variableDeclarationExpression = convertToVariableDeclarationExpression(initialization);
/* 2205 */         int initializationsLength = initializations.length;
/* 2206 */         for (int i = 1; i < initializationsLength; i++) {
/* 2207 */           initialization = (LocalDeclaration)initializations[i];
/* 2208 */           variableDeclarationExpression.fragments().add(convertToVariableDeclarationFragment(initialization));
/*      */         } 
/* 2210 */         if (initializationsLength != 1) {
/* 2211 */           int start = variableDeclarationExpression.getStartPosition();
/* 2212 */           int end = ((LocalDeclaration)initializations[initializationsLength - 1]).declarationSourceEnd;
/* 2213 */           variableDeclarationExpression.setSourceRange(start, end - start + 1);
/*      */         } 
/* 2215 */         forStatement.initializers().add(variableDeclarationExpression);
/*      */       } else {
/* 2217 */         int initializationsLength = initializations.length;
/* 2218 */         for (int i = 0; i < initializationsLength; i++) {
/* 2219 */           Expression initializer = convertToExpression(initializations[i]);
/* 2220 */           if (initializer != null) {
/* 2221 */             forStatement.initializers().add(initializer);
/*      */           } else {
/* 2223 */             forStatement.setFlags(forStatement.getFlags() | 0x1);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/* 2228 */     if (statement.condition != null) {
/* 2229 */       forStatement.setExpression(convert(statement.condition));
/*      */     }
/* 2231 */     Statement[] increments = statement.increments;
/* 2232 */     if (increments != null) {
/* 2233 */       int incrementsLength = increments.length;
/* 2234 */       for (int i = 0; i < incrementsLength; i++) {
/* 2235 */         forStatement.updaters().add(convertToExpression(increments[i]));
/*      */       }
/*      */     } 
/* 2238 */     Statement action = convert(statement.action);
/* 2239 */     if (action == null) return null; 
/* 2240 */     forStatement.setBody(action);
/* 2241 */     return forStatement;
/*      */   }
/*      */   
/*      */   public Pattern convert(GuardedPattern pattern) {
/* 2245 */     GuardedPattern guardedPattern = new GuardedPattern(this.ast);
/* 2246 */     if (this.resolveBindings) {
/* 2247 */       recordNodes(guardedPattern, (ASTNode)pattern);
/*      */     }
/* 2249 */     guardedPattern.setPattern(convert(pattern.primaryPattern));
/* 2250 */     guardedPattern.setExpression(convert(pattern.condition));
/* 2251 */     int startPosition = pattern.sourceStart;
/* 2252 */     int sourceEnd = pattern.sourceEnd;
/* 2253 */     guardedPattern.setSourceRange(startPosition, sourceEnd - startPosition + 1);
/* 2254 */     guardedPattern.setRestrictedIdentifierStartPosition(pattern.restrictedIdentifierStart);
/* 2255 */     return guardedPattern;
/*      */   }
/*      */   
/*      */   public Pattern convert(RecordPattern pattern) {
/* 2259 */     RecordPattern recordPattern = new RecordPattern(this.ast);
/* 2260 */     if (this.resolveBindings) {
/* 2261 */       recordNodes(recordPattern, (ASTNode)pattern);
/*      */     }
/* 2263 */     int startPosition = pattern.sourceStart;
/* 2264 */     int sourceEnd = pattern.sourceEnd;
/* 2265 */     recordPattern.setSourceRange(startPosition, sourceEnd - startPosition + 1);
/* 2266 */     if (pattern.local != null) {
/* 2267 */       recordPattern.setPatternType(convertType(pattern.local.type));
/* 2268 */       SimpleName patternName = new SimpleName(this.ast);
/* 2269 */       patternName.internalSetIdentifier(new String(pattern.local.name));
/* 2270 */       patternName.setSourceRange(pattern.local.nameSourceStart(), pattern.local.nameSourceEnd() - pattern.local.nameSourceStart() + 1);
/* 2271 */       recordPattern.setPatternName(patternName);
/* 2272 */     } else if (pattern.type != null) {
/* 2273 */       recordPattern.setPatternType(convertType(pattern.type));
/*      */     }  byte b; int i; Pattern[] arrayOfPattern;
/* 2275 */     for (i = (arrayOfPattern = pattern.patterns).length, b = 0; b < i; ) { Pattern nestedPattern = arrayOfPattern[b];
/* 2276 */       recordPattern.patterns().add(convert(nestedPattern));
/*      */       b++; }
/*      */     
/* 2279 */     return recordPattern;
/*      */   }
/*      */   
/*      */   public IfStatement convert(IfStatement statement) {
/* 2283 */     IfStatement ifStatement = new IfStatement(this.ast);
/* 2284 */     ifStatement.setSourceRange(statement.sourceStart, statement.sourceEnd - statement.sourceStart + 1);
/* 2285 */     ifStatement.setExpression(convert(statement.condition));
/* 2286 */     Statement thenStatement = convert(statement.thenStatement);
/* 2287 */     if (thenStatement == null) return null; 
/* 2288 */     ifStatement.setThenStatement(thenStatement);
/* 2289 */     Statement statement2 = statement.elseStatement;
/* 2290 */     if (statement2 != null) {
/* 2291 */       Statement elseStatement = convert(statement2);
/* 2292 */       if (elseStatement != null) {
/* 2293 */         ifStatement.setElseStatement(elseStatement);
/*      */       }
/*      */     } 
/* 2296 */     return ifStatement;
/*      */   }
/*      */   
/*      */   public Expression convert(InstanceOfExpression expression) {
/* 2300 */     if (DOMASTUtil.isPatternInstanceofExpressionSupported(this.ast) && expression.pattern != null) {
/* 2301 */       return convertToPatternInstanceOfExpression(expression);
/*      */     }
/* 2303 */     InstanceofExpression instanceOfExpression = new InstanceofExpression(this.ast);
/* 2304 */     if (this.resolveBindings) {
/* 2305 */       recordNodes(instanceOfExpression, (ASTNode)expression);
/*      */     }
/* 2307 */     Expression leftExpression = convert(expression.expression);
/* 2308 */     instanceOfExpression.setLeftOperand(leftExpression);
/* 2309 */     Type convertType = convertType(expression.type);
/* 2310 */     instanceOfExpression.setRightOperand(convertType);
/* 2311 */     int startPosition = leftExpression.getStartPosition();
/* 2312 */     int sourceEnd = convertType.getStartPosition() + convertType.getLength() - 1;
/*      */     
/* 2314 */     instanceOfExpression.setSourceRange(startPosition, sourceEnd - startPosition + 1);
/* 2315 */     return instanceOfExpression;
/*      */   }
/*      */ 
/*      */   
/*      */   public PatternInstanceofExpression convertToPatternInstanceOfExpression(InstanceOfExpression expression) {
/* 2320 */     PatternInstanceofExpression patternInstanceOfExpression = new PatternInstanceofExpression(this.ast);
/* 2321 */     if (this.resolveBindings) {
/* 2322 */       recordNodes(patternInstanceOfExpression, (ASTNode)expression);
/*      */     }
/* 2324 */     Expression leftExpression = convert(expression.expression);
/* 2325 */     patternInstanceOfExpression.setLeftOperand(leftExpression);
/* 2326 */     if (this.ast.apiLevel == 20 && this.ast.isPreviewEnabled()) {
/* 2327 */       patternInstanceOfExpression.setPattern(convert(expression.pattern));
/*      */     }
/* 2329 */     else if (expression.elementVariable != null) {
/* 2330 */       patternInstanceOfExpression.setRightOperand(convertToSingleVariableDeclaration(expression.elementVariable));
/* 2331 */     } else if (expression.pattern != null) {
/*      */       
/* 2333 */       SingleVariableDeclaration rightOperand = patternInstanceOfExpression.getRightOperand();
/* 2334 */       if (rightOperand != null) {
/* 2335 */         TypeReference type = expression.pattern.getType();
/* 2336 */         Type convertType = convertType(type);
/* 2337 */         rightOperand.setType(convertType);
/* 2338 */         int i = expression.pattern.sourceStart;
/* 2339 */         int j = expression.pattern.sourceEnd;
/* 2340 */         rightOperand.setSourceRange(i, j - i + 1);
/* 2341 */         SimpleName name = rightOperand.getName();
/* 2342 */         i = type.sourceStart + 1;
/* 2343 */         name.setSourceRange(i, j - i + 1);
/*      */       } 
/*      */     } 
/*      */     
/* 2347 */     int startPosition = leftExpression.getStartPosition();
/* 2348 */     int sourceEnd = expression.pattern.sourceEnd;
/*      */     
/* 2350 */     patternInstanceOfExpression.setSourceRange(startPosition, sourceEnd - startPosition + 1);
/* 2351 */     return patternInstanceOfExpression;
/*      */   }
/*      */   
/*      */   public NumberLiteral convert(IntLiteral expression) {
/* 2355 */     int length = expression.sourceEnd - expression.sourceStart + 1;
/* 2356 */     int sourceStart = expression.sourceStart;
/* 2357 */     NumberLiteral literal = new NumberLiteral(this.ast);
/* 2358 */     literal.internalSetToken(new String(this.compilationUnitSource, sourceStart, length));
/* 2359 */     if (this.resolveBindings) {
/* 2360 */       recordNodes(literal, (ASTNode)expression);
/*      */     }
/* 2362 */     literal.setSourceRange(sourceStart, length);
/* 2363 */     removeLeadingAndTrailingCommentsFromLiteral(literal);
/* 2364 */     return literal;
/*      */   }
/*      */   
/*      */   public NumberLiteral convert(IntLiteralMinValue expression) {
/* 2368 */     int length = expression.sourceEnd - expression.sourceStart + 1;
/* 2369 */     int sourceStart = expression.sourceStart;
/* 2370 */     NumberLiteral literal = new NumberLiteral(this.ast);
/* 2371 */     literal.internalSetToken(new String(this.compilationUnitSource, sourceStart, length));
/* 2372 */     if (this.resolveBindings) {
/* 2373 */       recordNodes(literal, (ASTNode)expression);
/*      */     }
/* 2375 */     literal.setSourceRange(sourceStart, length);
/* 2376 */     removeLeadingAndTrailingCommentsFromLiteral(literal);
/* 2377 */     return literal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void convert(Javadoc javadoc, IGetJavaDoc getJ, ISetJavaDoc setJ) {
/* 2387 */     if (getJ.getJavaDoc() == null) {
/* 2388 */       Javadoc docComment = convert(javadoc);
/* 2389 */       if (docComment != null)
/* 2390 */         setJ.setJavadoc(docComment); 
/*      */     } 
/*      */   }
/*      */   private Javadoc convert(Javadoc javadoc) {
/* 2394 */     Javadoc docComment = null;
/* 2395 */     if (javadoc != null) {
/* 2396 */       if (this.commentMapper == null || !this.commentMapper.hasSameTable(this.commentsTable)) {
/* 2397 */         this.commentMapper = new DefaultCommentMapper(this.commentsTable);
/*      */       }
/* 2399 */       Comment comment = this.commentMapper.getComment(javadoc.sourceStart);
/* 2400 */       if (comment != null && comment.isDocComment() && comment.getParent() == null) {
/* 2401 */         docComment = (Javadoc)comment;
/* 2402 */         if (this.resolveBindings) {
/* 2403 */           recordNodes(docComment, (ASTNode)javadoc);
/*      */           
/* 2405 */           Iterator<TagElement> tags = docComment.tags().listIterator();
/* 2406 */           while (tags.hasNext()) {
/* 2407 */             recordNodes(javadoc, tags.next());
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 2412 */     return docComment;
/*      */   }
/*      */   public void convert(Javadoc javadoc, BodyDeclaration bodyDeclaration) {
/* 2415 */     convert(javadoc, bodyDeclaration::getJavadoc, bodyDeclaration::setJavadoc);
/*      */   }
/*      */   public void convert(Javadoc javadoc, ModuleDeclaration moduleDeclaration) {
/* 2418 */     convert(javadoc, moduleDeclaration::getJavadoc, moduleDeclaration::setJavadoc);
/*      */   }
/*      */   
/*      */   public void convert(Javadoc javadoc, PackageDeclaration packageDeclaration) {
/* 2422 */     if (this.ast.apiLevel == 2)
/* 2423 */       return;  convert(javadoc, packageDeclaration::getJavadoc, packageDeclaration::setJavadoc);
/*      */   }
/*      */   
/*      */   public LabeledStatement convert(LabeledStatement statement) {
/* 2427 */     LabeledStatement labeledStatement = new LabeledStatement(this.ast);
/* 2428 */     int sourceStart = statement.sourceStart;
/* 2429 */     labeledStatement.setSourceRange(sourceStart, statement.sourceEnd - sourceStart + 1);
/* 2430 */     Statement body = convert(statement.statement);
/* 2431 */     if (body == null) return null; 
/* 2432 */     labeledStatement.setBody(body);
/* 2433 */     SimpleName name = new SimpleName(this.ast);
/* 2434 */     name.internalSetIdentifier(new String(statement.label));
/* 2435 */     name.setSourceRange(sourceStart, statement.labelEnd - sourceStart + 1);
/* 2436 */     labeledStatement.setLabel(name);
/* 2437 */     return labeledStatement;
/*      */   }
/*      */   
/*      */   public NumberLiteral convert(LongLiteral expression) {
/* 2441 */     int length = expression.sourceEnd - expression.sourceStart + 1;
/* 2442 */     int sourceStart = expression.sourceStart;
/* 2443 */     NumberLiteral literal = new NumberLiteral(this.ast);
/* 2444 */     literal.internalSetToken(new String(this.compilationUnitSource, sourceStart, length));
/* 2445 */     if (this.resolveBindings) {
/* 2446 */       recordNodes(literal, (ASTNode)expression);
/*      */     }
/* 2448 */     literal.setSourceRange(sourceStart, length);
/* 2449 */     removeLeadingAndTrailingCommentsFromLiteral(literal);
/* 2450 */     return literal;
/*      */   }
/*      */   
/*      */   public NumberLiteral convert(LongLiteralMinValue expression) {
/* 2454 */     int length = expression.sourceEnd - expression.sourceStart + 1;
/* 2455 */     int sourceStart = expression.sourceStart;
/* 2456 */     NumberLiteral literal = new NumberLiteral(this.ast);
/* 2457 */     literal.internalSetToken(new String(this.compilationUnitSource, sourceStart, length));
/* 2458 */     if (this.resolveBindings) {
/* 2459 */       recordNodes(literal, (ASTNode)expression);
/*      */     }
/* 2461 */     literal.setSourceRange(sourceStart, length);
/* 2462 */     removeLeadingAndTrailingCommentsFromLiteral(literal);
/* 2463 */     return literal;
/*      */   }
/*      */ 
/*      */   
/*      */   public Expression convert(MessageSend expression) {
/*      */     Expression expr;
/* 2469 */     int sourceStart = expression.sourceStart;
/* 2470 */     if (expression.isSuperAccess()) {
/*      */       
/* 2472 */       SuperMethodInvocation superMethodInvocation = new SuperMethodInvocation(this.ast);
/* 2473 */       if (this.resolveBindings) {
/* 2474 */         recordNodes(superMethodInvocation, (ASTNode)expression);
/*      */       }
/* 2476 */       SimpleName name = new SimpleName(this.ast);
/* 2477 */       name.internalSetIdentifier(new String(expression.selector));
/* 2478 */       int nameSourceStart = (int)(expression.nameSourcePosition >>> 32L);
/* 2479 */       int nameSourceLength = (int)expression.nameSourcePosition - nameSourceStart + 1;
/* 2480 */       name.setSourceRange(nameSourceStart, nameSourceLength);
/* 2481 */       if (this.resolveBindings) {
/* 2482 */         recordNodes(name, (ASTNode)expression);
/*      */       }
/* 2484 */       superMethodInvocation.setName(name);
/*      */ 
/*      */       
/* 2487 */       if (expression.receiver instanceof QualifiedSuperReference) {
/* 2488 */         Name qualifier = convert((QualifiedSuperReference)expression.receiver);
/* 2489 */         superMethodInvocation.setQualifier(qualifier);
/* 2490 */         if (this.resolveBindings) {
/* 2491 */           recordNodes(qualifier, (ASTNode)expression.receiver);
/*      */         }
/* 2493 */         if (qualifier != null) {
/* 2494 */           sourceStart = qualifier.getStartPosition();
/*      */         }
/*      */       } 
/* 2497 */       Expression[] arguments = expression.arguments;
/* 2498 */       if (arguments != null) {
/* 2499 */         int argumentsLength = arguments.length;
/* 2500 */         for (int i = 0; i < argumentsLength; i++) {
/* 2501 */           Expression expri = convert(arguments[i]);
/* 2502 */           if (this.resolveBindings) {
/* 2503 */             recordNodes(expri, (ASTNode)arguments[i]);
/*      */           }
/* 2505 */           superMethodInvocation.arguments().add(expri);
/*      */         } 
/*      */       } 
/* 2508 */       TypeReference[] typeArguments = expression.typeArguments;
/* 2509 */       if (typeArguments != null) {
/* 2510 */         int i; int max; switch (this.ast.apiLevel) {
/*      */           case 2:
/* 2512 */             superMethodInvocation.setFlags(superMethodInvocation.getFlags() | 0x1);
/*      */             break;
/*      */           default:
/* 2515 */             for (i = 0, max = typeArguments.length; i < max; i++) {
/* 2516 */               superMethodInvocation.typeArguments().add(convertType(typeArguments[i]));
/*      */             }
/*      */             break;
/*      */         } 
/*      */       } 
/* 2521 */       expr = superMethodInvocation;
/*      */     } else {
/*      */       
/* 2524 */       MethodInvocation methodInvocation = new MethodInvocation(this.ast);
/* 2525 */       if (this.resolveBindings) {
/* 2526 */         recordNodes(methodInvocation, (ASTNode)expression);
/*      */       }
/* 2528 */       SimpleName name = new SimpleName(this.ast);
/* 2529 */       name.internalSetIdentifier(new String(expression.selector));
/* 2530 */       int nameSourceStart = (int)(expression.nameSourcePosition >>> 32L);
/* 2531 */       int nameSourceLength = (int)expression.nameSourcePosition - nameSourceStart + 1;
/* 2532 */       name.setSourceRange(nameSourceStart, nameSourceLength);
/* 2533 */       methodInvocation.setName(name);
/* 2534 */       if (this.resolveBindings) {
/* 2535 */         recordNodes(name, (ASTNode)expression);
/*      */       }
/* 2537 */       Expression[] arguments = expression.arguments;
/* 2538 */       if (arguments != null) {
/* 2539 */         int argumentsLength = arguments.length;
/* 2540 */         for (int i = 0; i < argumentsLength; i++) {
/* 2541 */           Expression expri = convert(arguments[i]);
/* 2542 */           if (this.resolveBindings) {
/* 2543 */             recordNodes(expri, (ASTNode)arguments[i]);
/*      */           }
/* 2545 */           methodInvocation.arguments().add(expri);
/*      */         } 
/*      */       } 
/* 2548 */       Expression qualifier = null;
/* 2549 */       Expression receiver = expression.receiver;
/* 2550 */       if (receiver instanceof MessageSend) {
/* 2551 */         if ((receiver.bits & 0x1FE00000) != 0) {
/* 2552 */           qualifier = convertToParenthesizedExpression(receiver);
/*      */         } else {
/* 2554 */           qualifier = convert((MessageSend)receiver);
/*      */         } 
/*      */       } else {
/* 2557 */         qualifier = convert(receiver);
/*      */       } 
/* 2559 */       if (qualifier instanceof Name && this.resolveBindings) {
/* 2560 */         recordNodes(qualifier, (ASTNode)receiver);
/*      */       }
/* 2562 */       methodInvocation.setExpression(qualifier);
/* 2563 */       if (qualifier != null) {
/* 2564 */         sourceStart = qualifier.getStartPosition();
/*      */       }
/* 2566 */       TypeReference[] typeArguments = expression.typeArguments;
/* 2567 */       if (typeArguments != null) {
/* 2568 */         int i; int max; switch (this.ast.apiLevel) {
/*      */           case 2:
/* 2570 */             methodInvocation.setFlags(methodInvocation.getFlags() | 0x1);
/*      */             break;
/*      */           default:
/* 2573 */             for (i = 0, max = typeArguments.length; i < max; i++) {
/* 2574 */               methodInvocation.typeArguments().add(convertType(typeArguments[i]));
/*      */             }
/*      */             break;
/*      */         } 
/*      */       } 
/* 2579 */       expr = methodInvocation;
/*      */     } 
/* 2581 */     expr.setSourceRange(sourceStart, expression.sourceEnd - sourceStart + 1);
/* 2582 */     return expr;
/*      */   }
/*      */   
/*      */   public Expression convert(LambdaExpression lambda) {
/* 2586 */     if (this.ast.apiLevel < 8) {
/* 2587 */       return createFakeNullLiteral((Expression)lambda);
/*      */     }
/* 2589 */     LambdaExpression lambdaExpression = new LambdaExpression(this.ast);
/* 2590 */     if (this.resolveBindings) {
/* 2591 */       recordNodes(lambdaExpression, (ASTNode)lambda);
/*      */     }
/* 2593 */     Argument[] arguments = lambda.arguments();
/* 2594 */     if (arguments != null) {
/* 2595 */       int argumentsLength = arguments.length;
/* 2596 */       for (int i = 0; i < argumentsLength; i++) {
/* 2597 */         Argument argument = arguments[i];
/* 2598 */         if (argument.type == null) {
/* 2599 */           VariableDeclarationFragment variableDeclarationFragment = new VariableDeclarationFragment(this.ast);
/* 2600 */           SimpleName simpleName = new SimpleName(this.ast);
/* 2601 */           simpleName.internalSetIdentifier(new String(argument.name));
/* 2602 */           int start = argument.sourceStart;
/* 2603 */           int end = argument.sourceEnd;
/* 2604 */           simpleName.setSourceRange(start, end - start + 1);
/* 2605 */           if (this.resolveBindings) {
/* 2606 */             recordNodes(simpleName, (ASTNode)argument);
/* 2607 */             recordNodes(variableDeclarationFragment, (ASTNode)argument);
/* 2608 */             variableDeclarationFragment.resolveBinding();
/*      */           } 
/* 2610 */           variableDeclarationFragment.setName(simpleName);
/* 2611 */           variableDeclarationFragment.setSourceRange(start, end - start + 1);
/* 2612 */           lambdaExpression.parameters().add(variableDeclarationFragment);
/*      */         } else {
/* 2614 */           SingleVariableDeclaration singleVariableDeclaration = convert(argument);
/* 2615 */           lambdaExpression.parameters().add(singleVariableDeclaration);
/*      */         } 
/*      */       } 
/*      */     } 
/* 2619 */     Statement body = lambda.body();
/* 2620 */     if (body instanceof Expression && (
/* 2621 */       (Expression)body).isTrulyExpression()) {
/* 2622 */       lambdaExpression.setBody(convert((Expression)body));
/*      */     } else {
/* 2624 */       lambdaExpression.setBody(convert((Block)body));
/*      */     } 
/* 2626 */     int sourceStart = lambda.sourceStart;
/* 2627 */     lambdaExpression.setSourceRange(sourceStart, lambda.sourceEnd - sourceStart + 1);
/* 2628 */     lambdaExpression.setParentheses(lambda.hasParentheses);
/* 2629 */     return lambdaExpression;
/*      */   }
/*      */   
/*      */   public MarkerAnnotation convert(MarkerAnnotation annotation) {
/* 2633 */     MarkerAnnotation markerAnnotation = new MarkerAnnotation(this.ast);
/* 2634 */     setTypeNameForAnnotation((Annotation)annotation, markerAnnotation);
/* 2635 */     int start = annotation.sourceStart;
/* 2636 */     int end = annotation.declarationSourceEnd;
/* 2637 */     markerAnnotation.setSourceRange(start, end - start + 1);
/* 2638 */     if (this.resolveBindings) {
/* 2639 */       recordNodes(markerAnnotation, (ASTNode)annotation);
/* 2640 */       markerAnnotation.resolveAnnotationBinding();
/*      */     } 
/* 2642 */     return markerAnnotation;
/*      */   }
/*      */   
/*      */   public MemberValuePair convert(MemberValuePair memberValuePair) {
/* 2646 */     MemberValuePair pair = new MemberValuePair(this.ast);
/* 2647 */     SimpleName simpleName = new SimpleName(this.ast);
/* 2648 */     simpleName.internalSetIdentifier(new String(memberValuePair.name));
/* 2649 */     int start = memberValuePair.sourceStart;
/* 2650 */     int end = memberValuePair.sourceEnd;
/* 2651 */     simpleName.setSourceRange(start, end - start + 1);
/* 2652 */     pair.setName(simpleName);
/* 2653 */     Expression value = convert(memberValuePair.value);
/* 2654 */     pair.setValue(value);
/* 2655 */     start = memberValuePair.sourceStart;
/* 2656 */     end = value.getStartPosition() + value.getLength() - 1;
/* 2657 */     pair.setSourceRange(start, end - start + 1);
/*      */     
/* 2659 */     if (memberValuePair.value instanceof SingleNameReference && 
/* 2660 */       ((SingleNameReference)memberValuePair.value).token == RecoveryScanner.FAKE_IDENTIFIER) {
/* 2661 */       pair.setFlags(pair.getFlags() | 0x8);
/*      */     }
/*      */     
/* 2664 */     if (this.resolveBindings) {
/* 2665 */       recordNodes(simpleName, (ASTNode)memberValuePair);
/* 2666 */       recordNodes(pair, (ASTNode)memberValuePair);
/*      */     } 
/* 2668 */     return pair;
/*      */   }
/*      */   
/*      */   public Name convert(NameReference reference) {
/* 2672 */     if (reference instanceof QualifiedNameReference) {
/* 2673 */       return convert((QualifiedNameReference)reference);
/*      */     }
/* 2675 */     return convert((SingleNameReference)reference);
/*      */   }
/*      */ 
/*      */   
/*      */   public InfixExpression convert(StringLiteralConcatenation expression) {
/* 2680 */     expression.computeConstant();
/* 2681 */     InfixExpression infixExpression = new InfixExpression(this.ast);
/* 2682 */     infixExpression.setOperator(InfixExpression.Operator.PLUS);
/* 2683 */     Expression[] stringLiterals = expression.literals;
/* 2684 */     infixExpression.setLeftOperand(convert(stringLiterals[0]));
/* 2685 */     infixExpression.setRightOperand(convert(stringLiterals[1]));
/* 2686 */     for (int i = 2; i < expression.counter; i++) {
/* 2687 */       infixExpression.extendedOperands().add(convert(stringLiterals[i]));
/*      */     }
/* 2689 */     if (this.resolveBindings) {
/* 2690 */       recordNodes(infixExpression, (ASTNode)expression);
/*      */     }
/* 2692 */     infixExpression.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 2693 */     return infixExpression;
/*      */   }
/*      */   
/*      */   public NormalAnnotation convert(NormalAnnotation annotation) {
/* 2697 */     NormalAnnotation normalAnnotation = new NormalAnnotation(this.ast);
/* 2698 */     setTypeNameForAnnotation((Annotation)annotation, normalAnnotation);
/*      */     
/* 2700 */     int start = annotation.sourceStart;
/* 2701 */     int end = annotation.declarationSourceEnd;
/*      */     
/* 2703 */     MemberValuePair[] memberValuePairs = annotation.memberValuePairs;
/* 2704 */     if (memberValuePairs != null) {
/* 2705 */       for (int i = 0, max = memberValuePairs.length; i < max; i++) {
/* 2706 */         MemberValuePair memberValuePair = convert(memberValuePairs[i]);
/* 2707 */         int memberValuePairEnd = memberValuePair.getStartPosition() + memberValuePair.getLength() - 1;
/* 2708 */         if (end == memberValuePairEnd) {
/* 2709 */           normalAnnotation.setFlags(normalAnnotation.getFlags() | 0x8);
/*      */         }
/* 2711 */         normalAnnotation.values().add(memberValuePair);
/*      */       } 
/*      */     }
/*      */     
/* 2715 */     normalAnnotation.setSourceRange(start, end - start + 1);
/* 2716 */     if (this.resolveBindings) {
/* 2717 */       recordNodes(normalAnnotation, (ASTNode)annotation);
/* 2718 */       normalAnnotation.resolveAnnotationBinding();
/*      */     } 
/* 2720 */     return normalAnnotation;
/*      */   }
/*      */   
/*      */   public NullLiteral convert(NullLiteral expression) {
/* 2724 */     NullLiteral literal = new NullLiteral(this.ast);
/* 2725 */     if (this.resolveBindings) {
/* 2726 */       recordNodes(literal, (ASTNode)expression);
/*      */     }
/* 2728 */     literal.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 2729 */     return literal;
/*      */   }
/*      */   
/*      */   public Expression convert(OR_OR_Expression expression) {
/* 2733 */     InfixExpression infixExpression = new InfixExpression(this.ast);
/* 2734 */     infixExpression.setOperator(InfixExpression.Operator.CONDITIONAL_OR);
/* 2735 */     if (this.resolveBindings) {
/* 2736 */       recordNodes(infixExpression, (ASTNode)expression);
/*      */     }
/* 2738 */     int expressionOperatorID = (expression.bits & 0x3F00) >> 8;
/* 2739 */     if (expression.left instanceof BinaryExpression && (
/* 2740 */       expression.left.bits & 0x1FE00000) == 0) {
/*      */       
/* 2742 */       infixExpression.extendedOperands().add(convert(expression.right));
/* 2743 */       Expression leftOperand = expression.left;
/* 2744 */       Expression rightOperand = null;
/*      */       do {
/* 2746 */         rightOperand = ((BinaryExpression)leftOperand).right;
/* 2747 */         if (((leftOperand.bits & 0x3F00) >> 8 != expressionOperatorID && (
/* 2748 */           leftOperand.bits & 0x1FE00000) == 0) || (
/* 2749 */           rightOperand instanceof BinaryExpression && (
/* 2750 */           rightOperand.bits & 0x3F00) >> 8 != expressionOperatorID && (
/* 2751 */           rightOperand.bits & 0x1FE00000) == 0)) {
/* 2752 */           List<Expression> extendedOperands = infixExpression.extendedOperands();
/* 2753 */           InfixExpression temp = new InfixExpression(this.ast);
/* 2754 */           if (this.resolveBindings) {
/* 2755 */             recordNodes(temp, (ASTNode)expression);
/*      */           }
/* 2757 */           temp.setOperator(getOperatorFor(expressionOperatorID));
/* 2758 */           Expression leftSide = convert(leftOperand);
/* 2759 */           temp.setLeftOperand(leftSide);
/* 2760 */           temp.setSourceRange(leftSide.getStartPosition(), leftSide.getLength());
/* 2761 */           int size = extendedOperands.size(); int i;
/* 2762 */           for (i = 0; i < size - 1; i++) {
/* 2763 */             Expression expr = temp;
/* 2764 */             temp = new InfixExpression(this.ast);
/*      */             
/* 2766 */             if (this.resolveBindings) {
/* 2767 */               recordNodes(temp, (ASTNode)expression);
/*      */             }
/* 2769 */             temp.setLeftOperand(expr);
/* 2770 */             temp.setOperator(getOperatorFor(expressionOperatorID));
/* 2771 */             temp.setSourceRange(expr.getStartPosition(), expr.getLength());
/*      */           } 
/* 2773 */           infixExpression = temp;
/* 2774 */           for (i = 0; i < size; i++) {
/* 2775 */             Expression extendedOperand = extendedOperands.remove(size - 1 - i);
/* 2776 */             temp.setRightOperand(extendedOperand);
/* 2777 */             int startPosition = temp.getLeftOperand().getStartPosition();
/* 2778 */             temp.setSourceRange(startPosition, extendedOperand.getStartPosition() + extendedOperand.getLength() - startPosition);
/* 2779 */             if (temp.getLeftOperand().getNodeType() == 27) {
/* 2780 */               temp = (InfixExpression)temp.getLeftOperand();
/*      */             }
/*      */           } 
/* 2783 */           setInfixSourcePositions(infixExpression, expression.sourceStart);
/* 2784 */           if (this.resolveBindings) {
/* 2785 */             recordNodes(infixExpression, (ASTNode)expression);
/*      */           }
/* 2787 */           return infixExpression;
/*      */         } 
/* 2789 */         infixExpression.extendedOperands().add(0, convert(rightOperand));
/* 2790 */         leftOperand = ((BinaryExpression)leftOperand).left;
/* 2791 */       } while (leftOperand instanceof BinaryExpression && (leftOperand.bits & 0x1FE00000) == 0);
/* 2792 */       Expression expression1 = convert(leftOperand);
/* 2793 */       infixExpression.setLeftOperand(expression1);
/* 2794 */       infixExpression.setRightOperand(infixExpression.extendedOperands().remove(0));
/* 2795 */       setInfixSourcePositions(infixExpression, expression.sourceStart);
/* 2796 */       return infixExpression;
/*      */     } 
/* 2798 */     Expression leftExpression = convert(expression.left);
/* 2799 */     infixExpression.setLeftOperand(leftExpression);
/* 2800 */     infixExpression.setRightOperand(convert(expression.right));
/* 2801 */     infixExpression.setOperator(InfixExpression.Operator.CONDITIONAL_OR);
/* 2802 */     setInfixSourcePositions(infixExpression, expression.sourceStart);
/* 2803 */     return infixExpression;
/*      */   }
/*      */   
/*      */   private void setInfixSourcePositions(InfixExpression infixExpression, int sourceStart) {
/* 2807 */     int n = infixExpression.extendedOperands().size();
/* 2808 */     Expression rightMostExp = (n <= 0) ? infixExpression.getRightOperand() : infixExpression.extendedOperands().get(n - 1);
/* 2809 */     int rightSourceEnd = rightMostExp.getStartPosition() + rightMostExp.getLength() - 1;
/* 2810 */     int infixSourceEnd = infixExpression.getStartPosition() + infixExpression.getLength() - 1;
/* 2811 */     infixSourceEnd = (rightSourceEnd > infixSourceEnd) ? rightSourceEnd : infixSourceEnd;
/* 2812 */     infixExpression.setSourceRange(sourceStart, infixSourceEnd - sourceStart + 1);
/*      */   }
/*      */   
/*      */   public PostfixExpression convert(PostfixExpression expression) {
/* 2816 */     PostfixExpression postfixExpression = new PostfixExpression(this.ast);
/* 2817 */     if (this.resolveBindings) {
/* 2818 */       recordNodes(postfixExpression, (ASTNode)expression);
/*      */     }
/* 2820 */     postfixExpression.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 2821 */     postfixExpression.setOperand(convert(expression.lhs));
/* 2822 */     switch (expression.operator) {
/*      */       case 14:
/* 2824 */         postfixExpression.setOperator(PostfixExpression.Operator.INCREMENT);
/*      */         break;
/*      */       case 13:
/* 2827 */         postfixExpression.setOperator(PostfixExpression.Operator.DECREMENT);
/*      */         break;
/*      */     } 
/* 2830 */     return postfixExpression;
/*      */   }
/*      */   
/*      */   public Pattern convert(Pattern pattern) {
/* 2834 */     if (!DOMASTUtil.isPatternSupported(this.ast)) {
/* 2835 */       return createFakeNullPattern(pattern);
/*      */     }
/* 2837 */     if (pattern instanceof RecordPattern) {
/* 2838 */       return convert((RecordPattern)pattern);
/*      */     }
/* 2840 */     if (pattern instanceof GuardedPattern) {
/* 2841 */       return convert((GuardedPattern)pattern);
/*      */     }
/* 2843 */     if (pattern instanceof TypePattern) {
/* 2844 */       return convert((TypePattern)pattern);
/*      */     }
/* 2846 */     return null;
/*      */   }
/*      */   
/*      */   public PrefixExpression convert(PrefixExpression expression) {
/* 2850 */     PrefixExpression prefixExpression = new PrefixExpression(this.ast);
/* 2851 */     if (this.resolveBindings) {
/* 2852 */       recordNodes(prefixExpression, (ASTNode)expression);
/*      */     }
/* 2854 */     prefixExpression.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 2855 */     prefixExpression.setOperand(convert(expression.lhs));
/* 2856 */     switch (expression.operator) {
/*      */       case 14:
/* 2858 */         prefixExpression.setOperator(PrefixExpression.Operator.INCREMENT);
/*      */         break;
/*      */       case 13:
/* 2861 */         prefixExpression.setOperator(PrefixExpression.Operator.DECREMENT);
/*      */         break;
/*      */     } 
/* 2864 */     return prefixExpression;
/*      */   }
/*      */   
/*      */   public Expression convert(QualifiedAllocationExpression allocation) {
/* 2868 */     ClassInstanceCreation classInstanceCreation = new ClassInstanceCreation(this.ast);
/* 2869 */     if (allocation.enclosingInstance != null) {
/* 2870 */       classInstanceCreation.setExpression(convert(allocation.enclosingInstance));
/*      */     }
/* 2872 */     switch (this.ast.apiLevel) {
/*      */       case 2:
/* 2874 */         classInstanceCreation.internalSetName(convert(allocation.type));
/*      */         break;
/*      */       default:
/* 2877 */         classInstanceCreation.setType(convertType(allocation.type)); break;
/*      */     } 
/* 2879 */     Expression[] arguments = allocation.arguments;
/* 2880 */     if (arguments != null) {
/* 2881 */       int length = arguments.length;
/* 2882 */       for (int i = 0; i < length; i++) {
/* 2883 */         Expression argument = convert(arguments[i]);
/* 2884 */         if (this.resolveBindings) {
/* 2885 */           recordNodes(argument, (ASTNode)arguments[i]);
/*      */         }
/* 2887 */         classInstanceCreation.arguments().add(argument);
/*      */       } 
/*      */     } 
/* 2890 */     if (allocation.typeArguments != null) {
/* 2891 */       int i; int max; switch (this.ast.apiLevel) {
/*      */         case 2:
/* 2893 */           classInstanceCreation.setFlags(classInstanceCreation.getFlags() | 0x1);
/*      */           break;
/*      */         default:
/* 2896 */           for (i = 0, max = allocation.typeArguments.length; i < max; i++)
/* 2897 */             classInstanceCreation.typeArguments().add(convertType(allocation.typeArguments[i])); 
/*      */           break;
/*      */       } 
/*      */     } 
/* 2901 */     if (allocation.anonymousType != null) {
/* 2902 */       int declarationSourceStart = allocation.sourceStart;
/* 2903 */       classInstanceCreation.setSourceRange(declarationSourceStart, allocation.anonymousType.bodyEnd - declarationSourceStart + 1);
/* 2904 */       AnonymousClassDeclaration anonymousClassDeclaration = new AnonymousClassDeclaration(this.ast);
/* 2905 */       int i = retrieveStartBlockPosition(allocation.anonymousType.sourceEnd, allocation.anonymousType.bodyEnd);
/* 2906 */       anonymousClassDeclaration.setSourceRange(i, allocation.anonymousType.bodyEnd - i + 1);
/* 2907 */       classInstanceCreation.setAnonymousClassDeclaration(anonymousClassDeclaration);
/* 2908 */       buildBodyDeclarations(allocation.anonymousType, anonymousClassDeclaration);
/* 2909 */       if (this.resolveBindings) {
/* 2910 */         recordNodes(classInstanceCreation, (ASTNode)allocation.anonymousType);
/* 2911 */         recordNodes(anonymousClassDeclaration, (ASTNode)allocation.anonymousType);
/* 2912 */         anonymousClassDeclaration.resolveBinding();
/*      */       } 
/* 2914 */       return classInstanceCreation;
/*      */     } 
/* 2916 */     int start = allocation.sourceStart;
/* 2917 */     classInstanceCreation.setSourceRange(start, allocation.sourceEnd - start + 1);
/* 2918 */     if (this.resolveBindings) {
/* 2919 */       recordNodes(classInstanceCreation, (ASTNode)allocation);
/*      */     }
/* 2921 */     return classInstanceCreation;
/*      */   }
/*      */ 
/*      */   
/*      */   public Name convert(QualifiedNameReference nameReference) {
/* 2926 */     return setQualifiedNameNameAndSourceRanges(nameReference.tokens, nameReference.sourcePositions, (ASTNode)nameReference);
/*      */   }
/*      */   
/*      */   public Name convert(QualifiedSuperReference reference) {
/* 2930 */     return convert(reference.qualification);
/*      */   }
/*      */   
/*      */   public ThisExpression convert(QualifiedThisReference reference) {
/* 2934 */     ThisExpression thisExpression = new ThisExpression(this.ast);
/* 2935 */     thisExpression.setSourceRange(reference.sourceStart, reference.sourceEnd - reference.sourceStart + 1);
/* 2936 */     thisExpression.setQualifier(convert(reference.qualification));
/* 2937 */     if (this.resolveBindings) {
/* 2938 */       recordNodes(thisExpression, (ASTNode)reference);
/* 2939 */       recordPendingThisExpressionScopeResolution(thisExpression);
/*      */     } 
/* 2941 */     return thisExpression;
/*      */   }
/*      */   
/*      */   public Expression convert(Reference reference) {
/* 2945 */     if (reference instanceof NameReference) {
/* 2946 */       return convert((NameReference)reference);
/*      */     }
/* 2948 */     if (reference instanceof ThisReference) {
/* 2949 */       return convert((ThisReference)reference);
/*      */     }
/* 2951 */     if (reference instanceof ArrayReference) {
/* 2952 */       return convert((ArrayReference)reference);
/*      */     }
/* 2954 */     if (reference instanceof FieldReference) {
/* 2955 */       return convert((FieldReference)reference);
/*      */     }
/* 2957 */     return null;
/*      */   }
/*      */   
/*      */   public Expression convert(ReferenceExpression reference) {
/* 2961 */     if (this.ast.apiLevel < 8) {
/* 2962 */       return createFakeNullLiteral((Expression)reference);
/*      */     }
/* 2964 */     Expression result = null;
/* 2965 */     Expression lhs = reference.lhs;
/* 2966 */     TypeReference[] arguments = reference.typeArguments;
/* 2967 */     int start = (arguments != null && arguments.length > 0) ? ((arguments[arguments.length - 1]).sourceEnd + 1) : (reference.lhs.sourceEnd + 1);
/* 2968 */     SimpleName name = new SimpleName(this.ast);
/* 2969 */     retrieveIdentifierAndSetPositions(start, reference.sourceEnd, name);
/* 2970 */     name.internalSetIdentifier(new String(reference.selector));
/* 2971 */     if (this.resolveBindings) {
/* 2972 */       recordNodes(name, (ASTNode)reference);
/*      */     }
/* 2974 */     List<Type> typeArguments = null;
/* 2975 */     if (name.getStartPosition() == -1 && name.getIdentifier().equals("<init>")) {
/* 2976 */       retrieveInitAndSetPositions(start, reference.sourceEnd, name);
/* 2977 */       Type type = null;
/* 2978 */       if (lhs instanceof TypeReference) {
/* 2979 */         type = convertType((TypeReference)lhs);
/* 2980 */       } else if (lhs instanceof NameReference) {
/* 2981 */         Name typeName = convert((NameReference)lhs);
/* 2982 */         SimpleType simpleType = new SimpleType(this.ast);
/* 2983 */         simpleType.setName(typeName);
/* 2984 */         if (this.resolveBindings) {
/* 2985 */           recordNodes(simpleType, (ASTNode)lhs);
/*      */         }
/* 2987 */         simpleType.setSourceRange(lhs.sourceStart, lhs.sourceEnd - lhs.sourceStart + 1);
/* 2988 */         type = simpleType;
/*      */       } 
/* 2990 */       CreationReference creationReference = new CreationReference(this.ast);
/* 2991 */       creationReference.setType(type);
/* 2992 */       typeArguments = creationReference.typeArguments();
/* 2993 */       result = creationReference;
/* 2994 */     } else if (lhs instanceof TypeReference) {
/* 2995 */       TypeMethodReference typeMethodReference = new TypeMethodReference(this.ast);
/* 2996 */       typeMethodReference.setType(convertType((TypeReference)lhs));
/* 2997 */       typeMethodReference.setName(name);
/* 2998 */       typeArguments = typeMethodReference.typeArguments();
/* 2999 */       result = typeMethodReference;
/* 3000 */     } else if (lhs instanceof org.eclipse.jdt.internal.compiler.ast.SuperReference) {
/* 3001 */       SuperMethodReference superMethodReference = new SuperMethodReference(this.ast);
/* 3002 */       superMethodReference.setName(name);
/* 3003 */       typeArguments = superMethodReference.typeArguments();
/* 3004 */       result = superMethodReference;
/* 3005 */     } else if (lhs instanceof QualifiedSuperReference) {
/* 3006 */       SuperMethodReference superMethodReference = new SuperMethodReference(this.ast);
/* 3007 */       superMethodReference.setQualifier(convert((QualifiedSuperReference)lhs));
/* 3008 */       superMethodReference.setName(name);
/* 3009 */       typeArguments = superMethodReference.typeArguments();
/* 3010 */       result = superMethodReference;
/*      */     } else {
/* 3012 */       ExpressionMethodReference expressionMethodReference = new ExpressionMethodReference(this.ast);
/* 3013 */       expressionMethodReference.setExpression(convert(lhs));
/* 3014 */       typeArguments = expressionMethodReference.typeArguments();
/* 3015 */       expressionMethodReference.setName(name);
/* 3016 */       result = expressionMethodReference;
/*      */     } 
/* 3018 */     if (typeArguments != null && arguments != null) {
/* 3019 */       int argumentsLength = arguments.length;
/* 3020 */       for (int i = 0; i < argumentsLength; i++) {
/* 3021 */         TypeReference argument = arguments[i];
/* 3022 */         typeArguments.add(convertType(argument));
/*      */       } 
/*      */     } 
/* 3025 */     if (this.resolveBindings) {
/* 3026 */       recordNodes(result, (ASTNode)reference);
/*      */     }
/* 3028 */     int sourceStart = reference.sourceStart;
/* 3029 */     result.setSourceRange(sourceStart, reference.sourceEnd - sourceStart + 1);
/* 3030 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public ReturnStatement convert(ReturnStatement statement) {
/* 3035 */     ReturnStatement returnStatement = new ReturnStatement(this.ast);
/* 3036 */     returnStatement.setSourceRange(statement.sourceStart, statement.sourceEnd - statement.sourceStart + 1);
/* 3037 */     if (statement.expression != null) {
/* 3038 */       returnStatement.setExpression(convert(statement.expression));
/*      */     }
/* 3040 */     return returnStatement;
/*      */   }
/*      */   
/*      */   public SingleMemberAnnotation convert(SingleMemberAnnotation annotation) {
/* 3044 */     SingleMemberAnnotation singleMemberAnnotation = new SingleMemberAnnotation(this.ast);
/* 3045 */     setTypeNameForAnnotation((Annotation)annotation, singleMemberAnnotation);
/* 3046 */     singleMemberAnnotation.setValue(convert(annotation.memberValue));
/* 3047 */     int start = annotation.sourceStart;
/* 3048 */     int end = annotation.declarationSourceEnd;
/* 3049 */     singleMemberAnnotation.setSourceRange(start, end - start + 1);
/* 3050 */     if (this.resolveBindings) {
/* 3051 */       recordNodes(singleMemberAnnotation, (ASTNode)annotation);
/* 3052 */       singleMemberAnnotation.resolveAnnotationBinding();
/*      */     } 
/* 3054 */     return singleMemberAnnotation;
/*      */   }
/*      */   
/*      */   public SimpleName convert(SingleNameReference nameReference) {
/* 3058 */     SimpleName name = new SimpleName(this.ast);
/* 3059 */     name.internalSetIdentifier(new String(nameReference.token));
/* 3060 */     if (this.resolveBindings) {
/* 3061 */       recordNodes(name, (ASTNode)nameReference);
/*      */     }
/* 3063 */     name.setSourceRange(nameReference.sourceStart, nameReference.sourceEnd - nameReference.sourceStart + 1);
/* 3064 */     return name;
/*      */   }
/*      */   
/*      */   public Statement convert(Statement statement) {
/* 3068 */     if (statement instanceof ForeachStatement) {
/* 3069 */       return convert((ForeachStatement)statement);
/*      */     }
/* 3071 */     if (statement instanceof LocalDeclaration) {
/* 3072 */       LocalDeclaration localDeclaration = (LocalDeclaration)statement;
/* 3073 */       return convertToVariableDeclarationStatement(localDeclaration);
/*      */     } 
/* 3075 */     if (statement instanceof AssertStatement) {
/* 3076 */       return convert((AssertStatement)statement);
/*      */     }
/* 3078 */     if (statement instanceof Block) {
/* 3079 */       return convert((Block)statement);
/*      */     }
/* 3081 */     if (statement instanceof BreakStatement) {
/* 3082 */       return convert((BreakStatement)statement);
/*      */     }
/* 3084 */     if (statement instanceof ContinueStatement) {
/* 3085 */       return convert((ContinueStatement)statement);
/*      */     }
/* 3087 */     if (statement instanceof CaseStatement) {
/* 3088 */       return convert((CaseStatement)statement);
/*      */     }
/* 3090 */     if (statement instanceof DoStatement) {
/* 3091 */       return convert((DoStatement)statement);
/*      */     }
/* 3093 */     if (statement instanceof EmptyStatement) {
/* 3094 */       return convert((EmptyStatement)statement);
/*      */     }
/* 3096 */     if (statement instanceof ExplicitConstructorCall) {
/* 3097 */       return convert((ExplicitConstructorCall)statement);
/*      */     }
/* 3099 */     if (statement instanceof ForStatement) {
/* 3100 */       return convert((ForStatement)statement);
/*      */     }
/* 3102 */     if (statement instanceof IfStatement) {
/* 3103 */       return convert((IfStatement)statement);
/*      */     }
/* 3105 */     if (statement instanceof LabeledStatement) {
/* 3106 */       return convert((LabeledStatement)statement);
/*      */     }
/* 3108 */     if (statement instanceof ReturnStatement) {
/* 3109 */       return convert((ReturnStatement)statement);
/*      */     }
/* 3111 */     if (statement instanceof SwitchStatement) {
/* 3112 */       return convert((SwitchStatement)statement);
/*      */     }
/* 3114 */     if (statement instanceof SynchronizedStatement) {
/* 3115 */       return convert((SynchronizedStatement)statement);
/*      */     }
/* 3117 */     if (statement instanceof ThrowStatement) {
/* 3118 */       return convert((ThrowStatement)statement);
/*      */     }
/* 3120 */     if (statement instanceof TryStatement) {
/* 3121 */       return convert((TryStatement)statement);
/*      */     }
/* 3123 */     if (statement instanceof TypeDeclaration) {
/* 3124 */       TypeDeclaration typeDecl; ASTNode result = convert((TypeDeclaration)statement);
/* 3125 */       if (result == null || (!(result instanceof TypeDeclaration) && !(result instanceof RecordDeclaration) && !(result instanceof EnumDeclaration))) {
/* 3126 */         return createFakeEmptyStatement(statement);
/*      */       }
/* 3128 */       TypeDeclarationStatement typeDeclarationStatement = new TypeDeclarationStatement(this.ast);
/* 3129 */       if (result instanceof TypeDeclaration) {
/*      */         
/* 3131 */         TypeDeclaration typeDeclaration = (TypeDeclaration)result;
/* 3132 */         typeDeclarationStatement.setDeclaration(typeDeclaration);
/* 3133 */       } else if (result instanceof RecordDeclaration) {
/* 3134 */         RecordDeclaration recordDeclaration = (RecordDeclaration)result;
/* 3135 */         typeDeclarationStatement.setDeclaration(recordDeclaration);
/*      */       } else {
/* 3137 */         EnumDeclaration enumDeclaration = (EnumDeclaration)result;
/* 3138 */         typeDeclarationStatement.setDeclaration(enumDeclaration);
/*      */       } 
/* 3140 */       switch (this.ast.apiLevel)
/*      */       { case 2:
/* 3142 */           typeDecl = typeDeclarationStatement.internalGetTypeDeclaration();
/* 3143 */           typeDeclarationStatement.setSourceRange(typeDecl.getStartPosition(), typeDecl.getLength());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3150 */           return typeDeclarationStatement; }  AbstractTypeDeclaration typeDeclAST3 = typeDeclarationStatement.getDeclaration(); typeDeclarationStatement.setSourceRange(typeDeclAST3.getStartPosition(), typeDeclAST3.getLength()); return typeDeclarationStatement;
/*      */     } 
/* 3152 */     if (statement instanceof WhileStatement) {
/* 3153 */       return convert((WhileStatement)statement);
/*      */     }
/* 3155 */     if (statement instanceof YieldStatement) {
/* 3156 */       return convert((YieldStatement)statement);
/*      */     }
/* 3158 */     if (statement instanceof Expression && (
/* 3159 */       (Expression)statement).isTrulyExpression()) {
/* 3160 */       Expression statement2 = (Expression)statement;
/* 3161 */       Expression expr = convert(statement2);
/* 3162 */       ExpressionStatement stmt = new ExpressionStatement(this.ast);
/* 3163 */       stmt.setExpression(expr);
/* 3164 */       int sourceStart = expr.getStartPosition();
/* 3165 */       int sourceEnd = statement2.statementEnd;
/* 3166 */       stmt.setSourceRange(sourceStart, sourceEnd - sourceStart + 1);
/* 3167 */       return stmt;
/*      */     } 
/* 3169 */     return createFakeEmptyStatement(statement);
/*      */   }
/*      */   
/*      */   public Expression convert(StringLiteral expression) {
/* 3173 */     if (expression instanceof StringLiteralConcatenation) {
/* 3174 */       return convert((StringLiteralConcatenation)expression);
/*      */     }
/* 3176 */     int length = expression.sourceEnd - expression.sourceStart + 1;
/* 3177 */     int sourceStart = expression.sourceStart;
/* 3178 */     StringLiteral literal = new StringLiteral(this.ast);
/* 3179 */     if (this.resolveBindings) {
/* 3180 */       recordNodes(literal, (ASTNode)expression);
/*      */     }
/* 3182 */     literal.internalSetEscapedValue(new String(this.compilationUnitSource, sourceStart, length));
/* 3183 */     literal.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 3184 */     return literal;
/*      */   }
/*      */   
/*      */   public Expression convert(SwitchExpression expression) {
/* 3188 */     if (this.ast.apiLevel < 14) {
/* 3189 */       return createFakeNullLiteral((Expression)expression);
/*      */     }
/* 3191 */     SwitchExpression switchExpression = new SwitchExpression(this.ast);
/* 3192 */     if (this.resolveBindings) {
/* 3193 */       recordNodes(switchExpression, (ASTNode)expression);
/*      */     }
/* 3195 */     switchExpression.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 3196 */     switchExpression.setExpression(convert(expression.expression));
/* 3197 */     Statement[] statements = expression.statements;
/* 3198 */     if (statements != null) {
/* 3199 */       int statementsLength = statements.length;
/* 3200 */       for (int i = 0; i < statementsLength; i++) {
/* 3201 */         if (statements[i] instanceof LocalDeclaration) {
/* 3202 */           checkAndAddMultipleLocalDeclaration(statements, i, switchExpression.statements());
/*      */         } else {
/* 3204 */           Statement currentStatement = convert(statements[i]);
/* 3205 */           if (currentStatement != null) {
/* 3206 */             switchExpression.statements().add(currentStatement);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 3211 */     return switchExpression;
/*      */   }
/*      */   
/*      */   public SwitchStatement convert(SwitchStatement statement) {
/* 3215 */     SwitchStatement switchStatement = new SwitchStatement(this.ast);
/* 3216 */     switchStatement.setSourceRange(statement.sourceStart, statement.sourceEnd - statement.sourceStart + 1);
/* 3217 */     switchStatement.setExpression(convert(statement.expression));
/* 3218 */     Statement[] statements = statement.statements;
/* 3219 */     if (statements != null) {
/* 3220 */       int statementsLength = statements.length;
/* 3221 */       for (int i = 0; i < statementsLength; i++) {
/* 3222 */         if (statements[i] instanceof LocalDeclaration) {
/* 3223 */           checkAndAddMultipleLocalDeclaration(statements, i, switchStatement.statements());
/*      */         } else {
/* 3225 */           Statement currentStatement = convert(statements[i]);
/* 3226 */           if (currentStatement != null) {
/* 3227 */             switchStatement.statements().add(currentStatement);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 3232 */     return switchStatement;
/*      */   }
/*      */   
/*      */   public SynchronizedStatement convert(SynchronizedStatement statement) {
/* 3236 */     SynchronizedStatement synchronizedStatement = new SynchronizedStatement(this.ast);
/* 3237 */     synchronizedStatement.setSourceRange(statement.sourceStart, statement.sourceEnd - statement.sourceStart + 1);
/* 3238 */     synchronizedStatement.setBody(convert(statement.block));
/* 3239 */     synchronizedStatement.setExpression(convert(statement.expression));
/* 3240 */     return synchronizedStatement;
/*      */   }
/*      */   
/*      */   public Expression convert(TextBlock expression) {
/* 3244 */     if (this.ast.apiLevel < 15) {
/* 3245 */       return createFakeNullLiteral((Expression)expression);
/*      */     }
/* 3247 */     int length = expression.sourceEnd - expression.sourceStart + 1;
/* 3248 */     int sourceStart = expression.sourceStart;
/* 3249 */     TextBlock literal = new TextBlock(this.ast);
/* 3250 */     if (this.resolveBindings) {
/* 3251 */       recordNodes(literal, (ASTNode)expression);
/*      */     }
/* 3253 */     literal.internalSetEscapedValue(
/* 3254 */         new String(this.compilationUnitSource, sourceStart, length), 
/* 3255 */         new String(expression.source()));
/* 3256 */     literal.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 3257 */     return literal;
/*      */   }
/*      */   
/*      */   public Expression convert(ThisReference reference) {
/* 3261 */     if (reference.isImplicitThis())
/*      */     {
/* 3263 */       return null; } 
/* 3264 */     if (reference instanceof QualifiedSuperReference)
/* 3265 */       return convert((QualifiedSuperReference)reference); 
/* 3266 */     if (reference instanceof QualifiedThisReference) {
/* 3267 */       return convert((QualifiedThisReference)reference);
/*      */     }
/* 3269 */     ThisExpression thisExpression = new ThisExpression(this.ast);
/* 3270 */     thisExpression.setSourceRange(reference.sourceStart, reference.sourceEnd - reference.sourceStart + 1);
/* 3271 */     if (this.resolveBindings) {
/* 3272 */       recordNodes(thisExpression, (ASTNode)reference);
/* 3273 */       recordPendingThisExpressionScopeResolution(thisExpression);
/*      */     } 
/* 3275 */     return thisExpression;
/*      */   }
/*      */ 
/*      */   
/*      */   public ThrowStatement convert(ThrowStatement statement) {
/* 3280 */     ThrowStatement throwStatement = new ThrowStatement(this.ast);
/* 3281 */     throwStatement.setSourceRange(statement.sourceStart, statement.sourceEnd - statement.sourceStart + 1);
/* 3282 */     throwStatement.setExpression(convert(statement.exception));
/* 3283 */     return throwStatement;
/*      */   }
/*      */   
/*      */   public BooleanLiteral convert(TrueLiteral expression) {
/* 3287 */     BooleanLiteral literal = new BooleanLiteral(this.ast);
/* 3288 */     literal.setBooleanValue(true);
/* 3289 */     if (this.resolveBindings) {
/* 3290 */       recordNodes(literal, (ASTNode)expression);
/*      */     }
/* 3292 */     literal.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 3293 */     return literal;
/*      */   }
/*      */   
/*      */   public TryStatement convert(TryStatement statement) {
/* 3297 */     TryStatement tryStatement = new TryStatement(this.ast);
/* 3298 */     tryStatement.setSourceRange(statement.sourceStart, statement.sourceEnd - statement.sourceStart + 1);
/* 3299 */     int resourcesLength = statement.resources.length;
/* 3300 */     if (resourcesLength > 0) {
/* 3301 */       int i; switch (this.ast.apiLevel) {
/*      */         
/*      */         case 2:
/*      */         case 3:
/* 3305 */           tryStatement.setFlags(tryStatement.getFlags() | 0x1);
/*      */           break;
/*      */         case 4:
/*      */         case 8:
/* 3309 */           for (i = 0; i < resourcesLength; i++) {
/* 3310 */             if (!(statement.resources[i] instanceof LocalDeclaration)) {
/* 3311 */               tryStatement.setFlags(tryStatement.getFlags() | 0x1);
/*      */               break;
/*      */             } 
/* 3314 */             LocalDeclaration localDeclaration = (LocalDeclaration)statement.resources[i];
/* 3315 */             VariableDeclarationExpression variableDeclarationExpression = convertToVariableDeclarationExpression(localDeclaration);
/* 3316 */             int start = variableDeclarationExpression.getStartPosition();
/* 3317 */             int end = localDeclaration.declarationEnd;
/* 3318 */             variableDeclarationExpression.setSourceRange(start, end - start + 1);
/* 3319 */             tryStatement.resources().add(variableDeclarationExpression);
/*      */           } 
/*      */           break;
/*      */         default:
/* 3323 */           for (i = 0; i < resourcesLength; i++) {
/* 3324 */             Statement resource = statement.resources[i];
/* 3325 */             if (resource instanceof LocalDeclaration) {
/* 3326 */               LocalDeclaration localDeclaration = (LocalDeclaration)resource;
/* 3327 */               VariableDeclarationExpression variableDeclarationExpression = convertToVariableDeclarationExpression(localDeclaration);
/* 3328 */               int start = variableDeclarationExpression.getStartPosition();
/* 3329 */               int end = localDeclaration.declarationEnd;
/* 3330 */               variableDeclarationExpression.setSourceRange(start, end - start + 1);
/* 3331 */               tryStatement.resources().add(variableDeclarationExpression);
/* 3332 */             } else if (resource instanceof NameReference) {
/* 3333 */               tryStatement.resources().add(convert((NameReference)resource));
/* 3334 */             } else if (resource instanceof FieldReference) {
/* 3335 */               tryStatement.resources().add(convert((FieldReference)resource));
/*      */             } else {
/* 3337 */               tryStatement.setFlags(tryStatement.getFlags() | 0x1);
/*      */               break;
/*      */             } 
/*      */           } 
/*      */           break;
/*      */       } 
/*      */     } 
/* 3344 */     tryStatement.setBody(convert(statement.tryBlock));
/* 3345 */     Argument[] catchArguments = statement.catchArguments;
/* 3346 */     if (catchArguments != null) {
/* 3347 */       int catchArgumentsLength = catchArguments.length;
/* 3348 */       Block[] catchBlocks = statement.catchBlocks;
/* 3349 */       int start = statement.tryBlock.sourceEnd;
/* 3350 */       for (int i = 0; i < catchArgumentsLength; i++) {
/* 3351 */         CatchClause catchClause = new CatchClause(this.ast);
/* 3352 */         int catchClauseSourceStart = retrieveStartingCatchPosition(start, (catchArguments[i]).sourceStart);
/* 3353 */         catchClause.setSourceRange(catchClauseSourceStart, (catchBlocks[i]).sourceEnd - catchClauseSourceStart + 1);
/* 3354 */         catchClause.setBody(convert(catchBlocks[i]));
/* 3355 */         catchClause.setException(convert(catchArguments[i]));
/* 3356 */         tryStatement.catchClauses().add(catchClause);
/* 3357 */         start = (catchBlocks[i]).sourceEnd;
/*      */       } 
/*      */     } 
/* 3360 */     if (statement.finallyBlock != null) {
/* 3361 */       tryStatement.setFinally(convert(statement.finallyBlock));
/*      */     }
/* 3363 */     return tryStatement;
/*      */   }
/*      */   
/*      */   public ASTNode convert(TypeDeclaration typeDeclaration) {
/* 3367 */     int kind = TypeDeclaration.kind(typeDeclaration.modifiers);
/* 3368 */     switch (kind) {
/*      */       case 3:
/* 3370 */         if (this.ast.apiLevel == 2) {
/* 3371 */           return null;
/*      */         }
/* 3373 */         return convertToEnumDeclaration(typeDeclaration);
/*      */       
/*      */       case 4:
/* 3376 */         if (this.ast.apiLevel == 2) {
/* 3377 */           return null;
/*      */         }
/* 3379 */         return convertToAnnotationDeclaration(typeDeclaration);
/*      */     } 
/*      */     
/* 3382 */     if (typeDeclaration.isRecord()) {
/* 3383 */       if (!DOMASTUtil.isRecordDeclarationSupported(this.ast)) {
/* 3384 */         return null;
/*      */       }
/* 3386 */       return convertToRecordDeclaration(typeDeclaration);
/*      */     } 
/* 3388 */     checkCanceled();
/* 3389 */     TypeDeclaration typeDecl = new TypeDeclaration(this.ast);
/* 3390 */     ASTNode oldReferenceContext = this.referenceContext;
/* 3391 */     this.referenceContext = typeDecl;
/* 3392 */     if (typeDeclaration.modifiersSourceStart != -1) {
/* 3393 */       setModifiers(typeDecl, typeDeclaration);
/*      */     }
/* 3395 */     boolean isInterface = (kind == 2);
/* 3396 */     typeDecl.setInterface(isInterface);
/* 3397 */     SimpleName typeName = new SimpleName(this.ast);
/* 3398 */     typeName.internalSetIdentifier(new String(typeDeclaration.name));
/* 3399 */     typeName.setSourceRange(typeDeclaration.sourceStart, typeDeclaration.sourceEnd - typeDeclaration.sourceStart + 1);
/* 3400 */     typeDecl.setName(typeName);
/* 3401 */     typeDecl.setSourceRange(typeDeclaration.declarationSourceStart, typeDeclaration.bodyEnd - typeDeclaration.declarationSourceStart + 1);
/*      */ 
/*      */ 
/*      */     
/* 3405 */     if (typeDeclaration.superclass != null) {
/* 3406 */       switch (this.ast.apiLevel) {
/*      */         case 2:
/* 3408 */           typeDecl.internalSetSuperclass(convert(typeDeclaration.superclass));
/*      */           break;
/*      */         default:
/* 3411 */           typeDecl.setSuperclassType(convertType(typeDeclaration.superclass));
/*      */           break;
/*      */       } 
/*      */     
/*      */     }
/* 3416 */     TypeReference[] superInterfaces = typeDeclaration.superInterfaces;
/* 3417 */     if (superInterfaces != null) {
/* 3418 */       int index; int length; switch (this.ast.apiLevel) {
/*      */         case 2:
/* 3420 */           for (index = 0, length = superInterfaces.length; index < length; index++) {
/* 3421 */             typeDecl.internalSuperInterfaces().add(convert(superInterfaces[index]));
/*      */           }
/*      */           break;
/*      */         default:
/* 3425 */           for (index = 0, length = superInterfaces.length; index < length; index++)
/* 3426 */             typeDecl.superInterfaceTypes().add(convertType(superInterfaces[index])); 
/*      */           break;
/*      */       } 
/*      */     } 
/* 3430 */     TypeParameter[] typeParameters = typeDeclaration.typeParameters;
/* 3431 */     if (typeParameters != null) {
/* 3432 */       int index; int length; switch (this.ast.apiLevel) {
/*      */         case 2:
/* 3434 */           typeDecl.setFlags(typeDecl.getFlags() | 0x1);
/*      */           break;
/*      */         default:
/* 3437 */           for (index = 0, length = typeParameters.length; index < length; index++)
/* 3438 */             typeDecl.typeParameters().add(convert(typeParameters[index])); 
/*      */           break;
/*      */       } 
/*      */     } 
/* 3442 */     TypeReference[] permittedTypes = typeDeclaration.permittedTypes;
/* 3443 */     if (permittedTypes != null && 
/* 3444 */       DOMASTUtil.isFeatureSupportedinAST(this.ast, 512)) {
/* 3445 */       for (int index = 0, length = permittedTypes.length; index < length; index++) {
/* 3446 */         Type convertType = convertType(permittedTypes[index]);
/* 3447 */         if (convertType != null) {
/* 3448 */           typeDecl.permittedTypes().add(convertType);
/*      */         }
/*      */       } 
/* 3451 */       if (permittedTypes.length > 0 && typeDeclaration.restrictedIdentifierStart >= 0) {
/* 3452 */         typeDecl.setRestrictedIdentifierStartPosition(typeDeclaration.restrictedIdentifierStart);
/*      */       }
/*      */     } 
/*      */     
/* 3456 */     buildBodyDeclarations(typeDeclaration, typeDecl, isInterface);
/* 3457 */     if (this.resolveBindings) {
/* 3458 */       recordNodes(typeDecl, (ASTNode)typeDeclaration);
/* 3459 */       recordNodes(typeName, (ASTNode)typeDeclaration);
/* 3460 */       typeDecl.resolveBinding();
/*      */     } 
/* 3462 */     this.referenceContext = oldReferenceContext;
/* 3463 */     return typeDecl;
/*      */   }
/*      */   
/*      */   public TypeParameter convert(TypeParameter typeParameter) {
/* 3467 */     TypeParameter typeParameter2 = new TypeParameter(this.ast);
/* 3468 */     SimpleName simpleName = new SimpleName(this.ast);
/* 3469 */     simpleName.internalSetIdentifier(new String(typeParameter.name));
/* 3470 */     int start = typeParameter.sourceStart;
/* 3471 */     int end = typeParameter.sourceEnd;
/* 3472 */     simpleName.setSourceRange(start, end - start + 1);
/* 3473 */     typeParameter2.setName(simpleName);
/* 3474 */     int annotationsStart = start;
/* 3475 */     Annotation[] annotations = typeParameter.annotations;
/* 3476 */     if (annotations != null) {
/* 3477 */       if (annotations[0] != null)
/* 3478 */         annotationsStart = (annotations[0]).sourceStart; 
/* 3479 */       annotateTypeParameter(typeParameter2, typeParameter.annotations);
/*      */     } 
/* 3481 */     TypeReference superType = typeParameter.type;
/* 3482 */     end = typeParameter.declarationSourceEnd;
/* 3483 */     if (superType != null) {
/* 3484 */       Type type = convertType(superType);
/* 3485 */       typeParameter2.typeBounds().add(type);
/* 3486 */       end = type.getStartPosition() + type.getLength() - 1;
/*      */     } 
/* 3488 */     TypeReference[] bounds = typeParameter.bounds;
/* 3489 */     if (bounds != null) {
/* 3490 */       Type type = null;
/* 3491 */       for (int index = 0, length = bounds.length; index < length; index++) {
/* 3492 */         type = convertType(bounds[index]);
/* 3493 */         typeParameter2.typeBounds().add(type);
/* 3494 */         end = type.getStartPosition() + type.getLength() - 1;
/*      */       } 
/*      */     } 
/* 3497 */     start = (annotationsStart < typeParameter.declarationSourceStart) ? annotationsStart : typeParameter.declarationSourceStart;
/* 3498 */     end = retrieveClosingAngleBracketPosition(end);
/* 3499 */     typeParameter2.setSourceRange(start, end - start + 1);
/* 3500 */     if (this.resolveBindings) {
/* 3501 */       recordName(simpleName, (ASTNode)typeParameter);
/* 3502 */       recordNodes(typeParameter2, (ASTNode)typeParameter);
/* 3503 */       typeParameter2.resolveBinding();
/*      */     } 
/* 3505 */     return typeParameter2;
/*      */   }
/*      */   
/*      */   public Pattern convert(TypePattern pattern) {
/* 3509 */     TypePattern typePattern = new TypePattern(this.ast);
/* 3510 */     if (this.resolveBindings) {
/* 3511 */       recordNodes(typePattern, (ASTNode)pattern);
/*      */     }
/* 3513 */     if (pattern.local == null) {
/* 3514 */       return createFakeNullPattern((Pattern)pattern);
/*      */     }
/* 3516 */     typePattern.setPatternVariable(convertToSingleVariableDeclaration(pattern.local));
/* 3517 */     int startPosition = pattern.local.declarationSourceStart;
/* 3518 */     int sourceEnd = pattern.sourceEnd;
/* 3519 */     typePattern.setSourceRange(startPosition, sourceEnd - startPosition + 1);
/* 3520 */     return typePattern;
/*      */   }
/*      */   
/*      */   public Name convert(TypeReference typeReference) {
/* 3524 */     char[][] typeName = typeReference.getTypeName();
/* 3525 */     int length = typeName.length;
/* 3526 */     if (length > 1) {
/*      */       
/* 3528 */       QualifiedTypeReference qualifiedTypeReference = (QualifiedTypeReference)typeReference;
/* 3529 */       long[] positions = qualifiedTypeReference.sourcePositions;
/* 3530 */       return setQualifiedNameNameAndSourceRanges(typeName, positions, (ASTNode)typeReference);
/*      */     } 
/* 3532 */     SimpleName name = new SimpleName(this.ast);
/* 3533 */     name.internalSetIdentifier(new String(typeName[0]));
/* 3534 */     name.setSourceRange(typeReference.sourceStart, typeReference.sourceEnd - typeReference.sourceStart + 1);
/* 3535 */     name.index = 1;
/* 3536 */     if (this.resolveBindings) {
/* 3537 */       recordNodes(name, (ASTNode)typeReference);
/*      */     }
/* 3539 */     return name;
/*      */   }
/*      */ 
/*      */   
/*      */   public PrefixExpression convert(UnaryExpression expression) {
/* 3544 */     PrefixExpression prefixExpression = new PrefixExpression(this.ast);
/* 3545 */     if (this.resolveBindings) {
/* 3546 */       recordNodes(prefixExpression, (ASTNode)expression);
/*      */     }
/* 3548 */     prefixExpression.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 3549 */     prefixExpression.setOperand(convert(expression.expression));
/* 3550 */     switch ((expression.bits & 0x3F00) >> 8) {
/*      */       case 14:
/* 3552 */         prefixExpression.setOperator(PrefixExpression.Operator.PLUS);
/*      */         break;
/*      */       case 13:
/* 3555 */         prefixExpression.setOperator(PrefixExpression.Operator.MINUS);
/*      */         break;
/*      */       case 11:
/* 3558 */         prefixExpression.setOperator(PrefixExpression.Operator.NOT);
/*      */         break;
/*      */       case 12:
/* 3561 */         prefixExpression.setOperator(PrefixExpression.Operator.COMPLEMENT); break;
/*      */     } 
/* 3563 */     return prefixExpression;
/*      */   }
/*      */   
/*      */   public WhileStatement convert(WhileStatement statement) {
/* 3567 */     WhileStatement whileStatement = new WhileStatement(this.ast);
/* 3568 */     whileStatement.setSourceRange(statement.sourceStart, statement.sourceEnd - statement.sourceStart + 1);
/* 3569 */     whileStatement.setExpression(convert(statement.condition));
/* 3570 */     Statement action = convert(statement.action);
/* 3571 */     if (action == null) return null; 
/* 3572 */     whileStatement.setBody(action);
/* 3573 */     return whileStatement;
/*      */   }
/*      */   
/*      */   public Statement convert(YieldStatement statement) {
/* 3577 */     if (this.ast.apiLevel < 14) {
/* 3578 */       return createFakeEmptyStatement((Statement)statement);
/*      */     }
/* 3580 */     YieldStatement yieldStatement = new YieldStatement(this.ast);
/*      */     
/* 3582 */     yieldStatement.setExpression(convert(statement.expression));
/* 3583 */     yieldStatement.setImplicit(statement.isImplicit);
/* 3584 */     yieldStatement.setSourceRange(statement.sourceStart, statement.sourceEnd - statement.sourceStart + 1);
/* 3585 */     return yieldStatement;
/*      */   }
/*      */   
/*      */   public ImportDeclaration convertImport(ImportReference importReference) {
/* 3589 */     ImportDeclaration importDeclaration = new ImportDeclaration(this.ast);
/* 3590 */     Name name = getImportName(importReference);
/* 3591 */     importDeclaration.setName(name);
/* 3592 */     boolean onDemand = ((importReference.bits & 0x20000) != 0);
/* 3593 */     importDeclaration.setSourceRange(importReference.declarationSourceStart, importReference.declarationEnd - importReference.declarationSourceStart + 1);
/* 3594 */     importDeclaration.setOnDemand(onDemand);
/* 3595 */     int modifiers = importReference.modifiers;
/* 3596 */     if (modifiers != 0) {
/* 3597 */       switch (this.ast.apiLevel) {
/*      */         case 2:
/* 3599 */           importDeclaration.setFlags(importDeclaration.getFlags() | 0x1);
/*      */           break;
/*      */         default:
/* 3602 */           if (modifiers == 8) {
/* 3603 */             importDeclaration.setStatic(true); break;
/*      */           } 
/* 3605 */           importDeclaration.setFlags(importDeclaration.getFlags() | 0x1);
/*      */           break;
/*      */       } 
/*      */     }
/* 3609 */     if (this.resolveBindings) {
/* 3610 */       recordNodes(importDeclaration, (ASTNode)importReference);
/*      */     }
/* 3612 */     return importDeclaration;
/*      */   }
/*      */   
/*      */   public Name getImportName(ImportReference importReference) {
/* 3616 */     return getName((ASTNode)importReference, importReference.tokens, importReference.sourcePositions);
/*      */   }
/*      */ 
/*      */   
/*      */   private Name getName(ASTNode node, char[][] tokens, long[] positions) {
/*      */     Name name;
/* 3622 */     int length = (tokens != null) ? tokens.length : 0;
/* 3623 */     if (length > 1) {
/* 3624 */       name = setQualifiedNameNameAndSourceRanges(tokens, positions, node);
/*      */     } else {
/* 3626 */       name = new SimpleName(this.ast);
/* 3627 */       ((SimpleName)name).internalSetIdentifier(new String(tokens[0]));
/* 3628 */       int start = (int)(positions[0] >>> 32L);
/* 3629 */       int end = (int)(positions[0] & 0xFFFFFFFFFFFFFFFFL);
/* 3630 */       name.setSourceRange(start, end - start + 1);
/* 3631 */       name.index = 1;
/* 3632 */       if (this.resolveBindings) {
/* 3633 */         recordNodes(name, node);
/*      */       }
/*      */     } 
/* 3636 */     return name;
/*      */   }
/*      */   
/*      */   public PackageDeclaration convertPackage(CompilationUnitDeclaration compilationUnitDeclaration) {
/* 3640 */     ImportReference importReference = compilationUnitDeclaration.currentPackage;
/* 3641 */     PackageDeclaration packageDeclaration = new PackageDeclaration(this.ast);
/* 3642 */     char[][] tokens = importReference.tokens;
/* 3643 */     int length = importReference.tokens.length;
/* 3644 */     long[] positions = importReference.sourcePositions;
/* 3645 */     if (length > 1) {
/* 3646 */       packageDeclaration.setName(setQualifiedNameNameAndSourceRanges(tokens, positions, (ASTNode)importReference));
/*      */     } else {
/* 3648 */       SimpleName name = new SimpleName(this.ast);
/* 3649 */       name.internalSetIdentifier(new String(tokens[0]));
/* 3650 */       int start = (int)(positions[0] >>> 32L);
/* 3651 */       int end = (int)(positions[length - 1] & 0xFFFFFFFFFFFFFFFFL);
/* 3652 */       name.setSourceRange(start, end - start + 1);
/* 3653 */       name.index = 1;
/* 3654 */       packageDeclaration.setName(name);
/* 3655 */       if (this.resolveBindings) {
/* 3656 */         recordNodes(name, (ASTNode)compilationUnitDeclaration);
/*      */       }
/*      */     } 
/* 3659 */     packageDeclaration.setSourceRange(importReference.declarationSourceStart, importReference.declarationEnd - importReference.declarationSourceStart + 1);
/* 3660 */     Annotation[] annotations = importReference.annotations;
/* 3661 */     if (annotations != null) {
/* 3662 */       int i; int max; switch (this.ast.apiLevel) {
/*      */         case 2:
/* 3664 */           packageDeclaration.setFlags(packageDeclaration.getFlags() & 0x1);
/*      */           break;
/*      */         default:
/* 3667 */           for (i = 0, max = annotations.length; i < max; i++)
/* 3668 */             packageDeclaration.annotations().add(convert(annotations[i])); 
/*      */           break;
/*      */       } 
/*      */     } 
/* 3672 */     if (this.resolveBindings) {
/* 3673 */       recordNodes(packageDeclaration, (ASTNode)importReference);
/*      */     }
/*      */     
/* 3676 */     convert(compilationUnitDeclaration.javadoc, packageDeclaration);
/* 3677 */     return packageDeclaration;
/*      */   }
/*      */   
/*      */   private ArrayType convertToArray(Type elementType, int sourceStart, int length, int dimensions, Annotation[][] annotationsOnDimensions) {
/* 3681 */     ArrayType arrayType = this.ast.newArrayType(elementType, dimensions);
/* 3682 */     if (length > 0) arrayType.setSourceRange(sourceStart, length); 
/* 3683 */     if (this.ast.apiLevel() < 8) {
/* 3684 */       if (annotationsOnDimensions != null) {
/* 3685 */         arrayType.setFlags(arrayType.getFlags() | 0x1);
/*      */       }
/* 3687 */       ArrayType subarrayType = arrayType;
/* 3688 */       int index = dimensions - 1;
/* 3689 */       int arrayEnd = retrieveProperRightBracketPosition(dimensions, sourceStart);
/* 3690 */       while (index > 0) {
/* 3691 */         subarrayType = (ArrayType)componentType(subarrayType);
/* 3692 */         int end = retrieveProperRightBracketPosition(index, sourceStart);
/* 3693 */         subarrayType.setSourceRange(sourceStart, end - sourceStart + 1);
/* 3694 */         index--;
/*      */       } 
/* 3696 */       if (length < arrayEnd - sourceStart) arrayType.setSourceRange(sourceStart, arrayEnd - sourceStart + 1); 
/* 3697 */       return arrayType;
/*      */     } 
/*      */     
/* 3700 */     setTypeAnnotationsAndSourceRangeOnArray(arrayType, annotationsOnDimensions);
/* 3701 */     return arrayType;
/*      */   }
/*      */   
/*      */   private EnumDeclaration convertToEnumDeclaration(TypeDeclaration typeDeclaration) {
/* 3705 */     checkCanceled();
/*      */     
/* 3707 */     EnumDeclaration enumDeclaration2 = new EnumDeclaration(this.ast);
/* 3708 */     setModifiers(enumDeclaration2, typeDeclaration);
/* 3709 */     SimpleName typeName = new SimpleName(this.ast);
/* 3710 */     typeName.internalSetIdentifier(new String(typeDeclaration.name));
/* 3711 */     typeName.setSourceRange(typeDeclaration.sourceStart, typeDeclaration.sourceEnd - typeDeclaration.sourceStart + 1);
/* 3712 */     enumDeclaration2.setName(typeName);
/* 3713 */     enumDeclaration2.setSourceRange(typeDeclaration.declarationSourceStart, typeDeclaration.bodyEnd - typeDeclaration.declarationSourceStart + 1);
/*      */     
/* 3715 */     TypeReference[] superInterfaces = typeDeclaration.superInterfaces;
/* 3716 */     if (superInterfaces != null) {
/* 3717 */       for (int index = 0, length = superInterfaces.length; index < length; index++) {
/* 3718 */         enumDeclaration2.superInterfaceTypes().add(convertType(superInterfaces[index]));
/*      */       }
/*      */     }
/* 3721 */     buildBodyDeclarations(typeDeclaration, enumDeclaration2);
/* 3722 */     if (this.resolveBindings) {
/* 3723 */       recordNodes(enumDeclaration2, (ASTNode)typeDeclaration);
/* 3724 */       recordNodes(typeName, (ASTNode)typeDeclaration);
/* 3725 */       enumDeclaration2.resolveBinding();
/*      */     } 
/* 3727 */     return enumDeclaration2;
/*      */   }
/*      */   
/*      */   private RecordDeclaration convertToRecordDeclaration(TypeDeclaration typeDeclaration) {
/* 3731 */     checkCanceled();
/*      */     
/* 3733 */     RecordDeclaration recordDeclaration = new RecordDeclaration(this.ast);
/* 3734 */     setModifiers(recordDeclaration, typeDeclaration);
/* 3735 */     SimpleName typeName = new SimpleName(this.ast);
/* 3736 */     typeName.internalSetIdentifier(new String(typeDeclaration.name));
/* 3737 */     typeName.setSourceRange(typeDeclaration.sourceStart, typeDeclaration.name.length);
/* 3738 */     recordDeclaration.setName(typeName);
/* 3739 */     recordDeclaration.setSourceRange(typeDeclaration.declarationSourceStart, typeDeclaration.bodyEnd - typeDeclaration.declarationSourceStart + 1);
/* 3740 */     recordDeclaration.setRestrictedIdentifierStartPosition(typeDeclaration.restrictedIdentifierStart);
/*      */     
/* 3742 */     TypeReference[] superInterfaces = typeDeclaration.superInterfaces;
/* 3743 */     if (superInterfaces != null) {
/* 3744 */       byte b; int i; TypeReference[] arrayOfTypeReference; for (i = (arrayOfTypeReference = superInterfaces).length, b = 0; b < i; ) { TypeReference superInterface = arrayOfTypeReference[b];
/* 3745 */         recordDeclaration.superInterfaceTypes().add(convertType(superInterface)); b++; }
/*      */     
/*      */     } 
/* 3748 */     TypeParameter[] typeParameters = typeDeclaration.typeParameters;
/* 3749 */     if (typeParameters != null) {
/* 3750 */       byte b; int i; TypeParameter[] arrayOfTypeParameter; for (i = (arrayOfTypeParameter = typeParameters).length, b = 0; b < i; ) { TypeParameter typeParameter = arrayOfTypeParameter[b];
/* 3751 */         recordDeclaration.typeParameters().add(convert(typeParameter)); b++; }
/*      */     
/*      */     } 
/* 3754 */     RecordComponent[] recComps = typeDeclaration.recordComponents;
/* 3755 */     if (recComps != null) {
/* 3756 */       byte b; int i; RecordComponent[] arrayOfRecordComponent; for (i = (arrayOfRecordComponent = recComps).length, b = 0; b < i; ) { RecordComponent recComp = arrayOfRecordComponent[b];
/* 3757 */         recordDeclaration.recordComponents().add(convert(recComp)); b++; }
/*      */     
/*      */     } 
/* 3760 */     buildBodyDeclarations(typeDeclaration, recordDeclaration, false);
/* 3761 */     if (this.resolveBindings) {
/* 3762 */       recordNodes(recordDeclaration, (ASTNode)typeDeclaration);
/* 3763 */       recordNodes(typeName, (ASTNode)typeDeclaration);
/* 3764 */       recordDeclaration.resolveBinding();
/*      */     } 
/* 3766 */     return recordDeclaration;
/*      */   }
/*      */   public Expression convertToExpression(Statement statement) {
/* 3769 */     if (statement instanceof Expression && (
/* 3770 */       (Expression)statement).isTrulyExpression()) {
/* 3771 */       return convert((Expression)statement);
/*      */     }
/* 3773 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected FieldDeclaration convertToFieldDeclaration(FieldDeclaration fieldDecl) {
/* 3778 */     VariableDeclarationFragment variableDeclarationFragment = convertToVariableDeclarationFragment(fieldDecl);
/* 3779 */     FieldDeclaration fieldDeclaration = new FieldDeclaration(this.ast);
/* 3780 */     fieldDeclaration.fragments().add(variableDeclarationFragment);
/* 3781 */     if (this.resolveBindings) {
/* 3782 */       recordNodes(variableDeclarationFragment, (ASTNode)fieldDecl);
/* 3783 */       variableDeclarationFragment.resolveBinding();
/*      */     } 
/* 3785 */     fieldDeclaration.setSourceRange(fieldDecl.declarationSourceStart, fieldDecl.declarationEnd - fieldDecl.declarationSourceStart + 1);
/* 3786 */     Type type = convertType(fieldDecl.type);
/* 3787 */     setTypeForField(fieldDeclaration, type, variableDeclarationFragment.getExtraDimensions());
/* 3788 */     setModifiers(fieldDeclaration, fieldDecl);
/* 3789 */     convert(fieldDecl.javadoc, fieldDeclaration);
/* 3790 */     return fieldDeclaration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getKnownEnd(ModuleDeclaration md, int sourceEnd, int declSourceEnd) {
/* 3800 */     int end = retrieveRightBrace(md.getStartPosition() + 1, this.compilationUnitSourceLength);
/* 3801 */     end = (end > sourceEnd) ? end : sourceEnd;
/* 3802 */     end = (end > declSourceEnd) ? end : declSourceEnd;
/* 3803 */     return end;
/*      */   }
/*      */   public ModuleDeclaration convertToModuleDeclaration(ModuleDeclaration moduleDeclaration) {
/* 3806 */     checkCanceled();
/* 3807 */     if (this.scanner.sourceLevel < 3473408L || 
/* 3808 */       this.ast.apiLevel < 9) return null; 
/* 3809 */     ModuleDeclaration moduleDecl = this.ast.newModuleDeclaration();
/*      */ 
/*      */     
/* 3812 */     setAnnotations(moduleDecl, moduleDeclaration);
/* 3813 */     moduleDecl.setOpen(moduleDeclaration.isOpen());
/* 3814 */     Name moduleName = getName((ASTNode)moduleDeclaration, CharOperation.splitOn('.', moduleDeclaration.moduleName), moduleDeclaration.sourcePositions);
/* 3815 */     moduleDecl.setName(moduleName);
/*      */     
/* 3817 */     List<ModuleDirective> stmts = moduleDecl.moduleStatements();
/* 3818 */     TreeSet<ModuleDirective> tSet = new TreeSet<>(new Comparator<ModuleDirective>()
/*      */         {
/*      */           public int compare(Object o1, Object o2) {
/* 3821 */             int p1 = ((ModuleDirective)o1).getStartPosition();
/* 3822 */             int p2 = ((ModuleDirective)o2).getStartPosition();
/* 3823 */             return (p1 < p2) ? -1 : ((p1 == p2) ? 0 : 1); }
/*      */         });
/*      */     int i;
/* 3826 */     for (i = 0; i < moduleDeclaration.exportsCount; i++) {
/* 3827 */       tSet.add(getPackageVisibilityStatement((PackageVisibilityStatement)moduleDeclaration.exports[i], new ExportsDirective(this.ast)));
/*      */     }
/* 3829 */     for (i = 0; i < moduleDeclaration.opensCount; i++) {
/* 3830 */       tSet.add(getPackageVisibilityStatement((PackageVisibilityStatement)moduleDeclaration.opens[i], new OpensDirective(this.ast)));
/*      */     }
/* 3832 */     for (i = 0; i < moduleDeclaration.requiresCount; i++) {
/* 3833 */       RequiresStatement req = moduleDeclaration.requires[i];
/* 3834 */       ModuleReference moduleRef = req.module;
/* 3835 */       RequiresDirective stmt = new RequiresDirective(this.ast);
/* 3836 */       Name name = getName((ASTNode)moduleRef, CharOperation.splitOn('.', moduleRef.moduleName), moduleRef.sourcePositions);
/* 3837 */       stmt.setName(name);
/* 3838 */       if (this.resolveBindings) {
/* 3839 */         recordNodes(name, (ASTNode)moduleRef);
/*      */       }
/*      */       
/* 3842 */       setModuleModifiers(req, stmt);
/* 3843 */       stmt.setSourceRange(req.declarationSourceStart, req.declarationEnd - req.declarationSourceStart + 1);
/* 3844 */       tSet.add(stmt);
/*      */     } 
/* 3846 */     for (i = 0; i < moduleDeclaration.usesCount; i++) {
/* 3847 */       UsesStatement usesStatement = moduleDeclaration.uses[i];
/* 3848 */       UsesDirective stmt = new UsesDirective(this.ast);
/* 3849 */       TypeReference usesRef = usesStatement.serviceInterface;
/* 3850 */       Name name = convert(usesRef);
/* 3851 */       stmt.setName(name);
/* 3852 */       stmt.setSourceRange(usesStatement.declarationSourceStart, usesStatement.declarationSourceEnd - usesStatement.declarationSourceStart + 1);
/* 3853 */       tSet.add(stmt);
/*      */     } 
/* 3855 */     for (i = 0; i < moduleDeclaration.servicesCount; i++) {
/* 3856 */       ProvidesStatement pStmt = moduleDeclaration.services[i];
/* 3857 */       ProvidesDirective stmt = new ProvidesDirective(this.ast);
/* 3858 */       stmt.setName(convert(pStmt.serviceInterface));
/* 3859 */       TypeReference[] impls = pStmt.implementations; byte b; int j; TypeReference[] arrayOfTypeReference1;
/* 3860 */       for (j = (arrayOfTypeReference1 = impls).length, b = 0; b < j; ) { TypeReference impl = arrayOfTypeReference1[b];
/* 3861 */         stmt.implementations().add(convert(impl)); b++; }
/*      */       
/* 3863 */       stmt.setSourceRange(pStmt.declarationSourceStart, pStmt.declarationSourceEnd - pStmt.declarationSourceStart + 1);
/* 3864 */       tSet.add(stmt);
/*      */     } 
/*      */     
/* 3867 */     if (this.resolveBindings) {
/* 3868 */       recordNodes(moduleDecl, (ASTNode)moduleDeclaration);
/* 3869 */       recordNodes(moduleName, (ASTNode)moduleDeclaration);
/* 3870 */       moduleDecl.resolveBinding();
/*      */     } 
/* 3872 */     stmts.addAll(tSet);
/* 3873 */     int end = getKnownEnd(moduleDecl, moduleDeclaration.sourceEnd, moduleDeclaration.declarationSourceEnd);
/* 3874 */     moduleDecl.setSourceRange(moduleDeclaration.declarationSourceStart, end - moduleDeclaration.declarationSourceStart + 1);
/* 3875 */     return moduleDecl;
/*      */   }
/*      */   
/*      */   private void setModuleModifiers(RequiresStatement req, RequiresDirective stmt) {
/* 3879 */     boolean fakeInModule = this.scanner.fakeInModule;
/* 3880 */     this.scanner.fakeInModule = true;
/* 3881 */     this.scanner.resetTo(req.declarationSourceStart, req.sourceEnd);
/*      */     
/*      */     try {
/*      */       int token;
/* 3885 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 3886 */         ModuleModifier modifier; switch (token) {
/*      */           case 37:
/* 3888 */             modifier = createModuleModifier(ModuleModifier.ModuleModifierKeyword.STATIC_KEYWORD);
/*      */             break;
/*      */           case 128:
/* 3891 */             modifier = createModuleModifier(ModuleModifier.ModuleModifierKeyword.TRANSITIVE_KEYWORD);
/*      */             break;
/*      */           default:
/*      */             continue;
/*      */         } 
/* 3896 */         if (modifier != null) {
/* 3897 */           stmt.modifiers().add(modifier);
/*      */         }
/*      */       } 
/* 3900 */     } catch (InvalidInputException invalidInputException) {
/*      */     
/*      */     } finally {
/* 3903 */       this.scanner.fakeInModule = fakeInModule;
/*      */     } 
/*      */   }
/*      */   
/*      */   public ParenthesizedExpression convertToParenthesizedExpression(Expression expression) {
/* 3908 */     ParenthesizedExpression parenthesizedExpression = new ParenthesizedExpression(this.ast);
/* 3909 */     if (this.resolveBindings) {
/* 3910 */       recordNodes(parenthesizedExpression, (ASTNode)expression);
/*      */     }
/* 3912 */     parenthesizedExpression.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 3913 */     adjustSourcePositionsForParent(expression);
/* 3914 */     trimWhiteSpacesAndComments(expression);
/*      */     
/* 3916 */     int numberOfParenthesis = (expression.bits & 0x1FE00000) >> 21;
/* 3917 */     expression.bits &= 0xE01FFFFF;
/* 3918 */     expression.bits |= numberOfParenthesis - 1 << 21;
/* 3919 */     parenthesizedExpression.setExpression(convert(expression));
/* 3920 */     return parenthesizedExpression;
/*      */   }
/*      */   
/*      */   protected VariableDeclarationExpression convertToVariableDeclarationExpression(LocalDeclaration localDeclaration) {
/* 3924 */     VariableDeclarationFragment variableDeclarationFragment = convertToVariableDeclarationFragment(localDeclaration);
/* 3925 */     VariableDeclarationExpression variableDeclarationExpression = new VariableDeclarationExpression(this.ast);
/* 3926 */     variableDeclarationExpression.fragments().add(variableDeclarationFragment);
/* 3927 */     if (this.resolveBindings) {
/* 3928 */       recordNodes(variableDeclarationFragment, (ASTNode)localDeclaration);
/*      */     }
/* 3930 */     variableDeclarationExpression.setSourceRange(localDeclaration.declarationSourceStart, localDeclaration.declarationSourceEnd - localDeclaration.declarationSourceStart + 1);
/* 3931 */     Type type = convertType(localDeclaration.type);
/* 3932 */     setTypeForVariableDeclarationExpression(variableDeclarationExpression, type, variableDeclarationFragment.getExtraDimensions());
/* 3933 */     if (localDeclaration.modifiersSourceStart != -1) {
/* 3934 */       setModifiers(variableDeclarationExpression, localDeclaration);
/*      */     }
/* 3936 */     return variableDeclarationExpression;
/*      */   }
/*      */   
/*      */   protected SingleVariableDeclaration convertToSingleVariableDeclaration(LocalDeclaration localDeclaration) {
/* 3940 */     SingleVariableDeclaration variableDecl = new SingleVariableDeclaration(this.ast);
/* 3941 */     setModifiers(variableDecl, localDeclaration);
/* 3942 */     SimpleName name = new SimpleName(this.ast);
/* 3943 */     name.internalSetIdentifier(new String(localDeclaration.name));
/* 3944 */     int start = localDeclaration.sourceStart;
/* 3945 */     int nameEnd = localDeclaration.sourceEnd;
/* 3946 */     name.setSourceRange(start, nameEnd - start + 1);
/* 3947 */     variableDecl.setName(name);
/* 3948 */     TypeReference typeReference = localDeclaration.type;
/* 3949 */     int extraDimensions = typeReference.extraDimensions();
/* 3950 */     if (this.ast.apiLevel >= 8) {
/* 3951 */       setExtraAnnotatedDimensions(nameEnd + 1, localDeclaration.declarationSourceEnd, typeReference, 
/* 3952 */           variableDecl.extraDimensions(), extraDimensions);
/*      */     } else {
/* 3954 */       internalSetExtraDimensions(variableDecl, extraDimensions);
/*      */     } 
/* 3956 */     Type type = convertType(localDeclaration.type);
/* 3957 */     int typeEnd = type.getStartPosition() + type.getLength() - 1;
/*      */ 
/*      */     
/* 3960 */     int sourceEnd = ((localDeclaration.bits & 0x10) != 0) ? 
/* 3961 */       localDeclaration.sourceEnd : localDeclaration.declarationSourceEnd;
/* 3962 */     int rightEnd = Math.max(typeEnd, sourceEnd);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3967 */     setTypeForSingleVariableDeclaration(variableDecl, type, extraDimensions);
/* 3968 */     variableDecl.setSourceRange(localDeclaration.declarationSourceStart, rightEnd - localDeclaration.declarationSourceStart + 1);
/* 3969 */     if (this.resolveBindings) {
/* 3970 */       recordNodes(name, (ASTNode)localDeclaration);
/* 3971 */       recordNodes(variableDecl, (ASTNode)localDeclaration);
/* 3972 */       variableDecl.resolveBinding();
/*      */     } 
/* 3974 */     return variableDecl;
/*      */   }
/*      */   
/*      */   private Dimension convertToDimensions(int start, int end, Annotation[] annotation) {
/* 3978 */     int length = (annotation == null) ? 0 : annotation.length;
/* 3979 */     Dimension dimension = this.ast.newDimension();
/* 3980 */     for (int i = 0; i < length; i++) {
/* 3981 */       Annotation annot = convert(annotation[i]);
/* 3982 */       dimension.annotations().add(annot);
/*      */     } 
/* 3984 */     retrieveDimensionAndSetPositions(start, end, dimension);
/* 3985 */     return dimension;
/*      */   }
/*      */   
/*      */   protected VariableDeclarationFragment convertToVariableDeclarationFragment(FieldDeclaration fieldDeclaration) {
/* 3989 */     VariableDeclarationFragment variableDeclarationFragment = new VariableDeclarationFragment(this.ast);
/* 3990 */     SimpleName name = new SimpleName(this.ast);
/* 3991 */     name.internalSetIdentifier(new String(fieldDeclaration.name));
/* 3992 */     name.setSourceRange(fieldDeclaration.sourceStart, fieldDeclaration.sourceEnd - fieldDeclaration.sourceStart + 1);
/* 3993 */     variableDeclarationFragment.setName(name);
/* 3994 */     int start = fieldDeclaration.sourceEnd;
/* 3995 */     int end = start;
/* 3996 */     TypeReference typeReference = fieldDeclaration.type;
/* 3997 */     int extraDimensions = typeReference.extraDimensions();
/* 3998 */     if (this.ast.apiLevel >= 8) {
/* 3999 */       setExtraAnnotatedDimensions(fieldDeclaration.sourceEnd + 1, fieldDeclaration.declarationSourceEnd, 
/* 4000 */           typeReference, variableDeclarationFragment.extraDimensions(), extraDimensions);
/*      */     } else {
/* 4002 */       internalSetExtraDimensions(variableDeclarationFragment, extraDimensions);
/*      */     } 
/* 4004 */     if (fieldDeclaration.initialization != null) {
/* 4005 */       Expression expression = convert(fieldDeclaration.initialization);
/* 4006 */       variableDeclarationFragment.setInitializer(expression);
/* 4007 */       start = expression.getStartPosition() + expression.getLength();
/* 4008 */       end = start - 1;
/*      */     }
/*      */     else {
/*      */       
/* 4012 */       int possibleEnd = retrieveEndOfPotentialExtendedDimensions(start + 1, fieldDeclaration.sourceEnd, fieldDeclaration.declarationSourceEnd);
/* 4013 */       if (possibleEnd == Integer.MIN_VALUE) {
/* 4014 */         end = fieldDeclaration.declarationSourceEnd;
/* 4015 */         variableDeclarationFragment.setFlags(variableDeclarationFragment.getFlags() | 0x1);
/* 4016 */       }  if (possibleEnd < 0) {
/* 4017 */         end = -possibleEnd;
/* 4018 */         variableDeclarationFragment.setFlags(variableDeclarationFragment.getFlags() | 0x1);
/*      */       } else {
/* 4020 */         end = possibleEnd;
/*      */       } 
/*      */     } 
/* 4023 */     variableDeclarationFragment.setSourceRange(fieldDeclaration.sourceStart, end - fieldDeclaration.sourceStart + 1);
/* 4024 */     if (this.resolveBindings) {
/* 4025 */       recordNodes(name, (ASTNode)fieldDeclaration);
/* 4026 */       recordNodes(variableDeclarationFragment, (ASTNode)fieldDeclaration);
/* 4027 */       variableDeclarationFragment.resolveBinding();
/*      */     } 
/* 4029 */     return variableDeclarationFragment;
/*      */   }
/*      */   protected VariableDeclarationFragment convertToVariableDeclarationFragment(LocalDeclaration localDeclaration) {
/*      */     int end;
/* 4033 */     VariableDeclarationFragment variableDeclarationFragment = new VariableDeclarationFragment(this.ast);
/* 4034 */     SimpleName name = new SimpleName(this.ast);
/* 4035 */     name.internalSetIdentifier(new String(localDeclaration.name));
/* 4036 */     name.setSourceRange(localDeclaration.sourceStart, localDeclaration.sourceEnd - localDeclaration.sourceStart + 1);
/* 4037 */     variableDeclarationFragment.setName(name);
/* 4038 */     int start = localDeclaration.sourceEnd;
/* 4039 */     Expression initialization = localDeclaration.initialization;
/* 4040 */     TypeReference typeReference = localDeclaration.type;
/* 4041 */     int extraDimension = typeReference.extraDimensions();
/* 4042 */     if (this.ast.apiLevel >= 8) {
/* 4043 */       setExtraAnnotatedDimensions(localDeclaration.sourceEnd + 1, this.compilationUnitSourceLength, 
/* 4044 */           typeReference, variableDeclarationFragment.extraDimensions(), extraDimension);
/*      */     } else {
/* 4046 */       internalSetExtraDimensions(variableDeclarationFragment, extraDimension);
/*      */     } 
/*      */     
/* 4049 */     boolean hasInitialization = (initialization != null);
/*      */     
/* 4051 */     if (hasInitialization) {
/* 4052 */       Expression expression = convert(initialization);
/* 4053 */       variableDeclarationFragment.setInitializer(expression);
/* 4054 */       start = expression.getStartPosition() + expression.getLength();
/* 4055 */       end = start - 1;
/*      */     }
/*      */     else {
/*      */       
/* 4059 */       int possibleEnd = retrieveEndOfPotentialExtendedDimensions(start + 1, localDeclaration.sourceEnd, localDeclaration.declarationSourceEnd);
/* 4060 */       if (possibleEnd == Integer.MIN_VALUE) {
/* 4061 */         end = start;
/* 4062 */         variableDeclarationFragment.setFlags(variableDeclarationFragment.getFlags() | 0x1);
/* 4063 */       } else if (possibleEnd < 0) {
/* 4064 */         end = -possibleEnd;
/* 4065 */         variableDeclarationFragment.setFlags(variableDeclarationFragment.getFlags() | 0x1);
/*      */       } else {
/* 4067 */         end = possibleEnd;
/*      */       } 
/*      */     } 
/* 4070 */     variableDeclarationFragment.setSourceRange(localDeclaration.sourceStart, end - localDeclaration.sourceStart + 1);
/* 4071 */     if (this.resolveBindings) {
/* 4072 */       recordNodes(variableDeclarationFragment, (ASTNode)localDeclaration);
/* 4073 */       recordNodes(name, (ASTNode)localDeclaration);
/* 4074 */       variableDeclarationFragment.resolveBinding();
/*      */     } 
/* 4076 */     return variableDeclarationFragment;
/*      */   }
/*      */   
/*      */   protected void setExtraAnnotatedDimensions(int start, int end, TypeReference type, List<Dimension> extraAnnotatedDimensions, int extraDimension) {
/* 4080 */     if (extraDimension > 0) {
/* 4081 */       Annotation[][] annotationsOnDims = type.getAnnotationsOnDimensions(true);
/* 4082 */       int length = (annotationsOnDims == null) ? 0 : annotationsOnDims.length;
/* 4083 */       for (int i = length - extraDimension; i < length; i++) {
/* 4084 */         Dimension dim = convertToDimensions(start, end, (annotationsOnDims == null) ? null : annotationsOnDims[i]);
/* 4085 */         extraAnnotatedDimensions.add(dim);
/* 4086 */         start = dim.getStartPosition() + dim.getLength();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setTypeAnnotationsOnDimension(Dimension currentDimension, Annotation[][] annotationsOnDimensions, int dimension) {
/* 4092 */     if (annotationsOnDimensions == null)
/* 4093 */       return;  Annotation[] annotations = annotationsOnDimensions[dimension];
/* 4094 */     if (annotations != null) {
/* 4095 */       for (int j = 0, length = annotations.length; j < length; j++) {
/* 4096 */         Annotation annotation = convert(annotations[j]);
/* 4097 */         currentDimension.annotations().add(annotation);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private void setTypeAnnotationsAndSourceRangeOnArray(ArrayType arrayType, Annotation[][] annotationsOnDimensions) {
/* 4103 */     List<Dimension> dimensions = arrayType.dimensions();
/* 4104 */     Type elementType = arrayType.getElementType();
/*      */ 
/*      */ 
/*      */     
/* 4108 */     int start = elementType.getStartPosition();
/*      */ 
/*      */ 
/*      */     
/* 4112 */     int startArray = start + elementType.getLength();
/*      */ 
/*      */ 
/*      */     
/* 4116 */     int end = retrieveProperRightBracketPosition(dimensions.size(), startArray);
/* 4117 */     if (end == -1) {
/* 4118 */       end = startArray - 1;
/*      */     }
/* 4120 */     arrayType.setSourceRange(start, end - start + 1);
/*      */     
/* 4122 */     start = startArray;
/* 4123 */     for (int i = 0; i < dimensions.size(); i++) {
/* 4124 */       Dimension currentDimension = dimensions.get(i);
/* 4125 */       setTypeAnnotationsOnDimension(currentDimension, annotationsOnDimensions, i);
/* 4126 */       retrieveDimensionAndSetPositions(start, end, currentDimension);
/* 4127 */       start = currentDimension.getStartPosition() + currentDimension.getLength();
/*      */     } 
/*      */   }
/*      */   
/*      */   protected VariableDeclarationStatement convertToVariableDeclarationStatement(LocalDeclaration localDeclaration) {
/* 4132 */     VariableDeclarationFragment variableDeclarationFragment = convertToVariableDeclarationFragment(localDeclaration);
/* 4133 */     VariableDeclarationStatement variableDeclarationStatement = new VariableDeclarationStatement(this.ast);
/* 4134 */     variableDeclarationStatement.fragments().add(variableDeclarationFragment);
/* 4135 */     variableDeclarationStatement.setSourceRange(localDeclaration.declarationSourceStart, localDeclaration.declarationSourceEnd - localDeclaration.declarationSourceStart + 1);
/* 4136 */     Type type = convertType(localDeclaration.type);
/* 4137 */     setTypeForVariableDeclarationStatement(variableDeclarationStatement, type, variableDeclarationFragment.getExtraDimensions());
/* 4138 */     if (this.resolveBindings) {
/* 4139 */       recordNodes(variableDeclarationFragment, (ASTNode)localDeclaration);
/* 4140 */       if (this.ast.apiLevel() >= 10 && type.isVar()) {
/* 4141 */         SimpleName varName = (SimpleName)((SimpleType)type).getName();
/* 4142 */         varName.setVar(true);
/* 4143 */         recordNodes(varName, (ASTNode)localDeclaration);
/*      */       } 
/*      */     } 
/* 4146 */     if (localDeclaration.modifiersSourceStart != -1) {
/* 4147 */       setModifiers(variableDeclarationStatement, localDeclaration);
/*      */     }
/* 4149 */     return variableDeclarationStatement;
/*      */   }
/*      */   
/*      */   private int annotateType(AnnotatableType type, Annotation[] annotations) {
/* 4153 */     int annotationsEnd = 0;
/* 4154 */     switch (this.ast.apiLevel)
/*      */     { case 2:
/*      */       case 3:
/*      */       case 4:
/* 4158 */         type.setFlags(type.getFlags() | 0x1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4180 */         return annotationsEnd; }  if (annotations != null) { int start = type.getStartPosition(); int length = type.getLength(); int annotationsLength = annotations.length; for (int i = 0; i < annotationsLength; i++) { Annotation typeAnnotation = annotations[i]; if (typeAnnotation != null) { Annotation annotation = convert(typeAnnotation); type.annotations().add(annotation); annotationsEnd = annotation.getStartPosition() + annotation.getLength(); }  }  int annotationsStart; if (annotations[0] != null && (annotationsStart = (annotations[0]).sourceStart) < start && annotationsStart > 0) { length += start - annotationsStart; start = annotationsStart; }  type.setSourceRange(start, length); }  return annotationsEnd;
/*      */   }
/*      */   private void annotateTypeParameter(TypeParameter typeParameter, Annotation[] annotations) {
/* 4183 */     switch (this.ast.apiLevel) {
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/* 4187 */         typeParameter.setFlags(typeParameter.getFlags() | 0x1);
/*      */         return;
/*      */     } 
/* 4190 */     int annotationsLength = annotations.length;
/* 4191 */     for (int i = 0; i < annotationsLength; i++) {
/* 4192 */       Annotation typeAnnotation = annotations[i];
/* 4193 */       if (typeAnnotation != null) {
/* 4194 */         Annotation annotation = convert(typeAnnotation);
/* 4195 */         typeParameter.modifiers().add(annotation);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Type convertType(TypeReference typeReference) {
/* 4203 */     if (typeReference instanceof Wildcard) {
/* 4204 */       Wildcard wildcard = (Wildcard)typeReference;
/* 4205 */       WildcardType wildcardType = new WildcardType(this.ast);
/* 4206 */       if (wildcard.bound != null) {
/* 4207 */         Type bound = convertType(wildcard.bound);
/* 4208 */         wildcardType.setBound(bound, (wildcard.kind == 1));
/* 4209 */         int start = wildcard.sourceStart;
/* 4210 */         wildcardType.setSourceRange(start, bound.getStartPosition() + bound.getLength() - start);
/*      */       } else {
/* 4212 */         int start = wildcard.sourceStart;
/* 4213 */         int end = wildcard.sourceEnd;
/* 4214 */         wildcardType.setSourceRange(start, end - start + 1);
/*      */       } 
/* 4216 */       if (this.resolveBindings)
/* 4217 */         recordNodes(wildcardType, (ASTNode)typeReference); 
/*      */       Annotation[] annotations;
/* 4219 */       if (typeReference.annotations != null && (annotations = typeReference.annotations[0]) != null) {
/* 4220 */         annotateType(wildcardType, annotations);
/*      */       }
/* 4222 */       return wildcardType;
/*      */     } 
/* 4224 */     Type type = null;
/* 4225 */     int sourceStart = typeReference.sourceStart;
/* 4226 */     int length = 0;
/* 4227 */     int dimensions = typeReference.dimensions();
/* 4228 */     if (typeReference instanceof SingleTypeReference) {
/* 4229 */       Annotation[] annotations = (typeReference.annotations != null) ? typeReference.annotations[0] : null;
/* 4230 */       int annotationsEnd = (annotations != null) ? ((annotations[annotations.length - 1]).declarationSourceEnd + 1) : -1;
/*      */       
/* 4232 */       char[] name = ((SingleTypeReference)typeReference).getTypeName()[0];
/* 4233 */       length = typeReference.sourceEnd - typeReference.sourceStart + 1;
/*      */       
/* 4235 */       if (isPrimitiveType(name)) {
/* 4236 */         int[] positions = retrieveEndOfElementTypeNamePosition((sourceStart < annotationsEnd) ? annotationsEnd : sourceStart, sourceStart + length);
/* 4237 */         int end = positions[1];
/* 4238 */         if (end == -1) {
/* 4239 */           end = sourceStart + length - 1;
/*      */         }
/* 4241 */         PrimitiveType primitiveType = new PrimitiveType(this.ast);
/* 4242 */         primitiveType.setPrimitiveTypeCode(getPrimitiveTypeCode(name));
/* 4243 */         primitiveType.setSourceRange(sourceStart, end - sourceStart + 1);
/* 4244 */         type = primitiveType;
/* 4245 */         if (typeReference.annotations != null && (annotations = typeReference.annotations[0]) != null) {
/* 4246 */           annotateType(primitiveType, annotations);
/*      */         }
/* 4248 */       } else if (typeReference instanceof ParameterizedSingleTypeReference) {
/* 4249 */         SimpleType simpleType; int newSourceStart; ParameterizedType parameterizedType; TypeReference[] typeArguments; ParameterizedSingleTypeReference parameterizedSingleTypeReference = (ParameterizedSingleTypeReference)typeReference;
/* 4250 */         SimpleName simpleName = new SimpleName(this.ast);
/* 4251 */         simpleName.internalSetIdentifier(new String(name));
/* 4252 */         int[] positions = retrieveEndOfElementTypeNamePosition((sourceStart < annotationsEnd) ? annotationsEnd : sourceStart, sourceStart + length);
/* 4253 */         int end = positions[1];
/* 4254 */         if (end == -1) {
/* 4255 */           end = sourceStart + length - 1;
/*      */         }
/* 4257 */         if (positions[0] != -1) {
/* 4258 */           simpleName.setSourceRange(positions[0], end - positions[0] + 1);
/*      */         } else {
/* 4260 */           simpleName.setSourceRange(sourceStart, end - sourceStart + 1);
/*      */         } 
/*      */         
/* 4263 */         switch (this.ast.apiLevel) {
/*      */           case 2:
/* 4265 */             simpleType = new SimpleType(this.ast);
/* 4266 */             simpleType.setName(simpleName);
/* 4267 */             simpleType.setFlags(simpleType.getFlags() | 0x1);
/* 4268 */             simpleType.setSourceRange(sourceStart, end - sourceStart + 1);
/* 4269 */             type = simpleType;
/* 4270 */             if (this.resolveBindings) {
/* 4271 */               recordNodes(simpleName, (ASTNode)typeReference);
/*      */             }
/*      */             break;
/*      */           default:
/* 4275 */             simpleType = new SimpleType(this.ast);
/* 4276 */             simpleType.setName(simpleName);
/* 4277 */             simpleType.setSourceRange(simpleName.getStartPosition(), simpleName.getLength());
/* 4278 */             if (typeReference.annotations != null && (annotations = typeReference.annotations[0]) != null) {
/* 4279 */               annotateType(simpleType, annotations);
/*      */             }
/* 4281 */             newSourceStart = simpleType.getStartPosition();
/* 4282 */             if (newSourceStart > 0 && newSourceStart < sourceStart)
/* 4283 */               sourceStart = newSourceStart; 
/* 4284 */             parameterizedType = new ParameterizedType(this.ast);
/* 4285 */             parameterizedType.setType(simpleType);
/* 4286 */             type = parameterizedType;
/* 4287 */             typeArguments = parameterizedSingleTypeReference.typeArguments;
/* 4288 */             if (typeArguments != null) {
/* 4289 */               Type type2 = null;
/* 4290 */               for (int i = 0, max = typeArguments.length; i < max; i++) {
/* 4291 */                 type2 = convertType(typeArguments[i]);
/* 4292 */                 ((ParameterizedType)type).typeArguments().add(type2);
/* 4293 */                 end = type2.getStartPosition() + type2.getLength() - 1;
/*      */               } 
/* 4295 */               end = retrieveClosingAngleBracketPosition(end + 1);
/* 4296 */               type.setSourceRange(sourceStart, end - sourceStart + 1);
/*      */             } else {
/* 4298 */               type.setSourceRange(sourceStart, end - sourceStart + 1);
/*      */             } 
/* 4300 */             if (this.resolveBindings) {
/* 4301 */               recordNodes(simpleName, (ASTNode)typeReference);
/* 4302 */               recordNodes(simpleType, (ASTNode)typeReference);
/*      */             }  break;
/*      */         } 
/*      */       } else {
/* 4306 */         SimpleName simpleName = new SimpleName(this.ast);
/* 4307 */         simpleName.internalSetIdentifier(new String(name));
/*      */ 
/*      */         
/* 4310 */         int[] positions = retrieveEndOfElementTypeNamePosition((sourceStart < annotationsEnd) ? annotationsEnd : sourceStart, sourceStart + length);
/* 4311 */         int end = positions[1];
/* 4312 */         if (end == -1) {
/* 4313 */           end = sourceStart + length - 1;
/*      */         }
/* 4315 */         if (positions[0] != -1) {
/* 4316 */           simpleName.setSourceRange(positions[0], end - positions[0] + 1);
/*      */         } else {
/* 4318 */           simpleName.setSourceRange(sourceStart, end - sourceStart + 1);
/*      */         } 
/* 4320 */         SimpleType simpleType = new SimpleType(this.ast);
/* 4321 */         simpleType.setName(simpleName);
/* 4322 */         type = simpleType;
/* 4323 */         type.setSourceRange(sourceStart, end - sourceStart + 1);
/* 4324 */         type = simpleType;
/* 4325 */         if (this.ast.apiLevel() >= 10 && type.isVar()) {
/* 4326 */           simpleName.setVar(true);
/*      */         }
/* 4328 */         if (this.resolveBindings) {
/* 4329 */           recordNodes(simpleName, (ASTNode)typeReference);
/*      */         }
/* 4331 */         if (typeReference.annotations != null && (annotations = typeReference.annotations[0]) != null) {
/* 4332 */           annotateType(simpleType, annotations);
/*      */         }
/*      */       } 
/* 4335 */       if (dimensions != 0) {
/* 4336 */         type = convertToArray(type, sourceStart, length, dimensions, typeReference.getAnnotationsOnDimensions(true));
/* 4337 */         if (this.resolveBindings)
/*      */         {
/* 4339 */           completeRecord((ArrayType)type, (ASTNode)typeReference);
/*      */         }
/*      */       } 
/*      */     } else {
/* 4343 */       if (typeReference instanceof ParameterizedQualifiedTypeReference) {
/* 4344 */         char[][] name; boolean isTypeArgumentBased; int nameLength, i, start; Name qualifiedName; int end; SimpleType simpleType; Type currentType; int indexOfEnclosingType, j; ParameterizedQualifiedTypeReference parameterizedQualifiedTypeReference = (ParameterizedQualifiedTypeReference)typeReference;
/* 4345 */         char[][] tokens = parameterizedQualifiedTypeReference.tokens;
/* 4346 */         TypeReference[][] typeArguments = parameterizedQualifiedTypeReference.typeArguments;
/* 4347 */         Annotation[][] typeAnnotations = parameterizedQualifiedTypeReference.annotations;
/* 4348 */         TypeReference[] arguments = null;
/* 4349 */         int lenth = tokens.length;
/* 4350 */         int firstTypeIndex = lenth - 1;
/* 4351 */         long[] positions = parameterizedQualifiedTypeReference.sourcePositions;
/* 4352 */         switch (this.ast.apiLevel) {
/*      */           case 2:
/* 4354 */             name = ((QualifiedTypeReference)typeReference).getTypeName();
/* 4355 */             nameLength = name.length;
/* 4356 */             sourceStart = (int)(positions[0] >>> 32L);
/* 4357 */             length = (int)(positions[nameLength - 1] & 0xFFFFFFFFFFFFFFFFL) - sourceStart + 1;
/* 4358 */             qualifiedName = setQualifiedNameNameAndSourceRanges(name, positions, (ASTNode)typeReference);
/* 4359 */             simpleType = new SimpleType(this.ast);
/* 4360 */             simpleType.setName(qualifiedName);
/* 4361 */             simpleType.setSourceRange(sourceStart, length);
/* 4362 */             simpleType.setFlags(simpleType.getFlags() | 0x1);
/* 4363 */             type = simpleType;
/*      */             break;
/*      */           
/*      */           default:
/* 4367 */             isTypeArgumentBased = false;
/* 4368 */             for (i = 0; i < lenth; i++) {
/* 4369 */               if (typeArguments != null && typeArguments[i] != null) {
/* 4370 */                 firstTypeIndex = i;
/* 4371 */                 isTypeArgumentBased = true;
/*      */                 break;
/*      */               } 
/* 4374 */               if (typeAnnotations != null && typeAnnotations[i] != null) {
/* 4375 */                 firstTypeIndex = i;
/* 4376 */                 isTypeArgumentBased = false;
/*      */                 break;
/*      */               } 
/*      */             } 
/* 4380 */             start = (int)(positions[0] >>> 32L);
/* 4381 */             end = (int)positions[firstTypeIndex];
/*      */             
/* 4383 */             currentType = createBaseType(typeReference, positions, typeAnnotations, tokens, lenth, firstTypeIndex, isTypeArgumentBased);
/* 4384 */             indexOfEnclosingType = 1;
/* 4385 */             if (typeArguments != null && (arguments = typeArguments[firstTypeIndex]) != null) {
/* 4386 */               int arglen = arguments.length;
/* 4387 */               ParameterizedType parameterizedType = new ParameterizedType(this.ast);
/* 4388 */               parameterizedType.index = indexOfEnclosingType;
/* 4389 */               parameterizedType.setType(currentType);
/* 4390 */               if (this.resolveBindings) {
/* 4391 */                 recordNodes(parameterizedType, (ASTNode)typeReference);
/*      */               }
/* 4393 */               Type type2 = null;
/* 4394 */               for (int k = 0; k < arglen; k++) {
/* 4395 */                 type2 = convertType(arguments[k]);
/* 4396 */                 parameterizedType.typeArguments().add(type2);
/*      */               } 
/* 4398 */               end = (type2 != null) ? (type2.getStartPosition() + type2.getLength() - 1) : end;
/* 4399 */               end = retrieveClosingAngleBracketPosition(end + 1);
/* 4400 */               int baseStart = currentType.getStartPosition();
/* 4401 */               start = (start <= baseStart) ? start : baseStart;
/* 4402 */               parameterizedType.setSourceRange(start, end - start + 1);
/* 4403 */               currentType = parameterizedType;
/*      */             } 
/*      */             
/* 4406 */             for (j = firstTypeIndex + 1; j < lenth; j++) {
/* 4407 */               SimpleName simpleName = new SimpleName(this.ast);
/* 4408 */               simpleName.setIdentifier(new String(tokens[j]));
/* 4409 */               simpleName.index = j + 1;
/* 4410 */               start = (int)(positions[j] >>> 32L);
/* 4411 */               end = (int)positions[j];
/* 4412 */               simpleName.setSourceRange(start, end - start + 1);
/* 4413 */               recordPendingNameScopeResolution(simpleName);
/* 4414 */               QualifiedType qualifiedType = new QualifiedType(this.ast);
/* 4415 */               qualifiedType.setQualifier(currentType);
/* 4416 */               qualifiedType.setName(simpleName);
/* 4417 */               start = currentType.getStartPosition();
/* 4418 */               end = simpleName.getStartPosition() + simpleName.getLength() - 1;
/* 4419 */               qualifiedType.setSourceRange(start, end - start + 1); Annotation[] annotations;
/* 4420 */               if (typeAnnotations != null && (annotations = typeAnnotations[j]) != null) {
/* 4421 */                 int nextPosition = annotateType(qualifiedType, annotations);
/* 4422 */                 if (simpleName.getStartPosition() < nextPosition && nextPosition <= end) {
/* 4423 */                   simpleName.setSourceRange(nextPosition, end - nextPosition + 1);
/* 4424 */                   trimWhiteSpacesAndComments(simpleName);
/*      */                 } 
/*      */               } 
/* 4427 */               if (this.resolveBindings) {
/* 4428 */                 recordNodes(simpleName, (ASTNode)typeReference);
/* 4429 */                 recordNodes(qualifiedType, (ASTNode)typeReference);
/*      */               } 
/* 4431 */               currentType = qualifiedType;
/* 4432 */               indexOfEnclosingType++;
/*      */               
/* 4434 */               if (typeArguments != null && (arguments = typeArguments[j]) != null) {
/* 4435 */                 int arglen = arguments.length;
/* 4436 */                 qualifiedType.index = indexOfEnclosingType;
/* 4437 */                 ParameterizedType parameterizedType = new ParameterizedType(this.ast);
/* 4438 */                 parameterizedType.index = indexOfEnclosingType;
/* 4439 */                 parameterizedType.setType(currentType);
/* 4440 */                 if (this.resolveBindings) {
/* 4441 */                   recordNodes(parameterizedType, (ASTNode)typeReference);
/*      */                 }
/* 4443 */                 Type type2 = null;
/* 4444 */                 for (int k = 0; k < arglen; k++) {
/* 4445 */                   type2 = convertType(arguments[k]);
/* 4446 */                   parameterizedType.typeArguments().add(type2);
/*      */                 } 
/* 4448 */                 end = (type2 != null) ? (type2.getStartPosition() + type2.getLength() - 1) : end;
/* 4449 */                 end = retrieveClosingAngleBracketPosition(end + 1);
/* 4450 */                 parameterizedType.setSourceRange(start, end - start + 1);
/* 4451 */                 currentType = parameterizedType;
/*      */               } else {
/* 4453 */                 qualifiedType.index = indexOfEnclosingType;
/*      */               } 
/*      */             } 
/* 4456 */             type = currentType; break;
/*      */         } 
/* 4458 */       } else if (typeReference instanceof QualifiedTypeReference) {
/* 4459 */         QualifiedTypeReference qualifiedTypeReference = (QualifiedTypeReference)typeReference;
/* 4460 */         long[] positions = ((QualifiedTypeReference)typeReference).sourcePositions;
/* 4461 */         Annotation[][] typeAnnotations = typeReference.annotations;
/* 4462 */         char[][] tokens = qualifiedTypeReference.tokens;
/* 4463 */         int lenth = tokens.length;
/* 4464 */         int firstTypeIndex = lenth;
/*      */         
/* 4466 */         if (typeAnnotations != null) {
/* 4467 */           for (int j = 0; j < lenth; j++) {
/* 4468 */             if (typeAnnotations[j] != null) {
/* 4469 */               firstTypeIndex = j;
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         }
/* 4474 */         Type currentType = createBaseType(typeReference, positions, typeAnnotations, tokens, lenth, firstTypeIndex, false);
/* 4475 */         for (int i = firstTypeIndex + 1; i < lenth; i++) {
/* 4476 */           currentType = createQualifiedType(typeReference, positions, typeAnnotations, tokens, i, currentType);
/*      */         }
/* 4478 */         type = currentType;
/* 4479 */       } else if (typeReference instanceof UnionTypeReference) {
/* 4480 */         int start, endPosition; UnionType unionType; int i; List<Type> types; int max, size; Type lastType; TypeReference[] typeReferences = ((UnionTypeReference)typeReference).typeReferences;
/* 4481 */         switch (this.ast.apiLevel) {
/*      */           
/*      */           case 2:
/*      */           case 3:
/* 4485 */             type = convertType(typeReferences[0]);
/* 4486 */             start = typeReference.sourceStart;
/* 4487 */             endPosition = typeReference.sourceEnd;
/* 4488 */             length = endPosition - start + 1;
/* 4489 */             type.setSourceRange(start, length);
/* 4490 */             type.setFlags(type.getFlags() | 0x1);
/*      */             break;
/*      */           
/*      */           default:
/* 4494 */             unionType = new UnionType(this.ast);
/* 4495 */             for (i = 0, max = typeReferences.length; i < max; i++) {
/* 4496 */               unionType.types().add(convertType(typeReferences[i]));
/*      */             }
/* 4498 */             type = unionType;
/* 4499 */             types = unionType.types();
/* 4500 */             size = types.size();
/* 4501 */             start = ((Type)types.get(0)).getStartPosition();
/* 4502 */             lastType = types.get(size - 1);
/* 4503 */             endPosition = lastType.getStartPosition() + lastType.getLength();
/* 4504 */             length = endPosition - start;
/* 4505 */             type.setSourceRange(start, length); break;
/*      */         } 
/* 4507 */       } else if (typeReference instanceof IntersectionCastTypeReference) {
/* 4508 */         int start, endPosition; IntersectionType castType; int i; List<Type> types; int max, size; Type lastType; TypeReference[] typeReferences = ((IntersectionCastTypeReference)typeReference).typeReferences;
/* 4509 */         switch (this.ast.apiLevel) {
/*      */           case 2:
/*      */           case 3:
/*      */           case 4:
/* 4513 */             type = convertType(typeReferences[0]);
/* 4514 */             start = typeReference.sourceStart;
/* 4515 */             endPosition = typeReference.sourceEnd;
/* 4516 */             length = endPosition - start + 1;
/* 4517 */             type.setSourceRange(start, length);
/* 4518 */             type.setFlags(type.getFlags() | 0x1);
/*      */             break;
/*      */           
/*      */           default:
/* 4522 */             castType = new IntersectionType(this.ast);
/* 4523 */             for (i = 0, max = typeReferences.length; i < max; i++) {
/* 4524 */               castType.types().add(convertType(typeReferences[i]));
/*      */             }
/* 4526 */             type = castType;
/* 4527 */             types = castType.types();
/* 4528 */             size = types.size();
/* 4529 */             start = ((Type)types.get(0)).getStartPosition();
/* 4530 */             lastType = types.get(size - 1);
/* 4531 */             endPosition = lastType.getStartPosition() + lastType.getLength();
/* 4532 */             length = endPosition - start;
/* 4533 */             type.setSourceRange(start, length);
/*      */             break;
/*      */         } 
/*      */       } 
/* 4537 */       length = typeReference.sourceEnd - sourceStart + 1;
/* 4538 */       if (dimensions != 0) {
/* 4539 */         type = convertToArray(type, sourceStart, length, dimensions, typeReference.getAnnotationsOnDimensions(true));
/* 4540 */         if (this.resolveBindings) {
/* 4541 */           completeRecord((ArrayType)type, (ASTNode)typeReference);
/*      */         }
/*      */       } 
/*      */     } 
/* 4545 */     if (this.resolveBindings) {
/* 4546 */       recordNodes(type, (ASTNode)typeReference);
/*      */     }
/* 4548 */     boolean sawDiamond = false;
/* 4549 */     if (typeReference instanceof ParameterizedSingleTypeReference) {
/* 4550 */       ParameterizedSingleTypeReference pstr = (ParameterizedSingleTypeReference)typeReference;
/* 4551 */       if (pstr.typeArguments == TypeReference.NO_TYPE_ARGUMENTS) {
/* 4552 */         sawDiamond = true;
/*      */       }
/* 4554 */     } else if (typeReference instanceof ParameterizedQualifiedTypeReference) {
/* 4555 */       ParameterizedQualifiedTypeReference pqtr = (ParameterizedQualifiedTypeReference)typeReference;
/* 4556 */       for (int i = 0, len = pqtr.typeArguments.length; i < len; i++) {
/* 4557 */         if (pqtr.typeArguments[i] == TypeReference.NO_TYPE_ARGUMENTS) {
/* 4558 */           sawDiamond = true;
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 4563 */     if (sawDiamond)
/* 4564 */       switch (this.ast.apiLevel) {
/*      */         case 2:
/*      */         case 3:
/* 4567 */           type.setFlags(type.getFlags() | 0x1);
/*      */           break;
/*      */       }  
/* 4570 */     return type;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Type createBaseType(TypeReference typeReference, long[] positions, Annotation[][] typeAnnotations, char[][] tokens, int lenth, int firstTypeIndex, boolean isTypeArgumentBased) {
/*      */     Type currentType;
/* 4577 */     Name name = null;
/* 4578 */     if (firstTypeIndex == 0) {
/* 4579 */       name = createSimpleName(typeReference, positions, tokens, 0);
/* 4580 */       currentType = createSimpleType(name, typeReference, positions, 0, 0);
/* 4581 */       setSourceRangeAnnotationsAndRecordNodes(typeReference, (SimpleType)currentType, positions, typeAnnotations, 0, 0, (name.index > 0) ? (name.index - 1) : 0);
/* 4582 */     } else if (firstTypeIndex == lenth) {
/* 4583 */       name = setQualifiedNameNameAndSourceRanges(tokens, positions, firstTypeIndex - 1, typeReference);
/* 4584 */       currentType = createSimpleType(name, typeReference, positions, 0, firstTypeIndex - 1);
/* 4585 */     } else if (isTypeArgumentBased && (typeAnnotations == null || typeAnnotations[firstTypeIndex] == null)) {
/* 4586 */       name = setQualifiedNameNameAndSourceRanges(tokens, positions, firstTypeIndex, typeReference);
/* 4587 */       currentType = createSimpleType(name, typeReference, positions, 0, firstTypeIndex);
/*      */     } else {
/* 4589 */       if (firstTypeIndex == 1) {
/* 4590 */         name = createSimpleName(typeReference, positions, tokens, 0);
/*      */       } else {
/* 4592 */         name = setQualifiedNameNameAndSourceRanges(tokens, positions, firstTypeIndex - 1, typeReference);
/*      */       } 
/*      */       
/* 4595 */       boolean createNameQualifiedType = (typeAnnotations != null && typeAnnotations[firstTypeIndex] != null);
/* 4596 */       if (createNameQualifiedType && this.ast.apiLevel >= 8) {
/* 4597 */         NameQualifiedType nameQualifiedType = new NameQualifiedType(this.ast);
/* 4598 */         nameQualifiedType.setQualifier(name);
/* 4599 */         nameQualifiedType.setName(createSimpleName(typeReference, positions, tokens, firstTypeIndex));
/* 4600 */         setSourceRangeAnnotationsAndRecordNodes(typeReference, nameQualifiedType, positions, typeAnnotations, firstTypeIndex, 0, firstTypeIndex);
/* 4601 */         currentType = nameQualifiedType;
/*      */       } else {
/* 4603 */         SimpleType simpleType = this.ast.newSimpleType(name);
/* 4604 */         setSourceRangeAnnotationsAndRecordNodes(typeReference, simpleType, positions, typeAnnotations, 0, 0, (name.index > 0) ? (name.index - 1) : 0);
/* 4605 */         currentType = createQualifiedType(typeReference, positions, typeAnnotations, tokens, firstTypeIndex, simpleType);
/* 4606 */         if (createNameQualifiedType)
/* 4607 */           currentType.setFlags(currentType.getFlags() | 0x1); 
/*      */       } 
/*      */     } 
/* 4610 */     return currentType;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private QualifiedType createQualifiedType(TypeReference typeReference, long[] positions, Annotation[][] typeAnnotations, char[][] tokens, int index, Type qualifier) {
/* 4616 */     SimpleName simpleName = createSimpleName(typeReference, positions, tokens, index);
/* 4617 */     QualifiedType qualifiedType = new QualifiedType(this.ast);
/* 4618 */     qualifiedType.setQualifier(qualifier);
/* 4619 */     qualifiedType.setName(simpleName);
/* 4620 */     int start = qualifier.getStartPosition();
/* 4621 */     int end = simpleName.getStartPosition() + simpleName.getLength() - 1;
/* 4622 */     setSourceRangeAnnotationsAndRecordNodes(typeReference, qualifiedType, typeAnnotations, index, start, end);
/* 4623 */     return qualifiedType;
/*      */   }
/*      */ 
/*      */   
/*      */   private SimpleType createSimpleType(Name name, TypeReference typeReference, long[] positions, int startIndex, int endIndex) {
/* 4628 */     SimpleType simpleType = new SimpleType(this.ast);
/* 4629 */     simpleType.setName(name);
/* 4630 */     int start = (int)(positions[startIndex] >>> 32L);
/* 4631 */     int end = (int)positions[endIndex];
/* 4632 */     simpleType.setSourceRange(start, end - start + 1);
/* 4633 */     if (this.resolveBindings) {
/* 4634 */       recordNodes(simpleType, (ASTNode)typeReference);
/*      */     }
/* 4636 */     return simpleType;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void setSourceRangeAnnotationsAndRecordNodes(TypeReference typeReference, AnnotatableType annotatableType, Annotation[][] typeAnnotations, int index, int start, int end) {
/* 4642 */     int length = end - start + 1;
/* 4643 */     annotatableType.setSourceRange(start, length); Annotation[] annotations;
/* 4644 */     if (typeAnnotations != null && (annotations = typeAnnotations[index]) != null) {
/* 4645 */       annotateType(annotatableType, annotations);
/*      */     }
/* 4647 */     if (this.resolveBindings) {
/* 4648 */       recordNodes(annotatableType, (ASTNode)typeReference);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private void setSourceRangeAnnotationsAndRecordNodes(TypeReference typeReference, AnnotatableType annotatableType, long[] positions, Annotation[][] typeAnnotations, int index, int startIndex, int endIndex) {
/* 4654 */     int start = (int)(positions[startIndex] >>> 32L);
/* 4655 */     int end = (int)positions[endIndex];
/* 4656 */     setSourceRangeAnnotationsAndRecordNodes(typeReference, annotatableType, typeAnnotations, index, start, end);
/*      */   }
/*      */   
/*      */   private SimpleName createSimpleName(TypeReference typeReference, long[] positions, char[][] tokens, int index) {
/* 4660 */     SimpleName simpleName = new SimpleName(this.ast);
/* 4661 */     simpleName.internalSetIdentifier(new String(tokens[index]));
/* 4662 */     recordPendingNameScopeResolution(simpleName);
/* 4663 */     int start = (int)(positions[index] >>> 32L);
/* 4664 */     int end = (int)positions[index];
/* 4665 */     simpleName.setSourceRange(start, end - start + 1);
/* 4666 */     simpleName.index = index + 1;
/* 4667 */     if (this.resolveBindings) {
/* 4668 */       recordNodes(simpleName, (ASTNode)typeReference);
/*      */     }
/* 4670 */     return simpleName;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Comment createComment(int[] positions) {
/* 4675 */     Comment comment = null;
/* 4676 */     int start = positions[0];
/* 4677 */     int end = positions[1];
/* 4678 */     if (positions[1] > 0) {
/* 4679 */       Javadoc docComment = this.docParser.parse(positions);
/* 4680 */       if (docComment == null) return null; 
/* 4681 */       comment = docComment;
/*      */     } else {
/* 4683 */       end = -end;
/* 4684 */       if (positions[0] == 0) {
/* 4685 */         if (this.docParser.scanner.source[1] == '/') {
/* 4686 */           comment = new LineComment(this.ast);
/*      */         } else {
/* 4688 */           comment = new BlockComment(this.ast);
/*      */         }
/*      */       
/* 4691 */       } else if (positions[0] > 0) {
/* 4692 */         comment = new BlockComment(this.ast);
/*      */       } else {
/* 4694 */         start = -start;
/* 4695 */         comment = new LineComment(this.ast);
/*      */       } 
/* 4697 */       comment.setSourceRange(start, end - start);
/*      */     } 
/* 4699 */     return comment;
/*      */   }
/*      */   
/*      */   protected Statement createFakeEmptyStatement(Statement statement) {
/* 4703 */     if (statement == null) return null; 
/* 4704 */     EmptyStatement emptyStatement = new EmptyStatement(this.ast);
/* 4705 */     emptyStatement.setFlags(emptyStatement.getFlags() | 0x1);
/* 4706 */     int start = statement.sourceStart;
/* 4707 */     int end = statement.sourceEnd;
/* 4708 */     emptyStatement.setSourceRange(start, end - start + 1);
/* 4709 */     return emptyStatement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Expression createFakeNullLiteral(Expression expression) {
/* 4717 */     if (this.referenceContext != null) {
/* 4718 */       this.referenceContext.setFlags(this.referenceContext.getFlags() | 0x1);
/*      */     }
/* 4720 */     NullLiteral nullLiteral = new NullLiteral(this.ast);
/* 4721 */     nullLiteral.setFlags(nullLiteral.getFlags() | 0x1);
/* 4722 */     nullLiteral.setSourceRange(expression.sourceStart, expression.sourceEnd - expression.sourceStart + 1);
/* 4723 */     return nullLiteral;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Pattern createFakeNullPattern(Pattern pattern) {
/* 4731 */     if (this.referenceContext != null) {
/* 4732 */       this.referenceContext.setFlags(this.referenceContext.getFlags() | 0x1);
/*      */     }
/* 4734 */     NullPattern nullPattern = new NullPattern(this.ast);
/* 4735 */     nullPattern.setFlags(nullPattern.getFlags() | 0x1);
/* 4736 */     nullPattern.setSourceRange(pattern.sourceStart, pattern.sourceEnd - pattern.sourceStart + 1);
/* 4737 */     return nullPattern;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Modifier createModifier(Modifier.ModifierKeyword keyword) {
/* 4744 */     Modifier modifier = new Modifier(this.ast);
/* 4745 */     modifier.setKeyword(keyword);
/* 4746 */     int start = this.scanner.getCurrentTokenStartPosition();
/* 4747 */     int end = this.scanner.getCurrentTokenEndPosition();
/* 4748 */     modifier.setSourceRange(start, end - start + 1);
/* 4749 */     return modifier;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ModuleModifier createModuleModifier(ModuleModifier.ModuleModifierKeyword keyword) {
/* 4756 */     ModuleModifier modifier = new ModuleModifier(this.ast);
/* 4757 */     modifier.setKeyword(keyword);
/* 4758 */     int start = this.scanner.getCurrentTokenStartPosition();
/* 4759 */     int end = this.scanner.getCurrentTokenEndPosition();
/* 4760 */     modifier.setSourceRange(start, end - start + 1);
/* 4761 */     return modifier;
/*      */   }
/*      */   
/*      */   protected InfixExpression.Operator getOperatorFor(int operatorID) {
/* 4765 */     switch (operatorID) {
/*      */       case 18:
/* 4767 */         return InfixExpression.Operator.EQUALS;
/*      */       case 5:
/* 4769 */         return InfixExpression.Operator.LESS_EQUALS;
/*      */       case 7:
/* 4771 */         return InfixExpression.Operator.GREATER_EQUALS;
/*      */       case 29:
/* 4773 */         return InfixExpression.Operator.NOT_EQUALS;
/*      */       case 10:
/* 4775 */         return InfixExpression.Operator.LEFT_SHIFT;
/*      */       case 17:
/* 4777 */         return InfixExpression.Operator.RIGHT_SHIFT_SIGNED;
/*      */       case 19:
/* 4779 */         return InfixExpression.Operator.RIGHT_SHIFT_UNSIGNED;
/*      */       case 1:
/* 4781 */         return InfixExpression.Operator.CONDITIONAL_OR;
/*      */       case 0:
/* 4783 */         return InfixExpression.Operator.CONDITIONAL_AND;
/*      */       case 14:
/* 4785 */         return InfixExpression.Operator.PLUS;
/*      */       case 13:
/* 4787 */         return InfixExpression.Operator.MINUS;
/*      */       case 16:
/* 4789 */         return InfixExpression.Operator.REMAINDER;
/*      */       case 8:
/* 4791 */         return InfixExpression.Operator.XOR;
/*      */       case 2:
/* 4793 */         return InfixExpression.Operator.AND;
/*      */       case 15:
/* 4795 */         return InfixExpression.Operator.TIMES;
/*      */       case 3:
/* 4797 */         return InfixExpression.Operator.OR;
/*      */       case 9:
/* 4799 */         return InfixExpression.Operator.DIVIDE;
/*      */       case 6:
/* 4801 */         return InfixExpression.Operator.GREATER;
/*      */       case 4:
/* 4803 */         return InfixExpression.Operator.LESS;
/*      */     } 
/* 4805 */     return null;
/*      */   }
/*      */   
/*      */   protected PrimitiveType.Code getPrimitiveTypeCode(char[] name) {
/* 4809 */     switch (name[0]) {
/*      */       case 'i':
/* 4811 */         if (name.length == 3 && name[1] == 'n' && name[2] == 't') {
/* 4812 */           return PrimitiveType.INT;
/*      */         }
/*      */         break;
/*      */       case 'l':
/* 4816 */         if (name.length == 4 && name[1] == 'o' && name[2] == 'n' && name[3] == 'g') {
/* 4817 */           return PrimitiveType.LONG;
/*      */         }
/*      */         break;
/*      */       case 'd':
/* 4821 */         if (name.length == 6 && 
/* 4822 */           name[1] == 'o' && 
/* 4823 */           name[2] == 'u' && 
/* 4824 */           name[3] == 'b' && 
/* 4825 */           name[4] == 'l' && 
/* 4826 */           name[5] == 'e') {
/* 4827 */           return PrimitiveType.DOUBLE;
/*      */         }
/*      */         break;
/*      */       case 'f':
/* 4831 */         if (name.length == 5 && 
/* 4832 */           name[1] == 'l' && 
/* 4833 */           name[2] == 'o' && 
/* 4834 */           name[3] == 'a' && 
/* 4835 */           name[4] == 't') {
/* 4836 */           return PrimitiveType.FLOAT;
/*      */         }
/*      */         break;
/*      */       case 'b':
/* 4840 */         if (name.length == 4 && 
/* 4841 */           name[1] == 'y' && 
/* 4842 */           name[2] == 't' && 
/* 4843 */           name[3] == 'e') {
/* 4844 */           return PrimitiveType.BYTE;
/*      */         }
/* 4846 */         if (name.length == 7 && 
/* 4847 */           name[1] == 'o' && 
/* 4848 */           name[2] == 'o' && 
/* 4849 */           name[3] == 'l' && 
/* 4850 */           name[4] == 'e' && 
/* 4851 */           name[5] == 'a' && 
/* 4852 */           name[6] == 'n') {
/* 4853 */           return PrimitiveType.BOOLEAN;
/*      */         }
/*      */         break;
/*      */       case 'c':
/* 4857 */         if (name.length == 4 && 
/* 4858 */           name[1] == 'h' && 
/* 4859 */           name[2] == 'a' && 
/* 4860 */           name[3] == 'r') {
/* 4861 */           return PrimitiveType.CHAR;
/*      */         }
/*      */         break;
/*      */       case 's':
/* 4865 */         if (name.length == 5 && 
/* 4866 */           name[1] == 'h' && 
/* 4867 */           name[2] == 'o' && 
/* 4868 */           name[3] == 'r' && 
/* 4869 */           name[4] == 't') {
/* 4870 */           return PrimitiveType.SHORT;
/*      */         }
/*      */         break;
/*      */       case 'v':
/* 4874 */         if (name.length == 4 && 
/* 4875 */           name[1] == 'o' && 
/* 4876 */           name[2] == 'i' && 
/* 4877 */           name[3] == 'd')
/* 4878 */           return PrimitiveType.VOID; 
/*      */         break;
/*      */     } 
/* 4881 */     return null;
/*      */   }
/*      */   
/*      */   protected boolean isPrimitiveType(char[] name) {
/* 4885 */     switch (name[0]) {
/*      */       case 'i':
/* 4887 */         if (name.length == 3 && name[1] == 'n' && name[2] == 't') {
/* 4888 */           return true;
/*      */         }
/* 4890 */         return false;
/*      */       case 'l':
/* 4892 */         if (name.length == 4 && name[1] == 'o' && name[2] == 'n' && name[3] == 'g') {
/* 4893 */           return true;
/*      */         }
/* 4895 */         return false;
/*      */       case 'd':
/* 4897 */         if (name.length == 6 && 
/* 4898 */           name[1] == 'o' && 
/* 4899 */           name[2] == 'u' && 
/* 4900 */           name[3] == 'b' && 
/* 4901 */           name[4] == 'l' && 
/* 4902 */           name[5] == 'e') {
/* 4903 */           return true;
/*      */         }
/* 4905 */         return false;
/*      */       case 'f':
/* 4907 */         if (name.length == 5 && 
/* 4908 */           name[1] == 'l' && 
/* 4909 */           name[2] == 'o' && 
/* 4910 */           name[3] == 'a' && 
/* 4911 */           name[4] == 't') {
/* 4912 */           return true;
/*      */         }
/* 4914 */         return false;
/*      */       case 'b':
/* 4916 */         if (name.length == 4 && 
/* 4917 */           name[1] == 'y' && 
/* 4918 */           name[2] == 't' && 
/* 4919 */           name[3] == 'e') {
/* 4920 */           return true;
/*      */         }
/* 4922 */         if (name.length == 7 && 
/* 4923 */           name[1] == 'o' && 
/* 4924 */           name[2] == 'o' && 
/* 4925 */           name[3] == 'l' && 
/* 4926 */           name[4] == 'e' && 
/* 4927 */           name[5] == 'a' && 
/* 4928 */           name[6] == 'n') {
/* 4929 */           return true;
/*      */         }
/* 4931 */         return false;
/*      */       case 'c':
/* 4933 */         if (name.length == 4 && 
/* 4934 */           name[1] == 'h' && 
/* 4935 */           name[2] == 'a' && 
/* 4936 */           name[3] == 'r') {
/* 4937 */           return true;
/*      */         }
/* 4939 */         return false;
/*      */       case 's':
/* 4941 */         if (name.length == 5 && 
/* 4942 */           name[1] == 'h' && 
/* 4943 */           name[2] == 'o' && 
/* 4944 */           name[3] == 'r' && 
/* 4945 */           name[4] == 't') {
/* 4946 */           return true;
/*      */         }
/* 4948 */         return false;
/*      */       case 'v':
/* 4950 */         if (name.length == 4 && 
/* 4951 */           name[1] == 'o' && 
/* 4952 */           name[2] == 'i' && 
/* 4953 */           name[3] == 'd') {
/* 4954 */           return true;
/*      */         }
/* 4956 */         return false;
/*      */     } 
/* 4958 */     return false;
/*      */   }
/*      */   private void lookupForScopes() {
/* 4961 */     if (this.pendingNameScopeResolution != null) {
/* 4962 */       for (Iterator<Name> iterator = this.pendingNameScopeResolution.iterator(); iterator.hasNext(); ) {
/* 4963 */         Name name = iterator.next();
/* 4964 */         this.ast.getBindingResolver().recordScope(name, lookupScope(name));
/*      */       } 
/*      */     }
/* 4967 */     if (this.pendingThisExpressionScopeResolution != null) {
/* 4968 */       for (Iterator<ThisExpression> iterator = this.pendingThisExpressionScopeResolution.iterator(); iterator.hasNext(); ) {
/* 4969 */         ThisExpression thisExpression = iterator.next();
/* 4970 */         this.ast.getBindingResolver().recordScope(thisExpression, lookupScope(thisExpression));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private BlockScope lookupScope(ASTNode node) {
/* 4977 */     ASTNode currentNode = node;
/* 4978 */     while (currentNode != null && 
/* 4979 */       !(currentNode instanceof MethodDeclaration) && 
/* 4980 */       !(currentNode instanceof Initializer) && 
/* 4981 */       !(currentNode instanceof FieldDeclaration) && 
/* 4982 */       !(currentNode instanceof AbstractTypeDeclaration)) {
/* 4983 */       currentNode = currentNode.getParent();
/*      */     }
/* 4985 */     if (currentNode == null) {
/* 4986 */       return null;
/*      */     }
/* 4988 */     if (currentNode instanceof Initializer) {
/* 4989 */       Initializer initializer = (Initializer)currentNode;
/* 4990 */       while (!(currentNode instanceof AbstractTypeDeclaration)) {
/* 4991 */         currentNode = currentNode.getParent();
/*      */       }
/* 4993 */       if (currentNode instanceof TypeDeclaration || 
/* 4994 */         currentNode instanceof EnumDeclaration || 
/* 4995 */         currentNode instanceof AnnotationTypeDeclaration || 
/* 4996 */         currentNode instanceof RecordDeclaration) {
/* 4997 */         TypeDeclaration typeDecl = 
/*      */           
/* 4999 */           (TypeDeclaration)this.ast.getBindingResolver().getCorrespondingNode(currentNode);
/* 5000 */         if ((initializer.getModifiers() & 0x8) != 0) {
/* 5001 */           return (BlockScope)typeDecl.staticInitializerScope;
/*      */         }
/* 5003 */         return (BlockScope)typeDecl.initializerScope;
/*      */       } 
/*      */     } else {
/* 5006 */       if (currentNode instanceof FieldDeclaration) {
/* 5007 */         FieldDeclaration fieldDeclaration = (FieldDeclaration)currentNode;
/* 5008 */         while (!(currentNode instanceof AbstractTypeDeclaration)) {
/* 5009 */           currentNode = currentNode.getParent();
/*      */         }
/* 5011 */         TypeDeclaration typeDecl = (TypeDeclaration)this.ast.getBindingResolver().getCorrespondingNode(currentNode);
/* 5012 */         if ((fieldDeclaration.getModifiers() & 0x8) != 0) {
/* 5013 */           return (BlockScope)typeDecl.staticInitializerScope;
/*      */         }
/* 5015 */         return (BlockScope)typeDecl.initializerScope;
/*      */       } 
/* 5017 */       if (currentNode instanceof AbstractTypeDeclaration) {
/* 5018 */         TypeDeclaration typeDecl = (TypeDeclaration)this.ast.getBindingResolver().getCorrespondingNode(currentNode);
/* 5019 */         return (BlockScope)typeDecl.initializerScope;
/*      */       } 
/* 5021 */     }  AbstractMethodDeclaration abstractMethodDeclaration = (AbstractMethodDeclaration)this.ast.getBindingResolver().getCorrespondingNode(currentNode);
/* 5022 */     return (BlockScope)abstractMethodDeclaration.scope;
/*      */   }
/*      */   
/*      */   protected void recordName(Name name, ASTNode compilerNode) {
/* 5026 */     if (compilerNode != null) {
/* 5027 */       if (name instanceof ModuleQualifiedName && 
/* 5028 */         compilerNode instanceof TypeReference) {
/* 5029 */         Name tName = ((ModuleQualifiedName)name).getName();
/* 5030 */         if (tName != null) {
/* 5031 */           recordName(tName, compilerNode);
/*      */           return;
/*      */         } 
/*      */       } 
/* 5035 */       recordNodes(name, compilerNode);
/* 5036 */       if (compilerNode instanceof TypeReference) {
/* 5037 */         TypeReference typeRef = (TypeReference)compilerNode;
/* 5038 */         if (name.isQualifiedName()) {
/* 5039 */           SimpleName simpleName = null;
/* 5040 */           while (name.isQualifiedName()) {
/* 5041 */             simpleName = ((QualifiedName)name).getName();
/* 5042 */             recordNodes(simpleName, (ASTNode)typeRef);
/* 5043 */             name = ((QualifiedName)name).getQualifier();
/* 5044 */             recordNodes(name, (ASTNode)typeRef);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void recordNodes(ASTNode node, ASTNode oldASTNode) {
/* 5053 */     if (oldASTNode instanceof org.eclipse.jdt.internal.compiler.ast.FunctionalExpression && node instanceof NullLiteral) {
/*      */       return;
/*      */     }
/* 5056 */     if (oldASTNode instanceof Pattern && node instanceof NullPattern) {
/*      */       return;
/*      */     }
/* 5059 */     this.ast.getBindingResolver().store(node, oldASTNode);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void recordNodes(Javadoc javadoc, TagElement tagElement) {
/* 5064 */     Iterator<ASTNode> fragments = tagElement.fragments().listIterator();
/* 5065 */     while (fragments.hasNext()) {
/* 5066 */       ASTNode node = fragments.next();
/* 5067 */       if (node.getNodeType() == 67) {
/* 5068 */         MemberRef memberRef = (MemberRef)node;
/* 5069 */         Name name = memberRef.getName();
/*      */         
/* 5071 */         int start = name.getStartPosition();
/* 5072 */         ASTNode compilerNode = javadoc.getNodeStartingAt(start);
/* 5073 */         if (compilerNode != null) {
/* 5074 */           recordNodes(name, compilerNode);
/* 5075 */           recordNodes(node, compilerNode);
/*      */         } 
/*      */         
/* 5078 */         if (memberRef.getQualifier() != null) {
/* 5079 */           TypeReference typeRef = null;
/* 5080 */           JavadocModuleReference modRef = null;
/* 5081 */           if (compilerNode instanceof JavadocFieldReference) {
/* 5082 */             Expression expression = ((JavadocFieldReference)compilerNode).receiver;
/* 5083 */             if (expression instanceof TypeReference) {
/* 5084 */               typeRef = (TypeReference)expression;
/* 5085 */             } else if (expression instanceof JavadocModuleReference) {
/* 5086 */               modRef = (JavadocModuleReference)expression;
/* 5087 */               if (modRef.typeReference != null) {
/* 5088 */                 typeRef = modRef.typeReference;
/*      */               }
/*      */             }
/*      */           
/* 5092 */           } else if (compilerNode instanceof JavadocMessageSend) {
/* 5093 */             Expression expression = ((JavadocMessageSend)compilerNode).receiver;
/* 5094 */             if (expression instanceof TypeReference) {
/* 5095 */               typeRef = (TypeReference)expression;
/*      */             }
/*      */           } 
/* 5098 */           Name mQual = memberRef.getQualifier();
/* 5099 */           if (typeRef != null) {
/* 5100 */             if (mQual instanceof ModuleQualifiedName && 
/* 5101 */               modRef != null) {
/* 5102 */               ModuleQualifiedName moduleQualifiedName = (ModuleQualifiedName)mQual;
/* 5103 */               recordName(moduleQualifiedName, (ASTNode)modRef);
/* 5104 */               recordName(moduleQualifiedName.getModuleQualifier(), (ASTNode)modRef.moduleReference);
/* 5105 */               recordName(moduleQualifiedName.getName(), (ASTNode)typeRef); continue;
/*      */             } 
/* 5107 */             recordName(memberRef.getQualifier(), (ASTNode)typeRef);
/*      */           } 
/*      */         }  continue;
/*      */       } 
/* 5111 */       if (node.getNodeType() == 68) {
/* 5112 */         MethodRef methodRef = (MethodRef)node;
/* 5113 */         Name name = methodRef.getName();
/*      */         
/* 5115 */         int start = methodRef.getStartPosition();
/* 5116 */         this.scanner.resetTo(start, start + name.getStartPosition() + name.getLength());
/*      */         try {
/*      */           int token;
/* 5119 */           while ((token = this.scanner.getNextToken()) != 64 && token != 23) {
/* 5120 */             if (token == 138 && this.scanner.currentCharacter == '#') {
/* 5121 */               start = this.scanner.getCurrentTokenEndPosition() + 1;
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/* 5126 */         } catch (InvalidInputException invalidInputException) {}
/*      */ 
/*      */ 
/*      */         
/* 5130 */         ASTNode compilerNode = javadoc.getNodeStartingAt(start);
/*      */         
/* 5132 */         if (compilerNode != null) {
/* 5133 */           recordNodes(methodRef, compilerNode);
/*      */           
/* 5135 */           TypeReference typeRef = null;
/* 5136 */           if (compilerNode instanceof JavadocAllocationExpression) {
/* 5137 */             typeRef = ((JavadocAllocationExpression)compilerNode).type;
/* 5138 */             if (typeRef != null) recordNodes(name, compilerNode);
/*      */           
/* 5140 */           } else if (compilerNode instanceof JavadocMessageSend) {
/* 5141 */             Expression expression = ((JavadocMessageSend)compilerNode).receiver;
/* 5142 */             if (expression instanceof TypeReference) {
/* 5143 */               typeRef = (TypeReference)expression;
/*      */             }
/* 5145 */             recordNodes(name, compilerNode);
/*      */           } 
/* 5147 */           Name mQual = methodRef.getQualifier();
/*      */           
/* 5149 */           if (typeRef != null && mQual != null) {
/* 5150 */             if (mQual instanceof ModuleQualifiedName) {
/* 5151 */               recordName(mQual, javadoc.getNodeStartingAt(mQual.getStartPosition()));
/*      */             }
/* 5153 */             recordName(methodRef.getQualifier(), (ASTNode)typeRef);
/*      */           } 
/*      */         } 
/*      */         
/* 5157 */         Iterator<MethodRefParameter> parameters = methodRef.parameters().listIterator();
/* 5158 */         while (parameters.hasNext()) {
/* 5159 */           MethodRefParameter param = parameters.next();
/* 5160 */           Expression expression = (Expression)javadoc.getNodeStartingAt(param.getStartPosition());
/* 5161 */           if (expression != null) {
/* 5162 */             recordNodes(param, (ASTNode)expression);
/* 5163 */             if (expression instanceof JavadocArgumentExpression) {
/* 5164 */               JavadocArgumentExpression argExpr = (JavadocArgumentExpression)expression;
/* 5165 */               TypeReference typeRef = argExpr.argument.type;
/* 5166 */               if (this.ast.apiLevel >= 3) {
/* 5167 */                 param.setVarargs(argExpr.argument.isVarArgs());
/*      */               }
/* 5169 */               recordNodes(param.getType(), (ASTNode)typeRef);
/* 5170 */               if (param.getType().isSimpleType()) {
/* 5171 */                 recordName(((SimpleType)param.getType()).getName(), (ASTNode)typeRef); continue;
/* 5172 */               }  if (param.getType().isArrayType()) {
/* 5173 */                 Type type = ((ArrayType)param.getType()).getElementType();
/* 5174 */                 recordNodes(type, (ASTNode)typeRef);
/* 5175 */                 if (type.isSimpleType())
/* 5176 */                   recordName(((SimpleType)type).getName(), (ASTNode)typeRef); 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         }  continue;
/*      */       } 
/* 5182 */       if (node.getNodeType() == 42 || 
/* 5183 */         node.getNodeType() == 40) {
/* 5184 */         ASTNode compilerNode = javadoc.getNodeStartingAt(node.getStartPosition());
/* 5185 */         recordName((Name)node, compilerNode); continue;
/* 5186 */       }  if (node.getNodeType() == 105) {
/* 5187 */         ModuleQualifiedName mqName = (ModuleQualifiedName)node;
/* 5188 */         ASTNode compilerNode = javadoc.getNodeStartingAt(mqName.getStartPosition());
/* 5189 */         recordName(mqName, compilerNode);
/* 5190 */         Name name = mqName.getName();
/* 5191 */         if (name != null) {
/* 5192 */           ASTNode internalNode = javadoc.getNodeStartingAt(name.getStartPosition());
/* 5193 */           recordName(name, internalNode);
/*      */         } 
/* 5195 */         if (compilerNode instanceof JavadocModuleReference) {
/* 5196 */           ModuleReference moduleReference = ((JavadocModuleReference)compilerNode).moduleReference;
/* 5197 */           recordNodes(mqName.getModuleQualifier(), (ASTNode)moduleReference);
/*      */         }  continue;
/* 5199 */       }  if (node.getNodeType() == 65)
/*      */       {
/* 5201 */         recordNodes(javadoc, (TagElement)node);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void recordPendingNameScopeResolution(Name name) {
/* 5207 */     if (this.pendingNameScopeResolution == null) {
/* 5208 */       this.pendingNameScopeResolution = new HashSet();
/*      */     }
/* 5210 */     this.pendingNameScopeResolution.add(name);
/*      */   }
/*      */   
/*      */   protected void recordPendingThisExpressionScopeResolution(ThisExpression thisExpression) {
/* 5214 */     if (this.pendingThisExpressionScopeResolution == null) {
/* 5215 */       this.pendingThisExpressionScopeResolution = new HashSet();
/*      */     }
/* 5217 */     this.pendingThisExpressionScopeResolution.add(thisExpression);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void trimWhiteSpacesAndComments(Expression expression) {
/* 5224 */     int[] positions = trimWhiteSpacesAndComments(expression.sourceStart, expression.sourceEnd);
/* 5225 */     expression.sourceStart = positions[0];
/* 5226 */     expression.sourceEnd = positions[1];
/*      */   }
/*      */   private void trimWhiteSpacesAndComments(ASTNode node) {
/* 5229 */     int start = node.getStartPosition();
/* 5230 */     int end = start + node.getLength() - 1;
/* 5231 */     int[] positions = trimWhiteSpacesAndComments(start, end);
/* 5232 */     start = positions[0];
/* 5233 */     end = positions[1];
/* 5234 */     node.setSourceRange(start, end - start + 1);
/*      */   }
/*      */   private int[] trimWhiteSpacesAndComments(int start, int end) {
/* 5237 */     int[] positions = { start, end };
/*      */     
/* 5239 */     int trimLeftPosition = start;
/* 5240 */     int trimRightPosition = end;
/* 5241 */     boolean first = true;
/* 5242 */     Scanner removeBlankScanner = this.ast.scanner;
/*      */     try {
/* 5244 */       removeBlankScanner.setSource(this.compilationUnitSource);
/* 5245 */       removeBlankScanner.resetTo(start, end);
/*      */       while (true) {
/* 5247 */         int token = removeBlankScanner.getNextToken();
/* 5248 */         switch (token) {
/*      */           case 1001:
/*      */           case 1002:
/*      */           case 1003:
/* 5252 */             if (first) {
/* 5253 */               trimLeftPosition = removeBlankScanner.currentPosition;
/*      */             }
/*      */             continue;
/*      */           case 1000:
/* 5257 */             if (first) {
/* 5258 */               trimLeftPosition = removeBlankScanner.currentPosition;
/*      */             }
/*      */             continue;
/*      */           case 64:
/* 5262 */             positions[0] = trimLeftPosition;
/* 5263 */             positions[1] = trimRightPosition;
/* 5264 */             return positions;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5271 */         trimRightPosition = removeBlankScanner.currentPosition - 1;
/* 5272 */         first = false;
/*      */       }
/*      */     
/* 5275 */     } catch (InvalidInputException invalidInputException) {
/*      */ 
/*      */       
/* 5278 */       return positions;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void removeLeadingAndTrailingCommentsFromLiteral(ASTNode node) {
/* 5285 */     int start = node.getStartPosition();
/* 5286 */     this.scanner.resetTo(start, start + node.getLength());
/*      */     
/* 5288 */     int startPosition = -1; try {
/*      */       int token;
/* 5290 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5291 */         int end; switch (token) {
/*      */           case 55:
/*      */           case 56:
/*      */           case 57:
/*      */           case 58:
/*      */           case 59:
/* 5297 */             if (startPosition == -1) {
/* 5298 */               startPosition = this.scanner.startPosition;
/*      */             }
/* 5300 */             end = this.scanner.currentPosition;
/* 5301 */             node.setSourceRange(startPosition, end - startPosition);
/*      */             return;
/*      */           case 5:
/* 5304 */             startPosition = this.scanner.startPosition;
/*      */         } 
/*      */       
/*      */       } 
/* 5308 */     } catch (InvalidInputException invalidInputException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int retrieveClosingAngleBracketPosition(int start) {
/* 5318 */     this.scanner.resetTo(start, this.compilationUnitSourceLength);
/* 5319 */     this.scanner.returnOnlyGreater = true;
/*      */     try {
/*      */       int token;
/* 5322 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5323 */         switch (token) {
/*      */           case 15:
/* 5325 */             return this.scanner.currentPosition - 1;
/*      */           
/*      */           case 11:
/*      */             continue;
/*      */         } 
/* 5330 */         return start;
/*      */       }
/*      */     
/* 5333 */     } catch (InvalidInputException invalidInputException) {}
/*      */ 
/*      */     
/* 5336 */     this.scanner.returnOnlyGreater = false;
/* 5337 */     return start;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void retrieveColonPosition(ASTNode node) {
/* 5346 */     setNodeSourceEndPosition(node, 65);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void retrieveArrowPosition(ASTNode node) {
/* 5354 */     setNodeSourceEndPosition(node, 104);
/*      */   }
/*      */   private void setNodeSourceEndPosition(ASTNode node, int expectedToken) {
/* 5357 */     int start = node.getStartPosition();
/* 5358 */     int length = node.getLength();
/* 5359 */     int end = start + length;
/* 5360 */     this.scanner.resetTo(end, this.compilationUnitSourceLength);
/*      */     try {
/*      */       int token;
/* 5363 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5364 */         if (token == expectedToken) {
/* 5365 */           node.setSourceRange(start, this.scanner.currentPosition - start);
/*      */           return;
/*      */         } 
/*      */       } 
/* 5369 */     } catch (InvalidInputException invalidInputException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int retrieveEllipsisStartPosition(int start, int end) {
/* 5377 */     this.scanner.resetTo(start, end);
/*      */     try {
/*      */       int token;
/* 5380 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5381 */         switch (token) {
/*      */           case 120:
/* 5383 */             return this.scanner.startPosition - 1;
/*      */         } 
/*      */       } 
/* 5386 */     } catch (InvalidInputException invalidInputException) {}
/*      */ 
/*      */     
/* 5389 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   protected int retrieveSemiColonPosition(Expression node) {
/* 5394 */     int start = node.getStartPosition();
/* 5395 */     int length = node.getLength();
/* 5396 */     int end = start + length;
/* 5397 */     this.scanner.resetTo(end, this.compilationUnitSourceLength);
/*      */     try {
/*      */       int token;
/* 5400 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5401 */         switch (token) {
/*      */           case 24:
/* 5403 */             return this.scanner.currentPosition - 1;
/*      */         } 
/*      */       } 
/* 5406 */     } catch (InvalidInputException invalidInputException) {}
/*      */ 
/*      */     
/* 5409 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int[] retrieveEndOfElementTypeNamePosition(int start, int end) {
/* 5418 */     this.scanner.resetTo(start, end);
/*      */     
/*      */     try {
/* 5421 */       int count = 0; int token;
/* 5422 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5423 */         switch (token) {
/*      */           case 23:
/* 5425 */             count++;
/*      */           
/*      */           case 26:
/* 5428 */             count--;
/*      */           
/*      */           case 19:
/*      */           case 105:
/*      */           case 106:
/*      */           case 108:
/*      */           case 109:
/*      */           case 110:
/*      */           case 112:
/*      */           case 113:
/*      */           case 114:
/* 5439 */             if (count > 0)
/* 5440 */               continue;  return new int[] { this.scanner.startPosition, this.scanner.currentPosition - 1 };
/*      */         } 
/*      */       } 
/* 5443 */     } catch (InvalidInputException invalidInputException) {}
/*      */ 
/*      */     
/* 5446 */     return new int[] { -1, -1 };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int retrieveEndOfRightParenthesisPosition(int start, int end) {
/* 5454 */     this.scanner.resetTo(start, end);
/*      */     
/*      */     try {
/* 5457 */       int count = 0; int token;
/* 5458 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5459 */         switch (token) {
/*      */           case 26:
/* 5461 */             count--;
/* 5462 */             if (count <= 0) return this.scanner.currentPosition;
/*      */           
/*      */           case 23:
/* 5465 */             count++;
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       } 
/* 5471 */     } catch (InvalidInputException invalidInputException) {}
/*      */ 
/*      */     
/* 5474 */     return -1;
/*      */   }
/*      */   
/*      */   protected void retrieveDimensionAndSetPositions(int start, int end, Dimension dim) {
/* 5478 */     this.scanner.resetTo(start, end);
/*      */     
/* 5480 */     int count = 0, lParenCount = 0;
/* 5481 */     boolean startSet = false; try {
/*      */       int token;
/* 5483 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5484 */         if (token != 1000) {
/* 5485 */           int endDim; if (!startSet) {
/* 5486 */             start = this.scanner.startPosition;
/* 5487 */             startSet = true;
/*      */           } 
/* 5489 */           switch (token) {
/*      */             
/*      */             case 69:
/* 5492 */               count--;
/* 5493 */               if (lParenCount > 0 || count > 0)
/* 5494 */                 continue;  endDim = this.scanner.currentPosition - 1;
/* 5495 */               dim.setSourceRange(start, endDim - start + 1);
/*      */               return;
/*      */             case 6:
/* 5498 */               if (lParenCount > 0)
/* 5499 */                 continue;  count++;
/*      */             
/*      */             case 23:
/* 5502 */               lParenCount++;
/*      */             
/*      */             case 26:
/* 5505 */               lParenCount--;
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/*      */         } 
/*      */       } 
/* 5512 */     } catch (InvalidInputException invalidInputException) {}
/*      */   }
/*      */ 
/*      */   
/*      */   protected void retrieveIdentifierAndSetPositions(int start, int end, Name name) {
/* 5517 */     this.scanner.resetTo(start, end);
/*      */     try {
/*      */       int token;
/* 5520 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5521 */         if (token == 19) {
/* 5522 */           int startName = this.scanner.startPosition;
/* 5523 */           int endName = this.scanner.currentPosition - 1;
/* 5524 */           name.setSourceRange(startName, endName - startName + 1);
/*      */           return;
/*      */         } 
/*      */       } 
/* 5528 */     } catch (InvalidInputException invalidInputException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int retrieveIdentifierEndPosition(int start, int end) {
/* 5538 */     this.scanner.resetTo(start, end);
/*      */     try {
/*      */       int token;
/* 5541 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5542 */         switch (token) {
/*      */           case 19:
/* 5544 */             return this.scanner.getCurrentTokenEndPosition();
/*      */         } 
/*      */       } 
/* 5547 */     } catch (InvalidInputException invalidInputException) {}
/*      */ 
/*      */     
/* 5550 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void retrieveInitAndSetPositions(int start, int end, Name name) {
/* 5560 */     this.scanner.resetTo(start, end);
/*      */     try {
/*      */       int token;
/* 5563 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5564 */         if (token == 38) {
/* 5565 */           int startName = this.scanner.startPosition;
/* 5566 */           int endName = this.scanner.currentPosition;
/* 5567 */           name.setSourceRange(startName, endName - startName);
/*      */           return;
/*      */         } 
/*      */       } 
/* 5571 */     } catch (InvalidInputException invalidInputException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int retrieveEndOfPotentialExtendedDimensions(int initializerEnd, int nameEnd, int end) {
/* 5582 */     this.scanner.resetTo(initializerEnd, end);
/* 5583 */     boolean hasTokens = false;
/* 5584 */     int balance = 0;
/* 5585 */     int pos = (initializerEnd > nameEnd) ? (initializerEnd - 1) : nameEnd;
/*      */     try {
/* 5587 */       int lParenCount = 0;
/* 5588 */       boolean hasAnnotations = false; int token;
/* 5589 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5590 */         hasTokens = true;
/* 5591 */         if (hasAnnotations) {
/* 5592 */           if (token == 23) { lParenCount++; }
/* 5593 */           else if (token == 26)
/* 5594 */           { lParenCount--;
/*      */             continue; }
/*      */           
/* 5597 */           if (lParenCount > 0)
/*      */             continue; 
/* 5599 */         }  switch (token) {
/*      */           case 34:
/* 5601 */             hasAnnotations = true;
/*      */           
/*      */           case 6:
/*      */           case 40:
/* 5605 */             balance++;
/*      */           
/*      */           case 33:
/*      */           case 69:
/* 5609 */             balance--;
/* 5610 */             pos = this.scanner.currentPosition - 1;
/*      */           
/*      */           case 32:
/* 5613 */             if (balance == 0) return pos;
/*      */             
/* 5615 */             pos = this.scanner.currentPosition - 1;
/*      */           
/*      */           case 24:
/* 5618 */             if (balance == 0) return pos; 
/* 5619 */             return -pos;
/*      */         } 
/*      */       } 
/* 5622 */     } catch (InvalidInputException invalidInputException) {}
/*      */ 
/*      */ 
/*      */     
/* 5626 */     return hasTokens ? Integer.MIN_VALUE : pos;
/*      */   }
/*      */   
/*      */   protected int retrieveProperRightBracketPosition(int bracketNumber, int start, int end) {
/* 5630 */     this.scanner.resetTo(start, this.compilationUnitSourceLength);
/*      */     try {
/* 5632 */       int count = 0, lParentCount = 0, balance = 0; int token;
/* 5633 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5634 */         switch (token) {
/*      */           case 23:
/* 5636 */             lParentCount++;
/*      */           
/*      */           case 26:
/* 5639 */             lParentCount--;
/*      */           
/*      */           case 6:
/* 5642 */             balance++;
/*      */           
/*      */           case 120:
/* 5645 */             balance++;
/*      */           
/*      */           case 69:
/* 5648 */             balance--;
/*      */ 
/*      */             
/* 5651 */             count++;
/* 5652 */             if (lParentCount <= 0 && balance <= 0 && count == bracketNumber) {
/* 5653 */               return this.scanner.currentPosition - 1;
/*      */             }
/*      */         } 
/*      */       } 
/* 5657 */     } catch (InvalidInputException invalidInputException) {}
/*      */ 
/*      */     
/* 5660 */     return -1;
/*      */   }
/*      */   
/*      */   protected int retrieveProperRightBracketPosition(int bracketNumber, int start) {
/* 5664 */     return retrieveProperRightBracketPosition(bracketNumber, start, this.compilationUnitSourceLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int retrieveRightBraceOrSemiColonPosition(int start, int end) {
/* 5672 */     this.scanner.resetTo(start, end);
/*      */     try {
/*      */       int token;
/* 5675 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5676 */         switch (token) {
/*      */           case 33:
/* 5678 */             return this.scanner.currentPosition - 1;
/*      */           case 24:
/* 5680 */             return this.scanner.currentPosition - 1;
/*      */         } 
/*      */       } 
/* 5683 */     } catch (InvalidInputException invalidInputException) {}
/*      */ 
/*      */     
/* 5686 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int retrieveRightBrace(int start, int end) {
/* 5694 */     this.scanner.resetTo(start, end);
/*      */     try {
/*      */       int token;
/* 5697 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5698 */         switch (token) {
/*      */           case 33:
/* 5700 */             return this.scanner.currentPosition - 1;
/*      */         } 
/*      */       } 
/* 5703 */     } catch (InvalidInputException invalidInputException) {}
/*      */ 
/*      */     
/* 5706 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int retrieveStartBlockPosition(int start, int end) {
/* 5714 */     this.scanner.resetTo(start, end);
/*      */     try {
/*      */       int token;
/* 5717 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5718 */         switch (token) {
/*      */           case 40:
/* 5720 */             return this.scanner.startPosition;
/*      */         } 
/*      */       } 
/* 5723 */     } catch (InvalidInputException invalidInputException) {}
/*      */ 
/*      */     
/* 5726 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int retrieveStartingCatchPosition(int start, int end) {
/* 5734 */     this.scanner.resetTo(start, end);
/*      */     try {
/*      */       int token;
/* 5737 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5738 */         switch (token) {
/*      */           case 107:
/* 5740 */             return this.scanner.startPosition;
/*      */         } 
/*      */       } 
/* 5743 */     } catch (InvalidInputException invalidInputException) {}
/*      */ 
/*      */     
/* 5746 */     return -1;
/*      */   }
/*      */   
/*      */   public void setAST(AST ast) {
/* 5750 */     this.ast = ast;
/* 5751 */     this.docParser = new DocCommentParser(this.ast, this.scanner, this.insideComments);
/*      */   }
/*      */   
/*      */   protected void setModifiers(AnnotationTypeDeclaration typeDecl, TypeDeclaration typeDeclaration) {
/* 5755 */     this.scanner.resetTo(typeDeclaration.declarationSourceStart, typeDeclaration.sourceStart);
/* 5756 */     setModifiers(typeDecl, typeDeclaration.annotations, typeDeclaration.sourceStart);
/*      */   }
/*      */   
/*      */   protected void setModifiers(AnnotationTypeMemberDeclaration annotationTypeMemberDecl, AnnotationMethodDeclaration annotationTypeMemberDeclaration) {
/* 5760 */     this.scanner.resetTo(annotationTypeMemberDeclaration.declarationSourceStart, annotationTypeMemberDeclaration.sourceStart);
/* 5761 */     setModifiers(annotationTypeMemberDecl, annotationTypeMemberDeclaration.annotations, annotationTypeMemberDeclaration.sourceStart);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setModifiers(BodyDeclaration bodyDeclaration, Annotation[] annotations, int modifiersEnd) {
/* 5768 */     setModifiers(bodyDeclaration.modifiers(), annotations, modifiersEnd);
/*      */   }
/*      */   protected void setModifiers(List<IExtendedModifier> modifiers, Annotation[] annotations, int modifiersEnd) {
/* 5771 */     this.scanner.tokenizeWhiteSpace = false;
/*      */     
/*      */     try {
/* 5774 */       int indexInAnnotations = 0; int token;
/* 5775 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5776 */         IExtendedModifier modifier = null;
/* 5777 */         switch (token) {
/*      */           case 42:
/* 5779 */             modifier = createModifier(Modifier.ModifierKeyword.ABSTRACT_KEYWORD);
/*      */             break;
/*      */           case 48:
/* 5782 */             modifier = createModifier(Modifier.ModifierKeyword.PUBLIC_KEYWORD);
/*      */             break;
/*      */           case 37:
/* 5785 */             modifier = createModifier(Modifier.ModifierKeyword.STATIC_KEYWORD);
/*      */             break;
/*      */           case 47:
/* 5788 */             modifier = createModifier(Modifier.ModifierKeyword.PROTECTED_KEYWORD);
/*      */             break;
/*      */           case 46:
/* 5791 */             modifier = createModifier(Modifier.ModifierKeyword.PRIVATE_KEYWORD);
/*      */             break;
/*      */           case 43:
/* 5794 */             modifier = createModifier(Modifier.ModifierKeyword.FINAL_KEYWORD);
/*      */             break;
/*      */           case 44:
/* 5797 */             modifier = createModifier(Modifier.ModifierKeyword.NATIVE_KEYWORD);
/*      */             break;
/*      */           case 39:
/* 5800 */             modifier = createModifier(Modifier.ModifierKeyword.SYNCHRONIZED_KEYWORD);
/*      */             break;
/*      */           case 50:
/* 5803 */             modifier = createModifier(Modifier.ModifierKeyword.TRANSIENT_KEYWORD);
/*      */             break;
/*      */           case 51:
/* 5806 */             modifier = createModifier(Modifier.ModifierKeyword.VOLATILE_KEYWORD);
/*      */             break;
/*      */           case 49:
/* 5809 */             modifier = createModifier(Modifier.ModifierKeyword.STRICTFP_KEYWORD);
/*      */             break;
/*      */           case 76:
/* 5812 */             modifier = createModifier(Modifier.ModifierKeyword.DEFAULT_KEYWORD);
/*      */             break;
/*      */           case 41:
/* 5815 */             modifier = createModifier(Modifier.ModifierKeyword.SEALED_KEYWORD);
/*      */             break;
/*      */           case 45:
/* 5818 */             modifier = createModifier(Modifier.ModifierKeyword.NON_SEALED_KEYWORD);
/*      */             break;
/*      */           case 131:
/* 5821 */             modifier = createModifier(Modifier.ModifierKeyword.WHEN_KEYWORD);
/*      */             break;
/*      */           
/*      */           case 34:
/* 5825 */             if (annotations != null && indexInAnnotations < annotations.length) {
/* 5826 */               Annotation annotation = annotations[indexInAnnotations++];
/* 5827 */               modifier = convert(annotation);
/* 5828 */               this.scanner.resetTo(annotation.declarationSourceEnd + 1, modifiersEnd);
/*      */             } 
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5839 */         if (modifier != null) {
/* 5840 */           modifiers.add(modifier);
/*      */         }
/*      */       } 
/* 5843 */     } catch (InvalidInputException invalidInputException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setModifiers(EnumDeclaration enumDeclaration, TypeDeclaration enumDeclaration2) {
/* 5849 */     this.scanner.resetTo(enumDeclaration2.declarationSourceStart, enumDeclaration2.sourceStart);
/* 5850 */     setModifiers(enumDeclaration, enumDeclaration2.annotations, enumDeclaration2.sourceStart);
/*      */   }
/*      */   
/*      */   protected void setModifiers(RecordDeclaration recordDeclaration, TypeDeclaration recordDeclaration2) {
/* 5854 */     this.scanner.resetTo(recordDeclaration2.declarationSourceStart, recordDeclaration2.sourceStart);
/* 5855 */     setModifiers(recordDeclaration, recordDeclaration2.annotations, recordDeclaration2.sourceStart);
/*      */   }
/*      */   
/*      */   protected void setModifiers(EnumConstantDeclaration enumConstantDeclaration, FieldDeclaration fieldDeclaration) {
/* 5859 */     switch (this.ast.apiLevel) {
/*      */       case 2:
/* 5861 */         enumConstantDeclaration.internalSetModifiers(fieldDeclaration.modifiers & 0xFFFF);
/* 5862 */         if (fieldDeclaration.annotations != null) {
/* 5863 */           enumConstantDeclaration.setFlags(enumConstantDeclaration.getFlags() | 0x1);
/*      */         }
/*      */         return;
/*      */     } 
/* 5867 */     this.scanner.resetTo(fieldDeclaration.declarationSourceStart, fieldDeclaration.sourceStart);
/* 5868 */     setModifiers(enumConstantDeclaration, fieldDeclaration.annotations, fieldDeclaration.sourceStart);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setModifiers(FieldDeclaration fieldDeclaration, FieldDeclaration fieldDecl) {
/* 5877 */     switch (this.ast.apiLevel) {
/*      */       case 2:
/* 5879 */         fieldDeclaration.internalSetModifiers(fieldDecl.modifiers & 0xFFFF);
/* 5880 */         if (fieldDecl.annotations != null) {
/* 5881 */           fieldDeclaration.setFlags(fieldDeclaration.getFlags() | 0x1);
/*      */         }
/*      */         return;
/*      */     } 
/* 5885 */     this.scanner.resetTo(fieldDecl.declarationSourceStart, fieldDecl.sourceStart);
/* 5886 */     setModifiers(fieldDeclaration, fieldDecl.annotations, fieldDecl.sourceStart);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setModifiers(Initializer initializer, Initializer oldInitializer) {
/* 5895 */     switch (this.ast.apiLevel) {
/*      */       case 2:
/* 5897 */         initializer.internalSetModifiers(oldInitializer.modifiers & 0xFFFF);
/* 5898 */         if (oldInitializer.annotations != null) {
/* 5899 */           initializer.setFlags(initializer.getFlags() | 0x1);
/*      */         }
/*      */         return;
/*      */     } 
/* 5903 */     this.scanner.resetTo(oldInitializer.declarationSourceStart, oldInitializer.bodyStart);
/* 5904 */     setModifiers(initializer, oldInitializer.annotations, oldInitializer.bodyStart);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setModifiers(MethodDeclaration methodDecl, AbstractMethodDeclaration methodDeclaration) {
/* 5912 */     switch (this.ast.apiLevel) {
/*      */       case 2:
/* 5914 */         methodDecl.internalSetModifiers(methodDeclaration.modifiers & 0xFFFF);
/* 5915 */         if (methodDeclaration.annotations != null) {
/* 5916 */           methodDecl.setFlags(methodDecl.getFlags() | 0x1);
/*      */         }
/*      */         return;
/*      */     } 
/* 5920 */     this.scanner.resetTo(methodDeclaration.declarationSourceStart, methodDeclaration.sourceStart);
/* 5921 */     setModifiers(methodDecl, methodDeclaration.annotations, methodDeclaration.sourceStart);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void setAnnotations(ModuleDeclaration moduleDecl, ModuleDeclaration moduleDeclaration) {
/* 5926 */     this.scanner.resetTo(moduleDeclaration.declarationSourceStart, moduleDeclaration.sourceStart);
/* 5927 */     List<IExtendedModifier> modifiers = new ArrayList<>();
/* 5928 */     setModifiers(modifiers, moduleDeclaration.annotations, moduleDeclaration.sourceStart);
/* 5929 */     for (IExtendedModifier ie : modifiers) {
/* 5930 */       if (!ie.isAnnotation()) {
/*      */         continue;
/*      */       }
/* 5933 */       moduleDecl.annotations().add(ie);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setModifiers(SingleVariableDeclaration variableDecl, Argument argument) {
/* 5941 */     switch (this.ast.apiLevel) {
/*      */       case 2:
/* 5943 */         variableDecl.internalSetModifiers(argument.modifiers & 0xFFFF);
/* 5944 */         if (argument.annotations != null) {
/* 5945 */           variableDecl.setFlags(variableDecl.getFlags() | 0x1);
/*      */         }
/*      */         return;
/*      */     } 
/* 5949 */     this.scanner.resetTo(argument.declarationSourceStart, argument.sourceStart);
/* 5950 */     Annotation[] annotations = argument.annotations;
/* 5951 */     int indexInAnnotations = 0;
/*      */     try {
/*      */       int token;
/* 5954 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 5955 */         IExtendedModifier modifier = null;
/* 5956 */         switch (token) {
/*      */           case 42:
/* 5958 */             modifier = createModifier(Modifier.ModifierKeyword.ABSTRACT_KEYWORD);
/*      */             break;
/*      */           case 48:
/* 5961 */             modifier = createModifier(Modifier.ModifierKeyword.PUBLIC_KEYWORD);
/*      */             break;
/*      */           case 37:
/* 5964 */             modifier = createModifier(Modifier.ModifierKeyword.STATIC_KEYWORD);
/*      */             break;
/*      */           case 47:
/* 5967 */             modifier = createModifier(Modifier.ModifierKeyword.PROTECTED_KEYWORD);
/*      */             break;
/*      */           case 46:
/* 5970 */             modifier = createModifier(Modifier.ModifierKeyword.PRIVATE_KEYWORD);
/*      */             break;
/*      */           case 43:
/* 5973 */             modifier = createModifier(Modifier.ModifierKeyword.FINAL_KEYWORD);
/*      */             break;
/*      */           case 44:
/* 5976 */             modifier = createModifier(Modifier.ModifierKeyword.NATIVE_KEYWORD);
/*      */             break;
/*      */           case 39:
/* 5979 */             modifier = createModifier(Modifier.ModifierKeyword.SYNCHRONIZED_KEYWORD);
/*      */             break;
/*      */           case 50:
/* 5982 */             modifier = createModifier(Modifier.ModifierKeyword.TRANSIENT_KEYWORD);
/*      */             break;
/*      */           case 51:
/* 5985 */             modifier = createModifier(Modifier.ModifierKeyword.VOLATILE_KEYWORD);
/*      */             break;
/*      */           case 49:
/* 5988 */             modifier = createModifier(Modifier.ModifierKeyword.STRICTFP_KEYWORD);
/*      */             break;
/*      */           
/*      */           case 34:
/* 5992 */             if (annotations != null && indexInAnnotations < annotations.length) {
/* 5993 */               Annotation annotation = annotations[indexInAnnotations++];
/* 5994 */               modifier = convert(annotation);
/* 5995 */               this.scanner.resetTo(annotation.declarationSourceEnd + 1, this.compilationUnitSourceLength);
/*      */             } 
/*      */             break;
/*      */           case 1001:
/*      */           case 1002:
/*      */           case 1003:
/*      */             break;
/*      */           default:
/*      */             return;
/*      */         } 
/* 6005 */         if (modifier != null) {
/* 6006 */           variableDecl.modifiers().add(modifier);
/*      */         }
/*      */       } 
/* 6009 */     } catch (InvalidInputException invalidInputException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setModifiers(SingleVariableDeclaration variableDecl, LocalDeclaration localDeclaration) {
/* 6016 */     switch (this.ast.apiLevel) {
/*      */       case 2:
/* 6018 */         variableDecl.internalSetModifiers(localDeclaration.modifiers & 0xFFFF);
/* 6019 */         if (localDeclaration.annotations != null) {
/* 6020 */           variableDecl.setFlags(variableDecl.getFlags() | 0x1);
/*      */         }
/*      */         return;
/*      */     } 
/* 6024 */     this.scanner.resetTo(localDeclaration.declarationSourceStart, localDeclaration.sourceStart);
/* 6025 */     Annotation[] annotations = localDeclaration.annotations;
/* 6026 */     int indexInAnnotations = 0;
/*      */     try {
/*      */       int token;
/* 6029 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 6030 */         IExtendedModifier modifier = null;
/* 6031 */         switch (token) {
/*      */           case 42:
/* 6033 */             modifier = createModifier(Modifier.ModifierKeyword.ABSTRACT_KEYWORD);
/*      */             break;
/*      */           case 48:
/* 6036 */             modifier = createModifier(Modifier.ModifierKeyword.PUBLIC_KEYWORD);
/*      */             break;
/*      */           case 37:
/* 6039 */             modifier = createModifier(Modifier.ModifierKeyword.STATIC_KEYWORD);
/*      */             break;
/*      */           case 47:
/* 6042 */             modifier = createModifier(Modifier.ModifierKeyword.PROTECTED_KEYWORD);
/*      */             break;
/*      */           case 46:
/* 6045 */             modifier = createModifier(Modifier.ModifierKeyword.PRIVATE_KEYWORD);
/*      */             break;
/*      */           case 43:
/* 6048 */             modifier = createModifier(Modifier.ModifierKeyword.FINAL_KEYWORD);
/*      */             break;
/*      */           case 44:
/* 6051 */             modifier = createModifier(Modifier.ModifierKeyword.NATIVE_KEYWORD);
/*      */             break;
/*      */           case 39:
/* 6054 */             modifier = createModifier(Modifier.ModifierKeyword.SYNCHRONIZED_KEYWORD);
/*      */             break;
/*      */           case 50:
/* 6057 */             modifier = createModifier(Modifier.ModifierKeyword.TRANSIENT_KEYWORD);
/*      */             break;
/*      */           case 51:
/* 6060 */             modifier = createModifier(Modifier.ModifierKeyword.VOLATILE_KEYWORD);
/*      */             break;
/*      */           case 49:
/* 6063 */             modifier = createModifier(Modifier.ModifierKeyword.STRICTFP_KEYWORD);
/*      */             break;
/*      */           
/*      */           case 34:
/* 6067 */             if (annotations != null && indexInAnnotations < annotations.length) {
/* 6068 */               Annotation annotation = annotations[indexInAnnotations++];
/* 6069 */               modifier = convert(annotation);
/* 6070 */               this.scanner.resetTo(annotation.declarationSourceEnd + 1, this.compilationUnitSourceLength);
/*      */             } 
/*      */             break;
/*      */           case 1001:
/*      */           case 1002:
/*      */           case 1003:
/*      */             break;
/*      */           default:
/*      */             return;
/*      */         } 
/* 6080 */         if (modifier != null) {
/* 6081 */           variableDecl.modifiers().add(modifier);
/*      */         }
/*      */       } 
/* 6084 */     } catch (InvalidInputException invalidInputException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setModifiers(SingleVariableDeclaration variableDecl, RecordComponent component) {
/* 6097 */     switch (this.ast.apiLevel) {
/*      */       case 2:
/* 6099 */         variableDecl.internalSetModifiers(component.modifiers & 0xFFFF);
/* 6100 */         if (component.annotations != null) {
/* 6101 */           variableDecl.setFlags(variableDecl.getFlags() | 0x1);
/*      */         }
/*      */         return;
/*      */     } 
/* 6105 */     this.scanner.resetTo(component.declarationSourceStart, component.sourceStart);
/* 6106 */     Annotation[] annotations = component.annotations;
/* 6107 */     int indexInAnnotations = 0;
/*      */     try {
/*      */       int token;
/* 6110 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 6111 */         IExtendedModifier modifier = null;
/* 6112 */         switch (token) {
/*      */           case 42:
/* 6114 */             modifier = createModifier(Modifier.ModifierKeyword.ABSTRACT_KEYWORD);
/*      */             break;
/*      */           case 48:
/* 6117 */             modifier = createModifier(Modifier.ModifierKeyword.PUBLIC_KEYWORD);
/*      */             break;
/*      */           case 37:
/* 6120 */             modifier = createModifier(Modifier.ModifierKeyword.STATIC_KEYWORD);
/*      */             break;
/*      */           case 47:
/* 6123 */             modifier = createModifier(Modifier.ModifierKeyword.PROTECTED_KEYWORD);
/*      */             break;
/*      */           case 46:
/* 6126 */             modifier = createModifier(Modifier.ModifierKeyword.PRIVATE_KEYWORD);
/*      */             break;
/*      */           case 43:
/* 6129 */             modifier = createModifier(Modifier.ModifierKeyword.FINAL_KEYWORD);
/*      */             break;
/*      */           case 44:
/* 6132 */             modifier = createModifier(Modifier.ModifierKeyword.NATIVE_KEYWORD);
/*      */             break;
/*      */           case 39:
/* 6135 */             modifier = createModifier(Modifier.ModifierKeyword.SYNCHRONIZED_KEYWORD);
/*      */             break;
/*      */           case 50:
/* 6138 */             modifier = createModifier(Modifier.ModifierKeyword.TRANSIENT_KEYWORD);
/*      */             break;
/*      */           case 51:
/* 6141 */             modifier = createModifier(Modifier.ModifierKeyword.VOLATILE_KEYWORD);
/*      */             break;
/*      */           case 49:
/* 6144 */             modifier = createModifier(Modifier.ModifierKeyword.STRICTFP_KEYWORD);
/*      */             break;
/*      */           
/*      */           case 34:
/* 6148 */             if (annotations != null && indexInAnnotations < annotations.length) {
/* 6149 */               Annotation annotation = annotations[indexInAnnotations++];
/* 6150 */               modifier = convert(annotation);
/* 6151 */               this.scanner.resetTo(annotation.declarationSourceEnd + 1, this.compilationUnitSourceLength);
/*      */             } 
/*      */             break;
/*      */           case 1001:
/*      */           case 1002:
/*      */           case 1003:
/*      */             break;
/*      */           default:
/*      */             return;
/*      */         } 
/* 6161 */         if (modifier != null) {
/* 6162 */           variableDecl.modifiers().add(modifier);
/*      */         }
/*      */       } 
/* 6165 */     } catch (InvalidInputException invalidInputException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setModifiers(TypeDeclaration typeDecl, TypeDeclaration typeDeclaration) {
/*      */     int modifiers;
/* 6175 */     switch (this.ast.apiLevel) {
/*      */       case 2:
/* 6177 */         modifiers = typeDeclaration.modifiers;
/* 6178 */         modifiers &= 0xFFFFFDFF;
/* 6179 */         modifiers &= 0xFFFF;
/* 6180 */         typeDecl.internalSetModifiers(modifiers);
/* 6181 */         if (typeDeclaration.annotations != null) {
/* 6182 */           typeDecl.setFlags(typeDecl.getFlags() | 0x1);
/*      */         }
/*      */         return;
/*      */     } 
/* 6186 */     this.scanner.resetTo(typeDeclaration.declarationSourceStart, typeDeclaration.sourceStart);
/* 6187 */     setModifiers(typeDecl, typeDeclaration.annotations, typeDeclaration.sourceStart);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setModifiers(VariableDeclarationExpression variableDeclarationExpression, LocalDeclaration localDeclaration) {
/*      */     int modifiers;
/* 6196 */     switch (this.ast.apiLevel) {
/*      */       case 2:
/* 6198 */         modifiers = localDeclaration.modifiers & 0xFFFF;
/* 6199 */         modifiers &= 0xFBFFFFFF;
/* 6200 */         variableDeclarationExpression.internalSetModifiers(modifiers);
/* 6201 */         if (localDeclaration.annotations != null) {
/* 6202 */           variableDeclarationExpression.setFlags(variableDeclarationExpression.getFlags() | 0x1);
/*      */         }
/*      */         return;
/*      */     } 
/* 6206 */     this.scanner.resetTo(localDeclaration.declarationSourceStart, localDeclaration.sourceStart);
/* 6207 */     Annotation[] annotations = localDeclaration.annotations;
/* 6208 */     int indexInAnnotations = 0;
/*      */     try {
/*      */       int token;
/* 6211 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 6212 */         IExtendedModifier modifier = null;
/* 6213 */         switch (token) {
/*      */           case 42:
/* 6215 */             modifier = createModifier(Modifier.ModifierKeyword.ABSTRACT_KEYWORD);
/*      */             break;
/*      */           case 48:
/* 6218 */             modifier = createModifier(Modifier.ModifierKeyword.PUBLIC_KEYWORD);
/*      */             break;
/*      */           case 37:
/* 6221 */             modifier = createModifier(Modifier.ModifierKeyword.STATIC_KEYWORD);
/*      */             break;
/*      */           case 47:
/* 6224 */             modifier = createModifier(Modifier.ModifierKeyword.PROTECTED_KEYWORD);
/*      */             break;
/*      */           case 46:
/* 6227 */             modifier = createModifier(Modifier.ModifierKeyword.PRIVATE_KEYWORD);
/*      */             break;
/*      */           case 43:
/* 6230 */             modifier = createModifier(Modifier.ModifierKeyword.FINAL_KEYWORD);
/*      */             break;
/*      */           case 44:
/* 6233 */             modifier = createModifier(Modifier.ModifierKeyword.NATIVE_KEYWORD);
/*      */             break;
/*      */           case 39:
/* 6236 */             modifier = createModifier(Modifier.ModifierKeyword.SYNCHRONIZED_KEYWORD);
/*      */             break;
/*      */           case 50:
/* 6239 */             modifier = createModifier(Modifier.ModifierKeyword.TRANSIENT_KEYWORD);
/*      */             break;
/*      */           case 51:
/* 6242 */             modifier = createModifier(Modifier.ModifierKeyword.VOLATILE_KEYWORD);
/*      */             break;
/*      */           case 49:
/* 6245 */             modifier = createModifier(Modifier.ModifierKeyword.STRICTFP_KEYWORD);
/*      */             break;
/*      */           
/*      */           case 34:
/* 6249 */             if (annotations != null && indexInAnnotations < annotations.length) {
/* 6250 */               Annotation annotation = annotations[indexInAnnotations++];
/* 6251 */               modifier = convert(annotation);
/* 6252 */               this.scanner.resetTo(annotation.declarationSourceEnd + 1, this.compilationUnitSourceLength);
/*      */             } 
/*      */             break;
/*      */           case 1001:
/*      */           case 1002:
/*      */           case 1003:
/*      */             break;
/*      */           default:
/*      */             return;
/*      */         } 
/* 6262 */         if (modifier != null) {
/* 6263 */           variableDeclarationExpression.modifiers().add(modifier);
/*      */         }
/*      */       } 
/* 6266 */     } catch (InvalidInputException invalidInputException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setModifiers(VariableDeclarationStatement variableDeclarationStatement, LocalDeclaration localDeclaration) {
/*      */     int modifiers;
/* 6277 */     switch (this.ast.apiLevel) {
/*      */       case 2:
/* 6279 */         modifiers = localDeclaration.modifiers & 0xFFFF;
/* 6280 */         modifiers &= 0xFBFFFFFF;
/* 6281 */         variableDeclarationStatement.internalSetModifiers(modifiers);
/* 6282 */         if (localDeclaration.annotations != null) {
/* 6283 */           variableDeclarationStatement.setFlags(variableDeclarationStatement.getFlags() | 0x1);
/*      */         }
/*      */         return;
/*      */     } 
/* 6287 */     this.scanner.resetTo(localDeclaration.declarationSourceStart, localDeclaration.sourceStart);
/* 6288 */     Annotation[] annotations = localDeclaration.annotations;
/* 6289 */     int indexInAnnotations = 0;
/*      */     try {
/*      */       int token;
/* 6292 */       while ((token = this.scanner.getNextToken()) != 64) {
/* 6293 */         IExtendedModifier modifier = null;
/* 6294 */         switch (token) {
/*      */           case 42:
/* 6296 */             modifier = createModifier(Modifier.ModifierKeyword.ABSTRACT_KEYWORD);
/*      */             break;
/*      */           case 48:
/* 6299 */             modifier = createModifier(Modifier.ModifierKeyword.PUBLIC_KEYWORD);
/*      */             break;
/*      */           case 37:
/* 6302 */             modifier = createModifier(Modifier.ModifierKeyword.STATIC_KEYWORD);
/*      */             break;
/*      */           case 47:
/* 6305 */             modifier = createModifier(Modifier.ModifierKeyword.PROTECTED_KEYWORD);
/*      */             break;
/*      */           case 46:
/* 6308 */             modifier = createModifier(Modifier.ModifierKeyword.PRIVATE_KEYWORD);
/*      */             break;
/*      */           case 43:
/* 6311 */             modifier = createModifier(Modifier.ModifierKeyword.FINAL_KEYWORD);
/*      */             break;
/*      */           case 44:
/* 6314 */             modifier = createModifier(Modifier.ModifierKeyword.NATIVE_KEYWORD);
/*      */             break;
/*      */           case 39:
/* 6317 */             modifier = createModifier(Modifier.ModifierKeyword.SYNCHRONIZED_KEYWORD);
/*      */             break;
/*      */           case 50:
/* 6320 */             modifier = createModifier(Modifier.ModifierKeyword.TRANSIENT_KEYWORD);
/*      */             break;
/*      */           case 51:
/* 6323 */             modifier = createModifier(Modifier.ModifierKeyword.VOLATILE_KEYWORD);
/*      */             break;
/*      */           case 49:
/* 6326 */             modifier = createModifier(Modifier.ModifierKeyword.STRICTFP_KEYWORD);
/*      */             break;
/*      */           
/*      */           case 34:
/* 6330 */             if (annotations != null && indexInAnnotations < annotations.length) {
/* 6331 */               Annotation annotation = annotations[indexInAnnotations++];
/* 6332 */               modifier = convert(annotation);
/* 6333 */               this.scanner.resetTo(annotation.declarationSourceEnd + 1, this.compilationUnitSourceLength);
/*      */             } 
/*      */             break;
/*      */           case 1001:
/*      */           case 1002:
/*      */           case 1003:
/*      */             break;
/*      */           default:
/*      */             return;
/*      */         } 
/* 6343 */         if (modifier != null) {
/* 6344 */           variableDeclarationStatement.modifiers().add(modifier);
/*      */         }
/*      */       } 
/* 6347 */     } catch (InvalidInputException invalidInputException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected QualifiedName setQualifiedNameNameAndSourceRanges(char[][] typeName, long[] positions, ASTNode node) {
/* 6354 */     int length = typeName.length;
/* 6355 */     SimpleName firstToken = new SimpleName(this.ast);
/* 6356 */     firstToken.internalSetIdentifier(new String(typeName[0]));
/* 6357 */     firstToken.index = 1;
/* 6358 */     int start0 = (int)(positions[0] >>> 32L);
/* 6359 */     int start = start0;
/* 6360 */     int end = (int)(positions[0] & 0xFFFFFFFFFFFFFFFFL);
/* 6361 */     firstToken.setSourceRange(start, end - start + 1);
/* 6362 */     SimpleName secondToken = new SimpleName(this.ast);
/* 6363 */     secondToken.internalSetIdentifier(new String(typeName[1]));
/* 6364 */     secondToken.index = 2;
/* 6365 */     start = (int)(positions[1] >>> 32L);
/* 6366 */     end = (int)(positions[1] & 0xFFFFFFFFFFFFFFFFL);
/* 6367 */     secondToken.setSourceRange(start, end - start + 1);
/* 6368 */     QualifiedName qualifiedName = new QualifiedName(this.ast);
/* 6369 */     qualifiedName.setQualifier(firstToken);
/* 6370 */     qualifiedName.setName(secondToken);
/* 6371 */     if (this.resolveBindings) {
/* 6372 */       recordNodes(qualifiedName, node);
/* 6373 */       recordPendingNameScopeResolution(qualifiedName);
/* 6374 */       recordNodes(firstToken, node);
/* 6375 */       recordNodes(secondToken, node);
/* 6376 */       recordPendingNameScopeResolution(firstToken);
/* 6377 */       recordPendingNameScopeResolution(secondToken);
/*      */     } 
/* 6379 */     qualifiedName.index = 2;
/* 6380 */     qualifiedName.setSourceRange(start0, end - start0 + 1);
/* 6381 */     SimpleName newPart = null;
/* 6382 */     for (int i = 2; i < length; i++) {
/* 6383 */       newPart = new SimpleName(this.ast);
/* 6384 */       newPart.internalSetIdentifier(new String(typeName[i]));
/* 6385 */       newPart.index = i + 1;
/* 6386 */       start = (int)(positions[i] >>> 32L);
/* 6387 */       end = (int)(positions[i] & 0xFFFFFFFFFFFFFFFFL);
/* 6388 */       newPart.setSourceRange(start, end - start + 1);
/* 6389 */       QualifiedName qualifiedName2 = new QualifiedName(this.ast);
/* 6390 */       qualifiedName2.setQualifier(qualifiedName);
/* 6391 */       qualifiedName2.setName(newPart);
/* 6392 */       qualifiedName = qualifiedName2;
/* 6393 */       qualifiedName.index = newPart.index;
/* 6394 */       qualifiedName.setSourceRange(start0, end - start0 + 1);
/* 6395 */       if (this.resolveBindings) {
/* 6396 */         recordNodes(qualifiedName, node);
/* 6397 */         recordNodes(newPart, node);
/* 6398 */         recordPendingNameScopeResolution(qualifiedName);
/* 6399 */         recordPendingNameScopeResolution(newPart);
/*      */       } 
/*      */     } 
/* 6402 */     QualifiedName name = qualifiedName;
/* 6403 */     if (this.resolveBindings) {
/* 6404 */       recordNodes(name, node);
/* 6405 */       recordPendingNameScopeResolution(name);
/*      */     } 
/* 6407 */     return name;
/*      */   }
/*      */   
/*      */   protected QualifiedName setQualifiedNameNameAndSourceRanges(char[][] typeName, long[] positions, int endingIndex, TypeReference node) {
/* 6411 */     int length = endingIndex + 1;
/* 6412 */     SimpleName firstToken = new SimpleName(this.ast);
/* 6413 */     firstToken.internalSetIdentifier(new String(typeName[0]));
/* 6414 */     firstToken.index = 1;
/* 6415 */     int start0 = (int)(positions[0] >>> 32L);
/* 6416 */     int start = start0;
/* 6417 */     int end = (int)positions[0];
/* 6418 */     firstToken.setSourceRange(start, end - start + 1);
/* 6419 */     SimpleName secondToken = new SimpleName(this.ast);
/* 6420 */     secondToken.internalSetIdentifier(new String(typeName[1]));
/* 6421 */     secondToken.index = 2;
/* 6422 */     start = (int)(positions[1] >>> 32L);
/* 6423 */     end = (int)positions[1];
/* 6424 */     secondToken.setSourceRange(start, end - start + 1);
/* 6425 */     QualifiedName qualifiedName = new QualifiedName(this.ast);
/* 6426 */     qualifiedName.setQualifier(firstToken);
/* 6427 */     qualifiedName.setName(secondToken);
/* 6428 */     if (this.resolveBindings) {
/* 6429 */       recordNodes(qualifiedName, (ASTNode)node);
/* 6430 */       recordPendingNameScopeResolution(qualifiedName);
/* 6431 */       recordNodes(firstToken, (ASTNode)node);
/* 6432 */       recordNodes(secondToken, (ASTNode)node);
/* 6433 */       recordPendingNameScopeResolution(firstToken);
/* 6434 */       recordPendingNameScopeResolution(secondToken);
/*      */     } 
/* 6436 */     qualifiedName.index = 2;
/* 6437 */     qualifiedName.setSourceRange(start0, end - start0 + 1);
/* 6438 */     SimpleName newPart = null;
/* 6439 */     for (int i = 2; i < length; i++) {
/* 6440 */       newPart = new SimpleName(this.ast);
/* 6441 */       newPart.internalSetIdentifier(new String(typeName[i]));
/* 6442 */       newPart.index = i + 1;
/* 6443 */       start = (int)(positions[i] >>> 32L);
/* 6444 */       end = (int)positions[i];
/* 6445 */       newPart.setSourceRange(start, end - start + 1);
/* 6446 */       QualifiedName qualifiedName2 = new QualifiedName(this.ast);
/* 6447 */       qualifiedName2.setQualifier(qualifiedName);
/* 6448 */       qualifiedName2.setName(newPart);
/* 6449 */       qualifiedName = qualifiedName2;
/* 6450 */       qualifiedName.index = newPart.index;
/* 6451 */       qualifiedName.setSourceRange(start0, end - start0 + 1);
/* 6452 */       if (this.resolveBindings) {
/* 6453 */         recordNodes(qualifiedName, (ASTNode)node);
/* 6454 */         recordNodes(newPart, (ASTNode)node);
/* 6455 */         recordPendingNameScopeResolution(qualifiedName);
/* 6456 */         recordPendingNameScopeResolution(newPart);
/*      */       } 
/*      */     } 
/* 6459 */     if (newPart == null && this.resolveBindings) {
/* 6460 */       recordNodes(qualifiedName, (ASTNode)node);
/* 6461 */       recordPendingNameScopeResolution(qualifiedName);
/*      */     } 
/* 6463 */     return qualifiedName;
/*      */   }
/*      */   
/*      */   protected void setTypeNameForAnnotation(Annotation compilerAnnotation, Annotation annotation) {
/* 6467 */     TypeReference typeReference = compilerAnnotation.type;
/* 6468 */     if (typeReference instanceof QualifiedTypeReference) {
/* 6469 */       QualifiedTypeReference qualifiedTypeReference = (QualifiedTypeReference)typeReference;
/* 6470 */       char[][] tokens = qualifiedTypeReference.tokens;
/* 6471 */       long[] positions = qualifiedTypeReference.sourcePositions;
/*      */       
/* 6473 */       annotation.setTypeName(setQualifiedNameNameAndSourceRanges(tokens, positions, (ASTNode)typeReference));
/*      */     } else {
/* 6475 */       SingleTypeReference singleTypeReference = (SingleTypeReference)typeReference;
/* 6476 */       SimpleName name = new SimpleName(this.ast);
/* 6477 */       name.internalSetIdentifier(new String(singleTypeReference.token));
/* 6478 */       int start = singleTypeReference.sourceStart;
/* 6479 */       int end = singleTypeReference.sourceEnd;
/* 6480 */       name.setSourceRange(start, end - start + 1);
/* 6481 */       name.index = 1;
/* 6482 */       annotation.setTypeName(name);
/* 6483 */       if (this.resolveBindings) {
/* 6484 */         recordNodes(name, (ASTNode)typeReference);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void setTypeForField(FieldDeclaration fieldDeclaration, Type type, int extraDimension) {
/* 6490 */     if (extraDimension != 0) {
/* 6491 */       if (type.isArrayType()) {
/* 6492 */         ArrayType arrayType = (ArrayType)type;
/* 6493 */         int remainingDimensions = arrayType.getDimensions() - extraDimension;
/* 6494 */         if (remainingDimensions == 0) {
/*      */           
/* 6496 */           Type elementType = arrayType.getElementType();
/*      */           
/* 6498 */           elementType.setParent(null, null);
/* 6499 */           this.ast.getBindingResolver().updateKey(type, elementType);
/* 6500 */           fieldDeclaration.setType(elementType);
/*      */         } else {
/* 6502 */           ArrayType subarrayType = extractSubArrayType(arrayType, remainingDimensions, extraDimension);
/* 6503 */           fieldDeclaration.setType(subarrayType);
/* 6504 */           this.ast.getBindingResolver().updateKey(type, subarrayType);
/*      */         } 
/* 6506 */         checkAndSetMalformed(type, fieldDeclaration);
/*      */       } else {
/* 6508 */         fieldDeclaration.setType(type);
/*      */       } 
/*      */     } else {
/* 6511 */       if (type.isArrayType() && this.ast.apiLevel() < 8) {
/*      */         
/* 6513 */         int dimensions = ((ArrayType)type).getDimensions();
/* 6514 */         updateInnerPositions(type, dimensions);
/*      */       } 
/* 6516 */       fieldDeclaration.setType(type);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayType extractSubArrayType(ArrayType arrayType, int remainingDimensions, int dimensionsToRemove) {
/* 6527 */     ArrayType subArrayType = arrayType;
/* 6528 */     int start = subArrayType.getStartPosition();
/* 6529 */     if (this.ast.apiLevel() < 8) {
/* 6530 */       while (dimensionsToRemove > 0) {
/* 6531 */         subArrayType = (ArrayType)componentType(subArrayType);
/* 6532 */         dimensionsToRemove--;
/*      */       } 
/* 6534 */       updateInnerPositions(subArrayType, remainingDimensions);
/*      */     } else {
/* 6536 */       List dimensions = subArrayType.dimensions();
/* 6537 */       while (dimensionsToRemove > 0) {
/* 6538 */         dimensions.remove(dimensions.size() - 1);
/* 6539 */         dimensionsToRemove--;
/*      */       } 
/*      */     } 
/* 6542 */     int end = retrieveProperRightBracketPosition(remainingDimensions, start);
/* 6543 */     subArrayType.setSourceRange(start, end - start + 1);
/*      */     
/* 6545 */     subArrayType.setParent(null, null);
/* 6546 */     return subArrayType;
/*      */   }
/*      */   
/*      */   protected void setTypeForMethodDeclaration(MethodDeclaration methodDeclaration, Type type, int extraDimension) {
/* 6550 */     if (extraDimension != 0) {
/* 6551 */       if (type.isArrayType()) {
/* 6552 */         ArrayType arrayType = (ArrayType)type;
/* 6553 */         int remainingDimensions = arrayType.getDimensions() - extraDimension;
/* 6554 */         if (remainingDimensions == 0) {
/*      */           
/* 6556 */           Type elementType = arrayType.getElementType();
/*      */           
/* 6558 */           elementType.setParent(null, null);
/* 6559 */           this.ast.getBindingResolver().updateKey(type, elementType);
/* 6560 */           switch (this.ast.apiLevel) {
/*      */             case 2:
/* 6562 */               methodDeclaration.internalSetReturnType(elementType);
/*      */               break;
/*      */             default:
/* 6565 */               methodDeclaration.setReturnType2(elementType);
/*      */               break;
/*      */           } 
/*      */         } else {
/* 6569 */           ArrayType subarrayType = extractSubArrayType(arrayType, remainingDimensions, extraDimension);
/* 6570 */           switch (this.ast.apiLevel) {
/*      */             case 2:
/* 6572 */               methodDeclaration.internalSetReturnType(subarrayType);
/*      */               break;
/*      */             default:
/* 6575 */               methodDeclaration.setReturnType2(subarrayType);
/*      */               break;
/*      */           } 
/* 6578 */           this.ast.getBindingResolver().updateKey(type, subarrayType);
/*      */         } 
/* 6580 */         checkAndSetMalformed(type, methodDeclaration);
/*      */       } else {
/* 6582 */         switch (this.ast.apiLevel) {
/*      */           case 2:
/* 6584 */             methodDeclaration.internalSetReturnType(type);
/*      */             return;
/*      */         } 
/* 6587 */         methodDeclaration.setReturnType2(type);
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 6592 */       switch (this.ast.apiLevel) {
/*      */         case 2:
/* 6594 */           methodDeclaration.internalSetReturnType(type);
/*      */           return;
/*      */       } 
/* 6597 */       methodDeclaration.setReturnType2(type);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setTypeForMethodDeclaration(AnnotationTypeMemberDeclaration annotationTypeMemberDeclaration, Type type, int extraDimension) {
/* 6604 */     annotationTypeMemberDeclaration.setType(type);
/*      */   }
/*      */   
/*      */   protected void setTypeForSingleVariableDeclaration(SingleVariableDeclaration singleVariableDeclaration, Type type, int extraDimension) {
/* 6608 */     if (extraDimension != 0) {
/* 6609 */       if (type.isArrayType()) {
/* 6610 */         ArrayType arrayType = (ArrayType)type;
/* 6611 */         int remainingDimensions = arrayType.getDimensions() - extraDimension;
/* 6612 */         if (remainingDimensions == 0) {
/*      */           
/* 6614 */           Type elementType = arrayType.getElementType();
/*      */           
/* 6616 */           elementType.setParent(null, null);
/* 6617 */           this.ast.getBindingResolver().updateKey(type, elementType);
/* 6618 */           singleVariableDeclaration.setType(elementType);
/*      */         } else {
/* 6620 */           ArrayType subarrayType = extractSubArrayType(arrayType, remainingDimensions, extraDimension);
/* 6621 */           this.ast.getBindingResolver().updateKey(type, subarrayType);
/* 6622 */           singleVariableDeclaration.setType(subarrayType);
/*      */         } 
/* 6624 */         checkAndSetMalformed(type, singleVariableDeclaration);
/*      */       } else {
/*      */         
/* 6627 */         singleVariableDeclaration.setType(type);
/*      */       } 
/*      */     } else {
/* 6630 */       singleVariableDeclaration.setType(type);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void setTypeForVariableDeclarationExpression(VariableDeclarationExpression variableDeclarationExpression, Type type, int extraDimension) {
/* 6635 */     if (extraDimension != 0) {
/* 6636 */       if (type.isArrayType()) {
/* 6637 */         ArrayType arrayType = (ArrayType)type;
/* 6638 */         int remainingDimensions = arrayType.getDimensions() - extraDimension;
/* 6639 */         if (remainingDimensions == 0) {
/*      */           
/* 6641 */           Type elementType = arrayType.getElementType();
/*      */           
/* 6643 */           elementType.setParent(null, null);
/* 6644 */           this.ast.getBindingResolver().updateKey(type, elementType);
/* 6645 */           variableDeclarationExpression.setType(elementType);
/*      */         } else {
/* 6647 */           ArrayType subarrayType = extractSubArrayType(arrayType, remainingDimensions, extraDimension);
/* 6648 */           variableDeclarationExpression.setType(subarrayType);
/* 6649 */           this.ast.getBindingResolver().updateKey(type, subarrayType);
/*      */         } 
/* 6651 */         checkAndSetMalformed(type, variableDeclarationExpression);
/*      */       } else {
/* 6653 */         variableDeclarationExpression.setType(type);
/*      */       } 
/*      */     } else {
/* 6656 */       variableDeclarationExpression.setType(type);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void setTypeForVariableDeclarationStatement(VariableDeclarationStatement variableDeclarationStatement, Type type, int extraDimension) {
/* 6661 */     if (extraDimension != 0) {
/* 6662 */       if (type.isArrayType()) {
/* 6663 */         ArrayType arrayType = (ArrayType)type;
/* 6664 */         int remainingDimensions = arrayType.getDimensions() - extraDimension;
/* 6665 */         if (remainingDimensions == 0) {
/*      */           
/* 6667 */           Type elementType = arrayType.getElementType();
/*      */           
/* 6669 */           elementType.setParent(null, null);
/* 6670 */           this.ast.getBindingResolver().updateKey(type, elementType);
/* 6671 */           variableDeclarationStatement.setType(elementType);
/*      */         } else {
/* 6673 */           ArrayType subarrayType = extractSubArrayType(arrayType, remainingDimensions, extraDimension);
/* 6674 */           variableDeclarationStatement.setType(subarrayType);
/* 6675 */           this.ast.getBindingResolver().updateKey(type, subarrayType);
/*      */         } 
/* 6677 */         checkAndSetMalformed(type, variableDeclarationStatement);
/*      */       } else {
/* 6679 */         variableDeclarationStatement.setType(type);
/*      */       } 
/*      */     } else {
/* 6682 */       variableDeclarationStatement.setType(type);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void updateInnerPositions(Type type, int dimensions) {
/* 6687 */     if (dimensions > 1) {
/*      */       
/* 6689 */       int start = type.getStartPosition();
/* 6690 */       Type currentComponentType = componentType((ArrayType)type);
/* 6691 */       int searchedDimension = dimensions - 1;
/* 6692 */       int rightBracketEndPosition = start;
/* 6693 */       while (currentComponentType.isArrayType()) {
/* 6694 */         rightBracketEndPosition = retrieveProperRightBracketPosition(searchedDimension, start);
/* 6695 */         currentComponentType.setSourceRange(start, rightBracketEndPosition - start + 1);
/* 6696 */         currentComponentType = componentType((ArrayType)currentComponentType);
/* 6697 */         searchedDimension--;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   static interface IGetJavaDoc {
/*      */     Javadoc getJavaDoc();
/*      */   }
/*      */   
/*      */   static interface ISetJavaDoc {
/*      */     void setJavadoc(Javadoc param1Javadoc);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ASTConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */