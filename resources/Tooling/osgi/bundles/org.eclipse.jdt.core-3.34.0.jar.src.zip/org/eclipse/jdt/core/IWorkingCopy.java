package org.eclipse.jdt.core;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IWorkingCopy {
  void commit(boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void destroy();
  
  IJavaElement findSharedWorkingCopy(IBufferFactory paramIBufferFactory);
  
  IJavaElement getOriginal(IJavaElement paramIJavaElement);
  
  IJavaElement getOriginalElement();
  
  IJavaElement[] findElements(IJavaElement paramIJavaElement);
  
  IType findPrimaryType();
  
  IJavaElement getSharedWorkingCopy(IProgressMonitor paramIProgressMonitor, IBufferFactory paramIBufferFactory, IProblemRequestor paramIProblemRequestor) throws JavaModelException;
  
  IJavaElement getWorkingCopy() throws JavaModelException;
  
  IJavaElement getWorkingCopy(IProgressMonitor paramIProgressMonitor, IBufferFactory paramIBufferFactory, IProblemRequestor paramIProblemRequestor) throws JavaModelException;
  
  boolean isBasedOn(IResource paramIResource);
  
  boolean isWorkingCopy();
  
  IMarker[] reconcile() throws JavaModelException;
  
  void reconcile(boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void restore() throws JavaModelException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IWorkingCopy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */