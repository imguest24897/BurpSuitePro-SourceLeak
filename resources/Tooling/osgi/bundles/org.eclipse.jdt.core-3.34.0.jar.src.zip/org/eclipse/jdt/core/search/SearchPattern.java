/*      */ package org.eclipse.jdt.core.search;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.util.regex.Pattern;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.OperationCanceledException;
/*      */ import org.eclipse.jdt.core.IField;
/*      */ import org.eclipse.jdt.core.IImportDeclaration;
/*      */ import org.eclipse.jdt.core.IJavaElement;
/*      */ import org.eclipse.jdt.core.IMember;
/*      */ import org.eclipse.jdt.core.IMethod;
/*      */ import org.eclipse.jdt.core.IType;
/*      */ import org.eclipse.jdt.core.ITypeParameter;
/*      */ import org.eclipse.jdt.core.JavaModelException;
/*      */ import org.eclipse.jdt.core.Signature;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*      */ import org.eclipse.jdt.internal.compiler.env.AccessRuleSet;
/*      */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*      */ import org.eclipse.jdt.internal.compiler.parser.ScannerHelper;
/*      */ import org.eclipse.jdt.internal.core.LocalVariable;
/*      */ import org.eclipse.jdt.internal.core.index.EntryResult;
/*      */ import org.eclipse.jdt.internal.core.index.Index;
/*      */ import org.eclipse.jdt.internal.core.search.HierarchyScope;
/*      */ import org.eclipse.jdt.internal.core.search.IndexQueryRequestor;
/*      */ import org.eclipse.jdt.internal.core.search.JavaSearchScope;
/*      */ import org.eclipse.jdt.internal.core.search.StringOperation;
/*      */ import org.eclipse.jdt.internal.core.search.indexing.IIndexConstants;
/*      */ import org.eclipse.jdt.internal.core.search.indexing.QualifierQuery;
/*      */ import org.eclipse.jdt.internal.core.search.matching.AndPattern;
/*      */ import org.eclipse.jdt.internal.core.search.matching.ConstructorPattern;
/*      */ import org.eclipse.jdt.internal.core.search.matching.FieldPattern;
/*      */ import org.eclipse.jdt.internal.core.search.matching.LocalVariablePattern;
/*      */ import org.eclipse.jdt.internal.core.search.matching.MatchLocator;
/*      */ import org.eclipse.jdt.internal.core.search.matching.MethodPattern;
/*      */ import org.eclipse.jdt.internal.core.search.matching.ModulePattern;
/*      */ import org.eclipse.jdt.internal.core.search.matching.OrPattern;
/*      */ import org.eclipse.jdt.internal.core.search.matching.PackageDeclarationPattern;
/*      */ import org.eclipse.jdt.internal.core.search.matching.PackageReferencePattern;
/*      */ import org.eclipse.jdt.internal.core.search.matching.QualifiedTypeDeclarationPattern;
/*      */ import org.eclipse.jdt.internal.core.search.matching.SuperTypeReferencePattern;
/*      */ import org.eclipse.jdt.internal.core.search.matching.TypeDeclarationPattern;
/*      */ import org.eclipse.jdt.internal.core.search.matching.TypeParameterPattern;
/*      */ import org.eclipse.jdt.internal.core.search.matching.TypeReferencePattern;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class SearchPattern
/*      */ {
/*      */   public static final int R_EXACT_MATCH = 0;
/*      */   public static final int R_PREFIX_MATCH = 1;
/*      */   public static final int R_PATTERN_MATCH = 2;
/*      */   public static final int R_REGEXP_MATCH = 4;
/*      */   public static final int R_CASE_SENSITIVE = 8;
/*      */   public static final int R_ERASURE_MATCH = 16;
/*      */   public static final int R_EQUIVALENT_MATCH = 32;
/*      */   public static final int R_FULL_MATCH = 64;
/*      */   public static final int R_CAMELCASE_MATCH = 128;
/*      */   public static final int R_CAMELCASE_SAME_PART_COUNT_MATCH = 256;
/*      */   public static final int R_SUBSTRING_MATCH = 512;
/*      */   public static final int R_SUBWORD_MATCH = 1024;
/*      */   private static final int MODE_MASK = 1927;
/*      */   private int matchRule;
/*      */   public IJavaElement focus;
/*      */   public char[] indexQualifierQuery;
/*      */   public int kind;
/*      */   public boolean mustResolve = true;
/*      */   
/*      */   public SearchPattern(int matchRule) {
/*  355 */     this.matchRule = matchRule;
/*      */     
/*  357 */     if ((matchRule & 0x30) == 0) {
/*  358 */       this.matchRule |= 0x40;
/*      */     }
/*      */     
/*  361 */     if ((matchRule & 0x80) != 0) {
/*  362 */       this.matchRule &= 0xFFFFFEFF;
/*  363 */       this.matchRule &= 0xFFFFFFFE;
/*  364 */     } else if ((matchRule & 0x100) != 0) {
/*  365 */       this.matchRule &= 0xFFFFFFFE;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void acceptMatch(String relativePath, String containerPath, char separator, SearchPattern pattern, IndexQueryRequestor requestor, SearchParticipant participant, IJavaSearchScope scope) {
/*  374 */     acceptMatch(relativePath, containerPath, separator, pattern, requestor, participant, scope, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void acceptMatch(String relativePath, String containerPath, char separator, SearchPattern pattern, IndexQueryRequestor requestor, SearchParticipant participant, IJavaSearchScope scope, IProgressMonitor monitor) {
/*  382 */     if (scope instanceof JavaSearchScope) {
/*  383 */       JavaSearchScope javaSearchScope = (JavaSearchScope)scope;
/*      */ 
/*      */       
/*  386 */       AccessRuleSet access = javaSearchScope.getAccessRuleSet(relativePath, containerPath);
/*  387 */       if (access != JavaSearchScope.NOT_ENCLOSED) {
/*  388 */         StringBuilder documentPath = new StringBuilder(containerPath.length() + 1 + relativePath.length());
/*  389 */         documentPath.append(containerPath);
/*  390 */         documentPath.append(separator);
/*  391 */         documentPath.append(relativePath);
/*  392 */         if (!requestor.acceptIndexMatch(documentPath.toString(), pattern, participant, access))
/*  393 */           throw new OperationCanceledException(); 
/*      */       } 
/*      */     } else {
/*  396 */       StringBuilder buffer = new StringBuilder(containerPath.length() + 1 + relativePath.length());
/*  397 */       buffer.append(containerPath);
/*  398 */       buffer.append(separator);
/*  399 */       buffer.append(relativePath);
/*  400 */       String documentPath = buffer.toString();
/*  401 */       boolean encloses = (scope instanceof HierarchyScope) ? ((HierarchyScope)scope).encloses(documentPath, monitor) : 
/*  402 */         scope.encloses(documentPath);
/*  403 */       if (encloses && 
/*  404 */         !requestor.acceptIndexMatch(documentPath, pattern, participant, null)) {
/*  405 */         throw new OperationCanceledException();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SearchPattern currentPattern() {
/*  414 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean camelCaseMatch(String pattern, String name) {
/*  476 */     if (pattern == null)
/*  477 */       return true; 
/*  478 */     if (name == null) {
/*  479 */       return false;
/*      */     }
/*  481 */     return camelCaseMatch(pattern, 0, pattern.length(), name, 0, name.length(), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean camelCaseMatch(String pattern, String name, boolean samePartCount) {
/*  551 */     if (pattern == null)
/*  552 */       return true; 
/*  553 */     if (name == null) {
/*  554 */       return false;
/*      */     }
/*  556 */     return camelCaseMatch(pattern, 0, pattern.length(), name, 0, name.length(), samePartCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean camelCaseMatch(String pattern, int patternStart, int patternEnd, String name, int nameStart, int nameEnd) {
/*  663 */     return camelCaseMatch(pattern, patternStart, patternEnd, name, nameStart, nameEnd, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean camelCaseMatch(String pattern, int patternStart, int patternEnd, String name, int nameStart, int nameEnd, boolean samePartCount) {
/*  775 */     return (StringOperation.getCamelCaseMatchingRegions(pattern, patternStart, patternEnd, name, nameStart, nameEnd, samePartCount) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int[] getMatchingRegions(String pattern, String name, int matchRule) {
/*  885 */     if (name == null) return null; 
/*  886 */     int nameLength = name.length();
/*  887 */     if (pattern == null) {
/*  888 */       return new int[] { 0, nameLength };
/*      */     }
/*  890 */     int patternLength = pattern.length();
/*  891 */     boolean countMatch = false;
/*  892 */     switch (matchRule) {
/*      */       case 0:
/*  894 */         if (patternLength == nameLength && pattern.equalsIgnoreCase(name)) {
/*  895 */           return new int[] { 0, patternLength };
/*      */         }
/*      */         break;
/*      */       case 8:
/*  899 */         if (patternLength == nameLength && pattern.equals(name)) {
/*  900 */           return new int[] { 0, patternLength };
/*      */         }
/*      */         break;
/*      */       case 1:
/*  904 */         if (patternLength <= nameLength && name.substring(0, patternLength).equalsIgnoreCase(pattern)) {
/*  905 */           return new int[] { 0, patternLength };
/*      */         }
/*      */         break;
/*      */       case 9:
/*  909 */         if (name.startsWith(pattern)) {
/*  910 */           return new int[] { 0, patternLength };
/*      */         }
/*      */         break;
/*      */       case 256:
/*  914 */         countMatch = true;
/*      */       
/*      */       case 128:
/*  917 */         if (patternLength <= nameLength) {
/*  918 */           int[] regions = StringOperation.getCamelCaseMatchingRegions(pattern, 0, patternLength, name, 0, nameLength, countMatch);
/*  919 */           if (regions != null) return regions; 
/*  920 */           if (name.substring(0, patternLength).equalsIgnoreCase(pattern)) {
/*  921 */             return new int[] { 0, patternLength };
/*      */           }
/*      */         } 
/*      */         break;
/*      */       case 264:
/*  926 */         countMatch = true;
/*      */       
/*      */       case 136:
/*  929 */         if (patternLength <= nameLength) {
/*  930 */           return StringOperation.getCamelCaseMatchingRegions(pattern, 0, patternLength, name, 0, nameLength, countMatch);
/*      */         }
/*      */         break;
/*      */       case 2:
/*  934 */         return StringOperation.getPatternMatchingRegions(pattern, 0, patternLength, name, 0, nameLength, false);
/*      */       case 10:
/*  936 */         return StringOperation.getPatternMatchingRegions(pattern, 0, patternLength, name, 0, nameLength, true);
/*      */       case 512:
/*  938 */         if (patternLength <= nameLength) {
/*  939 */           int next = CharOperation.indexOf(pattern.toCharArray(), name.toCharArray(), false);
/*  940 */           (new int[2])[0] = next; (new int[2])[1] = patternLength; return (next >= 0) ? new int[2] : null;
/*      */         } 
/*      */         break;
/*      */       case 1024:
/*  944 */         return CharOperation.getSubWordMatchingRegions(pattern, name);
/*      */     } 
/*  946 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SearchPattern createAndPattern(SearchPattern leftPattern, SearchPattern rightPattern) {
/*  962 */     return (SearchPattern)new AndPattern(leftPattern, rightPattern);
/*      */   }
/*      */ 
/*      */   
/*      */   private static SearchPattern createFieldPattern(String patternString, int limitTo, int matchRule) {
/*      */     int token;
/*  968 */     Scanner scanner = new Scanner(false, true, false, 3342336L, null, null, true);
/*  969 */     scanner.setSource(patternString.toCharArray());
/*      */ 
/*      */     
/*  972 */     int lastToken = -1;
/*      */     
/*  974 */     String declaringType = null, fieldName = null;
/*  975 */     String type = null;
/*  976 */     int mode = 1;
/*      */     
/*      */     try {
/*  979 */       token = scanner.getNextToken();
/*  980 */     } catch (InvalidInputException invalidInputException) {
/*  981 */       return null;
/*      */     } 
/*  983 */     while (token != 64) {
/*  984 */       switch (mode) {
/*      */         
/*      */         case 1:
/*  987 */           switch (token) {
/*      */             case 1:
/*  989 */               if (declaringType == null) {
/*  990 */                 if (fieldName == null) return null; 
/*  991 */                 declaringType = fieldName;
/*      */               } else {
/*  993 */                 String tokenSource = scanner.getCurrentTokenString();
/*  994 */                 declaringType = String.valueOf(declaringType) + tokenSource + fieldName;
/*      */               } 
/*  996 */               fieldName = null;
/*      */               break;
/*      */             case 1000:
/*  999 */               if (1000 != lastToken && 1 != lastToken)
/* 1000 */                 mode = 2; 
/*      */               break;
/*      */           } 
/* 1003 */           if (fieldName == null) {
/* 1004 */             fieldName = scanner.getCurrentTokenString(); break;
/*      */           } 
/* 1006 */           fieldName = String.valueOf(fieldName) + scanner.getCurrentTokenString();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 2:
/* 1011 */           switch (token) {
/*      */             case 1000:
/*      */               break;
/*      */           } 
/* 1015 */           if (type == null) {
/* 1016 */             type = scanner.getCurrentTokenString(); break;
/*      */           } 
/* 1018 */           type = String.valueOf(type) + scanner.getCurrentTokenString();
/*      */           break;
/*      */       } 
/*      */       
/* 1022 */       lastToken = token;
/*      */       try {
/* 1024 */         token = scanner.getNextToken();
/* 1025 */       } catch (InvalidInputException invalidInputException) {
/* 1026 */         return null;
/*      */       } 
/*      */     } 
/* 1029 */     if (fieldName == null) return null;
/*      */     
/* 1031 */     char[] fieldNameChars = fieldName.toCharArray();
/* 1032 */     if (fieldNameChars.length == 1 && fieldNameChars[0] == '*') fieldNameChars = null;
/*      */     
/* 1034 */     char[] declaringTypeQualification = null, declaringTypeSimpleName = null;
/* 1035 */     char[] typeQualification = null, typeSimpleName = null;
/*      */ 
/*      */     
/* 1038 */     if (declaringType != null) {
/* 1039 */       char[] declaringTypePart = declaringType.toCharArray();
/* 1040 */       int lastDotPosition = CharOperation.lastIndexOf('.', declaringTypePart);
/* 1041 */       if (lastDotPosition >= 0) {
/* 1042 */         declaringTypeQualification = CharOperation.subarray(declaringTypePart, 0, lastDotPosition);
/* 1043 */         if (declaringTypeQualification.length == 1 && declaringTypeQualification[0] == '*')
/* 1044 */           declaringTypeQualification = null; 
/* 1045 */         declaringTypeSimpleName = CharOperation.subarray(declaringTypePart, lastDotPosition + 1, declaringTypePart.length);
/*      */       } else {
/* 1047 */         declaringTypeSimpleName = declaringTypePart;
/*      */       } 
/* 1049 */       if (declaringTypeSimpleName.length == 1 && declaringTypeSimpleName[0] == '*') {
/* 1050 */         declaringTypeSimpleName = null;
/*      */       }
/*      */     } 
/* 1053 */     if (type != null) {
/* 1054 */       char[] typePart = type.toCharArray();
/* 1055 */       int lastDotPosition = CharOperation.lastIndexOf('.', typePart);
/* 1056 */       if (lastDotPosition >= 0) {
/* 1057 */         typeQualification = CharOperation.subarray(typePart, 0, lastDotPosition);
/* 1058 */         if (typeQualification.length == 1 && typeQualification[0] == '*') {
/* 1059 */           typeQualification = null;
/*      */         } else {
/*      */           
/* 1062 */           typeQualification = CharOperation.concat(IIndexConstants.ONE_STAR, typeQualification);
/*      */         } 
/* 1064 */         typeSimpleName = CharOperation.subarray(typePart, lastDotPosition + 1, typePart.length);
/*      */       } else {
/* 1066 */         typeSimpleName = typePart;
/*      */       } 
/* 1068 */       if (typeSimpleName.length == 1 && typeSimpleName[0] == '*') {
/* 1069 */         typeSimpleName = null;
/*      */       }
/*      */     } 
/* 1072 */     return (SearchPattern)new FieldPattern(
/* 1073 */         fieldNameChars, 
/* 1074 */         declaringTypeQualification, 
/* 1075 */         declaringTypeSimpleName, 
/* 1076 */         typeQualification, 
/* 1077 */         typeSimpleName, 
/* 1078 */         limitTo, 
/* 1079 */         matchRule);
/*      */   }
/*      */ 
/*      */   
/*      */   private static SearchPattern createMethodOrConstructorPattern(String patternString, int limitTo, int matchRule, boolean isConstructor) {
/*      */     int token;
/* 1085 */     Scanner scanner = new Scanner(false, true, false, 3342336L, null, null, true);
/* 1086 */     scanner.setSource(patternString.toCharArray());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1091 */     int lastToken = -1;
/*      */     
/* 1093 */     String declaringType = null, selector = null, parameterType = null;
/* 1094 */     String[] parameterTypes = null;
/* 1095 */     char[][] typeArguments = null;
/* 1096 */     String typeArgumentsString = null;
/* 1097 */     int parameterCount = -1;
/* 1098 */     String returnType = null;
/* 1099 */     boolean foundClosingParenthesis = false;
/* 1100 */     int mode = 1;
/* 1101 */     int argCount = 0;
/*      */     try {
/* 1103 */       token = scanner.getNextToken();
/* 1104 */     } catch (InvalidInputException invalidInputException) {
/* 1105 */       return null;
/*      */     } 
/* 1107 */     while (token != 64) {
/* 1108 */       switch (mode) {
/*      */         
/*      */         case 1:
/* 1111 */           if (argCount == 0) {
/* 1112 */             switch (token) {
/*      */               case 11:
/* 1114 */                 argCount++;
/* 1115 */                 if (selector == null || lastToken == 1) {
/* 1116 */                   typeArgumentsString = scanner.getCurrentTokenString();
/* 1117 */                   mode = 2;
/*      */                   break;
/*      */                 } 
/* 1120 */                 if (declaringType == null) {
/* 1121 */                   declaringType = selector;
/*      */                 } else {
/* 1123 */                   declaringType = String.valueOf(declaringType) + '.' + selector;
/*      */                 } 
/* 1125 */                 declaringType = String.valueOf(declaringType) + scanner.getCurrentTokenString();
/* 1126 */                 selector = null;
/*      */                 break;
/*      */               case 1:
/* 1129 */                 if (!isConstructor && typeArgumentsString != null) return null; 
/* 1130 */                 if (declaringType == null) {
/* 1131 */                   if (selector == null) return null; 
/* 1132 */                   declaringType = selector;
/* 1133 */                 } else if (selector != null) {
/* 1134 */                   declaringType = String.valueOf(declaringType) + scanner.getCurrentTokenString() + selector;
/*      */                 } 
/* 1136 */                 selector = null;
/*      */                 break;
/*      */               case 23:
/* 1139 */                 parameterTypes = new String[5];
/* 1140 */                 parameterCount = 0;
/* 1141 */                 mode = 3;
/*      */                 break;
/*      */               case 1000:
/* 1144 */                 switch (lastToken) {
/*      */                   case 1:
/*      */                   case 14:
/*      */                   case 15:
/*      */                   case 16:
/*      */                   case 1000:
/*      */                     break;
/*      */                 } 
/* 1152 */                 mode = 4;
/*      */                 break;
/*      */             } 
/*      */ 
/*      */             
/* 1157 */             if (selector == null) {
/* 1158 */               selector = scanner.getCurrentTokenString(); break;
/*      */             } 
/* 1160 */             selector = String.valueOf(selector) + scanner.getCurrentTokenString();
/*      */             
/*      */             break;
/*      */           } 
/* 1164 */           if (declaringType == null) return null; 
/* 1165 */           switch (token) {
/*      */             case 14:
/*      */             case 15:
/*      */             case 16:
/* 1169 */               argCount--;
/*      */               break;
/*      */             case 11:
/* 1172 */               argCount++;
/*      */               break;
/*      */           } 
/* 1175 */           declaringType = String.valueOf(declaringType) + scanner.getCurrentTokenString();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 2:
/* 1180 */           if (typeArgumentsString == null) return null; 
/* 1181 */           typeArgumentsString = String.valueOf(typeArgumentsString) + scanner.getCurrentTokenString();
/* 1182 */           switch (token) {
/*      */             case 14:
/*      */             case 15:
/*      */             case 16:
/* 1186 */               argCount--;
/* 1187 */               if (argCount == 0) {
/* 1188 */                 String pseudoType = "Type" + typeArgumentsString;
/* 1189 */                 typeArguments = Signature.getTypeArguments(Signature.createTypeSignature(pseudoType, false).toCharArray());
/* 1190 */                 mode = 1;
/*      */               } 
/*      */               break;
/*      */             case 11:
/* 1194 */               argCount++;
/*      */               break;
/*      */           } 
/*      */           
/*      */           break;
/*      */         case 3:
/* 1200 */           if (argCount == 0) {
/* 1201 */             switch (token) {
/*      */               case 1000:
/*      */                 break;
/*      */               case 32:
/* 1205 */                 if (parameterType == null) return null; 
/* 1206 */                 if (parameterTypes != null) {
/* 1207 */                   if (parameterTypes.length == parameterCount)
/* 1208 */                     System.arraycopy(parameterTypes, 0, parameterTypes = new String[parameterCount * 2], 0, parameterCount); 
/* 1209 */                   parameterTypes[parameterCount++] = parameterType;
/*      */                 } 
/* 1211 */                 parameterType = null;
/*      */                 break;
/*      */               case 26:
/* 1214 */                 foundClosingParenthesis = true;
/* 1215 */                 if (parameterType != null && parameterTypes != null) {
/* 1216 */                   if (parameterTypes.length == parameterCount)
/* 1217 */                     System.arraycopy(parameterTypes, 0, parameterTypes = new String[parameterCount * 2], 0, parameterCount); 
/* 1218 */                   parameterTypes[parameterCount++] = parameterType;
/*      */                 } 
/* 1220 */                 mode = isConstructor ? 2 : 4;
/*      */                 break;
/*      */               case 11:
/* 1223 */                 argCount++;
/* 1224 */                 if (parameterType == null) return null; 
/*      */                 break;
/*      */             } 
/* 1227 */             if (parameterType == null) {
/* 1228 */               parameterType = scanner.getCurrentTokenString(); break;
/*      */             } 
/* 1230 */             parameterType = String.valueOf(parameterType) + scanner.getCurrentTokenString();
/*      */             break;
/*      */           } 
/* 1233 */           if (parameterType == null) return null; 
/* 1234 */           switch (token) {
/*      */             case 14:
/*      */             case 15:
/*      */             case 16:
/* 1238 */               argCount--;
/*      */               break;
/*      */             case 11:
/* 1241 */               argCount++;
/*      */               break;
/*      */           } 
/* 1244 */           parameterType = String.valueOf(parameterType) + scanner.getCurrentTokenString();
/*      */           break;
/*      */ 
/*      */         
/*      */         case 4:
/* 1249 */           if (argCount == 0) {
/* 1250 */             switch (token) {
/*      */               case 1000:
/*      */                 break;
/*      */               case 23:
/* 1254 */                 parameterTypes = new String[5];
/* 1255 */                 parameterCount = 0;
/* 1256 */                 mode = 3;
/*      */                 break;
/*      */               case 11:
/* 1259 */                 argCount++;
/* 1260 */                 if (returnType == null) return null; 
/*      */                 break;
/*      */             } 
/* 1263 */             if (returnType == null) {
/* 1264 */               returnType = scanner.getCurrentTokenString(); break;
/*      */             } 
/* 1266 */             returnType = String.valueOf(returnType) + scanner.getCurrentTokenString();
/*      */             break;
/*      */           } 
/* 1269 */           if (returnType == null) return null; 
/* 1270 */           switch (token) {
/*      */             case 14:
/*      */             case 15:
/*      */             case 16:
/* 1274 */               argCount--;
/*      */               break;
/*      */             case 11:
/* 1277 */               argCount++;
/*      */               break;
/*      */           } 
/* 1280 */           returnType = String.valueOf(returnType) + scanner.getCurrentTokenString();
/*      */           break;
/*      */       } 
/*      */       
/* 1284 */       lastToken = token;
/*      */       try {
/* 1286 */         token = scanner.getNextToken();
/* 1287 */       } catch (InvalidInputException invalidInputException) {
/* 1288 */         return null;
/*      */       } 
/*      */     } 
/*      */     
/* 1292 */     if (parameterCount > 0 && !foundClosingParenthesis) return null;
/*      */     
/* 1294 */     if (argCount > 0) return null;
/*      */     
/* 1296 */     char[] selectorChars = null;
/* 1297 */     if (isConstructor) {
/*      */       
/* 1299 */       if (declaringType == null) {
/* 1300 */         declaringType = selector;
/* 1301 */       } else if (selector != null) {
/* 1302 */         declaringType = String.valueOf(declaringType) + '.' + selector;
/*      */       } 
/*      */     } else {
/* 1305 */       if (selector == null) return null; 
/* 1306 */       selectorChars = selector.toCharArray();
/* 1307 */       if (selectorChars.length == 1 && selectorChars[0] == '*') {
/* 1308 */         selectorChars = null;
/*      */       }
/*      */     } 
/* 1311 */     char[] declaringTypeQualification = null, declaringTypeSimpleName = null;
/* 1312 */     char[] returnTypeQualification = null, returnTypeSimpleName = null;
/* 1313 */     char[][] parameterTypeQualifications = null, parameterTypeSimpleNames = null;
/*      */     
/* 1315 */     String declaringTypeSignature = null;
/* 1316 */     String returnTypeSignature = null;
/* 1317 */     String[] parameterTypeSignatures = null;
/*      */ 
/*      */     
/* 1320 */     if (declaringType != null) {
/*      */       
/* 1322 */       char[] declaringTypePart = null;
/*      */       try {
/* 1324 */         declaringTypeSignature = Signature.createTypeSignature(declaringType, false);
/* 1325 */         if (declaringTypeSignature.indexOf('<') < 0) {
/* 1326 */           declaringTypePart = declaringType.toCharArray();
/*      */         } else {
/* 1328 */           declaringTypePart = Signature.toCharArray(Signature.getTypeErasure(declaringTypeSignature.toCharArray()));
/*      */         }
/*      */       
/* 1331 */       } catch (IllegalArgumentException illegalArgumentException) {
/*      */         
/* 1333 */         return null;
/*      */       } 
/* 1335 */       int lastDotPosition = CharOperation.lastIndexOf('.', declaringTypePart);
/* 1336 */       if (lastDotPosition >= 0) {
/* 1337 */         declaringTypeQualification = CharOperation.subarray(declaringTypePart, 0, lastDotPosition);
/* 1338 */         if (declaringTypeQualification.length == 1 && declaringTypeQualification[0] == '*')
/* 1339 */           declaringTypeQualification = null; 
/* 1340 */         declaringTypeSimpleName = CharOperation.subarray(declaringTypePart, lastDotPosition + 1, declaringTypePart.length);
/*      */       } else {
/* 1342 */         declaringTypeSimpleName = declaringTypePart;
/*      */       } 
/* 1344 */       if (declaringTypeSimpleName.length == 1 && declaringTypeSimpleName[0] == '*') {
/* 1345 */         declaringTypeSimpleName = null;
/*      */       }
/*      */     } 
/* 1348 */     if (parameterCount >= 0) {
/* 1349 */       parameterTypeQualifications = new char[parameterCount][];
/* 1350 */       parameterTypeSimpleNames = new char[parameterCount][];
/* 1351 */       parameterTypeSignatures = new String[parameterCount];
/* 1352 */       for (int i = 0; i < parameterCount; i++) {
/*      */         
/* 1354 */         char[] parameterTypePart = null;
/*      */         try {
/* 1356 */           if (parameterTypes != null) {
/* 1357 */             parameterTypeSignatures[i] = Signature.createTypeSignature(parameterTypes[i], false);
/* 1358 */             if (parameterTypeSignatures[i].indexOf('<') < 0) {
/* 1359 */               parameterTypePart = parameterTypes[i].toCharArray();
/*      */             } else {
/* 1361 */               parameterTypePart = Signature.toCharArray(Signature.getTypeErasure(parameterTypeSignatures[i].toCharArray()));
/*      */             }
/*      */           
/*      */           } 
/* 1365 */         } catch (IllegalArgumentException illegalArgumentException) {
/*      */           
/* 1367 */           return null;
/*      */         } 
/* 1369 */         int lastDotPosition = (parameterTypePart == null) ? -1 : CharOperation.lastIndexOf('.', parameterTypePart);
/* 1370 */         if (parameterTypePart != null && lastDotPosition >= 0) {
/* 1371 */           parameterTypeQualifications[i] = CharOperation.subarray(parameterTypePart, 0, lastDotPosition);
/* 1372 */           if ((parameterTypeQualifications[i]).length == 1 && parameterTypeQualifications[i][0] == '*') {
/* 1373 */             parameterTypeQualifications[i] = null;
/*      */           } else {
/*      */             
/* 1376 */             parameterTypeQualifications[i] = CharOperation.concat(IIndexConstants.ONE_STAR, parameterTypeQualifications[i]);
/*      */           } 
/* 1378 */           parameterTypeSimpleNames[i] = CharOperation.subarray(parameterTypePart, lastDotPosition + 1, parameterTypePart.length);
/*      */         } else {
/* 1380 */           parameterTypeQualifications[i] = null;
/* 1381 */           parameterTypeSimpleNames[i] = parameterTypePart;
/*      */         } 
/* 1383 */         if ((parameterTypeSimpleNames[i]).length == 1 && parameterTypeSimpleNames[i][0] == '*') {
/* 1384 */           parameterTypeSimpleNames[i] = null;
/*      */         }
/*      */       } 
/*      */     } 
/* 1388 */     if (returnType != null) {
/*      */       
/* 1390 */       char[] returnTypePart = null;
/*      */       try {
/* 1392 */         returnTypeSignature = Signature.createTypeSignature(returnType, false);
/* 1393 */         if (returnTypeSignature.indexOf('<') < 0) {
/* 1394 */           returnTypePart = returnType.toCharArray();
/*      */         } else {
/* 1396 */           returnTypePart = Signature.toCharArray(Signature.getTypeErasure(returnTypeSignature.toCharArray()));
/*      */         }
/*      */       
/* 1399 */       } catch (IllegalArgumentException illegalArgumentException) {
/*      */         
/* 1401 */         return null;
/*      */       } 
/* 1403 */       int lastDotPosition = CharOperation.lastIndexOf('.', returnTypePart);
/* 1404 */       if (lastDotPosition >= 0) {
/* 1405 */         returnTypeQualification = CharOperation.subarray(returnTypePart, 0, lastDotPosition);
/* 1406 */         if (returnTypeQualification.length == 1 && returnTypeQualification[0] == '*') {
/* 1407 */           returnTypeQualification = null;
/*      */         } else {
/*      */           
/* 1410 */           returnTypeQualification = CharOperation.concat(IIndexConstants.ONE_STAR, returnTypeQualification);
/*      */         } 
/* 1412 */         returnTypeSimpleName = CharOperation.subarray(returnTypePart, lastDotPosition + 1, returnTypePart.length);
/*      */       } else {
/* 1414 */         returnTypeSimpleName = returnTypePart;
/*      */       } 
/* 1416 */       if (returnTypeSimpleName.length == 1 && returnTypeSimpleName[0] == '*') {
/* 1417 */         returnTypeSimpleName = null;
/*      */       }
/*      */     } 
/* 1420 */     if (isConstructor) {
/* 1421 */       return (SearchPattern)new ConstructorPattern(
/* 1422 */           declaringTypeSimpleName, 
/* 1423 */           declaringTypeQualification, 
/* 1424 */           declaringTypeSignature, 
/* 1425 */           parameterTypeQualifications, 
/* 1426 */           parameterTypeSimpleNames, 
/* 1427 */           parameterTypeSignatures, 
/* 1428 */           typeArguments, 
/* 1429 */           limitTo, 
/* 1430 */           matchRule);
/*      */     }
/* 1432 */     return (SearchPattern)new MethodPattern(
/* 1433 */         selectorChars, 
/* 1434 */         declaringTypeQualification, 
/* 1435 */         declaringTypeSimpleName, 
/* 1436 */         declaringTypeSignature, 
/* 1437 */         returnTypeQualification, 
/* 1438 */         returnTypeSimpleName, 
/* 1439 */         returnTypeSignature, 
/* 1440 */         parameterTypeQualifications, 
/* 1441 */         parameterTypeSimpleNames, 
/* 1442 */         parameterTypeSignatures, 
/* 1443 */         typeArguments, 
/* 1444 */         limitTo, 
/* 1445 */         matchRule);
/*      */   }
/*      */ 
/*      */   
/*      */   private static SearchPattern createModulePattern(String patternString, int limitTo, int matchRule) {
/* 1450 */     return (SearchPattern)new ModulePattern(patternString.toCharArray(), limitTo, matchRule);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SearchPattern createOrPattern(SearchPattern leftPattern, SearchPattern rightPattern) {
/* 1463 */     return (SearchPattern)new OrPattern(leftPattern, rightPattern);
/*      */   }
/*      */   
/*      */   private static SearchPattern createPackagePattern(String patternString, int limitTo, int matchRule) {
/* 1467 */     switch (limitTo) {
/*      */       case 0:
/* 1469 */         return (SearchPattern)new PackageDeclarationPattern(patternString.toCharArray(), matchRule);
/*      */       case 2:
/* 1471 */         return (SearchPattern)new PackageReferencePattern(patternString.toCharArray(), matchRule);
/*      */       case 3:
/* 1473 */         return (SearchPattern)new OrPattern(
/* 1474 */             (SearchPattern)new PackageDeclarationPattern(patternString.toCharArray(), matchRule), 
/* 1475 */             (SearchPattern)new PackageReferencePattern(patternString.toCharArray(), matchRule));
/*      */     } 
/*      */     
/* 1478 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SearchPattern createPattern(String stringPattern, int searchFor, int limitTo, int matchRule) {
/* 1716 */     if (stringPattern == null || stringPattern.length() == 0) return null;
/*      */     
/* 1718 */     if ((matchRule = validateMatchRule(stringPattern, searchFor, limitTo, matchRule)) == -1) {
/* 1719 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1723 */     limitTo &= 0xFFFFFFCF;
/*      */     
/* 1725 */     switch (searchFor) {
/*      */       case 5:
/* 1727 */         return createTypePattern(stringPattern, limitTo, matchRule, 'C');
/*      */       case 10:
/* 1729 */         return createTypePattern(stringPattern, limitTo, matchRule, '\n');
/*      */       case 9:
/* 1731 */         return createTypePattern(stringPattern, limitTo, matchRule, '\t');
/*      */       case 6:
/* 1733 */         return createTypePattern(stringPattern, limitTo, matchRule, 'I');
/*      */       case 11:
/* 1735 */         return createTypePattern(stringPattern, limitTo, matchRule, '\013');
/*      */       case 7:
/* 1737 */         return createTypePattern(stringPattern, limitTo, matchRule, 'E');
/*      */       case 8:
/* 1739 */         return createTypePattern(stringPattern, limitTo, matchRule, 'A');
/*      */       case 0:
/* 1741 */         return createTypePattern(stringPattern, limitTo, matchRule, false);
/*      */       case 1:
/* 1743 */         return createMethodOrConstructorPattern(stringPattern, limitTo, matchRule, false);
/*      */       case 3:
/* 1745 */         return createMethodOrConstructorPattern(stringPattern, limitTo, matchRule, true);
/*      */       case 4:
/* 1747 */         return createFieldPattern(stringPattern, limitTo, matchRule);
/*      */       case 2:
/* 1749 */         return createPackagePattern(stringPattern, limitTo, matchRule);
/*      */       case 12:
/* 1751 */         return createModulePattern(stringPattern, limitTo, matchRule);
/*      */     } 
/* 1753 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SearchPattern createPattern(IJavaElement element, int limitTo) {
/* 1872 */     return createPattern(element, limitTo, 24);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SearchPattern createPattern(IJavaElement element, int limitTo, int matchRule) {
/*      */     FieldPattern fieldPattern;
/*      */     SearchPattern searchPattern2;
/*      */     LocalVariablePattern localVariablePattern;
/*      */     TypeParameterPattern typeParameterPattern;
/*      */     MethodPattern methodPattern;
/*      */     SearchPattern searchPattern1;
/*      */     int lastDot;
/*      */     IField field;
/*      */     char[] name, typeSimpleName, typeQualification;
/*      */     String typeSignature;
/*      */     IType declaringType;
/*      */     String elementName;
/*      */     IImportDeclaration importDecl;
/*      */     LocalVariable localVar;
/*      */     ITypeParameter typeParam;
/*      */     boolean findParamDeclarations, findParamReferences;
/*      */     IMethod method;
/*      */     boolean isConstructor;
/*      */     IType declaringClass;
/*      */     char[] selector, returnSimpleName, returnQualification;
/*      */     String returnSignature, parameterTypes[];
/*      */     int paramCount;
/*      */     char[][] parameterSimpleNames, parameterQualifications;
/*      */     String[] parameterSignatures;
/*      */     int i;
/*      */     IType type;
/*      */     char[] simpleName;
/* 2014 */     SearchPattern searchPattern = null;
/*      */     
/* 2016 */     boolean ignoreDeclaringType = false;
/* 2017 */     boolean ignoreReturnType = false;
/* 2018 */     int maskedLimitTo = limitTo & 0xFFFFFFCF;
/* 2019 */     if (maskedLimitTo == 0 || maskedLimitTo == 3) {
/* 2020 */       ignoreDeclaringType = ((limitTo & 0x10) != 0);
/* 2021 */       ignoreReturnType = ((limitTo & 0x20) != 0);
/*      */     } 
/* 2023 */     if ((matchRule = validateMatchRule(null, matchRule)) == -1) {
/* 2024 */       return null;
/*      */     }
/* 2026 */     char[] declaringSimpleName = null;
/* 2027 */     char[] declaringQualification = null;
/* 2028 */     switch (element.getElementType()) {
/*      */       case 8:
/* 2030 */         field = (IField)element;
/* 2031 */         if (!ignoreDeclaringType) {
/* 2032 */           IType iType = field.getDeclaringType();
/* 2033 */           declaringSimpleName = iType.getElementName().toCharArray();
/* 2034 */           declaringQualification = iType.getPackageFragment().getElementName().toCharArray();
/* 2035 */           char[][] enclosingNames = enclosingTypeNames(iType);
/* 2036 */           if (enclosingNames.length > 0) {
/* 2037 */             declaringQualification = CharOperation.concat(declaringQualification, CharOperation.concatWith(enclosingNames, '.'), '.');
/*      */           }
/*      */         } 
/* 2040 */         name = field.getElementName().toCharArray();
/* 2041 */         typeSimpleName = null;
/* 2042 */         typeQualification = null;
/* 2043 */         typeSignature = null;
/* 2044 */         if (!ignoreReturnType) {
/*      */           try {
/* 2046 */             typeSignature = field.getTypeSignature();
/* 2047 */             char[] signature = typeSignature.toCharArray();
/* 2048 */             char[] typeErasure = Signature.toCharArray(Signature.getTypeErasure(signature));
/* 2049 */             CharOperation.replace(typeErasure, '$', '.'); int j;
/* 2050 */             if ((j = CharOperation.lastIndexOf('.', typeErasure)) == -1) {
/* 2051 */               typeSimpleName = typeErasure;
/*      */             } else {
/* 2053 */               typeSimpleName = CharOperation.subarray(typeErasure, j + 1, typeErasure.length);
/* 2054 */               typeQualification = CharOperation.subarray(typeErasure, 0, j);
/* 2055 */               if (!field.isBinary())
/*      */               {
/* 2057 */                 typeQualification = CharOperation.concat(IIndexConstants.ONE_STAR, typeQualification);
/*      */               }
/*      */             } 
/* 2060 */           } catch (JavaModelException javaModelException) {
/* 2061 */             return null;
/*      */           } 
/*      */         }
/*      */         
/* 2065 */         fieldPattern = 
/* 2066 */           new FieldPattern(
/* 2067 */             name, 
/* 2068 */             declaringQualification, 
/* 2069 */             declaringSimpleName, 
/* 2070 */             typeQualification, 
/* 2071 */             typeSimpleName, 
/* 2072 */             typeSignature, 
/* 2073 */             limitTo, 
/* 2074 */             matchRule);
/*      */ 
/*      */         
/* 2077 */         declaringType = field.getDeclaringType();
/*      */         try {
/* 2079 */           if (declaringType.isRecord()) {
/* 2080 */             MethodPattern accessorMethodPattern = new MethodPattern(name, 
/* 2081 */                 declaringQualification, 
/* 2082 */                 declaringSimpleName, 
/* 2083 */                 typeQualification, 
/* 2084 */                 typeSimpleName, 
/* 2085 */                 null, 
/* 2086 */                 null, 
/* 2087 */                 field.getDeclaringType(), 
/* 2088 */                 limitTo, 
/* 2089 */                 matchRule);
/*      */             
/* 2091 */             OrPattern orPattern = new OrPattern((SearchPattern)fieldPattern, (SearchPattern)accessorMethodPattern);
/*      */           } 
/* 2093 */         } catch (JavaModelException javaModelException) {}
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 13:
/* 2099 */         elementName = element.getElementName();
/* 2100 */         lastDot = elementName.lastIndexOf('.');
/* 2101 */         if (lastDot == -1) return null; 
/* 2102 */         importDecl = (IImportDeclaration)element;
/* 2103 */         if (importDecl.isOnDemand()) {
/* 2104 */           SearchPattern searchPattern3 = createPackagePattern(elementName.substring(0, lastDot), maskedLimitTo, matchRule); break;
/*      */         } 
/* 2106 */         searchPattern2 = 
/* 2107 */           createTypePattern(
/* 2108 */             elementName.substring(lastDot + 1).toCharArray(), 
/* 2109 */             elementName.substring(0, lastDot).toCharArray(), 
/* 2110 */             null, 
/* 2111 */             null, 
/* 2112 */             null, 
/* 2113 */             maskedLimitTo, 
/* 2114 */             matchRule);
/*      */         break;
/*      */       
/*      */       case 14:
/* 2118 */         localVar = (LocalVariable)element;
/* 2119 */         localVariablePattern = new LocalVariablePattern(localVar, limitTo, matchRule);
/*      */         break;
/*      */       case 15:
/* 2122 */         typeParam = (ITypeParameter)element;
/* 2123 */         findParamDeclarations = true;
/* 2124 */         findParamReferences = true;
/* 2125 */         switch (maskedLimitTo) {
/*      */           case 0:
/* 2127 */             findParamReferences = false;
/*      */             break;
/*      */           case 2:
/* 2130 */             findParamDeclarations = false;
/*      */             break;
/*      */         } 
/* 2133 */         typeParameterPattern = 
/* 2134 */           new TypeParameterPattern(
/* 2135 */             findParamDeclarations, 
/* 2136 */             findParamReferences, 
/* 2137 */             typeParam, 
/* 2138 */             matchRule);
/*      */         break;
/*      */       case 9:
/* 2141 */         method = (IMethod)element;
/*      */         
/*      */         try {
/* 2144 */           isConstructor = method.isConstructor();
/* 2145 */         } catch (JavaModelException javaModelException) {
/* 2146 */           return null;
/*      */         } 
/* 2148 */         declaringClass = method.getDeclaringType();
/* 2149 */         if (ignoreDeclaringType) {
/* 2150 */           if (isConstructor) declaringSimpleName = declaringClass.getElementName().toCharArray(); 
/*      */         } else {
/* 2152 */           declaringSimpleName = declaringClass.getElementName().toCharArray();
/* 2153 */           declaringQualification = declaringClass.getPackageFragment().getElementName().toCharArray();
/* 2154 */           char[][] enclosingNames = enclosingTypeNames(declaringClass);
/* 2155 */           if (enclosingNames.length > 0) {
/* 2156 */             declaringQualification = CharOperation.concat(declaringQualification, CharOperation.concatWith(enclosingNames, '.'), '.');
/*      */           }
/*      */         } 
/* 2159 */         selector = method.getElementName().toCharArray();
/* 2160 */         returnSimpleName = null;
/* 2161 */         returnQualification = null;
/* 2162 */         returnSignature = null;
/* 2163 */         if (!ignoreReturnType) {
/*      */           try {
/* 2165 */             returnSignature = method.getReturnType();
/* 2166 */             char[] signature = returnSignature.toCharArray();
/* 2167 */             char[] returnErasure = Signature.toCharArray(Signature.getTypeErasure(signature));
/* 2168 */             CharOperation.replace(returnErasure, '$', '.');
/* 2169 */             if ((lastDot = CharOperation.lastIndexOf('.', returnErasure)) == -1) {
/* 2170 */               returnSimpleName = returnErasure;
/*      */             } else {
/* 2172 */               returnSimpleName = CharOperation.subarray(returnErasure, lastDot + 1, returnErasure.length);
/* 2173 */               returnQualification = CharOperation.subarray(returnErasure, 0, lastDot);
/* 2174 */               if (!method.isBinary())
/*      */               {
/* 2176 */                 CharOperation.concat(IIndexConstants.ONE_STAR, returnQualification);
/*      */               }
/*      */             } 
/* 2179 */           } catch (JavaModelException javaModelException) {
/* 2180 */             return null;
/*      */           } 
/*      */         }
/* 2183 */         parameterTypes = method.getParameterTypes();
/* 2184 */         paramCount = parameterTypes.length;
/* 2185 */         parameterSimpleNames = new char[paramCount][];
/* 2186 */         parameterQualifications = new char[paramCount][];
/* 2187 */         parameterSignatures = new String[paramCount];
/* 2188 */         for (i = 0; i < paramCount; i++) {
/* 2189 */           parameterSignatures[i] = parameterTypes[i];
/* 2190 */           char[] signature = parameterSignatures[i].toCharArray();
/* 2191 */           char[] paramErasure = Signature.toCharArray(Signature.getTypeErasure(signature));
/* 2192 */           CharOperation.replace(paramErasure, '$', '.');
/* 2193 */           if ((lastDot = CharOperation.lastIndexOf('.', paramErasure)) == -1) {
/* 2194 */             parameterSimpleNames[i] = paramErasure;
/* 2195 */             parameterQualifications[i] = null;
/*      */           } else {
/* 2197 */             parameterSimpleNames[i] = CharOperation.subarray(paramErasure, lastDot + 1, paramErasure.length);
/* 2198 */             parameterQualifications[i] = CharOperation.subarray(paramErasure, 0, lastDot);
/* 2199 */             if (!method.isBinary())
/*      */             {
/* 2201 */               CharOperation.concat(IIndexConstants.ONE_STAR, parameterQualifications[i]);
/*      */             }
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 2207 */         if (isConstructor) {
/* 2208 */           ConstructorPattern constructorPattern = 
/* 2209 */             new ConstructorPattern(
/* 2210 */               declaringSimpleName, 
/* 2211 */               declaringQualification, 
/* 2212 */               parameterQualifications, 
/* 2213 */               parameterSimpleNames, 
/* 2214 */               parameterSignatures, 
/* 2215 */               method, 
/* 2216 */               limitTo, 
/* 2217 */               matchRule); break;
/*      */         } 
/* 2219 */         methodPattern = 
/* 2220 */           new MethodPattern(
/* 2221 */             selector, 
/* 2222 */             declaringQualification, 
/* 2223 */             declaringSimpleName, 
/* 2224 */             returnQualification, 
/* 2225 */             returnSimpleName, 
/* 2226 */             returnSignature, 
/* 2227 */             parameterQualifications, 
/* 2228 */             parameterSimpleNames, 
/* 2229 */             parameterSignatures, 
/* 2230 */             method, 
/* 2231 */             limitTo, 
/* 2232 */             matchRule);
/*      */         break;
/*      */       
/*      */       case 7:
/* 2236 */         type = (IType)element;
/* 2237 */         simpleName = type.getElementName().toCharArray();
/* 2238 */         searchPattern1 = createTypePattern(
/* 2239 */             simpleName, 
/* 2240 */             type.getPackageFragment().getElementName().toCharArray(), 
/* 2241 */             ignoreDeclaringType ? null : enclosingTypeNames(type), 
/* 2242 */             null, 
/* 2243 */             type, 
/* 2244 */             maskedLimitTo, 
/* 2245 */             matchRule);
/* 2246 */         if (maskedLimitTo == 0 || 
/* 2247 */           maskedLimitTo == 2) {
/* 2248 */           char[] qualifiedName = type.getFullyQualifiedName().toCharArray();
/* 2249 */           qualifiedName = CharOperation.equals(simpleName, qualifiedName) ? CharOperation.NO_CHAR : qualifiedName;
/* 2250 */           MatchLocator.setIndexQualifierQuery(searchPattern1, QualifierQuery.encodeQuery(new QualifierQuery.QueryCategory[] {
/* 2251 */                   QualifierQuery.QueryCategory.REF
/* 2252 */                 }, simpleName, qualifiedName));
/*      */         } 
/*      */         break;
/*      */       case 4:
/*      */       case 11:
/* 2257 */         searchPattern1 = createPackagePattern(element.getElementName(), maskedLimitTo, matchRule);
/*      */         break;
/*      */       case 17:
/* 2260 */         searchPattern1 = createModulePattern(element.getElementName(), maskedLimitTo, matchRule);
/*      */         break;
/*      */     } 
/* 2263 */     if (searchPattern1 != null)
/* 2264 */       MatchLocator.setFocus(searchPattern1, element); 
/* 2265 */     return searchPattern1;
/*      */   }
/*      */   
/*      */   private static SearchPattern createTypePattern(char[] simpleName, char[] packageName, char[][] enclosingTypeNames, String typeSignature, IType type, int limitTo, int matchRule) {
/* 2269 */     switch (limitTo) {
/*      */       case 0:
/* 2271 */         return (SearchPattern)new TypeDeclarationPattern(
/* 2272 */             packageName, 
/* 2273 */             enclosingTypeNames, 
/* 2274 */             simpleName, 
/* 2275 */             false, 
/* 2276 */             matchRule);
/*      */       case 2:
/* 2278 */         if (type != null) {
/* 2279 */           return (SearchPattern)new TypeReferencePattern(
/* 2280 */               CharOperation.concatWith(packageName, enclosingTypeNames, '.'), 
/* 2281 */               simpleName, 
/* 2282 */               type, 
/* 2283 */               matchRule);
/*      */         }
/* 2285 */         return (SearchPattern)new TypeReferencePattern(
/* 2286 */             CharOperation.concatWith(packageName, enclosingTypeNames, '.'), 
/* 2287 */             simpleName, 
/* 2288 */             typeSignature, 
/* 2289 */             matchRule);
/*      */       case 1:
/* 2291 */         return (SearchPattern)new SuperTypeReferencePattern(
/* 2292 */             CharOperation.concatWith(packageName, enclosingTypeNames, '.'), 
/* 2293 */             simpleName, 
/* 2294 */             1, 
/* 2295 */             matchRule);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/* 2304 */         if (type != null) {
/*      */         
/*      */         } else {
/*      */         
/*      */         } 
/*      */         
/* 2310 */         return (SearchPattern)new OrPattern((SearchPattern)new TypeDeclarationPattern(packageName, enclosingTypeNames, simpleName, false, matchRule), (SearchPattern)new TypeReferencePattern(
/* 2311 */               CharOperation.concatWith(packageName, enclosingTypeNames, '.'), 
/* 2312 */               simpleName, 
/* 2313 */               typeSignature, 
/* 2314 */               matchRule));
/*      */     } 
/*      */     
/* 2317 */     if (type != null) {
/* 2318 */       return (SearchPattern)new TypeReferencePattern(
/* 2319 */           CharOperation.concatWith(packageName, enclosingTypeNames, '.'), 
/* 2320 */           simpleName, 
/* 2321 */           type, 
/* 2322 */           limitTo, 
/* 2323 */           matchRule);
/*      */     }
/*      */     
/* 2326 */     return null; } private static SearchPattern createTypePattern(String patternString, int limitTo, int matchRule, char indexSuffix) {
/*      */     int token;
/*      */     QualifiedTypeDeclarationPattern qualifiedTypeDeclarationPattern;
/* 2329 */     String[] arr = patternString.split(String.valueOf('/'));
/* 2330 */     String moduleName = null;
/* 2331 */     if (arr.length == 2) {
/* 2332 */       moduleName = arr[0];
/* 2333 */       patternString = arr[1];
/*      */     } 
/* 2335 */     char[] patModName = (moduleName != null) ? moduleName.toCharArray() : null;
/*      */ 
/*      */     
/* 2338 */     Scanner scanner = new Scanner(false, true, false, 3342336L, null, null, true);
/* 2339 */     scanner.setSource(patternString.toCharArray());
/* 2340 */     String type = null;
/*      */     
/*      */     try {
/* 2343 */       token = scanner.getNextToken();
/* 2344 */     } catch (InvalidInputException invalidInputException) {
/* 2345 */       return null;
/*      */     } 
/* 2347 */     int argCount = 0;
/* 2348 */     while (token != 64) {
/* 2349 */       if (argCount == 0) {
/* 2350 */         switch (token) {
/*      */           case 1000:
/*      */             break;
/*      */           case 11:
/* 2354 */             argCount++;
/*      */           
/*      */           default:
/* 2357 */             if (type == null) {
/* 2358 */               type = scanner.getCurrentTokenString(); break;
/*      */             } 
/* 2360 */             type = String.valueOf(type) + scanner.getCurrentTokenString(); break;
/*      */         } 
/*      */       } else {
/* 2363 */         switch (token) {
/*      */           case 14:
/*      */           case 15:
/*      */           case 16:
/* 2367 */             argCount--;
/*      */             break;
/*      */           case 11:
/* 2370 */             argCount++;
/*      */             break;
/*      */         } 
/* 2373 */         if (type == null) return null; 
/* 2374 */         type = String.valueOf(type) + scanner.getCurrentTokenString();
/*      */       } 
/*      */       try {
/* 2377 */         token = scanner.getNextToken();
/* 2378 */       } catch (InvalidInputException invalidInputException) {
/* 2379 */         return null;
/*      */       } 
/*      */     } 
/* 2382 */     if (type == null) return null; 
/* 2383 */     String typeSignature = null;
/* 2384 */     char[] qualificationChars = null, typeChars = null;
/*      */ 
/*      */     
/* 2387 */     char[] typePart = null;
/*      */     try {
/* 2389 */       typeSignature = Signature.createTypeSignature(type, false);
/* 2390 */       if (typeSignature.indexOf('<') < 0) {
/* 2391 */         typePart = type.toCharArray();
/*      */       } else {
/* 2393 */         typePart = Signature.toCharArray(Signature.getTypeErasure(typeSignature.toCharArray()));
/*      */       }
/*      */     
/* 2396 */     } catch (IllegalArgumentException illegalArgumentException) {
/*      */       
/* 2398 */       return null;
/*      */     } 
/*      */ 
/*      */     
/* 2402 */     int lastDotPosition = CharOperation.lastIndexOf('.', typePart);
/* 2403 */     if (lastDotPosition >= 0) {
/* 2404 */       qualificationChars = CharOperation.subarray(typePart, 0, lastDotPosition);
/* 2405 */       if (qualificationChars.length == 1 && qualificationChars[0] == '*')
/* 2406 */         qualificationChars = null; 
/* 2407 */       typeChars = CharOperation.subarray(typePart, lastDotPosition + 1, typePart.length);
/*      */     } else {
/* 2409 */       typeChars = typePart;
/*      */     } 
/* 2411 */     if (typeChars.length == 1 && typeChars[0] == '*') {
/* 2412 */       typeChars = null;
/*      */     }
/* 2414 */     boolean modGraph = false;
/* 2415 */     switch (limitTo) {
/*      */       case 6:
/* 2417 */         modGraph = true;
/*      */       
/*      */       case 0:
/* 2420 */         qualifiedTypeDeclarationPattern = new QualifiedTypeDeclarationPattern(patModName, qualificationChars, typeChars, indexSuffix, matchRule);
/* 2421 */         ((TypeDeclarationPattern)qualifiedTypeDeclarationPattern).moduleGraph = modGraph;
/* 2422 */         return (SearchPattern)qualifiedTypeDeclarationPattern;
/*      */       case 2:
/* 2424 */         return (SearchPattern)new TypeReferencePattern(qualificationChars, typeChars, typeSignature, indexSuffix, matchRule);
/*      */       case 1:
/* 2426 */         return (SearchPattern)new SuperTypeReferencePattern(qualificationChars, typeChars, 1, indexSuffix, matchRule);
/*      */       case 3:
/* 2428 */         return (SearchPattern)new OrPattern(
/* 2429 */             (SearchPattern)new QualifiedTypeDeclarationPattern(patModName, qualificationChars, typeChars, indexSuffix, matchRule), 
/* 2430 */             (SearchPattern)new TypeReferencePattern(qualificationChars, typeChars, typeSignature, indexSuffix, matchRule));
/*      */     } 
/* 2432 */     return (SearchPattern)new TypeReferencePattern(qualificationChars, typeChars, typeSignature, limitTo, indexSuffix, matchRule);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static char[][] enclosingTypeNames(IType type) {
/*      */     IType declaringType, declaringClass;
/* 2439 */     IJavaElement parent = type.getParent();
/* 2440 */     switch (parent.getElementType()) {
/*      */       case 6:
/* 2442 */         if (parent instanceof org.eclipse.jdt.core.IModularClassFile) {
/* 2443 */           return null;
/*      */         }
/*      */         
/* 2446 */         declaringType = type.getDeclaringType();
/* 2447 */         if (declaringType == null) return CharOperation.NO_CHAR_CHAR; 
/* 2448 */         return CharOperation.arrayConcat(
/* 2449 */             enclosingTypeNames(declaringType), 
/* 2450 */             declaringType.getElementName().toCharArray());
/*      */       case 5:
/* 2452 */         return CharOperation.NO_CHAR_CHAR;
/*      */       case 8:
/*      */       case 9:
/*      */       case 10:
/* 2456 */         declaringClass = ((IMember)parent).getDeclaringType();
/* 2457 */         return CharOperation.arrayConcat(
/* 2458 */             enclosingTypeNames(declaringClass), 
/* 2459 */             new char[][] { declaringClass.getElementName().toCharArray(), IIndexConstants.ONE_STAR });
/*      */       case 7:
/* 2461 */         return CharOperation.arrayConcat(
/* 2462 */             enclosingTypeNames((IType)parent), 
/* 2463 */             parent.getElementName().toCharArray());
/*      */     } 
/* 2465 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void decodeIndexKey(char[] key) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void findIndexMatches(Index index, IndexQueryRequestor requestor, SearchParticipant participant, IJavaSearchScope scope, IProgressMonitor monitor) throws IOException {
/* 2489 */     findIndexMatches(index, requestor, participant, scope, true, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void findIndexMatches(Index index, IndexQueryRequestor requestor, SearchParticipant participant, IJavaSearchScope scope, boolean resolveDocumentName, IProgressMonitor monitor) throws IOException {
/* 2513 */     if (monitor != null && monitor.isCanceled()) throw new OperationCanceledException(); 
/*      */     try {
/* 2515 */       index.startQuery();
/* 2516 */       SearchPattern pattern = currentPattern();
/* 2517 */       EntryResult[] entries = pattern.queryIn(index);
/* 2518 */       if (entries == null)
/*      */         return; 
/* 2520 */       String containerPath = index.containerPath;
/* 2521 */       char separator = index.separator;
/* 2522 */       for (int i = 0, l = entries.length; i < l; i++) {
/* 2523 */         if (monitor != null && monitor.isCanceled()) throw new OperationCanceledException();
/*      */         
/* 2525 */         EntryResult entry = entries[i];
/* 2526 */         SearchPattern decodedResult = pattern.getBlankPattern();
/* 2527 */         decodedResult.decodeIndexKey(entry.getWord());
/* 2528 */         if (pattern.matchesDecodedKey(decodedResult))
/*      */         {
/*      */           
/* 2531 */           if (resolveDocumentName) {
/* 2532 */             String[] names = entry.getDocumentNames(index);
/* 2533 */             for (int j = 0, n = names.length; j < n; j++)
/* 2534 */               acceptMatch(names[j], containerPath, separator, decodedResult, requestor, participant, scope, monitor); 
/*      */           } else {
/* 2536 */             acceptMatch("", containerPath, separator, decodedResult, requestor, participant, scope, monitor);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } finally {
/* 2541 */       index.stopQuery();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getIndexKey() {
/* 2568 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[][] getIndexCategories() {
/* 2583 */     return CharOperation.NO_CHAR_CHAR;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getMatchRule() {
/* 2594 */     return this.matchRule;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPolymorphicSearch() {
/* 2601 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matchesDecodedKey(SearchPattern decodedPattern) {
/* 2614 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean matchesName(char[] pattern, char[] name) {
/* 2629 */     if (pattern == null) return true; 
/* 2630 */     if (name != null) {
/* 2631 */       boolean isCaseSensitive = ((this.matchRule & 0x8) != 0);
/* 2632 */       int matchMode = this.matchRule & 0x787;
/* 2633 */       boolean emptyPattern = (pattern.length == 0);
/* 2634 */       if (emptyPattern && (this.matchRule & 0x1) != 0) return true; 
/* 2635 */       boolean sameLength = (pattern.length == name.length);
/* 2636 */       boolean canBePrefix = (name.length >= pattern.length);
/* 2637 */       boolean matchFirstChar = !(isCaseSensitive && !emptyPattern && (name.length <= 0 || pattern[0] != name[0]));
/*      */       
/* 2639 */       if ((matchMode & 0x200) != 0) {
/* 2640 */         if (CharOperation.substringMatch(pattern, name))
/* 2641 */           return true; 
/* 2642 */         matchMode &= 0xFFFFFDFF;
/*      */       } 
/* 2644 */       if ((matchMode & 0x400) != 0) {
/* 2645 */         if (CharOperation.subWordMatch(pattern, name))
/* 2646 */           return true; 
/* 2647 */         matchMode &= 0xFFFFFBFF;
/*      */       } 
/*      */       
/* 2650 */       switch (matchMode) {
/*      */         case 0:
/* 2652 */           if (sameLength && matchFirstChar) {
/* 2653 */             return CharOperation.equals(pattern, name, isCaseSensitive);
/*      */           }
/*      */           break;
/*      */         
/*      */         case 1:
/* 2658 */           if (canBePrefix && matchFirstChar) {
/* 2659 */             return CharOperation.prefixEquals(pattern, name, isCaseSensitive);
/*      */           }
/*      */           break;
/*      */         
/*      */         case 2:
/* 2664 */           if (!isCaseSensitive)
/* 2665 */             pattern = CharOperation.toLowerCase(pattern); 
/* 2666 */           return CharOperation.match(pattern, name, isCaseSensitive);
/*      */         
/*      */         case 128:
/* 2669 */           if (matchFirstChar && CharOperation.camelCaseMatch(pattern, name, false)) {
/* 2670 */             return true;
/*      */           }
/*      */           
/* 2673 */           if (!isCaseSensitive && matchFirstChar && CharOperation.prefixEquals(pattern, name, false)) {
/* 2674 */             return true;
/*      */           }
/*      */           break;
/*      */         
/*      */         case 256:
/* 2679 */           return (matchFirstChar && CharOperation.camelCaseMatch(pattern, name, true));
/*      */         
/*      */         case 4:
/* 2682 */           return Pattern.matches(new String(pattern), new String(name));
/*      */       } 
/*      */     } 
/* 2685 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int validateMatchRule(String stringPattern, int matchRule) {
/* 2739 */     if ((matchRule & 0x4) != 0)
/*      */     {
/* 2741 */       return -1;
/*      */     }
/*      */ 
/*      */     
/* 2745 */     if (stringPattern != null) {
/* 2746 */       int starIndex = stringPattern.indexOf('*');
/* 2747 */       int questionIndex = stringPattern.indexOf('?');
/* 2748 */       if (starIndex < 0 && questionIndex < 0) {
/*      */         
/* 2750 */         matchRule &= 0xFFFFFFFD;
/*      */       } else {
/*      */         
/* 2753 */         matchRule |= 0x2;
/*      */       } 
/*      */     } 
/* 2756 */     if ((matchRule & 0x2) != 0) {
/*      */       
/* 2758 */       matchRule &= 0xFFFFFF7F;
/* 2759 */       matchRule &= 0xFFFFFEFF;
/* 2760 */       matchRule &= 0xFFFFFFFE;
/* 2761 */       return matchRule;
/*      */     } 
/*      */ 
/*      */     
/* 2765 */     if ((matchRule & 0x80) != 0) {
/*      */       
/* 2767 */       matchRule &= 0xFFFFFEFF;
/* 2768 */       matchRule &= 0xFFFFFFFE;
/*      */       
/* 2770 */       boolean validCamelCase = validateCamelCasePattern(stringPattern);
/* 2771 */       if (!validCamelCase) {
/* 2772 */         matchRule &= 0xFFFFFF7F;
/* 2773 */         matchRule |= 0x1;
/*      */       } 
/* 2775 */       return matchRule;
/*      */     } 
/*      */ 
/*      */     
/* 2779 */     if ((matchRule & 0x100) != 0) {
/*      */       
/* 2781 */       matchRule &= 0xFFFFFFFE;
/*      */       
/* 2783 */       boolean validCamelCase = validateCamelCasePattern(stringPattern);
/* 2784 */       if (!validCamelCase) {
/* 2785 */         matchRule &= 0xFFFFFEFF;
/*      */       }
/* 2787 */       return matchRule;
/*      */     } 
/*      */ 
/*      */     
/* 2791 */     return matchRule;
/*      */   }
/*      */ 
/*      */   
/*      */   private static int validateMatchRule(String stringPattern, int searchFor, int limitTo, int matchRule) {
/* 2796 */     if (searchFor == 12 && 
/* 2797 */       limitTo == 0 && 
/* 2798 */       matchRule == 4)
/* 2799 */       return matchRule; 
/* 2800 */     return validateMatchRule(stringPattern, matchRule);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean validateCamelCasePattern(String stringPattern) {
/* 2808 */     if (stringPattern == null) return true;
/*      */     
/* 2810 */     int length = stringPattern.length();
/* 2811 */     boolean validCamelCase = true;
/* 2812 */     boolean lowerCamelCase = false;
/* 2813 */     int uppercase = 0;
/* 2814 */     for (int i = 0; i < length && validCamelCase; i++) {
/* 2815 */       char ch = stringPattern.charAt(i);
/* 2816 */       validCamelCase = (i == 0) ? ScannerHelper.isJavaIdentifierStart(ch) : ScannerHelper.isJavaIdentifierPart(ch);
/*      */ 
/*      */       
/* 2819 */       if (ScannerHelper.isUpperCase(ch)) uppercase++; 
/* 2820 */       if (i == 0) lowerCamelCase = (uppercase == 0); 
/*      */     } 
/* 2822 */     if (validCamelCase) {
/* 2823 */       validCamelCase = lowerCamelCase ? ((uppercase > 0)) : ((uppercase > 1));
/*      */     }
/* 2825 */     return validCamelCase;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public EntryResult[] queryIn(Index index) throws IOException {
/* 2833 */     return index.query(getIndexCategories(), getIndexKey(), getMatchRule());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2841 */     return "SearchPattern";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SearchPattern clone() throws CloneNotSupportedException {
/* 2849 */     return (SearchPattern)super.clone();
/*      */   }
/*      */   
/*      */   public abstract SearchPattern getBlankPattern();
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\search\SearchPattern.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */