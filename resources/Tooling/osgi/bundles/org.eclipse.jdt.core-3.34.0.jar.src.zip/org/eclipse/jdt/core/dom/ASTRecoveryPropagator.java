/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.compiler.CategorizedProblem;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.parser.RecoveryScanner;
/*     */ import org.eclipse.jdt.internal.compiler.parser.RecoveryScannerData;
/*     */ import org.eclipse.jdt.internal.compiler.util.HashtableOfObjectToIntArray;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ASTRecoveryPropagator
/*     */   extends DefaultASTVisitor
/*     */ {
/*     */   private static final int NOTHING = -1;
/*     */   private CategorizedProblem[] problems;
/*     */   private boolean[] usedOrIrrelevantProblems;
/*     */   private RecoveryScannerData data;
/*     */   private int blockDepth;
/*     */   private int lastEnd;
/*  34 */   HashtableOfObjectToIntArray endingTokens = new HashtableOfObjectToIntArray();
/*     */   ASTRecoveryPropagator(CategorizedProblem[] problems, RecoveryScannerData data) {
/*  36 */     this.endingTokens.put(AnonymousClassDeclaration.class, new int[] { 33 });
/*  37 */     this.endingTokens.put(ArrayAccess.class, new int[] { 69 });
/*  38 */     this.endingTokens.put(ArrayCreation.class, new int[] { -1, 69 });
/*  39 */     this.endingTokens.put(ArrayInitializer.class, new int[] { 33 });
/*  40 */     this.endingTokens.put(ArrayType.class, new int[] { 69 });
/*  41 */     this.endingTokens.put(AssertStatement.class, new int[] { 24 });
/*  42 */     this.endingTokens.put(Block.class, new int[] { 33 });
/*  43 */     this.endingTokens.put(BooleanLiteral.class, new int[] { 52, 54 });
/*  44 */     this.endingTokens.put(BreakStatement.class, new int[] { 24 });
/*  45 */     this.endingTokens.put(CharacterLiteral.class, new int[] { 59 });
/*  46 */     this.endingTokens.put(ClassInstanceCreation.class, new int[] { 33, 26 });
/*  47 */     this.endingTokens.put(ConstructorInvocation.class, new int[] { 24 });
/*  48 */     this.endingTokens.put(ContinueStatement.class, new int[] { 24 });
/*  49 */     this.endingTokens.put(DoStatement.class, new int[] { 26 });
/*  50 */     this.endingTokens.put(EmptyStatement.class, new int[] { 24 });
/*  51 */     this.endingTokens.put(ExpressionStatement.class, new int[] { 24 });
/*  52 */     this.endingTokens.put(FieldDeclaration.class, new int[] { 24 });
/*  53 */     this.endingTokens.put(ImportDeclaration.class, new int[] { 24 });
/*  54 */     this.endingTokens.put(Initializer.class, new int[] { 33 });
/*  55 */     this.endingTokens.put(MethodDeclaration.class, new int[] { -1, 24 });
/*  56 */     this.endingTokens.put(MethodInvocation.class, new int[] { 26 });
/*  57 */     this.endingTokens.put(ModuleDeclaration.class, new int[] { 33 });
/*  58 */     this.endingTokens.put(ModuleDirective.class, new int[] { 24 });
/*  59 */     this.endingTokens.put(NullLiteral.class, new int[] { 53 });
/*  60 */     this.endingTokens.put(NumberLiteral.class, new int[] { 55, 56, 57, 58 });
/*  61 */     this.endingTokens.put(PackageDeclaration.class, new int[] { 24 });
/*  62 */     this.endingTokens.put(ParenthesizedExpression.class, new int[] { 26 });
/*  63 */     this.endingTokens.put(PostfixExpression.class, new int[] { 2, 3 });
/*  64 */     this.endingTokens.put(PrimitiveType.class, new int[] { 106, 114, 108, 112, 113, 110, 105, 109, 115 });
/*  65 */     this.endingTokens.put(ReturnStatement.class, new int[] { 24 });
/*  66 */     this.endingTokens.put(SimpleName.class, new int[] { 19 });
/*  67 */     this.endingTokens.put(SingleVariableDeclaration.class, new int[] { 24 });
/*  68 */     this.endingTokens.put(StringLiteral.class, new int[] { 60 });
/*  69 */     this.endingTokens.put(SuperConstructorInvocation.class, new int[] { 24 });
/*  70 */     this.endingTokens.put(SuperMethodInvocation.class, new int[] { 26 });
/*  71 */     this.endingTokens.put(SwitchCase.class, new int[] { 65 });
/*  72 */     this.endingTokens.put(SwitchStatement.class, new int[] { 33 });
/*  73 */     this.endingTokens.put(SynchronizedStatement.class, new int[] { 33 });
/*  74 */     this.endingTokens.put(ThisExpression.class, new int[] { 36 });
/*  75 */     this.endingTokens.put(ThrowStatement.class, new int[] { 24 });
/*  76 */     this.endingTokens.put(TypeDeclaration.class, new int[] { 33 });
/*  77 */     this.endingTokens.put(TypeLiteral.class, new int[] { 70 });
/*  78 */     this.endingTokens.put(VariableDeclarationStatement.class, new int[] { 24 });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     this.blockDepth = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     this.stack = new ArrayList<>();
/*     */ 
/*     */ 
/*     */     
/*  99 */     this.problems = problems;
/* 100 */     this.usedOrIrrelevantProblems = new boolean[problems.length];
/*     */     
/* 102 */     this.data = data;
/*     */     
/* 104 */     if (this.data != null) {
/*     */       
/* 106 */       int length = 0;
/* 107 */       for (int i = 0; i < data.insertedTokensPtr + 1; i++) {
/* 108 */         length += (data.insertedTokens[i]).length;
/*     */       }
/* 110 */       this.insertedTokensKind = new int[length];
/* 111 */       this.insertedTokensPosition = new int[length];
/* 112 */       this.insertedTokensFlagged = new boolean[length];
/* 113 */       int tokenCount = 0;
/* 114 */       for (int j = 0; j < data.insertedTokensPtr + 1; j++) {
/* 115 */         for (int k = 0; k < (data.insertedTokens[j]).length; k++) {
/* 116 */           this.insertedTokensKind[tokenCount] = data.insertedTokens[j][k];
/* 117 */           this.insertedTokensPosition[tokenCount] = data.insertedTokensPosition[j];
/* 118 */           tokenCount++;
/*     */         } 
/*     */       } 
/*     */       
/* 122 */       if (data.removedTokensPtr != -1) {
/* 123 */         this.removedTokensFlagged = new boolean[data.removedTokensPtr + 1];
/*     */       }
/* 125 */       if (data.replacedTokensPtr != -1)
/* 126 */         this.replacedTokensFlagged = new boolean[data.replacedTokensPtr + 1]; 
/*     */     } 
/*     */   }
/*     */   
/*     */   private int[] insertedTokensKind;
/*     */   
/*     */   public void endVisit(Block node) {
/* 133 */     this.blockDepth--;
/* 134 */     if (this.blockDepth <= 0) {
/* 135 */       flagNodeWithInsertedTokens();
/*     */     }
/* 137 */     super.endVisit(node);
/*     */   }
/*     */   private int[] insertedTokensPosition; private boolean[] insertedTokensFlagged; private boolean[] removedTokensFlagged;
/*     */   private boolean[] replacedTokensFlagged;
/*     */   private ArrayList<ASTNode> stack;
/*     */   
/*     */   public boolean visit(Block node) {
/* 144 */     boolean visitChildren = super.visit(node);
/* 145 */     this.blockDepth++;
/* 146 */     return visitChildren;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean visitNode(ASTNode node) {
/* 151 */     if (this.blockDepth > 0) {
/* 152 */       int start = node.getStartPosition();
/* 153 */       int end = start + node.getLength() - 1;
/*     */ 
/*     */ 
/*     */       
/* 157 */       if (this.insertedTokensFlagged != null) {
/* 158 */         for (int i = 0; i < this.insertedTokensFlagged.length; i++) {
/* 159 */           if (this.insertedTokensPosition[i] >= start && 
/* 160 */             this.insertedTokensPosition[i] <= end) {
/* 161 */             return true;
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/* 166 */       if (this.removedTokensFlagged != null) {
/* 167 */         for (int i = 0; i <= this.data.removedTokensPtr; i++) {
/* 168 */           if (this.data.removedTokensStart[i] >= start && 
/* 169 */             this.data.removedTokensEnd[i] <= end) {
/* 170 */             return true;
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/* 175 */       if (this.replacedTokensFlagged != null) {
/* 176 */         for (int i = 0; i <= this.data.replacedTokensPtr; i++) {
/* 177 */           if (this.data.replacedTokensStart[i] >= start && 
/* 178 */             this.data.replacedTokensEnd[i] <= end) {
/* 179 */             return true;
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/* 184 */       return false;
/*     */     } 
/* 186 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void endVisitNode(ASTNode node) {
/* 191 */     int start = node.getStartPosition();
/* 192 */     int end = start + node.getLength() - 1;
/*     */ 
/*     */     
/* 195 */     if (this.blockDepth < 1) {
/* 196 */       switch (node.getNodeType()) {
/*     */         case 8:
/*     */         case 15:
/*     */         case 23:
/*     */         case 26:
/*     */         case 28:
/*     */         case 31:
/*     */         case 35:
/*     */         case 55:
/*     */         case 71:
/*     */         case 77:
/*     */         case 78:
/*     */         case 79:
/*     */         case 81:
/*     */         case 93:
/* 211 */           if (markIncludedProblems(start, end)) {
/* 212 */             node.setFlags(node.getFlags() | 0x8);
/*     */           }
/*     */           break;
/*     */       } 
/*     */     } else {
/* 217 */       markIncludedProblems(start, end);
/*     */       
/* 219 */       if (this.insertedTokensFlagged != null) {
/* 220 */         if (this.lastEnd != end) {
/* 221 */           flagNodeWithInsertedTokens();
/*     */         }
/* 223 */         this.stack.add(node);
/*     */       } 
/*     */       
/* 226 */       if (this.removedTokensFlagged != null) {
/* 227 */         for (int i = 0; i <= this.data.removedTokensPtr; i++) {
/* 228 */           if (!this.removedTokensFlagged[i] && 
/* 229 */             this.data.removedTokensStart[i] >= start && 
/* 230 */             this.data.removedTokensEnd[i] <= end) {
/* 231 */             node.setFlags(node.getFlags() | 0x8);
/* 232 */             this.removedTokensFlagged[i] = true;
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 237 */       if (this.replacedTokensFlagged != null) {
/* 238 */         for (int i = 0; i <= this.data.replacedTokensPtr; i++) {
/* 239 */           if (!this.replacedTokensFlagged[i] && 
/* 240 */             this.data.replacedTokensStart[i] >= start && 
/* 241 */             this.data.replacedTokensEnd[i] <= end) {
/* 242 */             node.setFlags(node.getFlags() | 0x8);
/* 243 */             this.replacedTokensFlagged[i] = true;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/* 248 */     this.lastEnd = end;
/*     */   }
/*     */   
/*     */   private void flagNodeWithInsertedTokens() {
/* 252 */     if (this.insertedTokensKind != null && this.insertedTokensKind.length > 0) {
/* 253 */       int s = this.stack.size(); int i;
/* 254 */       for (i = s - 1; i > -1; i--) {
/* 255 */         flagNodesWithInsertedTokensAtEnd(this.stack.get(i));
/*     */       }
/* 257 */       for (i = 0; i < s; i++) {
/* 258 */         flagNodesWithInsertedTokensInside(this.stack.get(i));
/*     */       }
/* 260 */       this.stack = new ArrayList<>();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean flagNodesWithInsertedTokensAtEnd(ASTNode node) {
/* 265 */     int[] expectedEndingToken = this.endingTokens.get(node.getClass());
/* 266 */     if (expectedEndingToken != null) {
/* 267 */       int start = node.getStartPosition();
/* 268 */       int end = start + node.getLength() - 1;
/*     */       
/* 270 */       boolean flagParent = false; int i;
/* 271 */       label30: for (i = this.insertedTokensKind.length - 1; i > -1; i--) {
/* 272 */         if (!this.insertedTokensFlagged[i] && 
/* 273 */           this.insertedTokensPosition[i] == end) {
/* 274 */           this.insertedTokensFlagged[i] = true;
/* 275 */           for (int j = 0; j < expectedEndingToken.length; j++) {
/* 276 */             if (expectedEndingToken[j] == this.insertedTokensKind[i]) {
/* 277 */               node.setFlags(node.getFlags() | 0x8);
/*     */               break label30;
/*     */             } 
/*     */           } 
/* 281 */           flagParent = true;
/*     */         } 
/*     */       } 
/*     */       
/* 285 */       if (flagParent) {
/* 286 */         ASTNode parent = node.getParent();
/* 287 */         while (parent != null) {
/* 288 */           parent.setFlags(node.getFlags() | 0x8);
/* 289 */           if (parent.getStartPosition() + parent.getLength() - 1 != end) {
/* 290 */             parent = null; continue;
/*     */           } 
/* 292 */           parent = parent.getParent();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 297 */     return true;
/*     */   }
/*     */   
/*     */   private boolean flagNodesWithInsertedTokensInside(ASTNode node) {
/* 301 */     int start = node.getStartPosition();
/* 302 */     int end = start + node.getLength() - 1;
/* 303 */     for (int i = 0; i < this.insertedTokensKind.length; i++) {
/* 304 */       if (!this.insertedTokensFlagged[i] && 
/* 305 */         start <= this.insertedTokensPosition[i] && 
/* 306 */         this.insertedTokensPosition[i] < end) {
/* 307 */         node.setFlags(node.getFlags() | 0x8);
/* 308 */         this.insertedTokensFlagged[i] = true;
/*     */       } 
/*     */     } 
/* 311 */     return true;
/*     */   }
/*     */   
/*     */   private boolean markIncludedProblems(int start, int end) {
/* 315 */     boolean foundProblems = false;
/* 316 */     for (int i = 0, max = this.problems.length; i < max; i++) {
/* 317 */       CategorizedProblem problem = this.problems[i];
/*     */       
/* 319 */       if (!this.usedOrIrrelevantProblems[i]) {
/*     */         
/* 321 */         switch (problem.getID()) {
/*     */           case 1610612940:
/*     */           case 1610612941:
/*     */           case 1610612945:
/*     */           case 1610612946:
/*     */           case 1610612966:
/*     */           case 1610612967:
/*     */           case 1610612968:
/*     */           case 1610612969:
/*     */           case 1610612970:
/*     */           case 1610612971:
/*     */           case 1610612972:
/*     */           case 1610612973:
/*     */           case 1610612974:
/*     */           case 1610612975:
/*     */           case 1610612976:
/*     */           case 1610612977:
/*     */           case 1610612978:
/*     */           case 1610612986:
/*     */           case 1610612987:
/*     */           case 1610612988:
/*     */           case 1610612989:
/*     */           case 1610612990:
/*     */           case 1610612991:
/*     */           case 1610612992:
/*     */           case 1610612993:
/*     */           case 1610612994:
/*     */           case 1610612995:
/*     */           case 1610612996:
/*     */           case 1610612998:
/*     */             break;
/*     */           default:
/* 353 */             this.usedOrIrrelevantProblems[i] = true;
/*     */             i++;
/*     */             continue;
/*     */         } 
/*     */         
/* 358 */         int problemStart = problem.getSourceStart();
/* 359 */         int problemEnd = problem.getSourceEnd();
/* 360 */         if ((start <= problemStart && problemStart <= end) || (
/* 361 */           start <= problemEnd && problemEnd <= end)) {
/* 362 */           this.usedOrIrrelevantProblems[i] = true;
/* 363 */           foundProblems = true;
/*     */         } 
/*     */       } 
/* 366 */     }  return foundProblems;
/*     */   }
/*     */ 
/*     */   
/*     */   public void endVisit(ExpressionStatement node) {
/* 371 */     endVisitNode(node);
/* 372 */     if ((node.getFlags() & 0x8) == 0)
/* 373 */       return;  Expression expression = node.getExpression();
/* 374 */     if (expression.getNodeType() == 7) {
/* 375 */       Assignment assignment = (Assignment)expression;
/* 376 */       Expression rightHandSide = assignment.getRightHandSide();
/* 377 */       if (rightHandSide.getNodeType() == 42) {
/* 378 */         SimpleName simpleName = (SimpleName)rightHandSide;
/* 379 */         if (CharOperation.equals(RecoveryScanner.FAKE_IDENTIFIER, simpleName.getIdentifier().toCharArray())) {
/* 380 */           Expression expression2 = assignment.getLeftHandSide();
/*     */           
/* 382 */           expression2.setParent(null, null);
/* 383 */           expression2.setFlags(expression2.getFlags() | 0x8);
/* 384 */           node.setExpression(expression2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void endVisit(ForStatement node) {
/* 392 */     endVisitNode(node);
/* 393 */     List<Expression> initializers = node.initializers();
/* 394 */     if (initializers.size() == 1) {
/* 395 */       Expression expression = initializers.get(0);
/* 396 */       if (expression.getNodeType() == 58) {
/* 397 */         VariableDeclarationExpression variableDeclarationExpression = (VariableDeclarationExpression)expression;
/* 398 */         List<VariableDeclarationFragment> fragments = variableDeclarationExpression.fragments();
/* 399 */         for (int i = 0, max = fragments.size(); i < max; i++) {
/* 400 */           VariableDeclarationFragment fragment = fragments.get(i);
/* 401 */           SimpleName simpleName = fragment.getName();
/* 402 */           if (CharOperation.equals(RecoveryScanner.FAKE_IDENTIFIER, simpleName.getIdentifier().toCharArray())) {
/* 403 */             fragments.remove(fragment);
/* 404 */             variableDeclarationExpression.setFlags(variableDeclarationExpression.getFlags() | 0x8);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void endVisit(VariableDeclarationStatement node) {
/* 413 */     endVisitNode(node);
/* 414 */     List<VariableDeclarationFragment> fragments = node.fragments();
/* 415 */     for (int i = 0, max = fragments.size(); i < max; i++) {
/* 416 */       VariableDeclarationFragment fragment = fragments.get(i);
/* 417 */       Expression expression = fragment.getInitializer();
/* 418 */       if (expression != null && (
/* 419 */         expression.getFlags() & 0x8) != 0 && 
/* 420 */         expression.getNodeType() == 42) {
/* 421 */         SimpleName simpleName = (SimpleName)expression;
/* 422 */         if (CharOperation.equals(RecoveryScanner.FAKE_IDENTIFIER, simpleName.getIdentifier().toCharArray())) {
/* 423 */           fragment.setInitializer((Expression)null);
/* 424 */           fragment.setFlags(fragment.getFlags() | 0x8);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void endVisit(NormalAnnotation node) {
/* 432 */     endVisitNode(node);
/*     */     
/* 434 */     if (this.blockDepth < 1) {
/* 435 */       List<MemberValuePair> values = node.values();
/* 436 */       int size = values.size();
/* 437 */       if (size > 0) {
/* 438 */         MemberValuePair lastMemberValuePair = values.get(size - 1);
/*     */         
/* 440 */         int annotationEnd = node.getStartPosition() + node.getLength();
/* 441 */         int lastMemberValuePairEnd = lastMemberValuePair.getStartPosition() + lastMemberValuePair.getLength();
/* 442 */         if (annotationEnd == lastMemberValuePairEnd) {
/* 443 */           node.setFlags(node.getFlags() | 0x8);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void endVisit(SingleMemberAnnotation node) {
/* 451 */     endVisitNode(node);
/*     */     
/* 453 */     if (this.blockDepth < 1) {
/* 454 */       Expression value = node.getValue();
/* 455 */       int annotationEnd = node.getStartPosition() + node.getLength();
/* 456 */       int valueEnd = value.getStartPosition() + value.getLength();
/* 457 */       if (annotationEnd == valueEnd)
/* 458 */         node.setFlags(node.getFlags() | 0x8); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ASTRecoveryPropagator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */