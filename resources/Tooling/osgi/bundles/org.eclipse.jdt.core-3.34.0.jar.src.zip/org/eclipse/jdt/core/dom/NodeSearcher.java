/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ASTVisitor;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*     */ import org.eclipse.jdt.internal.compiler.ast.ConstructorDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.FieldDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Initializer;
/*     */ import org.eclipse.jdt.internal.compiler.ast.MethodDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.CompilationUnitScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NodeSearcher
/*     */   extends ASTVisitor
/*     */ {
/*     */   public ASTNode found;
/*     */   public TypeDeclaration enclosingType;
/*     */   public int position;
/*     */   
/*     */   NodeSearcher(int position) {
/*  32 */     this.position = position;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visit(ConstructorDeclaration constructorDeclaration, ClassScope scope) {
/*  40 */     if (constructorDeclaration.declarationSourceStart <= this.position && 
/*  41 */       this.position <= constructorDeclaration.declarationSourceEnd) {
/*  42 */       this.found = (ASTNode)constructorDeclaration;
/*  43 */       return false;
/*     */     } 
/*  45 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visit(FieldDeclaration fieldDeclaration, MethodScope scope) {
/*  52 */     if (fieldDeclaration.declarationSourceStart <= this.position && 
/*  53 */       this.position <= fieldDeclaration.declarationSourceEnd) {
/*  54 */       this.found = (ASTNode)fieldDeclaration;
/*  55 */       return false;
/*     */     } 
/*  57 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(Initializer initializer, MethodScope scope) {
/*  62 */     if (initializer.declarationSourceStart <= this.position && 
/*  63 */       this.position <= initializer.declarationSourceEnd) {
/*  64 */       this.found = (ASTNode)initializer;
/*  65 */       return false;
/*     */     } 
/*  67 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visit(TypeDeclaration memberTypeDeclaration, ClassScope scope) {
/*  74 */     if (memberTypeDeclaration.declarationSourceStart <= this.position && 
/*  75 */       this.position <= memberTypeDeclaration.declarationSourceEnd) {
/*  76 */       this.enclosingType = memberTypeDeclaration;
/*  77 */       return true;
/*     */     } 
/*     */     
/*  80 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visit(MethodDeclaration methodDeclaration, ClassScope scope) {
/*  88 */     if (methodDeclaration.declarationSourceStart <= this.position && 
/*  89 */       this.position <= methodDeclaration.declarationSourceEnd) {
/*  90 */       this.found = (ASTNode)methodDeclaration;
/*  91 */       return false;
/*     */     } 
/*  93 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visit(TypeDeclaration typeDeclaration, CompilationUnitScope scope) {
/* 100 */     if (typeDeclaration.declarationSourceStart <= this.position && 
/* 101 */       this.position <= typeDeclaration.declarationSourceEnd) {
/* 102 */       this.enclosingType = typeDeclaration;
/* 103 */       return true;
/*     */     } 
/* 105 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\NodeSearcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */