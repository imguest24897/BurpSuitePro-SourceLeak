/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LambdaExpression
/*     */   extends Expression
/*     */ {
/*  48 */   public static final SimplePropertyDescriptor PARENTHESES_PROPERTY = new SimplePropertyDescriptor(LambdaExpression.class, "parentheses", boolean.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public static final ChildListPropertyDescriptor PARAMETERS_PROPERTY = new ChildListPropertyDescriptor(LambdaExpression.class, "parameters", VariableDeclaration.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public static final ChildPropertyDescriptor BODY_PROPERTY = new ChildPropertyDescriptor(LambdaExpression.class, "body", ASTNode.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_8_0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  74 */     List propertyList = new ArrayList(4);
/*  75 */     createPropertyList(LambdaExpression.class, propertyList);
/*  76 */     addProperty(PARENTHESES_PROPERTY, propertyList);
/*  77 */     addProperty(PARAMETERS_PROPERTY, propertyList);
/*  78 */     addProperty(BODY_PROPERTY, propertyList);
/*  79 */     PROPERTY_DESCRIPTORS_8_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  91 */     return PROPERTY_DESCRIPTORS_8_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasParentheses = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   private ASTNode.NodeList parameters = new ASTNode.NodeList(this, PARAMETERS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   private ASTNode body = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LambdaExpression(AST ast) {
/* 126 */     super(ast);
/* 127 */     unsupportedIn2_3_4();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 132 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final boolean internalGetSetBooleanProperty(SimplePropertyDescriptor property, boolean get, boolean value) {
/* 137 */     if (property == PARENTHESES_PROPERTY) {
/* 138 */       if (get) {
/* 139 */         return hasParentheses();
/*     */       }
/* 141 */       setParentheses(value);
/* 142 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 146 */     return super.internalGetSetBooleanProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 151 */     if (property == PARAMETERS_PROPERTY) {
/* 152 */       return parameters();
/*     */     }
/*     */     
/* 155 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 160 */     if (property == BODY_PROPERTY) {
/* 161 */       if (get) {
/* 162 */         return getBody();
/*     */       }
/* 164 */       setBody(child);
/* 165 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 169 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 174 */     return 86;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 179 */     LambdaExpression result = new LambdaExpression(target);
/* 180 */     result.setSourceRange(getStartPosition(), getLength());
/* 181 */     result.setParentheses(hasParentheses());
/* 182 */     result.parameters().addAll(ASTNode.copySubtrees(target, parameters()));
/* 183 */     result.setBody(ASTNode.copySubtree(target, getBody()));
/* 184 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 190 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 195 */     boolean visitChildren = visitor.visit(this);
/* 196 */     if (visitChildren) {
/*     */       
/* 198 */       acceptChildren(visitor, this.parameters);
/* 199 */       acceptChild(visitor, getBody());
/*     */     } 
/* 201 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasParentheses() {
/* 216 */     return this.hasParentheses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParentheses(boolean hasParentheses) {
/* 231 */     preValueChange(PARENTHESES_PROPERTY);
/* 232 */     this.hasParentheses = hasParentheses;
/* 233 */     postValueChange(PARENTHESES_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List parameters() {
/* 248 */     return this.parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ASTNode getBody() {
/* 257 */     if (this.body == null)
/*     */     {
/* 259 */       synchronized (this) {
/* 260 */         if (this.body == null) {
/* 261 */           preLazyInit();
/* 262 */           this.body = new Block(this.ast);
/* 263 */           postLazyInit(this.body, BODY_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 267 */     return this.body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBody(ASTNode body) {
/* 283 */     if (!(body instanceof Expression) && !(body instanceof Block)) {
/* 284 */       throw new IllegalArgumentException();
/*     */     }
/* 286 */     ASTNode oldChild = this.body;
/* 287 */     preReplaceChild(oldChild, body, BODY_PROPERTY);
/* 288 */     this.body = body;
/* 289 */     postReplaceChild(oldChild, body, BODY_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMethodBinding resolveMethodBinding() {
/* 303 */     return this.ast.getBindingResolver().resolveMethod(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 308 */     return 52;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 313 */     return 
/* 314 */       memSize() + 
/* 315 */       this.parameters.listSize() + (
/* 316 */       (this.body == null) ? 0 : getBody().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\LambdaExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */