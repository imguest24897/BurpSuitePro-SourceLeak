/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ import org.eclipse.jdt.internal.compiler.ast.Argument;
/*    */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnArgumentName
/*    */   extends Argument
/*    */ {
/* 29 */   private static final char[] FAKENAMESUFFIX = " ".toCharArray();
/*    */   
/*    */   public char[] realName;
/*    */   public boolean isCatchArgument = false;
/*    */   
/*    */   public CompletionOnArgumentName(char[] name, long posNom, TypeReference tr, int modifiers) {
/* 35 */     super(CharOperation.concat(name, FAKENAMESUFFIX), posNom, tr, modifiers);
/* 36 */     this.realName = name;
/*    */   }
/*    */   
/*    */   public CompletionOnArgumentName(Argument typeElidedArgument, long posNom) {
/* 40 */     super(typeElidedArgument.name, posNom, null, 0, true);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeBinding bind(MethodScope scope, TypeBinding typeBinding, boolean used) {
/* 46 */     super.bind(scope, typeBinding, used);
/* 47 */     throw new CompletionNodeFound(this, scope);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public StringBuffer print(int indent, StringBuffer output) {
/* 53 */     printIndent(indent, output);
/* 54 */     output.append("<CompleteOnArgumentName:");
/* 55 */     if (this.type != null) this.type.print(0, output).append(' '); 
/* 56 */     output.append(this.realName);
/* 57 */     if (this.initialization != null) {
/* 58 */       output.append(" = ");
/* 59 */       this.initialization.printExpression(0, output);
/*    */     } 
/* 61 */     return output.append('>');
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void resolve(BlockScope scope) {
/* 67 */     super.resolve(scope);
/* 68 */     throw new CompletionNodeFound(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnArgumentName.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */