/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TextElement
/*     */   extends AbstractTextElement
/*     */ {
/*  42 */   public static final SimplePropertyDescriptor TEXT_PROPERTY = internalTextPropertyFactory(TextElement.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  53 */     List propertyList = new ArrayList(2);
/*  54 */     createPropertyList(TextElement.class, propertyList);
/*  55 */     addProperty(TEXT_PROPERTY, propertyList);
/*  56 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  70 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */   
/*     */   final SimplePropertyDescriptor internalTextPropertyFactory() {
/*  75 */     return TEXT_PROPERTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TextElement(AST ast) {
/*  90 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  95 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 101 */     return 66;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 106 */     TextElement result = new TextElement(target);
/* 107 */     result.setSourceRange(getStartPosition(), getLength());
/* 108 */     result.setText(getText());
/* 109 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 115 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 120 */     visitor.visit(this);
/* 121 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(String text) {
/* 139 */     super.setText(text);
/* 140 */     if (text.indexOf("*/") > 0) {
/* 141 */       throw new IllegalArgumentException();
/*     */     }
/* 143 */     preValueChange(TEXT_PROPERTY);
/* 144 */     this.text = text;
/* 145 */     postValueChange(TEXT_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 150 */     int size = 44;
/* 151 */     if (this.text != Util.EMPTY_STRING)
/*     */     {
/* 153 */       size += stringSize(this.text);
/*     */     }
/* 155 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 160 */     return memSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\TextElement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */