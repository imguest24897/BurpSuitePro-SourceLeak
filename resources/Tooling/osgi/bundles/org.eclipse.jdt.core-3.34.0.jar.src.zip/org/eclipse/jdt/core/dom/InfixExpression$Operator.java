/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Operator
/*     */ {
/*     */   private String token;
/*     */   
/*     */   private Operator(String token) {
/*  77 */     this.token = token;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  87 */     return this.token;
/*     */   }
/*     */ 
/*     */   
/*  91 */   public static final Operator TIMES = new Operator("*");
/*     */   
/*  93 */   public static final Operator DIVIDE = new Operator("/");
/*     */   
/*  95 */   public static final Operator REMAINDER = new Operator("%");
/*     */   
/*  97 */   public static final Operator PLUS = new Operator("+");
/*     */   
/*  99 */   public static final Operator MINUS = new Operator("-");
/*     */   
/* 101 */   public static final Operator LEFT_SHIFT = new Operator("<<");
/*     */   
/* 103 */   public static final Operator RIGHT_SHIFT_SIGNED = new Operator(">>");
/*     */ 
/*     */   
/* 106 */   public static final Operator RIGHT_SHIFT_UNSIGNED = new Operator(">>>");
/*     */   
/* 108 */   public static final Operator LESS = new Operator("<");
/*     */   
/* 110 */   public static final Operator GREATER = new Operator(">");
/*     */   
/* 112 */   public static final Operator LESS_EQUALS = new Operator("<=");
/*     */   
/* 114 */   public static final Operator GREATER_EQUALS = new Operator(">=");
/*     */   
/* 116 */   public static final Operator EQUALS = new Operator("==");
/*     */   
/* 118 */   public static final Operator NOT_EQUALS = new Operator("!=");
/*     */   
/* 120 */   public static final Operator XOR = new Operator("^");
/*     */   
/* 122 */   public static final Operator OR = new Operator("|");
/*     */   
/* 124 */   public static final Operator AND = new Operator("&");
/*     */   
/* 126 */   public static final Operator CONDITIONAL_OR = new Operator("||");
/*     */   
/* 128 */   public static final Operator CONDITIONAL_AND = new Operator("&&");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   private static final Map CODES = new HashMap<>(20); static {
/* 137 */     Operator[] ops = { 
/* 138 */         TIMES, 
/* 139 */         DIVIDE, 
/* 140 */         REMAINDER, 
/* 141 */         PLUS, 
/* 142 */         MINUS, 
/* 143 */         LEFT_SHIFT, 
/* 144 */         RIGHT_SHIFT_SIGNED, 
/* 145 */         RIGHT_SHIFT_UNSIGNED, 
/* 146 */         LESS, 
/* 147 */         GREATER, 
/* 148 */         LESS_EQUALS, 
/* 149 */         GREATER_EQUALS, 
/* 150 */         EQUALS, 
/* 151 */         NOT_EQUALS, 
/* 152 */         XOR, 
/* 153 */         OR, 
/* 154 */         AND, 
/* 155 */         CONDITIONAL_OR, 
/* 156 */         CONDITIONAL_AND };
/*     */     
/* 158 */     for (int i = 0; i < ops.length; i++) {
/* 159 */       CODES.put(ops[i].toString(), ops[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Operator toOperator(String token) {
/* 176 */     return (Operator)CODES.get(token);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\InfixExpression$Operator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */