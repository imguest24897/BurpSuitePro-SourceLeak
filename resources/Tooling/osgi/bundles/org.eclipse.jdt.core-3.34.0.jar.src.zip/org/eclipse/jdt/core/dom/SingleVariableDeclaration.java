/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SingleVariableDeclaration
/*     */   extends VariableDeclaration
/*     */ {
/*  46 */   public static final SimplePropertyDescriptor MODIFIERS_PROPERTY = new SimplePropertyDescriptor(SingleVariableDeclaration.class, "modifiers", int.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public static final ChildListPropertyDescriptor MODIFIERS2_PROPERTY = new ChildListPropertyDescriptor(SingleVariableDeclaration.class, "modifiers", IExtendedModifier.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public static final ChildPropertyDescriptor TYPE_PROPERTY = new ChildPropertyDescriptor(SingleVariableDeclaration.class, "type", Type.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public static final ChildListPropertyDescriptor VARARGS_ANNOTATIONS_PROPERTY = new ChildListPropertyDescriptor(SingleVariableDeclaration.class, "varargsAnnotations", Annotation.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   public static final SimplePropertyDescriptor VARARGS_PROPERTY = new SimplePropertyDescriptor(SingleVariableDeclaration.class, "varargs", boolean.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   public static final ChildPropertyDescriptor NAME_PROPERTY = internalNamePropertyFactory(SingleVariableDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public static final SimplePropertyDescriptor EXTRA_DIMENSIONS_PROPERTY = internalExtraDimensionsPropertyFactory(SingleVariableDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public static final ChildListPropertyDescriptor EXTRA_DIMENSIONS2_PROPERTY = internalExtraDimensions2PropertyFactory(SingleVariableDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public static final ChildPropertyDescriptor INITIALIZER_PROPERTY = internalInitializerPropertyFactory(SingleVariableDeclaration.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_8_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 133 */     List propertyList = new ArrayList(6);
/* 134 */     createPropertyList(SingleVariableDeclaration.class, propertyList);
/* 135 */     addProperty(MODIFIERS_PROPERTY, propertyList);
/* 136 */     addProperty(TYPE_PROPERTY, propertyList);
/* 137 */     addProperty(NAME_PROPERTY, propertyList);
/* 138 */     addProperty(EXTRA_DIMENSIONS_PROPERTY, propertyList);
/* 139 */     addProperty(INITIALIZER_PROPERTY, propertyList);
/* 140 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(propertyList);
/*     */     
/* 142 */     propertyList = new ArrayList(7);
/* 143 */     createPropertyList(SingleVariableDeclaration.class, propertyList);
/* 144 */     addProperty(MODIFIERS2_PROPERTY, propertyList);
/* 145 */     addProperty(TYPE_PROPERTY, propertyList);
/* 146 */     addProperty(VARARGS_PROPERTY, propertyList);
/* 147 */     addProperty(NAME_PROPERTY, propertyList);
/* 148 */     addProperty(EXTRA_DIMENSIONS_PROPERTY, propertyList);
/* 149 */     addProperty(INITIALIZER_PROPERTY, propertyList);
/* 150 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(propertyList);
/*     */     
/* 152 */     propertyList = new ArrayList(8);
/* 153 */     createPropertyList(SingleVariableDeclaration.class, propertyList);
/* 154 */     addProperty(MODIFIERS2_PROPERTY, propertyList);
/* 155 */     addProperty(TYPE_PROPERTY, propertyList);
/* 156 */     addProperty(VARARGS_ANNOTATIONS_PROPERTY, propertyList);
/* 157 */     addProperty(VARARGS_PROPERTY, propertyList);
/* 158 */     addProperty(NAME_PROPERTY, propertyList);
/* 159 */     addProperty(EXTRA_DIMENSIONS2_PROPERTY, propertyList);
/* 160 */     addProperty(INITIALIZER_PROPERTY, propertyList);
/* 161 */     PROPERTY_DESCRIPTORS_8_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 175 */     if (apiLevel == 2)
/* 176 */       return PROPERTY_DESCRIPTORS_2_0; 
/* 177 */     if (apiLevel < 8) {
/* 178 */       return PROPERTY_DESCRIPTORS_3_0;
/*     */     }
/* 180 */     return PROPERTY_DESCRIPTORS_8_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   private ASTNode.NodeList modifiers = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 197 */   private int modifierFlags = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 203 */   private Type type = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 212 */   private ASTNode.NodeList varargsAnnotations = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean variableArity = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SingleVariableDeclaration(AST ast) {
/* 234 */     super(ast);
/* 235 */     if (ast.apiLevel >= 3) {
/* 236 */       this.modifiers = new ASTNode.NodeList(this, MODIFIERS2_PROPERTY);
/* 237 */       if (ast.apiLevel >= 8) {
/* 238 */         this.varargsAnnotations = new ASTNode.NodeList(this, VARARGS_ANNOTATIONS_PROPERTY);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalNameProperty() {
/* 245 */     return NAME_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final SimplePropertyDescriptor internalExtraDimensionsProperty() {
/* 250 */     return EXTRA_DIMENSIONS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalExtraDimensions2Property() {
/* 255 */     return EXTRA_DIMENSIONS2_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalInitializerProperty() {
/* 260 */     return INITIALIZER_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 265 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final int internalGetSetIntProperty(SimplePropertyDescriptor property, boolean get, int value) {
/* 270 */     if (property == MODIFIERS_PROPERTY) {
/* 271 */       if (get) {
/* 272 */         return getModifiers();
/*     */       }
/* 274 */       setModifiers(value);
/* 275 */       return 0;
/*     */     } 
/*     */     
/* 278 */     if (property == EXTRA_DIMENSIONS_PROPERTY) {
/* 279 */       if (get) {
/* 280 */         return getExtraDimensions();
/*     */       }
/* 282 */       internalSetExtraDimensions(value);
/* 283 */       return 0;
/*     */     } 
/*     */ 
/*     */     
/* 287 */     return super.internalGetSetIntProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final boolean internalGetSetBooleanProperty(SimplePropertyDescriptor property, boolean get, boolean value) {
/* 292 */     if (property == VARARGS_PROPERTY) {
/* 293 */       if (get) {
/* 294 */         return isVarargs();
/*     */       }
/* 296 */       setVarargs(value);
/* 297 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 301 */     return super.internalGetSetBooleanProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 306 */     if (property == TYPE_PROPERTY) {
/* 307 */       if (get) {
/* 308 */         return getType();
/*     */       }
/* 310 */       setType((Type)child);
/* 311 */       return null;
/*     */     } 
/*     */     
/* 314 */     if (property == NAME_PROPERTY) {
/* 315 */       if (get) {
/* 316 */         return getName();
/*     */       }
/* 318 */       setName((SimpleName)child);
/* 319 */       return null;
/*     */     } 
/*     */     
/* 322 */     if (property == INITIALIZER_PROPERTY) {
/* 323 */       if (get) {
/* 324 */         return getInitializer();
/*     */       }
/* 326 */       setInitializer((Expression)child);
/* 327 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 331 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 336 */     if (property == MODIFIERS2_PROPERTY) {
/* 337 */       return modifiers();
/*     */     }
/* 339 */     if (property == VARARGS_ANNOTATIONS_PROPERTY) {
/* 340 */       return varargsAnnotations();
/*     */     }
/* 342 */     if (property == EXTRA_DIMENSIONS2_PROPERTY) {
/* 343 */       return extraDimensions();
/*     */     }
/*     */     
/* 346 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 351 */     return 44;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 356 */     SingleVariableDeclaration result = new SingleVariableDeclaration(target);
/* 357 */     result.setSourceRange(getStartPosition(), getLength());
/* 358 */     if (this.ast.apiLevel == 2) {
/* 359 */       result.setModifiers(getModifiers());
/*     */     } else {
/* 361 */       result.modifiers().addAll(ASTNode.copySubtrees(target, modifiers()));
/* 362 */       result.setVarargs(isVarargs());
/*     */     } 
/* 364 */     result.setType((Type)getType().clone(target));
/* 365 */     if (this.ast.apiLevel >= 8) {
/* 366 */       result.varargsAnnotations().addAll(
/* 367 */           ASTNode.copySubtrees(target, varargsAnnotations()));
/*     */     }
/* 369 */     result.setName((SimpleName)getName().clone(target));
/* 370 */     if (this.ast.apiLevel >= 8) {
/* 371 */       result.extraDimensions().addAll(
/* 372 */           ASTNode.copySubtrees(target, extraDimensions()));
/*     */     } else {
/* 374 */       result.internalSetExtraDimensions(getExtraDimensions());
/*     */     } 
/* 376 */     result.setInitializer(
/* 377 */         (Expression)ASTNode.copySubtree(target, getInitializer()));
/* 378 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 384 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 389 */     boolean visitChildren = visitor.visit(this);
/* 390 */     if (visitChildren) {
/*     */       
/* 392 */       if (this.ast.apiLevel >= 3) {
/* 393 */         acceptChildren(visitor, this.modifiers);
/*     */       }
/* 395 */       acceptChild(visitor, getType());
/* 396 */       if (this.ast.apiLevel >= 8 && isVarargs()) {
/* 397 */         acceptChildren(visitor, this.varargsAnnotations);
/*     */       }
/* 399 */       acceptChild(visitor, getName());
/* 400 */       if (this.ast.apiLevel >= 8) {
/* 401 */         acceptChildren(visitor, this.extraDimensions);
/*     */       }
/* 403 */       acceptChild(visitor, getInitializer());
/*     */     } 
/* 405 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List modifiers() {
/* 424 */     if (this.modifiers == null) {
/* 425 */       unsupportedIn2();
/*     */     }
/* 427 */     return this.modifiers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 442 */     if (this.modifiers == null)
/*     */     {
/* 444 */       return this.modifierFlags;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 449 */     int computedModifierFlags = 0;
/* 450 */     for (Iterator it = modifiers().iterator(); it.hasNext(); ) {
/* 451 */       Object x = it.next();
/* 452 */       if (x instanceof Modifier) {
/* 453 */         computedModifierFlags |= ((Modifier)x).getKeyword().toFlagValue();
/*     */       }
/*     */     } 
/* 456 */     return computedModifierFlags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModifiers(int modifiers) {
/* 476 */     internalSetModifiers(modifiers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void internalSetModifiers(int pmodifiers) {
/* 485 */     supportedOnlyIn2();
/* 486 */     preValueChange(MODIFIERS_PROPERTY);
/* 487 */     this.modifierFlags = pmodifiers;
/* 488 */     postValueChange(MODIFIERS_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 504 */     if (this.type == null)
/*     */     {
/* 506 */       synchronized (this) {
/* 507 */         if (this.type == null) {
/* 508 */           preLazyInit();
/* 509 */           this.type = this.ast.newPrimitiveType(PrimitiveType.INT);
/* 510 */           postLazyInit(this.type, TYPE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 514 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(Type type) {
/* 529 */     if (type == null) {
/* 530 */       throw new IllegalArgumentException();
/*     */     }
/* 532 */     ASTNode oldChild = this.type;
/* 533 */     preReplaceChild(oldChild, type, TYPE_PROPERTY);
/* 534 */     this.type = type;
/* 535 */     postReplaceChild(oldChild, type, TYPE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVarargs() {
/* 565 */     if (this.modifiers == null) {
/* 566 */       unsupportedIn2();
/*     */     }
/* 568 */     return this.variableArity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVarargs(boolean variableArity) {
/* 581 */     if (this.modifiers == null) {
/* 582 */       unsupportedIn2();
/*     */     }
/* 584 */     preValueChange(VARARGS_PROPERTY);
/* 585 */     this.variableArity = variableArity;
/* 586 */     postValueChange(VARARGS_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List varargsAnnotations() {
/* 605 */     if (this.varargsAnnotations == null) {
/* 606 */       unsupportedIn2_3_4();
/*     */     }
/* 608 */     return this.varargsAnnotations;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 614 */     return 76;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 619 */     return 
/* 620 */       memSize() + (
/* 621 */       (this.modifiers == null) ? 0 : this.modifiers.listSize()) + (
/* 622 */       (this.type == null) ? 0 : getType().treeSize()) + (
/* 623 */       (this.varargsAnnotations == null) ? 0 : this.varargsAnnotations.listSize()) + (
/* 624 */       (this.variableName == null) ? 0 : getName().treeSize()) + (
/* 625 */       (this.extraDimensions == null) ? 0 : this.extraDimensions.listSize()) + (
/* 626 */       (this.optionalInitializer == null) ? 0 : getInitializer().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\SingleVariableDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */