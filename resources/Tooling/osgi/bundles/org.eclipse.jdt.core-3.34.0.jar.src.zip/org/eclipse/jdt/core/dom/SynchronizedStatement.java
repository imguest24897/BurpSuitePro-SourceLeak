/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SynchronizedStatement
/*     */   extends Statement
/*     */ {
/*  39 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(SynchronizedStatement.class, "expression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final ChildPropertyDescriptor BODY_PROPERTY = new ChildPropertyDescriptor(SynchronizedStatement.class, "body", Block.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  56 */     List propertyList = new ArrayList(3);
/*  57 */     createPropertyList(SynchronizedStatement.class, propertyList);
/*  58 */     addProperty(EXPRESSION_PROPERTY, propertyList);
/*  59 */     addProperty(BODY_PROPERTY, propertyList);
/*  60 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  75 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private Expression expression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private Block body = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SynchronizedStatement(AST ast) {
/* 100 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 105 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 110 */     if (property == EXPRESSION_PROPERTY) {
/* 111 */       if (get) {
/* 112 */         return getExpression();
/*     */       }
/* 114 */       setExpression((Expression)child);
/* 115 */       return null;
/*     */     } 
/*     */     
/* 118 */     if (property == BODY_PROPERTY) {
/* 119 */       if (get) {
/* 120 */         return getBody();
/*     */       }
/* 122 */       setBody((Block)child);
/* 123 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 127 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 132 */     return 51;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 137 */     SynchronizedStatement result = new SynchronizedStatement(target);
/* 138 */     result.setSourceRange(getStartPosition(), getLength());
/* 139 */     result.copyLeadingComment(this);
/* 140 */     result.setExpression((Expression)getExpression().clone(target));
/* 141 */     result.setBody((Block)getBody().clone(target));
/* 142 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 148 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 153 */     boolean visitChildren = visitor.visit(this);
/* 154 */     if (visitChildren) {
/*     */       
/* 156 */       acceptChild(visitor, getExpression());
/* 157 */       acceptChild(visitor, getBody());
/*     */     } 
/* 159 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 168 */     if (this.expression == null)
/*     */     {
/* 170 */       synchronized (this) {
/* 171 */         if (this.expression == null) {
/* 172 */           preLazyInit();
/* 173 */           this.expression = new SimpleName(this.ast);
/* 174 */           postLazyInit(this.expression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 178 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 193 */     if (expression == null) {
/* 194 */       throw new IllegalArgumentException();
/*     */     }
/* 196 */     ASTNode oldChild = this.expression;
/* 197 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 198 */     this.expression = expression;
/* 199 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Block getBody() {
/* 208 */     if (this.body == null)
/*     */     {
/* 210 */       synchronized (this) {
/* 211 */         if (this.body == null) {
/* 212 */           preLazyInit();
/* 213 */           this.body = new Block(this.ast);
/* 214 */           postLazyInit(this.body, BODY_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 218 */     return this.body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBody(Block block) {
/* 233 */     if (block == null) {
/* 234 */       throw new IllegalArgumentException();
/*     */     }
/* 236 */     ASTNode oldChild = this.body;
/* 237 */     preReplaceChild(oldChild, block, BODY_PROPERTY);
/* 238 */     this.body = block;
/* 239 */     postReplaceChild(oldChild, block, BODY_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 244 */     return super.memSize() + 8;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 249 */     return 
/* 250 */       memSize() + (
/* 251 */       (this.expression == null) ? 0 : getExpression().treeSize()) + (
/* 252 */       (this.body == null) ? 0 : getBody().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\SynchronizedStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */