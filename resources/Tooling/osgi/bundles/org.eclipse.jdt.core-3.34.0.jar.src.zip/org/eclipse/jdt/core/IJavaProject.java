package org.eclipse.jdt.core;

import java.util.Map;
import java.util.Set;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.eval.IEvaluationContext;

public interface IJavaProject extends IParent, IJavaElement, IOpenable {
  public static final String CLASSPATH_FILE_NAME = ".classpath";
  
  IClasspathEntry decodeClasspathEntry(String paramString);
  
  String encodeClasspathEntry(IClasspathEntry paramIClasspathEntry);
  
  IJavaElement findElement(IPath paramIPath) throws JavaModelException;
  
  IJavaElement findElement(IPath paramIPath, WorkingCopyOwner paramWorkingCopyOwner) throws JavaModelException;
  
  IJavaElement findElement(String paramString, WorkingCopyOwner paramWorkingCopyOwner) throws JavaModelException;
  
  IPackageFragment findPackageFragment(IPath paramIPath) throws JavaModelException;
  
  IPackageFragmentRoot findPackageFragmentRoot(IPath paramIPath) throws JavaModelException;
  
  IPackageFragmentRoot[] findPackageFragmentRoots(IClasspathEntry paramIClasspathEntry);
  
  IPackageFragmentRoot[] findUnfilteredPackageFragmentRoots(IClasspathEntry paramIClasspathEntry);
  
  IType findType(String paramString) throws JavaModelException;
  
  IType findType(String paramString, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  IType findType(String paramString, WorkingCopyOwner paramWorkingCopyOwner) throws JavaModelException;
  
  IType findType(String paramString, WorkingCopyOwner paramWorkingCopyOwner, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  IType findType(String paramString1, String paramString2) throws JavaModelException;
  
  IType findType(String paramString1, String paramString2, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  IType findType(String paramString1, String paramString2, WorkingCopyOwner paramWorkingCopyOwner) throws JavaModelException;
  
  IType findType(String paramString1, String paramString2, WorkingCopyOwner paramWorkingCopyOwner, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  IModuleDescription findModule(String paramString, WorkingCopyOwner paramWorkingCopyOwner) throws JavaModelException;
  
  IPackageFragmentRoot[] getAllPackageFragmentRoots() throws JavaModelException;
  
  Object[] getNonJavaResources() throws JavaModelException;
  
  String getOption(String paramString, boolean paramBoolean);
  
  Map<String, String> getOptions(boolean paramBoolean);
  
  IPath getOutputLocation() throws JavaModelException;
  
  IPackageFragmentRoot getPackageFragmentRoot(String paramString);
  
  IPackageFragmentRoot getPackageFragmentRoot(IResource paramIResource);
  
  IPackageFragmentRoot[] getPackageFragmentRoots() throws JavaModelException;
  
  IPackageFragmentRoot[] getPackageFragmentRoots(IClasspathEntry paramIClasspathEntry);
  
  IPackageFragment[] getPackageFragments() throws JavaModelException;
  
  IProject getProject();
  
  IModuleDescription getModuleDescription() throws JavaModelException;
  
  IModuleDescription getOwnModuleDescription() throws JavaModelException;
  
  IClasspathEntry[] getRawClasspath() throws JavaModelException;
  
  String[] getRequiredProjectNames() throws JavaModelException;
  
  IClasspathEntry[] getResolvedClasspath(boolean paramBoolean) throws JavaModelException;
  
  boolean hasBuildState();
  
  boolean hasClasspathCycle(IClasspathEntry[] paramArrayOfIClasspathEntry);
  
  boolean isOnClasspath(IJavaElement paramIJavaElement);
  
  boolean isOnClasspath(IResource paramIResource);
  
  IClasspathEntry findContainingClasspathEntry(IResource paramIResource);
  
  IEvaluationContext newEvaluationContext();
  
  ITypeHierarchy newTypeHierarchy(IRegion paramIRegion, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  ITypeHierarchy newTypeHierarchy(IRegion paramIRegion, WorkingCopyOwner paramWorkingCopyOwner, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  ITypeHierarchy newTypeHierarchy(IType paramIType, IRegion paramIRegion, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  ITypeHierarchy newTypeHierarchy(IType paramIType, IRegion paramIRegion, WorkingCopyOwner paramWorkingCopyOwner, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  IPath readOutputLocation();
  
  IClasspathEntry[] readRawClasspath();
  
  void setOption(String paramString1, String paramString2);
  
  void setOptions(Map<String, String> paramMap);
  
  void setOutputLocation(IPath paramIPath, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void setRawClasspath(IClasspathEntry[] paramArrayOfIClasspathEntry, IPath paramIPath, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void setRawClasspath(IClasspathEntry[] paramArrayOfIClasspathEntry, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void setRawClasspath(IClasspathEntry[] paramArrayOfIClasspathEntry1, IClasspathEntry[] paramArrayOfIClasspathEntry2, IPath paramIPath, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  IClasspathEntry[] getReferencedClasspathEntries() throws JavaModelException;
  
  void setRawClasspath(IClasspathEntry[] paramArrayOfIClasspathEntry, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void setRawClasspath(IClasspathEntry[] paramArrayOfIClasspathEntry, IPath paramIPath, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  IClasspathEntry getClasspathEntryFor(IPath paramIPath) throws JavaModelException;
  
  Set<String> determineModulesOfProjectsWithNonEmptyClasspath() throws JavaModelException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IJavaProject.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */