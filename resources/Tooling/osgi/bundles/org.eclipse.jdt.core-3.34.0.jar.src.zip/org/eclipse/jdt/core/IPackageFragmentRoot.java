package org.eclipse.jdt.core;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IPackageFragmentRoot extends IParent, IJavaElement, IOpenable {
  public static final int K_SOURCE = 1;
  
  public static final int K_BINARY = 2;
  
  public static final String DEFAULT_PACKAGEROOT_PATH = "";
  
  public static final int NO_RESOURCE_MODIFICATION = 1;
  
  public static final int ORIGINATING_PROJECT_CLASSPATH = 2;
  
  public static final int OTHER_REFERRING_PROJECTS_CLASSPATH = 4;
  
  public static final int DESTINATION_PROJECT_CLASSPATH = 8;
  
  public static final int REPLACE = 16;
  
  void attachSource(IPath paramIPath1, IPath paramIPath2, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void copy(IPath paramIPath, int paramInt1, int paramInt2, IClasspathEntry paramIClasspathEntry, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  IPackageFragment createPackageFragment(String paramString, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void delete(int paramInt1, int paramInt2, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  int getKind() throws JavaModelException;
  
  Object[] getNonJavaResources() throws JavaModelException;
  
  IPackageFragment getPackageFragment(String paramString);
  
  IClasspathEntry getRawClasspathEntry() throws JavaModelException;
  
  IClasspathEntry getResolvedClasspathEntry() throws JavaModelException;
  
  IPath getSourceAttachmentPath() throws JavaModelException;
  
  IPath getSourceAttachmentRootPath() throws JavaModelException;
  
  boolean isArchive();
  
  boolean isExternal();
  
  void move(IPath paramIPath, int paramInt1, int paramInt2, IClasspathEntry paramIClasspathEntry, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  IModuleDescription getModuleDescription();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IPackageFragmentRoot.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */