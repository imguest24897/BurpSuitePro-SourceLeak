/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QualifiedName
/*     */   extends Name
/*     */ {
/*  46 */   public static final ChildPropertyDescriptor QUALIFIER_PROPERTY = new ChildPropertyDescriptor(QualifiedName.class, "qualifier", Name.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(QualifiedName.class, "name", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  63 */     List propertyList = new ArrayList(3);
/*  64 */     createPropertyList(QualifiedName.class, propertyList);
/*  65 */     addProperty(QUALIFIER_PROPERTY, propertyList);
/*  66 */     addProperty(NAME_PROPERTY, propertyList);
/*  67 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  81 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private Name qualifier = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private SimpleName name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   QualifiedName(AST ast) {
/* 107 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 112 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 117 */     if (property == QUALIFIER_PROPERTY) {
/* 118 */       if (get) {
/* 119 */         return getQualifier();
/*     */       }
/* 121 */       setQualifier((Name)child);
/* 122 */       return null;
/*     */     } 
/*     */     
/* 125 */     if (property == NAME_PROPERTY) {
/* 126 */       if (get) {
/* 127 */         return getName();
/*     */       }
/* 129 */       setName((SimpleName)child);
/* 130 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 134 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 139 */     return 40;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 144 */     QualifiedName result = new QualifiedName(target);
/* 145 */     result.setSourceRange(getStartPosition(), getLength());
/* 146 */     result.setQualifier((Name)getQualifier().clone(target));
/* 147 */     result.setName((SimpleName)getName().clone(target));
/* 148 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 154 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 159 */     boolean visitChildren = visitor.visit(this);
/* 160 */     if (visitChildren) {
/*     */       
/* 162 */       acceptChild(visitor, getQualifier());
/* 163 */       acceptChild(visitor, getName());
/*     */     } 
/* 165 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getQualifier() {
/* 174 */     if (this.qualifier == null)
/*     */     {
/* 176 */       synchronized (this) {
/* 177 */         if (this.qualifier == null) {
/* 178 */           preLazyInit();
/* 179 */           this.qualifier = new SimpleName(this.ast);
/* 180 */           postLazyInit(this.qualifier, QUALIFIER_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 184 */     return this.qualifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQualifier(Name qualifier) {
/* 199 */     if (qualifier == null) {
/* 200 */       throw new IllegalArgumentException();
/*     */     }
/* 202 */     ASTNode oldChild = this.qualifier;
/* 203 */     preReplaceChild(oldChild, qualifier, QUALIFIER_PROPERTY);
/* 204 */     this.qualifier = qualifier;
/* 205 */     postReplaceChild(oldChild, qualifier, QUALIFIER_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 214 */     if (this.name == null)
/*     */     {
/* 216 */       synchronized (this) {
/* 217 */         if (this.name == null) {
/* 218 */           preLazyInit();
/* 219 */           this.name = new SimpleName(this.ast);
/* 220 */           postLazyInit(this.name, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 224 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName name) {
/* 238 */     if (name == null) {
/* 239 */       throw new IllegalArgumentException();
/*     */     }
/* 241 */     ASTNode oldChild = this.name;
/* 242 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 243 */     this.name = name;
/* 244 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   void appendName(StringBuffer buffer) {
/* 249 */     getQualifier().appendName(buffer);
/* 250 */     buffer.append('.');
/* 251 */     getName().appendName(buffer);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 256 */     return 56;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 261 */     return 
/* 262 */       memSize() + (
/* 263 */       (this.name == null) ? 0 : getName().treeSize()) + (
/* 264 */       (this.qualifier == null) ? 0 : getQualifier().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\QualifiedName.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */