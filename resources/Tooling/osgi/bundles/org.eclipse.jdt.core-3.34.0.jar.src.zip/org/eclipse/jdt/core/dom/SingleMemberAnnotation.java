/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SingleMemberAnnotation
/*     */   extends Annotation
/*     */ {
/*  41 */   public static final ChildPropertyDescriptor TYPE_NAME_PROPERTY = internalTypeNamePropertyFactory(SingleMemberAnnotation.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   public static final ChildPropertyDescriptor VALUE_PROPERTY = new ChildPropertyDescriptor(SingleMemberAnnotation.class, "value", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  57 */     List propertyList = new ArrayList(3);
/*  58 */     createPropertyList(SingleMemberAnnotation.class, propertyList);
/*  59 */     addProperty(TYPE_NAME_PROPERTY, propertyList);
/*  60 */     addProperty(VALUE_PROPERTY, propertyList);
/*  61 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  73 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   private Expression value = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SingleMemberAnnotation(AST ast) {
/*  93 */     super(ast);
/*  94 */     unsupportedIn2();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  99 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 104 */     if (property == TYPE_NAME_PROPERTY) {
/* 105 */       if (get) {
/* 106 */         return getTypeName();
/*     */       }
/* 108 */       setTypeName((Name)child);
/* 109 */       return null;
/*     */     } 
/*     */     
/* 112 */     if (property == VALUE_PROPERTY) {
/* 113 */       if (get) {
/* 114 */         return getValue();
/*     */       }
/* 116 */       setValue((Expression)child);
/* 117 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 121 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalTypeNameProperty() {
/* 126 */     return TYPE_NAME_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 131 */     return 79;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 136 */     SingleMemberAnnotation result = new SingleMemberAnnotation(target);
/* 137 */     result.setSourceRange(getStartPosition(), getLength());
/* 138 */     result.setTypeName((Name)ASTNode.copySubtree(target, getTypeName()));
/* 139 */     result.setValue((Expression)ASTNode.copySubtree(target, getValue()));
/* 140 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 146 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 151 */     boolean visitChildren = visitor.visit(this);
/* 152 */     if (visitChildren) {
/*     */       
/* 154 */       acceptChild(visitor, getTypeName());
/* 155 */       acceptChild(visitor, getValue());
/*     */     } 
/* 157 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getValue() {
/* 166 */     if (this.value == null)
/*     */     {
/* 168 */       synchronized (this) {
/* 169 */         if (this.value == null) {
/* 170 */           preLazyInit();
/* 171 */           this.value = new SimpleName(this.ast);
/* 172 */           postLazyInit(this.value, VALUE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 176 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(Expression value) {
/* 191 */     if (value == null) {
/* 192 */       throw new IllegalArgumentException();
/*     */     }
/* 194 */     ASTNode oldChild = this.value;
/* 195 */     preReplaceChild(oldChild, value, VALUE_PROPERTY);
/* 196 */     this.value = value;
/* 197 */     postReplaceChild(oldChild, value, VALUE_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 202 */     return super.memSize() + 4;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 207 */     return 
/* 208 */       memSize() + (
/* 209 */       (this.typeName == null) ? 0 : getTypeName().treeSize()) + (
/* 210 */       (this.value == null) ? 0 : getValue().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\SingleMemberAnnotation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */