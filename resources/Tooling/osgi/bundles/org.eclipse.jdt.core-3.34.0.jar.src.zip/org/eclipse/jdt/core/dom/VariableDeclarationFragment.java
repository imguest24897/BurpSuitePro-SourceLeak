/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VariableDeclarationFragment
/*     */   extends VariableDeclaration
/*     */ {
/*  43 */   public static final ChildPropertyDescriptor NAME_PROPERTY = internalNamePropertyFactory(VariableDeclarationFragment.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public static final SimplePropertyDescriptor EXTRA_DIMENSIONS_PROPERTY = internalExtraDimensionsPropertyFactory(VariableDeclarationFragment.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   public static final ChildListPropertyDescriptor EXTRA_DIMENSIONS2_PROPERTY = internalExtraDimensions2PropertyFactory(VariableDeclarationFragment.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public static final ChildPropertyDescriptor INITIALIZER_PROPERTY = internalInitializerPropertyFactory(VariableDeclarationFragment.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_8_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  85 */     List propertyList = new ArrayList(4);
/*  86 */     createPropertyList(VariableDeclarationFragment.class, propertyList);
/*  87 */     addProperty(NAME_PROPERTY, propertyList);
/*  88 */     addProperty(EXTRA_DIMENSIONS_PROPERTY, propertyList);
/*  89 */     addProperty(INITIALIZER_PROPERTY, propertyList);
/*  90 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */     
/*  92 */     propertyList = new ArrayList(4);
/*  93 */     createPropertyList(VariableDeclarationFragment.class, propertyList);
/*  94 */     addProperty(NAME_PROPERTY, propertyList);
/*  95 */     addProperty(EXTRA_DIMENSIONS2_PROPERTY, propertyList);
/*  96 */     addProperty(INITIALIZER_PROPERTY, propertyList);
/*  97 */     PROPERTY_DESCRIPTORS_8_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 111 */     if (apiLevel >= 8) {
/* 112 */       return PROPERTY_DESCRIPTORS_8_0;
/*     */     }
/* 114 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   VariableDeclarationFragment(AST ast) {
/* 129 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalNameProperty() {
/* 134 */     return NAME_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final SimplePropertyDescriptor internalExtraDimensionsProperty() {
/* 139 */     return EXTRA_DIMENSIONS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalExtraDimensions2Property() {
/* 144 */     return EXTRA_DIMENSIONS2_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalInitializerProperty() {
/* 149 */     return INITIALIZER_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 154 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final int internalGetSetIntProperty(SimplePropertyDescriptor property, boolean get, int value) {
/* 159 */     if (property == EXTRA_DIMENSIONS_PROPERTY) {
/* 160 */       if (get) {
/* 161 */         return getExtraDimensions();
/*     */       }
/* 163 */       internalSetExtraDimensions(value);
/* 164 */       return 0;
/*     */     } 
/*     */ 
/*     */     
/* 168 */     return super.internalGetSetIntProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 173 */     if (property == NAME_PROPERTY) {
/* 174 */       if (get) {
/* 175 */         return getName();
/*     */       }
/* 177 */       setName((SimpleName)child);
/* 178 */       return null;
/*     */     } 
/*     */     
/* 181 */     if (property == INITIALIZER_PROPERTY) {
/* 182 */       if (get) {
/* 183 */         return getInitializer();
/*     */       }
/* 185 */       setInitializer((Expression)child);
/* 186 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 190 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 195 */     if (property == EXTRA_DIMENSIONS2_PROPERTY) {
/* 196 */       return extraDimensions();
/*     */     }
/*     */     
/* 199 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 204 */     return 59;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 209 */     VariableDeclarationFragment result = new VariableDeclarationFragment(target);
/* 210 */     result.setSourceRange(getStartPosition(), getLength());
/* 211 */     result.setName((SimpleName)getName().clone(target));
/* 212 */     if (this.ast.apiLevel >= 8) {
/* 213 */       result.extraDimensions().addAll(
/* 214 */           ASTNode.copySubtrees(target, extraDimensions()));
/*     */     } else {
/* 216 */       result.internalSetExtraDimensions(getExtraDimensions());
/*     */     } 
/* 218 */     result.setInitializer(
/* 219 */         (Expression)ASTNode.copySubtree(target, getInitializer()));
/* 220 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 226 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 231 */     boolean visitChildren = visitor.visit(this);
/* 232 */     if (visitChildren) {
/*     */       
/* 234 */       acceptChild(visitor, getName());
/* 235 */       if (this.ast.apiLevel >= 8) {
/* 236 */         acceptChildren(visitor, this.extraDimensions);
/*     */       }
/* 238 */       acceptChild(visitor, getInitializer());
/*     */     } 
/* 240 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 246 */     return 56;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 251 */     return 
/* 252 */       memSize() + (
/* 253 */       (this.variableName == null) ? 0 : getName().treeSize()) + (
/* 254 */       (this.extraDimensions == null) ? 0 : this.extraDimensions.listSize()) + (
/* 255 */       (this.optionalInitializer == null) ? 0 : getInitializer().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\VariableDeclarationFragment.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */