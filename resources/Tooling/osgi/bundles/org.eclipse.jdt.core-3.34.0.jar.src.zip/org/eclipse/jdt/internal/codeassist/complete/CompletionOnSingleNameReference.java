/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.SingleNameReference;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnSingleNameReference
/*    */   extends SingleNameReference
/*    */ {
/*    */   public char[][] possibleKeywords;
/*    */   public boolean canBeExplicitConstructor;
/*    */   public boolean isInsideAnnotationAttribute;
/*    */   public boolean isPrecededByModifiers;
/*    */   
/*    */   public CompletionOnSingleNameReference(char[] source, long pos, boolean isInsideAnnotationAttribute) {
/* 48 */     this(source, pos, null, false, isInsideAnnotationAttribute);
/*    */   }
/*    */   
/*    */   public CompletionOnSingleNameReference(char[] source, long pos, char[][] possibleKeywords, boolean canBeExplicitConstructor, boolean isInsideAnnotationAttribute) {
/* 52 */     super(source, pos);
/* 53 */     this.possibleKeywords = possibleKeywords;
/* 54 */     this.canBeExplicitConstructor = canBeExplicitConstructor;
/* 55 */     this.isInsideAnnotationAttribute = isInsideAnnotationAttribute;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 61 */     output.append("<CompleteOnName:");
/* 62 */     return super.printExpression(0, output).append('>');
/*    */   }
/*    */ 
/*    */   
/*    */   public TypeBinding resolveType(BlockScope scope) {
/* 67 */     if (scope instanceof MethodScope) {
/* 68 */       throw new CompletionNodeFound(this, scope, ((MethodScope)scope).insideTypeAnnotation);
/*    */     }
/* 70 */     throw new CompletionNodeFound(this, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnSingleNameReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */