/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringLiteral
/*     */   extends Expression
/*     */ {
/*  39 */   public static final SimplePropertyDescriptor ESCAPED_VALUE_PROPERTY = new SimplePropertyDescriptor(StringLiteral.class, "escapedValue", String.class, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  49 */     List propertyList = new ArrayList(2);
/*  50 */     createPropertyList(StringLiteral.class, propertyList);
/*  51 */     addProperty(ESCAPED_VALUE_PROPERTY, propertyList);
/*  52 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  67 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private String escapedValue = "\"\"";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   StringLiteral(AST ast) {
/*  86 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  91 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final Object internalGetSetObjectProperty(SimplePropertyDescriptor property, boolean get, Object value) {
/*  96 */     if (property == ESCAPED_VALUE_PROPERTY) {
/*  97 */       if (get) {
/*  98 */         return getEscapedValue();
/*     */       }
/* 100 */       setEscapedValue((String)value);
/* 101 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 105 */     return super.internalGetSetObjectProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 110 */     return 45;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 115 */     StringLiteral result = new StringLiteral(target);
/* 116 */     result.setSourceRange(getStartPosition(), getLength());
/* 117 */     result.setEscapedValue(getEscapedValue());
/* 118 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 124 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 129 */     visitor.visit(this);
/* 130 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEscapedValue() {
/* 143 */     return this.escapedValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEscapedValue(String token) {
/* 163 */     if (token == null) {
/* 164 */       throw new IllegalArgumentException("Token cannot be null");
/*     */     }
/* 166 */     Scanner scanner = this.ast.scanner;
/* 167 */     char[] source = token.toCharArray();
/* 168 */     scanner.setSource(source);
/* 169 */     scanner.resetTo(0, source.length);
/*     */     try {
/* 171 */       int tokenType = scanner.getNextToken();
/* 172 */       switch (tokenType) {
/*     */         case 60:
/*     */           break;
/*     */         default:
/* 176 */           throw new IllegalArgumentException("Invalid string literal : >" + token + "<");
/*     */       } 
/* 178 */     } catch (InvalidInputException invalidInputException) {
/* 179 */       throw new IllegalArgumentException("Invalid string literal : >" + token + "<");
/*     */     } 
/* 181 */     preValueChange(ESCAPED_VALUE_PROPERTY);
/* 182 */     this.escapedValue = token;
/* 183 */     postValueChange(ESCAPED_VALUE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void internalSetEscapedValue(String token) {
/* 190 */     preValueChange(ESCAPED_VALUE_PROPERTY);
/* 191 */     this.escapedValue = token;
/* 192 */     postValueChange(ESCAPED_VALUE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLiteralValue() {
/* 214 */     String s = getEscapedValue();
/* 215 */     int len = s.length();
/* 216 */     if (len < 2 || s.charAt(0) != '"' || s.charAt(len - 1) != '"') {
/* 217 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 220 */     Scanner scanner = this.ast.scanner;
/* 221 */     char[] source = s.toCharArray();
/* 222 */     scanner.setSource(source);
/* 223 */     scanner.resetTo(0, source.length);
/*     */     try {
/* 225 */       int tokenType = scanner.getNextToken();
/* 226 */       switch (tokenType) {
/*     */         case 60:
/* 228 */           return scanner.getCurrentStringLiteral();
/*     */       } 
/* 230 */       throw new IllegalArgumentException();
/*     */     }
/* 232 */     catch (InvalidInputException invalidInputException) {
/* 233 */       throw new IllegalArgumentException();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLiteralValue(String value) {
/* 257 */     if (value == null) {
/* 258 */       throw new IllegalArgumentException();
/*     */     }
/* 260 */     int len = value.length();
/* 261 */     StringBuffer b = new StringBuffer(len + 2);
/*     */     
/* 263 */     b.append("\"");
/* 264 */     for (int i = 0; i < len; i++) {
/* 265 */       char c = value.charAt(i);
/* 266 */       Util.appendEscapedChar(b, c, true);
/*     */     } 
/* 268 */     b.append("\"");
/* 269 */     setEscapedValue(b.toString());
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 274 */     int size = 44 + stringSize(this.escapedValue);
/* 275 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 280 */     return memSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\StringLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */