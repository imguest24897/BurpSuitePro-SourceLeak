/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTypeDeclaration
/*     */   extends BodyDeclaration
/*     */ {
/*  38 */   SimpleName typeName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ASTNode.NodeList bodyDeclarations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract ChildListPropertyDescriptor internalBodyDeclarationsProperty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ChildListPropertyDescriptor getBodyDeclarationsProperty() {
/*  63 */     return internalBodyDeclarationsProperty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract ChildPropertyDescriptor internalNameProperty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ChildPropertyDescriptor getNameProperty() {
/*  82 */     return internalNameProperty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final ChildListPropertyDescriptor internalBodyDeclarationPropertyFactory(Class nodeClass) {
/*  92 */     return new ChildListPropertyDescriptor(nodeClass, "bodyDeclarations", BodyDeclaration.class, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final ChildPropertyDescriptor internalNamePropertyFactory(Class nodeClass) {
/* 102 */     return new ChildPropertyDescriptor(nodeClass, "name", SimpleName.class, true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractTypeDeclaration(AST ast) {
/* 117 */     super(ast);
/* 118 */     this.bodyDeclarations = new ASTNode.NodeList(this, internalBodyDeclarationsProperty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 128 */     if (this.typeName == null)
/*     */     {
/* 130 */       synchronized (this) {
/* 131 */         if (this.typeName == null) {
/* 132 */           preLazyInit();
/* 133 */           this.typeName = new SimpleName(this.ast);
/* 134 */           postLazyInit(this.typeName, internalNameProperty());
/*     */         } 
/*     */       } 
/*     */     }
/* 138 */     return this.typeName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName typeName) {
/* 154 */     if (typeName == null) {
/* 155 */       throw new IllegalArgumentException();
/*     */     }
/* 157 */     ChildPropertyDescriptor p = internalNameProperty();
/* 158 */     ASTNode oldChild = this.typeName;
/* 159 */     preReplaceChild(oldChild, typeName, p);
/* 160 */     this.typeName = typeName;
/* 161 */     postReplaceChild(oldChild, typeName, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List bodyDeclarations() {
/* 173 */     return this.bodyDeclarations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPackageMemberTypeDeclaration() {
/* 189 */     ASTNode parent = getParent();
/* 190 */     return parent instanceof CompilationUnit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMemberTypeDeclaration() {
/* 207 */     ASTNode parent = getParent();
/* 208 */     return !(!(parent instanceof AbstractTypeDeclaration) && 
/* 209 */       !(parent instanceof AnonymousClassDeclaration));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocalTypeDeclaration() {
/* 224 */     ASTNode parent = getParent();
/* 225 */     return parent instanceof TypeDeclarationStatement;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ITypeBinding resolveBinding() {
/* 241 */     return internalResolveBinding();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract ITypeBinding internalResolveBinding();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 255 */     return super.memSize() + 8;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\AbstractTypeDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */