/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpressionMethodReference
/*     */   extends MethodReference
/*     */ {
/*  38 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(ExpressionMethodReference.class, "expression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   public static final ChildListPropertyDescriptor TYPE_ARGUMENTS_PROPERTY = internalTypeArgumentsFactory(ExpressionMethodReference.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(ExpressionMethodReference.class, "name", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_8_0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  60 */     List propertyList = new ArrayList(4);
/*  61 */     createPropertyList(ExpressionMethodReference.class, propertyList);
/*  62 */     addProperty(EXPRESSION_PROPERTY, propertyList);
/*  63 */     addProperty(TYPE_ARGUMENTS_PROPERTY, propertyList);
/*  64 */     addProperty(NAME_PROPERTY, propertyList);
/*  65 */     PROPERTY_DESCRIPTORS_8_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  77 */     return PROPERTY_DESCRIPTORS_8_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private Expression expression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   private SimpleName methodName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExpressionMethodReference(AST ast) {
/* 104 */     super(ast);
/* 105 */     unsupportedIn2_3_4();
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalTypeArgumentsProperty() {
/* 110 */     return TYPE_ARGUMENTS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 115 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 120 */     if (property == NAME_PROPERTY) {
/* 121 */       if (get) {
/* 122 */         return getName();
/*     */       }
/* 124 */       setName((SimpleName)child);
/* 125 */       return null;
/*     */     } 
/*     */     
/* 128 */     if (property == EXPRESSION_PROPERTY) {
/* 129 */       if (get) {
/* 130 */         return getExpression();
/*     */       }
/* 132 */       setExpression((Expression)child);
/* 133 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 137 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 142 */     if (property == TYPE_ARGUMENTS_PROPERTY) {
/* 143 */       return typeArguments();
/*     */     }
/*     */     
/* 146 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 151 */     return 90;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 156 */     ExpressionMethodReference result = new ExpressionMethodReference(target);
/* 157 */     result.setSourceRange(getStartPosition(), getLength());
/* 158 */     result.setExpression(
/* 159 */         (Expression)ASTNode.copySubtree(target, getExpression()));
/* 160 */     result.typeArguments().addAll(ASTNode.copySubtrees(target, typeArguments()));
/* 161 */     result.setName((SimpleName)getName().clone(target));
/* 162 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 168 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 173 */     boolean visitChildren = visitor.visit(this);
/* 174 */     if (visitChildren) {
/*     */       
/* 176 */       acceptChild(visitor, getExpression());
/* 177 */       acceptChildren(visitor, this.typeArguments);
/* 178 */       acceptChild(visitor, getName());
/*     */     } 
/* 180 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 189 */     if (this.expression == null)
/*     */     {
/* 191 */       synchronized (this) {
/* 192 */         if (this.expression == null) {
/* 193 */           preLazyInit();
/* 194 */           this.expression = new SimpleName(this.ast);
/* 195 */           postLazyInit(this.expression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 199 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 214 */     if (expression == null) {
/* 215 */       throw new IllegalArgumentException();
/*     */     }
/* 217 */     ASTNode oldChild = this.expression;
/* 218 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 219 */     this.expression = expression;
/* 220 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List typeArguments() {
/* 231 */     return this.typeArguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 240 */     if (this.methodName == null)
/*     */     {
/* 242 */       synchronized (this) {
/* 243 */         if (this.methodName == null) {
/* 244 */           preLazyInit();
/* 245 */           this.methodName = new SimpleName(this.ast);
/* 246 */           postLazyInit(this.methodName, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 250 */     return this.methodName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName name) {
/* 265 */     if (name == null) {
/* 266 */       throw new IllegalArgumentException();
/*     */     }
/* 268 */     ASTNode oldChild = this.methodName;
/* 269 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 270 */     this.methodName = name;
/* 271 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 277 */     return 52;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 282 */     return 
/* 283 */       memSize() + (
/* 284 */       (this.expression == null) ? 0 : getExpression().treeSize()) + (
/* 285 */       (this.typeArguments == null) ? 0 : this.typeArguments.listSize()) + (
/* 286 */       (this.methodName == null) ? 0 : getName().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ExpressionMethodReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */