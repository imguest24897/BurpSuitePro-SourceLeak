package org.eclipse.jdt.core;

public interface IField extends IMember, IAnnotatable {
  Object getConstant() throws JavaModelException;
  
  String getElementName();
  
  String getKey();
  
  String getTypeSignature() throws JavaModelException;
  
  boolean isEnumConstant() throws JavaModelException;
  
  boolean isResolved();
  
  boolean isRecordComponent() throws JavaModelException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IField.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */