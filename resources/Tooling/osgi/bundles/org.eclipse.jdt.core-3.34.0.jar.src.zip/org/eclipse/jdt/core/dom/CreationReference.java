/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CreationReference
/*     */   extends MethodReference
/*     */ {
/*  39 */   public static final ChildPropertyDescriptor TYPE_PROPERTY = new ChildPropertyDescriptor(CreationReference.class, "type", Type.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public static final ChildListPropertyDescriptor TYPE_ARGUMENTS_PROPERTY = internalTypeArgumentsFactory(CreationReference.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_8_0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  55 */     List propertyList = new ArrayList(3);
/*  56 */     createPropertyList(CreationReference.class, propertyList);
/*  57 */     addProperty(TYPE_PROPERTY, propertyList);
/*  58 */     addProperty(TYPE_ARGUMENTS_PROPERTY, propertyList);
/*  59 */     PROPERTY_DESCRIPTORS_8_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  71 */     return PROPERTY_DESCRIPTORS_8_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   private Type type = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CreationReference(AST ast) {
/*  91 */     super(ast);
/*  92 */     unsupportedIn2_3_4();
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalTypeArgumentsProperty() {
/*  97 */     return TYPE_ARGUMENTS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 102 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 107 */     if (property == TYPE_PROPERTY) {
/* 108 */       if (get) {
/* 109 */         return getType();
/*     */       }
/* 111 */       setType((Type)child);
/* 112 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 116 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 121 */     if (property == TYPE_ARGUMENTS_PROPERTY) {
/* 122 */       return typeArguments();
/*     */     }
/*     */     
/* 125 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 130 */     return 89;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 135 */     CreationReference result = new CreationReference(target);
/* 136 */     result.setSourceRange(getStartPosition(), getLength());
/* 137 */     result.setType((Type)ASTNode.copySubtree(target, getType()));
/* 138 */     result.typeArguments().addAll(ASTNode.copySubtrees(target, typeArguments()));
/* 139 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 145 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 150 */     boolean visitChildren = visitor.visit(this);
/* 151 */     if (visitChildren) {
/*     */       
/* 153 */       acceptChild(visitor, getType());
/* 154 */       acceptChildren(visitor, this.typeArguments);
/*     */     } 
/* 156 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 165 */     if (this.type == null)
/*     */     {
/* 167 */       synchronized (this) {
/* 168 */         if (this.type == null) {
/* 169 */           preLazyInit();
/* 170 */           this.type = new SimpleType(this.ast);
/* 171 */           postLazyInit(this.type, TYPE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 175 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(Type type) {
/* 189 */     if (type == null) {
/* 190 */       throw new IllegalArgumentException();
/*     */     }
/* 192 */     ASTNode oldChild = this.type;
/* 193 */     preReplaceChild(oldChild, type, TYPE_PROPERTY);
/* 194 */     this.type = type;
/* 195 */     postReplaceChild(oldChild, type, TYPE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List typeArguments() {
/* 206 */     return this.typeArguments;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 212 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 217 */     return 
/* 218 */       memSize() + (
/* 219 */       (this.type == null) ? 0 : getType().treeSize()) + (
/* 220 */       (this.typeArguments == null) ? 0 : this.typeArguments.listSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\CreationReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */