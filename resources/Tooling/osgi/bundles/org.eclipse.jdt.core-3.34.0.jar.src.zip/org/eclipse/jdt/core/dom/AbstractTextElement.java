/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractTextElement
/*     */   extends ASTNode
/*     */   implements IDocElement
/*     */ {
/*     */   public static final SimplePropertyDescriptor internalTextPropertyFactory(Class nodeClass) {
/*  39 */     return new SimplePropertyDescriptor(nodeClass, "text", String.class, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   String text = Util.EMPTY_STRING;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractTextElement(AST ast) {
/*  60 */     super(ast);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract SimplePropertyDescriptor internalTextPropertyFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SimplePropertyDescriptor getTextNameProperty() {
/*  79 */     return internalTextPropertyFactory();
/*     */   }
/*     */ 
/*     */   
/*     */   final Object internalGetSetObjectProperty(SimplePropertyDescriptor property, boolean get, Object value) {
/*  84 */     if (property == internalTextPropertyFactory()) {
/*  85 */       if (get) {
/*  86 */         return getText();
/*     */       }
/*  88 */       setText((String)value);
/*  89 */       return null;
/*     */     } 
/*     */ 
/*     */     
/*  93 */     return super.internalGetSetObjectProperty(property, get, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 108 */     return this.text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(String text) {
/* 123 */     if (text == null) {
/* 124 */       throw new IllegalArgumentException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNested() {
/* 146 */     return getParent() instanceof AbstractTextElement;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 151 */     int size = 46 + stringSize(this.text);
/* 152 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 157 */     return memSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\AbstractTextElement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */