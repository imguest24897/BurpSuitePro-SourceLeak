/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WhileStatement
/*     */   extends Statement
/*     */ {
/*  39 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(WhileStatement.class, "expression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final ChildPropertyDescriptor BODY_PROPERTY = new ChildPropertyDescriptor(WhileStatement.class, "body", Statement.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  56 */     List propertyList = new ArrayList(3);
/*  57 */     createPropertyList(WhileStatement.class, propertyList);
/*  58 */     addProperty(EXPRESSION_PROPERTY, propertyList);
/*  59 */     addProperty(BODY_PROPERTY, propertyList);
/*  60 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  75 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private Expression expression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private Statement body = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WhileStatement(AST ast) {
/* 101 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 106 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 111 */     if (property == EXPRESSION_PROPERTY) {
/* 112 */       if (get) {
/* 113 */         return getExpression();
/*     */       }
/* 115 */       setExpression((Expression)child);
/* 116 */       return null;
/*     */     } 
/*     */     
/* 119 */     if (property == BODY_PROPERTY) {
/* 120 */       if (get) {
/* 121 */         return getBody();
/*     */       }
/* 123 */       setBody((Statement)child);
/* 124 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 128 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 133 */     return 61;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 138 */     WhileStatement result = new WhileStatement(target);
/* 139 */     result.setSourceRange(getStartPosition(), getLength());
/* 140 */     result.copyLeadingComment(this);
/* 141 */     result.setExpression((Expression)getExpression().clone(target));
/* 142 */     result.setBody((Statement)getBody().clone(target));
/* 143 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 149 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 154 */     boolean visitChildren = visitor.visit(this);
/* 155 */     if (visitChildren) {
/*     */       
/* 157 */       acceptChild(visitor, getExpression());
/* 158 */       acceptChild(visitor, getBody());
/*     */     } 
/* 160 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 169 */     if (this.expression == null)
/*     */     {
/* 171 */       synchronized (this) {
/* 172 */         if (this.expression == null) {
/* 173 */           preLazyInit();
/* 174 */           this.expression = new SimpleName(this.ast);
/* 175 */           postLazyInit(this.expression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 179 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 194 */     if (expression == null) {
/* 195 */       throw new IllegalArgumentException();
/*     */     }
/* 197 */     ASTNode oldChild = this.expression;
/* 198 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 199 */     this.expression = expression;
/* 200 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement getBody() {
/* 209 */     if (this.body == null)
/*     */     {
/* 211 */       synchronized (this) {
/* 212 */         if (this.body == null) {
/* 213 */           preLazyInit();
/* 214 */           this.body = new Block(this.ast);
/* 215 */           postLazyInit(this.body, BODY_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 219 */     return this.body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBody(Statement statement) {
/* 242 */     if (statement == null) {
/* 243 */       throw new IllegalArgumentException();
/*     */     }
/* 245 */     ASTNode oldChild = this.body;
/* 246 */     preReplaceChild(oldChild, statement, BODY_PROPERTY);
/* 247 */     this.body = statement;
/* 248 */     postReplaceChild(oldChild, statement, BODY_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 253 */     return super.memSize() + 8;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 258 */     return 
/* 259 */       memSize() + (
/* 260 */       (this.expression == null) ? 0 : getExpression().treeSize()) + (
/* 261 */       (this.body == null) ? 0 : getBody().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\WhileStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */