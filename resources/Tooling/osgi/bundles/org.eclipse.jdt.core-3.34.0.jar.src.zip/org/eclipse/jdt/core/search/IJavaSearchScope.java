package org.eclipse.jdt.core.search;

import org.eclipse.core.runtime.IPath;
import org.eclipse.jdt.core.IJavaElement;

public interface IJavaSearchScope {
  public static final String JAR_FILE_ENTRY_SEPARATOR = "|";
  
  public static final int SOURCES = 1;
  
  public static final int APPLICATION_LIBRARIES = 2;
  
  public static final int SYSTEM_LIBRARIES = 4;
  
  public static final int REFERENCED_PROJECTS = 8;
  
  boolean encloses(String paramString);
  
  boolean encloses(IJavaElement paramIJavaElement);
  
  IPath[] enclosingProjectsAndJars();
  
  boolean includesBinaries();
  
  boolean includesClasspaths();
  
  void setIncludesBinaries(boolean paramBoolean);
  
  void setIncludesClasspaths(boolean paramBoolean);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\search\IJavaSearchScope.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */