/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwitchCase
/*     */   extends Statement
/*     */ {
/*  44 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(SwitchCase.class, "expression", Expression.class, false, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public static final ChildListPropertyDescriptor EXPRESSIONS2_PROPERTY = new ChildListPropertyDescriptor(SwitchCase.class, "expression", Expression.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   public static final SimplePropertyDescriptor SWITCH_LABELED_RULE_PROPERTY = new SimplePropertyDescriptor(SwitchCase.class, "switchLabeledRule", boolean.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_13;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  75 */     List propertyList = new ArrayList(2);
/*  76 */     createPropertyList(SwitchCase.class, propertyList);
/*  77 */     addProperty(EXPRESSION_PROPERTY, propertyList);
/*  78 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */     
/*  80 */     propertyList = new ArrayList(2);
/*  81 */     createPropertyList(SwitchCase.class, propertyList);
/*  82 */     addProperty(EXPRESSIONS2_PROPERTY, propertyList);
/*  83 */     addProperty(SWITCH_LABELED_RULE_PROPERTY, propertyList);
/*  84 */     PROPERTY_DESCRIPTORS_13 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  98 */     if (apiLevel >= 14) {
/*  99 */       return PROPERTY_DESCRIPTORS_13;
/*     */     }
/* 101 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private Expression optionalExpression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean switchLabeledRule = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   private ASTNode.NodeList expressions = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean expressionInitialized = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SwitchCase(AST ast) {
/* 135 */     super(ast);
/* 136 */     if (ast.apiLevel >= 14) {
/* 137 */       this.expressions = new ASTNode.NodeList(this, EXPRESSIONS2_PROPERTY);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 143 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final boolean internalGetSetBooleanProperty(SimplePropertyDescriptor property, boolean get, boolean value) {
/* 148 */     if (property == SWITCH_LABELED_RULE_PROPERTY) {
/* 149 */       if (get) {
/* 150 */         return isSwitchLabeledRule();
/*     */       }
/* 152 */       setSwitchLabeledRule(value);
/* 153 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 157 */     return super.internalGetSetBooleanProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 162 */     if (property == EXPRESSION_PROPERTY) {
/* 163 */       if (get) {
/* 164 */         return getExpression();
/*     */       }
/* 166 */       setExpression((Expression)child);
/* 167 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 171 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 176 */     if (property == EXPRESSIONS2_PROPERTY) {
/* 177 */       return expressions();
/*     */     }
/*     */     
/* 180 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 185 */     return 49;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 191 */     SwitchCase result = new SwitchCase(target);
/* 192 */     result.setSourceRange(getStartPosition(), getLength());
/* 193 */     result.copyLeadingComment(this);
/* 194 */     if (this.ast.apiLevel >= 14) {
/* 195 */       result.expressions().addAll(
/* 196 */           ASTNode.copySubtrees(target, expressions()));
/*     */     } else {
/* 198 */       result.setExpression(
/* 199 */           (Expression)ASTNode.copySubtree(target, getExpression()));
/*     */     } 
/* 201 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 207 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 212 */     boolean visitChildren = visitor.visit(this);
/* 213 */     if (visitChildren) {
/* 214 */       if (this.ast.apiLevel >= 14) {
/* 215 */         acceptChildren(visitor, this.expressions);
/*     */       } else {
/* 217 */         acceptChild(visitor, getExpression());
/*     */       } 
/*     */     }
/* 220 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 231 */     if (!this.expressionInitialized)
/*     */     {
/* 233 */       synchronized (this) {
/* 234 */         if (!this.expressionInitialized) {
/* 235 */           preLazyInit();
/* 236 */           this.optionalExpression = new SimpleName(this.ast);
/* 237 */           this.expressionInitialized = true;
/* 238 */           postLazyInit(this.optionalExpression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 242 */     return this.optionalExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List expressions() {
/* 255 */     if (this.expressions == null) {
/* 256 */       unsupportedBelow14();
/*     */     }
/* 258 */     return this.expressions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 276 */     ASTNode oldChild = this.optionalExpression;
/* 277 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 278 */     this.optionalExpression = expression;
/* 279 */     this.expressionInitialized = true;
/* 280 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSwitchLabeledRule(boolean switchLabeledRule) {
/* 292 */     unsupportedBelow14();
/* 293 */     preValueChange(SWITCH_LABELED_RULE_PROPERTY);
/* 294 */     this.switchLabeledRule = switchLabeledRule;
/* 295 */     postValueChange(SWITCH_LABELED_RULE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSwitchLabeledRule() {
/* 307 */     unsupportedBelow14();
/* 308 */     return this.switchLabeledRule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefault() {
/* 322 */     if (this.ast.apiLevel >= 14) {
/* 323 */       return expressions().isEmpty();
/*     */     }
/* 325 */     return (getExpression() == null);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 330 */     return super.memSize() + 8;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 335 */     return 
/* 336 */       memSize() + (
/* 337 */       (this.optionalExpression == null) ? 0 : this.optionalExpression.treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\SwitchCase.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */