/*     */ package org.eclipse.jdt.core.formatter;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Messages
/*     */   extends NLS
/*     */ {
/*     */   private static final String BUNDLE_NAME = "org.eclipse.jdt.core.formatter.messages";
/*     */   public static String CommandLineConfigFile;
/*     */   public static String CommandLineDone;
/*     */   public static String CommandLineErrorConfig;
/*     */   public static String CommandLineErrorFileTryFullPath;
/*     */   public static String CommandLineErrorFile;
/*     */   public static String CommandLineErrorFileDir;
/*     */   public static String CommandLineErrorQuietVerbose;
/*     */   public static String CommandLineErrorNoConfigFile;
/*     */   public static String CommandLineFormatting;
/*     */   public static String CommandLineStart;
/*     */   public static String CommandLineUsage;
/*     */   public static String ConfigFileNotFoundErrorTryFullPath;
/*     */   public static String ConfigFileReadingError;
/*     */   public static String FormatProblem;
/*     */   public static String CaughtException;
/*     */   public static String ExceptionSkip;
/*     */   
/*     */   static {
/*  99 */     NLS.initializeMessages("org.eclipse.jdt.core.formatter.messages", Messages.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bind(String message) {
/* 111 */     return bind(message, (Object[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bind(String message, Object binding) {
/* 125 */     return bind(message, new Object[] {
/* 126 */           binding
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bind(String message, Object binding1, Object binding2) {
/* 143 */     return bind(message, new Object[] {
/* 144 */           binding1, binding2
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bind(String message, Object[] bindings) {
/* 159 */     return MessageFormat.format(message, bindings);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\formatter\CodeFormatterApplication$Messages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */