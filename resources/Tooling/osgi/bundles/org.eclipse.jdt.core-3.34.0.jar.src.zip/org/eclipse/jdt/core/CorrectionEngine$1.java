/*     */ package org.eclipse.jdt.core;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   extends CompletionRequestor
/*     */ {
/*     */   public void accept(CompletionProposal proposal) {
/*     */     int flags;
/* 321 */     switch (proposal.getKind()) {
/*     */       case 9:
/* 323 */         flags = proposal.getFlags();
/* 324 */         if (!Flags.isEnum(flags) && !Flags.isAnnotation(flags)) {
/* 325 */           if ((CorrectionEngine.this.filter & 0x3) != 0) {
/* 326 */             char[] completionName = proposal.getCompletion();
/* 327 */             CorrectionEngine.this.correctionRequestor.acceptClass(
/* 328 */                 proposal.getDeclarationSignature(), 
/* 329 */                 Signature.getSignatureSimpleName(proposal.getSignature()), 
/* 330 */                 CharOperation.subarray(completionName, CorrectionEngine.this.prefixLength, completionName.length), 
/* 331 */                 proposal.getFlags(), 
/* 332 */                 CorrectionEngine.this.correctionStart, 
/* 333 */                 CorrectionEngine.this.correctionEnd); break;
/* 334 */           }  if ((CorrectionEngine.this.filter & 0x4) != 0) {
/* 335 */             char[] packageName = proposal.getDeclarationSignature();
/* 336 */             char[] className = Signature.getSignatureSimpleName(proposal.getSignature());
/* 337 */             char[] fullName = CharOperation.concat(packageName, className, '.');
/* 338 */             CorrectionEngine.this.correctionRequestor.acceptClass(
/* 339 */                 packageName, 
/* 340 */                 className, 
/* 341 */                 CharOperation.subarray(fullName, CorrectionEngine.this.prefixLength, fullName.length), 
/* 342 */                 proposal.getFlags(), 
/* 343 */                 CorrectionEngine.this.correctionStart, 
/* 344 */                 CorrectionEngine.this.correctionEnd);
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       case 2:
/* 349 */         if ((CorrectionEngine.this.filter & 0x10) != 0) {
/* 350 */           char[] declaringSignature = proposal.getDeclarationSignature();
/* 351 */           char[] signature = proposal.getSignature();
/* 352 */           CorrectionEngine.this.correctionRequestor.acceptField(
/* 353 */               Signature.getSignatureQualifier(declaringSignature), 
/* 354 */               Signature.getSignatureSimpleName(declaringSignature), 
/* 355 */               proposal.getName(), 
/* 356 */               Signature.getSignatureQualifier(signature), 
/* 357 */               Signature.getSignatureSimpleName(signature), 
/* 358 */               proposal.getName(), 
/* 359 */               proposal.getFlags(), 
/* 360 */               CorrectionEngine.this.correctionStart, 
/* 361 */               CorrectionEngine.this.correctionEnd);
/*     */         } 
/*     */         break;
/*     */       case 5:
/* 365 */         if ((CorrectionEngine.this.filter & 0x20) != 0) {
/* 366 */           char[] signature = proposal.getSignature();
/* 367 */           CorrectionEngine.this.correctionRequestor.acceptLocalVariable(
/* 368 */               proposal.getName(), 
/* 369 */               Signature.getSignatureQualifier(signature), 
/* 370 */               Signature.getSignatureSimpleName(signature), 
/* 371 */               proposal.getFlags(), 
/* 372 */               CorrectionEngine.this.correctionStart, 
/* 373 */               CorrectionEngine.this.correctionEnd);
/*     */         } 
/*     */         break;
/*     */       case 6:
/* 377 */         if ((CorrectionEngine.this.filter & 0x8) != 0) {
/* 378 */           char[] declaringSignature = proposal.getDeclarationSignature();
/* 379 */           char[] signature = proposal.getSignature();
/* 380 */           char[][] parameterTypeSignatures = Signature.getParameterTypes(signature);
/* 381 */           int length = parameterTypeSignatures.length;
/* 382 */           char[][] parameterPackageNames = new char[length][];
/* 383 */           char[][] parameterTypeNames = new char[length][];
/* 384 */           for (int i = 0; i < length; i++) {
/* 385 */             parameterPackageNames[i] = Signature.getSignatureQualifier(parameterTypeSignatures[i]);
/* 386 */             parameterTypeNames[i] = Signature.getSignatureSimpleName(parameterTypeSignatures[i]);
/*     */           } 
/* 388 */           char[] returnTypeSignature = Signature.getReturnType(signature);
/* 389 */           CorrectionEngine.this.correctionRequestor.acceptMethod(
/* 390 */               Signature.getSignatureQualifier(declaringSignature), 
/* 391 */               Signature.getSignatureSimpleName(declaringSignature), 
/* 392 */               proposal.getName(), 
/* 393 */               parameterPackageNames, 
/* 394 */               parameterTypeNames, 
/* 395 */               proposal.findParameterNames(null), 
/* 396 */               Signature.getSignatureQualifier(returnTypeSignature), 
/* 397 */               Signature.getSignatureSimpleName(returnTypeSignature), 
/* 398 */               proposal.getName(), 
/* 399 */               proposal.getFlags(), 
/* 400 */               CorrectionEngine.this.correctionStart, 
/* 401 */               CorrectionEngine.this.correctionEnd);
/*     */         } 
/*     */         break;
/*     */       case 8:
/* 405 */         if ((CorrectionEngine.this.filter & 0x7) != 0) {
/* 406 */           char[] packageName = proposal.getDeclarationSignature();
/* 407 */           CorrectionEngine.this.correctionRequestor.acceptPackage(
/* 408 */               packageName, 
/* 409 */               CharOperation.subarray(packageName, CorrectionEngine.this.prefixLength, packageName.length), 
/* 410 */               CorrectionEngine.this.correctionStart, 
/* 411 */               CorrectionEngine.this.correctionEnd);
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\CorrectionEngine$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */