/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmptyStatement
/*     */   extends Statement
/*     */ {
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */   
/*     */   static {
/*  42 */     List properyList = new ArrayList(1);
/*  43 */     createPropertyList(EmptyStatement.class, properyList);
/*  44 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  59 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   EmptyStatement(AST ast) {
/*  71 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  76 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/*  81 */     return 20;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/*  86 */     EmptyStatement result = new EmptyStatement(target);
/*  87 */     result.setSourceRange(getStartPosition(), getLength());
/*  88 */     result.copyLeadingComment(this);
/*  89 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/*  95 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 100 */     visitor.visit(this);
/* 101 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 106 */     return memSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\EmptyStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */