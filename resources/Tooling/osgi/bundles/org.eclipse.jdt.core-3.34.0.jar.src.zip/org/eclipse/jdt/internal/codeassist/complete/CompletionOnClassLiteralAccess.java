/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.ClassLiteralAccess;
/*    */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnClassLiteralAccess
/*    */   extends ClassLiteralAccess
/*    */ {
/*    */   public char[] completionIdentifier;
/*    */   public int classStart;
/*    */   
/*    */   public CompletionOnClassLiteralAccess(long pos, TypeReference t) {
/* 47 */     super((int)pos, t);
/* 48 */     this.classStart = (int)(pos >>> 32L);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 54 */     output.append("<CompleteOnClassLiteralAccess:");
/* 55 */     return this.type.print(0, output).append('.').append(this.completionIdentifier).append('>');
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeBinding resolveType(BlockScope scope) {
/* 61 */     if (super.resolveType(scope) == null) {
/* 62 */       throw new CompletionNodeFound();
/*    */     }
/* 64 */     throw new CompletionNodeFound(this, this.targetType, scope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnClassLiteralAccess.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */