/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.MemberValuePair;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnMemberValueName
/*    */   extends MemberValuePair
/*    */ {
/*    */   public CompletionOnMemberValueName(char[] token, int sourceStart, int sourceEnd) {
/* 33 */     super(token, sourceStart, sourceEnd, null);
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer print(int indent, StringBuffer output) {
/* 38 */     output.append("<CompleteOnAttributeName:");
/* 39 */     output.append(this.name);
/* 40 */     output.append('>');
/* 41 */     return output;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnMemberValueName.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */