/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NullPattern
/*     */   extends Pattern
/*     */ {
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */   
/*     */   static {
/*  38 */     List propertyList = new ArrayList(1);
/*  39 */     createPropertyList(NullPattern.class, propertyList);
/*  40 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  54 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NullPattern(AST ast) {
/*  66 */     super(ast);
/*  67 */     supportedOnlyIn20();
/*  68 */     unsupportedWithoutPreviewError();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  73 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/*  78 */     return 108;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/*  83 */     NullPattern result = new NullPattern(target);
/*  84 */     result.setSourceRange(getStartPosition(), getLength());
/*  85 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/*  91 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/*  96 */     visitor.visit(this);
/*  97 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 102 */     return 40;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 107 */     return memSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\NullPattern.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */