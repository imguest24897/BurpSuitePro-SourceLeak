/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidCursorLocation
/*    */   extends RuntimeException
/*    */ {
/*    */   public String irritant;
/*    */   public static final String NO_COMPLETION_INSIDE_UNICODE = "No Completion Inside Unicode";
/*    */   public static final String NO_COMPLETION_INSIDE_COMMENT = "No Completion Inside Comment";
/*    */   public static final String NO_COMPLETION_INSIDE_STRING = "No Completion Inside String";
/*    */   public static final String NO_COMPLETION_INSIDE_NUMBER = "No Completion Inside Number";
/*    */   private static final long serialVersionUID = -3443160725735779590L;
/*    */   
/*    */   public InvalidCursorLocation(String irritant) {
/* 33 */     this.irritant = irritant;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\InvalidCursorLocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */