/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.ASTNode;
/*    */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AssistNodeParentAnnotationArrayInitializer
/*    */   extends ASTNode
/*    */ {
/*    */   public final TypeReference type;
/*    */   public final char[] name;
/*    */   
/*    */   public AssistNodeParentAnnotationArrayInitializer(TypeReference type, char[] name) {
/* 23 */     this.type = type;
/* 24 */     this.name = name;
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer print(int indent, StringBuffer output) {
/* 29 */     output.append("<AssistNodeParentAnnotationArrayInitializer:");
/* 30 */     output.append('@');
/* 31 */     this.type.printExpression(0, output);
/* 32 */     output.append('(');
/* 33 */     output.append(this.name);
/* 34 */     output.append(')');
/* 35 */     output.append('>');
/*    */     
/* 37 */     return output;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\AssistNodeParentAnnotationArrayInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */