package org.eclipse.jdt.core;

import java.io.OutputStream;
import org.eclipse.core.runtime.IProgressMonitor;

public interface ITypeHierarchy {
  void addTypeHierarchyChangedListener(ITypeHierarchyChangedListener paramITypeHierarchyChangedListener);
  
  boolean contains(IType paramIType);
  
  boolean exists();
  
  IType[] getAllClasses();
  
  IType[] getAllInterfaces();
  
  IType[] getAllSubtypes(IType paramIType);
  
  IType[] getAllSuperclasses(IType paramIType);
  
  IType[] getAllSuperInterfaces(IType paramIType);
  
  IType[] getAllSupertypes(IType paramIType);
  
  IType[] getAllTypes();
  
  int getCachedFlags(IType paramIType);
  
  IType[] getExtendingInterfaces(IType paramIType);
  
  IType[] getImplementingClasses(IType paramIType);
  
  IType[] getRootClasses();
  
  IType[] getRootInterfaces();
  
  IType[] getSubclasses(IType paramIType);
  
  IType[] getSubtypes(IType paramIType);
  
  IType getSuperclass(IType paramIType);
  
  IType[] getSuperInterfaces(IType paramIType);
  
  IType[] getSupertypes(IType paramIType);
  
  IType getType();
  
  void refresh(IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void removeTypeHierarchyChangedListener(ITypeHierarchyChangedListener paramITypeHierarchyChangedListener);
  
  void store(OutputStream paramOutputStream, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\ITypeHierarchy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */