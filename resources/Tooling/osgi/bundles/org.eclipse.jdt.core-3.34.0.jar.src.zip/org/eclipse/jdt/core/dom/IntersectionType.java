/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntersectionType
/*     */   extends Type
/*     */ {
/*  40 */   public static final ChildListPropertyDescriptor TYPES_PROPERTY = new ChildListPropertyDescriptor(IntersectionType.class, "types", Type.class, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_8_0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  50 */     List propertyList = new ArrayList(2);
/*  51 */     createPropertyList(IntersectionType.class, propertyList);
/*  52 */     addProperty(TYPES_PROPERTY, propertyList);
/*  53 */     PROPERTY_DESCRIPTORS_8_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  66 */     return PROPERTY_DESCRIPTORS_8_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private ASTNode.NodeList types = new ASTNode.NodeList(this, TYPES_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IntersectionType(AST ast) {
/*  84 */     super(ast);
/*  85 */     unsupportedIn2_3_4();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  90 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/*  95 */     if (property == TYPES_PROPERTY) {
/*  96 */       return types();
/*     */     }
/*     */     
/*  99 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 104 */     return 87;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 109 */     IntersectionType result = new IntersectionType(target);
/* 110 */     result.setSourceRange(getStartPosition(), getLength());
/* 111 */     result.types().addAll(
/* 112 */         ASTNode.copySubtrees(target, types()));
/* 113 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 119 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 124 */     boolean visitChildren = visitor.visit(this);
/* 125 */     if (visitChildren)
/*     */     {
/* 127 */       acceptChildren(visitor, this.types);
/*     */     }
/* 129 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List types() {
/* 142 */     return this.types;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 147 */     return 44;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 152 */     return 
/* 153 */       memSize() + 
/* 154 */       this.types.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\IntersectionType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */