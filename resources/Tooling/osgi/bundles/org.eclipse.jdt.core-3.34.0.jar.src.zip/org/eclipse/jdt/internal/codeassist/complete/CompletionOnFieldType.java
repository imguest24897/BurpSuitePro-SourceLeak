/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ import org.eclipse.jdt.internal.compiler.ast.FieldDeclaration;
/*    */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnFieldType
/*    */   extends FieldDeclaration
/*    */ {
/*    */   public boolean isLocalVariable;
/*    */   
/*    */   public CompletionOnFieldType(TypeReference type, boolean isLocalVariable) {
/* 45 */     this.sourceStart = type.sourceStart;
/* 46 */     this.sourceEnd = type.sourceEnd;
/* 47 */     this.type = type;
/* 48 */     this.name = CharOperation.NO_CHAR;
/* 49 */     this.isLocalVariable = isLocalVariable;
/* 50 */     if (type instanceof CompletionOnSingleTypeReference) {
/* 51 */       ((CompletionOnSingleTypeReference)type).fieldTypeCompletionNode = this;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printStatement(int tab, StringBuffer output) {
/* 57 */     return this.type.print(tab, output).append(';');
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnFieldType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */