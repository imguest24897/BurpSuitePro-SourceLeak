/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class VariableDeclaration
/*     */   extends ASTNode
/*     */ {
/*  39 */   SimpleName variableName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   int extraArrayDimensions = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   ASTNode.NodeList extraDimensions = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   Expression optionalInitializer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final ChildPropertyDescriptor internalNamePropertyFactory(Class nodeClass) {
/*  73 */     return new ChildPropertyDescriptor(nodeClass, "name", SimpleName.class, true, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final SimplePropertyDescriptor internalExtraDimensionsPropertyFactory(Class nodeClass) {
/*  84 */     return new SimplePropertyDescriptor(nodeClass, "extraDimensions", int.class, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final ChildListPropertyDescriptor internalExtraDimensions2PropertyFactory(Class nodeClass) {
/*  94 */     return new ChildListPropertyDescriptor(nodeClass, "extraDimensions2", Dimension.class, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final ChildPropertyDescriptor internalInitializerPropertyFactory(Class nodeClass) {
/* 104 */     return new ChildPropertyDescriptor(nodeClass, "initializer", Expression.class, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract ChildPropertyDescriptor internalNameProperty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ChildPropertyDescriptor getNameProperty() {
/* 124 */     return internalNameProperty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract SimplePropertyDescriptor internalExtraDimensionsProperty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SimplePropertyDescriptor getExtraDimensionsProperty() {
/* 147 */     return internalExtraDimensionsProperty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract ChildListPropertyDescriptor internalExtraDimensions2Property();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ChildListPropertyDescriptor getExtraDimensions2Property() {
/* 167 */     return internalExtraDimensions2Property();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract ChildPropertyDescriptor internalInitializerProperty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ChildPropertyDescriptor getInitializerProperty() {
/* 187 */     return internalInitializerProperty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   VariableDeclaration(AST ast) {
/* 199 */     super(ast);
/* 200 */     if (ast.apiLevel >= 8) {
/* 201 */       this.extraDimensions = new ASTNode.NodeList(this, getExtraDimensions2Property());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 211 */     if (this.variableName == null)
/*     */     {
/* 213 */       synchronized (this) {
/* 214 */         if (this.variableName == null) {
/* 215 */           preLazyInit();
/* 216 */           this.variableName = new SimpleName(this.ast);
/* 217 */           postLazyInit(this.variableName, internalNameProperty());
/*     */         } 
/*     */       } 
/*     */     }
/* 221 */     return this.variableName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName variableName) {
/* 236 */     if (variableName == null) {
/* 237 */       throw new IllegalArgumentException();
/*     */     }
/* 239 */     ChildPropertyDescriptor p = internalNameProperty();
/* 240 */     ASTNode oldChild = this.variableName;
/* 241 */     preReplaceChild(oldChild, variableName, p);
/* 242 */     this.variableName = variableName;
/* 243 */     postReplaceChild(oldChild, variableName, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getExtraDimensions() {
/* 267 */     if (this.extraDimensions == null)
/*     */     {
/* 269 */       return this.extraArrayDimensions;
/*     */     }
/* 271 */     return this.extraDimensions.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExtraDimensions(int dimensions) {
/* 297 */     internalSetExtraDimensions(dimensions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void internalSetExtraDimensions(int dimensions) {
/* 307 */     if (this.extraDimensions != null) {
/* 308 */       supportedOnlyIn2_3_4();
/*     */     }
/* 310 */     if (dimensions < 0) {
/* 311 */       throw new IllegalArgumentException();
/*     */     }
/* 313 */     SimplePropertyDescriptor p = internalExtraDimensionsProperty();
/* 314 */     preValueChange(p);
/* 315 */     this.extraArrayDimensions = dimensions;
/* 316 */     postValueChange(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List extraDimensions() {
/* 328 */     if (this.extraDimensions == null) {
/* 329 */       unsupportedIn2_3_4();
/*     */     }
/* 331 */     return this.extraDimensions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getInitializer() {
/* 342 */     return this.optionalInitializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInitializer(Expression initializer) {
/* 358 */     ChildPropertyDescriptor p = internalInitializerProperty();
/* 359 */     ASTNode oldChild = this.optionalInitializer;
/* 360 */     preReplaceChild(oldChild, initializer, p);
/* 361 */     this.optionalInitializer = initializer;
/* 362 */     postReplaceChild(oldChild, initializer, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IVariableBinding resolveBinding() {
/* 377 */     return this.ast.getBindingResolver().resolveVariable(this);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\VariableDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */