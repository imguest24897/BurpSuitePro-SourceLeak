/*    */ package org.eclipse.jdt.internal.codeassist.impl;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.jdt.core.ICompilationUnit;
/*    */ import org.eclipse.jdt.core.IImportContainer;
/*    */ import org.eclipse.jdt.core.IPackageDeclaration;
/*    */ import org.eclipse.jdt.core.IType;
/*    */ import org.eclipse.jdt.core.JavaModelException;
/*    */ import org.eclipse.jdt.core.WorkingCopyOwner;
/*    */ import org.eclipse.jdt.internal.core.CompilationUnit;
/*    */ import org.eclipse.jdt.internal.core.ImportContainer;
/*    */ import org.eclipse.jdt.internal.core.JavaElement;
/*    */ import org.eclipse.jdt.internal.core.JavaElementInfo;
/*    */ import org.eclipse.jdt.internal.core.PackageDeclaration;
/*    */ import org.eclipse.jdt.internal.core.PackageFragment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AssistCompilationUnit
/*    */   extends CompilationUnit
/*    */ {
/*    */   private Map infoCache;
/*    */   private Map bindingCache;
/*    */   
/*    */   public AssistCompilationUnit(ICompilationUnit compilationUnit, WorkingCopyOwner owner, Map bindingCache, Map infoCache) {
/* 34 */     super((PackageFragment)compilationUnit.getParent(), compilationUnit.getElementName(), owner);
/* 35 */     this.bindingCache = bindingCache;
/* 36 */     this.infoCache = infoCache;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getElementInfo(IProgressMonitor monitor) throws JavaModelException {
/* 41 */     return this.infoCache.get(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public ImportContainer getImportContainer() {
/* 46 */     return new AssistImportContainer(this, this.infoCache);
/*    */   }
/*    */ 
/*    */   
/*    */   public PackageDeclaration getPackageDeclaration(String pkg) {
/* 51 */     return new AssistPackageDeclaration(this, pkg, this.infoCache);
/*    */   }
/*    */ 
/*    */   
/*    */   public IType getType(String typeName) {
/* 56 */     return (IType)new AssistSourceType((JavaElement)this, typeName, this.bindingCache, this.infoCache);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean hasChildren() throws JavaModelException {
/* 61 */     JavaElementInfo info = (JavaElementInfo)this.infoCache.get(this);
/* 62 */     return ((info.getChildren()).length > 0);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\impl\AssistCompilationUnit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */