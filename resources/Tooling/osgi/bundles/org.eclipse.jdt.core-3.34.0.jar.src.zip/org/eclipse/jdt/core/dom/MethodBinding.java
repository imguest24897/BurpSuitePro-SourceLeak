/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.LookupEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedGenericMethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.RawTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.problem.AbortCompilation;
/*     */ import org.eclipse.jdt.internal.core.JavaElement;
/*     */ import org.eclipse.jdt.internal.core.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MethodBinding
/*     */   implements IMethodBinding
/*     */ {
/*     */   private static final int VALID_MODIFIERS = 68927;
/*  44 */   private static final ITypeBinding[] NO_TYPE_BINDINGS = new ITypeBinding[0];
/*  45 */   static final IVariableBinding[] NO_VARIABLE_BINDINGS = new IVariableBinding[0];
/*     */   protected org.eclipse.jdt.internal.compiler.lookup.MethodBinding binding;
/*     */   protected BindingResolver resolver;
/*     */   private volatile ITypeBinding[] parameterTypes;
/*     */   private volatile ITypeBinding[] exceptionTypes;
/*     */   private volatile String name;
/*     */   private volatile ITypeBinding declaringClass;
/*     */   private volatile ITypeBinding returnType;
/*     */   private volatile String key;
/*     */   private volatile ITypeBinding[] typeParameters;
/*     */   private volatile ITypeBinding[] typeArguments;
/*     */   private volatile IAnnotationBinding[] annotations;
/*     */   private volatile IAnnotationBinding[][] parameterAnnotations;
/*     */   
/*     */   MethodBinding(BindingResolver resolver, org.eclipse.jdt.internal.compiler.lookup.MethodBinding binding) {
/*  60 */     this.resolver = resolver;
/*  61 */     this.binding = binding;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAnnotationMember() {
/*  66 */     return getDeclaringClass().isAnnotation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isConstructor() {
/*  74 */     return this.binding.isConstructor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompactConstructor() {
/*  82 */     return this.binding.isCompactConstructor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCanonicalConstructor() {
/*  90 */     return this.binding.isCanonicalConstructor();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefaultConstructor() {
/*  99 */     ReferenceBinding declaringClassBinding = this.binding.declaringClass;
/* 100 */     if (declaringClassBinding.isRawType()) {
/* 101 */       RawTypeBinding rawTypeBinding = (RawTypeBinding)declaringClassBinding;
/* 102 */       if (rawTypeBinding.genericType().isBinaryBinding()) {
/* 103 */         return false;
/*     */       }
/* 105 */       return ((this.binding.modifiers & 0x4000000) != 0);
/*     */     } 
/* 107 */     if (declaringClassBinding.isBinaryBinding()) {
/* 108 */       return false;
/*     */     }
/* 110 */     return ((this.binding.modifiers & 0x4000000) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 118 */     if (this.name == null) {
/* 119 */       if (this.binding.isConstructor()) {
/* 120 */         this.name = getDeclaringClass().getName();
/*     */       } else {
/* 122 */         this.name = new String(this.binding.selector);
/*     */       } 
/*     */     }
/* 125 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public IAnnotationBinding[] getAnnotations() {
/* 130 */     if (this.annotations != null) {
/* 131 */       return this.annotations;
/*     */     }
/* 133 */     AnnotationBinding[] internalAnnotations = this.binding.getAnnotations();
/* 134 */     return this.annotations = filterTypeAnnotations(internalAnnotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeBinding getDeclaringClass() {
/* 142 */     if (this.declaringClass == null) {
/* 143 */       this.declaringClass = this.resolver.getTypeBinding((TypeBinding)this.binding.declaringClass);
/*     */     }
/* 145 */     return this.declaringClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public IBinding getDeclaringMember() {
/* 150 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IAnnotationBinding[] getParameterAnnotations(int index) {
/* 155 */     if (getParameterTypes() == NO_TYPE_BINDINGS) {
/* 156 */       return (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */     }
/* 158 */     if (this.parameterAnnotations != null) {
/* 159 */       return this.parameterAnnotations[index];
/*     */     }
/* 161 */     AnnotationBinding[][] bindingAnnotations = this.binding.getParameterAnnotations();
/* 162 */     if (bindingAnnotations == null) return (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */     
/* 164 */     int length = bindingAnnotations.length;
/* 165 */     IAnnotationBinding[][] domAnnotations = new IAnnotationBinding[length][];
/* 166 */     for (int i = 0; i < length; i++) {
/* 167 */       AnnotationBinding[] paramBindingAnnotations = bindingAnnotations[i];
/* 168 */       int pLength = paramBindingAnnotations.length;
/* 169 */       domAnnotations[i] = (IAnnotationBinding[])new AnnotationBinding[pLength];
/* 170 */       for (int j = 0; j < pLength; j++) {
/* 171 */         IAnnotationBinding domAnnotation = this.resolver.getAnnotationInstance(paramBindingAnnotations[j]);
/* 172 */         if (domAnnotation == null) {
/* 173 */           domAnnotations[i] = (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */           break;
/*     */         } 
/* 176 */         domAnnotations[i][j] = domAnnotation;
/*     */       } 
/*     */     } 
/* 179 */     this.parameterAnnotations = domAnnotations;
/*     */     
/* 181 */     return this.parameterAnnotations[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeBinding[] getParameterTypes() {
/* 189 */     if (this.parameterTypes != null) {
/* 190 */       return this.parameterTypes;
/*     */     }
/* 192 */     TypeBinding[] parameters = this.binding.parameters;
/* 193 */     int length = (parameters == null) ? 0 : parameters.length;
/* 194 */     if (length == 0) {
/* 195 */       return this.parameterTypes = NO_TYPE_BINDINGS;
/*     */     }
/* 197 */     ITypeBinding[] paramTypes = new ITypeBinding[length];
/* 198 */     for (int i = 0; i < length; i++) {
/* 199 */       TypeBinding parameterBinding = parameters[i];
/* 200 */       if (parameterBinding != null) {
/* 201 */         ITypeBinding typeBinding = this.resolver.getTypeBinding(parameterBinding);
/* 202 */         if (typeBinding == null) {
/* 203 */           return this.parameterTypes = NO_TYPE_BINDINGS;
/*     */         }
/* 205 */         paramTypes[i] = typeBinding;
/*     */       } else {
/*     */         
/* 208 */         StringBuilder message = new StringBuilder("Report method binding where a parameter is null:\n");
/* 209 */         message.append(toString());
/* 210 */         Util.log(new IllegalArgumentException(), message.toString());
/*     */         
/* 212 */         return this.parameterTypes = NO_TYPE_BINDINGS;
/*     */       } 
/*     */     } 
/* 215 */     return this.parameterTypes = paramTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeBinding getDeclaredReceiverType() {
/* 224 */     return this.resolver.getTypeBinding(this.binding.receiver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeBinding getReturnType() {
/* 231 */     if (this.returnType == null) {
/* 232 */       this.returnType = this.resolver.getTypeBinding(this.binding.returnType);
/*     */     }
/* 234 */     return this.returnType;
/*     */   }
/*     */   
/*     */   protected IAnnotationBinding[] filterTypeAnnotations(AnnotationBinding[] internalAnnotations) {
/* 238 */     int length = (internalAnnotations == null) ? 0 : internalAnnotations.length;
/* 239 */     if (length != 0) {
/* 240 */       IAnnotationBinding[] tempAnnotations = new IAnnotationBinding[length];
/* 241 */       int convertedAnnotationCount = 0;
/* 242 */       boolean isConstructor = isConstructor();
/* 243 */       for (int i = 0; i < length; i++) {
/* 244 */         AnnotationBinding internalAnnotation = internalAnnotations[i];
/* 245 */         ReferenceBinding annotationType = internalAnnotation.getAnnotationType();
/* 246 */         long metaTagBits = annotationType.getAnnotationTagBits();
/*     */ 
/*     */         
/* 249 */         if (!isConstructor || (metaTagBits & 0x10000000000L) != 0L || (
/* 250 */           metaTagBits & 0x20600FF840000000L) == 0L) {
/*     */ 
/*     */ 
/*     */           
/* 254 */           IAnnotationBinding annotationInstance = this.resolver.getAnnotationInstance(internalAnnotation);
/* 255 */           if (annotationInstance != null)
/*     */           {
/*     */             
/* 258 */             tempAnnotations[convertedAnnotationCount++] = annotationInstance; } 
/*     */         } 
/* 260 */       }  if (convertedAnnotationCount == length) return tempAnnotations; 
/* 261 */       if (convertedAnnotationCount == 0) return (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */       
/* 263 */       System.arraycopy(tempAnnotations, 0, tempAnnotations = new IAnnotationBinding[convertedAnnotationCount], 0, convertedAnnotationCount);
/* 264 */       return tempAnnotations;
/*     */     } 
/* 266 */     return (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getDefaultValue() {
/* 271 */     if (isAnnotationMember())
/* 272 */       return MemberValuePairBinding.buildDOMValue(this.binding.getDefaultValue(), this.resolver); 
/* 273 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeBinding[] getExceptionTypes() {
/* 281 */     if (this.exceptionTypes != null) {
/* 282 */       return this.exceptionTypes;
/*     */     }
/* 284 */     ReferenceBinding[] arrayOfReferenceBinding = this.binding.thrownExceptions;
/* 285 */     int length = (arrayOfReferenceBinding == null) ? 0 : arrayOfReferenceBinding.length;
/* 286 */     if (length == 0) {
/* 287 */       return this.exceptionTypes = NO_TYPE_BINDINGS;
/*     */     }
/* 289 */     ITypeBinding[] exTypes = new ITypeBinding[length];
/* 290 */     for (int i = 0; i < length; i++) {
/* 291 */       ITypeBinding typeBinding = this.resolver.getTypeBinding((TypeBinding)arrayOfReferenceBinding[i]);
/* 292 */       if (typeBinding == null) {
/* 293 */         return this.exceptionTypes = NO_TYPE_BINDINGS;
/*     */       }
/* 295 */       exTypes[i] = typeBinding;
/*     */     } 
/* 297 */     return this.exceptionTypes = exTypes;
/*     */   }
/*     */ 
/*     */   
/*     */   public IJavaElement getJavaElement() {
/* 302 */     JavaElement element = getUnresolvedJavaElement();
/* 303 */     if (element == null)
/* 304 */       return null; 
/* 305 */     return (IJavaElement)element.resolved((Binding)this.binding);
/*     */   }
/*     */   
/*     */   private JavaElement getUnresolvedJavaElement() {
/* 309 */     if (JavaCore.getPlugin() == null) {
/* 310 */       return null;
/*     */     }
/* 312 */     if (!(this.resolver instanceof DefaultBindingResolver)) return null;
/*     */     
/* 314 */     DefaultBindingResolver defaultBindingResolver = (DefaultBindingResolver)this.resolver;
/* 315 */     if (!defaultBindingResolver.fromJavaProject) return null; 
/* 316 */     return Util.getUnresolvedJavaElement(
/* 317 */         this.binding, 
/* 318 */         defaultBindingResolver.workingCopyOwner, 
/* 319 */         defaultBindingResolver.getBindingsToNodesMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getKind() {
/* 327 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 335 */     return this.binding.getAccessFlags() & 0x10D3F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDeprecated() {
/* 343 */     return this.binding.isDeprecated();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRecovered() {
/* 351 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSynthetic() {
/* 359 */     return this.binding.isSynthetic();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVarargs() {
/* 368 */     return this.binding.isVarargs();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 376 */     if (this.key == null) {
/* 377 */       this.key = new String(this.binding.computeUniqueKey());
/*     */     }
/* 379 */     return this.key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEqualTo(IBinding other) {
/* 388 */     if (other == this)
/*     */     {
/* 390 */       return true;
/*     */     }
/* 392 */     if (other == null)
/*     */     {
/* 394 */       return false;
/*     */     }
/* 396 */     if (!(other instanceof MethodBinding)) {
/* 397 */       return false;
/*     */     }
/* 399 */     org.eclipse.jdt.internal.compiler.lookup.MethodBinding otherBinding = ((MethodBinding)other).binding;
/* 400 */     return BindingComparator.isEqual(this.binding, otherBinding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeBinding[] getTypeParameters() {
/* 408 */     if (this.typeParameters != null) {
/* 409 */       return this.typeParameters;
/*     */     }
/* 411 */     TypeVariableBinding[] typeVariableBindings = this.binding.typeVariables();
/* 412 */     int typeVariableBindingsLength = (typeVariableBindings == null) ? 0 : typeVariableBindings.length;
/* 413 */     if (typeVariableBindingsLength == 0) {
/* 414 */       return this.typeParameters = NO_TYPE_BINDINGS;
/*     */     }
/* 416 */     ITypeBinding[] tParameters = new ITypeBinding[typeVariableBindingsLength];
/* 417 */     for (int i = 0; i < typeVariableBindingsLength; i++) {
/* 418 */       ITypeBinding typeBinding = this.resolver.getTypeBinding((TypeBinding)typeVariableBindings[i]);
/* 419 */       if (typeBinding == null) {
/* 420 */         return this.typeParameters = NO_TYPE_BINDINGS;
/*     */       }
/* 422 */       tParameters[i] = typeBinding;
/*     */     } 
/* 424 */     return this.typeParameters = tParameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGenericMethod() {
/* 434 */     if (this.typeParameters != null) {
/* 435 */       return (this.typeParameters.length > 0);
/*     */     }
/* 437 */     TypeVariableBinding[] typeVariableBindings = this.binding.typeVariables();
/* 438 */     return (typeVariableBindings != null && typeVariableBindings.length > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeBinding[] getTypeArguments() {
/* 446 */     if (this.typeArguments != null) {
/* 447 */       return this.typeArguments;
/*     */     }
/*     */     
/* 450 */     if (this.binding instanceof ParameterizedGenericMethodBinding) {
/* 451 */       ParameterizedGenericMethodBinding genericMethodBinding = (ParameterizedGenericMethodBinding)this.binding;
/* 452 */       TypeBinding[] typeArgumentsBindings = genericMethodBinding.typeArguments;
/* 453 */       int typeArgumentsLength = (typeArgumentsBindings == null) ? 0 : typeArgumentsBindings.length;
/* 454 */       if (typeArgumentsLength != 0) {
/* 455 */         ITypeBinding[] tArguments = new ITypeBinding[typeArgumentsLength];
/* 456 */         for (int i = 0; i < typeArgumentsLength; i++) {
/* 457 */           ITypeBinding typeBinding = this.resolver.getTypeBinding(typeArgumentsBindings[i]);
/* 458 */           if (typeBinding == null) {
/* 459 */             return this.typeArguments = NO_TYPE_BINDINGS;
/*     */           }
/* 461 */           tArguments[i] = typeBinding;
/*     */         } 
/* 463 */         return this.typeArguments = tArguments;
/*     */       } 
/*     */     } 
/* 466 */     return this.typeArguments = NO_TYPE_BINDINGS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isParameterizedMethod() {
/* 474 */     return (this.binding instanceof ParameterizedGenericMethodBinding && 
/* 475 */       !((ParameterizedGenericMethodBinding)this.binding).isRaw);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRawMethod() {
/* 483 */     return (this.binding instanceof ParameterizedGenericMethodBinding && 
/* 484 */       ((ParameterizedGenericMethodBinding)this.binding).isRaw);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSubsignature(IMethodBinding otherMethod) {
/*     */     try {
/* 490 */       LookupEnvironment lookupEnvironment = this.resolver.lookupEnvironment();
/* 491 */       return (lookupEnvironment != null && 
/* 492 */         lookupEnvironment.methodVerifier().isMethodSubsignature(this.binding, ((MethodBinding)otherMethod).binding));
/* 493 */     } catch (AbortCompilation abortCompilation) {
/*     */ 
/*     */       
/* 496 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMethodBinding getMethodDeclaration() {
/* 505 */     return this.resolver.getMethodBinding(this.binding.original());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean overrides(IMethodBinding otherMethod) {
/* 513 */     LookupEnvironment lookupEnvironment = this.resolver.lookupEnvironment();
/* 514 */     return (lookupEnvironment != null && 
/* 515 */       lookupEnvironment.methodVerifier().doesMethodOverride(this.binding, ((MethodBinding)otherMethod).binding));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 524 */     return this.binding.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class LambdaMethod
/*     */     extends MethodBinding
/*     */   {
/*     */     private MethodBinding implementation;
/*     */ 
/*     */     
/*     */     private IBinding declaringMember;
/*     */ 
/*     */     
/*     */     private IVariableBinding[] syntheticOuterLocalVariables;
/*     */ 
/*     */ 
/*     */     
/*     */     public LambdaMethod(DefaultBindingResolver resolver, org.eclipse.jdt.internal.compiler.lookup.MethodBinding lambdaDescriptor, org.eclipse.jdt.internal.compiler.lookup.MethodBinding implementation, IBinding declaringMember) {
/* 544 */       super(resolver, lambdaDescriptor);
/* 545 */       this.implementation = new MethodBinding(resolver, implementation);
/* 546 */       this.declaringMember = declaringMember;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getModifiers() {
/* 554 */       return super.getModifiers() & 0xFFFFFBFF;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getKey() {
/* 562 */       return this.implementation.getKey();
/*     */     }
/*     */ 
/*     */     
/*     */     public ITypeBinding[] getParameterTypes() {
/* 567 */       return this.implementation.getParameterTypes();
/*     */     }
/*     */ 
/*     */     
/*     */     public IAnnotationBinding[] getParameterAnnotations(int paramIndex) {
/* 572 */       return this.implementation.getParameterAnnotations(paramIndex);
/*     */     }
/*     */ 
/*     */     
/*     */     public IAnnotationBinding[] getAnnotations() {
/* 577 */       return this.implementation.getAnnotations();
/*     */     }
/*     */ 
/*     */     
/*     */     public IBinding getDeclaringMember() {
/* 582 */       return this.declaringMember;
/*     */     }
/*     */ 
/*     */     
/*     */     public IMethodBinding getMethodDeclaration() {
/* 587 */       return this.resolver.getMethodBinding(this.binding);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 592 */       return super.toString().replace("public abstract ", "public ");
/*     */     }
/*     */ 
/*     */     
/*     */     public IVariableBinding[] getSyntheticOuterLocals() {
/* 597 */       if (this.syntheticOuterLocalVariables != null) {
/* 598 */         return this.syntheticOuterLocalVariables;
/*     */       }
/* 600 */       return NO_VARIABLE_BINDINGS;
/*     */     }
/*     */     
/*     */     public void setSyntheticOuterLocals(IVariableBinding[] syntheticOuterLocalVariables) {
/* 604 */       this.syntheticOuterLocalVariables = syntheticOuterLocalVariables;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public IVariableBinding[] getSyntheticOuterLocals() {
/* 610 */     return NO_VARIABLE_BINDINGS;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSyntheticRecordMethod() {
/* 615 */     return (getDeclaringClass().isRecord() && 
/* 616 */       this.binding instanceof org.eclipse.jdt.internal.compiler.lookup.SyntheticMethodBinding);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getParameterNames() {
/* 621 */     return CharOperation.toStrings(this.binding.parameterNames);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\MethodBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */