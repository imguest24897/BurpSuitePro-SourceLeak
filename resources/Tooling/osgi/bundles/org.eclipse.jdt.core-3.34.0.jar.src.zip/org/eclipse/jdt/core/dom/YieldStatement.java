/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YieldStatement
/*     */   extends Statement
/*     */ {
/*  37 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(YieldStatement.class, "expression", Expression.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isImplicit = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  52 */     List properyList = new ArrayList(2);
/*  53 */     createPropertyList(YieldStatement.class, properyList);
/*  54 */     addProperty(EXPRESSION_PROPERTY, properyList);
/*  55 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  70 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   private Expression expression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   YieldStatement(AST ast) {
/*  89 */     super(ast);
/*  90 */     unsupportedBelow14();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  95 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel, boolean previewEnabled) {
/* 100 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 105 */     if (property == EXPRESSION_PROPERTY) {
/* 106 */       if (get) {
/* 107 */         return getExpression();
/*     */       }
/* 109 */       setExpression((Expression)child);
/* 110 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 114 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 119 */     return 101;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 124 */     YieldStatement result = new YieldStatement(target);
/* 125 */     result.setSourceRange(getStartPosition(), getLength());
/* 126 */     result.copyLeadingComment(this);
/* 127 */     if (this.ast.apiLevel >= 12) {
/* 128 */       result.setExpression((Expression)ASTNode.copySubtree(target, getExpression()));
/*     */     }
/* 130 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 136 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 141 */     boolean visitChildren = visitor.visit(this);
/* 142 */     if (visitChildren && 
/* 143 */       this.ast.apiLevel >= 13) {
/* 144 */       acceptChild(visitor, getExpression());
/*     */     }
/*     */     
/* 147 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 159 */     unsupportedBelow14();
/* 160 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 176 */     unsupportedBelow14();
/* 177 */     ASTNode oldChild = this.expression;
/* 178 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 179 */     this.expression = expression;
/* 180 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isImplicit() {
/* 192 */     unsupportedBelow14();
/* 193 */     return this.isImplicit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setImplicit(boolean isImplicit) {
/* 205 */     unsupportedBelow14();
/* 206 */     this.isImplicit = isImplicit;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 212 */     return super.memSize() + 8;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 217 */     return 
/* 218 */       memSize() + (
/* 219 */       (this.expression == null) ? 0 : getExpression().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\YieldStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */