/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModuleQualifiedName
/*     */   extends Name
/*     */ {
/*  43 */   public static final ChildPropertyDescriptor MODULE_QUALIFIER_PROPERTY = new ChildPropertyDescriptor(ModuleQualifiedName.class, "moduleQualifier", SimpleName.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(ModuleQualifiedName.class, "name", QualifiedName.class, true, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  59 */     List propertyList = new ArrayList(3);
/*  60 */     createPropertyList(ModuleQualifiedName.class, propertyList);
/*  61 */     addProperty(MODULE_QUALIFIER_PROPERTY, propertyList);
/*  62 */     addProperty(NAME_PROPERTY, propertyList);
/*  63 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  76 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   private Name moduleQualifier = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   private Name name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ModuleQualifiedName(AST ast) {
/* 102 */     super(ast);
/* 103 */     unsupportedBelow15();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 108 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 113 */     if (property == MODULE_QUALIFIER_PROPERTY) {
/* 114 */       if (get) {
/* 115 */         return getModuleQualifier();
/*     */       }
/* 117 */       setModuleQualifier((SimpleName)child);
/* 118 */       return null;
/*     */     } 
/*     */     
/* 121 */     if (property == NAME_PROPERTY) {
/* 122 */       if (get) {
/* 123 */         return getName();
/*     */       }
/* 125 */       setName((QualifiedName)child);
/* 126 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 130 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 135 */     return 105;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 140 */     ModuleQualifiedName result = new ModuleQualifiedName(target);
/* 141 */     result.setSourceRange(getStartPosition(), getLength());
/* 142 */     result.setModuleQualifier((SimpleName)getModuleQualifier().clone(target));
/* 143 */     result.setName((QualifiedName)getName().clone(target));
/* 144 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 150 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 155 */     boolean visitChildren = visitor.visit(this);
/* 156 */     if (visitChildren) {
/*     */       
/* 158 */       acceptChild(visitor, getModuleQualifier());
/* 159 */       acceptChild(visitor, getName());
/*     */     } 
/* 161 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getModuleQualifier() {
/* 170 */     if (this.moduleQualifier == null)
/*     */     {
/* 172 */       synchronized (this) {
/* 173 */         if (this.moduleQualifier == null) {
/* 174 */           preLazyInit();
/* 175 */           this.moduleQualifier = new SimpleName(this.ast);
/* 176 */           postLazyInit(this.moduleQualifier, MODULE_QUALIFIER_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 180 */     return this.moduleQualifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModuleQualifier(Name moduleQualifier) {
/* 195 */     if (moduleQualifier == null) {
/* 196 */       throw new IllegalArgumentException();
/*     */     }
/* 198 */     ASTNode oldChild = this.moduleQualifier;
/* 199 */     preReplaceChild(oldChild, moduleQualifier, MODULE_QUALIFIER_PROPERTY);
/* 200 */     this.moduleQualifier = moduleQualifier;
/* 201 */     postReplaceChild(oldChild, moduleQualifier, MODULE_QUALIFIER_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getName() {
/* 210 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(Name name) {
/* 224 */     ASTNode oldChild = this.name;
/* 225 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 226 */     this.name = name;
/* 227 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   void appendName(StringBuffer buffer) {
/* 232 */     getModuleQualifier().appendName(buffer);
/* 233 */     buffer.append('/');
/* 234 */     if (getName() != null) {
/* 235 */       getName().appendName(buffer);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 241 */     return 56;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 246 */     return 
/* 247 */       memSize() + (
/* 248 */       (this.name == null) ? 0 : getName().treeSize()) + (
/* 249 */       (this.moduleQualifier == null) ? 0 : getModuleQualifier().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ModuleQualifiedName.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */