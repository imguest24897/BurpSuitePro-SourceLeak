/*     */ package org.eclipse.jdt.internal.codeassist.complete;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ast.AbstractMethodDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Argument;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Expression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.Javadoc;
/*     */ import org.eclipse.jdt.internal.compiler.ast.JavadocSingleNameReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeParameter;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.CompilationUnitScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ 
/*     */ public class CompletionJavadoc
/*     */   extends Javadoc
/*     */ {
/*     */   Expression completionNode;
/*     */   
/*     */   public CompletionJavadoc(int sourceStart, int sourceEnd) {
/*  27 */     super(sourceStart, sourceEnd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getCompletionNode() {
/*  34 */     return this.completionNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void internalResolve(Scope scope) {
/*  44 */     if (this.completionNode != null) {
/*  45 */       TypeBinding typeBinding; if (this.completionNode instanceof CompletionOnJavadocTag) {
/*  46 */         ((CompletionOnJavadocTag)this.completionNode).filterPossibleTags(scope);
/*     */       } else {
/*  48 */         boolean resolve = true;
/*  49 */         if (this.completionNode instanceof CompletionOnJavadocParamNameReference) {
/*  50 */           resolve = (((CompletionOnJavadocParamNameReference)this.completionNode).token != null);
/*  51 */         } else if (this.completionNode instanceof CompletionOnJavadocTypeParamReference) {
/*  52 */           resolve = (((CompletionOnJavadocTypeParamReference)this.completionNode).token != null);
/*     */         } 
/*  54 */         if (resolve) {
/*  55 */           switch (scope.kind) {
/*     */             case 3:
/*  57 */               this.completionNode.resolveType((ClassScope)scope);
/*     */               break;
/*     */             case 2:
/*  60 */               this.completionNode.resolveType((BlockScope)scope);
/*     */               break;
/*     */           } 
/*     */         }
/*  64 */         if (this.completionNode instanceof CompletionOnJavadocParamNameReference) {
/*  65 */           CompletionOnJavadocParamNameReference paramNameReference = (CompletionOnJavadocParamNameReference)this.completionNode;
/*  66 */           if (scope.kind == 2) {
/*  67 */             paramNameReference.missingParams = missingParamTags(paramNameReference.binding, (MethodScope)scope);
/*     */           }
/*  69 */           if (paramNameReference.token == null || paramNameReference.token.length == 0) {
/*  70 */             paramNameReference.missingTypeParams = missingTypeParameterTags(paramNameReference.binding, scope);
/*     */           }
/*  72 */         } else if (this.completionNode instanceof CompletionOnJavadocTypeParamReference) {
/*  73 */           CompletionOnJavadocTypeParamReference typeParamReference = (CompletionOnJavadocTypeParamReference)this.completionNode;
/*  74 */           typeParamReference.missingParams = missingTypeParameterTags((Binding)typeParamReference.resolvedType, scope);
/*     */         } 
/*     */       } 
/*  77 */       Binding qualifiedBinding = null;
/*  78 */       CompletionOnJavadocQualifiedTypeReference completionOnJavadocQualifiedTypeReference = null;
/*  79 */       if (this.completionNode instanceof CompletionOnJavadocModuleReference) {
/*  80 */         CompletionOnJavadocModuleReference modRef = (CompletionOnJavadocModuleReference)this.completionNode;
/*  81 */         TypeReference tRef = modRef.getTypeReference();
/*  82 */         if (tRef instanceof CompletionOnJavadocQualifiedTypeReference) {
/*  83 */           completionOnJavadocQualifiedTypeReference = (CompletionOnJavadocQualifiedTypeReference)tRef;
/*     */         }
/*     */       } 
/*  86 */       if (this.completionNode instanceof CompletionOnJavadocQualifiedTypeReference) {
/*  87 */         completionOnJavadocQualifiedTypeReference = (CompletionOnJavadocQualifiedTypeReference)this.completionNode;
/*     */       }
/*  89 */       if (completionOnJavadocQualifiedTypeReference != null) {
/*  90 */         if (completionOnJavadocQualifiedTypeReference.packageBinding == null) {
/*  91 */           typeBinding = completionOnJavadocQualifiedTypeReference.resolvedType;
/*     */         } else {
/*  93 */           PackageBinding packageBinding = completionOnJavadocQualifiedTypeReference.packageBinding;
/*     */         } 
/*  95 */       } else if (this.completionNode instanceof CompletionOnJavadocMessageSend) {
/*  96 */         CompletionOnJavadocMessageSend msg = (CompletionOnJavadocMessageSend)this.completionNode;
/*  97 */         if (!msg.receiver.isThis()) typeBinding = msg.receiver.resolvedType; 
/*  98 */       } else if (this.completionNode instanceof CompletionOnJavadocAllocationExpression) {
/*  99 */         CompletionOnJavadocAllocationExpression alloc = (CompletionOnJavadocAllocationExpression)this.completionNode;
/* 100 */         typeBinding = alloc.type.resolvedType;
/*     */       } 
/* 102 */       throw new CompletionNodeFound(this.completionNode, typeBinding, scope);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer print(int indent, StringBuffer output) {
/* 111 */     printIndent(indent, output).append("/**\n");
/* 112 */     boolean nodePrinted = false;
/* 113 */     if (this.paramReferences != null) {
/* 114 */       for (int i = 0, length = this.paramReferences.length; i < length; i++) {
/* 115 */         printIndent(indent, output).append(" * @param ");
/* 116 */         this.paramReferences[i].print(indent, output).append('\n');
/* 117 */         if (!nodePrinted && this.completionNode != null) {
/* 118 */           nodePrinted = (this.completionNode == this.paramReferences[i]);
/*     */         }
/*     */       } 
/*     */     }
/* 122 */     if (this.paramTypeParameters != null) {
/* 123 */       for (int i = 0, length = this.paramTypeParameters.length; i < length; i++) {
/* 124 */         printIndent(indent, output).append(" * @param <");
/* 125 */         this.paramTypeParameters[i].print(indent, output).append(">\n");
/* 126 */         if (!nodePrinted && this.completionNode != null) {
/* 127 */           nodePrinted = (this.completionNode == this.paramTypeParameters[i]);
/*     */         }
/*     */       } 
/*     */     }
/* 131 */     if (this.returnStatement != null) {
/* 132 */       printIndent(indent, output).append(" * @");
/* 133 */       this.returnStatement.print(indent, output).append('\n');
/*     */     } 
/* 135 */     if (this.exceptionReferences != null) {
/* 136 */       for (int i = 0, length = this.exceptionReferences.length; i < length; i++) {
/* 137 */         printIndent(indent, output).append(" * @throws ");
/* 138 */         this.exceptionReferences[i].print(indent, output).append('\n');
/* 139 */         if (!nodePrinted && this.completionNode != null) {
/* 140 */           nodePrinted = (this.completionNode == this.exceptionReferences[i]);
/*     */         }
/*     */       } 
/*     */     }
/* 144 */     if (this.seeReferences != null) {
/* 145 */       for (int i = 0, length = this.seeReferences.length; i < length; i++) {
/* 146 */         printIndent(indent, output).append(" * @see ");
/* 147 */         this.seeReferences[i].print(indent, output).append('\n');
/* 148 */         if (!nodePrinted && this.completionNode != null) {
/* 149 */           nodePrinted = (this.completionNode == this.seeReferences[i]);
/*     */         }
/*     */       } 
/*     */     }
/* 153 */     if (!nodePrinted && this.completionNode != null) {
/* 154 */       printIndent(indent, output).append(" * ");
/* 155 */       this.completionNode.print(indent, output).append('\n');
/*     */     } 
/* 157 */     printIndent(indent, output).append(" */\n");
/* 158 */     return output;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(ClassScope scope) {
/* 169 */     super.resolve(scope);
/* 170 */     internalResolve((Scope)scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(CompilationUnitScope scope) {
/* 181 */     internalResolve((Scope)scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(MethodScope scope) {
/* 192 */     super.resolve(scope);
/* 193 */     internalResolve((Scope)scope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private char[][] missingParamTags(Binding paramNameRefBinding, MethodScope methScope) {
/* 202 */     AbstractMethodDeclaration md = methScope.referenceMethod();
/* 203 */     int paramTagsSize = (this.paramReferences == null) ? 0 : this.paramReferences.length;
/* 204 */     if (md == null) return null; 
/* 205 */     int argumentsSize = (md.arguments == null) ? 0 : md.arguments.length;
/* 206 */     if (argumentsSize == 0) return null;
/*     */ 
/*     */     
/* 209 */     if (paramTagsSize == 0) {
/* 210 */       char[][] arrayOfChar = new char[argumentsSize][];
/* 211 */       for (int j = 0; j < argumentsSize; j++) {
/* 212 */         arrayOfChar[j] = (md.arguments[j]).name;
/*     */       }
/* 214 */       return arrayOfChar;
/*     */     } 
/*     */ 
/*     */     
/* 218 */     char[][] missingParams = new char[argumentsSize][];
/* 219 */     int size = 0;
/* 220 */     for (int i = 0; i < argumentsSize; i++) {
/* 221 */       Argument arg = md.arguments[i];
/* 222 */       boolean found = false;
/* 223 */       int paramNameRefCount = 0;
/* 224 */       for (int j = 0; j < paramTagsSize && !found; j++) {
/* 225 */         JavadocSingleNameReference param = this.paramReferences[j];
/* 226 */         if (arg.binding == param.binding) {
/* 227 */           if (param.binding == paramNameRefBinding) {
/* 228 */             paramNameRefCount++;
/* 229 */             found = (paramNameRefCount > 1);
/*     */           } else {
/* 231 */             found = true;
/*     */           } 
/*     */         }
/*     */       } 
/* 235 */       if (!found) {
/* 236 */         missingParams[size++] = arg.name;
/*     */       }
/*     */     } 
/* 239 */     if (size > 0) {
/* 240 */       if (size != argumentsSize) {
/* 241 */         System.arraycopy(missingParams, 0, missingParams = new char[size][], 0, size);
/*     */       }
/* 243 */       return missingParams;
/*     */     } 
/* 245 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private char[][] missingTypeParameterTags(Binding paramNameRefBinding, Scope scope) {
/*     */     AbstractMethodDeclaration methodDeclaration;
/*     */     TypeDeclaration typeDeclaration;
/* 252 */     int paramTypeParamLength = (this.paramTypeParameters == null) ? 0 : this.paramTypeParameters.length;
/*     */ 
/*     */     
/* 255 */     TypeParameter[] parameters = null;
/* 256 */     TypeVariableBinding[] typeVariables = null;
/* 257 */     switch (scope.kind) {
/*     */       case 2:
/* 259 */         methodDeclaration = ((MethodScope)scope).referenceMethod();
/* 260 */         if (methodDeclaration == null) return null; 
/* 261 */         parameters = methodDeclaration.typeParameters();
/* 262 */         typeVariables = methodDeclaration.binding.typeVariables;
/*     */         break;
/*     */       case 3:
/* 265 */         typeDeclaration = ((ClassScope)scope).referenceContext;
/* 266 */         parameters = typeDeclaration.typeParameters;
/* 267 */         typeVariables = typeDeclaration.binding.typeVariables;
/*     */         break;
/*     */     } 
/* 270 */     if (typeVariables == null || typeVariables.length == 0) return null;
/*     */ 
/*     */     
/* 273 */     if (parameters != null) {
/* 274 */       int typeParametersLength = parameters.length;
/* 275 */       if (paramTypeParamLength == 0) {
/* 276 */         char[][] arrayOfChar = new char[typeParametersLength][];
/* 277 */         for (int j = 0; j < typeParametersLength; j++) {
/* 278 */           arrayOfChar[j] = (parameters[j]).name;
/*     */         }
/* 280 */         return arrayOfChar;
/*     */       } 
/*     */ 
/*     */       
/* 284 */       char[][] missingParams = new char[typeParametersLength][];
/* 285 */       int size = 0;
/* 286 */       for (int i = 0; i < typeParametersLength; i++) {
/* 287 */         TypeParameter parameter = parameters[i];
/* 288 */         boolean found = false;
/* 289 */         int paramNameRefCount = 0;
/* 290 */         for (int j = 0; j < paramTypeParamLength && !found; j++) {
/* 291 */           if (TypeBinding.equalsEquals((TypeBinding)parameter.binding, (this.paramTypeParameters[j]).resolvedType)) {
/* 292 */             if (parameter.binding == paramNameRefBinding) {
/* 293 */               paramNameRefCount++;
/* 294 */               found = (paramNameRefCount > 1);
/*     */             } else {
/* 296 */               found = true;
/*     */             } 
/*     */           }
/*     */         } 
/* 300 */         if (!found) {
/* 301 */           missingParams[size++] = parameter.name;
/*     */         }
/*     */       } 
/* 304 */       if (size > 0) {
/* 305 */         if (size != typeParametersLength) {
/* 306 */           System.arraycopy(missingParams, 0, missingParams = new char[size][], 0, size);
/*     */         }
/* 308 */         return missingParams;
/*     */       } 
/*     */     } 
/* 311 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionJavadoc.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */