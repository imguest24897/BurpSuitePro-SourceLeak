/*      */ package org.eclipse.jdt.core.dom.rewrite;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.SubMonitor;
/*      */ import org.eclipse.jdt.core.Flags;
/*      */ import org.eclipse.jdt.core.ICompilationUnit;
/*      */ import org.eclipse.jdt.core.IImportDeclaration;
/*      */ import org.eclipse.jdt.core.IType;
/*      */ import org.eclipse.jdt.core.ITypeRoot;
/*      */ import org.eclipse.jdt.core.JavaCore;
/*      */ import org.eclipse.jdt.core.JavaModelException;
/*      */ import org.eclipse.jdt.core.Signature;
/*      */ import org.eclipse.jdt.core.compiler.CharOperation;
/*      */ import org.eclipse.jdt.core.dom.AST;
/*      */ import org.eclipse.jdt.core.dom.ASTParser;
/*      */ import org.eclipse.jdt.core.dom.AbstractTypeDeclaration;
/*      */ import org.eclipse.jdt.core.dom.AnnotatableType;
/*      */ import org.eclipse.jdt.core.dom.Annotation;
/*      */ import org.eclipse.jdt.core.dom.ArrayInitializer;
/*      */ import org.eclipse.jdt.core.dom.ArrayType;
/*      */ import org.eclipse.jdt.core.dom.CharacterLiteral;
/*      */ import org.eclipse.jdt.core.dom.CompilationUnit;
/*      */ import org.eclipse.jdt.core.dom.Dimension;
/*      */ import org.eclipse.jdt.core.dom.Expression;
/*      */ import org.eclipse.jdt.core.dom.FieldAccess;
/*      */ import org.eclipse.jdt.core.dom.IAnnotationBinding;
/*      */ import org.eclipse.jdt.core.dom.IBinding;
/*      */ import org.eclipse.jdt.core.dom.IMemberValuePairBinding;
/*      */ import org.eclipse.jdt.core.dom.IMethodBinding;
/*      */ import org.eclipse.jdt.core.dom.IPackageBinding;
/*      */ import org.eclipse.jdt.core.dom.ITypeBinding;
/*      */ import org.eclipse.jdt.core.dom.IVariableBinding;
/*      */ import org.eclipse.jdt.core.dom.ImportDeclaration;
/*      */ import org.eclipse.jdt.core.dom.MarkerAnnotation;
/*      */ import org.eclipse.jdt.core.dom.MemberValuePair;
/*      */ import org.eclipse.jdt.core.dom.Modifier;
/*      */ import org.eclipse.jdt.core.dom.Name;
/*      */ import org.eclipse.jdt.core.dom.NameQualifiedType;
/*      */ import org.eclipse.jdt.core.dom.NormalAnnotation;
/*      */ import org.eclipse.jdt.core.dom.ParameterizedType;
/*      */ import org.eclipse.jdt.core.dom.PrimitiveType;
/*      */ import org.eclipse.jdt.core.dom.SimpleName;
/*      */ import org.eclipse.jdt.core.dom.SimpleType;
/*      */ import org.eclipse.jdt.core.dom.SingleMemberAnnotation;
/*      */ import org.eclipse.jdt.core.dom.StringLiteral;
/*      */ import org.eclipse.jdt.core.dom.Type;
/*      */ import org.eclipse.jdt.core.dom.TypeLiteral;
/*      */ import org.eclipse.jdt.core.dom.WildcardType;
/*      */ import org.eclipse.jdt.internal.core.dom.rewrite.imports.ImportRewriteAnalyzer;
/*      */ import org.eclipse.jdt.internal.core.dom.rewrite.imports.ImportRewriteConfiguration;
/*      */ import org.eclipse.jdt.internal.core.util.Messages;
/*      */ import org.eclipse.jdt.internal.core.util.Util;
/*      */ import org.eclipse.text.edits.MultiTextEdit;
/*      */ import org.eclipse.text.edits.TextEdit;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ImportRewrite
/*      */ {
/*      */   private static final char STATIC_PREFIX = 's';
/*      */   private static final char NORMAL_PREFIX = 'n';
/*      */   private static final int JLS8_INTERNAL = 8;
/*      */   private final ImportRewriteContext defaultContext;
/*      */   private final ICompilationUnit compilationUnit;
/*      */   private final CompilationUnit astRoot;
/*      */   private final boolean restoreExistingImports;
/*      */   private final List existingImports;
/*      */   private final Map importsKindMap;
/*      */   private String[] importOrder;
/*      */   private int importOnDemandThreshold;
/*      */   private int staticImportOnDemandThreshold;
/*      */   private List<String> addedImports;
/*      */   private List<String> removedImports;
/*      */   private Set<String> typeExplicitSimpleNames;
/*      */   private Set<String> staticExplicitSimpleNames;
/*      */   private String[] createdImports;
/*      */   private String[] createdStaticImports;
/*      */   private boolean filterImplicitImports;
/*      */   private boolean useContextToFilterImplicitImports;
/*      */   
/*      */   public enum TypeLocation
/*      */   {
/*  117 */     PARAMETER,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  124 */     RETURN_TYPE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  131 */     FIELD,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  138 */     TYPE_PARAMETER,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  145 */     TYPE_BOUND,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  152 */     TYPE_ARGUMENT,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  159 */     ARRAY_CONTENTS,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  166 */     LOCAL_VARIABLE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  175 */     CAST,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  184 */     INSTANCEOF,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  193 */     NEW,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  202 */     RECEIVER,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  211 */     EXCEPTION,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  219 */     OTHER,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  228 */     UNKNOWN;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static abstract class ImportRewriteContext
/*      */   {
/*      */     public static final int RES_NAME_FOUND = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int RES_NAME_UNKNOWN = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int RES_NAME_CONFLICT = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int RES_NAME_UNKNOWN_NEEDS_EXPLICIT_IMPORT = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int KIND_TYPE = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int KIND_STATIC_FIELD = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int KIND_STATIC_METHOD = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract int findInContext(String param1String1, String param1String2, int param1Int);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IAnnotationBinding[] removeRedundantTypeAnnotations(IAnnotationBinding[] annotations, ImportRewrite.TypeLocation location, ITypeBinding type) {
/*  311 */       return annotations;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImportRewrite create(ICompilationUnit cu, boolean restoreExistingImports) throws JavaModelException {
/*  370 */     if (cu == null) {
/*  371 */       throw new IllegalArgumentException("Compilation unit must not be null");
/*      */     }
/*  373 */     List<String> existingImport = null;
/*  374 */     if (restoreExistingImports) {
/*  375 */       existingImport = new ArrayList();
/*  376 */       IImportDeclaration[] imports = cu.getImports();
/*  377 */       for (int i = 0; i < imports.length; i++) {
/*  378 */         IImportDeclaration curr = imports[i];
/*  379 */         char prefix = Flags.isStatic(curr.getFlags()) ? 's' : 'n';
/*  380 */         existingImport.add(String.valueOf(prefix) + curr.getElementName());
/*      */       } 
/*      */     } 
/*  383 */     return new ImportRewrite(cu, null, existingImport);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ImportRewrite create(CompilationUnit astRoot, boolean restoreExistingImports) {
/*  401 */     if (astRoot == null) {
/*  402 */       throw new IllegalArgumentException("AST must not be null");
/*      */     }
/*  404 */     ITypeRoot typeRoot = astRoot.getTypeRoot();
/*  405 */     if (!(typeRoot instanceof ICompilationUnit)) {
/*  406 */       throw new IllegalArgumentException("AST must have been constructed from a Java element");
/*      */     }
/*  408 */     List<String> existingImport = null;
/*  409 */     if (restoreExistingImports) {
/*  410 */       existingImport = new ArrayList();
/*  411 */       List<ImportDeclaration> imports = astRoot.imports();
/*  412 */       for (int i = 0; i < imports.size(); i++) {
/*  413 */         ImportDeclaration curr = imports.get(i);
/*  414 */         StringBuilder buf = new StringBuilder();
/*  415 */         buf.append(curr.isStatic() ? 115 : 110).append(curr.getName().getFullyQualifiedName());
/*  416 */         if (curr.isOnDemand()) {
/*  417 */           if (buf.length() > 1)
/*  418 */             buf.append('.'); 
/*  419 */           buf.append('*');
/*      */         } 
/*  421 */         existingImport.add(buf.toString());
/*      */       } 
/*      */     } 
/*  424 */     return new ImportRewrite((ICompilationUnit)typeRoot, astRoot, existingImport);
/*      */   }
/*      */   
/*      */   private ImportRewrite(ICompilationUnit cu, CompilationUnit astRoot, List existingImports) {
/*  428 */     this.compilationUnit = cu;
/*  429 */     this.astRoot = astRoot;
/*  430 */     if (existingImports != null) {
/*  431 */       this.existingImports = existingImports;
/*  432 */       this.restoreExistingImports = !existingImports.isEmpty();
/*      */     } else {
/*  434 */       this.existingImports = new ArrayList();
/*  435 */       this.restoreExistingImports = false;
/*      */     } 
/*  437 */     this.filterImplicitImports = true;
/*      */     
/*  439 */     this.useContextToFilterImplicitImports = false;
/*      */     
/*  441 */     this.defaultContext = new ImportRewriteContext()
/*      */       {
/*      */         public int findInContext(String qualifier, String name, int kind) {
/*  444 */           return ImportRewrite.this.findInImports(qualifier, name, kind);
/*      */         }
/*      */       };
/*  447 */     this.addedImports = new ArrayList<>();
/*  448 */     this.removedImports = new ArrayList<>();
/*  449 */     this.typeExplicitSimpleNames = new HashSet<>();
/*  450 */     this.staticExplicitSimpleNames = new HashSet<>();
/*  451 */     this.createdImports = null;
/*  452 */     this.createdStaticImports = null;
/*      */     
/*  454 */     this.importOrder = CharOperation.NO_STRINGS;
/*  455 */     this.importOnDemandThreshold = 99;
/*  456 */     this.staticImportOnDemandThreshold = 99;
/*      */     
/*  458 */     this.importsKindMap = new HashMap<>();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setImportOrder(String[] order) {
/*  470 */     if (order == null)
/*  471 */       throw new IllegalArgumentException("Order must not be null"); 
/*  472 */     this.importOrder = order;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOnDemandImportThreshold(int threshold) {
/*  486 */     if (threshold <= 0)
/*  487 */       throw new IllegalArgumentException("Threshold must be positive."); 
/*  488 */     this.importOnDemandThreshold = threshold;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStaticOnDemandImportThreshold(int threshold) {
/*  502 */     if (threshold <= 0)
/*  503 */       throw new IllegalArgumentException("Threshold must be positive."); 
/*  504 */     this.staticImportOnDemandThreshold = threshold;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ICompilationUnit getCompilationUnit() {
/*  512 */     return this.compilationUnit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ImportRewriteContext getDefaultImportRewriteContext() {
/*  521 */     return this.defaultContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFilterImplicitImports(boolean filterImplicitImports) {
/*  542 */     this.filterImplicitImports = filterImplicitImports;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseContextToFilterImplicitImports(boolean useContextToFilterImplicitImports) {
/*  562 */     this.useContextToFilterImplicitImports = useContextToFilterImplicitImports;
/*      */   }
/*      */   
/*      */   private static int compareImport(char prefix, String qualifier, String name, String curr) {
/*  566 */     if (curr.charAt(0) != prefix || !curr.endsWith(name)) {
/*  567 */       return 2;
/*      */     }
/*      */     
/*  570 */     curr = curr.substring(1);
/*      */     
/*  572 */     if (curr.length() == name.length()) {
/*  573 */       if (qualifier.length() == 0) {
/*  574 */         return 1;
/*      */       }
/*  576 */       return 3;
/*      */     } 
/*      */ 
/*      */     
/*  580 */     int dotPos = curr.length() - name.length() - 1;
/*  581 */     if (curr.charAt(dotPos) != '.') {
/*  582 */       return 2;
/*      */     }
/*  584 */     if (qualifier.length() != dotPos || !curr.startsWith(qualifier)) {
/*  585 */       return 3;
/*      */     }
/*  587 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int findInImports(String qualifier, String name, int kind) {
/*  594 */     boolean allowAmbiguity = !(kind != 3 && (name.length() != 1 || name.charAt(0) != '*'));
/*  595 */     List<String> imports = this.existingImports;
/*  596 */     char prefix = (kind == 1) ? 'n' : 's';
/*      */     
/*  598 */     for (int i = imports.size() - 1; i >= 0; i--) {
/*  599 */       String curr = imports.get(i);
/*  600 */       int res = compareImport(prefix, qualifier, name, curr);
/*  601 */       if (res != 2 && (
/*  602 */         !allowAmbiguity || res == 1)) {
/*  603 */         if (prefix != 's') {
/*  604 */           return res;
/*      */         }
/*  606 */         Object currKind = this.importsKindMap.get(curr.substring(1));
/*  607 */         if (currKind != null && currKind.equals(this.importsKindMap.get(String.valueOf(qualifier) + '.' + name))) {
/*  608 */           return res;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  614 */     String packageName = this.compilationUnit.getParent().getElementName();
/*  615 */     if (kind == 1 && 
/*  616 */       this.filterImplicitImports && this.useContextToFilterImplicitImports) {
/*  617 */       String mainTypeSimpleName = JavaCore.removeJavaLikeExtension(this.compilationUnit.getElementName());
/*  618 */       String mainTypeName = Util.concatenateName(packageName, mainTypeSimpleName, '.');
/*  619 */       if (qualifier.equals(packageName) || 
/*  620 */         mainTypeName.equals(Util.concatenateName(qualifier, name, '.'))) {
/*  621 */         return 1;
/*      */       }
/*      */       
/*  624 */       if (this.astRoot != null) {
/*  625 */         List<AbstractTypeDeclaration> types = this.astRoot.types();
/*  626 */         int nTypes = types.size();
/*  627 */         for (int j = 0; j < nTypes; j++) {
/*  628 */           AbstractTypeDeclaration type = types.get(j);
/*  629 */           SimpleName simpleName = type.getName();
/*  630 */           if (simpleName.getIdentifier().equals(name)) {
/*  631 */             return qualifier.equals(packageName) ? 
/*  632 */               1 : 
/*  633 */               3;
/*      */           }
/*      */         } 
/*      */       } else {
/*      */         try {
/*  638 */           IType[] types = this.compilationUnit.getTypes();
/*  639 */           int nTypes = types.length;
/*  640 */           for (int j = 0; j < nTypes; j++) {
/*  641 */             IType type = types[j];
/*  642 */             String typeName = type.getElementName();
/*  643 */             if (typeName.equals(name)) {
/*  644 */               return qualifier.equals(packageName) ? 
/*  645 */                 1 : 
/*  646 */                 3;
/*      */             }
/*      */           } 
/*  649 */         } catch (JavaModelException javaModelException) {}
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  656 */     return 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Annotation addAnnotation(IAnnotationBinding annotation, AST ast, ImportRewriteContext context) {
/*      */     Name name;
/*  679 */     Type type = addImport(annotation.getAnnotationType(), ast, context, TypeLocation.OTHER);
/*      */     
/*  681 */     if (type instanceof SimpleType) {
/*  682 */       SimpleType simpleType = (SimpleType)type;
/*  683 */       name = simpleType.getName();
/*      */       
/*  685 */       simpleType.setName(ast.newName("a"));
/*      */     } else {
/*  687 */       name = ast.newName("invalid");
/*      */     } 
/*      */     
/*  690 */     IMemberValuePairBinding[] mvps = annotation.getDeclaredMemberValuePairs();
/*  691 */     if (mvps.length == 0) {
/*  692 */       MarkerAnnotation markerAnnotation = ast.newMarkerAnnotation();
/*  693 */       markerAnnotation.setTypeName(name);
/*  694 */       return (Annotation)markerAnnotation;
/*  695 */     }  if (mvps.length == 1 && "value".equals(mvps[0].getName())) {
/*  696 */       SingleMemberAnnotation singleMemberAnnotation = ast.newSingleMemberAnnotation();
/*  697 */       singleMemberAnnotation.setTypeName(name);
/*  698 */       Object value = mvps[0].getValue();
/*  699 */       if (value != null)
/*  700 */         singleMemberAnnotation.setValue(addAnnotation(ast, value, context)); 
/*  701 */       return (Annotation)singleMemberAnnotation;
/*      */     } 
/*  703 */     NormalAnnotation result = ast.newNormalAnnotation();
/*  704 */     result.setTypeName(name);
/*  705 */     for (int i = 0; i < mvps.length; i++) {
/*  706 */       IMemberValuePairBinding mvp = mvps[i];
/*  707 */       MemberValuePair mvpNode = ast.newMemberValuePair();
/*  708 */       mvpNode.setName(ast.newSimpleName(mvp.getName()));
/*  709 */       Object value = mvp.getValue();
/*  710 */       if (value != null)
/*  711 */         mvpNode.setValue(addAnnotation(ast, value, context)); 
/*  712 */       result.values().add(mvpNode);
/*      */     } 
/*  714 */     return (Annotation)result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Type addImportFromSignature(String typeSig, AST ast) {
/*  737 */     return addImportFromSignature(typeSig, ast, this.defaultContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Type addImportFromSignature(String typeSig, AST ast, ImportRewriteContext context) {
/*      */     Type elementType;
/*      */     String erasureSig, erasureName;
/*      */     SimpleType simpleType;
/*      */     String[] typeArguments;
/*      */     WildcardType wildcardType;
/*      */     char ch;
/*  761 */     if (typeSig == null || typeSig.length() == 0) {
/*  762 */       throw new IllegalArgumentException("Invalid type signature: empty or null");
/*      */     }
/*  764 */     int sigKind = Signature.getTypeSignatureKind(typeSig);
/*  765 */     switch (sigKind) {
/*      */       case 2:
/*  767 */         return (Type)ast.newPrimitiveType(PrimitiveType.toCode(Signature.toString(typeSig)));
/*      */       case 4:
/*  769 */         elementType = addImportFromSignature(Signature.getElementType(typeSig), ast, context);
/*  770 */         return (Type)ast.newArrayType(elementType, Signature.getArrayCount(typeSig));
/*      */       case 1:
/*  772 */         erasureSig = Signature.getTypeErasure(typeSig);
/*      */         
/*  774 */         erasureName = Signature.toString(erasureSig);
/*  775 */         if (erasureSig.charAt(0) == 'L') {
/*  776 */           erasureName = internalAddImport(erasureName, context, false);
/*      */         }
/*  778 */         simpleType = ast.newSimpleType(ast.newName(erasureName));
/*  779 */         typeArguments = Signature.getTypeArguments(typeSig);
/*  780 */         if (typeArguments.length > 0) {
/*  781 */           ParameterizedType type = ast.newParameterizedType((Type)simpleType);
/*  782 */           List<WildcardType> argNodes = type.typeArguments();
/*  783 */           for (int i = 0; i < typeArguments.length; i++) {
/*  784 */             String curr = typeArguments[i];
/*  785 */             if (containsNestedCapture(curr)) {
/*  786 */               argNodes.add(ast.newWildcardType());
/*      */             } else {
/*  788 */               argNodes.add(addImportFromSignature(curr, ast, context));
/*      */             } 
/*      */           } 
/*  791 */           return (Type)type;
/*      */         } 
/*  793 */         return (Type)simpleType;
/*      */       case 3:
/*  795 */         return (Type)ast.newSimpleType((Name)ast.newSimpleName(Signature.toString(typeSig)));
/*      */       case 5:
/*  797 */         wildcardType = ast.newWildcardType();
/*  798 */         ch = typeSig.charAt(0);
/*  799 */         if (ch != '*') {
/*  800 */           Type bound = addImportFromSignature(typeSig.substring(1), ast, context);
/*  801 */           wildcardType.setBound(bound, (ch == '+'));
/*      */         } 
/*  803 */         return (Type)wildcardType;
/*      */       case 6:
/*  805 */         return addImportFromSignature(typeSig.substring(1), ast, context);
/*      */     } 
/*  807 */     throw new IllegalArgumentException("Unknown type signature kind: " + typeSig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addImport(ITypeBinding binding) {
/*  831 */     return addImport(binding, this.defaultContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addImport(ITypeBinding binding, ImportRewriteContext context) {
/*  854 */     if (binding.isPrimitive() || binding.isTypeVariable() || binding.isRecovered()) {
/*  855 */       return binding.getName();
/*      */     }
/*      */     
/*  858 */     ITypeBinding normalizedBinding = normalizeTypeBinding(binding);
/*  859 */     if (normalizedBinding == null) {
/*  860 */       return "invalid";
/*      */     }
/*  862 */     if (normalizedBinding.isWildcardType()) {
/*  863 */       StringBuilder res = new StringBuilder("?");
/*  864 */       ITypeBinding bound = normalizedBinding.getBound();
/*  865 */       if (bound != null && !bound.isWildcardType() && !bound.isCapture()) {
/*  866 */         if (normalizedBinding.isUpperbound()) {
/*  867 */           res.append(" extends ");
/*      */         } else {
/*  869 */           res.append(" super ");
/*      */         } 
/*  871 */         res.append(addImport(bound, context));
/*      */       } 
/*  873 */       return res.toString();
/*      */     } 
/*      */     
/*  876 */     if (normalizedBinding.isArray()) {
/*  877 */       StringBuilder res = new StringBuilder(addImport(normalizedBinding.getElementType(), context));
/*  878 */       for (int i = normalizedBinding.getDimensions(); i > 0; i--) {
/*  879 */         res.append("[]");
/*      */       }
/*  881 */       return res.toString();
/*      */     } 
/*      */     
/*  884 */     String qualifiedName = getRawQualifiedName(normalizedBinding);
/*  885 */     if (qualifiedName.length() > 0) {
/*  886 */       String str = internalAddImport(qualifiedName, context, isTypeInUnnamedPackage(normalizedBinding));
/*      */       
/*  888 */       ITypeBinding[] typeArguments = normalizedBinding.getTypeArguments();
/*  889 */       if (typeArguments.length > 0) {
/*  890 */         StringBuilder res = new StringBuilder(str);
/*  891 */         res.append('<');
/*  892 */         for (int i = 0; i < typeArguments.length; i++) {
/*  893 */           if (i > 0) {
/*  894 */             res.append(',');
/*      */           }
/*  896 */           ITypeBinding curr = typeArguments[i];
/*  897 */           if (containsNestedCapture(curr, false)) {
/*  898 */             res.append('?');
/*      */           } else {
/*  900 */             res.append(addImport(curr, context));
/*      */           } 
/*      */         } 
/*  903 */         res.append('>');
/*  904 */         return res.toString();
/*      */       } 
/*  906 */       return str;
/*      */     } 
/*  908 */     return getRawName(normalizedBinding);
/*      */   }
/*      */   
/*      */   private boolean containsNestedCapture(ITypeBinding binding, boolean isNested) {
/*  912 */     if (binding == null || binding.isPrimitive() || binding.isTypeVariable()) {
/*  913 */       return false;
/*      */     }
/*  915 */     if (binding.isCapture()) {
/*  916 */       if (isNested) {
/*  917 */         return true;
/*      */       }
/*  919 */       return containsNestedCapture(binding.getWildcard(), true);
/*      */     } 
/*  921 */     if (binding.isWildcardType()) {
/*  922 */       return containsNestedCapture(binding.getBound(), true);
/*      */     }
/*  924 */     if (binding.isArray()) {
/*  925 */       return containsNestedCapture(binding.getElementType(), true);
/*      */     }
/*  927 */     ITypeBinding[] typeArguments = binding.getTypeArguments();
/*  928 */     for (int i = 0; i < typeArguments.length; i++) {
/*  929 */       if (containsNestedCapture(typeArguments[i], true)) {
/*  930 */         return true;
/*      */       }
/*      */     } 
/*  933 */     return false;
/*      */   }
/*      */   
/*      */   private boolean containsNestedCapture(String signature) {
/*  937 */     return (signature.length() > 1 && signature.indexOf('!', 1) != -1);
/*      */   }
/*      */   
/*      */   private static ITypeBinding normalizeTypeBinding(ITypeBinding binding) {
/*  941 */     if (binding != null && !binding.isNullType() && !"void".equals(binding.getName())) {
/*  942 */       if (binding.isAnonymous()) {
/*  943 */         ITypeBinding[] baseBindings = binding.getInterfaces();
/*  944 */         if (baseBindings.length > 0) {
/*  945 */           return baseBindings[0];
/*      */         }
/*  947 */         return binding.getSuperclass();
/*      */       } 
/*  949 */       if (binding.isCapture()) {
/*  950 */         return binding.getWildcard();
/*      */       }
/*  952 */       return binding;
/*      */     } 
/*  954 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Type addImport(ITypeBinding binding, AST ast) {
/*  977 */     return addImport(binding, ast, this.defaultContext, TypeLocation.UNKNOWN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Type addImport(ITypeBinding binding, AST ast, ImportRewriteContext context) {
/* 1002 */     return addImport(binding, ast, context, TypeLocation.UNKNOWN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Type addImport(ITypeBinding binding, AST ast, ImportRewriteContext context, TypeLocation location) {
/* 1029 */     ITypeBinding bindingPoint = checkAnnotationAndGenerics(binding);
/* 1030 */     Type type = internalAddImport((bindingPoint == null) ? binding : bindingPoint, ast, context, null, true, (bindingPoint != null && !bindingPoint.equals(binding)) ? TypeLocation.OTHER : location);
/* 1031 */     if (bindingPoint != null && !bindingPoint.equals(binding)) {
/* 1032 */       type = buildType(binding, bindingPoint, ast, context, type, location);
/*      */     }
/* 1034 */     return type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addImport(String qualifiedTypeName, ImportRewriteContext context) {
/* 1054 */     int angleBracketOffset = qualifiedTypeName.indexOf('<');
/* 1055 */     if (angleBracketOffset != -1) {
/* 1056 */       return String.valueOf(internalAddImport(qualifiedTypeName.substring(0, angleBracketOffset), context, false)) + qualifiedTypeName.substring(angleBracketOffset);
/*      */     }
/* 1058 */     int bracketOffset = qualifiedTypeName.indexOf('[');
/* 1059 */     if (bracketOffset != -1) {
/* 1060 */       return String.valueOf(internalAddImport(qualifiedTypeName.substring(0, bracketOffset), context, false)) + qualifiedTypeName.substring(bracketOffset);
/*      */     }
/* 1062 */     return internalAddImport(qualifiedTypeName, context, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addImport(String qualifiedTypeName) {
/* 1080 */     return addImport(qualifiedTypeName, this.defaultContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addStaticImport(IBinding binding) {
/* 1100 */     return addStaticImport(binding, this.defaultContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addStaticImport(IBinding binding, ImportRewriteContext context) {
/* 1122 */     if (Modifier.isStatic(binding.getModifiers())) {
/* 1123 */       if (binding instanceof IVariableBinding) {
/* 1124 */         IVariableBinding variableBinding = (IVariableBinding)binding;
/* 1125 */         if (variableBinding.isField()) {
/* 1126 */           ITypeBinding declaringType = variableBinding.getDeclaringClass();
/* 1127 */           return addStaticImport(getRawQualifiedName(declaringType), binding.getName(), true, context);
/*      */         } 
/* 1129 */       } else if (binding instanceof IMethodBinding) {
/* 1130 */         ITypeBinding declaringType = ((IMethodBinding)binding).getDeclaringClass();
/* 1131 */         return addStaticImport(getRawQualifiedName(declaringType), binding.getName(), false, context);
/*      */       } 
/*      */     }
/* 1134 */     throw new IllegalArgumentException("Binding must be a static field or method.");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addStaticImport(String declaringTypeName, String simpleName, boolean isField) {
/* 1155 */     return addStaticImport(declaringTypeName, simpleName, isField, this.defaultContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addStaticImport(String declaringTypeName, String simpleName, boolean isField, ImportRewriteContext context) {
/* 1178 */     String key = String.valueOf(declaringTypeName) + '.' + simpleName;
/* 1179 */     if (declaringTypeName.indexOf('.') == -1) {
/* 1180 */       return key;
/*      */     }
/* 1182 */     if (context == null) {
/* 1183 */       context = this.defaultContext;
/*      */     }
/* 1185 */     int kind = isField ? 2 : 3;
/* 1186 */     this.importsKindMap.put(key, Integer.valueOf(kind));
/* 1187 */     int res = context.findInContext(declaringTypeName, simpleName, kind);
/* 1188 */     if (res == 3) {
/* 1189 */       return key;
/*      */     }
/* 1191 */     if (res == 2) {
/* 1192 */       addEntry(String.valueOf('s') + key);
/*      */     }
/* 1194 */     if (res == 4) {
/* 1195 */       addEntry(String.valueOf('s') + key);
/* 1196 */       this.staticExplicitSimpleNames.add(simpleName);
/*      */     } 
/* 1198 */     return simpleName;
/*      */   }
/*      */   private String internalAddImport(String fullTypeName, ImportRewriteContext context, boolean isTypeInUnnamedPackage) {
/*      */     String typeContainerName, typeName;
/* 1202 */     int idx = fullTypeName.lastIndexOf('.');
/*      */     
/* 1204 */     if (idx != -1) {
/* 1205 */       typeContainerName = fullTypeName.substring(0, idx);
/* 1206 */       typeName = fullTypeName.substring(idx + 1);
/*      */     } else {
/* 1208 */       typeContainerName = "";
/* 1209 */       typeName = fullTypeName;
/*      */     } 
/*      */     
/* 1212 */     if (typeContainerName.length() == 0 && PrimitiveType.toCode(typeName) != null) {
/* 1213 */       return fullTypeName;
/*      */     }
/*      */     
/* 1216 */     if (context == null) {
/* 1217 */       context = this.defaultContext;
/*      */     }
/* 1219 */     int res = context.findInContext(typeContainerName, typeName, 1);
/* 1220 */     if (res == 3 || 
/* 1221 */       isTypeInUnnamedPackage) {
/* 1222 */       return fullTypeName;
/*      */     }
/* 1224 */     if (res == 2) {
/* 1225 */       addEntry(String.valueOf('n') + fullTypeName);
/*      */     }
/* 1227 */     if (res == 4) {
/* 1228 */       addEntry(String.valueOf('n') + fullTypeName);
/* 1229 */       this.typeExplicitSimpleNames.add(typeName);
/*      */     } 
/* 1231 */     return typeName;
/*      */   }
/*      */   
/*      */   private void addEntry(String entry) {
/* 1235 */     this.existingImports.add(entry);
/*      */     
/* 1237 */     if (this.removedImports.remove(entry)) {
/*      */       return;
/*      */     }
/*      */     
/* 1241 */     this.addedImports.add(entry);
/*      */   }
/*      */   
/*      */   private boolean removeEntry(String entry) {
/* 1245 */     if (this.existingImports.remove(entry)) {
/* 1246 */       if (this.addedImports.remove(entry)) {
/* 1247 */         return true;
/*      */       }
/*      */       
/* 1250 */       this.removedImports.add(entry);
/*      */       
/* 1252 */       return true;
/*      */     } 
/* 1254 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean removeImport(String qualifiedName) {
/* 1268 */     return removeEntry(String.valueOf('n') + qualifiedName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean removeStaticImport(String qualifiedName) {
/* 1282 */     return removeEntry(String.valueOf('s') + qualifiedName);
/*      */   }
/*      */   
/*      */   private static String getRawName(ITypeBinding normalizedBinding) {
/* 1286 */     return normalizedBinding.getTypeDeclaration().getName();
/*      */   }
/*      */   
/*      */   private static String getRawQualifiedName(ITypeBinding normalizedBinding) {
/* 1290 */     return normalizedBinding.getTypeDeclaration().getQualifiedName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final TextEdit rewriteImports(IProgressMonitor monitor) throws CoreException {
/* 1309 */     SubMonitor subMonitor = SubMonitor.convert(monitor, 
/* 1310 */         Messages.bind(Messages.importRewrite_processDescription), 2);
/* 1311 */     if (!hasRecordedChanges()) {
/* 1312 */       this.createdImports = CharOperation.NO_STRINGS;
/* 1313 */       this.createdStaticImports = CharOperation.NO_STRINGS;
/* 1314 */       return (TextEdit)new MultiTextEdit();
/*      */     } 
/*      */     
/* 1317 */     CompilationUnit usedAstRoot = this.astRoot;
/* 1318 */     if (usedAstRoot == null) {
/* 1319 */       ASTParser parser = ASTParser.newParser(AST.getJLSLatest());
/* 1320 */       parser.setSource(this.compilationUnit);
/* 1321 */       parser.setFocalPosition(0);
/* 1322 */       parser.setResolveBindings(false);
/* 1323 */       usedAstRoot = (CompilationUnit)parser.createAST((IProgressMonitor)subMonitor.split(1));
/*      */     } 
/*      */     
/* 1326 */     ImportRewriteConfiguration config = buildImportRewriteConfiguration();
/*      */     
/* 1328 */     ImportRewriteAnalyzer computer = 
/* 1329 */       new ImportRewriteAnalyzer(this.compilationUnit, usedAstRoot, config);
/*      */     
/* 1331 */     for (String addedImport : this.addedImports) {
/* 1332 */       boolean isStatic = ('s' == addedImport.charAt(0));
/* 1333 */       String qualifiedName = addedImport.substring(1);
/* 1334 */       computer.addImport(isStatic, qualifiedName);
/*      */     } 
/*      */     
/* 1337 */     for (String removedImport : this.removedImports) {
/* 1338 */       boolean isStatic = ('s' == removedImport.charAt(0));
/* 1339 */       String qualifiedName = removedImport.substring(1);
/* 1340 */       computer.removeImport(isStatic, qualifiedName);
/*      */     } 
/*      */     
/* 1343 */     for (String typeExplicitSimpleName : this.typeExplicitSimpleNames) {
/* 1344 */       computer.requireExplicitImport(false, typeExplicitSimpleName);
/*      */     }
/*      */     
/* 1347 */     for (String staticExplicitSimpleName : this.staticExplicitSimpleNames) {
/* 1348 */       computer.requireExplicitImport(true, staticExplicitSimpleName);
/*      */     }
/*      */     
/* 1351 */     ImportRewriteAnalyzer.RewriteResult result = computer.analyzeRewrite((IProgressMonitor)subMonitor.split(1));
/*      */     
/* 1353 */     this.createdImports = result.getCreatedImports();
/* 1354 */     this.createdStaticImports = result.getCreatedStaticImports();
/*      */     
/* 1356 */     return result.getTextEdit();
/*      */   }
/*      */ 
/*      */   
/*      */   private ImportRewriteConfiguration buildImportRewriteConfiguration() {
/*      */     ImportRewriteConfiguration.Builder configBuilder;
/* 1362 */     if (this.restoreExistingImports) {
/* 1363 */       configBuilder = ImportRewriteConfiguration.Builder.preservingOriginalImports();
/*      */     } else {
/* 1365 */       configBuilder = ImportRewriteConfiguration.Builder.discardingOriginalImports();
/*      */     } 
/*      */     
/* 1368 */     configBuilder.setImportOrder(Arrays.asList(this.importOrder));
/* 1369 */     configBuilder.setTypeOnDemandThreshold(this.importOnDemandThreshold);
/* 1370 */     configBuilder.setStaticOnDemandThreshold(this.staticImportOnDemandThreshold);
/*      */     
/* 1372 */     configBuilder.setTypeContainerSorting(this.useContextToFilterImplicitImports ? 
/* 1373 */         ImportRewriteConfiguration.ImportContainerSorting.BY_PACKAGE : ImportRewriteConfiguration.ImportContainerSorting.BY_PACKAGE_AND_CONTAINING_TYPE);
/*      */     
/* 1375 */     configBuilder.setStaticContainerSorting(ImportRewriteConfiguration.ImportContainerSorting.BY_PACKAGE_AND_CONTAINING_TYPE);
/*      */     
/* 1377 */     configBuilder.setImplicitImportIdentification(this.filterImplicitImports ? 
/* 1378 */         ImportRewriteConfiguration.ImplicitImportIdentification.JAVA_LANG_AND_CU_PACKAGE : ImportRewriteConfiguration.ImplicitImportIdentification.NONE);
/*      */     
/* 1380 */     return configBuilder.build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getCreatedImports() {
/* 1393 */     return this.createdImports;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getCreatedStaticImports() {
/* 1406 */     return this.createdStaticImports;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getAddedImports() {
/* 1415 */     return filterFromList(this.addedImports, 'n');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getAddedStaticImports() {
/* 1424 */     return filterFromList(this.addedImports, 's');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getRemovedImports() {
/* 1433 */     return filterFromList(this.removedImports, 'n');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getRemovedStaticImports() {
/* 1442 */     return filterFromList(this.removedImports, 's');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasRecordedChanges() {
/* 1450 */     return !(this.restoreExistingImports && 
/* 1451 */       this.addedImports.isEmpty() && 
/* 1452 */       this.removedImports.isEmpty());
/*      */   }
/*      */ 
/*      */   
/*      */   private static String[] filterFromList(List<String> imports, char prefix) {
/* 1457 */     if (imports == null) {
/* 1458 */       return CharOperation.NO_STRINGS;
/*      */     }
/* 1460 */     List<String> res = new ArrayList<>();
/* 1461 */     for (String curr : imports) {
/* 1462 */       if (prefix == curr.charAt(0)) {
/* 1463 */         res.add(curr.substring(1));
/*      */       }
/*      */     } 
/* 1466 */     return res.<String>toArray(new String[res.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   private void annotateList(List<Annotation> annotations, IAnnotationBinding[] annotationBindings, AST ast, ImportRewriteContext context, TypeLocation location, ITypeBinding type) {
/* 1471 */     if (context == null)
/* 1472 */       context = this.defaultContext; 
/* 1473 */     annotationBindings = context.removeRedundantTypeAnnotations(annotationBindings, location, type);
/* 1474 */     for (int i = 0; i < annotationBindings.length; i++) {
/* 1475 */       Annotation annotation = addAnnotation(annotationBindings[i], ast, context);
/* 1476 */       if (annotation != null) annotations.add(annotation); 
/*      */     } 
/*      */   }
/*      */   
/*      */   private Type annotateType(ITypeBinding binding, AST ast, ImportRewriteContext context, Type type, TypeLocation location) {
/* 1481 */     IAnnotationBinding[] annotationBindings = binding.getTypeAnnotations();
/* 1482 */     if (annotationBindings != null && annotationBindings.length > 0 && type instanceof AnnotatableType) {
/* 1483 */       annotateList(((AnnotatableType)type).annotations(), annotationBindings, ast, context, location, binding);
/*      */     }
/* 1485 */     return type;
/*      */   }
/*      */   
/*      */   private Type buildType(ITypeBinding binding, ITypeBinding bindingPoint, AST ast, ImportRewriteContext context, Type qualifier, TypeLocation location) {
/* 1489 */     if (binding.equals(bindingPoint)) {
/* 1490 */       return qualifier;
/*      */     }
/*      */     
/* 1493 */     Type type = binding.isMember() ? buildType(binding.getDeclaringClass(), bindingPoint, ast, context, qualifier, TypeLocation.OTHER) : null;
/* 1494 */     type = internalAddImport(binding, ast, context, type, false, location);
/* 1495 */     return type;
/*      */   }
/*      */   
/*      */   private ITypeBinding checkAnnotationAndGenerics(ITypeBinding binding) {
/* 1499 */     ITypeBinding bindingPoint = null;
/* 1500 */     while (binding != null) {
/* 1501 */       IAnnotationBinding[] annotationBinding = binding.getTypeAnnotations();
/* 1502 */       ITypeBinding[] typeArguments = binding.getTypeArguments();
/* 1503 */       if ((annotationBinding != null && annotationBinding.length > 0) || (
/* 1504 */         typeArguments != null && typeArguments.length > 0)) {
/* 1505 */         bindingPoint = binding;
/*      */       }
/* 1507 */       if (binding.isMember()) {
/* 1508 */         binding = binding.getDeclaringClass();
/*      */         continue;
/*      */       } 
/*      */       break;
/*      */     } 
/* 1513 */     return bindingPoint;
/*      */   }
/*      */   
/*      */   private Type createBaseType(AST ast, ImportRewriteContext context, ITypeBinding normalizedBinding, TypeLocation location) {
/*      */     SimpleType simpleType;
/* 1518 */     IAnnotationBinding[] annotationBinding = normalizedBinding.getTypeAnnotations();
/* 1519 */     boolean annotsPresent = (annotationBinding != null && annotationBinding.length > 0);
/*      */     
/* 1521 */     String qualifiedName = getRawQualifiedName(normalizedBinding);
/* 1522 */     String res = (qualifiedName.length() > 0) ? internalAddImport(qualifiedName, context, isTypeInUnnamedPackage(normalizedBinding)) : getRawName(normalizedBinding);
/*      */     
/* 1524 */     if (annotsPresent) {
/* 1525 */       int dotIndex = (res != null) ? res.lastIndexOf('.') : -1;
/* 1526 */       if (dotIndex > 0) {
/* 1527 */         Name nameQualifier = ast.newName(res.substring(0, dotIndex));
/* 1528 */         SimpleName simpleName = ast.newSimpleName(res.substring(dotIndex + 1));
/* 1529 */         NameQualifiedType nameQualifiedType = ast.newNameQualifiedType(nameQualifier, simpleName);
/*      */       } else {
/* 1531 */         simpleType = ast.newSimpleType(ast.newName(res));
/*      */       } 
/* 1533 */       annotateList(((AnnotatableType)simpleType).annotations(), annotationBinding, ast, context, location, normalizedBinding);
/*      */     } else {
/* 1535 */       simpleType = ast.newSimpleType(ast.newName(res));
/*      */     } 
/* 1537 */     return (Type)simpleType;
/*      */   }
/*      */   
/*      */   private Type getArrayType(Type elementType, AST ast, ImportRewriteContext context, ITypeBinding normalizedBinding, TypeLocation location) {
/* 1541 */     int noDimensions = normalizedBinding.getDimensions();
/* 1542 */     ArrayType arrayType = ast.newArrayType(elementType, noDimensions);
/* 1543 */     if (ast.apiLevel() >= 8) {
/* 1544 */       for (int i = 0; i < noDimensions; i++) {
/* 1545 */         IAnnotationBinding[] typeAnnotations = normalizedBinding.getTypeAnnotations();
/* 1546 */         if (typeAnnotations.length > 0) {
/* 1547 */           Dimension dimension = arrayType.dimensions().get(i);
/* 1548 */           annotateList(dimension.annotations(), typeAnnotations, ast, context, 
/* 1549 */               (i == 0) ? location : TypeLocation.ARRAY_CONTENTS, normalizedBinding);
/*      */         } 
/* 1551 */         normalizedBinding = normalizedBinding.getComponentType();
/*      */       } 
/*      */     }
/* 1554 */     return (Type)arrayType;
/*      */   }
/*      */   private Type internalAddImport(ITypeBinding binding, AST ast, ImportRewriteContext context, Type currentType, boolean getBase, TypeLocation location) {
/*      */     ParameterizedType parameterizedType;
/* 1558 */     Type type = null;
/* 1559 */     ITypeBinding normalizedBinding = null;
/*      */     
/* 1561 */     if (binding.isPrimitive()) {
/* 1562 */       PrimitiveType primitiveType = ast.newPrimitiveType(PrimitiveType.toCode(binding.getName()));
/* 1563 */       normalizedBinding = binding;
/*      */     } else {
/* 1565 */       normalizedBinding = normalizeTypeBinding(binding);
/* 1566 */       if (normalizedBinding == null)
/* 1567 */         return (Type)ast.newSimpleType((Name)ast.newSimpleName("invalid")); 
/* 1568 */       if (normalizedBinding.isTypeVariable()) {
/*      */         
/* 1570 */         SimpleType simpleType = ast.newSimpleType((Name)ast.newSimpleName(binding.getName()));
/* 1571 */       } else if (normalizedBinding.isWildcardType()) {
/* 1572 */         WildcardType wcType = ast.newWildcardType();
/* 1573 */         ITypeBinding bound = normalizedBinding.getBound();
/* 1574 */         if (bound != null && !bound.isWildcardType() && !bound.isCapture()) {
/* 1575 */           Type boundType = addImport(bound, ast, context, TypeLocation.TYPE_BOUND);
/* 1576 */           wcType.setBound(boundType, normalizedBinding.isUpperbound());
/*      */         } 
/* 1578 */         WildcardType wildcardType1 = wcType;
/* 1579 */       } else if (normalizedBinding.isArray()) {
/* 1580 */         Type elementType = addImport(normalizedBinding.getElementType(), ast, context, TypeLocation.ARRAY_CONTENTS);
/* 1581 */         type = getArrayType(elementType, ast, context, normalizedBinding, location);
/*      */       } 
/*      */     } 
/*      */     
/* 1585 */     if (type != null) {
/* 1586 */       return annotateType(normalizedBinding, ast, context, type, location);
/*      */     }
/*      */     
/* 1589 */     if (getBase) {
/* 1590 */       type = createBaseType(ast, context, normalizedBinding, location);
/*      */     } else {
/* 1592 */       type = (currentType != null) ? (Type)ast.newQualifiedType(currentType, ast.newSimpleName(getRawName(normalizedBinding))) : 
/* 1593 */         (Type)ast.newSimpleType(ast.newName(getRawName(normalizedBinding)));
/* 1594 */       type = annotateType(normalizedBinding, ast, context, type, location);
/*      */     } 
/*      */     
/* 1597 */     ITypeBinding[] typeArguments = normalizedBinding.getTypeArguments();
/* 1598 */     if (typeArguments.length > 0) {
/* 1599 */       ParameterizedType paramType = ast.newParameterizedType(type);
/* 1600 */       List<WildcardType> arguments = paramType.typeArguments();
/* 1601 */       for (int i = 0; i < typeArguments.length; i++) {
/* 1602 */         ITypeBinding curr = typeArguments[i];
/* 1603 */         if (containsNestedCapture(curr, false)) {
/* 1604 */           arguments.add(ast.newWildcardType());
/*      */         } else {
/* 1606 */           arguments.add(addImport(curr, ast, context, TypeLocation.TYPE_ARGUMENT));
/*      */         } 
/*      */       } 
/* 1609 */       parameterizedType = paramType;
/*      */     } 
/* 1611 */     return (Type)parameterizedType;
/*      */   }
/*      */   
/*      */   private Expression addAnnotation(AST ast, Object value, ImportRewriteContext context) {
/* 1615 */     if (value instanceof Boolean)
/* 1616 */       return (Expression)ast.newBooleanLiteral(((Boolean)value).booleanValue()); 
/* 1617 */     if (value instanceof Byte || value instanceof Short || value instanceof Integer || value instanceof Long || 
/* 1618 */       value instanceof Float || value instanceof Double)
/* 1619 */       return (Expression)ast.newNumberLiteral(value.toString()); 
/* 1620 */     if (value instanceof Character) {
/* 1621 */       CharacterLiteral result = ast.newCharacterLiteral();
/* 1622 */       result.setCharValue(((Character)value).charValue());
/* 1623 */       return (Expression)result;
/* 1624 */     }  if (value instanceof ITypeBinding) {
/* 1625 */       TypeLiteral result = ast.newTypeLiteral();
/* 1626 */       result.setType(addImport((ITypeBinding)value, ast, context, TypeLocation.OTHER));
/* 1627 */       return (Expression)result;
/* 1628 */     }  if (value instanceof String) {
/* 1629 */       StringLiteral result = ast.newStringLiteral();
/* 1630 */       result.setLiteralValue((String)value);
/* 1631 */       return (Expression)result;
/* 1632 */     }  if (value instanceof IVariableBinding) {
/* 1633 */       Name name; IVariableBinding variable = (IVariableBinding)value;
/*      */       
/* 1635 */       FieldAccess result = ast.newFieldAccess();
/* 1636 */       result.setName(ast.newSimpleName(variable.getName()));
/* 1637 */       Type type = addImport(variable.getType(), ast, context, TypeLocation.OTHER);
/*      */       
/* 1639 */       if (type instanceof SimpleType) {
/* 1640 */         SimpleType simpleType = (SimpleType)type;
/* 1641 */         name = simpleType.getName();
/*      */         
/* 1643 */         simpleType.setName((Name)ast.newSimpleName("a"));
/*      */       } else {
/* 1645 */         name = ast.newName("invalid");
/*      */       } 
/* 1647 */       result.setExpression((Expression)name);
/* 1648 */       return (Expression)result;
/* 1649 */     }  if (value instanceof IAnnotationBinding)
/* 1650 */       return (Expression)addAnnotation((IAnnotationBinding)value, ast, context); 
/* 1651 */     if (value instanceof Object[]) {
/* 1652 */       Object[] values = (Object[])value;
/* 1653 */       if (values.length == 1) {
/* 1654 */         return addAnnotation(ast, values[0], context);
/*      */       }
/* 1656 */       ArrayInitializer initializer = ast.newArrayInitializer();
/* 1657 */       List<Expression> expressions = initializer.expressions();
/* 1658 */       int size = values.length;
/* 1659 */       for (int i = 0; i < size; i++)
/* 1660 */         expressions.add(addAnnotation(ast, values[i], context)); 
/* 1661 */       return (Expression)initializer;
/*      */     } 
/* 1663 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isTypeInUnnamedPackage(ITypeBinding binding) {
/* 1668 */     boolean isInUnnamedPackage = false;
/* 1669 */     if (binding != null) {
/* 1670 */       IPackageBinding pBinding = binding.getPackage();
/* 1671 */       if (pBinding != null) {
/* 1672 */         isInUnnamedPackage = pBinding.isUnnamed();
/*      */       }
/*      */     } 
/* 1675 */     return isInUnnamedPackage;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\rewrite\ImportRewrite.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */