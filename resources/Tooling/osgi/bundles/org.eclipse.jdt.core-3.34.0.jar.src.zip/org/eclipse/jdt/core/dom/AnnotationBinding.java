/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import org.eclipse.jdt.core.IAnnotatable;
/*     */ import org.eclipse.jdt.core.ICompilationUnit;
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.core.IMember;
/*     */ import org.eclipse.jdt.core.IPackageDeclaration;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ElementValuePair;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.util.HashtableOfObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AnnotationBinding
/*     */   implements IAnnotationBinding
/*     */ {
/*  33 */   static final AnnotationBinding[] NoAnnotations = new AnnotationBinding[0];
/*     */   private org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding binding;
/*     */   private BindingResolver bindingResolver;
/*     */   private String key;
/*     */   
/*     */   AnnotationBinding(org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding annotation, BindingResolver resolver) {
/*  39 */     if (annotation == null)
/*  40 */       throw new IllegalStateException(); 
/*  41 */     this.binding = annotation;
/*  42 */     this.bindingResolver = resolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public IAnnotationBinding[] getAnnotations() {
/*  47 */     return (IAnnotationBinding[])NoAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITypeBinding getAnnotationType() {
/*  52 */     ITypeBinding typeBinding = this.bindingResolver.getTypeBinding((TypeBinding)this.binding.getAnnotationType());
/*  53 */     if (typeBinding == null)
/*  54 */       return null; 
/*  55 */     return typeBinding;
/*     */   }
/*     */ 
/*     */   
/*     */   public IMemberValuePairBinding[] getDeclaredMemberValuePairs() {
/*  60 */     ReferenceBinding typeBinding = this.binding.getAnnotationType();
/*  61 */     if (typeBinding == null || (typeBinding.tagBits & 0x80L) != 0L) {
/*  62 */       return (IMemberValuePairBinding[])MemberValuePairBinding.NoPair;
/*     */     }
/*  64 */     ElementValuePair[] internalPairs = this.binding.getElementValuePairs();
/*  65 */     int length = internalPairs.length;
/*  66 */     MemberValuePairBinding[] arrayOfMemberValuePairBinding = (length == 0) ? MemberValuePairBinding.NoPair : new MemberValuePairBinding[length];
/*  67 */     int counter = 0;
/*  68 */     for (int i = 0; i < length; i++) {
/*  69 */       ElementValuePair valuePair = internalPairs[i];
/*  70 */       if (valuePair.binding != null)
/*  71 */         arrayOfMemberValuePairBinding[counter++] = (MemberValuePairBinding)this.bindingResolver.getMemberValuePairBinding(valuePair); 
/*     */     } 
/*  73 */     if (counter == 0) return (IMemberValuePairBinding[])MemberValuePairBinding.NoPair; 
/*  74 */     if (counter != length)
/*     */     {
/*  76 */       System.arraycopy(arrayOfMemberValuePairBinding, 0, arrayOfMemberValuePairBinding = new MemberValuePairBinding[counter], 0, counter);
/*     */     }
/*  78 */     return (IMemberValuePairBinding[])arrayOfMemberValuePairBinding;
/*     */   }
/*     */ 
/*     */   
/*     */   public IMemberValuePairBinding[] getAllMemberValuePairs() {
/*  83 */     IMemberValuePairBinding[] pairs = getDeclaredMemberValuePairs();
/*  84 */     ReferenceBinding typeBinding = this.binding.getAnnotationType();
/*  85 */     if (typeBinding == null || (typeBinding.tagBits & 0x80L) != 0L) return pairs; 
/*  86 */     MethodBinding[] methods = typeBinding.availableMethods();
/*  87 */     int methodLength = (methods == null) ? 0 : methods.length;
/*  88 */     if (methodLength == 0) return pairs;
/*     */     
/*  90 */     int declaredLength = pairs.length;
/*  91 */     if (declaredLength == methodLength) {
/*  92 */       return pairs;
/*     */     }
/*  94 */     HashtableOfObject table = new HashtableOfObject(declaredLength);
/*  95 */     for (int i = 0; i < declaredLength; i++) {
/*  96 */       char[] internalName = ((MemberValuePairBinding)pairs[i]).internalName();
/*  97 */       if (internalName != null) {
/*  98 */         table.put(internalName, pairs[i]);
/*     */       }
/*     */     } 
/*     */     
/* 102 */     IMemberValuePairBinding[] allPairs = new IMemberValuePairBinding[methodLength];
/* 103 */     for (int j = 0; j < methodLength; j++) {
/* 104 */       Object pair = table.get((methods[j]).selector);
/* 105 */       allPairs[j] = (pair == null) ? new DefaultValuePairBinding(methods[j], this.bindingResolver) : (IMemberValuePairBinding)pair;
/*     */     } 
/* 107 */     return allPairs; } public IJavaElement getJavaElement() { IJavaElement cu;
/*     */     VariableDeclarationFragment fragment;
/*     */     IVariableBinding variableBinding;
/*     */     IMethodBinding methodBinding;
/*     */     IModuleBinding moduleBinding;
/* 112 */     if (!(this.bindingResolver instanceof DefaultBindingResolver)) return null; 
/* 113 */     ASTNode node = (ASTNode)((DefaultBindingResolver)this.bindingResolver).bindingsToAstNodes.get(this);
/* 114 */     if (!(node instanceof Annotation)) return null; 
/* 115 */     ASTNode parent = node.getParent();
/* 116 */     IJavaElement parentElement = null;
/* 117 */     switch (parent.getNodeType()) {
/*     */       case 35:
/* 119 */         cu = ((CompilationUnit)parent.getParent()).getJavaElement();
/* 120 */         if (cu instanceof ICompilationUnit) {
/* 121 */           String pkgName = ((PackageDeclaration)parent).getName().getFullyQualifiedName();
/* 122 */           IPackageDeclaration iPackageDeclaration = ((ICompilationUnit)cu).getPackageDeclaration(pkgName);
/*     */         } 
/*     */         break;
/*     */       case 55:
/*     */       case 71:
/*     */       case 81:
/* 128 */         parentElement = ((AbstractTypeDeclaration)parent).resolveBinding().getJavaElement();
/*     */         break;
/*     */       case 23:
/* 131 */         fragment = ((FieldDeclaration)parent).fragments().get(0);
/* 132 */         variableBinding = fragment.resolveBinding();
/* 133 */         if (variableBinding == null) {
/* 134 */           return null;
/*     */         }
/* 136 */         parentElement = variableBinding.getJavaElement();
/*     */         break;
/*     */       case 31:
/* 139 */         methodBinding = ((MethodDeclaration)parent).resolveBinding();
/* 140 */         if (methodBinding == null) return null; 
/* 141 */         parentElement = methodBinding.getJavaElement();
/*     */         break;
/*     */       case 93:
/* 144 */         moduleBinding = ((ModuleDeclaration)parent).resolveBinding();
/* 145 */         if (moduleBinding == null) return null; 
/* 146 */         parentElement = moduleBinding.getJavaElement();
/*     */         break;
/*     */       case 60:
/* 149 */         fragment = ((VariableDeclarationStatement)parent).fragments().get(0);
/* 150 */         variableBinding = fragment.resolveBinding();
/* 151 */         if (variableBinding == null) {
/* 152 */           return null;
/*     */         }
/* 154 */         parentElement = variableBinding.getJavaElement();
/*     */         break;
/*     */       default:
/* 157 */         return null;
/*     */     } 
/* 159 */     if (!(parentElement instanceof IAnnotatable)) return null; 
/* 160 */     if (parentElement instanceof IMember && ((IMember)parentElement).isBinary()) {
/* 161 */       return (IJavaElement)((IAnnotatable)parentElement).getAnnotation(getAnnotationType().getQualifiedName());
/*     */     }
/* 163 */     return (IJavaElement)((IAnnotatable)parentElement).getAnnotation(getName()); }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 168 */     if (this.key == null) {
/* 169 */       String recipientKey = getRecipientKey();
/* 170 */       this.key = new String(this.binding.computeUniqueKey(recipientKey.toCharArray()));
/*     */     } 
/* 172 */     return this.key;
/*     */   } private String getRecipientKey() {
/*     */     String pkgName;
/*     */     VariableDeclarationFragment fragment;
/* 176 */     if (!(this.bindingResolver instanceof DefaultBindingResolver)) return ""; 
/* 177 */     DefaultBindingResolver resolver = (DefaultBindingResolver)this.bindingResolver;
/* 178 */     ASTNode node = (ASTNode)resolver.bindingsToAstNodes.get(this);
/* 179 */     if (node == null)
/*     */     {
/* 181 */       return "";
/*     */     }
/* 183 */     ASTNode recipient = node.getParent();
/* 184 */     switch (recipient.getNodeType()) {
/*     */       case 35:
/* 186 */         pkgName = ((PackageDeclaration)recipient).getName().getFullyQualifiedName();
/* 187 */         return pkgName.replace('.', '/');
/*     */       case 55:
/* 189 */         return ((TypeDeclaration)recipient).resolveBinding().getKey();
/*     */       case 23:
/* 191 */         fragment = ((FieldDeclaration)recipient).fragments().get(0);
/* 192 */         return fragment.resolveBinding().getKey();
/*     */       case 31:
/* 194 */         return ((MethodDeclaration)recipient).resolveBinding().getKey();
/*     */       case 93:
/* 196 */         return ((ModuleDeclaration)recipient).resolveBinding().getKey();
/*     */       case 60:
/* 198 */         fragment = ((VariableDeclarationStatement)recipient).fragments().get(0);
/* 199 */         return fragment.resolveBinding().getKey();
/*     */     } 
/* 201 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getKind() {
/* 207 */     return 5;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 212 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 217 */     ITypeBinding annotationType = getAnnotationType();
/* 218 */     if (annotationType == null) {
/* 219 */       return new String(this.binding.getAnnotationType().sourceName());
/*     */     }
/* 221 */     return annotationType.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDeprecated() {
/* 227 */     ReferenceBinding typeBinding = this.binding.getAnnotationType();
/* 228 */     if (typeBinding == null) return false; 
/* 229 */     return typeBinding.isDeprecated();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEqualTo(IBinding otherBinding) {
/* 234 */     if (this == otherBinding)
/* 235 */       return true; 
/* 236 */     if (otherBinding.getKind() != 5)
/* 237 */       return false; 
/* 238 */     IAnnotationBinding other = (IAnnotationBinding)otherBinding;
/* 239 */     if (!getAnnotationType().isEqualTo(other.getAnnotationType()))
/* 240 */       return false; 
/* 241 */     IMemberValuePairBinding[] memberValuePairs = getDeclaredMemberValuePairs();
/* 242 */     IMemberValuePairBinding[] otherMemberValuePairs = other.getDeclaredMemberValuePairs();
/* 243 */     if (memberValuePairs.length != otherMemberValuePairs.length)
/* 244 */       return false; 
/* 245 */     for (int i = 0, length = memberValuePairs.length; i < length; i++) {
/* 246 */       if (!memberValuePairs[i].isEqualTo(otherMemberValuePairs[i]))
/* 247 */         return false; 
/*     */     } 
/* 249 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRecovered() {
/* 254 */     ReferenceBinding annotationType = this.binding.getAnnotationType();
/* 255 */     return !(annotationType != null && (annotationType.tagBits & 0x80L) == 0L);
/*     */   }
/*     */   
/*     */   public boolean isSynthetic() {
/* 259 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 264 */     ITypeBinding type = getAnnotationType();
/* 265 */     StringBuilder buffer = new StringBuilder();
/* 266 */     buffer.append('@');
/* 267 */     if (type != null)
/* 268 */       buffer.append(type.getName()); 
/* 269 */     buffer.append('(');
/* 270 */     IMemberValuePairBinding[] pairs = getDeclaredMemberValuePairs();
/* 271 */     for (int i = 0, len = pairs.length; i < len; i++) {
/* 272 */       if (i != 0)
/* 273 */         buffer.append(", "); 
/* 274 */       buffer.append(pairs[i].toString());
/*     */     } 
/* 276 */     buffer.append(')');
/* 277 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\AnnotationBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */