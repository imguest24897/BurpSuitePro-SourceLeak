/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.ImportReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnKeyword2
/*    */   extends ImportReference
/*    */   implements CompletionOnKeyword
/*    */ {
/*    */   private char[] token;
/*    */   private char[][] possibleKeywords;
/*    */   
/*    */   public CompletionOnKeyword2(char[] token, long pos, char[][] possibleKeywords) {
/* 23 */     super(new char[][] { token }, new long[] { pos }, false, 0);
/* 24 */     this.token = token;
/* 25 */     this.possibleKeywords = possibleKeywords;
/*    */   }
/*    */   
/*    */   public char[] getToken() {
/* 29 */     return this.token;
/*    */   }
/*    */   
/*    */   public char[][] getPossibleKeywords() {
/* 33 */     return this.possibleKeywords;
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer print(int indent, StringBuffer output, boolean withOnDemand) {
/* 38 */     return printIndent(indent, output).append("<CompleteOnKeyword:").append(this.token).append('>');
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnKeyword2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */