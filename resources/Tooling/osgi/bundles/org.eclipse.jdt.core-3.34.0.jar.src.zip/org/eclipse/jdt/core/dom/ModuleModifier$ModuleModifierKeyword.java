/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModuleModifierKeyword
/*     */ {
/*  46 */   public static final ModuleModifierKeyword STATIC_KEYWORD = new ModuleModifierKeyword("static", 64);
/*     */ 
/*     */   
/*  49 */   public static final ModuleModifierKeyword TRANSITIVE_KEYWORD = new ModuleModifierKeyword("transitive", 128);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private static final Map KEYWORDS = new HashMap<>(2); static {
/*  60 */     ModuleModifierKeyword[] ops = {
/*  61 */         STATIC_KEYWORD, 
/*  62 */         TRANSITIVE_KEYWORD
/*     */       };
/*  64 */     for (int i = 0; i < ops.length; i++) {
/*  65 */       KEYWORDS.put(ops[i].toString(), ops[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int flagValue;
/*     */ 
/*     */ 
/*     */   
/*     */   private String keyword;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ModuleModifierKeyword fromFlagValue(int flagValue) {
/*  83 */     for (Iterator<ModuleModifierKeyword> it = KEYWORDS.values().iterator(); it.hasNext(); ) {
/*  84 */       ModuleModifierKeyword k = it.next();
/*  85 */       if (k.toFlagValue() == flagValue) {
/*  86 */         return k;
/*     */       }
/*     */     } 
/*  89 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ModuleModifierKeyword toKeyword(String keyword) {
/* 106 */     return (ModuleModifierKeyword)KEYWORDS.get(keyword);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ModuleModifierKeyword(String keyword, int flagValue) {
/* 130 */     this.keyword = keyword;
/* 131 */     this.flagValue = flagValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int toFlagValue() {
/* 142 */     return this.flagValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 153 */     return this.keyword;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ModuleModifier$ModuleModifierKeyword.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */