/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.ImportReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnImportReference
/*    */   extends ImportReference
/*    */ {
/*    */   public CompletionOnImportReference(char[][] tokens, long[] positions, int modifiers) {
/* 43 */     super(tokens, positions, false, modifiers);
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer print(int indent, StringBuffer output, boolean withOnDemand) {
/* 48 */     printIndent(indent, output).append("<CompleteOnImport:");
/* 49 */     for (int i = 0; i < this.tokens.length; i++) {
/* 50 */       if (i > 0) output.append('.'); 
/* 51 */       output.append(this.tokens[i]);
/*    */     } 
/* 53 */     return output.append('>');
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnImportReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */