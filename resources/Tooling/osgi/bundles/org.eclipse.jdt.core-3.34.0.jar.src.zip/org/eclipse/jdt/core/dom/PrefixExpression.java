/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrefixExpression
/*     */   extends Expression
/*     */ {
/*     */   public static class Operator
/*     */   {
/*     */     private String token;
/*     */     
/*     */     private Operator(String token) {
/*  65 */       this.token = token;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/*  75 */       return this.token;
/*     */     }
/*     */ 
/*     */     
/*  79 */     public static final Operator INCREMENT = new Operator("++");
/*     */     
/*  81 */     public static final Operator DECREMENT = new Operator("--");
/*     */     
/*  83 */     public static final Operator PLUS = new Operator("+");
/*     */     
/*  85 */     public static final Operator MINUS = new Operator("-");
/*     */     
/*  87 */     public static final Operator COMPLEMENT = new Operator("~");
/*     */     
/*  89 */     public static final Operator NOT = new Operator("!");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     private static final Map CODES = new HashMap<>(20); static {
/*  98 */       Operator[] ops = {
/*  99 */           INCREMENT, 
/* 100 */           DECREMENT, 
/* 101 */           PLUS, 
/* 102 */           MINUS, 
/* 103 */           COMPLEMENT, 
/* 104 */           NOT
/*     */         };
/* 106 */       for (int i = 0; i < ops.length; i++) {
/* 107 */         CODES.put(ops[i].toString(), ops[i]);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Operator toOperator(String token) {
/* 124 */       return (Operator)CODES.get(token);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   public static final SimplePropertyDescriptor OPERATOR_PROPERTY = new SimplePropertyDescriptor(PrefixExpression.class, "operator", Operator.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public static final ChildPropertyDescriptor OPERAND_PROPERTY = new ChildPropertyDescriptor(PrefixExpression.class, "operand", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 150 */     List propertyList = new ArrayList(3);
/* 151 */     createPropertyList(PrefixExpression.class, propertyList);
/* 152 */     addProperty(OPERATOR_PROPERTY, propertyList);
/* 153 */     addProperty(OPERAND_PROPERTY, propertyList);
/* 154 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 169 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   private Operator operator = Operator.PLUS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   private Expression operand = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PrefixExpression(AST ast) {
/* 192 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 197 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final Object internalGetSetObjectProperty(SimplePropertyDescriptor property, boolean get, Object value) {
/* 202 */     if (property == OPERATOR_PROPERTY) {
/* 203 */       if (get) {
/* 204 */         return getOperator();
/*     */       }
/* 206 */       setOperator((Operator)value);
/* 207 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 211 */     return super.internalGetSetObjectProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 216 */     if (property == OPERAND_PROPERTY) {
/* 217 */       if (get) {
/* 218 */         return getOperand();
/*     */       }
/* 220 */       setOperand((Expression)child);
/* 221 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 225 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 230 */     return 38;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 235 */     PrefixExpression result = new PrefixExpression(target);
/* 236 */     result.setSourceRange(getStartPosition(), getLength());
/* 237 */     result.setOperator(getOperator());
/* 238 */     result.setOperand((Expression)getOperand().clone(target));
/* 239 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 245 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 250 */     boolean visitChildren = visitor.visit(this);
/* 251 */     if (visitChildren)
/*     */     {
/* 253 */       acceptChild(visitor, getOperand());
/*     */     }
/* 255 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Operator getOperator() {
/* 264 */     return this.operator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOperator(Operator operator) {
/* 274 */     if (operator == null) {
/* 275 */       throw new IllegalArgumentException();
/*     */     }
/* 277 */     preValueChange(OPERATOR_PROPERTY);
/* 278 */     this.operator = operator;
/* 279 */     postValueChange(OPERATOR_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getOperand() {
/* 288 */     if (this.operand == null)
/*     */     {
/* 290 */       synchronized (this) {
/* 291 */         if (this.operand == null) {
/* 292 */           preLazyInit();
/* 293 */           this.operand = new SimpleName(this.ast);
/* 294 */           postLazyInit(this.operand, OPERAND_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 298 */     return this.operand;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOperand(Expression expression) {
/* 313 */     if (expression == null) {
/* 314 */       throw new IllegalArgumentException();
/*     */     }
/* 316 */     ASTNode oldChild = this.operand;
/* 317 */     preReplaceChild(oldChild, expression, OPERAND_PROPERTY);
/* 318 */     this.operand = expression;
/* 319 */     postReplaceChild(oldChild, expression, OPERAND_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 325 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 330 */     return 
/* 331 */       memSize() + (
/* 332 */       (this.operand == null) ? 0 : getOperand().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\PrefixExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */