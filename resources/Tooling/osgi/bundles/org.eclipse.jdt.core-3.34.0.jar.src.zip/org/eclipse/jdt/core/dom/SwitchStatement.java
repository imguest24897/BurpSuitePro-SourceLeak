/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwitchStatement
/*     */   extends Statement
/*     */ {
/*  44 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(SwitchStatement.class, "expression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public static final ChildListPropertyDescriptor STATEMENTS_PROPERTY = new ChildListPropertyDescriptor(SwitchStatement.class, "statements", Statement.class, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  61 */     List propertyList = new ArrayList(3);
/*  62 */     createPropertyList(SwitchStatement.class, propertyList);
/*  63 */     addProperty(EXPRESSION_PROPERTY, propertyList);
/*  64 */     addProperty(STATEMENTS_PROPERTY, propertyList);
/*  65 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  79 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   private Expression expression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private ASTNode.NodeList statements = new ASTNode.NodeList(this, STATEMENTS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SwitchStatement(AST ast) {
/* 107 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 112 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 117 */     if (property == EXPRESSION_PROPERTY) {
/* 118 */       if (get) {
/* 119 */         return getExpression();
/*     */       }
/* 121 */       setExpression((Expression)child);
/* 122 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 126 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 131 */     if (property == STATEMENTS_PROPERTY) {
/* 132 */       return statements();
/*     */     }
/*     */     
/* 135 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 140 */     return 50;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 145 */     SwitchStatement result = new SwitchStatement(target);
/* 146 */     result.setSourceRange(getStartPosition(), getLength());
/* 147 */     result.copyLeadingComment(this);
/* 148 */     result.setExpression((Expression)getExpression().clone(target));
/* 149 */     result.statements().addAll(ASTNode.copySubtrees(target, statements()));
/* 150 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 156 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 161 */     boolean visitChildren = visitor.visit(this);
/* 162 */     if (visitChildren) {
/*     */       
/* 164 */       acceptChild(visitor, getExpression());
/* 165 */       acceptChildren(visitor, this.statements);
/*     */     } 
/* 167 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 176 */     if (this.expression == null)
/*     */     {
/* 178 */       synchronized (this) {
/* 179 */         if (this.expression == null) {
/* 180 */           preLazyInit();
/* 181 */           this.expression = new SimpleName(this.ast);
/* 182 */           postLazyInit(this.expression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 186 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 201 */     if (expression == null) {
/* 202 */       throw new IllegalArgumentException();
/*     */     }
/* 204 */     ASTNode oldChild = this.expression;
/* 205 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 206 */     this.expression = expression;
/* 207 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List statements() {
/* 219 */     return this.statements;
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 224 */     return super.memSize() + 8;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 229 */     return 
/* 230 */       memSize() + (
/* 231 */       (this.expression == null) ? 0 : getExpression().treeSize()) + 
/* 232 */       this.statements.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\SwitchStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */