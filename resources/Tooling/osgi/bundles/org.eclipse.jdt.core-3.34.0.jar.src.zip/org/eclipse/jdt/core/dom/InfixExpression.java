/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InfixExpression
/*     */   extends Expression
/*     */ {
/*     */   public static class Operator
/*     */   {
/*     */     private String token;
/*     */     
/*     */     private Operator(String token) {
/*  77 */       this.token = token;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/*  87 */       return this.token;
/*     */     }
/*     */ 
/*     */     
/*  91 */     public static final Operator TIMES = new Operator("*");
/*     */     
/*  93 */     public static final Operator DIVIDE = new Operator("/");
/*     */     
/*  95 */     public static final Operator REMAINDER = new Operator("%");
/*     */     
/*  97 */     public static final Operator PLUS = new Operator("+");
/*     */     
/*  99 */     public static final Operator MINUS = new Operator("-");
/*     */     
/* 101 */     public static final Operator LEFT_SHIFT = new Operator("<<");
/*     */     
/* 103 */     public static final Operator RIGHT_SHIFT_SIGNED = new Operator(">>");
/*     */ 
/*     */     
/* 106 */     public static final Operator RIGHT_SHIFT_UNSIGNED = new Operator(">>>");
/*     */     
/* 108 */     public static final Operator LESS = new Operator("<");
/*     */     
/* 110 */     public static final Operator GREATER = new Operator(">");
/*     */     
/* 112 */     public static final Operator LESS_EQUALS = new Operator("<=");
/*     */     
/* 114 */     public static final Operator GREATER_EQUALS = new Operator(">=");
/*     */     
/* 116 */     public static final Operator EQUALS = new Operator("==");
/*     */     
/* 118 */     public static final Operator NOT_EQUALS = new Operator("!=");
/*     */     
/* 120 */     public static final Operator XOR = new Operator("^");
/*     */     
/* 122 */     public static final Operator OR = new Operator("|");
/*     */     
/* 124 */     public static final Operator AND = new Operator("&");
/*     */     
/* 126 */     public static final Operator CONDITIONAL_OR = new Operator("||");
/*     */     
/* 128 */     public static final Operator CONDITIONAL_AND = new Operator("&&");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     private static final Map CODES = new HashMap<>(20); static {
/* 137 */       Operator[] ops = { 
/* 138 */           TIMES, 
/* 139 */           DIVIDE, 
/* 140 */           REMAINDER, 
/* 141 */           PLUS, 
/* 142 */           MINUS, 
/* 143 */           LEFT_SHIFT, 
/* 144 */           RIGHT_SHIFT_SIGNED, 
/* 145 */           RIGHT_SHIFT_UNSIGNED, 
/* 146 */           LESS, 
/* 147 */           GREATER, 
/* 148 */           LESS_EQUALS, 
/* 149 */           GREATER_EQUALS, 
/* 150 */           EQUALS, 
/* 151 */           NOT_EQUALS, 
/* 152 */           XOR, 
/* 153 */           OR, 
/* 154 */           AND, 
/* 155 */           CONDITIONAL_OR, 
/* 156 */           CONDITIONAL_AND };
/*     */       
/* 158 */       for (int i = 0; i < ops.length; i++) {
/* 159 */         CODES.put(ops[i].toString(), ops[i]);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Operator toOperator(String token) {
/* 176 */       return (Operator)CODES.get(token);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 186 */   public static final ChildPropertyDescriptor LEFT_OPERAND_PROPERTY = new ChildPropertyDescriptor(InfixExpression.class, "leftOperand", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 193 */   public static final SimplePropertyDescriptor OPERATOR_PROPERTY = new SimplePropertyDescriptor(InfixExpression.class, "operator", Operator.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 200 */   public static final ChildPropertyDescriptor RIGHT_OPERAND_PROPERTY = new ChildPropertyDescriptor(InfixExpression.class, "rightOperand", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 207 */   public static final ChildListPropertyDescriptor EXTENDED_OPERANDS_PROPERTY = new ChildListPropertyDescriptor(InfixExpression.class, "extendedOperands", Expression.class, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 217 */     List properyList = new ArrayList(5);
/* 218 */     createPropertyList(InfixExpression.class, properyList);
/* 219 */     addProperty(LEFT_OPERAND_PROPERTY, properyList);
/* 220 */     addProperty(OPERATOR_PROPERTY, properyList);
/* 221 */     addProperty(RIGHT_OPERAND_PROPERTY, properyList);
/* 222 */     addProperty(EXTENDED_OPERANDS_PROPERTY, properyList);
/* 223 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 238 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 244 */   private Operator operator = Operator.PLUS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 250 */   private Expression leftOperand = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 256 */   private Expression rightOperand = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 262 */   private ASTNode.NodeList extendedOperands = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InfixExpression(AST ast) {
/* 272 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 277 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final Object internalGetSetObjectProperty(SimplePropertyDescriptor property, boolean get, Object value) {
/* 282 */     if (property == OPERATOR_PROPERTY) {
/* 283 */       if (get) {
/* 284 */         return getOperator();
/*     */       }
/* 286 */       setOperator((Operator)value);
/* 287 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 291 */     return super.internalGetSetObjectProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 296 */     if (property == LEFT_OPERAND_PROPERTY) {
/* 297 */       if (get) {
/* 298 */         return getLeftOperand();
/*     */       }
/* 300 */       setLeftOperand((Expression)child);
/* 301 */       return null;
/*     */     } 
/*     */     
/* 304 */     if (property == RIGHT_OPERAND_PROPERTY) {
/* 305 */       if (get) {
/* 306 */         return getRightOperand();
/*     */       }
/* 308 */       setRightOperand((Expression)child);
/* 309 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 313 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 318 */     if (property == EXTENDED_OPERANDS_PROPERTY) {
/* 319 */       return extendedOperands();
/*     */     }
/*     */     
/* 322 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 327 */     return 27;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 332 */     InfixExpression result = new InfixExpression(target);
/* 333 */     result.setSourceRange(getStartPosition(), getLength());
/* 334 */     result.setOperator(getOperator());
/* 335 */     result.setLeftOperand((Expression)getLeftOperand().clone(target));
/* 336 */     result.setRightOperand((Expression)getRightOperand().clone(target));
/* 337 */     if (this.extendedOperands != null)
/*     */     {
/* 339 */       result.extendedOperands().addAll(
/* 340 */           ASTNode.copySubtrees(target, extendedOperands()));
/*     */     }
/* 342 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 348 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 353 */     boolean visitChildren = visitor.visit(this);
/* 354 */     if (visitChildren) {
/*     */       
/* 356 */       acceptChild(visitor, getLeftOperand());
/* 357 */       acceptChild(visitor, getRightOperand());
/* 358 */       if (this.extendedOperands != null)
/*     */       {
/* 360 */         acceptChildren(visitor, this.extendedOperands);
/*     */       }
/*     */     } 
/* 363 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Operator getOperator() {
/* 372 */     return this.operator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOperator(Operator operator) {
/* 382 */     if (operator == null) {
/* 383 */       throw new IllegalArgumentException();
/*     */     }
/* 385 */     preValueChange(OPERATOR_PROPERTY);
/* 386 */     this.operator = operator;
/* 387 */     postValueChange(OPERATOR_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getLeftOperand() {
/* 396 */     if (this.leftOperand == null)
/*     */     {
/* 398 */       synchronized (this) {
/* 399 */         if (this.leftOperand == null) {
/* 400 */           preLazyInit();
/* 401 */           this.leftOperand = new SimpleName(this.ast);
/* 402 */           postLazyInit(this.leftOperand, LEFT_OPERAND_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 406 */     return this.leftOperand;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLeftOperand(Expression expression) {
/* 421 */     if (expression == null) {
/* 422 */       throw new IllegalArgumentException();
/*     */     }
/* 424 */     ASTNode oldChild = this.leftOperand;
/* 425 */     preReplaceChild(oldChild, expression, LEFT_OPERAND_PROPERTY);
/* 426 */     this.leftOperand = expression;
/* 427 */     postReplaceChild(oldChild, expression, LEFT_OPERAND_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getRightOperand() {
/* 436 */     if (this.rightOperand == null)
/*     */     {
/* 438 */       synchronized (this) {
/* 439 */         if (this.rightOperand == null) {
/* 440 */           preLazyInit();
/* 441 */           this.rightOperand = new SimpleName(this.ast);
/* 442 */           postLazyInit(this.rightOperand, RIGHT_OPERAND_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 446 */     return this.rightOperand;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRightOperand(Expression expression) {
/* 461 */     if (expression == null) {
/* 462 */       throw new IllegalArgumentException();
/*     */     }
/* 464 */     ASTNode oldChild = this.rightOperand;
/* 465 */     preReplaceChild(oldChild, expression, RIGHT_OPERAND_PROPERTY);
/* 466 */     this.rightOperand = expression;
/* 467 */     postReplaceChild(oldChild, expression, RIGHT_OPERAND_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasExtendedOperands() {
/* 477 */     return 
/* 478 */       (this.extendedOperands != null && this.extendedOperands.size() > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List extendedOperands() {
/* 502 */     if (this.extendedOperands == null)
/*     */     {
/* 504 */       this.extendedOperands = new ASTNode.NodeList(this, EXTENDED_OPERANDS_PROPERTY);
/*     */     }
/* 506 */     return this.extendedOperands;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 512 */     return 56;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 517 */     return 
/* 518 */       memSize() + (
/* 519 */       (this.leftOperand == null) ? 0 : getLeftOperand().treeSize()) + (
/* 520 */       (this.rightOperand == null) ? 0 : getRightOperand().treeSize()) + (
/* 521 */       (this.extendedOperands == null) ? 0 : this.extendedOperands.listSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\InfixExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */