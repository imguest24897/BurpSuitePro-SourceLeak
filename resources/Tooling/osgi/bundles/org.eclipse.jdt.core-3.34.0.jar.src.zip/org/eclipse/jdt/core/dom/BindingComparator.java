/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.CaptureBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.FieldBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ImportBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.PackageBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeVariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.WildcardBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BindingComparator
/*     */ {
/*     */   static boolean isEqual(TypeVariableBinding[] bindings, TypeVariableBinding[] otherBindings) {
/*  44 */     if (bindings == null) {
/*  45 */       return (otherBindings == null);
/*     */     }
/*  47 */     if (otherBindings == null) {
/*  48 */       return false;
/*     */     }
/*  50 */     int length = bindings.length;
/*  51 */     int otherLength = otherBindings.length;
/*  52 */     if (length != otherLength) {
/*  53 */       return false;
/*     */     }
/*  55 */     for (int i = 0; i < length; i++) {
/*  56 */       TypeVariableBinding typeVariableBinding = bindings[i];
/*  57 */       TypeVariableBinding typeVariableBinding2 = otherBindings[i];
/*  58 */       if (!isEqual((TypeBinding)typeVariableBinding, (TypeBinding)typeVariableBinding2)) {
/*  59 */         return false;
/*     */       }
/*     */     } 
/*  62 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isEqual(Binding declaringElement, Binding declaringElement2, HashSet visitedTypes) {
/*  71 */     if (declaringElement instanceof TypeBinding) {
/*  72 */       if (!(declaringElement2 instanceof TypeBinding)) {
/*  73 */         return false;
/*     */       }
/*  75 */       return isEqual((TypeBinding)declaringElement, 
/*  76 */           (TypeBinding)declaringElement2, 
/*  77 */           visitedTypes);
/*  78 */     }  if (declaringElement instanceof MethodBinding) {
/*  79 */       if (!(declaringElement2 instanceof MethodBinding)) {
/*  80 */         return false;
/*     */       }
/*  82 */       return isEqual((MethodBinding)declaringElement, 
/*  83 */           (MethodBinding)declaringElement2, 
/*  84 */           visitedTypes);
/*  85 */     }  if (declaringElement instanceof VariableBinding) {
/*  86 */       if (!(declaringElement2 instanceof VariableBinding)) {
/*  87 */         return false;
/*     */       }
/*  89 */       return isEqual((VariableBinding)declaringElement, 
/*  90 */           (VariableBinding)declaringElement2);
/*  91 */     }  if (declaringElement instanceof PackageBinding) {
/*  92 */       if (!(declaringElement2 instanceof PackageBinding)) {
/*  93 */         return false;
/*     */       }
/*  95 */       PackageBinding packageBinding = (PackageBinding)declaringElement;
/*  96 */       PackageBinding packageBinding2 = (PackageBinding)declaringElement2;
/*  97 */       return CharOperation.equals(packageBinding.compoundName, packageBinding2.compoundName);
/*  98 */     }  if (declaringElement instanceof ImportBinding) {
/*  99 */       if (!(declaringElement2 instanceof ImportBinding)) {
/* 100 */         return false;
/*     */       }
/* 102 */       ImportBinding importBinding = (ImportBinding)declaringElement;
/* 103 */       ImportBinding importBinding2 = (ImportBinding)declaringElement2;
/* 104 */       return (importBinding.isStatic() == importBinding2.isStatic() && 
/* 105 */         importBinding.onDemand == importBinding2.onDemand && 
/* 106 */         CharOperation.equals(importBinding.compoundName, importBinding2.compoundName));
/* 107 */     }  if (declaringElement instanceof ModuleBinding) {
/* 108 */       if (!(declaringElement2 instanceof ModuleBinding)) {
/* 109 */         return false;
/*     */       }
/* 111 */       ModuleBinding moduleBinding = (ModuleBinding)declaringElement;
/* 112 */       ModuleBinding moduleBinding2 = (ModuleBinding)declaringElement2;
/* 113 */       return isEqual(moduleBinding, moduleBinding2);
/*     */     } 
/* 115 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean isEqual(MethodBinding methodBinding, MethodBinding methodBinding2) {
/* 120 */     return isEqual(methodBinding, methodBinding2, new HashSet());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isEqual(MethodBinding methodBinding, MethodBinding methodBinding2, HashSet visitedTypes) {
/* 126 */     if (methodBinding == null) {
/* 127 */       return (methodBinding2 == null);
/*     */     }
/* 129 */     if (methodBinding2 == null) return false; 
/* 130 */     return (CharOperation.equals(methodBinding.selector, methodBinding2.selector) && 
/* 131 */       isEqual(methodBinding.returnType, methodBinding2.returnType, visitedTypes) && 
/* 132 */       isEqual((TypeBinding[])methodBinding.thrownExceptions, (TypeBinding[])methodBinding2.thrownExceptions, visitedTypes) && 
/* 133 */       isEqual((TypeBinding)methodBinding.declaringClass, (TypeBinding)methodBinding2.declaringClass, visitedTypes) && 
/* 134 */       isEqual((TypeBinding[])methodBinding.typeVariables, (TypeBinding[])methodBinding2.typeVariables, visitedTypes) && 
/* 135 */       isEqual(methodBinding.parameters, methodBinding2.parameters, visitedTypes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isEqual(ModuleBinding moduleBinding, ModuleBinding moduleBinding2) {
/* 143 */     if (moduleBinding == null)
/* 144 */       return (moduleBinding2 == null); 
/* 145 */     if (moduleBinding2 == null)
/* 146 */       return false; 
/* 147 */     return CharOperation.equals(moduleBinding.moduleName, moduleBinding2.moduleName);
/*     */   }
/*     */   
/*     */   static boolean isEqual(VariableBinding variableBinding, VariableBinding variableBinding2) {
/* 151 */     return ((variableBinding.modifiers & 0xFFFF) == (variableBinding2.modifiers & 0xFFFF) && 
/* 152 */       CharOperation.equals(variableBinding.name, variableBinding2.name) && 
/* 153 */       isEqual(variableBinding.type, variableBinding2.type) && 
/* 154 */       variableBinding.id == variableBinding2.id);
/*     */   }
/*     */   
/*     */   static boolean isEqual(FieldBinding fieldBinding, FieldBinding fieldBinding2) {
/* 158 */     HashSet visitedTypes = new HashSet();
/* 159 */     return ((fieldBinding.modifiers & 0xFFFF) == (fieldBinding2.modifiers & 0xFFFF) && 
/* 160 */       CharOperation.equals(fieldBinding.name, fieldBinding2.name) && 
/* 161 */       isEqual(fieldBinding.type, fieldBinding2.type, visitedTypes) && 
/* 162 */       isEqual((TypeBinding)fieldBinding.declaringClass, (TypeBinding)fieldBinding2.declaringClass, visitedTypes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isEqual(TypeBinding[] bindings, TypeBinding[] otherBindings) {
/* 171 */     return isEqual(bindings, otherBindings, new HashSet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isEqual(TypeBinding[] bindings, TypeBinding[] otherBindings, HashSet visitedTypes) {
/* 179 */     if (bindings == null) {
/* 180 */       return (otherBindings == null);
/*     */     }
/* 182 */     if (otherBindings == null) {
/* 183 */       return false;
/*     */     }
/* 185 */     int length = bindings.length;
/* 186 */     int otherLength = otherBindings.length;
/* 187 */     if (length != otherLength) {
/* 188 */       return false;
/*     */     }
/* 190 */     for (int i = 0; i < length; i++) {
/* 191 */       if (!isEqual(bindings[i], otherBindings[i], visitedTypes)) {
/* 192 */         return false;
/*     */       }
/*     */     } 
/* 195 */     return true; } static boolean isEqual(TypeBinding typeBinding, TypeBinding typeBinding2, HashSet<TypeBinding> visitedTypes) { ParameterizedTypeBinding parameterizedTypeBinding, parameterizedTypeBinding2;
/*     */     WildcardBinding wildcardBinding, wildcardBinding2, intersectionBinding, intersectionBinding2;
/*     */     TypeVariableBinding typeVariableBinding, typeVariableBinding2;
/* 198 */     if (TypeBinding.equalsEquals(typeBinding, typeBinding2))
/* 199 */       return true; 
/* 200 */     if (typeBinding == null || typeBinding2 == null) {
/* 201 */       return false;
/*     */     }
/* 203 */     switch (typeBinding.kind()) {
/*     */       case 132:
/* 205 */         if (!typeBinding2.isBaseType()) {
/* 206 */           return false;
/*     */         }
/* 208 */         return (typeBinding.id == typeBinding2.id);
/*     */       
/*     */       case 68:
/* 211 */         if (!typeBinding2.isArrayType()) {
/* 212 */           return false;
/*     */         }
/* 214 */         return (typeBinding.dimensions() == typeBinding2.dimensions() && 
/* 215 */           isEqual(typeBinding.leafComponentType(), typeBinding2.leafComponentType(), visitedTypes));
/*     */       
/*     */       case 260:
/* 218 */         if (!typeBinding2.isParameterizedType()) {
/* 219 */           return false;
/*     */         }
/* 221 */         parameterizedTypeBinding = (ParameterizedTypeBinding)typeBinding;
/* 222 */         parameterizedTypeBinding2 = (ParameterizedTypeBinding)typeBinding2;
/* 223 */         if (CharOperation.equals(parameterizedTypeBinding.compoundName, parameterizedTypeBinding2.compoundName) && (
/* 224 */           parameterizedTypeBinding.modifiers & 0xFFFF) == (
/* 225 */           parameterizedTypeBinding2.modifiers & 0xFFFF))
/* 226 */           if (isEqual(parameterizedTypeBinding.arguments, parameterizedTypeBinding2.arguments, visitedTypes) && 
/* 227 */             isEqual((TypeBinding)parameterizedTypeBinding.enclosingType(), (TypeBinding)parameterizedTypeBinding2.enclosingType(), visitedTypes))
/*     */             return true;   return false;
/*     */       case 516:
/* 230 */         if (typeBinding2.kind() != 516) {
/* 231 */           return false;
/*     */         }
/* 233 */         wildcardBinding = (WildcardBinding)typeBinding;
/* 234 */         wildcardBinding2 = (WildcardBinding)typeBinding2;
/* 235 */         return (isEqual(wildcardBinding.bound, wildcardBinding2.bound, visitedTypes) && 
/* 236 */           wildcardBinding.boundKind == wildcardBinding2.boundKind);
/*     */       
/*     */       case 8196:
/* 239 */         if (typeBinding2.kind() != 8196) {
/* 240 */           return false;
/*     */         }
/* 242 */         intersectionBinding = (WildcardBinding)typeBinding;
/* 243 */         intersectionBinding2 = (WildcardBinding)typeBinding2;
/* 244 */         return (isEqual(intersectionBinding.bound, intersectionBinding2.bound, visitedTypes) && 
/* 245 */           isEqual(intersectionBinding.otherBounds, intersectionBinding2.otherBounds, visitedTypes));
/*     */       
/*     */       case 4100:
/* 248 */         if (!typeBinding2.isTypeVariable()) {
/* 249 */           return false;
/*     */         }
/* 251 */         if (typeBinding.isCapture()) {
/* 252 */           if (!typeBinding2.isCapture()) {
/* 253 */             return false;
/*     */           }
/* 255 */           CaptureBinding captureBinding = (CaptureBinding)typeBinding;
/* 256 */           CaptureBinding captureBinding2 = (CaptureBinding)typeBinding2;
/* 257 */           if (captureBinding.end == captureBinding2.end) {
/* 258 */             if (visitedTypes.contains(typeBinding)) return true; 
/* 259 */             visitedTypes.add(typeBinding);
/*     */             
/* 261 */             return (isEqual((TypeBinding)captureBinding.wildcard, (TypeBinding)captureBinding2.wildcard, visitedTypes) && 
/* 262 */               isEqual((TypeBinding)captureBinding.sourceType, (TypeBinding)captureBinding2.sourceType, visitedTypes));
/*     */           } 
/* 264 */           return false;
/*     */         } 
/* 266 */         typeVariableBinding = (TypeVariableBinding)typeBinding;
/* 267 */         typeVariableBinding2 = (TypeVariableBinding)typeBinding2;
/* 268 */         if (CharOperation.equals(typeVariableBinding.sourceName, typeVariableBinding2.sourceName)) {
/* 269 */           if (visitedTypes.contains(typeBinding)) return true; 
/* 270 */           visitedTypes.add(typeBinding);
/*     */           
/* 272 */           return (isEqual(typeVariableBinding.declaringElement, typeVariableBinding2.declaringElement, visitedTypes) && 
/* 273 */             isEqual((TypeBinding)typeVariableBinding.superclass(), (TypeBinding)typeVariableBinding2.superclass(), visitedTypes) && 
/* 274 */             isEqual((TypeBinding[])typeVariableBinding.superInterfaces(), (TypeBinding[])typeVariableBinding2.superInterfaces(), visitedTypes));
/*     */         } 
/* 276 */         return false;
/*     */       case 2052:
/* 278 */         if (!typeBinding2.isGenericType()) {
/* 279 */           return false;
/*     */         }
/* 281 */         referenceBinding = (ReferenceBinding)typeBinding;
/* 282 */         referenceBinding2 = (ReferenceBinding)typeBinding2;
/* 283 */         if (CharOperation.equals(referenceBinding.compoundName, referenceBinding2.compoundName) && (
/* 284 */           referenceBinding.modifiers & 0xFFFF) == (
/* 285 */           referenceBinding2.modifiers & 0xFFFF))
/* 286 */           if (isEqual((TypeBinding[])referenceBinding.typeVariables(), (TypeBinding[])referenceBinding2.typeVariables(), visitedTypes) && 
/* 287 */             isEqual((TypeBinding)referenceBinding.enclosingType(), (TypeBinding)referenceBinding2.enclosingType(), visitedTypes))
/*     */             return true;  
/*     */         return false;
/*     */     } 
/* 291 */     if (!(typeBinding2 instanceof ReferenceBinding)) {
/* 292 */       return false;
/*     */     }
/* 294 */     ReferenceBinding referenceBinding = (ReferenceBinding)typeBinding;
/* 295 */     ReferenceBinding referenceBinding2 = (ReferenceBinding)typeBinding2;
/* 296 */     char[] constantPoolName = referenceBinding.constantPoolName();
/* 297 */     char[] constantPoolName2 = referenceBinding2.constantPoolName();
/*     */     
/* 299 */     if (constantPoolName == null) {
/* 300 */       if (constantPoolName2 != null) {
/* 301 */         return false;
/*     */       }
/* 303 */       if (!CharOperation.equals(referenceBinding.computeUniqueKey(), referenceBinding2.computeUniqueKey())) {
/* 304 */         return false;
/*     */       }
/*     */     } else {
/* 307 */       if (constantPoolName2 == null) {
/* 308 */         return false;
/*     */       }
/* 310 */       if (!CharOperation.equals(constantPoolName, constantPoolName2)) {
/* 311 */         return false;
/*     */       }
/*     */     } 
/* 314 */     if (CharOperation.equals(referenceBinding.compoundName, referenceBinding2.compoundName) && 
/* 315 */       !referenceBinding2.isGenericType() && 
/* 316 */       referenceBinding.isRawType() == referenceBinding2.isRawType() && (
/* 317 */       referenceBinding.modifiers & 0xFFFFFFDF & 0xFFFF) == (
/* 318 */       referenceBinding2.modifiers & 0xFFFFFFDF & 0xFFFF)) {
/* 319 */       if (isEqual((TypeBinding)referenceBinding.enclosingType(), (TypeBinding)referenceBinding2.enclosingType(), visitedTypes)) {
/*     */         return true;
/*     */       }
/*     */     }
/*     */     return false; }
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isEqual(TypeBinding typeBinding, TypeBinding typeBinding2) {
/* 328 */     return isEqual(typeBinding, typeBinding2, new HashSet());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\BindingComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */