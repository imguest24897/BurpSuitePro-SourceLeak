/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.core.compiler.CharOperation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnPackageVisibilityReference
/*    */   extends CompletionOnImportReference
/*    */ {
/*    */   String pkgName;
/*    */   
/*    */   public CompletionOnPackageVisibilityReference(char[][] ident, long[] pos) {
/* 44 */     super(ident, pos, 0);
/* 45 */     this.pkgName = new String(CharOperation.concatWith(ident, '.'));
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer print(int indent, StringBuffer output) {
/* 50 */     printIndent(indent, output).append("<CompleteOnPackageVisibilityReference:");
/* 51 */     output.append(this.pkgName);
/* 52 */     return output.append('>');
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnPackageVisibilityReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */