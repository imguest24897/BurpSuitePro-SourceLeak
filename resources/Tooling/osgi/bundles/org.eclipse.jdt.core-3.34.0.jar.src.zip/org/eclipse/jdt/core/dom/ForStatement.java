/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ForStatement
/*     */   extends Statement
/*     */ {
/*  55 */   public static final ChildListPropertyDescriptor INITIALIZERS_PROPERTY = new ChildListPropertyDescriptor(ForStatement.class, "initializers", Expression.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(ForStatement.class, "expression", Expression.class, false, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public static final ChildListPropertyDescriptor UPDATERS_PROPERTY = new ChildListPropertyDescriptor(ForStatement.class, "updaters", Expression.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public static final ChildPropertyDescriptor BODY_PROPERTY = new ChildPropertyDescriptor(ForStatement.class, "body", Statement.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  86 */     List properyList = new ArrayList(5);
/*  87 */     createPropertyList(ForStatement.class, properyList);
/*  88 */     addProperty(INITIALIZERS_PROPERTY, properyList);
/*  89 */     addProperty(EXPRESSION_PROPERTY, properyList);
/*  90 */     addProperty(UPDATERS_PROPERTY, properyList);
/*  91 */     addProperty(BODY_PROPERTY, properyList);
/*  92 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 107 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   private ASTNode.NodeList initializers = new ASTNode.NodeList(this, INITIALIZERS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   private Expression optionalConditionExpression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   private ASTNode.NodeList updaters = new ASTNode.NodeList(this, UPDATERS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 133 */   private Statement body = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ForStatement(AST ast) {
/* 143 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 148 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 153 */     if (property == EXPRESSION_PROPERTY) {
/* 154 */       if (get) {
/* 155 */         return getExpression();
/*     */       }
/* 157 */       setExpression((Expression)child);
/* 158 */       return null;
/*     */     } 
/*     */     
/* 161 */     if (property == BODY_PROPERTY) {
/* 162 */       if (get) {
/* 163 */         return getBody();
/*     */       }
/* 165 */       setBody((Statement)child);
/* 166 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 170 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 175 */     if (property == INITIALIZERS_PROPERTY) {
/* 176 */       return initializers();
/*     */     }
/* 178 */     if (property == UPDATERS_PROPERTY) {
/* 179 */       return updaters();
/*     */     }
/*     */     
/* 182 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 187 */     return 24;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 192 */     ForStatement result = new ForStatement(target);
/* 193 */     result.setSourceRange(getStartPosition(), getLength());
/* 194 */     result.copyLeadingComment(this);
/* 195 */     result.initializers().addAll(ASTNode.copySubtrees(target, initializers()));
/* 196 */     result.setExpression(
/* 197 */         (Expression)ASTNode.copySubtree(target, getExpression()));
/* 198 */     result.updaters().addAll(ASTNode.copySubtrees(target, updaters()));
/* 199 */     result.setBody(
/* 200 */         (Statement)ASTNode.copySubtree(target, getBody()));
/* 201 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 207 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 212 */     boolean visitChildren = visitor.visit(this);
/* 213 */     if (visitChildren) {
/*     */       
/* 215 */       acceptChildren(visitor, this.initializers);
/* 216 */       acceptChild(visitor, getExpression());
/* 217 */       acceptChildren(visitor, this.updaters);
/* 218 */       acceptChild(visitor, getBody());
/*     */     } 
/* 220 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List initializers() {
/* 236 */     return this.initializers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 247 */     return this.optionalConditionExpression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 263 */     ASTNode oldChild = this.optionalConditionExpression;
/* 264 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 265 */     this.optionalConditionExpression = expression;
/* 266 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List updaters() {
/* 281 */     return this.updaters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement getBody() {
/* 290 */     if (this.body == null)
/*     */     {
/* 292 */       synchronized (this) {
/* 293 */         if (this.body == null) {
/* 294 */           preLazyInit();
/* 295 */           this.body = new Block(this.ast);
/* 296 */           postLazyInit(this.body, BODY_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 300 */     return this.body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBody(Statement statement) {
/* 323 */     if (statement == null) {
/* 324 */       throw new IllegalArgumentException();
/*     */     }
/* 326 */     ASTNode oldChild = this.body;
/* 327 */     preReplaceChild(oldChild, statement, BODY_PROPERTY);
/* 328 */     this.body = statement;
/* 329 */     postReplaceChild(oldChild, statement, BODY_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 334 */     return super.memSize() + 16;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 339 */     return 
/* 340 */       memSize() + 
/* 341 */       this.initializers.listSize() + 
/* 342 */       this.updaters.listSize() + (
/* 343 */       (this.optionalConditionExpression == null) ? 0 : getExpression().treeSize()) + (
/* 344 */       (this.body == null) ? 0 : getBody().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ForStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */