/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.ReferenceExpression;
/*    */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*    */ import org.eclipse.jdt.internal.compiler.impl.CompilerOptions;
/*    */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnReferenceExpressionName
/*    */   extends ReferenceExpression
/*    */ {
/*    */   public CompletionOnReferenceExpressionName(Scanner scanner) {
/* 29 */     super(scanner);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeBinding resolveType(BlockScope scope) {
/* 35 */     CompilerOptions compilerOptions = scope.compilerOptions();
/*    */ 
/*    */ 
/*    */     
/* 39 */     this.constant = Constant.NotAConstant;
/* 40 */     TypeBinding lhsType = this.lhs.resolveType(scope);
/* 41 */     if (this.typeArguments != null) {
/* 42 */       int length = this.typeArguments.length;
/* 43 */       boolean typeArgumentsHaveErrors = (compilerOptions.sourceLevel < 3211264L);
/* 44 */       this.resolvedTypeArguments = new TypeBinding[length];
/* 45 */       for (int i = 0; i < length; i++) {
/* 46 */         TypeReference typeReference = this.typeArguments[i];
/* 47 */         this.resolvedTypeArguments[i] = typeReference.resolveType(scope, true); if (typeReference.resolveType(scope, true) == null) {
/* 48 */           typeArgumentsHaveErrors = true;
/*    */         }
/* 50 */         if (typeArgumentsHaveErrors && typeReference instanceof org.eclipse.jdt.internal.compiler.ast.Wildcard) {
/* 51 */           scope.problemReporter().illegalUsageOfWildcard(typeReference);
/*    */         }
/*    */       } 
/* 54 */       if (typeArgumentsHaveErrors || lhsType == null) {
/* 55 */         throw new CompletionNodeFound();
/*    */       }
/*    */     } 
/* 58 */     if (lhsType != null && lhsType.isValidBinding())
/* 59 */       throw new CompletionNodeFound(this, lhsType, scope); 
/* 60 */     throw new CompletionNodeFound();
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int tab, StringBuffer output) {
/* 65 */     output.append("<CompletionOnReferenceExpressionName:");
/* 66 */     this.lhs.print(0, output);
/* 67 */     output.append("::");
/* 68 */     if (this.typeArguments != null) {
/* 69 */       output.append('<');
/* 70 */       int max = this.typeArguments.length - 1;
/* 71 */       for (int j = 0; j < max; j++) {
/* 72 */         this.typeArguments[j].print(0, output);
/* 73 */         output.append(", ");
/*    */       } 
/* 75 */       this.typeArguments[max].print(0, output);
/* 76 */       output.append('>');
/*    */     } 
/* 78 */     output.append(this.selector);
/* 79 */     return output.append('>');
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnReferenceExpressionName.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */