/*     */ package org.eclipse.jdt.core.jdom;
/*     */ 
/*     */ import org.eclipse.jdt.internal.core.jdom.DOMBuilder;
/*     */ import org.eclipse.jdt.internal.core.jdom.SimpleDOMBuilder;
/*     */ import org.eclipse.jdt.internal.core.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DOMFactory
/*     */   implements IDOMFactory
/*     */ {
/*  36 */   String lineSeparator = Util.getLineSeparator(null, null);
/*     */ 
/*     */ 
/*     */   
/*     */   public IDOMCompilationUnit createCompilationUnit() {
/*  41 */     return (new DOMBuilder()).createCompilationUnit();
/*     */   }
/*     */ 
/*     */   
/*     */   public IDOMCompilationUnit createCompilationUnit(char[] sourceCode, String name) {
/*  46 */     if (sourceCode == null) {
/*  47 */       return null;
/*     */     }
/*  49 */     return (new SimpleDOMBuilder()).createCompilationUnit(sourceCode, name.toCharArray());
/*     */   }
/*     */ 
/*     */   
/*     */   public IDOMCompilationUnit createCompilationUnit(String sourceCode, String name) {
/*  54 */     if (sourceCode == null) {
/*  55 */       return null;
/*     */     }
/*  57 */     return (new SimpleDOMBuilder()).createCompilationUnit(sourceCode.toCharArray(), name.toCharArray());
/*     */   }
/*     */ 
/*     */   
/*     */   public IDOMField createField() {
/*  62 */     return createField("Object aField;" + this.lineSeparator);
/*     */   }
/*     */ 
/*     */   
/*     */   public IDOMField createField(String sourceCode) {
/*  67 */     if (sourceCode == null) {
/*  68 */       return null;
/*     */     }
/*  70 */     return (new DOMBuilder()).createField(sourceCode.toCharArray());
/*     */   }
/*     */ 
/*     */   
/*     */   public IDOMImport createImport() {
/*  75 */     return (new DOMBuilder()).createImport();
/*     */   }
/*     */ 
/*     */   
/*     */   public IDOMImport createImport(String sourceCode) {
/*  80 */     if (sourceCode == null) {
/*  81 */       return null;
/*     */     }
/*  83 */     return (new DOMBuilder()).createImport(sourceCode.toCharArray());
/*     */   }
/*     */ 
/*     */   
/*     */   public IDOMInitializer createInitializer() {
/*  88 */     return createInitializer("static {}" + this.lineSeparator);
/*     */   }
/*     */ 
/*     */   
/*     */   public IDOMInitializer createInitializer(String sourceCode) {
/*  93 */     if (sourceCode == null) {
/*  94 */       return null;
/*     */     }
/*  96 */     return (new DOMBuilder()).createInitializer(sourceCode.toCharArray());
/*     */   }
/*     */ 
/*     */   
/*     */   public IDOMMethod createMethod() {
/* 101 */     return createMethod("public void newMethod() {" + this.lineSeparator + "}" + this.lineSeparator);
/*     */   }
/*     */ 
/*     */   
/*     */   public IDOMMethod createMethod(String sourceCode) {
/* 106 */     if (sourceCode == null) {
/* 107 */       return null;
/*     */     }
/* 109 */     return (new DOMBuilder()).createMethod(sourceCode.toCharArray());
/*     */   }
/*     */ 
/*     */   
/*     */   public IDOMPackage createPackage() {
/* 114 */     return (new DOMBuilder()).createPackage();
/*     */   }
/*     */ 
/*     */   
/*     */   public IDOMPackage createPackage(String sourceCode) {
/* 119 */     if (sourceCode == null) {
/* 120 */       return null;
/*     */     }
/* 122 */     return (new DOMBuilder()).createPackage(sourceCode.toCharArray());
/*     */   }
/*     */ 
/*     */   
/*     */   public IDOMType createType() {
/* 127 */     return createType("public class AClass {" + this.lineSeparator + "}" + this.lineSeparator);
/*     */   }
/*     */ 
/*     */   
/*     */   public IDOMType createClass() {
/* 132 */     return createType("public class AClass {" + this.lineSeparator + "}" + this.lineSeparator);
/*     */   }
/*     */ 
/*     */   
/*     */   public IDOMType createInterface() {
/* 137 */     return createType("public interface AnInterface {" + this.lineSeparator + "}" + this.lineSeparator);
/*     */   }
/*     */ 
/*     */   
/*     */   public IDOMType createType(String sourceCode) {
/* 142 */     if (sourceCode == null) {
/* 143 */       return null;
/*     */     }
/* 145 */     return (new DOMBuilder()).createType(sourceCode.toCharArray());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\jdom\DOMFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */