/*     */ package org.eclipse.jdt.core.search;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.SourceElementParser;
/*     */ import org.eclipse.jdt.internal.core.index.Index;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SearchDocument
/*     */ {
/*     */   private Index index;
/*     */   private String containerRelativePath;
/*     */   private SourceElementParser parser;
/*     */   private String documentPath;
/*     */   private SearchParticipant participant;
/*     */   private boolean shouldIndexResolvedDocument = false;
/*     */   
/*     */   protected SearchDocument(String documentPath, SearchParticipant participant) {
/*  45 */     this.documentPath = documentPath;
/*  46 */     this.participant = participant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addIndexEntry(char[] category, char[] key) {
/*  58 */     if (this.index != null) {
/*  59 */       this.index.addIndexEntry(category, key, getContainerRelativePath());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract byte[] getByteContents();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract char[] getCharContents();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getContainerRelativePath() {
/* 101 */     if (this.containerRelativePath == null)
/* 102 */       this.containerRelativePath = this.index.containerRelativePath(getPath()); 
/* 103 */     return this.containerRelativePath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getEncoding();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SourceElementParser getParser() {
/* 122 */     return this.parser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SearchParticipant getParticipant() {
/* 131 */     return this.participant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getPath() {
/* 143 */     return this.documentPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAllIndexEntries() {
/* 151 */     if (this.index != null) {
/* 152 */       this.index.remove(getContainerRelativePath());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIndex(Index indexToSet) {
/* 160 */     this.index = indexToSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParser(SourceElementParser sourceElementParser) {
/* 168 */     this.parser = sourceElementParser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void requireIndexingResolvedDocument() {
/* 178 */     this.shouldIndexResolvedDocument = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldIndexResolvedDocument() {
/* 186 */     return this.shouldIndexResolvedDocument;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\search\SearchDocument.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */