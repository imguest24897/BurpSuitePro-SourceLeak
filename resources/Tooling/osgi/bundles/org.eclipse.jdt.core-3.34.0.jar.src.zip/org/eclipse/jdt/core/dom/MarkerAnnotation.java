/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MarkerAnnotation
/*     */   extends Annotation
/*     */ {
/*  37 */   public static final ChildPropertyDescriptor TYPE_NAME_PROPERTY = internalTypeNamePropertyFactory(MarkerAnnotation.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  47 */     List propertyList = new ArrayList(2);
/*  48 */     createPropertyList(MarkerAnnotation.class, propertyList);
/*  49 */     addProperty(TYPE_NAME_PROPERTY, propertyList);
/*  50 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  62 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MarkerAnnotation(AST ast) {
/*  76 */     super(ast);
/*  77 */     unsupportedIn2();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  82 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/*  87 */     if (property == TYPE_NAME_PROPERTY) {
/*  88 */       if (get) {
/*  89 */         return getTypeName();
/*     */       }
/*  91 */       setTypeName((Name)child);
/*  92 */       return null;
/*     */     } 
/*     */ 
/*     */     
/*  96 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildPropertyDescriptor internalTypeNameProperty() {
/* 101 */     return TYPE_NAME_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 106 */     return 78;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 111 */     MarkerAnnotation result = new MarkerAnnotation(target);
/* 112 */     result.setSourceRange(getStartPosition(), getLength());
/* 113 */     result.setTypeName((Name)ASTNode.copySubtree(target, getTypeName()));
/* 114 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 120 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 125 */     boolean visitChildren = visitor.visit(this);
/* 126 */     if (visitChildren)
/*     */     {
/* 128 */       acceptChild(visitor, getTypeName());
/*     */     }
/* 130 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 135 */     return super.memSize();
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 140 */     return 
/* 141 */       memSize() + (
/* 142 */       (this.typeName == null) ? 0 : getTypeName().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\MarkerAnnotation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */