package org.eclipse.jdt.core.jdom;

public interface IDOMImport extends IDOMNode {
  String getName();
  
  boolean isOnDemand();
  
  int getFlags();
  
  void setFlags(int paramInt);
  
  void setName(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\jdom\IDOMImport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */