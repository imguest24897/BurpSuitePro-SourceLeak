/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PostfixExpression
/*     */   extends Expression
/*     */ {
/*     */   public static class Operator
/*     */   {
/*     */     private String token;
/*     */     
/*     */     private Operator(String token) {
/*  61 */       this.token = token;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/*  71 */       return this.token;
/*     */     }
/*     */ 
/*     */     
/*  75 */     public static final Operator INCREMENT = new Operator("++");
/*     */     
/*  77 */     public static final Operator DECREMENT = new Operator("--");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     private static final Map CODES = new HashMap<>(20); static {
/*  86 */       Operator[] ops = {
/*  87 */           INCREMENT, 
/*  88 */           DECREMENT
/*     */         };
/*  90 */       for (int i = 0; i < ops.length; i++) {
/*  91 */         CODES.put(ops[i].toString(), ops[i]);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Operator toOperator(String token) {
/* 108 */       return (Operator)CODES.get(token);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public static final SimplePropertyDescriptor OPERATOR_PROPERTY = new SimplePropertyDescriptor(PostfixExpression.class, "operator", Operator.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public static final ChildPropertyDescriptor OPERAND_PROPERTY = new ChildPropertyDescriptor(PostfixExpression.class, "operand", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 134 */     List propertyList = new ArrayList(3);
/* 135 */     createPropertyList(PostfixExpression.class, propertyList);
/* 136 */     addProperty(OPERAND_PROPERTY, propertyList);
/* 137 */     addProperty(OPERATOR_PROPERTY, propertyList);
/* 138 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/* 153 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   private Operator operator = Operator.INCREMENT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   private Expression operand = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PostfixExpression(AST ast) {
/* 176 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 181 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final Object internalGetSetObjectProperty(SimplePropertyDescriptor property, boolean get, Object value) {
/* 186 */     if (property == OPERATOR_PROPERTY) {
/* 187 */       if (get) {
/* 188 */         return getOperator();
/*     */       }
/* 190 */       setOperator((Operator)value);
/* 191 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 195 */     return super.internalGetSetObjectProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 200 */     if (property == OPERAND_PROPERTY) {
/* 201 */       if (get) {
/* 202 */         return getOperand();
/*     */       }
/* 204 */       setOperand((Expression)child);
/* 205 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 209 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 214 */     return 37;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 219 */     PostfixExpression result = new PostfixExpression(target);
/* 220 */     result.setSourceRange(getStartPosition(), getLength());
/* 221 */     result.setOperator(getOperator());
/* 222 */     result.setOperand((Expression)getOperand().clone(target));
/* 223 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 229 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 234 */     boolean visitChildren = visitor.visit(this);
/* 235 */     if (visitChildren) {
/* 236 */       acceptChild(visitor, getOperand());
/*     */     }
/* 238 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Operator getOperator() {
/* 247 */     return this.operator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOperator(Operator operator) {
/* 257 */     if (operator == null) {
/* 258 */       throw new IllegalArgumentException();
/*     */     }
/* 260 */     preValueChange(OPERATOR_PROPERTY);
/* 261 */     this.operator = operator;
/* 262 */     postValueChange(OPERATOR_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getOperand() {
/* 271 */     if (this.operand == null)
/*     */     {
/* 273 */       synchronized (this) {
/* 274 */         if (this.operand == null) {
/* 275 */           preLazyInit();
/* 276 */           this.operand = new SimpleName(this.ast);
/* 277 */           postLazyInit(this.operand, OPERAND_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 281 */     return this.operand;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOperand(Expression expression) {
/* 296 */     if (expression == null) {
/* 297 */       throw new IllegalArgumentException();
/*     */     }
/* 299 */     ASTNode oldChild = this.operand;
/* 300 */     preReplaceChild(oldChild, expression, OPERAND_PROPERTY);
/* 301 */     this.operand = expression;
/* 302 */     postReplaceChild(oldChild, expression, OPERAND_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 308 */     return 48;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 313 */     return 
/* 314 */       memSize() + (
/* 315 */       (this.operand == null) ? 0 : getOperand().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\PostfixExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */