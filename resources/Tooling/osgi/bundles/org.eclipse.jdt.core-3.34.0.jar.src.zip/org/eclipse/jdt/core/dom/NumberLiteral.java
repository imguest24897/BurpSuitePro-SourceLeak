/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*     */ import org.eclipse.jdt.internal.compiler.parser.Scanner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NumberLiteral
/*     */   extends Expression
/*     */ {
/*  38 */   public static final SimplePropertyDescriptor TOKEN_PROPERTY = new SimplePropertyDescriptor(NumberLiteral.class, "token", String.class, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  48 */     List propertyList = new ArrayList(2);
/*  49 */     createPropertyList(NumberLiteral.class, propertyList);
/*  50 */     addProperty(TOKEN_PROPERTY, propertyList);
/*  51 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  66 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private String tokenValue = "0";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NumberLiteral(AST ast) {
/*  84 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  89 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final Object internalGetSetObjectProperty(SimplePropertyDescriptor property, boolean get, Object value) {
/*  94 */     if (property == TOKEN_PROPERTY) {
/*  95 */       if (get) {
/*  96 */         return getToken();
/*     */       }
/*  98 */       setToken((String)value);
/*  99 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 103 */     return super.internalGetSetObjectProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 108 */     return 34;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 113 */     NumberLiteral result = new NumberLiteral(target);
/* 114 */     result.setSourceRange(getStartPosition(), getLength());
/* 115 */     result.setToken(getToken());
/* 116 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 122 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 127 */     visitor.visit(this);
/* 128 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getToken() {
/* 138 */     return this.tokenValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setToken(String token) {
/* 150 */     if (token == null || token.length() == 0) {
/* 151 */       throw new IllegalArgumentException();
/*     */     }
/* 153 */     Scanner scanner = this.ast.scanner;
/* 154 */     char[] source = token.toCharArray();
/* 155 */     scanner.setSource(source);
/* 156 */     scanner.resetTo(0, source.length);
/* 157 */     scanner.tokenizeComments = false;
/* 158 */     scanner.tokenizeWhiteSpace = false;
/*     */     try {
/* 160 */       int tokenType = scanner.getNextToken();
/* 161 */       switch (tokenType) {
/*     */         case 55:
/*     */         case 56:
/*     */         case 57:
/*     */         case 58:
/*     */           break;
/*     */         case 5:
/* 168 */           tokenType = scanner.getNextToken();
/* 169 */           switch (tokenType) {
/*     */             case 55:
/*     */             case 56:
/*     */             case 57:
/*     */             case 58:
/*     */               break;
/*     */           } 
/* 176 */           throw new IllegalArgumentException("Invalid number literal : >" + token + "<");
/*     */ 
/*     */         
/*     */         default:
/* 180 */           throw new IllegalArgumentException("Invalid number literal : >" + token + "<");
/*     */       } 
/* 182 */     } catch (InvalidInputException invalidInputException) {
/* 183 */       throw new IllegalArgumentException();
/*     */     } finally {
/* 185 */       scanner.tokenizeComments = true;
/* 186 */       scanner.tokenizeWhiteSpace = true;
/*     */     } 
/* 188 */     preValueChange(TOKEN_PROPERTY);
/* 189 */     this.tokenValue = token;
/* 190 */     postValueChange(TOKEN_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void internalSetToken(String token) {
/* 197 */     preValueChange(TOKEN_PROPERTY);
/* 198 */     this.tokenValue = token;
/* 199 */     postValueChange(TOKEN_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 204 */     int size = 44 + stringSize(this.tokenValue);
/* 205 */     return size;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 210 */     return memSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\NumberLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */