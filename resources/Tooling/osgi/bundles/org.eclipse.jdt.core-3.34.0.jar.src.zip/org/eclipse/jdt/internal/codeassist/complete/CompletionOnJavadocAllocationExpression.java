/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.JavadocAllocationExpression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnJavadocAllocationExpression
/*    */   extends JavadocAllocationExpression
/*    */   implements CompletionOnJavadoc
/*    */ {
/* 19 */   public int completionFlags = 1;
/*    */   public int separatorPosition;
/*    */   
/*    */   public CompletionOnJavadocAllocationExpression(JavadocAllocationExpression allocation, int position) {
/* 23 */     super(allocation.sourceStart, allocation.sourceEnd);
/* 24 */     this.arguments = allocation.arguments;
/* 25 */     this.type = allocation.type;
/* 26 */     this.tagValue = allocation.tagValue;
/* 27 */     this.sourceEnd = allocation.sourceEnd;
/* 28 */     this.separatorPosition = position;
/* 29 */     this.qualification = allocation.qualification;
/*    */   }
/*    */   
/*    */   public CompletionOnJavadocAllocationExpression(JavadocAllocationExpression allocation, int position, int flags) {
/* 33 */     this(allocation, position);
/* 34 */     this.completionFlags |= flags;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addCompletionFlags(int flags) {
/* 39 */     this.completionFlags |= flags;
/*    */   }
/*    */   
/*    */   public boolean completeAnException() {
/* 43 */     return ((this.completionFlags & 0x2) != 0);
/*    */   }
/*    */   
/*    */   public boolean completeInText() {
/* 47 */     return ((this.completionFlags & 0x4) != 0);
/*    */   }
/*    */   
/*    */   public boolean completeBaseTypes() {
/* 51 */     return ((this.completionFlags & 0x8) != 0);
/*    */   }
/*    */   
/*    */   public boolean completeFormalReference() {
/* 55 */     return ((this.completionFlags & 0x40) != 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getCompletionFlags() {
/* 60 */     return this.completionFlags;
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 65 */     output.append("<CompleteOnJavadocAllocationExpression:");
/* 66 */     super.printExpression(indent, output);
/* 67 */     indent++;
/* 68 */     if (this.completionFlags > 0) {
/* 69 */       output.append('\n');
/* 70 */       for (int j = 0; j < indent; ) { output.append('\t'); j++; }
/* 71 */        output.append("infos:");
/* 72 */       char separator = Character.MIN_VALUE;
/* 73 */       if (completeAnException()) {
/* 74 */         output.append("exception");
/* 75 */         separator = ',';
/*    */       } 
/* 77 */       if (completeInText()) {
/* 78 */         if (separator != '\000') output.append(separator); 
/* 79 */         output.append("text");
/* 80 */         separator = ',';
/*    */       } 
/* 82 */       if (completeBaseTypes()) {
/* 83 */         if (separator != '\000') output.append(separator); 
/* 84 */         output.append("base types");
/* 85 */         separator = ',';
/*    */       } 
/* 87 */       if (completeFormalReference()) {
/* 88 */         if (separator != '\000') output.append(separator); 
/* 89 */         output.append("formal reference");
/* 90 */         separator = ',';
/*    */       } 
/* 92 */       output.append('\n');
/*    */     } 
/* 94 */     indent--;
/* 95 */     for (int i = 0; i < indent; ) { output.append('\t'); i++; }
/* 96 */      return output.append('>');
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnJavadocAllocationExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */