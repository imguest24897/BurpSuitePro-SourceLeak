/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImportDeclaration
/*     */   extends ASTNode
/*     */ {
/*  38 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(ImportDeclaration.class, "name", Name.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public static final SimplePropertyDescriptor ON_DEMAND_PROPERTY = new SimplePropertyDescriptor(ImportDeclaration.class, "onDemand", boolean.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public static final SimplePropertyDescriptor STATIC_PROPERTY = new SimplePropertyDescriptor(ImportDeclaration.class, "static", boolean.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_2_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_3_0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  71 */     List properyList = new ArrayList(3);
/*  72 */     createPropertyList(ImportDeclaration.class, properyList);
/*  73 */     addProperty(NAME_PROPERTY, properyList);
/*  74 */     addProperty(ON_DEMAND_PROPERTY, properyList);
/*  75 */     PROPERTY_DESCRIPTORS_2_0 = reapPropertyList(properyList);
/*     */     
/*  77 */     properyList = new ArrayList(4);
/*  78 */     createPropertyList(ImportDeclaration.class, properyList);
/*  79 */     addProperty(STATIC_PROPERTY, properyList);
/*  80 */     addProperty(NAME_PROPERTY, properyList);
/*  81 */     addProperty(ON_DEMAND_PROPERTY, properyList);
/*  82 */     PROPERTY_DESCRIPTORS_3_0 = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  97 */     if (apiLevel == 2) {
/*  98 */       return PROPERTY_DESCRIPTORS_2_0;
/*     */     }
/* 100 */     return PROPERTY_DESCRIPTORS_3_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   private Name importName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean onDemand = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isStatic = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ImportDeclaration(AST ast) {
/* 135 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 140 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final boolean internalGetSetBooleanProperty(SimplePropertyDescriptor property, boolean get, boolean value) {
/* 145 */     if (property == ON_DEMAND_PROPERTY) {
/* 146 */       if (get) {
/* 147 */         return isOnDemand();
/*     */       }
/* 149 */       setOnDemand(value);
/* 150 */       return false;
/*     */     } 
/*     */     
/* 153 */     if (property == STATIC_PROPERTY) {
/* 154 */       if (get) {
/* 155 */         return isStatic();
/*     */       }
/* 157 */       setStatic(value);
/* 158 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 162 */     return super.internalGetSetBooleanProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 167 */     if (property == NAME_PROPERTY) {
/* 168 */       if (get) {
/* 169 */         return getName();
/*     */       }
/* 171 */       setName((Name)child);
/* 172 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 176 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 181 */     return 26;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 186 */     ImportDeclaration result = new ImportDeclaration(target);
/* 187 */     result.setSourceRange(getStartPosition(), getLength());
/* 188 */     result.setOnDemand(isOnDemand());
/* 189 */     if (this.ast.apiLevel >= 3) {
/* 190 */       result.setStatic(isStatic());
/*     */     }
/* 192 */     result.setName((Name)getName().clone(target));
/* 193 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 199 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 204 */     boolean visitChildren = visitor.visit(this);
/* 205 */     if (visitChildren) {
/* 206 */       acceptChild(visitor, getName());
/*     */     }
/* 208 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getName() {
/* 224 */     if (this.importName == null)
/*     */     {
/* 226 */       synchronized (this) {
/* 227 */         if (this.importName == null) {
/* 228 */           preLazyInit();
/* 229 */           this.importName = this.ast.newQualifiedName(
/* 230 */               new SimpleName(this.ast), new SimpleName(this.ast));
/* 231 */           postLazyInit(this.importName, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 235 */     return this.importName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(Name name) {
/* 256 */     if (name == null) {
/* 257 */       throw new IllegalArgumentException();
/*     */     }
/* 259 */     ASTNode oldChild = this.importName;
/* 260 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 261 */     this.importName = name;
/* 262 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOnDemand() {
/* 273 */     return this.onDemand;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOnDemand(boolean onDemand) {
/* 284 */     preValueChange(ON_DEMAND_PROPERTY);
/* 285 */     this.onDemand = onDemand;
/* 286 */     postValueChange(ON_DEMAND_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStatic() {
/* 299 */     unsupportedIn2();
/* 300 */     return this.isStatic;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStatic(boolean isStatic) {
/* 313 */     unsupportedIn2();
/* 314 */     preValueChange(STATIC_PROPERTY);
/* 315 */     this.isStatic = isStatic;
/* 316 */     postValueChange(STATIC_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBinding resolveBinding() {
/* 343 */     return this.ast.getBindingResolver().resolveImport(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 348 */     return 52;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 353 */     return 
/* 354 */       memSize() + (
/* 355 */       (this.importName == null) ? 0 : getName().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ImportDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */