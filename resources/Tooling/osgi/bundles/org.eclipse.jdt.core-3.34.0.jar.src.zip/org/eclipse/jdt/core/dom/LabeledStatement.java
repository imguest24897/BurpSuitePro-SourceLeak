/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LabeledStatement
/*     */   extends Statement
/*     */ {
/*  39 */   public static final ChildPropertyDescriptor LABEL_PROPERTY = new ChildPropertyDescriptor(LabeledStatement.class, "label", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final ChildPropertyDescriptor BODY_PROPERTY = new ChildPropertyDescriptor(LabeledStatement.class, "body", Statement.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  56 */     List propertyList = new ArrayList(3);
/*  57 */     createPropertyList(LabeledStatement.class, propertyList);
/*  58 */     addProperty(LABEL_PROPERTY, propertyList);
/*  59 */     addProperty(BODY_PROPERTY, propertyList);
/*  60 */     PROPERTY_DESCRIPTORS = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  75 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private SimpleName labelName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private Statement body = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   LabeledStatement(AST ast) {
/* 101 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 106 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 111 */     if (property == LABEL_PROPERTY) {
/* 112 */       if (get) {
/* 113 */         return getLabel();
/*     */       }
/* 115 */       setLabel((SimpleName)child);
/* 116 */       return null;
/*     */     } 
/*     */     
/* 119 */     if (property == BODY_PROPERTY) {
/* 120 */       if (get) {
/* 121 */         return getBody();
/*     */       }
/* 123 */       setBody((Statement)child);
/* 124 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 128 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 133 */     return 30;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 138 */     LabeledStatement result = new LabeledStatement(target);
/* 139 */     result.setSourceRange(getStartPosition(), getLength());
/* 140 */     result.setLabel(
/* 141 */         (SimpleName)ASTNode.copySubtree(target, getLabel()));
/* 142 */     result.setBody(
/* 143 */         (Statement)ASTNode.copySubtree(target, getBody()));
/* 144 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 150 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 155 */     boolean visitChildren = visitor.visit(this);
/* 156 */     if (visitChildren) {
/*     */       
/* 158 */       acceptChild(visitor, getLabel());
/* 159 */       acceptChild(visitor, getBody());
/*     */     } 
/* 161 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getLabel() {
/* 170 */     if (this.labelName == null)
/*     */     {
/* 172 */       synchronized (this) {
/* 173 */         if (this.labelName == null) {
/* 174 */           preLazyInit();
/* 175 */           this.labelName = new SimpleName(this.ast);
/* 176 */           postLazyInit(this.labelName, LABEL_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 180 */     return this.labelName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLabel(SimpleName label) {
/* 194 */     if (label == null) {
/* 195 */       throw new IllegalArgumentException();
/*     */     }
/* 197 */     ASTNode oldChild = this.labelName;
/* 198 */     preReplaceChild(oldChild, label, LABEL_PROPERTY);
/* 199 */     this.labelName = label;
/* 200 */     postReplaceChild(oldChild, label, LABEL_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement getBody() {
/* 209 */     if (this.body == null)
/*     */     {
/* 211 */       synchronized (this) {
/* 212 */         if (this.body == null) {
/* 213 */           preLazyInit();
/* 214 */           this.body = new EmptyStatement(this.ast);
/* 215 */           postLazyInit(this.body, BODY_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 219 */     return this.body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBody(Statement statement) {
/* 242 */     if (statement == null) {
/* 243 */       throw new IllegalArgumentException();
/*     */     }
/* 245 */     ASTNode oldChild = this.body;
/* 246 */     preReplaceChild(oldChild, statement, BODY_PROPERTY);
/* 247 */     this.body = statement;
/* 248 */     postReplaceChild(oldChild, statement, BODY_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 253 */     return super.memSize() + 8;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 258 */     return 
/* 259 */       memSize() + (
/* 260 */       (this.labelName == null) ? 0 : getLabel().treeSize()) + (
/* 261 */       (this.body == null) ? 0 : getBody().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\LabeledStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */