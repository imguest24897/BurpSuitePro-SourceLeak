/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UsesDirective
/*     */   extends ModuleDirective
/*     */ {
/*  37 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(UsesDirective.class, "name", Name.class, true, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_9_0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  47 */     List properyList = new ArrayList(2);
/*  48 */     createPropertyList(UsesDirective.class, properyList);
/*  49 */     addProperty(NAME_PROPERTY, properyList);
/*  50 */     PROPERTY_DESCRIPTORS_9_0 = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  64 */     return PROPERTY_DESCRIPTORS_9_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private Name name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   UsesDirective(AST ast) {
/*  86 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  91 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/*  96 */     if (property == NAME_PROPERTY) {
/*  97 */       if (get) {
/*  98 */         return getName();
/*     */       }
/* 100 */       setName((Name)child);
/* 101 */       return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 106 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 111 */     return 97;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 116 */     UsesDirective result = new UsesDirective(target);
/* 117 */     result.setSourceRange(getStartPosition(), getLength());
/* 118 */     result.setName((Name)getName().clone(target));
/* 119 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 125 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 130 */     boolean visitChildren = visitor.visit(this);
/* 131 */     if (visitChildren) {
/* 132 */       acceptChild(visitor, getName());
/*     */     }
/* 134 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getName() {
/* 144 */     if (this.name == null)
/*     */     {
/* 146 */       synchronized (this) {
/* 147 */         if (this.name == null) {
/* 148 */           preLazyInit();
/* 149 */           this.name = this.ast.newQualifiedName(
/* 150 */               new SimpleName(this.ast), new SimpleName(this.ast));
/* 151 */           postLazyInit(this.name, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 155 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(Name name) {
/* 169 */     if (name == null) {
/* 170 */       throw new IllegalArgumentException();
/*     */     }
/* 172 */     ASTNode oldChild = this.name;
/* 173 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 174 */     this.name = name;
/* 175 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 180 */     return 44;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 185 */     return 
/* 186 */       memSize() + (
/* 187 */       (this.name == null) ? 0 : getName().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\UsesDirective.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */