/*    */ package org.eclipse.jdt.internal.codeassist.impl;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.jdt.core.JavaModelException;
/*    */ import org.eclipse.jdt.internal.core.ImportContainer;
/*    */ import org.eclipse.jdt.internal.core.ImportDeclaration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AssistImportDeclaration
/*    */   extends ImportDeclaration
/*    */ {
/*    */   private Map infoCache;
/*    */   
/*    */   public AssistImportDeclaration(ImportContainer parent, String name, boolean isOnDemand, Map infoCache) {
/* 27 */     super(parent, name, isOnDemand);
/* 28 */     this.infoCache = infoCache;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getElementInfo(IProgressMonitor monitor) throws JavaModelException {
/* 33 */     return this.infoCache.get(this);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\impl\AssistImportDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */