/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import org.eclipse.jdt.core.compiler.CategorizedProblem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ASTSyntaxErrorPropagator
/*     */   extends ASTVisitor
/*     */ {
/*     */   private CategorizedProblem[] problems;
/*     */   
/*     */   ASTSyntaxErrorPropagator(CategorizedProblem[] problems) {
/*  29 */     super(true);
/*  30 */     this.problems = problems;
/*     */   }
/*     */   
/*     */   private boolean checkAndTagAsMalformed(ASTNode node) {
/*  34 */     boolean tagWithErrors = false;
/*  35 */     for (int i = 0, max = this.problems.length; i < max; ) {
/*  36 */       CategorizedProblem problem = this.problems[i];
/*  37 */       switch (problem.getID()) {
/*     */         case 1610612940:
/*     */         case 1610612941:
/*     */         case 1610612945:
/*     */         case 1610612946:
/*     */         case 1610612966:
/*     */         case 1610612967:
/*     */         case 1610612968:
/*     */         case 1610612969:
/*     */         case 1610612970:
/*     */         case 1610612971:
/*     */         case 1610612972:
/*     */         case 1610612973:
/*     */         case 1610612974:
/*     */         case 1610612975:
/*     */         case 1610612976:
/*     */         case 1610612977:
/*     */         case 1610612978:
/*     */         case 1610612986:
/*     */         case 1610612987:
/*     */         case 1610612988:
/*     */         case 1610612989:
/*     */         case 1610612990:
/*     */         case 1610612991:
/*     */         case 1610612992:
/*     */         case 1610612993:
/*     */         case 1610612994:
/*     */         case 1610612995:
/*     */         case 1610612996:
/*     */         case 1610612998:
/*     */           break;
/*     */         default:
/*     */           i++; continue;
/*     */       } 
/*  71 */       int position = problem.getSourceStart();
/*  72 */       int start = node.getStartPosition();
/*  73 */       int end = start + node.getLength();
/*  74 */       if (start <= position && position <= end) {
/*  75 */         node.setFlags(node.getFlags() | 0x1);
/*     */         
/*  77 */         ASTNode currentNode = node.getParent();
/*  78 */         while (currentNode != null) {
/*  79 */           currentNode.setFlags(currentNode.getFlags() & 0xFFFFFFFE);
/*  80 */           currentNode = currentNode.getParent();
/*     */         } 
/*  82 */         tagWithErrors = true;
/*     */       } 
/*     */     } 
/*  85 */     return tagWithErrors;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(FieldDeclaration node) {
/*  90 */     return checkAndTagAsMalformed(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(MethodDeclaration node) {
/*  95 */     return checkAndTagAsMalformed(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(ModuleDeclaration node) {
/* 100 */     return checkAndTagAsMalformed(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(PackageDeclaration node) {
/* 105 */     return checkAndTagAsMalformed(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(ImportDeclaration node) {
/* 110 */     return checkAndTagAsMalformed(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(CompilationUnit node) {
/* 115 */     return checkAndTagAsMalformed(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(AnnotationTypeDeclaration node) {
/* 120 */     return checkAndTagAsMalformed(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(EnumDeclaration node) {
/* 125 */     return checkAndTagAsMalformed(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(TypeDeclaration node) {
/* 130 */     return checkAndTagAsMalformed(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(Initializer node) {
/* 135 */     return checkAndTagAsMalformed(node);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ASTSyntaxErrorPropagator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */