/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.StringLiteral;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnStringLiteral
/*    */   extends StringLiteral
/*    */ {
/*    */   public int contentStart;
/*    */   public int contentEnd;
/*    */   
/*    */   public CompletionOnStringLiteral(char[] token, int s, int e, int cs, int ce, int lineNumber) {
/* 43 */     super(token, s, e, lineNumber);
/* 44 */     this.contentStart = cs;
/* 45 */     this.contentEnd = ce;
/*    */   }
/*    */   
/*    */   public CompletionOnStringLiteral(int s, int e, int cs, int ce) {
/* 49 */     super(s, e);
/* 50 */     this.contentStart = cs;
/* 51 */     this.contentEnd = ce;
/*    */   }
/*    */   
/*    */   public TypeBinding resolveType(ClassScope scope) {
/* 55 */     throw new CompletionNodeFound(this, null, scope);
/*    */   }
/*    */   
/*    */   public TypeBinding resolveType(BlockScope scope) {
/* 59 */     throw new CompletionNodeFound(this, null, scope);
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 64 */     output.append("<CompletionOnString:");
/* 65 */     output = super.printExpression(indent, output);
/* 66 */     return output.append('>');
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnStringLiteral.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */