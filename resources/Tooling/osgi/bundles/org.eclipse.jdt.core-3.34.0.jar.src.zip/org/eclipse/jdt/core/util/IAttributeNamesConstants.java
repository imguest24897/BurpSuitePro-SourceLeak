/*     */ package org.eclipse.jdt.core.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IAttributeNamesConstants
/*     */ {
/*  35 */   public static final char[] SYNTHETIC = "Synthetic".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   public static final char[] CONSTANT_VALUE = "ConstantValue".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   public static final char[] LINE_NUMBER = "LineNumberTable".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public static final char[] LOCAL_VARIABLE = "LocalVariableTable".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   public static final char[] INNER_CLASSES = "InnerClasses".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public static final char[] CODE = "Code".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public static final char[] EXCEPTIONS = "Exceptions".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   public static final char[] SOURCE = "SourceFile".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public static final char[] DEPRECATED = "Deprecated".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public static final char[] SIGNATURE = "Signature".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public static final char[] ENCLOSING_METHOD = "EnclosingMethod".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public static final char[] LOCAL_VARIABLE_TYPE_TABLE = "LocalVariableTypeTable".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public static final char[] RUNTIME_VISIBLE_ANNOTATIONS = "RuntimeVisibleAnnotations".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public static final char[] RUNTIME_INVISIBLE_ANNOTATIONS = "RuntimeInvisibleAnnotations".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   public static final char[] RUNTIME_VISIBLE_PARAMETER_ANNOTATIONS = "RuntimeVisibleParameterAnnotations".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   public static final char[] RUNTIME_INVISIBLE_PARAMETER_ANNOTATIONS = "RuntimeInvisibleParameterAnnotations".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public static final char[] ANNOTATION_DEFAULT = "AnnotationDefault".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   public static final char[] STACK_MAP_TABLE = "StackMapTable".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   public static final char[] STACK_MAP = "StackMap".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public static final char[] RUNTIME_VISIBLE_TYPE_ANNOTATIONS = "RuntimeVisibleTypeAnnotations".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public static final char[] RUNTIME_INVISIBLE_TYPE_ANNOTATIONS = "RuntimeInvisibleTypeAnnotations".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 168 */   public static final char[] BOOTSTRAP_METHODS = "BootstrapMethods".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   public static final char[] METHOD_PARAMETERS = "MethodParameters".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 180 */   public static final char[] MODULE = "Module".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 186 */   public static final char[] MODULE_PACKAGES = "ModulePackages".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   public static final char[] MODULE_MAIN_CLASS = "ModuleMainClass".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   public static final char[] NEST_HOST = "NestHost".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 204 */   public static final char[] NEST_MEMBERS = "NestMembers".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 209 */   public static final char[] RECORD = "Record".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 214 */   public static final char[] PERMITTED_SUBCLASSES = "PermittedSubclasses".toCharArray();
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\cor\\util\IAttributeNamesConstants.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */