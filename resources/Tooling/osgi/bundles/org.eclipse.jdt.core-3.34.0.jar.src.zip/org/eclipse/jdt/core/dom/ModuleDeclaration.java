/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModuleDeclaration
/*     */   extends ASTNode
/*     */ {
/*  40 */   public static final ChildPropertyDescriptor JAVADOC_PROPERTY = new ChildPropertyDescriptor(ModuleDeclaration.class, "javadoc", Javadoc.class, false, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final ChildListPropertyDescriptor ANNOTATIONS_PROPERTY = new ChildListPropertyDescriptor(ModuleDeclaration.class, "annotations", Annotation.class, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public static final SimplePropertyDescriptor OPEN_PROPERTY = new SimplePropertyDescriptor(ModuleDeclaration.class, "open", boolean.class, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(ModuleDeclaration.class, "name", Name.class, true, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public static final ChildListPropertyDescriptor MODULE_DIRECTIVES_PROPERTY = new ChildListPropertyDescriptor(ModuleDeclaration.class, "moduleDirectives", ModuleDirective.class, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_9_0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  74 */     List properyList = new ArrayList(6);
/*  75 */     createPropertyList(ModuleDeclaration.class, properyList);
/*  76 */     addProperty(JAVADOC_PROPERTY, properyList);
/*  77 */     addProperty(ANNOTATIONS_PROPERTY, properyList);
/*  78 */     addProperty(OPEN_PROPERTY, properyList);
/*  79 */     addProperty(NAME_PROPERTY, properyList);
/*  80 */     addProperty(MODULE_DIRECTIVES_PROPERTY, properyList);
/*  81 */     PROPERTY_DESCRIPTORS_9_0 = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  95 */     return PROPERTY_DESCRIPTORS_9_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   private Javadoc optionalDocComment = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private ASTNode.NodeList annotations = new ASTNode.NodeList(this, ANNOTATIONS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isOpen = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   private Name name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   private ASTNode.NodeList moduleStatements = new ASTNode.NodeList(this, MODULE_DIRECTIVES_PROPERTY);
/*     */   
/*     */   ModuleDeclaration(AST ast) {
/* 129 */     super(ast);
/* 130 */     unsupportedBelow9();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 135 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final boolean internalGetSetBooleanProperty(SimplePropertyDescriptor property, boolean get, boolean value) {
/* 140 */     if (property == OPEN_PROPERTY) {
/* 141 */       if (get) {
/* 142 */         return isOpen();
/*     */       }
/* 144 */       setOpen(value);
/* 145 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 149 */     return super.internalGetSetBooleanProperty(property, get, value);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 154 */     if (property == JAVADOC_PROPERTY) {
/* 155 */       if (get) {
/* 156 */         return getJavadoc();
/*     */       }
/* 158 */       setJavadoc((Javadoc)child);
/* 159 */       return null;
/*     */     } 
/*     */     
/* 162 */     if (property == NAME_PROPERTY) {
/* 163 */       if (get) {
/* 164 */         return getName();
/*     */       }
/* 166 */       setName((Name)child);
/* 167 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 171 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 176 */     if (property == ANNOTATIONS_PROPERTY) {
/* 177 */       return annotations();
/*     */     }
/* 179 */     if (property == MODULE_DIRECTIVES_PROPERTY) {
/* 180 */       return moduleStatements();
/*     */     }
/*     */     
/* 183 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   int getNodeType0() {
/* 188 */     return 93;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 194 */     ModuleDeclaration result = new ModuleDeclaration(target);
/* 195 */     result.setSourceRange(getStartPosition(), getLength());
/* 196 */     result.setJavadoc((Javadoc)ASTNode.copySubtree(target, getJavadoc()));
/* 197 */     result.setOpen(isOpen());
/* 198 */     result.annotations().addAll(ASTNode.copySubtrees(target, annotations()));
/* 199 */     result.setName((SimpleName)getName().clone(target));
/* 200 */     result.moduleStatements().addAll(ASTNode.copySubtrees(target, moduleStatements()));
/* 201 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 207 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 212 */     boolean visitChildren = visitor.visit(this);
/* 213 */     if (visitChildren) {
/*     */       
/* 215 */       acceptChild(visitor, getJavadoc());
/* 216 */       acceptChildren(visitor, this.annotations);
/* 217 */       acceptChild(visitor, getName());
/* 218 */       acceptChildren(visitor, this.moduleStatements);
/*     */     } 
/* 220 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Javadoc getJavadoc() {
/* 229 */     return this.optionalDocComment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJavadoc(Javadoc docComment) {
/* 239 */     ChildPropertyDescriptor p = JAVADOC_PROPERTY;
/* 240 */     ASTNode oldChild = this.optionalDocComment;
/* 241 */     preReplaceChild(oldChild, docComment, p);
/* 242 */     this.optionalDocComment = docComment;
/* 243 */     postReplaceChild(oldChild, docComment, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List annotations() {
/* 254 */     return this.annotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOpen() {
/* 264 */     return this.isOpen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOpen(boolean isOpen) {
/* 274 */     preValueChange(OPEN_PROPERTY);
/* 275 */     this.isOpen = isOpen;
/* 276 */     postValueChange(OPEN_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getName() {
/* 285 */     if (this.name == null)
/*     */     {
/* 287 */       synchronized (this) {
/* 288 */         if (this.name == null) {
/* 289 */           preLazyInit();
/* 290 */           this.name = this.ast.newQualifiedName(
/* 291 */               new SimpleName(this.ast), new SimpleName(this.ast));
/* 292 */           postLazyInit(this.name, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 296 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(Name name) {
/* 310 */     if (name == null) {
/* 311 */       throw new IllegalArgumentException();
/*     */     }
/* 313 */     ASTNode oldChild = this.name;
/* 314 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 315 */     this.name = name;
/* 316 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List moduleStatements() {
/* 330 */     return this.moduleStatements;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IModuleBinding resolveBinding() {
/* 344 */     return this.ast.getBindingResolver().resolveModule(this);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 349 */     return 60;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 354 */     return memSize() + (
/* 355 */       (this.optionalDocComment == null) ? 0 : getJavadoc().treeSize()) + 
/* 356 */       this.annotations.listSize() + (
/* 357 */       (this.name == null) ? 0 : getName().treeSize()) + 
/* 358 */       this.moduleStatements.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ModuleDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */