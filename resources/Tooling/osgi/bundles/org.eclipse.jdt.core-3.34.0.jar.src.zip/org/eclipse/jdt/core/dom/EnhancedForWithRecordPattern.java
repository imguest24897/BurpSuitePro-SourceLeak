/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnhancedForWithRecordPattern
/*     */   extends Statement
/*     */ {
/*  40 */   public static final ChildPropertyDescriptor PATTERN_PROPERTY = new ChildPropertyDescriptor(EnhancedForWithRecordPattern.class, "pattern", RecordPattern.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(EnhancedForWithRecordPattern.class, "expression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public static final ChildPropertyDescriptor BODY_PROPERTY = new ChildPropertyDescriptor(EnhancedForWithRecordPattern.class, "body", Statement.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  62 */     List properyList = new ArrayList(4);
/*  63 */     createPropertyList(EnhancedForWithRecordPattern.class, properyList);
/*  64 */     addProperty(PATTERN_PROPERTY, properyList);
/*  65 */     addProperty(EXPRESSION_PROPERTY, properyList);
/*  66 */     addProperty(BODY_PROPERTY, properyList);
/*  67 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  81 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private RecordPattern pattern = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private Expression expression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private Statement body = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   EnhancedForWithRecordPattern(AST ast) {
/* 110 */     super(ast);
/* 111 */     supportedOnlyIn20();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 116 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 121 */     if (property == PATTERN_PROPERTY) {
/* 122 */       if (get) {
/* 123 */         return getPattern();
/*     */       }
/* 125 */       setPattern((RecordPattern)child);
/* 126 */       return null;
/*     */     } 
/*     */     
/* 129 */     if (property == EXPRESSION_PROPERTY) {
/* 130 */       if (get) {
/* 131 */         return getExpression();
/*     */       }
/* 133 */       setExpression((Expression)child);
/* 134 */       return null;
/*     */     } 
/*     */     
/* 137 */     if (property == BODY_PROPERTY) {
/* 138 */       if (get) {
/* 139 */         return getBody();
/*     */       }
/* 141 */       setBody((Statement)child);
/* 142 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 146 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 151 */     return 114;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 156 */     EnhancedForWithRecordPattern result = new EnhancedForWithRecordPattern(target);
/* 157 */     result.setSourceRange(getStartPosition(), getLength());
/* 158 */     result.copyLeadingComment(this);
/* 159 */     result.setPattern((RecordPattern)getPattern().clone(target));
/* 160 */     result.setExpression((Expression)getExpression().clone(target));
/* 161 */     result.setBody(
/* 162 */         (Statement)ASTNode.copySubtree(target, getBody()));
/* 163 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 169 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 174 */     boolean visitChildren = visitor.visit(this);
/* 175 */     if (visitChildren) {
/*     */       
/* 177 */       acceptChild(visitor, getPattern());
/* 178 */       acceptChild(visitor, getExpression());
/* 179 */       acceptChild(visitor, getBody());
/*     */     } 
/* 181 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RecordPattern getPattern() {
/* 190 */     if (this.pattern == null)
/*     */     {
/* 192 */       synchronized (this) {
/* 193 */         if (this.pattern == null) {
/* 194 */           preLazyInit();
/* 195 */           this.pattern = this.ast.newRecordPattern();
/* 196 */           postLazyInit(this.pattern, PATTERN_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 200 */     return this.pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPattern(RecordPattern pattern) {
/* 214 */     if (pattern == null) {
/* 215 */       throw new IllegalArgumentException();
/*     */     }
/* 217 */     ASTNode oldChild = this.pattern;
/* 218 */     preReplaceChild(oldChild, pattern, PATTERN_PROPERTY);
/* 219 */     this.pattern = pattern;
/* 220 */     postReplaceChild(oldChild, pattern, PATTERN_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 229 */     if (this.expression == null)
/*     */     {
/* 231 */       synchronized (this) {
/* 232 */         if (this.expression == null) {
/* 233 */           preLazyInit();
/* 234 */           this.expression = new SimpleName(this.ast);
/* 235 */           postLazyInit(this.expression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 239 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 254 */     if (expression == null) {
/* 255 */       throw new IllegalArgumentException();
/*     */     }
/* 257 */     ASTNode oldChild = this.expression;
/* 258 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 259 */     this.expression = expression;
/* 260 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement getBody() {
/* 269 */     if (this.body == null)
/*     */     {
/* 271 */       synchronized (this) {
/* 272 */         if (this.body == null) {
/* 273 */           preLazyInit();
/* 274 */           this.body = new Block(this.ast);
/* 275 */           postLazyInit(this.body, BODY_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 279 */     return this.body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBody(Statement statement) {
/* 294 */     if (statement == null) {
/* 295 */       throw new IllegalArgumentException();
/*     */     }
/* 297 */     ASTNode oldChild = this.body;
/* 298 */     preReplaceChild(oldChild, statement, BODY_PROPERTY);
/* 299 */     this.body = statement;
/* 300 */     postReplaceChild(oldChild, statement, BODY_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 305 */     return super.memSize() + 12;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 310 */     return 
/* 311 */       memSize() + (
/* 312 */       (this.pattern == null) ? 0 : getPattern().treeSize()) + (
/* 313 */       (this.expression == null) ? 0 : getExpression().treeSize()) + (
/* 314 */       (this.body == null) ? 0 : getBody().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\EnhancedForWithRecordPattern.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */