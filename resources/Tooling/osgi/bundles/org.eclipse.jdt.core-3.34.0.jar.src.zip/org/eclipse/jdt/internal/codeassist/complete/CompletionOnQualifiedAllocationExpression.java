/*     */ package org.eclipse.jdt.internal.codeassist.complete;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.ast.AllocationExpression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.QualifiedAllocationExpression;
/*     */ import org.eclipse.jdt.internal.compiler.ast.SingleTypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.ast.TypeReference;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Binding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ParameterizedTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ReferenceBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompletionOnQualifiedAllocationExpression
/*     */   extends QualifiedAllocationExpression
/*     */ {
/*     */   public TypeBinding resolveType(BlockScope scope) {
/*  46 */     this.argumentTypes = Binding.NO_PARAMETERS;
/*  47 */     boolean hasMissingType = false;
/*  48 */     if (this.arguments != null) {
/*  49 */       int argsLength = this.arguments.length;
/*  50 */       int length = this.arguments.length;
/*  51 */       this.argumentTypes = new TypeBinding[length];
/*  52 */       for (int a = argsLength; --a >= 0;) {
/*     */         try {
/*  54 */           this.argumentTypes[a] = this.arguments[a].resolveType(scope);
/*  55 */         } catch (CompletionNodeFound completionNodeFound) {
/*     */           
/*  57 */           hasMissingType = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*  61 */     boolean isDiamond = (this.type != null && (this.type.bits & 0x80000) != 0);
/*  62 */     if (this.enclosingInstance != null) {
/*  63 */       TypeBinding enclosingType = this.enclosingInstance.resolveType(scope);
/*  64 */       if (enclosingType == null)
/*     */       {
/*     */         
/*  67 */         if (this.enclosingInstance instanceof AllocationExpression) {
/*  68 */           TypeReference enclosingInstanceType = ((AllocationExpression)this.enclosingInstance).type;
/*  69 */           if (enclosingInstanceType != null) {
/*  70 */             enclosingType = enclosingInstanceType.resolvedType;
/*     */           }
/*     */         } 
/*     */       }
/*  74 */       if (enclosingType == null || !(enclosingType instanceof ReferenceBinding)) {
/*  75 */         throw new CompletionNodeFound();
/*     */       }
/*  77 */       this.resolvedType = ((SingleTypeReference)this.type).resolveTypeEnclosing(scope, (ReferenceBinding)enclosingType);
/*     */     } else {
/*  79 */       this.resolvedType = this.type.resolveType(scope, true);
/*     */     } 
/*     */     
/*  82 */     if (isDiamond && this.resolvedType instanceof ParameterizedTypeBinding && !hasMissingType) {
/*  83 */       TypeBinding[] inferredTypes = inferElidedTypes((Scope)scope);
/*  84 */       if (inferredTypes != null) {
/*  85 */         this.resolvedType = this.type.resolvedType = (TypeBinding)scope.environment().createParameterizedType(((ParameterizedTypeBinding)this.resolvedType).genericType(), inferredTypes, this.resolvedType.enclosingType());
/*     */       } else {
/*     */         
/*  88 */         this.bits |= 0x80000;
/*     */       } 
/*     */     } 
/*  91 */     if (!(this.resolvedType instanceof ReferenceBinding)) {
/*  92 */       throw new CompletionNodeFound();
/*     */     }
/*  94 */     throw new CompletionNodeFound(this, this.resolvedType, scope);
/*     */   }
/*     */   
/*     */   public StringBuffer printExpression(int indent, StringBuffer output) {
/*  98 */     if (this.enclosingInstance == null) {
/*  99 */       output.append("<CompleteOnAllocationExpression:");
/*     */     } else {
/* 101 */       output.append("<CompleteOnQualifiedAllocationExpression:");
/* 102 */     }  return super.printExpression(indent, output).append('>');
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnQualifiedAllocationExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */