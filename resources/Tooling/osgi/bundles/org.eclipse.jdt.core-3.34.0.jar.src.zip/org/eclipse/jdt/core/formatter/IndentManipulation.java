/*     */ package org.eclipse.jdt.core.formatter;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import org.eclipse.jdt.internal.compiler.parser.ScannerHelper;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.DefaultLineTracker;
/*     */ import org.eclipse.jface.text.IRegion;
/*     */ import org.eclipse.text.edits.ReplaceEdit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IndentManipulation
/*     */ {
/*     */   public static boolean isIndentChar(char ch) {
/*  50 */     return (ScannerHelper.isWhitespace(ch) && !isLineDelimiterChar(ch));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isLineDelimiterChar(char ch) {
/*  60 */     return !(ch != '\n' && ch != '\r');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int measureIndentUnits(CharSequence line, int tabWidth, int indentWidth) {
/*  80 */     if (indentWidth < 0 || tabWidth < 0 || line == null) {
/*  81 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*  84 */     if (indentWidth == 0) return 0; 
/*  85 */     int visualLength = measureIndentInSpaces(line, tabWidth);
/*  86 */     return visualLength / indentWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int measureIndentInSpaces(CharSequence line, int tabWidth) {
/* 106 */     if (tabWidth < 0 || line == null) {
/* 107 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 110 */     int length = 0;
/* 111 */     int max = line.length();
/* 112 */     for (int i = 0; i < max; i++) {
/* 113 */       char ch = line.charAt(i);
/* 114 */       if (ch == '\t') {
/* 115 */         length = calculateSpaceEquivalents(tabWidth, length);
/* 116 */       } else if (isIndentChar(ch)) {
/* 117 */         length++;
/*     */       } else {
/* 119 */         return length;
/*     */       } 
/*     */     } 
/* 122 */     return length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String extractIndentString(String line, int tabWidth, int indentWidth) {
/* 142 */     if (tabWidth < 0 || indentWidth < 0 || line == null) {
/* 143 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 146 */     int size = line.length();
/* 147 */     int end = 0;
/*     */     
/* 149 */     int spaceEquivs = 0;
/* 150 */     int characters = 0;
/* 151 */     for (int i = 0; i < size; i++) {
/* 152 */       char c = line.charAt(i);
/* 153 */       if (c == '\t') {
/* 154 */         spaceEquivs = calculateSpaceEquivalents(tabWidth, spaceEquivs);
/* 155 */         characters++;
/* 156 */       } else if (isIndentChar(c)) {
/* 157 */         spaceEquivs++;
/* 158 */         characters++;
/*     */       } else {
/*     */         break;
/*     */       } 
/* 162 */       if (spaceEquivs >= indentWidth) {
/* 163 */         end += characters;
/* 164 */         characters = 0;
/* 165 */         if (indentWidth == 0) {
/* 166 */           spaceEquivs = 0;
/*     */         } else {
/* 168 */           spaceEquivs %= indentWidth;
/*     */         } 
/*     */       } 
/*     */     } 
/* 172 */     if (end == 0)
/* 173 */       return Util.EMPTY_STRING; 
/* 174 */     if (end == size) {
/* 175 */       return line;
/*     */     }
/* 177 */     return line.substring(0, end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String trimIndent(String line, int indentUnitsToRemove, int tabWidth, int indentWidth) {
/*     */     String trimmed;
/* 199 */     if (tabWidth < 0 || indentWidth < 0 || line == null) {
/* 200 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 203 */     if (indentUnitsToRemove <= 0 || indentWidth == 0) {
/* 204 */       return line;
/*     */     }
/* 206 */     int spaceEquivalentsToRemove = indentUnitsToRemove * indentWidth;
/*     */     
/* 208 */     int start = 0;
/* 209 */     int spaceEquivalents = 0;
/* 210 */     int size = line.length();
/* 211 */     String prefix = null;
/* 212 */     for (int i = 0; i < size; i++) {
/* 213 */       char c = line.charAt(i);
/* 214 */       if (c == '\t') {
/* 215 */         spaceEquivalents = calculateSpaceEquivalents(tabWidth, spaceEquivalents);
/* 216 */       } else if (isIndentChar(c)) {
/* 217 */         spaceEquivalents++;
/*     */       } else {
/*     */         
/* 220 */         start = i;
/*     */         break;
/*     */       } 
/* 223 */       if (spaceEquivalents == spaceEquivalentsToRemove) {
/* 224 */         start = i + 1;
/*     */         break;
/*     */       } 
/* 227 */       if (spaceEquivalents > spaceEquivalentsToRemove) {
/*     */ 
/*     */         
/* 230 */         start = i + 1;
/*     */         
/* 232 */         char[] missing = new char[spaceEquivalents - spaceEquivalentsToRemove];
/* 233 */         Arrays.fill(missing, ' ');
/* 234 */         prefix = new String(missing);
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 239 */     if (start == size) {
/* 240 */       trimmed = Util.EMPTY_STRING;
/*     */     } else {
/* 242 */       trimmed = line.substring(start);
/*     */     } 
/* 244 */     if (prefix == null)
/* 245 */       return trimmed; 
/* 246 */     return String.valueOf(prefix) + trimmed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String changeIndent(String code, int indentUnitsToRemove, int tabWidth, int indentWidth, String newIndentString, String lineDelim) {
/* 273 */     if (tabWidth < 0 || indentWidth < 0 || code == null || indentUnitsToRemove < 0 || newIndentString == null || lineDelim == null) {
/* 274 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*     */     try {
/* 278 */       DefaultLineTracker defaultLineTracker = new DefaultLineTracker();
/* 279 */       defaultLineTracker.set(code);
/* 280 */       int nLines = defaultLineTracker.getNumberOfLines();
/* 281 */       if (nLines == 1) {
/* 282 */         return code;
/*     */       }
/*     */       
/* 285 */       StringBuilder buf = new StringBuilder();
/*     */       
/* 287 */       for (int i = 0; i < nLines; i++) {
/* 288 */         IRegion region = defaultLineTracker.getLineInformation(i);
/* 289 */         int start = region.getOffset();
/* 290 */         int end = start + region.getLength();
/* 291 */         String line = code.substring(start, end);
/*     */         
/* 293 */         if (i == 0) {
/* 294 */           buf.append(line);
/*     */         } else {
/* 296 */           buf.append(lineDelim);
/* 297 */           buf.append(newIndentString);
/* 298 */           if (indentWidth != 0) {
/* 299 */             buf.append(trimIndent(line, indentUnitsToRemove, tabWidth, indentWidth));
/*     */           } else {
/* 301 */             buf.append(line);
/*     */           } 
/*     */         } 
/*     */       } 
/* 305 */       return buf.toString();
/* 306 */     } catch (BadLocationException badLocationException) {
/*     */       
/* 308 */       return code;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReplaceEdit[] getChangeIndentEdits(String source, int indentUnitsToRemove, int tabWidth, int indentWidth, String newIndentString) {
/* 335 */     if (tabWidth < 0 || indentWidth < 0 || source == null || indentUnitsToRemove < 0 || newIndentString == null) {
/* 336 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 339 */     ArrayList<ReplaceEdit> result = new ArrayList();
/*     */     try {
/* 341 */       DefaultLineTracker defaultLineTracker = new DefaultLineTracker();
/* 342 */       defaultLineTracker.set(source);
/* 343 */       int nLines = defaultLineTracker.getNumberOfLines();
/* 344 */       if (nLines == 1)
/* 345 */         return (ReplaceEdit[])result.toArray((Object[])new ReplaceEdit[result.size()]); 
/* 346 */       for (int i = 1; i < nLines; i++) {
/* 347 */         IRegion region = defaultLineTracker.getLineInformation(i);
/* 348 */         int offset = region.getOffset();
/* 349 */         String line = source.substring(offset, offset + region.getLength());
/* 350 */         int length = indexOfIndent(line, indentUnitsToRemove, tabWidth, indentWidth);
/* 351 */         if (length >= 0) {
/* 352 */           result.add(new ReplaceEdit(offset, length, newIndentString));
/*     */         } else {
/* 354 */           length = measureIndentUnits(line, tabWidth, indentWidth);
/* 355 */           result.add(new ReplaceEdit(offset, length, ""));
/*     */         } 
/*     */       } 
/* 358 */     } catch (BadLocationException badLocationException) {}
/*     */ 
/*     */     
/* 361 */     return result.<ReplaceEdit>toArray(new ReplaceEdit[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int indexOfIndent(CharSequence line, int numberOfIndentUnits, int tabWidth, int indentWidth) {
/* 371 */     int spaceEquivalents = numberOfIndentUnits * indentWidth;
/*     */     
/* 373 */     int size = line.length();
/* 374 */     int result = -1;
/* 375 */     int blanks = 0;
/* 376 */     for (int i = 0; i < size && blanks < spaceEquivalents; i++) {
/* 377 */       char c = line.charAt(i);
/* 378 */       if (c == '\t') {
/* 379 */         blanks = calculateSpaceEquivalents(tabWidth, blanks);
/* 380 */       } else if (isIndentChar(c)) {
/* 381 */         blanks++;
/*     */       } else {
/*     */         break;
/*     */       } 
/* 385 */       result = i;
/*     */     } 
/* 387 */     if (blanks < spaceEquivalents)
/* 388 */       return -1; 
/* 389 */     return result + 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int calculateSpaceEquivalents(int tabWidth, int spaceEquivalents) {
/* 396 */     if (tabWidth == 0) {
/* 397 */       return spaceEquivalents;
/*     */     }
/* 399 */     int remainder = spaceEquivalents % tabWidth;
/* 400 */     spaceEquivalents += tabWidth - remainder;
/* 401 */     return spaceEquivalents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getTabWidth(Map options) {
/* 414 */     if (options == null) {
/* 415 */       throw new IllegalArgumentException();
/*     */     }
/* 417 */     return getIntValue(options, "org.eclipse.jdt.core.formatter.tabulation.size", 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getIndentWidth(Map options) {
/* 430 */     if (options == null) {
/* 431 */       throw new IllegalArgumentException();
/*     */     }
/* 433 */     int tabWidth = getTabWidth(options);
/* 434 */     boolean isMixedMode = "mixed".equals(options.get("org.eclipse.jdt.core.formatter.tabulation.char"));
/* 435 */     if (isMixedMode) {
/* 436 */       return getIntValue(options, "org.eclipse.jdt.core.formatter.indentation.size", tabWidth);
/*     */     }
/* 438 */     return tabWidth;
/*     */   }
/*     */   
/*     */   private static int getIntValue(Map options, String key, int def) {
/*     */     try {
/* 443 */       return Integer.parseInt((String)options.get(key));
/* 444 */     } catch (NumberFormatException numberFormatException) {
/* 445 */       return def;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\formatter\IndentManipulation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */