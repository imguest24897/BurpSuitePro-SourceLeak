package org.eclipse.jdt.core;

import org.eclipse.core.resources.IMarker;

public interface ICodeCompletionRequestor {
  void acceptClass(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[] paramArrayOfchar3, int paramInt1, int paramInt2, int paramInt3);
  
  void acceptError(IMarker paramIMarker);
  
  void acceptField(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[] paramArrayOfchar3, char[] paramArrayOfchar4, char[] paramArrayOfchar5, char[] paramArrayOfchar6, int paramInt1, int paramInt2, int paramInt3);
  
  void acceptInterface(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[] paramArrayOfchar3, int paramInt1, int paramInt2, int paramInt3);
  
  void acceptKeyword(char[] paramArrayOfchar, int paramInt1, int paramInt2);
  
  void acceptLabel(char[] paramArrayOfchar, int paramInt1, int paramInt2);
  
  void acceptLocalVariable(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[] paramArrayOfchar3, int paramInt1, int paramInt2, int paramInt3);
  
  void acceptMethod(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[] paramArrayOfchar3, char[][] paramArrayOfchar4, char[][] paramArrayOfchar5, char[] paramArrayOfchar6, char[] paramArrayOfchar7, char[] paramArrayOfchar8, int paramInt1, int paramInt2, int paramInt3);
  
  void acceptModifier(char[] paramArrayOfchar, int paramInt1, int paramInt2);
  
  void acceptPackage(char[] paramArrayOfchar1, char[] paramArrayOfchar2, int paramInt1, int paramInt2);
  
  void acceptType(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[] paramArrayOfchar3, int paramInt1, int paramInt2);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\ICodeCompletionRequestor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */