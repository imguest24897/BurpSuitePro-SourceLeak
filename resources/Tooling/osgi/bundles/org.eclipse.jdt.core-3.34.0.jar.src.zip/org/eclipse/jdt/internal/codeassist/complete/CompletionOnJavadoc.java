package org.eclipse.jdt.internal.codeassist.complete;

public interface CompletionOnJavadoc {
  public static final int JAVADOC = 1;
  
  public static final int EXCEPTION = 2;
  
  public static final int TEXT = 4;
  
  public static final int BASE_TYPES = 8;
  
  public static final int ONLY_INLINE_TAG = 16;
  
  public static final int REPLACE_TAG = 32;
  
  public static final int FORMAL_REFERENCE = 64;
  
  public static final int ALL_POSSIBLE_TAGS = 128;
  
  int getCompletionFlags();
  
  void addCompletionFlags(int paramInt);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnJavadoc.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */