/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.JavadocMessageSend;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnJavadocMessageSend
/*    */   extends JavadocMessageSend
/*    */   implements CompletionOnJavadoc
/*    */ {
/* 19 */   public int completionFlags = 1;
/*    */   public int separatorPosition;
/*    */   
/*    */   public CompletionOnJavadocMessageSend(JavadocMessageSend method, int position) {
/* 23 */     super(method.selector, method.nameSourcePosition);
/* 24 */     this.arguments = method.arguments;
/* 25 */     this.receiver = method.receiver;
/* 26 */     this.sourceEnd = method.sourceEnd;
/* 27 */     this.tagValue = method.tagValue;
/* 28 */     this.separatorPosition = position;
/*    */   }
/*    */   
/*    */   public CompletionOnJavadocMessageSend(JavadocMessageSend method, int position, int flags) {
/* 32 */     this(method, position);
/* 33 */     this.completionFlags |= flags;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addCompletionFlags(int flags) {
/* 38 */     this.completionFlags |= flags;
/*    */   }
/*    */   
/*    */   public boolean completeAnException() {
/* 42 */     return ((this.completionFlags & 0x2) != 0);
/*    */   }
/*    */   
/*    */   public boolean completeInText() {
/* 46 */     return ((this.completionFlags & 0x4) != 0);
/*    */   }
/*    */   
/*    */   public boolean completeBaseTypes() {
/* 50 */     return ((this.completionFlags & 0x8) != 0);
/*    */   }
/*    */   
/*    */   public boolean completeFormalReference() {
/* 54 */     return ((this.completionFlags & 0x40) != 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getCompletionFlags() {
/* 59 */     return this.completionFlags;
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 64 */     output.append("<CompleteOnJavadocMessageSend:");
/* 65 */     super.printExpression(indent, output);
/* 66 */     indent++;
/* 67 */     if (this.completionFlags > 0) {
/* 68 */       output.append('\n');
/* 69 */       for (int j = 0; j < indent; ) { output.append('\t'); j++; }
/* 70 */        output.append("infos:");
/* 71 */       char separator = Character.MIN_VALUE;
/* 72 */       if (completeAnException()) {
/* 73 */         output.append("exception");
/* 74 */         separator = ',';
/*    */       } 
/* 76 */       if (completeInText()) {
/* 77 */         if (separator != '\000') output.append(separator); 
/* 78 */         output.append("text");
/* 79 */         separator = ',';
/*    */       } 
/* 81 */       if (completeBaseTypes()) {
/* 82 */         if (separator != '\000') output.append(separator); 
/* 83 */         output.append("base types");
/* 84 */         separator = ',';
/*    */       } 
/* 86 */       if (completeFormalReference()) {
/* 87 */         if (separator != '\000') output.append(separator); 
/* 88 */         output.append("formal reference");
/* 89 */         separator = ',';
/*    */       } 
/* 91 */       output.append('\n');
/*    */     } 
/* 93 */     indent--;
/* 94 */     for (int i = 0; i < indent; ) { output.append('\t'); i++; }
/* 95 */      return output.append('>');
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnJavadocMessageSend.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */