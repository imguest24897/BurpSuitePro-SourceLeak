package org.eclipse.jdt.core;

import org.eclipse.core.runtime.IPath;

public interface IAccessRule {
  public static final int K_ACCESSIBLE = 0;
  
  public static final int K_NON_ACCESSIBLE = 1;
  
  public static final int K_DISCOURAGED = 2;
  
  public static final int IGNORE_IF_BETTER = 256;
  
  IPath getPattern();
  
  int getKind();
  
  boolean ignoreIfBetter();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IAccessRule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */