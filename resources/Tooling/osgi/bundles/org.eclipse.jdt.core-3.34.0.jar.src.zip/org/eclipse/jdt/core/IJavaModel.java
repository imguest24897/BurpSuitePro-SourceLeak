package org.eclipse.jdt.core;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IJavaModel extends IJavaElement, IOpenable, IParent {
  boolean contains(IResource paramIResource);
  
  void copy(IJavaElement[] paramArrayOfIJavaElement1, IJavaElement[] paramArrayOfIJavaElement2, IJavaElement[] paramArrayOfIJavaElement3, String[] paramArrayOfString, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void delete(IJavaElement[] paramArrayOfIJavaElement, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  IJavaProject getJavaProject(String paramString);
  
  IJavaProject[] getJavaProjects() throws JavaModelException;
  
  Object[] getNonJavaResources() throws JavaModelException;
  
  IWorkspace getWorkspace();
  
  void move(IJavaElement[] paramArrayOfIJavaElement1, IJavaElement[] paramArrayOfIJavaElement2, IJavaElement[] paramArrayOfIJavaElement3, String[] paramArrayOfString, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void refreshExternalArchives(IJavaElement[] paramArrayOfIJavaElement, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
  
  void rename(IJavaElement[] paramArrayOfIJavaElement1, IJavaElement[] paramArrayOfIJavaElement2, String[] paramArrayOfString, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws JavaModelException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IJavaModel.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */