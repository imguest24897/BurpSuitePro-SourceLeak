/*      */ package org.eclipse.jdt.core.dom;
/*      */ 
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import org.eclipse.jdt.internal.core.dom.util.DOMASTUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ASTMatcher
/*      */ {
/*      */   private boolean matchDocTags;
/*      */   
/*      */   public ASTMatcher() {
/*   70 */     this(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ASTMatcher(boolean matchDocTags) {
/*   82 */     this.matchDocTags = matchDocTags;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean safeSubtreeListMatch(List list1, List list2) {
/*  102 */     int size1 = list1.size();
/*  103 */     int size2 = list2.size();
/*  104 */     if (size1 != size2) {
/*  105 */       return false;
/*      */     }
/*  107 */     for (Iterator<ASTNode> it1 = list1.iterator(), it2 = list2.iterator(); it1.hasNext(); ) {
/*  108 */       ASTNode n1 = it1.next();
/*  109 */       ASTNode n2 = it2.next();
/*  110 */       if (!n1.subtreeMatch(this, n2)) {
/*  111 */         return false;
/*      */       }
/*      */     } 
/*  114 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean safeSubtreeMatch(Object node1, Object node2) {
/*  137 */     if (node1 == null && node2 == null) {
/*  138 */       return true;
/*      */     }
/*  140 */     if (node1 == null || node2 == null) {
/*  141 */       return false;
/*      */     }
/*      */     
/*  144 */     return ((ASTNode)node1).subtreeMatch(this, node2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean safeEquals(Object o1, Object o2) {
/*  159 */     if (o1 == o2) {
/*  160 */       return true;
/*      */     }
/*  162 */     if (o1 == null || o2 == null) {
/*  163 */       return false;
/*      */     }
/*  165 */     return o1.equals(o2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Type componentType(ArrayType array) {
/*  172 */     return array.getComponentType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(AnnotationTypeDeclaration node, Object other) {
/*  191 */     if (!(other instanceof AnnotationTypeDeclaration)) {
/*  192 */       return false;
/*      */     }
/*  194 */     AnnotationTypeDeclaration o = (AnnotationTypeDeclaration)other;
/*      */     
/*  196 */     return (safeSubtreeMatch(node.getJavadoc(), o.getJavadoc()) && 
/*  197 */       safeSubtreeListMatch(node.modifiers(), o.modifiers()) && 
/*  198 */       safeSubtreeMatch(node.getName(), o.getName()) && 
/*  199 */       safeSubtreeListMatch(node.bodyDeclarations(), o.bodyDeclarations()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(AnnotationTypeMemberDeclaration node, Object other) {
/*  218 */     if (!(other instanceof AnnotationTypeMemberDeclaration)) {
/*  219 */       return false;
/*      */     }
/*  221 */     AnnotationTypeMemberDeclaration o = (AnnotationTypeMemberDeclaration)other;
/*      */     
/*  223 */     return (safeSubtreeMatch(node.getJavadoc(), o.getJavadoc()) && 
/*  224 */       safeSubtreeListMatch(node.modifiers(), o.modifiers()) && 
/*  225 */       safeSubtreeMatch(node.getType(), o.getType()) && 
/*  226 */       safeSubtreeMatch(node.getName(), o.getName()) && 
/*  227 */       safeSubtreeMatch(node.getDefault(), o.getDefault()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(AnonymousClassDeclaration node, Object other) {
/*  245 */     if (!(other instanceof AnonymousClassDeclaration)) {
/*  246 */       return false;
/*      */     }
/*  248 */     AnonymousClassDeclaration o = (AnonymousClassDeclaration)other;
/*  249 */     return safeSubtreeListMatch(node.bodyDeclarations(), o.bodyDeclarations());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ArrayAccess node, Object other) {
/*  267 */     if (!(other instanceof ArrayAccess)) {
/*  268 */       return false;
/*      */     }
/*  270 */     ArrayAccess o = (ArrayAccess)other;
/*  271 */     return 
/*  272 */       (safeSubtreeMatch(node.getArray(), o.getArray()) && 
/*  273 */       safeSubtreeMatch(node.getIndex(), o.getIndex()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ArrayCreation node, Object other) {
/*  291 */     if (!(other instanceof ArrayCreation)) {
/*  292 */       return false;
/*      */     }
/*  294 */     ArrayCreation o = (ArrayCreation)other;
/*  295 */     return 
/*  296 */       (safeSubtreeMatch(node.getType(), o.getType()) && 
/*  297 */       safeSubtreeListMatch(node.dimensions(), o.dimensions()) && 
/*  298 */       safeSubtreeMatch(node.getInitializer(), o.getInitializer()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ArrayInitializer node, Object other) {
/*  316 */     if (!(other instanceof ArrayInitializer)) {
/*  317 */       return false;
/*      */     }
/*  319 */     ArrayInitializer o = (ArrayInitializer)other;
/*  320 */     return safeSubtreeListMatch(node.expressions(), o.expressions());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ArrayType node, Object other) {
/*  338 */     if (!(other instanceof ArrayType)) {
/*  339 */       return false;
/*      */     }
/*  341 */     ArrayType o = (ArrayType)other;
/*  342 */     int level = (node.getAST()).apiLevel;
/*  343 */     if (level < 8) {
/*  344 */       return safeSubtreeMatch(componentType(node), componentType(o));
/*      */     }
/*  346 */     return (safeSubtreeMatch(node.getElementType(), o.getElementType()) && 
/*  347 */       safeSubtreeListMatch(node.dimensions(), o.dimensions()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(AssertStatement node, Object other) {
/*  365 */     if (!(other instanceof AssertStatement)) {
/*  366 */       return false;
/*      */     }
/*  368 */     AssertStatement o = (AssertStatement)other;
/*  369 */     return 
/*  370 */       (safeSubtreeMatch(node.getExpression(), o.getExpression()) && 
/*  371 */       safeSubtreeMatch(node.getMessage(), o.getMessage()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(Assignment node, Object other) {
/*  389 */     if (!(other instanceof Assignment)) {
/*  390 */       return false;
/*      */     }
/*  392 */     Assignment o = (Assignment)other;
/*  393 */     return 
/*  394 */       (node.getOperator().equals(o.getOperator()) && 
/*  395 */       safeSubtreeMatch(node.getLeftHandSide(), o.getLeftHandSide()) && 
/*  396 */       safeSubtreeMatch(node.getRightHandSide(), o.getRightHandSide()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(Block node, Object other) {
/*  414 */     if (!(other instanceof Block)) {
/*  415 */       return false;
/*      */     }
/*  417 */     Block o = (Block)other;
/*  418 */     return safeSubtreeListMatch(node.statements(), o.statements());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(BlockComment node, Object other) {
/*  442 */     if (!(other instanceof BlockComment)) {
/*  443 */       return false;
/*      */     }
/*  445 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(BooleanLiteral node, Object other) {
/*  463 */     if (!(other instanceof BooleanLiteral)) {
/*  464 */       return false;
/*      */     }
/*  466 */     BooleanLiteral o = (BooleanLiteral)other;
/*  467 */     return (node.booleanValue() == o.booleanValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(BreakStatement node, Object other) {
/*  485 */     if (!(other instanceof BreakStatement)) {
/*  486 */       return false;
/*      */     }
/*  488 */     BreakStatement o = (BreakStatement)other;
/*  489 */     return safeSubtreeMatch(node.getLabel(), o.getLabel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(CaseDefaultExpression node, Object other) {
/*  508 */     if (!(other instanceof CaseDefaultExpression)) {
/*  509 */       return false;
/*      */     }
/*  511 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(CastExpression node, Object other) {
/*  529 */     if (!(other instanceof CastExpression)) {
/*  530 */       return false;
/*      */     }
/*  532 */     CastExpression o = (CastExpression)other;
/*  533 */     return 
/*  534 */       (safeSubtreeMatch(node.getType(), o.getType()) && 
/*  535 */       safeSubtreeMatch(node.getExpression(), o.getExpression()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(CatchClause node, Object other) {
/*  553 */     if (!(other instanceof CatchClause)) {
/*  554 */       return false;
/*      */     }
/*  556 */     CatchClause o = (CatchClause)other;
/*  557 */     return 
/*  558 */       (safeSubtreeMatch(node.getException(), o.getException()) && 
/*  559 */       safeSubtreeMatch(node.getBody(), o.getBody()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(CharacterLiteral node, Object other) {
/*  577 */     if (!(other instanceof CharacterLiteral)) {
/*  578 */       return false;
/*      */     }
/*  580 */     CharacterLiteral o = (CharacterLiteral)other;
/*  581 */     return safeEquals(node.getEscapedValue(), o.getEscapedValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ClassInstanceCreation node, Object other) {
/*  599 */     if (!(other instanceof ClassInstanceCreation)) {
/*  600 */       return false;
/*      */     }
/*  602 */     ClassInstanceCreation o = (ClassInstanceCreation)other;
/*  603 */     int level = (node.getAST()).apiLevel;
/*  604 */     if (level == 2 && 
/*  605 */       !safeSubtreeMatch(node.internalGetName(), o.internalGetName())) {
/*  606 */       return false;
/*      */     }
/*      */     
/*  609 */     if (level >= 3) {
/*  610 */       if (!safeSubtreeListMatch(node.typeArguments(), o.typeArguments())) {
/*  611 */         return false;
/*      */       }
/*  613 */       if (!safeSubtreeMatch(node.getType(), o.getType())) {
/*  614 */         return false;
/*      */       }
/*      */     } 
/*  617 */     return 
/*  618 */       (safeSubtreeMatch(node.getExpression(), o.getExpression()) && 
/*  619 */       safeSubtreeListMatch(node.arguments(), o.arguments()) && 
/*  620 */       safeSubtreeMatch(
/*  621 */         node.getAnonymousClassDeclaration(), 
/*  622 */         o.getAnonymousClassDeclaration()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(CompilationUnit node, Object other) {
/*  640 */     if (!(other instanceof CompilationUnit)) {
/*  641 */       return false;
/*      */     }
/*  643 */     CompilationUnit o = (CompilationUnit)other;
/*  644 */     return 
/*  645 */       (((node.getAST()).apiLevel < 9 || safeSubtreeMatch(node.getModule(), o.getModule())) && 
/*  646 */       safeSubtreeMatch(node.getPackage(), o.getPackage()) && 
/*  647 */       safeSubtreeListMatch(node.imports(), o.imports()) && 
/*  648 */       safeSubtreeListMatch(node.types(), o.types()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ConditionalExpression node, Object other) {
/*  666 */     if (!(other instanceof ConditionalExpression)) {
/*  667 */       return false;
/*      */     }
/*  669 */     ConditionalExpression o = (ConditionalExpression)other;
/*  670 */     return 
/*  671 */       (safeSubtreeMatch(node.getExpression(), o.getExpression()) && 
/*  672 */       safeSubtreeMatch(node.getThenExpression(), o.getThenExpression()) && 
/*  673 */       safeSubtreeMatch(node.getElseExpression(), o.getElseExpression()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ConstructorInvocation node, Object other) {
/*  691 */     if (!(other instanceof ConstructorInvocation)) {
/*  692 */       return false;
/*      */     }
/*  694 */     ConstructorInvocation o = (ConstructorInvocation)other;
/*  695 */     if ((node.getAST()).apiLevel >= 3 && 
/*  696 */       !safeSubtreeListMatch(node.typeArguments(), o.typeArguments())) {
/*  697 */       return false;
/*      */     }
/*      */     
/*  700 */     return safeSubtreeListMatch(node.arguments(), o.arguments());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ContinueStatement node, Object other) {
/*  718 */     if (!(other instanceof ContinueStatement)) {
/*  719 */       return false;
/*      */     }
/*  721 */     ContinueStatement o = (ContinueStatement)other;
/*  722 */     return safeSubtreeMatch(node.getLabel(), o.getLabel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(CreationReference node, Object other) {
/*  741 */     if (!(other instanceof CreationReference)) {
/*  742 */       return false;
/*      */     }
/*  744 */     CreationReference o = (CreationReference)other;
/*  745 */     return 
/*  746 */       (safeSubtreeMatch(node.getType(), o.getType()) && 
/*  747 */       safeSubtreeListMatch(node.typeArguments(), o.typeArguments()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(Dimension node, Object other) {
/*  766 */     if (!(other instanceof Dimension)) {
/*  767 */       return false;
/*      */     }
/*  769 */     Dimension o = (Dimension)other;
/*  770 */     return safeSubtreeListMatch(node.annotations(), o.annotations());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(DoStatement node, Object other) {
/*  788 */     if (!(other instanceof DoStatement)) {
/*  789 */       return false;
/*      */     }
/*  791 */     DoStatement o = (DoStatement)other;
/*  792 */     return 
/*  793 */       (safeSubtreeMatch(node.getExpression(), o.getExpression()) && 
/*  794 */       safeSubtreeMatch(node.getBody(), o.getBody()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(EmptyStatement node, Object other) {
/*  812 */     if (!(other instanceof EmptyStatement)) {
/*  813 */       return false;
/*      */     }
/*  815 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(EnhancedForStatement node, Object other) {
/*  834 */     if (!(other instanceof EnhancedForStatement)) {
/*  835 */       return false;
/*      */     }
/*  837 */     EnhancedForStatement o = (EnhancedForStatement)other;
/*  838 */     return 
/*  839 */       (safeSubtreeMatch(node.getParameter(), o.getParameter()) && 
/*  840 */       safeSubtreeMatch(node.getExpression(), o.getExpression()) && 
/*  841 */       safeSubtreeMatch(node.getBody(), o.getBody()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(EnhancedForWithRecordPattern node, Object other) {
/*  861 */     if (!(other instanceof EnhancedForWithRecordPattern)) {
/*  862 */       return false;
/*      */     }
/*  864 */     EnhancedForWithRecordPattern o = (EnhancedForWithRecordPattern)other;
/*  865 */     return 
/*  866 */       (safeSubtreeMatch(node.getPattern(), o.getPattern()) && 
/*  867 */       safeSubtreeMatch(node.getExpression(), o.getExpression()) && 
/*  868 */       safeSubtreeMatch(node.getBody(), o.getBody()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(EnumConstantDeclaration node, Object other) {
/*  887 */     if (!(other instanceof EnumConstantDeclaration)) {
/*  888 */       return false;
/*      */     }
/*  890 */     EnumConstantDeclaration o = (EnumConstantDeclaration)other;
/*  891 */     return 
/*  892 */       (safeSubtreeMatch(node.getJavadoc(), o.getJavadoc()) && 
/*  893 */       safeSubtreeListMatch(node.modifiers(), o.modifiers()) && 
/*  894 */       safeSubtreeMatch(node.getName(), o.getName()) && 
/*  895 */       safeSubtreeListMatch(node.arguments(), o.arguments()) && 
/*  896 */       safeSubtreeMatch(
/*  897 */         node.getAnonymousClassDeclaration(), 
/*  898 */         o.getAnonymousClassDeclaration()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(EnumDeclaration node, Object other) {
/*  917 */     if (!(other instanceof EnumDeclaration)) {
/*  918 */       return false;
/*      */     }
/*  920 */     EnumDeclaration o = (EnumDeclaration)other;
/*  921 */     return 
/*  922 */       (safeSubtreeMatch(node.getJavadoc(), o.getJavadoc()) && 
/*  923 */       safeSubtreeListMatch(node.modifiers(), o.modifiers()) && 
/*  924 */       safeSubtreeMatch(node.getName(), o.getName()) && 
/*  925 */       safeSubtreeListMatch(node.superInterfaceTypes(), o.superInterfaceTypes()) && 
/*  926 */       safeSubtreeListMatch(node.enumConstants(), o.enumConstants()) && 
/*  927 */       safeSubtreeListMatch(
/*  928 */         node.bodyDeclarations(), 
/*  929 */         o.bodyDeclarations()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ExportsDirective node, Object other) {
/*  948 */     if (!(other instanceof ExportsDirective)) {
/*  949 */       return false;
/*      */     }
/*  951 */     ExportsDirective o = (ExportsDirective)other;
/*  952 */     return 
/*  953 */       (safeSubtreeMatch(node.getName(), o.getName()) && 
/*  954 */       safeSubtreeListMatch(node.modules(), o.modules()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ExpressionMethodReference node, Object other) {
/*  973 */     if (!(other instanceof ExpressionMethodReference)) {
/*  974 */       return false;
/*      */     }
/*  976 */     ExpressionMethodReference o = (ExpressionMethodReference)other;
/*  977 */     return 
/*  978 */       (safeSubtreeMatch(node.getExpression(), o.getExpression()) && 
/*  979 */       safeSubtreeListMatch(node.typeArguments(), o.typeArguments()) && 
/*  980 */       safeSubtreeMatch(node.getName(), o.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ExpressionStatement node, Object other) {
/*  998 */     if (!(other instanceof ExpressionStatement)) {
/*  999 */       return false;
/*      */     }
/* 1001 */     ExpressionStatement o = (ExpressionStatement)other;
/* 1002 */     return safeSubtreeMatch(node.getExpression(), o.getExpression());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(FieldAccess node, Object other) {
/* 1020 */     if (!(other instanceof FieldAccess)) {
/* 1021 */       return false;
/*      */     }
/* 1023 */     FieldAccess o = (FieldAccess)other;
/* 1024 */     return 
/* 1025 */       (safeSubtreeMatch(node.getExpression(), o.getExpression()) && 
/* 1026 */       safeSubtreeMatch(node.getName(), o.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(FieldDeclaration node, Object other) {
/* 1044 */     if (!(other instanceof FieldDeclaration)) {
/* 1045 */       return false;
/*      */     }
/* 1047 */     FieldDeclaration o = (FieldDeclaration)other;
/* 1048 */     int level = (node.getAST()).apiLevel;
/* 1049 */     if (level == 2 && 
/* 1050 */       node.getModifiers() != o.getModifiers()) {
/* 1051 */       return false;
/*      */     }
/*      */     
/* 1054 */     if (level >= 3 && 
/* 1055 */       !safeSubtreeListMatch(node.modifiers(), o.modifiers())) {
/* 1056 */       return false;
/*      */     }
/*      */     
/* 1059 */     return 
/* 1060 */       (safeSubtreeMatch(node.getJavadoc(), o.getJavadoc()) && 
/* 1061 */       safeSubtreeMatch(node.getType(), o.getType()) && 
/* 1062 */       safeSubtreeListMatch(node.fragments(), o.fragments()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ForStatement node, Object other) {
/* 1080 */     if (!(other instanceof ForStatement)) {
/* 1081 */       return false;
/*      */     }
/* 1083 */     ForStatement o = (ForStatement)other;
/* 1084 */     return 
/* 1085 */       (safeSubtreeListMatch(node.initializers(), o.initializers()) && 
/* 1086 */       safeSubtreeMatch(node.getExpression(), o.getExpression()) && 
/* 1087 */       safeSubtreeListMatch(node.updaters(), o.updaters()) && 
/* 1088 */       safeSubtreeMatch(node.getBody(), o.getBody()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(GuardedPattern node, Object other) {
/* 1107 */     if (!(other instanceof GuardedPattern)) {
/* 1108 */       return false;
/*      */     }
/* 1110 */     GuardedPattern o = (GuardedPattern)other;
/* 1111 */     return (safeSubtreeMatch(node.getPattern(), o.getPattern()) && 
/* 1112 */       safeSubtreeMatch(node.getExpression(), o.getExpression()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(IfStatement node, Object other) {
/* 1130 */     if (!(other instanceof IfStatement)) {
/* 1131 */       return false;
/*      */     }
/* 1133 */     IfStatement o = (IfStatement)other;
/* 1134 */     return 
/* 1135 */       (safeSubtreeMatch(node.getExpression(), o.getExpression()) && 
/* 1136 */       safeSubtreeMatch(node.getThenStatement(), o.getThenStatement()) && 
/* 1137 */       safeSubtreeMatch(node.getElseStatement(), o.getElseStatement()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ImportDeclaration node, Object other) {
/* 1155 */     if (!(other instanceof ImportDeclaration)) {
/* 1156 */       return false;
/*      */     }
/* 1158 */     ImportDeclaration o = (ImportDeclaration)other;
/* 1159 */     if ((node.getAST()).apiLevel >= 3 && 
/* 1160 */       node.isStatic() != o.isStatic()) {
/* 1161 */       return false;
/*      */     }
/*      */     
/* 1164 */     return 
/* 1165 */       (safeSubtreeMatch(node.getName(), o.getName()) && 
/* 1166 */       node.isOnDemand() == o.isOnDemand());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(InfixExpression node, Object other) {
/* 1184 */     if (!(other instanceof InfixExpression)) {
/* 1185 */       return false;
/*      */     }
/* 1187 */     InfixExpression o = (InfixExpression)other;
/*      */     
/* 1189 */     if (node.hasExtendedOperands() && o.hasExtendedOperands() && 
/* 1190 */       !safeSubtreeListMatch(node.extendedOperands(), o.extendedOperands())) {
/* 1191 */       return false;
/*      */     }
/*      */     
/* 1194 */     if (node.hasExtendedOperands() != o.hasExtendedOperands()) {
/* 1195 */       return false;
/*      */     }
/* 1197 */     return 
/* 1198 */       (node.getOperator().equals(o.getOperator()) && 
/* 1199 */       safeSubtreeMatch(node.getLeftOperand(), o.getLeftOperand()) && 
/* 1200 */       safeSubtreeMatch(node.getRightOperand(), o.getRightOperand()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(Initializer node, Object other) {
/* 1218 */     if (!(other instanceof Initializer)) {
/* 1219 */       return false;
/*      */     }
/* 1221 */     Initializer o = (Initializer)other;
/* 1222 */     int level = (node.getAST()).apiLevel;
/* 1223 */     if (level == 2 && 
/* 1224 */       node.getModifiers() != o.getModifiers()) {
/* 1225 */       return false;
/*      */     }
/*      */     
/* 1228 */     if (level >= 3 && 
/* 1229 */       !safeSubtreeListMatch(node.modifiers(), o.modifiers())) {
/* 1230 */       return false;
/*      */     }
/*      */     
/* 1233 */     return 
/* 1234 */       (safeSubtreeMatch(node.getJavadoc(), o.getJavadoc()) && 
/* 1235 */       safeSubtreeMatch(node.getBody(), o.getBody()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(InstanceofExpression node, Object other) {
/* 1253 */     if (!(other instanceof InstanceofExpression)) {
/* 1254 */       return false;
/*      */     }
/* 1256 */     InstanceofExpression o = (InstanceofExpression)other;
/* 1257 */     return 
/* 1258 */       (safeSubtreeMatch(node.getLeftOperand(), o.getLeftOperand()) && 
/* 1259 */       safeSubtreeMatch(node.getRightOperand(), o.getRightOperand()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(IntersectionType node, Object other) {
/* 1278 */     if (!(other instanceof IntersectionType)) {
/* 1279 */       return false;
/*      */     }
/* 1281 */     IntersectionType o = (IntersectionType)other;
/* 1282 */     return safeSubtreeListMatch(node.types(), o.types());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(Javadoc node, Object other) {
/* 1312 */     if (!(other instanceof Javadoc)) {
/* 1313 */       return false;
/*      */     }
/* 1315 */     Javadoc o = (Javadoc)other;
/* 1316 */     if (this.matchDocTags) {
/* 1317 */       return safeSubtreeListMatch(node.tags(), o.tags());
/*      */     }
/* 1319 */     return compareDeprecatedComment(node, o);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(JavaDocRegion node, Object other) {
/* 1341 */     if (!(other instanceof JavaDocRegion)) {
/* 1342 */       return false;
/*      */     }
/* 1344 */     JavaDocRegion o = (JavaDocRegion)other;
/* 1345 */     return (safeEquals(node.getTagName(), o.getTagName()) && safeSubtreeListMatch(node.tags(), o.tags()) && safeSubtreeListMatch(node.fragments(), o.fragments()) && 
/* 1346 */       safeEquals(Boolean.valueOf(node.isDummyRegion()), Boolean.valueOf((o.isDummyRegion() && safeEquals(Boolean.valueOf(node.isValidSnippet()), Boolean.valueOf(o.isValidSnippet()))))));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(JavaDocTextElement node, Object other) {
/* 1365 */     if (!(other instanceof JavaDocTextElement)) {
/* 1366 */       return false;
/*      */     }
/* 1368 */     JavaDocTextElement o = (JavaDocTextElement)other;
/* 1369 */     return safeEquals(node.getText(), o.getText());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean compareDeprecatedComment(Javadoc first, Javadoc second) {
/* 1379 */     if ((first.getAST()).apiLevel == 2) {
/* 1380 */       return safeEquals(first.getComment(), second.getComment());
/*      */     }
/* 1382 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(LabeledStatement node, Object other) {
/* 1401 */     if (!(other instanceof LabeledStatement)) {
/* 1402 */       return false;
/*      */     }
/* 1404 */     LabeledStatement o = (LabeledStatement)other;
/* 1405 */     return 
/* 1406 */       (safeSubtreeMatch(node.getLabel(), o.getLabel()) && 
/* 1407 */       safeSubtreeMatch(node.getBody(), o.getBody()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(LambdaExpression node, Object other) {
/* 1426 */     if (!(other instanceof LambdaExpression)) {
/* 1427 */       return false;
/*      */     }
/* 1429 */     LambdaExpression o = (LambdaExpression)other;
/* 1430 */     return (node.hasParentheses() == o.hasParentheses() && 
/* 1431 */       safeSubtreeListMatch(node.parameters(), o.parameters()) && 
/* 1432 */       safeSubtreeMatch(node.getBody(), o.getBody()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(LineComment node, Object other) {
/* 1456 */     if (!(other instanceof LineComment)) {
/* 1457 */       return false;
/*      */     }
/* 1459 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(MarkerAnnotation node, Object other) {
/* 1478 */     if (!(other instanceof MarkerAnnotation)) {
/* 1479 */       return false;
/*      */     }
/* 1481 */     MarkerAnnotation o = (MarkerAnnotation)other;
/* 1482 */     return safeSubtreeMatch(node.getTypeName(), o.getTypeName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(MemberRef node, Object other) {
/* 1501 */     if (!(other instanceof MemberRef)) {
/* 1502 */       return false;
/*      */     }
/* 1504 */     MemberRef o = (MemberRef)other;
/* 1505 */     return 
/* 1506 */       (safeSubtreeMatch(node.getQualifier(), o.getQualifier()) && 
/* 1507 */       safeSubtreeMatch(node.getName(), o.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(MemberValuePair node, Object other) {
/* 1526 */     if (!(other instanceof MemberValuePair)) {
/* 1527 */       return false;
/*      */     }
/* 1529 */     MemberValuePair o = (MemberValuePair)other;
/* 1530 */     return (safeSubtreeMatch(node.getName(), o.getName()) && 
/* 1531 */       safeSubtreeMatch(node.getValue(), o.getValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(MethodRef node, Object other) {
/* 1550 */     if (!(other instanceof MethodRef)) {
/* 1551 */       return false;
/*      */     }
/* 1553 */     MethodRef o = (MethodRef)other;
/* 1554 */     return 
/* 1555 */       (safeSubtreeMatch(node.getQualifier(), o.getQualifier()) && 
/* 1556 */       safeSubtreeMatch(node.getName(), o.getName()) && 
/* 1557 */       safeSubtreeListMatch(node.parameters(), o.parameters()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(MethodRefParameter node, Object other) {
/* 1576 */     if (!(other instanceof MethodRefParameter)) {
/* 1577 */       return false;
/*      */     }
/* 1579 */     MethodRefParameter o = (MethodRefParameter)other;
/* 1580 */     int level = (node.getAST()).apiLevel;
/* 1581 */     if (level >= 3 && 
/* 1582 */       node.isVarargs() != o.isVarargs()) {
/* 1583 */       return false;
/*      */     }
/*      */     
/* 1586 */     return 
/* 1587 */       (safeSubtreeMatch(node.getType(), o.getType()) && 
/* 1588 */       safeSubtreeMatch(node.getName(), o.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(MethodDeclaration node, Object other) {
/*      */     // Byte code:
/*      */     //   0: aload_2
/*      */     //   1: instanceof org/eclipse/jdt/core/dom/MethodDeclaration
/*      */     //   4: ifne -> 9
/*      */     //   7: iconst_0
/*      */     //   8: ireturn
/*      */     //   9: aload_2
/*      */     //   10: checkcast org/eclipse/jdt/core/dom/MethodDeclaration
/*      */     //   13: astore_3
/*      */     //   14: aload_1
/*      */     //   15: invokevirtual getAST : ()Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   18: getfield apiLevel : I
/*      */     //   21: istore #4
/*      */     //   23: aload_1
/*      */     //   24: invokevirtual isConstructor : ()Z
/*      */     //   27: aload_3
/*      */     //   28: invokevirtual isConstructor : ()Z
/*      */     //   31: if_icmpne -> 300
/*      */     //   34: aload_0
/*      */     //   35: aload_1
/*      */     //   36: invokevirtual getJavadoc : ()Lorg/eclipse/jdt/core/dom/Javadoc;
/*      */     //   39: aload_3
/*      */     //   40: invokevirtual getJavadoc : ()Lorg/eclipse/jdt/core/dom/Javadoc;
/*      */     //   43: invokevirtual safeSubtreeMatch : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*      */     //   46: ifeq -> 300
/*      */     //   49: iload #4
/*      */     //   51: iconst_3
/*      */     //   52: if_icmplt -> 103
/*      */     //   55: aload_0
/*      */     //   56: aload_1
/*      */     //   57: invokevirtual modifiers : ()Ljava/util/List;
/*      */     //   60: aload_3
/*      */     //   61: invokevirtual modifiers : ()Ljava/util/List;
/*      */     //   64: invokevirtual safeSubtreeListMatch : (Ljava/util/List;Ljava/util/List;)Z
/*      */     //   67: ifeq -> 300
/*      */     //   70: aload_0
/*      */     //   71: aload_1
/*      */     //   72: invokevirtual typeParameters : ()Ljava/util/List;
/*      */     //   75: aload_3
/*      */     //   76: invokevirtual typeParameters : ()Ljava/util/List;
/*      */     //   79: invokevirtual safeSubtreeListMatch : (Ljava/util/List;Ljava/util/List;)Z
/*      */     //   82: ifeq -> 300
/*      */     //   85: aload_0
/*      */     //   86: aload_1
/*      */     //   87: invokevirtual getReturnType2 : ()Lorg/eclipse/jdt/core/dom/Type;
/*      */     //   90: aload_3
/*      */     //   91: invokevirtual getReturnType2 : ()Lorg/eclipse/jdt/core/dom/Type;
/*      */     //   94: invokevirtual safeSubtreeMatch : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*      */     //   97: ifeq -> 300
/*      */     //   100: goto -> 129
/*      */     //   103: aload_1
/*      */     //   104: invokevirtual getModifiers : ()I
/*      */     //   107: aload_3
/*      */     //   108: invokevirtual getModifiers : ()I
/*      */     //   111: if_icmpne -> 300
/*      */     //   114: aload_0
/*      */     //   115: aload_1
/*      */     //   116: invokevirtual internalGetReturnType : ()Lorg/eclipse/jdt/core/dom/Type;
/*      */     //   119: aload_3
/*      */     //   120: invokevirtual internalGetReturnType : ()Lorg/eclipse/jdt/core/dom/Type;
/*      */     //   123: invokevirtual safeSubtreeMatch : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*      */     //   126: ifeq -> 300
/*      */     //   129: aload_0
/*      */     //   130: aload_1
/*      */     //   131: invokevirtual getName : ()Lorg/eclipse/jdt/core/dom/SimpleName;
/*      */     //   134: aload_3
/*      */     //   135: invokevirtual getName : ()Lorg/eclipse/jdt/core/dom/SimpleName;
/*      */     //   138: invokevirtual safeSubtreeMatch : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*      */     //   141: ifeq -> 300
/*      */     //   144: iload #4
/*      */     //   146: bipush #8
/*      */     //   148: if_icmplt -> 181
/*      */     //   151: aload_0
/*      */     //   152: aload_1
/*      */     //   153: invokevirtual getReceiverType : ()Lorg/eclipse/jdt/core/dom/Type;
/*      */     //   156: aload_3
/*      */     //   157: invokevirtual getReceiverType : ()Lorg/eclipse/jdt/core/dom/Type;
/*      */     //   160: invokevirtual safeSubtreeMatch : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*      */     //   163: ifeq -> 300
/*      */     //   166: aload_0
/*      */     //   167: aload_1
/*      */     //   168: invokevirtual getReceiverQualifier : ()Lorg/eclipse/jdt/core/dom/SimpleName;
/*      */     //   171: aload_3
/*      */     //   172: invokevirtual getReceiverQualifier : ()Lorg/eclipse/jdt/core/dom/SimpleName;
/*      */     //   175: invokevirtual safeSubtreeMatch : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*      */     //   178: ifeq -> 300
/*      */     //   181: aload_0
/*      */     //   182: aload_1
/*      */     //   183: invokevirtual parameters : ()Ljava/util/List;
/*      */     //   186: aload_3
/*      */     //   187: invokevirtual parameters : ()Ljava/util/List;
/*      */     //   190: invokevirtual safeSubtreeListMatch : (Ljava/util/List;Ljava/util/List;)Z
/*      */     //   193: ifeq -> 300
/*      */     //   196: iload #4
/*      */     //   198: bipush #8
/*      */     //   200: if_icmplt -> 236
/*      */     //   203: aload_0
/*      */     //   204: aload_1
/*      */     //   205: invokevirtual extraDimensions : ()Ljava/util/List;
/*      */     //   208: aload_3
/*      */     //   209: invokevirtual extraDimensions : ()Ljava/util/List;
/*      */     //   212: invokevirtual safeSubtreeListMatch : (Ljava/util/List;Ljava/util/List;)Z
/*      */     //   215: ifeq -> 300
/*      */     //   218: aload_0
/*      */     //   219: aload_1
/*      */     //   220: invokevirtual thrownExceptionTypes : ()Ljava/util/List;
/*      */     //   223: aload_3
/*      */     //   224: invokevirtual thrownExceptionTypes : ()Ljava/util/List;
/*      */     //   227: invokevirtual safeSubtreeListMatch : (Ljava/util/List;Ljava/util/List;)Z
/*      */     //   230: ifeq -> 300
/*      */     //   233: goto -> 262
/*      */     //   236: aload_1
/*      */     //   237: invokevirtual getExtraDimensions : ()I
/*      */     //   240: aload_3
/*      */     //   241: invokevirtual getExtraDimensions : ()I
/*      */     //   244: if_icmpne -> 300
/*      */     //   247: aload_0
/*      */     //   248: aload_1
/*      */     //   249: invokevirtual internalThrownExceptions : ()Ljava/util/List;
/*      */     //   252: aload_3
/*      */     //   253: invokevirtual internalThrownExceptions : ()Ljava/util/List;
/*      */     //   256: invokevirtual safeSubtreeListMatch : (Ljava/util/List;Ljava/util/List;)Z
/*      */     //   259: ifeq -> 300
/*      */     //   262: aload_0
/*      */     //   263: aload_1
/*      */     //   264: invokevirtual getBody : ()Lorg/eclipse/jdt/core/dom/Block;
/*      */     //   267: aload_3
/*      */     //   268: invokevirtual getBody : ()Lorg/eclipse/jdt/core/dom/Block;
/*      */     //   271: invokevirtual safeSubtreeMatch : (Ljava/lang/Object;Ljava/lang/Object;)Z
/*      */     //   274: ifeq -> 300
/*      */     //   277: aload_1
/*      */     //   278: invokevirtual getAST : ()Lorg/eclipse/jdt/core/dom/AST;
/*      */     //   281: invokestatic isRecordDeclarationSupported : (Lorg/eclipse/jdt/core/dom/AST;)Z
/*      */     //   284: ifeq -> 298
/*      */     //   287: aload_1
/*      */     //   288: invokevirtual isCompactConstructor : ()Z
/*      */     //   291: aload_3
/*      */     //   292: invokevirtual isCompactConstructor : ()Z
/*      */     //   295: if_icmpne -> 300
/*      */     //   298: iconst_1
/*      */     //   299: ireturn
/*      */     //   300: iconst_0
/*      */     //   301: ireturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1614	-> 0
/*      */     //   #1615	-> 7
/*      */     //   #1617	-> 9
/*      */     //   #1618	-> 14
/*      */     //   #1619	-> 23
/*      */     //   #1620	-> 34
/*      */     //   #1621	-> 49
/*      */     //   #1622	-> 55
/*      */     //   #1623	-> 70
/*      */     //   #1625	-> 85
/*      */     //   #1626	-> 103
/*      */     //   #1628	-> 114
/*      */     //   #1629	-> 129
/*      */     //   #1630	-> 144
/*      */     //   #1631	-> 151
/*      */     //   #1632	-> 166
/*      */     //   #1634	-> 181
/*      */     //   #1635	-> 196
/*      */     //   #1636	-> 203
/*      */     //   #1637	-> 218
/*      */     //   #1638	-> 236
/*      */     //   #1639	-> 247
/*      */     //   #1640	-> 262
/*      */     //   #1641	-> 277
/*      */     //   #1642	-> 287
/*      */     //   #1619	-> 298
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	302	0	this	Lorg/eclipse/jdt/core/dom/ASTMatcher;
/*      */     //   0	302	1	node	Lorg/eclipse/jdt/core/dom/MethodDeclaration;
/*      */     //   0	302	2	other	Ljava/lang/Object;
/*      */     //   14	288	3	o	Lorg/eclipse/jdt/core/dom/MethodDeclaration;
/*      */     //   23	279	4	level	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(MethodInvocation node, Object other) {
/* 1661 */     if (!(other instanceof MethodInvocation)) {
/* 1662 */       return false;
/*      */     }
/* 1664 */     MethodInvocation o = (MethodInvocation)other;
/* 1665 */     if ((node.getAST()).apiLevel >= 3 && 
/* 1666 */       !safeSubtreeListMatch(node.typeArguments(), o.typeArguments())) {
/* 1667 */       return false;
/*      */     }
/*      */     
/* 1670 */     return 
/* 1671 */       (safeSubtreeMatch(node.getExpression(), o.getExpression()) && 
/* 1672 */       safeSubtreeMatch(node.getName(), o.getName()) && 
/* 1673 */       safeSubtreeListMatch(node.arguments(), o.arguments()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(Modifier node, Object other) {
/* 1692 */     if (!(other instanceof Modifier)) {
/* 1693 */       return false;
/*      */     }
/* 1695 */     Modifier o = (Modifier)other;
/* 1696 */     return (node.getKeyword() == o.getKeyword());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ModuleDeclaration node, Object other) {
/* 1715 */     if (!(other instanceof ModuleDeclaration)) {
/* 1716 */       return false;
/*      */     }
/* 1718 */     ModuleDeclaration o = (ModuleDeclaration)other;
/* 1719 */     return (safeSubtreeMatch(node.getJavadoc(), o.getJavadoc()) && 
/* 1720 */       safeSubtreeListMatch(node.annotations(), o.annotations()) && 
/* 1721 */       node.isOpen() == o.isOpen() && 
/* 1722 */       safeSubtreeMatch(node.getName(), o.getName()) && 
/* 1723 */       safeSubtreeListMatch(node.moduleStatements(), o.moduleStatements()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ModuleModifier node, Object other) {
/* 1742 */     if (!(other instanceof ModuleModifier)) {
/* 1743 */       return false;
/*      */     }
/* 1745 */     ModuleModifier o = (ModuleModifier)other;
/* 1746 */     return (node.getKeyword() == o.getKeyword());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(NameQualifiedType node, Object other) {
/* 1765 */     if (!(other instanceof NameQualifiedType)) {
/* 1766 */       return false;
/*      */     }
/* 1768 */     NameQualifiedType o = (NameQualifiedType)other;
/* 1769 */     return (safeSubtreeMatch(node.getQualifier(), o.getQualifier()) && 
/* 1770 */       safeSubtreeListMatch(node.annotations(), o.annotations()) && 
/* 1771 */       safeSubtreeMatch(node.getName(), o.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(NormalAnnotation node, Object other) {
/* 1790 */     if (!(other instanceof NormalAnnotation)) {
/* 1791 */       return false;
/*      */     }
/* 1793 */     NormalAnnotation o = (NormalAnnotation)other;
/* 1794 */     return (safeSubtreeMatch(node.getTypeName(), o.getTypeName()) && 
/* 1795 */       safeSubtreeListMatch(node.values(), o.values()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(NullLiteral node, Object other) {
/* 1813 */     if (!(other instanceof NullLiteral)) {
/* 1814 */       return false;
/*      */     }
/* 1816 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(NullPattern node, Object other) {
/* 1835 */     if (!(other instanceof NullPattern)) {
/* 1836 */       return false;
/*      */     }
/* 1838 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(NumberLiteral node, Object other) {
/* 1856 */     if (!(other instanceof NumberLiteral)) {
/* 1857 */       return false;
/*      */     }
/* 1859 */     NumberLiteral o = (NumberLiteral)other;
/* 1860 */     return safeEquals(node.getToken(), o.getToken());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(OpensDirective node, Object other) {
/* 1879 */     if (!(other instanceof OpensDirective)) {
/* 1880 */       return false;
/*      */     }
/* 1882 */     OpensDirective o = (OpensDirective)other;
/* 1883 */     return 
/* 1884 */       (safeSubtreeMatch(node.getName(), o.getName()) && 
/* 1885 */       safeSubtreeListMatch(node.modules(), o.modules()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(PackageDeclaration node, Object other) {
/* 1903 */     if (!(other instanceof PackageDeclaration)) {
/* 1904 */       return false;
/*      */     }
/* 1906 */     PackageDeclaration o = (PackageDeclaration)other;
/* 1907 */     if ((node.getAST()).apiLevel >= 3) {
/* 1908 */       if (!safeSubtreeMatch(node.getJavadoc(), o.getJavadoc())) {
/* 1909 */         return false;
/*      */       }
/* 1911 */       if (!safeSubtreeListMatch(node.annotations(), o.annotations())) {
/* 1912 */         return false;
/*      */       }
/*      */     } 
/* 1915 */     return safeSubtreeMatch(node.getName(), o.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ParameterizedType node, Object other) {
/* 1934 */     if (!(other instanceof ParameterizedType)) {
/* 1935 */       return false;
/*      */     }
/* 1937 */     ParameterizedType o = (ParameterizedType)other;
/* 1938 */     return (safeSubtreeMatch(node.getType(), o.getType()) && 
/* 1939 */       safeSubtreeListMatch(node.typeArguments(), o.typeArguments()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ParenthesizedExpression node, Object other) {
/* 1957 */     if (!(other instanceof ParenthesizedExpression)) {
/* 1958 */       return false;
/*      */     }
/* 1960 */     ParenthesizedExpression o = (ParenthesizedExpression)other;
/* 1961 */     return safeSubtreeMatch(node.getExpression(), o.getExpression());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(PatternInstanceofExpression node, Object other) {
/* 1981 */     if (!(other instanceof PatternInstanceofExpression)) {
/* 1982 */       return false;
/*      */     }
/* 1984 */     PatternInstanceofExpression o = (PatternInstanceofExpression)other;
/* 1985 */     return 
/* 1986 */       (safeSubtreeMatch(node.getLeftOperand(), o.getLeftOperand()) && 
/* 1987 */       safeSubtreeMatch(node.getRightOperand(), o.getRightOperand()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(PostfixExpression node, Object other) {
/* 2005 */     if (!(other instanceof PostfixExpression)) {
/* 2006 */       return false;
/*      */     }
/* 2008 */     PostfixExpression o = (PostfixExpression)other;
/* 2009 */     return 
/* 2010 */       (node.getOperator().equals(o.getOperator()) && 
/* 2011 */       safeSubtreeMatch(node.getOperand(), o.getOperand()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(PrefixExpression node, Object other) {
/* 2029 */     if (!(other instanceof PrefixExpression)) {
/* 2030 */       return false;
/*      */     }
/* 2032 */     PrefixExpression o = (PrefixExpression)other;
/* 2033 */     return 
/* 2034 */       (node.getOperator().equals(o.getOperator()) && 
/* 2035 */       safeSubtreeMatch(node.getOperand(), o.getOperand()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(PrimitiveType node, Object other) {
/* 2053 */     if (!(other instanceof PrimitiveType)) {
/* 2054 */       return false;
/*      */     }
/* 2056 */     PrimitiveType o = (PrimitiveType)other;
/* 2057 */     int level = (node.getAST()).apiLevel;
/* 2058 */     return ((level < 8 || safeSubtreeListMatch(node.annotations(), o.annotations())) && 
/* 2059 */       node.getPrimitiveTypeCode() == o.getPrimitiveTypeCode());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ProvidesDirective node, Object other) {
/* 2079 */     if (!(other instanceof ProvidesDirective)) {
/* 2080 */       return false;
/*      */     }
/* 2082 */     ProvidesDirective o = (ProvidesDirective)other;
/* 2083 */     return 
/* 2084 */       (safeSubtreeMatch(node.getName(), o.getName()) && 
/* 2085 */       safeSubtreeListMatch(node.implementations(), o.implementations()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(QualifiedName node, Object other) {
/* 2103 */     if (!(other instanceof QualifiedName)) {
/* 2104 */       return false;
/*      */     }
/* 2106 */     QualifiedName o = (QualifiedName)other;
/* 2107 */     return (safeSubtreeMatch(node.getQualifier(), o.getQualifier()) && 
/* 2108 */       safeSubtreeMatch(node.getName(), o.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ModuleQualifiedName node, Object other) {
/* 2127 */     if (!(other instanceof ModuleQualifiedName)) {
/* 2128 */       return false;
/*      */     }
/* 2130 */     ModuleQualifiedName o = (ModuleQualifiedName)other;
/* 2131 */     return (safeSubtreeMatch(node.getModuleQualifier(), o.getModuleQualifier()) && 
/* 2132 */       safeSubtreeMatch(node.getName(), o.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(QualifiedType node, Object other) {
/* 2151 */     if (!(other instanceof QualifiedType)) {
/* 2152 */       return false;
/*      */     }
/* 2154 */     QualifiedType o = (QualifiedType)other;
/* 2155 */     int level = (node.getAST()).apiLevel;
/* 2156 */     return (safeSubtreeMatch(node.getQualifier(), o.getQualifier()) && (
/* 2157 */       level < 8 || safeSubtreeListMatch(node.annotations(), o.annotations())) && 
/* 2158 */       safeSubtreeMatch(node.getName(), o.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(RecordDeclaration node, Object other) {
/* 2177 */     if (!(other instanceof RecordDeclaration)) {
/* 2178 */       return false;
/*      */     }
/* 2180 */     RecordDeclaration o = (RecordDeclaration)other;
/* 2181 */     return 
/* 2182 */       (safeSubtreeMatch(node.getJavadoc(), o.getJavadoc()) && 
/* 2183 */       safeSubtreeListMatch(node.modifiers(), o.modifiers()) && 
/* 2184 */       safeSubtreeMatch(node.getName(), o.getName()) && 
/* 2185 */       safeSubtreeListMatch(node.superInterfaceTypes(), o.superInterfaceTypes()) && 
/* 2186 */       safeSubtreeMatch(node.typeParameters(), o.typeParameters()) && 
/* 2187 */       safeSubtreeListMatch(node.bodyDeclarations(), o.bodyDeclarations()) && 
/* 2188 */       safeSubtreeMatch(node.recordComponents(), o.recordComponents()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(RecordPattern node, Object other) {
/* 2207 */     if (!(other instanceof RecordPattern)) {
/* 2208 */       return false;
/*      */     }
/* 2210 */     RecordPattern o = (RecordPattern)other;
/* 2211 */     return (safeSubtreeMatch(node.getPatternType(), o.getPatternType()) && 
/* 2212 */       safeSubtreeMatch(node.getPatternName(), o.getPatternName()) && 
/* 2213 */       safeSubtreeListMatch(node.patterns(), o.patterns()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(RequiresDirective node, Object other) {
/* 2233 */     if (!(other instanceof RequiresDirective)) {
/* 2234 */       return false;
/*      */     }
/* 2236 */     RequiresDirective o = (RequiresDirective)other;
/* 2237 */     return (safeSubtreeListMatch(node.modifiers(), o.modifiers()) && 
/* 2238 */       safeSubtreeMatch(node.getName(), o.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ReturnStatement node, Object other) {
/* 2256 */     if (!(other instanceof ReturnStatement)) {
/* 2257 */       return false;
/*      */     }
/* 2259 */     ReturnStatement o = (ReturnStatement)other;
/* 2260 */     return safeSubtreeMatch(node.getExpression(), o.getExpression());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(SimpleName node, Object other) {
/* 2278 */     if (!(other instanceof SimpleName)) {
/* 2279 */       return false;
/*      */     }
/* 2281 */     SimpleName o = (SimpleName)other;
/* 2282 */     return node.getIdentifier().equals(o.getIdentifier());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(SimpleType node, Object other) {
/* 2300 */     if (!(other instanceof SimpleType)) {
/* 2301 */       return false;
/*      */     }
/* 2303 */     SimpleType o = (SimpleType)other;
/* 2304 */     int level = (node.getAST()).apiLevel;
/* 2305 */     return ((level < 8 || safeSubtreeListMatch(node.annotations(), o.annotations())) && 
/* 2306 */       safeSubtreeMatch(node.getName(), o.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(SingleMemberAnnotation node, Object other) {
/* 2325 */     if (!(other instanceof SingleMemberAnnotation)) {
/* 2326 */       return false;
/*      */     }
/* 2328 */     SingleMemberAnnotation o = (SingleMemberAnnotation)other;
/* 2329 */     return (safeSubtreeMatch(node.getTypeName(), o.getTypeName()) && 
/* 2330 */       safeSubtreeMatch(node.getValue(), o.getValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(SingleVariableDeclaration node, Object other) {
/* 2352 */     if (!(other instanceof SingleVariableDeclaration)) {
/* 2353 */       return false;
/*      */     }
/* 2355 */     SingleVariableDeclaration o = (SingleVariableDeclaration)other;
/* 2356 */     int level = (node.getAST()).apiLevel;
/* 2357 */     if ((level >= 3) ? 
/* 2358 */       safeSubtreeListMatch(node.modifiers(), o.modifiers()) : (
/* 2359 */       node.getModifiers() == o.getModifiers())) {
/* 2360 */       if (safeSubtreeMatch(node.getType(), o.getType()) && (
/* 2361 */         level < 8 || !node.isVarargs() || 
/* 2362 */         safeSubtreeListMatch(node.varargsAnnotations(), o.varargsAnnotations())))
/*      */       {
/* 2364 */         if (level < 3 || 
/* 2365 */           node.isVarargs() == o.isVarargs())
/*      */         {
/* 2367 */           if (safeSubtreeMatch(node.getName(), o.getName()) && (
/* 2368 */             (level >= 8) ? 
/* 2369 */             safeSubtreeListMatch(node.extraDimensions(), o.extraDimensions()) : (
/* 2370 */             node.getExtraDimensions() == o.getExtraDimensions()))) {
/* 2371 */             if (safeSubtreeMatch(node.getInitializer(), o.getInitializer())) {
/*      */               return true;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(StringLiteral node, Object other) {
/* 2389 */     if (!(other instanceof StringLiteral)) {
/* 2390 */       return false;
/*      */     }
/* 2392 */     StringLiteral o = (StringLiteral)other;
/* 2393 */     return safeEquals(node.getEscapedValue(), o.getEscapedValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(SuperConstructorInvocation node, Object other) {
/* 2411 */     if (!(other instanceof SuperConstructorInvocation)) {
/* 2412 */       return false;
/*      */     }
/* 2414 */     SuperConstructorInvocation o = (SuperConstructorInvocation)other;
/* 2415 */     if ((node.getAST()).apiLevel >= 3 && 
/* 2416 */       !safeSubtreeListMatch(node.typeArguments(), o.typeArguments())) {
/* 2417 */       return false;
/*      */     }
/*      */     
/* 2420 */     return 
/* 2421 */       (safeSubtreeMatch(node.getExpression(), o.getExpression()) && 
/* 2422 */       safeSubtreeListMatch(node.arguments(), o.arguments()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(SuperFieldAccess node, Object other) {
/* 2440 */     if (!(other instanceof SuperFieldAccess)) {
/* 2441 */       return false;
/*      */     }
/* 2443 */     SuperFieldAccess o = (SuperFieldAccess)other;
/* 2444 */     return 
/* 2445 */       (safeSubtreeMatch(node.getName(), o.getName()) && 
/* 2446 */       safeSubtreeMatch(node.getQualifier(), o.getQualifier()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(SuperMethodInvocation node, Object other) {
/* 2464 */     if (!(other instanceof SuperMethodInvocation)) {
/* 2465 */       return false;
/*      */     }
/* 2467 */     SuperMethodInvocation o = (SuperMethodInvocation)other;
/* 2468 */     if ((node.getAST()).apiLevel >= 3 && 
/* 2469 */       !safeSubtreeListMatch(node.typeArguments(), o.typeArguments())) {
/* 2470 */       return false;
/*      */     }
/*      */     
/* 2473 */     return 
/* 2474 */       (safeSubtreeMatch(node.getQualifier(), o.getQualifier()) && 
/* 2475 */       safeSubtreeMatch(node.getName(), o.getName()) && 
/* 2476 */       safeSubtreeListMatch(node.arguments(), o.arguments()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(SuperMethodReference node, Object other) {
/* 2496 */     if (!(other instanceof SuperMethodReference)) {
/* 2497 */       return false;
/*      */     }
/* 2499 */     SuperMethodReference o = (SuperMethodReference)other;
/* 2500 */     return (safeSubtreeMatch(node.getQualifier(), o.getQualifier()) && 
/* 2501 */       safeSubtreeListMatch(node.typeArguments(), o.typeArguments()) && 
/* 2502 */       safeSubtreeMatch(node.getName(), o.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(SwitchCase node, Object other) {
/* 2520 */     if (!(other instanceof SwitchCase)) {
/* 2521 */       return false;
/*      */     }
/* 2523 */     SwitchCase o = (SwitchCase)other;
/* 2524 */     return ((node.getAST()).apiLevel >= 14) ? 
/* 2525 */       safeSubtreeListMatch(node.expressions(), o.expressions()) : 
/* 2526 */       compareDeprecatedSwitchExpression(node, o);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean compareDeprecatedSwitchExpression(SwitchCase first, SwitchCase second) {
/* 2536 */     return safeSubtreeMatch(first.getExpression(), second.getExpression());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(SwitchExpression node, Object other) {
/* 2555 */     if (!(other instanceof SwitchExpression)) {
/* 2556 */       return false;
/*      */     }
/* 2558 */     SwitchExpression o = (SwitchExpression)other;
/* 2559 */     return (safeSubtreeMatch(node.getExpression(), o.getExpression()) && 
/* 2560 */       safeSubtreeListMatch(node.statements(), o.statements()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(SwitchStatement node, Object other) {
/* 2578 */     if (!(other instanceof SwitchStatement)) {
/* 2579 */       return false;
/*      */     }
/* 2581 */     SwitchStatement o = (SwitchStatement)other;
/* 2582 */     return 
/* 2583 */       (safeSubtreeMatch(node.getExpression(), o.getExpression()) && 
/* 2584 */       safeSubtreeListMatch(node.statements(), o.statements()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(SynchronizedStatement node, Object other) {
/* 2602 */     if (!(other instanceof SynchronizedStatement)) {
/* 2603 */       return false;
/*      */     }
/* 2605 */     SynchronizedStatement o = (SynchronizedStatement)other;
/* 2606 */     return 
/* 2607 */       (safeSubtreeMatch(node.getExpression(), o.getExpression()) && 
/* 2608 */       safeSubtreeMatch(node.getBody(), o.getBody()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(TagElement node, Object other) {
/* 2627 */     if (!(other instanceof TagElement)) {
/* 2628 */       return false;
/*      */     }
/* 2630 */     TagElement o = (TagElement)other;
/* 2631 */     return 
/* 2632 */       (safeEquals(node.getTagName(), o.getTagName()) && 
/* 2633 */       safeSubtreeListMatch(node.fragments(), o.fragments()) && (
/* 2634 */       !DOMASTUtil.isJavaDocCodeSnippetSupported((node.getAST()).apiLevel) || safeSubtreeListMatch(node.tagProperties(), o.tagProperties())));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(TagProperty node, Object other) {
/* 2653 */     if (!(other instanceof TagProperty)) {
/* 2654 */       return false;
/*      */     }
/* 2656 */     TagProperty o = (TagProperty)other;
/* 2657 */     return 
/* 2658 */       (safeEquals(node.getName(), o.getName()) && 
/* 2659 */       safeEquals(node.getStringValue(), o.getStringValue()) && 
/* 2660 */       safeSubtreeMatch(node.getNodeValue(), o.getNodeValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(TextBlock node, Object other) {
/* 2681 */     if (!(other instanceof TextBlock)) {
/* 2682 */       return false;
/*      */     }
/* 2684 */     TextBlock o = (TextBlock)other;
/* 2685 */     return safeEquals(node.getEscapedValue(), o.getEscapedValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(TextElement node, Object other) {
/* 2704 */     if (!(other instanceof TextElement)) {
/* 2705 */       return false;
/*      */     }
/* 2707 */     TextElement o = (TextElement)other;
/* 2708 */     return safeEquals(node.getText(), o.getText());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ThisExpression node, Object other) {
/* 2726 */     if (!(other instanceof ThisExpression)) {
/* 2727 */       return false;
/*      */     }
/* 2729 */     ThisExpression o = (ThisExpression)other;
/* 2730 */     return safeSubtreeMatch(node.getQualifier(), o.getQualifier());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(ThrowStatement node, Object other) {
/* 2748 */     if (!(other instanceof ThrowStatement)) {
/* 2749 */       return false;
/*      */     }
/* 2751 */     ThrowStatement o = (ThrowStatement)other;
/* 2752 */     return safeSubtreeMatch(node.getExpression(), o.getExpression());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(TryStatement node, Object other) {
/* 2770 */     if (!(other instanceof TryStatement)) {
/* 2771 */       return false;
/*      */     }
/* 2773 */     TryStatement o = (TryStatement)other;
/* 2774 */     int level = (node.getAST()).apiLevel;
/* 2775 */     return ((level < 4 || safeSubtreeListMatch(node.resources(), o.resources())) && 
/* 2776 */       safeSubtreeMatch(node.getBody(), o.getBody()) && 
/* 2777 */       safeSubtreeListMatch(node.catchClauses(), o.catchClauses()) && 
/* 2778 */       safeSubtreeMatch(node.getFinally(), o.getFinally()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(TypeDeclaration node, Object other) {
/* 2796 */     if (!(other instanceof TypeDeclaration)) {
/* 2797 */       return false;
/*      */     }
/* 2799 */     TypeDeclaration o = (TypeDeclaration)other;
/* 2800 */     int level = (node.getAST()).apiLevel;
/* 2801 */     if (level == 2) {
/* 2802 */       if (node.getModifiers() != o.getModifiers()) {
/* 2803 */         return false;
/*      */       }
/* 2805 */       if (!safeSubtreeMatch(node.internalGetSuperclass(), o.internalGetSuperclass())) {
/* 2806 */         return false;
/*      */       }
/* 2808 */       if (!safeSubtreeListMatch(node.internalSuperInterfaces(), o.internalSuperInterfaces())) {
/* 2809 */         return false;
/*      */       }
/*      */     } 
/* 2812 */     if (level >= 3) {
/* 2813 */       if (!safeSubtreeListMatch(node.modifiers(), o.modifiers())) {
/* 2814 */         return false;
/*      */       }
/* 2816 */       if (!safeSubtreeListMatch(node.typeParameters(), o.typeParameters())) {
/* 2817 */         return false;
/*      */       }
/* 2819 */       if (!safeSubtreeMatch(node.getSuperclassType(), o.getSuperclassType())) {
/* 2820 */         return false;
/*      */       }
/* 2822 */       if (!safeSubtreeListMatch(node.superInterfaceTypes(), o.superInterfaceTypes())) {
/* 2823 */         return false;
/*      */       }
/*      */     } 
/* 2826 */     if (DOMASTUtil.isFeatureSupportedinAST(node.getAST(), 512) && 
/* 2827 */       !safeSubtreeListMatch(node.permittedTypes(), o.permittedTypes())) {
/* 2828 */       return false;
/*      */     }
/*      */     
/* 2831 */     return 
/* 2832 */       (node.isInterface() == o.isInterface() && 
/* 2833 */       safeSubtreeMatch(node.getJavadoc(), o.getJavadoc()) && 
/* 2834 */       safeSubtreeMatch(node.getName(), o.getName()) && 
/* 2835 */       safeSubtreeListMatch(node.bodyDeclarations(), o.bodyDeclarations()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(TypeDeclarationStatement node, Object other) {
/* 2853 */     if (!(other instanceof TypeDeclarationStatement)) {
/* 2854 */       return false;
/*      */     }
/* 2856 */     TypeDeclarationStatement o = (TypeDeclarationStatement)other;
/* 2857 */     return safeSubtreeMatch(node.getDeclaration(), o.getDeclaration());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(TypeLiteral node, Object other) {
/* 2875 */     if (!(other instanceof TypeLiteral)) {
/* 2876 */       return false;
/*      */     }
/* 2878 */     TypeLiteral o = (TypeLiteral)other;
/* 2879 */     return safeSubtreeMatch(node.getType(), o.getType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(TypeMethodReference node, Object other) {
/* 2898 */     if (!(other instanceof TypeMethodReference)) {
/* 2899 */       return false;
/*      */     }
/* 2901 */     TypeMethodReference o = (TypeMethodReference)other;
/* 2902 */     return 
/* 2903 */       (safeSubtreeMatch(node.getType(), o.getType()) && 
/* 2904 */       safeSubtreeListMatch(node.typeArguments(), o.typeArguments()) && 
/* 2905 */       safeSubtreeMatch(node.getName(), o.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(TypeParameter node, Object other) {
/* 2924 */     if (!(other instanceof TypeParameter)) {
/* 2925 */       return false;
/*      */     }
/* 2927 */     TypeParameter o = (TypeParameter)other;
/* 2928 */     int level = (node.getAST()).apiLevel;
/* 2929 */     return ((level < 8 || safeSubtreeListMatch(node.modifiers(), o.modifiers())) && 
/* 2930 */       safeSubtreeMatch(node.getName(), o.getName()) && 
/* 2931 */       safeSubtreeListMatch(node.typeBounds(), o.typeBounds()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(TypePattern node, Object other) {
/* 2950 */     if (!(other instanceof TypePattern)) {
/* 2951 */       return false;
/*      */     }
/* 2953 */     TypePattern o = (TypePattern)other;
/* 2954 */     return safeSubtreeMatch(node.getPatternVariable(), o.getPatternVariable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(UnionType node, Object other) {
/* 2973 */     if (!(other instanceof UnionType)) {
/* 2974 */       return false;
/*      */     }
/* 2976 */     UnionType o = (UnionType)other;
/* 2977 */     return safeSubtreeListMatch(node.types(), o.types());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(UsesDirective node, Object other) {
/* 2996 */     if (!(other instanceof UsesDirective)) {
/* 2997 */       return false;
/*      */     }
/* 2999 */     UsesDirective o = (UsesDirective)other;
/* 3000 */     return safeSubtreeMatch(node.getName(), o.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(VariableDeclarationExpression node, Object other) {
/* 3018 */     if (!(other instanceof VariableDeclarationExpression)) {
/* 3019 */       return false;
/*      */     }
/* 3021 */     VariableDeclarationExpression o = (VariableDeclarationExpression)other;
/* 3022 */     int level = (node.getAST()).apiLevel;
/* 3023 */     if (level == 2 && 
/* 3024 */       node.getModifiers() != o.getModifiers()) {
/* 3025 */       return false;
/*      */     }
/*      */     
/* 3028 */     if (level >= 3 && 
/* 3029 */       !safeSubtreeListMatch(node.modifiers(), o.modifiers())) {
/* 3030 */       return false;
/*      */     }
/*      */     
/* 3033 */     return (safeSubtreeMatch(node.getType(), o.getType()) && 
/* 3034 */       safeSubtreeListMatch(node.fragments(), o.fragments()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(VariableDeclarationFragment node, Object other) {
/* 3056 */     if (!(other instanceof VariableDeclarationFragment)) {
/* 3057 */       return false;
/*      */     }
/* 3059 */     VariableDeclarationFragment o = (VariableDeclarationFragment)other;
/* 3060 */     int level = (node.getAST()).apiLevel;
/* 3061 */     if (safeSubtreeMatch(node.getName(), o.getName()) && (
/* 3062 */       (level >= 8) ? 
/* 3063 */       safeSubtreeListMatch(node.extraDimensions(), o.extraDimensions()) : (
/* 3064 */       node.getExtraDimensions() == o.getExtraDimensions()))) {
/* 3065 */       if (safeSubtreeMatch(node.getInitializer(), o.getInitializer())) {
/*      */         return true;
/*      */       }
/*      */     }
/*      */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(VariableDeclarationStatement node, Object other) {
/* 3083 */     if (!(other instanceof VariableDeclarationStatement)) {
/* 3084 */       return false;
/*      */     }
/* 3086 */     VariableDeclarationStatement o = (VariableDeclarationStatement)other;
/* 3087 */     int level = (node.getAST()).apiLevel;
/* 3088 */     if (level == 2 && 
/* 3089 */       node.getModifiers() != o.getModifiers()) {
/* 3090 */       return false;
/*      */     }
/*      */     
/* 3093 */     if (level >= 3 && 
/* 3094 */       !safeSubtreeListMatch(node.modifiers(), o.modifiers())) {
/* 3095 */       return false;
/*      */     }
/*      */     
/* 3098 */     return (safeSubtreeMatch(node.getType(), o.getType()) && 
/* 3099 */       safeSubtreeListMatch(node.fragments(), o.fragments()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(WhileStatement node, Object other) {
/* 3117 */     if (!(other instanceof WhileStatement)) {
/* 3118 */       return false;
/*      */     }
/* 3120 */     WhileStatement o = (WhileStatement)other;
/* 3121 */     return 
/* 3122 */       (safeSubtreeMatch(node.getExpression(), o.getExpression()) && 
/* 3123 */       safeSubtreeMatch(node.getBody(), o.getBody()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(WildcardType node, Object other) {
/* 3142 */     if (!(other instanceof WildcardType)) {
/* 3143 */       return false;
/*      */     }
/* 3145 */     WildcardType o = (WildcardType)other;
/* 3146 */     int level = (node.getAST()).apiLevel;
/* 3147 */     return ((level < 8 || safeSubtreeListMatch(node.annotations(), o.annotations())) && 
/* 3148 */       node.isUpperBound() == o.isUpperBound() && 
/* 3149 */       safeSubtreeMatch(node.getBound(), o.getBound()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(YieldStatement node, Object other) {
/* 3170 */     if (!(other instanceof YieldStatement)) {
/* 3171 */       return false;
/*      */     }
/* 3173 */     YieldStatement o = (YieldStatement)other;
/* 3174 */     return safeSubtreeMatch(node.getExpression(), o.getExpression());
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\ASTMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */