/*     */ package org.eclipse.jdt.core;
/*     */ 
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.core.util.KeyKind;
/*     */ import org.eclipse.jdt.internal.core.util.KeyToSignature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BindingKey
/*     */ {
/*     */   private String key;
/*     */   
/*     */   public BindingKey(String key) {
/*  39 */     this.key = key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String createArrayTypeBindingKey(String typeKey, int arrayDimension) {
/*  59 */     StringBuilder buffer = new StringBuilder();
/*  60 */     while (arrayDimension-- > 0)
/*  61 */       buffer.append('['); 
/*  62 */     buffer.append(typeKey);
/*  63 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String createParameterizedTypeBindingKey(String genericTypeKey, String[] argumentTypeKeys) {
/*  89 */     StringBuilder buffer = new StringBuilder();
/*  90 */     buffer.append(Signature.getTypeErasure(genericTypeKey));
/*  91 */     buffer.insert(buffer.length() - 1, '<');
/*  92 */     for (int i = 0, length = argumentTypeKeys.length; i < length; i++) {
/*  93 */       String argumentTypeKey = argumentTypeKeys[i];
/*  94 */       buffer.insert(buffer.length() - 1, argumentTypeKey);
/*     */     } 
/*  96 */     buffer.insert(buffer.length() - 1, '>');
/*  97 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String createTypeBindingKey(String typeName) {
/* 120 */     return Signature.createTypeSignature(typeName.replace('.', '/'), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String createTypeVariableBindingKey(String typeVariableName, String declaringKey) {
/* 143 */     StringBuilder buffer = new StringBuilder();
/* 144 */     buffer.append(declaringKey);
/* 145 */     buffer.append(':');
/* 146 */     buffer.append('T');
/* 147 */     buffer.append(typeVariableName);
/* 148 */     buffer.append(';');
/* 149 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String createWilcardTypeBindingKey(String typeKey, char kind) {
/* 177 */     switch (kind) {
/*     */       case '*':
/* 179 */         return "*";
/*     */       case '-':
/* 181 */         return String.valueOf('-') + typeKey;
/*     */       case '+':
/* 183 */         return String.valueOf('+') + typeKey;
/*     */     } 
/* 185 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String createWildcardTypeBindingKey(String genericTypeKey, char boundKind, String boundTypeKey, int rank) {
/*     */     String wildCardKey;
/* 215 */     switch (boundKind) {
/*     */       case '*':
/* 217 */         wildCardKey = new String(TypeConstants.WILDCARD_STAR);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 228 */         return String.valueOf(genericTypeKey) + '{' + rank + '}' + wildCardKey;case '-': wildCardKey = String.valueOf(new String(TypeConstants.WILDCARD_MINUS)) + boundTypeKey; return String.valueOf(genericTypeKey) + '{' + rank + '}' + wildCardKey;case '+': wildCardKey = String.valueOf(new String(TypeConstants.WILDCARD_PLUS)) + boundTypeKey; return String.valueOf(genericTypeKey) + '{' + rank + '}' + wildCardKey;
/*     */     } 
/*     */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BindingKey getDeclaringType() {
/* 243 */     int end = this.key.lastIndexOf('.');
/* 244 */     if (end == -1) {
/* 245 */       end = this.key.lastIndexOf('$');
/* 246 */       if (end == -1) return null; 
/*     */     } 
/* 248 */     KeyKind kind = new KeyKind(this.key);
/* 249 */     kind.parse();
/* 250 */     if ((kind.flags & 0x10) != 0)
/*     */     {
/* 252 */       return null;
/*     */     }
/* 254 */     String typeKey = this.key.substring(0, end);
/* 255 */     if (typeKey.charAt(typeKey.length() - 1) != ';') {
/* 256 */       typeKey = String.valueOf(typeKey) + ';';
/*     */     }
/* 258 */     return new BindingKey(typeKey);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getThrownExceptions() {
/* 269 */     KeyToSignature keyToSignature = new KeyToSignature(this.key, 3);
/* 270 */     keyToSignature.parse();
/* 271 */     return keyToSignature.getThrownExceptions();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getTypeArguments() {
/* 282 */     KeyToSignature keyToSignature = new KeyToSignature(this.key, 1);
/* 283 */     keyToSignature.parse();
/* 284 */     return keyToSignature.getTypeArguments();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRawType() {
/* 293 */     KeyKind kind = new KeyKind(this.key);
/* 294 */     kind.parse();
/* 295 */     return ((kind.flags & 0x100) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isParameterizedType() {
/* 304 */     KeyKind kind = new KeyKind(this.key);
/* 305 */     kind.parse();
/* 306 */     return ((kind.flags & 0x80) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isParameterizedMethod() {
/* 315 */     KeyKind kind = new KeyKind(this.key);
/* 316 */     kind.parse();
/* 317 */     return ((kind.flags & 0x400) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toSignature() {
/* 330 */     KeyToSignature keyToSignature = new KeyToSignature(this.key, 0);
/* 331 */     keyToSignature.parse();
/* 332 */     return keyToSignature.signature.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 337 */     return this.key;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\BindingKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */