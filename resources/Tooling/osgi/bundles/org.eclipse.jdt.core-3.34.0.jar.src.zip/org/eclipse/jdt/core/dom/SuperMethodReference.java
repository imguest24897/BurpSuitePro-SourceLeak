/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SuperMethodReference
/*     */   extends MethodReference
/*     */ {
/*  39 */   public static final ChildPropertyDescriptor QUALIFIER_PROPERTY = new ChildPropertyDescriptor(SuperMethodReference.class, "qualifier", Name.class, false, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public static final ChildListPropertyDescriptor TYPE_ARGUMENTS_PROPERTY = internalTypeArgumentsFactory(SuperMethodReference.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public static final ChildPropertyDescriptor NAME_PROPERTY = new ChildPropertyDescriptor(SuperMethodReference.class, "name", SimpleName.class, true, false);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS_8_0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  61 */     List propertyList = new ArrayList(4);
/*  62 */     createPropertyList(SuperMethodReference.class, propertyList);
/*  63 */     addProperty(QUALIFIER_PROPERTY, propertyList);
/*  64 */     addProperty(TYPE_ARGUMENTS_PROPERTY, propertyList);
/*  65 */     addProperty(NAME_PROPERTY, propertyList);
/*  66 */     PROPERTY_DESCRIPTORS_8_0 = reapPropertyList(propertyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  79 */     return PROPERTY_DESCRIPTORS_8_0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   private Name optionalQualifier = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   private SimpleName methodName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SuperMethodReference(AST ast) {
/* 104 */     super(ast);
/* 105 */     unsupportedIn2_3_4();
/*     */   }
/*     */ 
/*     */   
/*     */   final ChildListPropertyDescriptor internalTypeArgumentsProperty() {
/* 110 */     return TYPE_ARGUMENTS_PROPERTY;
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 115 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 120 */     if (property == QUALIFIER_PROPERTY) {
/* 121 */       if (get) {
/* 122 */         return getQualifier();
/*     */       }
/* 124 */       setQualifier((Name)child);
/* 125 */       return null;
/*     */     } 
/*     */     
/* 128 */     if (property == NAME_PROPERTY) {
/* 129 */       if (get) {
/* 130 */         return getName();
/*     */       }
/* 132 */       setName((SimpleName)child);
/* 133 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 137 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 142 */     if (property == TYPE_ARGUMENTS_PROPERTY) {
/* 143 */       return typeArguments();
/*     */     }
/*     */     
/* 146 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 151 */     return 91;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 156 */     SuperMethodReference result = new SuperMethodReference(target);
/* 157 */     result.setSourceRange(getStartPosition(), getLength());
/* 158 */     result.setName((SimpleName)getName().clone(target));
/* 159 */     result.setQualifier((Name)ASTNode.copySubtree(target, getQualifier()));
/* 160 */     result.typeArguments().addAll(ASTNode.copySubtrees(target, typeArguments()));
/* 161 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 167 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 172 */     boolean visitChildren = visitor.visit(this);
/* 173 */     if (visitChildren) {
/*     */       
/* 175 */       acceptChild(visitor, getQualifier());
/* 176 */       acceptChildren(visitor, this.typeArguments);
/* 177 */       acceptChild(visitor, getName());
/*     */     } 
/* 179 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Name getQualifier() {
/* 189 */     return this.optionalQualifier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setQualifier(Name name) {
/* 204 */     ASTNode oldChild = this.optionalQualifier;
/* 205 */     preReplaceChild(oldChild, name, QUALIFIER_PROPERTY);
/* 206 */     this.optionalQualifier = name;
/* 207 */     postReplaceChild(oldChild, name, QUALIFIER_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List typeArguments() {
/* 218 */     return this.typeArguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleName getName() {
/* 227 */     if (this.methodName == null)
/*     */     {
/* 229 */       synchronized (this) {
/* 230 */         if (this.methodName == null) {
/* 231 */           preLazyInit();
/* 232 */           this.methodName = new SimpleName(this.ast);
/* 233 */           postLazyInit(this.methodName, NAME_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 237 */     return this.methodName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(SimpleName name) {
/* 252 */     if (name == null) {
/* 253 */       throw new IllegalArgumentException();
/*     */     }
/* 255 */     ASTNode oldChild = this.methodName;
/* 256 */     preReplaceChild(oldChild, name, NAME_PROPERTY);
/* 257 */     this.methodName = name;
/* 258 */     postReplaceChild(oldChild, name, NAME_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 264 */     return 52;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 269 */     return 
/* 270 */       memSize() + (
/* 271 */       (this.optionalQualifier == null) ? 0 : getQualifier().treeSize()) + (
/* 272 */       (this.typeArguments == null) ? 0 : this.typeArguments.listSize()) + (
/* 273 */       (this.methodName == null) ? 0 : getName().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\SuperMethodReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */