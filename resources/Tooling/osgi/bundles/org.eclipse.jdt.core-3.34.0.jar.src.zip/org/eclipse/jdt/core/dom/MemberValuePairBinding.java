/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.internal.compiler.impl.Constant;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ElementValuePair;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.MethodBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.VariableBinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MemberValuePairBinding
/*     */   implements IMemberValuePairBinding
/*     */ {
/*  30 */   static final MemberValuePairBinding[] NoPair = new MemberValuePairBinding[0];
/*  31 */   private static final Object NoValue = new Object();
/*  32 */   private static final Object[] EmptyArray = new Object[0];
/*     */   
/*     */   private ElementValuePair internalPair;
/*  35 */   protected Object value = null;
/*     */   protected BindingResolver bindingResolver;
/*     */   
/*     */   static void appendValue(Object value, StringBuffer buffer) {
/*  39 */     if (value instanceof Object[]) {
/*  40 */       Object[] values = (Object[])value;
/*  41 */       buffer.append('{');
/*  42 */       for (int i = 0, l = values.length; i < l; i++) {
/*  43 */         if (i != 0)
/*  44 */           buffer.append(", "); 
/*  45 */         appendValue(values[i], buffer);
/*     */       } 
/*  47 */       buffer.append('}');
/*  48 */     } else if (value instanceof ITypeBinding) {
/*  49 */       buffer.append(((ITypeBinding)value).getName());
/*  50 */       buffer.append(".class");
/*     */     } else {
/*  52 */       buffer.append(value);
/*     */     } 
/*     */   }
/*     */   
/*     */   static Object buildDOMValue(Object internalObject, BindingResolver resolver) {
/*  57 */     if (internalObject == null) {
/*  58 */       return null;
/*     */     }
/*  60 */     if (internalObject instanceof Constant) {
/*  61 */       Constant constant = (Constant)internalObject;
/*  62 */       switch (constant.typeID()) {
/*     */         case 5:
/*  64 */           return Boolean.valueOf(constant.booleanValue());
/*     */         case 3:
/*  66 */           return Byte.valueOf(constant.byteValue());
/*     */         case 2:
/*  68 */           return Character.valueOf(constant.charValue());
/*     */         case 8:
/*  70 */           return Double.valueOf(constant.doubleValue());
/*     */         case 9:
/*  72 */           return Float.valueOf(constant.floatValue());
/*     */         case 10:
/*  74 */           return Integer.valueOf(constant.intValue());
/*     */         case 7:
/*  76 */           return Long.valueOf(constant.longValue());
/*     */         case 4:
/*  78 */           return Short.valueOf(constant.shortValue());
/*     */       } 
/*     */       
/*  81 */       return constant.stringValue();
/*     */     } 
/*  83 */     if (internalObject instanceof TypeBinding)
/*  84 */       return resolver.getTypeBinding((TypeBinding)internalObject); 
/*  85 */     if (internalObject instanceof AnnotationBinding)
/*  86 */       return resolver.getAnnotationInstance((AnnotationBinding)internalObject); 
/*  87 */     if (internalObject instanceof org.eclipse.jdt.internal.compiler.lookup.FieldBinding)
/*  88 */       return resolver.getVariableBinding((VariableBinding)internalObject); 
/*  89 */     if (internalObject instanceof Object[]) {
/*  90 */       Object[] elements = (Object[])internalObject;
/*  91 */       int length = elements.length;
/*  92 */       Object[] values = (length == 0) ? EmptyArray : new Object[length];
/*  93 */       for (int i = 0; i < length; i++)
/*  94 */         values[i] = buildDOMValue(elements[i], resolver); 
/*  95 */       return values;
/*     */     } 
/*  97 */     return null;
/*     */   }
/*     */   
/*     */   MemberValuePairBinding(ElementValuePair pair, BindingResolver resolver) {
/* 101 */     this.internalPair = pair;
/* 102 */     this.bindingResolver = resolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public IAnnotationBinding[] getAnnotations() {
/* 107 */     return (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public IJavaElement getJavaElement() {
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getKind() {
/* 123 */     return 6;
/*     */   }
/*     */ 
/*     */   
/*     */   public IMethodBinding getMethodBinding() {
/* 128 */     return this.bindingResolver.getMethodBinding(this.internalPair.getMethodBinding());
/*     */   }
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 133 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 138 */     if (this.internalPair == null)
/* 139 */       return null; 
/* 140 */     char[] membername = this.internalPair.getName();
/* 141 */     return (membername == null) ? null : new String(membername);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getValue() {
/* 146 */     if (this.value == null)
/* 147 */       init(); 
/* 148 */     return (this.value == NoValue) ? null : this.value;
/*     */   }
/*     */   
/*     */   private void init() {
/* 152 */     this.value = buildDOMValue(this.internalPair.getValue(), this.bindingResolver);
/* 153 */     if (this.value == null)
/* 154 */       this.value = NoValue; 
/* 155 */     IMethodBinding methodBinding = getMethodBinding();
/* 156 */     if (methodBinding.getReturnType().isArray() && !this.value.getClass().isArray()) {
/* 157 */       this.value = new Object[] { this.value };
/*     */     }
/*     */   }
/*     */   
/*     */   char[] internalName() {
/* 162 */     return (this.internalPair == null) ? null : this.internalPair.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDefault() {
/* 167 */     Object value2 = getValue();
/* 168 */     Object defaultValue = getMethodBinding().getDefaultValue();
/* 169 */     if (value2 instanceof IBinding) {
/* 170 */       if (defaultValue instanceof IBinding) {
/* 171 */         return ((IBinding)value2).isEqualTo((IBinding)defaultValue);
/*     */       }
/* 173 */       return false;
/*     */     } 
/* 175 */     if (defaultValue == null) return false; 
/* 176 */     return defaultValue.equals(value2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDeprecated() {
/* 181 */     MethodBinding methodBinding = this.internalPair.getMethodBinding();
/* 182 */     return (methodBinding == null) ? false : methodBinding.isDeprecated();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEqualTo(IBinding binding) {
/* 187 */     if (this == binding)
/* 188 */       return true; 
/* 189 */     if (binding.getKind() != 6)
/* 190 */       return false; 
/* 191 */     IMemberValuePairBinding otherMemberValuePairBinding = (IMemberValuePairBinding)binding;
/* 192 */     if (!getMethodBinding().isEqualTo(otherMemberValuePairBinding.getMethodBinding())) {
/* 193 */       return false;
/*     */     }
/* 195 */     Object otherValue = otherMemberValuePairBinding.getValue();
/* 196 */     Object currentValue = getValue();
/* 197 */     if (currentValue == null) {
/* 198 */       return (otherValue == null);
/*     */     }
/* 200 */     if (currentValue instanceof IBinding) {
/* 201 */       if (otherValue instanceof IBinding) {
/* 202 */         return ((IBinding)currentValue).isEqualTo((IBinding)otherValue);
/*     */       }
/* 204 */       return false;
/*     */     } 
/* 206 */     if (currentValue.getClass().isArray()) {
/* 207 */       if (!otherValue.getClass().isArray()) {
/* 208 */         return false;
/*     */       }
/* 210 */       Object[] currentValues = (Object[])currentValue;
/* 211 */       Object[] otherValues = (Object[])otherValue;
/* 212 */       int length = currentValues.length;
/* 213 */       if (length != otherValues.length) {
/* 214 */         return false;
/*     */       }
/* 216 */       for (int i = 0; i < length; i++) {
/* 217 */         Object current = currentValues[i];
/* 218 */         Object other = otherValues[i];
/* 219 */         if (current instanceof IBinding) {
/* 220 */           if (!(other instanceof IBinding)) {
/* 221 */             return false;
/*     */           }
/* 223 */           if (!((IBinding)current).isEqualTo((IBinding)other)) {
/* 224 */             return false;
/*     */           }
/* 226 */         } else if (!current.equals(other)) {
/* 227 */           return false;
/*     */         } 
/*     */       } 
/* 230 */       return true;
/*     */     } 
/* 232 */     return currentValue.equals(otherValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRecovered() {
/* 238 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSynthetic() {
/* 243 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 248 */     StringBuffer buffer = new StringBuffer();
/* 249 */     buffer.append(getName());
/* 250 */     buffer.append(" = ");
/* 251 */     appendValue(getValue(), buffer);
/* 252 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\MemberValuePairBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */