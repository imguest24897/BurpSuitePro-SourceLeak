package org.eclipse.jdt.core;

import org.eclipse.jdt.core.compiler.IProblem;

public interface ICompletionRequestor {
  void acceptAnonymousType(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[][] paramArrayOfchar3, char[][] paramArrayOfchar4, char[][] paramArrayOfchar5, char[] paramArrayOfchar6, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void acceptClass(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[] paramArrayOfchar3, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void acceptError(IProblem paramIProblem);
  
  void acceptField(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[] paramArrayOfchar3, char[] paramArrayOfchar4, char[] paramArrayOfchar5, char[] paramArrayOfchar6, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void acceptInterface(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[] paramArrayOfchar3, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void acceptKeyword(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3);
  
  void acceptLabel(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3);
  
  void acceptLocalVariable(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[] paramArrayOfchar3, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void acceptMethod(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[] paramArrayOfchar3, char[][] paramArrayOfchar4, char[][] paramArrayOfchar5, char[][] paramArrayOfchar6, char[] paramArrayOfchar7, char[] paramArrayOfchar8, char[] paramArrayOfchar9, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void acceptMethodDeclaration(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[] paramArrayOfchar3, char[][] paramArrayOfchar4, char[][] paramArrayOfchar5, char[][] paramArrayOfchar6, char[] paramArrayOfchar7, char[] paramArrayOfchar8, char[] paramArrayOfchar9, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void acceptModifier(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3);
  
  void acceptPackage(char[] paramArrayOfchar1, char[] paramArrayOfchar2, int paramInt1, int paramInt2, int paramInt3);
  
  void acceptType(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[] paramArrayOfchar3, int paramInt1, int paramInt2, int paramInt3);
  
  void acceptVariableName(char[] paramArrayOfchar1, char[] paramArrayOfchar2, char[] paramArrayOfchar3, char[] paramArrayOfchar4, int paramInt1, int paramInt2, int paramInt3);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\ICompletionRequestor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */