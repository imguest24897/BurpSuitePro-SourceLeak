/*    */ package org.eclipse.jdt.core.dom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IModuleBinding
/*    */   extends IBinding
/*    */ {
/*    */   default int getKind() {
/* 28 */     return 7;
/*    */   }
/*    */   
/*    */   boolean isOpen();
/*    */   
/*    */   IModuleBinding[] getRequiredModules();
/*    */   
/*    */   IPackageBinding[] getExportedPackages();
/*    */   
/*    */   String[] getExportedTo(IPackageBinding paramIPackageBinding);
/*    */   
/*    */   IPackageBinding[] getOpenedPackages();
/*    */   
/*    */   String[] getOpenedTo(IPackageBinding paramIPackageBinding);
/*    */   
/*    */   ITypeBinding[] getUses();
/*    */   
/*    */   ITypeBinding[] getServices();
/*    */   
/*    */   ITypeBinding[] getImplementations(ITypeBinding paramITypeBinding);
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\IModuleBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */