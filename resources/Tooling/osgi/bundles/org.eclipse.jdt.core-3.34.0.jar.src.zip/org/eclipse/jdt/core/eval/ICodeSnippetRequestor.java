/*    */ package org.eclipse.jdt.core.eval;
/*    */ 
/*    */ import org.eclipse.core.resources.IMarker;
/*    */ import org.eclipse.jdt.internal.eval.EvaluationConstants;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ICodeSnippetRequestor
/*    */ {
/* 37 */   public static final String LOCAL_VAR_PREFIX = new String(EvaluationConstants.LOCAL_VAR_PREFIX);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   public static final String DELEGATE_THIS = new String(EvaluationConstants.DELEGATE_THIS);
/*    */   public static final String RUN_METHOD = "run";
/*    */   public static final String RESULT_VALUE_FIELD = "resultValue";
/*    */   public static final String RESULT_TYPE_FIELD = "resultType";
/*    */   public static final int VARIABLE = 1;
/*    */   public static final int CODE_SNIPPET = 2;
/*    */   public static final int IMPORT = 3;
/*    */   public static final int PACKAGE = 4;
/*    */   public static final int INTERNAL = 5;
/*    */   
/*    */   boolean acceptClassFiles(byte[][] paramArrayOfbyte, String[][] paramArrayOfString, String paramString);
/*    */   
/*    */   void acceptProblem(IMarker paramIMarker, String paramString, int paramInt);
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\eval\ICodeSnippetRequestor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */