/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.internal.core.dom.util.DOMASTUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypePattern
/*     */   extends Pattern
/*     */ {
/*  40 */   public static final ChildPropertyDescriptor PATTERN_VARIABLE_PROPERTY = new ChildPropertyDescriptor(TypePattern.class, "patternVariable", SingleVariableDeclaration.class, true, true);
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */   
/*     */   private SingleVariableDeclaration patternVariable;
/*     */ 
/*     */   
/*     */   static {
/*  50 */     List properyList = new ArrayList(3);
/*  51 */     createPropertyList(TypePattern.class, properyList);
/*  52 */     addProperty(PATTERN_VARIABLE_PROPERTY, properyList);
/*  53 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */   
/*     */   int getNodeType0() {
/*  58 */     return 106;
/*     */   }
/*     */   
/*     */   TypePattern(AST ast) {
/*  62 */     super(ast);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  71 */     this.patternVariable = null;
/*     */     supportedOnlyIn20();
/*     */     unsupportedWithoutPreviewError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel, boolean previewEnabled) {
/*  99 */     if (DOMASTUtil.isPatternSupported(apiLevel, previewEnabled)) {
/* 100 */       return PROPERTY_DESCRIPTORS;
/*     */     }
/* 102 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 107 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel, boolean previewEnabled) {
/* 112 */     return propertyDescriptors(apiLevel, previewEnabled);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 117 */     if (property == PATTERN_VARIABLE_PROPERTY) {
/* 118 */       return getPatternVariable();
/*     */     }
/*     */     
/* 121 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */   
/*     */   public List<SingleVariableDeclaration> patternVariables() {
/* 125 */     supportedOnlyIn20();
/* 126 */     unsupportedWithoutPreviewError();
/* 127 */     return new ArrayList<>(Arrays.asList(new SingleVariableDeclaration[] { getPatternVariable() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPatternVariable(SingleVariableDeclaration patternVariable) {
/* 145 */     supportedOnlyIn20();
/* 146 */     unsupportedWithoutPreviewError();
/* 147 */     if (patternVariable == null) {
/* 148 */       throw new IllegalArgumentException();
/*     */     }
/* 150 */     ASTNode oldChild = this.patternVariable;
/* 151 */     preReplaceChild(oldChild, patternVariable, PATTERN_VARIABLE_PROPERTY);
/* 152 */     this.patternVariable = patternVariable;
/* 153 */     postReplaceChild(oldChild, patternVariable, PATTERN_VARIABLE_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SingleVariableDeclaration getPatternVariable() {
/* 165 */     supportedOnlyIn20();
/* 166 */     unsupportedWithoutPreviewError();
/* 167 */     if (this.patternVariable == null)
/*     */     {
/* 169 */       synchronized (this) {
/* 170 */         if (this.patternVariable == null) {
/* 171 */           preLazyInit();
/* 172 */           this.patternVariable = new SingleVariableDeclaration(this.ast);
/* 173 */           postLazyInit(this.patternVariable, PATTERN_VARIABLE_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 177 */     return this.patternVariable;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 182 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 187 */     TypePattern result = new TypePattern(target);
/* 188 */     result.setSourceRange(getStartPosition(), getLength());
/* 189 */     result.setPatternVariable((SingleVariableDeclaration)getPatternVariable().clone(target));
/* 190 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 195 */     boolean visitChildren = visitor.visit(this);
/* 196 */     if (visitChildren)
/*     */     {
/* 198 */       acceptChild(visitor, getPatternVariable());
/*     */     }
/* 200 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 206 */     return 44;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 211 */     return 
/* 212 */       memSize() + (
/* 213 */       (this.patternVariable == null) ? 0 : getPatternVariable().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\TypePattern.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */