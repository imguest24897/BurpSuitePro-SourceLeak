package org.eclipse.jdt.core;

public interface IMethod extends IMember, IAnnotatable {
  IMemberValuePair getDefaultValue() throws JavaModelException;
  
  String getElementName();
  
  String[] getExceptionTypes() throws JavaModelException;
  
  String[] getTypeParameterSignatures() throws JavaModelException;
  
  ITypeParameter[] getTypeParameters() throws JavaModelException;
  
  int getNumberOfParameters();
  
  ILocalVariable[] getParameters() throws JavaModelException;
  
  String getKey();
  
  String[] getParameterNames() throws JavaModelException;
  
  String[] getParameterTypes();
  
  String[] getRawParameterNames() throws JavaModelException;
  
  String getReturnType() throws JavaModelException;
  
  String getSignature() throws JavaModelException;
  
  ITypeParameter getTypeParameter(String paramString);
  
  boolean isConstructor() throws JavaModelException;
  
  boolean isMainMethod() throws JavaModelException;
  
  boolean isLambdaMethod();
  
  boolean isResolved();
  
  boolean isSimilar(IMethod paramIMethod);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\IMethod.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */