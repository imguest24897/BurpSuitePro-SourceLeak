/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.JavadocSingleTypeReference;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.BlockScope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnJavadocTypeParamReference
/*    */   extends JavadocSingleTypeReference
/*    */   implements CompletionOnJavadoc
/*    */ {
/* 21 */   public int completionFlags = 1;
/*    */   public char[][] missingParams;
/*    */   
/*    */   public CompletionOnJavadocTypeParamReference(char[] name, long pos, int start, int end) {
/* 25 */     super(name, pos, start, end);
/*    */   }
/*    */   
/*    */   public CompletionOnJavadocTypeParamReference(JavadocSingleTypeReference typeRef) {
/* 29 */     super(typeRef.token, (typeRef.sourceStart << 32L) + typeRef.sourceEnd, typeRef.tagSourceStart, typeRef.tagSourceStart);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addCompletionFlags(int flags) {
/* 34 */     this.completionFlags |= flags;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getCompletionFlags() {
/* 39 */     return this.completionFlags;
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 44 */     output.append("<CompletionOnJavadocTypeParamReference:");
/* 45 */     if (this.token != null) super.printExpression(indent, output); 
/* 46 */     return output.append('>');
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TypeBinding reportError(BlockScope scope) {
/* 53 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnJavadocTypeParamReference.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */