package org.eclipse.jdt.core.util;

public interface IClassFileAttribute {
  int getAttributeNameIndex();
  
  char[] getAttributeName();
  
  long getAttributeLength();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\cor\\util\IClassFileAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */