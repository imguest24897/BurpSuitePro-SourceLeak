/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnonymousClassDeclaration
/*     */   extends ASTNode
/*     */ {
/*  43 */   public static final ChildListPropertyDescriptor BODY_DECLARATIONS_PROPERTY = new ChildListPropertyDescriptor(AnonymousClassDeclaration.class, "bodyDeclarations", BodyDeclaration.class, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  53 */     List properyList = new ArrayList(2);
/*  54 */     createPropertyList(AnonymousClassDeclaration.class, properyList);
/*  55 */     addProperty(BODY_DECLARATIONS_PROPERTY, properyList);
/*  56 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  71 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   private ASTNode.NodeList bodyDeclarations = new ASTNode.NodeList(this, BODY_DECLARATIONS_PROPERTY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnonymousClassDeclaration(AST ast) {
/*  93 */     super(ast);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/*  98 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalGetChildListProperty(ChildListPropertyDescriptor property) {
/* 103 */     if (property == BODY_DECLARATIONS_PROPERTY) {
/* 104 */       return bodyDeclarations();
/*     */     }
/*     */     
/* 107 */     return super.internalGetChildListProperty(property);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 112 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 117 */     AnonymousClassDeclaration result = new AnonymousClassDeclaration(target);
/* 118 */     result.setSourceRange(getStartPosition(), getLength());
/* 119 */     result.bodyDeclarations().addAll(
/* 120 */         ASTNode.copySubtrees(target, bodyDeclarations()));
/* 121 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 127 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 132 */     boolean visitChildren = visitor.visit(this);
/* 133 */     if (visitChildren)
/*     */     {
/* 135 */       acceptChildren(visitor, this.bodyDeclarations);
/*     */     }
/* 137 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List bodyDeclarations() {
/* 148 */     return this.bodyDeclarations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeBinding resolveBinding() {
/* 163 */     return this.ast.getBindingResolver().resolveType(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int memSize() {
/* 169 */     return 44;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 174 */     return 
/* 175 */       memSize() + 
/* 176 */       this.bodyDeclarations.listSize();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\AnonymousClassDeclaration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */