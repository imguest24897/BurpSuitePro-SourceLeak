/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.jdt.core.ICompilationUnit;
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.core.IPackageFragment;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryAnnotation;
/*     */ import org.eclipse.jdt.internal.compiler.env.IBinaryType;
/*     */ import org.eclipse.jdt.internal.compiler.env.INameEnvironment;
/*     */ import org.eclipse.jdt.internal.compiler.env.NameEnvironmentAnswer;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.AnnotationBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.BinaryTypeBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.ModuleBinding;
/*     */ import org.eclipse.jdt.internal.compiler.lookup.TypeConstants;
/*     */ import org.eclipse.jdt.internal.compiler.util.Util;
/*     */ import org.eclipse.jdt.internal.core.NameLookup;
/*     */ import org.eclipse.jdt.internal.core.SearchableEnvironment;
/*     */ import org.eclipse.jdt.internal.core.util.Util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PackageBinding
/*     */   implements IPackageBinding
/*     */ {
/*  47 */   private static final String[] NO_NAME_COMPONENTS = CharOperation.NO_STRINGS;
/*  48 */   private static final String UNNAMED = Util.EMPTY_STRING;
/*     */   
/*     */   private static final char PACKAGE_NAME_SEPARATOR = '.';
/*     */   private org.eclipse.jdt.internal.compiler.lookup.PackageBinding binding;
/*     */   private String name;
/*     */   private BindingResolver resolver;
/*     */   private String[] components;
/*     */   
/*     */   PackageBinding(org.eclipse.jdt.internal.compiler.lookup.PackageBinding binding, BindingResolver resolver) {
/*  57 */     this.binding = binding;
/*  58 */     this.resolver = resolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public IAnnotationBinding[] getAnnotations() {
/*     */     try {
/*  64 */       INameEnvironment nameEnvironment = this.binding.environment.nameEnvironment;
/*  65 */       if (!(nameEnvironment instanceof SearchableEnvironment))
/*  66 */         return (IAnnotationBinding[])AnnotationBinding.NoAnnotations; 
/*  67 */       NameLookup nameLookup = ((SearchableEnvironment)nameEnvironment).nameLookup;
/*  68 */       if (nameLookup == null)
/*  69 */         return (IAnnotationBinding[])AnnotationBinding.NoAnnotations; 
/*  70 */       String pkgName = getName();
/*  71 */       IPackageFragment[] pkgs = nameLookup.findPackageFragments(pkgName, false);
/*  72 */       if (pkgs == null) {
/*  73 */         return (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */       }
/*  75 */       for (int i = 0, len = pkgs.length; i < len; i++) {
/*  76 */         String unitName; ICompilationUnit unit; NameEnvironmentAnswer answer; int fragType = pkgs[i].getKind();
/*  77 */         switch (fragType) {
/*     */           case 1:
/*  79 */             unitName = "package-info.java";
/*  80 */             unit = pkgs[i].getCompilationUnit(unitName);
/*  81 */             if (unit != null && unit.exists()) {
/*  82 */               ASTParser p = ASTParser.newParser(3);
/*  83 */               p.setSource(unit);
/*  84 */               p.setResolveBindings(true);
/*  85 */               p.setUnitName(unitName);
/*  86 */               p.setFocalPosition(0);
/*  87 */               p.setKind(8);
/*  88 */               CompilationUnit domUnit = (CompilationUnit)p.createAST(null);
/*  89 */               PackageDeclaration pkgDecl = domUnit.getPackage();
/*  90 */               if (pkgDecl != null) {
/*  91 */                 List annos = pkgDecl.annotations();
/*  92 */                 if (annos == null || annos.isEmpty())
/*  93 */                   return (IAnnotationBinding[])AnnotationBinding.NoAnnotations; 
/*  94 */                 IAnnotationBinding[] result = new IAnnotationBinding[annos.size()];
/*  95 */                 int index = 0;
/*  96 */                 for (Iterator<Annotation> it = annos.iterator(); it.hasNext(); index++) {
/*  97 */                   result[index] = ((Annotation)it.next()).resolveAnnotationBinding();
/*     */                   
/*  99 */                   if (result[index] == null)
/* 100 */                     return (IAnnotationBinding[])AnnotationBinding.NoAnnotations; 
/*     */                 } 
/* 102 */                 return result;
/*     */               } 
/*     */             } 
/*     */             break;
/*     */           case 2:
/* 107 */             answer = 
/* 108 */               nameEnvironment.findType(TypeConstants.PACKAGE_INFO_NAME, this.binding.compoundName);
/* 109 */             if (answer != null && answer.isBinaryType()) {
/* 110 */               IBinaryType type = answer.getBinaryType();
/* 111 */               char[][][] missingTypeNames = type.getMissingTypeNames();
/* 112 */               IBinaryAnnotation[] binaryAnnotations = type.getAnnotations();
/* 113 */               AnnotationBinding[] binaryInstances = 
/* 114 */                 BinaryTypeBinding.createAnnotations(binaryAnnotations, this.binding.environment, missingTypeNames);
/* 115 */               AnnotationBinding[] allInstances = 
/* 116 */                 AnnotationBinding.addStandardAnnotations(binaryInstances, type.getTagBits(), this.binding.environment);
/* 117 */               int total = allInstances.length;
/* 118 */               AnnotationBinding[] arrayOfAnnotationBinding = new AnnotationBinding[total];
/* 119 */               for (int a = 0; a < total; a++) {
/* 120 */                 IAnnotationBinding annotationInstance = this.resolver.getAnnotationInstance(allInstances[a]);
/* 121 */                 if (annotationInstance == null) {
/* 122 */                   return (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */                 }
/* 124 */                 arrayOfAnnotationBinding[a] = (AnnotationBinding)annotationInstance;
/*     */               } 
/* 126 */               return (IAnnotationBinding[])arrayOfAnnotationBinding;
/*     */             }  break;
/*     */         } 
/*     */       } 
/* 130 */     } catch (JavaModelException javaModelException) {
/* 131 */       return (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */     } 
/* 133 */     return (IAnnotationBinding[])AnnotationBinding.NoAnnotations;
/*     */   }
/*     */ 
/*     */   
/*     */   public IModuleBinding getModule() {
/* 138 */     ModuleBinding moduleBinding = this.binding.enclosingModule;
/* 139 */     return (moduleBinding != null) ? this.resolver.getModuleBinding(moduleBinding) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 144 */     if (this.name == null) {
/* 145 */       computeNameAndComponents();
/*     */     }
/* 147 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUnnamed() {
/* 152 */     return getName().equals(UNNAMED);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getNameComponents() {
/* 157 */     if (this.components == null) {
/* 158 */       computeNameAndComponents();
/*     */     }
/* 160 */     return this.components;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getKind() {
/* 165 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getModifiers() {
/* 170 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDeprecated() {
/* 175 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRecovered() {
/* 183 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSynthetic() {
/* 191 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public IJavaElement getJavaElement() {
/* 196 */     INameEnvironment nameEnvironment = this.binding.environment.nameEnvironment;
/* 197 */     if (!(nameEnvironment instanceof SearchableEnvironment)) return null;
/*     */     
/* 199 */     NameLookup nameLookup = ((SearchableEnvironment)nameEnvironment).nameLookup;
/* 200 */     if (nameLookup == null) return null; 
/* 201 */     IPackageFragment[] arrayOfIPackageFragment = nameLookup.findPackageFragments(getName(), false);
/* 202 */     if (arrayOfIPackageFragment == null) return null; 
/* 203 */     if (arrayOfIPackageFragment.length == 0) {
/*     */       
/* 205 */       Util.log(
/* 206 */           (IStatus)new Status(
/* 207 */             2, 
/* 208 */             "org.eclipse.jdt.core", 
/* 209 */             "Searching for package " + getName() + " returns an empty array"));
/* 210 */       return null;
/*     */     } 
/* 212 */     return (IJavaElement)arrayOfIPackageFragment[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 217 */     return new String(this.binding.computeUniqueKey());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEqualTo(IBinding other) {
/* 222 */     if (other == this)
/*     */     {
/* 224 */       return true;
/*     */     }
/* 226 */     if (other == null)
/*     */     {
/* 228 */       return false;
/*     */     }
/* 230 */     if (!(other instanceof PackageBinding)) {
/* 231 */       return false;
/*     */     }
/* 233 */     org.eclipse.jdt.internal.compiler.lookup.PackageBinding packageBinding2 = ((PackageBinding)other).binding;
/* 234 */     return CharOperation.equals(this.binding.compoundName, packageBinding2.compoundName);
/*     */   }
/*     */   
/*     */   private void computeNameAndComponents() {
/* 238 */     char[][] compoundName = this.binding.compoundName;
/* 239 */     if (compoundName == CharOperation.NO_CHAR_CHAR || compoundName == null) {
/* 240 */       this.name = UNNAMED;
/* 241 */       this.components = NO_NAME_COMPONENTS;
/*     */     } else {
/* 243 */       int length = compoundName.length;
/* 244 */       this.components = new String[length];
/* 245 */       StringBuilder buffer = new StringBuilder();
/* 246 */       for (int i = 0; i < length - 1; i++) {
/* 247 */         this.components[i] = new String(compoundName[i]);
/* 248 */         buffer.append(compoundName[i]).append('.');
/*     */       } 
/* 250 */       this.components[length - 1] = new String(compoundName[length - 1]);
/* 251 */       buffer.append(compoundName[length - 1]);
/* 252 */       this.name = buffer.toString();
/*     */     } 
/*     */   }
/*     */   
/*     */   org.eclipse.jdt.internal.compiler.lookup.PackageBinding getCompilerBinding() {
/* 257 */     return this.binding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 266 */     return this.binding.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\PackageBinding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */