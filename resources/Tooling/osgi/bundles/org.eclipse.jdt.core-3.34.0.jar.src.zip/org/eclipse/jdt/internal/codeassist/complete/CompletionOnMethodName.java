/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.CompilationResult;
/*    */ import org.eclipse.jdt.internal.compiler.ast.MethodDeclaration;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.ClassScope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnMethodName
/*    */   extends MethodDeclaration
/*    */ {
/*    */   public int selectorEnd;
/*    */   
/*    */   public CompletionOnMethodName(CompilationResult compilationResult) {
/* 24 */     super(compilationResult);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public StringBuffer print(int indent, StringBuffer output) {
/* 30 */     printIndent(indent, output);
/* 31 */     output.append("<CompletionOnMethodName:");
/* 32 */     printModifiers(this.modifiers, output);
/* 33 */     printReturnType(0, output);
/* 34 */     output.append(this.selector).append('(');
/* 35 */     if (this.arguments != null) {
/* 36 */       for (int i = 0; i < this.arguments.length; i++) {
/* 37 */         if (i > 0) output.append(", "); 
/* 38 */         this.arguments[i].print(0, output);
/*    */       } 
/*    */     }
/* 41 */     output.append(')');
/* 42 */     if (this.thrownExceptions != null) {
/* 43 */       output.append(" throws ");
/* 44 */       for (int i = 0; i < this.thrownExceptions.length; i++) {
/* 45 */         if (i > 0) output.append(", "); 
/* 46 */         this.thrownExceptions[i].print(0, output);
/*    */       } 
/*    */     } 
/* 49 */     return output.append('>');
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void resolve(ClassScope upperScope) {
/* 55 */     super.resolve(upperScope);
/* 56 */     throw new CompletionNodeFound(this, upperScope);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnMethodName.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */