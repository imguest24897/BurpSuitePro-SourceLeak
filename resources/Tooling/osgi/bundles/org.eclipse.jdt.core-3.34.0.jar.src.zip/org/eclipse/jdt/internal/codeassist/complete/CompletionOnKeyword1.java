/*    */ package org.eclipse.jdt.internal.codeassist.complete;
/*    */ 
/*    */ import org.eclipse.jdt.internal.compiler.ast.SingleTypeReference;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.Scope;
/*    */ import org.eclipse.jdt.internal.compiler.lookup.TypeBinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompletionOnKeyword1
/*    */   extends SingleTypeReference
/*    */   implements CompletionOnKeyword
/*    */ {
/*    */   private char[][] possibleKeywords;
/*    */   
/*    */   public CompletionOnKeyword1(char[] token, long pos, char[] possibleKeyword) {
/* 24 */     this(token, pos, new char[][] { possibleKeyword });
/*    */   }
/*    */   public CompletionOnKeyword1(char[] token, long pos, char[][] possibleKeywords) {
/* 27 */     super(token, pos);
/* 28 */     this.possibleKeywords = possibleKeywords;
/*    */   }
/*    */   
/*    */   public char[] getToken() {
/* 32 */     return this.token;
/*    */   }
/*    */   
/*    */   public char[][] getPossibleKeywords() {
/* 36 */     return this.possibleKeywords;
/*    */   }
/*    */   
/*    */   public void aboutToResolve(Scope scope) {
/* 40 */     getTypeBinding(scope);
/*    */   }
/*    */   
/*    */   protected TypeBinding getTypeBinding(Scope scope) {
/* 44 */     throw new CompletionNodeFound(this, scope);
/*    */   }
/*    */ 
/*    */   
/*    */   public StringBuffer printExpression(int indent, StringBuffer output) {
/* 49 */     return output.append("<CompleteOnKeyword:").append(this.token).append('>');
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\internal\codeassist\complete\CompletionOnKeyword1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */