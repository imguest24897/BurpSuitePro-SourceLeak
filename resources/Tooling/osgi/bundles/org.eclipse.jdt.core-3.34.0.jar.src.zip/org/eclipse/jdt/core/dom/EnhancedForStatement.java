/*     */ package org.eclipse.jdt.core.dom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnhancedForStatement
/*     */   extends Statement
/*     */ {
/*  42 */   public static final ChildPropertyDescriptor PARAMETER_PROPERTY = new ChildPropertyDescriptor(EnhancedForStatement.class, "parameter", SingleVariableDeclaration.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   public static final ChildPropertyDescriptor EXPRESSION_PROPERTY = new ChildPropertyDescriptor(EnhancedForStatement.class, "expression", Expression.class, true, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final ChildPropertyDescriptor BODY_PROPERTY = new ChildPropertyDescriptor(EnhancedForStatement.class, "body", Statement.class, true, true);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final List PROPERTY_DESCRIPTORS;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  64 */     List properyList = new ArrayList(4);
/*  65 */     createPropertyList(EnhancedForStatement.class, properyList);
/*  66 */     addProperty(PARAMETER_PROPERTY, properyList);
/*  67 */     addProperty(EXPRESSION_PROPERTY, properyList);
/*  68 */     addProperty(BODY_PROPERTY, properyList);
/*  69 */     PROPERTY_DESCRIPTORS = reapPropertyList(properyList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List propertyDescriptors(int apiLevel) {
/*  83 */     return PROPERTY_DESCRIPTORS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   private SingleVariableDeclaration parameter = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   private Expression expression = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   private Statement body = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   EnhancedForStatement(AST ast) {
/* 112 */     super(ast);
/* 113 */     unsupportedIn2();
/*     */   }
/*     */ 
/*     */   
/*     */   final List internalStructuralPropertiesForType(int apiLevel) {
/* 118 */     return propertyDescriptors(apiLevel);
/*     */   }
/*     */ 
/*     */   
/*     */   final ASTNode internalGetSetChildProperty(ChildPropertyDescriptor property, boolean get, ASTNode child) {
/* 123 */     if (property == PARAMETER_PROPERTY) {
/* 124 */       if (get) {
/* 125 */         return getParameter();
/*     */       }
/* 127 */       setParameter((SingleVariableDeclaration)child);
/* 128 */       return null;
/*     */     } 
/*     */     
/* 131 */     if (property == EXPRESSION_PROPERTY) {
/* 132 */       if (get) {
/* 133 */         return getExpression();
/*     */       }
/* 135 */       setExpression((Expression)child);
/* 136 */       return null;
/*     */     } 
/*     */     
/* 139 */     if (property == BODY_PROPERTY) {
/* 140 */       if (get) {
/* 141 */         return getBody();
/*     */       }
/* 143 */       setBody((Statement)child);
/* 144 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 148 */     return super.internalGetSetChildProperty(property, get, child);
/*     */   }
/*     */ 
/*     */   
/*     */   final int getNodeType0() {
/* 153 */     return 70;
/*     */   }
/*     */ 
/*     */   
/*     */   ASTNode clone0(AST target) {
/* 158 */     EnhancedForStatement result = new EnhancedForStatement(target);
/* 159 */     result.setSourceRange(getStartPosition(), getLength());
/* 160 */     result.copyLeadingComment(this);
/* 161 */     result.setParameter((SingleVariableDeclaration)getParameter().clone(target));
/* 162 */     result.setExpression((Expression)getExpression().clone(target));
/* 163 */     result.setBody(
/* 164 */         (Statement)ASTNode.copySubtree(target, getBody()));
/* 165 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean subtreeMatch0(ASTMatcher matcher, Object other) {
/* 171 */     return matcher.match(this, other);
/*     */   }
/*     */ 
/*     */   
/*     */   void accept0(ASTVisitor visitor) {
/* 176 */     boolean visitChildren = visitor.visit(this);
/* 177 */     if (visitChildren) {
/*     */       
/* 179 */       acceptChild(visitor, getParameter());
/* 180 */       acceptChild(visitor, getExpression());
/* 181 */       acceptChild(visitor, getBody());
/*     */     } 
/* 183 */     visitor.endVisit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SingleVariableDeclaration getParameter() {
/* 192 */     if (this.parameter == null)
/*     */     {
/* 194 */       synchronized (this) {
/* 195 */         if (this.parameter == null) {
/* 196 */           preLazyInit();
/* 197 */           this.parameter = this.ast.newSingleVariableDeclaration();
/* 198 */           postLazyInit(this.parameter, PARAMETER_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 202 */     return this.parameter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameter(SingleVariableDeclaration parameter) {
/* 216 */     if (parameter == null) {
/* 217 */       throw new IllegalArgumentException();
/*     */     }
/* 219 */     ASTNode oldChild = this.parameter;
/* 220 */     preReplaceChild(oldChild, parameter, PARAMETER_PROPERTY);
/* 221 */     this.parameter = parameter;
/* 222 */     postReplaceChild(oldChild, parameter, PARAMETER_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression() {
/* 231 */     if (this.expression == null)
/*     */     {
/* 233 */       synchronized (this) {
/* 234 */         if (this.expression == null) {
/* 235 */           preLazyInit();
/* 236 */           this.expression = new SimpleName(this.ast);
/* 237 */           postLazyInit(this.expression, EXPRESSION_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 241 */     return this.expression;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpression(Expression expression) {
/* 256 */     if (expression == null) {
/* 257 */       throw new IllegalArgumentException();
/*     */     }
/* 259 */     ASTNode oldChild = this.expression;
/* 260 */     preReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/* 261 */     this.expression = expression;
/* 262 */     postReplaceChild(oldChild, expression, EXPRESSION_PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Statement getBody() {
/* 271 */     if (this.body == null)
/*     */     {
/* 273 */       synchronized (this) {
/* 274 */         if (this.body == null) {
/* 275 */           preLazyInit();
/* 276 */           this.body = new Block(this.ast);
/* 277 */           postLazyInit(this.body, BODY_PROPERTY);
/*     */         } 
/*     */       } 
/*     */     }
/* 281 */     return this.body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBody(Statement statement) {
/* 296 */     if (statement == null) {
/* 297 */       throw new IllegalArgumentException();
/*     */     }
/* 299 */     ASTNode oldChild = this.body;
/* 300 */     preReplaceChild(oldChild, statement, BODY_PROPERTY);
/* 301 */     this.body = statement;
/* 302 */     postReplaceChild(oldChild, statement, BODY_PROPERTY);
/*     */   }
/*     */ 
/*     */   
/*     */   int memSize() {
/* 307 */     return super.memSize() + 12;
/*     */   }
/*     */ 
/*     */   
/*     */   int treeSize() {
/* 312 */     return 
/* 313 */       memSize() + (
/* 314 */       (this.parameter == null) ? 0 : getParameter().treeSize()) + (
/* 315 */       (this.expression == null) ? 0 : getExpression().treeSize()) + (
/* 316 */       (this.body == null) ? 0 : getBody().treeSize());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.core-3.34.0.jar!\org\eclipse\jdt\core\dom\EnhancedForStatement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */