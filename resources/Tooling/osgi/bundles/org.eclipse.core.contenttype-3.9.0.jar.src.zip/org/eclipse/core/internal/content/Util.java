/*     */ package org.eclipse.core.internal.content;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Util
/*     */ {
/*     */   public static String[] parseItems(String string) {
/*  23 */     return parseItems(string, ",");
/*     */   }
/*     */   
/*     */   public static String[] parseItems(String string, String separator) {
/*  27 */     if (string == null)
/*  28 */       return new String[0]; 
/*  29 */     StringTokenizer tokenizer = new StringTokenizer(string, separator, true);
/*  30 */     if (!tokenizer.hasMoreTokens())
/*  31 */       return new String[] { string.trim() }; 
/*  32 */     String first = tokenizer.nextToken().trim();
/*  33 */     boolean wasSeparator = false;
/*  34 */     if (first.equals(separator)) {
/*     */       
/*  36 */       first = "";
/*  37 */       wasSeparator = true;
/*     */     } 
/*     */     
/*  40 */     if (!tokenizer.hasMoreTokens()) {
/*  41 */       (new String[2])[0] = first; (new String[2])[1] = first; (new String[1])[0] = first; return wasSeparator ? new String[2] : new String[1];
/*  42 */     }  ArrayList<String> items = new ArrayList<>();
/*  43 */     items.add(first);
/*     */     
/*     */     while (true) {
/*  46 */       String current = tokenizer.nextToken().trim();
/*  47 */       boolean isSeparator = current.equals(separator);
/*  48 */       if (isSeparator) {
/*  49 */         if (wasSeparator)
/*  50 */           items.add(""); 
/*     */       } else {
/*  52 */         items.add(current);
/*  53 */       }  wasSeparator = isSeparator;
/*  54 */       if (!tokenizer.hasMoreTokens()) {
/*  55 */         if (wasSeparator)
/*     */         {
/*  57 */           items.add(""); } 
/*  58 */         return items.<String>toArray(new String[items.size()]);
/*     */       } 
/*     */     } 
/*     */   } public static List<String> parseItemsIntoList(String string) {
/*  62 */     return parseItemsIntoList(string, ",");
/*     */   }
/*     */   
/*     */   public static List<String> parseItemsIntoList(String string, String separator) {
/*  66 */     List<String> items = new ArrayList<>(5);
/*  67 */     if (string == null)
/*  68 */       return items; 
/*  69 */     StringTokenizer tokenizer = new StringTokenizer(string, separator, true);
/*  70 */     if (!tokenizer.hasMoreTokens()) {
/*  71 */       items.add(string.trim());
/*  72 */       return items;
/*     */     } 
/*  74 */     String first = tokenizer.nextToken().trim();
/*  75 */     boolean wasSeparator = false;
/*  76 */     if (first.equals(separator)) {
/*     */       
/*  78 */       first = "";
/*  79 */       wasSeparator = true;
/*     */     } 
/*  81 */     items.add(first);
/*  82 */     if (!tokenizer.hasMoreTokens()) {
/*  83 */       return items;
/*     */     }
/*     */     while (true) {
/*  86 */       String current = tokenizer.nextToken().trim();
/*  87 */       boolean isSeparator = current.equals(separator);
/*  88 */       if (isSeparator) {
/*  89 */         if (wasSeparator)
/*  90 */           items.add(""); 
/*     */       } else {
/*  92 */         items.add(current);
/*  93 */       }  wasSeparator = isSeparator;
/*  94 */       if (!tokenizer.hasMoreTokens()) {
/*  95 */         if (wasSeparator)
/*     */         {
/*  97 */           items.add(""); } 
/*  98 */         return items;
/*     */       } 
/*     */     } 
/*     */   } public static String toListString(Object[] list) {
/* 102 */     return toListString(list, ",");
/*     */   }
/*     */   
/*     */   public static String toListString(Object[] list, String separator) {
/* 106 */     if (list == null || list.length == 0)
/* 107 */       return null; 
/* 108 */     StringBuilder result = new StringBuilder(); byte b; int i; Object[] arrayOfObject;
/* 109 */     for (i = (arrayOfObject = list).length, b = 0; b < i; ) { Object element = arrayOfObject[b];
/* 110 */       result.append(element);
/* 111 */       result.append(separator);
/*     */       b++; }
/*     */     
/* 114 */     return result.substring(0, result.length() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getByteOrderMark(InputStream input) throws IOException {
/* 122 */     int second, third, first = input.read();
/* 123 */     switch (first) {
/*     */       
/*     */       case 239:
/* 126 */         second = input.read();
/* 127 */         third = input.read();
/* 128 */         if (second == 187 && third == 191) {
/* 129 */           return IContentDescription.BOM_UTF_8;
/*     */         }
/*     */         break;
/*     */       case 254:
/* 133 */         if (input.read() == 255)
/* 134 */           return IContentDescription.BOM_UTF_16BE; 
/*     */         break;
/*     */       case 255:
/* 137 */         if (input.read() == 254) {
/* 138 */           return IContentDescription.BOM_UTF_16LE;
/*     */         }
/*     */         break;
/*     */     } 
/*     */     
/* 143 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\Util.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */