/*     */ package org.eclipse.core.internal.content;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.IRegistryChangeEvent;
/*     */ import org.eclipse.core.runtime.IRegistryChangeListener;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.InvalidRegistryObjectException;
/*     */ import org.eclipse.core.runtime.ListenerList;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.core.runtime.ServiceCaller;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ import org.eclipse.core.runtime.content.IContentTypeManager;
/*     */ import org.eclipse.core.runtime.content.IContentTypeMatcher;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*     */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*     */ import org.eclipse.osgi.service.debug.DebugOptions;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ 
/*     */ public class ContentTypeManager extends ContentTypeMatcher implements IContentTypeManager {
/*     */   private static class ContentTypeRegistryChangeListener implements IRegistryChangeListener {
/*     */     public void registryChanged(IRegistryChangeEvent event) {
/*  33 */       if ((event.getExtensionDeltas("org.eclipse.core.runtime", "contentTypes")).length == 0)
/*  34 */         if ((event.getExtensionDeltas("org.eclipse.core.contenttype", 
/*  35 */             "contentTypes")).length == 0)
/*     */           return;  
/*  37 */       ContentTypeManager.getInstance().invalidate();
/*     */     }
/*     */   }
/*     */   
/*  41 */   private static IRegistryChangeListener runtimeExtensionListener = new ContentTypeRegistryChangeListener();
/*  42 */   private static IRegistryChangeListener contentExtensionListener = new ContentTypeRegistryChangeListener();
/*     */   
/*     */   private static volatile ContentTypeManager instance;
/*     */   
/*     */   public static final int BLOCK_SIZE = 1024;
/*     */   
/*     */   public static final String CONTENT_TYPE_PREF_NODE = "org.eclipse.core.runtime/content-types";
/*     */   
/*     */   private static final String OPTION_DEBUG_CONTENT_TYPES = "org.eclipse.core.contenttype/debug";
/*     */   
/*     */   private ContentTypeCatalog catalog;
/*     */   private int catalogGeneration;
/*     */   
/*     */   static class DebuggingHolder
/*     */   {
/*     */     static final boolean DEBUGGING;
/*     */     
/*     */     static {
/*  60 */       boolean[] debugging = new boolean[1];
/*  61 */       ServiceCaller.callOnce(DebuggingHolder.class, DebugOptions.class, debugOptions -> param1ArrayOfboolean[0] = debugOptions.getBooleanOption("org.eclipse.core.contenttype/debug", false));
/*     */ 
/*     */ 
/*     */       
/*  65 */       DEBUGGING = debugging[0];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   protected final ListenerList<IContentTypeManager.IContentTypeChangeListener> contentTypeListeners = new ListenerList();
/*     */ 
/*     */   
/*     */   public void addRegistryChangeListener(IExtensionRegistry registry) {
/*  79 */     if (registry == null) {
/*     */       return;
/*     */     }
/*     */     
/*  83 */     registry.addRegistryChangeListener(runtimeExtensionListener, "org.eclipse.core.runtime");
/*  84 */     registry.addRegistryChangeListener(contentExtensionListener, "org.eclipse.core.contenttype");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void shutdown() {
/*  93 */     instance = null;
/*     */   }
/*     */   
/*     */   public void removeRegistryChangeListener(IExtensionRegistry registry) {
/*  97 */     if (registry == null)
/*     */       return; 
/*  99 */     getInstance().invalidate();
/* 100 */     registry.removeRegistryChangeListener(runtimeExtensionListener);
/* 101 */     registry.removeRegistryChangeListener(contentExtensionListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ContentTypeManager getInstance() {
/* 112 */     if (instance == null) {
/* 113 */       synchronized (ContentTypeManager.class) {
/* 114 */         if (instance == null) {
/* 115 */           instance = new ContentTypeManager();
/*     */         }
/*     */       } 
/*     */     }
/* 119 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getFileExtension(String fileName) {
/* 126 */     int dotPosition = fileName.lastIndexOf('.');
/* 127 */     return (dotPosition == -1 || dotPosition == fileName.length() - 1) ? "" : fileName.substring(dotPosition + 1);
/*     */   }
/*     */   
/*     */   protected static ILazySource readBuffer(InputStream contents) {
/* 131 */     return new LazyInputStream(contents, 1024);
/*     */   }
/*     */   
/*     */   protected static ILazySource readBuffer(Reader contents) {
/* 135 */     return new LazyReader(contents, 1024);
/*     */   }
/*     */   
/*     */   public ContentTypeManager() {
/* 139 */     super(null, InstanceScope.INSTANCE);
/* 140 */     instance = this;
/*     */   }
/*     */   
/*     */   protected ContentTypeBuilder createBuilder(ContentTypeCatalog newCatalog) {
/* 144 */     return new ContentTypeBuilder(newCatalog);
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentType[] getAllContentTypes() {
/* 149 */     ContentTypeCatalog currentCatalog = getCatalog();
/* 150 */     IContentType[] types = currentCatalog.getAllContentTypes();
/* 151 */     IContentType[] result = new IContentType[types.length];
/* 152 */     int generation = currentCatalog.getGeneration();
/* 153 */     for (int i = 0; i < result.length; i++)
/* 154 */       result[i] = new ContentTypeHandler((ContentType)types[i], generation); 
/* 155 */     return result;
/*     */   }
/*     */   
/*     */   protected synchronized ContentTypeCatalog getCatalog() {
/* 159 */     if (this.catalog != null)
/*     */     {
/* 161 */       return this.catalog;
/*     */     }
/* 163 */     ContentTypeCatalog newCatalog = new ContentTypeCatalog(this, this.catalogGeneration++);
/*     */     
/* 165 */     ContentTypeBuilder builder = createBuilder(newCatalog);
/*     */     try {
/* 167 */       builder.buildCatalog(getContext());
/*     */       
/* 169 */       this.catalog = newCatalog;
/* 170 */     } catch (InvalidRegistryObjectException invalidRegistryObjectException) {}
/*     */ 
/*     */     
/* 173 */     newCatalog.organize();
/* 174 */     return newCatalog;
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentType getContentType(String contentTypeIdentifier) {
/* 179 */     ContentTypeCatalog currentCatalog = getCatalog();
/* 180 */     ContentType type = currentCatalog.getContentType(contentTypeIdentifier);
/* 181 */     return (type == null) ? null : new ContentTypeHandler(type, currentCatalog.getGeneration());
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentTypeMatcher getMatcher(IContentTypeManager.ISelectionPolicy customPolicy, IScopeContext context) {
/* 186 */     return new ContentTypeMatcher(customPolicy, (context == null) ? getContext() : context);
/*     */   }
/*     */   
/*     */   IEclipsePreferences getPreferences() {
/* 190 */     return getPreferences(getContext());
/*     */   }
/*     */   
/*     */   IEclipsePreferences getPreferences(IScopeContext context) {
/* 194 */     return context.getNode("org.eclipse.core.runtime/content-types");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void invalidate() {
/* 201 */     if (DebuggingHolder.DEBUGGING && this.catalog != null)
/* 202 */       ContentMessages.message("Registry discarded"); 
/* 203 */     this.catalog = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addContentTypeChangeListener(IContentTypeManager.IContentTypeChangeListener listener) {
/* 208 */     this.contentTypeListeners.add(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeContentTypeChangeListener(IContentTypeManager.IContentTypeChangeListener listener) {
/* 213 */     this.contentTypeListeners.remove(listener);
/*     */   }
/*     */   
/*     */   public void fireContentTypeChangeEvent(IContentType type) {
/* 217 */     IContentType eventObject = type;
/* 218 */     if (type instanceof ContentType) {
/* 219 */       eventObject = new ContentTypeHandler((ContentType)type, ((ContentType)type).getCatalog().getGeneration());
/*     */     } else {
/* 221 */       eventObject = type;
/*     */     } 
/* 223 */     for (IContentTypeManager.IContentTypeChangeListener listener : this.contentTypeListeners) {
/* 224 */       final IContentTypeManager.ContentTypeChangeEvent event = new IContentTypeManager.ContentTypeChangeEvent(eventObject);
/* 225 */       ISafeRunnable job = new ISafeRunnable()
/*     */         {
/*     */           public void handleException(Throwable exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void run() throws Exception {
/* 233 */             listener.contentTypeChanged(event);
/*     */           }
/*     */         };
/* 236 */       SafeRunner.run(job);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IContentDescription getSpecificDescription(BasicDescription description) {
/* 243 */     return description;
/*     */   }
/*     */ 
/*     */   
/*     */   public final void removeContentType(String contentTypeIdentifier) throws CoreException {
/* 248 */     if (contentTypeIdentifier == null) {
/*     */       return;
/*     */     }
/* 251 */     IContentType contentType = getContentType(contentTypeIdentifier);
/* 252 */     if (contentType == null) {
/*     */       return;
/*     */     }
/* 255 */     if (!contentType.isUserDefined()) {
/* 256 */       throw new IllegalArgumentException("Can only delete content-types defined by users.");
/*     */     }
/* 258 */     getCatalog().removeContentType(contentType.getId());
/*     */     
/* 260 */     List<String> userDefinedIds = new ArrayList<>(Arrays.asList(getUserDefinedContentTypeIds()));
/* 261 */     userDefinedIds.remove(contentType.getId());
/* 262 */     getContext().getNode("userDefined").put("userDefined", 
/* 263 */         userDefinedIds.stream().collect(Collectors.joining(",")));
/*     */     try {
/* 265 */       getContext().getNode("userDefined").flush();
/* 266 */     } catch (BackingStoreException e) {
/* 267 */       String message = NLS.bind(ContentMessages.content_errorSavingSettings, contentType.getId());
/* 268 */       Status status = new Status(4, "org.eclipse.core.contenttype", 0, message, (Throwable)e);
/* 269 */       throw new CoreException(status);
/*     */     } 
/* 271 */     getCatalog().organize();
/* 272 */     fireContentTypeChangeEvent(contentType);
/*     */   }
/*     */ 
/*     */   
/*     */   public final IContentType addContentType(String id, String name, IContentType baseType) throws CoreException {
/* 277 */     if (id == null) {
/* 278 */       throw new IllegalArgumentException("Content-type 'id' mustn't be null");
/*     */     }
/* 280 */     if (id.contains(",")) {
/* 281 */       throw new IllegalArgumentException(
/* 282 */           "Content-Type id mustn't contain ','");
/*     */     }
/* 284 */     if (getContentType(id) != null) {
/* 285 */       throw new IllegalArgumentException("Content-type '" + id + "' already exists.");
/*     */     }
/* 287 */     ContentType contentType = ContentType.createContentType(getCatalog(), id, name, (byte)0, new String[0], 
/* 288 */         new String[0], new String[0], (baseType != null) ? baseType.getId() : null, null, null, null);
/* 289 */     getCatalog().addContentType(contentType);
/*     */     
/* 291 */     String currentUserDefined = getContext().getNode("userDefined")
/* 292 */       .get("userDefined", "");
/* 293 */     if (!currentUserDefined.isEmpty()) {
/* 294 */       currentUserDefined = String.valueOf(currentUserDefined) + ",";
/*     */     }
/* 296 */     getContext().getNode("userDefined").put("userDefined", String.valueOf(currentUserDefined) + id);
/* 297 */     contentType.setValidation((byte)0);
/* 298 */     IEclipsePreferences contextTypeNode = getContext().getNode(contentType.getId());
/* 299 */     contextTypeNode.put("name", name);
/* 300 */     if (baseType != null) {
/* 301 */       contextTypeNode.put("baseTypeId", baseType.getId());
/*     */     }
/*     */     try {
/* 304 */       getContext().getNode("userDefined").flush();
/* 305 */       contextTypeNode.flush();
/* 306 */     } catch (BackingStoreException e) {
/* 307 */       String message = NLS.bind(ContentMessages.content_errorSavingSettings, id);
/* 308 */       Status status = new Status(4, "org.eclipse.core.contenttype", 0, message, (Throwable)e);
/* 309 */       throw new CoreException(status);
/*     */     } 
/* 311 */     getCatalog().organize();
/* 312 */     fireContentTypeChangeEvent(contentType);
/* 313 */     return contentType;
/*     */   }
/*     */   
/*     */   private String[] getUserDefinedContentTypeIds() {
/* 317 */     return getUserDefinedContentTypeIds(getContext());
/*     */   }
/*     */   
/*     */   static String[] getUserDefinedContentTypeIds(IScopeContext context) {
/* 321 */     String ids = context.getNode("userDefined")
/* 322 */       .get("userDefined", "");
/* 323 */     if (ids.isEmpty()) {
/* 324 */       return new String[0];
/*     */     }
/* 326 */     return ids.split(",");
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\ContentTypeManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */