package org.eclipse.core.runtime.content;

import java.io.IOException;
import java.io.Reader;

public interface ITextContentDescriber extends IContentDescriber {
  int describe(Reader paramReader, IContentDescription paramIContentDescription) throws IOException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\runtime\content\ITextContentDescriber.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */