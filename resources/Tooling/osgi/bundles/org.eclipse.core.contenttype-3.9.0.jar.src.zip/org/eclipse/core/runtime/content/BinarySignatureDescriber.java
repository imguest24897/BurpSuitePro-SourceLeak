/*     */ package org.eclipse.core.runtime.content;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import org.eclipse.core.internal.content.ContentMessages;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExecutableExtension;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BinarySignatureDescriber
/*     */   implements IContentDescriber, IExecutableExtension
/*     */ {
/*     */   private static final String SIGNATURE = "signature";
/*     */   private static final String OFFSET = "offset";
/*  59 */   private static final Object REQUIRED = "required";
/*     */   
/*     */   private byte[] signature;
/*     */   
/*     */   private int offset;
/*     */   
/*     */   private boolean required = true;
/*     */ 
/*     */   
/*     */   public int describe(InputStream contents, IContentDescription description) throws IOException {
/*  69 */     byte[] buffer = new byte[this.signature.length];
/*  70 */     int notValid = this.required ? 0 : 1;
/*  71 */     if (contents.skip(this.offset) < this.offset)
/*  72 */       return notValid; 
/*  73 */     if (contents.read(buffer) != buffer.length)
/*  74 */       return notValid; 
/*  75 */     for (int i = 0; i < this.signature.length; i++) {
/*  76 */       if (this.signature[i] != buffer[i])
/*  77 */         return notValid; 
/*  78 */     }  return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public QualifiedName[] getSupportedOptions() {
/*  83 */     return new QualifiedName[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInitializationData(IConfigurationElement config, String propertyName, Object data) throws CoreException {
/*     */     try {
/*  89 */       if (data instanceof String) {
/*  90 */         this.signature = parseSignature((String)data);
/*  91 */       } else if (data instanceof Hashtable) {
/*  92 */         Hashtable<?, ?> parameters = (Hashtable<?, ?>)data;
/*  93 */         if (!parameters.containsKey("signature")) {
/*  94 */           String message = NLS.bind(ContentMessages.content_badInitializationData, BinarySignatureDescriber.class.getName());
/*  95 */           throw new CoreException(new Status(4, "org.eclipse.core.contenttype", 0, message, null));
/*     */         } 
/*  97 */         this.signature = parseSignature((String)parameters.get("signature"));
/*  98 */         if (parameters.containsKey("offset"))
/*  99 */           this.offset = Integer.parseInt((String)parameters.get("offset")); 
/* 100 */         if (parameters.containsKey(REQUIRED))
/* 101 */           this.required = Boolean.parseBoolean((String)parameters.get(REQUIRED)); 
/*     */       } 
/* 103 */     } catch (NumberFormatException nfe) {
/* 104 */       String message = NLS.bind(ContentMessages.content_badInitializationData, BinarySignatureDescriber.class.getName());
/* 105 */       throw new CoreException(new Status(4, "org.eclipse.core.contenttype", 0, message, nfe));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static byte[] parseSignature(String data) {
/* 110 */     List<Byte> bytes = new ArrayList<>();
/* 111 */     StringTokenizer tokenizer = new StringTokenizer(data, " \t\n\r\f,");
/* 112 */     while (tokenizer.hasMoreTokens())
/* 113 */       bytes.add(Byte.valueOf((byte)Integer.parseInt(tokenizer.nextToken().trim(), 16))); 
/* 114 */     byte[] signature = new byte[bytes.size()];
/* 115 */     for (int i = 0; i < signature.length; i++)
/* 116 */       signature[i] = ((Byte)bytes.get(i)).byteValue(); 
/* 117 */     return signature;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\runtime\content\BinarySignatureDescriber.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */