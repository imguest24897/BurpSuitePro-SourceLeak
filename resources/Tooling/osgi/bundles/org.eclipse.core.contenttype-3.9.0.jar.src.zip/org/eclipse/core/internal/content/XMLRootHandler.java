/*     */ package org.eclipse.core.internal.content;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.eclipse.core.runtime.ServiceCaller;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXNotRecognizedException;
/*     */ import org.xml.sax.SAXNotSupportedException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.ext.LexicalHandler;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XMLRootHandler
/*     */   extends DefaultHandler
/*     */   implements LexicalHandler
/*     */ {
/*     */   private boolean checkRoot;
/*     */   
/*     */   private static class StopParsingException
/*     */     extends SAXException
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     public StopParsingException() {
/*  52 */       super((String)null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   private String dtdFound = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private String elementFound = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private String namespaceFound = null;
/*     */   
/*     */   public XMLRootHandler(boolean checkRoot) {
/*  81 */     this.checkRoot = checkRoot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void comment(char[] ch, int start, int length) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SAXParser createParser(SAXParserFactory parserFactory) throws ParserConfigurationException, SAXException, SAXNotRecognizedException, SAXNotSupportedException {
/* 107 */     SAXParser parser = parserFactory.newSAXParser();
/* 108 */     XMLReader reader = parser.getXMLReader();
/* 109 */     reader.setProperty("http://xml.org/sax/properties/lexical-handler", this);
/*     */ 
/*     */     
/*     */     try {
/* 113 */       reader.setFeature("http://xml.org/sax/features/validation", false);
/* 114 */       reader.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
/* 115 */     } catch (SAXNotRecognizedException|SAXNotSupportedException sAXNotRecognizedException) {}
/*     */ 
/*     */     
/* 118 */     return parser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endCDATA() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void endDTD() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void endEntity(String name) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDTD() {
/* 137 */     return this.dtdFound;
/*     */   }
/*     */   
/*     */   public String getRootName() {
/* 141 */     return this.elementFound;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRootNamespace() {
/* 148 */     return this.namespaceFound;
/*     */   }
/*     */ 
/*     */   
/*     */   static <E extends Throwable> void sneakyThrow(Throwable e) throws E {
/* 153 */     throw (E)e;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean parseContents(InputSource contents) throws IOException, ParserConfigurationException, SAXException {
/* 158 */     return ServiceCaller.callOnce(getClass(), SAXParserFactory.class, factory -> {
/*     */           try {
/*     */             factory.setNamespaceAware(true);
/*     */             
/*     */             SAXParser parser = createParser(factory);
/*     */             paramInputSource.setSystemId("/");
/*     */             parser.parse(paramInputSource, this);
/* 165 */           } catch (StopParsingException stopParsingException) {
/*     */           
/* 167 */           } catch (SAXException|IOException|ParserConfigurationException e) {
/*     */             sneakyThrow(e);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputSource resolveEntity(String publicId, String systemId) throws SAXException {
/* 181 */     return new InputSource(new StringReader(""));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startCDATA() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void startDTD(String name, String publicId, String systemId) throws SAXException {
/* 191 */     this.dtdFound = systemId;
/*     */     
/* 193 */     if (!this.checkRoot) {
/* 194 */       throw new StopParsingException();
/*     */     }
/*     */   }
/*     */   
/*     */   public void startElement(String uri, String elementName, String qualifiedName, Attributes attributes) throws SAXException {
/* 199 */     this.elementFound = elementName;
/* 200 */     this.namespaceFound = uri;
/* 201 */     throw new StopParsingException();
/*     */   }
/*     */   
/*     */   public void startEntity(String name) {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\XMLRootHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */