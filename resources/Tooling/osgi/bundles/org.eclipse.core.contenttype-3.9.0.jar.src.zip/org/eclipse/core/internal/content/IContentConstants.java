package org.eclipse.core.internal.content;

public interface IContentConstants {
  public static final String RUNTIME_NAME = "org.eclipse.core.runtime";
  
  public static final String CONTENT_NAME = "org.eclipse.core.contenttype";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\IContentConstants.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */