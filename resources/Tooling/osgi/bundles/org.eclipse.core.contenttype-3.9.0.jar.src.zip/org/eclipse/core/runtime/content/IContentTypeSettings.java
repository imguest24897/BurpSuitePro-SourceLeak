package org.eclipse.core.runtime.content;

import org.eclipse.core.runtime.CoreException;

public interface IContentTypeSettings {
  public static final int FILE_EXTENSION_SPEC = 8;
  
  public static final int FILE_NAME_SPEC = 4;
  
  public static final int FILE_PATTERN_SPEC = 16;
  
  void addFileSpec(String paramString, int paramInt) throws CoreException;
  
  String getDefaultCharset();
  
  String[] getFileSpecs(int paramInt);
  
  String getId();
  
  void removeFileSpec(String paramString, int paramInt) throws CoreException;
  
  void setDefaultCharset(String paramString) throws CoreException;
  
  boolean isUserDefined();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\runtime\content\IContentTypeSettings.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */