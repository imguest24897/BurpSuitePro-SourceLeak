/*     */ package org.eclipse.core.runtime.content;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.eclipse.core.internal.content.ContentMessages;
/*     */ import org.eclipse.core.internal.content.XMLRootHandler;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExecutableExtension;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class XMLRootElementContentDescriber2
/*     */   extends XMLContentDescriber
/*     */   implements IExecutableExtension
/*     */ {
/*     */   static final String DTD = "org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.dtd";
/*     */   static final String NAMESPACE = "org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.namespace";
/*     */   static final String ELEMENT = "org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.element";
/*     */   static final String RESULT = "org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.result";
/*     */   private static final String ELEMENT_TO_FIND = "element";
/*  86 */   private QualifiedElement[] elementsToFind = null;
/*     */ 
/*     */   
/*     */   private static class QualifiedElement
/*     */   {
/*     */     private String namespace;
/*     */     
/*     */     private String element;
/*     */     
/*     */     private String dtd;
/*     */     
/*     */     public QualifiedElement(String qualifiedElement) {
/*  98 */       int openBrace = qualifiedElement.indexOf('{');
/*  99 */       int closeBrace = qualifiedElement.indexOf('}');
/* 100 */       if (openBrace == 0 && closeBrace >= 1) {
/* 101 */         this.namespace = qualifiedElement.substring(1, closeBrace);
/* 102 */         qualifiedElement = qualifiedElement.substring(closeBrace + 1);
/*     */       } 
/*     */       
/* 105 */       int dtdSlash = qualifiedElement.indexOf('/');
/* 106 */       if (dtdSlash > 0) {
/* 107 */         this.dtd = qualifiedElement.substring(dtdSlash + 1);
/* 108 */         qualifiedElement = qualifiedElement.substring(0, dtdSlash);
/*     */       } 
/*     */       
/* 111 */       this.element = "*".equals(qualifiedElement) ? null : qualifiedElement;
/*     */     }
/*     */     
/*     */     public boolean matches(String someNamespace, String someElement, String someDtd) {
/* 115 */       boolean nsMatch = (this.namespace != null) ? this.namespace.equals(someNamespace) : true;
/* 116 */       boolean elementEquals = (this.element != null) ? this.element.equals(someElement) : true;
/* 117 */       boolean dtdEquals = (this.dtd != null) ? this.dtd.equals(someDtd) : true;
/* 118 */       return (nsMatch && elementEquals && dtdEquals);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int checkCriteria(InputSource contents, Map<String, Object> properties) throws IOException {
/* 134 */     if (!isProcessed(properties))
/* 135 */       fillContentProperties(contents, properties); 
/* 136 */     return checkCriteria(properties);
/*     */   }
/*     */   
/*     */   private int checkCriteria(Map<String, Object> properties) throws IOException {
/* 140 */     Boolean result = (Boolean)properties.get("org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.result");
/* 141 */     if (!result.booleanValue()) {
/* 142 */       return 1;
/*     */     }
/* 144 */     if (this.elementsToFind != null) {
/* 145 */       boolean foundOne = false;
/* 146 */       for (int i = 0; i < this.elementsToFind.length && !foundOne; i++) {
/* 147 */         String dtd = (String)properties.get("org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.dtd");
/* 148 */         String namespace = (String)properties.get("org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.namespace");
/* 149 */         String element = (String)properties.get("org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.element");
/* 150 */         foundOne |= this.elementsToFind[i].matches(namespace, element, dtd);
/*     */       } 
/* 152 */       if (!foundOne) {
/* 153 */         return 1;
/*     */       }
/*     */     } 
/* 156 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public int describe(InputStream contents, IContentDescription description) throws IOException {
/* 161 */     return describe(contents, description, new HashMap<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int describe(InputStream contents, IContentDescription description, Map<String, Object> properties) throws IOException {
/* 169 */     if (describe2(contents, description, properties) == 0) {
/* 170 */       return 0;
/*     */     }
/* 172 */     contents.reset();
/*     */     
/* 174 */     return checkCriteria(new InputSource(contents), properties);
/*     */   }
/*     */ 
/*     */   
/*     */   public int describe(Reader contents, IContentDescription description) throws IOException {
/* 179 */     return describe(contents, description, new HashMap<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int describe(Reader contents, IContentDescription description, Map<String, Object> properties) throws IOException {
/* 187 */     if (describe2(contents, description, properties) == 0) {
/* 188 */       return 0;
/*     */     }
/* 190 */     contents.reset();
/*     */     
/* 192 */     return checkCriteria(new InputSource(contents), properties);
/*     */   }
/*     */   
/*     */   static boolean isProcessed(Map<String, Object> properties) {
/* 196 */     Boolean result = (Boolean)properties.get("org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.result");
/*     */     
/* 198 */     if (result != null)
/* 199 */       return true; 
/* 200 */     return false;
/*     */   }
/*     */   
/*     */   static void fillContentProperties(InputSource input, Map<String, Object> properties) throws IOException {
/* 204 */     XMLRootHandler xmlHandler = new XMLRootHandler(true);
/*     */     try {
/* 206 */       if (!xmlHandler.parseContents(input)) {
/* 207 */         properties.put("org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.result", Boolean.FALSE);
/*     */         return;
/*     */       } 
/* 210 */     } catch (SAXException sAXException) {
/*     */       
/* 212 */       properties.put("org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.result", Boolean.FALSE);
/*     */       return;
/* 214 */     } catch (ParserConfigurationException e) {
/*     */       
/* 216 */       String message = ContentMessages.content_parserConfiguration;
/* 217 */       RuntimeLog.log((IStatus)new Status(4, "org.eclipse.core.contenttype", 0, message, e));
/* 218 */       throw new RuntimeException(message);
/*     */     } 
/* 220 */     String element = xmlHandler.getRootName();
/* 221 */     if (element != null)
/* 222 */       properties.put("org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.element", element); 
/* 223 */     String dtd = xmlHandler.getDTD();
/* 224 */     if (dtd != null)
/* 225 */       properties.put("org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.dtd", dtd); 
/* 226 */     String namespace = xmlHandler.getRootNamespace();
/* 227 */     if (namespace != null)
/* 228 */       properties.put("org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.namespace", namespace); 
/* 229 */     properties.put("org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.result", Boolean.TRUE);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInitializationData(IConfigurationElement config, String propertyName, Object data) throws CoreException {
/* 234 */     if (data instanceof String) {
/* 235 */       this.elementsToFind = new QualifiedElement[] { new QualifiedElement((String)data) };
/* 236 */     } else if (data instanceof java.util.Hashtable) {
/* 237 */       List<QualifiedElement> elements = null;
/*     */ 
/*     */ 
/*     */       
/* 241 */       IConfigurationElement describerElement = config.getChildren("describer")[0];
/* 242 */       IConfigurationElement[] params = describerElement.getChildren("parameter");
/* 243 */       String pname = null; byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 244 */       for (i = (arrayOfIConfigurationElement1 = params).length, b = 0; b < i; ) { IConfigurationElement param = arrayOfIConfigurationElement1[b];
/* 245 */         pname = param.getAttribute("name");
/* 246 */         if ("element".equals(pname)) {
/* 247 */           if (elements == null)
/* 248 */             elements = new LinkedList<>(); 
/* 249 */           elements.add(new QualifiedElement(param.getAttribute("value")));
/*     */         } 
/*     */         b++; }
/*     */       
/* 253 */       List<QualifiedElement> qualifiedElements = new ArrayList<>();
/*     */ 
/*     */       
/* 256 */       if (elements != null) {
/* 257 */         qualifiedElements.addAll(elements);
/*     */       }
/* 259 */       this.elementsToFind = qualifiedElements.<QualifiedElement>toArray(new QualifiedElement[qualifiedElements.size()]);
/*     */     } 
/*     */     
/* 262 */     if (this.elementsToFind.length == 0) {
/* 263 */       String message = NLS.bind(ContentMessages.content_badInitializationData, XMLRootElementContentDescriber2.class.getName());
/* 264 */       throw new CoreException(new Status(4, "org.eclipse.core.contenttype", 0, message, null));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\runtime\content\XMLRootElementContentDescriber2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */