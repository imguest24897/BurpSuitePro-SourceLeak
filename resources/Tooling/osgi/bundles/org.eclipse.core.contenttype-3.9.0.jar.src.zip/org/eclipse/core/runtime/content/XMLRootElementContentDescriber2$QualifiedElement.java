/*     */ package org.eclipse.core.runtime.content;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class QualifiedElement
/*     */ {
/*     */   private String namespace;
/*     */   private String element;
/*     */   private String dtd;
/*     */   
/*     */   public QualifiedElement(String qualifiedElement) {
/*  98 */     int openBrace = qualifiedElement.indexOf('{');
/*  99 */     int closeBrace = qualifiedElement.indexOf('}');
/* 100 */     if (openBrace == 0 && closeBrace >= 1) {
/* 101 */       this.namespace = qualifiedElement.substring(1, closeBrace);
/* 102 */       qualifiedElement = qualifiedElement.substring(closeBrace + 1);
/*     */     } 
/*     */     
/* 105 */     int dtdSlash = qualifiedElement.indexOf('/');
/* 106 */     if (dtdSlash > 0) {
/* 107 */       this.dtd = qualifiedElement.substring(dtdSlash + 1);
/* 108 */       qualifiedElement = qualifiedElement.substring(0, dtdSlash);
/*     */     } 
/*     */     
/* 111 */     this.element = "*".equals(qualifiedElement) ? null : qualifiedElement;
/*     */   }
/*     */   
/*     */   public boolean matches(String someNamespace, String someElement, String someDtd) {
/* 115 */     boolean nsMatch = (this.namespace != null) ? this.namespace.equals(someNamespace) : true;
/* 116 */     boolean elementEquals = (this.element != null) ? this.element.equals(someElement) : true;
/* 117 */     boolean dtdEquals = (this.dtd != null) ? this.dtd.equals(someDtd) : true;
/* 118 */     return (nsMatch && elementEquals && dtdEquals);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\runtime\content\XMLRootElementContentDescriber2$QualifiedElement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */