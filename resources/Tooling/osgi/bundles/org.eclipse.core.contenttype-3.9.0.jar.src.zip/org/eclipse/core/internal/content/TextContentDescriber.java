/*    */ package org.eclipse.core.internal.content;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.Reader;
/*    */ import org.eclipse.core.runtime.QualifiedName;
/*    */ import org.eclipse.core.runtime.content.IContentDescription;
/*    */ import org.eclipse.core.runtime.content.ITextContentDescriber;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextContentDescriber
/*    */   implements ITextContentDescriber
/*    */ {
/* 34 */   private static final QualifiedName[] SUPPORTED_OPTIONS = new QualifiedName[] { IContentDescription.BYTE_ORDER_MARK };
/*    */ 
/*    */ 
/*    */   
/*    */   public int describe(Reader contents, IContentDescription description) throws IOException {
/* 39 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int describe(InputStream contents, IContentDescription description) throws IOException {
/* 44 */     if (description == null || !description.isRequested(IContentDescription.BYTE_ORDER_MARK))
/* 45 */       return 1; 
/* 46 */     byte[] bom = Util.getByteOrderMark(contents);
/* 47 */     if (bom != null) {
/* 48 */       description.setProperty(IContentDescription.BYTE_ORDER_MARK, bom);
/*    */     }
/* 50 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public QualifiedName[] getSupportedOptions() {
/* 55 */     return SUPPORTED_OPTIONS;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\TextContentDescriber.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */