/*    */ package org.eclipse.core.internal.content;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FileSpec
/*    */ {
/*    */   static final int BASIC_TYPE = 12;
/*    */   private String text;
/*    */   private int type;
/*    */   
/*    */   public FileSpec(String text, int type) {
/* 28 */     this.text = text;
/* 29 */     this.type = type;
/*    */   }
/*    */   
/*    */   public String getText() {
/* 33 */     return this.text;
/*    */   }
/*    */   
/*    */   public int getType() {
/* 37 */     return this.type;
/*    */   }
/*    */   
/*    */   public static int getBasicType(int type) {
/* 41 */     return 0xC & type;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object other) {
/* 46 */     if (!(other instanceof FileSpec))
/* 47 */       return false; 
/* 48 */     FileSpec otherFileSpec = (FileSpec)other;
/* 49 */     return equals(this.text, otherFileSpec.getType(), false);
/*    */   }
/*    */   
/*    */   public boolean equals(String text, int otherType, boolean strict) {
/* 53 */     return (((!strict && getBasicType(this.type) == getBasicType(otherType)) || this.type == otherType) && this.text.equalsIgnoreCase(text));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 58 */     return this.text.hashCode();
/*    */   }
/*    */   
/*    */   public static String getMappingKeyFor(String fileSpecText) {
/* 62 */     return fileSpecText.toLowerCase();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 67 */     return getText();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\FileSpec.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */