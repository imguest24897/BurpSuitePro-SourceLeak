/*    */ package org.eclipse.core.internal.content;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentMessages
/*    */   extends NLS
/*    */ {
/*    */   public static final String OWNER_NAME = "org.eclipse.core.contenttype";
/*    */   private static final String BUNDLE_NAME = "org.eclipse.core.internal.content.messages";
/*    */   public static String content_badInitializationData;
/*    */   public static String content_errorReadingContents;
/*    */   public static String content_errorLoadingSettings;
/*    */   public static String content_errorSavingSettings;
/*    */   public static String content_invalidContentDescriber;
/*    */   public static String content_invalidProperty;
/*    */   public static String content_missingIdentifier;
/*    */   public static String content_missingName;
/*    */   public static String content_parserConfiguration;
/*    */   
/*    */   static {
/* 42 */     reloadMessages();
/*    */   }
/*    */   
/*    */   public static void reloadMessages() {
/* 46 */     NLS.initializeMessages("org.eclipse.core.internal.content.messages", ContentMessages.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void message(String message) {
/* 54 */     StringBuilder buffer = new StringBuilder();
/* 55 */     buffer.append(new Date(System.currentTimeMillis()));
/* 56 */     buffer.append(" - [");
/* 57 */     buffer.append(Thread.currentThread().getName());
/* 58 */     buffer.append("] ");
/* 59 */     buffer.append(message);
/* 60 */     System.out.println(buffer.toString());
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\ContentMessages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */