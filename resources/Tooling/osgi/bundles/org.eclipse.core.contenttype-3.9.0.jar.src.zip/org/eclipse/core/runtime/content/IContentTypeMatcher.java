package org.eclipse.core.runtime.content;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import org.eclipse.core.runtime.QualifiedName;

public interface IContentTypeMatcher {
  IContentType findContentTypeFor(InputStream paramInputStream, String paramString) throws IOException;
  
  IContentType findContentTypeFor(String paramString);
  
  IContentType[] findContentTypesFor(InputStream paramInputStream, String paramString) throws IOException;
  
  IContentType[] findContentTypesFor(String paramString);
  
  IContentDescription getDescriptionFor(InputStream paramInputStream, String paramString, QualifiedName[] paramArrayOfQualifiedName) throws IOException;
  
  IContentDescription getDescriptionFor(Reader paramReader, String paramString, QualifiedName[] paramArrayOfQualifiedName) throws IOException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\runtime\content\IContentTypeMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */