/*    */ package org.eclipse.core.internal.content;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.Reader;
/*    */ import org.eclipse.core.runtime.QualifiedName;
/*    */ import org.eclipse.core.runtime.content.IContentDescriber;
/*    */ import org.eclipse.core.runtime.content.IContentDescription;
/*    */ import org.eclipse.core.runtime.content.ITextContentDescriber;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class InvalidDescriber
/*    */   implements IContentDescriber, ITextContentDescriber
/*    */ {
/*    */   public int describe(InputStream contents, IContentDescription description) {
/* 32 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public int describe(Reader contents, IContentDescription description) {
/* 37 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public QualifiedName[] getSupportedOptions() {
/* 42 */     return new QualifiedName[0];
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\ContentType$InvalidDescriber.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */