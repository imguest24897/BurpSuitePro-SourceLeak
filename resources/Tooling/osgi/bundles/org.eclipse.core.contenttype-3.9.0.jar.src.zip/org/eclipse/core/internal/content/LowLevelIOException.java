/*    */ package org.eclipse.core.internal.content;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LowLevelIOException
/*    */   extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private IOException actual;
/*    */   
/*    */   public LowLevelIOException(IOException actual) {
/* 39 */     Assert.isLegal(!(actual instanceof LowLevelIOException));
/* 40 */     this.actual = actual;
/*    */   }
/*    */   
/*    */   public IOException getActualException() {
/* 44 */     return this.actual;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\LowLevelIOException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */