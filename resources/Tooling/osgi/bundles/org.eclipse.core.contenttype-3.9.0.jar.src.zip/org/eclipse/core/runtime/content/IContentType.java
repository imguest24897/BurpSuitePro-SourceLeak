package org.eclipse.core.runtime.content;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.core.runtime.preferences.IScopeContext;

public interface IContentType extends IContentTypeSettings {
  public static final int IGNORE_PRE_DEFINED = 1;
  
  public static final int IGNORE_USER_DEFINED = 2;
  
  public static final int FILE_NAME_SPEC = 4;
  
  public static final int FILE_EXTENSION_SPEC = 8;
  
  public static final int FILE_PATTERN_SPEC = 16;
  
  IContentType getBaseType();
  
  IContentDescription getDefaultDescription();
  
  IContentDescription getDescriptionFor(InputStream paramInputStream, QualifiedName[] paramArrayOfQualifiedName) throws IOException;
  
  IContentDescription getDescriptionFor(Reader paramReader, QualifiedName[] paramArrayOfQualifiedName) throws IOException;
  
  String getDefaultCharset();
  
  String[] getFileSpecs(int paramInt);
  
  String getId();
  
  String getName();
  
  boolean isAssociatedWith(String paramString);
  
  boolean isAssociatedWith(String paramString, IScopeContext paramIScopeContext);
  
  boolean isKindOf(IContentType paramIContentType);
  
  IContentTypeSettings getSettings(IScopeContext paramIScopeContext) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\runtime\content\IContentType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */