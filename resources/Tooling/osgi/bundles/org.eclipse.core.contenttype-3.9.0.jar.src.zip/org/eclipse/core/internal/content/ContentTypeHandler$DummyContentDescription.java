/*    */ package org.eclipse.core.internal.content;
/*    */ 
/*    */ import org.eclipse.core.runtime.QualifiedName;
/*    */ import org.eclipse.core.runtime.content.IContentDescription;
/*    */ import org.eclipse.core.runtime.content.IContentType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DummyContentDescription
/*    */   implements IContentDescription
/*    */ {
/*    */   public String getCharset() {
/* 36 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public IContentType getContentType() {
/* 41 */     return ContentTypeHandler.this;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getProperty(QualifiedName key) {
/* 46 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isRequested(QualifiedName key) {
/* 51 */     return false;
/*    */   }
/*    */   
/*    */   public void setProperty(QualifiedName key, Object value) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\ContentTypeHandler$DummyContentDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */