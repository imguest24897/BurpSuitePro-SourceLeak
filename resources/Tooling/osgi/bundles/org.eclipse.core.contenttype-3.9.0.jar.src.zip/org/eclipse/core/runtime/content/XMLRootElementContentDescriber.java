/*     */ package org.eclipse.core.runtime.content;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.content.ContentMessages;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExecutableExtension;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class XMLRootElementContentDescriber
/*     */   extends XMLContentDescriber
/*     */   implements IExecutableExtension
/*     */ {
/*     */   private static final String DTD_TO_FIND = "dtd";
/*     */   private static final String ELEMENT_TO_FIND = "element";
/*  54 */   private String dtdToFind = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private String elementToFind = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int checkCriteria(InputSource contents, Map<String, Object> properties) throws IOException {
/*  75 */     if (!XMLRootElementContentDescriber2.isProcessed(properties))
/*  76 */       XMLRootElementContentDescriber2.fillContentProperties(contents, properties); 
/*  77 */     return checkCriteria(properties);
/*     */   }
/*     */   
/*     */   private int checkCriteria(Map<String, Object> properties) throws IOException {
/*  81 */     Boolean result = (Boolean)properties.get("org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.result");
/*  82 */     if (!result.booleanValue()) {
/*  83 */       return 1;
/*     */     }
/*  85 */     if (this.dtdToFind != null && !this.dtdToFind.equals(properties.get("org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.dtd")))
/*  86 */       return 1; 
/*  87 */     if (this.elementToFind != null && !this.elementToFind.equals(properties.get("org.eclipse.core.runtime.content.XMLRootElementContentDescriber2.element"))) {
/*  88 */       return 1;
/*     */     }
/*  90 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int describe(InputStream contents, IContentDescription description) throws IOException {
/*  98 */     return describe(contents, description, new HashMap<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int describe(InputStream contents, IContentDescription description, Map<String, Object> properties) throws IOException {
/* 106 */     if (describe2(contents, description, properties) == 0) {
/* 107 */       return 0;
/*     */     }
/* 109 */     contents.reset();
/*     */     
/* 111 */     return checkCriteria(new InputSource(contents), properties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int describe(Reader contents, IContentDescription description) throws IOException {
/* 119 */     return describe(contents, description, new HashMap<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int describe(Reader contents, IContentDescription description, Map<String, Object> properties) throws IOException {
/* 127 */     if (describe2(contents, description, properties) == 0) {
/* 128 */       return 0;
/*     */     }
/* 130 */     contents.reset();
/*     */     
/* 132 */     return checkCriteria(new InputSource(contents), properties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInitializationData(IConfigurationElement config, String propertyName, Object data) throws CoreException {
/* 140 */     if (data instanceof String) {
/* 141 */       this.elementToFind = (String)data;
/* 142 */     } else if (data instanceof Hashtable) {
/* 143 */       Hashtable<?, ?> parameters = (Hashtable<?, ?>)data;
/* 144 */       this.dtdToFind = (String)parameters.get("dtd");
/* 145 */       this.elementToFind = (String)parameters.get("element");
/*     */     } 
/* 147 */     if (this.dtdToFind == null && this.elementToFind == null) {
/* 148 */       String message = NLS.bind(ContentMessages.content_badInitializationData, XMLRootElementContentDescriber.class.getName());
/* 149 */       throw new CoreException(new Status(4, "org.eclipse.core.contenttype", 0, message, null));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\runtime\content\XMLRootElementContentDescriber.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */