/*    */ package org.eclipse.core.internal.content;
/*    */ 
/*    */ import org.eclipse.core.runtime.content.IContentDescription;
/*    */ import org.eclipse.core.runtime.content.IContentType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BasicDescription
/*    */   implements IContentDescription
/*    */ {
/*    */   protected IContentTypeInfo contentTypeInfo;
/*    */   
/*    */   public BasicDescription(IContentTypeInfo contentTypeInfo) {
/* 24 */     this.contentTypeInfo = contentTypeInfo;
/*    */   }
/*    */ 
/*    */   
/*    */   public IContentType getContentType() {
/* 29 */     ContentType contentType = this.contentTypeInfo.getContentType();
/*    */     
/* 31 */     return new ContentTypeHandler(contentType, contentType.getCatalog().getGeneration());
/*    */   }
/*    */   
/*    */   public IContentTypeInfo getContentTypeInfo() {
/* 35 */     return this.contentTypeInfo;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\BasicDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */