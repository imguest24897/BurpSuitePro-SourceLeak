/*     */ package org.eclipse.core.internal.content;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LazyReader
/*     */   extends Reader
/*     */   implements ILazySource
/*     */ {
/*     */   private int blockCapacity;
/*  21 */   char[][] blocks = new char[0][];
/*     */   private int bufferSize;
/*     */   private Reader in;
/*     */   private int mark;
/*     */   private int offset;
/*     */   
/*     */   public LazyReader(Reader in, int blockCapacity) {
/*  28 */     this.in = in;
/*  29 */     this.blockCapacity = blockCapacity;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */ 
/*     */   
/*     */   private int computeBlockSize(int blockIndex) {
/*  38 */     if (blockIndex < this.blocks.length - 1)
/*  39 */       return this.blockCapacity; 
/*  40 */     int blockSize = this.bufferSize % this.blockCapacity;
/*  41 */     return (blockSize == 0) ? this.blockCapacity : blockSize;
/*     */   }
/*     */   
/*     */   private int copyFromBuffer(char[] userBuffer, int userOffset, int needed) {
/*  45 */     int copied = 0;
/*  46 */     int current = this.offset / this.blockCapacity;
/*  47 */     while (needed - copied > 0 && current < this.blocks.length) {
/*  48 */       int blockSize = computeBlockSize(current);
/*  49 */       int offsetInBlock = this.offset % this.blockCapacity;
/*  50 */       int availableInBlock = blockSize - offsetInBlock;
/*  51 */       int toCopy = Math.min(availableInBlock, needed - copied);
/*  52 */       System.arraycopy(this.blocks[current], offsetInBlock, userBuffer, userOffset + copied, toCopy);
/*  53 */       copied += toCopy;
/*  54 */       current++;
/*  55 */       this.offset += toCopy;
/*     */     } 
/*  57 */     return copied;
/*     */   }
/*     */   
/*     */   private void ensureAvailable(long charsToRead) throws IOException {
/*  61 */     int loadedBlockSize = this.blockCapacity;
/*  62 */     while (this.bufferSize < this.offset + charsToRead && loadedBlockSize == this.blockCapacity) {
/*     */       try {
/*  64 */         loadedBlockSize = loadBlock();
/*  65 */       } catch (IOException ioe) {
/*  66 */         throw new LowLevelIOException(ioe);
/*     */       } 
/*  68 */       this.bufferSize += loadedBlockSize;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getBlockCount() {
/*  74 */     return this.blocks.length;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getBufferSize() {
/*  79 */     return this.bufferSize;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getMark() {
/*  84 */     return this.mark;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getOffset() {
/*  89 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isText() {
/*  94 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private int loadBlock() throws IOException {
/*  99 */     char[] newBlock = new char[this.blockCapacity];
/* 100 */     int readCount = this.in.read(newBlock);
/* 101 */     if (readCount == -1) {
/* 102 */       return 0;
/*     */     }
/* 104 */     char[][] tmpBlocks = new char[this.blocks.length + 1][];
/* 105 */     System.arraycopy(this.blocks, 0, tmpBlocks, 0, this.blocks.length);
/* 106 */     this.blocks = tmpBlocks;
/* 107 */     this.blocks[this.blocks.length - 1] = newBlock;
/* 108 */     return readCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public void mark(int readlimit) {
/* 113 */     this.mark = this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 118 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 123 */     ensureAvailable(1L);
/* 124 */     if (this.bufferSize <= this.offset)
/* 125 */       return -1; 
/* 126 */     char nextChar = this.blocks[this.offset / this.blockCapacity][this.offset % this.blockCapacity];
/* 127 */     this.offset++;
/* 128 */     return nextChar;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(char[] c) throws IOException {
/* 133 */     return read(c, 0, c.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(char[] c, int off, int len) throws IOException {
/* 138 */     ensureAvailable(len);
/* 139 */     int copied = copyFromBuffer(c, off, len);
/* 140 */     return (copied == 0) ? -1 : copied;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean ready() throws IOException {
/*     */     try {
/* 146 */       return !(this.bufferSize - this.offset <= 0 && !this.in.ready());
/* 147 */     } catch (IOException ioe) {
/* 148 */       throw new LowLevelIOException(ioe);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 154 */     this.offset = this.mark;
/*     */   }
/*     */ 
/*     */   
/*     */   public void rewind() {
/* 159 */     this.mark = 0;
/* 160 */     this.offset = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public long skip(long toSkip) throws IOException {
/* 165 */     if (toSkip <= 0L)
/* 166 */       return 0L; 
/* 167 */     ensureAvailable(toSkip);
/* 168 */     long skipped = Math.min(toSkip, (this.bufferSize - this.offset));
/* 169 */     this.offset = (int)(this.offset + skipped);
/* 170 */     return skipped;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\LazyReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */