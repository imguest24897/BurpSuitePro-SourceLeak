/*    */ package org.eclipse.core.internal.content;
/*    */ 
/*    */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*    */ import org.eclipse.core.runtime.preferences.PreferenceModifyListener;
/*    */ import org.osgi.service.prefs.BackingStoreException;
/*    */ import org.osgi.service.prefs.Preferences;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PreferenceModifyListener
/*    */   extends PreferenceModifyListener
/*    */ {
/*    */   public IEclipsePreferences preApply(IEclipsePreferences node) {
/* 24 */     Preferences root = node.node("/");
/*    */     try {
/* 26 */       if (root.nodeExists("instance")) {
/* 27 */         Preferences instance = root.node("instance");
/* 28 */         if (instance.nodeExists("org.eclipse.core.runtime/content-types"))
/* 29 */           ContentTypeManager.getInstance().invalidate(); 
/*    */       } 
/* 31 */     } catch (BackingStoreException backingStoreException) {}
/*    */ 
/*    */     
/* 34 */     return node;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\PreferenceModifyListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */