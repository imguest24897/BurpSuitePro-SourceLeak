package org.eclipse.core.internal.content;

import org.eclipse.core.runtime.content.XMLContentDescriber;

@Deprecated
public class XMLContentDescriber extends XMLContentDescriber {}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\XMLContentDescriber.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */