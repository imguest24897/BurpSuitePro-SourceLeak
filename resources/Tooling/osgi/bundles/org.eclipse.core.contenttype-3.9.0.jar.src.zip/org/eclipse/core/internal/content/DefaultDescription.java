/*    */ package org.eclipse.core.internal.content;
/*    */ 
/*    */ import org.eclipse.core.runtime.QualifiedName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultDescription
/*    */   extends BasicDescription
/*    */ {
/*    */   public DefaultDescription(IContentTypeInfo contentTypeInfo) {
/* 24 */     super(contentTypeInfo);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 29 */     if (!(obj instanceof DefaultDescription)) {
/* 30 */       return false;
/*    */     }
/* 32 */     return this.contentTypeInfo.equals(((DefaultDescription)obj).contentTypeInfo);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getCharset() {
/* 37 */     return (String)getProperty(CHARSET);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getProperty(QualifiedName key) {
/* 42 */     return this.contentTypeInfo.getDefaultProperty(key);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 47 */     return this.contentTypeInfo.getContentType().hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isRequested(QualifiedName key) {
/* 52 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setProperty(QualifiedName key, Object value) {
/* 57 */     throw new IllegalStateException();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 62 */     return "{default} : " + this.contentTypeInfo.getContentType();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\DefaultDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */