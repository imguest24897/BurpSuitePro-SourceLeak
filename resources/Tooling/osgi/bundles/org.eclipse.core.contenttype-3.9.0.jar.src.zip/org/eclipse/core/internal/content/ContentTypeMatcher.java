/*     */ package org.eclipse.core.internal.content;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ import org.eclipse.core.runtime.content.IContentTypeManager;
/*     */ import org.eclipse.core.runtime.content.IContentTypeMatcher;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentTypeMatcher
/*     */   implements IContentTypeMatcher
/*     */ {
/*     */   private IScopeContext context;
/*     */   private IContentTypeManager.ISelectionPolicy policy;
/*     */   
/*     */   public ContentTypeMatcher(IContentTypeManager.ISelectionPolicy policy, IScopeContext context) {
/*  35 */     this.policy = policy;
/*  36 */     this.context = context;
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentType findContentTypeFor(InputStream contents, String fileName) throws IOException {
/*  41 */     ContentTypeCatalog currentCatalog = getCatalog();
/*  42 */     IContentType[] all = currentCatalog.findContentTypesFor(this, contents, fileName);
/*  43 */     return (all.length > 0) ? new ContentTypeHandler((ContentType)all[0], currentCatalog.getGeneration()) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IContentType findContentTypeFor(String fileName) {
/*  49 */     ContentTypeCatalog currentCatalog = getCatalog();
/*  50 */     IContentType[] associated = currentCatalog.findContentTypesFor(this, fileName);
/*  51 */     return (associated.length == 0) ? null : new ContentTypeHandler((ContentType)associated[0], currentCatalog.getGeneration());
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentType[] findContentTypesFor(InputStream contents, String fileName) throws IOException {
/*  56 */     ContentTypeCatalog currentCatalog = getCatalog();
/*  57 */     IContentType[] types = currentCatalog.findContentTypesFor(this, contents, fileName);
/*  58 */     IContentType[] result = new IContentType[types.length];
/*  59 */     int generation = currentCatalog.getGeneration();
/*  60 */     for (int i = 0; i < result.length; i++)
/*  61 */       result[i] = new ContentTypeHandler((ContentType)types[i], generation); 
/*  62 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentType[] findContentTypesFor(String fileName) {
/*  67 */     ContentTypeCatalog currentCatalog = getCatalog();
/*  68 */     IContentType[] types = currentCatalog.findContentTypesFor(this, fileName);
/*  69 */     IContentType[] result = new IContentType[types.length];
/*  70 */     int generation = currentCatalog.getGeneration();
/*  71 */     for (int i = 0; i < result.length; i++)
/*  72 */       result[i] = new ContentTypeHandler((ContentType)types[i], generation); 
/*  73 */     return result;
/*     */   }
/*     */   
/*     */   private ContentTypeCatalog getCatalog() {
/*  77 */     return ContentTypeManager.getInstance().getCatalog();
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentDescription getDescriptionFor(InputStream contents, String fileName, QualifiedName[] options) throws IOException {
/*  82 */     return getCatalog().getDescriptionFor(this, contents, fileName, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentDescription getDescriptionFor(Reader contents, String fileName, QualifiedName[] options) throws IOException {
/*  87 */     return getCatalog().getDescriptionFor(this, contents, fileName, options);
/*     */   }
/*     */   
/*     */   public IScopeContext getContext() {
/*  91 */     return this.context;
/*     */   }
/*     */   
/*     */   public IContentTypeManager.ISelectionPolicy getPolicy() {
/*  95 */     return this.policy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ContentType> getDirectlyAssociated(ContentTypeCatalog catalog, String fileSpec, int typeMask) {
/* 102 */     if ((typeMask & 0xC) == 0) {
/* 103 */       throw new IllegalArgumentException("This method only apply to name or extension based associations");
/*     */     }
/*     */     
/* 106 */     IEclipsePreferences root = this.context.getNode("org.eclipse.core.runtime/content-types");
/* 107 */     Set<ContentType> result = new HashSet<>(3);
/*     */     try {
/* 109 */       root.accept(node -> {
/*     */             if (node == paramIEclipsePreferences1)
/*     */               return true;  String[] fileSpecs = ContentTypeSettings.getFileSpecs((Preferences)node, paramInt); String[] arrayOfString1; int i = (arrayOfString1 = fileSpecs).length; for (byte b = 0; b < i; b++) {
/*     */               String fileSpecification = arrayOfString1[b];
/*     */               if (fileSpecification.equalsIgnoreCase(paramString)) {
/*     */                 ContentType associated = paramContentTypeCatalog.getContentType(node.name());
/*     */                 if (associated != null)
/*     */                   paramSet.add(associated); 
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */             return false;
/*     */           });
/* 122 */     } catch (BackingStoreException bse) {
/* 123 */       ContentType.log(ContentMessages.content_errorLoadingSettings, (Throwable)bse);
/*     */     } 
/* 125 */     return (result == null) ? Collections.EMPTY_SET : result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<? extends ContentType> getMatchingRegexpAssociated(ContentTypeCatalog catalog, String fileName, int typeMask) {
/* 130 */     if ((typeMask & 0x10) == 0) {
/* 131 */       throw new IllegalArgumentException("This method only applies for FILE_REGEXP_SPEC.");
/*     */     }
/* 133 */     IEclipsePreferences root = this.context.getNode("org.eclipse.core.runtime/content-types");
/* 134 */     Set<ContentType> result = new HashSet<>(3);
/*     */     try {
/* 136 */       root.accept(node -> {
/*     */             if (node == paramIEclipsePreferences1)
/*     */               return true;  String[] fileSpecs = ContentTypeSettings.getFileSpecs((Preferences)node, paramInt); String[] arrayOfString1; int i = (arrayOfString1 = fileSpecs).length; for (byte b = 0; b < i; b++) {
/*     */               String fileSpecification = arrayOfString1[b];
/*     */               if (Pattern.matches(paramContentTypeCatalog.toRegexp(fileSpecification), paramString)) {
/*     */                 ContentType associated = paramContentTypeCatalog.getContentType(node.name());
/*     */                 if (associated != null)
/*     */                   paramSet.add(associated); 
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */             return false;
/*     */           });
/* 149 */     } catch (BackingStoreException bse) {
/* 150 */       ContentType.log(ContentMessages.content_errorLoadingSettings, (Throwable)bse);
/*     */     } 
/* 152 */     return (result == null) ? Collections.EMPTY_SET : result;
/*     */   }
/*     */   
/*     */   public IContentDescription getSpecificDescription(BasicDescription description) {
/* 156 */     if (description == null || ContentTypeManager.getInstance().getContext().equals(getContext()))
/*     */     {
/* 158 */       return description;
/*     */     }
/* 160 */     if (description instanceof DefaultDescription)
/*     */     {
/* 162 */       return new DefaultDescription(new ContentTypeSettings((ContentType)description.getContentTypeInfo(), this.context));
/*     */     }
/*     */     
/* 165 */     ((ContentDescription)description).setContentTypeInfo(new ContentTypeSettings((ContentType)description.getContentTypeInfo(), this.context));
/* 166 */     return description;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\ContentTypeMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */