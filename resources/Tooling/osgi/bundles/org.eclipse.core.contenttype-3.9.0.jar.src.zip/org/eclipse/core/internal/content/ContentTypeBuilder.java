/*     */ package org.eclipse.core.internal.content;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.runtime.RuntimeLog;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.core.runtime.RegistryFactory;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentTypeBuilder
/*     */ {
/*     */   public static final String PT_CONTENTTYPES = "contentTypes";
/*     */   private ContentTypeCatalog catalog;
/*     */   
/*     */   private static String getUniqueId(String namespace, String baseTypeId) {
/*  37 */     if (baseTypeId == null)
/*  38 */       return null; 
/*  39 */     int separatorPosition = baseTypeId.lastIndexOf('.');
/*     */     
/*  41 */     if (separatorPosition == -1)
/*  42 */       baseTypeId = String.valueOf(namespace) + '.' + baseTypeId; 
/*  43 */     return baseTypeId;
/*     */   }
/*     */   
/*     */   private static QualifiedName parseQualifiedName(String namespace, String value) {
/*  47 */     if (value == null)
/*  48 */       return null; 
/*  49 */     int separatorPosition = value.lastIndexOf('.');
/*     */     
/*  51 */     if (separatorPosition == -1)
/*  52 */       return new QualifiedName(namespace, value); 
/*  53 */     if (separatorPosition == 0 || separatorPosition == value.length() - 1)
/*     */     {
/*  55 */       return null; } 
/*  56 */     namespace = value.substring(0, separatorPosition);
/*  57 */     String simpleValue = value.substring(separatorPosition + 1);
/*  58 */     return new QualifiedName(namespace, simpleValue);
/*     */   }
/*     */   
/*     */   private static byte parsePriority(String priority) {
/*  62 */     if (priority == null)
/*  63 */       return 0; 
/*  64 */     if ("high".equals(priority))
/*  65 */       return 1; 
/*  66 */     if ("low".equals(priority))
/*  67 */       return -1; 
/*  68 */     if (!"normal".equals(priority)) {
/*  69 */       return 0;
/*     */     }
/*  71 */     return 0;
/*     */   }
/*     */   
/*     */   protected ContentTypeBuilder(ContentTypeCatalog catalog) {
/*  75 */     this.catalog = catalog;
/*     */   }
/*     */   
/*     */   private void addFileAssociation(IConfigurationElement fileAssociationElement, ContentType target) {
/*  79 */     String[] fileNames = Util.parseItems(fileAssociationElement.getAttribute("file-names")); byte b; int i; String[] arrayOfString1;
/*  80 */     for (i = (arrayOfString1 = fileNames).length, b = 0; b < i; ) { String fileName = arrayOfString1[b];
/*  81 */       target.internalAddFileSpec(fileName, 5); b++; }
/*  82 */      String[] fileExtensions = Util.parseItems(fileAssociationElement.getAttribute("file-extensions")); int j; String[] arrayOfString2;
/*  83 */     for (j = (arrayOfString2 = fileExtensions).length, i = 0; i < j; ) { String fileExtension = arrayOfString2[i];
/*  84 */       target.internalAddFileSpec(fileExtension, 9); i++; }
/*  85 */      String[] filePatterns = Util.parseItems(fileAssociationElement.getAttribute("file-patterns")); String[] arrayOfString3;
/*  86 */     for (int k = (arrayOfString3 = filePatterns).length; j < k; ) { String filePattern = arrayOfString3[j];
/*  87 */       target.internalAddFileSpec(filePattern, 17);
/*     */       j++; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void buildCatalog(IScopeContext context) {
/*  94 */     IConfigurationElement[] allContentTypeCEs = getConfigurationElements(); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement2;
/*  95 */     for (i = (arrayOfIConfigurationElement2 = allContentTypeCEs).length, b = 0; b < i; ) { IConfigurationElement allContentTypeCE = arrayOfIConfigurationElement2[b];
/*  96 */       if ("content-type".equals(allContentTypeCE.getName()))
/*  97 */         registerContentType(allContentTypeCE);  b++; }
/*  98 */      String[] arrayOfString; for (i = (arrayOfString = ContentTypeManager.getUserDefinedContentTypeIds(context)).length, b = 0; b < i; ) { String id = arrayOfString[b];
/*  99 */       IEclipsePreferences node = context.getNode(id);
/* 100 */       this.catalog.addContentType(ContentType.createContentType(this.catalog, id, 
/* 101 */             node.get("name", ""), (byte)
/* 102 */             0, new String[0], new String[0], new String[0], 
/* 103 */             node.get("baseTypeId", null), null, Collections.emptyMap(), 
/* 104 */             null)); b++; }
/*     */      IConfigurationElement[] arrayOfIConfigurationElement1;
/* 106 */     for (i = (arrayOfIConfigurationElement1 = allContentTypeCEs).length, b = 0; b < i; ) { IConfigurationElement allContentTypeCE = arrayOfIConfigurationElement1[b];
/* 107 */       if ("file-association".equals(allContentTypeCE.getName()))
/* 108 */         registerFileAssociation(allContentTypeCE);  b++; }
/* 109 */      applyPreferences();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void applyPreferences() {
/*     */     try {
/* 117 */       ContentTypeCatalog localCatalog = this.catalog;
/* 118 */       IEclipsePreferences root = localCatalog.getManager().getPreferences();
/* 119 */       root.accept(node -> {
/*     */             if (node == paramIEclipsePreferences1) {
/*     */               return true;
/*     */             }
/*     */             ContentType contentType = paramContentTypeCatalog.internalGetContentType(node.name());
/*     */             if (contentType != null)
/*     */               contentType.processPreferences((Preferences)node); 
/*     */             return false;
/*     */           });
/* 128 */     } catch (BackingStoreException bse) {
/* 129 */       ContentType.log(ContentMessages.content_errorLoadingSettings, (Throwable)bse);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ContentType createContentType(IConfigurationElement contentTypeCE) throws CoreException {
/* 137 */     String uniqueId, namespace = contentTypeCE.getContributor().getName();
/* 138 */     String simpleId = contentTypeCE.getAttribute("id");
/* 139 */     String name = contentTypeCE.getAttribute("name");
/*     */     
/* 141 */     if (simpleId == null) {
/* 142 */       missingMandatoryAttribute(ContentMessages.content_missingIdentifier, namespace);
/*     */     }
/* 144 */     if (simpleId.lastIndexOf('.') == -1) {
/* 145 */       uniqueId = String.valueOf(namespace) + '.' + simpleId;
/*     */     } else {
/* 147 */       uniqueId = simpleId;
/* 148 */     }  if (name == null) {
/* 149 */       missingMandatoryAttribute(ContentMessages.content_missingName, uniqueId);
/*     */     }
/* 151 */     byte priority = parsePriority(contentTypeCE.getAttribute("priority"));
/* 152 */     String[] fileNames = Util.parseItems(contentTypeCE.getAttribute("file-names"));
/* 153 */     String[] fileExtensions = Util.parseItems(contentTypeCE.getAttribute("file-extensions"));
/* 154 */     String[] filePatterns = Util.parseItems(contentTypeCE.getAttribute("file-patterns"));
/* 155 */     String baseTypeId = getUniqueId(namespace, contentTypeCE.getAttribute("base-type"));
/* 156 */     String aliasTargetTypeId = getUniqueId(namespace, contentTypeCE.getAttribute("alias-for"));
/* 157 */     IConfigurationElement[] propertyCEs = null;
/* 158 */     Map<QualifiedName, String> defaultProperties = null;
/* 159 */     if ((propertyCEs = contentTypeCE.getChildren("property")).length > 0) {
/* 160 */       defaultProperties = new HashMap<>(); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement;
/* 161 */       for (i = (arrayOfIConfigurationElement = propertyCEs).length, b = 0; b < i; ) { IConfigurationElement propertyCE = arrayOfIConfigurationElement[b];
/* 162 */         String defaultValue = propertyCE.getAttribute("default");
/* 163 */         if (defaultValue == null)
/*     */         {
/* 165 */           defaultValue = ""; } 
/* 166 */         String propertyKey = propertyCE.getAttribute("name");
/* 167 */         QualifiedName qualifiedKey = parseQualifiedName(namespace, propertyKey);
/* 168 */         if (qualifiedKey == null) {
/* 169 */           if (ContentTypeManager.DebuggingHolder.DEBUGGING) {
/* 170 */             String message = NLS.bind(ContentMessages.content_invalidProperty, propertyKey, getUniqueId(namespace, simpleId));
/* 171 */             ContentType.log(message, null);
/*     */           } 
/*     */         } else {
/*     */           
/* 175 */           defaultProperties.put(qualifiedKey, defaultValue);
/*     */         }  b++; }
/*     */     
/* 178 */     }  String defaultCharset = contentTypeCE.getAttribute("default-charset");
/* 179 */     if (defaultCharset != null)
/* 180 */       if (defaultProperties == null) {
/* 181 */         defaultProperties = Collections.singletonMap(IContentDescription.CHARSET, defaultCharset);
/*     */       } else {
/* 183 */         defaultProperties.putIfAbsent(IContentDescription.CHARSET, defaultCharset);
/* 184 */       }   return ContentType.createContentType(this.catalog, uniqueId, name, priority, fileExtensions, fileNames, filePatterns, 
/* 185 */         baseTypeId, aliasTargetTypeId, defaultProperties, contentTypeCE);
/*     */   }
/*     */ 
/*     */   
/* 189 */   private static final IConfigurationElement[] emptyConfArray = new IConfigurationElement[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IConfigurationElement[] getConfigurationElements() {
/* 198 */     IExtensionRegistry registry = RegistryFactory.getRegistry();
/* 199 */     if (registry == null)
/* 200 */       return emptyConfArray; 
/* 201 */     IConfigurationElement[] oldConfigElements = emptyConfArray;
/* 202 */     IConfigurationElement[] newConfigElements = emptyConfArray;
/*     */     
/* 204 */     IExtensionPoint oldPoint = registry.getExtensionPoint("org.eclipse.core.runtime", "contentTypes");
/* 205 */     if (oldPoint != null) {
/* 206 */       oldConfigElements = oldPoint.getConfigurationElements();
/*     */     }
/* 208 */     IExtensionPoint newPoint = registry.getExtensionPoint("org.eclipse.core.contenttype", "contentTypes");
/* 209 */     if (newPoint != null) {
/* 210 */       newConfigElements = newPoint.getConfigurationElements();
/*     */     }
/* 212 */     IConfigurationElement[] allContentTypeCEs = new IConfigurationElement[oldConfigElements.length + newConfigElements.length];
/* 213 */     System.arraycopy(oldConfigElements, 0, allContentTypeCEs, 0, oldConfigElements.length);
/* 214 */     System.arraycopy(newConfigElements, 0, allContentTypeCEs, oldConfigElements.length, newConfigElements.length);
/*     */     
/* 216 */     return allContentTypeCEs;
/*     */   }
/*     */   
/*     */   private void missingMandatoryAttribute(String messageKey, String argument) throws CoreException {
/* 220 */     String message = NLS.bind(messageKey, argument);
/* 221 */     throw new CoreException(new Status(4, "org.eclipse.core.contenttype", 0, message, null));
/*     */   }
/*     */   
/*     */   private void registerContentType(IConfigurationElement contentTypeCE) {
/*     */     try {
/* 226 */       ContentType contentType = createContentType(contentTypeCE);
/* 227 */       this.catalog.addContentType(contentType);
/* 228 */     } catch (CoreException e) {
/*     */       
/* 230 */       RuntimeLog.log(e.getStatus());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerFileAssociation(IConfigurationElement fileAssociationElement) {
/* 239 */     String contentTypeId = getUniqueId(fileAssociationElement.getContributor().getName(), fileAssociationElement.getAttribute("content-type"));
/* 240 */     ContentType target = this.catalog.internalGetContentType(contentTypeId);
/* 241 */     if (target == null)
/*     */       return; 
/* 243 */     addFileAssociation(fileAssociationElement, target);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\ContentTypeBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */