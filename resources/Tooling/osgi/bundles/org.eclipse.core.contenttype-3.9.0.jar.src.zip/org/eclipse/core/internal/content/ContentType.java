/*     */ package org.eclipse.core.internal.content;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.InvalidRegistryObjectException;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.content.IContentDescriber;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ import org.eclipse.core.runtime.content.IContentTypeSettings;
/*     */ import org.eclipse.core.runtime.content.ITextContentDescriber;
/*     */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ 
/*     */ public final class ContentType implements IContentType, IContentTypeInfo {
/*     */   static final byte ASSOCIATED_BY_EXTENSION = 2;
/*     */   static final byte ASSOCIATED_BY_NAME = 1;
/*     */   private static final String DESCRIBER_ELEMENT = "describer";
/*     */   
/*     */   private static class InvalidDescriber implements IContentDescriber, ITextContentDescriber {
/*     */     public int describe(InputStream contents, IContentDescription description) {
/*  32 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public int describe(Reader contents, IContentDescription description) {
/*  37 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public QualifiedName[] getSupportedOptions() {
/*  42 */       return new QualifiedName[0];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   private static ArrayList<FileSpec> EMPTY_LIST = new ArrayList<>(0);
/*  50 */   private static final Object INHERITED_DESCRIBER = "INHERITED DESCRIBER";
/*     */   
/*  52 */   private static final Object NO_DESCRIBER = "NO DESCRIBER";
/*     */   
/*     */   static final byte NOT_ASSOCIATED = 0;
/*     */   
/*     */   public static final String PREF_DEFAULT_CHARSET = "charset";
/*     */   
/*     */   public static final String PREF_FILE_EXTENSIONS = "file-extensions";
/*     */   
/*     */   public static final String PREF_FILE_NAMES = "file-names";
/*     */   
/*     */   public static final String PREF_FILE_PATTERNS = "file-patterns";
/*     */   
/*     */   public static final String PREF_USER_DEFINED = "userDefined";
/*     */   public static final String PREF_USER_DEFINED__SEPARATOR = ",";
/*     */   public static final String PREF_USER_DEFINED__NAME = "name";
/*     */   public static final String PREF_USER_DEFINED__BASE_TYPE_ID = "baseTypeId";
/*     */   static final byte PRIORITY_HIGH = 1;
/*     */   static final byte PRIORITY_LOW = -1;
/*     */   static final byte PRIORITY_NORMAL = 0;
/*     */   static final int SPEC_PRE_DEFINED = 1;
/*     */   static final int SPEC_USER_DEFINED = 2;
/*     */   static final byte STATUS_INVALID = 2;
/*     */   static final byte STATUS_UNKNOWN = 0;
/*     */   static final byte STATUS_VALID = 1;
/*     */   static final String EMPTY_STRING = "";
/*     */   private String aliasTargetId;
/*     */   private String baseTypeId;
/*     */   private boolean builtInAssociations = false;
/*     */   private ContentTypeCatalog catalog;
/*     */   private IConfigurationElement contentTypeElement;
/*     */   private DefaultDescription defaultDescription;
/*     */   private Map<QualifiedName, String> defaultProperties;
/*     */   private Object describer;
/*  85 */   private ArrayList<FileSpec> fileSpecs = EMPTY_LIST;
/*     */   String id;
/*     */   private ContentTypeManager manager;
/*     */   private String name;
/*     */   private byte priority;
/*     */   private ContentType target;
/*     */   private String userCharset;
/*  92 */   private byte validation = 0;
/*     */   
/*     */   private ContentType baseType;
/*  95 */   private byte depth = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   public static ContentType createContentType(ContentTypeCatalog catalog, String uniqueId, String name, byte priority, String[] fileExtensions, String[] fileNames, String[] filePatterns, String baseTypeId, String aliasTargetId, Map<QualifiedName, String> defaultProperties, IConfigurationElement contentTypeElement) {
/* 100 */     ContentType contentType = new ContentType(catalog.getManager());
/* 101 */     contentType.catalog = catalog;
/* 102 */     contentType.defaultDescription = new DefaultDescription(contentType);
/* 103 */     contentType.id = uniqueId;
/* 104 */     contentType.name = name;
/* 105 */     contentType.priority = priority;
/* 106 */     if ((fileExtensions != null && fileExtensions.length > 0) || (fileNames != null && fileNames.length > 0) || (
/* 107 */       filePatterns != null && filePatterns.length > 0)) {
/* 108 */       contentType.builtInAssociations = true;
/* 109 */       contentType.fileSpecs = new ArrayList<>(fileExtensions.length + fileNames.length + filePatterns.length); byte b; int i; String[] arrayOfString;
/* 110 */       for (i = (arrayOfString = fileNames).length, b = 0; b < i; ) { String fileName = arrayOfString[b];
/* 111 */         contentType.internalAddFileSpec(fileName, 5); b++; }
/* 112 */        for (i = (arrayOfString = fileExtensions).length, b = 0; b < i; ) { String fileExtension = arrayOfString[b];
/* 113 */         contentType.internalAddFileSpec(fileExtension, 9); b++; }
/* 114 */        for (i = (arrayOfString = filePatterns).length, b = 0; b < i; ) { String fileExtension = arrayOfString[b];
/* 115 */         contentType.internalAddFileSpec(fileExtension, 17); b++; }
/*     */     
/*     */     } 
/* 118 */     contentType.defaultProperties = defaultProperties;
/* 119 */     contentType.contentTypeElement = contentTypeElement;
/* 120 */     contentType.baseTypeId = baseTypeId;
/* 121 */     contentType.aliasTargetId = aliasTargetId;
/* 122 */     return contentType;
/*     */   }
/*     */   
/*     */   static FileSpec createFileSpec(String fileSpec, int type) {
/* 126 */     return new FileSpec(fileSpec, type);
/*     */   }
/*     */   
/*     */   static String getPreferenceKey(int flags) {
/* 130 */     if ((flags & 0x8) != 0)
/* 131 */       return "file-extensions"; 
/* 132 */     if ((flags & 0x4) != 0)
/* 133 */       return "file-names"; 
/* 134 */     if ((flags & 0x10) != 0)
/* 135 */       return "file-patterns"; 
/* 136 */     throw new IllegalArgumentException("Unknown type: " + flags);
/*     */   }
/*     */   
/*     */   private static String getValidationString(byte validation) {
/* 140 */     return (validation == 1) ? "VALID" : ((validation == 2) ? "INVALID" : "UNKNOWN");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void log(String message, Throwable reason) {
/* 145 */     Status status = new Status(4, "org.eclipse.core.contenttype", 0, message, (reason instanceof CoreException) ? null : reason);
/* 146 */     RuntimeLog.log((IStatus)status);
/*     */   }
/*     */   
/*     */   public ContentType(ContentTypeManager manager) {
/* 150 */     this.manager = manager;
/*     */   }
/*     */   
/*     */   public void addFileSpec(String fileSpec, int type) throws CoreException {
/*     */     String[] userSet;
/* 155 */     Assert.isLegal(!(type != 8 && type != 4 && type != 16), 
/* 156 */         "Unknown type: " + type);
/*     */     
/* 158 */     synchronized (this) {
/* 159 */       if (!internalAddFileSpec(fileSpec, type | 0x2))
/*     */         return; 
/* 161 */       userSet = getFileSpecs(type | 0x1);
/*     */     } 
/*     */     
/* 164 */     Preferences contentTypeNode = this.manager.getPreferences().node(this.id);
/* 165 */     String newValue = Util.toListString((Object[])userSet);
/*     */     
/* 167 */     Assert.isNotNull(newValue);
/* 168 */     setPreference(contentTypeNode, getPreferenceKey(type), newValue);
/*     */     try {
/* 170 */       contentTypeNode.flush();
/* 171 */     } catch (BackingStoreException bse) {
/* 172 */       String message = NLS.bind(ContentMessages.content_errorSavingSettings, this.id);
/* 173 */       Status status = new Status(4, "org.eclipse.core.contenttype", 0, message, (Throwable)bse);
/* 174 */       throw new CoreException(status);
/*     */     } 
/*     */     
/* 177 */     this.manager.fireContentTypeChangeEvent(this);
/*     */   }
/*     */   
/*     */   int describe(IContentDescriber selectedDescriber, ILazySource contents, ContentDescription description) throws IOException {
/*     */     try {
/* 182 */       return contents.isText() ? ((ITextContentDescriber)selectedDescriber).describe((Reader)contents, description) : selectedDescriber.describe((InputStream)contents, description);
/* 183 */     } catch (RuntimeException re) {
/*     */       
/* 185 */       invalidateDescriber(re);
/* 186 */     } catch (Error e) {
/*     */       
/* 188 */       invalidateDescriber(e);
/* 189 */       throw e;
/* 190 */     } catch (LowLevelIOException llioe) {
/*     */       
/* 192 */       throw llioe.getActualException();
/* 193 */     } catch (IOException ioe) {
/*     */       
/* 195 */       if (ContentTypeManager.DebuggingHolder.DEBUGGING) {
/* 196 */         String message = NLS.bind(ContentMessages.content_errorReadingContents, this.id);
/* 197 */         log(message, ioe);
/*     */       } 
/*     */       
/* 200 */       return 1;
/*     */     } finally {
/* 202 */       contents.rewind();
/*     */     } 
/* 204 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/* 209 */     if (another instanceof ContentType)
/* 210 */       return this.id.equals(((ContentType)another).id); 
/* 211 */     if (another instanceof ContentTypeHandler)
/* 212 */       return this.id.equals(((ContentTypeHandler)another).id); 
/* 213 */     return false;
/*     */   }
/*     */   
/*     */   public String getAliasTargetId() {
/* 217 */     return this.aliasTargetId;
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentType getBaseType() {
/* 222 */     return this.baseType;
/*     */   }
/*     */   
/*     */   String getBaseTypeId() {
/* 226 */     return this.baseTypeId;
/*     */   }
/*     */   
/*     */   public ContentTypeCatalog getCatalog() {
/* 230 */     return this.catalog;
/*     */   }
/*     */ 
/*     */   
/*     */   public ContentType getContentType() {
/* 235 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDefaultCharset() {
/* 240 */     return getDefaultProperty(IContentDescription.CHARSET);
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentDescription getDefaultDescription() {
/* 245 */     return this.defaultDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultProperty(QualifiedName key) {
/* 253 */     String propertyValue = internalGetDefaultProperty(key);
/* 254 */     if ("".equals(propertyValue))
/* 255 */       return null; 
/* 256 */     return propertyValue;
/*     */   }
/*     */   
/*     */   byte getDepth() {
/* 260 */     byte tmpDepth = this.depth;
/* 261 */     if (tmpDepth >= 0) {
/* 262 */       return tmpDepth;
/*     */     }
/* 264 */     if (this.baseType == null)
/* 265 */       return this.depth = 0; 
/* 266 */     return this.depth = (byte)((this.baseType == null) ? 0 : (1 + this.baseType.getDepth()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IContentDescriber getDescriber() {
/*     */     try {
/* 275 */       Object tmpDescriber = this.describer;
/* 276 */       if (tmpDescriber != null) {
/* 277 */         if (INHERITED_DESCRIBER == tmpDescriber)
/* 278 */           return this.baseType.getDescriber(); 
/* 279 */         return (NO_DESCRIBER == tmpDescriber) ? null : (IContentDescriber)tmpDescriber;
/*     */       } 
/* 281 */       String describerValue = (this.contentTypeElement != null) ? 
/* 282 */         this.contentTypeElement.getAttribute("describer") : 
/* 283 */         null;
/* 284 */       IConfigurationElement[] childrenDescribers = (this.contentTypeElement != null) ? 
/* 285 */         this.contentTypeElement.getChildren("describer") : 
/* 286 */         new IConfigurationElement[0];
/* 287 */       if (describerValue != null || childrenDescribers.length > 0)
/*     */         try {
/* 289 */           if ("".equals(describerValue)) {
/* 290 */             this.describer = NO_DESCRIBER;
/* 291 */             return null;
/*     */           } 
/* 293 */           this.describer = tmpDescriber = this.contentTypeElement.createExecutableExtension("describer");
/* 294 */           return (IContentDescriber)tmpDescriber;
/* 295 */         } catch (CoreException ce) {
/*     */ 
/*     */ 
/*     */           
/* 299 */           return invalidateDescriber((Throwable)ce);
/*     */         }  
/* 301 */     } catch (InvalidRegistryObjectException invalidRegistryObjectException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 307 */       this.manager.invalidate();
/*     */       
/* 309 */       return null;
/*     */     } 
/* 311 */     if (this.baseType == null) {
/* 312 */       this.describer = NO_DESCRIBER;
/* 313 */       return null;
/*     */     } 
/*     */     
/* 316 */     this.describer = INHERITED_DESCRIBER;
/* 317 */     return this.baseType.getDescriber();
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentDescription getDescriptionFor(InputStream contents, QualifiedName[] options) throws IOException {
/* 322 */     return internalGetDescriptionFor(ContentTypeManager.readBuffer(contents), options);
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentDescription getDescriptionFor(Reader contents, QualifiedName[] options) throws IOException {
/* 327 */     return internalGetDescriptionFor(ContentTypeManager.readBuffer(contents), options);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getFileSpecs(int typeMask) {
/* 332 */     if (this.fileSpecs.isEmpty()) {
/* 333 */       return new String[0];
/*     */     }
/* 335 */     typeMask ^= 0x3;
/* 336 */     List<String> result = new ArrayList<>(this.fileSpecs.size());
/* 337 */     for (FileSpec spec : this.fileSpecs) {
/* 338 */       if ((spec.getType() & typeMask) == spec.getType())
/* 339 */         result.add(spec.getText()); 
/*     */     } 
/* 341 */     return result.<String>toArray(new String[result.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getId() {
/* 346 */     return this.id;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 351 */     return this.name;
/*     */   }
/*     */   
/*     */   byte getPriority() {
/* 355 */     return this.priority;
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentTypeSettings getSettings(IScopeContext context) {
/* 360 */     if (context == null || context.equals(this.manager.getContext()))
/* 361 */       return (IContentTypeSettings)this; 
/* 362 */     return new ContentTypeSettings(this, context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ContentType getAliasTarget(boolean self) {
/* 369 */     return (self && this.target == null) ? this : this.target;
/*     */   }
/*     */   
/*     */   byte getValidation() {
/* 373 */     return this.validation;
/*     */   }
/*     */   
/*     */   boolean hasBuiltInAssociations() {
/* 377 */     return this.builtInAssociations;
/*     */   }
/*     */   
/*     */   boolean hasFileSpec(IScopeContext context, String text, int typeMask) {
/* 381 */     if (context.equals(this.manager.getContext()) || (typeMask & 0x2) != 0)
/* 382 */       return hasFileSpec(text, typeMask, false); 
/* 383 */     String[] fileSpecs = ContentTypeSettings.getFileSpecs(context, this.id, typeMask); byte b; int i; String[] arrayOfString1;
/* 384 */     for (i = (arrayOfString1 = fileSpecs).length, b = 0; b < i; ) { String fileSpec = arrayOfString1[b];
/* 385 */       if (text.equalsIgnoreCase(fileSpec))
/* 386 */         return true;  b++; }
/*     */     
/* 388 */     return hasFileSpec(text, typeMask | 0x1, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasFileSpec(String text, int typeMask, boolean strict) {
/* 402 */     if (this.fileSpecs.isEmpty())
/* 403 */       return false; 
/* 404 */     for (FileSpec spec : this.fileSpecs) {
/* 405 */       if (spec.equals(text, typeMask, strict))
/* 406 */         return true; 
/*     */     } 
/* 408 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 413 */     return this.id.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean internalAddFileSpec(String fileSpec, int typeMask) {
/* 420 */     if (hasFileSpec(fileSpec, typeMask, false))
/* 421 */       return false; 
/* 422 */     FileSpec newFileSpec = createFileSpec(fileSpec, typeMask);
/* 423 */     if ((typeMask & 0x2) == 0) {
/*     */       
/* 425 */       if (this.fileSpecs.isEmpty())
/* 426 */         this.fileSpecs = new ArrayList<>(3); 
/* 427 */       this.fileSpecs.add(newFileSpec);
/* 428 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 432 */     ArrayList<FileSpec> tmpFileSpecs = (ArrayList<FileSpec>)this.fileSpecs.clone();
/* 433 */     tmpFileSpecs.add(newFileSpec);
/* 434 */     this.catalog.associate(this, newFileSpec.getText(), newFileSpec.getType());
/*     */     
/* 436 */     this.fileSpecs = tmpFileSpecs;
/* 437 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String internalGetDefaultProperty(QualifiedName key) {
/* 445 */     if (this.userCharset != null && key.equals(IContentDescription.CHARSET))
/* 446 */       return this.userCharset; 
/* 447 */     String defaultValue = basicGetDefaultProperty(key);
/* 448 */     if (defaultValue != null) {
/* 449 */       return defaultValue;
/*     */     }
/* 451 */     return (this.baseType == null) ? null : this.baseType.internalGetDefaultProperty(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String basicGetDefaultProperty(QualifiedName key) {
/* 458 */     return (this.defaultProperties == null) ? null : this.defaultProperties.get(key);
/*     */   }
/*     */   
/*     */   BasicDescription internalGetDescriptionFor(ILazySource buffer, QualifiedName[] options) throws IOException {
/* 462 */     if (buffer == null) {
/* 463 */       return this.defaultDescription;
/*     */     }
/* 465 */     IContentDescriber tmpDescriber = getDescriber();
/*     */     
/* 467 */     if (tmpDescriber == null)
/* 468 */       return this.defaultDescription; 
/* 469 */     if (buffer.isText() && !(tmpDescriber instanceof ITextContentDescriber))
/*     */     {
/* 471 */       throw new UnsupportedOperationException(); } 
/* 472 */     ContentDescription description = new ContentDescription(options, this);
/* 473 */     if (describe(tmpDescriber, buffer, description) == 0)
/*     */     {
/* 475 */       return null;
/*     */     }
/* 477 */     if (!description.isSet()) {
/* 478 */       return this.defaultDescription;
/*     */     }
/* 480 */     description.markImmutable();
/* 481 */     return description;
/*     */   }
/*     */   
/*     */   byte internalIsAssociatedWith(String fileName, IScopeContext context) {
/* 485 */     if (hasFileSpec(context, fileName, 4))
/* 486 */       return 1; 
/* 487 */     String fileExtension = ContentTypeManager.getFileExtension(fileName);
/* 488 */     if (hasFileSpec(context, fileExtension, 8)) {
/* 489 */       return 2;
/*     */     }
/* 491 */     if (!hasBuiltInAssociations() && this.baseType != null)
/* 492 */       return this.baseType.internalIsAssociatedWith(fileName, context); 
/* 493 */     return 0;
/*     */   }
/*     */   
/*     */   boolean internalRemoveFileSpec(String fileSpec, int typeMask) {
/* 497 */     if (this.fileSpecs.isEmpty()) {
/* 498 */       return false;
/*     */     }
/*     */     
/* 501 */     ArrayList<FileSpec> tmpFileSpecs = (ArrayList<FileSpec>)this.fileSpecs.clone();
/* 502 */     for (Iterator<FileSpec> i = tmpFileSpecs.iterator(); i.hasNext(); ) {
/* 503 */       FileSpec spec = i.next();
/* 504 */       if (spec.getType() == typeMask && fileSpec.equals(spec.getText())) {
/* 505 */         i.remove();
/* 506 */         this.catalog.dissociate(this, spec.getText(), spec.getType());
/*     */         
/* 508 */         this.fileSpecs = tmpFileSpecs;
/* 509 */         return true;
/*     */       } 
/*     */     } 
/* 512 */     return false;
/*     */   }
/*     */   
/*     */   public IContentDescriber invalidateDescriber(Throwable reason) {
/* 516 */     String message = NLS.bind(ContentMessages.content_invalidContentDescriber, this.id);
/* 517 */     log(message, reason);
/* 518 */     return (IContentDescriber)(this.describer = new InvalidDescriber());
/*     */   }
/*     */   
/*     */   boolean isAlias() {
/* 522 */     return (this.target != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAssociatedWith(String fileName) {
/* 527 */     return isAssociatedWith(fileName, this.manager.getContext());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAssociatedWith(String fileName, IScopeContext context) {
/* 532 */     return (internalIsAssociatedWith(fileName, context) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isKindOf(IContentType another) {
/* 537 */     if (another == null)
/* 538 */       return false; 
/* 539 */     if (this == another)
/* 540 */       return true; 
/* 541 */     return (this.baseType != null && this.baseType.isKindOf(another));
/*     */   }
/*     */   
/*     */   boolean isValid() {
/* 545 */     return (this.validation == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   void processPreferences(Preferences contentTypeNode) {
/* 550 */     this.userCharset = contentTypeNode.get("charset", null);
/*     */     
/* 552 */     String userSetFileNames = contentTypeNode.get("file-names", null);
/* 553 */     String[] fileNames = Util.parseItems(userSetFileNames); byte b1; int i; String[] arrayOfString1;
/* 554 */     for (i = (arrayOfString1 = fileNames).length, b1 = 0; b1 < i; ) { String fileName = arrayOfString1[b1];
/* 555 */       internalAddFileSpec(fileName, 6); b1++; }
/*     */     
/* 557 */     String userSetFileExtensions = contentTypeNode.get("file-extensions", null);
/* 558 */     String[] fileExtensions = Util.parseItems(userSetFileExtensions); byte b2; int j; String[] arrayOfString2;
/* 559 */     for (j = (arrayOfString2 = fileExtensions).length, b2 = 0; b2 < j; ) { String fileExtension = arrayOfString2[b2];
/* 560 */       internalAddFileSpec(fileExtension, 10); b2++; }
/*     */     
/* 562 */     String userSetFileRegexp = contentTypeNode.get("file-patterns", null);
/* 563 */     String[] fileRegexps = Util.parseItems(userSetFileRegexp); byte b3; int k; String[] arrayOfString3;
/* 564 */     for (k = (arrayOfString3 = fileRegexps).length, b3 = 0; b3 < k; ) { String fileRegexp = arrayOfString3[b3];
/* 565 */       internalAddFileSpec(fileRegexp, 18);
/*     */       b3++; }
/*     */   
/*     */   }
/*     */   
/*     */   public void removeFileSpec(String fileSpec, int type) throws CoreException {
/* 571 */     Assert.isLegal(!(type != 8 && type != 4 && type != 16), 
/* 572 */         "Unknown type: " + type);
/* 573 */     synchronized (this) {
/* 574 */       if (!internalRemoveFileSpec(fileSpec, type | 0x2)) {
/*     */         return;
/*     */       }
/*     */     } 
/* 578 */     Preferences contentTypeNode = this.manager.getPreferences().node(this.id);
/* 579 */     String[] userSet = getFileSpecs(type | 0x1);
/* 580 */     String preferenceKey = getPreferenceKey(type);
/* 581 */     String newValue = Util.toListString((Object[])userSet);
/* 582 */     setPreference(contentTypeNode, preferenceKey, newValue);
/*     */     try {
/* 584 */       contentTypeNode.flush();
/* 585 */     } catch (BackingStoreException bse) {
/* 586 */       String message = NLS.bind(ContentMessages.content_errorSavingSettings, this.id);
/* 587 */       Status status = new Status(4, "org.eclipse.core.contenttype", 0, message, (Throwable)bse);
/* 588 */       throw new CoreException(status);
/*     */     } 
/*     */     
/* 591 */     this.manager.fireContentTypeChangeEvent(this);
/*     */   }
/*     */   
/*     */   void setAliasTarget(ContentType newTarget) {
/* 595 */     this.target = newTarget;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDefaultCharset(String newCharset) throws CoreException {
/* 600 */     synchronized (this) {
/*     */       
/* 602 */       if (this.userCharset == null) {
/* 603 */         if (newCharset == null)
/*     */           return; 
/* 605 */       } else if (this.userCharset.equals(newCharset)) {
/*     */         return;
/*     */       } 
/* 608 */       this.userCharset = newCharset;
/*     */     } 
/*     */     
/* 611 */     Preferences contentTypeNode = this.manager.getPreferences().node(this.id);
/* 612 */     setPreference(contentTypeNode, "charset", this.userCharset);
/*     */     try {
/* 614 */       contentTypeNode.flush();
/* 615 */     } catch (BackingStoreException bse) {
/* 616 */       String message = NLS.bind(ContentMessages.content_errorSavingSettings, this.id);
/* 617 */       Status status = new Status(4, "org.eclipse.core.contenttype", 0, message, (Throwable)bse);
/* 618 */       throw new CoreException(status);
/*     */     } 
/*     */     
/* 621 */     this.manager.fireContentTypeChangeEvent(this);
/*     */   }
/*     */   
/*     */   static void setPreference(Preferences node, String key, String value) {
/* 625 */     if (value == null) {
/* 626 */       node.remove(key);
/*     */     } else {
/* 628 */       node.put(key, value);
/*     */     } 
/*     */   }
/*     */   void setValidation(byte validation) {
/* 632 */     this.validation = validation;
/* 633 */     if (ContentTypeManager.DebuggingHolder.DEBUGGING) {
/* 634 */       ContentMessages.message("Validating " + this + ": " + getValidationString(validation));
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/* 639 */     return this.id;
/*     */   }
/*     */   
/*     */   void setBaseType(ContentType baseType) {
/* 643 */     this.baseType = baseType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUserDefined() {
/* 648 */     return (this.contentTypeElement == null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\ContentType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */