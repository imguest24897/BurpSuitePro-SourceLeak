package org.eclipse.core.runtime.content;

public interface IContentTypeChangeListener {
  void contentTypeChanged(IContentTypeManager.ContentTypeChangeEvent paramContentTypeChangeEvent);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\runtime\content\IContentTypeManager$IContentTypeChangeListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */