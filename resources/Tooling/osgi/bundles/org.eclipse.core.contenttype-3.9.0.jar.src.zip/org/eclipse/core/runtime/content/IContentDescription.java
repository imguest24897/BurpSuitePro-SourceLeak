/*    */ package org.eclipse.core.runtime.content;
/*    */ 
/*    */ import org.eclipse.core.runtime.QualifiedName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IContentDescription
/*    */ {
/* 54 */   public static final QualifiedName CHARSET = new QualifiedName("org.eclipse.core.runtime", "charset");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 59 */   public static final QualifiedName BYTE_ORDER_MARK = new QualifiedName("org.eclipse.core.runtime", "bom");
/*    */ 
/*    */ 
/*    */   
/* 63 */   public static final QualifiedName[] ALL = null;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 68 */   public static final byte[] BOM_UTF_8 = new byte[] { -17, -69, -65 };
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 73 */   public static final byte[] BOM_UTF_16BE = new byte[] { -2, -1 };
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 78 */   public static final byte[] BOM_UTF_16LE = new byte[] { -1, -2 };
/*    */   
/*    */   boolean isRequested(QualifiedName paramQualifiedName);
/*    */   
/*    */   String getCharset();
/*    */   
/*    */   IContentType getContentType();
/*    */   
/*    */   Object getProperty(QualifiedName paramQualifiedName);
/*    */   
/*    */   void setProperty(QualifiedName paramQualifiedName, Object paramObject);
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\runtime\content\IContentDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */