/*     */ package org.eclipse.core.internal.content;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.lang.ref.SoftReference;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ import org.eclipse.core.runtime.content.IContentTypeSettings;
/*     */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentTypeHandler
/*     */   implements IContentType
/*     */ {
/*     */   private int generation;
/*     */   String id;
/*     */   private SoftReference<ContentType> targetRef;
/*     */   
/*     */   private class DummyContentDescription
/*     */     implements IContentDescription
/*     */   {
/*     */     public String getCharset() {
/*  36 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public IContentType getContentType() {
/*  41 */       return ContentTypeHandler.this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getProperty(QualifiedName key) {
/*  46 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isRequested(QualifiedName key) {
/*  51 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setProperty(QualifiedName key, Object value) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ContentTypeHandler(ContentType target, int generation) {
/*  65 */     this.id = target.getId();
/*  66 */     this.targetRef = new SoftReference<>(target);
/*  67 */     this.generation = generation;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFileSpec(String fileSpec, int type) throws CoreException {
/*  72 */     IContentType target = getTarget();
/*  73 */     if (target != null) {
/*  74 */       target.addFileSpec(fileSpec, type);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean equals(Object another) {
/*  79 */     if (another instanceof ContentType)
/*  80 */       return this.id.equals(((ContentType)another).id); 
/*  81 */     if (another instanceof ContentTypeHandler)
/*  82 */       return this.id.equals(((ContentTypeHandler)another).id); 
/*  83 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentType getBaseType() {
/*  88 */     ContentType target = getTarget();
/*  89 */     if (target == null)
/*  90 */       return null; 
/*  91 */     ContentType baseType = (ContentType)target.getBaseType();
/*  92 */     return (baseType != null) ? new ContentTypeHandler(baseType, baseType.getCatalog().getGeneration()) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDefaultCharset() {
/*  97 */     IContentType target = getTarget();
/*  98 */     return (target != null) ? target.getDefaultCharset() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentDescription getDefaultDescription() {
/* 103 */     IContentType target = getTarget();
/* 104 */     return (target != null) ? target.getDefaultDescription() : new DummyContentDescription();
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentDescription getDescriptionFor(InputStream contents, QualifiedName[] options) throws IOException {
/* 109 */     IContentType target = getTarget();
/* 110 */     return (target != null) ? target.getDescriptionFor(contents, options) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentDescription getDescriptionFor(Reader contents, QualifiedName[] options) throws IOException {
/* 115 */     IContentType target = getTarget();
/* 116 */     return (target != null) ? target.getDescriptionFor(contents, options) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getFileSpecs(int type) {
/* 121 */     IContentType target = getTarget();
/* 122 */     return (target != null) ? target.getFileSpecs(type) : new String[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public String getId() {
/* 127 */     return this.id;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 132 */     IContentType target = getTarget();
/* 133 */     return (target != null) ? target.getName() : this.id;
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentTypeSettings getSettings(IScopeContext context) throws CoreException {
/* 138 */     ContentType target = getTarget();
/* 139 */     if (target == null) {
/* 140 */       return null;
/*     */     }
/* 142 */     IContentTypeSettings settings = target.getSettings(context);
/*     */     
/* 144 */     return (settings == target) ? (IContentTypeSettings)this : settings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentType getTarget() {
/* 154 */     ContentType target = this.targetRef.get();
/* 155 */     ContentTypeCatalog catalog = ContentTypeManager.getInstance().getCatalog();
/* 156 */     if (target == null || catalog.getGeneration() != this.generation) {
/* 157 */       target = catalog.getContentType(this.id);
/* 158 */       this.targetRef = new SoftReference<>(target);
/* 159 */       this.generation = catalog.getGeneration();
/*     */     } 
/* 161 */     return (target == null) ? null : target.getAliasTarget(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 166 */     return this.id.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAssociatedWith(String fileName) {
/* 171 */     IContentType target = getTarget();
/* 172 */     return (target != null) ? target.isAssociatedWith(fileName) : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAssociatedWith(String fileName, IScopeContext context) {
/* 177 */     IContentType target = getTarget();
/* 178 */     return (target != null) ? target.isAssociatedWith(fileName, context) : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isKindOf(IContentType another) {
/* 183 */     if (another instanceof ContentTypeHandler)
/* 184 */       another = ((ContentTypeHandler)another).getTarget(); 
/* 185 */     IContentType target = getTarget();
/* 186 */     return (target != null) ? target.isKindOf(another) : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeFileSpec(String fileSpec, int type) throws CoreException {
/* 191 */     IContentType target = getTarget();
/* 192 */     if (target != null) {
/* 193 */       target.removeFileSpec(fileSpec, type);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setDefaultCharset(String userCharset) throws CoreException {
/* 198 */     IContentType target = getTarget();
/* 199 */     if (target != null) {
/* 200 */       target.setDefaultCharset(userCharset);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/* 205 */     return this.id;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUserDefined() {
/* 210 */     ContentType target = getTarget();
/* 211 */     if (target != null) {
/* 212 */       return target.isUserDefined();
/*     */     }
/* 214 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\ContentTypeHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */