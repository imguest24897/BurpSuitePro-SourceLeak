/*     */ package org.eclipse.core.internal.content;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.core.runtime.content.IContentDescriber;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ import org.eclipse.core.runtime.content.IContentTypeManager;
/*     */ import org.eclipse.core.runtime.content.XMLRootElementContentDescriber;
/*     */ import org.eclipse.core.runtime.content.XMLRootElementContentDescriber2;
/*     */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*     */ 
/*     */ public final class ContentTypeCatalog {
/*  28 */   private static final IContentType[] NO_CONTENT_TYPES = new IContentType[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  33 */   private final Map<ContentType, ContentType[]> allChildren = (Map)new HashMap<>();
/*  34 */   private final Map<String, IContentType> contentTypes = new HashMap<>();
/*  35 */   private final Map<String, Set<ContentType>> fileExtensions = new HashMap<>();
/*  36 */   private final Map<String, Set<ContentType>> fileNames = new HashMap<>();
/*  37 */   private final Map<String, Pattern> compiledRegexps = new HashMap<>();
/*  38 */   private final Map<Pattern, String> initialPatternForRegexp = new HashMap<>();
/*  39 */   private final Map<Pattern, Set<ContentType>> fileRegexps = new HashMap<>();
/*     */   
/*     */   private int generation;
/*     */   
/*     */   private ContentTypeManager manager;
/*     */   
/*     */   private final Comparator<IContentType> policyConstantGeneralIsBetter;
/*     */   private Comparator<IContentType> policyConstantSpecificIsBetter;
/*     */   private Comparator<IContentType> policyGeneralIsBetter;
/*     */   private Comparator<IContentType> policyLexicographical;
/*     */   private Comparator<IContentType> policySpecificIsBetter;
/*     */   
/*     */   private static boolean isAncestor(ContentType type1, ContentType type2) {
/*  52 */     return !(!type1.isKindOf(type2) && !type2.isKindOf(type1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentTypeCatalog(ContentTypeManager manager, int generation) {
/*  59 */     this.policyConstantGeneralIsBetter = ((o1, o2) -> {
/*     */         ContentType type1 = (ContentType)o1;
/*     */ 
/*     */         
/*     */         ContentType type2 = (ContentType)o2;
/*     */ 
/*     */         
/*     */         if (isAncestor(type1, type2)) {
/*     */           int depthCriteria = type1.getDepth() - type2.getDepth();
/*     */ 
/*     */           
/*     */           if (depthCriteria != 0) {
/*     */             return depthCriteria;
/*     */           }
/*     */         } 
/*     */         
/*     */         int priorityCriteria = type1.getPriority() - type2.getPriority();
/*     */         
/*     */         return (priorityCriteria != 0) ? -priorityCriteria : type1.getId().compareTo(type2.getId());
/*     */       });
/*     */     
/*  80 */     this.policyConstantSpecificIsBetter = ((o1, o2) -> {
/*     */         ContentType type1 = (ContentType)o1;
/*     */ 
/*     */         
/*     */         ContentType type2 = (ContentType)o2;
/*     */ 
/*     */         
/*     */         if (isAncestor(type1, type2)) {
/*     */           int depthCriteria = type1.getDepth() - type2.getDepth();
/*     */           
/*     */           if (depthCriteria != 0) {
/*     */             return -depthCriteria;
/*     */           }
/*     */         } 
/*     */         
/*     */         int priorityCriteria = type1.getPriority() - type2.getPriority();
/*     */         
/*     */         return (priorityCriteria != 0) ? -priorityCriteria : type1.getId().compareTo(type2.getId());
/*     */       });
/*     */     
/* 100 */     this.policyGeneralIsBetter = ((o1, o2) -> {
/*     */         ContentType type1 = (ContentType)o1;
/*     */ 
/*     */         
/*     */         ContentType type2 = (ContentType)o2;
/*     */         
/*     */         if (isAncestor(type1, type2)) {
/*     */           int depthCriteria = type1.getDepth() - type2.getDepth();
/*     */           
/*     */           if (depthCriteria != 0) {
/*     */             return depthCriteria;
/*     */           }
/*     */         } 
/*     */         
/*     */         int priorityCriteria = type1.getPriority() - type2.getPriority();
/*     */         
/*     */         return (priorityCriteria != 0) ? -priorityCriteria : 0;
/*     */       });
/*     */     
/* 119 */     this.policyLexicographical = ((o1, o2) -> {
/*     */         ContentType type1 = (ContentType)o1;
/*     */         
/*     */         ContentType type2 = (ContentType)o2;
/*     */         
/*     */         return type1.getId().compareTo(type2.getId());
/*     */       });
/*     */     
/* 127 */     this.policySpecificIsBetter = ((o1, o2) -> {
/*     */         ContentType type1 = (ContentType)o1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         ContentType type2 = (ContentType)o2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         if (isAncestor(type1, type2)) {
/*     */           int depthCriteria = type1.getDepth() - type2.getDepth();
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           if (depthCriteria != 0) {
/*     */             return -depthCriteria;
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         int priorityCriteria = type1.getPriority() - type2.getPriority();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         return (priorityCriteria != 0) ? -priorityCriteria : 0;
/*     */       });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 165 */     this.manager = manager;
/* 166 */     this.generation = generation;
/*     */   }
/*     */   
/*     */   synchronized void addContentType(IContentType contentType) {
/* 170 */     this.contentTypes.put(contentType.getId(), contentType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IContentType[] applyPolicy(final IContentTypeManager.ISelectionPolicy policy, final IContentType[] candidates, final boolean fileName, final boolean contents) {
/* 177 */     final IContentType[][] result = { candidates };
/* 178 */     SafeRunner.run(new ISafeRunnable()
/*     */         {
/*     */           public void handleException(Throwable exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void run() throws Exception {
/* 188 */             result[0] = policy.select(candidates, fileName, contents);
/*     */           }
/*     */         });
/* 191 */     return result[0];
/*     */   } private static IContentType[] concat(IContentType[][] types) { int size = 0; IContentType[] nonEmptyOne = NO_CONTENT_TYPES; byte b1; int i; IContentType[][] arrayOfIContentType1; for (i = (arrayOfIContentType1 = types).length, b1 = 0; b1 < i; ) { IContentType[] array = arrayOfIContentType1[b1]; size += array.length; if (array.length > 0)
/*     */         nonEmptyOne = array;  b1++; }  if (nonEmptyOne.length == size)
/*     */       return nonEmptyOne;  IContentType[] result = new IContentType[size]; int currentIndex = 0; byte b2; int j; IContentType[][] arrayOfIContentType2; for (j = (arrayOfIContentType2 = types).length, b2 = 0; b2 < j; ) { IContentType[] array = arrayOfIContentType2[b2]; System.arraycopy(array, 0, result, currentIndex, array.length); currentIndex += array.length; b2++; }
/* 195 */      return result; } private void associate(ContentType contentType) { String[] builtInFileNames = contentType.getFileSpecs(6); byte b; int i; String[] arrayOfString1;
/* 196 */     for (i = (arrayOfString1 = builtInFileNames).length, b = 0; b < i; ) { String builtInFileName = arrayOfString1[b];
/* 197 */       associate(contentType, builtInFileName, 4); b++; }
/* 198 */      String[] builtInFileExtensions = contentType.getFileSpecs(10); int j; String[] arrayOfString2;
/* 199 */     for (j = (arrayOfString2 = builtInFileExtensions).length, i = 0; i < j; ) { String builtInFileExtension = arrayOfString2[i];
/* 200 */       associate(contentType, builtInFileExtension, 8); i++; }
/* 201 */      String[] builtInFilePatterns = contentType
/* 202 */       .getFileSpecs(18); String[] arrayOfString3;
/* 203 */     for (int k = (arrayOfString3 = builtInFilePatterns).length; j < k; ) { String builtInFilePattern = arrayOfString3[j];
/* 204 */       associate(contentType, builtInFilePattern, 16);
/*     */       j++; }
/*     */      }
/*     */   
/*     */   String toRegexp(String filePattern) {
/* 209 */     return filePattern.replace(".", "\\.").replace('?', '.').replace("*", ".*");
/*     */   }
/*     */   
/*     */   synchronized void associate(ContentType contentType, String text, int type) {
/* 213 */     Map<String, Set<ContentType>> fileSpecMap = null;
/* 214 */     if ((type & 0x4) != 0) {
/* 215 */       fileSpecMap = this.fileNames;
/* 216 */     } else if ((type & 0x8) != 0) {
/* 217 */       fileSpecMap = this.fileExtensions;
/*     */     } 
/* 219 */     if (fileSpecMap != null) {
/* 220 */       String mappingKey = FileSpec.getMappingKeyFor(text);
/* 221 */       Set<ContentType> existing = fileSpecMap.get(mappingKey);
/* 222 */       if (existing == null)
/* 223 */         fileSpecMap.put(mappingKey, existing = new HashSet<>()); 
/* 224 */       existing.add(contentType);
/* 225 */     } else if ((type & 0x10) != 0) {
/* 226 */       Pattern compiledPattern = this.compiledRegexps.get(text);
/* 227 */       if (compiledPattern == null) {
/* 228 */         compiledPattern = Pattern.compile(toRegexp(text));
/* 229 */         this.compiledRegexps.put(text, compiledPattern);
/* 230 */         this.initialPatternForRegexp.put(compiledPattern, text);
/* 231 */         this.fileRegexps.put(compiledPattern, new HashSet<>());
/*     */       } 
/* 233 */       ((Set<ContentType>)this.fileRegexps.get(compiledPattern)).add(contentType);
/*     */     }  } private int collectMatchingByContents(int valid, IContentType[] subset, List<ContentType> destination, ILazySource contents, Map<String, Object> properties) throws IOException {
/*     */     byte b;
/*     */     int i;
/*     */     IContentType[] arrayOfIContentType;
/* 238 */     for (i = (arrayOfIContentType = subset).length, b = 0; b < i; ) { IContentType element = arrayOfIContentType[b];
/* 239 */       ContentType current = (ContentType)element;
/* 240 */       IContentDescriber describer = current.getDescriber();
/* 241 */       int status = 1;
/* 242 */       if (describer != null) {
/* 243 */         if (contents.isText() && !(describer instanceof ITextContentDescriber)) {
/*     */           continue;
/*     */         }
/* 246 */         status = describe(current, contents, null, properties);
/* 247 */         if (status == 0)
/*     */           continue; 
/*     */       } 
/* 250 */       if (status == 2) {
/* 251 */         destination.add(valid++, current);
/*     */       } else {
/* 253 */         destination.add(current);
/*     */       }  continue; b++; }
/* 255 */      return valid;
/*     */   }
/*     */ 
/*     */   
/*     */   int describe(ContentType type, ILazySource contents, ContentDescription description, Map<String, Object> properties) throws IOException {
/* 260 */     IContentDescriber describer = type.getDescriber();
/*     */     try {
/* 262 */       if (contents.isText()) {
/* 263 */         if (describer instanceof XMLRootElementContentDescriber2)
/* 264 */           return ((XMLRootElementContentDescriber2)describer).describe((Reader)contents, description, properties); 
/* 265 */         if (describer instanceof XMLRootElementContentDescriber) {
/* 266 */           return ((XMLRootElementContentDescriber)describer).describe((Reader)contents, description, properties);
/*     */         }
/* 268 */         return ((ITextContentDescriber)describer).describe((Reader)contents, description);
/*     */       } 
/* 270 */       if (describer instanceof XMLRootElementContentDescriber2)
/* 271 */         return ((XMLRootElementContentDescriber2)describer).describe((InputStream)contents, description, properties); 
/* 272 */       if (describer instanceof XMLRootElementContentDescriber) {
/* 273 */         return ((XMLRootElementContentDescriber)describer).describe((InputStream)contents, description, properties);
/*     */       }
/* 275 */       return describer.describe((InputStream)contents, description);
/*     */     }
/* 277 */     catch (RuntimeException re) {
/*     */       
/* 279 */       type.invalidateDescriber(re);
/* 280 */     } catch (Error e) {
/*     */       
/* 282 */       type.invalidateDescriber(e);
/* 283 */       throw e;
/* 284 */     } catch (LowLevelIOException llioe) {
/*     */       
/* 286 */       throw llioe.getActualException();
/* 287 */     } catch (IOException ioe) {
/*     */       
/* 289 */       String message = NLS.bind(ContentMessages.content_errorReadingContents, type.getId());
/* 290 */       ContentType.log(message, ioe);
/*     */       
/* 292 */       return 1;
/*     */     } finally {
/* 294 */       contents.rewind();
/*     */     } 
/* 296 */     return 0;
/*     */   }
/*     */   
/*     */   synchronized void dissociate(ContentType contentType, String text, int type) {
/* 300 */     Map<String, Set<ContentType>> fileSpecMap = null;
/* 301 */     if ((type & 0x4) != 0) {
/* 302 */       fileSpecMap = this.fileNames;
/* 303 */     } else if ((type & 0x8) != 0) {
/* 304 */       fileSpecMap = this.fileExtensions;
/*     */     } 
/* 306 */     if (fileSpecMap != null) {
/* 307 */       String mappingKey = FileSpec.getMappingKeyFor(text);
/* 308 */       Set<ContentType> existing = fileSpecMap.get(mappingKey);
/* 309 */       if (existing == null)
/*     */         return; 
/* 311 */       existing.remove(contentType);
/* 312 */     } else if ((type & 0x10) != 0) {
/* 313 */       Pattern pattern = this.compiledRegexps.get(text);
/* 314 */       ((Set)this.fileRegexps.get(pattern)).remove(contentType);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ensureValid(ContentType type) {
/* 332 */     if (type.getValidation() != 0)
/*     */     {
/* 334 */       return type.isValid();
/*     */     }
/*     */     
/* 337 */     type.setValidation((byte)2);
/* 338 */     if (type.isAlias())
/*     */     {
/* 340 */       return false;
/*     */     }
/* 342 */     ContentType baseType = null;
/* 343 */     if (type.getBaseTypeId() != null) {
/* 344 */       baseType = (ContentType)this.contentTypes.get(type.getBaseTypeId());
/* 345 */       if (baseType == null)
/*     */       {
/* 347 */         return false;
/*     */       }
/* 349 */       baseType = baseType.getAliasTarget(true);
/* 350 */       ensureValid(baseType);
/* 351 */       if (baseType.getValidation() != 1)
/*     */       {
/* 353 */         return false;
/*     */       }
/*     */     } 
/* 356 */     type.setValidation((byte)1);
/* 357 */     type.setBaseType(baseType);
/* 358 */     return true;
/*     */   }
/*     */   
/*     */   IContentType[] findContentTypesFor(ContentTypeMatcher matcher, InputStream contents, String fileName) throws IOException {
/* 362 */     ILazySource buffer = ContentTypeManager.readBuffer(contents);
/* 363 */     IContentType[] selected = internalFindContentTypesFor(matcher, buffer, fileName, true);
/*     */     
/* 365 */     IContentTypeManager.ISelectionPolicy policy = matcher.getPolicy();
/* 366 */     if (policy != null)
/* 367 */       selected = applyPolicy(policy, selected, (fileName != null), true); 
/* 368 */     return selected;
/*     */   }
/*     */   
/*     */   IContentType[] findContentTypesFor(ContentTypeMatcher matcher, String fileName) {
/* 372 */     IContentType[] selected = concat(internalFindContentTypesFor(matcher, fileName, this.policyConstantGeneralIsBetter));
/*     */     
/* 374 */     IContentTypeManager.ISelectionPolicy policy = matcher.getPolicy();
/* 375 */     if (policy != null)
/* 376 */       selected = applyPolicy(policy, selected, true, false); 
/* 377 */     return selected;
/*     */   }
/*     */   
/*     */   public synchronized IContentType[] getAllContentTypes() {
/* 381 */     List<ContentType> result = new ArrayList<>(this.contentTypes.size());
/* 382 */     for (IContentType iContentType : this.contentTypes.values()) {
/* 383 */       ContentType type = (ContentType)iContentType;
/* 384 */       if (type.isValid() && !type.isAlias())
/* 385 */         result.add(type); 
/*     */     } 
/* 387 */     return result.<IContentType>toArray(new IContentType[result.size()]);
/*     */   }
/*     */   
/*     */   private ContentType[] getChildren(ContentType parent) {
/* 391 */     ContentType[] children = this.allChildren.get(parent);
/* 392 */     if (children != null)
/* 393 */       return children; 
/* 394 */     List<ContentType> result = new ArrayList<>(5);
/* 395 */     for (IContentType iContentType : this.contentTypes.values()) {
/* 396 */       ContentType next = (ContentType)iContentType;
/* 397 */       if (next.getBaseType() == parent)
/* 398 */         result.add(next); 
/*     */     } 
/* 400 */     children = result.<ContentType>toArray(new ContentType[result.size()]);
/* 401 */     this.allChildren.put(parent, children);
/* 402 */     return children;
/*     */   }
/*     */   
/*     */   public ContentType getContentType(String contentTypeIdentifier) {
/* 406 */     ContentType type = internalGetContentType(contentTypeIdentifier);
/* 407 */     return (type != null && type.isValid() && !type.isAlias()) ? type : null;
/*     */   }
/*     */   
/*     */   private IContentDescription getDescriptionFor(ContentTypeMatcher matcher, ILazySource contents, String fileName, QualifiedName[] options) throws IOException {
/* 411 */     IContentType[] selected = internalFindContentTypesFor(matcher, contents, fileName, false);
/* 412 */     if (selected.length == 0) {
/* 413 */       return null;
/*     */     }
/* 415 */     IContentTypeManager.ISelectionPolicy policy = matcher.getPolicy();
/* 416 */     if (policy != null) {
/* 417 */       selected = applyPolicy(policy, selected, (fileName != null), true);
/* 418 */       if (selected.length == 0)
/* 419 */         return null; 
/*     */     } 
/* 421 */     return matcher.getSpecificDescription(((ContentType)selected[0]).internalGetDescriptionFor(contents, options));
/*     */   }
/*     */   
/*     */   public IContentDescription getDescriptionFor(ContentTypeMatcher matcher, InputStream contents, String fileName, QualifiedName[] options) throws IOException {
/* 425 */     return getDescriptionFor(matcher, ContentTypeManager.readBuffer(contents), fileName, options);
/*     */   }
/*     */   
/*     */   public IContentDescription getDescriptionFor(ContentTypeMatcher matcher, Reader contents, String fileName, QualifiedName[] options) throws IOException {
/* 429 */     return getDescriptionFor(matcher, ContentTypeManager.readBuffer(contents), fileName, options);
/*     */   }
/*     */   
/*     */   public int getGeneration() {
/* 433 */     return this.generation;
/*     */   }
/*     */   
/*     */   public ContentTypeManager getManager() {
/* 437 */     return this.manager;
/*     */   }
/*     */   
/*     */   private boolean internalAccept(ContentTypeVisitor visitor, ContentType root) {
/* 441 */     if (!root.isValid() || root.isAlias())
/* 442 */       return true; 
/* 443 */     int result = visitor.visit(root);
/* 444 */     switch (result) {
/*     */       
/*     */       case 2:
/* 447 */         return false;
/*     */       
/*     */       case 1:
/* 450 */         return true;
/*     */     } 
/* 452 */     ContentType[] children = getChildren(root);
/* 453 */     if (children == null)
/*     */     {
/* 455 */       return true; }  byte b; int i; ContentType[] arrayOfContentType1;
/* 456 */     for (i = (arrayOfContentType1 = children).length, b = 0; b < i; ) { ContentType c = arrayOfContentType1[b];
/* 457 */       if (!internalAccept(visitor, c))
/*     */       {
/* 459 */         return false; } 
/*     */       b++; }
/*     */     
/* 462 */     return true;
/*     */   }
/*     */   
/*     */   private IContentType[] internalFindContentTypesFor(ILazySource buffer, IContentType[][] subset, Comparator<IContentType> validPolicy, Comparator<IContentType> indeterminatePolicy) throws IOException {
/* 466 */     Map<String, Object> properties = new HashMap<>();
/* 467 */     List<ContentType> appropriate = new ArrayList<>(5);
/* 468 */     int validFullName = collectMatchingByContents(0, subset[0], appropriate, buffer, properties);
/* 469 */     int appropriateFullName = appropriate.size();
/* 470 */     int validExtension = collectMatchingByContents(validFullName, subset[1], appropriate, buffer, properties) - validFullName;
/* 471 */     int appropriateExtension = appropriate.size() - appropriateFullName;
/* 472 */     int validPattern = collectMatchingByContents(validExtension, subset[2], appropriate, buffer, properties) - 
/* 473 */       validExtension;
/* 474 */     int appropriatePattern = appropriate.size() - appropriateFullName - appropriateExtension;
/* 475 */     IContentType[] result = appropriate.<IContentType>toArray(new IContentType[appropriate.size()]);
/* 476 */     if (validFullName > 1)
/* 477 */       Arrays.sort(result, 0, validFullName, validPolicy); 
/* 478 */     if (validExtension > 1)
/* 479 */       Arrays.sort(result, validFullName, validFullName + validExtension, validPolicy); 
/* 480 */     if (validPattern > 1) {
/* 481 */       Arrays.sort(result, validFullName + validExtension, validFullName + validExtension + validPattern, 
/* 482 */           validPolicy);
/*     */     }
/* 484 */     if (appropriateFullName - validFullName > 1)
/* 485 */       Arrays.sort(result, validFullName + validExtension, appropriateFullName + validExtension, indeterminatePolicy); 
/* 486 */     if (appropriateExtension - validExtension > 1)
/* 487 */       Arrays.sort(result, appropriateFullName + validExtension, appropriate.size() - validPattern, 
/* 488 */           indeterminatePolicy); 
/* 489 */     if (appropriatePattern - validPattern > 1) {
/* 490 */       Arrays.sort(result, appropriate.size() - validPattern, appropriate.size(), indeterminatePolicy);
/*     */     }
/* 492 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private IContentType[] internalFindContentTypesFor(ContentTypeMatcher matcher, ILazySource buffer, String fileName, boolean forceValidation) throws IOException {
/*     */     IContentType[][] subset;
/*     */     Comparator<IContentType> validPolicy, indeterminatePolicy;
/* 499 */     if (fileName == null) {
/*     */ 
/*     */       
/* 502 */       subset = new IContentType[][] { getAllContentTypes(), NO_CONTENT_TYPES, NO_CONTENT_TYPES };
/* 503 */       indeterminatePolicy = this.policyConstantGeneralIsBetter;
/* 504 */       validPolicy = this.policyConstantSpecificIsBetter;
/*     */     } else {
/* 506 */       subset = internalFindContentTypesFor(matcher, fileName, this.policyLexicographical);
/* 507 */       indeterminatePolicy = this.policyGeneralIsBetter;
/* 508 */       validPolicy = this.policySpecificIsBetter;
/*     */     } 
/* 510 */     int total = (subset[0]).length + (subset[1]).length + (subset[2]).length;
/* 511 */     if (total == 0)
/*     */     {
/* 513 */       return NO_CONTENT_TYPES; } 
/* 514 */     if (!forceValidation && total == 1) {
/*     */       
/* 516 */       IContentType[] found = ((subset[0]).length == 1) ? subset[0] : (((subset[1]).length == 1) ? subset[1] : subset[2]);
/*     */       
/* 518 */       if (!buffer.isText())
/*     */       {
/* 520 */         return found;
/*     */       }
/* 522 */       IContentDescriber describer = ((ContentType)found[0]).getDescriber();
/* 523 */       if (describer == null || describer instanceof ITextContentDescriber)
/*     */       {
/* 525 */         return found;
/*     */       }
/* 527 */       return NO_CONTENT_TYPES;
/*     */     } 
/* 529 */     return internalFindContentTypesFor(buffer, subset, validPolicy, indeterminatePolicy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized IContentType[][] internalFindContentTypesFor(ContentTypeMatcher matcher, String fileName, Comparator<IContentType> sortingPolicy) {
/*     */     Set<ContentType> allByFileName, allByFilePattern;
/* 539 */     IScopeContext context = matcher.getContext();
/* 540 */     IContentType[][] result = { NO_CONTENT_TYPES, NO_CONTENT_TYPES, NO_CONTENT_TYPES };
/*     */     
/* 542 */     Set<ContentType> existing = new HashSet<>();
/*     */ 
/*     */     
/* 545 */     if (context.equals(this.manager.getContext())) {
/* 546 */       allByFileName = getDirectlyAssociated(fileName, 4);
/*     */     } else {
/* 548 */       allByFileName = new HashSet<>(getDirectlyAssociated(fileName, 6));
/* 549 */       allByFileName.addAll(matcher.getDirectlyAssociated(this, fileName, 4));
/*     */     } 
/* 551 */     Set<ContentType> selectedByName = selectMatchingByName(context, allByFileName, Collections.emptySet(), fileName, 
/* 552 */         4);
/* 553 */     existing.addAll(selectedByName);
/* 554 */     result[0] = selectedByName.<IContentType>toArray(new IContentType[selectedByName.size()]);
/* 555 */     if ((result[0]).length > 1) {
/* 556 */       Arrays.sort(result[0], sortingPolicy);
/*     */     }
/* 558 */     String fileExtension = ContentTypeManager.getFileExtension(fileName);
/* 559 */     if (fileExtension != null) {
/*     */       Set<ContentType> allByFileExtension;
/* 561 */       if (context.equals(this.manager.getContext())) {
/* 562 */         allByFileExtension = getDirectlyAssociated(fileExtension, 8);
/*     */       } else {
/* 564 */         allByFileExtension = new HashSet<>(getDirectlyAssociated(fileExtension, 10));
/* 565 */         allByFileExtension.addAll(matcher.getDirectlyAssociated(this, fileExtension, 8));
/*     */       } 
/* 567 */       Set<ContentType> selectedByExtension = selectMatchingByName(context, allByFileExtension, selectedByName, fileExtension, 8);
/* 568 */       existing.addAll(selectedByExtension);
/* 569 */       if (!selectedByExtension.isEmpty())
/* 570 */         result[1] = selectedByExtension.<IContentType>toArray(new IContentType[selectedByExtension.size()]); 
/*     */     } 
/* 572 */     if ((result[1]).length > 1) {
/* 573 */       Arrays.sort(result[1], sortingPolicy);
/*     */     }
/*     */     
/* 576 */     if (context.equals(this.manager.getContext())) {
/* 577 */       allByFilePattern = getMatchingRegexpAssociated(fileName, 16);
/*     */     } else {
/* 579 */       allByFilePattern = new HashSet<>(getMatchingRegexpAssociated(fileName, 
/* 580 */             18));
/* 581 */       allByFilePattern
/* 582 */         .addAll(matcher.getMatchingRegexpAssociated(this, fileName, 
/* 583 */             16));
/*     */     } 
/* 585 */     existing.addAll(allByFilePattern);
/* 586 */     if (!allByFilePattern.isEmpty()) {
/* 587 */       result[2] = allByFilePattern.<IContentType>toArray(new IContentType[allByFilePattern.size()]);
/*     */     }
/* 589 */     return result;
/*     */   }
/*     */   
/*     */   private Set<ContentType> getMatchingRegexpAssociated(String fileName, int typeMask) {
/* 593 */     if ((typeMask & 0x10) == 0) {
/* 594 */       throw new IllegalArgumentException("This method requires FILE_PATTERN_SPEC.");
/*     */     }
/* 596 */     Set<ContentType> res = new HashSet<>();
/* 597 */     for (Map.Entry<Pattern, Set<ContentType>> spec : this.fileRegexps.entrySet()) {
/* 598 */       if (((Pattern)spec.getKey()).matcher(fileName).matches()) {
/* 599 */         res.addAll(filterOnDefinitionSource(this.initialPatternForRegexp.get(spec.getKey()), typeMask, 
/* 600 */               spec.getValue()));
/*     */       }
/*     */     } 
/* 603 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Set<ContentType> getDirectlyAssociated(String text, int typeMask) {
/* 620 */     if ((typeMask & 0x10) != 0) {
/* 621 */       throw new IllegalArgumentException("This method don't allow FILE_REGEXP_SPEC.");
/*     */     }
/* 623 */     Map<String, Set<ContentType>> associations = ((typeMask & 0x4) != 0) ? this.fileNames : this.fileExtensions;
/* 624 */     Set<ContentType> result = associations.get(FileSpec.getMappingKeyFor(text));
/* 625 */     if ((typeMask & 0x3) != 0) {
/* 626 */       result = filterOnDefinitionSource(text, typeMask, result);
/*     */     }
/* 628 */     return (result == null) ? Collections.EMPTY_SET : result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Set<ContentType> filterOnDefinitionSource(String text, int typeMask, Set<ContentType> contentTypes) {
/* 647 */     if ((typeMask & 0x3) == 0) {
/* 648 */       return contentTypes;
/*     */     }
/* 650 */     if (contentTypes != null && !contentTypes.isEmpty()) {
/*     */       
/* 652 */       contentTypes = new HashSet<>(contentTypes);
/*     */       
/* 654 */       typeMask ^= 0x3;
/* 655 */       for (Iterator<ContentType> i = contentTypes.iterator(); i.hasNext(); ) {
/* 656 */         ContentType contentType = i.next();
/* 657 */         if (!contentType.hasFileSpec(text, typeMask, true))
/* 658 */           i.remove(); 
/*     */       } 
/*     */     } 
/* 661 */     return contentTypes;
/*     */   }
/*     */   
/*     */   synchronized ContentType internalGetContentType(String contentTypeIdentifier) {
/* 665 */     return (ContentType)this.contentTypes.get(contentTypeIdentifier);
/*     */   }
/*     */ 
/*     */   
/*     */   private void makeAliases() {
/* 670 */     for (IContentType iContentType : this.contentTypes.values()) {
/* 671 */       ContentType type = (ContentType)iContentType;
/* 672 */       String targetId = type.getAliasTargetId();
/* 673 */       if (targetId == null)
/*     */         continue; 
/* 675 */       ContentType target = internalGetContentType(targetId);
/* 676 */       if (target != null) {
/* 677 */         type.setAliasTarget(target);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void organize() {
/* 686 */     makeAliases();
/*     */     
/* 688 */     for (IContentType iContentType : this.contentTypes.values()) {
/* 689 */       ContentType type = (ContentType)iContentType;
/* 690 */       if (ensureValid(type))
/* 691 */         associate(type); 
/*     */     } 
/* 693 */     if (ContentTypeManager.DebuggingHolder.DEBUGGING) {
/* 694 */       for (IContentType iContentType : this.contentTypes.values()) {
/* 695 */         ContentType type = (ContentType)iContentType;
/* 696 */         if (!type.isValid()) {
/* 697 */           ContentMessages.message("Invalid: " + type);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Set<ContentType> selectMatchingByName(final IScopeContext context, Collection<ContentType> source, final Collection<ContentType> existing, final String fileSpecText, final int fileSpecType) {
/* 706 */     if (source == null || source.isEmpty())
/* 707 */       return Collections.EMPTY_SET; 
/* 708 */     final Set<ContentType> destination = new HashSet<>(5);
/*     */     
/* 710 */     for (ContentType root : source) {
/*     */ 
/*     */       
/* 713 */       internalAccept(new ContentTypeVisitor()
/*     */           {
/*     */             public int visit(ContentType type) {
/* 716 */               if (type != root && type.hasBuiltInAssociations())
/*     */               {
/* 718 */                 return 1; } 
/* 719 */               if (type == root && !type.hasFileSpec(context, fileSpecText, fileSpecType))
/*     */               {
/* 721 */                 return 1;
/*     */               }
/*     */               
/* 724 */               if (!existing.contains(type))
/* 725 */                 destination.add(type); 
/* 726 */               return 0;
/*     */             }
/* 728 */           }root);
/*     */     } 
/* 730 */     return destination;
/*     */   }
/*     */   
/*     */   void removeContentType(String contentTypeIdentifier) throws CoreException {
/* 734 */     ContentType contentType = getContentType(contentTypeIdentifier);
/* 735 */     if (contentType == null) {
/*     */       return;
/*     */     }
/* 738 */     if (!contentType.isUserDefined()) {
/* 739 */       throw new IllegalArgumentException("Content type must be user-defined.");
/*     */     }
/* 741 */     this.contentTypes.remove(contentType.getId());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\ContentTypeCatalog.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */