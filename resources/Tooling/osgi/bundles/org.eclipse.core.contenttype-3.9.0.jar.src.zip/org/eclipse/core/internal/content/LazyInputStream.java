/*     */ package org.eclipse.core.internal.content;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LazyInputStream
/*     */   extends InputStream
/*     */   implements ILazySource
/*     */ {
/*     */   private int blockCapacity;
/*  21 */   byte[][] blocks = new byte[0][];
/*     */   private int bufferSize;
/*     */   private InputStream in;
/*     */   private int mark;
/*     */   private int offset;
/*     */   
/*     */   public LazyInputStream(InputStream in, int blockCapacity) {
/*  28 */     this.in = in;
/*  29 */     this.blockCapacity = blockCapacity;
/*     */   }
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/*     */     try {
/*  35 */       return this.bufferSize - this.offset + this.in.available();
/*  36 */     } catch (IOException ioe) {
/*  37 */       throw new LowLevelIOException(ioe);
/*     */     } 
/*     */   }
/*     */   
/*     */   private int computeBlockSize(int blockIndex) {
/*  42 */     if (blockIndex < this.blocks.length - 1)
/*  43 */       return this.blockCapacity; 
/*  44 */     int blockSize = this.bufferSize % this.blockCapacity;
/*  45 */     return (blockSize == 0) ? this.blockCapacity : blockSize;
/*     */   }
/*     */   
/*     */   private int copyFromBuffer(byte[] userBuffer, int userOffset, int needed) {
/*  49 */     int copied = 0;
/*  50 */     int current = this.offset / this.blockCapacity;
/*  51 */     while (needed - copied > 0 && current < this.blocks.length) {
/*  52 */       int blockSize = computeBlockSize(current);
/*  53 */       int offsetInBlock = this.offset % this.blockCapacity;
/*  54 */       int availableInBlock = blockSize - offsetInBlock;
/*  55 */       int toCopy = Math.min(availableInBlock, needed - copied);
/*  56 */       System.arraycopy(this.blocks[current], offsetInBlock, userBuffer, userOffset + copied, toCopy);
/*  57 */       copied += toCopy;
/*  58 */       current++;
/*  59 */       this.offset += toCopy;
/*     */     } 
/*  61 */     return copied;
/*     */   }
/*     */   
/*     */   private void ensureAvailable(long bytesToRead) throws IOException {
/*  65 */     int loadedBlockSize = this.blockCapacity;
/*  66 */     while (this.bufferSize < this.offset + bytesToRead && loadedBlockSize == this.blockCapacity) {
/*     */       try {
/*  68 */         loadedBlockSize = loadBlock();
/*  69 */       } catch (IOException e) {
/*  70 */         throw new LowLevelIOException(e);
/*     */       } 
/*  72 */       this.bufferSize += loadedBlockSize;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getBlockCount() {
/*  78 */     return this.blocks.length;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getBufferSize() {
/*  83 */     return this.bufferSize;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getMark() {
/*  88 */     return this.mark;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getOffset() {
/*  93 */     return this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isText() {
/*  98 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private int loadBlock() throws IOException {
/* 103 */     byte[] newBlock = new byte[this.blockCapacity];
/* 104 */     int readCount = this.in.read(newBlock);
/* 105 */     if (readCount == -1) {
/* 106 */       return 0;
/*     */     }
/* 108 */     byte[][] tmpBlocks = new byte[this.blocks.length + 1][];
/* 109 */     System.arraycopy(this.blocks, 0, tmpBlocks, 0, this.blocks.length);
/* 110 */     this.blocks = tmpBlocks;
/* 111 */     this.blocks[this.blocks.length - 1] = newBlock;
/* 112 */     return readCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void mark(int readlimit) {
/* 117 */     this.mark = this.offset;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 122 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 127 */     ensureAvailable(1L);
/* 128 */     if (this.bufferSize <= this.offset)
/* 129 */       return -1; 
/* 130 */     int nextByte = 0xFF & this.blocks[this.offset / this.blockCapacity][this.offset % this.blockCapacity];
/* 131 */     this.offset++;
/* 132 */     return nextByte;
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b) throws IOException {
/* 137 */     return read(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 142 */     ensureAvailable(len);
/* 143 */     int copied = copyFromBuffer(b, off, len);
/* 144 */     return (copied == 0) ? -1 : copied;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void reset() {
/* 149 */     this.offset = this.mark;
/*     */   }
/*     */ 
/*     */   
/*     */   public void rewind() {
/* 154 */     this.mark = 0;
/* 155 */     this.offset = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public long skip(long toSkip) throws IOException {
/* 160 */     if (toSkip <= 0L)
/* 161 */       return 0L; 
/* 162 */     ensureAvailable(toSkip);
/* 163 */     long skipped = Math.min(toSkip, (this.bufferSize - this.offset));
/* 164 */     this.offset = (int)(this.offset + skipped);
/* 165 */     return skipped;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\LazyInputStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */