/*     */ package org.eclipse.core.internal.content;
/*     */ 
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ContentDescription
/*     */   extends BasicDescription
/*     */ {
/*     */   private static final String CHARSET_UTF_16 = "UTF-16";
/*     */   private static final String CHARSET_UTF_8 = "UTF-8";
/*     */   private static final byte FLAG_ALL_OPTIONS = 1;
/*     */   private static final byte FLAG_IMMUTABLE = 2;
/*     */   private byte flags;
/*     */   private Object keys;
/*     */   private Object values;
/*     */   
/*     */   public ContentDescription(QualifiedName[] requested, IContentTypeInfo contentTypeInfo) {
/*  30 */     super(contentTypeInfo);
/*  31 */     if (requested == IContentDescription.ALL) {
/*  32 */       this.flags = (byte)(this.flags | 0x1);
/*     */       return;
/*     */     } 
/*  35 */     if (requested.length > 1) {
/*  36 */       this.keys = requested;
/*  37 */       this.values = new Object[requested.length];
/*  38 */     } else if (requested.length == 1) {
/*  39 */       this.keys = requested[0];
/*     */     } 
/*     */   }
/*     */   
/*     */   private void assertMutable() {
/*  44 */     if ((this.flags & 0x2) != 0) {
/*  45 */       throw new IllegalStateException("Content description is immutable");
/*     */     }
/*     */   }
/*     */   
/*     */   public String getCharset() {
/*  50 */     byte[] bom = (byte[])getProperty(BYTE_ORDER_MARK);
/*  51 */     if (bom == BOM_UTF_8)
/*  52 */       return "UTF-8"; 
/*  53 */     if (bom == BOM_UTF_16BE || bom == BOM_UTF_16LE)
/*     */     {
/*  55 */       return "UTF-16"; } 
/*  56 */     return (String)getProperty(CHARSET);
/*     */   }
/*     */ 
/*     */   
/*     */   private Object getDescribedProperty(QualifiedName key) {
/*  61 */     if (this.values == null) {
/*  62 */       return null;
/*     */     }
/*  64 */     if (this.keys instanceof QualifiedName) {
/*  65 */       return this.keys.equals(key) ? this.values : null;
/*     */     }
/*  67 */     QualifiedName[] tmpKeys = (QualifiedName[])this.keys;
/*  68 */     for (int i = 0; i < tmpKeys.length; i++) {
/*  69 */       if (tmpKeys[i].equals(key))
/*  70 */         return ((Object[])this.values)[i]; 
/*  71 */     }  return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getProperty(QualifiedName key) {
/*  76 */     Object describedProperty = getDescribedProperty(key);
/*  77 */     if (describedProperty != null)
/*  78 */       return describedProperty; 
/*  79 */     return this.contentTypeInfo.getDefaultProperty(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRequested(QualifiedName propertyKey) {
/*  85 */     if ((this.flags & 0x1) != 0) {
/*  86 */       return true;
/*     */     }
/*  88 */     if (this.keys == null) {
/*  89 */       return false;
/*     */     }
/*  91 */     if (this.keys instanceof QualifiedName) {
/*  92 */       return this.keys.equals(propertyKey);
/*     */     }
/*  94 */     QualifiedName[] tmpKeys = (QualifiedName[])this.keys; byte b; int i; QualifiedName[] arrayOfQualifiedName1;
/*  95 */     for (i = (arrayOfQualifiedName1 = tmpKeys).length, b = 0; b < i; ) { QualifiedName tmpKey = arrayOfQualifiedName1[b];
/*  96 */       if (tmpKey.equals(propertyKey))
/*  97 */         return true;  b++; }
/*  98 */      return false;
/*     */   }
/*     */   
/*     */   boolean isSet() {
/* 102 */     if (this.keys == null || this.values == null)
/* 103 */       return false; 
/* 104 */     if (this.keys instanceof QualifiedName)
/* 105 */       return true; 
/* 106 */     Object[] tmpValues = (Object[])this.values; byte b; int i; Object[] arrayOfObject1;
/* 107 */     for (i = (arrayOfObject1 = tmpValues).length, b = 0; b < i; ) { Object tmpValue = arrayOfObject1[b];
/* 108 */       if (tmpValue != null)
/* 109 */         return true;  b++; }
/* 110 */      return false;
/*     */   }
/*     */   
/*     */   public void markImmutable() {
/* 114 */     assertMutable();
/* 115 */     this.flags = (byte)(this.flags | 0x2);
/*     */   }
/*     */ 
/*     */   
/*     */   void setContentTypeInfo(IContentTypeInfo info) {
/* 120 */     this.contentTypeInfo = info;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProperty(QualifiedName newKey, Object newValue) {
/* 125 */     assertMutable();
/* 126 */     if (this.keys == null) {
/* 127 */       if ((this.flags & 0x1) != 0) {
/* 128 */         this.keys = newKey;
/* 129 */         this.values = newValue;
/*     */       } 
/*     */       return;
/*     */     } 
/* 133 */     if (this.keys.equals(newKey)) {
/* 134 */       this.values = newValue;
/*     */       return;
/*     */     } 
/* 137 */     if (this.keys instanceof QualifiedName) {
/* 138 */       if ((this.flags & 0x1) != 0) {
/* 139 */         this.keys = new QualifiedName[] { (QualifiedName)this.keys, newKey };
/* 140 */         this.values = new Object[] { this.values, newValue };
/*     */       } 
/*     */       return;
/*     */     } 
/* 144 */     QualifiedName[] tmpKeys = (QualifiedName[])this.keys;
/* 145 */     for (int i = 0; i < tmpKeys.length; i++) {
/* 146 */       if (tmpKeys[i].equals(newKey)) {
/* 147 */         ((Object[])this.values)[i] = newValue; return;
/*     */       } 
/*     */     } 
/* 150 */     if ((this.flags & 0x1) == 0) {
/*     */       return;
/*     */     }
/* 153 */     int currentSize = tmpKeys.length;
/* 154 */     tmpKeys = new QualifiedName[currentSize + 1];
/* 155 */     System.arraycopy(this.keys, 0, tmpKeys, 0, currentSize);
/* 156 */     Object[] tmpValues = new Object[currentSize + 1];
/* 157 */     System.arraycopy(this.values, 0, tmpValues, 0, currentSize);
/* 158 */     tmpKeys[tmpKeys.length - 1] = newKey;
/* 159 */     tmpValues[tmpValues.length - 1] = newValue;
/* 160 */     this.keys = tmpKeys;
/* 161 */     this.values = tmpValues;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 166 */     StringBuilder result = new StringBuilder("{");
/* 167 */     if (this.keys != null)
/* 168 */       if (this.keys instanceof QualifiedName) {
/* 169 */         if (this.values != null)
/* 170 */           result.append(this.keys + "=" + this.values); 
/*     */       } else {
/* 172 */         QualifiedName[] tmpKeys = (QualifiedName[])this.keys;
/* 173 */         Object[] tmpValues = (Object[])this.values;
/* 174 */         boolean any = false;
/* 175 */         for (int i = 0; i < tmpKeys.length; i++) {
/* 176 */           if (tmpValues[i] != null) {
/* 177 */             result.append(tmpKeys[i] + "=" + tmpValues[i] + ",");
/* 178 */             any = true;
/*     */           } 
/* 180 */         }  if (any)
/* 181 */           result.deleteCharAt(result.length() - 1); 
/*     */       }  
/* 183 */     result.append("} : ");
/* 184 */     result.append(this.contentTypeInfo.getContentType());
/* 185 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\ContentDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */