package org.eclipse.core.runtime.content;

import java.io.IOException;
import java.io.InputStream;
import org.eclipse.core.runtime.QualifiedName;

public interface IContentDescriber {
  public static final int INDETERMINATE = 1;
  
  public static final int INVALID = 0;
  
  public static final int VALID = 2;
  
  int describe(InputStream paramInputStream, IContentDescription paramIContentDescription) throws IOException;
  
  QualifiedName[] getSupportedOptions();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\runtime\content\IContentDescriber.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */