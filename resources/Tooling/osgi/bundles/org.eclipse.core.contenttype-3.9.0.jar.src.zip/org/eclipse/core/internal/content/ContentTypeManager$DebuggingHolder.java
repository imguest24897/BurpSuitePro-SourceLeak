/*    */ package org.eclipse.core.internal.content;
/*    */ 
/*    */ import org.eclipse.core.runtime.ServiceCaller;
/*    */ import org.eclipse.osgi.service.debug.DebugOptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DebuggingHolder
/*    */ {
/*    */   static final boolean DEBUGGING;
/*    */   
/*    */   static {
/* 60 */     boolean[] debugging = new boolean[1];
/* 61 */     ServiceCaller.callOnce(DebuggingHolder.class, DebugOptions.class, debugOptions -> paramArrayOfboolean[0] = debugOptions.getBooleanOption("org.eclipse.core.contenttype/debug", false));
/*    */ 
/*    */ 
/*    */     
/* 65 */     DEBUGGING = debugging[0];
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\ContentTypeManager$DebuggingHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */