/*     */ package org.eclipse.core.internal.content;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ import org.eclipse.core.runtime.content.IContentTypeSettings;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentTypeSettings
/*     */   implements IContentTypeSettings, IContentTypeInfo
/*     */ {
/*     */   private ContentType contentType;
/*     */   private IScopeContext context;
/*     */   
/*     */   static void addFileSpec(IScopeContext context, String contentTypeId, String fileSpec, int type) throws CoreException {
/*  31 */     Preferences contentTypeNode = ContentTypeManager.getInstance().getPreferences(context).node(contentTypeId);
/*  32 */     String key = ContentType.getPreferenceKey(type);
/*  33 */     List<String> existingValues = Util.parseItemsIntoList(contentTypeNode.get(key, null));
/*  34 */     for (String existingValue : existingValues) {
/*  35 */       if (existingValue.equalsIgnoreCase(fileSpec))
/*     */         return; 
/*     */     } 
/*  38 */     existingValues.add(fileSpec);
/*     */     
/*  40 */     String newValue = Util.toListString(existingValues.toArray());
/*  41 */     ContentType.setPreference(contentTypeNode, key, newValue);
/*     */     try {
/*  43 */       contentTypeNode.flush();
/*  44 */     } catch (BackingStoreException bse) {
/*  45 */       String message = NLS.bind(ContentMessages.content_errorSavingSettings, contentTypeId);
/*  46 */       Status status = new Status(4, "org.eclipse.core.contenttype", 0, message, (Throwable)bse);
/*  47 */       throw new CoreException(status);
/*     */     } 
/*     */   }
/*     */   
/*     */   static String[] getFileSpecs(IScopeContext context, String contentTypeId, int type) {
/*  52 */     Preferences contentTypeNode = ContentTypeManager.getInstance().getPreferences(context).node(contentTypeId);
/*  53 */     return getFileSpecs(contentTypeNode, type);
/*     */   }
/*     */   
/*     */   static String[] getFileSpecs(Preferences contentTypeNode, int type) {
/*  57 */     String key = ContentType.getPreferenceKey(type);
/*  58 */     String existing = contentTypeNode.get(key, null);
/*  59 */     return Util.parseItems(existing);
/*     */   }
/*     */   
/*     */   public static String internalGetDefaultProperty(ContentType current, Preferences contentTypePrefs, QualifiedName key) throws BackingStoreException {
/*  63 */     String id = current.getId();
/*  64 */     if (contentTypePrefs.nodeExists(id)) {
/*  65 */       Preferences contentTypeNode = contentTypePrefs.node(id);
/*  66 */       String str = contentTypeNode.get(key.getLocalName(), null);
/*  67 */       if (str != null) {
/*  68 */         return str;
/*     */       }
/*     */     } 
/*  71 */     String propertyValue = current.basicGetDefaultProperty(key);
/*  72 */     if (propertyValue != null) {
/*  73 */       return propertyValue;
/*     */     }
/*  75 */     ContentType baseType = (ContentType)current.getBaseType();
/*  76 */     return (baseType == null) ? null : internalGetDefaultProperty(baseType, contentTypePrefs, key);
/*     */   }
/*     */   
/*     */   static void removeFileSpec(IScopeContext context, String contentTypeId, String fileSpec, int type) throws CoreException {
/*  80 */     Preferences contentTypeNode = ContentTypeManager.getInstance().getPreferences(context).node(contentTypeId);
/*  81 */     String key = ContentType.getPreferenceKey(type);
/*  82 */     String existing = contentTypeNode.get(key, null);
/*  83 */     if (existing == null) {
/*     */       return;
/*     */     }
/*  86 */     List<String> existingValues = Util.parseItemsIntoList(contentTypeNode.get(key, null));
/*  87 */     int index = -1;
/*  88 */     int existingCount = existingValues.size();
/*  89 */     for (int i = 0; index == -1 && i < existingCount; i++) {
/*  90 */       if (((String)existingValues.get(i)).equalsIgnoreCase(fileSpec))
/*  91 */         index = i; 
/*  92 */     }  if (index == -1) {
/*     */       return;
/*     */     }
/*  95 */     existingValues.remove(index);
/*     */     
/*  97 */     String newValue = Util.toListString(existingValues.toArray());
/*  98 */     ContentType.setPreference(contentTypeNode, key, newValue);
/*     */     try {
/* 100 */       contentTypeNode.flush();
/* 101 */     } catch (BackingStoreException bse) {
/* 102 */       String message = NLS.bind(ContentMessages.content_errorSavingSettings, contentTypeId);
/* 103 */       Status status = new Status(4, "org.eclipse.core.contenttype", 0, message, (Throwable)bse);
/* 104 */       throw new CoreException(status);
/*     */     } 
/*     */   }
/*     */   
/*     */   public ContentTypeSettings(ContentType contentType, IScopeContext context) {
/* 109 */     this.context = context;
/* 110 */     this.contentType = contentType;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addFileSpec(String fileSpec, int type) throws CoreException {
/* 115 */     addFileSpec(this.context, this.contentType.getId(), fileSpec, type);
/*     */   }
/*     */ 
/*     */   
/*     */   public ContentType getContentType() {
/* 120 */     return this.contentType;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDefaultCharset() {
/* 125 */     return getDefaultProperty(IContentDescription.CHARSET);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDefaultProperty(QualifiedName key) {
/* 130 */     IEclipsePreferences iEclipsePreferences = ContentTypeManager.getInstance().getPreferences(this.context);
/*     */     try {
/* 132 */       String propertyValue = internalGetDefaultProperty(this.contentType, (Preferences)iEclipsePreferences, key);
/* 133 */       return "".equals(propertyValue) ? null : propertyValue;
/* 134 */     } catch (BackingStoreException backingStoreException) {
/* 135 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getFileSpecs(int type) {
/* 141 */     return getFileSpecs(this.context, this.contentType.getId(), type);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getId() {
/* 146 */     return this.contentType.getId();
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeFileSpec(String fileSpec, int type) throws CoreException {
/* 151 */     removeFileSpec(this.context, this.contentType.getId(), fileSpec, type);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDefaultCharset(String userCharset) throws CoreException {
/* 156 */     Preferences contentTypeNode = ContentTypeManager.getInstance().getPreferences(this.context).node(this.contentType.getId());
/* 157 */     ContentType.setPreference(contentTypeNode, "charset", userCharset);
/*     */     try {
/* 159 */       contentTypeNode.flush();
/* 160 */     } catch (BackingStoreException bse) {
/* 161 */       String message = NLS.bind(ContentMessages.content_errorSavingSettings, this.contentType.getId());
/* 162 */       Status status = new Status(4, "org.eclipse.core.contenttype", 0, message, (Throwable)bse);
/* 163 */       throw new CoreException(status);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUserDefined() {
/* 169 */     return getContentType().isUserDefined();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\ContentTypeSettings.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */