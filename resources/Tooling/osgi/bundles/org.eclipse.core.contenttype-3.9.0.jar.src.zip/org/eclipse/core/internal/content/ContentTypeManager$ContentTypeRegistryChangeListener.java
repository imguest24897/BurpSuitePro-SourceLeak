/*    */ package org.eclipse.core.internal.content;
/*    */ 
/*    */ import org.eclipse.core.runtime.IRegistryChangeEvent;
/*    */ import org.eclipse.core.runtime.IRegistryChangeListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ContentTypeRegistryChangeListener
/*    */   implements IRegistryChangeListener
/*    */ {
/*    */   public void registryChanged(IRegistryChangeEvent event) {
/* 33 */     if ((event.getExtensionDeltas("org.eclipse.core.runtime", "contentTypes")).length == 0)
/* 34 */       if ((event.getExtensionDeltas("org.eclipse.core.contenttype", 
/* 35 */           "contentTypes")).length == 0)
/*    */         return;  
/* 37 */     ContentTypeManager.getInstance().invalidate();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\internal\content\ContentTypeManager$ContentTypeRegistryChangeListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */