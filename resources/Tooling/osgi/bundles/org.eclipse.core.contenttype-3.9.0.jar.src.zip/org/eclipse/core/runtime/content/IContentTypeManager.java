/*    */ package org.eclipse.core.runtime.content;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IContentTypeManager
/*    */   extends IContentTypeMatcher
/*    */ {
/*    */   public static final String CT_TEXT = "org.eclipse.core.runtime.text";
/*    */   
/*    */   void addContentTypeChangeListener(IContentTypeChangeListener paramIContentTypeChangeListener);
/*    */   
/*    */   IContentType[] getAllContentTypes();
/*    */   
/*    */   IContentType getContentType(String paramString);
/*    */   
/*    */   IContentTypeMatcher getMatcher(ISelectionPolicy paramISelectionPolicy, IScopeContext paramIScopeContext);
/*    */   
/*    */   void removeContentTypeChangeListener(IContentTypeChangeListener paramIContentTypeChangeListener);
/*    */   
/*    */   IContentType addContentType(String paramString1, String paramString2, IContentType paramIContentType) throws CoreException;
/*    */   
/*    */   void removeContentType(String paramString) throws CoreException;
/*    */   
/*    */   public static final class ContentTypeChangeEvent
/*    */     extends EventObject
/*    */   {
/*    */     private static final long serialVersionUID = 1L;
/*    */     private IScopeContext context;
/*    */     
/*    */     public ContentTypeChangeEvent(IContentType source) {
/* 59 */       super(source);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public ContentTypeChangeEvent(IContentType source, IScopeContext context) {
/* 70 */       super(source);
/* 71 */       this.context = context;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public IContentType getContentType() {
/* 80 */       return (IContentType)this.source;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public IScopeContext getContext() {
/* 92 */       return this.context;
/*    */     }
/*    */   }
/*    */   
/*    */   public static interface IContentTypeChangeListener {
/*    */     void contentTypeChanged(IContentTypeManager.ContentTypeChangeEvent param1ContentTypeChangeEvent);
/*    */   }
/*    */   
/*    */   public static interface ISelectionPolicy {
/*    */     IContentType[] select(IContentType[] param1ArrayOfIContentType, boolean param1Boolean1, boolean param1Boolean2);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\runtime\content\IContentTypeManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */