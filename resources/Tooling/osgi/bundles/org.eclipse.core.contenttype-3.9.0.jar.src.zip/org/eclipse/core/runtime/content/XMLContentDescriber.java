/*     */ package org.eclipse.core.runtime.content;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.content.TextContentDescriber;
/*     */ import org.eclipse.core.internal.content.Util;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLContentDescriber
/*     */   extends TextContentDescriber
/*     */ {
/*  52 */   private static final QualifiedName[] SUPPORTED_OPTIONS = new QualifiedName[] { IContentDescription.CHARSET, IContentDescription.BYTE_ORDER_MARK };
/*     */   
/*     */   private static final String XML_PREFIX = "<?xml ";
/*     */   private static final String XML_DECL_END = "?>";
/*     */   private static final String BOM = "org.eclipse.core.runtime.content.XMLContentDescriber.bom";
/*     */   private static final String CHARSET = "org.eclipse.core.runtime.content.XMLContentDescriber.charset";
/*     */   private static final String FULL_XML_DECL = "org.eclipse.core.runtime.content.XMLContentDescriber.fullXMLDecl";
/*     */   private static final String RESULT = "org.eclipse.core.runtime.content.XMLContentDescriber.processed";
/*     */   
/*     */   public int describe(InputStream input, IContentDescription description) throws IOException {
/*  62 */     return describe2(input, description, new HashMap<>());
/*     */   }
/*     */   
/*     */   int describe2(InputStream input, IContentDescription description, Map<String, Object> properties) throws IOException {
/*  66 */     if (!isProcessed(properties))
/*  67 */       fillContentProperties(input, description, properties); 
/*  68 */     return internalDescribe(description, properties);
/*     */   }
/*     */ 
/*     */   
/*     */   public int describe(Reader input, IContentDescription description) throws IOException {
/*  73 */     return describe2(input, description, new HashMap<>());
/*     */   }
/*     */   
/*     */   int describe2(Reader input, IContentDescription description, Map<String, Object> properties) throws IOException {
/*  77 */     if (!isProcessed(properties))
/*  78 */       fillContentProperties(readXMLDecl(input), description, properties); 
/*  79 */     return internalDescribe(description, properties);
/*     */   }
/*     */   
/*     */   private boolean isProcessed(Map<String, Object> properties) {
/*  83 */     Boolean result = (Boolean)properties.get("org.eclipse.core.runtime.content.XMLContentDescriber.processed");
/*  84 */     if (result != null)
/*  85 */       return true; 
/*  86 */     return false;
/*     */   }
/*     */   
/*     */   private void fillContentProperties(InputStream input, IContentDescription description, Map<String, Object> properties) throws IOException {
/*  90 */     byte[] bom = Util.getByteOrderMark(input);
/*  91 */     String xmlDeclEncoding = "UTF-8";
/*  92 */     input.reset();
/*  93 */     if (bom != null) {
/*  94 */       if (bom == IContentDescription.BOM_UTF_16BE) {
/*  95 */         xmlDeclEncoding = "UTF-16BE";
/*  96 */       } else if (bom == IContentDescription.BOM_UTF_16LE) {
/*  97 */         xmlDeclEncoding = "UTF-16LE";
/*     */       } 
/*  99 */       input.skip(bom.length);
/* 100 */       properties.put("org.eclipse.core.runtime.content.XMLContentDescriber.bom", bom);
/*     */     } 
/* 102 */     fillContentProperties(readXMLDecl(input, xmlDeclEncoding), description, properties);
/*     */   }
/*     */ 
/*     */   
/*     */   private void fillContentProperties(String line, IContentDescription description, Map<String, Object> properties) throws IOException {
/* 107 */     if (line != null && line.startsWith("<?xml "))
/* 108 */       properties.put("org.eclipse.core.runtime.content.XMLContentDescriber.fullXMLDecl", Boolean.TRUE); 
/* 109 */     String charset = getCharset(line);
/* 110 */     if (charset != null)
/* 111 */       properties.put("org.eclipse.core.runtime.content.XMLContentDescriber.charset", charset); 
/* 112 */     properties.put("org.eclipse.core.runtime.content.XMLContentDescriber.processed", Boolean.TRUE);
/*     */   }
/*     */   
/*     */   private int internalDescribe(IContentDescription description, Map<String, Object> properties) {
/* 116 */     if (description != null) {
/* 117 */       byte[] bom = (byte[])properties.get("org.eclipse.core.runtime.content.XMLContentDescriber.bom");
/* 118 */       if (bom != null && description.isRequested(IContentDescription.BYTE_ORDER_MARK))
/* 119 */         description.setProperty(IContentDescription.BYTE_ORDER_MARK, bom); 
/*     */     } 
/* 121 */     Boolean fullXMLDecl = (Boolean)properties.get("org.eclipse.core.runtime.content.XMLContentDescriber.fullXMLDecl");
/* 122 */     if (fullXMLDecl == null || !fullXMLDecl.booleanValue())
/* 123 */       return 1; 
/* 124 */     if (description == null)
/* 125 */       return 2; 
/* 126 */     String charset = (String)properties.get("org.eclipse.core.runtime.content.XMLContentDescriber.charset");
/* 127 */     if (description.isRequested(IContentDescription.CHARSET)) {
/* 128 */       if (charset != null && !isCharsetValid(charset))
/* 129 */         return 0; 
/* 130 */       if (isNonDefaultCharset(charset))
/* 131 */         description.setProperty(IContentDescription.CHARSET, charset); 
/*     */     } 
/* 133 */     return 2;
/*     */   }
/*     */   
/*     */   private boolean isNonDefaultCharset(String charset) {
/* 137 */     if (charset == null)
/* 138 */       return false; 
/* 139 */     if ("utf8".equalsIgnoreCase(charset) || "utf-8".equalsIgnoreCase(charset))
/* 140 */       return false; 
/* 141 */     return true;
/*     */   }
/*     */   
/*     */   private boolean isFullXMLDecl(String xmlDecl) {
/* 145 */     return xmlDecl.endsWith("?>");
/*     */   }
/*     */   
/*     */   private String readXMLDecl(InputStream input, String encoding) throws IOException {
/* 149 */     byte[] xmlDeclEndBytes = "?>".getBytes(encoding);
/*     */ 
/*     */     
/* 152 */     int xmlDeclSize = 100 * xmlDeclEndBytes.length / 2;
/* 153 */     byte[] xmlDecl = new byte[xmlDeclSize];
/*     */ 
/*     */     
/* 156 */     int c = 0;
/* 157 */     int read = 0;
/*     */ 
/*     */ 
/*     */     
/* 161 */     int count = 0;
/*     */     
/* 163 */     while (read < xmlDecl.length && (c = input.read()) != -1) {
/* 164 */       if (c == xmlDeclEndBytes[count]) {
/* 165 */         count++;
/*     */       } else {
/* 167 */         count = 0;
/* 168 */       }  xmlDecl[read++] = (byte)c;
/* 169 */       if (count == xmlDeclEndBytes.length)
/*     */         break; 
/*     */     } 
/* 172 */     return new String(xmlDecl, 0, read, encoding);
/*     */   }
/*     */   
/*     */   private String readXMLDecl(Reader input) throws IOException {
/* 176 */     BufferedReader reader = new BufferedReader(input);
/* 177 */     String line = null;
/*     */     
/* 179 */     StringBuilder stringBuilder = new StringBuilder(100);
/* 180 */     while (stringBuilder.length() < 100 && (line = reader.readLine()) != null) {
/* 181 */       stringBuilder.append(line);
/* 182 */       if (line.contains("?>")) {
/* 183 */         String resultString = stringBuilder.toString();
/* 184 */         return resultString.substring(0, resultString.indexOf("?>") + "?>".length());
/*     */       } 
/*     */     } 
/* 187 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   private String getCharset(String firstLine) {
/* 191 */     int encodingPos = findEncodingPosition(firstLine);
/* 192 */     if (encodingPos == -1)
/* 193 */       return null; 
/* 194 */     char quoteChar = '"';
/* 195 */     int firstQuote = firstLine.indexOf('"', encodingPos);
/* 196 */     int firstApostrophe = firstLine.indexOf('\'', encodingPos);
/*     */     
/* 198 */     if (firstQuote == -1 || (firstApostrophe != -1 && firstApostrophe < firstQuote)) {
/* 199 */       quoteChar = '\'';
/* 200 */       firstQuote = firstApostrophe;
/*     */     } 
/* 202 */     if (firstQuote == -1 || firstLine.length() == firstQuote + 1)
/* 203 */       return null; 
/* 204 */     int secondQuote = firstLine.indexOf(quoteChar, firstQuote + 1);
/* 205 */     if (secondQuote == -1)
/* 206 */       return isFullXMLDecl(firstLine) ? firstLine.substring(firstQuote + 1, firstLine.lastIndexOf("?>")).trim() : null; 
/* 207 */     return firstLine.substring(firstQuote + 1, secondQuote);
/*     */   }
/*     */   
/*     */   private int findEncodingPosition(String line) {
/* 211 */     String encoding = "encoding";
/* 212 */     int fromIndex = 0;
/* 213 */     int position = 0;
/* 214 */     while ((position = line.indexOf(encoding, fromIndex)) != -1) {
/* 215 */       boolean equals = false;
/* 216 */       fromIndex = position + encoding.length();
/* 217 */       for (int i = fromIndex; i < line.length(); i++) {
/* 218 */         char c = line.charAt(i);
/* 219 */         if (c == '=' && !equals) {
/* 220 */           equals = true;
/* 221 */         } else if (c != ' ' && c != '\t' && c != '\r' && c != '\n') {
/*     */           
/* 223 */           if ((c == '"' || c == '\'') && equals) {
/* 224 */             return position;
/*     */           }
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 230 */     return -1;
/*     */   }
/*     */   
/*     */   private boolean isCharsetValid(String charset) {
/* 234 */     if (charset.isEmpty()) {
/* 235 */       return false;
/*     */     }
/* 237 */     char c = charset.charAt(0);
/* 238 */     if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z')) {
/* 239 */       return false;
/*     */     }
/* 241 */     for (int i = 1; i < charset.length(); ) {
/* 242 */       c = charset.charAt(i);
/* 243 */       if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.') {
/*     */         i++; continue;
/* 245 */       }  return false;
/*     */     } 
/* 247 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public QualifiedName[] getSupportedOptions() {
/* 252 */     return SUPPORTED_OPTIONS;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.contenttype-3.9.0.jar!\org\eclipse\core\runtime\content\XMLContentDescriber.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */