/*     */ package org.eclipse.core.resources;
/*     */ 
/*     */ import org.eclipse.core.internal.preferences.AbstractScope;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.core.runtime.preferences.IPreferencesService;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ProjectScope
/*     */   extends AbstractScope
/*     */ {
/*     */   public static final String SCOPE = "project";
/*     */   private final IProject project;
/*     */   
/*     */   public ProjectScope(IProject context) {
/*  60 */     if (context == null)
/*  61 */       throw new IllegalArgumentException(); 
/*  62 */     this.project = context;
/*     */   }
/*     */ 
/*     */   
/*     */   public IEclipsePreferences getNode(String qualifier) {
/*  67 */     if (qualifier == null)
/*  68 */       throw new IllegalArgumentException(); 
/*  69 */     IPreferencesService preferencesService = Platform.getPreferencesService();
/*  70 */     Preferences scopeNode = preferencesService.getRootNode().node("project");
/*  71 */     Preferences projectNode = scopeNode.node(this.project.getName());
/*  72 */     return (IEclipsePreferences)projectNode.node(qualifier);
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getLocation() {
/*  77 */     IPath location = this.project.getLocation();
/*  78 */     return (location == null) ? null : location.append(".settings");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  83 */     return "project";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  88 */     if (this == obj)
/*  89 */       return true; 
/*  90 */     if (!super.equals(obj))
/*  91 */       return false; 
/*  92 */     if (!(obj instanceof ProjectScope))
/*  93 */       return false; 
/*  94 */     ProjectScope other = (ProjectScope)obj;
/*  95 */     return this.project.equals(other.project);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 100 */     return super.hashCode() * 31 + this.project.getFullPath().hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\ProjectScope.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */