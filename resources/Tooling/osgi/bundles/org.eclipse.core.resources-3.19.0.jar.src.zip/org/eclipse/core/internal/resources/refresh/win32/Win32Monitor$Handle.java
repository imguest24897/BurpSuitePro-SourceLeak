/*     */ package org.eclipse.core.internal.resources.refresh.win32;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Handle
/*     */   implements Closeable
/*     */ {
/* 146 */   protected long handleValue = Win32Natives.INVALID_HANDLE_VALUE;
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 151 */     if (isOpen()) {
/* 152 */       if (!Win32Natives.FindCloseChangeNotification(this.handleValue)) {
/* 153 */         int error = Win32Natives.GetLastError();
/* 154 */         if (error != Win32Natives.ERROR_INVALID_HANDLE)
/* 155 */           Win32Monitor.this.addException(NLS.bind(Messages.WM_errCloseHandle, Integer.toString(error))); 
/*     */       } 
/* 157 */       if (Policy.DEBUG_AUTO_REFRESH)
/* 158 */         Policy.debug("Win32RefreshMonitor: removed handle: " + this.handleValue); 
/* 159 */       this.handleValue = Win32Natives.INVALID_HANDLE_VALUE;
/*     */     } 
/*     */   }
/*     */   
/*     */   private long createHandleValue(String path, boolean monitorSubtree, int flags) {
/* 164 */     long handle = Win32Natives.FindFirstChangeNotification(path, monitorSubtree, flags);
/* 165 */     if (handle == Win32Natives.INVALID_HANDLE_VALUE) {
/* 166 */       int error = Win32Natives.GetLastError();
/* 167 */       Win32Monitor.this.addException(NLS.bind(Messages.WM_errCreateHandle, path, Integer.toString(error)));
/*     */     } 
/* 169 */     return handle;
/*     */   }
/*     */   
/*     */   public void destroy() {
/* 173 */     close();
/*     */   }
/*     */   
/*     */   protected void findNextChange() {
/* 177 */     if (!Win32Natives.FindNextChangeNotification(this.handleValue)) {
/* 178 */       int error = Win32Natives.GetLastError();
/* 179 */       if (error != Win32Natives.ERROR_INVALID_HANDLE && error != Win32Natives.ERROR_SUCCESS) {
/* 180 */         Win32Monitor.this.addException(NLS.bind(Messages.WM_errFindChange, Integer.toString(error)));
/*     */       }
/* 182 */       Win32Monitor.this.removeHandle(this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public long getHandleValue() {
/* 187 */     return this.handleValue;
/*     */   }
/*     */   
/*     */   public abstract void handleNotification();
/*     */   
/*     */   public boolean isOpen() {
/* 193 */     return (this.handleValue != Win32Natives.INVALID_HANDLE_VALUE);
/*     */   }
/*     */   
/*     */   public abstract void open();
/*     */   
/*     */   protected void openHandleOn(File file) {
/* 199 */     openHandleOn(file.getAbsolutePath(), false);
/*     */   }
/*     */   
/*     */   protected void openHandleOn(IResource resource) {
/* 203 */     IPath location = resource.getLocation();
/* 204 */     if (location != null) {
/* 205 */       openHandleOn(location.toOSString(), true);
/*     */     }
/*     */   }
/*     */   
/*     */   private void openHandleOn(String path, boolean subtree) {
/* 210 */     setHandleValue(createHandleValue(path, subtree, Win32Natives.FILE_NOTIFY_CHANGE_FILE_NAME | Win32Natives.FILE_NOTIFY_CHANGE_DIR_NAME | Win32Natives.FILE_NOTIFY_CHANGE_LAST_WRITE | Win32Natives.FILE_NOTIFY_CHANGE_SIZE));
/* 211 */     if (isOpen()) {
/* 212 */       Win32Monitor.this.fHandleValueToHandle.put(Long.valueOf(getHandleValue()), this);
/* 213 */       Win32Monitor.this.setHandleValueArrays(Win32Monitor.this.createHandleArrays());
/*     */     } else {
/* 215 */       close();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void postRefreshRequest(IResource resource) {
/* 221 */     if (!resource.isSynchronized(2))
/* 222 */       Win32Monitor.this.refreshResult.refresh(resource); 
/*     */   }
/*     */   
/*     */   public void setHandleValue(long handleValue) {
/* 226 */     this.handleValue = handleValue;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\refresh\win32\Win32Monitor$Handle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */