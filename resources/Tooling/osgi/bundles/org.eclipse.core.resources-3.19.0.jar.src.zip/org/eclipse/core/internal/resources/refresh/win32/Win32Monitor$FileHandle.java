/*     */ package org.eclipse.core.internal.resources.refresh.win32;
/*     */ 
/*     */ import java.io.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileHandle
/*     */   extends Win32Monitor.ChainedHandle
/*     */ {
/*     */   private File file;
/*     */   
/*     */   public FileHandle(File file) {
/*  80 */     this.file = file;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean exists() {
/*  85 */     return this.file.exists();
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleNotification() {
/*  90 */     if (!isOpen())
/*     */       return; 
/*  92 */     Win32Monitor.ChainedHandle next = getNext();
/*  93 */     if (next != null)
/*  94 */       if (next.isOpen()) {
/*  95 */         if (!next.exists()) {
/*  96 */           next.close();
/*  97 */           if (next instanceof Win32Monitor.LinkedResourceHandle) {
/*  98 */             Win32Monitor.LinkedResourceHandle linkedResourceHandle = (Win32Monitor.LinkedResourceHandle)next;
/*  99 */             linkedResourceHandle.postRefreshRequest();
/*     */           } 
/* 101 */           Win32Monitor.ChainedHandle previous = getPrevious();
/* 102 */           if (previous != null)
/* 103 */             previous.open(); 
/*     */         } 
/*     */       } else {
/* 106 */         next.open();
/* 107 */         if (next.isOpen()) {
/* 108 */           Win32Monitor.Handle previous = getPrevious();
/* 109 */           previous.close();
/* 110 */           if (next instanceof Win32Monitor.LinkedResourceHandle) {
/* 111 */             ((Win32Monitor.LinkedResourceHandle)next).postRefreshRequest();
/*     */           }
/*     */         } 
/*     */       }  
/* 115 */     findNextChange();
/*     */   }
/*     */ 
/*     */   
/*     */   public void open() {
/* 120 */     if (!isOpen()) {
/* 121 */       Win32Monitor.Handle next = getNext();
/* 122 */       if (next != null && next.isOpen()) {
/* 123 */         openHandleOn(this.file);
/*     */       } else {
/* 125 */         if (exists()) {
/* 126 */           openHandleOn(this.file);
/*     */         }
/* 128 */         Win32Monitor.Handle previous = getPrevious();
/* 129 */         if (previous != null) {
/* 130 */           previous.open();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 138 */     return this.file.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\refresh\win32\Win32Monitor$FileHandle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */