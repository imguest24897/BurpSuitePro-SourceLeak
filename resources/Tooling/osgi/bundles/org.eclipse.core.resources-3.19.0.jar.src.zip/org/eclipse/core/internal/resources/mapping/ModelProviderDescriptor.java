/*     */ package org.eclipse.core.internal.resources.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.expressions.EvaluationContext;
/*     */ import org.eclipse.core.expressions.EvaluationResult;
/*     */ import org.eclipse.core.expressions.Expression;
/*     */ import org.eclipse.core.expressions.ExpressionConverter;
/*     */ import org.eclipse.core.expressions.IEvaluationContext;
/*     */ import org.eclipse.core.internal.resources.ResourceException;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.mapping.IModelProviderDescriptor;
/*     */ import org.eclipse.core.resources.mapping.ModelProvider;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelProviderDescriptor
/*     */   implements IModelProviderDescriptor
/*     */ {
/*     */   private String id;
/*     */   private String[] extendedModels;
/*     */   private String label;
/*     */   private ModelProvider provider;
/*     */   private Expression enablementRule;
/*     */   
/*     */   private static EvaluationContext createEvaluationContext(Object element) {
/*  37 */     EvaluationContext result = new EvaluationContext(null, element);
/*  38 */     return result;
/*     */   }
/*     */   
/*     */   public ModelProviderDescriptor(IExtension extension) throws CoreException {
/*  42 */     readExtension(extension);
/*     */   }
/*     */   
/*     */   private boolean convert(EvaluationResult eval) {
/*  46 */     if (eval == EvaluationResult.FALSE)
/*  47 */       return false; 
/*  48 */     return true;
/*     */   }
/*     */   
/*     */   protected void fail(String reason) throws CoreException {
/*  52 */     throw new ResourceException(new Status(4, "org.eclipse.core.resources", 1, reason, null));
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getExtendedModels() {
/*  57 */     return this.extendedModels;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getId() {
/*  62 */     return this.id;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabel() {
/*  67 */     return this.label;
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource[] getMatchingResources(IResource[] resources) throws CoreException {
/*  72 */     Set<IResource> result = new HashSet<>(); byte b; int i; IResource[] arrayOfIResource;
/*  73 */     for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/*  74 */       EvaluationContext evalContext = createEvaluationContext(resource);
/*  75 */       if (matches((IEvaluationContext)evalContext))
/*  76 */         result.add(resource); 
/*     */       b++; }
/*     */     
/*  79 */     return result.<IResource>toArray(new IResource[result.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized ModelProvider getModelProvider() throws CoreException {
/*  84 */     if (this.provider == null) {
/*  85 */       IExtension extension = Platform.getExtensionRegistry().getExtension("org.eclipse.core.resources", "modelProviders", this.id);
/*  86 */       IConfigurationElement[] elements = extension.getConfigurationElements(); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/*  87 */       for (i = (arrayOfIConfigurationElement1 = elements).length, b = 0; b < i; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b];
/*  88 */         if (element.getName().equalsIgnoreCase("modelProvider"))
/*     */           try {
/*  90 */             this.provider = (ModelProvider)element.createExecutableExtension("class");
/*  91 */             this.provider.init(this);
/*  92 */           } catch (ClassCastException e) {
/*  93 */             String message = NLS.bind(Messages.mapping_wrongType, this.id);
/*  94 */             throw new CoreException(new Status(4, "org.eclipse.core.resources", 2, message, e));
/*     */           }  
/*     */         b++; }
/*     */     
/*     */     } 
/*  99 */     return this.provider;
/*     */   }
/*     */   
/*     */   public boolean matches(IEvaluationContext context) throws CoreException {
/* 103 */     if (this.enablementRule == null)
/* 104 */       return false; 
/* 105 */     return convert(this.enablementRule.evaluate(context));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void readExtension(IExtension extension) throws CoreException {
/* 113 */     this.id = extension.getUniqueIdentifier();
/* 114 */     if (this.id == null)
/* 115 */       fail(Messages.mapping_noIdentifier); 
/* 116 */     this.label = extension.getLabel();
/* 117 */     IConfigurationElement[] elements = extension.getConfigurationElements();
/* 118 */     int count = elements.length;
/* 119 */     ArrayList<String> extendsList = new ArrayList<>(count);
/* 120 */     for (int i = 0; i < count; i++) {
/* 121 */       IConfigurationElement element = elements[i];
/* 122 */       String name = element.getName();
/* 123 */       if (name.equalsIgnoreCase("extends-model")) {
/* 124 */         String attribute = element.getAttribute("id");
/* 125 */         if (attribute == null)
/* 126 */           fail(NLS.bind(Messages.mapping_invalidDef, this.id)); 
/* 127 */         extendsList.add(attribute);
/* 128 */       } else if (name.equalsIgnoreCase("enablement")) {
/* 129 */         this.enablementRule = ExpressionConverter.getDefault().perform(element);
/*     */       } 
/*     */     } 
/* 132 */     this.extendedModels = extendsList.<String>toArray(new String[extendsList.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceTraversal[] getMatchingTraversals(ResourceTraversal[] traversals) throws CoreException {
/* 137 */     List<ResourceTraversal> result = new ArrayList<>(); byte b; int i; ResourceTraversal[] arrayOfResourceTraversal;
/* 138 */     for (i = (arrayOfResourceTraversal = traversals).length, b = 0; b < i; ) { ResourceTraversal traversal = arrayOfResourceTraversal[b];
/* 139 */       if ((getMatchingResources(traversal.getResources())).length > 0)
/* 140 */         result.add(traversal); 
/*     */       b++; }
/*     */     
/* 143 */     return result.<ResourceTraversal>toArray(new ResourceTraversal[result.size()]);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\mapping\ModelProviderDescriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */