/*    */ package org.eclipse.core.resources;
/*    */ 
/*    */ import org.eclipse.core.internal.resources.InternalWorkspaceJob;
/*    */ import org.eclipse.core.internal.resources.Workspace;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WorkspaceJob
/*    */   extends InternalWorkspaceJob
/*    */ {
/*    */   public WorkspaceJob(String name) {
/* 68 */     super(name, (Workspace)ResourcesPlugin.getWorkspace());
/*    */   }
/*    */   
/*    */   public abstract IStatus runInWorkspace(IProgressMonitor paramIProgressMonitor) throws CoreException;
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\WorkspaceJob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */