/*     */ package org.eclipse.core.internal.propertytester;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringMatcher
/*     */ {
/*     */   private static final char SINGLE_WILD_CARD = '\000';
/*  30 */   private int bound = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasLeadingStar;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasTrailingStar;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int patternLength;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] segments;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringMatcher(String pattern) {
/*  63 */     if (pattern == null)
/*  64 */       throw new IllegalArgumentException(); 
/*  65 */     this.pattern = pattern;
/*  66 */     this.patternLength = pattern.length();
/*  67 */     parseWildCards();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int findPosition(String text, int start, int end, String p) {
/*  78 */     boolean hasWildCard = (p.indexOf(false) >= 0);
/*  79 */     int plen = p.length();
/*  80 */     for (int i = start, max = end - plen; i <= max; i++) {
/*  81 */       if (hasWildCard) {
/*  82 */         if (regExpRegionMatches(text, i, p, 0, plen)) {
/*  83 */           return i;
/*     */         }
/*  85 */       } else if (text.regionMatches(true, i, p, 0, plen)) {
/*  86 */         return i;
/*     */       } 
/*     */     } 
/*  89 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean match(String text) {
/*  99 */     if (text == null)
/* 100 */       return false; 
/* 101 */     int end = text.length();
/* 102 */     int segmentCount = this.segments.length;
/* 103 */     if (segmentCount == 0 && (this.hasLeadingStar || this.hasTrailingStar))
/* 104 */       return true; 
/* 105 */     if (end == 0)
/* 106 */       return (this.patternLength == 0); 
/* 107 */     if (this.patternLength == 0)
/* 108 */       return false; 
/* 109 */     int currentTextPosition = 0;
/* 110 */     if (end - this.bound < 0)
/* 111 */       return false; 
/* 112 */     int segmentIndex = 0;
/* 113 */     String current = this.segments[segmentIndex];
/*     */ 
/*     */     
/* 116 */     if (!this.hasLeadingStar) {
/* 117 */       int currentLength = current.length();
/* 118 */       if (!regExpRegionMatches(text, 0, current, 0, currentLength))
/* 119 */         return false; 
/* 120 */       segmentIndex++;
/* 121 */       currentTextPosition += currentLength;
/*     */     } 
/* 123 */     if (segmentCount == 1 && !this.hasLeadingStar && !this.hasTrailingStar)
/*     */     {
/* 125 */       return (currentTextPosition == end);
/*     */     }
/*     */     
/* 128 */     while (segmentIndex < segmentCount) {
/* 129 */       current = this.segments[segmentIndex];
/* 130 */       int currentMatch = findPosition(text, currentTextPosition, end, current);
/* 131 */       if (currentMatch < 0)
/* 132 */         return false; 
/* 133 */       currentTextPosition = currentMatch + current.length();
/* 134 */       segmentIndex++;
/*     */     } 
/*     */ 
/*     */     
/* 138 */     if (!this.hasTrailingStar && currentTextPosition != end) {
/* 139 */       int currentLength = current.length();
/* 140 */       return regExpRegionMatches(text, end - currentLength, current, 0, currentLength);
/*     */     } 
/* 142 */     return (segmentIndex == segmentCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseWildCards() {
/* 149 */     if (this.pattern.startsWith("*"))
/* 150 */       this.hasLeadingStar = true; 
/* 151 */     if (this.pattern.endsWith("*"))
/*     */     {
/* 153 */       if (this.patternLength > 1 && this.pattern.charAt(this.patternLength - 2) != '\\') {
/* 154 */         this.hasTrailingStar = true;
/*     */       }
/*     */     }
/*     */     
/* 158 */     ArrayList<String> temp = new ArrayList<>();
/*     */     
/* 160 */     int pos = 0;
/* 161 */     StringBuilder buf = new StringBuilder();
/* 162 */     while (pos < this.patternLength) {
/* 163 */       char next, c = this.pattern.charAt(pos++);
/* 164 */       switch (c) {
/*     */         case '\\':
/* 166 */           if (pos >= this.patternLength) {
/* 167 */             buf.append(c); continue;
/*     */           } 
/* 169 */           next = this.pattern.charAt(pos++);
/*     */           
/* 171 */           if (next == '*' || next == '?' || next == '\\') {
/* 172 */             buf.append(next);
/*     */             continue;
/*     */           } 
/* 175 */           buf.append(c);
/* 176 */           buf.append(next);
/*     */           continue;
/*     */ 
/*     */         
/*     */         case '*':
/* 181 */           if (buf.length() > 0) {
/*     */             
/* 183 */             temp.add(buf.toString());
/* 184 */             this.bound += buf.length();
/* 185 */             buf.setLength(0);
/*     */           } 
/*     */           continue;
/*     */         
/*     */         case '?':
/* 190 */           buf.append(false);
/*     */           continue;
/*     */       } 
/* 193 */       buf.append(c);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 198 */     if (buf.length() > 0) {
/* 199 */       temp.add(buf.toString());
/* 200 */       this.bound += buf.length();
/*     */     } 
/* 202 */     this.segments = temp.<String>toArray(new String[temp.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean regExpRegionMatches(String text, int tStart, String p, int pStart, int plen) {
/* 215 */     while (plen-- > 0) {
/* 216 */       char tchar = text.charAt(tStart++);
/* 217 */       char pchar = p.charAt(pStart++);
/*     */ 
/*     */       
/* 220 */       if (pchar == '\000')
/*     */         continue; 
/* 222 */       if (pchar == tchar)
/*     */         continue; 
/* 224 */       if (Character.toUpperCase(tchar) == Character.toUpperCase(pchar)) {
/*     */         continue;
/*     */       }
/*     */       
/* 228 */       if (Character.toLowerCase(tchar) == Character.toLowerCase(pchar))
/*     */         continue; 
/* 230 */       return false;
/*     */     } 
/* 232 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\propertytester\StringMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */