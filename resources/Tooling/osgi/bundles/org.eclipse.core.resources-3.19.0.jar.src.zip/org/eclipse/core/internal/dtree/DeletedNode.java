/*     */ package org.eclipse.core.internal.dtree;
/*     */ 
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeletedNode
/*     */   extends AbstractDataTreeNode
/*     */ {
/*     */   DeletedNode(String localName) {
/*  31 */     super(localName, NO_CHILDREN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode asBackwardDelta(DeltaDataTree myTree, DeltaDataTree parentTree, IPath key) {
/*  39 */     if (parentTree.includes(key))
/*  40 */       return parentTree.copyCompleteSubtree(key); 
/*  41 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode childAt(String localName) {
/*  50 */     throw new ObjectNotFoundException(NLS.bind(Messages.dtree_missingChild, localName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode childAtOrNull(String localName) {
/*  59 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode compareWithParent(IPath key, DeltaDataTree parent, IComparator comparator) {
/*  69 */     if (parent.includes(key)) {
/*  70 */       return convertToRemovedComparisonNode(parent.copyCompleteSubtree(key), 2);
/*     */     }
/*     */     
/*  73 */     return new DataTreeNode(key.lastSegment(), new NodeComparison(null, null, 0, 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode copy() {
/*  82 */     return new DeletedNode(this.name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isDeleted() {
/*  90 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode simplifyWithParent(IPath key, DeltaDataTree parent, IComparator comparer) {
/*  98 */     if (parent.includes(key))
/*  99 */       return this; 
/* 100 */     return new NoDataDeltaNode(this.name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int size() {
/* 109 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int type() {
/* 117 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode childAtIgnoreCase(String localName) {
/* 123 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\dtree\DeletedNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */