/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import org.eclipse.core.internal.resources.ResourceException;
/*     */ import org.eclipse.core.internal.resources.ResourceStatus;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Bucket
/*     */ {
/*     */   static final String INDEXES_DIR_NAME = ".indexes";
/*     */   private final Map<String, Object> entries;
/*     */   private SoftReference<Map<Object, Map<String, Object>>> entriesCache;
/*     */   private File location;
/*     */   
/*     */   public static abstract class Entry
/*     */   {
/*     */     private static final int STATE_CLEAR = 0;
/*     */     private static final int STATE_DELETED = 2;
/*     */     private static final int STATE_DIRTY = 1;
/*     */     private IPath path;
/*  70 */     private byte state = 0;
/*     */     
/*     */     protected Entry(IPath path) {
/*  73 */       this.path = path;
/*     */     }
/*     */     
/*     */     public void delete() {
/*  77 */       this.state = 2;
/*     */     }
/*     */     
/*     */     public abstract int getOccurrences();
/*     */     
/*     */     public IPath getPath() {
/*  83 */       return this.path;
/*     */     }
/*     */     
/*     */     public abstract Object getValue();
/*     */     
/*     */     public boolean isDeleted() {
/*  89 */       return (this.state == 2);
/*     */     }
/*     */     
/*     */     public boolean isDirty() {
/*  93 */       return (this.state == 1);
/*     */     }
/*     */     
/*     */     public boolean isEmpty() {
/*  97 */       return (getOccurrences() == 0);
/*     */     }
/*     */     
/*     */     public void markDirty() {
/* 101 */       Assert.isTrue((this.state != 2));
/* 102 */       this.state = 1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void visited() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class Visitor
/*     */   {
/*     */     public static final int CONTINUE = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final int STOP = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final int RETURN = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void afterSaving(Bucket bucket) throws CoreException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void beforeSaving(Bucket bucket) throws CoreException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract int visit(Bucket.Entry param1Entry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean needSaving = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String projectName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Bucket() {
/* 176 */     this(false);
/*     */   }
/*     */   
/*     */   public Bucket(boolean cacheEntries) {
/* 180 */     this.entries = new HashMap<>();
/* 181 */     if (cacheEntries) {
/* 182 */       this.entriesCache = new SoftReference<>(null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int accept(Visitor visitor, IPath filter, int depth) throws CoreException {
/* 197 */     if (this.entries.isEmpty())
/* 198 */       return 0; 
/*     */     try {
/* 200 */       for (Iterator<Map.Entry<String, Object>> i = this.entries.entrySet().iterator(); i.hasNext(); ) {
/* 201 */         Map.Entry<String, Object> mapEntry = i.next();
/* 202 */         Path path = new Path(mapEntry.getKey());
/*     */         
/* 204 */         int matchingSegments = filter.matchingFirstSegments((IPath)path);
/* 205 */         if (!filter.isPrefixOf((IPath)path) || path.segmentCount() - matchingSegments > depth) {
/*     */           continue;
/*     */         }
/* 208 */         Entry bucketEntry = createEntry((IPath)path, mapEntry.getValue());
/*     */         
/* 210 */         int outcome = visitor.visit(bucketEntry);
/*     */         
/* 212 */         bucketEntry.visited();
/* 213 */         if (bucketEntry.isDeleted()) {
/* 214 */           this.needSaving = true;
/* 215 */           i.remove();
/* 216 */         } else if (bucketEntry.isDirty()) {
/* 217 */           this.needSaving = true;
/* 218 */           mapEntry.setValue(bucketEntry.getValue());
/*     */         } 
/* 220 */         if (outcome != 0)
/* 221 */           return outcome; 
/*     */       } 
/* 223 */       return 0;
/*     */     } finally {
/* 225 */       visitor.beforeSaving(this);
/* 226 */       save();
/* 227 */       visitor.afterSaving(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void cleanUp(File toDelete) {
/* 235 */     if (!toDelete.delete()) {
/*     */       return;
/*     */     }
/*     */     
/* 239 */     if (toDelete.getName().equals(".indexes")) {
/*     */       return;
/*     */     }
/* 242 */     cleanUp(toDelete.getParentFile());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Entry createEntry(IPath paramIPath, Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {
/* 255 */     if (isCachingEnabled()) {
/* 256 */       this.entriesCache.clear();
/*     */     }
/* 258 */     this.projectName = null;
/* 259 */     this.location = null;
/* 260 */     this.entries.clear();
/* 261 */     this.needSaving = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getEntryCount() {
/* 268 */     return this.entries.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getEntryValue(String path) {
/* 275 */     return this.entries.get(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String getIndexFileName();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract byte getVersion();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String getVersionFileName();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void load(String newProjectName, File baseLocation) throws CoreException {
/* 297 */     load(newProjectName, baseLocation, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void load(String newProjectName, File baseLocation, boolean force) throws CoreException {
/*     */     try {
/* 308 */       if (!force && this.location != null && baseLocation.equals(this.location.getParentFile()) && ((this.projectName == null) ? (newProjectName == null) : this.projectName.equals(newProjectName))) {
/* 309 */         this.projectName = newProjectName;
/*     */         
/*     */         return;
/*     */       } 
/* 313 */       save();
/* 314 */       this.projectName = newProjectName;
/* 315 */       this.location = new File(baseLocation, getIndexFileName());
/* 316 */       Map<String, Object> loadedEntries = null;
/* 317 */       this.entries.clear();
/* 318 */       if (force) {
/* 319 */         loadedEntries = loadEntries(this.location);
/*     */       } else {
/* 321 */         if (isCachingEnabled()) {
/* 322 */           Map<Object, Map<String, Object>> cache = this.entriesCache.get();
/* 323 */           if (cache != null) {
/* 324 */             loadedEntries = cache.get(createBucketKey());
/*     */           }
/*     */         } 
/*     */ 
/*     */         
/* 329 */         if (loadedEntries == null) {
/* 330 */           loadedEntries = loadEntries(this.location);
/*     */         }
/*     */       } 
/* 333 */       this.entries.putAll(loadedEntries);
/* 334 */     } catch (IOException ioe) {
/* 335 */       String message = NLS.bind(Messages.resources_readMeta, this.location.getAbsolutePath());
/* 336 */       ResourceStatus status = new ResourceStatus(567, null, message, ioe);
/* 337 */       throw new ResourceException(status);
/*     */     } 
/*     */   }
/*     */   
/*     */   boolean isCachingEnabled() {
/* 342 */     return (this.entriesCache != null);
/*     */   }
/*     */   
/*     */   private Object createBucketKey() {
/* 346 */     return (this.location == null) ? null : this.location.getAbsolutePath();
/*     */   }
/*     */   
/*     */   private Map<String, Object> loadEntries(File indexFile) throws CoreException, IOException {
/* 350 */     if (!indexFile.isFile()) {
/* 351 */       return Collections.EMPTY_MAP;
/*     */     }
/* 353 */     Map<String, Object> resultEntries = new HashMap<>();
/* 354 */     Exception exception1 = null, exception2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */     
/*     */     } finally {
/* 368 */       exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }
/*     */     
/*     */     } 
/*     */   } private String readEntryKey(DataInputStream source) throws IOException {
/* 372 */     if (this.projectName == null)
/* 373 */       return source.readUTF(); 
/* 374 */     return String.valueOf('/') + this.projectName + source.readUTF();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Object readEntryValue(DataInputStream paramDataInputStream) throws IOException, CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save() throws CoreException {
/* 386 */     if (isCachingEnabled()) {
/* 387 */       Object key = createBucketKey();
/* 388 */       if (key != null) {
/*     */ 
/*     */         
/* 391 */         Map.Entry[] a = new Map.Entry[0];
/* 392 */         Map<String, Object> denseCopy = Map.ofEntries((Map.Entry<? extends String, ?>[])this.entries.entrySet().toArray((Object[])a));
/* 393 */         Map<Object, Map<String, Object>> cache = this.entriesCache.get();
/* 394 */         if (cache == null) {
/* 395 */           cache = new WeakHashMap<>();
/* 396 */           this.entriesCache = new SoftReference<>(cache);
/*     */         } 
/* 398 */         cache.put(key, denseCopy);
/*     */       } 
/*     */     } 
/* 401 */     if (!this.needSaving)
/*     */       return; 
/*     */     try {
/* 404 */       if (this.entries.isEmpty()) {
/* 405 */         this.needSaving = false;
/* 406 */         cleanUp(this.location);
/*     */         
/*     */         return;
/*     */       } 
/* 410 */       File parent = this.location.getParentFile();
/* 411 */       if (parent == null)
/* 412 */         throw new IOException(); 
/* 413 */       parent.mkdirs();
/* 414 */       Exception exception1 = null, exception2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 423 */     catch (IOException ioe) {
/* 424 */       String message = NLS.bind(Messages.resources_writeMeta, this.location.getAbsolutePath());
/* 425 */       ResourceStatus status = new ResourceStatus(568, null, message, ioe);
/* 426 */       throw new ResourceException(status);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setEntryValue(String path, Object value) {
/* 435 */     if (value == null) {
/* 436 */       this.entries.remove(path);
/*     */     } else {
/* 438 */       this.entries.put(path, value);
/* 439 */     }  this.needSaving = true;
/*     */   }
/*     */   
/*     */   private void writeEntryKey(DataOutputStream destination, String path) throws IOException {
/* 443 */     if (this.projectName == null) {
/* 444 */       destination.writeUTF(path);
/*     */       
/*     */       return;
/*     */     } 
/* 448 */     int pathLength = path.length();
/* 449 */     int projectLength = this.projectName.length();
/* 450 */     String key = (pathLength == projectLength + 1) ? "" : path.substring(projectLength + 1);
/* 451 */     destination.writeUTF(key);
/*     */   }
/*     */   
/*     */   protected abstract void writeEntryValue(DataOutputStream paramDataOutputStream, Object paramObject) throws IOException, CoreException;
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\Bucket.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */