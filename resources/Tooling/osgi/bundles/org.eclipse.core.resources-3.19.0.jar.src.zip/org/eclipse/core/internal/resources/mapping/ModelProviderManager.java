/*    */ package org.eclipse.core.internal.resources.mapping;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.eclipse.core.internal.utils.Policy;
/*    */ import org.eclipse.core.resources.mapping.IModelProviderDescriptor;
/*    */ import org.eclipse.core.resources.mapping.ModelProvider;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IExtension;
/*    */ import org.eclipse.core.runtime.IExtensionPoint;
/*    */ import org.eclipse.core.runtime.Platform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModelProviderManager
/*    */ {
/*    */   private static Map<String, IModelProviderDescriptor> descriptors;
/*    */   private static ModelProviderManager instance;
/*    */   
/*    */   public static synchronized ModelProviderManager getDefault() {
/* 32 */     if (instance == null) {
/* 33 */       instance = new ModelProviderManager();
/*    */     }
/* 35 */     return instance;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void detectCycles() {}
/*    */ 
/*    */   
/*    */   public IModelProviderDescriptor getDescriptor(String id) {
/* 44 */     lazyInitialize();
/* 45 */     return descriptors.get(id);
/*    */   }
/*    */   
/*    */   public IModelProviderDescriptor[] getDescriptors() {
/* 49 */     lazyInitialize();
/* 50 */     return (IModelProviderDescriptor[])descriptors.values().toArray((Object[])new IModelProviderDescriptor[descriptors.size()]);
/*    */   }
/*    */   
/*    */   public ModelProvider getModelProvider(String modelProviderId) throws CoreException {
/* 54 */     IModelProviderDescriptor desc = getDescriptor(modelProviderId);
/* 55 */     if (desc == null)
/* 56 */       return null; 
/* 57 */     return desc.getModelProvider();
/*    */   }
/*    */   
/*    */   protected void lazyInitialize() {
/* 61 */     if (descriptors != null)
/*    */       return; 
/* 63 */     IExtensionPoint point = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.core.resources", "modelProviders");
/* 64 */     IExtension[] extensions = point.getExtensions();
/* 65 */     descriptors = new HashMap<>(extensions.length * 2 + 1); byte b; int i; IExtension[] arrayOfIExtension1;
/* 66 */     for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension1[b];
/* 67 */       IModelProviderDescriptor desc = null;
/*    */       try {
/* 69 */         desc = new ModelProviderDescriptor(extension);
/* 70 */       } catch (CoreException e) {
/* 71 */         Policy.log((Throwable)e);
/*    */       } 
/* 73 */       if (desc != null) {
/* 74 */         descriptors.put(desc.getId(), desc);
/*    */       }
/*    */       b++; }
/*    */     
/* 78 */     detectCycles();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\mapping\ModelProviderManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */