/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VariableDescription
/*    */   implements Comparable<VariableDescription>
/*    */ {
/*    */   private String name;
/*    */   private String value;
/*    */   
/*    */   public VariableDescription() {
/* 27 */     this.name = "";
/* 28 */     this.value = "";
/*    */   }
/*    */ 
/*    */   
/*    */   public VariableDescription(String name, String value) {
/* 33 */     Assert.isNotNull(name);
/* 34 */     Assert.isNotNull(value);
/* 35 */     this.name = name;
/* 36 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 41 */     if (o == null) {
/* 42 */       return false;
/*    */     }
/* 44 */     if (o.getClass() != getClass())
/* 45 */       return false; 
/* 46 */     VariableDescription other = (VariableDescription)o;
/* 47 */     return (this.name.equals(other.name) && this.value == other.value);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 51 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 55 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 60 */     return this.name.hashCode() + this.value.hashCode();
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 64 */     this.name = name;
/*    */   }
/*    */   
/*    */   public void setValue(String value) {
/* 68 */     this.value = value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int compareTo(VariableDescription that) {
/* 77 */     return this.name.compareTo(that.name);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\VariableDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */