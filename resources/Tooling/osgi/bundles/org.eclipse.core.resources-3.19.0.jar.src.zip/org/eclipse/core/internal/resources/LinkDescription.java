/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinkDescription
/*     */   implements Comparable<LinkDescription>
/*     */ {
/*  28 */   public static final URI VIRTUAL_LOCATION = getVirtualLocation();
/*     */   
/*     */   private static URI getVirtualLocation() {
/*     */     try {
/*  32 */       return new URI("virtual:/virtual");
/*  33 */     } catch (URISyntaxException uRISyntaxException) {
/*     */       
/*  35 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private URI localLocation;
/*     */ 
/*     */   
/*     */   private IPath path;
/*     */ 
/*     */   
/*     */   private int type;
/*     */ 
/*     */   
/*     */   public LinkDescription() {
/*  51 */     this.path = (IPath)Path.EMPTY;
/*  52 */     this.type = -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public LinkDescription(IResource linkedResource, URI location) {
/*  57 */     Assert.isNotNull(linkedResource);
/*  58 */     Assert.isNotNull(location);
/*  59 */     this.type = linkedResource.getType();
/*  60 */     this.path = linkedResource.getProjectRelativePath();
/*  61 */     this.localLocation = location;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  66 */     if (o == null) {
/*  67 */       return false;
/*     */     }
/*  69 */     if (o.getClass() != getClass())
/*  70 */       return false; 
/*  71 */     LinkDescription other = (LinkDescription)o;
/*  72 */     return (this.localLocation.equals(other.localLocation) && this.path.equals(other.path) && this.type == other.type);
/*     */   }
/*     */   
/*     */   public URI getLocationURI() {
/*  76 */     return this.localLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getProjectRelativePath() {
/*  84 */     return this.path;
/*     */   }
/*     */   
/*     */   public int getType() {
/*  88 */     return this.type;
/*     */   }
/*     */   
/*     */   public boolean isGroup() {
/*  92 */     return this.localLocation.equals(VIRTUAL_LOCATION);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  97 */     return this.type + this.path.hashCode() + this.localLocation.hashCode();
/*     */   }
/*     */   
/*     */   public void setLocationURI(URI location) {
/* 101 */     this.localLocation = location;
/*     */   }
/*     */   
/*     */   public void setPath(IPath path) {
/* 105 */     this.path = path;
/*     */   }
/*     */   
/*     */   public void setType(int type) {
/* 109 */     this.type = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(LinkDescription that) {
/* 119 */     IPath path1 = getProjectRelativePath();
/* 120 */     IPath path2 = that.getProjectRelativePath();
/* 121 */     int count1 = path1.segmentCount();
/* 122 */     int compare = count1 - path2.segmentCount();
/* 123 */     if (compare != 0)
/* 124 */       return compare; 
/* 125 */     for (int i = 0; i < count1; i++) {
/* 126 */       compare = path1.segment(i).compareTo(path2.segment(i));
/* 127 */       if (compare != 0)
/* 128 */         return compare; 
/*     */     } 
/* 130 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\LinkDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */