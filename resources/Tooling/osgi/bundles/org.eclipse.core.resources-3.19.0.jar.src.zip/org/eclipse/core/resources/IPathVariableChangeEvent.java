package org.eclipse.core.resources;

import org.eclipse.core.runtime.IPath;

public interface IPathVariableChangeEvent {
  public static final int VARIABLE_CHANGED = 1;
  
  public static final int VARIABLE_CREATED = 2;
  
  public static final int VARIABLE_DELETED = 3;
  
  IPath getValue();
  
  String getVariableName();
  
  Object getSource();
  
  int getType();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IPathVariableChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */