/*      */ package org.eclipse.core.internal.resources;
/*      */ import java.net.URI;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.eclipse.core.filesystem.IFileInfo;
/*      */ import org.eclipse.core.filesystem.IFileStore;
/*      */ import org.eclipse.core.filesystem.URIUtil;
/*      */ import org.eclipse.core.filesystem.provider.FileInfo;
/*      */ import org.eclipse.core.internal.events.LifecycleEvent;
/*      */ import org.eclipse.core.internal.utils.Messages;
/*      */ import org.eclipse.core.internal.utils.WrappedRuntimeException;
/*      */ import org.eclipse.core.internal.watson.ElementTreeIterator;
/*      */ import org.eclipse.core.internal.watson.IElementContentVisitor;
/*      */ import org.eclipse.core.internal.watson.IPathRequestor;
/*      */ import org.eclipse.core.resources.IContainer;
/*      */ import org.eclipse.core.resources.IFile;
/*      */ import org.eclipse.core.resources.IFolder;
/*      */ import org.eclipse.core.resources.IMarker;
/*      */ import org.eclipse.core.resources.IProject;
/*      */ import org.eclipse.core.resources.IProjectDescription;
/*      */ import org.eclipse.core.resources.IResource;
/*      */ import org.eclipse.core.resources.IResourceProxy;
/*      */ import org.eclipse.core.resources.IResourceProxyVisitor;
/*      */ import org.eclipse.core.resources.IResourceVisitor;
/*      */ import org.eclipse.core.resources.ResourceAttributes;
/*      */ import org.eclipse.core.resources.team.IMoveDeleteHook;
/*      */ import org.eclipse.core.runtime.Assert;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.MultiStatus;
/*      */ import org.eclipse.core.runtime.OperationCanceledException;
/*      */ import org.eclipse.core.runtime.Path;
/*      */ import org.eclipse.core.runtime.QualifiedName;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.core.runtime.SubMonitor;
/*      */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*      */ import org.eclipse.core.runtime.jobs.MultiRule;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ 
/*      */ public abstract class Resource extends PlatformObject implements IResource, ICoreConstants, Cloneable, IPathRequestor {
/*      */   final IPath path;
/*      */   
/*      */   protected Resource(IPath path, Workspace workspace) {
/*   49 */     this.path = path.removeTrailingSeparator();
/*   50 */     this.workspace = workspace;
/*      */   }
/*      */   final Workspace workspace;
/*      */   
/*      */   public void accept(IResourceProxyVisitor visitor, int memberFlags) throws CoreException {
/*   55 */     accept(visitor, 2, memberFlags);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void accept(IResourceProxyVisitor visitor, int depth, int memberFlags) throws CoreException {
/*   61 */     boolean includePhantoms = ((memberFlags & 0x1) != 0);
/*   62 */     if ((memberFlags & 0x10) == 0) {
/*   63 */       checkAccessible(getFlags(getResourceInfo(includePhantoms, false)));
/*      */     }
/*   65 */     ResourceProxy proxy = new ResourceProxy();
/*   66 */     IElementContentVisitor elementVisitor = (tree, requestor, contents) -> {
/*      */         ResourceInfo info = (ResourceInfo)contents;
/*      */         if (!isMember(getFlags(info), paramInt1))
/*      */           return false; 
/*      */         paramResourceProxy.requestor = requestor;
/*      */         paramResourceProxy.info = info;
/*      */         try {
/*      */           boolean shouldContinue = true;
/*      */           switch (paramInt2) {
/*      */             case 0:
/*      */               shouldContinue = false;
/*      */               break;
/*      */             case 1:
/*      */               shouldContinue = !this.path.equals(requestor.requestPath().removeLastSegments(1));
/*      */               break;
/*      */             case 2:
/*      */               shouldContinue = true;
/*      */               break;
/*      */           } 
/*   85 */           return (paramIResourceProxyVisitor.visit(paramResourceProxy) && shouldContinue);
/*   86 */         } catch (CoreException e) {
/*      */           throw new WrappedRuntimeException(e);
/*      */         } finally {
/*      */           paramResourceProxy.reset();
/*      */         } 
/*      */       };
/*      */     
/*      */     try {
/*   94 */       (new ElementTreeIterator(this.workspace.getElementTree(), getFullPath())).iterate(elementVisitor);
/*   95 */     } catch (WrappedRuntimeException e) {
/*   96 */       throw (CoreException)e.getTargetException();
/*      */     } finally {
/*   98 */       proxy.requestor = null;
/*   99 */       proxy.info = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void accept(IResourceVisitor visitor) throws CoreException {
/*  105 */     accept(visitor, 2, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public void accept(IResourceVisitor visitor, int depth, boolean includePhantoms) throws CoreException {
/*  110 */     accept(visitor, depth, includePhantoms ? 1 : 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void accept(IResourceVisitor visitor, int depth, int memberFlags) throws CoreException {
/*  116 */     if (depth == 2) {
/*  117 */       accept(proxy -> paramIResourceVisitor.visit(proxy.requestResource()), memberFlags);
/*      */       
/*      */       return;
/*      */     } 
/*  121 */     boolean includePhantoms = ((memberFlags & 0x1) != 0);
/*  122 */     ResourceInfo info = getResourceInfo(includePhantoms, false);
/*  123 */     int flags = getFlags(info);
/*  124 */     if ((memberFlags & 0x10) == 0) {
/*  125 */       checkAccessible(flags);
/*      */     }
/*      */     
/*  128 */     if (!isMember(flags, memberFlags)) {
/*      */       return;
/*      */     }
/*  131 */     if (!visitor.visit(this) || depth == 0) {
/*      */       return;
/*      */     }
/*  134 */     info = getResourceInfo(includePhantoms, false);
/*  135 */     if (info == null) {
/*      */       return;
/*      */     }
/*  138 */     int type = info.getType();
/*  139 */     if (type == 1) {
/*      */       return;
/*      */     }
/*  142 */     IContainer resource = (getType() != type) ? (IContainer)this.workspace.newResource(getFullPath(), type) : (IContainer)this;
/*  143 */     IResource[] members = resource.members(memberFlags); byte b; int i; IResource[] arrayOfIResource1;
/*  144 */     for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource member = arrayOfIResource1[b];
/*  145 */       member.accept(visitor, 0, memberFlags | 0x10);
/*      */       b++; }
/*      */   
/*      */   } protected void assertCopyRequirements(IPath destination, int destinationType, int updateFlags) throws CoreException {
/*  149 */     IStatus status = checkCopyRequirements(destination, destinationType, updateFlags);
/*  150 */     if (!status.isOK())
/*      */     {
/*      */       
/*  153 */       Assert.isTrue(false, status.getChildren()[0].getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IFileInfo assertLinkRequirements(URI localLocation, int updateFlags) throws CoreException {
/*  163 */     boolean allowMissingLocal = ((updateFlags & 0x10) != 0);
/*  164 */     if ((updateFlags & 0x100) == 0)
/*  165 */       checkDoesNotExist(getFlags(getResourceInfo(false, false)), true); 
/*  166 */     IStatus locationStatus = this.workspace.validateLinkLocationURI(this, localLocation);
/*      */     
/*  168 */     boolean variableUndefined = (locationStatus.getCode() == 333);
/*  169 */     if (locationStatus.getSeverity() == 4 || (variableUndefined && !allowMissingLocal)) {
/*  170 */       throw new ResourceException(locationStatus);
/*      */     }
/*  172 */     Container parent = (Container)getParent();
/*  173 */     parent.checkAccessible(getFlags(parent.getResourceInfo(false, false)));
/*      */     
/*  175 */     if (variableUndefined) {
/*  176 */       return null;
/*      */     }
/*  178 */     URI resolved = getPathVariableManager().resolveURI(localLocation);
/*  179 */     IFileStore store = EFS.getStore(resolved);
/*  180 */     IFileInfo fileInfo = store.fetchInfo();
/*  181 */     boolean localExists = fileInfo.exists();
/*  182 */     if (!allowMissingLocal && !localExists) {
/*  183 */       String msg = NLS.bind(Messages.links_localDoesNotExist, store.toString());
/*  184 */       throw new ResourceException(269, getFullPath(), msg, null);
/*      */     } 
/*      */     
/*  187 */     if (localExists && ((getType() == 2)) != fileInfo.isDirectory()) {
/*  188 */       String msg = NLS.bind(Messages.links_wrongLocalType, getFullPath());
/*  189 */       throw new ResourceException(276, getFullPath(), msg, null);
/*      */     } 
/*  191 */     return fileInfo;
/*      */   }
/*      */   
/*      */   protected void assertMoveRequirements(IPath destination, int destinationType, int updateFlags) throws CoreException {
/*  195 */     IStatus status = checkMoveRequirements(destination, destinationType, updateFlags);
/*  196 */     if (!status.isOK())
/*      */     {
/*      */       
/*  199 */       Assert.isTrue(false, status.getChildren()[0].getMessage());
/*      */     }
/*      */   }
/*      */   
/*      */   public void checkAccessible(int flags) throws CoreException {
/*  204 */     checkExists(flags, true);
/*      */   }
/*      */   
/*      */   private ResourceInfo checkAccessibleAndLocal(int depth) throws CoreException {
/*  208 */     ResourceInfo info = getResourceInfo(false, false);
/*  209 */     int flags = getFlags(info);
/*  210 */     checkAccessible(flags);
/*  211 */     checkLocal(flags, depth);
/*  212 */     return info;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IStatus checkCopyRequirements(IPath destination, int destinationType, int updateFlags) throws CoreException {
/*  228 */     String message = Messages.resources_copyNotMet;
/*  229 */     MultiStatus status = new MultiStatus("org.eclipse.core.resources", 77, message, null);
/*  230 */     if (destination == null) {
/*  231 */       message = Messages.resources_destNotNull;
/*  232 */       return (IStatus)new ResourceStatus(77, getFullPath(), message);
/*      */     } 
/*  234 */     destination = makePathAbsolute(destination);
/*  235 */     if (getFullPath().isPrefixOf(destination)) {
/*  236 */       message = NLS.bind(Messages.resources_copyDestNotSub, getFullPath());
/*  237 */       status.add((IStatus)new ResourceStatus(77, getFullPath(), message));
/*      */     } 
/*  239 */     checkValidPath(destination, destinationType, false);
/*      */ 
/*      */     
/*  242 */     checkAccessibleAndLocal(2);
/*      */     
/*  244 */     IPath destinationParent = destination.removeLastSegments(1);
/*  245 */     checkValidGroupContainer(destinationParent, isLinked(), isVirtual());
/*      */     
/*  247 */     Resource dest = this.workspace.newResource(destination, destinationType);
/*  248 */     dest.checkDoesNotExist();
/*      */ 
/*      */     
/*  251 */     if (getType() == 1 && destinationType == 4) {
/*  252 */       message = Messages.resources_fileToProj;
/*  253 */       throw new ResourceException(77, getFullPath(), message, null);
/*      */     } 
/*      */ 
/*      */     
/*  257 */     if (destinationType != 4) {
/*  258 */       Project project = (Project)dest.getProject();
/*  259 */       ResourceInfo info = project.getResourceInfo(false, false);
/*  260 */       project.checkAccessible(getFlags(info));
/*  261 */       Container parent = (Container)dest.getParent();
/*  262 */       if (!parent.equals(project)) {
/*  263 */         info = parent.getResourceInfo(false, false);
/*  264 */         parent.checkExists(getFlags(info), true);
/*      */       } 
/*      */     } 
/*  267 */     if (isUnderLink() || dest.isUnderLink()) {
/*      */ 
/*      */       
/*  270 */       URI sourceLocation = getLocationURI();
/*  271 */       if (sourceLocation == null) {
/*  272 */         message = NLS.bind(Messages.localstore_locationUndefined, getFullPath());
/*  273 */         throw new ResourceException(271, getFullPath(), message, null);
/*      */       } 
/*  275 */       URI destLocation = dest.getLocationURI();
/*  276 */       if (destLocation == null && !dest.isUnderVirtual()) {
/*  277 */         message = NLS.bind(Messages.localstore_locationUndefined, dest.getFullPath());
/*  278 */         throw new ResourceException(271, dest.getFullPath(), message, null);
/*      */       } 
/*      */ 
/*      */       
/*  282 */       if (getStore().isParentOf(dest.getStore())) {
/*  283 */         message = NLS.bind(Messages.resources_copyDestNotSub, getFullPath());
/*  284 */         throw new ResourceException(77, getFullPath(), message, null);
/*      */       } 
/*      */     } 
/*      */     
/*  288 */     return status.isOK() ? Status.OK_STATUS : (IStatus)status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkDoesNotExist() throws CoreException {
/*  296 */     checkDoesNotExist(getFlags(getResourceInfo(false, false)), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkDoesNotExist(int flags, boolean checkType) throws CoreException {
/*  307 */     if (exists(flags, checkType)) {
/*  308 */       String message = NLS.bind(Messages.resources_mustNotExist, getFullPath());
/*  309 */       throw new ResourceException(checkType ? 367 : 374, getFullPath(), message, null);
/*      */     } 
/*  311 */     if (Workspace.caseSensitive) {
/*      */       return;
/*      */     }
/*  314 */     IResource variant = findExistingResourceVariant(getFullPath());
/*  315 */     if (variant == null)
/*      */       return; 
/*  317 */     String msg = NLS.bind(Messages.resources_existsDifferentCase, variant.getFullPath());
/*  318 */     throw new ResourceException(275, variant.getFullPath(), msg, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkExists(int flags, boolean checkType) throws CoreException {
/*  328 */     if (!exists(flags, checkType)) {
/*  329 */       String message = NLS.bind(Messages.resources_mustExist, getFullPath());
/*  330 */       throw new ResourceException(368, getFullPath(), message, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkLocal(int flags, int depth) throws CoreException {
/*  340 */     if (!isLocal(flags, depth)) {
/*  341 */       String message = NLS.bind(Messages.resources_mustBeLocal, getFullPath());
/*  342 */       throw new ResourceException(369, getFullPath(), message, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IStatus checkMoveRequirements(IPath destination, int destinationType, int updateFlags) throws CoreException {
/*  361 */     String message = Messages.resources_moveNotMet;
/*  362 */     MultiStatus status = new MultiStatus("org.eclipse.core.resources", 77, message, null);
/*  363 */     if (destination == null) {
/*  364 */       message = Messages.resources_destNotNull;
/*  365 */       return (IStatus)new ResourceStatus(77, getFullPath(), message);
/*      */     } 
/*  367 */     destination = makePathAbsolute(destination);
/*  368 */     if (getFullPath().isPrefixOf(destination)) {
/*  369 */       message = NLS.bind(Messages.resources_moveDestNotSub, getFullPath());
/*  370 */       status.add((IStatus)new ResourceStatus(77, getFullPath(), message));
/*      */     } 
/*  372 */     checkValidPath(destination, destinationType, false);
/*      */ 
/*      */     
/*  375 */     checkAccessibleAndLocal(2);
/*      */     
/*  377 */     IPath destinationParent = destination.removeLastSegments(1);
/*  378 */     checkValidGroupContainer(destinationParent, isLinked(), isVirtual());
/*      */     
/*  380 */     Resource dest = this.workspace.newResource(destination, destinationType);
/*      */ 
/*      */     
/*  383 */     IResource variant = Workspace.caseSensitive ? null : findExistingResourceVariant(destination);
/*  384 */     if (variant == null || !equals(variant)) {
/*  385 */       dest.checkDoesNotExist();
/*      */     }
/*      */     
/*  388 */     if (getType() == 1 && dest.getType() == 4) {
/*  389 */       message = Messages.resources_fileToProj;
/*  390 */       throw new ResourceException(new ResourceStatus(77, getFullPath(), message));
/*      */     } 
/*      */ 
/*      */     
/*  394 */     if (destinationType != 4) {
/*  395 */       Project project = (Project)dest.getProject();
/*  396 */       ResourceInfo info = project.getResourceInfo(false, false);
/*  397 */       project.checkAccessible(getFlags(info));
/*  398 */       Container parent = (Container)dest.getParent();
/*  399 */       if (!parent.equals(project)) {
/*  400 */         info = parent.getResourceInfo(false, false);
/*  401 */         parent.checkExists(getFlags(info), true);
/*      */       } 
/*      */     } 
/*  404 */     if (isUnderLink() || dest.isUnderLink()) {
/*      */ 
/*      */       
/*  407 */       URI sourceLocation = getLocationURI();
/*  408 */       if (sourceLocation == null) {
/*  409 */         message = NLS.bind(Messages.localstore_locationUndefined, getFullPath());
/*  410 */         throw new ResourceException(271, getFullPath(), message, null);
/*      */       } 
/*  412 */       URI destLocation = dest.getLocationURI();
/*  413 */       if (destLocation == null && !dest.isUnderVirtual()) {
/*  414 */         message = NLS.bind(Messages.localstore_locationUndefined, dest.getFullPath());
/*  415 */         throw new ResourceException(271, dest.getFullPath(), message, null);
/*      */       } 
/*      */ 
/*      */       
/*  419 */       if (getStore().isParentOf(dest.getStore())) {
/*  420 */         message = NLS.bind(Messages.resources_moveDestNotSub, getFullPath());
/*  421 */         throw new ResourceException(77, getFullPath(), message, null);
/*      */       } 
/*      */     } 
/*      */     
/*  425 */     return status.isOK() ? Status.OK_STATUS : (IStatus)status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkValidPath(IPath toValidate, int type, boolean lastSegmentOnly) throws CoreException {
/*  434 */     IStatus result = this.workspace.locationValidator.validatePath(toValidate, type, lastSegmentOnly);
/*  435 */     if (!result.isOK()) {
/*  436 */       throw new ResourceException(result);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkValidGroupContainer(IPath destination, boolean isLink, boolean isGroup) throws CoreException {
/*  445 */     IStatus status = getValidGroupContainer(destination, isLink, isGroup);
/*  446 */     if (!status.isOK()) {
/*  447 */       throw new ResourceException(status);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkValidGroupContainer(Container destination, boolean isLink, boolean isGroup) throws CoreException {
/*  456 */     if (!isLink && !isGroup) {
/*  457 */       String message = Messages.group_invalidParent;
/*  458 */       if (destination.isVirtual())
/*  459 */         throw new ResourceException(new ResourceStatus(77, null, message)); 
/*      */     } 
/*      */   }
/*      */   
/*      */   public IStatus getValidGroupContainer(IPath destination, boolean isLink, boolean isGroup) {
/*  464 */     if (!isLink && !isGroup) {
/*  465 */       String message = Messages.group_invalidParent;
/*  466 */       ResourceInfo info = this.workspace.getResourceInfo(destination, false, false);
/*  467 */       if (info != null && info.isSet(524288))
/*  468 */         return (IStatus)new ResourceStatus(77, null, message); 
/*      */     } 
/*  470 */     return Status.OK_STATUS;
/*      */   }
/*      */ 
/*      */   
/*      */   public void clearHistory(IProgressMonitor monitor) {
/*  475 */     getLocalManager().getHistoryStore().remove(getFullPath(), monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean contains(ISchedulingRule rule) {
/*  480 */     if (this == rule) {
/*  481 */       return true;
/*      */     }
/*  483 */     if (rule.getClass().equals(WorkManager.NotifyRule.class))
/*  484 */       return true; 
/*  485 */     if (rule instanceof MultiRule) {
/*  486 */       MultiRule multi = (MultiRule)rule;
/*  487 */       ISchedulingRule[] children = multi.getChildren(); byte b; int i; ISchedulingRule[] arrayOfISchedulingRule1;
/*  488 */       for (i = (arrayOfISchedulingRule1 = children).length, b = 0; b < i; ) { ISchedulingRule c = arrayOfISchedulingRule1[b];
/*  489 */         if (!contains(c))
/*  490 */           return false; 
/*      */         b++; }
/*      */       
/*  493 */       return true;
/*      */     } 
/*  495 */     if (!(rule instanceof IResource))
/*  496 */       return false; 
/*  497 */     IResource resource = (IResource)rule;
/*  498 */     if (!this.workspace.equals(resource.getWorkspace()))
/*  499 */       return false; 
/*  500 */     return this.path.isPrefixOf(resource.getFullPath());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void convertToPhantom() throws CoreException {
/*  507 */     ResourceInfo info = getResourceInfo(false, true);
/*  508 */     if (info == null || isPhantom(getFlags(info)))
/*      */       return; 
/*  510 */     info.clearSessionProperties();
/*  511 */     info.set(8);
/*  512 */     getLocalManager().updateLocalSync(info, -1L);
/*  513 */     info.clearModificationStamp();
/*      */ 
/*      */     
/*  516 */     info.setMarkers(null);
/*      */   }
/*      */ 
/*      */   
/*      */   public void copy(IPath destination, boolean force, IProgressMonitor monitor) throws CoreException {
/*  521 */     int updateFlags = force ? 1 : 0;
/*  522 */     copy(destination, updateFlags, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void copy(IPath destination, int updateFlags, IProgressMonitor monitor) throws CoreException {
/*  527 */     String message = NLS.bind(Messages.resources_copying, getFullPath());
/*  528 */     SubMonitor progress = SubMonitor.convert(monitor, message, 100).checkCanceled();
/*  529 */     destination = makePathAbsolute(destination);
/*  530 */     checkValidPath(destination, getType(), false);
/*  531 */     Resource destResource = this.workspace.newResource(destination, getType());
/*  532 */     ISchedulingRule rule = this.workspace.getRuleFactory().copyRule(this, destResource);
/*  533 */     SubMonitor split = progress.split(1);
/*      */     try {
/*  535 */       this.workspace.prepareOperation(rule, (IProgressMonitor)split);
/*      */ 
/*      */       
/*  538 */       assertCopyRequirements(destination, getType(), updateFlags);
/*  539 */       this.workspace.beginOperation(true);
/*  540 */       getLocalManager().copy(this, destResource, updateFlags, (IProgressMonitor)progress.split(98));
/*  541 */     } catch (OperationCanceledException e) {
/*  542 */       this.workspace.getWorkManager().operationCanceled();
/*  543 */       throw e;
/*      */     } finally {
/*  545 */       progress.done();
/*  546 */       this.workspace.endOperation(rule, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void copy(IProjectDescription destDesc, boolean force, IProgressMonitor monitor) throws CoreException {
/*  552 */     int updateFlags = force ? 1 : 0;
/*  553 */     copy(destDesc, updateFlags, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copy(IProjectDescription destDesc, int updateFlags, IProgressMonitor monitor) throws CoreException {
/*  562 */     Assert.isNotNull(destDesc);
/*  563 */     String message = NLS.bind(Messages.resources_copying, getFullPath());
/*  564 */     SubMonitor progress = SubMonitor.convert(monitor, message, 100).checkCanceled();
/*  565 */     SubMonitor split = progress.split(1);
/*      */     try {
/*  567 */       this.workspace.prepareOperation((ISchedulingRule)this.workspace.getRoot(), (IProgressMonitor)split);
/*      */ 
/*      */       
/*  570 */       IPath destPath = (new Path(destDesc.getName())).makeAbsolute();
/*  571 */       assertCopyRequirements(destPath, getType(), updateFlags);
/*  572 */       Project destProject = (Project)this.workspace.getRoot().getProject(destPath.lastSegment());
/*  573 */       this.workspace.beginOperation(true);
/*      */ 
/*      */       
/*  576 */       destProject.create(destDesc, (IProgressMonitor)progress.split(5));
/*  577 */       destProject.open((IProgressMonitor)progress.split(5));
/*      */ 
/*      */       
/*  580 */       IResource[] children = ((IContainer)this).members(10);
/*  581 */       SubMonitor loopProgress = SubMonitor.convert((IProgressMonitor)progress.split(70), children.length); byte b; int i; IResource[] arrayOfIResource1;
/*  582 */       for (i = (arrayOfIResource1 = children).length, b = 0; b < i; ) { IResource element = arrayOfIResource1[b];
/*  583 */         Resource child = (Resource)element;
/*  584 */         child.copy(destPath.append(child.getName()), updateFlags, (IProgressMonitor)loopProgress.split(1));
/*      */         
/*      */         b++; }
/*      */       
/*  588 */       getPropertyManager().copy(this, destProject, 0);
/*  589 */       progress.split(18);
/*  590 */     } catch (OperationCanceledException e) {
/*  591 */       this.workspace.getWorkManager().operationCanceled();
/*  592 */       throw e;
/*      */     } finally {
/*  594 */       progress.done();
/*  595 */       this.workspace.endOperation((ISchedulingRule)this.workspace.getRoot(), true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int countResources(int depth, boolean phantom) {
/*  605 */     return this.workspace.countResources(this.path, depth, phantom);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void createLink(IPath localLocation, int updateFlags, IProgressMonitor monitor) throws CoreException {
/*  613 */     Assert.isNotNull(localLocation);
/*  614 */     createLink(URIUtil.toURI(localLocation), updateFlags, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void createLink(URI localLocation, int updateFlags, IProgressMonitor monitor) throws CoreException {
/*  622 */     Assert.isNotNull(localLocation);
/*  623 */     IResource existing = null;
/*  624 */     if ((updateFlags & 0x100) != 0) {
/*  625 */       existing = this.workspace.getRoot().findMember(getFullPath());
/*  626 */       if (existing != null && existing.isLinked()) {
/*  627 */         setLinkLocation(localLocation, updateFlags, monitor);
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*  632 */     String message = NLS.bind(Messages.links_creating, getFullPath());
/*  633 */     SubMonitor progress = SubMonitor.convert(monitor, message, 100).checkCanceled();
/*  634 */     checkValidPath(this.path, 2, true);
/*  635 */     ISchedulingRule rule = this.workspace.getRuleFactory().createRule(this);
/*  636 */     SubMonitor split = progress.split(1);
/*      */     try {
/*  638 */       this.workspace.prepareOperation(rule, (IProgressMonitor)split);
/*  639 */       IFileInfo fileInfo = assertLinkRequirements(localLocation, updateFlags);
/*  640 */       this.workspace.broadcastEvent(LifecycleEvent.newEvent(512, this));
/*  641 */       this.workspace.beginOperation(true);
/*      */       
/*  643 */       if ((updateFlags & 0x100) != 0 && existing != null) {
/*  644 */         this.workspace.deleteResource(existing);
/*      */       }
/*  646 */       ResourceInfo info = this.workspace.createResource(this, false);
/*  647 */       if ((updateFlags & 0x1000) != 0)
/*  648 */         info.set(2097152); 
/*  649 */       info.set(65536);
/*  650 */       LinkDescription linkDescription = new LinkDescription(this, localLocation);
/*  651 */       if (linkDescription.isGroup())
/*  652 */         info.set(524288); 
/*  653 */       getLocalManager().link(this, localLocation, fileInfo);
/*  654 */       progress.split(5);
/*      */       
/*  656 */       Project project = (Project)getProject();
/*  657 */       boolean changed = project.internalGetDescription().setLinkLocation(getProjectRelativePath(), linkDescription);
/*  658 */       if (changed) {
/*      */         try {
/*  660 */           project.writeDescription(0);
/*  661 */         } catch (CoreException e) {
/*      */           
/*  663 */           this.workspace.deleteResource(this);
/*  664 */           throw e;
/*      */         } 
/*      */       }
/*  667 */       progress.split(4);
/*      */ 
/*      */       
/*  670 */       if (getType() != 1) {
/*      */         
/*  672 */         if ((updateFlags & 0x80) != 0) {
/*  673 */           this.workspace.refreshManager.refresh(this);
/*  674 */           progress.split(90);
/*      */         } else {
/*  676 */           refreshLocal(2, (IProgressMonitor)progress.split(90));
/*      */         } 
/*      */       } else {
/*  679 */         progress.split(90);
/*      */       } 
/*  681 */     } catch (OperationCanceledException e) {
/*  682 */       this.workspace.getWorkManager().operationCanceled();
/*  683 */       throw e;
/*      */     } finally {
/*  685 */       progress.done();
/*  686 */       this.workspace.endOperation(rule, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public IMarker createMarker(String type) throws CoreException {
/*  692 */     return createMarker(type, Collections.emptyMap());
/*      */   }
/*      */ 
/*      */   
/*      */   public IMarker createMarker(String type, Map<String, ? extends Object> attributes) throws CoreException {
/*  697 */     Assert.isNotNull(type);
/*  698 */     ISchedulingRule rule = this.workspace.getRuleFactory().markerRule(this);
/*      */     try {
/*  700 */       this.workspace.prepareOperation(rule, null);
/*  701 */       checkAccessible(getFlags(getResourceInfo(false, false)));
/*  702 */       this.workspace.beginOperation(true);
/*  703 */       long id = this.workspace.nextMarkerId();
/*  704 */       MarkerManager manager = this.workspace.getMarkerManager();
/*  705 */       boolean validate = manager.isPersistentType(type);
/*  706 */       MarkerInfo markerInfo = new MarkerInfo(attributes, validate, type, id);
/*  707 */       manager.add(this, markerInfo);
/*  708 */       if (attributes != null && !attributes.isEmpty() && 
/*  709 */         manager.isPersistent(markerInfo)) {
/*  710 */         getResourceInfo(false, true).set(4096);
/*      */       }
/*      */       
/*  713 */       return new Marker(this, markerInfo.getId());
/*      */     } finally {
/*  715 */       this.workspace.endOperation(rule, false);
/*      */     } 
/*      */   }
/*      */   
/*      */   public IResourceProxy createProxy() {
/*  720 */     ResourceProxy result = new ResourceProxy();
/*  721 */     result.info = getResourceInfo(false, false);
/*  722 */     result.requestor = this;
/*  723 */     result.resource = this;
/*  724 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void delete(boolean force, boolean keepHistory, IProgressMonitor monitor) throws CoreException {
/*  733 */     int updateFlags = force ? 1 : 0;
/*  734 */     updateFlags |= keepHistory ? 2 : 0;
/*  735 */     delete(updateFlags, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void delete(boolean force, IProgressMonitor monitor) throws CoreException {
/*  740 */     delete(force ? 1 : 0, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void delete(int updateFlags, IProgressMonitor monitor) throws CoreException {
/*  745 */     String message = NLS.bind(Messages.resources_deleting, getFullPath());
/*  746 */     SubMonitor progress = SubMonitor.convert(monitor, 100).checkCanceled();
/*  747 */     progress.subTask(message);
/*  748 */     ISchedulingRule rule = this.workspace.getRuleFactory().deleteRule(this);
/*  749 */     SubMonitor split = progress.split(1);
/*      */     try {
/*  751 */       this.workspace.prepareOperation(rule, (IProgressMonitor)split);
/*      */       
/*  753 */       if (!exists())
/*      */         return; 
/*  755 */       this.workspace.beginOperation(true);
/*  756 */       broadcastPreDeleteEvent();
/*      */ 
/*      */       
/*  759 */       if (getType() == 4) {
/*  760 */         this.workspace.flushBuildOrder();
/*      */       }
/*  762 */       IFileStore originalStore = getStore();
/*  763 */       boolean wasLinked = isLinked();
/*  764 */       message = Messages.resources_deleteProblem;
/*  765 */       MultiStatus status = new MultiStatus("org.eclipse.core.resources", 273, message, null);
/*  766 */       WorkManager workManager = this.workspace.getWorkManager();
/*  767 */       ResourceTree tree = new ResourceTree(this.workspace.getFileSystemManager(), workManager.getLock(), status, updateFlags);
/*  768 */       int depth = 0;
/*      */       try {
/*  770 */         depth = workManager.beginUnprotected();
/*  771 */         unprotectedDelete(tree, updateFlags, (IProgressMonitor)progress.split(50));
/*      */       } finally {
/*  773 */         workManager.endUnprotected(depth);
/*      */       } 
/*  775 */       if (getType() == 8) {
/*      */         
/*  777 */         this.workspace.getMarkerManager().removeMarkers(this, 0);
/*  778 */         getPropertyManager().deleteProperties(this, 0);
/*  779 */         getResourceInfo(false, false).clearSessionProperties();
/*      */       } 
/*      */       
/*  782 */       tree.makeInvalid();
/*  783 */       if (!tree.getStatus().isOK()) {
/*  784 */         throw new ResourceException(tree.getStatus());
/*      */       }
/*      */       
/*  787 */       if (!wasLinked)
/*  788 */         this.workspace.getAliasManager().updateAliases(this, originalStore, 2, (IProgressMonitor)progress.split(48)); 
/*  789 */       if (getType() == 4) {
/*      */         
/*  791 */         ((Rules)this.workspace.getRuleFactory()).setRuleFactory((IProject)this, null);
/*      */         
/*  793 */         this.workspace.getSaveManager().requestSnapshot();
/*      */       } 
/*  795 */     } catch (OperationCanceledException e) {
/*  796 */       this.workspace.getWorkManager().operationCanceled();
/*  797 */       throw e;
/*      */     } finally {
/*  799 */       progress.done();
/*  800 */       this.workspace.endOperation(rule, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void deleteMarkers(String type, boolean includeSubtypes, int depth) throws CoreException {
/*  806 */     ISchedulingRule rule = this.workspace.getRuleFactory().markerRule(this);
/*      */     try {
/*  808 */       this.workspace.prepareOperation(rule, null);
/*  809 */       ResourceInfo info = getResourceInfo(false, false);
/*  810 */       checkAccessible(getFlags(info));
/*      */       
/*  812 */       this.workspace.beginOperation(true);
/*  813 */       this.workspace.getMarkerManager().removeMarkers(this, type, includeSubtypes, depth);
/*      */     } finally {
/*  815 */       this.workspace.endOperation(rule, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deleteResource(boolean convertToPhantom, MultiStatus status) throws CoreException {
/*  826 */     if (exists()) {
/*  827 */       getMarkerManager().removeMarkers(this, 2);
/*      */     }
/*      */     
/*  830 */     List<Resource> links = findLinks();
/*      */     
/*  832 */     if (links != null) {
/*  833 */       for (Resource resource : links) {
/*  834 */         this.workspace.broadcastEvent(LifecycleEvent.newEvent(1024, resource));
/*      */       }
/*      */     }
/*  837 */     ProjectPreferences.deleted(this);
/*      */ 
/*      */     
/*  840 */     if (getType() != 4 && links != null) {
/*  841 */       Project project = (Project)getProject();
/*  842 */       ProjectDescription description = project.internalGetDescription();
/*  843 */       if (description != null) {
/*  844 */         boolean wasChanged = false;
/*  845 */         for (Resource resource : links)
/*  846 */           wasChanged |= description.setLinkLocation(resource.getProjectRelativePath(), null); 
/*  847 */         if (wasChanged) {
/*  848 */           project.internalSetDescription(description, true);
/*      */           try {
/*  850 */             project.writeDescription(1);
/*  851 */           } catch (CoreException e) {
/*      */             
/*  853 */             project.updateDescription();
/*  854 */             throw e;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  862 */     if (convertToPhantom && getType() != 4 && synchronizing(getResourceInfo(true, false))) {
/*  863 */       convertToPhantom();
/*      */     } else {
/*  865 */       this.workspace.deleteResource(this);
/*      */     } 
/*      */     
/*  868 */     List<Resource> filters = findFilters();
/*  869 */     if (filters != null && filters.size() > 0) {
/*      */       
/*  871 */       Project project = (Project)getProject();
/*  872 */       ProjectDescription description = project.internalGetDescription();
/*  873 */       if (description != null) {
/*  874 */         for (Resource resource : filters)
/*  875 */           description.setFilters(resource.getProjectRelativePath(), null); 
/*  876 */         project.internalSetDescription(description, true);
/*  877 */         project.writeDescription(1);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  882 */     CoreException err = null;
/*      */     try {
/*  884 */       getPropertyManager().deleteResource(this);
/*  885 */     } catch (CoreException e) {
/*  886 */       if (status != null) {
/*  887 */         status.add(e.getStatus());
/*      */       } else {
/*  889 */         err = e;
/*      */       } 
/*      */     } 
/*  892 */     if (err != null) {
/*  893 */       throw err;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private List<Resource> findLinks() {
/*  900 */     Project project = (Project)getProject();
/*  901 */     ProjectDescription description = project.internalGetDescription();
/*  902 */     HashMap<IPath, LinkDescription> linkMap = description.getLinks();
/*  903 */     if (linkMap == null)
/*  904 */       return null; 
/*  905 */     List<Resource> links = null;
/*  906 */     IPath myPath = getProjectRelativePath();
/*  907 */     for (LinkDescription link : linkMap.values()) {
/*  908 */       IPath linkPath = link.getProjectRelativePath();
/*  909 */       if (myPath.isPrefixOf(linkPath)) {
/*  910 */         if (links == null)
/*  911 */           links = new ArrayList<>(); 
/*  912 */         links.add(this.workspace.newResource(project.getFullPath().append(linkPath), link.getType()));
/*      */       } 
/*      */     } 
/*  915 */     return links;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<Resource> findFilters() {
/*  922 */     Project project = (Project)getProject();
/*  923 */     ProjectDescription description = project.internalGetDescription();
/*  924 */     List<Resource> filters = null;
/*  925 */     if (description != null) {
/*  926 */       HashMap<IPath, LinkedList<FilterDescription>> filterMap = description.getFilters();
/*  927 */       if (filterMap != null) {
/*  928 */         IPath myPath = getProjectRelativePath();
/*  929 */         for (IPath filterPath : filterMap.keySet()) {
/*  930 */           if (myPath.isPrefixOf(filterPath)) {
/*  931 */             if (filters == null)
/*  932 */               filters = new ArrayList<>(); 
/*  933 */             filters.add(this.workspace.newResource(project.getFullPath().append(filterPath), 2));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  938 */     return filters;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equals(Object target) {
/*  943 */     if (this == target)
/*  944 */       return true; 
/*  945 */     if (!(target instanceof Resource))
/*  946 */       return false; 
/*  947 */     Resource resource = (Resource)target;
/*  948 */     return (getType() == resource.getType() && this.path.equals(resource.path) && this.workspace.equals(resource.workspace));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean exists() {
/*  953 */     ResourceInfo info = getResourceInfo(false, false);
/*  954 */     return exists(getFlags(info), true);
/*      */   }
/*      */   
/*      */   public boolean exists(int flags, boolean checkType) {
/*  958 */     return (flags != -1 && (!checkType || ResourceInfo.getType(flags) == getType()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IResource findExistingResourceVariant(IPath target) {
/*      */     IPath iPath;
/*  967 */     if (!this.workspace.tree.includesIgnoreCase(target)) {
/*  968 */       return null;
/*      */     }
/*  970 */     ResourceInfo info = (ResourceInfo)this.workspace.tree.getElementDataIgnoreCase(target);
/*  971 */     if (info != null && info.isSet(8)) {
/*  972 */       return null;
/*      */     }
/*  974 */     Path path = Path.ROOT;
/*  975 */     int segmentCount = target.segmentCount();
/*  976 */     for (int i = 0; i < segmentCount; i++) {
/*  977 */       String[] childNames = this.workspace.tree.getNamesOfChildren((IPath)path);
/*  978 */       String name = findVariant(target.segment(i), childNames);
/*  979 */       if (name == null)
/*  980 */         return null; 
/*  981 */       iPath = path.append(name);
/*      */     } 
/*  983 */     return this.workspace.getRoot().findMember(iPath);
/*      */   }
/*      */ 
/*      */   
/*      */   public IMarker findMarker(long id) {
/*  988 */     return this.workspace.getMarkerManager().findMarker(this, id);
/*      */   }
/*      */ 
/*      */   
/*      */   public IMarker[] findMarkers(String type, boolean includeSubtypes, int depth) throws CoreException {
/*  993 */     ResourceInfo info = getResourceInfo(false, false);
/*  994 */     checkAccessible(getFlags(info));
/*      */ 
/*      */     
/*  997 */     return this.workspace.getMarkerManager().findMarkers(this, type, includeSubtypes, depth);
/*      */   }
/*      */ 
/*      */   
/*      */   public int findMaxProblemSeverity(String type, boolean includeSubtypes, int depth) throws CoreException {
/* 1002 */     ResourceInfo info = getResourceInfo(false, false);
/* 1003 */     checkAccessible(getFlags(info));
/*      */ 
/*      */     
/* 1006 */     return this.workspace.getMarkerManager().findMaxProblemSeverity(this, type, includeSubtypes, depth);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private String findVariant(String target, String[] list) {
/*      */     byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/* 1015 */     for (i = (arrayOfString = list).length, b = 0; b < i; ) { String element = arrayOfString[b];
/* 1016 */       if (target.equalsIgnoreCase(element))
/* 1017 */         return element;  b++; }
/*      */     
/* 1019 */     return null;
/*      */   }
/*      */   
/*      */   protected void fixupAfterMoveSource() throws CoreException {
/* 1023 */     ResourceInfo info = getResourceInfo(true, true);
/*      */     
/* 1025 */     if (isLinked() || isVirtual()) {
/* 1026 */       Project project = (Project)getProject();
/* 1027 */       if (project.internalGetDescription().setLinkLocation(getProjectRelativePath(), null)) {
/* 1028 */         project.writeDescription(0);
/*      */       }
/*      */     } 
/* 1031 */     List<Resource> filters = findFilters();
/* 1032 */     if (filters != null && filters.size() > 0) {
/*      */       
/* 1034 */       Project project = (Project)getProject();
/* 1035 */       ProjectDescription description = project.internalGetDescription();
/* 1036 */       for (Resource resource : filters)
/* 1037 */         description.setFilters(resource.getProjectRelativePath(), null); 
/* 1038 */       project.writeDescription(0);
/*      */     } 
/*      */ 
/*      */     
/* 1042 */     ProjectPreferences.deleted(this);
/*      */     
/* 1044 */     if (!synchronizing(info)) {
/* 1045 */       this.workspace.deleteResource(this);
/*      */       return;
/*      */     } 
/* 1048 */     info.clearSessionProperties();
/* 1049 */     info.clear(2);
/* 1050 */     info.setLocalSyncInfo(-1L);
/* 1051 */     info.set(8);
/* 1052 */     info.clearModificationStamp();
/* 1053 */     info.setMarkers(null);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getFileExtension() {
/* 1058 */     String name = getName();
/* 1059 */     int index = name.lastIndexOf('.');
/* 1060 */     if (index == -1)
/* 1061 */       return null; 
/* 1062 */     if (index == name.length() - 1)
/* 1063 */       return ""; 
/* 1064 */     return name.substring(index + 1);
/*      */   }
/*      */   
/*      */   public int getFlags(ResourceInfo info) {
/* 1068 */     return (info == null) ? -1 : info.getFlags();
/*      */   }
/*      */ 
/*      */   
/*      */   public IPath getFullPath() {
/* 1073 */     return this.path;
/*      */   }
/*      */   
/*      */   public FileSystemResourceManager getLocalManager() {
/* 1077 */     return this.workspace.getFileSystemManager();
/*      */   }
/*      */ 
/*      */   
/*      */   public long getLocalTimeStamp() {
/* 1082 */     ResourceInfo info = getResourceInfo(false, false);
/* 1083 */     return (info == null || isVirtual()) ? -1L : info.getLocalSyncInfo();
/*      */   }
/*      */ 
/*      */   
/*      */   public IPath getLocation() {
/* 1088 */     IProject project = getProject();
/* 1089 */     if (project != null && !project.exists())
/* 1090 */       return null; 
/* 1091 */     return getLocalManager().locationFor(this, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public URI getLocationURI() {
/* 1096 */     IProject project = getProject();
/* 1097 */     if (project != null && !project.exists())
/* 1098 */       return null; 
/* 1099 */     return getLocalManager().locationURIFor(this, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public IMarker getMarker(long id) {
/* 1104 */     return new Marker(this, id);
/*      */   }
/*      */   
/*      */   protected MarkerManager getMarkerManager() {
/* 1108 */     return this.workspace.getMarkerManager();
/*      */   }
/*      */ 
/*      */   
/*      */   public long getModificationStamp() {
/* 1113 */     ResourceInfo info = getResourceInfo(false, false);
/* 1114 */     return (info == null) ? -1L : info.getModificationStamp();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getName() {
/* 1119 */     return this.path.lastSegment();
/*      */   }
/*      */ 
/*      */   
/*      */   public IContainer getParent() {
/* 1124 */     int segments = this.path.segmentCount();
/*      */     
/* 1126 */     if (segments < 2)
/* 1127 */       Assert.isLegal(false, this.path.toString()); 
/* 1128 */     if (segments == 2)
/* 1129 */       return (IContainer)this.workspace.getRoot().getProject(this.path.segment(0)); 
/* 1130 */     return (IContainer)this.workspace.newResource(this.path.removeLastSegments(1), 2);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getPersistentProperty(QualifiedName key) throws CoreException {
/* 1135 */     checkAccessibleAndLocal(0);
/* 1136 */     return getPropertyManager().getProperty(this, key);
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<QualifiedName, String> getPersistentProperties() throws CoreException {
/* 1141 */     checkAccessibleAndLocal(0);
/* 1142 */     return getPropertyManager().getProperties(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public IProject getProject() {
/* 1147 */     return this.workspace.getRoot().getProject(this.path.segment(0));
/*      */   }
/*      */ 
/*      */   
/*      */   public IPath getProjectRelativePath() {
/* 1152 */     return getFullPath().removeFirstSegments(1);
/*      */   }
/*      */   
/*      */   public IPropertyManager getPropertyManager() {
/* 1156 */     return this.workspace.getPropertyManager();
/*      */   }
/*      */ 
/*      */   
/*      */   public IPath getRawLocation() {
/* 1161 */     if (isLinked())
/* 1162 */       return FileUtil.toPath(((Project)getProject()).internalGetDescription().getLinkLocationURI(getProjectRelativePath())); 
/* 1163 */     return getLocation();
/*      */   }
/*      */ 
/*      */   
/*      */   public URI getRawLocationURI() {
/* 1168 */     if (isLinked())
/* 1169 */       return ((Project)getProject()).internalGetDescription().getLinkLocationURI(getProjectRelativePath()); 
/* 1170 */     return getLocationURI();
/*      */   }
/*      */ 
/*      */   
/*      */   public ResourceAttributes getResourceAttributes() {
/* 1175 */     if (!isAccessible() || isVirtual())
/* 1176 */       return null; 
/* 1177 */     return getLocalManager().attributes(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceInfo getResourceInfo(boolean phantom, boolean mutable) {
/* 1186 */     return this.workspace.getResourceInfo(getFullPath(), phantom, mutable);
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getSessionProperty(QualifiedName key) throws CoreException {
/* 1191 */     ResourceInfo info = checkAccessibleAndLocal(0);
/* 1192 */     return info.getSessionProperty(key);
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<QualifiedName, Object> getSessionProperties() throws CoreException {
/* 1197 */     ResourceInfo info = checkAccessibleAndLocal(0);
/* 1198 */     return info.getSessionProperties();
/*      */   }
/*      */   
/*      */   public IFileStore getStore() {
/* 1202 */     return getLocalManager().getStore(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTypeString() {
/* 1209 */     switch (getType()) {
/*      */       case 1:
/* 1211 */         return "L";
/*      */       case 2:
/* 1213 */         return "F";
/*      */       case 4:
/* 1215 */         return "P";
/*      */       case 8:
/* 1217 */         return "R";
/*      */     } 
/* 1219 */     return "";
/*      */   }
/*      */ 
/*      */   
/*      */   public IWorkspace getWorkspace() {
/* 1224 */     return this.workspace;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1231 */     return getFullPath().hashCode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void internalSetLocal(boolean flag, int depth) throws CoreException {
/* 1239 */     ResourceInfo info = getResourceInfo(true, true);
/*      */     
/* 1241 */     if (info.isSet(2) != flag) {
/* 1242 */       if (flag && !isPhantom(getFlags(info))) {
/* 1243 */         info.set(2);
/* 1244 */         this.workspace.updateModificationStamp(info);
/*      */       } else {
/* 1246 */         info.clear(2);
/* 1247 */         info.clearModificationStamp();
/*      */       } 
/*      */     }
/* 1250 */     if (getType() == 1 || depth == 0)
/*      */       return; 
/* 1252 */     if (depth == 1)
/* 1253 */       depth = 0; 
/* 1254 */     IResource[] children = ((IContainer)this).members(); byte b; int i; IResource[] arrayOfIResource1;
/* 1255 */     for (i = (arrayOfIResource1 = children).length, b = 0; b < i; ) { IResource element = arrayOfIResource1[b];
/* 1256 */       ((Resource)element).internalSetLocal(flag, depth);
/*      */       b++; }
/*      */   
/*      */   }
/*      */   public boolean isAccessible() {
/* 1261 */     return exists();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isConflicting(ISchedulingRule rule) {
/* 1266 */     if (this == rule) {
/* 1267 */       return true;
/*      */     }
/* 1269 */     if (rule.getClass().equals(WorkManager.NotifyRule.class))
/* 1270 */       return true; 
/* 1271 */     if (rule instanceof MultiRule) {
/* 1272 */       MultiRule multi = (MultiRule)rule;
/* 1273 */       ISchedulingRule[] children = multi.getChildren(); byte b; int i; ISchedulingRule[] arrayOfISchedulingRule1;
/* 1274 */       for (i = (arrayOfISchedulingRule1 = children).length, b = 0; b < i; ) { ISchedulingRule element = arrayOfISchedulingRule1[b];
/* 1275 */         if (isConflicting(element))
/* 1276 */           return true;  b++; }
/* 1277 */        return false;
/*      */     } 
/* 1279 */     if (!(rule instanceof IResource))
/* 1280 */       return false; 
/* 1281 */     IResource resource = (IResource)rule;
/* 1282 */     if (!this.workspace.equals(resource.getWorkspace()))
/* 1283 */       return false; 
/* 1284 */     IPath otherPath = resource.getFullPath();
/* 1285 */     return !(!this.path.isPrefixOf(otherPath) && !otherPath.isPrefixOf(this.path));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDerived() {
/* 1290 */     return isDerived(0);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isDerived(int options) {
/* 1295 */     ResourceInfo info = getResourceInfo(false, false);
/* 1296 */     int flags = getFlags(info);
/* 1297 */     if (flags != -1 && ResourceInfo.isSet(flags, 16384)) {
/* 1298 */       return true;
/*      */     }
/* 1300 */     if ((options & 0x200) != 0)
/* 1301 */       return getParent().isDerived(options); 
/* 1302 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isHidden() {
/* 1307 */     ResourceInfo info = getResourceInfo(false, false);
/* 1308 */     int flags = getFlags(info);
/* 1309 */     return (flags != -1 && ResourceInfo.isSet(flags, 2097152));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isHidden(int options) {
/* 1314 */     ResourceInfo info = getResourceInfo(false, false);
/* 1315 */     int flags = getFlags(info);
/* 1316 */     if (flags != -1 && ResourceInfo.isSet(flags, 2097152)) {
/* 1317 */       return true;
/*      */     }
/* 1319 */     if ((options & 0x200) != 0)
/* 1320 */       return getParent().isHidden(options); 
/* 1321 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isLinked() {
/* 1326 */     return isLinked(0);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isLinked(int options) {
/* 1331 */     if ((options & 0x200) != 0) {
/* 1332 */       IProject project = getProject();
/* 1333 */       if (project == null)
/* 1334 */         return false; 
/* 1335 */       ProjectDescription desc = ((Project)project).internalGetDescription();
/* 1336 */       if (desc == null)
/* 1337 */         return false; 
/* 1338 */       HashMap<IPath, LinkDescription> links = desc.getLinks();
/* 1339 */       if (links == null)
/* 1340 */         return false; 
/* 1341 */       IPath myPath = getProjectRelativePath();
/* 1342 */       for (LinkDescription linkDescription : links.values()) {
/* 1343 */         if (linkDescription.getProjectRelativePath().isPrefixOf(myPath))
/* 1344 */           return true; 
/*      */       } 
/* 1346 */       return false;
/*      */     } 
/*      */     
/* 1349 */     ResourceInfo info = getResourceInfo(false, false);
/* 1350 */     return (info != null && info.isSet(65536));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isVirtual() {
/* 1355 */     ResourceInfo info = getResourceInfo(false, false);
/* 1356 */     return (info != null && info.isSet(524288));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUnderVirtual() {
/* 1363 */     IContainer parent = getParent();
/* 1364 */     while (parent != null) {
/* 1365 */       if (parent.isVirtual())
/* 1366 */         return true; 
/* 1367 */       parent = parent.getParent();
/*      */     } 
/* 1369 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean isLocal(int depth) {
/* 1375 */     ResourceInfo info = getResourceInfo(false, false);
/* 1376 */     return isLocal(getFlags(info), depth);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean isLocal(int flags, int depth) {
/* 1386 */     return (flags != -1 && ResourceInfo.isSet(flags, 2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isMember(int flags, int memberFlags) {
/* 1398 */     int excludeMask = 0;
/* 1399 */     if ((memberFlags & 0x1) == 0)
/* 1400 */       excludeMask |= 0x8; 
/* 1401 */     if ((memberFlags & 0x8) == 0)
/* 1402 */       excludeMask |= 0x200000; 
/* 1403 */     if ((memberFlags & 0x2) == 0)
/* 1404 */       excludeMask |= 0x8000; 
/* 1405 */     if ((memberFlags & 0x4) != 0) {
/* 1406 */       excludeMask |= 0x4000;
/*      */     }
/* 1408 */     return (flags != -1 && (flags & excludeMask) == 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isPhantom() {
/* 1413 */     ResourceInfo info = getResourceInfo(true, false);
/* 1414 */     return isPhantom(getFlags(info));
/*      */   }
/*      */   
/*      */   public boolean isPhantom(int flags) {
/* 1418 */     return (flags != -1 && ResourceInfo.isSet(flags, 8));
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean isReadOnly() {
/* 1424 */     ResourceAttributes attributes = getResourceAttributes();
/* 1425 */     return (attributes != null && attributes.isReadOnly());
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isSynchronized(int depth) {
/* 1430 */     return getLocalManager().isSynchronized(this, depth);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTeamPrivateMember() {
/* 1435 */     ResourceInfo info = getResourceInfo(false, false);
/* 1436 */     int flags = getFlags(info);
/* 1437 */     return (flags != -1 && ResourceInfo.isSet(flags, 32768));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTeamPrivateMember(int options) {
/* 1442 */     ResourceInfo info = getResourceInfo(false, false);
/* 1443 */     int flags = getFlags(info);
/* 1444 */     if (flags != -1 && ResourceInfo.isSet(flags, 32768)) {
/* 1445 */       return true;
/*      */     }
/* 1447 */     if ((options & 0x200) != 0)
/* 1448 */       return getParent().isTeamPrivateMember(options); 
/* 1449 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUnderLink() {
/* 1457 */     int depth = this.path.segmentCount();
/* 1458 */     if (depth < 2)
/* 1459 */       return false; 
/* 1460 */     if (depth == 2) {
/* 1461 */       return isLinked();
/*      */     }
/* 1463 */     IPath linkParent = this.path.removeLastSegments(depth - 2);
/* 1464 */     return this.workspace.getResourceInfo(linkParent, false, false).isSet(65536);
/*      */   }
/*      */   
/*      */   protected IPath makePathAbsolute(IPath target) {
/* 1468 */     if (target.isAbsolute())
/* 1469 */       return target; 
/* 1470 */     return getParent().getFullPath().append(target);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void move(IPath destination, boolean force, boolean keepHistory, IProgressMonitor monitor) throws CoreException {
/* 1478 */     int updateFlags = force ? 1 : 0;
/* 1479 */     updateFlags |= keepHistory ? 2 : 0;
/* 1480 */     move(destination, updateFlags, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void move(IPath destination, boolean force, IProgressMonitor monitor) throws CoreException {
/* 1485 */     move(destination, force ? 1 : 0, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void move(IPath destination, int updateFlags, IProgressMonitor monitor) throws CoreException {
/* 1490 */     String message = NLS.bind(Messages.resources_moving, getFullPath());
/* 1491 */     SubMonitor progress = SubMonitor.convert(monitor, message, 100).checkCanceled();
/* 1492 */     destination = makePathAbsolute(destination);
/* 1493 */     checkValidPath(destination, getType(), false);
/* 1494 */     Resource destResource = this.workspace.newResource(destination, getType());
/* 1495 */     ISchedulingRule rule = this.workspace.getRuleFactory().moveRule(this, destResource);
/* 1496 */     SubMonitor split = progress.split(1);
/*      */     try {
/* 1498 */       this.workspace.prepareOperation(rule, (IProgressMonitor)split);
/*      */ 
/*      */       
/* 1501 */       assertMoveRequirements(destination, getType(), updateFlags);
/* 1502 */       this.workspace.beginOperation(true);
/* 1503 */       broadcastPreMoveEvent(destResource, updateFlags);
/* 1504 */       IFileStore originalStore = getStore();
/* 1505 */       message = Messages.resources_moveProblem;
/* 1506 */       MultiStatus status = new MultiStatus("org.eclipse.core.resources", 4, message, null);
/* 1507 */       WorkManager workManager = this.workspace.getWorkManager();
/* 1508 */       ResourceTree tree = new ResourceTree(this.workspace.getFileSystemManager(), workManager.getLock(), status, updateFlags);
/* 1509 */       boolean success = false;
/* 1510 */       int depth = 0;
/*      */       try {
/* 1512 */         depth = workManager.beginUnprotected();
/* 1513 */         success = unprotectedMove(tree, destResource, updateFlags, (IProgressMonitor)progress.split(50));
/*      */       } finally {
/* 1515 */         workManager.endUnprotected(depth);
/*      */       } 
/*      */       
/* 1518 */       tree.makeInvalid();
/*      */       
/* 1520 */       if (success) {
/* 1521 */         this.workspace.getAliasManager().updateAliases(this, originalStore, 2, (IProgressMonitor)progress.split(24));
/* 1522 */         this.workspace.getAliasManager().updateAliases(destResource, destResource.getStore(), 2, (IProgressMonitor)progress.split(24));
/*      */       } 
/* 1524 */       if (!tree.getStatus().isOK()) {
/* 1525 */         throw new ResourceException(tree.getStatus());
/*      */       }
/* 1527 */       if (getType() == 4)
/* 1528 */         this.workspace.getSaveManager().requestSnapshot(); 
/* 1529 */     } catch (OperationCanceledException e) {
/* 1530 */       this.workspace.getWorkManager().operationCanceled();
/* 1531 */       throw e;
/*      */     } finally {
/* 1533 */       progress.done();
/* 1534 */       this.workspace.endOperation(rule, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void move(IProjectDescription description, boolean force, boolean keepHistory, IProgressMonitor monitor) throws CoreException {
/* 1540 */     int updateFlags = force ? 1 : 0;
/* 1541 */     updateFlags |= keepHistory ? 2 : 0;
/* 1542 */     move(description, updateFlags, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void move(IProjectDescription description, int updateFlags, IProgressMonitor monitor) throws CoreException {
/* 1547 */     Assert.isNotNull(description);
/* 1548 */     if (getType() != 4) {
/* 1549 */       String message = NLS.bind(Messages.resources_moveNotProject, getFullPath(), description.getName());
/* 1550 */       throw new ResourceException(77, getFullPath(), message, null);
/*      */     } 
/* 1552 */     ((Project)this).move(description, updateFlags, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void refreshLocal(int depth, IProgressMonitor monitor) throws CoreException {
/* 1557 */     boolean isRoot = (getType() == 8);
/* 1558 */     String message = isRoot ? Messages.resources_refreshingRoot : NLS.bind(Messages.resources_refreshing, getFullPath());
/* 1559 */     SubMonitor progress = SubMonitor.convert(monitor, 100).checkCanceled();
/* 1560 */     progress.subTask(message);
/* 1561 */     boolean build = false;
/* 1562 */     ISchedulingRule rule = this.workspace.getRuleFactory().refreshRule(this);
/* 1563 */     SubMonitor split = progress.split(1);
/*      */     try {
/* 1565 */       this.workspace.prepareOperation(rule, (IProgressMonitor)split);
/* 1566 */       if (!isRoot && !getProject().isAccessible())
/*      */         return; 
/* 1568 */       if (!exists() && isFiltered())
/*      */         return; 
/* 1570 */       this.workspace.beginOperation(true);
/* 1571 */       if (getType() == 4 || getType() == 8)
/* 1572 */         this.workspace.broadcastEvent(LifecycleEvent.newEvent(4096, this)); 
/* 1573 */       build = getLocalManager().refresh(this, depth, true, (IProgressMonitor)progress.split(98));
/* 1574 */     } catch (OperationCanceledException e) {
/* 1575 */       this.workspace.getWorkManager().operationCanceled();
/* 1576 */       throw e;
/*      */     } finally {
/* 1578 */       progress.done();
/* 1579 */       this.workspace.endOperation(rule, build);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String requestName() {
/* 1585 */     return getName();
/*      */   }
/*      */ 
/*      */   
/*      */   public IPath requestPath() {
/* 1590 */     return getFullPath();
/*      */   }
/*      */ 
/*      */   
/*      */   public void revertModificationStamp(long value) throws CoreException {
/* 1595 */     if (value < 0L) {
/* 1596 */       throw new IllegalArgumentException("Illegal value: " + value);
/*      */     }
/*      */     
/* 1599 */     ResourceInfo info = checkAccessibleAndLocal(0);
/* 1600 */     info.setModificationStamp(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setDerived(boolean isDerived) throws CoreException {
/* 1609 */     ResourceInfo info = getResourceInfo(false, false);
/* 1610 */     int flags = getFlags(info);
/* 1611 */     checkAccessible(flags);
/*      */     
/* 1613 */     if (info.getType() == 1 || info.getType() == 2) {
/* 1614 */       if (isDerived) {
/* 1615 */         info.set(16384);
/*      */       } else {
/* 1617 */         info.clear(16384);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDerived(boolean isDerived, IProgressMonitor monitor) throws CoreException {
/* 1624 */     String message = NLS.bind(Messages.resources_settingDerivedFlag, getFullPath());
/* 1625 */     SubMonitor progress = SubMonitor.convert(monitor, message, 100).checkCanceled();
/* 1626 */     ISchedulingRule rule = this.workspace.getRuleFactory().derivedRule(this);
/* 1627 */     SubMonitor split = progress.split(1);
/*      */     try {
/* 1629 */       this.workspace.prepareOperation(rule, (IProgressMonitor)split);
/* 1630 */       ResourceInfo info = getResourceInfo(false, false);
/* 1631 */       checkAccessible(getFlags(info));
/*      */       
/* 1633 */       if (info.getType() != 1 && info.getType() != 2)
/*      */         return; 
/* 1635 */       this.workspace.beginOperation(true);
/* 1636 */       info = getResourceInfo(false, true);
/* 1637 */       if (isDerived) {
/* 1638 */         info.set(16384);
/*      */       } else {
/* 1640 */         info.clear(16384);
/*      */       } 
/* 1642 */       progress.split(98);
/* 1643 */     } catch (OperationCanceledException e) {
/* 1644 */       this.workspace.getWorkManager().operationCanceled();
/* 1645 */       throw e;
/*      */     } finally {
/* 1647 */       progress.done();
/* 1648 */       this.workspace.endOperation(rule, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHidden(boolean isHidden) throws CoreException {
/* 1657 */     ResourceInfo info = getResourceInfo(false, false);
/* 1658 */     int flags = getFlags(info);
/* 1659 */     checkAccessible(flags);
/* 1660 */     if (isHidden) {
/* 1661 */       info.set(2097152);
/*      */     } else {
/* 1663 */       info.clear(2097152);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setLocal(boolean flag, int depth, IProgressMonitor monitor) throws CoreException {
/* 1670 */     String message = Messages.resources_setLocal;
/* 1671 */     SubMonitor progress = SubMonitor.convert(monitor, message, 100).checkCanceled();
/* 1672 */     SubMonitor split = progress.split(1);
/*      */     try {
/* 1674 */       this.workspace.prepareOperation(null, (IProgressMonitor)split);
/* 1675 */       this.workspace.beginOperation(true);
/* 1676 */       internalSetLocal(flag, depth);
/* 1677 */       progress.split(98);
/*      */     } finally {
/* 1679 */       progress.done();
/* 1680 */       this.workspace.endOperation(null, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public long setLocalTimeStamp(long value) throws CoreException {
/* 1686 */     if (value < 0L) {
/* 1687 */       throw new IllegalArgumentException("Illegal value: " + value);
/*      */     }
/*      */     
/* 1690 */     ResourceInfo info = checkAccessibleAndLocal(0);
/* 1691 */     return getLocalManager().setLocalTimeStamp(this, info, value);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPersistentProperty(QualifiedName key, String value) throws CoreException {
/* 1696 */     checkAccessibleAndLocal(0);
/* 1697 */     getPropertyManager().setProperty(this, key, value);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setReadOnly(boolean readonly) {
/* 1703 */     ResourceAttributes attributes = getResourceAttributes();
/* 1704 */     if (attributes == null)
/*      */       return; 
/* 1706 */     attributes.setReadOnly(readonly);
/*      */     try {
/* 1708 */       setResourceAttributes(attributes);
/* 1709 */     } catch (CoreException coreException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResourceAttributes(ResourceAttributes attributes) throws CoreException {
/* 1716 */     checkAccessibleAndLocal(0);
/* 1717 */     getLocalManager().setResourceAttributes(this, attributes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSessionProperty(QualifiedName key, Object value) throws CoreException {
/* 1725 */     ResourceInfo info = checkAccessibleAndLocal(0);
/* 1726 */     info.setSessionProperty(key, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTeamPrivateMember(boolean isTeamPrivate) throws CoreException {
/* 1734 */     ResourceInfo info = getResourceInfo(false, false);
/* 1735 */     int flags = getFlags(info);
/* 1736 */     checkAccessible(flags);
/*      */     
/* 1738 */     if (info.getType() == 1 || info.getType() == 2) {
/* 1739 */       if (isTeamPrivate) {
/* 1740 */         info.set(32768);
/*      */       } else {
/* 1742 */         info.clear(32768);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean synchronizing(ResourceInfo info) {
/* 1752 */     return (info != null && info.getSyncInfo(false) != null);
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1757 */     return String.valueOf(getTypeString()) + getFullPath().toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public void touch(IProgressMonitor monitor) throws CoreException {
/* 1762 */     String message = NLS.bind(Messages.resources_touch, getFullPath());
/* 1763 */     SubMonitor progress = SubMonitor.convert(monitor, message, 100).checkCanceled();
/* 1764 */     ISchedulingRule rule = this.workspace.getRuleFactory().modifyRule(this);
/* 1765 */     SubMonitor split = progress.split(1);
/*      */     try {
/* 1767 */       this.workspace.prepareOperation(rule, (IProgressMonitor)split);
/* 1768 */       ResourceInfo info = checkAccessibleAndLocal(0);
/*      */       
/* 1770 */       this.workspace.beginOperation(true);
/*      */       
/* 1772 */       info = getResourceInfo(false, true);
/* 1773 */       info.incrementContentId();
/*      */       
/* 1775 */       info.clear(393216);
/* 1776 */       this.workspace.updateModificationStamp(info);
/* 1777 */       progress.split(98);
/* 1778 */     } catch (OperationCanceledException e) {
/* 1779 */       this.workspace.getWorkManager().operationCanceled();
/* 1780 */       throw e;
/*      */     } finally {
/* 1782 */       progress.done();
/* 1783 */       this.workspace.endOperation(rule, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void unprotectedDelete(ResourceTree tree, int updateFlags, IProgressMonitor monitor) {
/* 1792 */     IMoveDeleteHook hook = this.workspace.getMoveDeleteHook();
/* 1793 */     SubMonitor progress = SubMonitor.convert(monitor, 2).checkCanceled(); try {
/*      */       IProject[] projects; byte b; int i; IProject[] arrayOfIProject1;
/* 1795 */       switch (getType()) {
/*      */         case 1:
/* 1797 */           if (!hook.deleteFile(tree, (IFile)this, updateFlags, (IProgressMonitor)progress.split(1)))
/* 1798 */             tree.standardDeleteFile((IFile)this, updateFlags, (IProgressMonitor)progress.split(1)); 
/*      */           break;
/*      */         case 2:
/* 1801 */           if (!hook.deleteFolder(tree, (IFolder)this, updateFlags, (IProgressMonitor)progress.split(1)))
/* 1802 */             tree.standardDeleteFolder((IFolder)this, updateFlags, (IProgressMonitor)progress.split(1)); 
/*      */           break;
/*      */         case 4:
/* 1805 */           if (!hook.deleteProject(tree, (IProject)this, updateFlags, (IProgressMonitor)progress.split(1))) {
/* 1806 */             tree.standardDeleteProject((IProject)this, updateFlags, (IProgressMonitor)progress.split(1));
/*      */           }
/*      */           break;
/*      */         
/*      */         case 8:
/* 1811 */           projects = ((IWorkspaceRoot)this).getProjects(8);
/* 1812 */           progress.setWorkRemaining(projects.length * 2);
/* 1813 */           for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/* 1814 */             if (!hook.deleteProject(tree, project, updateFlags, (IProgressMonitor)progress.split(1)))
/* 1815 */               tree.standardDeleteProject(project, updateFlags, (IProgressMonitor)progress.split(1));  b++; }
/*      */           
/*      */           break;
/*      */       } 
/*      */     } finally {
/* 1820 */       progress.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean unprotectedMove(ResourceTree tree, IResource destination, int updateFlags, IProgressMonitor monitor) throws CoreException, ResourceException
/*      */   {
/* 1830 */     IMoveDeleteHook hook = this.workspace.getMoveDeleteHook();
/* 1831 */     SubMonitor progress = SubMonitor.convert(monitor, 2).checkCanceled(); try {
/*      */       IProject project; IProjectDescription description; String msg;
/* 1833 */       switch (getType()) {
/*      */         case 1:
/* 1835 */           if (!hook.moveFile(tree, (IFile)this, (IFile)destination, updateFlags, (IProgressMonitor)progress.split(1)))
/* 1836 */             tree.standardMoveFile((IFile)this, (IFile)destination, updateFlags, (IProgressMonitor)progress.split(1)); 
/*      */           break;
/*      */         case 2:
/* 1839 */           if (!hook.moveFolder(tree, (IFolder)this, (IFolder)destination, updateFlags, (IProgressMonitor)progress.split(1)))
/* 1840 */             tree.standardMoveFolder((IFolder)this, (IFolder)destination, updateFlags, (IProgressMonitor)progress.split(1)); 
/*      */           break;
/*      */         case 4:
/* 1843 */           project = (IProject)this;
/*      */           
/* 1845 */           if (getName().equals(destination.getName()))
/* 1846 */             return false; 
/* 1847 */           description = project.getDescription();
/* 1848 */           description.setName(destination.getName());
/* 1849 */           if (!hook.moveProject(tree, project, description, updateFlags, (IProgressMonitor)progress.split(1)))
/* 1850 */             tree.standardMoveProject(project, description, updateFlags, (IProgressMonitor)progress.split(1)); 
/*      */           break;
/*      */         case 8:
/* 1853 */           msg = Messages.resources_moveRoot;
/* 1854 */           throw new ResourceException(new ResourceStatus(77, getFullPath(), msg));
/*      */       } 
/*      */     } finally {
/* 1857 */       progress.done();
/*      */     } 
/* 1859 */     return true; } private void broadcastPreDeleteEvent() throws CoreException { IResource[] projects;
/*      */     byte b;
/*      */     int i;
/*      */     IResource[] arrayOfIResource1;
/* 1863 */     switch (getType()) {
/*      */       case 4:
/* 1865 */         this.workspace.broadcastEvent(LifecycleEvent.newEvent(16, this));
/*      */         break;
/*      */       
/*      */       case 8:
/* 1869 */         projects = ((Container)this).getChildren(8);
/* 1870 */         for (i = (arrayOfIResource1 = projects).length, b = 0; b < i; ) { IResource project2 = arrayOfIResource1[b];
/* 1871 */           this.workspace.broadcastEvent(LifecycleEvent.newEvent(16, project2));
/*      */           b++; }
/*      */         
/*      */         break;
/*      */     }  }
/*      */   
/*      */   private void broadcastPreMoveEvent(IResource destination, int updateFlags) throws CoreException {
/* 1878 */     switch (getType()) {
/*      */       case 1:
/* 1880 */         if (isLinked())
/* 1881 */           this.workspace.broadcastEvent(LifecycleEvent.newEvent(2048, this, destination, updateFlags)); 
/*      */         break;
/*      */       case 2:
/* 1884 */         if (isLinked())
/* 1885 */           this.workspace.broadcastEvent(LifecycleEvent.newEvent(2048, this, destination, updateFlags)); 
/* 1886 */         if (isVirtual())
/* 1887 */           this.workspace.broadcastEvent(LifecycleEvent.newEvent(65536, this, destination, updateFlags)); 
/*      */         break;
/*      */       case 4:
/* 1890 */         if (!getName().equals(destination.getName()))
/*      */         {
/* 1892 */           this.workspace.broadcastEvent(LifecycleEvent.newEvent(64, this, destination, updateFlags));
/*      */         }
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public IPathVariableManager getPathVariableManager() {
/* 1900 */     if (getProject() == null)
/* 1901 */       return this.workspace.getPathVariableManager(); 
/* 1902 */     return new ProjectPathVariableManager(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFiltered() {
/*      */     try {
/* 1917 */       return isFilteredWithException(false);
/* 1918 */     } catch (CoreException coreException) {
/*      */ 
/*      */       
/* 1921 */       return false;
/*      */     } 
/*      */   }
/*      */   public boolean isFilteredWithException(boolean throwExeception) throws CoreException {
/* 1925 */     if (isLinked() || isVirtual()) {
/* 1926 */       return false;
/*      */     }
/* 1928 */     Project project = (Project)getProject();
/* 1929 */     if (project == null)
/* 1930 */       return false; 
/* 1931 */     ProjectDescription description = project.internalGetDescription();
/* 1932 */     if (description == null)
/* 1933 */       return false; 
/* 1934 */     if (description.getFilters() == null) {
/* 1935 */       return false;
/*      */     }
/* 1937 */     Resource currentResource = this;
/* 1938 */     while (currentResource != null && currentResource.getParent() != null) {
/* 1939 */       Resource parent = (Resource)currentResource.getParent();
/* 1940 */       IFileStore store = currentResource.getStore();
/* 1941 */       if (store != null) {
/* 1942 */         FileInfo fileInfo = new FileInfo(store.getName());
/* 1943 */         fileInfo.setDirectory((currentResource.getType() == 2));
/* 1944 */         if (fileInfo != null) {
/* 1945 */           IFileInfo[] filtered = parent.filterChildren(project, description, new IFileInfo[] { (IFileInfo)fileInfo }, throwExeception);
/* 1946 */           if (filtered.length == 0)
/* 1947 */             return true; 
/*      */         } 
/*      */       } 
/* 1950 */       currentResource = parent;
/*      */     } 
/* 1952 */     return false;
/*      */   }
/*      */   
/*      */   public IFileInfo[] filterChildren(IFileInfo[] list, boolean throwException) throws CoreException {
/* 1956 */     Project project = (Project)getProject();
/* 1957 */     if (project == null)
/* 1958 */       return list; 
/* 1959 */     ProjectDescription description = project.internalGetDescription();
/* 1960 */     if (description == null)
/* 1961 */       return list; 
/* 1962 */     return filterChildren(project, description, list, throwException);
/*      */   }
/*      */   
/*      */   private IFileInfo[] filterChildren(Project project, ProjectDescription description, IFileInfo[] list, boolean throwException) throws CoreException {
/* 1966 */     IPath relativePath = getProjectRelativePath();
/* 1967 */     LinkedList<Filter> currentIncludeFilters = new LinkedList<>();
/* 1968 */     LinkedList<Filter> currentExcludeFilters = new LinkedList<>();
/* 1969 */     LinkedList<FilterDescription> filters = null;
/*      */     
/* 1971 */     boolean firstSegment = true;
/*      */     do {
/* 1973 */       if (!firstSegment)
/* 1974 */         relativePath = relativePath.removeLastSegments(1); 
/* 1975 */       filters = description.getFilter(relativePath);
/* 1976 */       if (filters != null) {
/* 1977 */         for (FilterDescription desc : filters) {
/* 1978 */           if (firstSegment || desc.isInheritable()) {
/* 1979 */             Filter filter = new Filter(project, desc);
/* 1980 */             if (filter.isIncludeOnly()) {
/* 1981 */               if (filter.isFirst()) {
/* 1982 */                 currentIncludeFilters.addFirst(filter); continue;
/*      */               } 
/* 1984 */               currentIncludeFilters.addLast(filter); continue;
/*      */             } 
/* 1986 */             if (filter.isFirst()) {
/* 1987 */               currentExcludeFilters.addFirst(filter); continue;
/*      */             } 
/* 1989 */             currentExcludeFilters.addLast(filter);
/*      */           } 
/*      */         } 
/*      */       }
/*      */       
/* 1994 */       firstSegment = false;
/* 1995 */     } while (relativePath.segmentCount() > 0);
/*      */     
/* 1997 */     if (currentIncludeFilters.size() > 0 || currentExcludeFilters.size() > 0)
/*      */       try {
/* 1999 */         list = Filter.filter(project, currentIncludeFilters, currentExcludeFilters, (IContainer)this, list);
/* 2000 */       } catch (CoreException e) {
/* 2001 */         if (throwException) {
/* 2002 */           throw e;
/*      */         }
/*      */       }  
/* 2005 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLinkLocation(URI location, int updateFlags, IProgressMonitor monitor) throws CoreException {
/* 2013 */     if (!isLinked()) {
/* 2014 */       String str = NLS.bind(Messages.links_resourceIsNotALink, getFullPath());
/* 2015 */       throw new ResourceException(77, getFullPath(), str, null);
/*      */     } 
/*      */     
/* 2018 */     String message = NLS.bind(Messages.links_setLocation, getFullPath());
/* 2019 */     SubMonitor progress = SubMonitor.convert(monitor, message, 100).checkCanceled();
/* 2020 */     ISchedulingRule rule = this.workspace.getRuleFactory().createRule(this);
/* 2021 */     SubMonitor split = progress.split(1);
/*      */     try {
/* 2023 */       this.workspace.prepareOperation(rule, (IProgressMonitor)split);
/* 2024 */       this.workspace.broadcastEvent(LifecycleEvent.newEvent(524288, this));
/* 2025 */       this.workspace.beginOperation(true);
/*      */       
/* 2027 */       ResourceInfo info = this.workspace.getResourceInfo(getFullPath(), true, false);
/* 2028 */       getLocalManager().setLocation(this, info, location);
/*      */ 
/*      */       
/* 2031 */       LinkDescription linkDescription = new LinkDescription(this, location);
/* 2032 */       Project project = (Project)getProject();
/* 2033 */       project.internalGetDescription().setLinkLocation(getProjectRelativePath(), linkDescription);
/* 2034 */       project.writeDescription(updateFlags);
/*      */ 
/*      */       
/* 2037 */       if ((updateFlags & 0x80) != 0) {
/* 2038 */         this.workspace.refreshManager.refresh(this);
/* 2039 */         progress.split(99);
/*      */       } else {
/* 2041 */         refreshLocal(2, (IProgressMonitor)progress.split(98));
/*      */       } 
/*      */     } finally {
/* 2044 */       progress.done();
/* 2045 */       this.workspace.endOperation(rule, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLinkLocation(IPath location, int updateFlags, IProgressMonitor monitor) throws CoreException {
/* 2054 */     if (location.isAbsolute()) {
/* 2055 */       setLinkLocation(URIUtil.toURI(location.toPortableString()), updateFlags, monitor);
/*      */     } else {
/*      */       URI uri;
/*      */       try {
/* 2059 */         uri = new URI(null, null, location.toPortableString(), null);
/* 2060 */       } catch (URISyntaxException uRISyntaxException) {
/* 2061 */         uri = URIUtil.toURI(location.toPortableString());
/*      */       } 
/* 2063 */       setLinkLocation(uri, updateFlags, monitor);
/*      */     } 
/*      */   }
/*      */   
/*      */   public abstract int getType();
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\Resource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */