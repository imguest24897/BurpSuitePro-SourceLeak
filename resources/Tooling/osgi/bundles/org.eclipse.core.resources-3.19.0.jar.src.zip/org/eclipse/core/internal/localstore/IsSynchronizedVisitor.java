/*    */ package org.eclipse.core.internal.localstore;
/*    */ 
/*    */ import org.eclipse.core.internal.resources.Resource;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IsSynchronizedVisitor
/*    */   extends CollectSyncStatusVisitor
/*    */ {
/*    */   static class ResourceChangedException
/*    */     extends RuntimeException
/*    */   {
/*    */     private static final long serialVersionUID = 1L;
/*    */     public final IResource target;
/*    */     
/*    */     public ResourceChangedException(IResource target) {
/* 34 */       this.target = target;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IsSynchronizedVisitor(IProgressMonitor monitor) {
/* 42 */     super("", monitor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void changed(Resource target) {
/* 50 */     throw new ResourceChangedException(target);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void fileToFolder(UnifiedTreeNode node, Resource target) {
/* 55 */     changed((Resource)this.workspace.getRoot().getFolder(target.getFullPath()));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void folderToFile(UnifiedTreeNode node, Resource target) {
/* 61 */     changed((Resource)this.workspace.getRoot().getFile(target.getFullPath()));
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\IsSynchronizedVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */