/*     */ package org.eclipse.core.internal.properties;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.localstore.Bucket;
/*     */ import org.eclipse.core.internal.localstore.BucketTree;
/*     */ import org.eclipse.core.internal.resources.Resource;
/*     */ import org.eclipse.core.internal.resources.ResourceException;
/*     */ import org.eclipse.core.internal.resources.ResourceInfo;
/*     */ import org.eclipse.core.internal.resources.Workspace;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyManager2
/*     */   implements IPropertyManager
/*     */ {
/*     */   private static final int MAX_VALUE_SIZE = 2048;
/*     */   BucketTree tree;
/*     */   
/*     */   class PropertyCopyVisitor
/*     */     extends Bucket.Visitor
/*     */   {
/*  38 */     private List<PropertyBucket.PropertyEntry> changes = new ArrayList<>();
/*     */     private IPath destination;
/*     */     private IPath source;
/*     */     
/*     */     public PropertyCopyVisitor(IPath source, IPath destination) {
/*  43 */       this.source = source;
/*  44 */       this.destination = destination;
/*     */     }
/*     */ 
/*     */     
/*     */     public void afterSaving(Bucket bucket) throws CoreException {
/*  49 */       saveChanges((PropertyBucket)bucket);
/*  50 */       this.changes.clear();
/*     */     }
/*     */     
/*     */     private void saveChanges(PropertyBucket bucket) throws CoreException {
/*  54 */       if (this.changes.isEmpty()) {
/*     */         return;
/*     */       }
/*  57 */       Iterator<PropertyBucket.PropertyEntry> i = this.changes.iterator();
/*  58 */       PropertyBucket.PropertyEntry entry = i.next();
/*  59 */       PropertyManager2.this.tree.loadBucketFor(entry.getPath());
/*  60 */       bucket.setProperties(entry);
/*  61 */       while (i.hasNext())
/*  62 */         bucket.setProperties(i.next()); 
/*  63 */       bucket.save();
/*     */     }
/*     */ 
/*     */     
/*     */     public int visit(Bucket.Entry entry) {
/*  68 */       PropertyBucket.PropertyEntry sourceEntry = (PropertyBucket.PropertyEntry)entry;
/*  69 */       IPath destinationPath = this.destination.append(sourceEntry.getPath().removeFirstSegments(this.source.segmentCount()));
/*  70 */       PropertyBucket.PropertyEntry destinationEntry = new PropertyBucket.PropertyEntry(destinationPath, sourceEntry);
/*  71 */       this.changes.add(destinationEntry);
/*  72 */       return 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyManager2(Workspace workspace) {
/*  79 */     this.tree = new BucketTree(workspace, new PropertyBucket());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void closePropertyStore(IResource target) throws CoreException {
/*  85 */     this.tree.getCurrent().save();
/*     */ 
/*     */     
/*  88 */     this.tree.getCurrent().flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void copy(IResource source, IResource destination, int depth) throws CoreException {
/*  93 */     copyProperties(source.getFullPath(), destination.getFullPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void copyProperties(IPath source, IPath destination) throws CoreException {
/* 100 */     Assert.isLegal((source.segmentCount() > 0));
/* 101 */     Assert.isLegal((destination.segmentCount() > 0));
/* 102 */     Assert.isLegal(!(source.segmentCount() <= 1 && destination.segmentCount() != 1));
/*     */ 
/*     */     
/* 105 */     PropertyCopyVisitor copyVisitor = new PropertyCopyVisitor(source, destination);
/* 106 */     this.tree.accept(copyVisitor, source, 2147483647);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void deleteProperties(IResource target, int depth) throws CoreException {
/* 111 */     this.tree.accept(new Bucket.Visitor()
/*     */         {
/*     */           public int visit(Bucket.Entry entry) {
/* 114 */             entry.delete();
/* 115 */             return 0;
/*     */           }
/* 117 */         },  target.getFullPath(), (depth == 2) ? Integer.MAX_VALUE : depth);
/*     */   }
/*     */ 
/*     */   
/*     */   public void deleteResource(IResource target) throws CoreException {
/* 122 */     deleteProperties(target, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized Map<QualifiedName, String> getProperties(IResource target) throws CoreException {
/* 127 */     final Map<QualifiedName, String> result = new HashMap<>();
/* 128 */     this.tree.accept(new Bucket.Visitor()
/*     */         {
/*     */           public int visit(Bucket.Entry entry) {
/* 131 */             PropertyBucket.PropertyEntry propertyEntry = (PropertyBucket.PropertyEntry)entry;
/* 132 */             int propertyCount = propertyEntry.getOccurrences();
/* 133 */             for (int i = 0; i < propertyCount; i++)
/* 134 */               result.put(propertyEntry.getPropertyName(i), propertyEntry.getPropertyValue(i)); 
/* 135 */             return 0;
/*     */           }
/* 137 */         }target.getFullPath(), 0);
/* 138 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized String getProperty(IResource target, QualifiedName name) throws CoreException {
/* 143 */     if (name.getQualifier() == null) {
/* 144 */       String message = Messages.properties_qualifierIsNull;
/* 145 */       throw new ResourceException(567, target.getFullPath(), message, null);
/*     */     } 
/* 147 */     IPath resourcePath = target.getFullPath();
/* 148 */     PropertyBucket current = (PropertyBucket)this.tree.getCurrent();
/* 149 */     this.tree.loadBucketFor(resourcePath);
/* 150 */     return current.getProperty(resourcePath, name);
/*     */   }
/*     */   
/*     */   public BucketTree getTree() {
/* 154 */     return this.tree;
/*     */   }
/*     */   
/*     */   public File getVersionFile() {
/* 158 */     return this.tree.getVersionFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setProperty(IResource target, QualifiedName name, String value) throws CoreException {
/* 165 */     Resource resource = (Resource)target;
/* 166 */     ResourceInfo info = resource.getResourceInfo(false, false);
/* 167 */     int flags = resource.getFlags(info);
/* 168 */     resource.checkAccessible(flags);
/*     */     
/* 170 */     if (value != null && value.length() > 2048) {
/* 171 */       String message = NLS.bind(Messages.properties_valueTooLong, new Object[] { name.getQualifier(), name.getLocalName(), Integer.toString(2048) });
/* 172 */       throw new ResourceException(568, target.getFullPath(), message, null);
/*     */     } 
/* 174 */     if (name.getQualifier() == null) {
/* 175 */       String message = Messages.properties_qualifierIsNull;
/* 176 */       throw new ResourceException(568, target.getFullPath(), message, null);
/*     */     } 
/*     */     
/* 179 */     IPath resourcePath = target.getFullPath();
/* 180 */     this.tree.loadBucketFor(resourcePath);
/* 181 */     PropertyBucket current = (PropertyBucket)this.tree.getCurrent();
/* 182 */     current.setProperty(resourcePath, name, value);
/* 183 */     current.save();
/*     */   }
/*     */ 
/*     */   
/*     */   public void shutdown(IProgressMonitor monitor) throws CoreException {
/* 188 */     this.tree.close();
/*     */   }
/*     */   
/*     */   public void startup(IProgressMonitor monitor) {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\properties\PropertyManager2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */