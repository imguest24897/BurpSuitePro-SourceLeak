/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.utils.IStringPoolParticipant;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.StringPool;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarkerInfo
/*     */   implements IMarkerSetElement, Cloneable, IStringPoolParticipant
/*     */ {
/*     */   private final MarkerAttributeMap attributes;
/*     */   protected final long creationTime;
/*     */   protected final long id;
/*     */   protected volatile String type;
/*     */   
/*     */   protected static Object checkValidAttribute(Object value) {
/*  48 */     if (value == null)
/*  49 */       return null; 
/*  50 */     if (value instanceof String) {
/*     */       
/*  52 */       String valueString = (String)value;
/*     */       
/*  54 */       if (valueString.length() < 21000)
/*  55 */         return value; 
/*  56 */       byte[] bytes = valueString.getBytes(StandardCharsets.UTF_8);
/*  57 */       if (bytes.length > 65535) {
/*  58 */         String msg = "Marker property value is too long: " + valueString.substring(0, 10000);
/*  59 */         Assert.isTrue(false, msg);
/*     */       } 
/*  61 */       return value;
/*     */     } 
/*  63 */     if (value instanceof Boolean)
/*     */     {
/*  65 */       return Boolean.valueOf(((Boolean)value).booleanValue());
/*     */     }
/*  67 */     if (value instanceof Integer)
/*     */     {
/*  69 */       return Integer.valueOf(((Integer)value).intValue());
/*     */     }
/*     */     
/*  72 */     throw new IllegalArgumentException(NLS.bind(Messages.resources_wrongMarkerAttributeValueType, value.getClass().getName()));
/*     */   }
/*     */   
/*     */   public MarkerInfo(String type, long id) {
/*  76 */     this((Map<String, ? extends Object>)null, false, type, id);
/*     */   }
/*     */ 
/*     */   
/*     */   public MarkerInfo(MarkerAttributeMap map, long creationTime, String type, long id) {
/*  81 */     this.attributes = map;
/*  82 */     this.id = id;
/*  83 */     this.creationTime = creationTime;
/*  84 */     this.type = type;
/*     */   }
/*     */ 
/*     */   
/*     */   public MarkerInfo(MarkerInfo markerInfo) {
/*  89 */     this(new MarkerAttributeMap(markerInfo.attributes), markerInfo.creationTime, markerInfo.type, markerInfo.id);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerInfo(Map<String, ? extends Object> attributes, boolean validate, long creationTime, String type, long id) {
/*  95 */     this((attributes == null) ? new MarkerAttributeMap() : new MarkerAttributeMap(attributes, validate), creationTime, type, id);
/*     */   }
/*     */ 
/*     */   
/*     */   public MarkerInfo(Map<String, ? extends Object> attributes, boolean validate, String type, long id) {
/* 100 */     this(attributes, validate, System.currentTimeMillis(), type, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 108 */     return new MarkerInfo(this);
/*     */   }
/*     */   
/*     */   public Object getAttribute(String attributeName) {
/* 112 */     return this.attributes.get(attributeName);
/*     */   }
/*     */   
/*     */   public Map<String, Object> getAttributes() {
/* 116 */     if (this.attributes.isEmpty())
/* 117 */       return null; 
/* 118 */     return this.attributes.toMap();
/*     */   }
/*     */   
/*     */   public MarkerAttributeMap getAttributes(boolean makeCopy) {
/* 122 */     if (this.attributes.isEmpty())
/* 123 */       return null; 
/* 124 */     return makeCopy ? new MarkerAttributeMap(this.attributes) : this.attributes;
/*     */   }
/*     */   
/*     */   public Object[] getAttributes(String[] attributeNames) {
/* 128 */     Object[] result = new Object[attributeNames.length];
/* 129 */     for (int i = 0; i < attributeNames.length; i++)
/* 130 */       result[i] = getAttribute(attributeNames[i]); 
/* 131 */     return result;
/*     */   }
/*     */   
/*     */   public long getCreationTime() {
/* 135 */     return this.creationTime;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getId() {
/* 140 */     return this.id;
/*     */   }
/*     */   
/*     */   public String getType() {
/* 144 */     return this.type;
/*     */   }
/*     */   
/*     */   public void setAttribute(String attributeName, Object value, boolean validate) {
/* 148 */     if (validate) {
/* 149 */       value = checkValidAttribute(value);
/*     */     }
/* 151 */     if (value == null) {
/* 152 */       this.attributes.remove(attributeName);
/*     */     } else {
/* 154 */       this.attributes.put(attributeName, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttributes(Map<String, ? extends Object> map, boolean validate) {
/* 160 */     this.attributes.setAttributes(map, validate);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addAttributes(String[] attributeNames, Object[] values, boolean validate) {
/* 165 */     Assert.isTrue((attributeNames.length == values.length));
/* 166 */     Map<String, Object> map = new HashMap<>();
/* 167 */     for (int i = 0; i < attributeNames.length; i++) {
/* 168 */       map.put(attributeNames[i], values[i]);
/*     */     }
/* 170 */     this.attributes.putAll(map, validate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shareStrings(StringPool set) {
/* 178 */     this.type = set.add(this.type);
/* 179 */     this.attributes.shareStrings(set);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\MarkerInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */