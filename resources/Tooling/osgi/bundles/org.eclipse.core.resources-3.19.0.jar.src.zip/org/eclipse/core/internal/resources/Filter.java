/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IFilterMatcherDescriptor;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.filtermatchers.AbstractFileInfoMatcher;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Filter
/*     */ {
/*     */   FilterDescription description;
/*     */   IProject project;
/*     */   
/*     */   private static class MatchNothingInfoMatcher
/*     */     extends AbstractFileInfoMatcher
/*     */   {
/*     */     public boolean matches(IContainer parent, IFileInfo fileInfo) {
/*  42 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void initialize(IProject project, Object arguments) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  53 */   AbstractFileInfoMatcher provider = null;
/*     */   
/*     */   public Filter(IProject project, FilterDescription description) {
/*  56 */     this.description = description;
/*  57 */     this.project = project;
/*     */   }
/*     */   
/*     */   public boolean match(IContainer parent, IFileInfo fileInfo) throws CoreException {
/*  61 */     if (this.provider == null) {
/*  62 */       IFilterMatcherDescriptor filterDescriptor = this.project.getWorkspace().getFilterMatcherDescriptor(getId());
/*  63 */       if (filterDescriptor != null)
/*  64 */         this.provider = ((FilterDescriptor)filterDescriptor).createFilter(); 
/*  65 */       if (this.provider == null) {
/*  66 */         String message = NLS.bind(Messages.filters_missingFilterType, getId());
/*  67 */         Policy.log((IStatus)new Status(4, "org.eclipse.core.resources", 2, message, new Error()));
/*     */ 
/*     */         
/*  70 */         this.provider = new MatchNothingInfoMatcher();
/*     */       } 
/*     */       try {
/*  73 */         this.provider.initialize(this.project, this.description.getFileInfoMatcherDescription().getArguments());
/*  74 */       } catch (CoreException e) {
/*  75 */         Policy.log(e.getStatus());
/*  76 */         this.provider = null;
/*     */       } 
/*     */     } 
/*  79 */     if (this.provider != null)
/*  80 */       return this.provider.matches(parent, fileInfo); 
/*  81 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isFirst() {
/*  85 */     IFilterMatcherDescriptor descriptor = this.project.getWorkspace().getFilterMatcherDescriptor(getId());
/*  86 */     if (descriptor != null)
/*  87 */       return descriptor.isFirstOrdering(); 
/*  88 */     return false;
/*     */   }
/*     */   
/*     */   public Object getArguments() {
/*  92 */     return this.description.getFileInfoMatcherDescription().getArguments();
/*     */   }
/*     */   
/*     */   public String getId() {
/*  96 */     return this.description.getFileInfoMatcherDescription().getId();
/*     */   }
/*     */   
/*     */   public int getType() {
/* 100 */     return this.description.getType();
/*     */   }
/*     */   
/*     */   public boolean isIncludeOnly() {
/* 104 */     return ((getType() & 0x1) != 0);
/*     */   }
/*     */   
/*     */   public boolean appliesTo(IFileInfo info) {
/* 108 */     if (info.isDirectory())
/* 109 */       return ((getType() & 0x8) != 0); 
/* 110 */     return ((getType() & 0x4) != 0);
/*     */   }
/*     */   
/*     */   public static IFileInfo[] filter(IProject project, LinkedList<Filter> includeFilters, LinkedList<Filter> excludeFilters, IContainer parent, IFileInfo[] list) throws CoreException {
/* 114 */     IFileInfo[] result = filterIncludes(project, includeFilters, parent, list);
/* 115 */     return filterExcludes(project, excludeFilters, parent, result);
/*     */   }
/*     */   
/*     */   public static IFileInfo[] filterIncludes(IProject project, LinkedList<Filter> filters, IContainer parent, IFileInfo[] list) throws CoreException {
/* 119 */     if (filters.size() > 0) {
/* 120 */       IFileInfo[] result = new IFileInfo[list.length];
/* 121 */       int outputIndex = 0; byte b; int i;
/*     */       IFileInfo[] arrayOfIFileInfo1;
/* 123 */       for (i = (arrayOfIFileInfo1 = list).length, b = 0; b < i; ) { IFileInfo info = arrayOfIFileInfo1[b];
/* 124 */         Iterator<Filter> objIt = filters.iterator();
/* 125 */         boolean filtersWereApplicable = false;
/* 126 */         while (objIt.hasNext()) {
/* 127 */           Filter filter = objIt.next();
/* 128 */           if (filter.appliesTo(info)) {
/* 129 */             filtersWereApplicable = true;
/* 130 */             if (filter.match(parent, info)) {
/* 131 */               result[outputIndex++] = info;
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/* 136 */         if (!filtersWereApplicable)
/* 137 */           result[outputIndex++] = info;  b++; }
/*     */       
/* 139 */       if (outputIndex != result.length) {
/* 140 */         IFileInfo[] tmp = new IFileInfo[outputIndex];
/* 141 */         System.arraycopy(result, 0, tmp, 0, outputIndex);
/* 142 */         result = tmp;
/*     */       } 
/* 144 */       return result;
/*     */     } 
/* 146 */     return list;
/*     */   }
/*     */   
/*     */   public static IFileInfo[] filterExcludes(IProject project, LinkedList<Filter> filters, IContainer parent, IFileInfo[] list) throws CoreException {
/* 150 */     if (filters.size() > 0) {
/* 151 */       IFileInfo[] result = new IFileInfo[list.length];
/* 152 */       int outputIndex = 0; byte b; int i;
/*     */       IFileInfo[] arrayOfIFileInfo1;
/* 154 */       for (i = (arrayOfIFileInfo1 = list).length, b = 0; b < i; ) { IFileInfo info = arrayOfIFileInfo1[b];
/* 155 */         Iterator<Filter> objIt = filters.iterator();
/* 156 */         boolean shouldBeExcluded = false;
/* 157 */         while (objIt.hasNext()) {
/* 158 */           Filter filter = objIt.next();
/* 159 */           if (filter.appliesTo(info) && 
/* 160 */             filter.match(parent, info)) {
/* 161 */             shouldBeExcluded = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 166 */         if (!shouldBeExcluded)
/* 167 */           result[outputIndex++] = info;  b++; }
/*     */       
/* 169 */       if (outputIndex != result.length) {
/* 170 */         IFileInfo[] tmp = new IFileInfo[outputIndex];
/* 171 */         System.arraycopy(result, 0, tmp, 0, outputIndex);
/* 172 */         result = tmp;
/*     */       } 
/* 174 */       return result;
/*     */     } 
/* 176 */     return list;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\Filter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */