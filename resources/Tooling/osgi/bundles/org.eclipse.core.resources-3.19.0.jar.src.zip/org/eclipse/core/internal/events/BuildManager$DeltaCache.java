/*    */ package org.eclipse.core.internal.events;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.function.Supplier;
/*    */ import org.eclipse.core.internal.watson.ElementTree;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DeltaCache<E>
/*    */ {
/* 47 */   private final Map<IPath, E> deltas = new HashMap<>();
/*    */   private ElementTree newTree;
/*    */   private ElementTree oldTree;
/*    */   
/*    */   public void flush() {
/* 52 */     this.deltas.clear();
/* 53 */     this.oldTree = null;
/* 54 */     this.newTree = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public E computeIfAbsent(IPath project, ElementTree anOldTree, ElementTree aNewTree, Supplier<E> calculator) {
/* 62 */     if (!areEqual(this.oldTree, anOldTree) || !areEqual(this.newTree, aNewTree)) {
/* 63 */       this.oldTree = anOldTree;
/* 64 */       this.newTree = aNewTree;
/* 65 */       this.deltas.clear();
/*    */     } 
/* 67 */     return this.deltas.computeIfAbsent(project, p -> paramSupplier.get());
/*    */   }
/*    */   
/*    */   private static boolean areEqual(ElementTree cached, ElementTree requested) {
/* 71 */     return !ElementTree.hasChanges(requested, cached, ResourceComparator.getBuildComparator(), true);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\BuildManager$DeltaCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */