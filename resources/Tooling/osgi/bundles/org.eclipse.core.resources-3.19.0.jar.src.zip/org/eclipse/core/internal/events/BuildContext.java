/*     */ package org.eclipse.core.internal.events;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.core.resources.IBuildConfiguration;
/*     */ import org.eclipse.core.resources.IBuildContext;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BuildContext
/*     */   implements IBuildContext
/*     */ {
/*     */   private final IBuildConfiguration buildConfiguration;
/*     */   private final IBuildConfiguration[] requestedBuilt;
/*     */   private final IBuildConfiguration[] buildOrder;
/*     */   
/*     */   public BuildContext(IBuildConfiguration buildConfiguration) {
/*  38 */     this.buildConfiguration = buildConfiguration;
/*  39 */     this.buildOrder = new IBuildConfiguration[] { buildConfiguration }; this.requestedBuilt = new IBuildConfiguration[1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BuildContext(IBuildConfiguration buildConfiguration, IBuildConfiguration[] requestedBuilt, IBuildConfiguration[] buildOrder) {
/*  49 */     this.buildConfiguration = buildConfiguration;
/*  50 */     this.requestedBuilt = requestedBuilt;
/*  51 */     this.buildOrder = buildOrder;
/*     */   }
/*     */   
/*     */   private int findBuildConfigurationIndex() {
/*  55 */     int position = -1;
/*  56 */     for (int i = 0; i < this.buildOrder.length; i++) {
/*  57 */       if (this.buildOrder[i].equals(this.buildConfiguration)) {
/*  58 */         position = i;
/*     */         break;
/*     */       } 
/*     */     } 
/*  62 */     Assert.isTrue((position >= 0 && position < this.buildOrder.length));
/*  63 */     return position;
/*     */   }
/*     */ 
/*     */   
/*     */   public IBuildConfiguration[] getRequestedConfigs() {
/*  68 */     return (IBuildConfiguration[])this.requestedBuilt.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public IBuildConfiguration[] getAllReferencedBuildConfigs() {
/*  73 */     int position = findBuildConfigurationIndex();
/*  74 */     IBuildConfiguration[] builtBefore = new IBuildConfiguration[position];
/*  75 */     System.arraycopy(this.buildOrder, 0, builtBefore, 0, builtBefore.length);
/*  76 */     return builtBefore;
/*     */   }
/*     */ 
/*     */   
/*     */   public IBuildConfiguration[] getAllReferencingBuildConfigs() {
/*  81 */     int position = findBuildConfigurationIndex();
/*  82 */     IBuildConfiguration[] builtAfter = new IBuildConfiguration[this.buildOrder.length - position - 1];
/*  83 */     System.arraycopy(this.buildOrder, position + 1, builtAfter, 0, builtAfter.length);
/*  84 */     return builtAfter;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  90 */     int result = 1;
/*  91 */     result = 31 * result + this.buildConfiguration.hashCode();
/*  92 */     result = 31 * result + Arrays.hashCode((Object[])this.requestedBuilt);
/*  93 */     result = 31 * result + Arrays.hashCode((Object[])this.buildOrder);
/*  94 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  99 */     if (this == obj)
/* 100 */       return true; 
/* 101 */     if (obj == null)
/* 102 */       return false; 
/* 103 */     if (getClass() != obj.getClass())
/* 104 */       return false; 
/* 105 */     BuildContext other = (BuildContext)obj;
/* 106 */     return (this.buildConfiguration.equals(other.buildConfiguration) && Arrays.equals((Object[])this.requestedBuilt, (Object[])other.requestedBuilt) && Arrays.equals((Object[])this.buildOrder, (Object[])other.buildOrder));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\BuildContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */