/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.eclipse.core.resources.IBuildConfiguration;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BuildConfiguration
/*     */   extends PlatformObject
/*     */   implements IBuildConfiguration
/*     */ {
/*     */   private final IProject project;
/*     */   private final String name;
/*     */   
/*     */   public BuildConfiguration(IProject project) {
/*  42 */     this(project, "");
/*     */   }
/*     */   
/*     */   public BuildConfiguration(IProject project, String configName) {
/*  46 */     this.project = project;
/*  47 */     this.name = configName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBuildConfiguration getBuildConfig() throws CoreException {
/*  55 */     return this.project.getBuildConfig(this.name);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  60 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public IProject getProject() {
/*  65 */     return this.project;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  70 */     if (this == obj)
/*  71 */       return true; 
/*  72 */     if (obj == null)
/*  73 */       return false; 
/*  74 */     if (getClass() != obj.getClass())
/*  75 */       return false; 
/*  76 */     BuildConfiguration other = (BuildConfiguration)obj;
/*  77 */     return (Objects.equals(this.name, other.name) && Objects.equals(this.project, other.project));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  83 */     int result = 1;
/*  84 */     result = 31 * result + Objects.hashCode(this.name);
/*  85 */     result = 31 * result + Objects.hashCode(this.project);
/*  86 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  91 */     StringBuilder result = new StringBuilder();
/*  92 */     if (this.project != null) {
/*  93 */       result.append(this.project.getName());
/*     */     } else {
/*  95 */       result.append("?");
/*  96 */     }  result.append(";");
/*  97 */     if (this.name != null) {
/*  98 */       result.append(" [").append(this.name).append(']');
/*     */     } else {
/* 100 */       result.append(" [active]");
/* 101 */     }  return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getAdapter(Class<T> adapter) {
/* 107 */     if (adapter.isInstance(this.project))
/* 108 */       return (T)this.project; 
/* 109 */     return (T)super.getAdapter(adapter);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\BuildConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */