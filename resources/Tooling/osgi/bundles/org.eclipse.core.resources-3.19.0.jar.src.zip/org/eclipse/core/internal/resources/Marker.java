/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.resources.IMarker;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Marker
/*     */   extends PlatformObject
/*     */   implements IMarker
/*     */ {
/*     */   protected final long id;
/*     */   protected final IResource resource;
/*     */   
/*     */   Marker(IResource resource, long id) {
/*  51 */     Assert.isLegal((resource != null));
/*  52 */     this.resource = resource;
/*  53 */     this.id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkInfo(MarkerInfo info) throws CoreException {
/*  61 */     if (info == null) {
/*  62 */       String message = NLS.bind(Messages.resources_markerNotFound, Long.toString(this.id));
/*  63 */       throw new ResourceException(new ResourceStatus(376, this.resource.getFullPath(), message, new IllegalStateException()));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete() throws CoreException {
/*  72 */     ISchedulingRule rule = getWorkspace().getRuleFactory().markerRule(this.resource);
/*     */     try {
/*  74 */       getWorkspace().prepareOperation(rule, null);
/*  75 */       getWorkspace().beginOperation(true);
/*  76 */       getWorkspace().getMarkerManager().removeMarker(getResource(), getId());
/*     */     } finally {
/*  78 */       getWorkspace().endOperation(rule, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/*  87 */     if (!(object instanceof IMarker))
/*  88 */       return false; 
/*  89 */     IMarker other = (IMarker)object;
/*  90 */     return (this.id == other.getId() && this.resource.equals(other.getResource()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean exists() {
/*  98 */     return (getInfo() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAttribute(String attributeName) throws CoreException {
/* 106 */     Assert.isNotNull(attributeName);
/* 107 */     MarkerInfo info = getInfo();
/* 108 */     checkInfo(info);
/* 109 */     return info.getAttribute(attributeName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAttribute(String attributeName, int defaultValue) {
/* 117 */     Assert.isNotNull(attributeName);
/* 118 */     MarkerInfo info = getInfo();
/* 119 */     if (info == null)
/* 120 */       return defaultValue; 
/* 121 */     Object value = info.getAttribute(attributeName);
/* 122 */     if (value instanceof Integer)
/* 123 */       return ((Integer)value).intValue(); 
/* 124 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAttribute(String attributeName, String defaultValue) {
/* 132 */     Assert.isNotNull(attributeName);
/* 133 */     MarkerInfo info = getInfo();
/* 134 */     if (info == null)
/* 135 */       return defaultValue; 
/* 136 */     Object value = info.getAttribute(attributeName);
/* 137 */     if (value instanceof String)
/* 138 */       return (String)value; 
/* 139 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAttribute(String attributeName, boolean defaultValue) {
/* 147 */     Assert.isNotNull(attributeName);
/* 148 */     MarkerInfo info = getInfo();
/* 149 */     if (info == null)
/* 150 */       return defaultValue; 
/* 151 */     Object value = info.getAttribute(attributeName);
/* 152 */     if (value instanceof Boolean)
/* 153 */       return ((Boolean)value).booleanValue(); 
/* 154 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getAttributes() throws CoreException {
/* 162 */     MarkerInfo info = getInfo();
/* 163 */     checkInfo(info);
/* 164 */     return info.getAttributes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getAttributes(String[] attributeNames) throws CoreException {
/* 172 */     Assert.isNotNull(attributeNames);
/* 173 */     MarkerInfo info = getInfo();
/* 174 */     checkInfo(info);
/* 175 */     return info.getAttributes(attributeNames);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getCreationTime() throws CoreException {
/* 183 */     MarkerInfo info = getInfo();
/* 184 */     checkInfo(info);
/* 185 */     return info.getCreationTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getId() {
/* 193 */     return this.id;
/*     */   }
/*     */   
/*     */   protected MarkerInfo getInfo() {
/* 197 */     return getWorkspace().getMarkerManager().findMarkerInfo(this.resource, this.id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource getResource() {
/* 205 */     return this.resource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() throws CoreException {
/* 213 */     MarkerInfo info = getInfo();
/* 214 */     checkInfo(info);
/* 215 */     return info.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Workspace getWorkspace() {
/* 224 */     return (this.resource == null) ? null : (Workspace)this.resource.getWorkspace();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 229 */     return (int)this.id + this.resource.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSubtypeOf(String type) throws CoreException {
/* 237 */     return getWorkspace().getMarkerManager().isSubtype(getType(), type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String attributeName, int value) throws CoreException {
/* 245 */     setAttribute(attributeName, Integer.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String attributeName, Object value) throws CoreException {
/* 253 */     Assert.isNotNull(attributeName);
/* 254 */     Workspace workspace = getWorkspace();
/* 255 */     MarkerManager manager = workspace.getMarkerManager();
/*     */     try {
/* 257 */       workspace.prepareOperation(null, null);
/* 258 */       workspace.beginOperation(true);
/* 259 */       MarkerInfo markerInfo = getInfo();
/* 260 */       checkInfo(markerInfo);
/*     */ 
/*     */       
/* 263 */       boolean needDelta = !manager.hasDelta(this.resource.getFullPath(), this.id);
/* 264 */       MarkerInfo oldInfo = needDelta ? (MarkerInfo)markerInfo.clone() : null;
/* 265 */       boolean validate = manager.isPersistentType(markerInfo.getType());
/* 266 */       markerInfo.setAttribute(attributeName, value, validate);
/* 267 */       if (manager.isPersistent(markerInfo))
/* 268 */         ((Resource)this.resource).getResourceInfo(false, true).set(4096); 
/* 269 */       if (needDelta) {
/* 270 */         MarkerDelta delta = new MarkerDelta(4, this.resource, oldInfo);
/* 271 */         manager.changedMarkers(this.resource, (IMarkerSetElement[])new MarkerDelta[] { delta });
/*     */       } 
/*     */     } finally {
/* 274 */       workspace.endOperation(null, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String attributeName, boolean value) throws CoreException {
/* 283 */     setAttribute(attributeName, value ? Boolean.TRUE : Boolean.FALSE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributes(String[] attributeNames, Object[] values) throws CoreException {
/* 292 */     Assert.isNotNull(attributeNames);
/* 293 */     Assert.isNotNull(values);
/* 294 */     Workspace workspace = getWorkspace();
/* 295 */     MarkerManager manager = workspace.getMarkerManager();
/*     */     try {
/* 297 */       workspace.prepareOperation(null, null);
/* 298 */       workspace.beginOperation(true);
/* 299 */       MarkerInfo markerInfo = getInfo();
/* 300 */       checkInfo(markerInfo);
/*     */ 
/*     */       
/* 303 */       boolean needDelta = !manager.hasDelta(this.resource.getFullPath(), this.id);
/* 304 */       MarkerInfo oldInfo = needDelta ? (MarkerInfo)markerInfo.clone() : null;
/* 305 */       boolean validate = manager.isPersistentType(markerInfo.getType());
/* 306 */       markerInfo.addAttributes(attributeNames, values, validate);
/* 307 */       if (manager.isPersistent(markerInfo))
/* 308 */         ((Resource)this.resource).getResourceInfo(false, true).set(4096); 
/* 309 */       if (needDelta) {
/* 310 */         MarkerDelta delta = new MarkerDelta(4, this.resource, oldInfo);
/* 311 */         manager.changedMarkers(this.resource, (IMarkerSetElement[])new MarkerDelta[] { delta });
/*     */       } 
/*     */     } finally {
/* 314 */       workspace.endOperation(null, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributes(Map<String, ? extends Object> values) throws CoreException {
/* 324 */     Workspace workspace = getWorkspace();
/* 325 */     MarkerManager manager = workspace.getMarkerManager();
/*     */     try {
/* 327 */       workspace.prepareOperation(null, null);
/* 328 */       workspace.beginOperation(true);
/* 329 */       MarkerInfo markerInfo = getInfo();
/* 330 */       checkInfo(markerInfo);
/*     */ 
/*     */       
/* 333 */       boolean needDelta = !manager.hasDelta(this.resource.getFullPath(), this.id);
/* 334 */       MarkerInfo oldInfo = needDelta ? (MarkerInfo)markerInfo.clone() : null;
/* 335 */       boolean validate = manager.isPersistentType(markerInfo.getType());
/* 336 */       markerInfo.setAttributes(values, validate);
/* 337 */       if (manager.isPersistent(markerInfo))
/* 338 */         ((Resource)this.resource).getResourceInfo(false, true).set(4096); 
/* 339 */       if (needDelta) {
/* 340 */         MarkerDelta delta = new MarkerDelta(4, this.resource, oldInfo);
/* 341 */         manager.changedMarkers(this.resource, (IMarkerSetElement[])new MarkerDelta[] { delta });
/*     */       } 
/*     */     } finally {
/* 344 */       workspace.endOperation(null, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 351 */     StringBuilder sb = new StringBuilder("Marker [");
/* 352 */     sb.append("on: ").append(this.resource.getFullPath());
/* 353 */     MarkerInfo info = getInfo();
/* 354 */     if (info == null) {
/* 355 */       sb.append(", not found]");
/* 356 */       return sb.toString();
/*     */     } 
/* 358 */     sb.append(", id: ").append(info.getId());
/* 359 */     sb.append(", type: ").append(info.getType());
/* 360 */     Map<String, Object> attributes = info.getAttributes();
/* 361 */     if (attributes != null) {
/* 362 */       TreeMap<String, Object> tm = new TreeMap<>(attributes);
/* 363 */       Set<Map.Entry<String, Object>> set = tm.entrySet();
/* 364 */       if (!set.isEmpty()) {
/* 365 */         sb.append(", attributes: [");
/* 366 */         for (Map.Entry<String, Object> entry : set) {
/* 367 */           sb.append(entry.getKey()).append(": ").append(entry.getValue()).append(", ");
/*     */         }
/* 369 */         sb.setLength(sb.length() - 2);
/* 370 */         sb.append(']');
/*     */       } 
/*     */     } 
/* 373 */     sb.append(", created: ").append(DateFormat.getDateTimeInstance(3, 3).format(new Date(info.getCreationTime())));
/* 374 */     sb.append(']');
/* 375 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\Marker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */