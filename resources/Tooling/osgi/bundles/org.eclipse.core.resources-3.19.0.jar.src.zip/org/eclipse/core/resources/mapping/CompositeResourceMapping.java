/*    */ package org.eclipse.core.resources.mapping;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.SubMonitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CompositeResourceMapping
/*    */   extends ResourceMapping
/*    */ {
/*    */   private final ResourceMapping[] mappings;
/*    */   private final Object modelObject;
/*    */   private IProject[] projects;
/*    */   private String providerId;
/*    */   
/*    */   public CompositeResourceMapping(String providerId, Object modelObject, ResourceMapping[] mappings) {
/* 42 */     this.modelObject = modelObject;
/* 43 */     this.mappings = mappings;
/* 44 */     this.providerId = providerId;
/*    */   } public boolean contains(ResourceMapping mapping) {
/*    */     byte b;
/*    */     int i;
/*    */     ResourceMapping[] arrayOfResourceMapping;
/* 49 */     for (i = (arrayOfResourceMapping = this.mappings).length, b = 0; b < i; ) { ResourceMapping childMapping = arrayOfResourceMapping[b];
/* 50 */       if (childMapping.contains(mapping))
/* 51 */         return true; 
/*    */       b++; }
/*    */     
/* 54 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ResourceMapping[] getMappings() {
/* 62 */     return this.mappings;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getModelObject() {
/* 67 */     return this.modelObject;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getModelProviderId() {
/* 72 */     return this.providerId;
/*    */   }
/*    */ 
/*    */   
/*    */   public IProject[] getProjects() {
/* 77 */     if (this.projects == null) {
/* 78 */       Set<IProject> result = new HashSet<>(); byte b; int i; ResourceMapping[] arrayOfResourceMapping;
/* 79 */       for (i = (arrayOfResourceMapping = this.mappings).length, b = 0; b < i; ) { ResourceMapping mapping = arrayOfResourceMapping[b];
/* 80 */         result.addAll(Arrays.asList(mapping.getProjects())); b++; }
/*    */       
/* 82 */       this.projects = result.<IProject>toArray(new IProject[result.size()]);
/*    */     } 
/* 84 */     return this.projects;
/*    */   }
/*    */ 
/*    */   
/*    */   public ResourceTraversal[] getTraversals(ResourceMappingContext context, IProgressMonitor monitor) throws CoreException {
/* 89 */     SubMonitor subMonitor = SubMonitor.convert(monitor, this.mappings.length);
/* 90 */     List<ResourceTraversal> result = new ArrayList<>(); byte b; int i; ResourceMapping[] arrayOfResourceMapping;
/* 91 */     for (i = (arrayOfResourceMapping = this.mappings).length, b = 0; b < i; ) { ResourceMapping mapping = arrayOfResourceMapping[b];
/* 92 */       Collections.addAll(result, mapping.getTraversals(context, (IProgressMonitor)subMonitor.newChild(1))); b++; }
/*    */     
/* 94 */     return result.<ResourceTraversal>toArray(new ResourceTraversal[result.size()]);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\mapping\CompositeResourceMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */