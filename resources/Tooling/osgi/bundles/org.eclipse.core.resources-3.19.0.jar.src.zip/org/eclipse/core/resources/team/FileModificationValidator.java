/*    */ package org.eclipse.core.resources.team;
/*    */ 
/*    */ import org.eclipse.core.resources.IFile;
/*    */ import org.eclipse.core.resources.IFileModificationValidator;
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FileModificationValidator
/*    */   implements IFileModificationValidator
/*    */ {
/*    */   @Deprecated
/*    */   public final IStatus validateEdit(IFile[] files, Object context) {
/*    */     FileModificationValidationContext validationContext;
/* 58 */     if (context == null) {
/* 59 */       validationContext = null;
/* 60 */     } else if (context instanceof FileModificationValidationContext) {
/* 61 */       validationContext = (FileModificationValidationContext)context;
/*    */     } else {
/* 63 */       validationContext = new FileModificationValidationContext(context);
/* 64 */     }  return validateEdit(files, validationContext);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IStatus validateSave(IFile file) {
/* 85 */     return validateEdit(new IFile[] { file }, (FileModificationValidationContext)null);
/*    */   }
/*    */   
/*    */   public abstract IStatus validateEdit(IFile[] paramArrayOfIFile, FileModificationValidationContext paramFileModificationValidationContext);
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\team\FileModificationValidator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */