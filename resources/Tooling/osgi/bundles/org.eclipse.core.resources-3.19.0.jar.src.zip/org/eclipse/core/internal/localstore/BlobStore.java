/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.internal.utils.UniversalUniqueIdentifier;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlobStore
/*     */ {
/*     */   protected IFileStore localStore;
/*     */   protected byte mask;
/*  36 */   private static byte[] randomArray = new byte[] { -43, -25, 37, 85, -45, 29, -95, -81, -69, 3, -109, -10, -86, 30, -54, -73, -14, 47, -2, -67, 25, -8, -63, 2, 119, -123, 125, 12, 76, -43, -37, 79, 69, -123, -54, 80, -106, -66, -99, -66, 80, -66, -37, -106, -87, 117, 95, 10, 77, -42, -23, 70, 5, -68, 44, 91, -91, -107, -79, 93, 17, 112, 4, 41, -26, -108, -68, 107, -43, 31, 52, 60, 111, -10, -30, 121, -127, -59, -112, -8, 92, -123, 96, 116, 104, 67, 74, -112, -71, -115, 96, 34, -74, 90, 36, -39, 28, -51, 107, 52, -55, 14, 8, 1, 27, -40, 60, 35, -5, -62, 7, -100, 32, 5, -111, 29, 96, 61, 110, -111, 50, 56, -21, -17, -86, -118, 17, -45, 56, 98, 101, 126, 27, 57, -45, -112, -50, -49, -77, 111, -96, 50, -13, 69, 106, 118, -101, -97, 28, 57, 11, -81, 43, -83, 96, -75, 99, -87, -85, -100, -10, -13, 30, 
/*  37 */       -58, -5, 81, 77, 92, -96, -21, -41, -69, 23, 71, 58, -9, Byte.MAX_VALUE, 56, 118, -124, 79, -68, 42, -68, -98, 121, -1, 65, -102, 118, -84, -39, 4, 47, 105, -52, -121, 27, 43, 90, 9, 31, 59, 115, -63, 28, 55, 101, 9, 117, -45, 112, 61, 55, 23, -21, 51, 104, 123, -118, 76, -108, 115, 119, 81, 54, 39, 46, -107, -65, 79, 16, -34, 69, -37, -120, -108, -75, 77, -6, 101, -33, -116, -62, -115, 44, -61, -39, 31, -33, -49, -107, -11, 115, -13, -73 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlobStore(IFileStore store, int limit) {
/*  45 */     Assert.isNotNull(store);
/*  46 */     this.localStore = store;
/*  47 */     Assert.isTrue(this.localStore.fetchInfo().isDirectory());
/*  48 */     Assert.isTrue(!(limit != 256 && limit != 128 && limit != 64 && limit != 32 && limit != 16 && limit != 8 && limit != 4 && limit != 2 && limit != 1));
/*  49 */     this.mask = (byte)(limit - 1);
/*     */   }
/*     */   
/*     */   public UniversalUniqueIdentifier addBlob(IFileStore target, boolean moveContents) throws CoreException {
/*  53 */     UniversalUniqueIdentifier uuid = new UniversalUniqueIdentifier();
/*  54 */     folderFor(uuid).mkdir(0, null);
/*  55 */     IFileStore destination = fileFor(uuid);
/*  56 */     if (moveContents) {
/*  57 */       target.move(destination, 0, null);
/*     */     } else {
/*  59 */       target.copy(destination, 0, null);
/*  60 */     }  return uuid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendByteString(StringBuilder buffer, byte value) {
/*     */     String hexString;
/*  69 */     if (value < 0) {
/*  70 */       hexString = Integer.toHexString(256 + value);
/*     */     } else {
/*  72 */       hexString = Integer.toHexString(value);
/*  73 */     }  if (hexString.length() == 1)
/*  74 */       buffer.append("0"); 
/*  75 */     buffer.append(hexString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String bytesToHexString(byte[] b) {
/*  84 */     StringBuilder buffer = new StringBuilder(); byte b1; int i; byte[] arrayOfByte;
/*  85 */     for (i = (arrayOfByte = b).length, b1 = 0; b1 < i; ) { byte element = arrayOfByte[b1];
/*  86 */       appendByteString(buffer, element); b1++; }
/*  87 */      return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteBlob(UniversalUniqueIdentifier uuid) {
/*  94 */     Assert.isNotNull(uuid);
/*     */     try {
/*  96 */       fileFor(uuid).delete(0, null);
/*  97 */     } catch (CoreException coreException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteBlobs(Set<UniversalUniqueIdentifier> set) {
/* 106 */     for (UniversalUniqueIdentifier id : set)
/* 107 */       deleteBlob(id); 
/*     */   }
/*     */   
/*     */   public IFileStore fileFor(UniversalUniqueIdentifier uuid) {
/* 111 */     IFileStore root = folderFor(uuid);
/* 112 */     return root.getChild(bytesToHexString(uuid.toBytes()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileStore folderFor(UniversalUniqueIdentifier uuid) {
/* 119 */     byte hash = hashUUIDbytes(uuid);
/* 120 */     hash = (byte)(hash & this.mask);
/* 121 */     String dirName = Integer.toHexString(hash + (0x80 & this.mask));
/* 122 */     return this.localStore.getChild(dirName);
/*     */   }
/*     */   
/*     */   public InputStream getBlob(UniversalUniqueIdentifier uuid) throws CoreException {
/* 126 */     IFileStore blobFile = fileFor(uuid);
/* 127 */     return blobFile.openInputStream(0, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte hashUUIDbytes(UniversalUniqueIdentifier uuid) {
/* 135 */     byte[] bytes = uuid.toBytes();
/* 136 */     byte hash = 0; byte b; int i; byte[] arrayOfByte1;
/* 137 */     for (i = (arrayOfByte1 = bytes).length, b = 0; b < i; ) { byte b1 = arrayOfByte1[b];
/* 138 */       hash = (byte)(hash ^ randomArray[b1 + 128]); b++; }
/* 139 */      return hash;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\BlobStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */