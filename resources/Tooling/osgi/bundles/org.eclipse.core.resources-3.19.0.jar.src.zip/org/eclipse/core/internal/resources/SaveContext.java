/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.ISaveContext;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SaveContext
/*     */   implements ISaveContext
/*     */ {
/*     */   protected String pluginId;
/*     */   protected int kind;
/*     */   protected boolean needDelta;
/*     */   protected boolean needSaveNumber;
/*     */   protected SafeFileTable fileTable;
/*     */   protected int previousSaveNumber;
/*     */   protected IProject project;
/*     */   private Workspace workspace;
/*     */   
/*     */   protected SaveContext(String pluginId, int kind, IProject project, Workspace workspace) throws CoreException {
/*  33 */     this.kind = kind;
/*  34 */     this.project = project;
/*  35 */     this.pluginId = pluginId;
/*  36 */     this.needDelta = false;
/*  37 */     this.needSaveNumber = false;
/*  38 */     this.workspace = workspace;
/*  39 */     this.fileTable = new SafeFileTable(pluginId, workspace);
/*  40 */     this.previousSaveNumber = getWorkspace().getSaveManager().getSaveNumber(pluginId);
/*     */   }
/*     */   
/*     */   public void commit() throws CoreException {
/*  44 */     if (this.needSaveNumber) {
/*  45 */       IPath oldLocation = getWorkspace().getMetaArea().getSafeTableLocationFor(this.pluginId);
/*  46 */       getWorkspace().getSaveManager().setSaveNumber(this.pluginId, getSaveNumber());
/*  47 */       this.fileTable.setLocation(getWorkspace().getMetaArea().getSafeTableLocationFor(this.pluginId));
/*  48 */       this.fileTable.save();
/*  49 */       oldLocation.toFile().delete();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath[] getFiles() {
/*  58 */     return getFileTable().getFiles();
/*     */   }
/*     */   
/*     */   protected SafeFileTable getFileTable() {
/*  62 */     return this.fileTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getKind() {
/*  70 */     return this.kind;
/*     */   }
/*     */   
/*     */   public String getPluginId() {
/*  74 */     return this.pluginId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPreviousSaveNumber() {
/*  82 */     return this.previousSaveNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IProject getProject() {
/*  90 */     return this.project;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSaveNumber() {
/*  98 */     int result = getPreviousSaveNumber() + 1;
/*  99 */     return (result > 0) ? result : 1;
/*     */   }
/*     */   
/*     */   protected Workspace getWorkspace() {
/* 103 */     return this.workspace;
/*     */   }
/*     */   
/*     */   public boolean isDeltaNeeded() {
/* 107 */     return this.needDelta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath lookup(IPath file) {
/* 115 */     return getFileTable().lookup(file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void map(IPath file, IPath location) {
/* 123 */     getFileTable().map(file, location);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void needDelta() {
/* 131 */     this.needDelta = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void needSaveNumber() {
/* 139 */     this.needSaveNumber = true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\SaveContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */