/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarkerReader_2
/*     */   extends MarkerReader
/*     */ {
/*     */   public static final byte INDEX = 1;
/*     */   public static final byte QNAME = 2;
/*     */   public static final byte ATTRIBUTE_NULL = 0;
/*     */   public static final byte ATTRIBUTE_BOOLEAN = 1;
/*     */   public static final byte ATTRIBUTE_INTEGER = 2;
/*     */   public static final byte ATTRIBUTE_STRING = 3;
/*     */   
/*     */   public MarkerReader_2(Workspace workspace) {
/*  43 */     super(workspace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void read(DataInputStream input, boolean generateDeltas) throws IOException, CoreException {
/*     */     try {
/*  71 */       List<String> readTypes = new ArrayList<>(5);
/*     */       while (true) {
/*  73 */         Path path = new Path(input.readUTF());
/*  74 */         int markersSize = input.readInt();
/*  75 */         MarkerSet markers = new MarkerSet(markersSize);
/*  76 */         for (int i = 0; i < markersSize; i++) {
/*  77 */           markers.add(readMarkerInfo(input, readTypes));
/*     */         }
/*     */ 
/*     */         
/*  81 */         ResourceInfo info = this.workspace.getResourceInfo((IPath)path, false, false);
/*  82 */         if (info == null)
/*     */           continue; 
/*  84 */         info.setMarkers(markers);
/*  85 */         if (generateDeltas) {
/*     */ 
/*     */           
/*  88 */           Resource resource = this.workspace.newResource((IPath)path, info.getType());
/*  89 */           IMarkerSetElement[] infos = markers.elements;
/*  90 */           ArrayList<MarkerDelta> deltas = new ArrayList<>(infos.length); byte b; int j; IMarkerSetElement[] arrayOfIMarkerSetElement1;
/*  91 */           for (j = (arrayOfIMarkerSetElement1 = infos).length, b = 0; b < j; ) { IMarkerSetElement info2 = arrayOfIMarkerSetElement1[b];
/*  92 */             if (info2 != null)
/*  93 */               deltas.add(new MarkerDelta(1, resource, (MarkerInfo)info2));  b++; }
/*  94 */            this.workspace.getMarkerManager().changedMarkers(resource, deltas.<IMarkerSetElement>toArray(new IMarkerSetElement[deltas.size()]));
/*     */         } 
/*     */       } 
/*  97 */     } catch (EOFException eOFException) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Map<String, Object> readAttributes(DataInputStream input) throws IOException {
/* 103 */     int attributesSize = input.readShort();
/* 104 */     if (attributesSize == 0)
/* 105 */       return null; 
/* 106 */     Map<String, Object> result = new HashMap<>(attributesSize);
/* 107 */     for (int j = 0; j < attributesSize; j++) {
/* 108 */       String key = input.readUTF();
/* 109 */       byte type = input.readByte();
/* 110 */       Object value = null;
/* 111 */       switch (type) {
/*     */         case 2:
/* 113 */           value = Integer.valueOf(input.readInt());
/*     */           break;
/*     */         case 1:
/* 116 */           value = Boolean.valueOf(input.readBoolean());
/*     */           break;
/*     */         case 3:
/* 119 */           value = input.readUTF();
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 125 */       if (value != null) {
/* 126 */         result.put(key, value);
/*     */       }
/*     */     } 
/* 129 */     return result.isEmpty() ? null : result;
/*     */   }
/*     */   private MarkerInfo readMarkerInfo(DataInputStream input, List<String> readTypes) throws IOException, CoreException {
/*     */     Map<String, Object> map, map1;
/* 133 */     long creationTime, id = input.readLong();
/* 134 */     byte constant = input.readByte();
/* 135 */     String type = null;
/* 136 */     switch (constant) {
/*     */       case 2:
/* 138 */         type = input.readUTF();
/* 139 */         readTypes.add(type);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 149 */         map = readAttributes(input);
/* 150 */         creationTime = 0L;
/* 151 */         return new MarkerInfo(map, false, creationTime, type, id);case 1: type = readTypes.get(input.readInt()); map1 = readAttributes(input); creationTime = 0L; return new MarkerInfo(map1, false, creationTime, type, id);
/*     */     } 
/*     */     String str1 = Messages.resources_readMarkers;
/*     */     throw new ResourceException(567, null, str1, null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\MarkerReader_2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */