/*    */ package org.eclipse.core.internal.events;
/*    */ 
/*    */ import org.eclipse.core.resources.IResourceChangeListener;
/*    */ import org.eclipse.core.resources.ISaveParticipant;
/*    */ import org.eclipse.core.resources.IncrementalProjectBuilder;
/*    */ import org.eclipse.core.resources.ResourcesPlugin;
/*    */ import org.eclipse.core.runtime.PerformanceStats;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceStats
/*    */ {
/*    */   private static PerformanceStats currentStats;
/*    */   public static final String EVENT_BUILDERS = "org.eclipse.core.resources/perf/builders";
/*    */   public static final String EVENT_LISTENERS = "org.eclipse.core.resources/perf/listeners";
/*    */   public static final String EVENT_SAVE_PARTICIPANTS = "org.eclipse.core.resources/perf/save.participants";
/*    */   public static final String EVENT_SNAPSHOT = "org.eclipse.core.resources/perf/snapshot";
/* 35 */   public static boolean TRACE_BUILDERS = PerformanceStats.isEnabled("org.eclipse.core.resources/perf/builders");
/* 36 */   public static boolean TRACE_LISTENERS = PerformanceStats.isEnabled("org.eclipse.core.resources/perf/listeners");
/* 37 */   public static boolean TRACE_SAVE_PARTICIPANTS = PerformanceStats.isEnabled("org.eclipse.core.resources/perf/save.participants");
/* 38 */   public static boolean TRACE_SNAPSHOT = PerformanceStats.isEnabled("org.eclipse.core.resources/perf/snapshot");
/*    */   
/*    */   public static void endBuild() {
/* 41 */     if (currentStats != null)
/* 42 */       currentStats.endRun(); 
/* 43 */     currentStats = null;
/*    */   }
/*    */   
/*    */   public static void endNotify() {
/* 47 */     if (currentStats != null)
/* 48 */       currentStats.endRun(); 
/* 49 */     currentStats = null;
/*    */   }
/*    */   
/*    */   public static void endSave() {
/* 53 */     if (currentStats != null)
/* 54 */       currentStats.endRun(); 
/* 55 */     currentStats = null;
/*    */   }
/*    */   
/*    */   public static void endSnapshot() {
/* 59 */     if (currentStats != null)
/* 60 */       currentStats.endRun(); 
/* 61 */     currentStats = null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void listenerAdded(IResourceChangeListener listener) {
/* 68 */     if (listener != null) {
/* 69 */       PerformanceStats.getStats("org.eclipse.core.resources/perf/listeners", listener.getClass().getName());
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void listenerRemoved(IResourceChangeListener listener) {
/* 76 */     if (listener != null)
/* 77 */       PerformanceStats.removeStats("org.eclipse.core.resources/perf/listeners", listener.getClass().getName()); 
/*    */   }
/*    */   
/*    */   public static void startBuild(IncrementalProjectBuilder builder) {
/* 81 */     currentStats = PerformanceStats.getStats("org.eclipse.core.resources/perf/builders", builder);
/* 82 */     currentStats.startRun(builder.getProject().getName());
/*    */   }
/*    */   
/*    */   public static void startNotify(IResourceChangeListener listener) {
/* 86 */     currentStats = PerformanceStats.getStats("org.eclipse.core.resources/perf/listeners", listener);
/* 87 */     currentStats.startRun();
/*    */   }
/*    */   
/*    */   public static void startSnapshot() {
/* 91 */     currentStats = PerformanceStats.getStats("org.eclipse.core.resources/perf/snapshot", ResourcesPlugin.getWorkspace());
/* 92 */     currentStats.startRun();
/*    */   }
/*    */   
/*    */   public static void startSave(ISaveParticipant participant) {
/* 96 */     currentStats = PerformanceStats.getStats("org.eclipse.core.resources/perf/save.participants", participant);
/* 97 */     currentStats.startRun();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\ResourceStats.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */