package org.eclipse.core.resources;

import java.io.InputStream;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IPath;

public interface IStorage extends IAdaptable {
  InputStream getContents() throws CoreException;
  
  IPath getFullPath();
  
  String getName();
  
  boolean isReadOnly();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IStorage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */