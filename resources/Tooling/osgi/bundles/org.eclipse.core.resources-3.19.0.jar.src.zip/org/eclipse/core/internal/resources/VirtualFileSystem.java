/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.eclipse.core.filesystem.IFileStore;
/*    */ import org.eclipse.core.filesystem.provider.FileSystem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VirtualFileSystem
/*    */   extends FileSystem
/*    */ {
/*    */   public IFileStore getStore(URI uri) {
/* 31 */     return (IFileStore)new VirtualFileStore(uri);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\VirtualFileSystem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */