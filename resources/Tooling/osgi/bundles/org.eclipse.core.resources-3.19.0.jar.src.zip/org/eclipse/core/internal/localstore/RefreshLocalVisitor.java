/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import org.eclipse.core.internal.resources.Container;
/*     */ import org.eclipse.core.internal.resources.File;
/*     */ import org.eclipse.core.internal.resources.Folder;
/*     */ import org.eclipse.core.internal.resources.Resource;
/*     */ import org.eclipse.core.internal.resources.ResourceInfo;
/*     */ import org.eclipse.core.internal.resources.ResourceStatus;
/*     */ import org.eclipse.core.internal.resources.Workspace;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RefreshLocalVisitor
/*     */   implements IUnifiedTreeVisitor, ILocalStoreConstants
/*     */ {
/*     */   protected static final int RL_UNKNOWN = 0;
/*     */   protected static final int RL_IN_SYNC = 1;
/*     */   protected static final int RL_NOT_IN_SYNC = 2;
/*     */   public static final int TOTAL_WORK = 1000;
/*     */   protected MultiStatus errors;
/*     */   protected SubMonitor monitor;
/*     */   protected boolean resourceChanged;
/*     */   protected Workspace workspace;
/*     */   
/*     */   public RefreshLocalVisitor(IProgressMonitor monitor) {
/*  46 */     this.monitor = SubMonitor.convert(monitor);
/*  47 */     this.workspace = (Workspace)ResourcesPlugin.getWorkspace();
/*  48 */     this.resourceChanged = false;
/*  49 */     String msg = Messages.resources_errorMultiRefresh;
/*  50 */     this.errors = new MultiStatus("org.eclipse.core.resources", 271, msg, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void contentAdded(UnifiedTreeNode node, Resource target) {
/*  58 */     resourceChanged(node, target);
/*     */   }
/*     */   
/*     */   protected void createResource(UnifiedTreeNode node, Resource target) throws CoreException {
/*  62 */     ResourceInfo info = target.getResourceInfo(false, false);
/*  63 */     int flags = target.getFlags(info);
/*  64 */     if (target.exists(flags, false)) {
/*     */       return;
/*     */     }
/*  67 */     IContainer parent = target.getParent();
/*  68 */     if (parent.getType() == 2) {
/*  69 */       ((Folder)target.getParent()).ensureExists((IProgressMonitor)this.monitor);
/*     */     }
/*  71 */     info = this.workspace.createResource((IResource)target, false);
/*     */     
/*  73 */     info.set(1048576);
/*  74 */     target.getLocalManager().updateLocalSync(info, node.getLastModified());
/*     */   }
/*     */   
/*     */   protected void deleteResource(UnifiedTreeNode node, Resource target) throws CoreException {
/*  78 */     ResourceInfo info = target.getResourceInfo(false, false);
/*  79 */     int flags = target.getFlags(info);
/*     */     
/*  81 */     if (ResourceInfo.isSet(flags, 65536)) {
/*     */       
/*  83 */       info = target.getResourceInfo(false, true);
/*     */       
/*  85 */       if (info != null) {
/*  86 */         info.clearModificationStamp();
/*  87 */         target.getLocalManager().updateLocalSync(info, node.getLastModified());
/*     */       } 
/*     */       return;
/*     */     } 
/*  91 */     if (target.exists(flags, false))
/*  92 */       target.deleteResource(true, this.errors); 
/*  93 */     node.setExistsWorkspace(false);
/*     */   } protected void fileToFolder(UnifiedTreeNode node, Resource target) throws CoreException {
/*     */     Folder folder;
/*     */     Resource resource;
/*  97 */     ResourceInfo info = target.getResourceInfo(false, false);
/*  98 */     int flags = target.getFlags(info);
/*  99 */     if (target.exists(flags, true)) {
/* 100 */       folder = (Folder)((File)target).changeToFolder();
/*     */     }
/* 102 */     else if (!folder.exists(flags, false)) {
/* 103 */       resource = (Resource)this.workspace.getRoot().getFolder(folder.getFullPath());
/*     */       
/* 105 */       this.workspace.createResource((IResource)resource, false);
/*     */     } 
/*     */     
/* 108 */     node.setResource((IResource)resource);
/* 109 */     info = resource.getResourceInfo(false, true);
/* 110 */     resource.getLocalManager().updateLocalSync(info, node.getLastModified());
/*     */   } protected void folderToFile(UnifiedTreeNode node, Resource target) throws CoreException {
/*     */     File file;
/*     */     Resource resource;
/* 114 */     ResourceInfo info = target.getResourceInfo(false, false);
/* 115 */     int flags = target.getFlags(info);
/* 116 */     if (target.exists(flags, true)) {
/* 117 */       file = (File)((Folder)target).changeToFile();
/*     */     }
/* 119 */     else if (!file.exists(flags, false)) {
/* 120 */       resource = (Resource)this.workspace.getRoot().getFile(file.getFullPath());
/*     */ 
/*     */       
/* 123 */       this.workspace.createResource((IResource)resource, false);
/*     */     } 
/*     */     
/* 126 */     node.setResource((IResource)resource);
/* 127 */     info = resource.getResourceInfo(false, true);
/* 128 */     resource.getLocalManager().updateLocalSync(info, node.getLastModified());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus getErrorStatus() {
/* 137 */     return (IStatus)this.errors;
/*     */   }
/*     */   
/*     */   protected void makeLocal(UnifiedTreeNode node, Resource target) {
/* 141 */     ResourceInfo info = target.getResourceInfo(false, true);
/* 142 */     if (info != null) {
/* 143 */       target.getLocalManager().updateLocalSync(info, node.getLastModified());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void refresh(Container parent) throws CoreException {
/* 150 */     parent.getLocalManager().refresh((IResource)parent, 0, false, null);
/*     */   }
/*     */   
/*     */   protected void resourceChanged(UnifiedTreeNode node, Resource target) {
/* 154 */     ResourceInfo info = target.getResourceInfo(false, true);
/* 155 */     if (info == null)
/*     */       return; 
/* 157 */     target.getLocalManager().updateLocalSync(info, node.getLastModified());
/* 158 */     info.incrementContentId();
/*     */     
/* 160 */     info.clear(393216);
/* 161 */     this.workspace.updateModificationStamp(info);
/*     */   }
/*     */   
/*     */   public boolean resourcesChanged() {
/* 165 */     return this.resourceChanged;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int synchronizeExistence(UnifiedTreeNode node, Resource target) throws CoreException {
/* 175 */     if (node.existsInWorkspace()) {
/* 176 */       if (!node.existsInFileSystem()) {
/*     */ 
/*     */         
/* 179 */         if (target.isLocal(0) && target.getModificationStamp() != -1L) {
/* 180 */           deleteResource(node, target);
/* 181 */           this.resourceChanged = true;
/* 182 */           return 2;
/*     */         } 
/* 184 */         return 1;
/*     */       } 
/*     */     } else {
/*     */       
/* 188 */       IResource genderVariant = this.workspace.getRoot().findMember(target.getFullPath());
/* 189 */       if (genderVariant != null)
/* 190 */         return 0; 
/* 191 */       if (node.existsInFileSystem()) {
/* 192 */         Container parent = (Container)target.getParent();
/* 193 */         if (!parent.exists()) {
/* 194 */           refresh(parent);
/* 195 */           if (!parent.exists())
/* 196 */             return 2; 
/*     */         } 
/* 198 */         if (!target.getName().equals(node.getLocalName()))
/* 199 */           return 1; 
/* 200 */         if (!Workspace.caseSensitive && node.getLevel() == 0) {
/*     */           
/* 202 */           IResource variant = target.findExistingResourceVariant(target.getFullPath());
/* 203 */           if (variant != null) {
/* 204 */             deleteResource(node, (Resource)variant);
/* 205 */             createResource(node, target);
/* 206 */             this.resourceChanged = true;
/* 207 */             return 2;
/*     */           } 
/*     */         } 
/* 210 */         createResource(node, target);
/* 211 */         this.resourceChanged = true;
/* 212 */         return 2;
/*     */       } 
/*     */     } 
/* 215 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean synchronizeGender(UnifiedTreeNode node, Resource target) throws CoreException {
/* 222 */     if (!node.existsInWorkspace()) {
/*     */       
/* 224 */       IResource genderVariant = this.workspace.getRoot().findMember(target.getFullPath());
/* 225 */       if (genderVariant != null)
/* 226 */         target = (Resource)genderVariant; 
/*     */     } 
/* 228 */     if (target.getType() == 1) {
/* 229 */       if (node.isFolder()) {
/* 230 */         fileToFolder(node, target);
/* 231 */         this.resourceChanged = true;
/* 232 */         return false;
/*     */       }
/*     */     
/* 235 */     } else if (!node.isFolder()) {
/* 236 */       folderToFile(node, target);
/* 237 */       this.resourceChanged = true;
/* 238 */       return false;
/*     */     } 
/*     */     
/* 241 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void synchronizeLastModified(UnifiedTreeNode node, Resource target) {
/* 248 */     if (target.isLocal(0)) {
/* 249 */       resourceChanged(node, target);
/*     */     } else {
/* 251 */       contentAdded(node, target);
/* 252 */     }  this.resourceChanged = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(UnifiedTreeNode node) throws CoreException {
/* 257 */     Policy.checkCanceled((IProgressMonitor)this.monitor);
/*     */     try {
/* 259 */       if (node.isErrorInFileSystem())
/* 260 */         return false; 
/* 261 */       Resource target = (Resource)node.getResource();
/* 262 */       int targetType = target.getType();
/* 263 */       if (targetType == 4)
/* 264 */         return true; 
/* 265 */       if (node.existsInWorkspace() && node.existsInFileSystem()) {
/*     */         
/* 267 */         if (targetType == 2 && node.isFolder()) {
/*     */           
/* 269 */           if (!target.isLocal(0))
/* 270 */             makeLocal(node, target); 
/* 271 */           ResourceInfo info = target.getResourceInfo(false, false);
/* 272 */           if (info != null && info.getModificationStamp() != -1L) {
/* 273 */             return true;
/*     */           }
/*     */         } 
/* 276 */         if (targetType == 1 && !node.isFolder()) {
/* 277 */           ResourceInfo info = target.getResourceInfo(false, false);
/* 278 */           if (info != null && info.getModificationStamp() != -1L && info.getLocalSyncInfo() == node.getLastModified())
/* 279 */             return true; 
/*     */         } 
/*     */       } else {
/* 282 */         if (node.existsInFileSystem() && !Path.EMPTY.isValidSegment(node.getLocalName())) {
/* 283 */           String message = NLS.bind(Messages.resources_invalidResourceName, node.getLocalName());
/* 284 */           this.errors.merge((IStatus)new ResourceStatus(278, message));
/* 285 */           return false;
/*     */         } 
/* 287 */         int state = synchronizeExistence(node, target);
/* 288 */         if (state == 1 || state == 2) {
/* 289 */           if (targetType == 1) {
/*     */             try {
/* 291 */               ((File)target).updateMetadataFiles();
/* 292 */             } catch (CoreException e) {
/* 293 */               this.errors.merge(e.getStatus());
/*     */             } 
/*     */           }
/* 296 */           return true;
/*     */         } 
/*     */       } 
/* 299 */       if (node.isSymbolicLink() && !node.existsInFileSystem()) {
/* 300 */         return true;
/*     */       }
/* 302 */       if (synchronizeGender(node, target))
/* 303 */         synchronizeLastModified(node, target); 
/* 304 */       if (targetType == 1) {
/*     */         try {
/* 306 */           ((File)target).updateMetadataFiles();
/* 307 */         } catch (CoreException e) {
/* 308 */           this.errors.merge(e.getStatus());
/*     */         } 
/*     */       }
/* 311 */       return true;
/*     */     } finally {
/*     */       
/* 314 */       this.monitor.setWorkRemaining(1000).worked(1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\RefreshLocalVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */