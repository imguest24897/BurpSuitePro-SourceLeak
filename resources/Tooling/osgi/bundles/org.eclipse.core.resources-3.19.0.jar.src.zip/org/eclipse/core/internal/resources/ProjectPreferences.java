/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.internal.preferences.EclipsePreferences;
/*     */ import org.eclipse.core.internal.preferences.ExportedPreferences;
/*     */ import org.eclipse.core.internal.preferences.SortedProperties;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IFolder;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceRuleFactory;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.ICoreRunnable;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.MultiRule;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.core.runtime.preferences.IExportedPreferences;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ 
/*     */ public class ProjectPreferences
/*     */   extends EclipsePreferences
/*     */ {
/*     */   static final String PREFS_REGULAR_QUALIFIER = "org.eclipse.core.resources";
/*     */   static final String PREFS_DERIVED_QUALIFIER = "org.eclipse.core.resources.derived";
/*     */   static final String PLACEHOLDER = "<temporary_value_placeholder>";
/*  52 */   protected static Set<String> loadedNodes = Collections.synchronizedSet(new HashSet<>());
/*     */   
/*     */   private IFile file;
/*     */   
/*     */   private boolean initialized = false;
/*     */   
/*     */   private boolean isReading;
/*     */   
/*     */   private boolean isWriting;
/*     */   
/*     */   private IEclipsePreferences loadLevel;
/*     */   
/*     */   private IProject project;
/*     */   
/*     */   private String qualifier;
/*     */   
/*     */   private int segmentCount;
/*     */   
/*     */   private Workspace workspace;
/*     */ 
/*     */   
/*     */   static void deleted(IFile file) throws CoreException {
/*  74 */     IPath path = file.getFullPath();
/*  75 */     int count = path.segmentCount();
/*  76 */     if (count != 3) {
/*     */       return;
/*     */     }
/*  79 */     if (!".settings".equals(path.segment(1)))
/*     */       return; 
/*  81 */     IEclipsePreferences iEclipsePreferences = Platform.getPreferencesService().getRootNode();
/*  82 */     String project = path.segment(0);
/*  83 */     String qualifier = path.removeFileExtension().lastSegment();
/*  84 */     ProjectPreferences projectNode = (ProjectPreferences)iEclipsePreferences.node("project").node(project);
/*     */     
/*     */     try {
/*  87 */       if (!projectNode.nodeExists(qualifier))
/*     */         return; 
/*  89 */     } catch (BackingStoreException backingStoreException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     clearNode(projectNode.node(qualifier));
/*     */ 
/*     */     
/*  97 */     if (qualifier.equals("org.eclipse.core.resources") || qualifier.equals("org.eclipse.core.resources.derived"))
/*  98 */       preferencesChanged(file.getProject()); 
/*     */   }
/*     */   
/*     */   static void deleted(IFolder folder) throws CoreException {
/* 102 */     IPath path = folder.getFullPath();
/* 103 */     int count = path.segmentCount();
/* 104 */     if (count != 2) {
/*     */       return;
/*     */     }
/* 107 */     if (!".settings".equals(path.segment(1)))
/*     */       return; 
/* 109 */     IEclipsePreferences iEclipsePreferences = Platform.getPreferencesService().getRootNode();
/*     */ 
/*     */     
/* 112 */     String project = path.segment(0);
/* 113 */     Preferences projectNode = iEclipsePreferences.node("project").node(project);
/*     */     
/* 115 */     boolean hasResourcesSettings = !(!getFile(folder, "org.eclipse.core.resources").exists() && !getFile(folder, "org.eclipse.core.resources.derived").exists());
/*     */     
/* 117 */     removeNode(projectNode);
/*     */     
/* 119 */     if (hasResourcesSettings) {
/* 120 */       preferencesChanged(folder.getProject());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void deleted(IProject project) throws CoreException {
/* 131 */     IEclipsePreferences iEclipsePreferences = Platform.getPreferencesService().getRootNode();
/* 132 */     Preferences projectNode = iEclipsePreferences.node("project").node(project.getName());
/*     */     
/* 134 */     boolean hasResourcesSettings = !(!getFile(project, "org.eclipse.core.resources").exists() && !getFile(project, "org.eclipse.core.resources.derived").exists());
/*     */     
/* 136 */     removeNode(projectNode);
/*     */     
/* 138 */     if (hasResourcesSettings)
/* 139 */       preferencesChanged(project); 
/*     */   }
/*     */   
/*     */   static void deleted(IResource resource) throws CoreException {
/* 143 */     switch (resource.getType()) {
/*     */       case 1:
/* 145 */         deleted((IFile)resource);
/*     */         return;
/*     */       case 2:
/* 148 */         deleted((IFolder)resource);
/*     */         return;
/*     */       case 4:
/* 151 */         deleted((IProject)resource);
/*     */         return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static IFile getFile(IFolder folder, String qualifier) {
/* 160 */     Assert.isLegal(folder.getName().equals(".settings"));
/* 161 */     return folder.getFile((new Path(qualifier)).addFileExtension("prefs"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static IFile getFile(IProject project, String qualifier) {
/* 168 */     return project.getFile((new Path(".settings")).append(qualifier).addFileExtension("prefs"));
/*     */   }
/*     */   
/*     */   private static Properties loadProperties(IFile file) throws BackingStoreException {
/* 172 */     if (Policy.DEBUG_PREFERENCES)
/* 173 */       Policy.debug("Loading preferences from file: " + file.getFullPath()); 
/* 174 */     Properties result = new Properties(); try {
/* 175 */       Exception exception2, exception1 = null;
/*     */ 
/*     */     
/*     */     }
/* 179 */     catch (CoreException e) {
/* 180 */       if (e.getStatus().getCode() == 368) {
/* 181 */         if (Policy.DEBUG_PREFERENCES)
/* 182 */           Policy.debug(MessageFormat.format("Preference file {0} does not exist.", new Object[] { file.getFullPath() })); 
/*     */       } else {
/* 184 */         String message = NLS.bind(Messages.preferences_loadException, file.getFullPath());
/* 185 */         log((IStatus)new Status(4, "org.eclipse.core.resources", 4, message, (Throwable)e));
/* 186 */         throw new BackingStoreException(message);
/*     */       } 
/* 188 */     } catch (IOException e) {
/* 189 */       String message = NLS.bind(Messages.preferences_loadException, file.getFullPath());
/* 190 */       log((IStatus)new Status(4, "org.eclipse.core.resources", 4, message, e));
/* 191 */       throw new BackingStoreException(message);
/*     */     } 
/* 193 */     return result;
/*     */   }
/*     */   
/*     */   private static void preferencesChanged(IProject project) {
/* 197 */     Workspace workspace = (Workspace)project.getWorkspace();
/* 198 */     workspace.getCharsetManager().projectPreferencesChanged(project);
/* 199 */     workspace.getContentDescriptionManager().projectPreferencesChanged(project);
/*     */   }
/*     */   
/*     */   private static void read(ProjectPreferences node, IFile file) throws BackingStoreException, CoreException {
/* 203 */     if (file == null || !file.exists()) {
/* 204 */       if (Policy.DEBUG_PREFERENCES) {
/* 205 */         Policy.debug("Unable to determine preference file or file does not exist for node: " + node.absolutePath());
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 210 */     ExportedPreferences myNode = overridingPreferences(node, file);
/*     */ 
/*     */     
/* 213 */     boolean oldIsReading = node.isReading;
/* 214 */     node.isReading = true;
/*     */     try {
/* 216 */       Platform.getPreferencesService().applyPreferences((IExportedPreferences)myNode);
/*     */     } finally {
/* 218 */       node.isReading = oldIsReading;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ExportedPreferences overridingPreferences(ProjectPreferences current, IFile file) throws BackingStoreException {
/* 234 */     Properties fromDisk = loadProperties(file);
/*     */     
/* 236 */     Properties fromMemory = new Properties();
/* 237 */     current.convertToProperties(fromMemory, "");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 242 */     Set<Map.Entry<Object, Object>> set = fromMemory.entrySet();
/* 243 */     for (Map.Entry<Object, Object> entry : set) {
/* 244 */       String key = (String)entry.getKey();
/*     */       
/* 246 */       if (!fromDisk.containsKey(key))
/*     */       {
/* 248 */         if (key.indexOf('/') > 0) {
/* 249 */           fromDisk.put(key, "<temporary_value_placeholder>");
/*     */         }
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 255 */     ExportedPreferences myNode = (ExportedPreferences)ExportedPreferences.newRoot().node(current.absolutePath());
/* 256 */     convertFromProperties((EclipsePreferences)myNode, fromDisk, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 262 */     myNode.accept(child -> {
/*     */           String[] keys = child.keys();
/*     */           boolean nodeShouldBeRemoved = false;
/*     */           String[] arrayOfString1;
/*     */           int i = (arrayOfString1 = keys).length;
/*     */           for (byte b = 0; b < i; b++) {
/*     */             String key = arrayOfString1[b];
/*     */             if ("<temporary_value_placeholder>".equals(child.get(key, null))) {
/*     */               child.remove(key);
/*     */               nodeShouldBeRemoved = true;
/*     */             } 
/*     */           } 
/*     */           if (child != paramExportedPreferences && nodeShouldBeRemoved) {
/*     */             ((ExportedPreferences)child).setExportRoot();
/*     */           }
/*     */           return true;
/*     */         });
/* 279 */     return myNode;
/*     */   }
/*     */   
/*     */   static void removeNode(Preferences node) throws CoreException {
/* 283 */     String message = NLS.bind(Messages.preferences_removeNodeException, node.absolutePath());
/*     */     try {
/* 285 */       node.removeNode();
/* 286 */     } catch (BackingStoreException e) {
/* 287 */       Status status = new Status(4, "org.eclipse.core.resources", 4, message, (Throwable)e);
/* 288 */       throw new CoreException(status);
/*     */     } 
/* 290 */     removeLoadedNodes(node);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void clearNode(Preferences node) throws CoreException {
/*     */     try {
/* 297 */       clearAll(node);
/* 298 */     } catch (BackingStoreException e) {
/* 299 */       String message = NLS.bind(Messages.preferences_clearNodeException, node.absolutePath());
/* 300 */       Status status = new Status(4, "org.eclipse.core.resources", 4, message, (Throwable)e);
/* 301 */       throw new CoreException(status);
/*     */     } 
/* 303 */     removeLoadedNodes(node);
/*     */   }
/*     */   
/*     */   private static void clearAll(Preferences node) throws BackingStoreException {
/* 307 */     node.clear();
/* 308 */     String[] names = node.childrenNames(); byte b; int i; String[] arrayOfString1;
/* 309 */     for (i = (arrayOfString1 = names).length, b = 0; b < i; ) { String name2 = arrayOfString1[b];
/* 310 */       clearAll(node.node(name2));
/*     */       b++; }
/*     */   
/*     */   }
/*     */   private static void removeLoadedNodes(Preferences node) {
/* 315 */     String path = node.absolutePath();
/* 316 */     synchronized (loadedNodes) {
/* 317 */       for (Iterator<String> i = loadedNodes.iterator(); i.hasNext(); ) {
/* 318 */         String key = i.next();
/* 319 */         if (key.startsWith(path))
/* 320 */           i.remove(); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void updatePreferences(IFile file) throws CoreException {
/* 326 */     IPath path = file.getFullPath();
/*     */ 
/*     */     
/* 329 */     if (!"prefs".equals(path.getFileExtension())) {
/*     */       return;
/*     */     }
/* 332 */     String project = path.segment(0);
/* 333 */     String qualifier = path.removeFileExtension().lastSegment();
/* 334 */     IEclipsePreferences iEclipsePreferences = Platform.getPreferencesService().getRootNode();
/* 335 */     Preferences node = iEclipsePreferences.node("project").node(project).node(qualifier);
/* 336 */     String message = null;
/*     */     try {
/* 338 */       message = NLS.bind(Messages.preferences_syncException, node.absolutePath());
/* 339 */       if (!(node instanceof ProjectPreferences))
/*     */         return; 
/* 341 */       ProjectPreferences projectPrefs = (ProjectPreferences)node;
/* 342 */       if (projectPrefs.isWriting)
/*     */         return; 
/* 344 */       read(projectPrefs, file);
/*     */ 
/*     */ 
/*     */       
/* 348 */       projectPrefs.dirty = false;
/*     */ 
/*     */ 
/*     */       
/* 352 */       if ("org.eclipse.core.resources".equals(qualifier) || "org.eclipse.core.resources.derived".equals(qualifier))
/* 353 */         preferencesChanged(file.getProject()); 
/* 354 */     } catch (BackingStoreException e) {
/* 355 */       Status status = new Status(4, "org.eclipse.core.resources", 4, message, (Throwable)e);
/* 356 */       throw new CoreException(status);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProjectPreferences() {
/* 364 */     super(null, null);
/*     */   }
/*     */   
/*     */   private ProjectPreferences(EclipsePreferences parent, String name, Workspace workspace) {
/* 368 */     super(parent, name);
/* 369 */     setWorkspace(workspace);
/*     */ 
/*     */     
/* 372 */     String path = absolutePath();
/* 373 */     this.segmentCount = getSegmentCount(path);
/*     */     
/* 375 */     if (this.segmentCount == 1) {
/*     */       return;
/*     */     }
/*     */     
/* 379 */     String projectName = getSegment(path, 1);
/* 380 */     if (projectName != null) {
/* 381 */       this.project = getWorkspace().getRoot().getProject(projectName);
/*     */     }
/*     */     
/* 384 */     if (this.segmentCount > 2) {
/* 385 */       this.qualifier = getSegment(path, 2);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] childrenNames() throws BackingStoreException {
/* 391 */     checkRemoved();
/* 392 */     initialize();
/* 393 */     silentLoad();
/* 394 */     return super.childrenNames();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 400 */     checkRemoved();
/* 401 */     silentLoad();
/* 402 */     super.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<String> computeChildren() {
/* 410 */     if (this.project == null) {
/* 411 */       return List.of();
/*     */     }
/* 413 */     IFolder folder = this.project.getFolder(".settings");
/* 414 */     if (!folder.exists()) {
/* 415 */       return List.of();
/*     */     }
/* 417 */     IResource[] members = null;
/*     */     try {
/* 419 */       members = folder.members();
/* 420 */     } catch (CoreException coreException) {
/* 421 */       return List.of();
/*     */     } 
/* 423 */     List<String> result = new ArrayList<>(); byte b; int i; IResource[] arrayOfIResource1;
/* 424 */     for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource resource = arrayOfIResource1[b];
/* 425 */       if (resource.getType() == 1 && "prefs".equals(resource.getFullPath().getFileExtension()))
/* 426 */         result.add(resource.getFullPath().removeFileExtension().lastSegment());  b++; }
/*     */     
/* 428 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() throws BackingStoreException {
/* 433 */     if (this.isReading)
/*     */       return; 
/* 435 */     this.isWriting = true;
/*     */     
/*     */     try {
/* 438 */       IEclipsePreferences toFlush = internalFlush();
/*     */       
/* 440 */       if (toFlush != null)
/* 441 */         toFlush.flush(); 
/*     */     } finally {
/* 443 */       this.isWriting = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private IFile getFile() {
/* 448 */     if (this.file == null) {
/* 449 */       if (this.project == null || this.qualifier == null)
/* 450 */         return null; 
/* 451 */       this.file = getFile(this.project, this.qualifier);
/*     */     } 
/* 453 */     return this.file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IEclipsePreferences getLoadLevel() {
/* 461 */     if (this.loadLevel == null) {
/* 462 */       if (this.project == null || this.qualifier == null) {
/* 463 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 467 */       EclipsePreferences node = this;
/* 468 */       for (int i = 3; i < this.segmentCount; i++)
/* 469 */         node = (EclipsePreferences)node.parent(); 
/* 470 */       this.loadLevel = (IEclipsePreferences)node;
/*     */     } 
/* 472 */     return this.loadLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IPath getLocation() {
/* 485 */     if (this.project == null || this.qualifier == null)
/* 486 */       return null; 
/* 487 */     IPath path = this.project.getLocation();
/* 488 */     return computeLocation(path, this.qualifier);
/*     */   }
/*     */ 
/*     */   
/*     */   protected EclipsePreferences internalCreate(EclipsePreferences nodeParent, String nodeName, Object context) {
/* 493 */     return new ProjectPreferences(nodeParent, nodeName, this.workspace);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String internalGet(String key) {
/* 499 */     if (key == null) {
/* 500 */       throw new NullPointerException();
/*     */     }
/* 502 */     checkRemoved();
/* 503 */     silentLoad();
/* 504 */     return super.internalGet(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String internalPut(String key, String newValue) {
/* 510 */     checkRemoved();
/* 511 */     silentLoad();
/* 512 */     if (this.segmentCount == 3 && "org.eclipse.core.resources".equals(this.qualifier) && this.project != null && 
/* 513 */       "separateDerivedEncodings".equals(key)) {
/* 514 */       CharsetManager charsetManager = getWorkspace().getCharsetManager();
/* 515 */       if (Boolean.parseBoolean(newValue)) {
/* 516 */         charsetManager.splitEncodingPreferences(this.project);
/*     */       } else {
/* 518 */         charsetManager.mergeEncodingPreferences(this.project);
/*     */       } 
/*     */     } 
/* 521 */     return super.internalPut(key, newValue);
/*     */   }
/*     */   
/*     */   private void initialize() {
/* 525 */     if (this.segmentCount != 2) {
/*     */       return;
/*     */     }
/*     */     
/* 529 */     if (this.initialized) {
/*     */       return;
/*     */     }
/*     */     
/* 533 */     if (this.project.isOpen()) {
/*     */       try {
/* 535 */         synchronized (this) {
/* 536 */           Set<String> addedNames = Set.of(internalChildNames());
/*     */           
/* 538 */           for (String child : computeChildren()) {
/* 539 */             if (!addedNames.contains(child)) {
/* 540 */               addChild(child, null);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } finally {
/*     */         
/* 546 */         this.initialized = true;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isAlreadyLoaded(IEclipsePreferences node) {
/* 553 */     return loadedNodes.contains(node.absolutePath());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] keys() {
/* 559 */     checkRemoved();
/* 560 */     silentLoad();
/* 561 */     return super.keys();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void load() throws BackingStoreException {
/* 566 */     load(true);
/*     */   }
/*     */   
/*     */   private void load(boolean reportProblems) throws BackingStoreException {
/* 570 */     IFile localFile = getFile();
/* 571 */     if (localFile == null || !localFile.exists()) {
/* 572 */       if (Policy.DEBUG_PREFERENCES)
/* 573 */         Policy.debug("Unable to determine preference file or file does not exist for node: " + absolutePath()); 
/*     */       return;
/*     */     } 
/* 576 */     if (Policy.DEBUG_PREFERENCES)
/* 577 */       Policy.debug("Loading preferences from file: " + localFile.getFullPath()); 
/* 578 */     Properties fromDisk = new Properties(); try {
/* 579 */       Exception exception2, exception1 = null;
/*     */ 
/*     */     
/*     */     }
/* 583 */     catch (CoreException e) {
/* 584 */       if (e.getStatus().getCode() == 368) {
/* 585 */         if (Policy.DEBUG_PREFERENCES)
/* 586 */           Policy.debug("Preference file does not exist for node: " + absolutePath()); 
/*     */         return;
/*     */       } 
/* 589 */       if (reportProblems) {
/* 590 */         String message = NLS.bind(Messages.preferences_loadException, localFile.getFullPath());
/* 591 */         log((IStatus)new Status(4, "org.eclipse.core.resources", 4, message, (Throwable)e));
/* 592 */         throw new BackingStoreException(message);
/*     */       } 
/* 594 */     } catch (IOException e) {
/* 595 */       if (reportProblems) {
/* 596 */         String message = NLS.bind(Messages.preferences_loadException, localFile.getFullPath());
/* 597 */         log((IStatus)new Status(4, "org.eclipse.core.resources", 4, message, e));
/* 598 */         throw new BackingStoreException(message);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean nodeExists(String path) throws BackingStoreException {
/* 611 */     if (path.length() == 0) {
/* 612 */       return !this.removed;
/*     */     }
/*     */     
/* 615 */     checkRemoved();
/* 616 */     initialize();
/* 617 */     silentLoad();
/* 618 */     if (this.segmentCount != 1)
/* 619 */       return super.nodeExists(path); 
/* 620 */     if (path.length() == 0)
/* 621 */       return super.nodeExists(path); 
/* 622 */     if (path.charAt(0) == '/')
/* 623 */       return super.nodeExists(path); 
/* 624 */     if (path.indexOf('/') != -1) {
/* 625 */       return super.nodeExists(path);
/*     */     }
/*     */     
/* 628 */     return !(!getWorkspace().getRoot().getProject(path).exists() && !super.nodeExists(path));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(String key) {
/* 634 */     checkRemoved();
/* 635 */     silentLoad();
/* 636 */     super.remove(key);
/* 637 */     if (this.segmentCount == 3 && "org.eclipse.core.resources".equals(this.qualifier) && this.project != null && 
/* 638 */       "separateDerivedEncodings".equals(key)) {
/* 639 */       CharsetManager charsetManager = getWorkspace().getCharsetManager();
/*     */ 
/*     */ 
/*     */       
/* 643 */       charsetManager.mergeEncodingPreferences(this.project);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void save() throws BackingStoreException {
/* 650 */     IFile fileInWorkspace = getFile();
/* 651 */     if (fileInWorkspace == null) {
/* 652 */       if (Policy.DEBUG_PREFERENCES)
/* 653 */         Policy.debug("Not saving preferences since there is no file for node: " + absolutePath()); 
/*     */       return;
/*     */     } 
/* 656 */     String finalQualifier = this.qualifier;
/* 657 */     BackingStoreException[] bse = new BackingStoreException[1];
/*     */     try {
/* 659 */       ICoreRunnable operation = monitor -> {
/*     */           try {
/*     */             Properties table = convertToProperties((Properties)new SortedProperties(), "");
/*     */             if (table.isEmpty()) {
/*     */               if (paramIFile.exists()) {
/*     */                 if (Policy.DEBUG_PREFERENCES) {
/*     */                   Policy.debug("Deleting preference file: " + paramIFile.getFullPath());
/*     */                 }
/*     */                 if (paramIFile.isReadOnly()) {
/*     */                   IStatus status1 = paramIFile.getWorkspace().validateEdit(new IFile[] { paramIFile }, IWorkspace.VALIDATE_PROMPT);
/*     */                   if (!status1.isOK())
/*     */                     throw new CoreException(status1); 
/*     */                 } 
/*     */                 try {
/*     */                   paramIFile.delete(true, null);
/* 674 */                 } catch (CoreException coreException) {
/*     */                   String message1 = NLS.bind(Messages.preferences_deleteException, paramIFile.getFullPath());
/*     */                   log((IStatus)new Status(2, "org.eclipse.core.resources", 2, message1, null));
/*     */                 } 
/*     */               } 
/*     */               return;
/*     */             } 
/*     */             table.put("eclipse.preferences.version", "1");
/*     */             String s = removeTimestampFromTable(table);
/*     */             String systemLineSeparator = System.lineSeparator();
/*     */             String fileLineSeparator = paramIFile.getLineSeparator(true);
/*     */             if (!systemLineSeparator.equals(fileLineSeparator)) {
/*     */               s = s.replaceAll(systemLineSeparator, fileLineSeparator);
/*     */             }
/*     */             InputStream input = new ByteArrayInputStream(s.getBytes(StandardCharsets.UTF_8));
/*     */             paramIFile.getParent().refreshLocal(0, null);
/*     */             paramIFile.refreshLocal(0, null);
/*     */             if (paramIFile.exists()) {
/*     */               if (Policy.DEBUG_PREFERENCES) {
/*     */                 Policy.debug("Setting preference file contents for: " + paramIFile.getFullPath());
/*     */               }
/*     */               if (paramIFile.isReadOnly()) {
/*     */                 IStatus status2 = paramIFile.getWorkspace().validateEdit(new IFile[] { paramIFile }, IWorkspace.VALIDATE_PROMPT);
/*     */                 if (!status2.isOK()) {
/*     */                   throw new CoreException(status2);
/*     */                 }
/*     */               } 
/*     */               paramIFile.setContents(input, 2, null);
/*     */             } else {
/*     */               IFolder folder = (IFolder)paramIFile.getParent();
/*     */               if (!folder.exists()) {
/*     */                 if (Policy.DEBUG_PREFERENCES) {
/*     */                   Policy.debug("Creating parent preference directory: " + folder.getFullPath());
/*     */                 }
/*     */                 folder.create(0, true, null);
/*     */               } 
/*     */               if (Policy.DEBUG_PREFERENCES) {
/*     */                 Policy.debug("Creating preference file: " + paramIFile.getLocation());
/*     */               }
/*     */               paramIFile.create(input, 0, null);
/*     */             } 
/*     */             if ("org.eclipse.core.resources.derived".equals(paramString))
/*     */               paramIFile.setDerived(true, null); 
/* 717 */           } catch (BackingStoreException e2) {
/*     */             paramArrayOfBackingStoreException[0] = e2;
/* 719 */           } catch (IOException e3) {
/*     */             String message2 = NLS.bind(Messages.preferences_saveProblems, paramIFile.getFullPath());
/*     */             
/*     */             log((IStatus)new Status(4, "org.eclipse.core.resources", 4, message2, e3));
/*     */             paramArrayOfBackingStoreException[0] = new BackingStoreException(message2);
/*     */           } 
/*     */         };
/*     */       try {
/* 727 */         Workspace workspace = getWorkspace();
/* 728 */         if (workspace.getWorkManager().isLockAlreadyAcquired()) {
/* 729 */           operation.run(null);
/*     */         } else {
/* 731 */           IResourceRuleFactory factory = workspace.getRuleFactory();
/*     */           
/* 733 */           ISchedulingRule rule = MultiRule.combine(new ISchedulingRule[] { factory.deleteRule((IResource)fileInWorkspace), factory.createRule((IResource)fileInWorkspace.getParent()), factory.modifyRule((IResource)fileInWorkspace), factory.derivedRule((IResource)fileInWorkspace) });
/* 734 */           workspace.run(operation, rule, 0, (IProgressMonitor)null);
/* 735 */           if (bse[0] != null)
/* 736 */             throw bse[0]; 
/*     */         } 
/* 738 */       } catch (OperationCanceledException operationCanceledException) {
/* 739 */         throw new BackingStoreException(Messages.preferences_operationCanceled);
/*     */       } 
/* 741 */     } catch (CoreException e) {
/* 742 */       String message = NLS.bind(Messages.preferences_saveProblems, fileInWorkspace.getFullPath());
/* 743 */       log((IStatus)new Status(4, "org.eclipse.core.resources", 4, message, (Throwable)e));
/* 744 */       throw new BackingStoreException(message);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void silentLoad() {
/* 749 */     ProjectPreferences node = (ProjectPreferences)getLoadLevel();
/* 750 */     if (node == null)
/*     */       return; 
/* 752 */     if (isAlreadyLoaded((IEclipsePreferences)node) || node.isLoading())
/*     */       return; 
/*     */     try {
/* 755 */       node.setLoading(true);
/* 756 */       node.load(false);
/* 757 */     } catch (BackingStoreException backingStoreException) {
/*     */     
/*     */     } finally {
/* 760 */       node.setLoading(false);
/*     */     } 
/*     */   }
/*     */   
/*     */   void setWorkspace(Workspace workspace) {
/* 765 */     this.workspace = workspace;
/*     */   }
/*     */   
/*     */   private Workspace getWorkspace() {
/* 769 */     if (this.workspace != null) {
/* 770 */       return this.workspace;
/*     */     }
/*     */     
/* 773 */     return (Workspace)ResourcesPlugin.getWorkspace();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ProjectPreferences.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */