/*     */ package org.eclipse.core.resources.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import org.eclipse.core.internal.resources.MarkerManager;
/*     */ import org.eclipse.core.internal.resources.Workspace;
/*     */ import org.eclipse.core.resources.IMarker;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceVisitor;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceTraversal
/*     */ {
/*     */   private final int depth;
/*     */   private final int flags;
/*     */   private final IResource[] resources;
/*     */   
/*     */   public ResourceTraversal(IResource[] resources, int depth, int flags) {
/*  54 */     if (resources == null)
/*  55 */       throw new NullPointerException(); 
/*  56 */     this.resources = resources;
/*  57 */     this.depth = depth;
/*  58 */     this.flags = flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(IResourceVisitor visitor) throws CoreException {
/*     */     byte b;
/*     */     int i;
/*     */     IResource[] arrayOfIResource;
/*  71 */     for (i = (arrayOfIResource = this.resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/*     */       try {
/*  73 */         if (resource.exists())
/*  74 */           resource.accept(visitor, this.depth, this.flags); 
/*  75 */       } catch (CoreException e) {
/*     */         
/*  77 */         if (e.getStatus().getCode() != 368) {
/*  78 */           throw e;
/*     */         }
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(IResource resource) {
/*     */     byte b;
/*     */     int i;
/*     */     IResource[] arrayOfIResource;
/*  92 */     for (i = (arrayOfIResource = this.resources).length, b = 0; b < i; ) { IResource member = arrayOfIResource[b];
/*  93 */       if (contains(member, resource))
/*  94 */         return true; 
/*     */       b++; }
/*     */     
/*  97 */     return false;
/*     */   }
/*     */   
/*     */   private boolean contains(IResource resource, IResource child) {
/* 101 */     if (resource.equals(child))
/* 102 */       return true; 
/* 103 */     if (this.depth == 0)
/* 104 */       return false; 
/* 105 */     if (child.getParent().equals(resource))
/* 106 */       return true; 
/* 107 */     if (this.depth == 2)
/* 108 */       return resource.getFullPath().isPrefixOf(child.getFullPath()); 
/* 109 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doFindMarkers(ArrayList<IMarker> result, String type, boolean includeSubtypes) {
/* 118 */     MarkerManager markerMan = ((Workspace)ResourcesPlugin.getWorkspace()).getMarkerManager(); byte b; int i; IResource[] arrayOfIResource;
/* 119 */     for (i = (arrayOfIResource = this.resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/* 120 */       markerMan.doFindMarkers(resource, result, type, includeSubtypes, this.depth);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMarker[] findMarkers(String type, boolean includeSubtypes) throws CoreException {
/* 136 */     if (this.resources.length == 0)
/* 137 */       return new IMarker[0]; 
/* 138 */     ArrayList<IMarker> result = new ArrayList<>();
/* 139 */     doFindMarkers(result, type, includeSubtypes);
/* 140 */     return result.<IMarker>toArray(new IMarker[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDepth() {
/* 151 */     return this.depth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFlags() {
/* 166 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource[] getResources() {
/* 183 */     return this.resources;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\mapping\ResourceTraversal.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */