package org.eclipse.core.resources;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IContainer extends IResource, IAdaptable {
  public static final int INCLUDE_PHANTOMS = 1;
  
  public static final int INCLUDE_TEAM_PRIVATE_MEMBERS = 2;
  
  public static final int EXCLUDE_DERIVED = 4;
  
  public static final int INCLUDE_HIDDEN = 8;
  
  public static final int DO_NOT_CHECK_EXISTENCE = 16;
  
  boolean exists(IPath paramIPath);
  
  IResource findMember(String paramString);
  
  IResource findMember(String paramString, boolean paramBoolean);
  
  IResource findMember(IPath paramIPath);
  
  IResource findMember(IPath paramIPath, boolean paramBoolean);
  
  String getDefaultCharset() throws CoreException;
  
  String getDefaultCharset(boolean paramBoolean) throws CoreException;
  
  IFile getFile(IPath paramIPath);
  
  IFolder getFolder(IPath paramIPath);
  
  IResource[] members() throws CoreException;
  
  IResource[] members(boolean paramBoolean) throws CoreException;
  
  IResource[] members(int paramInt) throws CoreException;
  
  IFile[] findDeletedMembersWithHistory(int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  @Deprecated
  void setDefaultCharset(String paramString) throws CoreException;
  
  void setDefaultCharset(String paramString, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  IResourceFilterDescription createFilter(int paramInt1, FileInfoMatcherDescription paramFileInfoMatcherDescription, int paramInt2, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  IResourceFilterDescription[] getFilters() throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */