/*    */ package org.eclipse.core.internal.localstore;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HistoryCopyVisitor
/*    */   extends Bucket.Visitor
/*    */ {
/* 30 */   private List<HistoryBucket.HistoryEntry> changes = new ArrayList<>();
/*    */   private IPath destination;
/*    */   private IPath source;
/*    */   
/*    */   public HistoryCopyVisitor(IPath source, IPath destination) {
/* 35 */     this.source = source;
/* 36 */     this.destination = destination;
/*    */   }
/*    */ 
/*    */   
/*    */   public void afterSaving(Bucket bucket) throws CoreException {
/* 41 */     saveChanges();
/* 42 */     this.changes.clear();
/*    */   }
/*    */   
/*    */   private void saveChanges() throws CoreException {
/* 46 */     if (this.changes.isEmpty()) {
/*    */       return;
/*    */     }
/* 49 */     Iterator<HistoryBucket.HistoryEntry> i = this.changes.iterator();
/* 50 */     HistoryBucket.HistoryEntry entry = i.next();
/* 51 */     HistoryStore2.this.tree.loadBucketFor(entry.getPath());
/* 52 */     HistoryBucket bucket = (HistoryBucket)HistoryStore2.this.tree.getCurrent();
/* 53 */     bucket.addBlobs(entry);
/* 54 */     while (i.hasNext())
/* 55 */       bucket.addBlobs(i.next()); 
/* 56 */     bucket.save();
/*    */   }
/*    */ 
/*    */   
/*    */   public int visit(Bucket.Entry sourceEntry) {
/* 61 */     IPath destinationPath = this.destination.append(sourceEntry.getPath().removeFirstSegments(this.source.segmentCount()));
/* 62 */     HistoryBucket.HistoryEntry destinationEntry = new HistoryBucket.HistoryEntry(destinationPath, (HistoryBucket.HistoryEntry)sourceEntry);
/*    */ 
/*    */     
/* 65 */     this.changes.add(destinationEntry);
/* 66 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\HistoryStore2$HistoryCopyVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */