/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.IOException;
/*    */ import org.eclipse.core.internal.utils.Messages;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MarkerReader
/*    */ {
/*    */   protected Workspace workspace;
/*    */   
/*    */   public MarkerReader(Workspace workspace) {
/* 32 */     this.workspace = workspace;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MarkerReader getReader(int formatVersion) throws IOException {
/* 39 */     switch (formatVersion) {
/*    */       case 1:
/* 41 */         return new MarkerReader_1(this.workspace);
/*    */       case 2:
/* 43 */         return new MarkerReader_2(this.workspace);
/*    */       case 3:
/* 45 */         return new MarkerReader_3(this.workspace);
/*    */     } 
/* 47 */     throw new IOException(NLS.bind(Messages.resources_format, Integer.valueOf(formatVersion)));
/*    */   }
/*    */ 
/*    */   
/*    */   public void read(DataInputStream input, boolean generateDeltas) throws IOException, CoreException {
/* 52 */     int formatVersion = readVersionNumber(input);
/* 53 */     MarkerReader reader = getReader(formatVersion);
/* 54 */     reader.read(input, generateDeltas);
/*    */   }
/*    */   
/*    */   protected static int readVersionNumber(DataInputStream input) throws IOException {
/* 58 */     return input.readInt();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\MarkerReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */