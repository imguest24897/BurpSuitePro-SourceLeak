/*    */ package org.eclipse.core.internal.resources.projectvariables;
/*    */ 
/*    */ import java.net.URISyntaxException;
/*    */ import java.net.URL;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.variableresolvers.PathVariableResolver;
/*    */ import org.eclipse.core.runtime.Platform;
/*    */ import org.eclipse.core.runtime.URIUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EclipseHomeProjectVariable
/*    */   extends PathVariableResolver
/*    */ {
/* 30 */   public static String NAME = "ECLIPSE_HOME";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getVariableNames(String variable, IResource resource) {
/* 38 */     return new String[] { NAME };
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue(String variable, IResource resource) {
/* 43 */     URL installURL = Platform.getInstallLocation().getURL();
/*    */     try {
/* 45 */       return URIUtil.toURI(installURL).toASCIIString();
/* 46 */     } catch (URISyntaxException uRISyntaxException) {
/* 47 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\projectvariables\EclipseHomeProjectVariable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */