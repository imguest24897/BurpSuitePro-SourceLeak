package org.eclipse.core.internal.properties;

import java.util.Map;
import org.eclipse.core.internal.resources.IManager;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.QualifiedName;

public interface IPropertyManager extends IManager {
  void closePropertyStore(IResource paramIResource) throws CoreException;
  
  void copy(IResource paramIResource1, IResource paramIResource2, int paramInt) throws CoreException;
  
  void deleteProperties(IResource paramIResource, int paramInt) throws CoreException;
  
  void deleteResource(IResource paramIResource) throws CoreException;
  
  String getProperty(IResource paramIResource, QualifiedName paramQualifiedName) throws CoreException;
  
  void setProperty(IResource paramIResource, QualifiedName paramQualifiedName, String paramString) throws CoreException;
  
  Map<QualifiedName, String> getProperties(IResource paramIResource) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\properties\IPropertyManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */