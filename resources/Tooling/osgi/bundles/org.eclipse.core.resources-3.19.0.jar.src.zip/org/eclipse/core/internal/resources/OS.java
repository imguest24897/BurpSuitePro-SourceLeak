/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import org.eclipse.core.runtime.Platform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class OS
/*    */ {
/* 33 */   private static final String INSTALLED_PLATFORM = Platform.getOS(); static {
/* 34 */     if (INSTALLED_PLATFORM.equals("win32")) {
/*    */       
/* 36 */       INVALID_RESOURCE_CHARACTERS = new char[] { '\\', '/', ':', '*', '?', '"', '<', '>', '|', 
/*    */ 
/*    */           
/* 39 */           '\001', '\002', '\003', '\004', '\005', '\006', '\007', '\b', '\t', 
/* 40 */           '\n', '\013', '\f', '\r', '\016', '\017', 
/* 41 */           '\020', '\021', '\022', '\023', '\024', '\025', '\026', '\027', '\030', '\031', 
/* 42 */           '\032', '\033', '\034', '\035', '\036', '\037' };
/* 43 */       INVALID_RESOURCE_BASENAMES = new String[] { "aux", "com1", "com2", "com3", "com4", 
/* 44 */           "com5", "com6", "com7", "com8", "com9", "con", "lpt1", "lpt2", 
/* 45 */           "lpt3", "lpt4", "lpt5", "lpt6", "lpt7", "lpt8", "lpt9", "nul", "prn" };
/* 46 */       Arrays.sort((Object[])INVALID_RESOURCE_BASENAMES);
/*    */       
/* 48 */       INVALID_RESOURCE_FULLNAMES = new String[] { "clock$" };
/*    */     }
/*    */     else {
/*    */       
/* 52 */       INVALID_RESOURCE_CHARACTERS = new char[] { '/' };
/* 53 */       INVALID_RESOURCE_BASENAMES = null;
/* 54 */       INVALID_RESOURCE_FULLNAMES = null;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static final char[] INVALID_RESOURCE_CHARACTERS;
/*    */   private static final String[] INVALID_RESOURCE_BASENAMES;
/*    */   private static final String[] INVALID_RESOURCE_FULLNAMES;
/*    */   
/*    */   public static boolean isNameValid(String name) {
/* 64 */     if (name.equals(".") || name.equals(".."))
/* 65 */       return false; 
/* 66 */     if (INSTALLED_PLATFORM.equals("win32")) {
/*    */       
/* 68 */       int length = name.length();
/* 69 */       if (length == 0)
/* 70 */         return false; 
/* 71 */       char lastChar = name.charAt(length - 1);
/*    */       
/* 73 */       if (lastChar == '.') {
/* 74 */         return false;
/*    */       }
/* 76 */       if (Character.isWhitespace(lastChar))
/* 77 */         return false; 
/* 78 */       int dot = name.indexOf('.');
/*    */       
/* 80 */       String basename = (dot == -1) ? name : name.substring(0, dot);
/* 81 */       if (Arrays.binarySearch((Object[])INVALID_RESOURCE_BASENAMES, basename.toLowerCase()) >= 0)
/* 82 */         return false; 
/* 83 */       return (Arrays.binarySearch((Object[])INVALID_RESOURCE_FULLNAMES, name.toLowerCase()) < 0);
/*    */     } 
/* 85 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\OS.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */