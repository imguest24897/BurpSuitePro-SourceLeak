package org.eclipse.core.internal.resources;

public interface IModelObjectConstants {
  public static final String ARGUMENTS = "arguments";
  
  public static final String ID = "id";
  
  public static final String BUILD_COMMAND = "buildCommand";
  
  public static final String BUILD_SPEC = "buildSpec";
  
  public static final String BUILD_TRIGGERS = "triggers";
  
  public static final String TRIGGER_AUTO = "auto";
  
  public static final String TRIGGER_CLEAN = "clean";
  
  public static final String TRIGGER_FULL = "full";
  
  public static final String TRIGGER_INCREMENTAL = "incremental";
  
  public static final String COMMENT = "comment";
  
  public static final String DICTIONARY = "dictionary";
  
  public static final String KEY = "key";
  
  public static final String LOCATION = "location";
  
  public static final String LOCATION_URI = "locationURI";
  
  public static final String NAME = "name";
  
  public static final String NATURE = "nature";
  
  public static final String NATURES = "natures";
  
  public static final String PROJECT = "project";
  
  public static final String PROJECT_DESCRIPTION = "projectDescription";
  
  public static final String PROJECTS = "projects";
  
  public static final String TYPE = "type";
  
  public static final String VALUE = "value";
  
  public static final String LINKED_RESOURCES = "linkedResources";
  
  public static final String LINK = "link";
  
  public static final String FILTERED_RESOURCES = "filteredResources";
  
  public static final String FILTER = "filter";
  
  public static final String MATCHER = "matcher";
  
  public static final String VARIABLE = "variable";
  
  public static final String VARIABLE_LIST = "variableList";
  
  public static final String SNAPSHOT_LOCATION = "snapshotLocation";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\IModelObjectConstants.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */