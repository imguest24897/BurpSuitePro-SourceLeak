/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.internal.events.ILifecycleListener;
/*     */ import org.eclipse.core.internal.events.LifecycleEvent;
/*     */ import org.eclipse.core.internal.utils.Cache;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.internal.watson.ElementTree;
/*     */ import org.eclipse.core.internal.watson.ElementTreeIterator;
/*     */ import org.eclipse.core.internal.watson.IElementContentVisitor;
/*     */ import org.eclipse.core.internal.watson.IPathRequestor;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IRegistryChangeEvent;
/*     */ import org.eclipse.core.runtime.IRegistryChangeListener;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ import org.eclipse.core.runtime.content.IContentTypeManager;
/*     */ import org.eclipse.core.runtime.content.IContentTypeMatcher;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Bundle;
/*     */ 
/*     */ 
/*     */ public class ContentDescriptionManager
/*     */   implements IManager, IRegistryChangeListener, IContentTypeManager.IContentTypeChangeListener, ILifecycleListener
/*     */ {
/*     */   private class FlushJob
/*     */     extends InternalWorkspaceJob
/*     */   {
/*     */     private final Set<IPath> toFlush;
/*     */     private boolean fullFlush;
/*     */     
/*     */     public FlushJob(Workspace workspace) {
/*  53 */       super(Messages.resources_flushingContentDescriptionCache, workspace);
/*  54 */       setSystem(true);
/*  55 */       setUser(false);
/*  56 */       setPriority(30);
/*  57 */       setRule((ISchedulingRule)workspace.getRoot());
/*  58 */       this.toFlush = new LinkedHashSet<>(5);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean belongsTo(Object family) {
/*  63 */       return "org.eclipse.core.resources.contentDescriptionCacheFamily".equals(family);
/*     */     }
/*     */ 
/*     */     
/*     */     public IStatus runInWorkspace(IProgressMonitor monitor) {
/*  68 */       if (monitor.isCanceled())
/*  69 */         return Status.CANCEL_STATUS; 
/*     */       try {
/*  71 */         monitor.beginTask("", Policy.opWork);
/*     */ 
/*     */         
/*  74 */         IWorkspaceRoot iWorkspaceRoot = ContentDescriptionManager.this.workspace.getRoot();
/*     */         try {
/*  76 */           ContentDescriptionManager.this.workspace.prepareOperation((ISchedulingRule)iWorkspaceRoot, monitor);
/*  77 */           ContentDescriptionManager.this.workspace.beginOperation(true);
/*     */ 
/*     */           
/*  80 */           if (ContentDescriptionManager.this.systemBundle.getState() != 16)
/*  81 */             ContentDescriptionManager.this.doFlushCache(monitor, getPathsToFlush()); 
/*     */         } finally {
/*  83 */           ContentDescriptionManager.this.workspace.endOperation((ISchedulingRule)iWorkspaceRoot, false);
/*     */         } 
/*  85 */       } catch (OperationCanceledException operationCanceledException) {
/*  86 */         return Status.CANCEL_STATUS;
/*  87 */       } catch (CoreException e) {
/*  88 */         return e.getStatus();
/*     */       } finally {
/*  90 */         monitor.done();
/*     */       } 
/*  92 */       return Status.OK_STATUS;
/*     */     }
/*     */     
/*     */     private Set<IPath> getPathsToFlush() {
/*  96 */       synchronized (this.toFlush) {
/*     */         try {
/*  98 */           if (this.fullFlush) {
/*  99 */             return Collections.EMPTY_SET;
/*     */           }
/* 101 */           return new LinkedHashSet<>(this.toFlush);
/*     */         } finally {
/* 103 */           this.fullFlush = false;
/* 104 */           this.toFlush.clear();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void flush(IProject project) {
/* 113 */       if (Policy.DEBUG_CONTENT_TYPE_CACHE)
/* 114 */         Policy.debug("Scheduling flushing of content type cache for " + ((project == null) ? (String)Path.ROOT : (String)project.getFullPath())); 
/* 115 */       synchronized (this.toFlush) {
/* 116 */         if (!this.fullFlush)
/* 117 */           if (project == null) {
/* 118 */             this.fullFlush = true;
/*     */           } else {
/* 120 */             this.toFlush.add(project.getFullPath());
/*     */           }  
/* 122 */       }  schedule(1000L);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static class LazyFileInputStream
/*     */     extends InputStream
/*     */   {
/*     */     private InputStream actual;
/*     */     
/*     */     private IFileStore target;
/*     */ 
/*     */     
/*     */     LazyFileInputStream(IFileStore target) {
/* 136 */       this.target = target;
/*     */     }
/*     */ 
/*     */     
/*     */     public int available() throws IOException {
/* 141 */       if (this.actual == null)
/* 142 */         return 0; 
/* 143 */       return this.actual.available();
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() throws IOException {
/* 148 */       if (this.actual == null)
/*     */         return; 
/* 150 */       this.actual.close();
/*     */     }
/*     */     
/*     */     private void ensureOpened() throws IOException {
/* 154 */       if (this.actual != null)
/*     */         return; 
/* 156 */       if (this.target == null)
/* 157 */         throw new FileNotFoundException(); 
/*     */       try {
/* 159 */         this.actual = this.target.openInputStream(0, null);
/* 160 */       } catch (CoreException e) {
/* 161 */         if (e.getCause() instanceof IOException) {
/* 162 */           throw (IOException)e.getCause();
/*     */         }
/* 164 */         throw new IOException(e.getMessage());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int read() throws IOException {
/* 170 */       ensureOpened();
/* 171 */       return this.actual.read();
/*     */     }
/*     */ 
/*     */     
/*     */     public int read(byte[] b, int off, int len) throws IOException {
/* 176 */       ensureOpened();
/* 177 */       return this.actual.read(b, off, len);
/*     */     }
/*     */ 
/*     */     
/*     */     public long skip(long n) throws IOException {
/* 182 */       ensureOpened();
/* 183 */       return this.actual.skip(n);
/*     */     }
/*     */   }
/*     */   
/* 187 */   private static final QualifiedName CACHE_STATE = new QualifiedName("org.eclipse.core.resources", "contentCacheState");
/* 188 */   private static final QualifiedName CACHE_TIMESTAMP = new QualifiedName("org.eclipse.core.resources", "contentCacheTimestamp");
/*     */   
/*     */   public static final String FAMILY_DESCRIPTION_CACHE_FLUSH = "org.eclipse.core.resources.contentDescriptionCacheFamily";
/*     */   
/*     */   public static final byte EMPTY_CACHE = 1;
/*     */   
/*     */   public static final byte USED_CACHE = 2;
/*     */   
/*     */   public static final byte INVALID_CACHE = 3;
/*     */   
/*     */   public static final byte FLUSHING_CACHE = 4;
/*     */   
/*     */   public static final byte ABOUT_TO_FLUSH = 5;
/*     */   
/*     */   private static final String PT_CONTENTTYPES = "contentTypes";
/*     */   
/*     */   private Cache cache;
/*     */   
/*     */   private volatile byte cacheState;
/*     */   
/*     */   private FlushJob flushJob;
/*     */   
/*     */   private ProjectContentTypes projectContentTypes;
/*     */   private final Workspace workspace;
/* 212 */   protected final Bundle systemBundle = Platform.getBundle("org.eclipse.osgi");
/*     */   
/*     */   public ContentDescriptionManager(Workspace workspace) {
/* 215 */     this.workspace = workspace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void contentTypeChanged(IContentTypeManager.ContentTypeChangeEvent event) {
/* 223 */     if (Policy.DEBUG_CONTENT_TYPE)
/* 224 */       Policy.debug("Content type settings changed for " + event.getContentType()); 
/* 225 */     invalidateCache(true, null);
/*     */   }
/*     */ 
/*     */   
/*     */   synchronized void doFlushCache(IProgressMonitor monitor, Set<IPath> toClean) throws CoreException {
/* 230 */     if (getCacheState() != 3 && getCacheState() != 5) {
/* 231 */       if (Policy.DEBUG_CONTENT_TYPE_CACHE)
/* 232 */         Policy.debug("Content type cache flush not performed"); 
/*     */       return;
/*     */     } 
/*     */     try {
/* 236 */       setCacheState((byte)4);
/*     */       
/* 238 */       this.cache.discardAll();
/* 239 */       SubMonitor subMonitor = SubMonitor.convert(monitor);
/* 240 */       if (toClean.isEmpty()) {
/*     */         
/* 242 */         clearContentFlags((IPath)Path.ROOT, (IProgressMonitor)subMonitor.split(1));
/*     */       } else {
/* 244 */         subMonitor.setWorkRemaining(toClean.size());
/*     */         
/* 246 */         for (IPath element : toClean) {
/* 247 */           subMonitor.subTask("Clear content flags for project '" + element.lastSegment() + "'");
/* 248 */           clearContentFlags(element, (IProgressMonitor)subMonitor.split(1));
/*     */         } 
/*     */       } 
/* 251 */     } catch (CoreException ce) {
/* 252 */       setCacheState((byte)3);
/* 253 */       throw ce;
/*     */     } 
/*     */     
/* 256 */     setCacheState((byte)1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void clearContentFlags(IPath root, IProgressMonitor monitor) {
/* 263 */     long flushStart = System.currentTimeMillis();
/* 264 */     if (Policy.DEBUG_CONTENT_TYPE_CACHE) {
/* 265 */       Policy.debug("Flushing content type cache for " + root);
/*     */     }
/* 267 */     IElementContentVisitor visitor = (tree, requestor, elementContents) -> {
/*     */         if (paramIProgressMonitor.isCanceled())
/*     */           throw new OperationCanceledException(); 
/*     */         if (elementContents == null)
/*     */           return false; 
/*     */         ResourceInfo info = (ResourceInfo)elementContents;
/*     */         if (info.getType() != 1)
/*     */           return true; 
/*     */         info = this.workspace.getResourceInfo(requestor.requestPath(), false, true);
/*     */         if (info == null)
/*     */           return false; 
/*     */         info.clear(393216);
/*     */         return true;
/*     */       };
/* 281 */     (new ElementTreeIterator(this.workspace.getElementTree(), root)).iterate(visitor);
/* 282 */     if (Policy.DEBUG_CONTENT_TYPE_CACHE)
/* 283 */       Policy.debug("Content type cache for " + root + " flushed in " + (System.currentTimeMillis() - flushStart) + " ms"); 
/*     */   }
/*     */   
/*     */   Cache getCache() {
/* 287 */     return this.cache;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getCacheState() {
/* 292 */     if (this.cacheState != 0)
/*     */     {
/* 294 */       return this.cacheState;
/*     */     }
/* 296 */     synchronized (this) {
/* 297 */       if (this.cacheState != 0)
/*     */       {
/* 299 */         return this.cacheState;
/*     */       }
/*     */       
/*     */       try {
/* 303 */         String persisted = this.workspace.getRoot().getPersistentProperty(CACHE_STATE);
/* 304 */         this.cacheState = (persisted != null) ? Byte.parseByte(persisted) : 3;
/* 305 */       } catch (NumberFormatException numberFormatException) {
/* 306 */         this.cacheState = 3;
/* 307 */       } catch (CoreException e) {
/* 308 */         Policy.log(e.getStatus());
/* 309 */         this.cacheState = 3;
/*     */       } 
/*     */     } 
/* 312 */     return this.cacheState;
/*     */   }
/*     */   
/*     */   public long getCacheTimestamp() throws CoreException {
/*     */     try {
/* 317 */       return Long.parseLong(this.workspace.getRoot().getPersistentProperty(CACHE_TIMESTAMP));
/* 318 */     } catch (NumberFormatException numberFormatException) {
/* 319 */       return 0L;
/*     */     } 
/*     */   }
/*     */   
/*     */   public IContentTypeMatcher getContentTypeMatcher(Project project) throws CoreException {
/* 324 */     return this.projectContentTypes.getMatcherFor(project);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IContentDescription getDescriptionFor(File file, ResourceInfo info, boolean inSync) throws CoreException {
/* 336 */     if (ProjectContentTypes.usesContentTypePreferences(file.getFullPath().segment(0)))
/*     */     {
/* 338 */       return readDescription(file); } 
/* 339 */     if (getCacheState() == 3) {
/*     */       
/* 341 */       setCacheState((byte)5);
/* 342 */       this.cache.discardAll();
/*     */       
/* 344 */       this.flushJob.schedule(1000L);
/*     */     } 
/* 346 */     if (inSync && getCacheState() != 5) {
/*     */ 
/*     */       
/* 349 */       if (info == null)
/* 350 */         return null; 
/* 351 */       if (info.isSet(131072))
/*     */       {
/* 353 */         return null; } 
/* 354 */       if (info.isSet(262144)) {
/*     */         
/* 356 */         IContentTypeManager contentTypeManager = Platform.getContentTypeManager();
/*     */         
/* 358 */         IContentType type = contentTypeManager.findContentTypeFor(file.getName());
/* 359 */         if (type != null)
/*     */         {
/* 361 */           return type.getDefaultDescription();
/*     */         }
/*     */         
/* 364 */         info.clear(393216);
/*     */       } 
/*     */     } 
/* 367 */     if (inSync)
/*     */     {
/* 369 */       synchronized (this) {
/* 370 */         Cache.Entry entry = this.cache.getEntry(file.getFullPath());
/* 371 */         if (entry != null && entry.getTimestamp() == getTimestamp(info))
/*     */         {
/* 373 */           return (IContentDescription)entry.getCached();
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 379 */     IContentDescription newDescription = readDescription(file);
/*     */     
/* 381 */     synchronized (this) {
/*     */       
/* 383 */       Cache.Entry entry = this.cache.getEntry(file.getFullPath());
/* 384 */       if (entry != null && inSync && entry.getTimestamp() == getTimestamp(info))
/*     */       {
/* 386 */         return (IContentDescription)entry.getCached();
/*     */       }
/* 388 */       if (getCacheState() != 5) {
/*     */         
/* 390 */         setCacheState((byte)2);
/* 391 */         if (newDescription == null) {
/*     */           
/* 393 */           info.set(131072);
/* 394 */           return null;
/*     */         } 
/* 396 */         if (newDescription.getContentType().getDefaultDescription().equals(newDescription)) {
/*     */           
/* 398 */           IContentType defaultForName = Platform.getContentTypeManager().findContentTypeFor(file.getName());
/* 399 */           if (newDescription.getContentType().equals(defaultForName)) {
/*     */             
/* 401 */             info.set(262144);
/* 402 */             return newDescription;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 407 */       if (entry == null) {
/*     */         
/* 409 */         entry = this.cache.addEntry(file.getFullPath(), newDescription, getTimestamp(info));
/*     */       } else {
/*     */         
/* 412 */         entry.setTimestamp(getTimestamp(info));
/* 413 */         entry.setCached(newDescription);
/*     */       } 
/* 415 */       return newDescription;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getTimestamp(ResourceInfo info) {
/* 424 */     return info.getContentId() + info.getNodeId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void invalidateCache(boolean flush, IProject project) {
/* 435 */     if (getCacheState() == 1) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 440 */       setCacheState((byte)3);
/* 441 */     } catch (CoreException e) {
/* 442 */       Policy.log(e.getStatus());
/*     */     } 
/* 444 */     if (Policy.DEBUG_CONTENT_TYPE_CACHE)
/* 445 */       Policy.debug("Invalidated cache for " + ((project == null) ? (String)Path.ROOT : (String)project.getFullPath())); 
/* 446 */     if (flush) {
/*     */       
/*     */       try {
/* 449 */         setCacheState((byte)5);
/* 450 */         this.cache.discardAll();
/* 451 */       } catch (CoreException e) {
/* 452 */         Policy.log(e.getStatus());
/*     */       } 
/*     */       
/* 455 */       this.flushJob.flush(project);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IContentDescription readDescription(File file) throws CoreException {
/* 463 */     if (Policy.DEBUG_CONTENT_TYPE)
/* 464 */       Policy.debug("reading contents of " + file); 
/*     */     
/* 466 */     try { Exception exception1 = null, exception2 = null;
/*     */ 
/*     */       
/*     */       try {  }
/*     */       finally
/* 471 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (FileNotFoundException e)
/* 472 */     { String message = NLS.bind(Messages.localstore_fileNotFound, file.getFullPath());
/* 473 */       throw new ResourceException(368, file.getFullPath(), message, e); }
/* 474 */     catch (IOException e)
/* 475 */     { String message = NLS.bind(Messages.resources_errorContentDescription, file.getFullPath());
/* 476 */       throw new ResourceException(381, file.getFullPath(), message, e); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registryChanged(IRegistryChangeEvent event) {
/* 486 */     if ((event.getExtensionDeltas("org.eclipse.core.runtime", "contentTypes")).length == 0)
/*     */       return; 
/* 488 */     invalidateCache(true, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleEvent(LifecycleEvent event) {
/* 497 */     switch (event.kind) {
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/*     */       case 16:
/*     */       case 64:
/* 504 */         invalidateCache(true, (IProject)event.resource);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   synchronized void setCacheState(byte newCacheState) throws CoreException {
/* 509 */     if (this.cacheState == newCacheState)
/*     */       return; 
/* 511 */     this.workspace.getRoot().setPersistentProperty(CACHE_STATE, Byte.toString(newCacheState));
/* 512 */     this.cacheState = newCacheState;
/*     */   }
/*     */   
/*     */   private void setCacheTimeStamp(long timeStamp) throws CoreException {
/* 516 */     this.workspace.getRoot().setPersistentProperty(CACHE_TIMESTAMP, Long.toString(timeStamp));
/*     */   }
/*     */ 
/*     */   
/*     */   public void shutdown(IProgressMonitor monitor) throws CoreException {
/* 521 */     if (getCacheState() != 3)
/*     */     {
/* 523 */       setCacheTimeStamp(Platform.getStateStamp()); } 
/* 524 */     IContentTypeManager contentTypeManager = Platform.getContentTypeManager();
/*     */     
/* 526 */     if (contentTypeManager != null)
/* 527 */       contentTypeManager.removeContentTypeChangeListener(this); 
/* 528 */     IExtensionRegistry registry = Platform.getExtensionRegistry();
/* 529 */     if (registry != null)
/* 530 */       registry.removeRegistryChangeListener(this); 
/* 531 */     this.cache.dispose();
/* 532 */     this.cache = null;
/* 533 */     this.flushJob.cancel();
/* 534 */     this.flushJob = null;
/* 535 */     this.projectContentTypes = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void startup(IProgressMonitor monitor) throws CoreException {
/* 540 */     this.cache = new Cache(100, 1000, 0.1D);
/* 541 */     this.projectContentTypes = new ProjectContentTypes(this.workspace);
/* 542 */     getCacheState();
/* 543 */     if (this.cacheState == 4 || this.cacheState == 5)
/*     */     {
/* 545 */       setCacheState((byte)3); } 
/* 546 */     this.flushJob = new FlushJob(this.workspace);
/*     */     
/* 548 */     if (getCacheTimestamp() != Platform.getStateStamp()) {
/* 549 */       invalidateCache(false, null);
/*     */     }
/* 551 */     this.workspace.addLifecycleListener(this);
/*     */     
/* 553 */     Platform.getContentTypeManager().addContentTypeChangeListener(this);
/*     */     
/* 555 */     Platform.getExtensionRegistry().addRegistryChangeListener(this, "org.eclipse.core.runtime");
/*     */   }
/*     */   
/*     */   public void projectPreferencesChanged(IProject project) {
/* 559 */     if (Policy.DEBUG_CONTENT_TYPE)
/* 560 */       Policy.debug("Project preferences changed for " + project); 
/* 561 */     this.projectContentTypes.contentTypePreferencesChanged(project);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ContentDescriptionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */