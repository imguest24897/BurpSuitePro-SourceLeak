/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import org.eclipse.core.internal.utils.FileUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SafeChunkyOutputStream
/*     */   extends FilterOutputStream
/*     */ {
/*     */   protected String filePath;
/*     */   protected boolean isOpen;
/*     */   
/*     */   public SafeChunkyOutputStream(File target) throws IOException {
/*  44 */     this(target.getAbsolutePath());
/*     */   }
/*     */   
/*     */   public SafeChunkyOutputStream(String filePath) throws IOException {
/*  48 */     super(new BufferedOutputStream(new FileOutputStream(filePath, true)));
/*  49 */     this.filePath = filePath;
/*  50 */     this.isOpen = true;
/*  51 */     beginChunk();
/*     */   }
/*     */   
/*     */   protected void beginChunk() throws IOException {
/*  55 */     write(ILocalStoreConstants.BEGIN_CHUNK);
/*     */   }
/*     */   
/*     */   protected void endChunk() throws IOException {
/*  59 */     write(ILocalStoreConstants.END_CHUNK);
/*     */   }
/*     */   
/*     */   protected void open() throws IOException {
/*  63 */     this.out = new BufferedOutputStream(new FileOutputStream(this.filePath, true));
/*  64 */     this.isOpen = true;
/*  65 */     beginChunk();
/*     */   }
/*     */   
/*     */   public void succeed() throws IOException {
/*     */     try {
/*  70 */       endChunk();
/*  71 */       close();
/*     */     } finally {
/*  73 */       this.isOpen = false;
/*  74 */       FileUtil.safeClose(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  86 */     Exception exception1 = null, exception2 = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/*  93 */     if (!this.isOpen)
/*  94 */       open(); 
/*  95 */     super.write(b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/* 100 */     if (!this.isOpen)
/* 101 */       open(); 
/* 102 */     this.out.write(b, off, len);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\SafeChunkyOutputStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */