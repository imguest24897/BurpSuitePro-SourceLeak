package org.eclipse.core.resources;

import java.net.URI;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IFolder extends IContainer, IAdaptable {
  void create(boolean paramBoolean1, boolean paramBoolean2, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void create(int paramInt, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void createLink(IPath paramIPath, int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void createLink(URI paramURI, int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void delete(boolean paramBoolean1, boolean paramBoolean2, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  IFile getFile(String paramString);
  
  IFolder getFolder(String paramString);
  
  void move(IPath paramIPath, boolean paramBoolean1, boolean paramBoolean2, IProgressMonitor paramIProgressMonitor) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IFolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */