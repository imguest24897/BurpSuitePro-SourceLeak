/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.Queue;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.internal.utils.WrappedRuntimeException;
/*     */ import org.eclipse.core.internal.watson.ElementTree;
/*     */ import org.eclipse.core.internal.watson.ElementTreeIterator;
/*     */ import org.eclipse.core.internal.watson.IElementContentVisitor;
/*     */ import org.eclipse.core.internal.watson.IPathRequestor;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.content.IContentTypeManager;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.osgi.framework.Bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharsetDeltaJob
/*     */   extends Job
/*     */   implements IContentTypeManager.IContentTypeChangeListener
/*     */ {
/*     */   public static final String FAMILY_CHARSET_DELTA = "org.eclipse.core.resourcescharsetJobFamily";
/*  55 */   private ThreadLocal<Boolean> disabled = new ThreadLocal<>();
/*     */   
/*  57 */   private final Bundle systemBundle = Platform.getBundle("org.eclipse.osgi");
/*  58 */   private Queue<ICharsetListenerFilter> work = new LinkedList<>();
/*     */   
/*     */   Workspace workspace;
/*     */   
/*     */   private static final int CHARSET_DELTA_DELAY = 500;
/*     */   
/*     */   public CharsetDeltaJob(Workspace workspace) {
/*  65 */     super(Messages.resources_charsetBroadcasting);
/*  66 */     this.workspace = workspace;
/*     */   }
/*     */   
/*     */   private void addToQueue(ICharsetListenerFilter filter) {
/*  70 */     synchronized (this.work) {
/*  71 */       this.work.add(filter);
/*     */     } 
/*  73 */     schedule(500L);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean belongsTo(Object family) {
/*  78 */     return "org.eclipse.core.resourcescharsetJobFamily".equals(family);
/*     */   }
/*     */ 
/*     */   
/*     */   public void charsetPreferencesChanged(final IProject project) {
/*  83 */     if (isDisabled())
/*     */       return; 
/*  85 */     ResourceInfo projectInfo = ((Project)project).getResourceInfo(false, false);
/*     */     
/*  87 */     if (projectInfo == null)
/*     */       return; 
/*  89 */     final long projectId = projectInfo.getNodeId();
/*     */ 
/*     */     
/*  92 */     ICharsetListenerFilter filter = new ICharsetListenerFilter()
/*     */       {
/*     */         public IPath getRoot()
/*     */         {
/*  96 */           ResourceInfo currentInfo = ((Project)project).getResourceInfo(false, false);
/*  97 */           if (currentInfo == null)
/*  98 */             return null; 
/*  99 */           long currentId = currentInfo.getNodeId();
/* 100 */           if (currentId != projectId) {
/* 101 */             return null;
/*     */           }
/* 103 */           return project.getFullPath();
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public boolean isAffected(ResourceInfo info, IPathRequestor requestor) {
/* 109 */           return true;
/*     */         }
/*     */ 
/*     */         
/*     */         public IProject getProject() {
/* 114 */           return project;
/*     */         }
/*     */       };
/*     */     
/* 118 */     addToQueue(filter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void contentTypeChanged(final IContentTypeManager.ContentTypeChangeEvent event) {
/* 126 */     ICharsetListenerFilter filter = new ICharsetListenerFilter()
/*     */       {
/*     */         
/*     */         public IPath getRoot()
/*     */         {
/* 131 */           return (IPath)Path.ROOT;
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean isAffected(ResourceInfo info, IPathRequestor requestor) {
/* 136 */           if (info.getType() != 1)
/* 137 */             return false; 
/* 138 */           return event.getContentType().isAssociatedWith(requestor.requestName());
/*     */         }
/*     */ 
/*     */         
/*     */         public IProject getProject() {
/* 143 */           return null;
/*     */         }
/*     */       };
/* 146 */     addToQueue(filter);
/*     */   }
/*     */   
/*     */   private boolean isDisabled() {
/* 150 */     return (this.disabled.get() != null);
/*     */   }
/*     */   
/*     */   private void processNextEvent(ICharsetListenerFilter filter, IProgressMonitor monitor) throws CoreException {
/* 154 */     IElementContentVisitor visitor = (tree, requestor, elementContents) -> {
/*     */         ResourceInfo info = (ResourceInfo)elementContents;
/*     */         if (!paramICharsetListenerFilter.isAffected(info, requestor))
/*     */           return true; 
/*     */         info = this.workspace.getResourceInfo(requestor.requestPath(), false, true);
/*     */         if (info == null)
/*     */           return false; 
/*     */         info.incrementCharsetGenerationCount();
/*     */         return true;
/*     */       };
/*     */     try {
/* 165 */       IPath root = filter.getRoot();
/* 166 */       if (root != null) {
/* 167 */         (new ElementTreeIterator(this.workspace.getElementTree(), root)).iterate(visitor);
/*     */       }
/* 169 */       IProject project = filter.getProject();
/* 170 */       if (project != null) {
/* 171 */         ValidateProjectEncoding.updateMissingEncodingMarker(project);
/*     */       }
/* 173 */     } catch (WrappedRuntimeException e) {
/* 174 */       throw (CoreException)e.getTargetException();
/*     */     } 
/* 176 */     if (monitor.isCanceled())
/* 177 */       throw new OperationCanceledException(); 
/*     */   }
/*     */   
/*     */   private ICharsetListenerFilter removeFromQueue() {
/* 181 */     synchronized (this.work) {
/* 182 */       return this.work.poll();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public IStatus run(IProgressMonitor monitor) {
/* 188 */     monitor = Policy.monitorFor(monitor);
/*     */     
/* 190 */     try { String message = Messages.resources_charsetBroadcasting;
/* 191 */       monitor.beginTask(message, 100);
/*     */       try {
/* 193 */         this.workspace.prepareOperation(null, monitor);
/* 194 */         this.workspace.beginOperation(true);
/*     */         
/*     */         ICharsetListenerFilter next;
/* 197 */         while (this.systemBundle.getState() != 16 && (next = removeFromQueue()) != null)
/* 198 */           processNextEvent(next, monitor); 
/* 199 */       } catch (OperationCanceledException operationCanceledException) {
/* 200 */         this.workspace.getWorkManager().operationCanceled();
/* 201 */         return Status.CANCEL_STATUS;
/*     */       } finally {
/* 203 */         this.workspace.endOperation(null, true);
/*     */       }
/*     */        }
/* 206 */     catch (CoreException sig)
/* 207 */     { return sig.getStatus(); }
/*     */     finally
/* 209 */     { monitor.done(); }  monitor.done();
/*     */     
/* 211 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisabled(boolean disabled) {
/* 219 */     this.disabled.set(disabled ? Boolean.TRUE : null);
/*     */   }
/*     */   
/*     */   public void shutdown() {
/* 223 */     IContentTypeManager contentTypeManager = Platform.getContentTypeManager();
/*     */     
/* 225 */     if (contentTypeManager != null)
/* 226 */       contentTypeManager.removeContentTypeChangeListener(this); 
/*     */   }
/*     */   
/*     */   public void startup() {
/* 230 */     Platform.getContentTypeManager().addContentTypeChangeListener(this);
/*     */   }
/*     */   
/*     */   static interface ICharsetListenerFilter {
/*     */     IPath getRoot();
/*     */     
/*     */     IProject getProject();
/*     */     
/*     */     boolean isAffected(ResourceInfo param1ResourceInfo, IPathRequestor param1IPathRequestor);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\CharsetDeltaJob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */