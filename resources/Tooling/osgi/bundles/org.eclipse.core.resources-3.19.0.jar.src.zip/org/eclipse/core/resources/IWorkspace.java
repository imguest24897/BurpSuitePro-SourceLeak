/*     */ package org.eclipse.core.resources;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.net.URI;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.resources.team.FileModificationValidationContext;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.core.runtime.ICoreRunnable;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Plugin;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IWorkspace
/*     */   extends IAdaptable
/*     */ {
/*     */   public static final int AVOID_UPDATE = 1;
/* 128 */   public static final Object VALIDATE_PROMPT = FileModificationValidationContext.VALIDATE_PROMPT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   public static final String SERVICE_NAME = IWorkspace.class.getName();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addResourceChangeListener(IResourceChangeListener paramIResourceChangeListener);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addResourceChangeListener(IResourceChangeListener paramIResourceChangeListener, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   ISavedState addSaveParticipant(Plugin paramPlugin, ISaveParticipant paramISaveParticipant) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ISavedState addSaveParticipant(String paramString, ISaveParticipant paramISaveParticipant) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void build(int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void build(IBuildConfiguration[] paramArrayOfIBuildConfiguration, int paramInt, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void checkpoint(boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   IProject[][] computePrerequisiteOrder(IProject[] paramArrayOfIProject);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ProjectOrder computeProjectOrder(IProject[] paramArrayOfIProject);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IStatus copy(IResource[] paramArrayOfIResource, IPath paramIPath, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IStatus copy(IResource[] paramArrayOfIResource, IPath paramIPath, int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IStatus delete(IResource[] paramArrayOfIResource, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IStatus delete(IResource[] paramArrayOfIResource, int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void deleteMarkers(IMarker[] paramArrayOfIMarker) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void forgetSavedTree(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IFilterMatcherDescriptor[] getFilterMatcherDescriptors();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IFilterMatcherDescriptor getFilterMatcherDescriptor(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IProjectNatureDescriptor[] getNatureDescriptors();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IProjectNatureDescriptor getNatureDescriptor(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map<IProject, IProject[]> getDanglingReferences();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IWorkspaceDescription getDescription();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IWorkspaceRoot getRoot();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IResourceRuleFactory getRuleFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ISynchronizer getSynchronizer();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isAutoBuilding();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isTreeLocked();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IProjectDescription loadProjectDescription(IPath paramIPath) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IProjectDescription loadProjectDescription(InputStream paramInputStream) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IStatus move(IResource[] paramArrayOfIResource, IPath paramIPath, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IStatus move(IResource[] paramArrayOfIResource, IPath paramIPath, int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IBuildConfiguration newBuildConfig(String paramString1, String paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IProjectDescription newProjectDescription(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeResourceChangeListener(IResourceChangeListener paramIResourceChangeListener);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   void removeSaveParticipant(Plugin paramPlugin);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeSaveParticipant(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void run(ICoreRunnable paramICoreRunnable, ISchedulingRule paramISchedulingRule, int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void run(ICoreRunnable paramICoreRunnable, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void run(IWorkspaceRunnable paramIWorkspaceRunnable, ISchedulingRule paramISchedulingRule, int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void run(IWorkspaceRunnable paramIWorkspaceRunnable, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IStatus save(boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setDescription(IWorkspaceDescription paramIWorkspaceDescription) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String[] sortNatureSet(String[] paramArrayOfString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IStatus validateEdit(IFile[] paramArrayOfIFile, Object paramObject);
/*     */ 
/*     */ 
/*     */   
/*     */   IStatus validateFiltered(IResource paramIResource);
/*     */ 
/*     */ 
/*     */   
/*     */   IStatus validateLinkLocation(IResource paramIResource, IPath paramIPath);
/*     */ 
/*     */ 
/*     */   
/*     */   IStatus validateLinkLocationURI(IResource paramIResource, URI paramURI);
/*     */ 
/*     */ 
/*     */   
/*     */   IStatus validateName(String paramString, int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   IStatus validateNatureSet(String[] paramArrayOfString);
/*     */ 
/*     */ 
/*     */   
/*     */   IStatus validatePath(String paramString, int paramInt);
/*     */ 
/*     */ 
/*     */   
/*     */   IStatus validateProjectLocation(IProject paramIProject, IPath paramIPath);
/*     */ 
/*     */ 
/*     */   
/*     */   IStatus validateProjectLocationURI(IProject paramIProject, URI paramURI);
/*     */ 
/*     */ 
/*     */   
/*     */   IPathVariableManager getPathVariableManager();
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class ProjectOrder
/*     */   {
/*     */     public IProject[] projects;
/*     */ 
/*     */     
/*     */     public boolean hasCycles;
/*     */ 
/*     */     
/*     */     public IProject[][] knots;
/*     */ 
/*     */ 
/*     */     
/*     */     public ProjectOrder(IProject[] projects, boolean hasCycles, IProject[][] knots) {
/* 405 */       this.projects = projects;
/* 406 */       this.hasCycles = hasCycles;
/* 407 */       this.knots = knots;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IWorkspace.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */