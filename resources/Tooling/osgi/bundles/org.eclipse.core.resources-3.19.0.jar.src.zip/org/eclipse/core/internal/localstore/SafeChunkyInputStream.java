/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SafeChunkyInputStream
/*     */   extends InputStream
/*     */ {
/*     */   protected static final int BUFFER_SIZE = 8192;
/*     */   protected byte[] buffer;
/*  24 */   protected int bufferLength = 0;
/*     */   protected byte[] chunk;
/*  26 */   protected int chunkLength = 0;
/*     */   protected boolean endOfFile = false;
/*     */   protected InputStream input;
/*  29 */   protected int nextByteInBuffer = 0;
/*  30 */   protected int nextByteInChunk = 0;
/*     */   
/*     */   public SafeChunkyInputStream(File target) throws IOException {
/*  33 */     this(target, 8192);
/*     */   }
/*     */   
/*     */   public SafeChunkyInputStream(File target, int bufferSize) throws IOException {
/*  37 */     this.input = new FileInputStream(target);
/*  38 */     this.buffer = new byte[bufferSize];
/*     */   }
/*     */   
/*     */   protected void accumulate(byte[] data, int start, int end) {
/*  42 */     byte[] result = new byte[this.chunk.length + end - start];
/*  43 */     System.arraycopy(this.chunk, 0, result, 0, this.chunk.length);
/*  44 */     System.arraycopy(data, start, result, this.chunk.length, end - start);
/*  45 */     this.chunk = result;
/*  46 */     this.chunkLength = this.chunkLength + end - start;
/*     */   }
/*     */ 
/*     */   
/*     */   public int available() {
/*  51 */     return this.chunkLength - this.nextByteInChunk;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void buildChunk() throws IOException {
/*     */     while (true) {
/*  57 */       if (this.nextByteInBuffer + ILocalStoreConstants.CHUNK_DELIMITER_SIZE > this.bufferLength)
/*  58 */         shiftAndFillBuffer(); 
/*  59 */       int end = find(ILocalStoreConstants.END_CHUNK, this.nextByteInBuffer, this.bufferLength, true);
/*  60 */       if (end != -1) {
/*  61 */         accumulate(this.buffer, this.nextByteInBuffer, end);
/*  62 */         this.nextByteInBuffer = end + ILocalStoreConstants.CHUNK_DELIMITER_SIZE;
/*     */         return;
/*     */       } 
/*  65 */       accumulate(this.buffer, this.nextByteInBuffer, this.bufferLength);
/*  66 */       this.bufferLength = this.input.read(this.buffer);
/*  67 */       this.nextByteInBuffer = 0;
/*  68 */       if (this.bufferLength == -1) {
/*  69 */         this.endOfFile = true;
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  77 */     this.input.close(); } protected boolean compare(byte[] source, byte[] target, int startIndex) {
/*     */     byte b;
/*     */     int i;
/*     */     byte[] arrayOfByte;
/*  81 */     for (i = (arrayOfByte = target).length, b = 0; b < i; ) { byte element = arrayOfByte[b];
/*  82 */       if (source[startIndex] != element)
/*  83 */         return false; 
/*  84 */       startIndex++; b++; }
/*     */     
/*  86 */     return true;
/*     */   }
/*     */   
/*     */   protected int find(byte[] pattern, int startIndex, int endIndex, boolean accumulate) throws IOException {
/*  90 */     int pos = findByte(pattern[0], startIndex, endIndex);
/*  91 */     if (pos == -1)
/*  92 */       return -1; 
/*  93 */     if (pos + ILocalStoreConstants.CHUNK_DELIMITER_SIZE > this.bufferLength) {
/*  94 */       if (accumulate)
/*  95 */         accumulate(this.buffer, this.nextByteInBuffer, pos); 
/*  96 */       this.nextByteInBuffer = pos;
/*  97 */       pos = 0;
/*  98 */       shiftAndFillBuffer();
/*     */     } 
/* 100 */     if (compare(this.buffer, pattern, pos))
/* 101 */       return pos; 
/* 102 */     return find(pattern, pos + 1, endIndex, accumulate);
/*     */   }
/*     */   
/*     */   protected int findByte(byte target, int startIndex, int endIndex) {
/* 106 */     while (startIndex < endIndex) {
/* 107 */       if (this.buffer[startIndex] == target)
/* 108 */         return startIndex; 
/* 109 */       startIndex++;
/*     */     } 
/* 111 */     return -1;
/*     */   }
/*     */   
/*     */   protected void findChunkStart() throws IOException {
/* 115 */     if (this.nextByteInBuffer + ILocalStoreConstants.CHUNK_DELIMITER_SIZE > this.bufferLength)
/* 116 */       shiftAndFillBuffer(); 
/* 117 */     int begin = find(ILocalStoreConstants.BEGIN_CHUNK, this.nextByteInBuffer, this.bufferLength, false);
/* 118 */     if (begin != -1) {
/* 119 */       this.nextByteInBuffer = begin + ILocalStoreConstants.CHUNK_DELIMITER_SIZE;
/*     */       return;
/*     */     } 
/* 122 */     this.bufferLength = this.input.read(this.buffer);
/* 123 */     this.nextByteInBuffer = 0;
/* 124 */     if (this.bufferLength == -1) {
/* 125 */       resetChunk();
/* 126 */       this.endOfFile = true;
/*     */       return;
/*     */     } 
/* 129 */     findChunkStart();
/*     */   }
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 134 */     if (this.endOfFile) {
/* 135 */       return -1;
/*     */     }
/* 137 */     if (this.nextByteInChunk < this.chunkLength) {
/* 138 */       return this.chunk[this.nextByteInChunk++] & 0xFF;
/*     */     }
/*     */ 
/*     */     
/* 142 */     resetChunk();
/* 143 */     findChunkStart();
/* 144 */     if (this.endOfFile)
/* 145 */       return -1; 
/* 146 */     buildChunk();
/* 147 */     refineChunk();
/* 148 */     return read();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void refineChunk() {
/* 156 */     int start = this.chunkLength - ILocalStoreConstants.CHUNK_DELIMITER_SIZE;
/* 157 */     if (start < 0)
/*     */       return; 
/* 159 */     for (int i = start; i >= 0; i--) {
/* 160 */       if (compare(this.chunk, ILocalStoreConstants.BEGIN_CHUNK, i)) {
/* 161 */         this.nextByteInChunk = i + ILocalStoreConstants.CHUNK_DELIMITER_SIZE;
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void resetChunk() {
/* 168 */     this.chunk = new byte[0];
/* 169 */     this.chunkLength = 0;
/* 170 */     this.nextByteInChunk = 0;
/*     */   }
/*     */   
/*     */   protected void shiftAndFillBuffer() throws IOException {
/* 174 */     int length = this.bufferLength - this.nextByteInBuffer;
/* 175 */     System.arraycopy(this.buffer, this.nextByteInBuffer, this.buffer, 0, length);
/* 176 */     this.nextByteInBuffer = 0;
/* 177 */     this.bufferLength = length;
/* 178 */     int read = this.input.read(this.buffer, this.bufferLength, this.buffer.length - this.bufferLength);
/* 179 */     if (read != -1) {
/* 180 */       this.bufferLength += read;
/*     */     } else {
/* 182 */       resetChunk();
/* 183 */       this.endOfFile = true;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\SafeChunkyInputStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */