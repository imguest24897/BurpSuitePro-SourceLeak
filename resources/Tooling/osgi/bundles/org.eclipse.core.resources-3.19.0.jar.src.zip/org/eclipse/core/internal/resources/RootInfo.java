/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import org.eclipse.core.runtime.QualifiedName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RootInfo
/*    */   extends ResourceInfo
/*    */ {
/* 20 */   protected Object propertyStore = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getPropertyStore() {
/* 27 */     return this.propertyStore;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void incrementSyncInfoGenerationCount() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setPropertyStore(Object value) {
/* 45 */     this.propertyStore = value;
/*    */   }
/*    */   
/*    */   public void setSyncInfo(QualifiedName id, byte[] value) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\RootInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */