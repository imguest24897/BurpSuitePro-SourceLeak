package org.eclipse.core.resources;

import java.net.URI;
import org.eclipse.core.runtime.IPath;

public interface IProjectDescription {
  public static final String DESCRIPTION_FILE_NAME = ".project";
  
  IBuildConfiguration[] getBuildConfigReferences(String paramString);
  
  ICommand[] getBuildSpec();
  
  String getComment();
  
  IProject[] getDynamicReferences();
  
  @Deprecated
  IPath getLocation();
  
  URI getLocationURI();
  
  String getName();
  
  String[] getNatureIds();
  
  IProject[] getReferencedProjects();
  
  boolean hasNature(String paramString);
  
  ICommand newCommand();
  
  void setActiveBuildConfig(String paramString);
  
  void setBuildConfigs(String[] paramArrayOfString);
  
  void setBuildConfigReferences(String paramString, IBuildConfiguration[] paramArrayOfIBuildConfiguration);
  
  void setBuildSpec(ICommand[] paramArrayOfICommand);
  
  void setComment(String paramString);
  
  @Deprecated
  void setDynamicReferences(IProject[] paramArrayOfIProject);
  
  void setLocation(IPath paramIPath);
  
  void setLocationURI(URI paramURI);
  
  void setName(String paramString);
  
  void setNatureIds(String[] paramArrayOfString);
  
  void setReferencedProjects(IProject[] paramArrayOfIProject);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IProjectDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */