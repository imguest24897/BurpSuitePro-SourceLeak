/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.internal.resources.Container;
/*     */ import org.eclipse.core.internal.resources.Resource;
/*     */ import org.eclipse.core.internal.resources.ResourceStatus;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CollectSyncStatusVisitor
/*     */   extends RefreshLocalVisitor
/*     */ {
/*     */   protected List<Resource> affectedResources;
/*     */   private boolean ignoreLocalDeletions = false;
/*     */   protected MultiStatus status;
/*     */   
/*     */   public CollectSyncStatusVisitor(String multiStatusTitle, IProgressMonitor monitor) {
/*  48 */     super(monitor);
/*  49 */     this.status = new MultiStatus("org.eclipse.core.resources", 1, multiStatusTitle, null);
/*     */   }
/*     */   
/*     */   protected void changed(Resource target) {
/*  53 */     String message = NLS.bind(Messages.localstore_resourceIsOutOfSync, target.getFullPath());
/*  54 */     this.status.add((IStatus)new ResourceStatus(274, target.getFullPath(), message));
/*  55 */     if (this.affectedResources == null)
/*  56 */       this.affectedResources = new ArrayList<>(20); 
/*  57 */     this.affectedResources.add(target);
/*  58 */     this.resourceChanged = true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void createResource(UnifiedTreeNode node, Resource target) {
/*  63 */     changed(target);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void deleteResource(UnifiedTreeNode node, Resource target) {
/*  68 */     if (!this.ignoreLocalDeletions) {
/*  69 */       changed(target);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void fileToFolder(UnifiedTreeNode node, Resource target) {
/*  74 */     changed(target);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void folderToFile(UnifiedTreeNode node, Resource target) {
/*  79 */     changed(target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Resource> getAffectedResources() {
/*  88 */     return this.affectedResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultiStatus getSyncStatus() {
/*  95 */     return this.status;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void makeLocal(UnifiedTreeNode node, Resource target) {
/* 100 */     changed(target);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void refresh(Container parent) {
/* 105 */     changed((Resource)parent);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void resourceChanged(UnifiedTreeNode node, Resource target) {
/* 110 */     changed(target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnoreLocalDeletions(boolean value) {
/* 118 */     this.ignoreLocalDeletions = value;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\CollectSyncStatusVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */