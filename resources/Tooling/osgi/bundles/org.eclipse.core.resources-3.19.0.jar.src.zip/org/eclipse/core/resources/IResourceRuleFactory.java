package org.eclipse.core.resources;

import org.eclipse.core.runtime.jobs.ISchedulingRule;

public interface IResourceRuleFactory {
  ISchedulingRule createRule(IResource paramIResource);
  
  ISchedulingRule buildRule();
  
  ISchedulingRule charsetRule(IResource paramIResource);
  
  ISchedulingRule derivedRule(IResource paramIResource);
  
  ISchedulingRule copyRule(IResource paramIResource1, IResource paramIResource2);
  
  ISchedulingRule deleteRule(IResource paramIResource);
  
  ISchedulingRule markerRule(IResource paramIResource);
  
  ISchedulingRule modifyRule(IResource paramIResource);
  
  ISchedulingRule moveRule(IResource paramIResource1, IResource paramIResource2);
  
  ISchedulingRule refreshRule(IResource paramIResource);
  
  ISchedulingRule validateEditRule(IResource[] paramArrayOfIResource);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IResourceRuleFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */