/*     */ package org.eclipse.core.internal.localstore;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.internal.resources.FileState;
/*     */ import org.eclipse.core.internal.resources.ResourceStatus;
/*     */ import org.eclipse.core.internal.resources.Workspace;
/*     */ import org.eclipse.core.internal.resources.WorkspaceDescription;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.internal.utils.UniversalUniqueIdentifier;
/*     */ import org.eclipse.core.resources.IFileState;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ 
/*     */ public class HistoryStore2 implements IHistoryStore {
/*     */   private BlobStore blobStore;
/*     */   
/*     */   class HistoryCopyVisitor extends Bucket.Visitor {
/*  30 */     private List<HistoryBucket.HistoryEntry> changes = new ArrayList<>();
/*     */     private IPath destination;
/*     */     private IPath source;
/*     */     
/*     */     public HistoryCopyVisitor(IPath source, IPath destination) {
/*  35 */       this.source = source;
/*  36 */       this.destination = destination;
/*     */     }
/*     */ 
/*     */     
/*     */     public void afterSaving(Bucket bucket) throws CoreException {
/*  41 */       saveChanges();
/*  42 */       this.changes.clear();
/*     */     }
/*     */     
/*     */     private void saveChanges() throws CoreException {
/*  46 */       if (this.changes.isEmpty()) {
/*     */         return;
/*     */       }
/*  49 */       Iterator<HistoryBucket.HistoryEntry> i = this.changes.iterator();
/*  50 */       HistoryBucket.HistoryEntry entry = i.next();
/*  51 */       HistoryStore2.this.tree.loadBucketFor(entry.getPath());
/*  52 */       HistoryBucket bucket = (HistoryBucket)HistoryStore2.this.tree.getCurrent();
/*  53 */       bucket.addBlobs(entry);
/*  54 */       while (i.hasNext())
/*  55 */         bucket.addBlobs(i.next()); 
/*  56 */       bucket.save();
/*     */     }
/*     */ 
/*     */     
/*     */     public int visit(Bucket.Entry sourceEntry) {
/*  61 */       IPath destinationPath = this.destination.append(sourceEntry.getPath().removeFirstSegments(this.source.segmentCount()));
/*  62 */       HistoryBucket.HistoryEntry destinationEntry = new HistoryBucket.HistoryEntry(destinationPath, (HistoryBucket.HistoryEntry)sourceEntry);
/*     */ 
/*     */       
/*  65 */       this.changes.add(destinationEntry);
/*  66 */       return 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*  71 */   private Set<UniversalUniqueIdentifier> blobsToRemove = new HashSet<>();
/*     */   final BucketTree tree;
/*     */   private Workspace workspace;
/*     */   
/*     */   public HistoryStore2(Workspace workspace, IFileStore store, int limit) {
/*  76 */     this.workspace = workspace;
/*     */     try {
/*  78 */       store.mkdir(0, null);
/*  79 */     } catch (CoreException coreException) {}
/*     */ 
/*     */ 
/*     */     
/*  83 */     this.blobStore = new BlobStore(store, limit);
/*  84 */     this.tree = new BucketTree(workspace, new HistoryBucket());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized IFileState addState(IPath key, IFileStore localFile, IFileInfo info, boolean moveContents) {
/*  92 */     long lastModified = info.getLastModified();
/*  93 */     if (Policy.DEBUG_HISTORY)
/*  94 */       Policy.debug("History: Adding state for key: " + key + ", file: " + localFile + ", timestamp: " + lastModified + ", size: " + localFile.fetchInfo().getLength()); 
/*  95 */     if (!isValid(localFile, info))
/*  96 */       return null; 
/*  97 */     UniversalUniqueIdentifier uuid = null;
/*     */     try {
/*  99 */       uuid = this.blobStore.addBlob(localFile, moveContents);
/* 100 */       this.tree.loadBucketFor(key);
/* 101 */       HistoryBucket currentBucket = (HistoryBucket)this.tree.getCurrent();
/* 102 */       currentBucket.addBlob(key, uuid, lastModified);
/*     */     }
/* 104 */     catch (CoreException e) {
/* 105 */       log(e);
/*     */     } 
/* 107 */     return (IFileState)new FileState(this, key, lastModified, uuid);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized Set<IPath> allFiles(IPath root, int depth, IProgressMonitor monitor) {
/* 112 */     final Set<IPath> allFiles = new HashSet<>();
/*     */     try {
/* 114 */       this.tree.accept(new Bucket.Visitor()
/*     */           {
/*     */             public int visit(Bucket.Entry fileEntry) {
/* 117 */               allFiles.add(fileEntry.getPath());
/* 118 */               return 0;
/*     */             }
/* 120 */           },  root, (depth == 2) ? Integer.MAX_VALUE : depth);
/* 121 */     } catch (CoreException e) {
/* 122 */       log(e);
/*     */     } 
/* 124 */     return allFiles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void applyPolicy(HistoryBucket.HistoryEntry fileEntry, int maxStates, long minTimeStamp) {
/* 131 */     for (int i = 0; i < fileEntry.getOccurrences(); i++) {
/* 132 */       if (i >= maxStates || fileEntry.getTimestamp(i) < minTimeStamp) {
/*     */ 
/*     */         
/* 135 */         this.blobsToRemove.add(fileEntry.getUUID(i));
/* 136 */         fileEntry.deleteOccurrence(i);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void applyPolicy(IPath root) throws CoreException {
/* 144 */     WorkspaceDescription workspaceDescription = this.workspace.internalGetDescription();
/* 145 */     final long minimumTimestamp = System.currentTimeMillis() - workspaceDescription.getFileStateLongevity();
/* 146 */     final int maxStates = workspaceDescription.getMaxFileStates();
/*     */     
/* 148 */     this.tree.accept(new Bucket.Visitor()
/*     */         {
/*     */           public int visit(Bucket.Entry entry) {
/* 151 */             HistoryStore2.this.applyPolicy((HistoryBucket.HistoryEntry)entry, maxStates, minimumTimestamp);
/* 152 */             return 0;
/*     */           }
/* 154 */         }root, 2147483647);
/* 155 */     this.tree.getCurrent().save();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void clean(final IProgressMonitor monitor) {
/* 160 */     long start = System.currentTimeMillis();
/*     */     try {
/* 162 */       monitor.beginTask(Messages.resources_pruningHistory, -1);
/* 163 */       WorkspaceDescription workspaceDescription = this.workspace.internalGetDescription();
/* 164 */       final long minimumTimestamp = System.currentTimeMillis() - workspaceDescription.getFileStateLongevity();
/* 165 */       final int maxStates = workspaceDescription.getMaxFileStates();
/* 166 */       final int[] entryCount = new int[1];
/* 167 */       if (workspaceDescription.isApplyFileStatePolicy()) {
/* 168 */         this.tree.accept(new Bucket.Visitor()
/*     */             {
/*     */               public int visit(Bucket.Entry fileEntry) {
/* 171 */                 if (monitor.isCanceled())
/* 172 */                   return 1; 
/* 173 */                 entryCount[0] = entryCount[0] + fileEntry.getOccurrences();
/* 174 */                 HistoryStore2.this.applyPolicy((HistoryBucket.HistoryEntry)fileEntry, maxStates, minimumTimestamp);
/*     */                 
/* 176 */                 HistoryStore2.this.removeUnreferencedBlobs(100);
/* 177 */                 return monitor.isCanceled() ? 1 : 0;
/*     */               }
/* 179 */             }(IPath)Path.ROOT, 2147483647);
/*     */       }
/* 181 */       if (Policy.DEBUG_HISTORY) {
/* 182 */         Policy.debug("Time to apply history store policies: " + (System.currentTimeMillis() - start) + "ms.");
/* 183 */         Policy.debug("Total number of history store entries: " + entryCount[0]);
/*     */       } 
/*     */       
/* 186 */       removeUnreferencedBlobs(0);
/* 187 */     } catch (Exception e) {
/* 188 */       String message = Messages.history_problemsCleaning;
/* 189 */       ResourceStatus status = new ResourceStatus(273, null, message, e);
/* 190 */       Policy.log((IStatus)status);
/*     */     } finally {
/* 192 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeUnreferencedBlobs(int limit) {
/* 202 */     if (limit <= 0 || limit <= this.blobsToRemove.size()) {
/* 203 */       long start = System.currentTimeMillis();
/*     */       
/* 205 */       this.blobStore.deleteBlobs(this.blobsToRemove);
/* 206 */       if (Policy.DEBUG_HISTORY)
/* 207 */         Policy.debug("Time to remove " + this.blobsToRemove.size() + " unreferenced blobs: " + (System.currentTimeMillis() - start) + "ms."); 
/* 208 */       this.blobsToRemove = new HashSet<>();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void closeHistoryStore(IResource resource) {
/*     */     try {
/* 215 */       this.tree.getCurrent().save();
/* 216 */       this.tree.getCurrent().flush();
/* 217 */     } catch (CoreException e) {
/* 218 */       log(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void copyHistory(IResource sourceResource, IResource destinationResource, boolean moving) {
/* 226 */     if (sourceResource == null || destinationResource == null) {
/* 227 */       String message = Messages.history_copyToNull;
/* 228 */       ResourceStatus status = new ResourceStatus(566, null, message, null);
/* 229 */       Policy.log((IStatus)status);
/*     */       return;
/*     */     } 
/* 232 */     if (sourceResource.equals(destinationResource)) {
/* 233 */       String message = Messages.history_copyToSelf;
/* 234 */       ResourceStatus status = new ResourceStatus(566, sourceResource.getFullPath(), message, null);
/* 235 */       Policy.log((IStatus)status);
/*     */       
/*     */       return;
/*     */     } 
/* 239 */     IPath source = sourceResource.getFullPath();
/* 240 */     IPath destination = destinationResource.getFullPath();
/* 241 */     Assert.isLegal((source.segmentCount() > 0));
/* 242 */     Assert.isLegal((destination.segmentCount() > 0));
/* 243 */     Assert.isLegal(!(source.segmentCount() <= 1 && destination.segmentCount() != 1));
/*     */ 
/*     */     
/*     */     try {
/* 247 */       if (moving && sourceResource.getType() == 4) {
/*     */         
/* 249 */         Bucket bucket = this.tree.getCurrent();
/* 250 */         bucket.save();
/* 251 */         bucket.flush();
/*     */         
/*     */         return;
/*     */       } 
/* 255 */       HistoryCopyVisitor copyVisitor = new HistoryCopyVisitor(source, destination);
/* 256 */       this.tree.accept(copyVisitor, source, 2147483647);
/*     */       
/* 258 */       applyPolicy(destinationResource.getFullPath());
/* 259 */     } catch (CoreException e) {
/* 260 */       log(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean exists(IFileState target) {
/* 266 */     return this.blobStore.fileFor(((FileState)target).getUUID()).fetchInfo().exists();
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getContents(IFileState target) throws CoreException {
/* 271 */     if (!target.exists()) {
/* 272 */       String message = Messages.history_notValid;
/* 273 */       throw new ResourceException(271, target.getFullPath(), message, null);
/*     */     } 
/* 275 */     return this.blobStore.getBlob(((FileState)target).getUUID());
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized IFileState[] getStates(IPath filePath, IProgressMonitor monitor) {
/*     */     try {
/* 281 */       this.tree.loadBucketFor(filePath);
/* 282 */       HistoryBucket currentBucket = (HistoryBucket)this.tree.getCurrent();
/* 283 */       HistoryBucket.HistoryEntry fileEntry = currentBucket.getEntry(filePath);
/* 284 */       if (fileEntry == null || fileEntry.isEmpty())
/* 285 */         return new IFileState[0]; 
/* 286 */       IFileState[] states = new IFileState[fileEntry.getOccurrences()];
/* 287 */       for (int i = 0; i < states.length; i++)
/* 288 */         states[i] = (IFileState)new FileState(this, fileEntry.getPath(), fileEntry.getTimestamp(i), fileEntry.getUUID(i)); 
/* 289 */       return states;
/* 290 */     } catch (CoreException ce) {
/* 291 */       log(ce);
/* 292 */       return new IFileState[0];
/*     */     } 
/*     */   }
/*     */   
/*     */   public BucketTree getTree() {
/* 297 */     return this.tree;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isValid(IFileStore localFile, IFileInfo info) {
/* 310 */     WorkspaceDescription description = this.workspace.internalGetDescription();
/* 311 */     if (!description.isApplyFileStatePolicy())
/* 312 */       return true; 
/* 313 */     long length = info.getLength();
/* 314 */     boolean result = (length <= description.getMaxFileStateSize());
/* 315 */     if (Policy.DEBUG_HISTORY && !result)
/* 316 */       Policy.debug("History: Ignoring file (too large). File: " + localFile.toString() + 
/* 317 */           ", size: " + length + 
/* 318 */           ", max: " + description.getMaxFileStateSize()); 
/* 319 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void log(CoreException e) {
/*     */     Status status1;
/* 327 */     IStatus status = e.getStatus();
/* 328 */     if (status.getException() == null)
/* 329 */       status1 = new Status(4, "org.eclipse.core.resources", 568, "Internal error in history store", (Throwable)e); 
/* 330 */     Policy.log((IStatus)status1);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void remove(IPath root, IProgressMonitor monitor) {
/*     */     try {
/* 336 */       final Set<UniversalUniqueIdentifier> tmpBlobsToRemove = this.blobsToRemove;
/* 337 */       this.tree.accept(new Bucket.Visitor()
/*     */           {
/*     */             public int visit(Bucket.Entry fileEntry) {
/* 340 */               for (int i = 0; i < fileEntry.getOccurrences(); i++)
/*     */               {
/* 342 */                 tmpBlobsToRemove.add(((HistoryBucket.HistoryEntry)fileEntry).getUUID(i)); } 
/* 343 */               fileEntry.delete();
/* 344 */               return 0;
/*     */             }
/* 346 */           }root, 2147483647);
/* 347 */     } catch (CoreException ce) {
/* 348 */       log(ce);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void removeGarbage() {
/*     */     try {
/* 358 */       final Set<UniversalUniqueIdentifier> tmpBlobsToRemove = this.blobsToRemove;
/* 359 */       this.tree.accept(new Bucket.Visitor()
/*     */           {
/*     */             public int visit(Bucket.Entry fileEntry) {
/* 362 */               for (int i = 0; i < fileEntry.getOccurrences(); i++)
/*     */               {
/* 364 */                 tmpBlobsToRemove.remove(((HistoryBucket.HistoryEntry)fileEntry).getUUID(i)); } 
/* 365 */               return 0;
/*     */             }
/* 367 */           }(IPath)Path.ROOT, 2147483647);
/* 368 */       this.blobStore.deleteBlobs(this.blobsToRemove);
/* 369 */       this.blobsToRemove = new HashSet<>();
/* 370 */     } catch (Exception e) {
/* 371 */       String message = Messages.history_problemsCleaning;
/* 372 */       ResourceStatus status = new ResourceStatus(273, null, message, e);
/* 373 */       Policy.log((IStatus)status);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void shutdown(IProgressMonitor monitor) throws CoreException {
/* 379 */     this.tree.close();
/*     */   }
/*     */   
/*     */   public void startup(IProgressMonitor monitor) {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\HistoryStore2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */