/*    */ package org.eclipse.core.internal.propertytester;
/*    */ 
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.QualifiedName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceMappingPropertyTester
/*    */   extends ResourcePropertyTester
/*    */ {
/*    */   public boolean test(Object receiver, String method, Object[] args, Object expectedValue) {
/*    */     String propertyName, expectedVal;
/* 29 */     if (!(receiver instanceof ResourceMapping))
/* 30 */       return false; 
/* 31 */     if (!method.equals("projectPersistentProperty")) {
/* 32 */       return false;
/*    */     }
/*    */     
/* 35 */     IProject[] projects = ((ResourceMapping)receiver).getProjects();
/* 36 */     if (projects.length == 0) {
/* 37 */       return false;
/*    */     }
/*    */     
/* 40 */     switch (args.length) {
/*    */       case 0:
/* 42 */         propertyName = toString(expectedValue);
/* 43 */         expectedVal = null;
/*    */         break;
/*    */       case 1:
/* 46 */         propertyName = toString(args[0]);
/* 47 */         expectedVal = null;
/*    */         break;
/*    */       default:
/* 50 */         propertyName = toString(args[0]);
/* 51 */         expectedVal = toString(args[1]);
/*    */         break;
/*    */     } 
/* 54 */     QualifiedName key = toQualifedName(propertyName);
/* 55 */     boolean found = false; byte b; int i; IProject[] arrayOfIProject1;
/* 56 */     for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/*    */       try {
/* 58 */         Object actualVal = project.getPersistentProperty(key);
/*    */         
/* 60 */         if (actualVal != null)
/*    */         
/*    */         { 
/* 63 */           found = true;
/*    */           
/* 65 */           if (expectedVal != null)
/*    */           {
/*    */             
/* 68 */             if (!expectedVal.equals(actualVal.toString()))
/* 69 */               return false;  }  } 
/* 70 */       } catch (CoreException coreException) {}
/*    */       
/*    */       b++; }
/*    */ 
/*    */     
/* 75 */     return found;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\propertytester\ResourceMappingPropertyTester.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */