/*     */ package org.eclipse.core.internal.resources.refresh.win32;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.resources.refresh.IRefreshMonitor;
/*     */ import org.eclipse.core.resources.refresh.IRefreshResult;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Win32Monitor
/*     */   extends Job
/*     */   implements IRefreshMonitor
/*     */ {
/*     */   private static final long RESCHEDULE_DELAY = 3000L;
/*     */   private static final int WAIT_FOR_MULTIPLE_OBJECTS_TIMEOUT = 1000;
/*     */   private static final String DEBUG_PREFIX = "Win32RefreshMonitor: ";
/*     */   protected MultiStatus errors;
/*     */   protected long[][] fHandleValueArrays;
/*     */   protected Map<Long, Handle> fHandleValueToHandle;
/*     */   protected IRefreshResult refreshResult;
/*     */   
/*     */   protected abstract class ChainedHandle
/*     */     extends Handle
/*     */   {
/*     */     private ChainedHandle next;
/*     */     private ChainedHandle previous;
/*     */     
/*     */     public abstract boolean exists();
/*     */     
/*     */     public ChainedHandle getNext() {
/*  60 */       return this.next;
/*     */     }
/*     */     
/*     */     public ChainedHandle getPrevious() {
/*  64 */       return this.previous;
/*     */     }
/*     */     
/*     */     public void setNext(ChainedHandle next) {
/*  68 */       this.next = next;
/*     */     }
/*     */     
/*     */     public void setPrevious(ChainedHandle previous) {
/*  72 */       this.previous = previous;
/*     */     }
/*     */   }
/*     */   
/*     */   protected class FileHandle extends ChainedHandle {
/*     */     private File file;
/*     */     
/*     */     public FileHandle(File file) {
/*  80 */       this.file = file;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean exists() {
/*  85 */       return this.file.exists();
/*     */     }
/*     */ 
/*     */     
/*     */     public void handleNotification() {
/*  90 */       if (!isOpen())
/*     */         return; 
/*  92 */       Win32Monitor.ChainedHandle next = getNext();
/*  93 */       if (next != null)
/*  94 */         if (next.isOpen()) {
/*  95 */           if (!next.exists()) {
/*  96 */             next.close();
/*  97 */             if (next instanceof Win32Monitor.LinkedResourceHandle) {
/*  98 */               Win32Monitor.LinkedResourceHandle linkedResourceHandle = (Win32Monitor.LinkedResourceHandle)next;
/*  99 */               linkedResourceHandle.postRefreshRequest();
/*     */             } 
/* 101 */             Win32Monitor.ChainedHandle previous = getPrevious();
/* 102 */             if (previous != null)
/* 103 */               previous.open(); 
/*     */           } 
/*     */         } else {
/* 106 */           next.open();
/* 107 */           if (next.isOpen()) {
/* 108 */             Win32Monitor.Handle previous = getPrevious();
/* 109 */             previous.close();
/* 110 */             if (next instanceof Win32Monitor.LinkedResourceHandle) {
/* 111 */               ((Win32Monitor.LinkedResourceHandle)next).postRefreshRequest();
/*     */             }
/*     */           } 
/*     */         }  
/* 115 */       findNextChange();
/*     */     }
/*     */ 
/*     */     
/*     */     public void open() {
/* 120 */       if (!isOpen()) {
/* 121 */         Win32Monitor.Handle next = getNext();
/* 122 */         if (next != null && next.isOpen()) {
/* 123 */           openHandleOn(this.file);
/*     */         } else {
/* 125 */           if (exists()) {
/* 126 */             openHandleOn(this.file);
/*     */           }
/* 128 */           Win32Monitor.Handle previous = getPrevious();
/* 129 */           if (previous != null) {
/* 130 */             previous.open();
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 138 */       return this.file.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract class Handle implements Closeable {
/*     */     protected long handleValue;
/*     */     
/*     */     public Handle() {
/* 146 */       this.handleValue = Win32Natives.INVALID_HANDLE_VALUE;
/*     */     }
/*     */ 
/*     */     
/*     */     public void close() {
/* 151 */       if (isOpen()) {
/* 152 */         if (!Win32Natives.FindCloseChangeNotification(this.handleValue)) {
/* 153 */           int error = Win32Natives.GetLastError();
/* 154 */           if (error != Win32Natives.ERROR_INVALID_HANDLE)
/* 155 */             Win32Monitor.this.addException(NLS.bind(Messages.WM_errCloseHandle, Integer.toString(error))); 
/*     */         } 
/* 157 */         if (Policy.DEBUG_AUTO_REFRESH)
/* 158 */           Policy.debug("Win32RefreshMonitor: removed handle: " + this.handleValue); 
/* 159 */         this.handleValue = Win32Natives.INVALID_HANDLE_VALUE;
/*     */       } 
/*     */     }
/*     */     
/*     */     private long createHandleValue(String path, boolean monitorSubtree, int flags) {
/* 164 */       long handle = Win32Natives.FindFirstChangeNotification(path, monitorSubtree, flags);
/* 165 */       if (handle == Win32Natives.INVALID_HANDLE_VALUE) {
/* 166 */         int error = Win32Natives.GetLastError();
/* 167 */         Win32Monitor.this.addException(NLS.bind(Messages.WM_errCreateHandle, path, Integer.toString(error)));
/*     */       } 
/* 169 */       return handle;
/*     */     }
/*     */     
/*     */     public void destroy() {
/* 173 */       close();
/*     */     }
/*     */     
/*     */     protected void findNextChange() {
/* 177 */       if (!Win32Natives.FindNextChangeNotification(this.handleValue)) {
/* 178 */         int error = Win32Natives.GetLastError();
/* 179 */         if (error != Win32Natives.ERROR_INVALID_HANDLE && error != Win32Natives.ERROR_SUCCESS) {
/* 180 */           Win32Monitor.this.addException(NLS.bind(Messages.WM_errFindChange, Integer.toString(error)));
/*     */         }
/* 182 */         Win32Monitor.this.removeHandle(this);
/*     */       } 
/*     */     }
/*     */     
/*     */     public long getHandleValue() {
/* 187 */       return this.handleValue;
/*     */     }
/*     */     
/*     */     public abstract void handleNotification();
/*     */     
/*     */     public boolean isOpen() {
/* 193 */       return (this.handleValue != Win32Natives.INVALID_HANDLE_VALUE);
/*     */     }
/*     */     
/*     */     public abstract void open();
/*     */     
/*     */     protected void openHandleOn(File file) {
/* 199 */       openHandleOn(file.getAbsolutePath(), false);
/*     */     }
/*     */     
/*     */     protected void openHandleOn(IResource resource) {
/* 203 */       IPath location = resource.getLocation();
/* 204 */       if (location != null) {
/* 205 */         openHandleOn(location.toOSString(), true);
/*     */       }
/*     */     }
/*     */     
/*     */     private void openHandleOn(String path, boolean subtree) {
/* 210 */       setHandleValue(createHandleValue(path, subtree, Win32Natives.FILE_NOTIFY_CHANGE_FILE_NAME | Win32Natives.FILE_NOTIFY_CHANGE_DIR_NAME | Win32Natives.FILE_NOTIFY_CHANGE_LAST_WRITE | Win32Natives.FILE_NOTIFY_CHANGE_SIZE));
/* 211 */       if (isOpen()) {
/* 212 */         Win32Monitor.this.fHandleValueToHandle.put(Long.valueOf(getHandleValue()), this);
/* 213 */         Win32Monitor.this.setHandleValueArrays(Win32Monitor.this.createHandleArrays());
/*     */       } else {
/* 215 */         close();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected void postRefreshRequest(IResource resource) {
/* 221 */       if (!resource.isSynchronized(2))
/* 222 */         Win32Monitor.this.refreshResult.refresh(resource); 
/*     */     }
/*     */     
/*     */     public void setHandleValue(long handleValue) {
/* 226 */       this.handleValue = handleValue;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected class LinkedResourceHandle
/*     */     extends ChainedHandle
/*     */   {
/*     */     private List<Win32Monitor.FileHandle> fileHandleChain;
/*     */     private IResource resource;
/*     */     
/*     */     public LinkedResourceHandle(IResource resource) {
/* 238 */       this.resource = resource;
/* 239 */       createFileHandleChain();
/*     */     }
/*     */     
/*     */     protected void createFileHandleChain() {
/* 243 */       this.fileHandleChain = new ArrayList<>(1);
/* 244 */       File file = new File(this.resource.getLocation().toOSString());
/* 245 */       file = file.getParentFile();
/* 246 */       while (file != null) {
/* 247 */         this.fileHandleChain.add(0, new Win32Monitor.FileHandle(file));
/* 248 */         file = file.getParentFile();
/*     */       } 
/* 250 */       int size = this.fileHandleChain.size();
/* 251 */       for (int i = 0; i < size; i++) {
/* 252 */         Win32Monitor.ChainedHandle handle = this.fileHandleChain.get(i);
/* 253 */         handle.setPrevious((i > 0) ? this.fileHandleChain.get(i - 1) : null);
/* 254 */         handle.setNext((i + 1 < size) ? this.fileHandleChain.get(i + 1) : this);
/*     */       } 
/* 256 */       setPrevious((size > 0) ? this.fileHandleChain.get(size - 1) : null);
/*     */     }
/*     */ 
/*     */     
/*     */     public void destroy() {
/* 261 */       super.destroy();
/* 262 */       for (Win32Monitor.FileHandle fileHandle : this.fileHandleChain) {
/* 263 */         Win32Monitor.Handle handle = fileHandle;
/* 264 */         handle.destroy();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean exists() {
/* 270 */       IPath location = this.resource.getLocation();
/* 271 */       return (location == null) ? false : location.toFile().exists();
/*     */     }
/*     */ 
/*     */     
/*     */     public void handleNotification() {
/* 276 */       if (isOpen()) {
/* 277 */         postRefreshRequest(this.resource);
/* 278 */         findNextChange();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void open() {
/* 284 */       if (!isOpen()) {
/* 285 */         if (exists()) {
/* 286 */           openHandleOn(this.resource);
/*     */         }
/* 288 */         Win32Monitor.FileHandle handle = (Win32Monitor.FileHandle)getPrevious();
/* 289 */         if (handle != null && !handle.isOpen()) {
/* 290 */           handle.open();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     public void postRefreshRequest() {
/* 296 */       postRefreshRequest(this.resource);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 301 */       return this.resource.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   protected class ResourceHandle
/*     */     extends Handle {
/*     */     private IResource resource;
/*     */     
/*     */     public ResourceHandle(IResource resource) {
/* 310 */       this.resource = resource;
/*     */     }
/*     */     
/*     */     public IResource getResource() {
/* 314 */       return this.resource;
/*     */     }
/*     */ 
/*     */     
/*     */     public void handleNotification() {
/* 319 */       if (isOpen()) {
/* 320 */         postRefreshRequest(this.resource);
/* 321 */         findNextChange();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void open() {
/* 327 */       if (!isOpen()) {
/* 328 */         openHandleOn(this.resource);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 334 */       return this.resource.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Win32Monitor(IRefreshResult result) {
/* 359 */     super(Messages.WM_jobName);
/* 360 */     this.refreshResult = result;
/* 361 */     setPriority(50);
/* 362 */     setSystem(true);
/* 363 */     this.fHandleValueToHandle = new HashMap<>(1);
/* 364 */     setHandleValueArrays(createHandleArrays());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void addException(String message) {
/* 371 */     if (this.errors == null) {
/* 372 */       String msg = Messages.WM_errors;
/* 373 */       this.errors = new MultiStatus("org.eclipse.core.resources", 1, msg, null);
/*     */     } 
/* 375 */     this.errors.add((IStatus)new Status(4, "org.eclipse.core.resources", 1, message, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long[][] balancedSplit(long[] array, int max) {
/* 387 */     int elementCount = array.length;
/*     */     
/* 389 */     int subArrayCount = (elementCount - 1) / max + 1;
/* 390 */     int subArrayBaseLength = elementCount / subArrayCount;
/* 391 */     int overflow = elementCount % subArrayCount;
/* 392 */     long[][] result = new long[subArrayCount][];
/* 393 */     int count = 0;
/* 394 */     for (int i = 0; i < subArrayCount; i++) {
/* 395 */       int subArrayLength = subArrayBaseLength + ((overflow-- > 0) ? 1 : 0);
/* 396 */       long[] subArray = new long[subArrayLength];
/* 397 */       for (int j = 0; j < subArrayLength; j++) {
/* 398 */         subArray[j] = array[count++];
/*     */       }
/* 400 */       result[i] = subArray;
/*     */     } 
/* 402 */     return result;
/*     */   }
/*     */   
/*     */   private Handle createHandle(IResource resource) {
/* 406 */     if (resource.isLinked())
/* 407 */       return new LinkedResourceHandle(resource); 
/* 408 */     return new ResourceHandle(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long[][] createHandleArrays() {
/*     */     long[] handles;
/* 422 */     synchronized (this.fHandleValueToHandle) {
/* 423 */       Set<Long> keys = this.fHandleValueToHandle.keySet();
/* 424 */       int size = keys.size();
/* 425 */       if (size == 0) {
/* 426 */         return new long[0][0];
/*     */       }
/* 428 */       handles = new long[size];
/* 429 */       int count = 0;
/* 430 */       for (Long long2 : keys) {
/* 431 */         handles[count++] = long2.longValue();
/*     */       }
/*     */     } 
/* 434 */     return balancedSplit(handles, Win32Natives.MAXIMUM_WAIT_OBJECTS);
/*     */   }
/*     */   
/*     */   private Handle getHandle(IResource resource) {
/* 438 */     if (resource == null) {
/* 439 */       return null;
/*     */     }
/*     */     
/* 442 */     synchronized (this.fHandleValueToHandle) {
/* 443 */       for (Handle handle : this.fHandleValueToHandle.values()) {
/* 444 */         if (handle instanceof ResourceHandle) {
/* 445 */           ResourceHandle resourceHandle = (ResourceHandle)handle;
/* 446 */           if (resourceHandle.getResource().equals(resource)) {
/* 447 */             return handle;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 452 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long[][] getHandleValueArrays() {
/* 461 */     return this.fHandleValueArrays;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean monitor(IResource resource) {
/* 468 */     IPath location = resource.getLocation();
/* 469 */     if (location == null)
/*     */     {
/* 471 */       return false;
/*     */     }
/* 473 */     Handle handle = createHandle(resource);
/*     */     
/* 475 */     synchronized (this) {
/* 476 */       handle.open();
/*     */     } 
/* 478 */     if (!handle.isOpen()) {
/*     */ 
/*     */       
/* 481 */       this.errors = null;
/* 482 */       return false;
/*     */     } 
/*     */     
/* 485 */     schedule(3000L);
/* 486 */     if (Policy.DEBUG_AUTO_REFRESH)
/* 487 */       Policy.debug("Win32RefreshMonitor:  added monitor for: " + resource); 
/* 488 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeHandle(Handle handle) {
/* 498 */     List<Handle> handles = new ArrayList<>(1);
/* 499 */     handles.add(handle);
/* 500 */     removeHandles(handles);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeHandles(Collection<Handle> handles) {
/* 514 */     synchronized (this) {
/* 515 */       for (Handle handle : handles) {
/* 516 */         this.fHandleValueToHandle.remove(Long.valueOf(handle.getHandleValue()));
/* 517 */         handle.destroy();
/*     */       } 
/* 519 */       setHandleValueArrays(createHandleArrays());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IStatus run(IProgressMonitor monitor) {
/* 528 */     long start = -System.currentTimeMillis();
/* 529 */     if (Policy.DEBUG_AUTO_REFRESH)
/* 530 */       Policy.debug("Win32RefreshMonitor: job started."); 
/*     */     try {
/* 532 */       long[][] handleArrays = getHandleValueArrays();
/* 533 */       monitor.beginTask(Messages.WM_beginTask, handleArrays.length); byte b;
/*     */       int i;
/*     */       long[][] arrayOfLong1;
/* 536 */       for (i = (arrayOfLong1 = handleArrays).length, b = 0; b < i; ) { long[] handleArray = arrayOfLong1[b];
/* 537 */         if (monitor.isCanceled())
/* 538 */           return Status.CANCEL_STATUS; 
/* 539 */         waitForNotification(handleArray);
/* 540 */         monitor.worked(1); b++; }
/*     */     
/*     */     } finally {
/* 543 */       monitor.done();
/* 544 */       start += System.currentTimeMillis();
/* 545 */       if (Policy.DEBUG_AUTO_REFRESH) {
/* 546 */         Policy.debug("Win32RefreshMonitor: job finished in: " + start + "ms");
/*     */       }
/*     */     } 
/* 549 */     long delay = Math.max(3000L, start);
/* 550 */     if (Policy.DEBUG_AUTO_REFRESH)
/* 551 */       Policy.debug("Win32RefreshMonitor: rescheduling in: " + (delay / 1000L) + " seconds"); 
/* 552 */     Bundle bundle = Platform.getBundle("org.eclipse.core.resources");
/*     */     
/* 554 */     if (bundle == null) {
/* 555 */       return Status.OK_STATUS;
/*     */     }
/* 557 */     if (bundle.getState() == 32)
/* 558 */       schedule(delay); 
/* 559 */     MultiStatus result = this.errors;
/* 560 */     this.errors = null;
/*     */     
/* 562 */     if (result != null && !result.isOK())
/* 563 */       ResourcesPlugin.getPlugin().getLog().log((IStatus)result); 
/* 564 */     return Status.OK_STATUS;
/*     */   }
/*     */   
/*     */   protected void setHandleValueArrays(long[][] arrays) {
/* 568 */     this.fHandleValueArrays = arrays;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean shouldRun() {
/* 573 */     return !this.fHandleValueToHandle.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public void unmonitor(IResource resource) {
/* 578 */     if (resource == null) {
/*     */       
/* 580 */       synchronized (this.fHandleValueToHandle) {
/* 581 */         removeHandles(new ArrayList<>(this.fHandleValueToHandle.values()));
/*     */       } 
/*     */     } else {
/* 584 */       Handle handle = getHandle(resource);
/* 585 */       if (handle != null) {
/* 586 */         removeHandle(handle);
/*     */       }
/*     */     } 
/* 589 */     if (this.fHandleValueToHandle.isEmpty()) {
/* 590 */       cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void waitForNotification(long[] handleValues) {
/* 601 */     int handleCount = handleValues.length;
/* 602 */     int index = Win32Natives.WaitForMultipleObjects(handleCount, handleValues, false, 1000);
/* 603 */     if (index == Win32Natives.WAIT_TIMEOUT) {
/*     */       return;
/*     */     }
/*     */     
/* 607 */     if (index == Win32Natives.WAIT_FAILED) {
/*     */       
/* 609 */       int error = Win32Natives.GetLastError();
/* 610 */       if (error != Win32Natives.ERROR_INVALID_HANDLE && error != Win32Natives.ERROR_SUCCESS) {
/* 611 */         if (error != 5) {
/* 612 */           addException(NLS.bind(Messages.WM_nativeErr, Integer.toString(error)));
/*     */         }
/* 614 */         this.refreshResult.monitorFailed(this, null);
/*     */       } 
/*     */       return;
/*     */     } 
/* 618 */     if (index >= Win32Natives.WAIT_ABANDONED_0) {
/*     */ 
/*     */       
/* 621 */       index -= Win32Natives.WAIT_ABANDONED_0;
/* 622 */       Handle handle1 = this.fHandleValueToHandle.get(Long.valueOf(handleValues[index]));
/* 623 */       addException(NLS.bind(Messages.WM_mutexAbandoned, handle1));
/* 624 */       this.refreshResult.monitorFailed(this, null);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 629 */     index -= Win32Natives.WAIT_OBJECT_0;
/* 630 */     Handle handle = this.fHandleValueToHandle.get(Long.valueOf(handleValues[index]));
/* 631 */     if (handle != null)
/* 632 */       handle.handleNotification(); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\refresh\win32\Win32Monitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */