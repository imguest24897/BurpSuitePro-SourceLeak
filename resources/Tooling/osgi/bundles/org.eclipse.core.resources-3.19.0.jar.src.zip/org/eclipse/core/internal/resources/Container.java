/*     */ package org.eclipse.core.internal.resources;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.internal.events.LifecycleEvent;
/*     */ import org.eclipse.core.internal.localstore.IHistoryStore;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.internal.utils.WrappedRuntimeException;
/*     */ import org.eclipse.core.internal.watson.ElementTree;
/*     */ import org.eclipse.core.internal.watson.ElementTreeIterator;
/*     */ import org.eclipse.core.internal.watson.IElementContentVisitor;
/*     */ import org.eclipse.core.internal.watson.IPathRequestor;
/*     */ import org.eclipse.core.resources.FileInfoMatcherDescription;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IFolder;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceFilterDescription;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ public abstract class Container extends Resource implements IContainer {
/*     */   protected Container(IPath path, Workspace container) {
/*  30 */     super(path, container);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void convertToPhantom() throws CoreException {
/*  39 */     if (isPhantom())
/*     */       return; 
/*  41 */     super.convertToPhantom();
/*  42 */     IResource[] members = members(11); byte b; int i; IResource[] arrayOfIResource1;
/*  43 */     for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource member = arrayOfIResource1[b];
/*  44 */       ((Resource)member).convertToPhantom();
/*     */       b++; }
/*     */   
/*     */   }
/*     */   public IResourceFilterDescription createFilter(int type, FileInfoMatcherDescription matcherDescription, int updateFlags, IProgressMonitor monitor) throws CoreException {
/*  49 */     Assert.isNotNull(getProject());
/*  50 */     monitor = Policy.monitorFor(monitor);
/*  51 */     FilterDescription filter = null;
/*     */     try {
/*  53 */       String message = NLS.bind(Messages.links_creating, getFullPath());
/*  54 */       monitor.beginTask(message, 100);
/*  55 */       Policy.checkCanceled(monitor);
/*  56 */       checkValidPath(this.path, 6, true);
/*  57 */       ISchedulingRule rule = this.workspace.getRuleFactory().createRule(this);
/*     */       try {
/*  59 */         this.workspace.prepareOperation(rule, monitor);
/*  60 */         this.workspace.broadcastEvent(LifecycleEvent.newEvent(131072, this));
/*  61 */         this.workspace.beginOperation(true);
/*  62 */         monitor.worked(Policy.opWork * 5 / 100);
/*     */         
/*  64 */         filter = new FilterDescription(this, type, matcherDescription);
/*  65 */         filter.setId(System.currentTimeMillis());
/*     */         
/*  67 */         Project project = (Project)getProject();
/*  68 */         project.internalGetDescription().addFilter(getProjectRelativePath(), filter);
/*  69 */         project.writeDescription(0);
/*  70 */         monitor.worked(Policy.opWork * 5 / 100);
/*     */ 
/*     */         
/*  73 */         if (getType() != 1)
/*     */         
/*  75 */         { if ((updateFlags & 0x80) != 0) {
/*  76 */             this.workspace.refreshManager.refresh(this);
/*  77 */             monitor.worked(Policy.opWork * 90 / 100);
/*     */           } else {
/*  79 */             refreshLocal(2, Policy.subMonitorFor(monitor, Policy.opWork * 90 / 100));
/*     */           }  }
/*     */         else
/*  82 */         { monitor.worked(Policy.opWork * 90 / 100); } 
/*  83 */       } catch (OperationCanceledException e) {
/*  84 */         this.workspace.getWorkManager().operationCanceled();
/*  85 */         throw e;
/*     */       } finally {
/*  87 */         this.workspace.endOperation(rule, true);
/*     */       } 
/*     */     } finally {
/*  90 */       monitor.done();
/*     */     } 
/*  92 */     return filter;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean exists(IPath childPath) {
/*  97 */     return (this.workspace.getResourceInfo(getFullPath().append(childPath), false, false) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource findMember(String memberPath) {
/* 102 */     return findMember(memberPath, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource findMember(String memberPath, boolean phantom) {
/* 107 */     IPath childPath = getFullPath().append(memberPath);
/* 108 */     ResourceInfo info = this.workspace.getResourceInfo(childPath, phantom, false);
/* 109 */     return (info == null) ? null : this.workspace.newResource(childPath, info.getType());
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource findMember(IPath childPath) {
/* 114 */     return findMember(childPath, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource findMember(IPath childPath, boolean phantom) {
/* 119 */     childPath = getFullPath().append(childPath);
/* 120 */     ResourceInfo info = this.workspace.getResourceInfo(childPath, phantom, false);
/* 121 */     return (info == null) ? null : this.workspace.newResource(childPath, info.getType());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void fixupAfterMoveSource() throws CoreException {
/* 126 */     super.fixupAfterMoveSource();
/* 127 */     if (!synchronizing(getResourceInfo(true, false)))
/*     */       return; 
/* 129 */     IResource[] members = members(11); byte b; int i; IResource[] arrayOfIResource1;
/* 130 */     for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource member = arrayOfIResource1[b];
/* 131 */       ((Resource)member).fixupAfterMoveSource();
/*     */       b++; }
/*     */   
/*     */   } protected IResource[] getChildren(int memberFlags) {
/* 135 */     IPath[] children = null;
/*     */     try {
/* 137 */       children = this.workspace.tree.getChildren(this.path);
/* 138 */     } catch (IllegalArgumentException illegalArgumentException) {}
/*     */ 
/*     */ 
/*     */     
/* 142 */     if (children == null || children.length == 0)
/* 143 */       return ICoreConstants.EMPTY_RESOURCE_ARRAY; 
/* 144 */     Resource[] result = new Resource[children.length];
/* 145 */     int found = 0; byte b; int i; IPath[] arrayOfIPath1;
/* 146 */     for (i = (arrayOfIPath1 = children).length, b = 0; b < i; ) { IPath child = arrayOfIPath1[b];
/* 147 */       ResourceInfo info = this.workspace.getResourceInfo(child, true, false);
/* 148 */       if (info != null && isMember(info.getFlags(), memberFlags))
/* 149 */         result[found++] = this.workspace.newResource(child, info.getType());  b++; }
/*     */     
/* 151 */     if (found == result.length)
/* 152 */       return (IResource[])result; 
/* 153 */     Resource[] trimmedResult = new Resource[found];
/* 154 */     System.arraycopy(result, 0, trimmedResult, 0, found);
/* 155 */     return (IResource[])trimmedResult;
/*     */   }
/*     */   
/*     */   public IFile getFile(String name) {
/* 159 */     return (IFile)this.workspace.newResource(getFullPath().append(name), 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public IResourceFilterDescription[] getFilters() throws CoreException {
/* 164 */     IResourceFilterDescription[] results = null;
/* 165 */     checkValidPath(this.path, 6, true);
/* 166 */     Project project = (Project)getProject();
/* 167 */     ProjectDescription desc = project.internalGetDescription();
/* 168 */     if (desc != null) {
/* 169 */       LinkedList<FilterDescription> list = desc.getFilter(getProjectRelativePath());
/* 170 */       if (list != null) {
/* 171 */         results = new IResourceFilterDescription[list.size()];
/* 172 */         for (int i = 0; i < list.size(); i++) {
/* 173 */           results[i] = list.get(i);
/*     */         }
/* 175 */         return results;
/*     */       } 
/*     */     } 
/* 178 */     return new IResourceFilterDescription[0];
/*     */   }
/*     */   
/*     */   public boolean hasFilters() {
/* 182 */     IProject project = getProject();
/* 183 */     if (project == null)
/* 184 */       return false; 
/* 185 */     ProjectDescription desc = ((Project)project).internalGetDescription();
/* 186 */     if (desc == null)
/* 187 */       return false; 
/* 188 */     LinkedList<FilterDescription> filters = desc.getFilter(getProjectRelativePath());
/* 189 */     if (filters != null && filters.size() > 0)
/* 190 */       return true; 
/* 191 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public IFile getFile(IPath childPath) {
/* 196 */     return (IFile)this.workspace.newResource(getFullPath().append(childPath), 1);
/*     */   }
/*     */   
/*     */   public IFolder getFolder(String name) {
/* 200 */     return (IFolder)this.workspace.newResource(getFullPath().append(name), 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public IFolder getFolder(IPath childPath) {
/* 205 */     return (IFolder)this.workspace.newResource(getFullPath().append(childPath), 2);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean isLocal(int flags, int depth) {
/* 211 */     if (!super.isLocal(flags, depth))
/* 212 */       return false; 
/* 213 */     if (depth == 0)
/* 214 */       return true; 
/* 215 */     if (depth == 1) {
/* 216 */       depth = 0;
/*     */     }
/*     */     
/* 219 */     IResource[] children = getChildren(0); byte b; int i; IResource[] arrayOfIResource1;
/* 220 */     for (i = (arrayOfIResource1 = children).length, b = 0; b < i; ) { IResource c = arrayOfIResource1[b];
/* 221 */       if (!c.isLocal(depth))
/* 222 */         return false; 
/*     */       b++; }
/*     */     
/* 225 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource[] members() throws CoreException {
/* 231 */     return members(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource[] members(boolean phantom) throws CoreException {
/* 237 */     return members(phantom ? 1 : 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource[] members(int memberFlags) throws CoreException {
/* 242 */     boolean phantom = ((memberFlags & 0x1) != 0);
/* 243 */     ResourceInfo info = getResourceInfo(phantom, false);
/* 244 */     checkAccessible(getFlags(info));
/*     */     
/* 246 */     if (info.isSet(1048576))
/* 247 */       this.workspace.refreshManager.refresh(this); 
/* 248 */     return getChildren(memberFlags);
/*     */   }
/*     */   
/*     */   public void removeFilter(IResourceFilterDescription filterDescription, int updateFlags, IProgressMonitor monitor) throws CoreException {
/* 252 */     monitor = Policy.monitorFor(monitor);
/*     */     try {
/* 254 */       String message = NLS.bind(Messages.links_creating, getFullPath());
/* 255 */       monitor.beginTask(message, 100);
/* 256 */       Policy.checkCanceled(monitor);
/* 257 */       checkValidPath(this.path, 6, true);
/* 258 */       ISchedulingRule rule = this.workspace.getRuleFactory().createRule(this);
/*     */       try {
/* 260 */         this.workspace.prepareOperation(rule, monitor);
/* 261 */         this.workspace.broadcastEvent(LifecycleEvent.newEvent(262144, this));
/* 262 */         this.workspace.beginOperation(true);
/* 263 */         monitor.worked(Policy.opWork * 5 / 100);
/*     */         
/* 265 */         Project project = (Project)getProject();
/* 266 */         project.internalGetDescription().removeFilter(getProjectRelativePath(), (FilterDescription)filterDescription);
/* 267 */         project.writeDescription(0);
/* 268 */         monitor.worked(Policy.opWork * 5 / 100);
/*     */ 
/*     */         
/* 271 */         if (getType() != 1)
/*     */         
/* 273 */         { if ((updateFlags & 0x80) != 0) {
/* 274 */             this.workspace.refreshManager.refresh(this);
/* 275 */             monitor.worked(Policy.opWork * 90 / 100);
/*     */           } else {
/* 277 */             refreshLocal(2, Policy.subMonitorFor(monitor, Policy.opWork * 90 / 100));
/*     */           }  }
/*     */         else
/* 280 */         { monitor.worked(Policy.opWork * 90 / 100); } 
/* 281 */       } catch (OperationCanceledException e) {
/* 282 */         this.workspace.getWorkManager().operationCanceled();
/* 283 */         throw e;
/*     */       } finally {
/* 285 */         this.workspace.endOperation(rule, true);
/*     */       } 
/*     */     } finally {
/* 288 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDefaultCharset() throws CoreException {
/* 294 */     return getDefaultCharset(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public IFile[] findDeletedMembersWithHistory(int depth, IProgressMonitor monitor) {
/* 299 */     IHistoryStore historyStore = getLocalManager().getHistoryStore();
/* 300 */     IPath basePath = getFullPath();
/* 301 */     IWorkspaceRoot root = getWorkspace().getRoot();
/* 302 */     Set<IFile> deletedFiles = new HashSet<>();
/*     */     
/* 304 */     if (depth == 0) {
/*     */       
/* 306 */       if ((historyStore.getStates(basePath, monitor)).length > 0) {
/* 307 */         IFile file = root.getFile(basePath);
/* 308 */         if (!file.exists()) {
/* 309 */           deletedFiles.add(file);
/*     */         }
/*     */       } 
/*     */     } else {
/*     */       
/* 314 */       for (IPath filePath : historyStore.allFiles(basePath, depth, monitor)) {
/* 315 */         IFile file = root.getFile(filePath);
/* 316 */         if (!file.exists()) {
/* 317 */           deletedFiles.add(file);
/*     */         }
/*     */       } 
/*     */     } 
/* 321 */     return deletedFiles.<IFile>toArray(new IFile[deletedFiles.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setDefaultCharset(String charset) throws CoreException {
/* 327 */     ResourceInfo info = getResourceInfo(false, false);
/* 328 */     checkAccessible(getFlags(info));
/* 329 */     this.workspace.getCharsetManager().setCharsetFor(getFullPath(), charset);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDefaultCharset(String newCharset, IProgressMonitor monitor) throws CoreException {
/* 334 */     monitor = Policy.monitorFor(monitor);
/*     */     try {
/* 336 */       String message = NLS.bind(Messages.resources_settingDefaultCharsetContainer, getFullPath());
/* 337 */       monitor.beginTask(message, 100);
/*     */ 
/*     */       
/* 340 */       ISchedulingRule rule = this.workspace.getRuleFactory().charsetRule(this);
/*     */       try {
/* 342 */         this.workspace.prepareOperation(rule, monitor);
/* 343 */         checkAccessible(getFlags(getResourceInfo(false, false)));
/* 344 */         this.workspace.beginOperation(true);
/* 345 */         this.workspace.getCharsetManager().setCharsetFor(getFullPath(), newCharset);
/*     */         
/* 347 */         IElementContentVisitor visitor = new IElementContentVisitor()
/*     */           {
/*     */             boolean visitedRoot = false;
/*     */             
/*     */             public boolean visitElement(ElementTree tree, IPathRequestor requestor, Object elementContents) {
/* 352 */               if (elementContents == null)
/* 353 */                 return false; 
/* 354 */               IPath nodePath = requestor.requestPath();
/*     */ 
/*     */ 
/*     */               
/* 358 */               if (!this.visitedRoot) {
/* 359 */                 this.visitedRoot = true;
/* 360 */                 ResourceInfo resourceInfo = Container.this.workspace.getResourceInfo(nodePath, false, true);
/* 361 */                 if (resourceInfo == null)
/* 362 */                   return false; 
/* 363 */                 resourceInfo.incrementCharsetGenerationCount();
/* 364 */                 return true;
/*     */               } 
/*     */               
/* 367 */               if (Container.this.workspace.getCharsetManager().getCharsetFor(nodePath, false) != null)
/* 368 */                 return false; 
/* 369 */               ResourceInfo info = Container.this.workspace.getResourceInfo(nodePath, false, true);
/* 370 */               if (info == null)
/* 371 */                 return false; 
/* 372 */               info.incrementCharsetGenerationCount();
/* 373 */               return true;
/*     */             }
/*     */           };
/*     */         try {
/* 377 */           (new ElementTreeIterator(this.workspace.getElementTree(), getFullPath())).iterate(visitor);
/* 378 */         } catch (WrappedRuntimeException e) {
/* 379 */           throw (CoreException)e.getTargetException();
/*     */         } 
/* 381 */         monitor.worked(Policy.opWork);
/* 382 */       } catch (OperationCanceledException e) {
/* 383 */         this.workspace.getWorkManager().operationCanceled();
/* 384 */         throw e;
/*     */       } finally {
/* 386 */         this.workspace.endOperation(rule, true);
/*     */       } 
/*     */     } finally {
/* 389 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\Container.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */