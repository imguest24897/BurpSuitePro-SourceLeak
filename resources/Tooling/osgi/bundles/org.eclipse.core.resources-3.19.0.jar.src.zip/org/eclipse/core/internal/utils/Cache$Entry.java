/*     */ package org.eclipse.core.internal.utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Entry
/*     */   implements KeyedHashSet.KeyedElement
/*     */ {
/*     */   Object cached;
/*     */   Object key;
/*     */   Entry next;
/*     */   Entry previous;
/*     */   long timestamp;
/*     */   
/*     */   public Entry(Object key, Object cached, long timestamp) {
/*  32 */     this.key = key;
/*  33 */     this.cached = cached;
/*  34 */     this.timestamp = timestamp;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean compare(KeyedHashSet.KeyedElement other) {
/*  39 */     if (!(other instanceof Entry))
/*  40 */       return false; 
/*  41 */     Entry otherEntry = (Entry)other;
/*  42 */     return this.key.equals(otherEntry.key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void discard() {
/*  47 */     unchain();
/*  48 */     this.cached = null;
/*  49 */     Cache.this.entries.remove(this);
/*     */   }
/*     */   
/*     */   public Object getCached() {
/*  53 */     return this.cached;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getKey() {
/*  58 */     return this.key;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getKeyHashCode() {
/*  63 */     return this.key.hashCode();
/*     */   }
/*     */   
/*     */   public Entry getNext() {
/*  67 */     return this.next;
/*     */   }
/*     */   
/*     */   public Entry getPrevious() {
/*  71 */     return this.previous;
/*     */   }
/*     */   
/*     */   public long getTimestamp() {
/*  75 */     return this.timestamp;
/*     */   }
/*     */   
/*     */   public boolean isHead() {
/*  79 */     return (this.previous == null);
/*     */   }
/*     */   
/*     */   public boolean isTail() {
/*  83 */     return (this.next == null);
/*     */   }
/*     */ 
/*     */   
/*     */   void makeHead() {
/*  88 */     Entry oldHead = Cache.this.head;
/*  89 */     Cache.this.head = this;
/*  90 */     this.next = oldHead;
/*  91 */     this.previous = null;
/*  92 */     if (oldHead == null) {
/*  93 */       Cache.this.tail = this;
/*     */     } else {
/*  95 */       oldHead.previous = this;
/*     */     } 
/*     */   }
/*     */   public void setCached(Object cached) {
/*  99 */     this.cached = cached;
/*     */   }
/*     */   
/*     */   public void setTimestamp(long timestamp) {
/* 103 */     this.timestamp = timestamp;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 108 */     return this.key + " -> " + this.cached + " [" + this.timestamp + ']';
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void unchain() {
/* 114 */     if (Cache.this.tail == this) {
/* 115 */       Cache.this.tail = this.previous;
/*     */     } else {
/* 117 */       this.next.previous = this.previous;
/*     */     } 
/* 119 */     if (Cache.this.head == this) {
/* 120 */       Cache.this.head = this.next;
/*     */     } else {
/* 122 */       this.previous.next = this.next;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\interna\\utils\Cache$Entry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */