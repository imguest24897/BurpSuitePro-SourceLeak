/*     */ package org.eclipse.core.internal.events;
/*     */ 
/*     */ import org.eclipse.core.internal.resources.ICoreConstants;
/*     */ import org.eclipse.core.internal.resources.ResourceException;
/*     */ import org.eclipse.core.internal.resources.Workspace;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Preferences;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.osgi.framework.Bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AutoBuildJob
/*     */   extends Job
/*     */   implements Preferences.IPropertyChangeListener
/*     */ {
/*     */   private volatile boolean avoidBuild;
/*     */   private volatile boolean buildNeeded;
/*     */   private volatile boolean forceBuild;
/*     */   private volatile boolean interrupted;
/*     */   private volatile boolean isAutoBuilding;
/*  43 */   private volatile long lastBuild = 0L;
/*  44 */   private Preferences preferences = ResourcesPlugin.getPlugin().getPluginPreferences();
/*  45 */   private final Bundle systemBundle = Platform.getBundle("org.eclipse.osgi");
/*     */   private Workspace workspace;
/*     */   final Job noBuildJob;
/*     */   
/*     */   AutoBuildJob(Workspace workspace) {
/*  50 */     super(Messages.events_building_0);
/*  51 */     setRule((ISchedulingRule)workspace.getRoot());
/*  52 */     setPriority(40);
/*  53 */     this.isAutoBuilding = workspace.isAutoBuilding();
/*  54 */     this.workspace = workspace;
/*  55 */     this.preferences.addPropertyChangeListener(this);
/*  56 */     this.noBuildJob = new AutoBuildOffJob();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void avoidBuild() {
/*  64 */     this.avoidBuild = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void avoidBuildIfNotInterrupted() {
/*  71 */     if (!this.interrupted) {
/*  72 */       avoidBuild();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean belongsTo(Object family) {
/*  78 */     return (family == ResourcesPlugin.FAMILY_AUTO_BUILD);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void build(boolean needsBuild) {
/*  88 */     this.buildNeeded |= needsBuild;
/*  89 */     long delay = computeScheduleDelay();
/*  90 */     int state = getState();
/*  91 */     if (Policy.DEBUG_BUILD_NEEDED) {
/*  92 */       Policy.debug("build requested, needsBuild: " + needsBuild + " state: " + state + ", delay: " + delay);
/*     */     }
/*     */ 
/*     */     
/*  96 */     if (state != 4) {
/*  97 */       setInterrupted(false);
/*     */     }
/*  99 */     switch (state) {
/*     */       case 1:
/* 101 */         if (Policy.DEBUG_BUILD_INVOKING) {
/* 102 */           traceMessageOrFullStack("wakeup, needsBuild: " + needsBuild + ", delay: " + delay);
/*     */         }
/* 104 */         wakeUp(delay);
/*     */         break;
/*     */       case 0:
/* 107 */         if (this.isAutoBuilding) {
/* 108 */           if (Policy.DEBUG_BUILD_INVOKING) {
/* 109 */             traceMessageOrFullStack("scheduled, needsBuild: " + needsBuild + ", delay: " + delay);
/*     */           }
/* 111 */           schedule(delay);
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 116 */         if (this.noBuildJob.getState() != 4) {
/* 117 */           this.noBuildJob.schedule(delay);
/*     */         }
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 4:
/* 128 */         if (this.isAutoBuilding && this.buildNeeded && !this.avoidBuild && Job.getJobManager().currentJob() != this) {
/* 129 */           if (Policy.DEBUG_BUILD_INVOKING) {
/* 130 */             traceMessageOrFullStack("scheduled from other thread with delay: " + delay);
/*     */           }
/* 132 */           schedule(delay);
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void traceMessageOrFullStack(String message) {
/* 142 */     message = "AutoBuildJob: " + message;
/* 143 */     if (Policy.DEBUG_BUILD_NEEDED_STACK) {
/* 144 */       Policy.debug(new RuntimeException(message));
/*     */     } else {
/* 146 */       Policy.debug(message);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long computeScheduleDelay() {
/* 156 */     long maxDelay = Math.min(1000L, 1000L + this.lastBuild - System.currentTimeMillis());
/* 157 */     return Math.max(100L, maxDelay);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized IStatus canceled() {
/* 171 */     this.buildNeeded = true;
/*     */     
/* 173 */     if (this.interrupted) {
/* 174 */       if (Policy.DEBUG_BUILD_INTERRUPT) {
/* 175 */         traceMessageOrFullStack("scheduling due to interruption");
/*     */       }
/* 177 */       setInterrupted(false);
/* 178 */       schedule(computeScheduleDelay());
/*     */     } 
/* 180 */     return Status.CANCEL_STATUS;
/*     */   }
/*     */   
/*     */   private void doBuild(IProgressMonitor monitor) throws CoreException, OperationCanceledException {
/* 184 */     SubMonitor subMonitor = SubMonitor.convert(monitor, Policy.opWork + 1);
/* 185 */     ISchedulingRule rule = this.workspace.getRuleFactory().buildRule();
/* 186 */     SubMonitor split = subMonitor.split(1);
/*     */     try {
/* 188 */       this.workspace.prepareOperation(rule, (IProgressMonitor)split);
/* 189 */       this.workspace.beginOperation(true);
/*     */       
/* 191 */       this.workspace.broadcastBuildEvent(this.workspace, 8, 9);
/* 192 */       IStatus result = Status.OK_STATUS;
/*     */       
/*     */       try {
/* 195 */         if (shouldBuild()) {
/* 196 */           result = this.workspace.getBuildManager().build(this.workspace.getBuildOrder(), ICoreConstants.EMPTY_BUILD_CONFIG_ARRAY, 9, (IProgressMonitor)subMonitor.split(Policy.opWork));
/*     */         }
/*     */       } finally {
/* 199 */         this.workspace.broadcastBuildEvent(this.workspace, 16, 9);
/*     */       } 
/* 201 */       if (!result.isOK()) {
/* 202 */         throw new ResourceException(result);
/*     */       }
/*     */     }
/*     */     finally {
/*     */       
/* 207 */       if (this.workspace.getElementTree().isImmutable()) {
/* 208 */         this.workspace.newWorkingTree();
/*     */       }
/* 210 */       this.workspace.endOperation(rule, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void forceBuild() {
/* 219 */     this.forceBuild = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void interrupt() {
/* 228 */     if (this.interrupted)
/*     */       return; 
/* 230 */     switch (getState()) {
/*     */       case 0:
/*     */         return;
/*     */       
/*     */       case 2:
/* 235 */         setInterrupted(!sleep());
/*     */         break;
/*     */       
/*     */       case 4:
/* 239 */         if (Job.getJobManager().currentJob() == this)
/*     */           return; 
/* 241 */         setInterrupted(true);
/*     */         break;
/*     */     } 
/*     */     
/* 245 */     if (this.interrupted)
/* 246 */       this.avoidBuild = false; 
/*     */   }
/*     */   
/*     */   synchronized boolean isInterrupted() {
/* 250 */     if (this.interrupted) {
/* 251 */       return true;
/*     */     }
/* 253 */     if (isBlocking())
/* 254 */       setInterrupted(true); 
/* 255 */     return this.interrupted;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void propertyChange(Preferences.PropertyChangeEvent event) {
/* 261 */     if (!event.getProperty().equals("description.autobuilding")) {
/*     */       return;
/*     */     }
/* 264 */     boolean wasAutoBuilding = this.isAutoBuilding;
/* 265 */     this.isAutoBuilding = this.preferences.getBoolean("description.autobuilding");
/* 266 */     if (wasAutoBuilding && !this.isAutoBuilding) {
/*     */       
/* 268 */       interrupt();
/* 269 */     } else if (!wasAutoBuilding && this.isAutoBuilding) {
/*     */       
/* 271 */       this.noBuildJob.cancel();
/* 272 */       this.forceBuild = true;
/* 273 */       build(false);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public IStatus run(IProgressMonitor monitor) {
/* 279 */     SubMonitor subMonitor = SubMonitor.convert(monitor, 1);
/* 280 */     synchronized (this) {
/* 281 */       if (subMonitor.isCanceled() || isInterrupted()) {
/* 282 */         return canceled();
/*     */       }
/*     */     } 
/*     */     
/* 286 */     if (this.systemBundle.getState() == 16)
/* 287 */       return Status.OK_STATUS; 
/*     */     try {
/* 289 */       doBuild((IProgressMonitor)subMonitor.split(1));
/* 290 */       this.lastBuild = System.currentTimeMillis();
/*     */       
/* 292 */       setInterrupted(false);
/* 293 */       return Status.OK_STATUS;
/* 294 */     } catch (OperationCanceledException operationCanceledException) {
/* 295 */       return canceled();
/* 296 */     } catch (CoreException sig) {
/* 297 */       return sig.getStatus();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void setInterrupted(boolean value) {
/* 305 */     this.interrupted = value;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 310 */     if (this.interrupted && Policy.DEBUG_BUILD_INTERRUPT) {
/* 311 */       traceMessageOrFullStack("was interrupted");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized boolean shouldBuild() {
/*     */     try {
/* 321 */       if (!this.workspace.isAutoBuilding()) {
/* 322 */         return false;
/*     */       }
/* 324 */       if (this.forceBuild)
/* 325 */         return true; 
/* 326 */       if (this.avoidBuild) {
/* 327 */         return false;
/*     */       }
/* 329 */       return this.buildNeeded;
/*     */     } finally {
/*     */       
/* 332 */       this.forceBuild = this.avoidBuild = this.buildNeeded = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class AutoBuildOffJob
/*     */     extends Job
/*     */   {
/*     */     private AutoBuildOffJob() {
/* 345 */       super("Sending build events with disabled autobuild");
/* 346 */       setRule((ISchedulingRule)AutoBuildJob.this.workspace.getRoot());
/* 347 */       setSystem(true);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean belongsTo(Object family) {
/* 352 */       return (family == ResourcesPlugin.FAMILY_AUTO_BUILD);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected IStatus run(IProgressMonitor monitor) {
/* 358 */       if (AutoBuildJob.this.systemBundle.getState() == 16)
/* 359 */         return Status.OK_STATUS; 
/* 360 */       ISchedulingRule rule = AutoBuildJob.this.workspace.getRuleFactory().buildRule();
/*     */       try {
/* 362 */         AutoBuildJob.this.workspace.prepareOperation(rule, monitor);
/* 363 */         AutoBuildJob.this.workspace.beginOperation(true);
/*     */         
/* 365 */         AutoBuildJob.this.workspace.broadcastBuildEvent(AutoBuildJob.this.workspace, 8, 9);
/* 366 */         AutoBuildJob.this.workspace.broadcastBuildEvent(AutoBuildJob.this.workspace, 16, 9);
/* 367 */       } catch (CoreException e) {
/* 368 */         return e.getStatus();
/*     */       } finally {
/*     */         try {
/* 371 */           AutoBuildJob.this.workspace.endOperation(rule, false);
/* 372 */         } catch (CoreException e) {
/* 373 */           return e.getStatus();
/*     */         } 
/*     */       } 
/* 376 */       return Status.OK_STATUS;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\AutoBuildJob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */