/*     */ package org.eclipse.core.internal.properties;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.internal.localstore.Bucket;
/*     */ import org.eclipse.core.internal.resources.ResourceException;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ public class PropertyBucket extends Bucket {
/*     */   public static final byte INDEX = 1;
/*     */   public static final byte QNAME = 2;
/*     */   private static final byte VERSION = 1;
/*     */   
/*     */   public static class PropertyEntry extends Bucket.Entry {
/*     */     private static final Comparator<String[]> COMPARATOR;
/*     */     
/*     */     static {
/*  29 */       COMPARATOR = ((o1, o2) -> {
/*     */           int qualifierComparison = o1[0].compareTo(o2[0]);
/*     */           return (qualifierComparison != 0) ? qualifierComparison : o1[1].compareTo(o2[1]);
/*     */         });
/*  33 */     } private static final String[][] EMPTY_DATA = new String[0][];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String[][] value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static String[][] delete(String[][] existing, QualifiedName propertyName) {
/*  47 */       if (existing.length == 1) {
/*  48 */         return (existing[0][0].equals(propertyName.getQualifier()) && existing[0][1].equals(propertyName.getLocalName())) ? null : existing;
/*     */       }
/*  50 */       int deletePosition = search(existing, propertyName);
/*  51 */       if (deletePosition < 0)
/*     */       {
/*  53 */         return existing; } 
/*  54 */       String[][] newValue = new String[existing.length - 1][];
/*  55 */       if (deletePosition > 0)
/*     */       {
/*  57 */         System.arraycopy(existing, 0, newValue, 0, deletePosition); } 
/*  58 */       if (deletePosition < existing.length - 1)
/*     */       {
/*  60 */         System.arraycopy(existing, deletePosition + 1, newValue, deletePosition, newValue.length - deletePosition); } 
/*  61 */       return newValue;
/*     */     }
/*     */ 
/*     */     
/*     */     static String[][] insert(String[][] existing, QualifiedName propertyName, String propertyValue) {
/*  66 */       int index = search(existing, propertyName);
/*  67 */       if (index >= 0) {
/*     */         
/*  69 */         existing[index][2] = propertyValue;
/*  70 */         return existing;
/*     */       } 
/*     */       
/*  73 */       int insertPosition = -index - 1;
/*  74 */       String[][] newValue = new String[existing.length + 1][];
/*  75 */       if (insertPosition > 0)
/*  76 */         System.arraycopy(existing, 0, newValue, 0, insertPosition); 
/*  77 */       (new String[3])[0] = propertyName.getQualifier(); (new String[3])[1] = propertyName.getLocalName(); (new String[3])[2] = propertyValue; newValue[insertPosition] = new String[3];
/*  78 */       if (insertPosition < existing.length)
/*  79 */         System.arraycopy(existing, insertPosition, newValue, insertPosition + 1, existing.length - insertPosition); 
/*  80 */       return newValue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static Object merge(String[][] base, String[][] additions) {
/*  87 */       int additionPointer = 0;
/*  88 */       int basePointer = 0;
/*  89 */       int added = 0;
/*  90 */       String[][] result = new String[base.length + additions.length][];
/*  91 */       while (basePointer < base.length && additionPointer < additions.length) {
/*  92 */         int comparison = COMPARATOR.compare(base[basePointer], additions[additionPointer]);
/*  93 */         if (comparison == 0) {
/*  94 */           result[added++] = additions[additionPointer++];
/*     */           
/*  96 */           basePointer++; continue;
/*  97 */         }  if (comparison < 0) {
/*  98 */           result[added++] = base[basePointer++]; continue;
/*     */         } 
/* 100 */         result[added++] = additions[additionPointer++];
/*     */       } 
/*     */       
/* 103 */       String[][] remaining = (basePointer == base.length) ? additions : base;
/* 104 */       int remainingPointer = (basePointer == base.length) ? additionPointer : basePointer;
/* 105 */       int remainingCount = remaining.length - remainingPointer;
/* 106 */       System.arraycopy(remaining, remainingPointer, result, added, remainingCount);
/* 107 */       added += remainingCount;
/* 108 */       if (added == base.length + additions.length)
/*     */       {
/* 110 */         return result;
/*     */       }
/* 112 */       String[][] finalResult = new String[added][];
/* 113 */       System.arraycopy(result, 0, finalResult, 0, finalResult.length);
/* 114 */       return finalResult;
/*     */     }
/*     */     
/*     */     private static int search(String[][] existing, QualifiedName propertyName) {
/* 118 */       return Arrays.binarySearch(existing, new String[] { propertyName.getQualifier(), propertyName.getLocalName() }, (Comparator)COMPARATOR);
/*     */     }
/*     */     
/*     */     public PropertyEntry(IPath path, PropertyEntry base) {
/* 122 */       super(path);
/*     */       
/* 124 */       int xLen = base.value.length;
/* 125 */       this.value = new String[xLen][];
/* 126 */       for (int i = 0; i < xLen; i++) {
/* 127 */         int yLen = (base.value[i]).length;
/* 128 */         this.value[i] = new String[yLen];
/* 129 */         System.arraycopy(base.value[i], 0, this.value[i], 0, yLen);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected PropertyEntry(IPath path, String[][] value) {
/* 139 */       super(path);
/* 140 */       this.value = value;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void compact() {
/* 148 */       if (!isDirty())
/*     */         return; 
/* 150 */       int occurrences = 0; byte b; int i; String[][] arrayOfString1;
/* 151 */       for (i = (arrayOfString1 = this.value).length, b = 0; b < i; ) { String[] s = arrayOfString1[b];
/* 152 */         if (s != null)
/* 153 */           this.value[occurrences++] = s; 
/*     */         b++; }
/*     */       
/* 156 */       if (occurrences == this.value.length) {
/*     */         return;
/*     */       }
/* 159 */       if (occurrences == 0) {
/*     */         
/* 161 */         this.value = EMPTY_DATA;
/* 162 */         delete();
/*     */         return;
/*     */       } 
/* 165 */       String[][] result = new String[occurrences][];
/* 166 */       System.arraycopy(this.value, 0, result, 0, occurrences);
/* 167 */       this.value = result;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getOccurrences() {
/* 172 */       return (this.value == null) ? 0 : this.value.length;
/*     */     }
/*     */     
/*     */     public String getProperty(QualifiedName name) {
/* 176 */       int index = search(this.value, name);
/* 177 */       return (index < 0) ? null : this.value[index][2];
/*     */     }
/*     */     
/*     */     public QualifiedName getPropertyName(int i) {
/* 181 */       return new QualifiedName(this.value[i][0], this.value[i][1]);
/*     */     }
/*     */     
/*     */     public String getPropertyValue(int i) {
/* 185 */       return this.value[i][2];
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getValue() {
/* 190 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public void visited() {
/* 195 */       compact();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 222 */   private final List<String> qualifierIndex = new ArrayList<>();
/*     */   
/*     */   public PropertyBucket() {
/* 225 */     super(!Boolean.getBoolean("org.eclipse.core.PropertyCache.disable"));
/*     */   }
/*     */ 
/*     */   
/*     */   protected Bucket.Entry createEntry(IPath path, Object value) {
/* 230 */     return new PropertyEntry(path, (String[][])value);
/*     */   }
/*     */   
/*     */   private PropertyEntry getEntry(IPath path) {
/* 234 */     String pathAsString = path.toString();
/* 235 */     String[][] existing = (String[][])getEntryValue(pathAsString);
/* 236 */     if (existing == null)
/* 237 */       return null; 
/* 238 */     return new PropertyEntry(path, existing);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getIndexFileName() {
/* 243 */     return "properties.index";
/*     */   }
/*     */   
/*     */   public String getProperty(IPath path, QualifiedName name) {
/* 247 */     PropertyEntry entry = getEntry(path);
/* 248 */     if (entry == null)
/* 249 */       return null; 
/* 250 */     return entry.getProperty(name);
/*     */   }
/*     */ 
/*     */   
/*     */   protected byte getVersion() {
/* 255 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getVersionFileName() {
/* 260 */     return "properties.version";
/*     */   }
/*     */ 
/*     */   
/*     */   public void load(String newProjectName, File baseLocation, boolean force) throws CoreException {
/* 265 */     this.qualifierIndex.clear();
/* 266 */     super.load(newProjectName, baseLocation, force);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object readEntryValue(DataInputStream source) throws IOException, CoreException {
/* 271 */     int length = source.readUnsignedShort();
/* 272 */     String[][] properties = new String[length][3]; byte b; int i; String[][] arrayOfString1;
/* 273 */     for (i = (arrayOfString1 = properties).length, b = 0; b < i; ) { IPath resourcePath; String msg, propertie[] = arrayOfString1[b];
/*     */       
/* 275 */       byte constant = source.readByte();
/* 276 */       switch (constant) {
/*     */         case 2:
/* 278 */           propertie[0] = source.readUTF();
/* 279 */           this.qualifierIndex.add(propertie[0]);
/*     */           break;
/*     */         case 1:
/* 282 */           propertie[0] = this.qualifierIndex.get(source.readInt());
/*     */           break;
/*     */         
/*     */         default:
/* 286 */           resourcePath = (this.projectName == null) ? (IPath)Path.ROOT : Path.ROOT.append(this.projectName);
/* 287 */           msg = NLS.bind(Messages.properties_readProperties, resourcePath.toString());
/* 288 */           throw new ResourceException(567, null, msg, null);
/*     */       } 
/*     */       
/* 291 */       propertie[1] = source.readUTF();
/*     */       
/* 293 */       propertie[2] = source.readUTF(); b++; }
/*     */     
/* 295 */     return properties;
/*     */   }
/*     */ 
/*     */   
/*     */   public void save() throws CoreException {
/* 300 */     this.qualifierIndex.clear();
/* 301 */     super.save();
/*     */   }
/*     */   
/*     */   public void setProperties(PropertyEntry entry) {
/* 305 */     IPath path = entry.getPath();
/* 306 */     String[][] additions = (String[][])entry.getValue();
/* 307 */     String pathAsString = path.toString();
/* 308 */     String[][] existing = (String[][])getEntryValue(pathAsString);
/* 309 */     if (existing == null) {
/* 310 */       setEntryValue(pathAsString, additions);
/*     */       return;
/*     */     } 
/* 313 */     setEntryValue(pathAsString, PropertyEntry.merge(existing, additions));
/*     */   }
/*     */   
/*     */   public void setProperty(IPath path, QualifiedName name, String value) {
/* 317 */     String newValue[][], pathAsString = path.toString();
/* 318 */     String[][] existing = (String[][])getEntryValue(pathAsString);
/* 319 */     if (existing == null) {
/* 320 */       if (value != null) {
/* 321 */         setEntryValue(pathAsString, new String[][] { { name.getQualifier(), name.getLocalName(), value } });
/*     */       }
/*     */       return;
/*     */     } 
/* 325 */     if (value != null) {
/* 326 */       newValue = PropertyEntry.insert(existing, name, value);
/*     */     } else {
/* 328 */       newValue = PropertyEntry.delete(existing, name);
/*     */     } 
/* 330 */     setEntryValue(pathAsString, newValue);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writeEntryValue(DataOutputStream destination, Object entryValue) throws IOException {
/* 335 */     String[][] properties = (String[][])entryValue;
/* 336 */     destination.writeShort(properties.length); byte b; int i; String[][] arrayOfString1;
/* 337 */     for (i = (arrayOfString1 = properties).length, b = 0; b < i; ) { String[] propertie = arrayOfString1[b];
/*     */       
/* 339 */       int index = this.qualifierIndex.indexOf(propertie[0]);
/* 340 */       if (index == -1) {
/* 341 */         destination.writeByte(2);
/* 342 */         destination.writeUTF(propertie[0]);
/* 343 */         this.qualifierIndex.add(propertie[0]);
/*     */       } else {
/* 345 */         destination.writeByte(1);
/* 346 */         destination.writeInt(index);
/*     */       } 
/*     */       
/* 349 */       destination.writeUTF(propertie[1]);
/*     */       
/* 351 */       destination.writeUTF(propertie[2]);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\properties\PropertyBucket.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */