/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.resources.IBuildConfiguration;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalMetaArea
/*     */   implements ICoreConstants
/*     */ {
/*     */   static final String F_BACKUP_FILE_EXTENSION = ".bak";
/*     */   static final String F_DESCRIPTION = ".workspace";
/*     */   static final String F_HISTORY_STORE = ".history";
/*     */   static final String F_MARKERS = ".markers";
/*     */   static final String F_OLD_PROJECT = ".prj";
/*     */   static final String F_PROJECT_LOCATION = ".location";
/*     */   static final String F_PROJECTS = ".projects";
/*     */   static final String F_PROPERTIES = ".properties";
/*     */   static final String F_REFRESH = ".refresh";
/*     */   static final String F_ROOT = ".root";
/*     */   static final String F_SAFE_TABLE = ".safetable";
/*     */   static final String F_SNAP = ".snap";
/*     */   static final String F_SNAP_EXTENSION = "snap";
/*     */   static final String F_SYNCINFO = ".syncinfo";
/*     */   static final String F_TREE = ".tree";
/*     */   static final String URI_PREFIX = "URI//";
/*     */   static final String F_METADATA = ".metadata";
/*     */   protected final IPath metaAreaLocation;
/*     */   protected final IPath projectMetaLocation;
/*     */   private Workspace workspace;
/*     */   
/*     */   public LocalMetaArea(Workspace workspace) {
/*  64 */     this.workspace = workspace;
/*  65 */     this.metaAreaLocation = ResourcesPlugin.getPlugin().getStateLocation();
/*  66 */     this.projectMetaLocation = this.metaAreaLocation.append(".projects");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearOldDescription(IProject target) {
/*  74 */     Workspace.clear(getOldDescriptionLocationFor(target).toFile());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearRefresh(IProject target) {
/*  81 */     Workspace.clear(getRefreshLocationFor(target).toFile());
/*     */   }
/*     */   
/*     */   public void create(IProject target) {
/*  85 */     File file = locationFor((IResource)target).toFile();
/*     */     
/*  87 */     Workspace.clear(file);
/*  88 */     file.mkdirs();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void createMetaArea() throws CoreException {
/*  95 */     File workspaceLocation = this.metaAreaLocation.toFile();
/*  96 */     Workspace.clear(workspaceLocation);
/*  97 */     if (!workspaceLocation.mkdirs()) {
/*  98 */       String message = NLS.bind(Messages.resources_writeWorkspaceMeta, workspaceLocation);
/*  99 */       throw new ResourceException(568, null, message, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete(IProject target) throws CoreException {
/* 108 */     IPath path = locationFor((IResource)target);
/* 109 */     if (!Workspace.clear(path.toFile()) && path.toFile().exists()) {
/* 110 */       String message = NLS.bind(Messages.resources_deleteMeta, target.getFullPath());
/* 111 */       throw new ResourceException(569, target.getFullPath(), message, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public IPath getBackupLocationFor(IPath file) {
/* 116 */     return file.removeLastSegments(1).append(String.valueOf(file.lastSegment()) + ".bak");
/*     */   }
/*     */   
/*     */   public IPath getHistoryStoreLocation() {
/* 120 */     return this.metaAreaLocation.append(".history");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getLocation() {
/* 128 */     return this.metaAreaLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getMarkersLocationFor(IResource resource) {
/* 136 */     Assert.isNotNull(resource);
/* 137 */     Assert.isLegal(!(resource.getType() != 8 && resource.getType() != 4));
/* 138 */     return locationFor(resource).append(".markers");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getMarkersSnapshotLocationFor(IResource resource) {
/* 146 */     return getMarkersLocationFor(resource).addFileExtension("snap");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getOldDescriptionLocationFor(IProject target) {
/* 156 */     return locationFor((IResource)target).append(".prj");
/*     */   }
/*     */   
/*     */   public IPath getPropertyStoreLocation(IResource resource) {
/* 160 */     int type = resource.getType();
/* 161 */     Assert.isTrue((type != 1 && type != 2));
/* 162 */     return locationFor(resource).append(".properties");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getRefreshLocationFor(IProject project) {
/* 170 */     Assert.isNotNull(project);
/* 171 */     return locationFor((IResource)project).append(".refresh");
/*     */   }
/*     */   
/*     */   public IPath getSafeTableLocationFor(String pluginId) {
/* 175 */     IPath prefix = this.metaAreaLocation.append(".safetable");
/*     */ 
/*     */     
/* 178 */     if (pluginId.equals("org.eclipse.core.resources"))
/* 179 */       return prefix.append(pluginId); 
/* 180 */     int saveNumber = getWorkspace().getSaveManager().getSaveNumber(pluginId);
/* 181 */     return prefix.append(String.valueOf(pluginId) + "." + saveNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getSnapshotLocationFor(IResource resource) {
/* 190 */     Assert.isNotNull(resource);
/* 191 */     Assert.isLegal((resource.getType() == 8));
/* 192 */     IPath key = resource.getFullPath().append(".tree");
/* 193 */     String sequenceNumber = getWorkspace().getSaveManager().getMasterTable().getProperty(key.toString());
/* 194 */     if (sequenceNumber == null)
/* 195 */       sequenceNumber = "0"; 
/* 196 */     return this.metaAreaLocation.append(String.valueOf(sequenceNumber) + ".snap");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getLegacySnapshotLocationFor(IResource resource) {
/* 204 */     Assert.isNotNull(resource);
/* 205 */     Assert.isLegal((resource.getType() == 8));
/* 206 */     return this.metaAreaLocation.append(".snap");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getSyncInfoLocationFor(IResource resource) {
/* 215 */     Assert.isNotNull(resource);
/* 216 */     Assert.isLegal(!(resource.getType() != 8 && resource.getType() != 4));
/* 217 */     return locationFor(resource).append(".syncinfo");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getSyncInfoSnapshotLocationFor(IResource resource) {
/* 226 */     return getSyncInfoLocationFor(resource).addFileExtension("snap");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getTreeLocationFor(IResource target, boolean updateSequenceNumber) {
/* 236 */     IPath key = target.getFullPath().append(".tree");
/* 237 */     String sequenceNumber = getWorkspace().getSaveManager().getMasterTable().getProperty(key.toString());
/* 238 */     if (sequenceNumber == null)
/* 239 */       sequenceNumber = "0"; 
/* 240 */     if (updateSequenceNumber) {
/* 241 */       int n = Integer.parseInt(sequenceNumber) + 1;
/* 242 */       n = (n < 0) ? 1 : n;
/* 243 */       sequenceNumber = Integer.toString(n);
/* 244 */       getWorkspace().getSaveManager().getMasterTable().setProperty(key.toString(), sequenceNumber);
/*     */     } 
/* 246 */     return locationFor(target).append(String.valueOf(sequenceNumber) + ".tree");
/*     */   }
/*     */   
/*     */   public IPath getWorkingLocation(IResource resource, String id) {
/* 250 */     return locationFor(resource).append(id);
/*     */   }
/*     */   
/*     */   protected Workspace getWorkspace() {
/* 254 */     return this.workspace;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasSavedProject(IProject project) {
/* 259 */     return !(!getOldDescriptionLocationFor(project).toFile().exists() && !locationFor((IResource)project).append(".location").toFile().exists());
/*     */   }
/*     */   
/*     */   public boolean hasSavedWorkspace() {
/* 263 */     return !(!this.metaAreaLocation.toFile().exists() && !getBackupLocationFor(this.metaAreaLocation).toFile().exists());
/*     */   }
/*     */   
/*     */   public boolean hasSavedProjects() {
/* 267 */     return this.projectMetaLocation.toFile().exists();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath locationFor(IPath resourcePath) {
/* 275 */     if (Path.ROOT.equals(resourcePath))
/* 276 */       return this.metaAreaLocation.append(".root"); 
/* 277 */     return this.projectMetaLocation.append(resourcePath.segment(0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath locationFor(IResource resource) {
/* 285 */     if (resource.getType() == 8)
/* 286 */       return this.metaAreaLocation.append(".root"); 
/* 287 */     return this.projectMetaLocation.append(resource.getProject().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProjectDescription readOldDescription(IProject project) throws CoreException {
/* 296 */     IPath path = getOldDescriptionLocationFor(project);
/* 297 */     if (!path.toFile().exists())
/* 298 */       return null; 
/* 299 */     IPath tempPath = getBackupLocationFor(path);
/* 300 */     ProjectDescription description = null;
/*     */     try {
/* 302 */       description = (new ProjectDescriptionReader(project)).read(path, tempPath);
/* 303 */     } catch (IOException e) {
/* 304 */       String msg = NLS.bind(Messages.resources_readMeta, project.getName());
/* 305 */       throw new ResourceException(567, project.getFullPath(), msg, e);
/*     */     } 
/* 307 */     if (description == null) {
/* 308 */       String msg = NLS.bind(Messages.resources_readMeta, project.getName());
/* 309 */       throw new ResourceException(567, project.getFullPath(), msg, null);
/*     */     } 
/* 311 */     return description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readPrivateDescription(IProject target, ProjectDescription description) {
/* 342 */     IPath locationFile = locationFor((IResource)target).append(".location");
/* 343 */     File file = locationFile.toFile();
/* 344 */     if (!file.exists()) {
/* 345 */       locationFile = getBackupLocationFor(locationFile);
/* 346 */       file = locationFile.toFile();
/* 347 */       if (!file.exists())
/*     */         return; 
/*     */     }  try {
/* 350 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 401 */     catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writePrivateDescription(IProject target) throws CoreException {
/* 413 */     IPath location = locationFor((IResource)target).append(".location");
/* 414 */     File file = location.toFile();
/*     */     
/* 416 */     Workspace.clear(file);
/*     */     
/* 418 */     ProjectDescription desc = ((Project)target).internalGetDescription();
/* 419 */     if (desc == null)
/*     */       return; 
/* 421 */     URI projectLocation = desc.getLocationURI();
/* 422 */     IProject[] prjRefs = desc.getDynamicReferences(false);
/* 423 */     String[] buildConfigs = desc.configNames;
/* 424 */     Map<String, IBuildConfiguration[]> configRefs = desc.getBuildConfigReferences(false);
/* 425 */     if (projectLocation == null && prjRefs.length == 0 && buildConfigs.length == 0 && configRefs.isEmpty())
/*     */       return; 
/*     */     try {
/* 428 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 464 */     catch (IOException e) {
/* 465 */       String message = NLS.bind(Messages.resources_exSaveProjectLocation, target.getName());
/* 466 */       throw new ResourceException(566, null, message, e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\LocalMetaArea.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */