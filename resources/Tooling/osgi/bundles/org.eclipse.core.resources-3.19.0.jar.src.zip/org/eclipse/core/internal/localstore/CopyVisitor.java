/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.LinkedList;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.internal.resources.Container;
/*     */ import org.eclipse.core.internal.resources.File;
/*     */ import org.eclipse.core.internal.resources.FilterDescription;
/*     */ import org.eclipse.core.internal.resources.Folder;
/*     */ import org.eclipse.core.internal.resources.Project;
/*     */ import org.eclipse.core.internal.resources.Resource;
/*     */ import org.eclipse.core.internal.resources.ResourceInfo;
/*     */ import org.eclipse.core.internal.resources.ResourceStatus;
/*     */ import org.eclipse.core.internal.resources.Workspace;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CopyVisitor
/*     */   implements IUnifiedTreeVisitor
/*     */ {
/*     */   protected IResource rootDestination;
/*     */   protected SubMonitor monitor;
/*     */   protected int updateFlags;
/*     */   protected boolean force;
/*     */   protected boolean isDeep;
/*     */   protected int segmentsToDrop;
/*     */   protected MultiStatus status;
/*     */   protected RefreshLocalVisitor refreshLocalVisitor;
/*     */   private FileSystemResourceManager localManager;
/*     */   
/*     */   public CopyVisitor(IResource rootSource, IResource destination, int updateFlags, IProgressMonitor monitor) {
/*  57 */     this.localManager = ((Resource)rootSource).getLocalManager();
/*  58 */     this.rootDestination = destination;
/*  59 */     this.updateFlags = updateFlags;
/*  60 */     this.isDeep = ((updateFlags & 0x20) == 0);
/*  61 */     this.force = ((updateFlags & 0x1) != 0);
/*  62 */     this.monitor = SubMonitor.convert(monitor);
/*  63 */     this.segmentsToDrop = rootSource.getFullPath().segmentCount();
/*  64 */     this.status = new MultiStatus("org.eclipse.core.resources", 1, Messages.localstore_copyProblem, null);
/*     */   }
/*     */   
/*     */   protected boolean copy(UnifiedTreeNode node) {
/*  68 */     Resource source = (Resource)node.getResource();
/*  69 */     IPath sufix = source.getFullPath().removeFirstSegments(this.segmentsToDrop);
/*  70 */     Resource destination = getDestinationResource(source, sufix);
/*  71 */     if (!copyProperties(source, destination))
/*  72 */       return false; 
/*  73 */     return copyContents(node, source, destination);
/*     */   }
/*     */   
/*     */   protected boolean copyContents(UnifiedTreeNode node, Resource source, Resource destination) {
/*     */     try {
/*  78 */       if (source.isVirtual()) {
/*  79 */         ((Folder)destination).create(8192, true, null);
/*  80 */         return true;
/*     */       } 
/*  82 */       if ((!this.isDeep || source.isUnderVirtual()) && source.isLinked()) {
/*  83 */         URI sourceLocationURI = getWorkspace().transferVariableDefinition((IResource)source, (IResource)destination, source.getRawLocationURI());
/*  84 */         destination.createLink(sourceLocationURI, this.updateFlags & 0x10, null);
/*  85 */         return false;
/*     */       } 
/*     */       
/*  88 */       if (source instanceof Container && ((Container)source).hasFilters()) {
/*  89 */         Project sourceProject = (Project)source.getProject();
/*  90 */         LinkedList<FilterDescription> originalDescriptions = sourceProject.internalGetDescription().getFilter(source.getProjectRelativePath());
/*  91 */         LinkedList<FilterDescription> filterDescriptions = FilterDescription.copy(originalDescriptions, (IResource)destination);
/*  92 */         Project project = (Project)destination.getProject();
/*  93 */         project.internalGetDescription().setFilters(destination.getProjectRelativePath(), filterDescriptions);
/*  94 */         project.writeDescription(this.updateFlags);
/*     */       } 
/*     */       
/*  97 */       IFileStore sourceStore = node.getStore();
/*  98 */       IFileStore destinationStore = destination.getStore();
/*     */       
/* 100 */       if (destination == this.rootDestination)
/* 101 */         destinationStore.getParent().mkdir(0, (IProgressMonitor)this.monitor.newChild(0)); 
/* 102 */       sourceStore.copy(destinationStore, 4, (IProgressMonitor)this.monitor.newChild(0));
/*     */       
/* 104 */       ResourceInfo info = this.localManager.getWorkspace().createResource((IResource)destination, this.updateFlags);
/* 105 */       this.localManager.updateLocalSync(info, destinationStore.fetchInfo().getLastModified());
/*     */       
/* 107 */       getWorkspace().getAliasManager().updateAliases((IResource)destination, destinationStore, 0, (IProgressMonitor)this.monitor);
/* 108 */       if (destination.getType() == 1)
/* 109 */         ((File)destination).updateMetadataFiles(); 
/* 110 */     } catch (CoreException e) {
/* 111 */       this.status.add(e.getStatus());
/*     */     } 
/* 113 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean copyProperties(Resource target, Resource destination) {
/*     */     try {
/* 118 */       target.getPropertyManager().copy((IResource)target, (IResource)destination, 0);
/* 119 */       return true;
/* 120 */     } catch (CoreException e) {
/* 121 */       this.status.add(e.getStatus());
/* 122 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Resource getDestinationResource(Resource source, IPath suffix) {
/* 127 */     if (suffix.segmentCount() == 0)
/* 128 */       return (Resource)this.rootDestination; 
/* 129 */     IPath destinationPath = this.rootDestination.getFullPath().append(suffix);
/* 130 */     return getWorkspace().newResource(destinationPath, source.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RefreshLocalVisitor getRefreshLocalVisitor() {
/* 137 */     if (this.refreshLocalVisitor == null)
/* 138 */       this.refreshLocalVisitor = new RefreshLocalVisitor((IProgressMonitor)SubMonitor.convert(null)); 
/* 139 */     return this.refreshLocalVisitor;
/*     */   }
/*     */   
/*     */   public IStatus getStatus() {
/* 143 */     return (IStatus)this.status;
/*     */   }
/*     */   
/*     */   protected Workspace getWorkspace() {
/* 147 */     return (Workspace)this.rootDestination.getWorkspace();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isSynchronized(UnifiedTreeNode node) {
/* 152 */     if (node.getResource().isVirtual())
/* 153 */       return true; 
/* 154 */     if (node.isErrorInFileSystem()) {
/* 155 */       return true;
/*     */     }
/* 157 */     if (!node.existsInWorkspace() || !node.existsInFileSystem()) {
/* 158 */       return false;
/*     */     }
/* 160 */     if (node.isFolder() && node.getResource().getType() == 2) {
/* 161 */       return true;
/*     */     }
/* 163 */     Resource target = (Resource)node.getResource();
/* 164 */     long lastModifed = target.getResourceInfo(false, false).getLocalSyncInfo();
/* 165 */     if (lastModifed != node.getLastModified())
/* 166 */       return false; 
/* 167 */     return true;
/*     */   }
/*     */   
/*     */   protected void synchronize(UnifiedTreeNode node) throws CoreException {
/* 171 */     getRefreshLocalVisitor().visit(node);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(UnifiedTreeNode node) throws CoreException {
/* 176 */     this.monitor.checkCanceled();
/* 177 */     int work = 1;
/*     */     
/*     */     try {
/* 180 */       if (node.getStore() == null) {
/*     */         
/* 182 */         IPath path = node.getResource().getFullPath();
/* 183 */         String message = NLS.bind(Messages.localstore_locationUndefined, path);
/* 184 */         this.status.add((IStatus)new ResourceStatus(271, path, message, null));
/* 185 */         return false;
/*     */       } 
/* 187 */       boolean wasSynchronized = isSynchronized(node);
/* 188 */       if (this.force && !wasSynchronized) {
/* 189 */         synchronize(node);
/*     */ 
/*     */         
/* 192 */         work = 0;
/*     */         
/* 194 */         if (!node.existsInFileSystem()) {
/* 195 */           IPath path = node.getResource().getFullPath();
/* 196 */           String message = NLS.bind(Messages.resources_mustExist, path);
/* 197 */           this.status.add((IStatus)new ResourceStatus(368, path, message, null));
/* 198 */           return false;
/*     */         } 
/*     */       } 
/* 201 */       if (!this.force && !wasSynchronized) {
/* 202 */         IPath path = node.getResource().getFullPath();
/* 203 */         String message = NLS.bind(Messages.localstore_resourceIsOutOfSync, path);
/* 204 */         this.status.add((IStatus)new ResourceStatus(274, path, message, null));
/* 205 */         return true;
/*     */       } 
/* 207 */       return copy(node);
/*     */     } finally {
/* 209 */       this.monitor.worked(work);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\CopyVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */