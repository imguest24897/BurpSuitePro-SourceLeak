package org.eclipse.core.resources;

import java.util.Map;

public interface ICommand {
  Map<String, String> getArguments();
  
  String getBuilderName();
  
  boolean isBuilding(int paramInt);
  
  boolean isConfigurable();
  
  void setArguments(Map<String, String> paramMap);
  
  void setBuilderName(String paramString);
  
  void setBuilding(int paramInt, boolean paramBoolean);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\ICommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */