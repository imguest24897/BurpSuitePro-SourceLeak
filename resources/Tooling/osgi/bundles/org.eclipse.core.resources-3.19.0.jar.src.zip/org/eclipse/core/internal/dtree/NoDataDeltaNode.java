/*     */ package org.eclipse.core.internal.dtree;
/*     */ 
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoDataDeltaNode
/*     */   extends AbstractDataTreeNode
/*     */ {
/*     */   public NoDataDeltaNode(String name) {
/*  30 */     this(name, NO_CHILDREN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NoDataDeltaNode(String name, AbstractDataTreeNode[] children) {
/*  40 */     super(name, children);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NoDataDeltaNode(String localName, AbstractDataTreeNode childNode) {
/*  50 */     super(localName, new AbstractDataTreeNode[] { childNode });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode asBackwardDelta(DeltaDataTree myTree, DeltaDataTree parentTree, IPath key) {
/*  58 */     int numChildren = this.children.length;
/*  59 */     if (numChildren == 0)
/*  60 */       return new NoDataDeltaNode(this.name, NO_CHILDREN); 
/*  61 */     AbstractDataTreeNode[] newChildren = new AbstractDataTreeNode[numChildren];
/*  62 */     for (int i = numChildren; --i >= 0;) {
/*  63 */       newChildren[i] = this.children[i].asBackwardDelta(myTree, parentTree, key.append(this.children[i].getName()));
/*     */     }
/*  65 */     return new NoDataDeltaNode(this.name, newChildren);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode compareWithParent(IPath key, DeltaDataTree parent, IComparator comparator) {
/*  73 */     AbstractDataTreeNode[] comparedChildren = compareWithParent(this.children, key, parent, comparator);
/*  74 */     Object oldData = parent.getData(key);
/*  75 */     return new DataTreeNode(key.lastSegment(), new NodeComparison(oldData, oldData, 4, 0), comparedChildren);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode copy() {
/*     */     AbstractDataTreeNode[] childrenCopy;
/*  85 */     if (this.children.length == 0) {
/*  86 */       childrenCopy = NO_CHILDREN;
/*     */     } else {
/*  88 */       childrenCopy = new AbstractDataTreeNode[this.children.length];
/*  89 */       System.arraycopy(this.children, 0, childrenCopy, 0, this.children.length);
/*     */     } 
/*  91 */     return new NoDataDeltaNode(this.name, childrenCopy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isDelta() {
/* 100 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isEmptyDelta() {
/* 108 */     return (size() == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode simplifyWithParent(IPath key, DeltaDataTree parent, IComparator comparer) {
/* 116 */     AbstractDataTreeNode[] simplifiedChildren = simplifyWithParent(this.children, key, parent, comparer);
/* 117 */     return new NoDataDeltaNode(this.name, simplifiedChildren);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int type() {
/* 125 */     return 3;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\dtree\NoDataDeltaNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */