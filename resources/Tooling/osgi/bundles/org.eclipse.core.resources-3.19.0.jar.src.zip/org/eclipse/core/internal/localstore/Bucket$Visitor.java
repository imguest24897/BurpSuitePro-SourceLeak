package org.eclipse.core.internal.localstore;

import org.eclipse.core.runtime.CoreException;

public abstract class Visitor {
  public static final int CONTINUE = 0;
  
  public static final int STOP = 1;
  
  public static final int RETURN = 2;
  
  public void afterSaving(Bucket bucket) throws CoreException {}
  
  public void beforeSaving(Bucket bucket) throws CoreException {}
  
  public abstract int visit(Bucket.Entry paramEntry);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\Bucket$Visitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */