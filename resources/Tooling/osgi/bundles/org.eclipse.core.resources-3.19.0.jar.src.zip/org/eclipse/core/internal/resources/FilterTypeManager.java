/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import org.eclipse.core.resources.IFilterMatcherDescriptor;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.core.runtime.IExtension;
/*    */ import org.eclipse.core.runtime.IExtensionPoint;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.IRegistryEventListener;
/*    */ import org.eclipse.core.runtime.RegistryFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FilterTypeManager
/*    */   implements IManager
/*    */ {
/*    */   private static final String FILTER_ELEMENT = "filterMatcher";
/* 33 */   private HashMap<String, IFilterMatcherDescriptor> factories = new HashMap<>();
/*    */   
/*    */   public FilterTypeManager() {
/* 36 */     IExtensionPoint point = RegistryFactory.getRegistry().getExtensionPoint("org.eclipse.core.resources", "filterMatchers");
/* 37 */     if (point != null) {
/*    */       byte b; int i; IExtension[] arrayOfIExtension;
/* 39 */       for (i = (arrayOfIExtension = point.getExtensions()).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension[b];
/* 40 */         processExtension(extension); b++; }
/*    */       
/* 42 */       RegistryFactory.getRegistry().addListener(new IRegistryEventListener() { public void added(IExtension[] extensions) { byte b;
/*    */               int i;
/*    */               IExtension[] arrayOfIExtension;
/* 45 */               for (i = (arrayOfIExtension = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension[b];
/* 46 */                 FilterTypeManager.this.processExtension(extension);
/*    */                 b++; }
/*    */                }
/*    */             
/*    */             public void added(IExtensionPoint[] extensionPoints) {}
/*    */             
/*    */             public void removed(IExtension[] extensions) {
/*    */               byte b;
/*    */               int i;
/*    */               IExtension[] arrayOfIExtension;
/* 56 */               for (i = (arrayOfIExtension = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension[b];
/* 57 */                 FilterTypeManager.this.processRemovedExtension(extension);
/*    */                 b++; }
/*    */             
/*    */             }
/*    */ 
/*    */             
/*    */             public void removed(IExtensionPoint[] extensionPoints) {} }
/*    */         );
/*    */     } 
/*    */   }
/*    */   
/*    */   public IFilterMatcherDescriptor getFilterDescriptor(String id) {
/* 69 */     return this.factories.get(id);
/*    */   }
/*    */   
/*    */   public IFilterMatcherDescriptor[] getFilterDescriptors() {
/* 73 */     return (IFilterMatcherDescriptor[])this.factories.values().toArray((Object[])new IFilterMatcherDescriptor[0]);
/*    */   }
/*    */   
/*    */   protected void processExtension(IExtension extension) {
/* 77 */     IConfigurationElement[] elements = extension.getConfigurationElements(); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 78 */     for (i = (arrayOfIConfigurationElement1 = elements).length, b = 0; b < i; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b];
/* 79 */       if (element.getName().equalsIgnoreCase("filterMatcher")) {
/* 80 */         IFilterMatcherDescriptor desc = new FilterDescriptor(element);
/* 81 */         this.factories.put(desc.getId(), desc);
/*    */       } 
/*    */       b++; }
/*    */   
/*    */   }
/*    */   protected void processRemovedExtension(IExtension extension) {
/* 87 */     IConfigurationElement[] elements = extension.getConfigurationElements(); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 88 */     for (i = (arrayOfIConfigurationElement1 = elements).length, b = 0; b < i; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b];
/* 89 */       if (element.getName().equalsIgnoreCase("filterMatcher")) {
/* 90 */         IFilterMatcherDescriptor desc = new FilterDescriptor(element, false);
/* 91 */         this.factories.remove(desc.getId());
/*    */       } 
/*    */       b++; }
/*    */   
/*    */   }
/*    */   
/*    */   public void shutdown(IProgressMonitor monitor) {}
/*    */   
/*    */   public void startup(IProgressMonitor monitor) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\FilterTypeManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */