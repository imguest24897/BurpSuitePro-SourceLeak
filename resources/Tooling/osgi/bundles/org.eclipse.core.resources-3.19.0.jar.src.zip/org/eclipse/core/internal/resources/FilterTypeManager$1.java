/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import org.eclipse.core.runtime.IExtension;
/*    */ import org.eclipse.core.runtime.IExtensionPoint;
/*    */ import org.eclipse.core.runtime.IRegistryEventListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements IRegistryEventListener
/*    */ {
/*    */   public void added(IExtension[] extensions) {
/*    */     byte b;
/*    */     int i;
/*    */     IExtension[] arrayOfIExtension;
/* 45 */     for (i = (arrayOfIExtension = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension[b];
/* 46 */       FilterTypeManager.this.processExtension(extension);
/*    */       b++; }
/*    */   
/*    */   }
/*    */   public void added(IExtensionPoint[] extensionPoints) {}
/*    */   
/*    */   public void removed(IExtension[] extensions) {
/*    */     byte b;
/*    */     int i;
/*    */     IExtension[] arrayOfIExtension;
/* 56 */     for (i = (arrayOfIExtension = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension[b];
/* 57 */       FilterTypeManager.this.processRemovedExtension(extension);
/*    */       b++; }
/*    */   
/*    */   }
/*    */   
/*    */   public void removed(IExtensionPoint[] extensionPoints) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\FilterTypeManager$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */