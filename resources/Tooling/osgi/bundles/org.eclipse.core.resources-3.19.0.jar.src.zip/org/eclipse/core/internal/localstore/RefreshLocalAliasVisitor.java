/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.internal.resources.Container;
/*     */ import org.eclipse.core.internal.resources.Resource;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RefreshLocalAliasVisitor
/*     */   extends RefreshLocalVisitor
/*     */ {
/*     */   public RefreshLocalAliasVisitor(IProgressMonitor monitor) {
/*  29 */     super(monitor);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void createResource(UnifiedTreeNode node, Resource target) throws CoreException {
/*  34 */     super.createResource(node, target);
/*  35 */     IFileStore store = node.getStore();
/*  36 */     if (store == null)
/*     */       return; 
/*  38 */     IResource[] aliases = this.workspace.getAliasManager().computeAliases((IResource)target, store);
/*  39 */     if (aliases != null) {
/*  40 */       byte b; int i; IResource[] arrayOfIResource; for (i = (arrayOfIResource = aliases).length, b = 0; b < i; ) { IResource alias = arrayOfIResource[b];
/*  41 */         if (alias.getProject().isOpen() && !((Resource)alias).isFiltered())
/*  42 */           super.createResource(node, (Resource)alias); 
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void deleteResource(UnifiedTreeNode node, Resource target) throws CoreException {
/*  49 */     super.deleteResource(node, target);
/*  50 */     IFileStore store = node.getStore();
/*  51 */     if (store == null)
/*     */       return; 
/*  53 */     IResource[] aliases = this.workspace.getAliasManager().computeAliases((IResource)target, store);
/*  54 */     if (aliases != null) {
/*  55 */       boolean wasFilteredOut = false;
/*  56 */       if (store.fetchInfo() != null && store.fetchInfo().exists())
/*  57 */         wasFilteredOut = target.isFiltered();  byte b; int i; IResource[] arrayOfIResource;
/*  58 */       for (i = (arrayOfIResource = aliases).length, b = 0; b < i; ) { IResource aliase = arrayOfIResource[b];
/*  59 */         if (aliase.getProject().isOpen())
/*  60 */           if (wasFilteredOut) {
/*  61 */             if (((Resource)aliase).isFiltered())
/*  62 */               super.deleteResource(node, (Resource)aliase); 
/*     */           } else {
/*  64 */             super.deleteResource(node, (Resource)aliase);
/*     */           }  
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void resourceChanged(UnifiedTreeNode node, Resource target) {
/*  72 */     super.resourceChanged(node, target);
/*  73 */     IFileStore store = node.getStore();
/*  74 */     if (store == null)
/*     */       return; 
/*  76 */     IResource[] aliases = this.workspace.getAliasManager().computeAliases((IResource)target, store);
/*  77 */     if (aliases != null) {
/*  78 */       byte b; int i; IResource[] arrayOfIResource; for (i = (arrayOfIResource = aliases).length, b = 0; b < i; ) { IResource aliase = arrayOfIResource[b];
/*  79 */         if (aliase.getProject().isOpen())
/*  80 */           super.resourceChanged(node, (Resource)aliase); 
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */   protected void fileToFolder(UnifiedTreeNode node, Resource target) throws CoreException {
/*  86 */     super.fileToFolder(node, target);
/*  87 */     IFileStore store = node.getStore();
/*  88 */     if (store == null)
/*     */       return; 
/*  90 */     IResource[] aliases = this.workspace.getAliasManager().computeAliases((IResource)target, store);
/*  91 */     if (aliases != null) {
/*  92 */       byte b; int i; IResource[] arrayOfIResource; for (i = (arrayOfIResource = aliases).length, b = 0; b < i; ) { IResource aliase = arrayOfIResource[b];
/*  93 */         super.fileToFolder(node, (Resource)aliase);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   } protected void folderToFile(UnifiedTreeNode node, Resource target) throws CoreException {
/*  98 */     super.folderToFile(node, target);
/*  99 */     IFileStore store = node.getStore();
/* 100 */     if (store == null)
/*     */       return; 
/* 102 */     IResource[] aliases = this.workspace.getAliasManager().computeAliases((IResource)target, store);
/* 103 */     if (aliases != null) {
/* 104 */       byte b; int i; IResource[] arrayOfIResource; for (i = (arrayOfIResource = aliases).length, b = 0; b < i; ) { IResource aliase = arrayOfIResource[b];
/* 105 */         super.folderToFile(node, (Resource)aliase);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   } protected void refresh(Container parent) throws CoreException {
/* 110 */     parent.getLocalManager().refresh((IResource)parent, 0, true, null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\RefreshLocalAliasVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */