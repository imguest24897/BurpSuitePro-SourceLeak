/*    */ package org.eclipse.core.internal.propertytester;
/*    */ 
/*    */ import org.eclipse.core.resources.IProject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProjectPropertyTester
/*    */   extends ResourcePropertyTester
/*    */ {
/*    */   private static final String OPEN = "open";
/*    */   
/*    */   public boolean test(Object receiver, String method, Object[] args, Object expectedValue) {
/* 33 */     if (receiver instanceof IProject && method.equals("open"))
/* 34 */       return (((IProject)receiver).isOpen() == toBoolean(expectedValue)); 
/* 35 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\propertytester\ProjectPropertyTester.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */