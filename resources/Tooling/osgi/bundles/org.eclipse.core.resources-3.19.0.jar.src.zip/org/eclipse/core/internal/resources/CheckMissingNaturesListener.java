/*     */ package org.eclipse.core.internal.resources;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IMarker;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResourceChangeEvent;
/*     */ import org.eclipse.core.resources.IResourceChangeListener;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.resources.WorkspaceJob;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.ILog;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*     */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.service.component.annotations.Component;
/*     */ import org.osgi.service.component.annotations.Deactivate;
/*     */ import org.osgi.service.component.annotations.Reference;
/*     */ 
/*     */ @Component(service = {IResourceChangeListener.class}, property = {"event.mask:Integer=1"})
/*     */ public class CheckMissingNaturesListener implements IResourceChangeListener, IEclipsePreferences.IPreferenceChangeListener {
/*  38 */   public static final String MARKER_TYPE = String.valueOf(ResourcesPlugin.getPlugin().getBundle().getSymbolicName()) + ".unknownNature";
/*     */   
/*     */   public static final String NATURE_ID_ATTRIBUTE = "natureId";
/*     */   
/*     */   @Reference
/*     */   private IWorkspace workspace;
/*     */   
/*     */   @Reference
/*     */   private ILog log;
/*     */   @Reference(target = "(&(objectClass=org.eclipse.core.runtime.preferences.IScopeContext)(type=bundle))")
/*     */   IScopeContext bundleScope;
/*     */   private IEclipsePreferences eclipsePreferences;
/*     */   
/*     */   @Activate
/*     */   public void register() {
/*  53 */     this.eclipsePreferences = this.bundleScope.getNode("");
/*  54 */     this.eclipsePreferences.addPreferenceChangeListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deactivate
/*     */   public void unregister() {
/*  60 */     this.eclipsePreferences.removePreferenceChangeListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void resourceChanged(IResourceChangeEvent event) {
/*  65 */     if (event.getDelta() == null) {
/*     */       return;
/*     */     }
/*     */     try {
/*  69 */       Set<IProject> modifiedProjects = new HashSet<>();
/*  70 */       event.getDelta().accept(delta -> {
/*     */             if (delta.getResource() != null && delta.getResource().getType() == 4 && (delta.getKind() == 1 || delta.getKind() == 4)) {
/*     */               paramSet.add((IProject)delta.getResource());
/*     */             }
/*  74 */             return !(delta.getResource() != null && delta.getResource().getType() != 8);
/*     */           });
/*  76 */       updateMarkers(modifiedProjects);
/*  77 */     } catch (CoreException e) {
/*  78 */       this.log.log((IStatus)new Status(4, ResourcesPlugin.getPlugin().getBundle().getSymbolicName(), e.getMessage(), 
/*  79 */             (Throwable)e));
/*     */     } 
/*     */   }
/*     */   
/*     */   int getMissingNatureSeverity(IProject project) {
/*  84 */     int severity = 1;
/*  85 */     IEclipsePreferences node = InstanceScope.INSTANCE.getNode("org.eclipse.core.resources");
/*  86 */     if (node != null) {
/*  87 */       severity = node.getInt("missingNatureMarkerSeverity", 1);
/*     */     }
/*  89 */     return severity;
/*     */   }
/*     */ 
/*     */   
/*     */   public void preferenceChange(IEclipsePreferences.PreferenceChangeEvent event) {
/*  94 */     if ("missingNatureMarkerSeverity".equals(event.getKey())) {
/*  95 */       int newSeverity = (event.getNewValue() != null) ? Integer.parseInt((String)event.getNewValue()) : 1;
/*  96 */       int oldSeverity = (event.getOldValue() != null) ? Integer.parseInt((String)event.getOldValue()) : 1;
/*  97 */       if (newSeverity < 0) {
/*  98 */         removeAllMarkers((IContainer)this.workspace.getRoot());
/*  99 */       } else if (oldSeverity < 0 && newSeverity >= 0) {
/* 100 */         updateMarkers(Arrays.asList(this.workspace.getRoot().getProjects()));
/*     */       } else {
/* 102 */         updateExistingMarkersSeverity((IContainer)this.workspace.getRoot(), newSeverity);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void removeAllMarkers(IContainer workspaceRootOrProject) {
/* 108 */     final Collection<IMarker> markers = getRelatedMarkers(workspaceRootOrProject);
/* 109 */     if (markers.isEmpty()) {
/*     */       return;
/*     */     }
/* 112 */     WorkspaceJob job = new WorkspaceJob(Messages.updateUnknownNatureMarkers)
/*     */       {
/*     */         public IStatus runInWorkspace(IProgressMonitor monitor) throws CoreException {
/* 115 */           for (IMarker marker : markers) {
/* 116 */             if (marker.exists() && marker.getResource().isAccessible()) {
/* 117 */               marker.delete();
/*     */             }
/*     */           } 
/* 120 */           return Status.OK_STATUS;
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean belongsTo(Object family) {
/* 125 */           return !(!super.belongsTo(family) && !CheckMissingNaturesListener.MARKER_TYPE.equals(family));
/*     */         }
/*     */       };
/* 128 */     job.setUser(false);
/* 129 */     job.setSystem(true);
/* 130 */     job.setPriority(50);
/* 131 */     job.setRule((ISchedulingRule)workspaceRootOrProject);
/* 132 */     job.schedule();
/*     */   }
/*     */   
/*     */   private void updateExistingMarkersSeverity(IContainer workspaceRootOrProject, final int newSeverity) {
/* 136 */     final Collection<IMarker> markers = getRelatedMarkers(workspaceRootOrProject);
/* 137 */     if (markers.isEmpty()) {
/*     */       return;
/*     */     }
/* 140 */     WorkspaceJob job = new WorkspaceJob(Messages.updateUnknownNatureMarkers)
/*     */       {
/*     */         public IStatus runInWorkspace(IProgressMonitor monitor) throws CoreException {
/* 143 */           for (IMarker marker : markers) {
/* 144 */             if (marker.exists() && marker.getResource().isAccessible()) {
/* 145 */               marker.setAttribute("severity", newSeverity);
/*     */             }
/*     */           } 
/* 148 */           return Status.OK_STATUS;
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean belongsTo(Object family) {
/* 153 */           return !(!super.belongsTo(family) && !CheckMissingNaturesListener.MARKER_TYPE.equals(family));
/*     */         }
/*     */       };
/* 156 */     job.setUser(false);
/* 157 */     job.setSystem(true);
/* 158 */     job.setPriority(50);
/* 159 */     job.setRule((ISchedulingRule)workspaceRootOrProject);
/* 160 */     job.schedule();
/*     */   }
/*     */   
/*     */   private void updateMarkers(Collection<IProject> projects) {
/* 164 */     for (IProject project : projects) {
/* 165 */       if (!project.isAccessible()) {
/*     */         continue;
/*     */       }
/* 168 */       int severity = getMissingNatureSeverity(project);
/*     */       try {
/* 170 */         if (severity < 0) {
/* 171 */           removeAllMarkers((IContainer)project);
/*     */           
/*     */           continue;
/*     */         } 
/* 175 */         final Set<String> missingNatures = new HashSet<>(); byte b; int i; String[] arrayOfString;
/* 176 */         for (i = (arrayOfString = project.getDescription().getNatureIds()).length, b = 0; b < i; ) { String natureId = arrayOfString[b];
/* 177 */           if (project.getWorkspace().getNatureDescriptor(natureId) == null) {
/* 178 */             missingNatures.add(natureId);
/*     */           }
/*     */           b++; }
/*     */         
/* 182 */         final Set<IMarker> toRemove = new HashSet<>();
/* 183 */         for (IMarker existingMarker : getRelatedProjectMarkers(project)) {
/* 184 */           String markerNature = existingMarker.getAttribute("natureId", "");
/* 185 */           if (!missingNatures.contains(markerNature)) {
/* 186 */             toRemove.add(existingMarker);
/*     */             continue;
/*     */           } 
/* 189 */           missingNatures.remove(markerNature);
/*     */         } 
/*     */ 
/*     */         
/* 193 */         if (!toRemove.isEmpty() || !missingNatures.isEmpty()) {
/* 194 */           WorkspaceJob workspaceJob = new WorkspaceJob(Messages.updateUnknownNatureMarkers) {
/*     */               public IStatus runInWorkspace(IProgressMonitor monitor) throws CoreException {
/*     */                 IProject iProject;
/* 197 */                 for (IMarker marker : toRemove) {
/* 198 */                   marker.delete();
/*     */                 }
/* 200 */                 IFile iFile = project.getFile(".project");
/* 201 */                 if (!iFile.isAccessible()) {
/* 202 */                   iProject = project;
/*     */                 }
/* 204 */                 for (String natureId : missingNatures) {
/*     */                   
/* 206 */                   Map<String, Object> attributes = new HashMap<>();
/* 207 */                   attributes.put("severity", Integer.valueOf(CheckMissingNaturesListener.this.getMissingNatureSeverity(project)));
/* 208 */                   attributes.put("message", NLS.bind(Messages.natures_missingNature, natureId));
/* 209 */                   attributes.put("natureId", natureId);
/* 210 */                   IMarker marker = iProject.createMarker(CheckMissingNaturesListener.MARKER_TYPE, attributes);
/* 211 */                   if (iProject.getType() == 1) {
/* 212 */                     CheckMissingNaturesListener.this.updateRange(marker, natureId, (IFile)iProject);
/*     */                   }
/*     */                 } 
/* 215 */                 return Status.OK_STATUS;
/*     */               }
/*     */ 
/*     */               
/*     */               public boolean belongsTo(Object family) {
/* 220 */                 return !(!super.belongsTo(family) && !CheckMissingNaturesListener.MARKER_TYPE.equals(family));
/*     */               }
/*     */             };
/* 223 */           workspaceJob.setRule((ISchedulingRule)project);
/* 224 */           workspaceJob.setUser(false);
/* 225 */           workspaceJob.setSystem(true);
/* 226 */           workspaceJob.setPriority(50);
/* 227 */           workspaceJob.schedule();
/*     */         } 
/* 229 */       } catch (CoreException e) {
/* 230 */         this.log.log((IStatus)new Status(4, "org.eclipse.core.resources", e.getMessage(), (Throwable)e));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void updateRange(IMarker marker, String natureId, IFile file) {
/* 236 */     if (!file.isAccessible()) {
/*     */       return;
/*     */     }
/* 239 */     Pattern pattern = Pattern.compile(".*<nature>\\s*(" + natureId.replace(".", "\\.") + ")\\s*</" + "nature" + ">.*", 
/* 240 */         32); try {
/* 241 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 256 */     catch (IOException|CoreException e) {
/* 257 */       this.log.log((IStatus)new Status(4, "org.eclipse.core.resources", e.getMessage(), e));
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Collection<IMarker> getRelatedMarkers(IContainer rootOrProject) {
/* 262 */     switch (rootOrProject.getType()) {
/*     */       case 8:
/* 264 */         return getRelatedRootMarkers((IWorkspaceRoot)rootOrProject);
/*     */       case 4:
/* 266 */         return getRelatedProjectMarkers((IProject)rootOrProject);
/*     */     } 
/* 268 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */   protected Collection<IMarker> getRelatedRootMarkers(IWorkspaceRoot root) {
/* 272 */     if (!root.isAccessible()) {
/* 273 */       return Collections.emptyList();
/*     */     }
/* 275 */     Set<IMarker> res = new HashSet<>(); byte b; int i; IProject[] arrayOfIProject;
/* 276 */     for (i = (arrayOfIProject = root.getProjects()).length, b = 0; b < i; ) { IProject project = arrayOfIProject[b];
/* 277 */       res.addAll(getRelatedProjectMarkers(project)); b++; }
/*     */     
/* 279 */     return res;
/*     */   }
/*     */   
/*     */   protected Collection<IMarker> getRelatedProjectMarkers(IProject project) {
/* 283 */     if (!project.isAccessible()) {
/* 284 */       return Collections.emptyList();
/*     */     }
/*     */     try {
/* 287 */       return Arrays.asList(project.findMarkers(MARKER_TYPE, true, 1));
/* 288 */     } catch (CoreException e) {
/* 289 */       this.log.log((IStatus)new Status(4, "org.eclipse.core.resources", e.getMessage(), (Throwable)e));
/* 290 */       return Collections.emptyList();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\CheckMissingNaturesListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */