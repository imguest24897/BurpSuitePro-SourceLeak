/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.IOException;
/*    */ import org.eclipse.core.internal.utils.Messages;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SyncInfoSnapReader
/*    */ {
/*    */   protected Workspace workspace;
/*    */   protected Synchronizer synchronizer;
/*    */   
/*    */   public SyncInfoSnapReader(Workspace workspace, Synchronizer synchronizer) {
/* 28 */     this.workspace = workspace;
/* 29 */     this.synchronizer = synchronizer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected SyncInfoSnapReader getReader(int formatVersion) throws IOException {
/* 36 */     switch (formatVersion) {
/*    */       case 3:
/* 38 */         return new SyncInfoSnapReader_3(this.workspace, this.synchronizer);
/*    */     } 
/* 40 */     throw new IOException(NLS.bind(Messages.resources_format, Integer.valueOf(formatVersion)));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void readSyncInfo(DataInputStream input) throws IOException {
/* 47 */     int formatVersion = readVersionNumber(input);
/* 48 */     SyncInfoSnapReader reader = getReader(formatVersion);
/* 49 */     reader.readSyncInfo(input);
/*    */   }
/*    */   
/*    */   protected static int readVersionNumber(DataInputStream input) throws IOException {
/* 53 */     return input.readInt();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\SyncInfoSnapReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */