/*    */ package org.eclipse.core.internal.utils;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StringPool
/*    */ {
/*    */   private int savings;
/* 34 */   private final HashMap<String, String> map = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String add(String string) {
/* 50 */     if (string == null)
/* 51 */       return string; 
/* 52 */     String result = this.map.putIfAbsent(string, string);
/* 53 */     if (result != null) {
/* 54 */       if (result != string)
/*    */       {
/*    */         
/* 57 */         this.savings += 44 + 2 * string.length();
/*    */       }
/* 59 */       return result;
/*    */     } 
/* 61 */     return string;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getSavedStringCount() {
/* 79 */     return this.savings;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\interna\\utils\StringPool.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */