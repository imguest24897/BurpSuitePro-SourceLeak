/*     */ package org.eclipse.core.internal.utils;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.math.BigInteger;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UniversalUniqueIdentifier
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  31 */   private byte[] fBits = new byte[16];
/*     */ 
/*     */   
/*     */   private static BigInteger fgPreviousClockValue;
/*     */   
/*  36 */   private static int fgClockAdjustment = 0;
/*  37 */   private static int fgClockSequence = -1;
/*     */ 
/*     */ 
/*     */   
/*  41 */   private static byte[] nodeAddress = computeNodeAddress();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private static Random fgRandomNumberGenerator = new Random();
/*     */ 
/*     */   
/*     */   public static final int BYTES_SIZE = 16;
/*     */   
/*  51 */   public static final byte[] UNDEFINED_UUID_BYTES = new byte[16];
/*     */   
/*     */   public static final int MAX_CLOCK_SEQUENCE = 16384;
/*     */   
/*     */   public static final int MAX_CLOCK_ADJUSTMENT = 32767;
/*     */   
/*     */   public static final int TIME_FIELD_START = 0;
/*     */   
/*     */   public static final int TIME_FIELD_STOP = 6;
/*     */   
/*     */   public static final int TIME_HIGH_AND_VERSION = 7;
/*     */   
/*     */   public static final int CLOCK_SEQUENCE_HIGH_AND_RESERVED = 8;
/*     */   
/*     */   public static final int CLOCK_SEQUENCE_LOW = 9;
/*     */   
/*     */   public static final int NODE_ADDRESS_START = 10;
/*     */   
/*     */   public static final int NODE_ADDRESS_BYTE_SIZE = 6;
/*     */   public static final int BYTE_MASK = 255;
/*     */   public static final int HIGH_NIBBLE_MASK = 240;
/*     */   public static final int LOW_NIBBLE_MASK = 15;
/*     */   public static final int SHIFT_NIBBLE = 4;
/*     */   public static final int ShiftByte = 8;
/*     */   
/*     */   public UniversalUniqueIdentifier() {
/*  77 */     setVersion(1);
/*  78 */     setVariant(1);
/*  79 */     setTimeValues();
/*  80 */     setNode(getNodeAddress());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UniversalUniqueIdentifier(byte[] byteValue) {
/*  93 */     this.fBits = new byte[16];
/*  94 */     if (byteValue.length >= 16) {
/*  95 */       System.arraycopy(byteValue, 0, this.fBits, 0, 16);
/*     */     }
/*     */   }
/*     */   
/*     */   private void appendByteString(StringBuilder buffer, byte value) {
/*     */     String hexString;
/* 101 */     if (value < 0) {
/* 102 */       hexString = Integer.toHexString(256 + value);
/*     */     } else {
/* 104 */       hexString = Integer.toHexString(value);
/* 105 */     }  if (hexString.length() == 1)
/* 106 */       buffer.append("0"); 
/* 107 */     buffer.append(hexString);
/*     */   }
/*     */   
/*     */   private static BigInteger clockValueNow() {
/* 111 */     GregorianCalendar now = new GregorianCalendar();
/* 112 */     BigInteger nowMillis = BigInteger.valueOf(now.getTime().getTime());
/* 113 */     BigInteger baseMillis = BigInteger.valueOf(now.getGregorianChange().getTime());
/*     */     
/* 115 */     return nowMillis.subtract(baseMillis).multiply(BigInteger.valueOf(10000L));
/*     */   }
/*     */   
/*     */   public static int compareTime(byte[] fBits1, byte[] fBits2) {
/* 119 */     for (int i = 6; i >= 0; i--) {
/* 120 */       if (fBits1[i] != fBits2[i])
/* 121 */         return (0xFF & fBits1[i]) - (0xFF & fBits2[i]); 
/* 122 */     }  return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] computeNodeAddress() {
/* 133 */     byte[] address = new byte[6];
/* 134 */     SecureRandom randomizer = new SecureRandom();
/* 135 */     randomizer.nextBytes(address);
/*     */ 
/*     */     
/* 138 */     address[0] = (byte)(address[0] | Byte.MIN_VALUE);
/*     */     
/* 140 */     return address;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 145 */     if (this == obj)
/* 146 */       return true; 
/* 147 */     if (!(obj instanceof UniversalUniqueIdentifier)) {
/* 148 */       return false;
/*     */     }
/* 150 */     byte[] other = ((UniversalUniqueIdentifier)obj).fBits;
/* 151 */     if (this.fBits == other)
/* 152 */       return true; 
/* 153 */     if (this.fBits.length != other.length)
/* 154 */       return false; 
/* 155 */     for (int i = 0; i < this.fBits.length; i++) {
/* 156 */       if (this.fBits[i] != other[i])
/* 157 */         return false; 
/*     */     } 
/* 159 */     return true;
/*     */   }
/*     */   
/*     */   private static byte[] getNodeAddress() {
/* 163 */     return nodeAddress;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 168 */     return this.fBits[0] + this.fBits[3] + this.fBits[7] + this.fBits[11] + this.fBits[15];
/*     */   }
/*     */ 
/*     */   
/*     */   private static int nextClockSequence() {
/* 173 */     if (fgClockSequence == -1) {
/* 174 */       fgClockSequence = (int)(fgRandomNumberGenerator.nextDouble() * 16384.0D);
/*     */     }
/* 176 */     fgClockSequence = (fgClockSequence + 1) % 16384;
/*     */     
/* 178 */     return fgClockSequence;
/*     */   }
/*     */ 
/*     */   
/*     */   private static BigInteger nextTimestamp() {
/* 183 */     BigInteger timestamp = clockValueNow();
/*     */ 
/*     */     
/* 186 */     int timestampComparison = timestamp.compareTo(fgPreviousClockValue);
/*     */     
/* 188 */     if (timestampComparison == 0)
/* 189 */     { if (fgClockAdjustment == 32767) {
/* 190 */         while (timestamp.compareTo(fgPreviousClockValue) == 0)
/* 191 */           timestamp = clockValueNow(); 
/* 192 */         timestamp = nextTimestamp();
/*     */       } else {
/* 194 */         fgClockAdjustment++;
/*     */       }  }
/* 196 */     else { fgClockAdjustment = 0;
/*     */       
/* 198 */       if (timestampComparison < 0) {
/* 199 */         nextClockSequence();
/*     */       } }
/*     */     
/* 202 */     return timestamp;
/*     */   }
/*     */   
/*     */   private void setClockSequence(int clockSeq) {
/* 206 */     int clockSeqHigh = clockSeq >>> 8 & 0xF;
/* 207 */     int reserved = this.fBits[8] & 0xF0;
/*     */     
/* 209 */     this.fBits[8] = (byte)(reserved | clockSeqHigh);
/* 210 */     this.fBits[9] = (byte)(clockSeq & 0xFF);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setNode(byte[] bytes) {
/* 215 */     System.arraycopy(bytes, 0, this.fBits, 10, 6);
/*     */   }
/*     */   
/*     */   private void setTimestamp(BigInteger timestamp) {
/* 219 */     BigInteger value = timestamp;
/* 220 */     BigInteger bigByte = BigInteger.valueOf(256L);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     for (int index = 0; index < 6; index++) {
/* 226 */       BigInteger[] results = value.divideAndRemainder(bigByte);
/* 227 */       value = results[0];
/* 228 */       this.fBits[index] = (byte)results[1].intValue();
/*     */     } 
/* 230 */     int version = this.fBits[7] & 0xF0;
/* 231 */     int timeHigh = value.intValue() & 0xF;
/* 232 */     this.fBits[7] = (byte)(timeHigh | version);
/*     */   }
/*     */   
/*     */   protected synchronized void setTimeValues() {
/* 236 */     setTimestamp(timestamp());
/* 237 */     setClockSequence(fgClockSequence);
/*     */   }
/*     */   
/*     */   protected int setVariant(int variantIdentifier) {
/* 241 */     int clockSeqHigh = this.fBits[8] & 0xF;
/* 242 */     int variant = variantIdentifier & 0xF;
/*     */     
/* 244 */     this.fBits[8] = (byte)(variant << 4 | clockSeqHigh);
/* 245 */     return variant;
/*     */   }
/*     */   
/*     */   protected void setVersion(int versionIdentifier) {
/* 249 */     int timeHigh = this.fBits[7] & 0xF;
/* 250 */     int version = versionIdentifier & 0xF;
/*     */     
/* 252 */     this.fBits[7] = (byte)(timeHigh | version << 4);
/*     */   }
/*     */ 
/*     */   
/*     */   private static BigInteger timestamp() {
/*     */     BigInteger timestamp;
/* 258 */     if (fgPreviousClockValue == null) {
/* 259 */       fgClockAdjustment = 0;
/* 260 */       nextClockSequence();
/* 261 */       timestamp = clockValueNow();
/*     */     } else {
/* 263 */       timestamp = nextTimestamp();
/*     */     } 
/* 265 */     fgPreviousClockValue = timestamp;
/* 266 */     return (fgClockAdjustment == 0) ? timestamp : timestamp.add(BigInteger.valueOf(fgClockAdjustment));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toBytes() {
/* 275 */     byte[] result = new byte[this.fBits.length];
/*     */     
/* 277 */     System.arraycopy(this.fBits, 0, result, 0, this.fBits.length);
/* 278 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 283 */     StringBuilder buffer = new StringBuilder(); byte b; int i; byte[] arrayOfByte;
/* 284 */     for (i = (arrayOfByte = this.fBits).length, b = 0; b < i; ) { byte bit = arrayOfByte[b];
/* 285 */       appendByteString(buffer, bit); b++; }
/* 286 */      return buffer.toString();
/*     */   }
/*     */   
/*     */   public String toStringAsBytes() {
/* 290 */     StringBuilder result = new StringBuilder("{");
/*     */     
/* 292 */     for (int i = 0; i < this.fBits.length; i++) {
/* 293 */       result.append(this.fBits[i]);
/* 294 */       if (i < this.fBits.length + 1)
/* 295 */         result.append(','); 
/*     */     } 
/* 297 */     result.append('}');
/* 298 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\interna\\utils\UniversalUniqueIdentifier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */