/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CharsetManagerJob
/*     */   extends Job
/*     */ {
/*     */   private static final int CHARSET_UPDATE_DELAY = 500;
/*  47 */   private List<Map.Entry<IProject, Boolean>> asyncChanges = new ArrayList<>();
/*     */   
/*     */   public CharsetManagerJob() {
/*  50 */     super(Messages.resources_charsetUpdating);
/*  51 */     setSystem(true);
/*  52 */     setPriority(10);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean belongsTo(Object family) {
/*  57 */     return (CharsetManager.class == family);
/*     */   }
/*     */   
/*     */   public void addChanges(Map<IProject, Boolean> newChanges) {
/*  61 */     if (newChanges.isEmpty())
/*     */       return; 
/*  63 */     synchronized (this.asyncChanges) {
/*  64 */       this.asyncChanges.addAll(newChanges.entrySet());
/*  65 */       this.asyncChanges.notify();
/*     */     } 
/*  67 */     schedule(500L);
/*     */   }
/*     */   
/*     */   public Map.Entry<IProject, Boolean> getNextChange() {
/*  71 */     synchronized (this.asyncChanges) {
/*  72 */       return this.asyncChanges.isEmpty() ? null : this.asyncChanges.remove(this.asyncChanges.size() - 1);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected IStatus run(IProgressMonitor monitor) {
/*  78 */     MultiStatus result = new MultiStatus("org.eclipse.core.resources", 382, Messages.resources_updatingEncoding, null);
/*  79 */     monitor = Policy.monitorFor(monitor);
/*     */     
/*  81 */     try { monitor.beginTask(Messages.resources_charsetUpdating, 100);
/*  82 */       ISchedulingRule rule = CharsetManager.this.workspace.getRuleFactory().modifyRule((IResource)CharsetManager.this.workspace.getRoot());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */        }
/*     */     
/* 114 */     catch (CoreException ce)
/* 115 */     { return ce.getStatus(); }
/*     */     finally
/* 117 */     { monitor.done(); }  monitor.done();
/*     */     
/* 119 */     return (IStatus)result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean shouldRun() {
/* 124 */     synchronized (this.asyncChanges) {
/* 125 */       return !this.asyncChanges.isEmpty();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\CharsetManager$CharsetManagerJob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */