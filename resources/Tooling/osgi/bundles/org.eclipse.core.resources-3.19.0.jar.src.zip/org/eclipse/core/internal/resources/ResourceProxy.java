/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import org.eclipse.core.internal.watson.IPathRequestor;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceProxy;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceProxy
/*     */   implements IResourceProxy, ICoreConstants
/*     */ {
/*  26 */   protected final Workspace workspace = (Workspace)ResourcesPlugin.getWorkspace();
/*     */ 
/*     */   
/*     */   protected IPathRequestor requestor;
/*     */   
/*     */   protected ResourceInfo info;
/*     */   
/*     */   protected IPath fullPath;
/*     */   
/*     */   protected IResource resource;
/*     */ 
/*     */   
/*     */   public long getModificationStamp() {
/*  39 */     return this.info.getModificationStamp();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  44 */     return this.requestor.requestName();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getSessionProperty(QualifiedName key) {
/*  49 */     return this.info.getSessionProperty(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getType() {
/*  54 */     return this.info.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAccessible() {
/*  62 */     int flags = this.info.getFlags();
/*  63 */     if (this.info.getType() == 4)
/*  64 */       return (flags != -1 && ResourceInfo.isSet(flags, 1)); 
/*  65 */     return (flags != -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDerived() {
/*  73 */     int flags = this.info.getFlags();
/*  74 */     return (flags != -1 && ResourceInfo.isSet(flags, 16384));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLinked() {
/*  82 */     int flags = this.info.getFlags();
/*  83 */     return (flags != -1 && ResourceInfo.isSet(flags, 65536));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPhantom() {
/*  91 */     int flags = this.info.getFlags();
/*  92 */     return (flags != -1 && ResourceInfo.isSet(flags, 8));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTeamPrivateMember() {
/* 100 */     int flags = this.info.getFlags();
/* 101 */     return (flags != -1 && ResourceInfo.isSet(flags, 32768));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHidden() {
/* 109 */     int flags = this.info.getFlags();
/* 110 */     return (flags != -1 && ResourceInfo.isSet(flags, 2097152));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath requestFullPath() {
/* 118 */     if (this.fullPath == null)
/* 119 */       this.fullPath = this.requestor.requestPath(); 
/* 120 */     return this.fullPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource requestResource() {
/* 128 */     if (this.resource == null)
/* 129 */       this.resource = this.workspace.newResource(requestFullPath(), this.info.getType()); 
/* 130 */     return this.resource;
/*     */   }
/*     */   
/*     */   protected void reset() {
/* 134 */     this.fullPath = null;
/* 135 */     this.resource = null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ResourceProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */