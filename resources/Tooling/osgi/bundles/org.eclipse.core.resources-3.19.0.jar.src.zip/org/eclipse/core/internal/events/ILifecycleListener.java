package org.eclipse.core.internal.events;

import org.eclipse.core.runtime.CoreException;

public interface ILifecycleListener {
  void handleEvent(LifecycleEvent paramLifecycleEvent) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\ILifecycleListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */