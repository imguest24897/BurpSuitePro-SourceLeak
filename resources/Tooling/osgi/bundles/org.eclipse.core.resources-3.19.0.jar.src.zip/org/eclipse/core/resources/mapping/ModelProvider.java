/*     */ package org.eclipse.core.resources.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.internal.resources.mapping.ModelProviderManager;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ModelProvider
/*     */   extends PlatformObject
/*     */ {
/*     */   public static final String RESOURCE_MODEL_PROVIDER_ID = "org.eclipse.core.resources.modelProvider";
/*     */   private IModelProviderDescriptor descriptor;
/*     */   
/*     */   public static IModelProviderDescriptor getModelProviderDescriptor(String id) {
/*  50 */     IModelProviderDescriptor[] descs = ModelProviderManager.getDefault().getDescriptors(); byte b; int i; IModelProviderDescriptor[] arrayOfIModelProviderDescriptor1;
/*  51 */     for (i = (arrayOfIModelProviderDescriptor1 = descs).length, b = 0; b < i; ) { IModelProviderDescriptor descriptor = arrayOfIModelProviderDescriptor1[b];
/*  52 */       if (descriptor.getId().equals(id))
/*  53 */         return descriptor; 
/*     */       b++; }
/*     */     
/*  56 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IModelProviderDescriptor[] getModelProviderDescriptors() {
/*  65 */     return ModelProviderManager.getDefault().getDescriptors();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  70 */     if (obj instanceof ModelProvider) {
/*  71 */       ModelProvider other = (ModelProvider)obj;
/*  72 */       return other.getDescriptor().getId().equals(getDescriptor().getId());
/*     */     } 
/*  74 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final IModelProviderDescriptor getDescriptor() {
/*  84 */     return this.descriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getId() {
/* 100 */     return this.descriptor.getId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceMapping[] getMappings(IResource resource, ResourceMappingContext context, IProgressMonitor monitor) throws CoreException {
/* 119 */     return new ResourceMapping[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceMapping[] getMappings(IResource[] resources, ResourceMappingContext context, IProgressMonitor monitor) throws CoreException {
/* 139 */     Set<ResourceMapping> mappings = new HashSet<>(); byte b; int i; IResource[] arrayOfIResource;
/* 140 */     for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/* 141 */       ResourceMapping[] resourceMappings = getMappings(resource, context, monitor);
/* 142 */       if (resourceMappings.length > 0)
/* 143 */         mappings.addAll(Arrays.asList(resourceMappings));  b++; }
/*     */     
/* 145 */     return mappings.<ResourceMapping>toArray(new ResourceMapping[mappings.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceMapping[] getMappings(ResourceTraversal[] traversals, ResourceMappingContext context, IProgressMonitor monitor) throws CoreException {
/* 165 */     Set<ResourceMapping> result = new HashSet<>(); byte b; int i; ResourceTraversal[] arrayOfResourceTraversal;
/* 166 */     for (i = (arrayOfResourceTraversal = traversals).length, b = 0; b < i; ) { ResourceTraversal traversal = arrayOfResourceTraversal[b];
/* 167 */       ResourceMapping[] mappings = getMappings(traversal.getResources(), context, monitor);
/* 168 */       result.addAll(Arrays.asList(mappings)); b++; }
/*     */     
/* 170 */     return result.<ResourceMapping>toArray(new ResourceMapping[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceTraversal[] getTraversals(ResourceMapping[] mappings, ResourceMappingContext context, IProgressMonitor monitor) throws CoreException {
/* 192 */     SubMonitor subMonitor = SubMonitor.convert(monitor, mappings.length);
/* 193 */     List<ResourceTraversal> traversals = new ArrayList<>(); byte b; int i; ResourceMapping[] arrayOfResourceMapping;
/* 194 */     for (i = (arrayOfResourceMapping = mappings).length, b = 0; b < i; ) { ResourceMapping mapping = arrayOfResourceMapping[b];
/* 195 */       Collections.addAll(traversals, mapping.getTraversals(context, (IProgressMonitor)subMonitor.newChild(1))); b++; }
/*     */     
/* 197 */     return traversals.<ResourceTraversal>toArray(new ResourceTraversal[traversals.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 202 */     return getDescriptor().getId().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void init(IModelProviderDescriptor desc) {
/* 216 */     if (this.descriptor != null) {
/*     */       return;
/*     */     }
/*     */     
/* 220 */     this.descriptor = desc;
/* 221 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initialize() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateChange(IResourceDelta delta, IProgressMonitor monitor) {
/* 255 */     return (IStatus)new ModelStatus(0, "org.eclipse.core.resources", this.descriptor.getId(), Status.OK_STATUS.getMessage());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\mapping\ModelProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */