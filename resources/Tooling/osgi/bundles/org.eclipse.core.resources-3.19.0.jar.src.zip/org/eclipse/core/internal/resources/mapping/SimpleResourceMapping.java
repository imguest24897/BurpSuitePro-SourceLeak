/*    */ package org.eclipse.core.internal.resources.mapping;
/*    */ 
/*    */ import org.eclipse.core.resources.IContainer;
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.IWorkspaceRoot;
/*    */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*    */ import org.eclipse.core.resources.mapping.ResourceMappingContext;
/*    */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleResourceMapping
/*    */   extends ResourceMapping
/*    */ {
/*    */   private final IResource resource;
/*    */   
/*    */   public SimpleResourceMapping(IResource resource) {
/* 30 */     this.resource = resource;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean contains(ResourceMapping mapping) {
/* 35 */     if (mapping.getModelProviderId().equals(getModelProviderId())) {
/* 36 */       Object object = mapping.getModelObject();
/* 37 */       if (object instanceof IResource) {
/* 38 */         IResource other = (IResource)object;
/* 39 */         return this.resource.getFullPath().isPrefixOf(other.getFullPath());
/*    */       } 
/* 41 */       if (object instanceof ShallowContainer) {
/* 42 */         ShallowContainer sc = (ShallowContainer)object;
/* 43 */         IContainer iContainer = sc.getResource();
/* 44 */         return this.resource.getFullPath().isPrefixOf(iContainer.getFullPath());
/*    */       } 
/*    */     } 
/* 47 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getModelObject() {
/* 52 */     return this.resource;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getModelProviderId() {
/* 57 */     return "org.eclipse.core.resources.modelProvider";
/*    */   }
/*    */ 
/*    */   
/*    */   public IProject[] getProjects() {
/* 62 */     if (this.resource.getType() == 8)
/* 63 */       return ((IWorkspaceRoot)this.resource).getProjects(); 
/* 64 */     return new IProject[] { this.resource.getProject() };
/*    */   }
/*    */ 
/*    */   
/*    */   public ResourceTraversal[] getTraversals(ResourceMappingContext context, IProgressMonitor monitor) {
/* 69 */     if (this.resource.getType() == 8) {
/* 70 */       return new ResourceTraversal[] { new ResourceTraversal((IResource[])((IWorkspaceRoot)this.resource).getProjects(), 2, 0) };
/*    */     }
/* 72 */     return new ResourceTraversal[] { new ResourceTraversal(new IResource[] { this.resource }, 2, 0) };
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\mapping\SimpleResourceMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */