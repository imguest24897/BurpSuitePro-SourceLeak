package org.eclipse.core.internal.watson;

import org.eclipse.core.runtime.IPath;

public interface IPathRequestor {
  IPath requestPath();
  
  String requestName();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\watson\IPathRequestor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */