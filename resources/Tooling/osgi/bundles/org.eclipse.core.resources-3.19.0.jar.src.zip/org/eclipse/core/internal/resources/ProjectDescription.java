/*     */ package org.eclipse.core.internal.resources;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.filesystem.URIUtil;
/*     */ import org.eclipse.core.internal.events.BuildCommand;
/*     */ import org.eclipse.core.internal.utils.FileUtil;
/*     */ import org.eclipse.core.resources.IBuildConfiguration;
/*     */ import org.eclipse.core.resources.ICommand;
/*     */ import org.eclipse.core.resources.IDynamicReferenceProvider;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IProjectDescription;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ 
/*     */ public class ProjectDescription extends ModelObject implements IProjectDescription {
/*  32 */   private static final IBuildConfiguration[] EMPTY_BUILD_CONFIG_REFERENCE_ARRAY = new IBuildConfiguration[0];
/*  33 */   private static final ICommand[] EMPTY_COMMAND_ARRAY = new ICommand[0];
/*  34 */   private static final IProject[] EMPTY_PROJECT_ARRAY = new IProject[0];
/*  35 */   private static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */ 
/*     */   
/*     */   private static final String EMPTY_STR = "";
/*     */   
/*     */   protected static boolean isReading = false;
/*     */   
/*     */   protected static boolean isWriting = false;
/*     */   
/*  44 */   protected ICommand[] buildSpec = EMPTY_COMMAND_ARRAY;
/*  45 */   protected String comment = "";
/*     */ 
/*     */ 
/*     */   
/*  49 */   protected String activeConfiguration = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   protected String[] configNames = EMPTY_STRING_ARRAY;
/*     */   
/*  58 */   protected IProject[] staticRefs = EMPTY_PROJECT_ARRAY;
/*  59 */   protected IProject[] dynamicRefs = EMPTY_PROJECT_ARRAY;
/*     */   
/*  61 */   protected HashMap<String, IBuildConfiguration[]> dynamicConfigRefs = (HashMap)new HashMap<>(1);
/*     */ 
/*     */   
/*     */   protected volatile IBuildConfiguration[] cachedBuildConfigs;
/*     */   
/*  66 */   protected Map<String, IBuildConfiguration[]> cachedConfigRefs = (Map)Collections.synchronizedMap(new HashMap<>(1));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IProject[] cachedRefs;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int cachedRefsDirtyCount;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   protected final Object cachedRefsMutex = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   protected HashMap<IPath, LinkDescription> linkDescriptions = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   protected HashMap<IPath, LinkedList<FilterDescription>> filterDescriptions = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   protected HashMap<String, VariableDescription> variableDescriptions = null;
/*     */ 
/*     */   
/* 102 */   protected URI location = null;
/* 103 */   protected String[] natures = EMPTY_STRING_ARRAY;
/* 104 */   protected URI snapshotLocation = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 113 */     ProjectDescription clone = (ProjectDescription)super.clone();
/*     */     
/* 115 */     clone.linkDescriptions = null;
/* 116 */     clone.filterDescriptions = null;
/* 117 */     if (this.variableDescriptions != null)
/* 118 */       clone.variableDescriptions = (HashMap<String, VariableDescription>)this.variableDescriptions.clone(); 
/* 119 */     clone.buildSpec = getBuildSpec(true);
/* 120 */     clone.dynamicConfigRefs = (HashMap<String, IBuildConfiguration[]>)this.dynamicConfigRefs.clone();
/* 121 */     clone.cachedConfigRefs = Collections.synchronizedMap(new HashMap<>(1));
/* 122 */     clone.clearCachedDynamicReferences(null);
/* 123 */     return clone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearCachedDynamicReferences(String configName) {
/* 131 */     synchronized (this.cachedRefsMutex) {
/* 132 */       if (configName == null) {
/* 133 */         this.cachedConfigRefs.clear();
/*     */       } else {
/* 135 */         this.cachedConfigRefs.remove(configName);
/* 136 */       }  this.cachedRefs = null;
/* 137 */       this.cachedRefsDirtyCount++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IBuildConfiguration[] copyAndRemoveDuplicates(IBuildConfiguration[] values) {
/* 145 */     Set<IBuildConfiguration> set = new LinkedHashSet<>(Arrays.asList(values));
/* 146 */     return set.<IBuildConfiguration>toArray(new IBuildConfiguration[set.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IProject[] copyAndRemoveDuplicates(IProject[] projects) {
/* 153 */     IProject[] result = new IProject[projects.length];
/* 154 */     int count = 0; byte b; int i; IProject[] arrayOfIProject1;
/* 155 */     for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/*     */       
/* 157 */       int j = 0; while (true) { if (j >= count)
/*     */         
/*     */         { 
/*     */           
/* 161 */           result[count++] = project; break; }  if (project.equals(result[j]))
/*     */           break;  j++; }  b++; }
/* 163 */      if (count < projects.length) {
/*     */       
/* 165 */       IProject[] reduced = new IProject[count];
/* 166 */       System.arraycopy(result, 0, reduced, 0, count);
/* 167 */       return reduced;
/*     */     } 
/* 169 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<BuildConfiguration> getBuildConfigReferencesFromProjects(IProject[] projects) {
/* 181 */     List<BuildConfiguration> refs = new ArrayList<>(projects.length); byte b; int i; IProject[] arrayOfIProject;
/* 182 */     for (i = (arrayOfIProject = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject[b];
/* 183 */       refs.add(new BuildConfiguration(project, null)); b++; }
/* 184 */      return refs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<IProject> getProjectsFromBuildConfigRefs(IBuildConfiguration[] refs) {
/* 193 */     LinkedHashSet<IProject> projects = new LinkedHashSet<>(refs.length); byte b; int i; IBuildConfiguration[] arrayOfIBuildConfiguration;
/* 194 */     for (i = (arrayOfIBuildConfiguration = refs).length, b = 0; b < i; ) { IBuildConfiguration ref = arrayOfIBuildConfiguration[b];
/* 195 */       projects.add(ref.getProject()); b++; }
/* 196 */      return projects;
/*     */   }
/*     */   
/*     */   public String getActiveBuildConfig() {
/* 200 */     return this.activeConfiguration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IProject[] getAllReferences(IProject project, boolean makeCopy) {
/*     */     int dirtyCount;
/*     */     IProject[] projRefs;
/* 213 */     synchronized (this.cachedRefsMutex) {
/* 214 */       projRefs = this.cachedRefs;
/* 215 */       dirtyCount = this.cachedRefsDirtyCount;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 220 */     while (projRefs == null) {
/*     */       IBuildConfiguration[] refs;
/* 222 */       if (hasBuildConfig(this.activeConfiguration)) {
/* 223 */         refs = getAllBuildConfigReferences(project, this.activeConfiguration, false);
/* 224 */       } else if (this.configNames.length > 0) {
/* 225 */         refs = getAllBuildConfigReferences(project, this.configNames[0], false);
/*     */       } else {
/*     */         
/* 228 */         refs = getAllBuildConfigReferences(project, "", false);
/* 229 */       }  Collection<IProject> l = getProjectsFromBuildConfigRefs(refs);
/*     */       
/* 231 */       synchronized (this.cachedRefsMutex) {
/*     */ 
/*     */         
/* 234 */         if (this.cachedRefsDirtyCount == dirtyCount) {
/* 235 */           this.cachedRefs = l.<IProject>toArray(new IProject[l.size()]);
/*     */         }
/* 237 */         projRefs = this.cachedRefs;
/* 238 */         dirtyCount = this.cachedRefsDirtyCount;
/*     */       } 
/*     */     } 
/*     */     
/* 242 */     return makeCopy ? (IProject[])projRefs.clone() : projRefs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBuildConfiguration[] getAllBuildConfigReferences(IProject project, String configName, boolean makeCopy) {
/* 257 */     if (!hasBuildConfig(configName))
/* 258 */       return EMPTY_BUILD_CONFIG_REFERENCE_ARRAY; 
/* 259 */     IBuildConfiguration[] refs = this.cachedConfigRefs.get(configName);
/* 260 */     if (refs == null) {
/* 261 */       Collection<BuildConfiguration> dynamic; Set<IBuildConfiguration> references = new LinkedHashSet<>();
/* 262 */       IBuildConfiguration[] dynamicBuildConfigs = this.dynamicConfigRefs.containsKey(configName) ? this.dynamicConfigRefs.get(configName) : EMPTY_BUILD_CONFIG_REFERENCE_ARRAY;
/*     */       
/*     */       try {
/* 265 */         IBuildConfiguration buildConfig = project.getBuildConfig(configName);
/* 266 */         dynamic = getBuildConfigReferencesFromProjects(computeDynamicReferencesForProject(buildConfig, getBuildSpec()));
/* 267 */       } catch (CoreException coreException) {
/* 268 */         dynamic = Collections.emptyList();
/*     */       } 
/* 270 */       Collection<BuildConfiguration> legacyDynamic = getBuildConfigReferencesFromProjects(this.dynamicRefs);
/* 271 */       Collection<BuildConfiguration> statik = getBuildConfigReferencesFromProjects(this.staticRefs);
/*     */ 
/*     */ 
/*     */       
/* 275 */       references.addAll(Arrays.asList(dynamicBuildConfigs));
/*     */       
/* 277 */       references.addAll((Collection)statik);
/* 278 */       references.addAll((Collection)legacyDynamic);
/* 279 */       references.addAll((Collection)dynamic);
/* 280 */       refs = references.<IBuildConfiguration>toArray(new IBuildConfiguration[references.size()]);
/* 281 */       this.cachedConfigRefs.put(configName, refs);
/*     */     } 
/* 283 */     return makeCopy ? (IBuildConfiguration[])refs.clone() : refs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBuildConfiguration[] getBuildConfigs(IProject project, boolean makeCopy) {
/* 291 */     IBuildConfiguration[] configs = this.cachedBuildConfigs;
/*     */     
/* 293 */     if (configs != null && !project.equals(configs[0].getProject()))
/* 294 */       configs = null; 
/* 295 */     if (configs == null) {
/* 296 */       if (this.configNames.length == 0) {
/* 297 */         configs = new IBuildConfiguration[] { new BuildConfiguration(project) };
/*     */       } else {
/* 299 */         configs = new IBuildConfiguration[this.configNames.length];
/* 300 */         for (int i = 0; i < configs.length; i++)
/* 301 */           configs[i] = new BuildConfiguration(project, this.configNames[i]); 
/*     */       } 
/* 303 */       this.cachedBuildConfigs = configs;
/*     */     } 
/* 305 */     return makeCopy ? (IBuildConfiguration[])configs.clone() : configs;
/*     */   }
/*     */ 
/*     */   
/*     */   public IBuildConfiguration[] getBuildConfigReferences(String configName) {
/* 310 */     return getBuildConfigRefs(configName, true);
/*     */   }
/*     */   
/*     */   public IBuildConfiguration[] getBuildConfigRefs(String configName, boolean makeCopy) {
/* 314 */     if (!hasBuildConfig(configName) || !this.dynamicConfigRefs.containsKey(configName)) {
/* 315 */       return EMPTY_BUILD_CONFIG_REFERENCE_ARRAY;
/*     */     }
/* 317 */     return makeCopy ? (IBuildConfiguration[])((IBuildConfiguration[])this.dynamicConfigRefs.get(configName)).clone() : this.dynamicConfigRefs.get(configName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, IBuildConfiguration[]> getBuildConfigReferences(boolean makeCopy) {
/* 326 */     return makeCopy ? (Map<String, IBuildConfiguration[]>)this.dynamicConfigRefs.clone() : (Map<String, IBuildConfiguration[]>)this.dynamicConfigRefs;
/*     */   }
/*     */ 
/*     */   
/*     */   public ICommand[] getBuildSpec() {
/* 331 */     return getBuildSpec(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public ICommand[] getBuildSpec(boolean makeCopy) {
/* 336 */     ICommand[] oldCommands = this.buildSpec;
/* 337 */     if (oldCommands == null)
/* 338 */       return EMPTY_COMMAND_ARRAY; 
/* 339 */     if (!makeCopy)
/* 340 */       return oldCommands; 
/* 341 */     ICommand[] result = new ICommand[oldCommands.length];
/* 342 */     for (int i = 0; i < result.length; i++)
/* 343 */       result[i] = (ICommand)((BuildCommand)oldCommands[i]).clone(); 
/* 344 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getComment() {
/* 349 */     return this.comment;
/*     */   }
/*     */ 
/*     */   
/*     */   public IProject[] getDynamicReferences() {
/* 354 */     return getDynamicReferences(true);
/*     */   }
/*     */   
/*     */   public IProject[] getDynamicReferences(boolean makeCopy) {
/* 358 */     return makeCopy ? (IProject[])this.dynamicRefs.clone() : this.dynamicRefs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URI getLinkLocationURI(IPath aPath) {
/* 366 */     if (this.linkDescriptions == null)
/* 367 */       return null; 
/* 368 */     LinkDescription desc = this.linkDescriptions.get(aPath);
/* 369 */     return (desc == null) ? null : desc.getLocationURI();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized LinkedList<FilterDescription> getFilter(IPath aPath) {
/* 377 */     if (this.filterDescriptions == null)
/* 378 */       return null; 
/* 379 */     return this.filterDescriptions.get(aPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashMap<IPath, LinkDescription> getLinks() {
/* 388 */     return this.linkDescriptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashMap<IPath, LinkedList<FilterDescription>> getFilters() {
/* 398 */     return this.filterDescriptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HashMap<String, VariableDescription> getVariables() {
/* 407 */     return this.variableDescriptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IPath getLocation() {
/* 417 */     if (this.location == null)
/* 418 */       return null; 
/* 419 */     return FileUtil.toPath(this.location);
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getLocationURI() {
/* 424 */     return this.location;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getNatureIds() {
/* 429 */     return getNatureIds(true);
/*     */   }
/*     */   
/*     */   public String[] getNatureIds(boolean makeCopy) {
/* 433 */     if (this.natures == null)
/* 434 */       return EMPTY_STRING_ARRAY; 
/* 435 */     return makeCopy ? (String[])this.natures.clone() : this.natures;
/*     */   }
/*     */ 
/*     */   
/*     */   public IProject[] getReferencedProjects() {
/* 440 */     return getReferencedProjects(true);
/*     */   }
/*     */   
/*     */   public IProject[] getReferencedProjects(boolean makeCopy) {
/* 444 */     if (this.staticRefs == null)
/* 445 */       return EMPTY_PROJECT_ARRAY; 
/* 446 */     return makeCopy ? (IProject[])this.staticRefs.clone() : this.staticRefs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URI getSnapshotLocationURI() {
/* 465 */     return this.snapshotLocation;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNature(String natureID) {
/* 470 */     String[] natureIDs = getNatureIds(false); byte b; int i; String[] arrayOfString1;
/* 471 */     for (i = (arrayOfString1 = natureIDs).length, b = 0; b < i; ) { String natureID2 = arrayOfString1[b];
/* 472 */       if (natureID2.equals(natureID))
/* 473 */         return true;  b++; }
/* 474 */      return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean configRefsHaveChanges(Map<String, IBuildConfiguration[]> m1, Map<String, IBuildConfiguration[]> m2) {
/* 482 */     if (m1.size() != m2.size())
/* 483 */       return true; 
/* 484 */     for (Map.Entry<String, IBuildConfiguration[]> e : m1.entrySet()) {
/* 485 */       if (!m2.containsKey(e.getKey()))
/* 486 */         return true; 
/* 487 */       if (!Arrays.equals((Object[])e.getValue(), (Object[])m2.get(e.getKey())))
/* 488 */         return true; 
/*     */     } 
/* 490 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasBuildConfig(String buildConfigName) {
/* 497 */     Assert.isNotNull(buildConfigName);
/* 498 */     if (this.configNames.length == 0)
/* 499 */       return "".equals(buildConfigName);  byte b; int i; String[] arrayOfString;
/* 500 */     for (i = (arrayOfString = this.configNames).length, b = 0; b < i; ) { String configName = arrayOfString[b];
/* 501 */       if (configName.equals(buildConfigName))
/* 502 */         return true;  b++; }
/* 503 */      return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasPrivateChanges(ProjectDescription description) {
/* 512 */     if (this.location == null) {
/* 513 */       if (description.location != null)
/* 514 */         return true; 
/* 515 */     } else if (!this.location.equals(description.location)) {
/* 516 */       return true;
/*     */     } 
/* 518 */     if (!Arrays.equals((Object[])this.dynamicRefs, (Object[])description.dynamicRefs)) {
/* 519 */       return true;
/*     */     }
/*     */     
/* 522 */     if (!this.activeConfiguration.equals(description.activeConfiguration))
/* 523 */       return true; 
/* 524 */     if (!Arrays.equals((Object[])this.configNames, (Object[])description.configNames)) {
/* 525 */       return true;
/*     */     }
/* 527 */     if (configRefsHaveChanges((Map<String, IBuildConfiguration[]>)this.dynamicConfigRefs, (Map<String, IBuildConfiguration[]>)description.dynamicConfigRefs)) {
/* 528 */       return true;
/*     */     }
/* 530 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasPublicChanges(ProjectDescription description) {
/* 539 */     if (!getName().equals(description.getName()))
/* 540 */       return true; 
/* 541 */     if (!this.comment.equals(description.getComment())) {
/* 542 */       return true;
/*     */     }
/* 544 */     if (!Arrays.equals((Object[])this.buildSpec, (Object[])description.getBuildSpec(false)))
/* 545 */       return true; 
/* 546 */     if (!Arrays.equals((Object[])this.staticRefs, (Object[])description.getReferencedProjects(false)))
/* 547 */       return true; 
/* 548 */     if (!Arrays.equals((Object[])this.natures, (Object[])description.getNatureIds(false))) {
/* 549 */       return true;
/*     */     }
/* 551 */     HashMap<IPath, LinkedList<FilterDescription>> otherFilters = description.getFilters();
/* 552 */     if (this.filterDescriptions == null && otherFilters != null)
/* 553 */       return (otherFilters != null); 
/* 554 */     if (this.filterDescriptions != null && !this.filterDescriptions.equals(otherFilters)) {
/* 555 */       return true;
/*     */     }
/* 557 */     HashMap<String, VariableDescription> otherVariables = description.getVariables();
/* 558 */     if (this.variableDescriptions == null && otherVariables != null)
/* 559 */       return true; 
/* 560 */     if (this.variableDescriptions != null && !this.variableDescriptions.equals(otherVariables)) {
/* 561 */       return true;
/*     */     }
/* 563 */     HashMap<IPath, LinkDescription> otherLinks = description.getLinks();
/* 564 */     if (this.linkDescriptions != otherLinks && (
/* 565 */       this.linkDescriptions == null || !this.linkDescriptions.equals(otherLinks))) {
/* 566 */       return true;
/*     */     }
/*     */     
/* 569 */     URI otherSnapshotLoc = description.getSnapshotLocationURI();
/* 570 */     if (this.snapshotLocation != otherSnapshotLoc && (
/* 571 */       this.snapshotLocation == null || !this.snapshotLocation.equals(otherSnapshotLoc))) {
/* 572 */       return true;
/*     */     }
/* 574 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public ICommand newCommand() {
/* 579 */     return (ICommand)new BuildCommand();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setActiveBuildConfig(String configName) {
/* 584 */     Assert.isNotNull(configName);
/* 585 */     if (!configName.equals(this.activeConfiguration))
/* 586 */       clearCachedDynamicReferences(null); 
/* 587 */     this.activeConfiguration = configName;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBuildSpec(ICommand[] value) {
/* 592 */     Assert.isLegal((value != null));
/*     */     
/* 594 */     ICommand[] result = new ICommand[value.length];
/* 595 */     for (int i = 0; i < result.length; i++) {
/* 596 */       result[i] = (ICommand)((BuildCommand)value[i]).clone(); byte b;
/*     */       int j;
/*     */       ICommand[] arrayOfICommand;
/* 599 */       for (j = (arrayOfICommand = this.buildSpec).length, b = 0; b < j; ) { ICommand element = arrayOfICommand[b];
/* 600 */         if (result[i].equals(element)) {
/* 601 */           ((BuildCommand)result[i]).setBuilders(((BuildCommand)element).getBuilders()); break;
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } 
/* 606 */     this.buildSpec = result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setComment(String value) {
/* 611 */     this.comment = value;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setDynamicReferences(IProject[] value) {
/* 617 */     Assert.isLegal((value != null));
/* 618 */     this.dynamicRefs = copyAndRemoveDuplicates(value);
/* 619 */     clearCachedDynamicReferences(null);
/*     */   }
/*     */   
/*     */   public void setBuildConfigReferences(HashMap<String, IBuildConfiguration[]> refs) {
/* 623 */     this.dynamicConfigRefs = (HashMap)new HashMap<>(refs);
/* 624 */     clearCachedDynamicReferences(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBuildConfigReferences(String configName, IBuildConfiguration[] references) {
/* 629 */     Assert.isLegal((configName != null));
/* 630 */     Assert.isLegal((references != null));
/* 631 */     if (!hasBuildConfig(configName))
/*     */       return; 
/* 633 */     this.dynamicConfigRefs.put(configName, copyAndRemoveDuplicates(references));
/* 634 */     clearCachedDynamicReferences(configName);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuildConfigs(String[] names) {
/* 640 */     LinkedHashSet<String> buildConfigNames = new LinkedHashSet<>();
/*     */     
/* 642 */     if (names == null || names.length == 0) {
/* 643 */       this.configNames = EMPTY_STRING_ARRAY;
/* 644 */       buildConfigNames.add("");
/*     */     } else {
/*     */       byte b; int i; String[] arrayOfString;
/* 647 */       for (i = (arrayOfString = names).length, b = 0; b < i; ) { String n = arrayOfString[b];
/* 648 */         Assert.isLegal((n != null));
/* 649 */         buildConfigNames.add(n);
/*     */         b++; }
/*     */       
/* 652 */       if (buildConfigNames.size() == 1 && ((String)buildConfigNames.iterator().next()).equals("")) {
/* 653 */         this.configNames = EMPTY_STRING_ARRAY;
/*     */       } else {
/* 655 */         this.configNames = (String[])buildConfigNames.toArray((Object[])new String[buildConfigNames.size()]);
/*     */       } 
/*     */     } 
/*     */     
/* 659 */     boolean modified = this.dynamicConfigRefs.keySet().retainAll(buildConfigNames);
/* 660 */     if (modified) {
/* 661 */       clearCachedDynamicReferences(null);
/*     */     }
/* 663 */     this.cachedBuildConfigs = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLinkDescriptions(HashMap<IPath, LinkDescription> linkDescriptions) {
/* 672 */     this.linkDescriptions = linkDescriptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilterDescriptions(HashMap<IPath, LinkedList<FilterDescription>> filterDescriptions) {
/* 681 */     this.filterDescriptions = filterDescriptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVariableDescriptions(HashMap<String, VariableDescription> variableDescriptions) {
/* 690 */     this.variableDescriptions = variableDescriptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setLinkLocation(IPath path, LinkDescription description) {
/* 702 */     HashMap<IPath, LinkDescription> tempMap = this.linkDescriptions;
/* 703 */     if (description != null) {
/*     */       
/* 705 */       if (tempMap == null) {
/* 706 */         tempMap = new HashMap<>(10);
/*     */       } else {
/*     */         
/* 709 */         tempMap = (HashMap<IPath, LinkDescription>)tempMap.clone();
/* 710 */       }  Object oldValue = tempMap.put(path, description);
/* 711 */       if (oldValue != null && description.equals(oldValue))
/*     */       {
/* 713 */         return false;
/*     */       }
/* 715 */       this.linkDescriptions = tempMap;
/*     */     } else {
/*     */       
/* 718 */       if (tempMap == null) {
/* 719 */         return false;
/*     */       }
/* 721 */       HashMap<IPath, LinkDescription> newMap = (HashMap<IPath, LinkDescription>)tempMap.clone();
/* 722 */       Object oldValue = newMap.remove(path);
/* 723 */       if (oldValue == null)
/*     */       {
/* 725 */         return false;
/*     */       }
/* 727 */       this.linkDescriptions = newMap.isEmpty() ? null : newMap;
/*     */     } 
/* 729 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addFilter(IPath path, FilterDescription description) {
/* 737 */     Assert.isNotNull(description);
/* 738 */     if (this.filterDescriptions == null)
/* 739 */       this.filterDescriptions = new HashMap<>(10); 
/* 740 */     LinkedList<FilterDescription> descList = this.filterDescriptions.get(path);
/* 741 */     if (descList == null) {
/* 742 */       descList = new LinkedList<>();
/* 743 */       this.filterDescriptions.put(path, descList);
/*     */     } 
/* 745 */     descList.add(description);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void removeFilter(IPath path, FilterDescription description) {
/* 753 */     if (this.filterDescriptions != null) {
/* 754 */       LinkedList<FilterDescription> descList = this.filterDescriptions.get(path);
/* 755 */       if (descList != null) {
/* 756 */         descList.remove(description);
/* 757 */         if (descList.isEmpty()) {
/* 758 */           this.filterDescriptions.remove(path);
/* 759 */           if (this.filterDescriptions.isEmpty()) {
/* 760 */             this.filterDescriptions = null;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setVariableDescription(String name, VariableDescription description) {
/* 775 */     HashMap<String, VariableDescription> tempMap = this.variableDescriptions;
/* 776 */     if (description != null) {
/*     */       
/* 778 */       if (tempMap == null) {
/* 779 */         tempMap = new HashMap<>(10);
/*     */       } else {
/*     */         
/* 782 */         tempMap = (HashMap<String, VariableDescription>)tempMap.clone();
/* 783 */       }  Object oldValue = tempMap.put(name, description);
/* 784 */       if (oldValue != null && description.equals(oldValue))
/*     */       {
/* 786 */         return false;
/*     */       }
/* 788 */       this.variableDescriptions = tempMap;
/*     */     } else {
/*     */       
/* 791 */       if (tempMap == null) {
/* 792 */         return false;
/*     */       }
/* 794 */       HashMap<String, VariableDescription> newMap = (HashMap<String, VariableDescription>)tempMap.clone();
/* 795 */       Object oldValue = newMap.remove(name);
/* 796 */       if (oldValue == null)
/*     */       {
/* 798 */         return false;
/*     */       }
/* 800 */       this.variableDescriptions = newMap.isEmpty() ? null : newMap;
/*     */     } 
/* 802 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean setFilters(IPath path, LinkedList<FilterDescription> descriptions) {
/* 812 */     if (descriptions != null) {
/*     */       
/* 814 */       if (this.filterDescriptions == null)
/* 815 */         this.filterDescriptions = new HashMap<>(10); 
/* 816 */       Object<FilterDescription> oldValue = (Object<FilterDescription>)this.filterDescriptions.put(path, descriptions);
/* 817 */       if (oldValue != null && descriptions.equals(oldValue))
/*     */       {
/* 819 */         return false;
/*     */       }
/*     */     } else {
/*     */       
/* 823 */       if (this.filterDescriptions == null) {
/* 824 */         return false;
/*     */       }
/* 826 */       Object<FilterDescription> oldValue = (Object<FilterDescription>)this.filterDescriptions.remove(path);
/* 827 */       if (oldValue == null)
/*     */       {
/* 829 */         return false;
/*     */       }
/* 831 */       if (this.filterDescriptions.isEmpty())
/* 832 */         this.filterDescriptions = null; 
/*     */     } 
/* 834 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLocation(IPath path) {
/* 839 */     this.location = (path == null) ? null : URIUtil.toURI(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLocationURI(URI location) {
/* 844 */     this.location = location;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setName(String value) {
/* 849 */     super.setName(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNatureIds(String[] value) {
/* 854 */     this.natures = (String[])value.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReferencedProjects(IProject[] value) {
/* 859 */     Assert.isLegal((value != null));
/* 860 */     this.staticRefs = copyAndRemoveDuplicates(value);
/* 861 */     clearCachedDynamicReferences(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSnapshotLocationURI(URI snapshotLocation) {
/* 880 */     this.snapshotLocation = snapshotLocation;
/*     */   }
/*     */   
/*     */   public URI getGroupLocationURI(IPath projectRelativePath) {
/* 884 */     return LinkDescription.VIRTUAL_LOCATION;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean updateDynamicState(ProjectDescription description) {
/* 901 */     boolean changed = false;
/* 902 */     if (!this.activeConfiguration.equals(description.activeConfiguration)) {
/* 903 */       changed = true;
/* 904 */       this.activeConfiguration = description.activeConfiguration;
/*     */     } 
/* 906 */     if (!Arrays.equals((Object[])this.dynamicRefs, (Object[])description.dynamicRefs)) {
/* 907 */       changed = true;
/* 908 */       setDynamicReferences(description.dynamicRefs);
/*     */     } 
/* 910 */     if (!Arrays.equals((Object[])this.configNames, (Object[])description.configNames)) {
/* 911 */       changed = true;
/* 912 */       setBuildConfigs(description.configNames);
/*     */     } 
/* 914 */     if (configRefsHaveChanges((Map<String, IBuildConfiguration[]>)this.dynamicConfigRefs, (Map<String, IBuildConfiguration[]>)description.dynamicConfigRefs)) {
/* 915 */       changed = true;
/* 916 */       this.dynamicConfigRefs = (HashMap)new HashMap<>(description.dynamicConfigRefs);
/*     */     } 
/* 918 */     if (changed)
/* 919 */       clearCachedDynamicReferences(null); 
/* 920 */     return changed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IProject[] computeDynamicReferencesForProject(IBuildConfiguration buildConfig, ICommand[] buildSpec) {
/* 927 */     List<IProject> result = new ArrayList<>(); byte b; int i; ICommand[] arrayOfICommand;
/* 928 */     for (i = (arrayOfICommand = buildSpec).length, b = 0; b < i; ) { ICommand command = arrayOfICommand[b];
/* 929 */       IExtension extension = Platform.getExtensionRegistry().getExtension("org.eclipse.core.resources", "builders", command.getBuilderName());
/*     */       
/* 931 */       if (extension != null) {
/*     */ 
/*     */ 
/*     */         
/* 935 */         IConfigurationElement[] configurationElements = extension.getConfigurationElements();
/*     */         
/* 937 */         if (configurationElements.length != 0) {
/*     */ 
/*     */ 
/*     */           
/* 941 */           IConfigurationElement element = configurationElements[0];
/*     */ 
/*     */ 
/*     */           
/* 945 */           try { IConfigurationElement[] children = element.getChildren("dynamicReference");
/* 946 */             if (children.length != 0) {
/* 947 */               Object executableExtension = children[0].createExecutableExtension("class");
/* 948 */               if (executableExtension instanceof IDynamicReferenceProvider) {
/* 949 */                 IDynamicReferenceProvider provider = (IDynamicReferenceProvider)executableExtension;
/*     */                 
/* 951 */                 result.addAll(provider.getDependentProjects(buildConfig));
/*     */               } 
/*     */             }  }
/* 954 */           catch (CoreException e)
/* 955 */           { String problemElement = element.toString();
/* 956 */             ResourcesPlugin.getPlugin().getLog().log((IStatus)new Status(4, "org.eclipse.core.resources", "Unable to load dynamic reference provider: " + problemElement, (Throwable)e)); } 
/*     */         } 
/*     */       }  b++; }
/* 959 */      return result.<IProject>toArray(new IProject[0]);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ProjectDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */