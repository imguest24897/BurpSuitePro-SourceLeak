/*    */ package org.eclipse.core.internal.watson;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultElementComparator
/*    */   implements IElementComparator
/*    */ {
/*    */   private static DefaultElementComparator singleton;
/*    */   
/*    */   public int compare(Object oldInfo, Object newInfo) {
/* 39 */     if (oldInfo == null && newInfo == null)
/* 40 */       return 0; 
/* 41 */     if (oldInfo == null || newInfo == null)
/* 42 */       return 1; 
/* 43 */     return testEquality(oldInfo, newInfo) ? 0 : 1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static IElementComparator getComparator() {
/* 50 */     if (singleton == null) {
/* 51 */       singleton = new DefaultElementComparator();
/*    */     }
/* 53 */     return singleton;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean testEquality(Object oldInfo, Object newInfo) {
/* 60 */     if (oldInfo == null && newInfo == null)
/* 61 */       return true; 
/* 62 */     if (oldInfo == null || newInfo == null) {
/* 63 */       return false;
/*    */     }
/* 65 */     return oldInfo.equals(newInfo);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\watson\DefaultElementComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */