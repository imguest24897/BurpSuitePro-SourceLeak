/*     */ package org.eclipse.core.internal.propertytester;
/*     */ 
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilePropertyTester
/*     */   extends ResourcePropertyTester
/*     */ {
/*     */   private static final String CONTENT_TYPE_ID = "contentTypeId";
/*     */   private static final String IS_KIND_OF = "kindOf";
/*     */   private static final String USE_FILENAME_ONLY = "useFilenameOnly";
/*     */   
/*     */   public boolean test(Object receiver, String method, Object[] args, Object expectedValue) {
/*  55 */     if (receiver instanceof IFile && method.equals("contentTypeId"))
/*  56 */       return testContentType((IFile)receiver, toString(expectedValue), isArgumentUsed(args, "kindOf"), isArgumentUsed(args, "useFilenameOnly")); 
/*  57 */     return false; } private boolean isArgumentUsed(Object[] args, String value) {
/*     */     byte b;
/*     */     int i;
/*     */     Object[] arrayOfObject;
/*  61 */     for (i = (arrayOfObject = args).length, b = 0; b < i; ) { Object arg = arrayOfObject[b];
/*  62 */       if (value.equals(arg))
/*  63 */         return true;  b++; }
/*  64 */      return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean testContentType(IFile file, String contentTypeId, boolean isKindOfUsed, boolean useFilenameOnly) {
/*  97 */     String expectedValue = contentTypeId.trim();
/*  98 */     IContentType actualContentType = null;
/*  99 */     if (!useFilenameOnly) {
/* 100 */       if (!file.exists())
/* 101 */         return false; 
/* 102 */       IContentDescription contentDescription = null;
/*     */       try {
/* 104 */         contentDescription = file.getContentDescription();
/* 105 */       } catch (CoreException e) {
/* 106 */         Policy.log(4, "Core exception while retrieving the content description", (Throwable)e);
/*     */       } 
/* 108 */       if (contentDescription != null)
/* 109 */         actualContentType = contentDescription.getContentType(); 
/*     */     } else {
/* 111 */       actualContentType = Platform.getContentTypeManager().findContentTypeFor(file.getName());
/*     */     } 
/* 113 */     if (actualContentType != null) {
/* 114 */       if (isKindOfUsed)
/* 115 */         return actualContentType.isKindOf(Platform.getContentTypeManager().getContentType(expectedValue)); 
/* 116 */       return expectedValue.equals(actualContentType.getId());
/*     */     } 
/* 118 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\propertytester\FilePropertyTester.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */