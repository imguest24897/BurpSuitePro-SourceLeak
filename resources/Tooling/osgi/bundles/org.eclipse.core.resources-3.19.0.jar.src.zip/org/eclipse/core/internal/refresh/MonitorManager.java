/*     */ package org.eclipse.core.internal.refresh;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.internal.events.ILifecycleListener;
/*     */ import org.eclipse.core.internal.events.LifecycleEvent;
/*     */ import org.eclipse.core.internal.resources.Workspace;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IPathVariableChangeEvent;
/*     */ import org.eclipse.core.resources.IPathVariableChangeListener;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceChangeEvent;
/*     */ import org.eclipse.core.resources.IResourceChangeListener;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.resources.IResourceDeltaVisitor;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.refresh.IRefreshMonitor;
/*     */ import org.eclipse.core.resources.refresh.RefreshProvider;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MonitorManager
/*     */   implements ILifecycleListener, IPathVariableChangeListener, IResourceChangeListener, IResourceDeltaVisitor
/*     */ {
/*     */   protected final PollingMonitor pollMonitor;
/*     */   private RefreshProvider[] providers;
/*     */   protected final RefreshManager refreshManager;
/*     */   protected final Map<IRefreshMonitor, List<IResource>> registeredMonitors;
/*     */   protected IWorkspace workspace;
/*     */   
/*     */   public MonitorManager(IWorkspace workspace, RefreshManager refreshManager) {
/*  60 */     this.workspace = workspace;
/*  61 */     this.refreshManager = refreshManager;
/*  62 */     this.registeredMonitors = Collections.synchronizedMap(new HashMap<>(10));
/*  63 */     this.pollMonitor = new PollingMonitor(refreshManager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RefreshProvider[] getRefreshProviders() {
/*  74 */     synchronized (this) {
/*  75 */       if (this.providers != null)
/*  76 */         return this.providers; 
/*     */     } 
/*  78 */     IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.core.resources", "refreshProviders");
/*  79 */     IConfigurationElement[] infos = extensionPoint.getConfigurationElements();
/*  80 */     List<RefreshProvider> providerList = new ArrayList<>(infos.length); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/*  81 */     for (i = (arrayOfIConfigurationElement1 = infos).length, b = 0; b < i; ) { IConfigurationElement configurationElement = arrayOfIConfigurationElement1[b];
/*  82 */       RefreshProvider provider = null;
/*     */       try {
/*  84 */         provider = (RefreshProvider)configurationElement.createExecutableExtension("class");
/*  85 */       } catch (CoreException e) {
/*  86 */         Policy.log(2, Messages.refresh_installError, (Throwable)e);
/*     */       } 
/*  88 */       if (provider != null)
/*  89 */         providerList.add(provider);  b++; }
/*     */     
/*  91 */     synchronized (this) {
/*  92 */       this.providers = providerList.<RefreshProvider>toArray(new RefreshProvider[providerList.size()]);
/*  93 */       return this.providers;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<IResource> getResourcesToMonitor() {
/* 102 */     List<IResource> resourcesToMonitor = new ArrayList<>(10);
/* 103 */     IProject[] projects = this.workspace.getRoot().getProjects(8); byte b; int i; IProject[] arrayOfIProject1;
/* 104 */     for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/* 105 */       if (project.isAccessible()) {
/*     */ 
/*     */         
/* 108 */         resourcesToMonitor.add(project);
/*     */         try {
/* 110 */           IResource[] members = project.members(); byte b1; int j; IResource[] arrayOfIResource1;
/* 111 */           for (j = (arrayOfIResource1 = members).length, b1 = 0; b1 < j; ) { IResource member = arrayOfIResource1[b1];
/* 112 */             if (member.isLinked())
/* 113 */               resourcesToMonitor.add(member);  b1++; }
/*     */         
/* 115 */         } catch (CoreException e) {
/* 116 */           Policy.log(2, Messages.refresh_refreshErr, (Throwable)e);
/*     */         } 
/*     */       }  b++; }
/* 119 */      return resourcesToMonitor;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleEvent(LifecycleEvent event) {
/* 124 */     switch (event.kind) {
/*     */       case 1:
/*     */       case 16:
/*     */       case 1024:
/* 128 */         unmonitor(event.resource, (IProgressMonitor)new NullProgressMonitor());
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isMonitoring(IResource resource) {
/* 134 */     synchronized (this.registeredMonitors) {
/* 135 */       for (List<IResource> resources : this.registeredMonitors.values()) {
/* 136 */         if (resources != null && resources.contains(resource))
/* 137 */           return true; 
/*     */       } 
/*     */     } 
/* 140 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean monitor(IResource resource, IProgressMonitor progressMonitor) {
/* 148 */     if (isMonitoring(resource))
/* 149 */       return false; 
/* 150 */     boolean pollingMonitorNeeded = true;
/* 151 */     RefreshProvider[] refreshProviders = getRefreshProviders();
/* 152 */     SubMonitor subMonitor = SubMonitor.convert(progressMonitor, refreshProviders.length); byte b; int i; RefreshProvider[] arrayOfRefreshProvider1;
/* 153 */     for (i = (arrayOfRefreshProvider1 = refreshProviders).length, b = 0; b < i; ) { RefreshProvider refreshProvider = arrayOfRefreshProvider1[b];
/* 154 */       IRefreshMonitor monitor = safeInstallMonitor(refreshProvider, resource, (IProgressMonitor)subMonitor.split(1));
/* 155 */       if (monitor != null) {
/* 156 */         registerMonitor(monitor, resource);
/* 157 */         pollingMonitorNeeded = false;
/*     */       }  b++; }
/*     */     
/* 160 */     if (pollingMonitorNeeded) {
/* 161 */       this.pollMonitor.monitor(resource);
/* 162 */       registerMonitor(this.pollMonitor, resource);
/*     */     } 
/* 164 */     return pollingMonitorNeeded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void monitorFailed(IRefreshMonitor monitor, IResource resource) {
/* 171 */     if (Policy.DEBUG_AUTO_REFRESH)
/* 172 */       Policy.debug("Auto-refresh:  monitor (" + monitor + ") failed to monitor resource: " + resource); 
/* 173 */     if (this.registeredMonitors == null || monitor == null)
/*     */       return; 
/* 175 */     if (resource == null) {
/* 176 */       List<IResource> resources = this.registeredMonitors.get(monitor);
/* 177 */       if (resources == null || resources.isEmpty()) {
/* 178 */         this.registeredMonitors.remove(monitor);
/*     */         
/*     */         return;
/*     */       } 
/* 182 */       synchronized (this.registeredMonitors) {
/* 183 */         for (IResource resource1 : resources) {
/* 184 */           this.pollMonitor.monitor(resource1);
/* 185 */           registerMonitor(this.pollMonitor, resource1);
/*     */         } 
/* 187 */         this.registeredMonitors.remove(monitor);
/*     */       } 
/*     */     } else {
/* 190 */       removeMonitor(monitor, resource);
/* 191 */       this.pollMonitor.monitor(resource);
/* 192 */       registerMonitor(this.pollMonitor, resource);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pathVariableChanged(IPathVariableChangeEvent event) {
/* 201 */     if (this.registeredMonitors.isEmpty())
/*     */       return; 
/* 203 */     String variableName = event.getVariableName();
/* 204 */     Set<IResource> invalidResources = new HashSet<>();
/* 205 */     for (List<IResource> resources : this.registeredMonitors.values()) {
/* 206 */       for (IResource resource : resources) {
/* 207 */         IPath rawLocation = resource.getRawLocation();
/* 208 */         if (rawLocation != null && 
/* 209 */           rawLocation.segmentCount() > 0 && variableName.equals(rawLocation.segment(0)) && !invalidResources.contains(resource)) {
/* 210 */           invalidResources.add(resource);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 215 */     if (!invalidResources.isEmpty()) {
/* 216 */       MonitorJob.createSystem(Messages.refresh_restoreOnInvalid, invalidResources, monitor -> {
/*     */             SubMonitor subMonitor = SubMonitor.convert(monitor, paramSet.size() * 2);
/*     */             
/*     */             for (IResource resource : paramSet) {
/*     */               unmonitor(resource, (IProgressMonitor)subMonitor.split(1));
/*     */               
/*     */               monitor(resource, (IProgressMonitor)subMonitor.split(1));
/*     */               this.refreshManager.refresh(resource);
/*     */             } 
/* 225 */           }).schedule();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerMonitor(IRefreshMonitor monitor, IResource resource) {
/* 231 */     synchronized (this.registeredMonitors) {
/* 232 */       List<IResource> resources = this.registeredMonitors.get(monitor);
/* 233 */       if (resources == null) {
/* 234 */         resources = new ArrayList<>(1);
/* 235 */         this.registeredMonitors.put(monitor, resources);
/*     */       } 
/* 237 */       if (!resources.contains(resource))
/* 238 */         resources.add(resource); 
/*     */     } 
/* 240 */     if (Policy.DEBUG_AUTO_REFRESH) {
/* 241 */       Policy.debug("Auto-refresh:  added monitor (" + monitor + ") on resource: " + resource);
/*     */     }
/*     */   }
/*     */   
/*     */   private void removeMonitor(IRefreshMonitor monitor, IResource resource) {
/* 246 */     synchronized (this.registeredMonitors) {
/* 247 */       List<IResource> resources = this.registeredMonitors.get(monitor);
/* 248 */       if (resources != null && !resources.isEmpty()) {
/* 249 */         resources.remove(resource);
/*     */       } else {
/* 251 */         this.registeredMonitors.remove(monitor);
/*     */       } 
/*     */     } 
/* 254 */     if (Policy.DEBUG_AUTO_REFRESH)
/* 255 */       Policy.debug("Auto-refresh:  removing monitor (" + monitor + ") on resource: " + resource); 
/*     */   }
/*     */   
/*     */   private IRefreshMonitor safeInstallMonitor(RefreshProvider provider, IResource resource, IProgressMonitor progressMonitor) {
/* 259 */     Throwable t = null;
/*     */     try {
/* 261 */       return provider.installMonitor(resource, this.refreshManager, progressMonitor);
/* 262 */     } catch (Exception|LinkageError e) {
/* 263 */       t = e;
/*     */       
/* 265 */       Status status = new Status(4, "org.eclipse.core.resources", 1, Messages.refresh_installError, t);
/* 266 */       Policy.log((IStatus)status);
/* 267 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(IProgressMonitor progressMonitor) {
/*     */     int i;
/* 275 */     List<IResource> resourcesToMonitor = getResourcesToMonitor();
/* 276 */     SubMonitor subMonitor = SubMonitor.convert(progressMonitor, resourcesToMonitor.size() + 1);
/* 277 */     boolean refreshNeeded = false;
/* 278 */     for (IResource resource : resourcesToMonitor) {
/* 279 */       i = refreshNeeded | (monitor(resource, (IProgressMonitor)subMonitor.split(1)) ? 0 : 1);
/*     */     }
/* 281 */     this.workspace.getPathVariableManager().addChangeListener(this);
/* 282 */     this.workspace.addResourceChangeListener(this, 1);
/*     */     
/* 284 */     ((Workspace)this.workspace).addLifecycleListener(this);
/* 285 */     if (Policy.DEBUG_AUTO_REFRESH) {
/* 286 */       Policy.debug("Auto-refresh:  starting monitor manager.");
/*     */     }
/*     */     
/* 289 */     subMonitor.split(1);
/* 290 */     if (i != 0) {
/* 291 */       (new PollingMonitor(this.refreshManager)).runOnce();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 299 */     this.workspace.removeResourceChangeListener(this);
/* 300 */     this.workspace.getPathVariableManager().removeChangeListener(this);
/*     */     
/* 302 */     synchronized (this.registeredMonitors) {
/* 303 */       for (IRefreshMonitor monitor : this.registeredMonitors.keySet()) {
/* 304 */         monitor.unmonitor(null);
/*     */       }
/*     */     } 
/* 307 */     this.registeredMonitors.clear();
/* 308 */     if (Policy.DEBUG_AUTO_REFRESH)
/* 309 */       Policy.debug("Auto-refresh:  stopping monitor manager."); 
/* 310 */     this.pollMonitor.cancel();
/*     */   }
/*     */   
/*     */   void unmonitor(IResource resource, IProgressMonitor progressMonitor) {
/* 314 */     if (resource == null || !isMonitoring(resource))
/*     */       return; 
/* 316 */     SubMonitor subMonitor = SubMonitor.convert(progressMonitor, 100);
/* 317 */     synchronized (this.registeredMonitors) {
/* 318 */       SubMonitor loopMonitor = subMonitor.split(90).setWorkRemaining(this.registeredMonitors.entrySet().size());
/* 319 */       for (Map.Entry<IRefreshMonitor, List<IResource>> entry : this.registeredMonitors.entrySet()) {
/* 320 */         loopMonitor.worked(1);
/* 321 */         List<IResource> resources = entry.getValue();
/* 322 */         if (resources != null && resources.contains(resource)) {
/* 323 */           ((IRefreshMonitor)entry.getKey()).unmonitor(resource);
/* 324 */           resources.remove(resource);
/*     */         } 
/*     */       } 
/*     */     } 
/* 328 */     if (resource.getType() == 4)
/* 329 */       unmonitorLinkedContents((IProject)resource, (IProgressMonitor)subMonitor.split(10)); 
/*     */   }
/*     */   
/*     */   private void unmonitorLinkedContents(IProject project, IProgressMonitor progressMonitor) {
/* 333 */     if (!project.isAccessible())
/*     */       return; 
/* 335 */     IResource[] children = null;
/*     */     try {
/* 337 */       children = project.members();
/* 338 */     } catch (CoreException e) {
/* 339 */       Policy.log(2, Messages.refresh_refreshErr, (Throwable)e);
/*     */     } 
/* 341 */     if (children != null && children.length > 0) {
/* 342 */       SubMonitor subMonitor = SubMonitor.convert(progressMonitor, children.length); byte b; int i; IResource[] arrayOfIResource;
/* 343 */       for (i = (arrayOfIResource = children).length, b = 0; b < i; ) { IResource child = arrayOfIResource[b];
/* 344 */         if (child.isLinked()) {
/* 345 */           unmonitor(child, (IProgressMonitor)subMonitor.split(1));
/*     */         }
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   public void resourceChanged(IResourceChangeEvent event) {
/* 353 */     IResourceDelta delta = event.getDelta();
/* 354 */     if (delta == null)
/*     */       return; 
/*     */     try {
/* 357 */       delta.accept(this);
/* 358 */     } catch (CoreException coreException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean visit(IResourceDelta delta) {
/* 365 */     if (delta.getKind() == 1) {
/* 366 */       IResource resource = delta.getResource();
/* 367 */       if (resource.isLinked())
/* 368 */         monitor(resource, (IProgressMonitor)new NullProgressMonitor()); 
/*     */     } 
/* 370 */     if ((delta.getFlags() & 0x4000) != 0) {
/* 371 */       IProject project = (IProject)delta.getResource();
/* 372 */       if (project.isAccessible())
/* 373 */         monitor((IResource)project, (IProgressMonitor)new NullProgressMonitor()); 
/*     */     } 
/* 375 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\refresh\MonitorManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */