/*     */ package org.eclipse.core.resources.team;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceRuleFactory;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.ResourceAttributes;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.MultiRule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceRuleFactory
/*     */   implements IResourceRuleFactory
/*     */ {
/*     */   private final IWorkspace workspace;
/*     */   
/*     */   @Deprecated
/*     */   protected ResourceRuleFactory() {
/*  44 */     this(ResourcesPlugin.getWorkspace());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceRuleFactory(IWorkspace workspace) {
/*  54 */     this.workspace = workspace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ISchedulingRule buildRule() {
/*  67 */     return (ISchedulingRule)this.workspace.getRoot();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule charsetRule(IResource resource) {
/*  86 */     if (resource.getType() == 8)
/*  87 */       return null; 
/*  88 */     return (ISchedulingRule)resource.getProject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ISchedulingRule derivedRule(IResource resource) {
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule copyRule(IResource source, IResource destination) {
/* 120 */     return parent(destination);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule createRule(IResource resource) {
/* 136 */     return parent(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule deleteRule(IResource resource) {
/* 152 */     return parent(resource);
/*     */   }
/*     */   
/*     */   private boolean isReadOnly(IResource resource) {
/* 156 */     ResourceAttributes attributes = resource.getResourceAttributes();
/* 157 */     return (attributes == null) ? false : attributes.isReadOnly();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ISchedulingRule markerRule(IResource resource) {
/* 170 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule modifyRule(IResource resource) {
/* 189 */     IPath path = resource.getFullPath();
/*     */     
/* 191 */     if (path.segmentCount() == 2 && path.segment(1).equals(".project"))
/* 192 */       return parent(resource); 
/* 193 */     return (ISchedulingRule)resource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule moveRule(IResource source, IResource destination) {
/* 210 */     return MultiRule.combine(parent(source), parent(destination));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ISchedulingRule parent(IResource resource) {
/* 221 */     switch (resource.getType()) {
/*     */       case 4:
/*     */       case 8:
/* 224 */         return (ISchedulingRule)resource;
/*     */     } 
/* 226 */     return (ISchedulingRule)resource.getParent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule refreshRule(IResource resource) {
/* 243 */     return parent(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule validateEditRule(IResource[] resources) {
/* 260 */     if (resources.length == 0) {
/* 261 */       return null;
/*     */     }
/* 263 */     if (resources.length == 1) {
/* 264 */       return isReadOnly(resources[0]) ? parent(resources[0]) : null;
/*     */     }
/* 266 */     HashSet<ISchedulingRule> rules = new HashSet<>(); byte b; int i; IResource[] arrayOfIResource;
/* 267 */     for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/* 268 */       if (isReadOnly(resource))
/* 269 */         rules.add(parent(resource));  b++; }
/* 270 */      if (rules.isEmpty())
/* 271 */       return null; 
/* 272 */     if (rules.size() == 1)
/* 273 */       return rules.iterator().next(); 
/* 274 */     ISchedulingRule[] ruleArray = rules.<ISchedulingRule>toArray(new ISchedulingRule[rules.size()]);
/* 275 */     return (ISchedulingRule)new MultiRule(ruleArray);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\team\ResourceRuleFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */