/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.IOException;
/*    */ import org.eclipse.core.internal.utils.ObjectMap;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ import org.eclipse.core.runtime.QualifiedName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SyncInfoSnapReader_3
/*    */   extends SyncInfoSnapReader
/*    */ {
/*    */   public SyncInfoSnapReader_3(Workspace workspace, Synchronizer synchronizer) {
/* 26 */     super(workspace, synchronizer);
/*    */   }
/*    */   
/*    */   private ObjectMap<QualifiedName, Object> internalReadSyncInfo(DataInputStream input) throws IOException {
/* 30 */     int size = input.readInt();
/* 31 */     ObjectMap<QualifiedName, Object> map = new ObjectMap(size);
/* 32 */     for (int i = 0; i < size; i++) {
/*    */       
/* 34 */       String qualifier = input.readUTF();
/* 35 */       String local = input.readUTF();
/* 36 */       QualifiedName name = new QualifiedName(qualifier, local);
/*    */       
/* 38 */       int length = input.readInt();
/* 39 */       byte[] bytes = new byte[length];
/* 40 */       input.readFully(bytes);
/*    */       
/* 42 */       map.put(name, bytes);
/*    */     } 
/* 44 */     return map;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void readSyncInfo(DataInputStream input) throws IOException {
/* 61 */     Path path = new Path(input.readUTF());
/* 62 */     ObjectMap<QualifiedName, Object> map = internalReadSyncInfo(input);
/*    */     
/* 64 */     ResourceInfo info = this.workspace.getResourceInfo((IPath)path, true, false);
/* 65 */     if (info == null)
/*    */       return; 
/* 67 */     info.setSyncInfo(map);
/* 68 */     info.clear(8192);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\SyncInfoSnapReader_3.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */