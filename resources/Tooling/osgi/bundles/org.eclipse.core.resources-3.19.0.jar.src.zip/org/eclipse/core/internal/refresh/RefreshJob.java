/*     */ package org.eclipse.core.internal.refresh;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.internal.localstore.PrefixPool;
/*     */ import org.eclipse.core.internal.resources.InternalWorkspaceJob;
/*     */ import org.eclipse.core.internal.resources.Workspace;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceRuleFactory;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RefreshJob
/*     */   extends InternalWorkspaceJob
/*     */ {
/*     */   public static final int MAX_RECURSION = 1073741824;
/*     */   public static final int FAST_REFRESH_THRESHOLD = 1000;
/*     */   public static final int SLOW_REFRESH_THRESHOLD = 2000;
/*     */   public static final int BASE_REFRESH_DEPTH = 1000;
/*     */   public static final int DEPTH_INCREASE_STEP = 1000;
/*     */   public static final int UPDATE_DELAY = 200;
/*     */   private final List<IResource> fRequests;
/*     */   private PrefixPool pathPrefixHistory;
/*     */   private PrefixPool rootPathHistory;
/*     */   private final int fastRefreshThreshold;
/*     */   private final int slowRefreshThreshold;
/*     */   private final int baseRefreshDepth;
/*     */   private final int depthIncreaseStep;
/*     */   private final int updateDelay;
/*     */   private final int maxRecursionDeep;
/*     */   private final Workspace workspace;
/*     */   private volatile boolean disabled;
/*     */   
/*     */   public RefreshJob(Workspace workspace) {
/*  90 */     this(1000, 2000, 1000, 1000, 200, 1073741824, workspace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RefreshJob(int fastRefreshThreshold, int slowRefreshThreshold, int baseRefreshDepth, int depthIncreaseStep, int updateDelay, int maxRecursionDeep, Workspace workspace) {
/*  98 */     super(Messages.refresh_jobName, workspace);
/*  99 */     this.fRequests = new ArrayList<>(1);
/* 100 */     this.fastRefreshThreshold = fastRefreshThreshold;
/* 101 */     this.slowRefreshThreshold = slowRefreshThreshold;
/* 102 */     this.baseRefreshDepth = baseRefreshDepth;
/* 103 */     this.depthIncreaseStep = depthIncreaseStep;
/* 104 */     this.updateDelay = updateDelay;
/* 105 */     this.maxRecursionDeep = maxRecursionDeep;
/* 106 */     this.workspace = workspace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void addRequest(IResource resource) {
/* 115 */     IPath toAdd = resource.getFullPath();
/* 116 */     for (Iterator<IResource> it = this.fRequests.iterator(); it.hasNext(); ) {
/* 117 */       IPath request = ((IResource)it.next()).getFullPath();
/*     */       
/* 119 */       if (toAdd.isPrefixOf(request)) {
/* 120 */         it.remove(); continue;
/*     */       } 
/* 122 */       if (request.isPrefixOf(toAdd)) {
/*     */         return;
/*     */       }
/*     */     } 
/* 126 */     this.fRequests.add(resource);
/*     */   }
/*     */ 
/*     */   
/*     */   private synchronized void addRequests(List<IResource> list) {
/* 131 */     if (!list.isEmpty()) {
/* 132 */       this.fRequests.addAll(0, list);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean belongsTo(Object family) {
/* 138 */     return (family == ResourcesPlugin.FAMILY_AUTO_REFRESH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<IResource> collectChildrenToDepth(IResource resource, ArrayList<IResource> children, int depth) {
/*     */     IResource[] members;
/* 146 */     if (resource.getType() == 1) {
/* 147 */       return children;
/*     */     }
/*     */     try {
/* 150 */       members = ((IContainer)resource).members();
/* 151 */     } catch (CoreException coreException) {
/*     */       
/* 153 */       return children;
/*     */     }  byte b; int i; IResource[] arrayOfIResource1;
/* 155 */     for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource member = arrayOfIResource1[b];
/* 156 */       if (member.getType() != 1)
/*     */       {
/* 158 */         if (depth <= 1) {
/* 159 */           children.add(member);
/*     */         } else {
/* 161 */           collectChildrenToDepth(member, children, depth - 1);
/*     */         }  }  b++; }
/* 163 */      return children;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrefixPool getPathPrefixHistory() {
/* 170 */     if (this.pathPrefixHistory == null)
/* 171 */       this.pathPrefixHistory = new PrefixPool(20); 
/* 172 */     return this.pathPrefixHistory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrefixPool getRootPathHistory() {
/* 179 */     if (this.rootPathHistory == null)
/* 180 */       this.rootPathHistory = new PrefixPool(20); 
/* 181 */     return this.rootPathHistory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized IResource nextRequest() {
/* 189 */     int len = this.fRequests.size();
/* 190 */     if (len == 0)
/* 191 */       return null; 
/* 192 */     return this.fRequests.remove(len - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh(IResource resource) {
/* 199 */     if (resource == null || this.disabled) {
/*     */       return;
/*     */     }
/* 202 */     addRequest(resource);
/* 203 */     schedule(this.updateDelay);
/*     */   }
/*     */ 
/*     */   
/*     */   public IStatus runInWorkspace(IProgressMonitor monitor) {
/* 208 */     long start = System.currentTimeMillis();
/* 209 */     String msg = Messages.refresh_refreshErr;
/* 210 */     MultiStatus errors = new MultiStatus("org.eclipse.core.resources", 1, msg, null);
/* 211 */     long longestRefresh = 0L;
/* 212 */     SubMonitor subMonitor = SubMonitor.convert(monitor);
/*     */     try {
/* 214 */       if (Policy.DEBUG_AUTO_REFRESH)
/* 215 */         Policy.debug("Auto-refresh:  starting refresh job"); 
/* 216 */       int refreshCount = 0;
/* 217 */       int depth = 2;
/*     */       
/* 219 */       IResourceRuleFactory ruleFactory = this.workspace.getRuleFactory();
/*     */       IResource toRefresh;
/* 221 */       while ((toRefresh = nextRequest()) != null) {
/* 222 */         ISchedulingRule refreshRule = ruleFactory.refreshRule(toRefresh);
/*     */         try {
/* 224 */           subMonitor.setWorkRemaining(Math.max(this.fRequests.size(), 100));
/* 225 */           Job.getJobManager().beginRule(refreshRule, (IProgressMonitor)subMonitor);
/* 226 */           refreshCount++;
/* 227 */           long refreshTime = -System.currentTimeMillis();
/* 228 */           toRefresh.refreshLocal(this.baseRefreshDepth + depth, (IProgressMonitor)subMonitor.split(1));
/* 229 */           refreshTime += System.currentTimeMillis();
/* 230 */           if (refreshTime > longestRefresh) {
/* 231 */             longestRefresh = refreshTime;
/*     */           }
/* 233 */           if (refreshCount % this.depthIncreaseStep == 0) {
/*     */             
/* 235 */             Thread.yield();
/*     */             
/* 237 */             if (longestRefresh > this.slowRefreshThreshold && depth > 1) {
/* 238 */               depth = 1;
/* 239 */               if (Policy.DEBUG_AUTO_REFRESH) {
/* 240 */                 Policy.debug("Auto-refresh:  decreased refresh depth to: " + depth);
/*     */               }
/*     */             } 
/* 243 */             if (longestRefresh < this.fastRefreshThreshold) {
/* 244 */               depth *= 2;
/* 245 */               if (depth <= 0 || depth > this.maxRecursionDeep)
/*     */               {
/* 247 */                 depth = this.maxRecursionDeep;
/*     */               }
/* 249 */               if (Policy.DEBUG_AUTO_REFRESH) {
/* 250 */                 Policy.debug("Auto-refresh:  increased refresh depth to: " + depth);
/*     */               }
/*     */             } 
/* 253 */             longestRefresh = 0L;
/*     */           } 
/* 255 */           addRequests(collectChildrenToDepth(toRefresh, new ArrayList<>(), depth));
/* 256 */         } catch (CoreException e) {
/* 257 */           errors.merge((IStatus)new Status(4, "org.eclipse.core.resources", 1, errors.getMessage(), (Throwable)e)); continue;
/*     */         } finally {
/* 259 */           Job.getJobManager().endRule(refreshRule);
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 263 */       this.pathPrefixHistory = null;
/* 264 */       this.rootPathHistory = null;
/* 265 */       if (Policy.DEBUG_AUTO_REFRESH)
/* 266 */         Policy.debug("Auto-refresh:  finished refresh job in: " + (System.currentTimeMillis() - start) + "ms"); 
/*     */     } 
/* 268 */     if (!errors.isOK())
/* 269 */       return (IStatus)errors; 
/* 270 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean shouldRun() {
/* 275 */     return !this.fRequests.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 282 */     if (Policy.DEBUG_AUTO_REFRESH) {
/* 283 */       Policy.debug("Auto-refresh:  enabling auto-refresh");
/*     */     }
/* 285 */     this.disabled = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 292 */     if (Policy.DEBUG_AUTO_REFRESH) {
/* 293 */       Policy.debug("Auto-refresh:  disabling auto-refresh");
/*     */     }
/* 295 */     this.disabled = true;
/* 296 */     cancel();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\refresh\RefreshJob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */