/*      */ package org.eclipse.core.internal.resources;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.util.ArrayDeque;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Deque;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import javax.xml.parsers.SAXParser;
/*      */ import javax.xml.parsers.SAXParserFactory;
/*      */ import org.eclipse.core.filesystem.URIUtil;
/*      */ import org.eclipse.core.internal.events.BuildCommand;
/*      */ import org.eclipse.core.internal.utils.Messages;
/*      */ import org.eclipse.core.internal.utils.Policy;
/*      */ import org.eclipse.core.resources.FileInfoMatcherDescription;
/*      */ import org.eclipse.core.resources.ICommand;
/*      */ import org.eclipse.core.resources.IProject;
/*      */ import org.eclipse.core.resources.IResource;
/*      */ import org.eclipse.core.resources.IWorkspace;
/*      */ import org.eclipse.core.resources.IWorkspaceRoot;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.MultiStatus;
/*      */ import org.eclipse.core.runtime.Path;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ import org.xml.sax.Attributes;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXException;
/*      */ import org.xml.sax.SAXParseException;
/*      */ import org.xml.sax.helpers.DefaultHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ProjectDescriptionReader
/*      */   extends DefaultHandler
/*      */   implements IModelObjectConstants
/*      */ {
/*      */   protected static final int S_BUILD_COMMAND = 0;
/*      */   protected static final int S_BUILD_COMMAND_ARGUMENTS = 1;
/*      */   protected static final int S_BUILD_COMMAND_NAME = 2;
/*      */   protected static final int S_BUILD_COMMAND_TRIGGERS = 3;
/*      */   protected static final int S_BUILD_SPEC = 4;
/*      */   protected static final int S_DICTIONARY = 5;
/*      */   protected static final int S_DICTIONARY_KEY = 6;
/*      */   protected static final int S_DICTIONARY_VALUE = 7;
/*      */   protected static final int S_INITIAL = 8;
/*      */   protected static final int S_LINK = 9;
/*      */   protected static final int S_LINK_LOCATION = 10;
/*      */   protected static final int S_LINK_LOCATION_URI = 11;
/*      */   protected static final int S_LINK_PATH = 12;
/*      */   protected static final int S_LINK_TYPE = 13;
/*      */   protected static final int S_LINKED_RESOURCES = 14;
/*      */   protected static final int S_NATURE_NAME = 15;
/*      */   protected static final int S_NATURES = 16;
/*      */   protected static final int S_PROJECT_COMMENT = 17;
/*      */   protected static final int S_PROJECT_DESC = 18;
/*      */   protected static final int S_PROJECT_NAME = 19;
/*      */   protected static final int S_PROJECTS = 20;
/*      */   protected static final int S_REFERENCED_PROJECT_NAME = 21;
/*      */   protected static final int S_FILTERED_RESOURCES = 23;
/*      */   protected static final int S_FILTER = 24;
/*      */   protected static final int S_FILTER_ID = 25;
/*      */   protected static final int S_FILTER_PATH = 26;
/*      */   protected static final int S_FILTER_TYPE = 27;
/*      */   protected static final int S_MATCHER = 28;
/*      */   protected static final int S_MATCHER_ID = 29;
/*      */   protected static final int S_MATCHER_ARGUMENTS = 30;
/*      */   protected static final int S_VARIABLE_LIST = 31;
/*      */   protected static final int S_VARIABLE = 32;
/*      */   protected static final int S_VARIABLE_NAME = 33;
/*      */   protected static final int S_VARIABLE_VALUE = 34;
/*      */   protected static final int S_SNAPSHOT_LOCATION = 35;
/*      */   private static SAXParserFactory singletonParserFactory;
/*      */   private static SAXParser singletonParser;
/*   97 */   protected final StringBuilder charBuffer = new StringBuilder();
/*      */ 
/*      */   
/*      */   protected Deque<Object> objectStack;
/*      */ 
/*      */   
/*      */   protected MultiStatus problems;
/*      */   
/*      */   private final IProject project;
/*      */   
/*  107 */   ProjectDescription projectDescription = null;
/*      */   
/*  109 */   protected int state = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Workspace workspace;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static synchronized SAXParser createParser(Workspace workspace) throws ParserConfigurationException, SAXException {
/*  120 */     if (workspace == null || !isWorkspaceLocked(workspace))
/*  121 */       return createParserFactory().newSAXParser(); 
/*  122 */     if (singletonParser == null) {
/*  123 */       singletonParser = createParserFactory().newSAXParser();
/*      */     }
/*  125 */     return singletonParser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static synchronized SAXParserFactory createParserFactory() throws ParserConfigurationException {
/*  133 */     if (singletonParserFactory == null) {
/*  134 */       singletonParserFactory = SAXParserFactory.newInstance();
/*  135 */       singletonParserFactory.setNamespaceAware(true);
/*      */       try {
/*  137 */         singletonParserFactory.setFeature("http://xml.org/sax/features/string-interning", true);
/*  138 */       } catch (SAXException sAXException) {}
/*      */     } 
/*      */ 
/*      */     
/*  142 */     return singletonParserFactory;
/*      */   }
/*      */   
/*      */   private static boolean isWorkspaceLocked(Workspace workspace) {
/*      */     try {
/*  147 */       return workspace.getWorkManager().isLockAlreadyAcquired();
/*  148 */     } catch (CoreException coreException) {
/*  149 */       return false;
/*      */     } 
/*      */   }
/*      */   
/*      */   public ProjectDescriptionReader(IWorkspace workspace) {
/*  154 */     this.workspace = (Workspace)workspace;
/*  155 */     this.project = null;
/*      */   }
/*      */   
/*      */   public ProjectDescriptionReader(IProject project) {
/*  159 */     this.project = project;
/*  160 */     this.workspace = (Workspace)project.getWorkspace();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void characters(char[] chars, int offset, int length) {
/*  169 */     this.charBuffer.append(chars, offset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void endBuildCommandElement(String elementName) {
/*  176 */     if (elementName.equals("buildCommand")) {
/*      */       
/*  178 */       BuildCommand command = (BuildCommand)this.objectStack.pop();
/*      */       
/*  180 */       ArrayList<BuildCommand> commandList = (ArrayList<BuildCommand>)this.objectStack.peek();
/*  181 */       commandList.add(command);
/*  182 */       this.state = 4;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void endBuildSpecElement(String elementName) {
/*  190 */     if (elementName.equals("buildSpec")) {
/*      */ 
/*      */       
/*  193 */       ArrayList<ICommand> commands = (ArrayList<ICommand>)this.objectStack.pop();
/*  194 */       this.state = 18;
/*  195 */       if (commands.isEmpty())
/*      */         return; 
/*  197 */       ICommand[] commandArray = commands.<ICommand>toArray(new ICommand[commands.size()]);
/*  198 */       this.projectDescription.setBuildSpec(commandArray);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void endBuildTriggersElement(String elementName) {
/*  207 */     if (elementName.equals("triggers")) {
/*  208 */       this.state = 0;
/*  209 */       BuildCommand command = (BuildCommand)this.objectStack.peek();
/*      */       
/*  211 */       command.setConfigurable(true);
/*      */       
/*  213 */       command.setBuilding(9, false);
/*  214 */       command.setBuilding(15, false);
/*  215 */       command.setBuilding(6, false);
/*  216 */       command.setBuilding(10, false);
/*      */ 
/*      */       
/*  219 */       StringTokenizer tokens = new StringTokenizer(this.charBuffer.toString(), ",");
/*  220 */       while (tokens.hasMoreTokens()) {
/*  221 */         String next = tokens.nextToken();
/*  222 */         if (next.toLowerCase().equals("auto")) {
/*  223 */           command.setBuilding(9, true); continue;
/*  224 */         }  if (next.toLowerCase().equals("clean")) {
/*  225 */           command.setBuilding(15, true); continue;
/*  226 */         }  if (next.toLowerCase().equals("full")) {
/*  227 */           command.setBuilding(6, true); continue;
/*  228 */         }  if (next.toLowerCase().equals("incremental")) {
/*  229 */           command.setBuilding(10, true);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void endDictionary(String elementName) {
/*  239 */     if (elementName.equals("dictionary")) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  244 */       String value = (String)this.objectStack.pop();
/*  245 */       String key = (String)this.objectStack.pop();
/*  246 */       ((HashMap<String, String>)this.objectStack.peek()).put(key, value);
/*  247 */       this.state = 1;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endDictionaryKey(String elementName) {
/*  252 */     if (elementName.equals("key")) {
/*      */ 
/*      */       
/*  255 */       String value = (String)this.objectStack.pop();
/*  256 */       String oldKey = (String)this.objectStack.pop();
/*  257 */       String newKey = this.charBuffer.toString();
/*  258 */       if (oldKey != null && oldKey.length() != 0) {
/*  259 */         parseProblem(NLS.bind(Messages.projRead_whichKey, oldKey, newKey));
/*  260 */         this.objectStack.push(oldKey);
/*      */       } else {
/*  262 */         this.objectStack.push(newKey);
/*      */       } 
/*      */       
/*  265 */       this.objectStack.push(value);
/*  266 */       this.state = 5;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endDictionaryValue(String elementName) {
/*  271 */     if (elementName.equals("value")) {
/*  272 */       String newValue = this.charBuffer.toString();
/*      */       
/*  274 */       String oldValue = (String)this.objectStack.pop();
/*  275 */       if (oldValue != null && oldValue.length() != 0) {
/*  276 */         parseProblem(NLS.bind(Messages.projRead_whichValue, oldValue, newValue));
/*  277 */         this.objectStack.push(oldValue);
/*      */       } else {
/*  279 */         this.objectStack.push(newValue);
/*      */       } 
/*  281 */       this.state = 5;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void endElement(String uri, String elementName, String qname) {
/*  290 */     switch (this.state) {
/*      */ 
/*      */ 
/*      */       
/*      */       case 19:
/*  295 */         if (elementName.equals("name")) {
/*      */ 
/*      */           
/*  298 */           this.projectDescription.setName(this.charBuffer.toString().trim());
/*  299 */           this.state = 18;
/*      */         } 
/*      */         break;
/*      */       case 20:
/*  303 */         if (elementName.equals("projects")) {
/*  304 */           endProjectsElement();
/*  305 */           this.state = 18;
/*      */         } 
/*      */         break;
/*      */       case 5:
/*  309 */         endDictionary(elementName);
/*      */         break;
/*      */       case 1:
/*  312 */         if (elementName.equals("arguments")) {
/*      */ 
/*      */           
/*  315 */           HashMap<String, String> dictionaryArgs = (HashMap<String, String>)this.objectStack.pop();
/*  316 */           this.state = 0;
/*  317 */           if (dictionaryArgs.isEmpty()) {
/*      */             break;
/*      */           }
/*  320 */           ((BuildCommand)this.objectStack.peek()).setArguments(dictionaryArgs);
/*      */         } 
/*      */         break;
/*      */       case 0:
/*  324 */         endBuildCommandElement(elementName);
/*      */         break;
/*      */       case 4:
/*  327 */         endBuildSpecElement(elementName);
/*      */         break;
/*      */       case 3:
/*  330 */         endBuildTriggersElement(elementName);
/*      */         break;
/*      */       case 16:
/*  333 */         endNaturesElement(elementName);
/*      */         break;
/*      */       case 9:
/*  336 */         endLinkElement(elementName);
/*      */         break;
/*      */       case 14:
/*  339 */         endLinkedResourcesElement(elementName);
/*      */         break;
/*      */       case 32:
/*  342 */         endVariableElement(elementName);
/*      */         break;
/*      */       case 24:
/*  345 */         endFilterElement(elementName);
/*      */         break;
/*      */       case 23:
/*  348 */         endFilteredResourcesElement(elementName);
/*      */         break;
/*      */       case 31:
/*  351 */         endVariableListElement(elementName);
/*      */         break;
/*      */       case 17:
/*  354 */         if (elementName.equals("comment")) {
/*  355 */           this.projectDescription.setComment(this.charBuffer.toString());
/*  356 */           this.state = 18;
/*      */         } 
/*      */         break;
/*      */       case 21:
/*  360 */         if (elementName.equals("project")) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  365 */           ((ArrayList<String>)this.objectStack.peek()).add(this.charBuffer.toString().trim());
/*  366 */           this.state = 20;
/*      */         } 
/*      */         break;
/*      */       case 2:
/*  370 */         if (elementName.equals("name")) {
/*      */ 
/*      */ 
/*      */           
/*  374 */           ((BuildCommand)this.objectStack.peek()).setName(this.charBuffer.toString().trim());
/*  375 */           this.state = 0;
/*      */         } 
/*      */         break;
/*      */       case 6:
/*  379 */         endDictionaryKey(elementName);
/*      */         break;
/*      */       case 7:
/*  382 */         endDictionaryValue(elementName);
/*      */         break;
/*      */       case 15:
/*  385 */         if (elementName.equals("nature")) {
/*      */ 
/*      */ 
/*      */           
/*  389 */           ((ArrayList<String>)this.objectStack.peek()).add(this.charBuffer.toString().trim());
/*  390 */           this.state = 16;
/*      */         } 
/*      */         break;
/*      */       case 12:
/*  394 */         endLinkPath(elementName);
/*      */         break;
/*      */       case 13:
/*  397 */         endLinkType(elementName);
/*      */         break;
/*      */       case 10:
/*  400 */         endLinkLocation(elementName);
/*      */         break;
/*      */       case 11:
/*  403 */         endLinkLocationURI(elementName);
/*      */         break;
/*      */       case 25:
/*  406 */         endFilterId(elementName);
/*      */         break;
/*      */       case 26:
/*  409 */         endFilterPath(elementName);
/*      */         break;
/*      */       case 27:
/*  412 */         endFilterType(elementName);
/*      */         break;
/*      */       case 28:
/*  415 */         endMatcherElement(elementName);
/*      */         break;
/*      */       case 29:
/*  418 */         endMatcherID(elementName);
/*      */         break;
/*      */       case 30:
/*  421 */         endMatcherArguments(elementName);
/*      */         break;
/*      */       case 33:
/*  424 */         endVariableName(elementName);
/*      */         break;
/*      */       case 34:
/*  427 */         endVariableValue(elementName);
/*      */         break;
/*      */       case 35:
/*  430 */         endSnapshotLocation(elementName);
/*      */         break;
/*      */     } 
/*  433 */     this.charBuffer.setLength(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void endLinkedResourcesElement(String elementName) {
/*  440 */     if (elementName.equals("linkedResources")) {
/*  441 */       HashMap<IPath, LinkDescription> linkedResources = (HashMap<IPath, LinkDescription>)this.objectStack.pop();
/*  442 */       this.state = 18;
/*  443 */       if (linkedResources.isEmpty())
/*      */         return; 
/*  445 */       this.projectDescription.setLinkDescriptions(linkedResources);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void endFilteredResourcesElement(String elementName) {
/*  453 */     if (elementName.equals("filteredResources")) {
/*  454 */       HashMap<IPath, LinkedList<FilterDescription>> filteredResources = (HashMap<IPath, LinkedList<FilterDescription>>)this.objectStack.pop();
/*  455 */       this.state = 18;
/*  456 */       if (filteredResources.isEmpty())
/*      */         return; 
/*  458 */       this.projectDescription.setFilterDescriptions(filteredResources);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void endVariableListElement(String elementName) {
/*  467 */     if (elementName.equals("variableList")) {
/*  468 */       HashMap<String, VariableDescription> variableList = (HashMap<String, VariableDescription>)this.objectStack.pop();
/*  469 */       this.state = 18;
/*  470 */       if (variableList.isEmpty())
/*      */         return; 
/*  472 */       this.projectDescription.setVariableDescriptions(variableList);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void endLinkElement(String elementName) {
/*  480 */     if (elementName.equals("link")) {
/*  481 */       this.state = 14;
/*      */       
/*  483 */       LinkDescription link = (LinkDescription)this.objectStack.pop();
/*      */       
/*  485 */       IPath path = link.getProjectRelativePath();
/*  486 */       int type = link.getType();
/*  487 */       URI location = link.getLocationURI();
/*  488 */       if (location == null) {
/*  489 */         parseProblem(NLS.bind(Messages.projRead_badLinkLocation, path, Integer.toString(type)));
/*      */         return;
/*      */       } 
/*  492 */       if (path == null || path.segmentCount() == 0) {
/*  493 */         parseProblem(NLS.bind(Messages.projRead_emptyLinkName, Integer.toString(type), location));
/*      */         return;
/*      */       } 
/*  496 */       if (type == -1) {
/*  497 */         parseProblem(NLS.bind(Messages.projRead_badLinkType, path, location));
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  502 */       ((HashMap<IPath, LinkDescription>)this.objectStack.peek()).put(link.getProjectRelativePath(), link);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endMatcherElement(String elementName) {
/*  507 */     if (elementName.equals("matcher")) {
/*      */       
/*  509 */       Object[] matcher = (Object[])this.objectStack.pop();
/*      */       
/*  511 */       String id = (String)matcher[0];
/*      */       
/*  513 */       if (id == null) {
/*  514 */         parseProblem(NLS.bind(Messages.projRead_badFilterID, null));
/*      */         
/*      */         return;
/*      */       } 
/*  518 */       if (this.objectStack.peek() instanceof ArrayList) {
/*  519 */         this.state = 30;
/*      */         
/*  521 */         ArrayList<FileInfoMatcherDescription> list = (ArrayList<FileInfoMatcherDescription>)this.objectStack.peek();
/*  522 */         list.add(new FileInfoMatcherDescription((String)matcher[0], matcher[1]));
/*      */       } 
/*      */       
/*  525 */       if (this.objectStack.peek() instanceof FilterDescription) {
/*  526 */         this.state = 24;
/*  527 */         FilterDescription d = (FilterDescription)this.objectStack.peek();
/*  528 */         d.setFileInfoMatcherDescription(new FileInfoMatcherDescription((String)matcher[0], matcher[1]));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void endFilterElement(String elementName) {
/*  537 */     if (elementName.equals("filter")) {
/*      */       
/*  539 */       FilterDescription filter = (FilterDescription)this.objectStack.pop();
/*  540 */       if (this.project != null) {
/*      */         
/*  542 */         IPath path = filter.getResource().getProjectRelativePath();
/*  543 */         int type = filter.getType();
/*      */         
/*  545 */         if (path == null) {
/*  546 */           parseProblem(NLS.bind(Messages.projRead_emptyFilterName, Integer.toString(type)));
/*      */           return;
/*      */         } 
/*  549 */         if (type == -1) {
/*  550 */           parseProblem(NLS.bind(Messages.projRead_badFilterType, path));
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/*  555 */         HashMap<IPath, LinkedList<FilterDescription>> map = (HashMap<IPath, LinkedList<FilterDescription>>)this.objectStack.peek();
/*  556 */         LinkedList<FilterDescription> list = map.get(filter.getResource().getProjectRelativePath());
/*  557 */         if (list == null) {
/*  558 */           list = new LinkedList<>();
/*  559 */           map.put(filter.getResource().getProjectRelativePath(), list);
/*      */         } 
/*  561 */         list.add(filter);
/*      */       }
/*      */       else {
/*      */         
/*  565 */         String key = "";
/*  566 */         HashMap<String, LinkedList<FilterDescription>> map = (HashMap<String, LinkedList<FilterDescription>>)this.objectStack.peek();
/*  567 */         LinkedList<FilterDescription> list = map.get(key);
/*  568 */         if (list == null) {
/*  569 */           list = new LinkedList<>();
/*  570 */           map.put(key, list);
/*      */         } 
/*  572 */         list.add(filter);
/*      */       } 
/*  574 */       this.state = 23;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void endVariableElement(String elementName) {
/*  582 */     if (elementName.equals("variable")) {
/*  583 */       this.state = 31;
/*      */       
/*  585 */       VariableDescription desc = (VariableDescription)this.objectStack.pop();
/*      */       
/*  587 */       if (desc.getName().length() == 0) {
/*  588 */         parseProblem(NLS.bind(Messages.projRead_emptyVariableName, this.project.getName()));
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  593 */       ((HashMap<String, VariableDescription>)this.objectStack.peek()).put(desc.getName(), desc);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void endLinkLocation(String elementName) {
/*  603 */     if (elementName.equals("location")) {
/*      */       
/*  605 */       String newLocation = this.charBuffer.toString().trim();
/*      */       
/*  607 */       URI oldLocation = ((LinkDescription)this.objectStack.peek()).getLocationURI();
/*  608 */       if (oldLocation != null) {
/*  609 */         parseProblem(NLS.bind(Messages.projRead_badLocation, oldLocation, newLocation));
/*      */       } else {
/*  611 */         ((LinkDescription)this.objectStack.peek()).setLocationURI(URIUtil.toURI(Path.fromPortableString(newLocation)));
/*      */       } 
/*  613 */       this.state = 9;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void endLinkLocationURI(String elementName) {
/*  623 */     if (elementName.equals("locationURI")) {
/*      */       
/*  625 */       String newLocation = this.charBuffer.toString().trim();
/*      */       
/*  627 */       URI oldLocation = ((LinkDescription)this.objectStack.peek()).getLocationURI();
/*  628 */       if (oldLocation != null) {
/*  629 */         parseProblem(NLS.bind(Messages.projRead_badLocation, oldLocation, newLocation));
/*      */       } else {
/*      */         try {
/*  632 */           ((LinkDescription)this.objectStack.peek()).setLocationURI(new URI(newLocation));
/*  633 */         } catch (URISyntaxException e) {
/*  634 */           String msg = Messages.projRead_failureReadingProjectDesc;
/*  635 */           this.problems.add((IStatus)new Status(2, "org.eclipse.core.resources", 567, msg, e));
/*      */         } 
/*      */       } 
/*  638 */       this.state = 9;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endLinkPath(String elementName) {
/*  643 */     if (elementName.equals("name")) {
/*  644 */       Path path = new Path(this.charBuffer.toString());
/*      */ 
/*      */       
/*  647 */       IPath oldPath = ((LinkDescription)this.objectStack.peek()).getProjectRelativePath();
/*  648 */       if (oldPath.segmentCount() != 0) {
/*  649 */         parseProblem(NLS.bind(Messages.projRead_badLinkName, oldPath, path));
/*      */       } else {
/*  651 */         ((LinkDescription)this.objectStack.peek()).setPath((IPath)path);
/*      */       } 
/*  653 */       this.state = 9;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endMatcherID(String elementName) {
/*  658 */     if (elementName.equals("id")) {
/*      */       
/*  660 */       String newID = this.charBuffer.toString().trim();
/*      */       
/*  662 */       String oldID = (String)((Object[])this.objectStack.peek())[0];
/*  663 */       if (oldID != null) {
/*  664 */         parseProblem(NLS.bind(Messages.projRead_badID, oldID, newID));
/*      */       } else {
/*  666 */         ((Object[])this.objectStack.peek())[0] = newID;
/*      */       } 
/*  668 */       this.state = 28;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endMatcherArguments(String elementName) {
/*  673 */     if (elementName.equals("arguments")) {
/*  674 */       ArrayList<FileInfoMatcherDescription> matchers = (ArrayList<FileInfoMatcherDescription>)this.objectStack.pop();
/*  675 */       Object newArguments = this.charBuffer.toString();
/*      */       
/*  677 */       if (matchers.size() > 0) {
/*  678 */         newArguments = matchers.toArray(new FileInfoMatcherDescription[matchers.size()]);
/*      */       }
/*      */       
/*  681 */       String oldArguments = (String)((Object[])this.objectStack.peek())[1];
/*  682 */       if (oldArguments != null) {
/*  683 */         parseProblem(NLS.bind(Messages.projRead_badArguments, oldArguments, newArguments));
/*      */       } else {
/*  685 */         ((Object[])this.objectStack.peek())[1] = newArguments;
/*  686 */       }  this.state = 28;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endFilterId(String elementName) {
/*  691 */     if (elementName.equals("id")) {
/*  692 */       Long newId = Long.valueOf(Long.parseLong(this.charBuffer.toString()));
/*      */ 
/*      */       
/*  695 */       long oldId = ((FilterDescription)this.objectStack.peek()).getId();
/*  696 */       if (oldId != 0L) {
/*  697 */         parseProblem(NLS.bind(Messages.projRead_badFilterName, Long.valueOf(oldId), newId));
/*      */       } else {
/*  699 */         ((FilterDescription)this.objectStack.peek()).setId(newId.longValue());
/*      */       } 
/*  701 */       this.state = 24;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endFilterPath(String elementName) {
/*  706 */     if (elementName.equals("name")) {
/*  707 */       Path path = new Path(this.charBuffer.toString());
/*      */ 
/*      */       
/*  710 */       IResource oldResource = ((FilterDescription)this.objectStack.peek()).getResource();
/*  711 */       if (oldResource != null) {
/*  712 */         parseProblem(NLS.bind(Messages.projRead_badFilterName, oldResource.getProjectRelativePath(), path));
/*      */       }
/*  714 */       else if (this.project != null) {
/*  715 */         ((FilterDescription)this.objectStack.peek()).setResource(path.isEmpty() ? (IResource)this.project : (IResource)this.project.getFolder((IPath)path));
/*      */       }
/*      */       else {
/*      */         
/*  719 */         ((FilterDescription)this.objectStack.peek()).setResource(null);
/*      */       } 
/*      */       
/*  722 */       this.state = 24;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endFilterType(String elementName) {
/*  727 */     if (elementName.equals("type")) {
/*  728 */       int newType = -1;
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  733 */         newType = Integer.parseInt(this.charBuffer.toString().trim());
/*  734 */       } catch (NumberFormatException e) {
/*  735 */         log(e);
/*      */       } 
/*      */ 
/*      */       
/*  739 */       int oldType = ((FilterDescription)this.objectStack.peek()).getType();
/*  740 */       if (oldType != -1) {
/*  741 */         parseProblem(NLS.bind(Messages.projRead_badFilterType2, Integer.toString(oldType), Integer.toString(newType)));
/*      */       } else {
/*  743 */         ((FilterDescription)this.objectStack.peek()).setType(newType);
/*      */       } 
/*  745 */       this.state = 24;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endVariableName(String elementName) {
/*  750 */     if (elementName.equals("name")) {
/*  751 */       String value = this.charBuffer.toString();
/*      */ 
/*      */       
/*  754 */       ((VariableDescription)this.objectStack.peek()).setName(value);
/*  755 */       this.state = 32;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endVariableValue(String elementName) {
/*  760 */     if (elementName.equals("value")) {
/*  761 */       String value = this.charBuffer.toString();
/*      */ 
/*      */       
/*  764 */       ((VariableDescription)this.objectStack.peek()).setValue(value);
/*  765 */       this.state = 32;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endLinkType(String elementName) {
/*  770 */     if (elementName.equals("type")) {
/*      */ 
/*      */       
/*  773 */       int newType = 1;
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  778 */         newType = Integer.parseInt(this.charBuffer.toString().trim());
/*  779 */       } catch (NumberFormatException e) {
/*  780 */         log(e);
/*      */       } 
/*      */ 
/*      */       
/*  784 */       int oldType = ((LinkDescription)this.objectStack.peek()).getType();
/*  785 */       if (oldType != -1) {
/*  786 */         parseProblem(NLS.bind(Messages.projRead_badLinkType2, Integer.toString(oldType), Integer.toString(newType)));
/*      */       } else {
/*  788 */         ((LinkDescription)this.objectStack.peek()).setType(newType);
/*      */       } 
/*  790 */       this.state = 9;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void endNaturesElement(String elementName) {
/*  798 */     if (elementName.equals("natures")) {
/*      */       
/*  800 */       ArrayList<String> natures = (ArrayList<String>)this.objectStack.pop();
/*  801 */       this.state = 18;
/*  802 */       if (natures.isEmpty())
/*      */         return; 
/*  804 */       String[] natureNames = natures.<String>toArray(new String[natures.size()]);
/*  805 */       this.projectDescription.setNatureIds(natureNames);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void endProjectsElement() {
/*  814 */     ArrayList<String> referencedProjects = (ArrayList<String>)this.objectStack.pop();
/*  815 */     if (referencedProjects.isEmpty()) {
/*      */       return;
/*      */     }
/*      */     
/*  819 */     IWorkspaceRoot root = this.workspace.getRoot();
/*  820 */     IProject[] projects = new IProject[referencedProjects.size()];
/*  821 */     for (int i = 0; i < projects.length; i++) {
/*  822 */       projects[i] = root.getProject(referencedProjects.get(i));
/*      */     }
/*  824 */     this.projectDescription.setReferencedProjects(projects);
/*      */   }
/*      */   
/*      */   private void endSnapshotLocation(String elementName) {
/*  828 */     if (elementName.equals("snapshotLocation")) {
/*  829 */       String location = this.charBuffer.toString().trim();
/*      */       try {
/*  831 */         this.projectDescription.setSnapshotLocationURI(new URI(location));
/*  832 */       } catch (URISyntaxException e) {
/*  833 */         String msg = NLS.bind(Messages.projRead_badSnapshotLocation, location);
/*  834 */         this.problems.add((IStatus)new Status(2, "org.eclipse.core.resources", 567, msg, e));
/*      */       } 
/*  836 */       this.state = 18;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(SAXParseException error) {
/*  845 */     log(error);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatalError(SAXParseException error) throws SAXException {
/*  854 */     String message = error.getMessage();
/*  855 */     if (this.project != null)
/*  856 */       message = NLS.bind(Messages.resources_readMeta, this.project.getName()); 
/*  857 */     this.problems.add((IStatus)new Status(4, "org.eclipse.core.resources", 567, (message == null) ? "" : message, error));
/*  858 */     throw error;
/*      */   }
/*      */   
/*      */   protected void log(Exception ex) {
/*  862 */     String message = ex.getMessage();
/*  863 */     if (this.project != null)
/*  864 */       message = NLS.bind(Messages.resources_readMeta, this.project.getName()); 
/*  865 */     this.problems.add((IStatus)new Status(2, "org.eclipse.core.resources", 567, (message == null) ? "" : message, ex));
/*      */   }
/*      */   
/*      */   private void parseProblem(String errorMessage) {
/*  869 */     this.problems.add((IStatus)new Status(2, "org.eclipse.core.resources", 567, errorMessage, null));
/*      */   }
/*      */   
/*      */   private void parseProjectDescription(String elementName) {
/*  873 */     if (elementName.equals("name")) {
/*  874 */       this.state = 19;
/*      */       return;
/*      */     } 
/*  877 */     if (elementName.equals("comment")) {
/*  878 */       this.state = 17;
/*      */       return;
/*      */     } 
/*  881 */     if (elementName.equals("projects")) {
/*  882 */       this.state = 20;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  888 */       this.objectStack.push(new ArrayList());
/*      */       return;
/*      */     } 
/*  891 */     if (elementName.equals("buildSpec")) {
/*  892 */       this.state = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  897 */       this.objectStack.push(new ArrayList());
/*      */       return;
/*      */     } 
/*  900 */     if (elementName.equals("natures")) {
/*  901 */       this.state = 16;
/*      */       
/*  903 */       this.objectStack.push(new ArrayList());
/*      */       return;
/*      */     } 
/*  906 */     if (elementName.equals("linkedResources")) {
/*      */       
/*  908 */       this.objectStack.push(new HashMap<>());
/*  909 */       this.state = 14;
/*      */       return;
/*      */     } 
/*  912 */     if (elementName.equals("filteredResources")) {
/*      */       
/*  914 */       this.objectStack.push(new HashMap<>());
/*  915 */       this.state = 23;
/*      */       return;
/*      */     } 
/*  918 */     if (elementName.equals("variableList")) {
/*      */       
/*  920 */       this.objectStack.push(new HashMap<>());
/*  921 */       this.state = 31;
/*      */       return;
/*      */     } 
/*  924 */     if (elementName.equals("snapshotLocation")) {
/*  925 */       this.state = 35;
/*      */       return;
/*      */     } 
/*      */   }
/*      */   
/*      */   public ProjectDescription read(InputSource input) {
/*  931 */     this.problems = new MultiStatus("org.eclipse.core.resources", 567, Messages.projRead_failureReadingProjectDesc, null);
/*  932 */     this.objectStack = new ArrayDeque();
/*  933 */     this.state = 8;
/*      */     try {
/*  935 */       createParser(this.workspace).parse(input, this);
/*  936 */     } catch (ParserConfigurationException|IOException|SAXException e) {
/*  937 */       log(e);
/*      */     } 
/*      */     
/*  940 */     if (this.projectDescription != null && this.projectDescription.getName() == null) {
/*  941 */       parseProblem(Messages.projRead_missingProjectName);
/*      */     }
/*  943 */     switch (this.problems.getSeverity()) {
/*      */       case 4:
/*  945 */         Policy.log((IStatus)this.problems);
/*  946 */         return null;
/*      */       case 1:
/*      */       case 2:
/*  949 */         Policy.log((IStatus)this.problems);
/*      */         break;
/*      */     } 
/*  952 */     return this.projectDescription;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ProjectDescription read(IPath location) throws IOException {
/*  960 */     Exception exception1 = null, exception2 = null;
/*      */     try {
/*      */     
/*      */     } finally {
/*  964 */       exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ProjectDescription read(IPath location, IPath tempLocation) throws IOException {
/*  972 */     Exception exception1 = null, exception2 = null;
/*      */     try {
/*      */     
/*      */     } finally {
/*  976 */       exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void startElement(String uri, String elementName, String qname, Attributes attributes) throws SAXException {
/*  985 */     this.charBuffer.setLength(0);
/*  986 */     switch (this.state) {
/*      */       case 8:
/*  988 */         if (elementName.equals("projectDescription")) {
/*  989 */           this.state = 18;
/*  990 */           this.projectDescription = new ProjectDescription(); break;
/*      */         } 
/*  992 */         throw new SAXException(NLS.bind(Messages.projRead_notProjectDescription, elementName));
/*      */ 
/*      */       
/*      */       case 18:
/*  996 */         parseProjectDescription(elementName);
/*      */         break;
/*      */       case 20:
/*  999 */         if (elementName.equals("project")) {
/* 1000 */           this.state = 21;
/*      */         }
/*      */         break;
/*      */       case 4:
/* 1004 */         if (elementName.equals("buildCommand")) {
/* 1005 */           this.state = 0;
/* 1006 */           this.objectStack.push(new BuildCommand());
/*      */         } 
/*      */         break;
/*      */       case 0:
/* 1010 */         if (elementName.equals("name")) {
/* 1011 */           this.state = 2; break;
/* 1012 */         }  if (elementName.equals("triggers")) {
/* 1013 */           this.state = 3; break;
/* 1014 */         }  if (elementName.equals("arguments")) {
/* 1015 */           this.state = 1;
/*      */ 
/*      */           
/* 1018 */           this.objectStack.push(new HashMap<>());
/*      */         } 
/*      */         break;
/*      */       case 1:
/* 1022 */         if (elementName.equals("dictionary")) {
/* 1023 */           this.state = 5;
/*      */           
/* 1025 */           this.objectStack.push("");
/* 1026 */           this.objectStack.push("");
/*      */         } 
/*      */         break;
/*      */       case 5:
/* 1030 */         if (elementName.equals("key")) {
/* 1031 */           this.state = 6; break;
/* 1032 */         }  if (elementName.equals("value")) {
/* 1033 */           this.state = 7;
/*      */         }
/*      */         break;
/*      */       case 16:
/* 1037 */         if (elementName.equals("nature")) {
/* 1038 */           this.state = 15;
/*      */         }
/*      */         break;
/*      */       case 14:
/* 1042 */         if (elementName.equals("link")) {
/* 1043 */           this.state = 9;
/*      */ 
/*      */           
/* 1046 */           this.objectStack.push(new LinkDescription());
/*      */         } 
/*      */         break;
/*      */       case 31:
/* 1050 */         if (elementName.equals("variable")) {
/* 1051 */           this.state = 32;
/*      */ 
/*      */           
/* 1054 */           this.objectStack.push(new VariableDescription());
/*      */         } 
/*      */         break;
/*      */       case 9:
/* 1058 */         if (elementName.equals("name")) {
/* 1059 */           this.state = 12; break;
/* 1060 */         }  if (elementName.equals("type")) {
/* 1061 */           this.state = 13; break;
/* 1062 */         }  if (elementName.equals("location")) {
/* 1063 */           this.state = 10; break;
/* 1064 */         }  if (elementName.equals("locationURI")) {
/* 1065 */           this.state = 11;
/*      */         }
/*      */         break;
/*      */       case 23:
/* 1069 */         if (elementName.equals("filter")) {
/* 1070 */           this.state = 24;
/*      */ 
/*      */           
/* 1073 */           this.objectStack.push(new FilterDescription());
/*      */         } 
/*      */         break;
/*      */       case 24:
/* 1077 */         if (elementName.equals("id")) {
/* 1078 */           this.state = 25; break;
/* 1079 */         }  if (elementName.equals("name")) {
/* 1080 */           this.state = 26; break;
/* 1081 */         }  if (elementName.equals("type")) {
/* 1082 */           this.state = 27; break;
/* 1083 */         }  if (elementName.equals("matcher")) {
/* 1084 */           this.state = 28;
/*      */           
/* 1086 */           this.objectStack.push(new Object[2]);
/*      */         } 
/*      */         break;
/*      */       case 28:
/* 1090 */         if (elementName.equals("id")) {
/* 1091 */           this.state = 29; break;
/* 1092 */         }  if (elementName.equals("arguments")) {
/* 1093 */           this.state = 30;
/* 1094 */           this.objectStack.push(new ArrayList());
/*      */         } 
/*      */         break;
/*      */       case 30:
/* 1098 */         if (elementName.equals("matcher")) {
/* 1099 */           this.state = 28;
/*      */           
/* 1101 */           this.objectStack.push(new Object[2]);
/*      */         } 
/*      */         break;
/*      */       case 32:
/* 1105 */         if (elementName.equals("name")) {
/* 1106 */           this.state = 33; break;
/* 1107 */         }  if (elementName.equals("value")) {
/* 1108 */           this.state = 34;
/*      */         }
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void warning(SAXParseException error) {
/* 1119 */     log(error);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ProjectDescriptionReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */