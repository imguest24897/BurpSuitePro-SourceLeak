/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.net.URI;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IFolder;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Folder
/*     */   extends Container
/*     */   implements IFolder
/*     */ {
/*     */   protected Folder(IPath path, Workspace container) {
/*  29 */     super(path, container);
/*     */   }
/*     */   
/*     */   protected void assertCreateRequirements(IFileStore store, IFileInfo localInfo, int updateFlags) throws CoreException {
/*  33 */     checkDoesNotExist();
/*  34 */     Container parent = (Container)getParent();
/*  35 */     ResourceInfo info = parent.getResourceInfo(false, false);
/*  36 */     parent.checkAccessible(getFlags(info));
/*  37 */     checkValidGroupContainer(parent, false, false);
/*     */     
/*  39 */     boolean force = ((updateFlags & 0x1) != 0);
/*  40 */     if (!force && localInfo.exists()) {
/*     */       
/*  42 */       if (!Workspace.caseSensitive) {
/*  43 */         String name = getLocalManager().getLocalName(store);
/*  44 */         if (name != null && !store.getName().equals(name)) {
/*  45 */           String str = NLS.bind(Messages.resources_existsLocalDifferentCase, (new Path(store.toString())).removeLastSegments(1).append(name).toOSString());
/*  46 */           throw new ResourceException(275, getFullPath(), str, null);
/*     */         } 
/*     */       } 
/*  49 */       String msg = NLS.bind(Messages.resources_fileExists, store.toString());
/*  50 */       throw new ResourceException(272, getFullPath(), msg, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFile changeToFile() throws CoreException {
/*  65 */     getPropertyManager().deleteProperties(this, 2);
/*  66 */     IFile result = this.workspace.getRoot().getFile(this.path);
/*  67 */     if (isLinked()) {
/*  68 */       URI location = getRawLocationURI();
/*  69 */       delete(0, (IProgressMonitor)null);
/*  70 */       result.createLink(location, 16, null);
/*     */     } else {
/*  72 */       this.workspace.deleteResource(this);
/*  73 */       this.workspace.createResource((IResource)result, false);
/*     */     } 
/*  75 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void create(int updateFlags, boolean local, IProgressMonitor monitor) throws CoreException {
/*  80 */     if ((updateFlags & 0x2000) == 8192) {
/*  81 */       createLink(LinkDescription.VIRTUAL_LOCATION, updateFlags, monitor);
/*     */       return;
/*     */     } 
/*  84 */     boolean force = ((updateFlags & 0x1) != 0);
/*  85 */     String message = NLS.bind(Messages.resources_creating, getFullPath());
/*  86 */     SubMonitor subMonitor = SubMonitor.convert(monitor, message, 100);
/*  87 */     checkValidPath(this.path, 2, true);
/*  88 */     ISchedulingRule rule = this.workspace.getRuleFactory().createRule(this);
/*  89 */     SubMonitor newChild = subMonitor.newChild(1);
/*     */     try {
/*  91 */       this.workspace.prepareOperation(rule, (IProgressMonitor)newChild);
/*  92 */       IFileStore store = getStore();
/*  93 */       IFileInfo localInfo = store.fetchInfo();
/*  94 */       assertCreateRequirements(store, localInfo, updateFlags);
/*  95 */       this.workspace.beginOperation(true);
/*  96 */       if (force && !Workspace.caseSensitive && localInfo.exists()) {
/*  97 */         String name = getLocalManager().getLocalName(store);
/*  98 */         if (name == null || localInfo.getName().equals(name)) {
/*  99 */           delete(true, (IProgressMonitor)null);
/*     */         }
/*     */         else {
/*     */           
/* 103 */           String msg = NLS.bind(Messages.resources_existsLocalDifferentCase, (
/* 104 */               new Path(store.toString())).removeLastSegments(1).append(name).toOSString());
/* 105 */           throw new ResourceException(275, getFullPath(), msg, null);
/*     */         } 
/*     */       } 
/* 108 */       internalCreate(updateFlags, local, (IProgressMonitor)subMonitor.newChild(98));
/* 109 */       this.workspace.getAliasManager().updateAliases(this, getStore(), 0, (IProgressMonitor)subMonitor.newChild(1));
/* 110 */     } catch (OperationCanceledException e) {
/* 111 */       this.workspace.getWorkManager().operationCanceled();
/* 112 */       throw e;
/*     */     } finally {
/* 114 */       subMonitor.done();
/* 115 */       this.workspace.endOperation(rule, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void create(boolean force, boolean local, IProgressMonitor monitor) throws CoreException {
/* 122 */     create(force ? 1 : 0, local, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ensureExists(IProgressMonitor monitor) throws CoreException {
/* 131 */     ResourceInfo info = getResourceInfo(false, false);
/* 132 */     int flags = getFlags(info);
/* 133 */     if (exists(flags, true))
/*     */       return; 
/* 135 */     if (exists(flags, false)) {
/* 136 */       String message = NLS.bind(Messages.resources_folderOverFile, getFullPath());
/* 137 */       throw new ResourceException(366, getFullPath(), message, null);
/*     */     } 
/* 139 */     Container parent = (Container)getParent();
/* 140 */     if (parent.getType() == 4) {
/* 141 */       info = parent.getResourceInfo(false, false);
/* 142 */       parent.checkExists(getFlags(info), true);
/*     */     } else {
/* 144 */       ((Folder)parent).ensureExists(monitor);
/* 145 */     }  if (getType() == 2 && isUnderVirtual()) {
/* 146 */       create(8193, true, monitor);
/*     */     } else {
/* 148 */       internalCreate(1, true, monitor);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDefaultCharset(boolean checkImplicit) {
/* 154 */     if (!exists())
/* 155 */       return checkImplicit ? this.workspace.getCharsetManager().getCharsetFor(getFullPath().removeLastSegments(1), true) : null; 
/* 156 */     return this.workspace.getCharsetManager().getCharsetFor(getFullPath(), checkImplicit);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getType() {
/* 161 */     return 2;
/*     */   }
/*     */   
/*     */   public void internalCreate(int updateFlags, boolean local, IProgressMonitor monitor) throws CoreException {
/* 165 */     monitor = Policy.monitorFor(monitor);
/*     */     try {
/* 167 */       String message = NLS.bind(Messages.resources_creating, getFullPath());
/* 168 */       monitor.beginTask(message, 100);
/* 169 */       this.workspace.createResource(this, updateFlags);
/* 170 */       if (local) {
/*     */         try {
/* 172 */           boolean force = ((updateFlags & 0x1) != 0);
/* 173 */           getLocalManager().write(this, force, Policy.subMonitorFor(monitor, 100));
/* 174 */         } catch (CoreException e) {
/*     */           
/* 176 */           this.workspace.deleteResource(this);
/* 177 */           throw e;
/*     */         } 
/*     */       }
/* 180 */       internalSetLocal(local, 0);
/* 181 */       if (!local)
/* 182 */         getResourceInfo(true, true).clearModificationStamp(); 
/*     */     } finally {
/* 184 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\Folder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */