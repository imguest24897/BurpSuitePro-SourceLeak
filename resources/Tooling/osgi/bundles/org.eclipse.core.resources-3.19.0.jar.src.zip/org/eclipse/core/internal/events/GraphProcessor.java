/*     */ package org.eclipse.core.internal.events;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Function;
/*     */ import org.eclipse.core.internal.resources.ComputeProjectOrder;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.core.runtime.jobs.JobGroup;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class GraphProcessor<T>
/*     */ {
/*     */   private final ComputeProjectOrder.Digraph<T> graph;
/*     */   private final Set<T> toProcess;
/*     */   private final Set<T> processing;
/*     */   private final Set<T> processed;
/*     */   private final ComputeProjectOrder.VertexOrder<T> sequentialOrder;
/*     */   private final JobGroup buildJobGroup;
/*     */   private final BiConsumer<T, GraphProcessor<T>> processor;
/*     */   private final Function<T, ISchedulingRule> ruleFactory;
/*     */   
/*     */   GraphProcessor(ComputeProjectOrder.Digraph<T> graph1, Class<T> clazz, BiConsumer<T, GraphProcessor<T>> processor, Function<T, ISchedulingRule> ruleFactory, JobGroup buildJobGroup) {
/*  41 */     this.graph = graph1;
/*  42 */     this.processor = processor;
/*  43 */     this.ruleFactory = ruleFactory;
/*  44 */     this.buildJobGroup = buildJobGroup;
/*  45 */     this.toProcess = new HashSet<>(this.graph.vertexMap.keySet());
/*  46 */     this.processing = new HashSet<>();
/*  47 */     this.processed = new HashSet<>();
/*  48 */     this.sequentialOrder = ComputeProjectOrder.computeVertexOrder(this.graph, clazz);
/*     */   }
/*     */   
/*     */   private boolean complete() {
/*  52 */     return (this.processed.size() == this.graph.vertexList.size());
/*     */   }
/*     */   
/*     */   private boolean allTriggered() {
/*  56 */     return this.toProcess.isEmpty();
/*     */   }
/*     */   
/*     */   private void markProcessing(T item) {
/*  60 */     if (!this.toProcess.remove(item)) {
/*  61 */       throw new IllegalArgumentException();
/*     */     }
/*  63 */     this.processing.add(item);
/*     */   }
/*     */   
/*     */   void markProcessed(T item) {
/*  67 */     if (!this.processing.remove(item)) {
/*  68 */       throw new IllegalArgumentException();
/*     */     }
/*  70 */     this.processed.add(item);
/*     */   }
/*     */   
/*     */   private Set<T> computeReadyVertexes() {
/*  74 */     Set<T> res = new HashSet<>(this.toProcess);
/*  75 */     for (T item : this.toProcess) {
/*  76 */       for (ComputeProjectOrder.Digraph.Edge<T> edge : (Iterable<ComputeProjectOrder.Digraph.Edge<T>>)this.graph.getEdges()) {
/*  77 */         if (edge.to == item && !this.processed.contains(edge.from)) {
/*  78 */           res.remove(item);
/*     */         }
/*     */       } 
/*     */     } 
/*  82 */     if (res.isEmpty() && !isProcessing()) {
/*  83 */       byte b; int i; Object[] arrayOfObject; for (i = (arrayOfObject = this.sequentialOrder.vertexes).length, b = 0; b < i; ) { T id = (T)arrayOfObject[b];
/*  84 */         if (!isProcessed(id))
/*  85 */           return Collections.singleton(id); 
/*     */         b++; }
/*     */     
/*     */     } 
/*  89 */     return res;
/*     */   }
/*     */   
/*     */   private boolean isProcessing() {
/*  93 */     return !this.processing.isEmpty();
/*     */   }
/*     */   
/*     */   private boolean isProcessed(T item) {
/*  97 */     return this.processed.contains(item);
/*     */   }
/*     */   
/*     */   public T[] getSequentialOrder() {
/* 101 */     return (T[])this.sequentialOrder.vertexes;
/*     */   }
/*     */   
/*     */   public synchronized void processGraphWithParallelJobs() {
/* 105 */     if (!complete() && 
/* 106 */       !allTriggered()) {
/* 107 */       Set<T> readyToBuild = computeReadyVertexes();
/* 108 */       readyToBuild.forEach(this::triggerJob);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void triggerJob(final T item) {
/* 114 */     synchronized (this) {
/* 115 */       markProcessing(item);
/*     */     } 
/* 117 */     Job buildJob = new Job(item.toString())
/*     */       {
/*     */         protected IStatus run(IProgressMonitor monitor)
/*     */         {
/* 121 */           GraphProcessor.this.processor.accept(item, GraphProcessor.this);
/* 122 */           synchronized (GraphProcessor.this) {
/* 123 */             GraphProcessor.this.markProcessed(item);
/*     */ 
/*     */             
/* 126 */             GraphProcessor.this.processGraphWithParallelJobs();
/*     */           } 
/* 128 */           return Status.OK_STATUS;
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean belongsTo(Object family) {
/* 133 */           return !(!super.belongsTo(family) && family != GraphProcessor.this);
/*     */         }
/*     */       };
/* 136 */     if (this.ruleFactory != null) {
/* 137 */       buildJob.setRule(this.ruleFactory.apply(item));
/*     */     }
/* 139 */     buildJob.setJobGroup(this.buildJobGroup);
/* 140 */     buildJob.schedule();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\GraphProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */