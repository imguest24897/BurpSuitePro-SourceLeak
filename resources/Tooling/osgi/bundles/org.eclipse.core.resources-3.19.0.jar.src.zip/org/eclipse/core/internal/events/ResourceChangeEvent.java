/*     */ package org.eclipse.core.internal.events;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.EventObject;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.resources.IMarkerSetElement;
/*     */ import org.eclipse.core.internal.resources.MarkerDelta;
/*     */ import org.eclipse.core.internal.resources.MarkerSet;
/*     */ import org.eclipse.core.resources.IMarkerDelta;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceChangeEvent;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceChangeEvent
/*     */   extends EventObject
/*     */   implements IResourceChangeEvent
/*     */ {
/*  24 */   private static final IMarkerDelta[] NO_MARKER_DELTAS = new IMarkerDelta[0];
/*     */   
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   IResourceDelta delta;
/*     */   
/*     */   IResource resource;
/*     */   
/*  32 */   private int trigger = 0;
/*     */   int type;
/*     */   
/*     */   protected ResourceChangeEvent(Object source, int type, IResource resource) {
/*  36 */     super(source);
/*  37 */     this.resource = resource;
/*  38 */     this.type = type;
/*     */   }
/*     */   
/*     */   public ResourceChangeEvent(Object source, int type, int buildKind, IResourceDelta delta) {
/*  42 */     super(source);
/*  43 */     this.delta = delta;
/*  44 */     this.trigger = buildKind;
/*  45 */     this.type = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMarkerDelta[] findMarkerDeltas(String findType, boolean includeSubtypes) {
/*  53 */     if (this.delta == null)
/*  54 */       return NO_MARKER_DELTAS; 
/*  55 */     ResourceDeltaInfo info = ((ResourceDelta)this.delta).getDeltaInfo();
/*  56 */     if (info == null) {
/*  57 */       return NO_MARKER_DELTAS;
/*     */     }
/*  59 */     Map<IPath, MarkerSet> markerDeltas = info.getMarkerDeltas();
/*  60 */     if (markerDeltas == null || markerDeltas.isEmpty())
/*  61 */       return NO_MARKER_DELTAS; 
/*  62 */     ArrayList<IMarkerDelta> matching = new ArrayList<>();
/*  63 */     Iterator<MarkerSet> deltaSets = markerDeltas.values().iterator();
/*  64 */     while (deltaSets.hasNext()) {
/*  65 */       MarkerSet deltas = deltaSets.next();
/*  66 */       IMarkerSetElement[] elements = deltas.elements(); byte b; int i; IMarkerSetElement[] arrayOfIMarkerSetElement1;
/*  67 */       for (i = (arrayOfIMarkerSetElement1 = elements).length, b = 0; b < i; ) { IMarkerSetElement element = arrayOfIMarkerSetElement1[b];
/*  68 */         MarkerDelta markerDelta = (MarkerDelta)element;
/*     */         
/*  70 */         if (findType == null || (includeSubtypes ? markerDelta.isSubtypeOf(findType) : markerDelta.getType().equals(findType)))
/*  71 */           matching.add(markerDelta);  b++; }
/*     */     
/*     */     } 
/*  74 */     return matching.<IMarkerDelta>toArray(new IMarkerDelta[matching.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBuildKind() {
/*  82 */     return this.trigger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResourceDelta getDelta() {
/*  90 */     return this.delta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource getResource() {
/*  98 */     return this.resource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getType() {
/* 106 */     return this.type;
/*     */   }
/*     */   
/*     */   public void setDelta(IResourceDelta value) {
/* 110 */     this.delta = value;
/*     */   }
/*     */   
/*     */   public String toDebugString() {
/* 114 */     StringBuilder output = new StringBuilder();
/* 115 */     output.append("\nType: ");
/* 116 */     switch (this.type) {
/*     */       case 1:
/* 118 */         output.append("POST_CHANGE");
/*     */         break;
/*     */       case 2:
/* 121 */         output.append("PRE_CLOSE");
/*     */         break;
/*     */       case 4:
/* 124 */         output.append("PRE_DELETE");
/*     */         break;
/*     */       case 8:
/* 127 */         output.append("PRE_BUILD");
/*     */         break;
/*     */       case 16:
/* 130 */         output.append("POST_BUILD");
/*     */         break;
/*     */       case 32:
/* 133 */         output.append("PRE_REFRESH");
/*     */         break;
/*     */       default:
/* 136 */         output.append("?");
/*     */         break;
/*     */     } 
/* 139 */     output.append("\nBuild kind: ");
/* 140 */     switch (this.trigger) {
/*     */       case 6:
/* 142 */         output.append("FULL_BUILD");
/*     */         break;
/*     */       case 9:
/*     */       case 10:
/* 146 */         output.append("INCREMENTAL_BUILD");
/*     */         break;
/*     */       case 15:
/* 149 */         output.append("CLEAN_BUILD");
/*     */         break;
/*     */       default:
/* 152 */         output.append(this.trigger);
/*     */         break;
/*     */     } 
/* 155 */     output.append("\nResource: " + ((this.resource == null) ? "null" : (String)this.resource));
/* 156 */     output.append("\nDelta:" + ((this.delta == null) ? " null" : ((ResourceDelta)this.delta).toDeepDebugString()));
/* 157 */     return output.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\ResourceChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */