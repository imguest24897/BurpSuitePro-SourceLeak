/*    */ package org.eclipse.core.internal.resources.refresh.win32;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.refresh.IRefreshMonitor;
/*    */ import org.eclipse.core.resources.refresh.IRefreshResult;
/*    */ import org.eclipse.core.resources.refresh.RefreshProvider;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Win32RefreshProvider
/*    */   extends RefreshProvider
/*    */ {
/*    */   private Win32Monitor monitor;
/*    */   
/*    */   public IRefreshMonitor installMonitor(IResource resource, IRefreshResult result, IProgressMonitor progressMonitor) {
/* 36 */     if (resource.getLocation() == null || !resource.exists() || resource.getType() == 1)
/* 37 */       return null; 
/* 38 */     if (this.monitor == null)
/* 39 */       this.monitor = new Win32Monitor(result); 
/* 40 */     if (this.monitor.monitor(resource))
/* 41 */       return this.monitor; 
/* 42 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\refresh\win32\Win32RefreshProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */