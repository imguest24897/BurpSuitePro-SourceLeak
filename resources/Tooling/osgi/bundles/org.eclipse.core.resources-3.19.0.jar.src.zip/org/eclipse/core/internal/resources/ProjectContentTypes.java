/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.internal.utils.Cache;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.ProjectScope;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ import org.eclipse.core.runtime.content.IContentTypeManager;
/*     */ import org.eclipse.core.runtime.content.IContentTypeMatcher;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*     */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProjectContentTypes
/*     */ {
/*     */   private static final String CONTENT_TYPE_PREF_NODE = "content-types";
/*     */   private static final String PREF_LOCAL_CONTENT_TYPE_SETTINGS = "enabled";
/*     */   
/*     */   private class ProjectContentTypeSelectionPolicy
/*     */     implements IContentTypeManager.ISelectionPolicy, IScopeContext
/*     */   {
/*     */     private Project project;
/*     */     private IScopeContext projectScope;
/*     */     
/*     */     public ProjectContentTypeSelectionPolicy(Project project) {
/*  52 */       this.project = project;
/*  53 */       this.projectScope = (IScopeContext)new ProjectScope(project);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/*  58 */       if (this == obj)
/*  59 */         return true; 
/*  60 */       if (!(obj instanceof IScopeContext))
/*  61 */         return false; 
/*  62 */       IScopeContext other = (IScopeContext)obj;
/*  63 */       if (!getName().equals(other.getName()))
/*  64 */         return false; 
/*  65 */       IPath location = getLocation();
/*  66 */       return (location == null) ? ((other.getLocation() == null)) : location.equals(other.getLocation());
/*     */     }
/*     */     
/*     */     private IScopeContext getDelegate() {
/*  70 */       if (!ProjectContentTypes.usesContentTypePreferences(this.project.getName()))
/*  71 */         return InstanceScope.INSTANCE; 
/*  72 */       return this.projectScope;
/*     */     }
/*     */ 
/*     */     
/*     */     public IPath getLocation() {
/*  77 */       return getDelegate().getLocation();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/*  82 */       return getDelegate().getName();
/*     */     }
/*     */ 
/*     */     
/*     */     public IEclipsePreferences getNode(String qualifier) {
/*  87 */       return getDelegate().getNode(qualifier);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  92 */       return getName().hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public IContentType[] select(IContentType[] candidates, boolean fileName, boolean content) {
/*  97 */       return ProjectContentTypes.this.select(this.project, candidates, fileName, content);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   private static final Preferences PROJECT_SCOPE = Platform.getPreferencesService().getRootNode().node("project");
/*     */   
/*     */   private Cache contentTypesPerProject;
/*     */   private Workspace workspace;
/*     */   
/*     */   static boolean usesContentTypePreferences(String projectName) {
/*     */     try {
/* 111 */       Preferences node = PROJECT_SCOPE;
/*     */ 
/*     */       
/* 114 */       if (!node.nodeExists(projectName))
/* 115 */         return false; 
/* 116 */       node = node.node(projectName);
/* 117 */       if (!node.nodeExists("org.eclipse.core.runtime"))
/* 118 */         return false; 
/* 119 */       node = node.node("org.eclipse.core.runtime");
/* 120 */       if (!node.nodeExists("content-types"))
/* 121 */         return false; 
/* 122 */       node = node.node("content-types");
/* 123 */       return node.getBoolean("enabled", false);
/* 124 */     } catch (BackingStoreException|IllegalStateException|IllegalArgumentException backingStoreException) {
/*     */ 
/*     */       
/* 127 */       return false;
/*     */     } 
/*     */   }
/*     */   public ProjectContentTypes(Workspace workspace) {
/* 131 */     this.workspace = workspace;
/*     */     
/* 133 */     this.contentTypesPerProject = new Cache(5, 30, 0.4D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Set<String> collectAssociatedContentTypes(Project project) {
/* 140 */     String[] enabledNatures = this.workspace.getNatureManager().getEnabledNatures(project);
/* 141 */     if (enabledNatures.length == 0)
/* 142 */       return Collections.EMPTY_SET; 
/* 143 */     Set<String> related = new HashSet<>(enabledNatures.length); byte b; int i; String[] arrayOfString1;
/* 144 */     for (i = (arrayOfString1 = enabledNatures).length, b = 0; b < i; ) { String enabledNature = arrayOfString1[b];
/* 145 */       ProjectNatureDescriptor descriptor = (ProjectNatureDescriptor)this.workspace.getNatureDescriptor(enabledNature);
/* 146 */       if (descriptor != null) {
/*     */ 
/*     */         
/* 149 */         String[] natureContentTypes = descriptor.getContentTypeIds();
/* 150 */         related.addAll(Arrays.asList(natureContentTypes));
/*     */       }  b++; }
/* 152 */      return related;
/*     */   }
/*     */   
/*     */   public void contentTypePreferencesChanged(IProject project) {
/* 156 */     ProjectInfo info = (ProjectInfo)((Project)project).getResourceInfo(false, false);
/* 157 */     if (info != null) {
/* 158 */       info.setMatcher(null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private IContentTypeMatcher createMatcher(Project project) {
/* 165 */     ProjectContentTypeSelectionPolicy projectContentTypeSelectionPolicy = new ProjectContentTypeSelectionPolicy(project);
/* 166 */     return Platform.getContentTypeManager().getMatcher(projectContentTypeSelectionPolicy, projectContentTypeSelectionPolicy);
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<String> getAssociatedContentTypes(Project project) {
/* 171 */     ResourceInfo info = project.getResourceInfo(false, false);
/* 172 */     if (info == null)
/*     */     {
/* 174 */       return null; } 
/* 175 */     String projectName = project.getName();
/* 176 */     synchronized (this.contentTypesPerProject) {
/* 177 */       Cache.Entry entry = this.contentTypesPerProject.getEntry(projectName);
/* 178 */       if (entry != null)
/*     */       {
/* 180 */         if (entry.getTimestamp() == info.getContentId())
/*     */         {
/* 182 */           return (Set<String>)entry.getCached(); } 
/*     */       }
/* 184 */       Set<String> result = collectAssociatedContentTypes(project);
/* 185 */       if (entry == null) {
/*     */         
/* 187 */         entry = this.contentTypesPerProject.addEntry(projectName, result, info.getContentId());
/*     */       } else {
/*     */         
/* 190 */         entry.setTimestamp(info.getContentId());
/* 191 */         entry.setCached(result);
/*     */       } 
/* 193 */       return result;
/*     */     } 
/*     */   }
/*     */   
/*     */   public IContentTypeMatcher getMatcherFor(Project project) throws CoreException {
/* 198 */     ProjectInfo info = (ProjectInfo)project.getResourceInfo(false, false);
/*     */     
/* 200 */     if (info == null)
/* 201 */       project.checkAccessible(project.getFlags(null)); 
/* 202 */     IContentTypeMatcher matcher = info.getMatcher();
/* 203 */     if (matcher != null)
/* 204 */       return matcher; 
/* 205 */     matcher = createMatcher(project);
/* 206 */     info.setMatcher(matcher);
/* 207 */     return matcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final IContentType[] select(Project project, IContentType[] candidates, boolean fileName, boolean content) {
/* 223 */     if (candidates.length < 2)
/* 224 */       return candidates; 
/* 225 */     Set<String> associated = getAssociatedContentTypes(project);
/* 226 */     if (associated == null || associated.isEmpty())
/*     */     {
/* 228 */       return candidates; } 
/* 229 */     int associatedCount = 0;
/* 230 */     for (int i = 0; i < candidates.length; i++) {
/*     */       
/* 232 */       if (associated.contains(candidates[i].getId())) {
/*     */         
/* 234 */         if (associatedCount < i) {
/* 235 */           IContentType promoted = candidates[i];
/*     */           
/* 237 */           for (int j = i; j > associatedCount; j--) {
/* 238 */             candidates[j] = candidates[j - 1];
/*     */           }
/* 240 */           candidates[associatedCount] = promoted;
/*     */         } 
/* 242 */         associatedCount++;
/*     */       } 
/* 244 */     }  return candidates;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ProjectContentTypes.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */