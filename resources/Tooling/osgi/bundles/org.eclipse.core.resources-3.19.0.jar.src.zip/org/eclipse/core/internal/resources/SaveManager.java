/*      */ package org.eclipse.core.internal.resources;
/*      */ 
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FilenameFilter;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ForkJoinPool;
/*      */ import java.util.concurrent.ForkJoinWorkerThread;
/*      */ import java.util.zip.ZipEntry;
/*      */ import java.util.zip.ZipInputStream;
/*      */ import java.util.zip.ZipOutputStream;
/*      */ import org.eclipse.core.internal.events.BuilderPersistentInfo;
/*      */ import org.eclipse.core.internal.events.ResourceStats;
/*      */ import org.eclipse.core.internal.localstore.SafeChunkyOutputStream;
/*      */ import org.eclipse.core.internal.localstore.SafeFileOutputStream;
/*      */ import org.eclipse.core.internal.utils.FileUtil;
/*      */ import org.eclipse.core.internal.utils.Messages;
/*      */ import org.eclipse.core.internal.utils.Policy;
/*      */ import org.eclipse.core.internal.utils.WrappedRuntimeException;
/*      */ import org.eclipse.core.internal.watson.ElementTree;
/*      */ import org.eclipse.core.internal.watson.ElementTreeWriter;
/*      */ import org.eclipse.core.internal.watson.IElementContentVisitor;
/*      */ import org.eclipse.core.internal.watson.IPathRequestor;
/*      */ import org.eclipse.core.resources.IProject;
/*      */ import org.eclipse.core.resources.IResource;
/*      */ import org.eclipse.core.resources.ISaveParticipant;
/*      */ import org.eclipse.core.resources.IWorkspaceRoot;
/*      */ import org.eclipse.core.runtime.Assert;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.ISafeRunnable;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.MultiStatus;
/*      */ import org.eclipse.core.runtime.Path;
/*      */ import org.eclipse.core.runtime.QualifiedName;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.core.runtime.SubMonitor;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ 
/*      */ public class SaveManager implements IElementInfoFlattener, IManager, IStringPoolParticipant {
/*      */   class MasterTable extends Properties { public synchronized Object put(Object key, Object value) {
/*   53 */       Object prev = super.put(key, value);
/*   54 */       if (prev != null && SaveManager.ROOT_SEQUENCE_NUMBER_KEY.equals(key)) {
/*   55 */         int prevSeqNum = Integer.parseInt((String)prev);
/*   56 */         int currSeqNum = Integer.parseInt((String)value);
/*   57 */         if (prevSeqNum > currSeqNum) {
/*      */           
/*   59 */           super.put(key, prev);
/*      */           
/*   61 */           String message = "Cannot set lower sequence number for root (previous: " + prevSeqNum + ", new: " + currSeqNum + "). Ignoring the new value.";
/*   62 */           Policy.log((IStatus)new Status(4, "org.eclipse.core.resources", 566, message, new IllegalArgumentException(message)));
/*      */         } 
/*      */       } 
/*   65 */       return prev;
/*      */     }
/*      */     private static final long serialVersionUID = 1L; }
/*      */   
/*   69 */   protected static final String ROOT_SEQUENCE_NUMBER_KEY = Path.ROOT + ".tree";
/*      */ 
/*      */   
/*      */   protected static final String CLEAR_DELTA_PREFIX = "clearDelta_";
/*      */ 
/*      */   
/*      */   protected static final String DELTA_EXPIRATION_PREFIX = "deltaExpiration_";
/*      */ 
/*      */   
/*      */   protected static final int DONE_SAVING = 3;
/*      */ 
/*      */   
/*      */   private static final long MIN_SNAPSHOT_DELAY = 30000L;
/*      */ 
/*      */   
/*      */   protected static final int NO_OP_THRESHOLD = 20;
/*      */ 
/*      */   
/*      */   protected static final int PREPARE_TO_SAVE = 1;
/*      */ 
/*      */   
/*      */   protected static final int ROLLBACK = 4;
/*      */ 
/*      */   
/*      */   protected static final String SAVE_NUMBER_PREFIX = "saveNumber_";
/*      */   
/*      */   protected static final int SAVING = 2;
/*      */   
/*      */   protected ElementTree lastSnap;
/*      */   
/*      */   protected final MasterTable masterTable;
/*      */   
/*      */   private volatile boolean isSaving = false;
/*      */   
/*  103 */   protected int noopCount = 0;
/*      */ 
/*      */ 
/*      */   
/*  107 */   protected int operationCount = 0;
/*      */ 
/*      */   
/*  110 */   protected long persistMarkers = 0L;
/*  111 */   protected long persistSyncInfo = 0L;
/*      */ 
/*      */   
/*      */   protected Map<String, SavedState> savedStates;
/*      */ 
/*      */   
/*      */   protected Map<String, ISaveParticipant> saveParticipants;
/*      */ 
/*      */   
/*      */   protected final DelayedSnapshotJob snapshotJob;
/*      */ 
/*      */   
/*      */   protected volatile boolean snapshotRequested;
/*      */   
/*      */   private IStatus snapshotRequestor;
/*      */   
/*      */   protected Workspace workspace;
/*      */   
/*      */   private Set<Map.Entry<Object, Object>> savedState;
/*      */   
/*      */   private static final String DEBUG_START = " starting...";
/*      */   
/*      */   private static final String DEBUG_FULL_SAVE = "Full save on workspace: ";
/*      */   
/*      */   private static final String DEBUG_PROJECT_SAVE = "Save on project ";
/*      */   
/*      */   private static final String DEBUG_SNAPSHOT = "Snapshot: ";
/*      */   
/*      */   private static final int TREE_BUFFER_SIZE = 65536;
/*      */ 
/*      */   
/*      */   public SaveManager(Workspace workspace) {
/*  143 */     this.workspace = workspace;
/*  144 */     this.masterTable = new MasterTable();
/*  145 */     this.snapshotJob = new DelayedSnapshotJob(this, workspace);
/*  146 */     this.snapshotRequested = false;
/*  147 */     this.snapshotRequestor = null;
/*  148 */     this.saveParticipants = Collections.synchronizedMap(new HashMap<>(10));
/*      */   }
/*      */ 
/*      */   
/*      */   public ISavedState addParticipant(String pluginId, ISaveParticipant participant) throws CoreException {
/*  153 */     if (this.saveParticipants.put(pluginId, participant) != null)
/*  154 */       return null; 
/*  155 */     SavedState state = this.savedStates.get(pluginId);
/*  156 */     if (state != null) {
/*  157 */       if (isDeltaCleared(pluginId)) {
/*      */         
/*  159 */         state.forgetTrees();
/*  160 */         removeClearDeltaMarks(pluginId);
/*      */       } else {
/*      */ 
/*      */         
/*      */         try {
/*  165 */           this.workspace.prepareOperation(null, null);
/*  166 */           this.workspace.beginOperation(true);
/*  167 */           state.newTree = this.workspace.getElementTree();
/*      */         } finally {
/*  169 */           this.workspace.endOperation(null, false);
/*      */         } 
/*  171 */         return state;
/*      */       } 
/*      */     }
/*      */     
/*  175 */     if (getSaveNumber(pluginId) > 0)
/*  176 */       return new SavedState(this.workspace, pluginId, null, null); 
/*  177 */     return null;
/*      */   }
/*      */   
/*      */   protected void broadcastLifecycle(final int lifecycle, Map<String, SaveContext> contexts, final MultiStatus warnings, IProgressMonitor monitor) {
/*  181 */     SubMonitor subMonitor = SubMonitor.convert(monitor, contexts.size());
/*      */     try {
/*  183 */       for (final Iterator<Map.Entry<String, SaveContext>> it = contexts.entrySet().iterator(); it.hasNext(); ) {
/*  184 */         Map.Entry<String, SaveContext> entry = it.next();
/*  185 */         String pluginId = entry.getKey();
/*  186 */         final ISaveParticipant participant = this.saveParticipants.get(pluginId);
/*      */         
/*  188 */         if (participant == null) {
/*  189 */           subMonitor.worked(1);
/*      */           continue;
/*      */         } 
/*  192 */         final SaveContext context = entry.getValue();
/*      */         
/*  194 */         ISafeRunnable code = new ISafeRunnable()
/*      */           {
/*      */             public void handleException(Throwable e)
/*      */             {
/*  198 */               String message = Messages.resources_saveProblem;
/*  199 */               Status status = new Status(2, "org.eclipse.core.resources", 
/*  200 */                   566, message, e);
/*  201 */               warnings.add((IStatus)status);
/*      */ 
/*      */               
/*  204 */               it.remove();
/*      */             }
/*      */ 
/*      */             
/*      */             public void run() throws Exception {
/*  209 */               SaveManager.this.executeLifecycle(lifecycle, participant, context);
/*      */             }
/*      */           };
/*  212 */         SafeRunner.run(code);
/*  213 */         subMonitor.worked(1);
/*      */       } 
/*      */     } finally {
/*  216 */       subMonitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void clearDeltaExpiration(String pluginId) {
/*  225 */     this.masterTable.remove("deltaExpiration_" + pluginId);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void cleanMasterTable() {
/*  230 */     for (Iterator<Object> it = this.masterTable.keySet().iterator(); it.hasNext(); ) {
/*  231 */       String key = (String)it.next();
/*  232 */       if (!key.endsWith(".tree"))
/*      */         continue; 
/*  234 */       String prefix = key.substring(0, key.length() - ".tree".length());
/*      */       
/*  236 */       if (prefix.equals(Path.ROOT.toString()))
/*      */         continue; 
/*  238 */       IProject project = this.workspace.getRoot().getProject(prefix);
/*  239 */       if (!project.exists() || project.isOpen())
/*  240 */         it.remove(); 
/*      */     } 
/*  242 */     this.savedState = null;
/*  243 */     IPath location = this.workspace.getMetaArea().getSafeTableLocationFor("org.eclipse.core.resources");
/*  244 */     IPath backup = this.workspace.getMetaArea().getBackupLocationFor(location);
/*      */     try {
/*  246 */       saveMasterTable(1, backup);
/*  247 */     } catch (CoreException e) {
/*  248 */       Policy.log(e.getStatus());
/*  249 */       backup.toFile().delete();
/*      */       return;
/*      */     } 
/*  252 */     if (location.toFile().exists() && !location.toFile().delete())
/*      */       return; 
/*      */     try {
/*  255 */       saveMasterTable(1, location);
/*  256 */     } catch (CoreException e) {
/*  257 */       Policy.log(e.getStatus());
/*  258 */       location.toFile().delete();
/*      */       return;
/*      */     } 
/*  261 */     backup.toFile().delete();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void clearSavedDelta() {
/*  270 */     synchronized (this.saveParticipants) {
/*  271 */       for (String pluginId : this.saveParticipants.keySet()) {
/*  272 */         this.masterTable.setProperty("clearDelta_" + pluginId, "true");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void collapseTrees(Map<String, SaveContext> contexts) throws CoreException {
/*  285 */     synchronized (this.savedStates) {
/*  286 */       for (SaveContext context : contexts.values()) {
/*  287 */         forgetSavedTree(context.getPluginId());
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  292 */     ArrayList<ElementTree> trees = new ArrayList<>();
/*  293 */     synchronized (this.savedStates) {
/*  294 */       for (SavedState state : this.savedStates.values()) {
/*  295 */         if (state.oldTree != null) {
/*  296 */           trees.add(state.oldTree);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  302 */     IProject[] projects = this.workspace.getRoot().getProjects(8); byte b; int j; IProject[] arrayOfIProject1;
/*  303 */     for (j = (arrayOfIProject1 = projects).length, b = 0; b < j; ) { IProject project = arrayOfIProject1[b];
/*  304 */       if (project.isOpen()) {
/*  305 */         ArrayList<BuilderPersistentInfo> builderInfos = this.workspace.getBuildManager().createBuildersPersistentInfo(project);
/*  306 */         if (builderInfos != null) {
/*  307 */           for (BuilderPersistentInfo info : builderInfos) {
/*  308 */             trees.add(info.getLastBuiltTree());
/*      */           }
/*      */         }
/*      */       } 
/*      */       
/*      */       b++; }
/*      */     
/*  315 */     if (trees.isEmpty()) {
/*      */       return;
/*      */     }
/*      */     
/*  319 */     trees.add(this.workspace.getElementTree());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  324 */     ElementTree[] treeArray = new ElementTree[trees.size()];
/*  325 */     trees.toArray(treeArray);
/*  326 */     ElementTree[] sorted = sortTrees(treeArray);
/*      */ 
/*      */     
/*  329 */     if (sorted == null)
/*      */       return; 
/*  331 */     for (int i = 1; i < sorted.length; i++)
/*  332 */       sorted[i].collapseTo(sorted[i - 1]); 
/*      */   }
/*      */   
/*      */   protected void commit(Map<String, SaveContext> contexts) throws CoreException {
/*  336 */     for (SaveContext saveContext : contexts.values()) {
/*  337 */       saveContext.commit();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<String, SaveContext> computeSaveContexts(String[] pluginIds, int kind, IProject project) {
/*  346 */     HashMap<String, SaveContext> result = new HashMap<>(pluginIds.length); byte b; int i; String[] arrayOfString;
/*  347 */     for (i = (arrayOfString = pluginIds).length, b = 0; b < i; ) { String pluginId = arrayOfString[b];
/*      */       try {
/*  349 */         SaveContext context = new SaveContext(pluginId, kind, project, this.workspace);
/*  350 */         result.put(pluginId, context);
/*  351 */       } catch (CoreException e) {
/*      */         
/*  353 */         Policy.log(e.getStatus());
/*      */       }  b++; }
/*      */     
/*  356 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<String, ElementTree> computeStatesToSave(Map<String, SaveContext> contexts, ElementTree current) {
/*  368 */     HashMap<String, ElementTree> result = new HashMap<>(this.savedStates.size() * 2);
/*  369 */     synchronized (this.savedStates) {
/*  370 */       for (SavedState state : this.savedStates.values()) {
/*  371 */         if (state.oldTree != null)
/*  372 */           result.put(state.pluginId, state.oldTree); 
/*      */       } 
/*      */     } 
/*  375 */     for (SaveContext context : contexts.values()) {
/*  376 */       if (!context.isDeltaNeeded())
/*      */         continue; 
/*  378 */       String pluginId = context.getPluginId();
/*  379 */       result.put(pluginId, current);
/*      */     } 
/*  381 */     return result;
/*      */   }
/*      */   
/*      */   protected void executeLifecycle(int lifecycle, ISaveParticipant participant, SaveContext context) throws CoreException {
/*  385 */     switch (lifecycle) {
/*      */       case 1:
/*  387 */         participant.prepareToSave(context);
/*      */         return;
/*      */       case 2:
/*      */         try {
/*  391 */           if (ResourceStats.TRACE_SAVE_PARTICIPANTS)
/*  392 */             ResourceStats.startSave(participant); 
/*  393 */           participant.saving(context);
/*      */         } finally {
/*  395 */           if (ResourceStats.TRACE_SAVE_PARTICIPANTS)
/*  396 */             ResourceStats.endSave(); 
/*      */         } 
/*      */         return;
/*      */       case 3:
/*  400 */         participant.doneSaving(context);
/*      */         return;
/*      */       case 4:
/*  403 */         participant.rollback(context);
/*      */         return;
/*      */     } 
/*  406 */     Assert.isTrue(false, "Invalid save lifecycle code");
/*      */   }
/*      */ 
/*      */   
/*      */   public void forgetSavedTree(String pluginId) {
/*  411 */     if (pluginId == null) {
/*  412 */       synchronized (this.savedStates) {
/*  413 */         for (SavedState savedState : this.savedStates.values())
/*  414 */           savedState.forgetTrees(); 
/*      */       } 
/*      */     } else {
/*  417 */       SavedState state = this.savedStates.get(pluginId);
/*  418 */       if (state != null) {
/*  419 */         state.forgetTrees();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected long getDeltaExpiration(String pluginId) {
/*  427 */     String result = this.masterTable.getProperty("deltaExpiration_" + pluginId);
/*  428 */     return (result == null) ? System.currentTimeMillis() : Long.parseLong(result);
/*      */   }
/*      */   
/*      */   protected Properties getMasterTable() {
/*  432 */     return this.masterTable;
/*      */   }
/*      */   
/*      */   public int getSaveNumber(String pluginId) {
/*  436 */     String value = this.masterTable.getProperty("saveNumber_" + pluginId);
/*  437 */     return (value == null) ? 0 : Integer.parseInt(value);
/*      */   }
/*      */   
/*      */   protected String[] getSaveParticipantPluginIds() {
/*  441 */     synchronized (this.saveParticipants) {
/*  442 */       return (String[])this.saveParticipants.keySet().toArray((Object[])new String[this.saveParticipants.size()]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void hookEndSave(int kind, IProject project, long start) {
/*  451 */     if (ResourceStats.TRACE_SNAPSHOT && kind == 2)
/*  452 */       ResourceStats.endSnapshot(); 
/*  453 */     if (Policy.DEBUG_SAVE) {
/*  454 */       String endMessage = null;
/*  455 */       switch (kind) {
/*      */         case 1:
/*  457 */           endMessage = "Full save on workspace: ";
/*      */           break;
/*      */         case 2:
/*  460 */           endMessage = "Snapshot: ";
/*      */           break;
/*      */         case 3:
/*  463 */           endMessage = "Save on project " + project.getFullPath() + ": ";
/*      */           break;
/*      */       } 
/*  466 */       if (endMessage != null) {
/*  467 */         Policy.debug(String.valueOf(endMessage) + (System.currentTimeMillis() - start) + "ms");
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void hookStartSave(int kind, Project project) {
/*  476 */     if (ResourceStats.TRACE_SNAPSHOT && kind == 2)
/*  477 */       ResourceStats.startSnapshot(); 
/*  478 */     if (Policy.DEBUG_SAVE) {
/*  479 */       switch (kind) {
/*      */         case 1:
/*  481 */           Policy.debug("Full save on workspace:  starting...");
/*      */           break;
/*      */         case 2:
/*  484 */           Policy.debug("Snapshot:  starting...");
/*      */           break;
/*      */         case 3:
/*  487 */           Policy.debug("Save on project " + project.getFullPath() + " starting...");
/*      */           break;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initSnap(IProgressMonitor monitor) {
/*  498 */     this.snapshotJob.cancel();
/*      */ 
/*      */     
/*  501 */     this.lastSnap = this.workspace.getElementTree();
/*  502 */     this.lastSnap.immutable();
/*  503 */     this.workspace.newWorkingTree();
/*  504 */     this.operationCount = 0;
/*      */     
/*  506 */     IPath location = this.workspace.getMetaArea().getSnapshotLocationFor((IResource)this.workspace.getRoot());
/*  507 */     File target = location.toFile().getParentFile();
/*  508 */     FilenameFilter filter = (dir, name) -> {
/*      */         if (!name.endsWith(".snap"))
/*      */           return false; 
/*      */         for (int i = 0; i < name.length() - ".snap".length(); i++) {
/*      */           char c = name.charAt(i);
/*      */           if (c < '0' || c > '9')
/*      */             return false; 
/*      */         } 
/*      */         return true;
/*      */       };
/*  518 */     String[] candidates = target.list(filter);
/*  519 */     if (candidates != null)
/*  520 */       removeFiles(target, candidates, Collections.emptyList()); 
/*      */   }
/*      */   
/*      */   protected boolean isDeltaCleared(String pluginId) {
/*  524 */     String clearDelta = this.masterTable.getProperty("clearDelta_" + pluginId);
/*  525 */     return (clearDelta != null && clearDelta.equals("true"));
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean isOldPluginTree(String pluginId) {
/*  530 */     if (isDeltaCleared(pluginId)) {
/*  531 */       return false;
/*      */     }
/*  533 */     if (Platform.getBundle(pluginId) == null) {
/*  534 */       return true;
/*      */     }
/*      */     
/*  537 */     long deltaAge = System.currentTimeMillis() - getDeltaExpiration(pluginId);
/*  538 */     return (deltaAge > this.workspace.internalGetDescription().getDeltaExpiration());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object readElement(IPath path, DataInput input) throws IOException {
/*  546 */     Assert.isNotNull(path);
/*  547 */     Assert.isNotNull(input);
/*      */     
/*  549 */     int flags = input.readInt();
/*  550 */     int type = (flags & 0xF00) >> 8;
/*  551 */     ResourceInfo info = this.workspace.newElement(type);
/*  552 */     info.readFrom(flags, input);
/*  553 */     return info;
/*      */   }
/*      */   
/*      */   private void rememberSnapshotRequestor() {
/*  557 */     if (Policy.DEBUG_SAVE)
/*  558 */       Policy.debug(new RuntimeException("Scheduling workspace snapshot")); 
/*  559 */     if (this.snapshotRequestor == null) {
/*  560 */       String msg = "The workspace will exit with unsaved changes in this session.";
/*  561 */       this.snapshotRequestor = (IStatus)new ResourceStatus(10035, msg);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void removeClearDeltaMarks() {
/*  570 */     synchronized (this.saveParticipants) {
/*  571 */       for (String pluginId : this.saveParticipants.keySet()) {
/*  572 */         removeClearDeltaMarks(pluginId);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void removeClearDeltaMarks(String pluginId) {
/*  578 */     this.masterTable.setProperty("clearDelta_" + pluginId, "false"); } protected void removeFiles(File root, String[] candidates, List<String> exclude) {
/*      */     byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/*  582 */     for (i = (arrayOfString = candidates).length, b = 0; b < i; ) { String candidate = arrayOfString[b];
/*  583 */       boolean delete = true;
/*  584 */       for (ListIterator<String> it = exclude.listIterator(); it.hasNext(); ) {
/*  585 */         String s = it.next();
/*  586 */         if (s.equals(candidate)) {
/*  587 */           it.remove();
/*  588 */           delete = false;
/*      */           break;
/*      */         } 
/*      */       } 
/*  592 */       if (delete)
/*  593 */         (new File(root, candidate)).delete(); 
/*      */       b++; }
/*      */   
/*      */   }
/*      */   private void removeGarbage(DataOutputStream output, IPath location, IPath tempLocation) throws IOException {
/*  598 */     if (output.size() == 0) {
/*  599 */       output.close();
/*  600 */       location.toFile().delete();
/*  601 */       tempLocation.toFile().delete();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void removeParticipant(String pluginId) {
/*  606 */     this.saveParticipants.remove(pluginId);
/*      */   }
/*      */   
/*      */   protected void removeUnusedSafeTables() {
/*  610 */     List<String> valuables = new ArrayList<>(10);
/*  611 */     IPath location = this.workspace.getMetaArea().getSafeTableLocationFor("org.eclipse.core.resources");
/*  612 */     valuables.add(location.lastSegment());
/*  613 */     for (Enumeration<Object> e = this.masterTable.keys(); e.hasMoreElements(); ) {
/*  614 */       String key = (String)e.nextElement();
/*  615 */       if (key.startsWith("saveNumber_")) {
/*  616 */         String pluginId = key.substring("saveNumber_".length());
/*  617 */         valuables.add(this.workspace.getMetaArea().getSafeTableLocationFor(pluginId).lastSegment());
/*      */       } 
/*      */     } 
/*  620 */     File target = location.toFile().getParentFile();
/*  621 */     String[] candidates = target.list();
/*  622 */     if (candidates == null)
/*      */       return; 
/*  624 */     removeFiles(target, candidates, valuables);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void removeUnusedTreeFiles() {
/*  629 */     List<String> valuables = new ArrayList<>(10);
/*  630 */     IPath location = this.workspace.getMetaArea().getTreeLocationFor((IResource)this.workspace.getRoot(), false);
/*  631 */     valuables.add(location.lastSegment());
/*  632 */     File target = location.toFile().getParentFile();
/*  633 */     FilenameFilter filter = (dir, name) -> name.endsWith(".tree");
/*  634 */     String[] candidates = target.list(filter);
/*  635 */     if (candidates != null) {
/*  636 */       removeFiles(target, candidates, valuables);
/*      */     }
/*      */     
/*  639 */     IProject[] projects = this.workspace.getRoot().getProjects(8); byte b; int i; IProject[] arrayOfIProject1;
/*  640 */     for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/*  641 */       location = this.workspace.getMetaArea().getTreeLocationFor((IResource)project, false);
/*  642 */       valuables.add(location.lastSegment());
/*  643 */       target = location.toFile().getParentFile();
/*  644 */       candidates = target.list(filter);
/*  645 */       if (candidates != null)
/*  646 */         removeFiles(target, candidates, valuables); 
/*      */       b++; }
/*      */   
/*      */   }
/*      */   protected void reportSnapshotRequestor() {
/*  651 */     if (this.snapshotRequestor != null)
/*  652 */       Policy.log(this.snapshotRequestor); 
/*      */   }
/*      */   
/*      */   public void requestSnapshot() {
/*  656 */     this.snapshotRequested = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void resetSnapshots(IResource resource) throws CoreException {
/*  664 */     Assert.isLegal(!(resource.getType() != 8 && resource.getType() != 4));
/*      */ 
/*      */ 
/*      */     
/*  668 */     File file = this.workspace.getMetaArea().getMarkersSnapshotLocationFor(resource).toFile();
/*  669 */     if (file.exists())
/*  670 */       file.delete(); 
/*  671 */     if (file.exists()) {
/*  672 */       String message = Messages.resources_resetMarkers;
/*  673 */       throw new ResourceException(569, resource.getFullPath(), message, null);
/*      */     } 
/*      */ 
/*      */     
/*  677 */     file = this.workspace.getMetaArea().getSyncInfoSnapshotLocationFor(resource).toFile();
/*  678 */     if (file.exists())
/*  679 */       file.delete(); 
/*  680 */     if (file.exists()) {
/*  681 */       String message = Messages.resources_resetSync;
/*  682 */       throw new ResourceException(569, resource.getFullPath(), message, null);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  687 */     if (resource.getType() == 4)
/*      */       return; 
/*  689 */     IProject[] projects = ((IWorkspaceRoot)resource).getProjects(8); byte b; int i; IProject[] arrayOfIProject1;
/*  690 */     for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/*  691 */       resetSnapshots((IResource)project);
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void restore(IProgressMonitor monitor) throws CoreException {
/*  699 */     if (Policy.DEBUG_RESTORE)
/*  700 */       Policy.debug("Restore workspace: starting..."); 
/*  701 */     long start = System.currentTimeMillis();
/*  702 */     monitor = Policy.monitorFor(monitor);
/*      */     try {
/*  704 */       monitor.beginTask("", 50);
/*      */ 
/*      */       
/*  707 */       this.workspace.newWorkingTree();
/*      */       try {
/*  709 */         String msg = Messages.resources_startupProblems;
/*  710 */         MultiStatus problems = new MultiStatus("org.eclipse.core.resources", 567, msg, null);
/*      */         
/*  712 */         restoreMasterTable();
/*      */         
/*  714 */         restoreTree(Policy.subMonitorFor(monitor, 10));
/*  715 */         restoreSnapshots(Policy.subMonitorFor(monitor, 10));
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  720 */           restoreMarkers((IResource)this.workspace.getRoot(), false, Policy.subMonitorFor(monitor, 10));
/*  721 */         } catch (CoreException e) {
/*  722 */           problems.merge(e.getStatus());
/*      */         } 
/*      */         try {
/*  725 */           restoreSyncInfo((IResource)this.workspace.getRoot(), Policy.subMonitorFor(monitor, 10));
/*  726 */         } catch (CoreException e) {
/*  727 */           problems.merge(e.getStatus());
/*      */         } 
/*      */         
/*  730 */         restoreMetaInfo(problems, Policy.subMonitorFor(monitor, 10));
/*  731 */         IProject[] roots = this.workspace.getRoot().getProjects(8); byte b; int i; IProject[] arrayOfIProject1;
/*  732 */         for (i = (arrayOfIProject1 = roots).length, b = 0; b < i; ) { IProject root = arrayOfIProject1[b];
/*  733 */           ((Project)root).startup(); b++; }
/*  734 */          if (!problems.isOK())
/*  735 */           Policy.log((IStatus)problems); 
/*      */       } finally {
/*  737 */         this.workspace.getElementTree().immutable();
/*      */       } 
/*      */     } finally {
/*  740 */       monitor.done();
/*      */     } 
/*  742 */     if (Policy.DEBUG_RESTORE) {
/*  743 */       Policy.debug("Restore workspace: " + (System.currentTimeMillis() - start) + "ms");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean restore(Project project, IProgressMonitor monitor) throws CoreException {
/*  754 */     boolean status = true;
/*  755 */     if (Policy.DEBUG_RESTORE)
/*  756 */       Policy.debug("Restore project " + project.getFullPath() + ": starting..."); 
/*  757 */     long start = System.currentTimeMillis();
/*  758 */     monitor = Policy.monitorFor(monitor);
/*      */     try {
/*  760 */       monitor.beginTask("", 40);
/*  761 */       if (project.isOpen()) {
/*  762 */         status = restoreTree(project, Policy.subMonitorFor(monitor, 10));
/*      */       } else {
/*  764 */         monitor.worked(10);
/*      */       } 
/*  766 */       restoreMarkers(project, true, Policy.subMonitorFor(monitor, 10));
/*  767 */       restoreSyncInfo(project, Policy.subMonitorFor(monitor, 10));
/*      */       
/*  769 */       restoreMetaInfo(project, Policy.subMonitorFor(monitor, 10));
/*      */     } finally {
/*  771 */       monitor.done();
/*      */     } 
/*  773 */     if (Policy.DEBUG_RESTORE)
/*  774 */       Policy.debug("Restore project " + project.getFullPath() + ": " + (System.currentTimeMillis() - start) + "ms"); 
/*  775 */     return status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean restoreFromRefreshSnapshot(Project project, IProgressMonitor monitor) throws CoreException {
/*  787 */     boolean status = true;
/*  788 */     IPath snapshotPath = this.workspace.getMetaArea().getRefreshLocationFor(project);
/*  789 */     File snapshotFile = snapshotPath.toFile();
/*  790 */     if (!snapshotFile.exists())
/*  791 */       return false; 
/*  792 */     if (Policy.DEBUG_RESTORE)
/*  793 */       Policy.debug("Restore project " + project.getFullPath() + ": starting..."); 
/*  794 */     long start = System.currentTimeMillis();
/*  795 */     monitor = Policy.monitorFor(monitor);
/*      */     try {
/*  797 */       monitor.beginTask("", 40);
/*  798 */       status = restoreTreeFromRefreshSnapshot(project, snapshotFile, Policy.subMonitorFor(monitor, 40));
/*  799 */       if (status) {
/*      */         
/*  801 */         ProjectDescription description = this.workspace.getFileSystemManager().read(project, true);
/*  802 */         project.internalSetDescription(description, false);
/*  803 */         this.workspace.getMetaArea().clearRefresh(project);
/*      */       } 
/*      */     } finally {
/*  806 */       monitor.done();
/*      */     } 
/*  808 */     if (Policy.DEBUG_RESTORE)
/*  809 */       Policy.debug("Restore project " + project.getFullPath() + ": " + (System.currentTimeMillis() - start) + "ms"); 
/*  810 */     return status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void restoreMarkers(IResource resource, boolean generateDeltas, IProgressMonitor monitor) throws CoreException {
/*  818 */     Assert.isLegal(!(resource.getType() != 8 && resource.getType() != 4));
/*  819 */     long start = System.currentTimeMillis();
/*  820 */     MarkerManager markerManager = this.workspace.getMarkerManager();
/*      */     
/*  822 */     if (resource.isAccessible()) {
/*  823 */       markerManager.restore(resource, generateDeltas, monitor);
/*      */     }
/*      */     
/*  826 */     if (resource.getType() == 4) {
/*  827 */       if (Policy.DEBUG_RESTORE_MARKERS) {
/*  828 */         Policy.debug("Restore Markers for " + resource.getFullPath() + ": " + (System.currentTimeMillis() - start) + "ms");
/*      */       }
/*      */       return;
/*      */     } 
/*  832 */     IProject[] projects = ((IWorkspaceRoot)resource).getProjects(8); byte b; int i; IProject[] arrayOfIProject1;
/*  833 */     for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/*  834 */       if (project.isAccessible())
/*  835 */         markerManager.restore((IResource)project, generateDeltas, monitor);  b++; }
/*  836 */      if (Policy.DEBUG_RESTORE_MARKERS) {
/*  837 */       Policy.debug("Restore Markers for workspace: " + (System.currentTimeMillis() - start) + "ms");
/*      */     }
/*      */   }
/*      */   
/*      */   protected void restoreMasterTable() throws CoreException {
/*  842 */     long start = System.currentTimeMillis();
/*  843 */     this.masterTable.clear();
/*  844 */     IPath location = this.workspace.getMetaArea().getSafeTableLocationFor("org.eclipse.core.resources");
/*  845 */     File target = location.toFile();
/*  846 */     if (!target.exists()) {
/*  847 */       location = this.workspace.getMetaArea().getBackupLocationFor(location);
/*  848 */       target = location.toFile();
/*  849 */       if (!target.exists())
/*      */         return; 
/*      */     }  try {
/*  852 */       Exception exception2, exception1 = null;
/*      */     }
/*  854 */     catch (IOException e) {
/*  855 */       String message = Messages.resources_exMasterTable;
/*  856 */       throw new ResourceException(566, null, message, e);
/*      */     } 
/*  858 */     if (Policy.DEBUG_RESTORE_MASTERTABLE) {
/*  859 */       Policy.debug("Restore master table for " + location + ": " + (System.currentTimeMillis() - start) + "ms");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void restoreMetaInfo(MultiStatus problems, IProgressMonitor monitor) {
/*  867 */     if (Policy.DEBUG_RESTORE_METAINFO)
/*  868 */       Policy.debug("Restore workspace metainfo: starting..."); 
/*  869 */     long start = System.currentTimeMillis();
/*  870 */     IProject[] roots = this.workspace.getRoot().getProjects(8); byte b; int i; IProject[] arrayOfIProject1;
/*  871 */     for (i = (arrayOfIProject1 = roots).length, b = 0; b < i; ) { IProject root = arrayOfIProject1[b];
/*      */       
/*      */       try {
/*  874 */         restoreMetaInfo((Project)root, monitor);
/*  875 */       } catch (CoreException e) {
/*  876 */         String message = NLS.bind(Messages.resources_readMeta, root.getName());
/*  877 */         problems.merge((IStatus)new ResourceStatus(567, root.getFullPath(), message, (Throwable)e));
/*      */       }  b++; }
/*      */     
/*  880 */     if (Policy.DEBUG_RESTORE_METAINFO) {
/*  881 */       Policy.debug("Restore workspace metainfo: " + (System.currentTimeMillis() - start) + "ms");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void restoreMetaInfo(Project project, IProgressMonitor monitor) throws CoreException {
/*  889 */     long start = System.currentTimeMillis();
/*  890 */     ProjectDescription description = null;
/*  891 */     CoreException failure = null;
/*      */     try {
/*  893 */       if (project.isOpen())
/*  894 */       { description = this.workspace.getFileSystemManager().read(project, true); }
/*      */       
/*      */       else
/*      */       
/*  898 */       { description = this.workspace.getMetaArea().readOldDescription(project); } 
/*  899 */     } catch (CoreException e) {
/*  900 */       failure = e;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  905 */     if (description == null) {
/*  906 */       description = new ProjectDescription();
/*  907 */       description.setName(project.getName());
/*      */       
/*  909 */       this.workspace.getMetaArea().readPrivateDescription(project, description);
/*      */     } 
/*  911 */     project.internalSetDescription(description, false);
/*  912 */     if (failure != null) {
/*      */       
/*      */       try {
/*  915 */         writeTree(project, 2);
/*      */       } finally {
/*      */         
/*  918 */         project.internalClose(monitor);
/*      */       } 
/*  920 */       throw failure;
/*      */     } 
/*  922 */     if (Policy.DEBUG_RESTORE_METAINFO) {
/*  923 */       Policy.debug("Restore metainfo for " + project.getFullPath() + ": " + (System.currentTimeMillis() - start) + "ms");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void restoreSnapshots(IProgressMonitor monitor) {
/*  934 */     long start = System.currentTimeMillis();
/*  935 */     monitor = Policy.monitorFor(monitor);
/*      */     
/*      */     try {
/*  938 */       monitor.beginTask("", 100);
/*  939 */       IPath snapLocation = this.workspace.getMetaArea().getSnapshotLocationFor((IResource)this.workspace.getRoot());
/*  940 */       File localFile = snapLocation.toFile();
/*      */       
/*  942 */       if (!localFile.exists()) {
/*      */ 
/*      */ 
/*      */         
/*  946 */         snapLocation = this.workspace.getMetaArea().getLegacySnapshotLocationFor((IResource)this.workspace.getRoot());
/*  947 */         localFile = snapLocation.toFile();
/*  948 */         if (!localFile.exists() || isSnapshotOlderThanTree(localFile)) {
/*      */ 
/*      */           
/*  951 */           initSnap(Policy.subMonitorFor(monitor, 50));
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*  956 */       this.workspace.setCrashed(true);
/*      */       
/*      */       try {
/*  959 */         ElementTree complete = this.workspace.getElementTree();
/*  960 */         complete.immutable(); try {
/*  961 */           Exception exception2, exception1 = null;
/*      */ 
/*      */         
/*      */         }
/*      */         finally {
/*      */ 
/*      */ 
/*      */           
/*  969 */           this.lastSnap = complete;
/*  970 */           complete = complete.newEmptyDelta();
/*  971 */           this.workspace.tree = complete;
/*      */         } 
/*  973 */       } catch (Exception e) {
/*      */         
/*  975 */         String message = Messages.resources_snapRead;
/*  976 */         Policy.log((IStatus)new ResourceStatus(567, null, message, e));
/*      */       } 
/*      */     } finally {
/*  979 */       monitor.done();
/*      */     } 
/*  981 */     if (Policy.DEBUG_RESTORE_SNAPSHOTS) {
/*  982 */       Policy.debug("Restore snapshots for workspace: " + (System.currentTimeMillis() - start) + "ms");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isSnapshotOlderThanTree(File snapshot) {
/*  993 */     IPath treeLocation = this.workspace.getMetaArea().getTreeLocationFor((IResource)this.workspace.getRoot(), false);
/*  994 */     File tree = treeLocation.toFile();
/*  995 */     if (!tree.exists()) {
/*  996 */       treeLocation = this.workspace.getMetaArea().getBackupLocationFor(treeLocation);
/*  997 */       tree = treeLocation.toFile();
/*  998 */       if (!tree.exists())
/*  999 */         return false; 
/*      */     } 
/* 1001 */     return (snapshot.lastModified() < tree.lastModified());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void restoreSyncInfo(IResource resource, IProgressMonitor monitor) throws CoreException {
/* 1009 */     Assert.isLegal(!(resource.getType() != 8 && resource.getType() != 4));
/* 1010 */     long start = System.currentTimeMillis();
/* 1011 */     Synchronizer synchronizer = (Synchronizer)this.workspace.getSynchronizer();
/*      */     
/* 1013 */     if (resource.isAccessible()) {
/* 1014 */       synchronizer.restore(resource, monitor);
/*      */     }
/*      */     
/* 1017 */     if (resource.getType() == 4) {
/* 1018 */       if (Policy.DEBUG_RESTORE_SYNCINFO) {
/* 1019 */         Policy.debug("Restore SyncInfo for " + resource.getFullPath() + ": " + (System.currentTimeMillis() - start) + "ms");
/*      */       }
/*      */       return;
/*      */     } 
/* 1023 */     IProject[] projects = ((IWorkspaceRoot)resource).getProjects(8); byte b; int i; IProject[] arrayOfIProject1;
/* 1024 */     for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/* 1025 */       if (project.isAccessible())
/* 1026 */         synchronizer.restore((IResource)project, monitor);  b++; }
/* 1027 */      if (Policy.DEBUG_RESTORE_SYNCINFO) {
/* 1028 */       Policy.debug("Restore SyncInfo for workspace: " + (System.currentTimeMillis() - start) + "ms");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void restoreTree(IProgressMonitor monitor) throws CoreException {
/* 1039 */     long start = System.currentTimeMillis();
/* 1040 */     IPath treeLocation = this.workspace.getMetaArea().getTreeLocationFor((IResource)this.workspace.getRoot(), false);
/* 1041 */     IPath tempLocation = this.workspace.getMetaArea().getBackupLocationFor(treeLocation);
/* 1042 */     if (!treeLocation.toFile().exists() && !tempLocation.toFile().exists()) {
/* 1043 */       this.savedStates = Collections.synchronizedMap(new HashMap<>(10)); return;
/*      */     } 
/*      */     try {
/* 1046 */       Exception exception2, exception1 = null;
/*      */     }
/* 1048 */     catch (Exception e) {
/* 1049 */       String msg = NLS.bind(Messages.resources_readMeta, treeLocation.toOSString());
/* 1050 */       throw new ResourceException(567, treeLocation, msg, e);
/*      */     } 
/* 1052 */     if (Policy.DEBUG_RESTORE_TREE) {
/* 1053 */       Policy.debug("Restore Tree for workspace: " + (System.currentTimeMillis() - start) + "ms");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean restoreTree(Project project, IProgressMonitor monitor) throws CoreException {
/* 1067 */     long start = System.currentTimeMillis();
/* 1068 */     monitor = Policy.monitorFor(monitor);
/*      */     try {
/*      */       Exception exception2;
/* 1071 */       monitor.beginTask("", 100);
/* 1072 */       IPath treeLocation = this.workspace.getMetaArea().getTreeLocationFor(project, false);
/* 1073 */       IPath tempLocation = this.workspace.getMetaArea().getBackupLocationFor(treeLocation);
/* 1074 */       if (!treeLocation.toFile().exists() && !tempLocation.toFile().exists())
/* 1075 */         return false; 
/* 1076 */       Exception exception1 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1082 */     catch (IOException e) {
/* 1083 */       String message = NLS.bind(Messages.resources_readMeta, project.getFullPath());
/* 1084 */       throw new ResourceException(567, project.getFullPath(), message, e);
/*      */     } finally {
/* 1086 */       monitor.done();
/*      */     } 
/* 1088 */     if (Policy.DEBUG_RESTORE_TREE) {
/* 1089 */       Policy.debug("Restore Tree for " + project.getFullPath() + ": " + (System.currentTimeMillis() - start) + "ms");
/*      */     }
/* 1091 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean restoreTreeFromRefreshSnapshot(Project project, File snapshotFile, IProgressMonitor monitor) throws CoreException {
/* 1100 */     long start = System.currentTimeMillis();
/* 1101 */     monitor = Policy.monitorFor(monitor);
/*      */     
/* 1103 */     IPath snapshotPath = null;
/*      */     try {
/* 1105 */       monitor.beginTask("", 100);
/* 1106 */       InputStream snapIn = new FileInputStream(snapshotFile);
/* 1107 */       ZipInputStream zip = new ZipInputStream(snapIn);
/* 1108 */       ZipEntry treeEntry = zip.getNextEntry();
/* 1109 */       if (treeEntry == null || !treeEntry.getName().equals("resource-index.tree")) {
/* 1110 */         zip.close();
/* 1111 */         return false;
/*      */       }  try {
/* 1113 */         Exception exception2, exception1 = null;
/*      */       
/*      */       }
/*      */       finally {
/*      */ 
/*      */         
/* 1119 */         zip.close();
/*      */       } 
/* 1121 */     } catch (IOException e) {
/* 1122 */       Path path = new Path(snapshotFile.getPath());
/* 1123 */       String message = NLS.bind(Messages.resources_readMeta, path);
/* 1124 */       throw new ResourceException(567, path, message, e);
/*      */     } finally {
/* 1126 */       monitor.done();
/*      */     } 
/* 1128 */     if (Policy.DEBUG_RESTORE_TREE) {
/* 1129 */       Policy.debug("Restore Tree for " + project.getFullPath() + ": " + (System.currentTimeMillis() - start) + "ms");
/*      */     }
/* 1131 */     return true;
/*      */   }
/*      */   
/*      */   class InternalMonitorWrapper extends ProgressMonitorWrapper {
/*      */     private boolean ignoreCancel;
/*      */     
/*      */     public InternalMonitorWrapper(IProgressMonitor monitor) {
/* 1138 */       super((IProgressMonitor)SubMonitor.convert(monitor));
/*      */     }
/*      */     
/*      */     public void ignoreCancelState(boolean ignore) {
/* 1142 */       this.ignoreCancel = ignore;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isCanceled() {
/* 1147 */       return this.ignoreCancel ? false : super.isCanceled();
/*      */     }
/*      */   }
/*      */   
/*      */   public IStatus save(int kind, Project project, IProgressMonitor monitor) throws CoreException {
/* 1152 */     return save(kind, false, project, monitor);
/*      */   }
/*      */   
/*      */   public IStatus save(int kind, boolean keepConsistencyWhenCanceled, Project project, IProgressMonitor parentMonitor) throws CoreException {
/* 1156 */     InternalMonitorWrapper monitor = new InternalMonitorWrapper(parentMonitor);
/* 1157 */     monitor.ignoreCancelState(keepConsistencyWhenCanceled);
/*      */     try {
/* 1159 */       this.isSaving = true;
/* 1160 */       String message = Messages.resources_saving_0;
/* 1161 */       monitor.beginTask(message, 7);
/* 1162 */       message = Messages.resources_saveWarnings;
/* 1163 */       MultiStatus warnings = new MultiStatus("org.eclipse.core.resources", 2, message, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1258 */       this.isSaving = false;
/* 1259 */       monitor.done();
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void saveMasterTable(int kind) throws CoreException {
/* 1264 */     Set<Map.Entry<Object, Object>> state = Set.copyOf(getMasterTable().entrySet());
/* 1265 */     if (Objects.equals(state, this.savedState)) {
/*      */       return;
/*      */     }
/* 1268 */     saveMasterTable(kind, this.workspace.getMetaArea().getSafeTableLocationFor("org.eclipse.core.resources"));
/* 1269 */     this.savedState = state;
/*      */   }
/*      */   
/*      */   protected void saveMasterTable(int kind, IPath location) throws CoreException {
/* 1273 */     long start = System.currentTimeMillis();
/* 1274 */     File target = location.toFile(); try {
/*      */       Exception exception2;
/* 1276 */       if (kind == 1 || kind == 2)
/* 1277 */         validateMasterTableBeforeSave(target); 
/* 1278 */       Exception exception1 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1284 */     catch (IOException e) {
/* 1285 */       throw new ResourceException(566, null, NLS.bind(Messages.resources_exSaveMaster, location.toOSString()), e);
/*      */     } 
/* 1287 */     if (Policy.DEBUG_SAVE_MASTERTABLE) {
/* 1288 */       Policy.debug("Save master table for " + location + ": " + (System.currentTimeMillis() - start) + "ms");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void saveMetaInfo(MultiStatus problems, IProgressMonitor monitor) throws CoreException {
/* 1296 */     if (Policy.DEBUG_SAVE_METAINFO)
/* 1297 */       Policy.debug("Save workspace metainfo: starting..."); 
/* 1298 */     long start = System.currentTimeMillis();
/*      */     
/* 1300 */     ResourcesPlugin.getPlugin().savePluginPreferences();
/*      */     
/* 1302 */     IProject[] roots = this.workspace.getRoot().getProjects(8); byte b; int i; IProject[] arrayOfIProject1;
/* 1303 */     for (i = (arrayOfIProject1 = roots).length, b = 0; b < i; ) { IProject root = arrayOfIProject1[b];
/* 1304 */       if (root.isAccessible()) {
/* 1305 */         IStatus result = saveMetaInfo((Project)root, (IProgressMonitor)null);
/* 1306 */         if (!result.isOK())
/* 1307 */           problems.merge(result); 
/*      */       }  b++; }
/* 1309 */      if (Policy.DEBUG_SAVE_METAINFO) {
/* 1310 */       Policy.debug("Save workspace metainfo: " + (System.currentTimeMillis() - start) + "ms");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IStatus saveMetaInfo(Project project, IProgressMonitor monitor) throws CoreException {
/* 1321 */     long start = System.currentTimeMillis();
/*      */     
/* 1323 */     if (!this.workspace.getFileSystemManager().hasSavedDescription(project)) {
/* 1324 */       this.workspace.getFileSystemManager().writeSilently(project);
/* 1325 */       String msg = NLS.bind(Messages.resources_missingProjectMetaRepaired, project.getName());
/* 1326 */       return (IStatus)new ResourceStatus(234, project.getFullPath(), msg);
/*      */     } 
/* 1328 */     if (Policy.DEBUG_SAVE_METAINFO)
/* 1329 */       Policy.debug("Save metainfo for " + project.getFullPath() + ": " + (System.currentTimeMillis() - start) + "ms"); 
/* 1330 */     return Status.OK_STATUS;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void saveRefreshSnapshot(Project project, URI snapshotLocation, IProgressMonitor monitor) throws CoreException {
/* 1341 */     IFileStore store = EFS.getStore(snapshotLocation);
/* 1342 */     Path path = new Path(snapshotLocation.getPath());
/* 1343 */     File tmpTree = null;
/*      */     try {
/* 1345 */       tmpTree = File.createTempFile("tmp", ".tree");
/* 1346 */     } catch (IOException e) {
/* 1347 */       throw new ResourceException(272, path, Messages.resources_copyProblem, e);
/*      */     } 
/* 1349 */     ZipOutputStream out = null; try {
/*      */       OutputStream snapOut;
/* 1351 */       FileOutputStream fis = new FileOutputStream(tmpTree);
/* 1352 */       Exception exception1 = null, exception2 = null; 
/* 1353 */       try { DataOutputStream output = new DataOutputStream(fis);
/*      */         
/* 1355 */         try { output.writeInt(67305986);
/* 1356 */           writeTree(project, output, monitor); }
/* 1357 */         finally { if (output != null) output.close();  }  } finally { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }
/*      */          }
/*      */       
/* 1360 */       out.setLevel(9);
/* 1361 */       ZipEntry e = new ZipEntry("resource-index.tree");
/* 1362 */       out.putNextEntry(e);
/* 1363 */       int read = 0;
/* 1364 */       byte[] buffer = new byte[4096];
/* 1365 */       Exception exception3 = null, exception4 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1374 */     catch (IOException e) {
/* 1375 */       throw new ResourceException(272, path, Messages.resources_copyProblem, e);
/*      */     } finally {
/* 1377 */       FileUtil.safeClose(out);
/* 1378 */       if (tmpTree != null) {
/* 1379 */         tmpTree.delete();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void saveTree(Map<String, SaveContext> contexts, IProgressMonitor monitor) throws CoreException {
/* 1390 */     long start = System.currentTimeMillis();
/* 1391 */     IPath treeLocation = this.workspace.getMetaArea().getTreeLocationFor((IResource)this.workspace.getRoot(), true); try {
/*      */       Exception exception2;
/* 1393 */       IPath tempLocation = this.workspace.getMetaArea().getBackupLocationFor(treeLocation);
/* 1394 */       Exception exception1 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1400 */     catch (Exception e) {
/* 1401 */       String msg = NLS.bind(Messages.resources_writeWorkspaceMeta, treeLocation);
/* 1402 */       throw new ResourceException(568, Path.ROOT, msg, e);
/*      */     } 
/* 1404 */     if (Policy.DEBUG_SAVE_TREE) {
/* 1405 */       Policy.debug("Save Workspace Tree: " + (System.currentTimeMillis() - start) + "ms");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void setPluginsSavedState(HashMap<String, SavedState> savedStates) {
/* 1412 */     this.savedStates = Collections.synchronizedMap(savedStates);
/*      */   }
/*      */   
/*      */   protected void setSaveNumber(String pluginId, int number) {
/* 1416 */     this.masterTable.setProperty("saveNumber_" + pluginId, Integer.toString(number));
/*      */   }
/*      */ 
/*      */   
/*      */   public void shareStrings(StringPool pool) {
/* 1421 */     this.lastSnap.shareStrings(pool);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void shutdown(IProgressMonitor monitor) {
/* 1429 */     int state = this.snapshotJob.getState();
/* 1430 */     if (state == 2 || state == 1)
/*      */     {
/* 1432 */       this.snapshotJob.run((IProgressMonitor)SubMonitor.convert(monitor));
/*      */     }
/* 1434 */     this.snapshotJob.cancel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void snapshotIfNeeded(boolean hasTreeChanges) {
/* 1444 */     if (this.isSaving)
/*      */       return; 
/* 1446 */     if (this.snapshotRequested || this.operationCount >= this.workspace.internalGetDescription().getOperationsPerSnapshot()) {
/* 1447 */       rememberSnapshotRequestor();
/* 1448 */       if (this.snapshotJob.getState() == 0) {
/* 1449 */         this.snapshotJob.schedule();
/*      */       } else {
/* 1451 */         this.snapshotJob.wakeUp();
/*      */       } 
/* 1453 */     } else if (hasTreeChanges) {
/* 1454 */       this.operationCount++;
/* 1455 */       if (this.snapshotJob.getState() == 0) {
/* 1456 */         rememberSnapshotRequestor();
/* 1457 */         long interval = this.workspace.internalGetDescription().getSnapshotInterval();
/* 1458 */         this.snapshotJob.schedule(Math.max(interval, 30000L));
/*      */       }
/*      */     
/*      */     }
/* 1462 */     else if (++this.noopCount > 20) {
/* 1463 */       this.operationCount++;
/* 1464 */       this.noopCount = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void snapTree(ElementTree tree, IProgressMonitor monitor) throws CoreException {
/* 1474 */     long start = System.currentTimeMillis();
/*      */     
/* 1476 */     SubMonitor subMonitor = SubMonitor.convert(monitor, 100);
/*      */     
/*      */     try {
/* 1479 */       tree.immutable();
/*      */       
/* 1481 */       if (tree == this.lastSnap)
/*      */         return; 
/* 1483 */       this.operationCount = 0;
/* 1484 */       IPath snapPath = this.workspace.getMetaArea().getSnapshotLocationFor((IResource)this.workspace.getRoot());
/* 1485 */       ElementTreeWriter writer = new ElementTreeWriter(this);
/* 1486 */       File localFile = snapPath.toFile(); try {
/*      */         Exception exception2;
/* 1488 */         SafeChunkyOutputStream safeStream = new SafeChunkyOutputStream(localFile);
/* 1489 */         Exception exception1 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1497 */       catch (IOException e) {
/* 1498 */         String message = NLS.bind(Messages.resources_writeWorkspaceMeta, localFile.getAbsolutePath());
/* 1499 */         throw new ResourceException(568, Path.ROOT, message, e);
/*      */       } 
/* 1501 */       this.lastSnap = tree;
/* 1502 */       if (Policy.DEBUG_SAVE_TREE)
/* 1503 */         Policy.debug("Snapshot Workspace Tree: " + (System.currentTimeMillis() - start) + "ms"); 
/*      */     } finally {
/* 1505 */       subMonitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ElementTree[] sortTrees(ElementTree[] trees) {
/* 1527 */     int numTrees = trees.length;
/* 1528 */     ElementTree[] sorted = new ElementTree[numTrees];
/*      */ 
/*      */     
/* 1531 */     Map<ElementTree, Integer> duplicateCount = new LinkedHashMap<>(numTrees * 2 + 1); byte b; int j; ElementTree[] arrayOfElementTree1;
/* 1532 */     for (j = (arrayOfElementTree1 = trees).length, b = 0; b < j; ) { ElementTree tree = arrayOfElementTree1[b];
/* 1533 */       duplicateCount.compute(tree, (k, duplicates) -> Integer.valueOf(((duplicates == null) ? 0 : duplicates.intValue()) + 1));
/*      */       
/*      */       b++; }
/*      */     
/* 1537 */     ElementTree oldest = trees[ElementTree.findOldest(trees)];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1543 */     int i = numTrees - 1;
/* 1544 */     while (oldest != null) {
/*      */       
/* 1546 */       Integer duplicates = duplicateCount.remove(oldest);
/* 1547 */       for (int k = 0; k < duplicates.intValue(); k++) {
/* 1548 */         sorted[i] = oldest;
/* 1549 */         i--;
/*      */       } 
/*      */       
/* 1552 */       oldest = oldest.getParent();
/* 1553 */       while (oldest != null && duplicateCount.get(oldest) == null)
/*      */       {
/* 1555 */         oldest = oldest.getParent();
/*      */       }
/*      */     } 
/* 1558 */     if (!duplicateCount.isEmpty()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1565 */       Exception e = new NullPointerException(
/* 1566 */           "Unable to save workspace - Given trees not in unambiguous order (Bug 352867)");
/* 1567 */       Status status = new Status(2, "org.eclipse.core.resources", 566, 
/* 1568 */           e.getMessage(), e);
/* 1569 */       Policy.log((IStatus)status);
/* 1570 */       return null;
/*      */     } 
/* 1572 */     return sorted;
/*      */   }
/*      */   
/*      */   static String parentChain(ElementTree e) {
/* 1576 */     ArrayList<ElementTree> chain = new ArrayList<>();
/* 1577 */     ElementTree el = e;
/* 1578 */     while (el != null) {
/* 1579 */       chain.add(el);
/* 1580 */       el = el.getParent();
/*      */     } 
/* 1582 */     return chain.stream().map(t -> t.getTreeStamp()).collect(Collectors.joining("->"));
/*      */   }
/*      */ 
/*      */   
/*      */   public void startup(IProgressMonitor monitor) throws CoreException {
/* 1587 */     restore(monitor);
/* 1588 */     File table = this.workspace.getMetaArea().getSafeTableLocationFor("org.eclipse.core.resources").toFile();
/* 1589 */     if (!table.exists()) {
/* 1590 */       table.getParentFile().mkdirs();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateDeltaExpiration(String pluginId) {
/* 1602 */     String key = "deltaExpiration_" + pluginId;
/* 1603 */     if (!this.masterTable.containsKey(key))
/* 1604 */       this.masterTable.setProperty(key, Long.toString(System.currentTimeMillis())); 
/*      */   }
/*      */   
/*      */   private void validateMasterTableBeforeSave(File target) throws IOException {
/* 1608 */     if (target.exists()) {
/* 1609 */       Exception exception2; MasterTable previousMasterTable = new MasterTable();
/* 1610 */       Exception exception1 = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getBadSequenceNumberErrorMessage(File target, int valueInFile, int valueInMemory) {
/* 1631 */     StringBuilder messageBuffer = new StringBuilder();
/* 1632 */     messageBuffer.append("Cannot set lower sequence number for root (previous: ");
/* 1633 */     messageBuffer.append(valueInFile);
/* 1634 */     messageBuffer.append(", new: ");
/* 1635 */     messageBuffer.append(valueInMemory);
/* 1636 */     messageBuffer.append("). Location: ");
/* 1637 */     messageBuffer.append(target.getAbsolutePath());
/*      */     try {
/* 1639 */       messageBuffer.append("Timestamps and tree sequence numbers from file:");
/* 1640 */       Path targetPath = Paths.get(target.getAbsolutePath(), new String[0]);
/* 1641 */       List<String> masterTableFileContents = Files.readAllLines(targetPath, Charset.defaultCharset());
/* 1642 */       for (String line : masterTableFileContents) {
/* 1643 */         if (line != null) {
/* 1644 */           boolean isPropertiesTimestamp = line.startsWith("#");
/* 1645 */           boolean isTreeProperty = line.startsWith(ROOT_SEQUENCE_NUMBER_KEY);
/* 1646 */           if (isPropertiesTimestamp || isTreeProperty) {
/* 1647 */             messageBuffer.append(System.lineSeparator());
/* 1648 */             messageBuffer.append(line);
/*      */           } 
/*      */         } 
/*      */       } 
/* 1652 */     } catch (IOException e) {
/* 1653 */       ILog log = ResourcesPlugin.getPlugin().getLog();
/* 1654 */       String errorMessage = "Error occurred while reading master table file";
/* 1655 */       Status status = new Status(4, "org.eclipse.core.resources", errorMessage, e);
/* 1656 */       log.log((IStatus)status);
/*      */     } 
/* 1658 */     return messageBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitAndSave(IResource root) throws CoreException {
/*      */     IStatus[] stats;
/* 1669 */     Assert.isLegal(!(root.getType() != 8 && root.getType() != 4));
/*      */     
/* 1671 */     if (!root.isAccessible()) {
/*      */       return;
/*      */     }
/*      */     
/* 1675 */     Synchronizer synchronizer = (Synchronizer)this.workspace.getSynchronizer();
/* 1676 */     MarkerManager markerManager = this.workspace.getMarkerManager();
/* 1677 */     IPath markersLocation = this.workspace.getMetaArea().getMarkersLocationFor(root);
/* 1678 */     IPath markersTempLocation = this.workspace.getMetaArea().getBackupLocationFor(markersLocation);
/* 1679 */     IPath syncInfoLocation = this.workspace.getMetaArea().getSyncInfoLocationFor(root);
/* 1680 */     IPath syncInfoTempLocation = this.workspace.getMetaArea().getBackupLocationFor(syncInfoLocation);
/* 1681 */     List<String> writtenTypes = new ArrayList<>(5);
/* 1682 */     List<QualifiedName> writtenPartners = new ArrayList<>(synchronizer.registry.size());
/* 1683 */     DataOutputStream o1 = null;
/* 1684 */     DataOutputStream o2 = null;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1689 */       o1 = new DataOutputStream((OutputStream)new SafeFileOutputStream(markersLocation.toOSString(), markersTempLocation.toOSString()));
/*      */ 
/*      */       
/* 1692 */       if (root.getType() != 8)
/* 1693 */         o2 = new DataOutputStream((OutputStream)new SafeFileOutputStream(syncInfoLocation.toOSString(), syncInfoTempLocation.toOSString())); 
/* 1694 */     } catch (IOException e) {
/* 1695 */       FileUtil.safeClose(o1);
/* 1696 */       FileUtil.safeClose(o2);
/* 1697 */       String message = NLS.bind(Messages.resources_writeMeta, root.getFullPath());
/* 1698 */       throw new ResourceException(568, root.getFullPath(), message, e);
/*      */     } 
/*      */     
/* 1701 */     DataOutputStream markersOutput = o1;
/* 1702 */     DataOutputStream syncInfoOutput = o2;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1707 */     long[] saveTimes = new long[2];
/*      */ 
/*      */     
/* 1710 */     IElementContentVisitor visitor = (tree, requestor, elementContents) -> {
/*      */         ResourceInfo info = (ResourceInfo)elementContents;
/*      */         
/*      */         if (info != null) {
/*      */           try {
/*      */             long start = System.currentTimeMillis();
/*      */             
/*      */             paramMarkerManager.save(info, requestor, paramDataOutputStream1, paramList1);
/*      */             long markerSaveTime = System.currentTimeMillis() - start;
/*      */             paramArrayOflong[0] = paramArrayOflong[0] + markerSaveTime;
/*      */             this.persistMarkers += markerSaveTime;
/*      */             if (paramDataOutputStream2 != null) {
/*      */               start = System.currentTimeMillis();
/*      */               paramSynchronizer.saveSyncInfo(info, requestor, paramDataOutputStream2, paramList2);
/*      */               long syncInfoSaveTime = System.currentTimeMillis() - start;
/*      */               paramArrayOflong[1] = paramArrayOflong[1] + syncInfoSaveTime;
/*      */               this.persistSyncInfo += syncInfoSaveTime;
/*      */             } 
/* 1728 */           } catch (IOException e) {
/*      */             throw new WrappedRuntimeException(e);
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*      */         return (paramIResource.getType() != 8);
/*      */       };
/*      */     
/*      */     try {
/*      */       try {
/* 1739 */         (new ElementTreeIterator(this.workspace.getElementTree(), root.getFullPath())).iterate(visitor);
/* 1740 */       } catch (WrappedRuntimeException e) {
/* 1741 */         throw (IOException)e.getTargetException();
/*      */       } 
/* 1743 */       if (Policy.DEBUG_SAVE_MARKERS)
/* 1744 */         Policy.debug("Save Markers for " + root.getFullPath() + ": " + saveTimes[0] + "ms"); 
/* 1745 */       if (Policy.DEBUG_SAVE_SYNCINFO)
/* 1746 */         Policy.debug("Save SyncInfo for " + root.getFullPath() + ": " + saveTimes[1] + "ms"); 
/* 1747 */       removeGarbage(markersOutput, markersLocation, markersTempLocation);
/*      */ 
/*      */       
/* 1750 */       if (syncInfoOutput != null) {
/* 1751 */         removeGarbage(syncInfoOutput, syncInfoLocation, syncInfoTempLocation);
/* 1752 */         syncInfoOutput.close();
/*      */       } 
/* 1754 */       markersOutput.close();
/* 1755 */     } catch (IOException e) {
/* 1756 */       String message = NLS.bind(Messages.resources_writeMeta, root.getFullPath());
/* 1757 */       throw new ResourceException(568, root.getFullPath(), message, e);
/*      */     } finally {
/* 1759 */       FileUtil.safeClose(markersOutput);
/* 1760 */       FileUtil.safeClose(syncInfoOutput);
/*      */     } 
/*      */ 
/*      */     
/* 1764 */     if (root.getType() == 4)
/*      */       return; 
/* 1766 */     IProject[] projects = ((IWorkspaceRoot)root).getProjects(8);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1771 */     ForkJoinPool forkJoinPool = new ForkJoinPool(ForkJoinPool.getCommonPoolParallelism(), pool -> new ForkJoinWorkerThread(pool)
/*      */         {
/*      */         
/* 1774 */         }null, false);
/*      */     
/*      */     try {
/* 1777 */       stats = forkJoinPool.<IStatus[]>submit(() -> (IStatus[])Arrays.<IProject>stream(paramArrayOfIProject).parallel().map(()).filter(Objects::nonNull).toArray(()))
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1784 */         .get();
/* 1785 */     } catch (InterruptedException|java.util.concurrent.ExecutionException e) {
/* 1786 */       throw new CoreException(Status.error(Messages.resources_saveProblem, e));
/*      */     } finally {
/* 1788 */       forkJoinPool.shutdown();
/* 1789 */     }  if (stats.length > 
/* 1790 */       0) {
/* 1791 */       throw new CoreException(new MultiStatus("org.eclipse.core.resources", 4, stats, 
/* 1792 */             Messages.resources_saveProblem, null));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void visitAndSnap(IResource root) throws CoreException {
/* 1804 */     Assert.isLegal(!(root.getType() != 8 && root.getType() != 4));
/*      */     
/* 1806 */     if (!root.isAccessible()) {
/*      */       return;
/*      */     }
/*      */     
/* 1810 */     Synchronizer synchronizer = (Synchronizer)this.workspace.getSynchronizer();
/* 1811 */     MarkerManager markerManager = this.workspace.getMarkerManager();
/* 1812 */     IPath markersLocation = this.workspace.getMetaArea().getMarkersSnapshotLocationFor(root);
/* 1813 */     IPath syncInfoLocation = this.workspace.getMetaArea().getSyncInfoSnapshotLocationFor(root);
/* 1814 */     SafeChunkyOutputStream safeMarkerStream = null;
/* 1815 */     SafeChunkyOutputStream safeSyncInfoStream = null;
/* 1816 */     DataOutputStream o1 = null;
/* 1817 */     DataOutputStream o2 = null;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1822 */       safeMarkerStream = new SafeChunkyOutputStream(markersLocation.toFile());
/* 1823 */       o1 = new DataOutputStream((OutputStream)safeMarkerStream);
/*      */ 
/*      */       
/* 1826 */       if (root.getType() != 8) {
/* 1827 */         safeSyncInfoStream = new SafeChunkyOutputStream(syncInfoLocation.toFile());
/* 1828 */         o2 = new DataOutputStream((OutputStream)safeSyncInfoStream);
/*      */       } 
/* 1830 */     } catch (IOException e) {
/* 1831 */       FileUtil.safeClose(o1);
/* 1832 */       String message = NLS.bind(Messages.resources_writeMeta, root.getFullPath());
/* 1833 */       throw new ResourceException(568, root.getFullPath(), message, e);
/*      */     } 
/*      */     
/* 1836 */     DataOutputStream markersOutput = o1;
/* 1837 */     DataOutputStream syncInfoOutput = o2;
/* 1838 */     int markerFileSize = markersOutput.size();
/* 1839 */     int syncInfoFileSize = (safeSyncInfoStream == null) ? -1 : syncInfoOutput.size();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1844 */     long[] snapTimes = new long[2];
/*      */     
/* 1846 */     IElementContentVisitor visitor = (tree, requestor, elementContents) -> {
/*      */         ResourceInfo info = (ResourceInfo)elementContents;
/*      */         
/*      */         if (info != null) {
/*      */           try {
/*      */             long start = System.currentTimeMillis();
/*      */             
/*      */             paramMarkerManager.snap(info, requestor, paramDataOutputStream1);
/*      */             long markerSnapTime = System.currentTimeMillis() - start;
/*      */             paramArrayOflong[0] = paramArrayOflong[0] + markerSnapTime;
/*      */             this.persistMarkers += markerSnapTime;
/*      */             if (paramDataOutputStream2 != null) {
/*      */               start = System.currentTimeMillis();
/*      */               paramSynchronizer.snapSyncInfo(info, requestor, paramDataOutputStream2);
/*      */               long syncInfoSnapTime = System.currentTimeMillis() - start;
/*      */               paramArrayOflong[1] = paramArrayOflong[1] + syncInfoSnapTime;
/*      */               this.persistSyncInfo += syncInfoSnapTime;
/*      */             } 
/* 1864 */           } catch (IOException e) {
/*      */             throw new WrappedRuntimeException(e);
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*      */         return (paramIResource.getType() != 8);
/*      */       };
/*      */     
/*      */     try {
/*      */       try {
/* 1875 */         (new ElementTreeIterator(this.workspace.getElementTree(), root.getFullPath())).iterate(visitor);
/* 1876 */       } catch (WrappedRuntimeException e) {
/* 1877 */         throw (IOException)e.getTargetException();
/*      */       } 
/* 1879 */       if (Policy.DEBUG_SAVE_MARKERS)
/* 1880 */         Policy.debug("Snap Markers for " + root.getFullPath() + ": " + snapTimes[0] + "ms"); 
/* 1881 */       if (Policy.DEBUG_SAVE_SYNCINFO)
/* 1882 */         Policy.debug("Snap SyncInfo for " + root.getFullPath() + ": " + snapTimes[1] + "ms"); 
/* 1883 */       if (markerFileSize != markersOutput.size())
/* 1884 */         safeMarkerStream.succeed(); 
/* 1885 */       if (safeSyncInfoStream != null && syncInfoFileSize != syncInfoOutput.size()) {
/* 1886 */         safeSyncInfoStream.succeed();
/* 1887 */         syncInfoOutput.close();
/*      */       } 
/* 1889 */       markersOutput.close();
/* 1890 */     } catch (IOException e) {
/* 1891 */       String message = NLS.bind(Messages.resources_writeMeta, root.getFullPath());
/* 1892 */       throw new ResourceException(568, root.getFullPath(), message, e);
/*      */     } finally {
/* 1894 */       FileUtil.safeClose(markersOutput);
/* 1895 */       FileUtil.safeClose(syncInfoOutput);
/*      */     } 
/*      */ 
/*      */     
/* 1899 */     if (root.getType() == 4)
/*      */       return; 
/* 1901 */     IProject[] projects = ((IWorkspaceRoot)root).getProjects(8); byte b; int i; IProject[] arrayOfIProject1;
/* 1902 */     for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/* 1903 */       visitAndSnap((IResource)project);
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeBuilderPersistentInfo(DataOutputStream output, List<BuilderPersistentInfo> builders) throws IOException {
/* 1919 */     int numBuilders = builders.size();
/* 1920 */     output.writeInt(numBuilders);
/* 1921 */     for (int i = 0; i < numBuilders; i++) {
/* 1922 */       BuilderPersistentInfo info = builders.get(i);
/* 1923 */       output.writeUTF(info.getProjectName());
/* 1924 */       output.writeUTF(info.getBuilderName());
/*      */       
/* 1926 */       IProject[] interestingProjects = info.getInterestingProjects();
/* 1927 */       output.writeInt(interestingProjects.length); byte b; int j; IProject[] arrayOfIProject1;
/* 1928 */       for (j = (arrayOfIProject1 = interestingProjects).length, b = 0; b < j; ) { IProject interestingProject = arrayOfIProject1[b];
/* 1929 */         output.writeUTF(interestingProject.getName());
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */   public void writeElement(IPath path, Object element, DataOutput output) throws IOException {
/* 1935 */     Assert.isNotNull(path);
/* 1936 */     Assert.isNotNull(element);
/* 1937 */     Assert.isNotNull(output);
/* 1938 */     ResourceInfo info = (ResourceInfo)element;
/* 1939 */     output.writeInt(info.getFlags());
/* 1940 */     info.writeTo(output);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getTreesToSave(IProject project, List<ElementTree> trees, List<BuilderPersistentInfo> builderInfos, List<String> configNames, List<ElementTree> additionalTrees, List<BuilderPersistentInfo> additionalBuilderInfos, List<String> additionalConfigNames) throws CoreException {
/* 1960 */     if (project.isOpen()) {
/* 1961 */       String activeConfigName = project.getActiveBuildConfig().getName();
/* 1962 */       List<BuilderPersistentInfo> infos = this.workspace.getBuildManager().createBuildersPersistentInfo(project);
/* 1963 */       if (infos != null) {
/* 1964 */         for (BuilderPersistentInfo info : infos) {
/*      */ 
/*      */ 
/*      */           
/* 1968 */           if (info.getLastBuiltTree() == null) {
/*      */             continue;
/*      */           }
/*      */           
/* 1972 */           String configName = (info.getConfigName() == null) ? activeConfigName : info.getConfigName();
/* 1973 */           if (configName.equals(activeConfigName)) {
/*      */ 
/*      */             
/* 1976 */             builderInfos.add(info);
/* 1977 */             configNames.add(configName);
/* 1978 */             trees.add(info.getLastBuiltTree()); continue;
/*      */           } 
/* 1980 */           additionalBuilderInfos.add(info);
/* 1981 */           additionalConfigNames.add(configName);
/* 1982 */           additionalTrees.add(info.getLastBuiltTree());
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writeTree(Map<String, ElementTree> statesToSave, DataOutputStream output, IProgressMonitor monitor) throws IOException, CoreException {
/* 2009 */     SubMonitor subMonitor = SubMonitor.convert(monitor, 10);
/* 2010 */     boolean wasImmutable = false;
/*      */     
/*      */     try {
/* 2013 */       ElementTree current = this.workspace.getElementTree();
/* 2014 */       wasImmutable = current.isImmutable();
/* 2015 */       current.immutable();
/* 2016 */       ArrayList<ElementTree> trees = new ArrayList<>(statesToSave.size() * 2);
/* 2017 */       subMonitor.worked(1);
/*      */ 
/*      */       
/* 2020 */       writeWorkspaceFields(output, (IProgressMonitor)subMonitor.newChild(2));
/*      */ 
/*      */       
/* 2023 */       output.writeInt(statesToSave.size());
/* 2024 */       for (Map.Entry<String, ElementTree> entry : statesToSave.entrySet()) {
/* 2025 */         String pluginId = entry.getKey();
/* 2026 */         output.writeUTF(pluginId);
/* 2027 */         trees.add(entry.getValue());
/* 2028 */         updateDeltaExpiration(pluginId);
/*      */       } 
/* 2030 */       subMonitor.worked(1);
/*      */ 
/*      */ 
/*      */       
/* 2034 */       IProject[] projects = this.workspace.getRoot().getProjects(8);
/* 2035 */       List<BuilderPersistentInfo> builderInfos = new ArrayList<>(projects.length * 2);
/* 2036 */       List<String> configNames = new ArrayList<>(projects.length);
/* 2037 */       List<ElementTree> additionalTrees = new ArrayList<>(projects.length * 2);
/* 2038 */       List<BuilderPersistentInfo> additionalBuilderInfos = new ArrayList<>(projects.length * 2);
/* 2039 */       List<String> additionalConfigNames = new ArrayList<>(projects.length); byte b; int i; IProject[] arrayOfIProject1;
/* 2040 */       for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/* 2041 */         getTreesToSave(project, trees, builderInfos, configNames, additionalTrees, additionalBuilderInfos, 
/* 2042 */             additionalConfigNames);
/*      */         b++; }
/*      */       
/* 2045 */       writeBuilderPersistentInfo(output, builderInfos);
/*      */ 
/*      */ 
/*      */       
/* 2049 */       trees.addAll(additionalTrees);
/*      */ 
/*      */       
/* 2052 */       trees.add(current);
/*      */ 
/*      */       
/* 2055 */       ElementTreeWriter writer = new ElementTreeWriter(this);
/* 2056 */       ElementTree[] treesToSave = trees.<ElementTree>toArray(new ElementTree[trees.size()]);
/* 2057 */       writer.writeDeltaChain(treesToSave, (IPath)Path.ROOT, -1, output, 
/* 2058 */           (IElementComparator)ResourceComparator.getSaveComparator());
/* 2059 */       subMonitor.worked(4);
/*      */ 
/*      */       
/* 2062 */       writeBuilderPersistentInfo(output, additionalBuilderInfos);
/*      */ 
/*      */       
/* 2065 */       for (String string : configNames)
/* 2066 */         output.writeUTF(string); 
/* 2067 */       for (String string : additionalConfigNames)
/* 2068 */         output.writeUTF(string); 
/*      */     } finally {
/* 2070 */       subMonitor.done();
/* 2071 */       if (!wasImmutable) {
/* 2072 */         this.workspace.newWorkingTree();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void writeTree(Project project, DataOutputStream output, IProgressMonitor monitor) throws IOException, CoreException {
/* 2095 */     SubMonitor subMonitor = SubMonitor.convert(monitor, 10);
/* 2096 */     boolean wasImmutable = false;
/*      */ 
/*      */     
/*      */     try {
/* 2100 */       ElementTree current = this.workspace.getElementTree();
/* 2101 */       wasImmutable = current.isImmutable();
/* 2102 */       current.immutable();
/* 2103 */       List<ElementTree> trees = new ArrayList<>(2);
/* 2104 */       subMonitor.worked(1);
/*      */ 
/*      */ 
/*      */       
/* 2108 */       List<String> configNames = new ArrayList<>(5);
/* 2109 */       List<BuilderPersistentInfo> builderInfos = new ArrayList<>(5);
/* 2110 */       List<String> additionalConfigNames = new ArrayList<>(5);
/* 2111 */       List<BuilderPersistentInfo> additionalBuilderInfos = new ArrayList<>(5);
/* 2112 */       List<ElementTree> additionalTrees = new ArrayList<>(5);
/* 2113 */       getTreesToSave(project, trees, builderInfos, configNames, additionalTrees, additionalBuilderInfos, 
/* 2114 */           additionalConfigNames);
/*      */ 
/*      */       
/* 2117 */       writeBuilderPersistentInfo(output, builderInfos);
/*      */ 
/*      */ 
/*      */       
/* 2121 */       trees.addAll(additionalTrees);
/*      */ 
/*      */       
/* 2124 */       trees.add(current);
/*      */ 
/*      */       
/* 2127 */       ElementTreeWriter writer = new ElementTreeWriter(this);
/* 2128 */       ElementTree[] treesToSave = trees.<ElementTree>toArray(new ElementTree[trees.size()]);
/* 2129 */       writer.writeDeltaChain(treesToSave, project.getFullPath(), -1, output, 
/* 2130 */           (IElementComparator)ResourceComparator.getSaveComparator());
/* 2131 */       subMonitor.worked(5);
/*      */ 
/*      */ 
/*      */       
/* 2135 */       writeBuilderPersistentInfo(output, additionalBuilderInfos);
/*      */ 
/*      */       
/* 2138 */       for (String string : configNames)
/* 2139 */         output.writeUTF(string); 
/* 2140 */       for (String string : additionalConfigNames)
/* 2141 */         output.writeUTF(string); 
/*      */     } finally {
/* 2143 */       subMonitor.done();
/* 2144 */       if (!wasImmutable)
/* 2145 */         this.workspace.newWorkingTree(); 
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void writeTree(Project project, int depth) throws CoreException {
/* 2150 */     long start = System.currentTimeMillis();
/* 2151 */     IPath treeLocation = this.workspace.getMetaArea().getTreeLocationFor(project, true);
/* 2152 */     IPath tempLocation = this.workspace.getMetaArea().getBackupLocationFor(treeLocation); try {
/*      */       Exception exception2;
/* 2154 */       SafeFileOutputStream safe = new SafeFileOutputStream(treeLocation.toOSString(), tempLocation.toOSString());
/* 2155 */       Exception exception1 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 2161 */     catch (IOException e) {
/* 2162 */       String msg = NLS.bind(Messages.resources_writeMeta, project.getFullPath());
/* 2163 */       throw new ResourceException(568, treeLocation, msg, e);
/*      */     } 
/* 2165 */     if (Policy.DEBUG_SAVE_TREE) {
/* 2166 */       Policy.debug("Save tree for " + project.getFullPath() + ": " + (System.currentTimeMillis() - start) + "ms");
/*      */     }
/*      */   }
/*      */   
/*      */   protected void writeWorkspaceFields(DataOutputStream output, IProgressMonitor monitor) throws IOException {
/* 2171 */     output.writeLong(this.workspace.nextNodeId.get());
/*      */     
/* 2173 */     output.writeLong(0L);
/*      */     
/* 2175 */     output.writeLong(this.workspace.nextMarkerId.get());
/*      */     
/* 2177 */     ((Synchronizer)this.workspace.getSynchronizer()).savePartners(output);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\SaveManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */