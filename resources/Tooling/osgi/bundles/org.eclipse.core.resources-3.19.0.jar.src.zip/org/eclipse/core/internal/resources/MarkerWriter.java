/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.watson.IPathRequestor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarkerWriter
/*     */ {
/*     */   protected MarkerManager manager;
/*     */   public static final int MARKERS_SAVE_VERSION = 3;
/*     */   public static final int MARKERS_SNAP_VERSION = 2;
/*     */   public static final byte INDEX = 1;
/*     */   public static final byte QNAME = 2;
/*     */   public static final byte ATTRIBUTE_NULL = 0;
/*     */   public static final byte ATTRIBUTE_BOOLEAN = 1;
/*     */   public static final byte ATTRIBUTE_INTEGER = 2;
/*     */   public static final byte ATTRIBUTE_STRING = 3;
/*     */   
/*     */   public MarkerWriter(MarkerManager manager) {
/*  45 */     this.manager = manager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object[] filterMarkers(IMarkerSetElement[] markers) {
/*  54 */     Object[] result = new Object[2];
/*  55 */     boolean[] isPersistent = new boolean[markers.length];
/*  56 */     int count = 0;
/*  57 */     for (int i = 0; i < markers.length; i++) {
/*  58 */       MarkerInfo info = (MarkerInfo)markers[i];
/*  59 */       if (this.manager.isPersistent(info)) {
/*  60 */         isPersistent[i] = true;
/*  61 */         count++;
/*     */       } 
/*     */     } 
/*  64 */     result[0] = Integer.valueOf(count);
/*  65 */     result[1] = isPersistent;
/*  66 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void save(ResourceInfo info, IPathRequestor requestor, DataOutputStream output, List<String> writtenTypes) throws IOException {
/*  94 */     if (info.isSet(8))
/*     */       return; 
/*  96 */     MarkerSet markers = info.getMarkers(false);
/*  97 */     if (markers == null)
/*     */       return; 
/*  99 */     IMarkerSetElement[] elements = markers.elements();
/*     */     
/* 101 */     Object[] result = filterMarkers(elements);
/* 102 */     int count = ((Integer)result[0]).intValue();
/* 103 */     if (count == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 107 */     if (output.size() == 0)
/* 108 */       output.writeInt(3); 
/* 109 */     boolean[] isPersistent = (boolean[])result[1];
/* 110 */     output.writeUTF(requestor.requestPath().toString());
/* 111 */     output.writeInt(count);
/* 112 */     for (int i = 0; i < elements.length; i++) {
/* 113 */       if (isPersistent[i]) {
/* 114 */         write((MarkerInfo)elements[i], output, writtenTypes);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void snap(ResourceInfo info, IPathRequestor requestor, DataOutputStream output) throws IOException {
/* 144 */     if (info.isSet(8))
/*     */       return; 
/* 146 */     if (!info.isSet(4096))
/*     */       return; 
/* 148 */     MarkerSet markers = info.getMarkers(false);
/* 149 */     if (markers == null)
/*     */       return; 
/* 151 */     IMarkerSetElement[] elements = markers.elements();
/*     */     
/* 153 */     Object[] result = filterMarkers(elements);
/* 154 */     int count = ((Integer)result[0]).intValue();
/*     */     
/* 156 */     output.writeInt(2);
/* 157 */     boolean[] isPersistent = (boolean[])result[1];
/* 158 */     output.writeUTF(requestor.requestPath().toString());
/*     */ 
/*     */     
/* 161 */     output.writeInt(count);
/* 162 */     List<String> writtenTypes = new ArrayList<>();
/* 163 */     for (int i = 0; i < elements.length; i++) {
/* 164 */       if (isPersistent[i])
/* 165 */         write((MarkerInfo)elements[i], output, writtenTypes); 
/* 166 */     }  info.clear(4096);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void write(MarkerAttributeMap markerAttributeMap, DataOutputStream output) throws IOException {
/* 173 */     output.writeShort(markerAttributeMap.size());
/* 174 */     for (Map.Entry<String, Object> e : markerAttributeMap.entrySet()) {
/* 175 */       String key = e.getKey();
/* 176 */       output.writeUTF(key);
/* 177 */       Object value = e.getValue();
/* 178 */       if (value instanceof Integer) {
/* 179 */         output.writeByte(2);
/* 180 */         output.writeInt(((Integer)value).intValue());
/*     */         continue;
/*     */       } 
/* 183 */       if (value instanceof Boolean) {
/* 184 */         output.writeByte(1);
/* 185 */         output.writeBoolean(((Boolean)value).booleanValue());
/*     */         continue;
/*     */       } 
/* 188 */       if (value instanceof String) {
/* 189 */         output.writeByte(3);
/* 190 */         output.writeUTF((String)value);
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 195 */       output.writeByte(0);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void write(MarkerInfo info, DataOutputStream output, List<String> writtenTypes) throws IOException {
/* 200 */     output.writeLong(info.getId());
/*     */ 
/*     */     
/* 203 */     String type = info.getType();
/* 204 */     int index = writtenTypes.indexOf(type);
/* 205 */     if (index == -1) {
/* 206 */       output.writeByte(2);
/* 207 */       output.writeUTF(type);
/* 208 */       writtenTypes.add(type);
/*     */     } else {
/* 210 */       output.writeByte(1);
/* 211 */       output.writeInt(index);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 216 */     MarkerAttributeMap attributes = info.getAttributes(false);
/* 217 */     if (attributes == null) {
/* 218 */       output.writeShort(0);
/*     */     } else {
/* 220 */       write(attributes, output);
/*     */     } 
/*     */ 
/*     */     
/* 224 */     output.writeLong(info.getCreationTime());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\MarkerWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */