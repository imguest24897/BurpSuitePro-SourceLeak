/*     */ package org.eclipse.core.internal.watson;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.IOException;
/*     */ import org.eclipse.core.internal.dtree.DeltaDataTree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ElementTreeReaderImpl_1
/*     */   extends ElementTreeReader
/*     */ {
/*     */   ElementTreeReaderImpl_1(IElementInfoFlattener factory) {
/*  37 */     super(factory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementTree readDelta(ElementTree parentTree, DataInput input) throws IOException {
/*  46 */     DeltaDataTree complete = parentTree.getDataTree();
/*  47 */     DeltaDataTree delta = this.dataTreeReader.readTree(complete, input, "");
/*     */ 
/*     */     
/*  50 */     if (delta.isEmptyDelta()) {
/*  51 */       return parentTree;
/*     */     }
/*  53 */     ElementTree tree = new ElementTree(delta);
/*     */ 
/*     */     
/*  56 */     IElementTreeData data = parentTree.getTreeData();
/*  57 */     if (data != null) {
/*  58 */       tree.setTreeData((IElementTreeData)data.clone());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     delta.immutable();
/*  65 */     return tree;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementTree[] readDeltaChain(DataInput input, String newProjectName) throws IOException {
/*  71 */     int treeCount = readNumber(input);
/*  72 */     ElementTree[] results = new ElementTree[treeCount];
/*     */     
/*  74 */     if (treeCount <= 0) {
/*  75 */       return results;
/*     */     }
/*     */ 
/*     */     
/*  79 */     int[] order = new int[treeCount]; int i;
/*  80 */     for (i = 0; i < treeCount; i++) {
/*  81 */       order[i] = readNumber(input);
/*     */     }
/*     */ 
/*     */     
/*  85 */     results[order[0]] = super.readTree(input, newProjectName);
/*     */ 
/*     */     
/*  88 */     for (i = 1; i < treeCount; i++) {
/*  89 */       results[order[i]] = super.readDelta(results[order[i - 1]], input);
/*     */     }
/*     */     
/*  92 */     return results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementTree readTree(DataInput input, String newProjectName) throws IOException {
/* 101 */     ElementTree result = new ElementTree(this.dataTreeReader.readTree(null, input, newProjectName));
/* 102 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\watson\ElementTreeReaderImpl_1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */