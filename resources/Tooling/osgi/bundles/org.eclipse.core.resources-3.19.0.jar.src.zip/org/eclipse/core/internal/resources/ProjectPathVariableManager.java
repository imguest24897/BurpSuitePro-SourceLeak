/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.filesystem.URIUtil;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.resources.IPathVariableChangeListener;
/*     */ import org.eclipse.core.resources.IPathVariableManager;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProjectPathVariableManager
/*     */   implements IPathVariableManager, IManager
/*     */ {
/*     */   private Resource resource;
/*  37 */   private ProjectVariableProviderManager.Descriptor[] variableProviders = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProjectPathVariableManager(Resource resource) {
/*  43 */     this.resource = resource;
/*  44 */     this.variableProviders = ProjectVariableProviderManager.getDefault().getDescriptors();
/*     */   }
/*     */   
/*     */   PathVariableManager getWorkspaceManager() {
/*  48 */     return (PathVariableManager)this.resource.getWorkspace().getPathVariableManager();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkIsValidName(String name) throws CoreException {
/*  56 */     IStatus status = validateName(name);
/*  57 */     if (!status.isOK()) {
/*  58 */       throw new CoreException(status);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkIsValidValue(URI newValue) throws CoreException {
/*  66 */     IStatus status = validateValue(newValue);
/*  67 */     if (!status.isOK()) {
/*  68 */       throw new CoreException(status);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getPathVariableNames() {
/*     */     HashMap<String, VariableDescription> map;
/*  76 */     List<String> result = new LinkedList<>();
/*     */     
/*     */     try {
/*  79 */       map = ((ProjectDescription)this.resource.getProject().getDescription()).getVariables();
/*  80 */     } catch (CoreException coreException) {
/*  81 */       return new String[0];
/*     */     }  byte b; int i; ProjectVariableProviderManager.Descriptor[] arrayOfDescriptor;
/*  83 */     for (i = (arrayOfDescriptor = this.variableProviders).length, b = 0; b < i; ) { ProjectVariableProviderManager.Descriptor variableProvider = arrayOfDescriptor[b];
/*  84 */       String[] variableHints = variableProvider.getVariableNames(variableProvider.getName(), this.resource);
/*  85 */       if (variableHints != null && variableHints.length > 0)
/*  86 */         for (int k = 0; k < variableHints.length; k++)
/*  87 */           result.add(variableProvider.getVariableNames(variableProvider.getName(), this.resource)[k]);   b++; }
/*     */     
/*  89 */     if (map != null)
/*  90 */       result.addAll(map.keySet()); 
/*  91 */     result.addAll(Arrays.asList(getWorkspaceManager().getPathVariableNames()));
/*  92 */     return result.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IPath getValue(String varName) {
/* 101 */     URI uri = getURIValue(varName);
/* 102 */     if (uri != null)
/* 103 */       return URIUtil.toPath(uri); 
/* 104 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URI getURIValue(String varName) {
/* 115 */     String value = internalGetValue(varName);
/* 116 */     if (value != null) {
/* 117 */       if (value.contains("..")) {
/*     */         
/* 119 */         int index = value.indexOf('/');
/* 120 */         if (index > 0) {
/*     */ 
/*     */           
/* 123 */           URI resolved = resolveVariable(value);
/* 124 */           if (resolved != null)
/* 125 */             return resolved; 
/*     */         } 
/*     */       } 
/*     */       try {
/* 129 */         return URI.create(value);
/* 130 */       } catch (IllegalArgumentException illegalArgumentException) {
/* 131 */         IPath path = Path.fromPortableString(value);
/* 132 */         return URIUtil.toURI(path);
/*     */       } 
/*     */     } 
/* 135 */     return getWorkspaceManager().getURIValue(varName);
/*     */   }
/*     */   public String internalGetValue(String varName) {
/*     */     HashMap<String, VariableDescription> map;
/*     */     String name;
/*     */     try {
/* 141 */       map = ((ProjectDescription)this.resource.getProject().getDescription()).getVariables();
/* 142 */     } catch (CoreException coreException) {
/* 143 */       return null;
/*     */     } 
/* 145 */     if (map != null && map.containsKey(varName)) {
/* 146 */       return ((VariableDescription)map.get(varName)).getValue();
/*     */     }
/*     */     
/* 149 */     int index = varName.indexOf('-');
/* 150 */     if (index != -1) {
/* 151 */       name = varName.substring(0, index);
/*     */     } else {
/* 153 */       name = varName;
/* 154 */     }  byte b; int i; ProjectVariableProviderManager.Descriptor[] arrayOfDescriptor; for (i = (arrayOfDescriptor = this.variableProviders).length, b = 0; b < i; ) { ProjectVariableProviderManager.Descriptor variableProvider = arrayOfDescriptor[b];
/* 155 */       if (variableProvider.getName().equals(name))
/* 156 */         return variableProvider.getValue(varName, this.resource);  b++; }
/*     */     
/* 158 */     for (i = (arrayOfDescriptor = this.variableProviders).length, b = 0; b < i; ) { ProjectVariableProviderManager.Descriptor variableProvider = arrayOfDescriptor[b];
/* 159 */       if (name.startsWith(variableProvider.getName()))
/* 160 */         return variableProvider.getValue(varName, this.resource);  b++; }
/*     */     
/* 162 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDefined(String varName) {
/*     */     byte b;
/*     */     int i;
/*     */     ProjectVariableProviderManager.Descriptor[] arrayOfDescriptor;
/* 170 */     for (i = (arrayOfDescriptor = this.variableProviders).length, b = 0; b < i; ) { ProjectVariableProviderManager.Descriptor variableProvider = arrayOfDescriptor[b];
/*     */ 
/*     */ 
/*     */       
/* 174 */       if (varName.startsWith(variableProvider.getName()))
/* 175 */         return true; 
/*     */       b++; }
/*     */     
/*     */     try {
/* 179 */       HashMap<String, VariableDescription> map = ((ProjectDescription)this.resource.getProject().getDescription()).getVariables();
/* 180 */       if (map != null) {
/* 181 */         Iterator<String> it = map.keySet().iterator();
/* 182 */         while (it.hasNext()) {
/* 183 */           String name = it.next();
/* 184 */           if (name.equals(varName))
/* 185 */             return true; 
/*     */         } 
/*     */       } 
/* 188 */     } catch (CoreException coreException) {
/* 189 */       return false;
/*     */     } 
/* 191 */     boolean value = getWorkspaceManager().isDefined(varName);
/* 192 */     if (!value) {
/*     */       
/* 194 */       int index = varName.indexOf('-');
/* 195 */       if (index != -1) {
/* 196 */         String newVarName = varName.substring(0, index);
/* 197 */         value = isDefined(newVarName);
/*     */       } 
/*     */     } 
/* 200 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IPath resolvePath(IPath path) {
/* 209 */     if (path == null || path.segmentCount() == 0 || path.isAbsolute() || path.getDevice() != null)
/* 210 */       return path; 
/* 211 */     URI value = resolveURI(URIUtil.toURI(path));
/* 212 */     return (value == null) ? path : URIUtil.toPath(value);
/*     */   }
/*     */   
/*     */   public URI resolveVariable(String variable) {
/* 216 */     LinkedList<String> variableStack = new LinkedList<>();
/*     */     
/* 218 */     String value = resolveVariable(variable, variableStack);
/* 219 */     if (value != null) {
/*     */       try {
/* 221 */         return URI.create(value);
/* 222 */       } catch (IllegalArgumentException illegalArgumentException) {
/* 223 */         return URIUtil.toURI(Path.fromPortableString(value));
/*     */       } 
/*     */     }
/* 226 */     return null;
/*     */   }
/*     */   
/*     */   public String resolveVariable(String value, LinkedList<String> variableStack) {
/* 230 */     if (variableStack == null) {
/* 231 */       variableStack = new LinkedList<>();
/*     */     }
/* 233 */     String tmp = internalGetValue(value);
/* 234 */     if (tmp == null) {
/* 235 */       URI result = getWorkspaceManager().getURIValue(value);
/* 236 */       if (result != null)
/* 237 */         return result.toASCIIString(); 
/*     */     } else {
/* 239 */       value = tmp;
/*     */     } 
/*     */     while (true) {
/*     */       String stringValue;
/*     */       try {
/* 244 */         URI uri = URI.create(value);
/* 245 */         if (uri != null)
/* 246 */         { IPath path = URIUtil.toPath(uri);
/* 247 */           if (path != null) {
/* 248 */             stringValue = path.toPortableString();
/*     */           } else {
/* 250 */             stringValue = value;
/*     */           }  }
/* 252 */         else { stringValue = value; } 
/* 253 */       } catch (IllegalArgumentException illegalArgumentException) {
/* 254 */         stringValue = value;
/*     */       } 
/*     */       
/* 257 */       int index = stringValue.indexOf("${");
/* 258 */       if (index != -1) {
/* 259 */         int endIndex = PathVariableUtil.getMatchingBrace(stringValue, index);
/* 260 */         String macro = stringValue.substring(index + 2, endIndex);
/* 261 */         String resolvedMacro = "";
/* 262 */         if (!variableStack.contains(macro)) {
/* 263 */           variableStack.add(macro);
/* 264 */           resolvedMacro = resolveVariable(macro, variableStack);
/* 265 */           if (resolvedMacro == null)
/* 266 */             resolvedMacro = ""; 
/*     */         } 
/* 268 */         if (stringValue.length() > endIndex) {
/* 269 */           stringValue = String.valueOf(stringValue.substring(0, index)) + resolvedMacro + stringValue.substring(endIndex + 1);
/*     */         } else {
/* 271 */           stringValue = resolvedMacro;
/* 272 */         }  value = stringValue; continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 276 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public URI resolveURI(URI uri) {
/* 281 */     if (uri == null || uri.isAbsolute()) {
/* 282 */       return uri;
/*     */     }
/* 284 */     String schemeSpecificPart = uri.getSchemeSpecificPart();
/* 285 */     if (schemeSpecificPart == null || schemeSpecificPart.isEmpty()) {
/* 286 */       return uri;
/*     */     }
/* 288 */     Path path1 = new Path(schemeSpecificPart);
/* 289 */     if (path1 == null || path1.segmentCount() == 0 || path1.isAbsolute() || path1.getDevice() != null)
/* 290 */       return URIUtil.toURI((IPath)path1); 
/* 291 */     URI value = resolveVariable(path1.segment(0));
/* 292 */     if (value == null) {
/* 293 */       return uri;
/*     */     }
/* 295 */     String path = value.getPath();
/* 296 */     if (path != null) {
/* 297 */       IPath p = Path.fromPortableString(path);
/* 298 */       p = p.append(path1.removeFirstSegments(1));
/*     */       try {
/* 300 */         value = new URI(value.getScheme(), value.getHost(), p.toPortableString(), value.getFragment());
/* 301 */       } catch (URISyntaxException uRISyntaxException) {
/* 302 */         return uri;
/*     */       } 
/* 304 */       return value;
/*     */     } 
/* 306 */     return uri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setValue(String varName, IPath newValue) throws CoreException {
/* 315 */     if (newValue == null) {
/* 316 */       setURIValue(varName, null);
/*     */     } else {
/* 318 */       setURIValue(varName, URIUtil.toURI(newValue));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setURIValue(String varName, URI newValue) throws CoreException {
/* 327 */     checkIsValidName(varName);
/* 328 */     checkIsValidValue(newValue);
/*     */ 
/*     */     
/* 331 */     boolean changeWorkspaceValue = false;
/* 332 */     Project project = (Project)this.resource.getProject();
/* 333 */     int eventType = 0;
/* 334 */     synchronized (this) {
/* 335 */       String value = internalGetValue(varName);
/* 336 */       URI currentValue = null;
/* 337 */       if (value == null) {
/* 338 */         currentValue = getWorkspaceManager().getURIValue(varName);
/*     */       } else {
/*     */         try {
/* 341 */           currentValue = URI.create(value);
/* 342 */         } catch (IllegalArgumentException illegalArgumentException) {
/* 343 */           currentValue = null;
/*     */         } 
/*     */       } 
/* 346 */       boolean variableExists = (currentValue != null);
/* 347 */       if (!variableExists && newValue == null)
/*     */         return; 
/* 349 */       if (variableExists && currentValue.equals(newValue))
/*     */         return;  byte b; int i;
/*     */       ProjectVariableProviderManager.Descriptor[] arrayOfDescriptor;
/* 352 */       for (i = (arrayOfDescriptor = this.variableProviders).length, b = 0; b < i; ) { ProjectVariableProviderManager.Descriptor variableProvider = arrayOfDescriptor[b];
/*     */ 
/*     */ 
/*     */         
/* 356 */         if (varName.startsWith(variableProvider.getName()))
/*     */           return; 
/*     */         b++; }
/*     */       
/* 360 */       if (value == null && variableExists) {
/* 361 */         changeWorkspaceValue = true;
/*     */       } else {
/* 363 */         NullProgressMonitor nullProgressMonitor = new NullProgressMonitor();
/* 364 */         IProject iProject = this.resource.getProject();
/*     */         try {
/* 366 */           project.workspace.prepareOperation((ISchedulingRule)iProject, (IProgressMonitor)nullProgressMonitor);
/* 367 */           project.workspace.beginOperation(true);
/*     */           
/* 369 */           ProjectDescription description = project.internalGetDescription();
/* 370 */           if (newValue == null) {
/* 371 */             description.setVariableDescription(varName, null);
/* 372 */             eventType = 3;
/*     */           } else {
/* 374 */             description.setVariableDescription(varName, new VariableDescription(varName, newValue.toASCIIString()));
/* 375 */             eventType = variableExists ? 1 : 2;
/*     */           } 
/* 377 */           project.writeDescription(0);
/*     */         } finally {
/* 379 */           project.workspace.endOperation((ISchedulingRule)iProject, true);
/*     */         } 
/*     */       } 
/*     */     } 
/* 383 */     if (changeWorkspaceValue) {
/* 384 */       getWorkspaceManager().setURIValue(varName, newValue);
/*     */     } else {
/*     */       
/* 387 */       getWorkspaceManager().fireVariableChangeEvent(project, varName, (newValue != null) ? URIUtil.toPath(newValue) : null, eventType);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown(IProgressMonitor monitor) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startup(IProgressMonitor monitor) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateName(String name) {
/* 412 */     String message = null;
/* 413 */     if (name.length() == 0) {
/* 414 */       message = Messages.pathvar_length;
/* 415 */       return (IStatus)new ResourceStatus(77, null, message);
/*     */     } 
/*     */     
/* 418 */     char first = name.charAt(0);
/* 419 */     if (!Character.isLetter(first) && first != '_') {
/* 420 */       message = NLS.bind(Messages.pathvar_beginLetter, String.valueOf(first));
/* 421 */       return (IStatus)new ResourceStatus(77, null, message);
/*     */     } 
/*     */     
/* 424 */     for (int i = 1; i < name.length(); i++) {
/* 425 */       char following = name.charAt(i);
/* 426 */       if (Character.isWhitespace(following))
/* 427 */         return (IStatus)new ResourceStatus(77, null, Messages.pathvar_whitespace); 
/* 428 */       if (!Character.isLetter(following) && !Character.isDigit(following) && following != '_') {
/* 429 */         message = NLS.bind(Messages.pathvar_invalidChar, String.valueOf(following));
/* 430 */         return (IStatus)new ResourceStatus(77, null, message);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 435 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateValue(IPath value) {
/* 444 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateValue(URI value) {
/* 453 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URI convertToRelative(URI path, boolean force, String variableHint) throws CoreException {
/* 462 */     return PathVariableUtil.convertToRelative(this, path, this.resource, force, variableHint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String convertToUserEditableFormat(String value, boolean locationFormat) {
/* 470 */     return PathVariableUtil.convertToUserEditableFormatInternal(value, locationFormat);
/*     */   }
/*     */ 
/*     */   
/*     */   public String convertFromUserEditableFormat(String userFormat, boolean locationFormat) {
/* 475 */     return PathVariableUtil.convertFromUserEditableFormatInternal(this, userFormat, locationFormat);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addChangeListener(IPathVariableChangeListener listener) {
/* 480 */     getWorkspaceManager().addChangeListener(listener, this.resource.getProject());
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeChangeListener(IPathVariableChangeListener listener) {
/* 485 */     getWorkspaceManager().removeChangeListener(listener, this.resource.getProject());
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getVariableRelativePathLocation(URI location) {
/*     */     try {
/* 491 */       URI result = convertToRelative(location, false, null);
/* 492 */       if (!result.equals(location))
/* 493 */         return result; 
/* 494 */     } catch (CoreException coreException) {}
/*     */ 
/*     */     
/* 497 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource getResource() {
/* 504 */     return this.resource;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUserDefined(String name) {
/* 509 */     return (ProjectVariableProviderManager.getDefault().findDescriptor(name) == null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ProjectPathVariableManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */