/*     */ package org.eclipse.core.internal.watson;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.eclipse.core.internal.dtree.DataTreeReader;
/*     */ import org.eclipse.core.internal.dtree.IDataFlattener;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElementTreeReader
/*     */ {
/*     */   protected IElementInfoFlattener elementInfoFlattener;
/*     */   protected DataTreeReader dataTreeReader;
/*     */   
/*     */   public ElementTreeReader(final IElementInfoFlattener factory) {
/*  53 */     Assert.isNotNull(factory);
/*  54 */     this.elementInfoFlattener = factory;
/*     */ 
/*     */     
/*  57 */     IDataFlattener f = new IDataFlattener()
/*     */       {
/*     */         public void writeData(IPath path, Object data, DataOutput output) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public Object readData(IPath path, DataInput input) throws IOException {
/*  67 */           if (!Path.ROOT.equals(path))
/*  68 */             return factory.readElement(path, input); 
/*  69 */           return null;
/*     */         }
/*     */       };
/*  72 */     this.dataTreeReader = new DataTreeReader(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementTreeReader getReader(int formatVersion) throws IOException {
/*  79 */     if (formatVersion == 1)
/*  80 */       return new ElementTreeReaderImpl_1(this.elementInfoFlattener); 
/*  81 */     throw new IOException(Messages.watson_unknown);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementTree readDelta(ElementTree completeTree, DataInput input) throws IOException {
/*  90 */     ElementTreeReader realReader = getReader(readNumber(input));
/*  91 */     return realReader.readDelta(completeTree, input);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementTree[] readDeltaChain(DataInput input) throws IOException {
/* 100 */     return readDeltaChain(input, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementTree[] readDeltaChain(DataInput input, String newProjectName) throws IOException {
/* 114 */     ElementTreeReader realReader = getReader(readNumber(input));
/* 115 */     return realReader.readDeltaChain(input, newProjectName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int readNumber(DataInput input) throws IOException {
/* 125 */     byte b = input.readByte();
/* 126 */     int number = b & 0xFF;
/*     */     
/* 128 */     if (number == 255) {
/* 129 */       number = input.readInt();
/*     */     }
/* 131 */     return number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementTree readTree(DataInput input) throws IOException {
/* 140 */     return readTree(input, "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementTree readTree(DataInput input, String newProjectName) throws IOException {
/* 155 */     ElementTreeReader realReader = getReader(readNumber(input));
/* 156 */     return realReader.readTree(input, newProjectName);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\watson\ElementTreeReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */