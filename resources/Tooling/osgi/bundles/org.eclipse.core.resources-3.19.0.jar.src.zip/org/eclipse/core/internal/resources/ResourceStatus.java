/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import org.eclipse.core.resources.IResourceStatus;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceStatus
/*    */   extends Status
/*    */   implements IResourceStatus
/*    */ {
/*    */   IPath path;
/*    */   
/*    */   public ResourceStatus(int type, int code, IPath path, String message, Throwable exception) {
/* 27 */     super(type, "org.eclipse.core.resources", code, message, exception);
/* 28 */     this.path = path;
/*    */   }
/*    */   
/*    */   public ResourceStatus(int code, String message) {
/* 32 */     this(getSeverity(code), code, (IPath)null, message, (Throwable)null);
/*    */   }
/*    */   
/*    */   public ResourceStatus(int code, IPath path, String message) {
/* 36 */     this(getSeverity(code), code, path, message, (Throwable)null);
/*    */   }
/*    */   
/*    */   public ResourceStatus(int code, IPath path, String message, Throwable exception) {
/* 40 */     this(getSeverity(code), code, path, message, exception);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IPath getPath() {
/* 48 */     return this.path;
/*    */   }
/*    */   
/*    */   protected static int getSeverity(int code) {
/* 52 */     return (code == 0) ? 0 : (1 << code % 100 / 33);
/*    */   }
/*    */ 
/*    */   
/*    */   private String getTypeName() {
/* 57 */     switch (getSeverity()) {
/*    */       case 0:
/* 59 */         return "OK";
/*    */       case 4:
/* 61 */         return "ERROR";
/*    */       case 1:
/* 63 */         return "INFO";
/*    */       case 2:
/* 65 */         return "WARNING";
/*    */     } 
/* 67 */     return String.valueOf(getSeverity());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 74 */     StringBuilder sb = new StringBuilder();
/* 75 */     sb.append("[type: ");
/* 76 */     sb.append(getTypeName());
/* 77 */     sb.append("], [path: ");
/* 78 */     sb.append(getPath());
/* 79 */     sb.append("], [message: ");
/* 80 */     sb.append(getMessage());
/* 81 */     sb.append("], [plugin: ");
/* 82 */     sb.append(getPlugin());
/* 83 */     sb.append("], [exception: ");
/* 84 */     sb.append(getException());
/* 85 */     sb.append("]\n");
/* 86 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ResourceStatus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */