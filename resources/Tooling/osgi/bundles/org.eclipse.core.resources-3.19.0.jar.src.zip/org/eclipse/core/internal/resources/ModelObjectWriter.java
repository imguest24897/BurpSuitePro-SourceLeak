/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.events.BuildCommand;
/*     */ import org.eclipse.core.internal.utils.FileUtil;
/*     */ import org.eclipse.core.resources.FileInfoMatcherDescription;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResourceFilterDescription;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModelObjectWriter
/*     */   implements IModelObjectConstants
/*     */ {
/*     */   private static String triggerString(BuildCommand command) {
/*  39 */     StringBuilder buf = new StringBuilder();
/*  40 */     if (command.isBuilding(9))
/*  41 */       buf.append("auto").append(','); 
/*  42 */     if (command.isBuilding(15))
/*  43 */       buf.append("clean").append(','); 
/*  44 */     if (command.isBuilding(6))
/*  45 */       buf.append("full").append(','); 
/*  46 */     if (command.isBuilding(10))
/*  47 */       buf.append("incremental").append(','); 
/*  48 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] getReferencedProjects(ProjectDescription description) {
/*  56 */     IProject[] projects = description.getReferencedProjects();
/*  57 */     String[] result = new String[projects.length];
/*  58 */     for (int i = 0; i < projects.length; i++)
/*  59 */       result[i] = projects[i].getName(); 
/*  60 */     return result;
/*     */   }
/*     */   
/*     */   protected void write(BuildCommand command, XMLWriter writer) {
/*  64 */     writer.startTag("buildCommand", (HashMap<String, Object>)null);
/*  65 */     if (command != null) {
/*  66 */       writer.printSimpleTag("name", command.getName());
/*  67 */       if (shouldWriteTriggers(command))
/*  68 */         writer.printSimpleTag("triggers", triggerString(command)); 
/*  69 */       write("arguments", command.getArguments(false), writer);
/*     */     } 
/*  71 */     writer.endTag("buildCommand");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean shouldWriteTriggers(BuildCommand command) {
/*  81 */     if (!command.isConfigurable())
/*  82 */       return false; 
/*  83 */     return !(command.isBuilding(9) && command.isBuilding(15) && command.isBuilding(6) && command.isBuilding(10));
/*     */   }
/*     */   
/*     */   protected void write(LinkDescription description, XMLWriter writer) {
/*  87 */     writer.startTag("link", (HashMap<String, Object>)null);
/*  88 */     if (description != null) {
/*  89 */       writer.printSimpleTag("name", description.getProjectRelativePath());
/*  90 */       writer.printSimpleTag("type", Integer.toString(description.getType()));
/*     */       
/*  92 */       writeLocation(description.getLocationURI(), writer);
/*     */     } 
/*  94 */     writer.endTag("link");
/*     */   }
/*     */   
/*     */   protected void write(IResourceFilterDescription description, XMLWriter writer) {
/*  98 */     writer.startTag("filter", (HashMap<String, Object>)null);
/*  99 */     if (description != null) {
/* 100 */       writer.printSimpleTag("id", Long.valueOf(((FilterDescription)description).getId()));
/* 101 */       writer.printSimpleTag("name", description.getResource().getProjectRelativePath());
/* 102 */       writer.printSimpleTag("type", Integer.toString(description.getType()));
/* 103 */       if (description.getFileInfoMatcherDescription() != null) {
/* 104 */         write(description.getFileInfoMatcherDescription(), writer);
/*     */       }
/*     */     } 
/* 107 */     writer.endTag("filter");
/*     */   }
/*     */   
/*     */   protected void write(FileInfoMatcherDescription description, XMLWriter writer) {
/* 111 */     writer.startTag("matcher", (HashMap<String, Object>)null);
/* 112 */     writer.printSimpleTag("id", description.getId());
/* 113 */     if (description.getArguments() != null)
/* 114 */       if (description.getArguments() instanceof String) {
/* 115 */         writer.printSimpleTag("arguments", description.getArguments());
/* 116 */       } else if (description.getArguments() instanceof FileInfoMatcherDescription[]) {
/* 117 */         writer.startTag("arguments", (HashMap<String, Object>)null);
/* 118 */         FileInfoMatcherDescription[] array = (FileInfoMatcherDescription[])description.getArguments(); byte b; int i; FileInfoMatcherDescription[] arrayOfFileInfoMatcherDescription1;
/* 119 */         for (i = (arrayOfFileInfoMatcherDescription1 = array).length, b = 0; b < i; ) { FileInfoMatcherDescription element = arrayOfFileInfoMatcherDescription1[b];
/* 120 */           write(element, writer); b++; }
/*     */         
/* 122 */         writer.endTag("arguments");
/*     */       } else {
/* 124 */         writer.printSimpleTag("arguments", "");
/*     */       }  
/* 126 */     writer.endTag("matcher");
/*     */   }
/*     */   
/*     */   protected void write(VariableDescription description, XMLWriter writer) {
/* 130 */     writer.startTag("variable", (HashMap<String, Object>)null);
/* 131 */     if (description != null) {
/* 132 */       writer.printSimpleTag("name", description.getName());
/* 133 */       writer.printSimpleTag("value", description.getValue());
/*     */     } 
/* 135 */     writer.endTag("variable");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeLocation(URI location, XMLWriter writer) {
/* 146 */     if ("file".equals(location.getScheme())) {
/* 147 */       writer.printSimpleTag("location", FileUtil.toPath(location).toPortableString());
/*     */     } else {
/* 149 */       writer.printSimpleTag("locationURI", location.toASCIIString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(Object object, OutputStream output, String lineSeparator) throws IOException {
/*     */     try {
/* 157 */       Exception exception2, exception1 = null;
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */       
/* 165 */       FileUtil.safeClose(output);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void write(Object obj, XMLWriter writer) throws IOException {
/* 170 */     if (obj instanceof BuildCommand) {
/* 171 */       write((BuildCommand)obj, writer);
/*     */       return;
/*     */     } 
/* 174 */     if (obj instanceof ProjectDescription) {
/* 175 */       write((ProjectDescription)obj, writer);
/*     */       return;
/*     */     } 
/* 178 */     if (obj instanceof WorkspaceDescription) {
/* 179 */       throw new IOException("Workspace description format is not supported anymore.");
/*     */     }
/* 181 */     if (obj instanceof LinkDescription) {
/* 182 */       write((LinkDescription)obj, writer);
/*     */       return;
/*     */     } 
/* 185 */     if (obj instanceof IResourceFilterDescription) {
/* 186 */       write((IResourceFilterDescription)obj, writer);
/*     */       return;
/*     */     } 
/* 189 */     if (obj instanceof VariableDescription) {
/* 190 */       write((VariableDescription)obj, writer);
/*     */       return;
/*     */     } 
/* 193 */     writer.printTabulation();
/* 194 */     writer.println(obj.toString());
/*     */   }
/*     */   
/*     */   protected void write(ProjectDescription description, XMLWriter writer) throws IOException {
/* 198 */     writer.startTag("projectDescription", (HashMap<String, Object>)null);
/* 199 */     if (description != null) {
/* 200 */       writer.printSimpleTag("name", description.getName());
/* 201 */       String comment = description.getComment();
/* 202 */       writer.printSimpleTag("comment", (comment == null) ? "" : comment);
/* 203 */       URI snapshotLocation = description.getSnapshotLocationURI();
/* 204 */       if (snapshotLocation != null) {
/* 205 */         writer.printSimpleTag("snapshotLocation", snapshotLocation.toString());
/*     */       }
/* 207 */       write("projects", "project", getReferencedProjects(description), writer);
/* 208 */       write("buildSpec", Arrays.asList((Object[])description.getBuildSpec(false)), writer);
/* 209 */       write("natures", "nature", description.getNatureIds(false), writer);
/* 210 */       HashMap<IPath, LinkDescription> links = description.getLinks();
/* 211 */       if (links != null) {
/*     */         
/* 213 */         List<LinkDescription> sorted = new ArrayList<>(links.values());
/* 214 */         sorted.sort(null);
/* 215 */         write("linkedResources", sorted, writer);
/*     */       } 
/* 217 */       HashMap<IPath, LinkedList<FilterDescription>> filters = description.getFilters();
/* 218 */       if (filters != null) {
/* 219 */         List<FilterDescription> sorted = new ArrayList<>();
/* 220 */         for (LinkedList<FilterDescription> linkedList : filters.values()) {
/* 221 */           List<FilterDescription> list = linkedList;
/* 222 */           sorted.addAll(list);
/*     */         } 
/* 224 */         sorted.sort(null);
/* 225 */         write("filteredResources", sorted, writer);
/*     */       } 
/* 227 */       HashMap<String, VariableDescription> variables = description.getVariables();
/* 228 */       if (variables != null) {
/* 229 */         List<VariableDescription> sorted = new ArrayList<>(variables.values());
/* 230 */         sorted.sort(null);
/* 231 */         write("variableList", sorted, writer);
/*     */       } 
/*     */     } 
/* 234 */     writer.endTag("projectDescription");
/*     */   }
/*     */   
/*     */   protected void write(String name, Collection<?> collection, XMLWriter writer) throws IOException {
/* 238 */     writer.startTag(name, (HashMap<String, Object>)null);
/* 239 */     for (Object o : collection)
/* 240 */       write(o, writer); 
/* 241 */     writer.endTag(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void write(String name, Map<String, String> table, XMLWriter writer) {
/* 248 */     writer.startTag(name, (HashMap<String, Object>)null);
/* 249 */     if (table != null) {
/*     */       
/* 251 */       List<String> sorted = new ArrayList<>(table.keySet());
/* 252 */       sorted.sort(null);
/*     */       
/* 254 */       for (String key : sorted) {
/* 255 */         Object value = table.get(key);
/* 256 */         writer.startTag("dictionary", (HashMap<String, Object>)null);
/* 257 */         writer.printSimpleTag("key", key);
/* 258 */         writer.printSimpleTag("value", value);
/* 259 */         writer.endTag("dictionary");
/*     */       } 
/*     */     } 
/* 262 */     writer.endTag(name);
/*     */   }
/*     */   
/*     */   protected void write(String name, String elementTagName, String[] array, XMLWriter writer) {
/* 266 */     writer.startTag(name, (HashMap<String, Object>)null); byte b; int i; String[] arrayOfString;
/* 267 */     for (i = (arrayOfString = array).length, b = 0; b < i; ) { String element = arrayOfString[b];
/* 268 */       writer.printSimpleTag(elementTagName, element); b++; }
/* 269 */      writer.endTag(name);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ModelObjectWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */