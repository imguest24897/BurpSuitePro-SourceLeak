/*     */ package org.eclipse.core.internal.events;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.resources.IMarkerSetElement;
/*     */ import org.eclipse.core.internal.resources.MarkerSet;
/*     */ import org.eclipse.core.internal.resources.ResourceInfo;
/*     */ import org.eclipse.core.internal.watson.ElementTree;
/*     */ import org.eclipse.core.resources.IMarkerDelta;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.resources.IResourceDeltaVisitor;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceDelta
/*     */   extends PlatformObject
/*     */   implements IResourceDelta
/*     */ {
/*     */   protected IPath path;
/*     */   protected ResourceDeltaInfo deltaInfo;
/*     */   protected int status;
/*     */   protected ResourceInfo oldInfo;
/*     */   protected ResourceInfo newInfo;
/*     */   protected ResourceDelta[] children;
/*     */   protected IResource cachedResource;
/*  41 */   protected static int KIND_MASK = 255;
/*  42 */   private static IMarkerDelta[] EMPTY_MARKER_DELTAS = new IMarkerDelta[0];
/*     */   
/*     */   protected ResourceDelta(IPath path, ResourceDeltaInfo deltaInfo) {
/*  45 */     this.path = path;
/*  46 */     this.deltaInfo = deltaInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(IResourceDeltaVisitor visitor) throws CoreException {
/*  51 */     accept(visitor, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(IResourceDeltaVisitor visitor, boolean includePhantoms) throws CoreException {
/*  56 */     accept(visitor, includePhantoms ? 1 : 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(IResourceDeltaVisitor visitor, int memberFlags) throws CoreException {
/*  61 */     boolean includePhantoms = ((memberFlags & 0x1) != 0);
/*  62 */     boolean includeTeamPrivate = ((memberFlags & 0x2) != 0);
/*  63 */     boolean includeHidden = ((memberFlags & 0x8) != 0);
/*  64 */     int mask = includePhantoms ? 31 : 7;
/*  65 */     if ((getKind() & mask) == 0)
/*     */       return; 
/*  67 */     if (!visitor.visit(this))
/*     */       return;  byte b; int i; ResourceDelta[] arrayOfResourceDelta;
/*  69 */     for (i = (arrayOfResourceDelta = this.children).length, b = 0; b < i; ) { ResourceDelta childDelta = arrayOfResourceDelta[b];
/*     */       
/*  71 */       if (includeTeamPrivate || !childDelta.isTeamPrivate())
/*     */       {
/*  73 */         if (includePhantoms || !childDelta.isPhantom())
/*     */         {
/*  75 */           if (includeHidden || !childDelta.isHidden())
/*     */           {
/*  77 */             childDelta.accept(visitor, memberFlags); } 
/*     */         }
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   protected void checkForMarkerDeltas() {
/*  85 */     if (this.deltaInfo.getMarkerDeltas() == null)
/*     */       return; 
/*  87 */     int kind = getKind();
/*     */ 
/*     */     
/*  90 */     if (this.path.isRoot() || kind == 1 || kind == 2) {
/*  91 */       MarkerSet changes = this.deltaInfo.getMarkerDeltas().get(this.path);
/*  92 */       if (changes != null && changes.size() > 0) {
/*  93 */         this.status |= 0x20000;
/*     */ 
/*     */         
/*  96 */         if (kind == 0) {
/*  97 */           this.status |= 0x4;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public IResourceDelta findMember(IPath path) {
/* 104 */     int segmentCount = path.segmentCount();
/* 105 */     if (segmentCount == 0) {
/* 106 */       return this;
/*     */     }
/*     */     
/* 109 */     ResourceDelta current = this;
/* 110 */     for (int i = 0; i < segmentCount; i++) {
/* 111 */       ResourceDelta[] arrayOfResourceDelta; int j = (arrayOfResourceDelta = current.children).length; byte b = 0; while (true) { if (b >= j)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 118 */           return null; }  IResourceDelta element = arrayOfResourceDelta[b]; if (element.getFullPath().lastSegment().equals(path.segment(i))) { current = (ResourceDelta)element; break; }  b++; }
/*     */     
/* 120 */     }  return current;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fixMovesAndMarkers(ElementTree oldTree) {
/* 130 */     NodeIDMap nodeIDMap = this.deltaInfo.getNodeIDMap();
/* 131 */     if (!this.path.isRoot() && !nodeIDMap.isEmpty()) {
/* 132 */       IPath oldPath, newPath; int kind = getKind();
/* 133 */       switch (kind) {
/*     */         case 1:
/*     */         case 4:
/* 136 */           oldPath = nodeIDMap.getOldPath(this.newInfo.getNodeId());
/* 137 */           if (oldPath != null && !oldPath.equals(this.path)) {
/*     */             
/* 139 */             ResourceInfo actualOldInfo = (ResourceInfo)oldTree.getElementData(oldPath);
/*     */ 
/*     */ 
/*     */             
/* 143 */             this.status = this.status & KIND_MASK | this.deltaInfo.getComparator().compare(actualOldInfo, this.newInfo) & (KIND_MASK ^ 0xFFFFFFFF);
/* 144 */             this.status |= 0x1000;
/*     */             
/* 146 */             if (kind == 4) {
/* 147 */               this.status = this.status | 0x40000 | 0x100;
/*     */             }
/* 149 */             if (this.oldInfo != null && this.newInfo != null && this.oldInfo.getType() != this.newInfo.getType())
/* 150 */               this.status |= 0x8000; 
/*     */           }  break;
/*     */       } 
/* 153 */       switch (kind) {
/*     */         case 2:
/*     */         case 4:
/* 156 */           newPath = nodeIDMap.getNewPath(this.oldInfo.getNodeId());
/* 157 */           if (newPath != null && !newPath.equals(this.path)) {
/* 158 */             this.status |= 0x2000;
/*     */             
/* 160 */             if (kind == 4) {
/* 161 */               this.status = this.status | 0x40000 | 0x100;
/*     */             }
/*     */           } 
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 168 */     checkForMarkerDeltas(); byte b;
/*     */     int i;
/*     */     ResourceDelta[] arrayOfResourceDelta;
/* 171 */     for (i = (arrayOfResourceDelta = this.children).length, b = 0; b < i; ) { ResourceDelta element = arrayOfResourceDelta[b];
/* 172 */       element.fixMovesAndMarkers(oldTree);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   public IResourceDelta[] getAffectedChildren() {
/* 177 */     return getAffectedChildren(7, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public IResourceDelta[] getAffectedChildren(int kindMask) {
/* 182 */     return getAffectedChildren(kindMask, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public IResourceDelta[] getAffectedChildren(int kindMask, int memberFlags) {
/* 187 */     int numChildren = this.children.length;
/*     */     
/* 189 */     if (numChildren == 0)
/* 190 */       return (IResourceDelta[])this.children; 
/* 191 */     boolean includePhantoms = ((memberFlags & 0x1) != 0);
/* 192 */     boolean includeTeamPrivate = ((memberFlags & 0x2) != 0);
/* 193 */     boolean includeHidden = ((memberFlags & 0x8) != 0);
/*     */     
/* 195 */     if (includePhantoms) {
/* 196 */       kindMask |= 0x18;
/*     */     }
/*     */     
/* 199 */     int matching = 0;
/* 200 */     for (int i = 0; i < numChildren; i++) {
/* 201 */       if ((this.children[i].getKind() & kindMask) != 0)
/*     */       {
/* 203 */         if (includePhantoms || !this.children[i].isPhantom())
/*     */         {
/* 205 */           if (includeTeamPrivate || !this.children[i].isTeamPrivate())
/*     */           {
/* 207 */             if (includeHidden || !this.children[i].isHidden())
/*     */             {
/* 209 */               matching++; }  }  } 
/*     */       }
/*     */     } 
/* 212 */     if (matching == numChildren) {
/* 213 */       IResourceDelta[] arrayOfIResourceDelta = new IResourceDelta[this.children.length];
/* 214 */       System.arraycopy(this.children, 0, arrayOfIResourceDelta, 0, this.children.length);
/* 215 */       return arrayOfIResourceDelta;
/*     */     } 
/*     */     
/* 218 */     IResourceDelta[] result = new IResourceDelta[matching];
/* 219 */     int nextPosition = 0;
/* 220 */     for (int j = 0; j < numChildren; j++) {
/* 221 */       if ((this.children[j].getKind() & kindMask) != 0)
/*     */       {
/* 223 */         if (includePhantoms || !this.children[j].isPhantom())
/*     */         {
/* 225 */           if (includeTeamPrivate || !this.children[j].isTeamPrivate())
/*     */           {
/* 227 */             if (includeHidden || !this.children[j].isHidden())
/*     */             {
/* 229 */               result[nextPosition++] = this.children[j]; }  }  }  } 
/*     */     } 
/* 231 */     return result;
/*     */   }
/*     */   
/*     */   protected ResourceDeltaInfo getDeltaInfo() {
/* 235 */     return this.deltaInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFlags() {
/* 240 */     return this.status & (KIND_MASK ^ 0xFFFFFFFF);
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getFullPath() {
/* 245 */     return this.path;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getKind() {
/* 250 */     return this.status & KIND_MASK;
/*     */   }
/*     */ 
/*     */   
/*     */   public IMarkerDelta[] getMarkerDeltas() {
/* 255 */     Map<IPath, MarkerSet> markerDeltas = this.deltaInfo.getMarkerDeltas();
/* 256 */     if (markerDeltas == null)
/* 257 */       return EMPTY_MARKER_DELTAS; 
/* 258 */     if (this.path == null)
/* 259 */       this.path = (IPath)Path.ROOT; 
/* 260 */     MarkerSet changes = markerDeltas.get(this.path);
/* 261 */     if (changes == null)
/* 262 */       return EMPTY_MARKER_DELTAS; 
/* 263 */     IMarkerSetElement[] elements = changes.elements();
/* 264 */     IMarkerDelta[] result = new IMarkerDelta[elements.length];
/* 265 */     for (int i = 0; i < elements.length; i++)
/* 266 */       result[i] = (IMarkerDelta)elements[i]; 
/* 267 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getMovedFromPath() {
/* 272 */     if ((this.status & 0x1000) != 0) {
/* 273 */       return this.deltaInfo.getNodeIDMap().getOldPath(this.newInfo.getNodeId());
/*     */     }
/* 275 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getMovedToPath() {
/* 280 */     if ((this.status & 0x2000) != 0) {
/* 281 */       return this.deltaInfo.getNodeIDMap().getNewPath(this.oldInfo.getNodeId());
/*     */     }
/* 283 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getProjectRelativePath() {
/* 288 */     IPath full = getFullPath();
/* 289 */     int count = full.segmentCount();
/* 290 */     if (count < 0)
/* 291 */       return null; 
/* 292 */     if (count <= 1)
/* 293 */       return (IPath)Path.EMPTY; 
/* 294 */     return full.removeFirstSegments(1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource getResource() {
/* 300 */     if (this.cachedResource != null) {
/* 301 */       return this.cachedResource;
/*     */     }
/*     */     
/* 304 */     if (this.path.segmentCount() == 0) {
/* 305 */       return (IResource)this.deltaInfo.getWorkspace().getRoot();
/*     */     }
/*     */     
/* 308 */     ResourceInfo info = null;
/* 309 */     if ((getKind() & 0x12) != 0) {
/* 310 */       info = this.oldInfo;
/*     */     } else {
/* 312 */       info = this.newInfo;
/* 313 */     }  Assert.isNotNull(info, "Do not have resource info for resource in delta: " + this.path);
/* 314 */     this.cachedResource = (IResource)this.deltaInfo.getWorkspace().newResource(this.path, info.getType());
/* 315 */     return this.cachedResource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isPhantom() {
/* 324 */     if ((this.status & 0x12) != 0)
/* 325 */       return ResourceInfo.isSet(this.oldInfo.getFlags(), 8); 
/* 326 */     return ResourceInfo.isSet(this.newInfo.getFlags(), 8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isTeamPrivate() {
/* 335 */     if ((this.status & 0x12) != 0)
/* 336 */       return ResourceInfo.isSet(this.oldInfo.getFlags(), 32768); 
/* 337 */     return ResourceInfo.isSet(this.newInfo.getFlags(), 32768);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isHidden() {
/* 346 */     if ((this.status & 0x12) != 0)
/* 347 */       return ResourceInfo.isSet(this.oldInfo.getFlags(), 2097152); 
/* 348 */     return ResourceInfo.isSet(this.newInfo.getFlags(), 2097152);
/*     */   }
/*     */   
/*     */   protected void setChildren(ResourceDelta[] children) {
/* 352 */     this.children = children;
/*     */   }
/*     */   
/*     */   protected void setNewInfo(ResourceInfo newInfo) {
/* 356 */     this.newInfo = newInfo;
/*     */   }
/*     */   
/*     */   protected void setOldInfo(ResourceInfo oldInfo) {
/* 360 */     this.oldInfo = oldInfo;
/*     */   }
/*     */   
/*     */   protected void setStatus(int status) {
/* 364 */     this.status = status;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toDebugString() {
/* 372 */     StringBuilder buffer = new StringBuilder();
/* 373 */     writeDebugString(buffer);
/* 374 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toDeepDebugString() {
/* 382 */     StringBuilder buffer = new StringBuilder("\n");
/* 383 */     writeDebugString(buffer); byte b; int i; ResourceDelta[] arrayOfResourceDelta;
/* 384 */     for (i = (arrayOfResourceDelta = this.children).length, b = 0; b < i; ) { ResourceDelta element = arrayOfResourceDelta[b];
/* 385 */       buffer.append(element.toDeepDebugString()); b++; }
/* 386 */      return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 394 */     return "ResourceDelta(" + this.path + ')';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateMarkers(Map<IPath, MarkerSet> markers) {
/* 403 */     this.deltaInfo.setMarkerDeltas(markers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDebugString(StringBuilder buffer) {
/* 411 */     buffer.append(getFullPath());
/* 412 */     buffer.append('[');
/* 413 */     switch (getKind()) {
/*     */       case 1:
/* 415 */         buffer.append('+');
/*     */         break;
/*     */       case 8:
/* 418 */         buffer.append('>');
/*     */         break;
/*     */       case 2:
/* 421 */         buffer.append('-');
/*     */         break;
/*     */       case 16:
/* 424 */         buffer.append('<');
/*     */         break;
/*     */       case 4:
/* 427 */         buffer.append('*');
/*     */         break;
/*     */       case 0:
/* 430 */         buffer.append('~');
/*     */         break;
/*     */       default:
/* 433 */         buffer.append('?');
/*     */         break;
/*     */     } 
/* 436 */     buffer.append("]: {");
/* 437 */     int changeFlags = getFlags();
/* 438 */     boolean prev = false;
/* 439 */     if ((changeFlags & 0x100) != 0) {
/* 440 */       if (prev)
/* 441 */         buffer.append(" | "); 
/* 442 */       buffer.append("CONTENT");
/* 443 */       prev = true;
/*     */     } 
/* 445 */     if ((changeFlags & 0x200000) != 0) {
/* 446 */       if (prev)
/* 447 */         buffer.append(" | "); 
/* 448 */       buffer.append("LOCAL_CHANGED");
/* 449 */       prev = true;
/*     */     } 
/* 451 */     if ((changeFlags & 0x1000) != 0) {
/* 452 */       if (prev)
/* 453 */         buffer.append(" | "); 
/* 454 */       buffer.append("MOVED_FROM(" + getMovedFromPath() + ")");
/* 455 */       prev = true;
/*     */     } 
/* 457 */     if ((changeFlags & 0x2000) != 0) {
/* 458 */       if (prev)
/* 459 */         buffer.append(" | "); 
/* 460 */       buffer.append("MOVED_TO(" + getMovedToPath() + ")");
/* 461 */       prev = true;
/*     */     } 
/* 463 */     if ((changeFlags & 0x4000) != 0) {
/* 464 */       if (prev)
/* 465 */         buffer.append(" | "); 
/* 466 */       buffer.append("OPEN");
/* 467 */       prev = true;
/*     */     } 
/* 469 */     if ((changeFlags & 0x8000) != 0) {
/* 470 */       if (prev)
/* 471 */         buffer.append(" | "); 
/* 472 */       buffer.append("TYPE");
/* 473 */       prev = true;
/*     */     } 
/* 475 */     if ((changeFlags & 0x10000) != 0) {
/* 476 */       if (prev)
/* 477 */         buffer.append(" | "); 
/* 478 */       buffer.append("SYNC");
/* 479 */       prev = true;
/*     */     } 
/* 481 */     if ((changeFlags & 0x20000) != 0) {
/* 482 */       if (prev)
/* 483 */         buffer.append(" | "); 
/* 484 */       buffer.append("MARKERS");
/* 485 */       writeMarkerDebugString(buffer);
/* 486 */       prev = true;
/*     */     } 
/* 488 */     if ((changeFlags & 0x40000) != 0) {
/* 489 */       if (prev)
/* 490 */         buffer.append(" | "); 
/* 491 */       buffer.append("REPLACED");
/* 492 */       prev = true;
/*     */     } 
/* 494 */     if ((changeFlags & 0x80000) != 0) {
/* 495 */       if (prev)
/* 496 */         buffer.append(" | "); 
/* 497 */       buffer.append("DESCRIPTION");
/* 498 */       prev = true;
/*     */     } 
/* 500 */     if ((changeFlags & 0x100000) != 0) {
/* 501 */       if (prev)
/* 502 */         buffer.append(" | "); 
/* 503 */       buffer.append("ENCODING");
/* 504 */       prev = true;
/*     */     } 
/* 506 */     if ((changeFlags & 0x400000) != 0) {
/* 507 */       if (prev)
/* 508 */         buffer.append(" | "); 
/* 509 */       buffer.append("DERIVED_CHANGED");
/* 510 */       prev = true;
/*     */     } 
/* 512 */     buffer.append("}");
/* 513 */     if (isTeamPrivate())
/* 514 */       buffer.append(" (team private)"); 
/* 515 */     if (isHidden())
/* 516 */       buffer.append(" (hidden)"); 
/*     */   }
/*     */   
/*     */   public void writeMarkerDebugString(StringBuilder buffer) {
/* 520 */     Map<IPath, MarkerSet> markerDeltas = this.deltaInfo.getMarkerDeltas();
/* 521 */     if (markerDeltas == null || markerDeltas.isEmpty())
/*     */       return; 
/* 523 */     buffer.append('[');
/* 524 */     for (Map.Entry<IPath, MarkerSet> entry : markerDeltas.entrySet()) {
/* 525 */       IPath key = entry.getKey();
/* 526 */       if (getResource().getFullPath().equals(key)) {
/* 527 */         MarkerSet set = entry.getValue();
/* 528 */         IMarkerSetElement[] deltas = set.elements();
/* 529 */         boolean addComma = false; byte b; int i; IMarkerSetElement[] arrayOfIMarkerSetElement1;
/* 530 */         for (i = (arrayOfIMarkerSetElement1 = deltas).length, b = 0; b < i; ) { IMarkerSetElement delta2 = arrayOfIMarkerSetElement1[b];
/* 531 */           IMarkerDelta delta = (IMarkerDelta)delta2;
/* 532 */           if (addComma)
/* 533 */             buffer.append(','); 
/* 534 */           switch (delta.getKind()) {
/*     */             case 1:
/* 536 */               buffer.append('+');
/*     */               break;
/*     */             case 2:
/* 539 */               buffer.append('-');
/*     */               break;
/*     */             case 4:
/* 542 */               buffer.append('*');
/*     */               break;
/*     */           } 
/* 545 */           buffer.append(delta.getId());
/* 546 */           addComma = true; b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 550 */     buffer.append(']');
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\ResourceDelta.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */