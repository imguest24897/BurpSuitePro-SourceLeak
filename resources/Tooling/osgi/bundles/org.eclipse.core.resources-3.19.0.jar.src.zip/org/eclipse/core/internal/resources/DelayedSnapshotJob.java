/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import org.eclipse.core.internal.utils.Messages;
/*    */ import org.eclipse.core.internal.utils.Policy;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*    */ import org.eclipse.core.runtime.jobs.Job;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelayedSnapshotJob
/*    */   extends Job
/*    */ {
/* 28 */   private static final String MSG_SNAPSHOT = Messages.resources_snapshot;
/*    */   private SaveManager saveManager;
/*    */   private Workspace workspace;
/*    */   
/*    */   public DelayedSnapshotJob(SaveManager manager, Workspace workspace) {
/* 33 */     super(MSG_SNAPSHOT);
/* 34 */     this.saveManager = manager;
/* 35 */     this.workspace = workspace;
/* 36 */     setRule((ISchedulingRule)workspace.getRoot());
/* 37 */     setSystem(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IStatus run(IProgressMonitor monitor) {
/* 45 */     if (monitor.isCanceled())
/* 46 */       return Status.CANCEL_STATUS; 
/* 47 */     if (!this.workspace.isOpen()) {
/* 48 */       return Status.OK_STATUS;
/*    */     }
/*    */     try {
/* 51 */       return this.saveManager.save(2, null, Policy.monitorFor(null));
/* 52 */     } catch (CoreException e) {
/* 53 */       return e.getStatus();
/*    */     } finally {
/* 55 */       this.saveManager.operationCount = 0;
/* 56 */       this.saveManager.snapshotRequested = false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\DelayedSnapshotJob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */