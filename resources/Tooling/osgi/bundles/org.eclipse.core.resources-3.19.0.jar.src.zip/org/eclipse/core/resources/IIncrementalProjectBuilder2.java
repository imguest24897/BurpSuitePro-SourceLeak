package org.eclipse.core.resources;

import java.util.Map;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IIncrementalProjectBuilder2 {
  void clean(Map<String, String> paramMap, IProgressMonitor paramIProgressMonitor) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IIncrementalProjectBuilder2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */