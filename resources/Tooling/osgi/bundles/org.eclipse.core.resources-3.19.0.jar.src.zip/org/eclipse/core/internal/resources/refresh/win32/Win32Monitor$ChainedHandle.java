/*    */ package org.eclipse.core.internal.resources.refresh.win32;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ChainedHandle
/*    */   extends Win32Monitor.Handle
/*    */ {
/*    */   private ChainedHandle next;
/*    */   private ChainedHandle previous;
/*    */   
/*    */   public abstract boolean exists();
/*    */   
/*    */   public ChainedHandle getNext() {
/* 60 */     return this.next;
/*    */   }
/*    */   
/*    */   public ChainedHandle getPrevious() {
/* 64 */     return this.previous;
/*    */   }
/*    */   
/*    */   public void setNext(ChainedHandle next) {
/* 68 */     this.next = next;
/*    */   }
/*    */   
/*    */   public void setPrevious(ChainedHandle previous) {
/* 72 */     this.previous = previous;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\refresh\win32\Win32Monitor$ChainedHandle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */