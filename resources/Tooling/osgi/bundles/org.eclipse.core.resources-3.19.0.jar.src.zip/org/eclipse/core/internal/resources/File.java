/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.internal.utils.BitMask;
/*     */ import org.eclipse.core.internal.utils.FileUtil;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IFileState;
/*     */ import org.eclipse.core.resources.IFolder;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ import org.eclipse.core.runtime.content.IContentTypeManager;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ public class File
/*     */   extends Resource
/*     */   implements IFile
/*     */ {
/*     */   protected File(IPath path, Workspace container) {
/*  36 */     super(path, container);
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendContents(InputStream content, int updateFlags, IProgressMonitor monitor) throws CoreException {
/*  41 */     String message = NLS.bind(Messages.resources_settingContents, getFullPath());
/*  42 */     SubMonitor subMonitor = SubMonitor.convert(monitor, message, 100);
/*     */     try {
/*  44 */       Assert.isNotNull(content, "Content cannot be null.");
/*  45 */       if (this.workspace.shouldValidate)
/*  46 */         this.workspace.validateSave(this); 
/*  47 */       ISchedulingRule rule = this.workspace.getRuleFactory().modifyRule(this);
/*  48 */       SubMonitor newChild = subMonitor.newChild(1);
/*     */       try {
/*  50 */         this.workspace.prepareOperation(rule, (IProgressMonitor)newChild);
/*  51 */         ResourceInfo info = getResourceInfo(false, false);
/*  52 */         checkAccessible(getFlags(info));
/*  53 */         this.workspace.beginOperation(true);
/*  54 */         IFileInfo fileInfo = getStore().fetchInfo();
/*  55 */         internalSetContents(content, fileInfo, updateFlags, true, (IProgressMonitor)subMonitor.newChild(99));
/*  56 */       } catch (OperationCanceledException e) {
/*  57 */         this.workspace.getWorkManager().operationCanceled();
/*  58 */         throw e;
/*     */       } finally {
/*  60 */         this.workspace.endOperation(rule, true);
/*     */       } 
/*     */     } finally {
/*  63 */       subMonitor.done();
/*  64 */       FileUtil.safeClose(content);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void appendContents(InputStream content, boolean force, boolean keepHistory, IProgressMonitor monitor) throws CoreException {
/*  71 */     int updateFlags = force ? 1 : 0;
/*  72 */     updateFlags |= keepHistory ? 2 : 0;
/*  73 */     appendContents(content, updateFlags, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFolder changeToFolder() throws CoreException {
/*  86 */     getPropertyManager().deleteProperties(this, 0);
/*  87 */     IFolder result = this.workspace.getRoot().getFolder(this.path);
/*  88 */     if (isLinked()) {
/*  89 */       IPath location = getRawLocation();
/*  90 */       delete(0, (IProgressMonitor)null);
/*  91 */       result.createLink(location, 16, null);
/*     */     } else {
/*  93 */       this.workspace.deleteResource(this);
/*  94 */       this.workspace.createResource((IResource)result, false);
/*     */     } 
/*  96 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public void create(InputStream content, int updateFlags, IProgressMonitor monitor) throws CoreException {
/* 101 */     String message = NLS.bind(Messages.resources_creating, getFullPath());
/* 102 */     SubMonitor subMonitor = SubMonitor.convert(monitor, message, 100);
/*     */     try {
/* 104 */       checkValidPath(this.path, 1, true);
/* 105 */       ISchedulingRule rule = this.workspace.getRuleFactory().createRule(this);
/* 106 */       SubMonitor newChild = subMonitor.newChild(1);
/*     */       try {
/* 108 */         this.workspace.prepareOperation(rule, (IProgressMonitor)newChild);
/* 109 */         checkDoesNotExist();
/* 110 */         Container parent = (Container)getParent();
/* 111 */         ResourceInfo info = parent.getResourceInfo(false, false);
/* 112 */         parent.checkAccessible(getFlags(info));
/* 113 */         checkValidGroupContainer(parent, false, false);
/*     */         
/* 115 */         this.workspace.beginOperation(true);
/* 116 */         IFileStore store = getStore();
/* 117 */         IFileInfo localInfo = store.fetchInfo();
/* 118 */         if (BitMask.isSet(updateFlags, 1)) {
/* 119 */           if (!Workspace.caseSensitive && 
/* 120 */             localInfo.exists()) {
/* 121 */             String name = getLocalManager().getLocalName(store);
/* 122 */             if (name == null || localInfo.getName().equals(name)) {
/* 123 */               delete(true, (IProgressMonitor)null);
/*     */             }
/*     */             else {
/*     */               
/* 127 */               message = NLS.bind(Messages.resources_existsLocalDifferentCase, (new Path(store.toString())).removeLastSegments(1).append(name).toOSString());
/* 128 */               throw new ResourceException(275, getFullPath(), message, null);
/*     */             }
/*     */           
/*     */           }
/*     */         
/* 133 */         } else if (localInfo.exists()) {
/*     */           
/* 135 */           if (!Workspace.caseSensitive) {
/* 136 */             String name = getLocalManager().getLocalName(store);
/* 137 */             if (name != null && !localInfo.getName().equals(name)) {
/* 138 */               message = NLS.bind(Messages.resources_existsLocalDifferentCase, (new Path(store.toString())).removeLastSegments(1).append(name).toOSString());
/* 139 */               throw new ResourceException(275, getFullPath(), message, null);
/*     */             } 
/*     */           } 
/* 142 */           message = NLS.bind(Messages.resources_fileExists, store.toString());
/* 143 */           throw new ResourceException(272, getFullPath(), message, null);
/*     */         } 
/*     */         
/* 146 */         subMonitor.worked(40);
/*     */         
/* 148 */         info = this.workspace.createResource(this, updateFlags);
/* 149 */         boolean local = (content != null);
/* 150 */         if (local) {
/*     */           try {
/* 152 */             internalSetContents(content, localInfo, updateFlags, false, (IProgressMonitor)subMonitor.newChild(59));
/* 153 */           } catch (CoreException|OperationCanceledException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 158 */             this.workspace.deleteResource(this);
/* 159 */             store.delete(0, null);
/* 160 */             throw e;
/*     */           } 
/*     */         }
/* 163 */         internalSetLocal(local, 0);
/* 164 */         if (!local)
/* 165 */           getResourceInfo(true, true).clearModificationStamp(); 
/* 166 */       } catch (OperationCanceledException e) {
/* 167 */         this.workspace.getWorkManager().operationCanceled();
/* 168 */         throw e;
/*     */       } finally {
/* 170 */         this.workspace.endOperation(rule, true);
/*     */       } 
/*     */     } finally {
/* 173 */       subMonitor.done();
/* 174 */       FileUtil.safeClose(content);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void create(InputStream content, boolean force, IProgressMonitor monitor) throws CoreException {
/* 181 */     create(content, force ? 1 : 0, monitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCharset() throws CoreException {
/* 186 */     return getCharset(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCharset(boolean checkImplicit) throws CoreException {
/* 192 */     ResourceInfo info = getResourceInfo(false, false);
/* 193 */     int flags = getFlags(info);
/* 194 */     if (!exists(flags, false))
/* 195 */       return checkImplicit ? this.workspace.getCharsetManager().getCharsetFor(getFullPath().removeLastSegments(1), true) : null; 
/* 196 */     checkLocal(flags, 0);
/*     */     try {
/* 198 */       return internalGetCharset(checkImplicit, info);
/* 199 */     } catch (CoreException e) {
/* 200 */       if (e.getStatus().getCode() == 368) {
/* 201 */         return checkImplicit ? this.workspace.getCharsetManager().getCharsetFor(getFullPath().removeLastSegments(1), true) : null;
/*     */       }
/* 203 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCharsetFor(Reader contents) throws CoreException {
/*     */     IContentDescription description;
/* 210 */     ResourceInfo info = getResourceInfo(false, false);
/* 211 */     int flags = getFlags(info);
/* 212 */     if (exists(flags, true)) {
/*     */       String str;
/* 214 */       if ((str = this.workspace.getCharsetManager().getCharsetFor(getFullPath(), false)) != null)
/*     */       {
/* 216 */         return str;
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/* 221 */       IContentTypeManager contentTypeManager = Platform.getContentTypeManager();
/* 222 */       description = contentTypeManager.getDescriptionFor(contents, getName(), new QualifiedName[] { IContentDescription.CHARSET });
/* 223 */     } catch (IOException e) {
/* 224 */       String message = NLS.bind(Messages.resources_errorContentDescription, getFullPath());
/* 225 */       throw new ResourceException(381, getFullPath(), message, e);
/*     */     }  String charset;
/* 227 */     if (description != null && (
/* 228 */       charset = description.getCharset()) != null)
/*     */     {
/* 230 */       return charset;
/*     */     }
/* 232 */     return this.workspace.getCharsetManager().getCharsetFor(getFullPath().removeLastSegments(1), true);
/*     */   }
/*     */ 
/*     */   
/*     */   private String internalGetCharset(boolean checkImplicit, ResourceInfo info) throws CoreException {
/* 237 */     String charset = this.workspace.getCharsetManager().getCharsetFor(getFullPath(), false);
/* 238 */     if (charset != null || !checkImplicit) {
/* 239 */       return charset;
/*     */     }
/* 241 */     IContentDescription description = this.workspace.getContentDescriptionManager().getDescriptionFor(this, info, true);
/* 242 */     if (description != null) {
/* 243 */       String contentCharset = description.getCharset();
/* 244 */       if (contentCharset != null) {
/* 245 */         return contentCharset;
/*     */       }
/*     */     } 
/* 248 */     return this.workspace.getCharsetManager().getCharsetFor(getFullPath().removeLastSegments(1), true);
/*     */   }
/*     */ 
/*     */   
/*     */   public IContentDescription getContentDescription() throws CoreException {
/* 253 */     ResourceInfo info = getResourceInfo(false, false);
/* 254 */     int flags = getFlags(info);
/* 255 */     checkAccessible(flags);
/* 256 */     checkLocal(flags, 0);
/* 257 */     boolean isSynchronized = isSynchronized(0);
/*     */     
/* 259 */     if (!isSynchronized && !getLocalManager().isLightweightAutoRefreshEnabled()) {
/* 260 */       String message = NLS.bind(Messages.localstore_resourceIsOutOfSync, getFullPath());
/* 261 */       throw new ResourceException(274, getFullPath(), message, null);
/*     */     } 
/* 263 */     return this.workspace.getContentDescriptionManager().getDescriptionFor(this, info, isSynchronized);
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getContents() throws CoreException {
/* 268 */     return getContents(getLocalManager().isLightweightAutoRefreshEnabled());
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getContents(boolean force) throws CoreException {
/* 273 */     ResourceInfo info = getResourceInfo(false, false);
/* 274 */     int flags = getFlags(info);
/* 275 */     checkAccessible(flags);
/* 276 */     checkLocal(flags, 0);
/* 277 */     return getLocalManager().read(this, force, null);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int getEncoding() throws CoreException {
/* 283 */     ResourceInfo info = getResourceInfo(false, false);
/* 284 */     int flags = getFlags(info);
/* 285 */     checkAccessible(flags);
/* 286 */     checkLocal(flags, 0);
/* 287 */     return getLocalManager().getEncoding(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileState[] getHistory(IProgressMonitor monitor) {
/* 292 */     return getLocalManager().getHistoryStore().getStates(getFullPath(), monitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getType() {
/* 297 */     return 1;
/*     */   }
/*     */   
/*     */   protected void internalSetContents(InputStream content, IFileInfo fileInfo, int updateFlags, boolean append, IProgressMonitor monitor) throws CoreException {
/* 301 */     if (content == null)
/* 302 */       content = new ByteArrayInputStream(new byte[0]); 
/* 303 */     getLocalManager().write(this, content, fileInfo, updateFlags, append, monitor);
/* 304 */     updateMetadataFiles();
/* 305 */     this.workspace.getAliasManager().updateAliases(this, getStore(), 0, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refreshLocal(int depth, IProgressMonitor monitor) throws CoreException {
/* 315 */     if (!getLocalManager().fastIsSynchronized(this)) {
/* 316 */       super.refreshLocal(0, monitor);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setContents(IFileState content, int updateFlags, IProgressMonitor monitor) throws CoreException {
/* 321 */     setContents(content.getContents(), updateFlags, monitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setContents(InputStream content, int updateFlags, IProgressMonitor monitor) throws CoreException {
/* 326 */     String message = NLS.bind(Messages.resources_settingContents, getFullPath());
/* 327 */     SubMonitor subMonitor = SubMonitor.convert(monitor, message, 100);
/*     */     try {
/* 329 */       if (this.workspace.shouldValidate)
/* 330 */         this.workspace.validateSave(this); 
/* 331 */       ISchedulingRule rule = this.workspace.getRuleFactory().modifyRule(this);
/* 332 */       SubMonitor newChild = subMonitor.newChild(1);
/*     */       try {
/* 334 */         this.workspace.prepareOperation(rule, (IProgressMonitor)newChild);
/* 335 */         ResourceInfo info = getResourceInfo(false, false);
/* 336 */         checkAccessible(getFlags(info));
/* 337 */         this.workspace.beginOperation(true);
/* 338 */         IFileInfo fileInfo = getStore().fetchInfo();
/* 339 */         internalSetContents(content, fileInfo, updateFlags, false, (IProgressMonitor)subMonitor.newChild(99));
/* 340 */       } catch (OperationCanceledException e) {
/* 341 */         this.workspace.getWorkManager().operationCanceled();
/* 342 */         throw e;
/*     */       } finally {
/* 344 */         this.workspace.endOperation(rule, true);
/*     */       } 
/*     */     } finally {
/* 347 */       subMonitor.done();
/* 348 */       FileUtil.safeClose(content);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long setLocalTimeStamp(long value) throws CoreException {
/* 355 */     long result = super.setLocalTimeStamp(value);
/* 356 */     if (this.path.segmentCount() == 2 && this.path.segment(1).equals(".project")) {
/*     */       
/* 358 */       ResourceInfo projectInfo = ((Project)getProject()).getResourceInfo(false, false);
/* 359 */       if (projectInfo != null)
/* 360 */         getLocalManager().updateLocalSync(projectInfo, result); 
/*     */     } 
/* 362 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateMetadataFiles() throws CoreException {
/* 374 */     int count = this.path.segmentCount();
/* 375 */     String name = this.path.segment(1);
/*     */     
/* 377 */     if (count == 2 && name.equals(".project")) {
/* 378 */       Project project = (Project)getProject();
/* 379 */       project.updateDescription();
/*     */       
/* 381 */       ProjectInfo projectInfo = (ProjectInfo)project.getResourceInfo(false, true);
/* 382 */       projectInfo.discardNatures();
/*     */       
/*     */       return;
/*     */     } 
/* 386 */     if (count == 3 && ".settings".equals(name)) {
/* 387 */       ProjectPreferences.updatePreferences(this);
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setCharset(String newCharset) throws CoreException {
/* 395 */     ResourceInfo info = getResourceInfo(false, false);
/* 396 */     checkAccessible(getFlags(info));
/* 397 */     this.workspace.getCharsetManager().setCharsetFor(getFullPath(), newCharset);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCharset(String newCharset, IProgressMonitor monitor) throws CoreException {
/* 402 */     String message = NLS.bind(Messages.resources_settingCharset, getFullPath());
/* 403 */     SubMonitor subMonitor = SubMonitor.convert(monitor, message, 100);
/*     */ 
/*     */     
/* 406 */     ISchedulingRule rule = this.workspace.getRuleFactory().charsetRule(this);
/* 407 */     SubMonitor newChild = subMonitor.newChild(1);
/*     */     try {
/* 409 */       this.workspace.prepareOperation(rule, (IProgressMonitor)newChild);
/* 410 */       ResourceInfo info = getResourceInfo(false, false);
/* 411 */       checkAccessible(getFlags(info));
/* 412 */       this.workspace.beginOperation(true);
/* 413 */       this.workspace.getCharsetManager().setCharsetFor(getFullPath(), newCharset);
/* 414 */       info = getResourceInfo(false, true);
/* 415 */       info.incrementCharsetGenerationCount();
/* 416 */       subMonitor.worked(99);
/* 417 */     } catch (OperationCanceledException e) {
/* 418 */       this.workspace.getWorkManager().operationCanceled();
/* 419 */       throw e;
/*     */     } finally {
/* 421 */       subMonitor.done();
/* 422 */       this.workspace.endOperation(rule, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContents(InputStream content, boolean force, boolean keepHistory, IProgressMonitor monitor) throws CoreException {
/* 429 */     int updateFlags = force ? 1 : 0;
/* 430 */     updateFlags |= keepHistory ? 2 : 0;
/* 431 */     setContents(content, updateFlags, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContents(IFileState source, boolean force, boolean keepHistory, IProgressMonitor monitor) throws CoreException {
/* 437 */     int updateFlags = force ? 1 : 0;
/* 438 */     updateFlags |= keepHistory ? 2 : 0;
/* 439 */     setContents(source.getContents(), updateFlags, monitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLineSeparator(boolean checkParent) throws CoreException {
/* 444 */     if (exists()) {
/* 445 */       try { Exception exception1 = null, exception2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         try {  }
/*     */         finally
/* 459 */         { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (CoreException core)
/* 460 */       { if (!checkParent) {
/* 461 */           throw core;
/*     */         } }
/* 463 */       catch (IOException io)
/* 464 */       { if (!checkParent) {
/* 465 */           throw new CoreException(Status.error(io.getMessage(), io));
/*     */         } }
/*     */     
/*     */     }
/* 469 */     return checkParent ? getProject().getDefaultLineSeparator() : null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\File.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */