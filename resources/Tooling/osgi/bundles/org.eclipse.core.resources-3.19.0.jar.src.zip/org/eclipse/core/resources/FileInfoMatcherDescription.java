/*    */ package org.eclipse.core.resources;
/*    */ 
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FileInfoMatcherDescription
/*    */ {
/*    */   private String id;
/*    */   private Object arguments;
/*    */   
/*    */   public FileInfoMatcherDescription(String id, Object arguments) {
/* 30 */     this.id = id;
/* 31 */     this.arguments = arguments;
/*    */   }
/*    */   
/*    */   public Object getArguments() {
/* 35 */     return this.arguments;
/*    */   }
/*    */   
/*    */   public String getId() {
/* 39 */     return this.id;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 45 */     int result = 1;
/* 46 */     result = 31 * result + Objects.hashCode(this.arguments);
/* 47 */     result = 31 * result + Objects.hashCode(this.id);
/* 48 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 53 */     if (this == obj)
/* 54 */       return true; 
/* 55 */     if (obj == null)
/* 56 */       return false; 
/* 57 */     if (getClass() != obj.getClass())
/* 58 */       return false; 
/* 59 */     FileInfoMatcherDescription other = (FileInfoMatcherDescription)obj;
/* 60 */     return (Objects.equals(this.arguments, other.arguments) && Objects.equals(this.id, other.id));
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\FileInfoMatcherDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */