/*     */ package org.eclipse.core.internal.watson;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.dtree.DataTreeWriter;
/*     */ import org.eclipse.core.internal.dtree.DeltaDataTree;
/*     */ import org.eclipse.core.internal.dtree.IDataFlattener;
/*     */ import org.eclipse.core.internal.resources.SaveManager;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElementTreeWriter
/*     */ {
/*     */   public static final int CURRENT_FORMAT = 1;
/*     */   public static final int D_INFINITE = -1;
/*     */   protected DataTreeWriter dataTreeWriter;
/*     */   
/*     */   public ElementTreeWriter(final IElementInfoFlattener flattener) {
/*  63 */     IDataFlattener f = new IDataFlattener()
/*     */       {
/*     */         
/*     */         public void writeData(IPath path, Object data, DataOutput output) throws IOException
/*     */         {
/*  68 */           if (!Path.ROOT.equals(path)) {
/*  69 */             flattener.writeElement(path, data, output);
/*     */           }
/*     */         }
/*     */ 
/*     */         
/*     */         public Object readData(IPath path, DataInput input) {
/*  75 */           return null;
/*     */         }
/*     */       };
/*  78 */     this.dataTreeWriter = new DataTreeWriter(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ElementTree[] writeSortedTrees(ElementTree[] trees, DataOutput output) throws IOException {
/*  89 */     ElementTree[] sorted = SaveManager.sortTrees(trees);
/*  90 */     if (sorted == null) {
/*  91 */       throw new IOException("Unable to save workspace - Trees in ambiguous order (Bug 352867)");
/*     */     }
/*     */ 
/*     */     
/*  95 */     int numTrees = trees.length;
/*  96 */     Map<ElementTree, Deque<Integer>> indicesByTree = new HashMap<>(); int i;
/*  97 */     for (i = 0; i < numTrees; i++) {
/*  98 */       ((Deque<Integer>)indicesByTree.computeIfAbsent(trees[i], k -> new ArrayDeque())).push(Integer.valueOf(i));
/*     */     }
/*     */ 
/*     */     
/* 102 */     for (i = 0; i < numTrees; i++) {
/* 103 */       Integer order = ((Deque<Integer>)indicesByTree.get(sorted[i])).pop();
/* 104 */       writeNumber(order.intValue(), output);
/*     */     } 
/* 106 */     return sorted;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDelta(ElementTree olderTree, ElementTree newerTree, IPath path, int depth, DataOutput output, IElementComparator comparator) throws IOException {
/* 122 */     writeNumber(1, output);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     DeltaDataTree completeTree = newerTree.getDataTree();
/* 130 */     DeltaDataTree derivedTree = olderTree.getDataTree();
/* 131 */     DeltaDataTree deltaToWrite = completeTree.forwardDeltaWith(derivedTree, comparator);
/*     */     
/* 133 */     Assert.isTrue(deltaToWrite.isImmutable());
/* 134 */     this.dataTreeWriter.writeTree(deltaToWrite, path, depth, output);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeDeltaChain(ElementTree[] trees, IPath path, int depth, DataOutput output, IElementComparator comparator) throws IOException {
/* 150 */     writeNumber(1, output);
/*     */ 
/*     */     
/* 153 */     int treeCount = trees.length;
/* 154 */     writeNumber(treeCount, output);
/*     */     
/* 156 */     if (treeCount <= 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 164 */     ElementTree[] sortedTrees = writeSortedTrees(trees, output);
/*     */ 
/*     */     
/* 167 */     writeTree(sortedTrees[0], path, depth, output);
/*     */ 
/*     */     
/* 170 */     for (int i = 1; i < treeCount; i++) {
/* 171 */       writeDelta(sortedTrees[i], sortedTrees[i - 1], path, depth, output, comparator);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeNumber(int number, DataOutput output) throws IOException {
/* 181 */     if (number >= 0 && number < 255) {
/* 182 */       output.writeByte(number);
/*     */     } else {
/* 184 */       output.writeByte(255);
/* 185 */       output.writeInt(number);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTree(ElementTree tree, IPath path, int depth, DataOutput output) throws IOException {
/* 204 */     writeNumber(1, output);
/*     */ 
/*     */     
/* 207 */     DeltaDataTree subtree = new DeltaDataTree(tree.getDataTree().copyCompleteSubtree((IPath)Path.ROOT));
/*     */     
/* 209 */     this.dataTreeWriter.writeTree(subtree, path, depth, output);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\watson\ElementTreeWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */