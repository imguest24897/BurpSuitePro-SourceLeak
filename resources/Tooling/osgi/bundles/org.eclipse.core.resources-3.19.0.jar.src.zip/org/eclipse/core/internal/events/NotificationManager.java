/*     */ package org.eclipse.core.internal.events;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.eclipse.core.internal.resources.IManager;
/*     */ import org.eclipse.core.internal.resources.MarkerSet;
/*     */ import org.eclipse.core.internal.resources.Workspace;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.internal.watson.ElementTree;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceChangeListener;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.ICoreRunnable;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ 
/*     */ public class NotificationManager implements IManager, ILifecycleListener {
/*     */   private static final long NOTIFICATION_DELAY = 1500L;
/*     */   
/*     */   class NotifyJob extends Job {
/*     */     private final ICoreRunnable noop = monitor -> {
/*     */       
/*     */       };
/*     */     
/*     */     public NotifyJob() {
/*  36 */       super(Messages.resources_updating);
/*  37 */       setSystem(true);
/*     */     }
/*     */ 
/*     */     
/*     */     public IStatus run(IProgressMonitor monitor) {
/*  42 */       if (monitor.isCanceled())
/*  43 */         return Status.CANCEL_STATUS; 
/*  44 */       NotificationManager.this.notificationRequested = true;
/*     */       try {
/*  46 */         NotificationManager.this.workspace.run(this.noop, null, 0, null);
/*  47 */       } catch (CoreException e) {
/*  48 */         return e.getStatus();
/*     */       } 
/*  50 */       return Status.OK_STATUS;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean belongsTo(Object family) {
/*  55 */       return (NotificationManager.class == family);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   private final Set<Thread> avoidNotify = ConcurrentHashMap.newKeySet();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected volatile boolean isNotifying;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile ResourceDelta lastDelta;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile long lastDeltaId;
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile ElementTree lastDeltaState;
/*     */ 
/*     */ 
/*     */   
/*  86 */   protected volatile long lastNotifyDuration = 0L;
/*     */ 
/*     */ 
/*     */   
/*  90 */   private volatile long lastPostBuildId = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile ElementTree lastPostBuildTree;
/*     */ 
/*     */ 
/*     */   
/*  99 */   private volatile long lastPostChangeId = 0L;
/*     */   
/*     */   private volatile ElementTree lastPostChangeTree;
/*     */   
/*     */   private final ResourceChangeListenerList listeners;
/*     */   
/*     */   protected volatile boolean notificationRequested = false;
/*     */   
/*     */   private final Job notifyJob;
/*     */   
/*     */   private final Workspace workspace;
/*     */ 
/*     */   
/*     */   public NotificationManager(Workspace workspace) {
/* 113 */     this.workspace = workspace;
/* 114 */     this.listeners = new ResourceChangeListenerList();
/* 115 */     this.notifyJob = new NotifyJob();
/*     */   }
/*     */   
/*     */   public void addListener(IResourceChangeListener listener, int eventMask) {
/* 119 */     this.listeners.add(listener, eventMask);
/* 120 */     if (ResourceStats.TRACE_LISTENERS) {
/* 121 */       ResourceStats.listenerAdded(listener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean beginAvoidNotify() {
/* 130 */     return this.avoidNotify.add(Thread.currentThread());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beginNotify() {
/* 137 */     this.notifyJob.cancel();
/* 138 */     this.notificationRequested = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void broadcastChanges(ElementTree lastState, ResourceChangeEvent event, boolean lockTree) {
/* 145 */     int type = event.getType();
/*     */     
/*     */     try {
/* 148 */       if (!this.listeners.hasListenerFor(type))
/*     */         return; 
/* 150 */       this.isNotifying = true;
/* 151 */       ResourceDelta delta = getDelta(lastState, type);
/*     */       
/* 153 */       if (delta == null || delta.getKind() == 0) {
/* 154 */         int trigger = event.getBuildKind();
/* 155 */         if (trigger == 9 || trigger == 0)
/*     */           return; 
/*     */       } 
/* 158 */       event.setDelta(delta);
/* 159 */       long start = System.currentTimeMillis();
/* 160 */       notify(getListeners(), event, lockTree);
/* 161 */       this.lastNotifyDuration = System.currentTimeMillis() - start;
/*     */     } finally {
/*     */       
/* 164 */       this.isNotifying = false;
/* 165 */       cleanUp(lastState, type);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void cleanUp(ElementTree lastState, int type) {
/* 175 */     boolean postChange = (type == 1);
/* 176 */     if (postChange || type == 16) {
/* 177 */       long id = this.workspace.getMarkerManager().getChangeId();
/* 178 */       lastState.immutable();
/* 179 */       if (postChange) {
/* 180 */         this.lastPostChangeTree = lastState;
/* 181 */         this.lastPostChangeId = id;
/*     */       } else {
/* 183 */         this.lastPostBuildTree = lastState;
/* 184 */         this.lastPostBuildId = id;
/*     */       } 
/* 186 */       this.workspace.getMarkerManager().resetMarkerDeltas(Math.min(this.lastPostBuildId, this.lastPostChangeId));
/* 187 */       this.lastDelta = null;
/* 188 */       this.lastDeltaState = lastState;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void broadcastChanges(IResourceChangeListener listener, int type, IResourceDelta delta) {
/* 196 */     ResourceChangeListenerList.ListenerEntry[] entries = { new ResourceChangeListenerList.ListenerEntry(listener, type) };
/* 197 */     notify(entries, new ResourceChangeEvent(this.workspace, type, 0, delta), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endAvoidNotify() {
/* 204 */     this.avoidNotify.remove(Thread.currentThread());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void requestNotify() {
/* 212 */     if (this.isNotifying || this.avoidNotify.contains(Thread.currentThread())) {
/*     */       return;
/*     */     }
/* 215 */     long delay = Math.max(1500L, this.lastNotifyDuration * 10L);
/* 216 */     if (this.notifyJob.getState() == 0) {
/* 217 */       this.notifyJob.schedule(delay);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceDelta getDelta(ElementTree tree, int type) {
/* 225 */     long id = this.workspace.getMarkerManager().getChangeId();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 230 */     boolean postChange = (type == 1);
/* 231 */     if (!postChange && this.lastDelta != null && !ElementTree.hasChanges(tree, this.lastDeltaState, ResourceComparator.getNotificationComparator(), true)) {
/*     */ 
/*     */       
/* 234 */       if (id != this.lastDeltaId) {
/* 235 */         Map<IPath, MarkerSet> markerDeltas = this.workspace.getMarkerManager().getMarkerDeltas(this.lastPostBuildId);
/* 236 */         this.lastDelta.updateMarkers(markerDeltas);
/*     */       } 
/*     */     } else {
/*     */       
/* 240 */       ElementTree oldTree = postChange ? this.lastPostChangeTree : this.lastPostBuildTree;
/* 241 */       long markerId = postChange ? this.lastPostChangeId : this.lastPostBuildId;
/* 242 */       this.lastDelta = ResourceDeltaFactory.computeDelta(this.workspace, oldTree, tree, (IPath)Path.ROOT, markerId + 1L);
/*     */     } 
/*     */     
/* 245 */     this.lastDeltaState = tree;
/* 246 */     this.lastDeltaId = id;
/* 247 */     return this.lastDelta;
/*     */   }
/*     */   
/*     */   protected ResourceChangeListenerList.ListenerEntry[] getListeners() {
/* 251 */     return this.listeners.getListeners();
/*     */   }
/*     */   
/*     */   public void handleEvent(LifecycleEvent event) {
/*     */     IProject project;
/* 256 */     switch (event.kind) {
/*     */       case 1:
/* 258 */         if (!this.listeners.hasListenerFor(2))
/*     */           return; 
/* 260 */         project = (IProject)event.resource;
/* 261 */         notify(getListeners(), new ResourceChangeEvent(this.workspace, 2, (IResource)project), true);
/*     */         break;
/*     */ 
/*     */       
/*     */       case 64:
/* 266 */         if (event.resource.equals(event.newResource)) {
/*     */           return;
/*     */         }
/*     */       case 16:
/* 270 */         if (!this.listeners.hasListenerFor(4))
/*     */           return; 
/* 272 */         project = (IProject)event.resource;
/* 273 */         notify(getListeners(), new ResourceChangeEvent(this.workspace, 4, (IResource)project), true);
/*     */         break;
/*     */       case 4096:
/* 276 */         if (!this.listeners.hasListenerFor(32))
/*     */           return; 
/* 278 */         if (event.resource.getType() == 4) {
/* 279 */           notify(getListeners(), new ResourceChangeEvent(event.resource, 32, event.resource), true); break;
/* 280 */         }  if (event.resource.getType() == 8)
/* 281 */           notify(getListeners(), new ResourceChangeEvent(this.workspace, 32, null), true); 
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void notify(ResourceChangeListenerList.ListenerEntry[] resourceListeners, final ResourceChangeEvent event, boolean lockTree) {
/* 287 */     int type = event.getType();
/* 288 */     boolean oldLock = this.workspace.isTreeLocked();
/* 289 */     if (lockTree)
/* 290 */       this.workspace.setTreeLocked(true);  try {
/*     */       byte b; int i; ResourceChangeListenerList.ListenerEntry[] arrayOfListenerEntry;
/* 292 */       for (i = (arrayOfListenerEntry = resourceListeners).length, b = 0; b < i; ) { ResourceChangeListenerList.ListenerEntry resourceListener = arrayOfListenerEntry[b];
/* 293 */         if ((type & resourceListener.eventMask) != 0) {
/* 294 */           final IResourceChangeListener listener = resourceListener.listener;
/* 295 */           if (ResourceStats.TRACE_LISTENERS)
/* 296 */             ResourceStats.startNotify(listener); 
/* 297 */           SafeRunner.run(new ISafeRunnable()
/*     */               {
/*     */                 public void handleException(Throwable e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 public void run() throws Exception {
/* 305 */                   if (Policy.DEBUG_NOTIFICATIONS)
/* 306 */                     Policy.debug("Notifying " + listener.getClass().getName() + " about resource change event" + event.toDebugString()); 
/* 307 */                   listener.resourceChanged(event);
/*     */                 }
/*     */               });
/* 310 */           if (ResourceStats.TRACE_LISTENERS)
/* 311 */             ResourceStats.endNotify(); 
/*     */         }  b++; }
/*     */     
/*     */     } finally {
/* 315 */       if (lockTree)
/* 316 */         this.workspace.setTreeLocked(oldLock); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removeListener(IResourceChangeListener listener) {
/* 321 */     this.listeners.remove(listener);
/* 322 */     if (ResourceStats.TRACE_LISTENERS) {
/* 323 */       ResourceStats.listenerRemoved(listener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldNotify() {
/* 332 */     return (!this.isNotifying && this.notificationRequested);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown(IProgressMonitor monitor) {
/* 338 */     this.listeners.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startup(IProgressMonitor monitor) {
/* 346 */     this.lastPostBuildTree = this.lastPostChangeTree = this.workspace.getElementTree();
/* 347 */     this.workspace.addLifecycleListener(this);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\NotificationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */