/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MarkerDeltaManager
/*    */ {
/*    */   private static final int DEFAULT_SIZE = 10;
/* 32 */   private long[] startIds = new long[10];
/*    */   
/* 34 */   private Map<IPath, MarkerSet>[] batches = (Map<IPath, MarkerSet>[])new Map[10];
/* 35 */   private int nextFree = 0;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Map<IPath, MarkerSet> assembleDeltas(long start) {
/* 42 */     Map<IPath, MarkerSet> result = null;
/* 43 */     for (int i = 0; i < this.nextFree; i++) {
/* 44 */       if (this.startIds[i] >= start)
/* 45 */         result = MarkerDelta.merge(result, this.batches[i]); 
/* 46 */     }  return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void resetDeltas(long startId) {
/*    */     Map[] arrayOfMap;
/* 55 */     int startOffset = 0;
/* 56 */     for (; startOffset < this.nextFree && 
/* 57 */       this.startIds[startOffset] < startId; startOffset++);
/*    */     
/* 59 */     if (startOffset == 0)
/*    */       return; 
/* 61 */     long[] newIds = this.startIds;
/* 62 */     Map<IPath, MarkerSet>[] arrayOfMap1 = this.batches;
/*    */     
/* 64 */     if (this.startIds.length > 10 && this.nextFree - startOffset < 10) {
/* 65 */       newIds = new long[10];
/* 66 */       arrayOfMap = new Map[10];
/*    */     } 
/*    */     
/* 69 */     int remaining = this.nextFree - startOffset;
/* 70 */     System.arraycopy(this.startIds, startOffset, newIds, 0, remaining);
/* 71 */     System.arraycopy(this.batches, startOffset, arrayOfMap, 0, remaining);
/*    */     
/* 73 */     Arrays.fill(this.startIds, remaining, this.startIds.length, 0L);
/* 74 */     Arrays.fill((Object[])this.batches, remaining, this.startIds.length, (Object)null);
/* 75 */     this.startIds = newIds;
/* 76 */     this.batches = (Map<IPath, MarkerSet>[])arrayOfMap;
/* 77 */     this.nextFree = remaining;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Map<IPath, MarkerSet> newGeneration(long start) {
/* 82 */     int len = this.startIds.length;
/* 83 */     if (this.nextFree >= len) {
/* 84 */       long[] newIds = new long[len * 2];
/* 85 */       Map[] newBatches = new Map[len * 2];
/* 86 */       System.arraycopy(this.startIds, 0, newIds, 0, len);
/* 87 */       System.arraycopy(this.batches, 0, newBatches, 0, len);
/* 88 */       this.startIds = newIds;
/* 89 */       this.batches = (Map<IPath, MarkerSet>[])newBatches;
/*    */     } 
/* 91 */     this.startIds[this.nextFree] = start;
/* 92 */     this.batches[this.nextFree] = new HashMap<>(11);
/* 93 */     return this.batches[this.nextFree++];
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\MarkerDeltaManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */