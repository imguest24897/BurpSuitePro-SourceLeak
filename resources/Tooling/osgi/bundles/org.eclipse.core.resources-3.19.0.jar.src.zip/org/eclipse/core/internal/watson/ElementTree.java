/*     */ package org.eclipse.core.internal.watson;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.eclipse.core.internal.dtree.AbstractDataTreeNode;
/*     */ import org.eclipse.core.internal.dtree.DataTreeLookup;
/*     */ import org.eclipse.core.internal.dtree.DataTreeNode;
/*     */ import org.eclipse.core.internal.dtree.DeltaDataTree;
/*     */ import org.eclipse.core.internal.dtree.ObjectNotFoundException;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.StringPool;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElementTree
/*     */ {
/*     */   protected final DeltaDataTree tree;
/*     */   protected volatile IElementTreeData userData;
/*     */   
/*     */   private static final class ChildIDsCache
/*     */   {
/*     */     final IPath path;
/*     */     final IPath[] childPaths;
/*     */     
/*     */     ChildIDsCache(IPath path, IPath[] childPaths) {
/* 103 */       this.path = path;
/* 104 */       this.childPaths = childPaths;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   private volatile ChildIDsCache childIDsCache = null;
/*     */ 
/*     */   
/* 115 */   private volatile DataTreeLookup lookupCache = null;
/*     */ 
/*     */   
/* 118 */   private volatile DataTreeLookup lookupCacheIgnoreCase = null;
/*     */   
/* 120 */   private static final AtomicInteger treeCounter = new AtomicInteger();
/*     */ 
/*     */   
/*     */   private final int treeStamp;
/*     */ 
/*     */   
/*     */   public ElementTree() {
/* 127 */     this(new DeltaDataTree());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ElementTree(DataTreeNode rootNode) {
/* 135 */     this(new DeltaDataTree((AbstractDataTreeNode)new DataTreeNode(null, null, new AbstractDataTreeNode[] { (AbstractDataTreeNode)rootNode })));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ElementTree(DeltaDataTree newTree) {
/* 145 */     this.treeStamp = treeCounter.incrementAndGet();
/* 146 */     newTree.setRootData(this);
/* 147 */     this.tree = newTree;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ElementTree(ElementTree parent) {
/* 155 */     this(parent.tree.newEmptyDeltaTree());
/*     */ 
/*     */     
/* 158 */     IElementTreeData data = parent.getTreeData();
/* 159 */     if (data != null) {
/* 160 */       this.userData = (IElementTreeData)data.clone();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized ElementTree collapseTo(ElementTree parent) {
/* 177 */     Assert.isTrue(this.tree.isImmutable());
/* 178 */     if (this == parent)
/*     */     {
/* 180 */       return this;
/*     */     }
/*     */     
/* 183 */     this.tree.collapseTo(parent.tree, DefaultElementComparator.getComparator());
/* 184 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void createElement(IPath key, Object data) {
/* 199 */     if (key.isRoot()) {
/*     */       return;
/*     */     }
/*     */     
/* 203 */     this.childIDsCache = null;
/*     */     
/* 205 */     IPath parent = key.removeLastSegments(1);
/*     */     try {
/* 207 */       this.tree.createChild(parent, key.lastSegment(), data);
/* 208 */     } catch (ObjectNotFoundException objectNotFoundException) {
/* 209 */       throw createElementNotFoundException(parent);
/*     */     } 
/*     */     
/* 212 */     this.lookupCache = DataTreeLookup.newLookup(key, true, data, true);
/* 213 */     this.lookupCacheIgnoreCase = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void createSubtree(IPath key, ElementTree subtree) {
/* 227 */     if (key.isRoot()) {
/* 228 */       throw new IllegalArgumentException(Messages.watson_noModify);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 233 */     this.childIDsCache = null;
/*     */ 
/*     */     
/* 236 */     this.lookupCache = this.lookupCacheIgnoreCase = null;
/*     */     
/*     */     try {
/* 239 */       IPath[] children = subtree.getChildren(subtree.getRoot());
/* 240 */       if (children.length != 1) {
/* 241 */         throw new IllegalArgumentException(Messages.watson_illegalSubtree);
/*     */       }
/*     */ 
/*     */       
/* 245 */       DataTreeNode node = (DataTreeNode)subtree.tree.copyCompleteSubtree(children[0]);
/*     */ 
/*     */       
/* 248 */       this.tree.createSubtree(key, (AbstractDataTreeNode)node);
/*     */     }
/* 250 */     catch (ObjectNotFoundException objectNotFoundException) {
/* 251 */       throw createElementNotFoundException(key);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void deleteElement(IPath key) {
/* 261 */     if (key.isRoot()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 266 */     this.childIDsCache = null;
/*     */ 
/*     */     
/* 269 */     this.lookupCache = this.lookupCacheIgnoreCase = null;
/*     */     try {
/* 271 */       this.tree.deleteChild(key.removeLastSegments(1), key.lastSegment());
/* 272 */     } catch (ObjectNotFoundException objectNotFoundException) {
/* 273 */       throw createElementNotFoundException(key);
/*     */     } 
/*     */   }
/*     */   
/*     */   private IllegalArgumentException createElementNotFoundException(IPath key) {
/* 278 */     return new IllegalArgumentException(NLS.bind(Messages.watson_elementNotFound, key));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int findOldest(ElementTree[] trees) {
/* 293 */     HashSet<ElementTree> candidates = new LinkedHashSet<>(List.of(trees));
/*     */ 
/*     */     
/* 296 */     ElementTree oldestSoFar = null;
/* 297 */     while (!candidates.isEmpty()) {
/*     */       
/* 299 */       ElementTree current = candidates.iterator().next();
/*     */ 
/*     */       
/* 302 */       candidates.remove(current);
/*     */ 
/*     */       
/* 305 */       ElementTree parent = current.getParent();
/*     */ 
/*     */       
/* 308 */       while (parent != null && parent != oldestSoFar) {
/* 309 */         candidates.remove(parent);
/* 310 */         parent = parent.getParent();
/*     */       } 
/*     */ 
/*     */       
/* 314 */       oldestSoFar = current;
/*     */     } 
/*     */ 
/*     */     
/* 318 */     Assert.isNotNull(oldestSoFar);
/*     */ 
/*     */     
/* 321 */     for (int i = 0; i < trees.length; i++) {
/* 322 */       if (trees[i] == oldestSoFar) {
/* 323 */         return i;
/*     */       }
/*     */     } 
/* 326 */     Assert.isTrue(false, "Should not get here");
/* 327 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int getChildCount(IPath key) {
/* 336 */     Assert.isNotNull(key);
/* 337 */     return (getChildIDs(key)).length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IPath[] getChildIDs(IPath key) {
/* 345 */     ChildIDsCache cache = this.childIDsCache;
/* 346 */     if (cache != null && cache.path == key) {
/* 347 */       return cache.childPaths;
/*     */     }
/* 349 */     if (key == null)
/* 350 */       return this.tree.rootPaths(); 
/*     */     try {
/* 352 */       IPath[] children = this.tree.getChildren(key);
/* 353 */       this.childIDsCache = new ChildIDsCache(key, children);
/* 354 */       return children;
/* 355 */     } catch (ObjectNotFoundException objectNotFoundException) {
/* 356 */       throw createElementNotFoundException(key);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized IPath[] getChildren(IPath key) {
/* 366 */     Assert.isNotNull(key);
/* 367 */     return getChildIDs(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeltaDataTree getDataTree() {
/* 374 */     return this.tree;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object getElementData(IPath key) {
/* 383 */     if (key.isRoot())
/* 384 */       return null; 
/* 385 */     DataTreeLookup lookup = this.lookupCache;
/* 386 */     if (lookup == null || lookup.key != key)
/* 387 */       this.lookupCache = lookup = this.tree.lookup(key); 
/* 388 */     if (lookup.isPresent)
/* 389 */       return lookup.data; 
/* 390 */     throw createElementNotFoundException(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object getElementDataIgnoreCase(IPath key) {
/* 399 */     if (key.isRoot())
/* 400 */       return null; 
/* 401 */     DataTreeLookup lookup = this.lookupCacheIgnoreCase;
/* 402 */     if (lookup == null || lookup.key != key)
/* 403 */       this.lookupCacheIgnoreCase = lookup = this.tree.lookupIgnoreCase(key); 
/* 404 */     if (lookup.isPresent)
/* 405 */       return lookup.data; 
/* 406 */     throw createElementNotFoundException(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized String[] getNamesOfChildren(IPath key) {
/*     */     try {
/* 416 */       if (key == null)
/* 417 */         return new String[] { "" }; 
/* 418 */       return this.tree.getNamesOfChildren(key);
/* 419 */     } catch (ObjectNotFoundException objectNotFoundException) {
/* 420 */       throw createElementNotFoundException(key);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementTree getParent() {
/* 428 */     DeltaDataTree parentTree = this.tree.getParent();
/* 429 */     if (parentTree == null) {
/* 430 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 434 */     return (ElementTree)parentTree.getRootData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getRoot() {
/* 441 */     return getChildIDs(null)[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementTree getSubtree(IPath key) {
/* 455 */     if (key.isRoot()) {
/* 456 */       return this;
/*     */     }
/*     */     try {
/* 459 */       DataTreeNode elementNode = (DataTreeNode)this.tree.copyCompleteSubtree(key);
/* 460 */       return new ElementTree(elementNode);
/* 461 */     } catch (ObjectNotFoundException objectNotFoundException) {
/* 462 */       throw createElementNotFoundException(key);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IElementTreeData getTreeData() {
/* 470 */     return this.userData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasChanges(ElementTree newLayer, ElementTree oldLayer, IElementComparator comparator, boolean inclusive) {
/* 480 */     if (newLayer == null || oldLayer == null)
/* 481 */       return true; 
/* 482 */     if (newLayer == oldLayer) {
/* 483 */       return false;
/*     */     }
/* 485 */     if (comparator.compare(newLayer.getTreeData(), oldLayer.getTreeData()) != 0) {
/* 486 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 496 */     ElementTree stopLayer = null;
/* 497 */     if (newLayer.isImmutable()) {
/*     */ 
/*     */       
/* 500 */       stopLayer = newLayer.getParent();
/*     */     } else {
/* 502 */       ElementTree elementTree = newLayer;
/* 503 */       while (elementTree != null && elementTree.getParent() != null) {
/* 504 */         if (!elementTree.getDataTree().isEmptyDelta())
/* 505 */           return true; 
/* 506 */         elementTree = elementTree.getParent();
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 512 */     ElementTree layer = inclusive ? oldLayer : oldLayer.getParent();
/* 513 */     while (layer != null && layer.getParent() != stopLayer) {
/* 514 */       if (!layer.getDataTree().isEmptyDelta())
/* 515 */         return true; 
/* 516 */       layer = layer.getParent();
/*     */     } 
/*     */     
/* 519 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void immutable() {
/* 527 */     if (!this.tree.isImmutable()) {
/* 528 */       this.tree.immutable();
/*     */ 
/*     */       
/* 531 */       this.lookupCache = this.lookupCacheIgnoreCase = null;
/*     */       
/* 533 */       this.tree.reroot();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean includes(IPath key) {
/* 542 */     DataTreeLookup lookup = this.lookupCache;
/* 543 */     if (lookup == null || lookup.key != key) {
/* 544 */       this.lookupCache = lookup = this.tree.lookup(key);
/*     */     }
/* 546 */     return lookup.isPresent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean includesIgnoreCase(IPath key) {
/* 554 */     DataTreeLookup lookup = this.lookupCacheIgnoreCase;
/* 555 */     if (lookup == null || lookup.key != key) {
/* 556 */       this.lookupCacheIgnoreCase = lookup = this.tree.lookupIgnoreCase(key);
/*     */     }
/* 558 */     return lookup.isPresent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isImmutable() {
/* 565 */     return this.tree.isImmutable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementTree mergeDeltaChain(IPath path, ElementTree[] trees) {
/* 582 */     if (path == null || trees == null) {
/* 583 */       throw new IllegalArgumentException(NLS.bind(Messages.watson_nullArg, "ElementTree.mergeDeltaChain"));
/*     */     }
/*     */ 
/*     */     
/* 587 */     if (isImmutable()) {
/* 588 */       throw new IllegalArgumentException(Messages.watson_immutable);
/*     */     }
/* 590 */     ElementTree current = this;
/* 591 */     if (trees.length > 0) {
/*     */       
/* 593 */       ElementTree toMerge = trees[findOldest(trees)];
/*     */ 
/*     */       
/* 596 */       while (toMerge != null) {
/* 597 */         if (path.isRoot()) {
/*     */           
/* 599 */           IPath[] children = toMerge.getChildren((IPath)Path.ROOT); byte b; int j; IPath[] arrayOfIPath1;
/* 600 */           for (j = (arrayOfIPath1 = children).length, b = 0; b < j; ) { IPath element = arrayOfIPath1[b];
/* 601 */             current.createSubtree(element, toMerge.getSubtree(element));
/*     */             b++; }
/*     */         
/*     */         } else {
/* 605 */           current.createSubtree(path, toMerge.getSubtree(path));
/*     */         } 
/* 607 */         current.immutable();
/*     */ 
/*     */ 
/*     */         
/* 611 */         for (int i = 0; i < trees.length; i++) {
/* 612 */           if (trees[i] == toMerge) {
/* 613 */             trees[i] = current;
/*     */           }
/*     */         } 
/* 616 */         current = current.newEmptyDelta();
/* 617 */         toMerge = toMerge.getParent();
/*     */       } 
/*     */     } 
/* 620 */     return current;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized ElementTree newEmptyDelta() {
/* 630 */     this.lookupCache = this.lookupCacheIgnoreCase = null;
/* 631 */     if (!isImmutable()) {
/* 632 */       immutable();
/*     */     }
/* 634 */     return new ElementTree(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object openElementData(IPath key) {
/* 645 */     Assert.isTrue(!isImmutable());
/*     */ 
/*     */     
/* 648 */     if (key.isRoot())
/* 649 */       return null; 
/* 650 */     DataTreeLookup lookup = this.lookupCache;
/* 651 */     if (lookup == null || lookup.key != key) {
/* 652 */       this.lookupCache = lookup = this.tree.lookup(key);
/*     */     }
/* 654 */     if (lookup.isPresent) {
/* 655 */       if (lookup.foundInFirstDelta) {
/* 656 */         return lookup.data;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 661 */       IElementTreeData oldData = (IElementTreeData)lookup.data;
/* 662 */       if (oldData != null) {
/*     */         try {
/* 664 */           Object newData = oldData.clone();
/* 665 */           this.tree.setData(key, newData);
/* 666 */           this.lookupCache = this.lookupCacheIgnoreCase = null;
/* 667 */           return newData;
/* 668 */         } catch (ObjectNotFoundException objectNotFoundException) {
/* 669 */           throw createElementNotFoundException(key);
/*     */         } 
/*     */       }
/*     */     } else {
/* 673 */       throw createElementNotFoundException(key);
/*     */     } 
/* 675 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setElementData(IPath key, Object data) {
/* 686 */     if (key.isRoot()) {
/*     */       return;
/*     */     }
/* 689 */     Assert.isNotNull(key);
/*     */ 
/*     */     
/* 692 */     this.lookupCache = this.lookupCacheIgnoreCase = null;
/*     */     try {
/* 694 */       this.tree.setData(key, data);
/* 695 */     } catch (ObjectNotFoundException objectNotFoundException) {
/* 696 */       throw createElementNotFoundException(key);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTreeData(IElementTreeData data) {
/* 704 */     this.userData = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shareStrings(StringPool set) {
/* 711 */     this.tree.storeStrings(set);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toDebugString() {
/* 719 */     StringBuilder buffer = new StringBuilder("\n");
/* 720 */     IElementContentVisitor visitor = (aTree, elementID, elementContents) -> {
/*     */         paramStringBuilder.append(elementID.requestPath() + " " + elementContents + "\n");
/*     */         return true;
/*     */       };
/* 724 */     (new ElementTreeIterator(this, (IPath)Path.ROOT)).iterate(visitor);
/* 725 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 731 */     return "ElementTree(" + this.treeStamp + ")";
/*     */   }
/*     */   
/*     */   public int getTreeStamp() {
/* 735 */     return this.treeStamp;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\watson\ElementTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */