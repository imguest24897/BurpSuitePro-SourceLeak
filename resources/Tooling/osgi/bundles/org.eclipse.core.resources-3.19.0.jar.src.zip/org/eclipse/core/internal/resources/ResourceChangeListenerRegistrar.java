/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.eclipse.core.resources.IResourceChangeListener;
/*    */ import org.eclipse.core.resources.IWorkspace;
/*    */ import org.osgi.service.log.Logger;
/*    */ import org.osgi.service.log.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ResourceChangeListenerRegistrar
/*    */ {
/*    */   private final IWorkspace workspace;
/*    */   private Logger logger;
/*    */   
/*    */   public ResourceChangeListenerRegistrar(IWorkspace workspace) {
/* 44 */     this.workspace = workspace;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addResourceChangeListener(IResourceChangeListener listener, Map<String, Object> properties) {
/* 57 */     Object mask = properties.get("event.mask");
/* 58 */     if (mask instanceof Integer) {
/* 59 */       this.workspace.addResourceChangeListener(listener, ((Integer)mask).intValue());
/*    */     } else {
/* 61 */       Logger local = this.logger;
/* 62 */       if (mask != null && local != null)
/* 63 */         local.warn("event.mask of IResourceChangeListener service: expected Integer but was {} (from {}): {}", new Object[] {
/* 64 */               mask.getClass(), listener.getClass(), mask
/*    */             }); 
/* 66 */       this.workspace.addResourceChangeListener(listener);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void removeResourceChangeListener(IResourceChangeListener listener) {
/* 76 */     this.workspace.removeResourceChangeListener(listener);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setLoggerFactory(LoggerFactory factory) {
/* 85 */     this.logger = factory.getLogger(ResourceChangeListenerRegistrar.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void unsetLogger() {
/* 92 */     this.logger = null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ResourceChangeListenerRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */