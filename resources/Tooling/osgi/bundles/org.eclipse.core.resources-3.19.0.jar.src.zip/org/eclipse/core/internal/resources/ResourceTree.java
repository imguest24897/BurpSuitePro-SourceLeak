/*      */ package org.eclipse.core.internal.resources;
/*      */ 
/*      */ import java.net.URI;
/*      */ import org.eclipse.core.filesystem.EFS;
/*      */ import org.eclipse.core.filesystem.IFileInfo;
/*      */ import org.eclipse.core.filesystem.IFileStore;
/*      */ import org.eclipse.core.filesystem.IFileSystem;
/*      */ import org.eclipse.core.filesystem.URIUtil;
/*      */ import org.eclipse.core.internal.localstore.FileSystemResourceManager;
/*      */ import org.eclipse.core.internal.properties.IPropertyManager;
/*      */ import org.eclipse.core.internal.utils.BitMask;
/*      */ import org.eclipse.core.internal.utils.Messages;
/*      */ import org.eclipse.core.internal.utils.Policy;
/*      */ import org.eclipse.core.resources.IFile;
/*      */ import org.eclipse.core.resources.IFolder;
/*      */ import org.eclipse.core.resources.IProject;
/*      */ import org.eclipse.core.resources.IProjectDescription;
/*      */ import org.eclipse.core.resources.IResource;
/*      */ import org.eclipse.core.resources.IResourceVisitor;
/*      */ import org.eclipse.core.resources.ResourcesPlugin;
/*      */ import org.eclipse.core.resources.team.IResourceTree;
/*      */ import org.eclipse.core.runtime.Assert;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.MultiStatus;
/*      */ import org.eclipse.core.runtime.NullProgressMonitor;
/*      */ import org.eclipse.core.runtime.OperationCanceledException;
/*      */ import org.eclipse.core.runtime.jobs.ILock;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class ResourceTree
/*      */   implements IResourceTree
/*      */ {
/*      */   private boolean isValid = true;
/*      */   private final FileSystemResourceManager localManager;
/*      */   private ILock lock;
/*      */   private MultiStatus multistatus;
/*      */   private int updateFlags;
/*      */   
/*      */   public ResourceTree(FileSystemResourceManager localManager, ILock lock, MultiStatus status, int updateFlags) {
/*   53 */     this.localManager = localManager;
/*   54 */     this.lock = lock;
/*   55 */     this.multistatus = status;
/*   56 */     this.updateFlags = updateFlags;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addToLocalHistory(IFile file) {
/*   64 */     if (!FileSystemResourceManager.storeHistory((IResource)file)) {
/*      */       return;
/*      */     }
/*   67 */     Assert.isLegal(this.isValid);
/*      */     try {
/*   69 */       this.lock.acquire();
/*   70 */       if (!file.exists())
/*      */         return; 
/*   72 */       IFileStore store = this.localManager.getStore((IResource)file);
/*   73 */       IFileInfo fileInfo = store.fetchInfo();
/*   74 */       if (!fileInfo.exists())
/*      */         return; 
/*   76 */       this.localManager.getHistoryStore().addState(file.getFullPath(), store, fileInfo, false);
/*      */     } finally {
/*   78 */       this.lock.release();
/*      */     } 
/*      */   }
/*      */   
/*      */   private IFileStore computeDestinationStore(IProjectDescription destDescription) throws CoreException {
/*   83 */     URI destLocation = destDescription.getLocationURI();
/*      */     
/*   85 */     if (destLocation == null) {
/*   86 */       IPath rootLocation = ResourcesPlugin.getWorkspace().getRoot().getLocation();
/*   87 */       destLocation = rootLocation.append(destDescription.getName()).toFile().toURI();
/*      */     } 
/*   89 */     return EFS.getStore(destLocation);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long computeTimestamp(IFile file) {
/*   97 */     Assert.isLegal(this.isValid);
/*      */     try {
/*   99 */       this.lock.acquire();
/*  100 */       if (!file.getProject().exists())
/*  101 */         return 0L; 
/*  102 */       return internalComputeTimestamp(file);
/*      */     } finally {
/*  104 */       this.lock.release();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void copyLocalHistory(IResource source, IResource destination) {
/*  115 */     this.localManager.getHistoryStore().copyHistory(source, destination, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deletedFile(IFile file) {
/*  123 */     Assert.isLegal(this.isValid);
/*      */     try {
/*  125 */       this.lock.acquire();
/*      */       
/*  127 */       if (!file.exists()) {
/*      */         return;
/*      */       }
/*      */       try {
/*  131 */         ((Resource)file).deleteResource(true, null);
/*  132 */       } catch (CoreException e) {
/*  133 */         String message = NLS.bind(Messages.resources_errorDeleting, file.getFullPath());
/*  134 */         ResourceStatus resourceStatus = new ResourceStatus(4, file.getFullPath(), message, (Throwable)e);
/*  135 */         failed((IStatus)resourceStatus);
/*      */       } 
/*      */     } finally {
/*  138 */       this.lock.release();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deletedFolder(IFolder folder) {
/*  147 */     Assert.isLegal(this.isValid);
/*      */     try {
/*  149 */       this.lock.acquire();
/*      */       
/*  151 */       if (!folder.exists()) {
/*      */         return;
/*      */       }
/*      */       try {
/*  155 */         ((Resource)folder).deleteResource(true, null);
/*  156 */       } catch (CoreException e) {
/*  157 */         String message = NLS.bind(Messages.resources_errorDeleting, folder.getFullPath());
/*  158 */         ResourceStatus resourceStatus = new ResourceStatus(4, folder.getFullPath(), message, (Throwable)e);
/*  159 */         failed((IStatus)resourceStatus);
/*      */       } 
/*      */     } finally {
/*  162 */       this.lock.release();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deletedProject(IProject target) {
/*  171 */     Assert.isLegal(this.isValid);
/*      */     try {
/*  173 */       this.lock.acquire();
/*      */       
/*  175 */       if (!target.exists()) {
/*      */         return;
/*      */       }
/*      */       try {
/*  179 */         ((Project)target).deleteResource(false, (MultiStatus)null);
/*  180 */       } catch (CoreException e) {
/*  181 */         String message = NLS.bind(Messages.resources_errorDeleting, target.getFullPath());
/*  182 */         ResourceStatus resourceStatus = new ResourceStatus(4, target.getFullPath(), message, (Throwable)e);
/*      */         
/*  184 */         failed((IStatus)resourceStatus);
/*      */       } 
/*      */     } finally {
/*  187 */       this.lock.release();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean ensureDestinationEmpty(IProject source, IFileStore destinationStore, IProgressMonitor monitor) throws CoreException {
/*  198 */     if (!destinationStore.fetchInfo().exists()) {
/*  199 */       return true;
/*      */     }
/*  201 */     if ((destinationStore.childNames(0, Policy.subMonitorFor(monitor, 0))).length > 0) {
/*      */       
/*  203 */       if (((Resource)source).getStore().equals(destinationStore)) {
/*  204 */         return true;
/*      */       }
/*  206 */       String message = NLS.bind(Messages.localstore_resourceExists, destinationStore);
/*  207 */       ResourceStatus resourceStatus = new ResourceStatus(4, source.getFullPath(), message, null);
/*  208 */       failed((IStatus)resourceStatus);
/*  209 */       return false;
/*      */     } 
/*      */     
/*  212 */     destinationStore.delete(0, Policy.subMonitorFor(monitor, 0));
/*  213 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void failed(IStatus reason) {
/*  222 */     Assert.isLegal(this.isValid);
/*  223 */     this.multistatus.add(reason);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IStatus getStatus() {
/*  230 */     return (IStatus)this.multistatus;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getTimestamp(IFile file) {
/*  238 */     Assert.isLegal(this.isValid);
/*      */     try {
/*  240 */       this.lock.acquire();
/*  241 */       if (!file.exists())
/*  242 */         return 0L; 
/*  243 */       ResourceInfo info = ((File)file).getResourceInfo(false, false);
/*  244 */       return (info == null) ? 0L : info.getLocalSyncInfo();
/*      */     } finally {
/*  246 */       this.lock.release();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long internalComputeTimestamp(IFile file) {
/*  257 */     IFileInfo fileInfo = this.localManager.getStore((IResource)file).fetchInfo();
/*  258 */     return fileInfo.exists() ? fileInfo.getLastModified() : 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean internalDeleteFile(IFile file, int flags, IProgressMonitor monitor) {
/*      */     try {
/*  267 */       String message = NLS.bind(Messages.resources_deleting, file.getFullPath());
/*  268 */       monitor.beginTask(message, 100);
/*  269 */       Policy.checkCanceled(monitor);
/*      */ 
/*      */       
/*  272 */       if (!file.exists())
/*      */       {
/*  274 */         return true;
/*      */       }
/*      */       
/*  277 */       if (file.isLinked()) {
/*  278 */         deletedFile(file);
/*  279 */         return true;
/*      */       } 
/*      */ 
/*      */       
/*  283 */       IFileStore fileStore = this.localManager.getStore((IResource)file);
/*  284 */       boolean localExists = fileStore.fetchInfo().exists();
/*  285 */       if (!localExists) {
/*  286 */         deletedFile(file);
/*      */         
/*  288 */         return true;
/*      */       } 
/*      */       
/*  291 */       boolean keepHistory = ((flags & 0x2) != 0);
/*  292 */       boolean force = ((flags & 0x1) != 0);
/*      */ 
/*      */       
/*  295 */       if (keepHistory)
/*  296 */         addToLocalHistory(file); 
/*  297 */       monitor.worked(25);
/*      */ 
/*      */ 
/*      */       
/*  301 */       if (!force) {
/*  302 */         boolean inSync = isSynchronized((IResource)file, 0);
/*      */         
/*  304 */         if (!inSync && localExists) {
/*  305 */           message = NLS.bind(Messages.localstore_resourceIsOutOfSync, file.getFullPath());
/*  306 */           ResourceStatus resourceStatus = new ResourceStatus(274, file.getFullPath(), message);
/*  307 */           failed((IStatus)resourceStatus);
/*      */           
/*  309 */           return false;
/*      */         } 
/*      */       } 
/*  312 */       monitor.worked(25);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  330 */       monitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean internalDeleteFolder(IFolder folder, int flags, IProgressMonitor monitor) {
/*  340 */     String message = NLS.bind(Messages.resources_deleting, folder.getFullPath());
/*  341 */     monitor.beginTask("", 100);
/*  342 */     monitor.subTask(message);
/*  343 */     Policy.checkCanceled(monitor);
/*      */ 
/*      */     
/*  346 */     if (!folder.exists()) {
/*  347 */       return true;
/*      */     }
/*      */     
/*  350 */     if (folder.isLinked()) {
/*  351 */       deletedFolder(folder);
/*  352 */       return true;
/*      */     } 
/*      */ 
/*      */     
/*  356 */     IFileStore fileStore = this.localManager.getStore((IResource)folder);
/*  357 */     if (!fileStore.fetchInfo().exists()) {
/*  358 */       deletedFolder(folder);
/*  359 */       return true;
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*  364 */       this.localManager.delete((IResource)folder, flags, Policy.subMonitorFor(monitor, 100));
/*  365 */     } catch (CoreException ce) {
/*  366 */       message = NLS.bind(Messages.localstore_couldnotDelete, folder.getFullPath());
/*  367 */       ResourceStatus resourceStatus = new ResourceStatus(4, 273, folder.getFullPath(), message, (Throwable)ce);
/*  368 */       failed((IStatus)resourceStatus);
/*  369 */       return false;
/*      */     } 
/*  371 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean internalDeleteProject(IProject project, int flags, IProgressMonitor monitor) {
/*      */     String[] children;
/*  379 */     IResource[] members = null;
/*      */     try {
/*  381 */       members = project.members(10);
/*  382 */     } catch (CoreException e) {
/*  383 */       String message = NLS.bind(Messages.resources_errorMembers, project.getFullPath());
/*  384 */       ResourceStatus resourceStatus = new ResourceStatus(4, project.getFullPath(), message, (Throwable)e);
/*  385 */       failed((IStatus)resourceStatus);
/*      */       
/*  387 */       return false;
/*      */     } 
/*  389 */     boolean deletedChildren = true; byte b; int i; IResource[] arrayOfIResource1;
/*  390 */     for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource member = arrayOfIResource1[b];
/*  391 */       IResource child = member;
/*  392 */       switch (child.getType()) {
/*      */         
/*      */         case 1:
/*  395 */           if (!".project".equals(child.getName()))
/*  396 */             deletedChildren &= internalDeleteFile((IFile)child, flags, Policy.subMonitorFor(monitor, 100 / members.length)); 
/*      */           break;
/*      */         case 2:
/*  399 */           deletedChildren &= internalDeleteFolder((IFolder)child, flags, Policy.subMonitorFor(monitor, 100 / members.length)); break;
/*      */       } 
/*      */       b++; }
/*      */     
/*  403 */     IFileStore projectStore = this.localManager.getStore((IResource)project);
/*      */ 
/*      */ 
/*      */     
/*  407 */     if (!deletedChildren)
/*      */     {
/*  409 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/*  414 */       children = projectStore.childNames(0, null);
/*  415 */     } catch (CoreException coreException) {
/*      */       
/*  417 */       children = new String[0];
/*      */     } 
/*  419 */     boolean force = BitMask.isSet(flags, 1);
/*  420 */     if (!force && (children.length != 1 || !".project".equals(children[0]))) {
/*  421 */       String message = NLS.bind(Messages.localstore_resourceIsOutOfSync, project.getName());
/*  422 */       failed((IStatus)new ResourceStatus(274, project.getFullPath(), message));
/*  423 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  427 */     IResource file = project.findMember(".project");
/*  428 */     if (file == null) {
/*      */       
/*  430 */       IFileStore dotProject = projectStore.getChild(".project");
/*      */       try {
/*  432 */         dotProject.delete(0, null);
/*  433 */       } catch (CoreException e) {
/*  434 */         failed(e.getStatus());
/*      */       } 
/*      */     } else {
/*  437 */       boolean deletedProjectFile = internalDeleteFile((IFile)file, flags, Policy.monitorFor(null));
/*  438 */       if (!deletedProjectFile) {
/*  439 */         String message = NLS.bind(Messages.resources_couldnotDelete, file.getFullPath());
/*  440 */         ResourceStatus resourceStatus = new ResourceStatus(273, file.getFullPath(), message);
/*  441 */         failed((IStatus)resourceStatus);
/*      */         
/*  443 */         return false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*  449 */       projectStore.delete(0, null);
/*  450 */       deletedProject(project);
/*      */       
/*  452 */       return true;
/*  453 */     } catch (CoreException e) {
/*  454 */       String message = NLS.bind(Messages.resources_couldnotDelete, projectStore.toString());
/*  455 */       ResourceStatus resourceStatus = new ResourceStatus(273, project.getFullPath(), message, (Throwable)e);
/*  456 */       failed((IStatus)resourceStatus);
/*      */       
/*  458 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isContentChange(IProject project, IProjectDescription destDescription) {
/*  466 */     IProjectDescription srcDescription = ((Project)project).internalGetDescription();
/*  467 */     URI srcLocation = srcDescription.getLocationURI();
/*  468 */     URI destLocation = destDescription.getLocationURI();
/*  469 */     if (srcLocation == null || destLocation == null) {
/*  470 */       return true;
/*      */     }
/*  472 */     return !srcLocation.equals(destLocation);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isNameChange(IProject project, IProjectDescription description) {
/*  479 */     return !project.getName().equals(description.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void safeRefresh(IResource resource) {
/*      */     try {
/*  488 */       resource.refreshLocal(2, (IProgressMonitor)new NullProgressMonitor());
/*  489 */     } catch (CoreException ce) {
/*  490 */       ResourceStatus resourceStatus = new ResourceStatus(4, 273, resource.getFullPath(), Messages.refresh_refreshErr, (Throwable)ce);
/*  491 */       failed((IStatus)resourceStatus);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSynchronized(IResource resource, int depth) {
/*      */     try {
/*  501 */       this.lock.acquire();
/*  502 */       return this.localManager.isSynchronized(resource, depth);
/*      */     } finally {
/*  504 */       this.lock.release();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void makeInvalid() {
/*  514 */     this.isValid = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void movedFile(IFile source, IFile destination) {
/*  522 */     Assert.isLegal(this.isValid);
/*      */     try {
/*  524 */       this.lock.acquire();
/*      */       
/*  526 */       if (!source.exists()) {
/*      */         return;
/*      */       }
/*  529 */       if (destination.exists()) {
/*  530 */         String message = NLS.bind(Messages.resources_mustNotExist, destination.getFullPath());
/*  531 */         ResourceStatus resourceStatus = new ResourceStatus(4, destination.getFullPath(), message);
/*      */         
/*  533 */         failed((IStatus)resourceStatus);
/*      */       } 
/*      */ 
/*      */       
/*  537 */       IPropertyManager propertyManager = ((Resource)source).getPropertyManager();
/*      */       try {
/*  539 */         propertyManager.copy((IResource)source, (IResource)destination, 0);
/*  540 */         propertyManager.deleteProperties((IResource)source, 0);
/*  541 */       } catch (CoreException e) {
/*  542 */         String message = NLS.bind(Messages.resources_errorPropertiesMove, source.getFullPath(), destination.getFullPath());
/*  543 */         ResourceStatus resourceStatus = new ResourceStatus(4, source.getFullPath(), message, (Throwable)e);
/*      */         
/*  545 */         failed((IStatus)resourceStatus);
/*      */       } 
/*      */ 
/*      */       
/*  549 */       Workspace workspace = (Workspace)source.getWorkspace();
/*      */       try {
/*  551 */         workspace.move((Resource)source, destination.getFullPath(), 0, this.updateFlags, false);
/*  552 */       } catch (CoreException e) {
/*  553 */         String message = NLS.bind(Messages.resources_errorMoving, source.getFullPath(), destination.getFullPath());
/*  554 */         ResourceStatus resourceStatus = new ResourceStatus(4, source.getFullPath(), message, (Throwable)e);
/*      */         
/*  556 */         failed((IStatus)resourceStatus);
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/*  561 */         workspace.getMarkerManager().moved((IResource)source, (IResource)destination, 0);
/*  562 */       } catch (CoreException e) {
/*  563 */         String message = NLS.bind(Messages.resources_errorMarkersDelete, source.getFullPath());
/*  564 */         ResourceStatus resourceStatus = new ResourceStatus(4, source.getFullPath(), message, (Throwable)e);
/*  565 */         failed((IStatus)resourceStatus);
/*      */       } 
/*      */ 
/*      */       
/*  569 */       copyLocalHistory((IResource)source, (IResource)destination);
/*      */     } finally {
/*  571 */       this.lock.release();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void movedFolderSubtree(IFolder source, IFolder destination) {
/*  580 */     Assert.isLegal(this.isValid);
/*      */     try {
/*  582 */       this.lock.acquire();
/*      */       
/*  584 */       if (!source.exists()) {
/*      */         return;
/*      */       }
/*  587 */       if (destination.exists()) {
/*  588 */         String message = NLS.bind(Messages.resources_mustNotExist, destination.getFullPath());
/*  589 */         ResourceStatus resourceStatus = new ResourceStatus(4, destination.getFullPath(), message);
/*  590 */         failed((IStatus)resourceStatus);
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  595 */       int depth = 2;
/*  596 */       IPropertyManager propertyManager = ((Resource)source).getPropertyManager();
/*      */       try {
/*  598 */         propertyManager.copy((IResource)source, (IResource)destination, depth);
/*  599 */         propertyManager.deleteProperties((IResource)source, depth);
/*  600 */       } catch (CoreException e) {
/*  601 */         String message = NLS.bind(Messages.resources_errorPropertiesMove, source.getFullPath(), destination.getFullPath());
/*  602 */         ResourceStatus resourceStatus = new ResourceStatus(4, source.getFullPath(), message, (Throwable)e);
/*      */         
/*  604 */         failed((IStatus)resourceStatus);
/*      */       } 
/*      */ 
/*      */       
/*  608 */       Workspace workspace = (Workspace)source.getWorkspace();
/*      */       try {
/*  610 */         workspace.move((Resource)source, destination.getFullPath(), depth, this.updateFlags, false);
/*  611 */       } catch (CoreException e) {
/*  612 */         String message = NLS.bind(Messages.resources_errorMoving, source.getFullPath(), destination.getFullPath());
/*  613 */         ResourceStatus resourceStatus = new ResourceStatus(4, source.getFullPath(), message, (Throwable)e);
/*      */         
/*  615 */         failed((IStatus)resourceStatus);
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/*  620 */         workspace.getMarkerManager().moved((IResource)source, (IResource)destination, depth);
/*  621 */       } catch (CoreException e) {
/*  622 */         String message = NLS.bind(Messages.resources_errorMarkersDelete, source.getFullPath());
/*  623 */         ResourceStatus resourceStatus = new ResourceStatus(4, source.getFullPath(), message, (Throwable)e);
/*  624 */         failed((IStatus)resourceStatus);
/*      */       } 
/*      */ 
/*      */       
/*  628 */       copyLocalHistory((IResource)source, (IResource)destination);
/*      */     } finally {
/*  630 */       this.lock.release();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean movedProjectSubtree(IProject project, IProjectDescription destDescription) {
/*  639 */     Assert.isLegal(this.isValid);
/*      */     try {
/*  641 */       this.lock.acquire();
/*      */       
/*  643 */       if (!project.exists()) {
/*  644 */         return true;
/*      */       }
/*  646 */       Project source = (Project)project;
/*  647 */       Project destination = (Project)source.getWorkspace().getRoot().getProject(destDescription.getName());
/*  648 */       Workspace workspace = (Workspace)source.getWorkspace();
/*  649 */       int depth = 2;
/*      */ 
/*      */ 
/*      */       
/*  653 */       if (isNameChange(source, destDescription)) {
/*  654 */         if (destination.exists()) {
/*  655 */           String message = NLS.bind(Messages.resources_mustNotExist, destination.getFullPath());
/*  656 */           ResourceStatus resourceStatus = new ResourceStatus(4, destination.getFullPath(), message);
/*  657 */           failed((IStatus)resourceStatus);
/*  658 */           return false;
/*      */         } 
/*      */ 
/*      */         
/*      */         try {
/*  663 */           source.getPropertyManager().closePropertyStore((IResource)source);
/*  664 */           this.localManager.getHistoryStore().closeHistoryStore((IResource)source);
/*  665 */         } catch (CoreException e) {
/*  666 */           String message = NLS.bind(Messages.properties_couldNotClose, source.getFullPath());
/*  667 */           ResourceStatus resourceStatus = new ResourceStatus(4, source.getFullPath(), message, (Throwable)e);
/*      */           
/*  669 */           failed((IStatus)resourceStatus);
/*      */         } 
/*  671 */         IFileSystem fileSystem = EFS.getLocalFileSystem();
/*  672 */         IFileStore oldMetaArea = fileSystem.getStore(workspace.getMetaArea().locationFor((IResource)source));
/*  673 */         IFileStore newMetaArea = fileSystem.getStore(workspace.getMetaArea().locationFor((IResource)destination));
/*      */         try {
/*  675 */           oldMetaArea.move(newMetaArea, 0, (IProgressMonitor)new NullProgressMonitor());
/*  676 */         } catch (CoreException e) {
/*  677 */           String message = NLS.bind(Messages.resources_moveMeta, oldMetaArea, newMetaArea);
/*  678 */           ResourceStatus resourceStatus = new ResourceStatus(568, destination.getFullPath(), message, (Throwable)e);
/*      */           
/*  680 */           failed((IStatus)resourceStatus);
/*      */         } 
/*      */ 
/*      */         
/*      */         try {
/*  685 */           workspace.move(source, destination.getFullPath(), depth, this.updateFlags, true);
/*  686 */         } catch (CoreException e) {
/*  687 */           String message = NLS.bind(Messages.resources_errorMoving, source.getFullPath(), destination.getFullPath());
/*  688 */           ResourceStatus resourceStatus = new ResourceStatus(4, source.getFullPath(), message, (Throwable)e);
/*      */           
/*  690 */           failed((IStatus)resourceStatus);
/*      */         } 
/*      */ 
/*      */         
/*  694 */         ((ProjectInfo)destination.getResourceInfo(false, true)).fixupAfterMove();
/*      */ 
/*      */         
/*      */         try {
/*  698 */           workspace.getMarkerManager().moved((IResource)source, (IResource)destination, depth);
/*  699 */         } catch (CoreException e) {
/*  700 */           String message = NLS.bind(Messages.resources_errorMarkersMove, source.getFullPath(), destination.getFullPath());
/*  701 */           ResourceStatus resourceStatus = new ResourceStatus(4, source.getFullPath(), message, (Throwable)e);
/*      */           
/*  703 */           failed((IStatus)resourceStatus);
/*      */         } 
/*      */         
/*  706 */         copyLocalHistory((IResource)source, (IResource)destination);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  712 */         ((ProjectDescription)destDescription).setLinkDescriptions(destination.internalGetDescription().getLinks());
/*      */         
/*  714 */         ((ProjectDescription)destDescription).setFilterDescriptions(destination.internalGetDescription().getFilters());
/*      */         
/*  716 */         ((ProjectDescription)destDescription).setVariableDescriptions(destination.internalGetDescription().getVariables());
/*  717 */         destination.internalSetDescription(destDescription, true);
/*  718 */         destination.writeDescription(1);
/*  719 */       } catch (CoreException e) {
/*  720 */         String message = Messages.resources_projectDesc;
/*  721 */         ResourceStatus resourceStatus = new ResourceStatus(4, destination.getFullPath(), message, (Throwable)e);
/*  722 */         failed((IStatus)resourceStatus);
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/*  727 */         workspace.getMetaArea().writePrivateDescription(destination);
/*  728 */       } catch (CoreException e) {
/*  729 */         failed(e.getStatus());
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/*  734 */         destination.refreshLocal(2, (IProgressMonitor)new NullProgressMonitor());
/*  735 */       } catch (CoreException e) {
/*  736 */         String message = NLS.bind(Messages.resources_errorRefresh, destination.getFullPath());
/*  737 */         ResourceStatus resourceStatus = new ResourceStatus(4, destination.getFullPath(), message, (Throwable)e);
/*  738 */         failed((IStatus)resourceStatus);
/*  739 */         return false;
/*      */       } 
/*  741 */       return true;
/*      */     } finally {
/*  743 */       this.lock.release();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void moveProjectContent(IProject source, IFileStore destStore, int flags, IProgressMonitor monitor) throws CoreException {
/*      */     try {
/*  753 */       String message = NLS.bind(Messages.resources_moving, source.getFullPath());
/*  754 */       monitor.beginTask(message, 10);
/*  755 */       IProjectDescription srcDescription = source.getDescription();
/*  756 */       URI srcLocation = srcDescription.getLocationURI();
/*      */       
/*  758 */       if (srcLocation != null && URIUtil.equals(srcLocation, destStore.toURI())) {
/*      */         return;
/*      */       }
/*      */       
/*  762 */       boolean replace = ((flags & 0x100) != 0);
/*  763 */       if (replace) {
/*  764 */         destStore.mkdir(0, Policy.subMonitorFor(monitor, 10));
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  769 */       this.localManager.move((IResource)source, destStore, flags, Policy.subMonitorFor(monitor, 9));
/*      */ 
/*      */       
/*  772 */       if ((flags & 0x20) == 0) {
/*  773 */         IResource[] children = source.members(); byte b; int i; IResource[] arrayOfIResource1;
/*  774 */         for (i = (arrayOfIResource1 = children).length, b = 0; b < i; ) { IResource element = arrayOfIResource1[b];
/*  775 */           if (element.isLinked()) {
/*  776 */             message = NLS.bind(Messages.resources_moving, element.getFullPath());
/*  777 */             monitor.subTask(message);
/*  778 */             IFileStore linkDestination = destStore.getChild(element.getName());
/*      */             try {
/*  780 */               this.localManager.move(element, linkDestination, flags, Policy.monitorFor(null));
/*  781 */             } catch (CoreException ce) {
/*      */               
/*  783 */               failed(ce.getStatus());
/*      */             } 
/*      */           }  b++; }
/*      */       
/*      */       } 
/*  788 */       monitor.worked(1);
/*      */     } finally {
/*  790 */       monitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void standardDeleteFile(IFile file, int flags, IProgressMonitor monitor) {
/*  799 */     Assert.isLegal(this.isValid);
/*      */     try {
/*  801 */       this.lock.acquire();
/*  802 */       internalDeleteFile(file, flags, monitor);
/*      */     } finally {
/*  804 */       this.lock.release();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void standardDeleteFolder(IFolder folder, int flags, IProgressMonitor monitor) {
/*  813 */     Assert.isLegal(this.isValid);
/*      */     try {
/*  815 */       this.lock.acquire();
/*  816 */       internalDeleteFolder(folder, flags, monitor);
/*  817 */     } catch (OperationCanceledException oce) {
/*  818 */       safeRefresh((IResource)folder);
/*  819 */       throw oce;
/*      */     } finally {
/*  821 */       this.lock.release();
/*  822 */       monitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void standardDeleteProject(IProject project, int flags, IProgressMonitor monitor) {
/*  831 */     Assert.isLegal(this.isValid);
/*      */     try {
/*  833 */       this.lock.acquire();
/*  834 */       String message = NLS.bind(Messages.resources_deleting, project.getFullPath());
/*  835 */       monitor.beginTask(message, 100);
/*      */       
/*  837 */       if (!project.exists()) {
/*      */         return;
/*      */       }
/*  840 */       boolean alwaysDeleteContent = ((flags & 0x4) != 0);
/*  841 */       boolean neverDeleteContent = ((flags & 0x8) != 0);
/*  842 */       boolean success = true;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  847 */       if (alwaysDeleteContent || (project.isOpen() && !neverDeleteContent)) {
/*      */ 
/*      */         
/*  850 */         if (alwaysDeleteContent || isSynchronized((IResource)project, 2)) {
/*  851 */           flags |= 0x1;
/*      */         }
/*      */ 
/*      */         
/*  855 */         if (project.isOpen()) {
/*  856 */           success = internalDeleteProject(project, flags, monitor);
/*  857 */           if (!success) {
/*  858 */             IFileStore store = this.localManager.getStore((IResource)project);
/*  859 */             message = NLS.bind(Messages.resources_couldnotDelete, store.toString());
/*  860 */             ResourceStatus resourceStatus = new ResourceStatus(273, project.getFullPath(), message);
/*  861 */             failed((IStatus)resourceStatus);
/*      */           } 
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/*      */         try {
/*  869 */           IFileStore projectStore = this.localManager.getStore((IResource)project);
/*  870 */           IFileStore[] members = projectStore.childStores(0, null); byte b; int i; IFileStore[] arrayOfIFileStore1;
/*  871 */           for (i = (arrayOfIFileStore1 = members).length, b = 0; b < i; ) { IFileStore member = arrayOfIFileStore1[b];
/*  872 */             if (!".project".equals(member.getName()))
/*  873 */               member.delete(0, Policy.subMonitorFor(monitor, 87 / members.length)); 
/*      */             b++; }
/*      */           
/*  876 */           projectStore.delete(0, Policy.subMonitorFor(monitor, 87 / ((members.length > 0) ? members.length : 1)));
/*  877 */         } catch (OperationCanceledException oce) {
/*  878 */           safeRefresh((IResource)project);
/*  879 */           throw oce;
/*  880 */         } catch (CoreException ce) {
/*  881 */           message = NLS.bind(Messages.localstore_couldnotDelete, project.getFullPath());
/*  882 */           ResourceStatus resourceStatus = new ResourceStatus(4, 273, project.getFullPath(), message, (Throwable)ce);
/*  883 */           failed((IStatus)resourceStatus);
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */       
/*  889 */       if (success) {
/*  890 */         deletedProject(project);
/*      */       } else {
/*  892 */         message = NLS.bind(Messages.localstore_couldnotDelete, project.getFullPath());
/*  893 */         ResourceStatus resourceStatus = new ResourceStatus(273, project.getFullPath(), message);
/*  894 */         failed((IStatus)resourceStatus);
/*      */       } 
/*      */     } finally {
/*  897 */       this.lock.release();
/*  898 */       monitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void standardMoveFile(IFile source, IFile destination, int flags, IProgressMonitor monitor) {
/*  907 */     Assert.isLegal(this.isValid);
/*      */     try {
/*  909 */       this.lock.acquire();
/*  910 */       String message = NLS.bind(Messages.resources_moving, source.getFullPath());
/*  911 */       monitor.subTask(message);
/*      */ 
/*      */       
/*  914 */       if (!source.exists() || destination.exists() || !destination.getParent().isAccessible()) {
/*  915 */         throw new IllegalArgumentException();
/*      */       }
/*  917 */       boolean force = ((flags & 0x1) != 0);
/*  918 */       boolean keepHistory = ((flags & 0x2) != 0);
/*  919 */       boolean isDeep = ((flags & 0x20) == 0);
/*      */ 
/*      */ 
/*      */       
/*  923 */       if (!force && !isSynchronized((IResource)source, 2)) {
/*  924 */         message = NLS.bind(Messages.localstore_resourceIsOutOfSync, source.getFullPath());
/*  925 */         ResourceStatus resourceStatus = new ResourceStatus(274, source.getFullPath(), message);
/*  926 */         failed((IStatus)resourceStatus);
/*      */         return;
/*      */       } 
/*  929 */       monitor.worked(25);
/*      */ 
/*      */       
/*  932 */       if (keepHistory)
/*  933 */         addToLocalHistory(source); 
/*  934 */       monitor.worked(25);
/*      */ 
/*      */       
/*  937 */       if (!isDeep && source.isLinked()) {
/*  938 */         movedFile(source, destination);
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  944 */       IFileStore destStore = null;
/*  945 */       boolean failedDeletingSource = false;
/*      */       try {
/*  947 */         destStore = this.localManager.getStore((IResource)destination);
/*      */         
/*  949 */         destStore.getParent().mkdir(0, Policy.subMonitorFor(monitor, 0));
/*  950 */         this.localManager.move((IResource)source, destStore, flags, monitor);
/*  951 */       } catch (CoreException e) {
/*  952 */         failed(e.getStatus());
/*      */         
/*  954 */         failedDeletingSource = (destStore != null && destStore.fetchInfo().exists());
/*      */         
/*  956 */         if (!failedDeletingSource)
/*      */           return; 
/*      */       } 
/*  959 */       movedFile(source, destination);
/*  960 */       updateMovedFileTimestamp(destination, internalComputeTimestamp(destination));
/*  961 */       if (failedDeletingSource) {
/*      */         
/*      */         try {
/*  964 */           source.refreshLocal(2, null);
/*  965 */         } catch (CoreException coreException) {}
/*      */       }
/*      */ 
/*      */       
/*  969 */       monitor.worked(25);
/*      */       return;
/*      */     } finally {
/*  972 */       this.lock.release();
/*  973 */       monitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void standardMoveFolder(IFolder source, IFolder destination, int flags, IProgressMonitor monitor) {
/*  982 */     Assert.isLegal(this.isValid);
/*      */     try {
/*  984 */       this.lock.acquire();
/*  985 */       String message = NLS.bind(Messages.resources_moving, source.getFullPath());
/*  986 */       monitor.beginTask(message, 100);
/*      */ 
/*      */       
/*  989 */       if (!source.exists() || destination.exists() || !destination.getParent().isAccessible()) {
/*  990 */         throw new IllegalArgumentException();
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  995 */       boolean force = ((flags & 0x1) != 0);
/*  996 */       if (!force && !isSynchronized((IResource)source, 2)) {
/*  997 */         message = NLS.bind(Messages.localstore_resourceIsOutOfSync, source.getFullPath());
/*  998 */         ResourceStatus resourceStatus = new ResourceStatus(4, source.getFullPath(), message);
/*  999 */         failed((IStatus)resourceStatus);
/*      */         return;
/*      */       } 
/* 1002 */       monitor.worked(20);
/*      */ 
/*      */       
/* 1005 */       boolean isDeep = ((flags & 0x20) == 0);
/* 1006 */       if (!isDeep && (source.isLinked() || source.isVirtual())) {
/* 1007 */         movedFolderSubtree(source, destination);
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 1013 */       IFileStore destStore = null;
/* 1014 */       boolean failedDeletingSource = false;
/*      */       try {
/* 1016 */         destStore = this.localManager.getStore((IResource)destination);
/* 1017 */         this.localManager.move((IResource)source, destStore, flags, Policy.subMonitorFor(monitor, 60));
/* 1018 */       } catch (CoreException e) {
/* 1019 */         failed(e.getStatus());
/*      */         
/* 1021 */         failedDeletingSource = (destStore != null && destStore.fetchInfo().exists());
/*      */         
/* 1023 */         if (!failedDeletingSource)
/*      */           return; 
/*      */       } 
/* 1026 */       movedFolderSubtree(source, destination);
/* 1027 */       monitor.worked(20);
/* 1028 */       updateTimestamps((IResource)destination, isDeep);
/* 1029 */       if (failedDeletingSource) {
/*      */         
/*      */         try {
/* 1032 */           source.refreshLocal(2, null);
/* 1033 */           destination.refreshLocal(2, null);
/* 1034 */         } catch (CoreException coreException) {}
/*      */       }
/*      */     }
/*      */     finally {
/*      */       
/* 1039 */       this.lock.release();
/* 1040 */       monitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void standardMoveProject(IProject source, IProjectDescription description, int flags, IProgressMonitor monitor) {
/* 1049 */     Assert.isLegal(this.isValid); try {
/*      */       IFileStore destinationStore;
/* 1051 */       this.lock.acquire();
/* 1052 */       String message = NLS.bind(Messages.resources_moving, source.getFullPath());
/* 1053 */       monitor.beginTask(message, 100);
/*      */ 
/*      */       
/* 1056 */       if (!source.isAccessible()) {
/* 1057 */         throw new IllegalArgumentException();
/*      */       }
/*      */ 
/*      */       
/* 1061 */       if (!isContentChange(source, description)) {
/* 1062 */         movedProjectSubtree(source, description);
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 1067 */       boolean force = ((flags & 0x1) != 0);
/* 1068 */       if (!force && !isSynchronized((IResource)source, 2)) {
/*      */         
/* 1070 */         message = NLS.bind(Messages.localstore_resourceIsOutOfSync, source.getFullPath());
/* 1071 */         ResourceStatus resourceStatus = new ResourceStatus(274, source.getFullPath(), message);
/* 1072 */         failed((IStatus)resourceStatus);
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*      */       try {
/* 1078 */         destinationStore = computeDestinationStore(description);
/*      */         
/* 1080 */         if ((flags & 0x100) == 0 && 
/* 1081 */           !ensureDestinationEmpty(source, destinationStore, monitor))
/*      */           return; 
/* 1083 */       } catch (CoreException e) {
/*      */         
/* 1085 */         message = NLS.bind(Messages.localstore_couldNotMove, source.getFullPath());
/* 1086 */         ResourceStatus resourceStatus = new ResourceStatus(4, source.getFullPath(), message, (Throwable)e);
/* 1087 */         failed((IStatus)resourceStatus);
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*      */       try {
/* 1093 */         moveProjectContent(source, destinationStore, flags, Policy.subMonitorFor(monitor, 75));
/* 1094 */       } catch (CoreException e) {
/* 1095 */         message = NLS.bind(Messages.localstore_couldNotMove, source.getFullPath());
/* 1096 */         ResourceStatus resourceStatus = new ResourceStatus(4, source.getFullPath(), message, (Throwable)e);
/* 1097 */         failed((IStatus)resourceStatus);
/*      */         
/*      */         try {
/* 1100 */           source.refreshLocal(2, null);
/* 1101 */         } catch (CoreException coreException) {}
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1108 */       movedProjectSubtree(source, description);
/* 1109 */       monitor.worked(12);
/*      */       
/* 1111 */       boolean isDeep = ((flags & 0x20) == 0);
/* 1112 */       updateTimestamps((IResource)source.getWorkspace().getRoot().getProject(description.getName()), isDeep);
/* 1113 */       monitor.worked(12);
/*      */     } finally {
/* 1115 */       this.lock.release();
/* 1116 */       monitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateMovedFileTimestamp(IFile file, long timestamp) {
/* 1125 */     Assert.isLegal(this.isValid);
/*      */     try {
/* 1127 */       this.lock.acquire();
/*      */       
/* 1129 */       if (!file.exists()) {
/*      */         return;
/*      */       }
/* 1132 */       ResourceInfo info = ((Resource)file).getResourceInfo(false, true);
/*      */       
/* 1134 */       this.localManager.updateLocalSync(info, timestamp);
/*      */       
/* 1136 */       info.clear(65536);
/*      */     } finally {
/* 1138 */       this.lock.release();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateTimestamps(IResource root, boolean isDeep) {
/* 1147 */     IResourceVisitor visitor = resource -> {
/*      */         if (resource.isLinked()) {
/*      */           if (paramBoolean && !((Resource)resource).isUnderVirtual()) {
/*      */             ResourceInfo info = ((Resource)resource).getResourceInfo(false, true);
/*      */ 
/*      */             
/*      */             info.clear(65536);
/*      */           } 
/*      */ 
/*      */           
/*      */           return true;
/*      */         } 
/*      */         
/*      */         return true;
/*      */       };
/*      */     
/*      */     try {
/* 1164 */       root.accept(visitor, 2, 10);
/* 1165 */     } catch (CoreException coreException) {}
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ResourceTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */