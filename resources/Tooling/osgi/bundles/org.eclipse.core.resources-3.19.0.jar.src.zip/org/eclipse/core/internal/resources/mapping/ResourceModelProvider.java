/*    */ package org.eclipse.core.internal.resources.mapping;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.eclipse.core.resources.IContainer;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.mapping.ModelProvider;
/*    */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*    */ import org.eclipse.core.resources.mapping.ResourceMappingContext;
/*    */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*    */ import org.eclipse.core.runtime.IAdaptable;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ResourceModelProvider
/*    */   extends ModelProvider
/*    */ {
/*    */   public ResourceMapping[] getMappings(IResource resource, ResourceMappingContext context, IProgressMonitor monitor) {
/* 35 */     return new ResourceMapping[] { new SimpleResourceMapping(resource) };
/*    */   }
/*    */ 
/*    */   
/*    */   public ResourceMapping[] getMappings(ResourceTraversal[] traversals, ResourceMappingContext context, IProgressMonitor monitor) {
/* 40 */     Set<IAdaptable> result = new HashSet<>(); byte b; int j; ResourceTraversal[] arrayOfResourceTraversal;
/* 41 */     for (j = (arrayOfResourceTraversal = traversals).length, b = 0; b < j; ) { ResourceTraversal traversal = arrayOfResourceTraversal[b];
/* 42 */       IResource[] resources = traversal.getResources();
/* 43 */       int depth = traversal.getDepth(); byte b1; int k; IResource[] arrayOfIResource1;
/* 44 */       for (k = (arrayOfIResource1 = resources).length, b1 = 0; b1 < k; ) { IResource resource = arrayOfIResource1[b1];
/* 45 */         switch (depth) {
/*    */           case 2:
/* 47 */             result.add(resource);
/*    */             break;
/*    */           case 1:
/* 50 */             if (resource.getType() == 1) {
/* 51 */               result.add(resource); break;
/*    */             } 
/* 53 */             result.add(new ShallowContainer((IContainer)resource));
/*    */             break;
/*    */           
/*    */           case 0:
/* 57 */             if (resource.getType() == 1)
/* 58 */               result.add(resource);  break;
/*    */         }  b1++; }
/*    */       
/*    */       b++; }
/*    */     
/* 63 */     ResourceMapping[] mappings = new ResourceMapping[result.size()];
/* 64 */     int i = 0;
/* 65 */     for (IAdaptable element : result) {
/* 66 */       if (element instanceof IResource) {
/* 67 */         mappings[i++] = new SimpleResourceMapping((IResource)element); continue;
/*    */       } 
/* 69 */       mappings[i++] = new ShallowResourceMapping((ShallowContainer)element);
/*    */     } 
/*    */     
/* 72 */     return mappings;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\mapping\ResourceModelProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */