/*    */ package org.eclipse.core.internal.events;
/*    */ 
/*    */ import org.eclipse.core.internal.utils.Messages;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.ICoreRunnable;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.core.runtime.jobs.Job;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NotifyJob
/*    */   extends Job
/*    */ {
/*    */   private final ICoreRunnable noop = monitor -> {
/*    */     
/*    */     };
/*    */   
/*    */   public NotifyJob() {
/* 36 */     super(Messages.resources_updating);
/* 37 */     setSystem(true);
/*    */   }
/*    */ 
/*    */   
/*    */   public IStatus run(IProgressMonitor monitor) {
/* 42 */     if (monitor.isCanceled())
/* 43 */       return Status.CANCEL_STATUS; 
/* 44 */     NotificationManager.this.notificationRequested = true;
/*    */     try {
/* 46 */       NotificationManager.this.workspace.run(this.noop, null, 0, null);
/* 47 */     } catch (CoreException e) {
/* 48 */       return e.getStatus();
/*    */     } 
/* 50 */     return Status.OK_STATUS;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean belongsTo(Object family) {
/* 55 */     return (NotificationManager.class == family);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\NotificationManager$NotifyJob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */