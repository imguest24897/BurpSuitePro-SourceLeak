/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.eclipse.core.filesystem.URIUtil;
/*     */ import org.eclipse.core.internal.utils.FileUtil;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Preferences;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WorkspaceRoot
/*     */   extends Container
/*     */   implements IWorkspaceRoot
/*     */ {
/*  33 */   private final Map<String, Project> projectTable = new ConcurrentHashMap<>(16);
/*     */ 
/*     */   
/*     */   private final IPath workspaceLocation;
/*     */ 
/*     */ 
/*     */   
/*     */   protected WorkspaceRoot(IPath path, Workspace container) {
/*  41 */     super(path, container);
/*  42 */     Assert.isTrue(path.equals(Path.ROOT));
/*  43 */     this.workspaceLocation = FileUtil.canonicalPath(Platform.getLocation());
/*  44 */     Assert.isNotNull(this.workspaceLocation);
/*     */   }
/*     */ 
/*     */   
/*     */   public void delete(boolean deleteContent, boolean force, IProgressMonitor monitor) throws CoreException {
/*  49 */     int updateFlags = force ? 1 : 0;
/*  50 */     updateFlags |= deleteContent ? 4 : 8;
/*  51 */     delete(updateFlags, monitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public void delete(boolean force, IProgressMonitor monitor) throws CoreException {
/*  56 */     int updateFlags = force ? 1 : 0;
/*  57 */     delete(updateFlags, monitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean exists(int flags, boolean checkType) {
/*  62 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IContainer[] findContainersForLocation(IPath location) {
/*  68 */     return findContainersForLocationURI(URIUtil.toURI(location.makeAbsolute()));
/*     */   }
/*     */ 
/*     */   
/*     */   public IContainer[] findContainersForLocationURI(URI location) {
/*  73 */     return findContainersForLocationURI(location, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public IContainer[] findContainersForLocationURI(URI location, int memberFlags) {
/*  78 */     if (!location.isAbsolute())
/*  79 */       throw new IllegalArgumentException(); 
/*  80 */     return (IContainer[])getLocalManager().allResourcesFor(location, false, memberFlags);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IFile[] findFilesForLocation(IPath location) {
/*  86 */     return findFilesForLocationURI(URIUtil.toURI(location.makeAbsolute()));
/*     */   }
/*     */ 
/*     */   
/*     */   public IFile[] findFilesForLocationURI(URI location) {
/*  91 */     return findFilesForLocationURI(location, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public IFile[] findFilesForLocationURI(URI location, int memberFlags) {
/*  96 */     if (!location.isAbsolute())
/*  97 */       throw new IllegalArgumentException(); 
/*  98 */     return (IFile[])getLocalManager().allResourcesFor(location, true, memberFlags);
/*     */   }
/*     */ 
/*     */   
/*     */   public IContainer getContainerForLocation(IPath location) {
/* 103 */     return getLocalManager().containerForLocation(location);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDefaultCharset(boolean checkImplicit) {
/* 108 */     if (checkImplicit)
/* 109 */       return ResourcesPlugin.getEncoding(); 
/* 110 */     String enc = ResourcesPlugin.getPlugin().getPluginPreferences().getString("encoding");
/* 111 */     return (enc == null || enc.length() == 0) ? null : enc;
/*     */   }
/*     */ 
/*     */   
/*     */   public IFile getFileForLocation(IPath location) {
/* 116 */     return getLocalManager().fileForLocation(location);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLocalTimeStamp() {
/* 121 */     return -1L;
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getLocation() {
/* 126 */     return this.workspaceLocation;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 131 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public IContainer getParent() {
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IProject getProject() {
/* 141 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IProject getProject(String name) {
/* 147 */     Project result = this.projectTable.get(name);
/* 148 */     if (result == null) {
/* 149 */       IPath projectPath = (new Path(null, name)).makeAbsolute();
/* 150 */       String message = "Path for project must have only one segment.";
/* 151 */       Assert.isLegal((projectPath.segmentCount() == 1), message);
/*     */       
/* 153 */       String canonicalName = projectPath.lastSegment();
/* 154 */       result = this.projectTable.computeIfAbsent(canonicalName, n -> new Project(paramIPath, this.workspace));
/*     */     } 
/* 156 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getProjectRelativePath() {
/* 161 */     return (IPath)Path.EMPTY;
/*     */   }
/*     */ 
/*     */   
/*     */   public IProject[] getProjects() {
/* 166 */     return getProjects(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public IProject[] getProjects(int memberFlags) {
/* 171 */     IResource[] roots = getChildren(memberFlags);
/* 172 */     IProject[] result = new IProject[roots.length];
/*     */     try {
/* 174 */       System.arraycopy(roots, 0, result, 0, roots.length);
/* 175 */     } catch (ArrayStoreException ex) {
/*     */       byte b; int i; IResource[] arrayOfIResource;
/* 177 */       for (i = (arrayOfIResource = roots).length, b = 0; b < i; ) { IResource root2 = arrayOfIResource[b];
/* 178 */         if (root2.getType() != 4)
/* 179 */           Policy.log(4, NLS.bind("{0} is an invalid child of the workspace root.", 
/* 180 */                 root2), null); 
/*     */         b++; }
/*     */       
/* 183 */       throw ex;
/*     */     } 
/* 185 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getType() {
/* 190 */     return 8;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void internalSetLocal(boolean flag, int depth) throws CoreException {
/* 196 */     if (depth == 0)
/*     */       return; 
/* 198 */     if (depth == 1) {
/* 199 */       depth = 0;
/*     */     }
/*     */     
/* 202 */     IResource[] children = getChildren(0); byte b; int i; IResource[] arrayOfIResource1;
/* 203 */     for (i = (arrayOfIResource1 = children).length, b = 0; b < i; ) { IResource element = arrayOfIResource1[b];
/* 204 */       ((Resource)element).internalSetLocal(flag, depth);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   public boolean isDerived(int options) {
/* 209 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isHidden() {
/* 214 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isHidden(int options) {
/* 219 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTeamPrivateMember(int options) {
/* 224 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLinked(int options) {
/* 229 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean isLocal(int depth) {
/* 236 */     return isLocal(-1, depth);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean isLocal(int flags, int depth) {
/* 243 */     if (depth == 0)
/* 244 */       return true; 
/* 245 */     if (depth == 1) {
/* 246 */       depth = 0;
/*     */     }
/*     */     
/* 249 */     IResource[] children = getChildren(0); byte b; int i; IResource[] arrayOfIResource1;
/* 250 */     for (i = (arrayOfIResource1 = children).length, b = 0; b < i; ) { IResource c = arrayOfIResource1[b];
/* 251 */       if (!c.isLocal(depth))
/* 252 */         return false; 
/*     */       b++; }
/*     */     
/* 255 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPhantom() {
/* 260 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setDefaultCharset(String charset) {
/* 267 */     Preferences resourcesPreferences = ResourcesPlugin.getPlugin().getPluginPreferences();
/* 268 */     if (charset != null) {
/* 269 */       resourcesPreferences.setValue("encoding", charset);
/*     */     } else {
/* 271 */       resourcesPreferences.setToDefault("encoding");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHidden(boolean isHidden) {}
/*     */ 
/*     */   
/*     */   public long setLocalTimeStamp(long value) {
/* 281 */     if (value < 0L) {
/* 282 */       throw new IllegalArgumentException("Illegal time stamp: " + value);
/*     */     }
/* 284 */     return value;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public void setReadOnly(boolean readonly) {}
/*     */   
/*     */   public void touch(IProgressMonitor monitor) {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\WorkspaceRoot.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */