/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import org.eclipse.core.internal.utils.Messages;
/*    */ import org.eclipse.core.internal.watson.ElementTree;
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WorkspaceTreeReader
/*    */ {
/*    */   protected boolean renameProjectNode;
/*    */   
/*    */   public static WorkspaceTreeReader getReader(Workspace workspace, int version, boolean renameProjectNode) throws CoreException {
/* 49 */     WorkspaceTreeReader w = null;
/* 50 */     switch (version) {
/*    */       case 67305985:
/* 52 */         w = new WorkspaceTreeReader_1(workspace);
/* 53 */         w.renameProjectNode = renameProjectNode;
/* 54 */         return w;
/*    */       case 67305986:
/* 56 */         w = new WorkspaceTreeReader_2(workspace);
/* 57 */         w.renameProjectNode = renameProjectNode;
/* 58 */         return w;
/*    */     } 
/*    */     
/* 61 */     String msg = NLS.bind(Messages.resources_format, Integer.valueOf(version));
/* 62 */     throw new ResourceException(567, null, msg, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static WorkspaceTreeReader getReader(Workspace workspace, int version) throws CoreException {
/* 70 */     return getReader(workspace, version, false);
/*    */   }
/*    */   
/*    */   public abstract ElementTree readSnapshotTree(DataInputStream paramDataInputStream, ElementTree paramElementTree, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*    */   
/*    */   public abstract void readTree(DataInputStream paramDataInputStream, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*    */   
/*    */   public abstract void readTree(IProject paramIProject, DataInputStream paramDataInputStream, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\WorkspaceTreeReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */