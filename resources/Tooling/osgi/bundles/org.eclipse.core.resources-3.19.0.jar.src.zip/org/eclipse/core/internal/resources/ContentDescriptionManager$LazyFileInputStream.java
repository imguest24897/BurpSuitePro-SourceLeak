/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LazyFileInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private InputStream actual;
/*     */   private IFileStore target;
/*     */   
/*     */   LazyFileInputStream(IFileStore target) {
/* 136 */     this.target = target;
/*     */   }
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/* 141 */     if (this.actual == null)
/* 142 */       return 0; 
/* 143 */     return this.actual.available();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 148 */     if (this.actual == null)
/*     */       return; 
/* 150 */     this.actual.close();
/*     */   }
/*     */   
/*     */   private void ensureOpened() throws IOException {
/* 154 */     if (this.actual != null)
/*     */       return; 
/* 156 */     if (this.target == null)
/* 157 */       throw new FileNotFoundException(); 
/*     */     try {
/* 159 */       this.actual = this.target.openInputStream(0, null);
/* 160 */     } catch (CoreException e) {
/* 161 */       if (e.getCause() instanceof IOException) {
/* 162 */         throw (IOException)e.getCause();
/*     */       }
/* 164 */       throw new IOException(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 170 */     ensureOpened();
/* 171 */     return this.actual.read();
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] b, int off, int len) throws IOException {
/* 176 */     ensureOpened();
/* 177 */     return this.actual.read(b, off, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public long skip(long n) throws IOException {
/* 182 */     ensureOpened();
/* 183 */     return this.actual.skip(n);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ContentDescriptionManager$LazyFileInputStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */