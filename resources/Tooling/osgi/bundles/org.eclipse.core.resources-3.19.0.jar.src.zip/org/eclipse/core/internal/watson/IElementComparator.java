package org.eclipse.core.internal.watson;

import org.eclipse.core.internal.dtree.IComparator;

public interface IElementComparator extends IComparator {
  public static final int K_NO_CHANGE = 0;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\watson\IElementComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */