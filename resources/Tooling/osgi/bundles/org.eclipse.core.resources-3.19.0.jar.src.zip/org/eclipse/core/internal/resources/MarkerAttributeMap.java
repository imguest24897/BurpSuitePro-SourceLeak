/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ import org.eclipse.core.internal.utils.IStringPoolParticipant;
/*     */ import org.eclipse.core.internal.utils.StringPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarkerAttributeMap
/*     */   implements IStringPoolParticipant
/*     */ {
/*     */   private final AtomicReference<Map<String, Object>> mapRef;
/*     */   protected static final int DEFAULT_SIZE = 9;
/*     */   
/*     */   public MarkerAttributeMap() {
/*  45 */     this(9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerAttributeMap(int initialCapacity) {
/*  56 */     this.mapRef = new AtomicReference<>(Map.of());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerAttributeMap(MarkerAttributeMap m) {
/*  64 */     this.mapRef = new AtomicReference<>(copy(m.getMap()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerAttributeMap(Map<String, ? extends Object> map, boolean validate) {
/*  72 */     this.mapRef = new AtomicReference<>(copy(map, validate));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributes(Map<String, ? extends Object> map, boolean validate) {
/*  80 */     this.mapRef.set(copy(map, validate));
/*     */   }
/*     */   
/*     */   private Map<String, Object> copy(Map<String, ? extends Object> map, boolean validate) {
/*  84 */     Map<String, Object> target = new HashMap<>();
/*  85 */     putAll(target, map, validate);
/*  86 */     return target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(Map<String, ? extends Object> map, boolean validate) {
/*  94 */     this.mapRef.getAndUpdate(old -> {
/*     */           Map<String, Object> copy = copy(old);
/*     */           putAll(copy, paramMap1, paramBoolean);
/*     */           return copy;
/*     */         });
/*     */   }
/*     */   
/*     */   private void putAll(Map<String, Object> target, Map<String, ? extends Object> source, boolean validate) {
/* 102 */     if (source == null) {
/*     */       return;
/*     */     }
/* 105 */     for (Map.Entry<String, ? extends Object> e : source.entrySet()) {
/* 106 */       String key = e.getKey();
/* 107 */       Objects.requireNonNull(key, "insert of null key not allowed");
/* 108 */       Object value = e.getValue();
/* 109 */       if (validate) {
/* 110 */         value = MarkerInfo.checkValidAttribute(value);
/*     */       }
/* 112 */       if (value != null) {
/* 113 */         target.put(((String)e.getKey()).intern(), value);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private Map<String, Object> copy(Map<String, ? extends Object> map) {
/* 119 */     return new HashMap<>(map);
/*     */   }
/*     */   
/*     */   private Map<String, Object> getMap() {
/* 123 */     return this.mapRef.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> toMap() {
/* 128 */     return copy(getMap());
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<String, Object>> entrySet() {
/* 133 */     return getMap().entrySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String k, Object value) {
/* 141 */     Objects.requireNonNull(k, "insert of null key not allowed");
/* 142 */     Objects.requireNonNull(value, "insert of null value not allowed");
/* 143 */     this.mapRef.getAndUpdate(map -> {
/*     */           Map<String, Object> m = copy(map);
/*     */           m.put(paramString.intern(), paramObject);
/*     */           return m;
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void shareStrings(StringPool set) {
/* 153 */     for (Map.Entry<String, Object> e : getMap().entrySet()) {
/* 154 */       Object o = e.getValue();
/* 155 */       if (o instanceof String) {
/* 156 */         e.setValue(set.add((String)o)); continue;
/* 157 */       }  if (o instanceof IStringPoolParticipant) {
/* 158 */         ((IStringPoolParticipant)o).shareStrings(set);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 165 */     return getMap().isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object remove(Object key) {
/* 170 */     return getMap().remove(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/* 175 */     return getMap().get(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 180 */     return getMap().size();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\MarkerAttributeMap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */