/*     */ package org.eclipse.core.internal.events;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IncrementalProjectBuilder;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MissingBuilder
/*     */   extends IncrementalProjectBuilder
/*     */ {
/*     */   private boolean hasBeenBuilt = false;
/*     */   private String name;
/*     */   
/*     */   MissingBuilder(String name) {
/*  83 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IProject[] build(int kind, Map<String, String> args, IProgressMonitor monitor) {
/*  91 */     if (!this.hasBeenBuilt && Policy.DEBUG_BUILD_FAILURE) {
/*  92 */       this.hasBeenBuilt = true;
/*  93 */       String msg = NLS.bind(Messages.events_skippingBuilder, this.name, getProject().getName());
/*  94 */       Policy.log(2, msg, null);
/*     */     } 
/*  96 */     return null;
/*     */   }
/*     */   
/*     */   String getName() {
/* 100 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISchedulingRule getRule(int kind, Map<String, String> args) {
/* 105 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\BuildManager$MissingBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */