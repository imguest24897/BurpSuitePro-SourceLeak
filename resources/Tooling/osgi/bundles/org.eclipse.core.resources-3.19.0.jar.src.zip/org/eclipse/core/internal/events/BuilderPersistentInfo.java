/*    */ package org.eclipse.core.internal.events;
/*    */ 
/*    */ import org.eclipse.core.internal.resources.ICoreConstants;
/*    */ import org.eclipse.core.internal.watson.ElementTree;
/*    */ import org.eclipse.core.resources.IProject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BuilderPersistentInfo
/*    */ {
/*    */   protected String builderName;
/* 27 */   private int buildSpecIndex = -1;
/* 28 */   protected IProject[] interestingProjects = ICoreConstants.EMPTY_PROJECT_ARRAY;
/*    */   protected ElementTree lastBuildTree;
/*    */   protected String projectName;
/*    */   protected String configName;
/*    */   
/*    */   public BuilderPersistentInfo(String projectName, String builderName, int buildSpecIndex) {
/* 34 */     this(projectName, null, builderName, buildSpecIndex);
/*    */   }
/*    */   
/*    */   public BuilderPersistentInfo(String projectName, String configName, String builderName, int buildSpecIndex) {
/* 38 */     this.projectName = projectName;
/* 39 */     this.configName = configName;
/* 40 */     this.builderName = builderName;
/* 41 */     this.buildSpecIndex = buildSpecIndex;
/*    */   }
/*    */   
/*    */   public String getBuilderName() {
/* 45 */     return this.builderName;
/*    */   }
/*    */   
/*    */   public int getBuildSpecIndex() {
/* 49 */     return this.buildSpecIndex;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getConfigName() {
/* 58 */     return this.configName;
/*    */   }
/*    */   
/*    */   public IProject[] getInterestingProjects() {
/* 62 */     return this.interestingProjects;
/*    */   }
/*    */   
/*    */   public ElementTree getLastBuiltTree() {
/* 66 */     return this.lastBuildTree;
/*    */   }
/*    */   
/*    */   public String getProjectName() {
/* 70 */     return this.projectName;
/*    */   }
/*    */   
/*    */   public void setConfigName(String configName) {
/* 74 */     this.configName = configName;
/*    */   }
/*    */   
/*    */   public void setInterestingProjects(IProject[] projects) {
/* 78 */     this.interestingProjects = projects;
/*    */   }
/*    */   
/*    */   public void setLastBuildTree(ElementTree tree) {
/* 82 */     this.lastBuildTree = tree;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\BuilderPersistentInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */