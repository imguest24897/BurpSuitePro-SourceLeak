package org.eclipse.core.resources;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IResourceFilterDescription {
  public static final int INCLUDE_ONLY = 1;
  
  public static final int EXCLUDE_ALL = 2;
  
  public static final int FILES = 4;
  
  public static final int FOLDERS = 8;
  
  public static final int INHERITABLE = 16;
  
  FileInfoMatcherDescription getFileInfoMatcherDescription();
  
  IResource getResource();
  
  int getType();
  
  void delete(int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IResourceFilterDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */