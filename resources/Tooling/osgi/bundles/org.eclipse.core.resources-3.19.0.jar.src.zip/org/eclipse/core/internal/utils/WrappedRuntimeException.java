/*    */ package org.eclipse.core.internal.utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WrappedRuntimeException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private Throwable target;
/*    */   
/*    */   public WrappedRuntimeException(Throwable target) {
/* 27 */     this.target = target;
/*    */   }
/*    */   
/*    */   public Throwable getTargetException() {
/* 31 */     return this.target;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getMessage() {
/* 36 */     return this.target.getMessage();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\interna\\utils\WrappedRuntimeException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */