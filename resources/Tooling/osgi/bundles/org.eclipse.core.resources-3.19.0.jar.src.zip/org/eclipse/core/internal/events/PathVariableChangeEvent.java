/*    */ package org.eclipse.core.internal.events;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ import org.eclipse.core.resources.IPathVariableChangeEvent;
/*    */ import org.eclipse.core.resources.IPathVariableManager;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PathVariableChangeEvent
/*    */   extends EventObject
/*    */   implements IPathVariableChangeEvent
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String variableName;
/*    */   private IPath value;
/*    */   private int type;
/*    */   
/*    */   public PathVariableChangeEvent(IPathVariableManager source, String variableName, IPath value, int type) {
/* 45 */     super(source);
/* 46 */     if (type < 1 || type > 3)
/* 47 */       throw new IllegalArgumentException("Invalid event type: " + type); 
/* 48 */     this.variableName = variableName;
/* 49 */     this.value = value;
/* 50 */     this.type = type;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IPath getValue() {
/* 58 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getVariableName() {
/* 66 */     return this.variableName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getType() {
/* 74 */     return this.type;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 82 */     String[] typeStrings = { "VARIABLE_CHANGED", "VARIABLE_CREATED", "VARIABLE_DELETED" };
/* 83 */     StringBuilder sb = new StringBuilder(getClass().getName());
/* 84 */     sb.append("[variable = ");
/* 85 */     sb.append(this.variableName);
/* 86 */     sb.append(", type = ");
/* 87 */     sb.append(typeStrings[this.type - 1]);
/* 88 */     if (this.type != 3) {
/* 89 */       sb.append(", value = ");
/* 90 */       sb.append(this.value);
/*    */     } 
/* 92 */     sb.append("]");
/* 93 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\PathVariableChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */