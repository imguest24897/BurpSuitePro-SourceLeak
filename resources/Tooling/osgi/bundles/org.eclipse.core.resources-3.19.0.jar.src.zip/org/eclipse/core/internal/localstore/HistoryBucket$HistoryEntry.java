/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import org.eclipse.core.internal.utils.UniversalUniqueIdentifier;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HistoryEntry
/*     */   extends Bucket.Entry
/*     */ {
/*  37 */   static final Comparator<byte[]> COMPARATOR = HistoryEntry::compareStates;
/*     */ 
/*     */   
/*  40 */   private static final byte[][] EMPTY_DATA = new byte[0][];
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int LONG_LENGTH = 8;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int UUID_LENGTH = 16;
/*     */ 
/*     */   
/*     */   public static final int DATA_LENGTH = 24;
/*     */ 
/*     */   
/*     */   private byte[][] data;
/*     */ 
/*     */ 
/*     */   
/*     */   static int compareStates(byte[] state1, byte[] state2) {
/*  59 */     long timestamp1 = getTimestamp(state1);
/*  60 */     long timestamp2 = getTimestamp(state2);
/*  61 */     if (timestamp1 == timestamp2)
/*  62 */       return -UniversalUniqueIdentifier.compareTime(state1, state2); 
/*  63 */     return (timestamp1 < timestamp2) ? 1 : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] getState(UniversalUniqueIdentifier uuid, long timestamp) {
/*  70 */     byte[] uuidBytes = uuid.toBytes();
/*  71 */     byte[] state = new byte[24];
/*  72 */     System.arraycopy(uuidBytes, 0, state, 0, uuidBytes.length);
/*  73 */     for (int j = 0; j < 8; j++) {
/*  74 */       state[16 + j] = (byte)(int)(0xFFL & timestamp);
/*  75 */       timestamp >>>= 8L;
/*     */     } 
/*  77 */     return state;
/*     */   }
/*     */   
/*     */   private static long getTimestamp(byte[] state) {
/*  81 */     long timestamp = 0L;
/*  82 */     for (int j = 0; j < 8; j++)
/*  83 */       timestamp += (state[16 + j] & 0xFFL) << j * 8; 
/*  84 */     return timestamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[][] insert(byte[][] existing, byte[] toAdd) {
/*  93 */     int index = search(existing, toAdd);
/*  94 */     if (index >= 0)
/*     */     {
/*  96 */       return null;
/*     */     }
/*  98 */     int insertPosition = -index - 1;
/*  99 */     byte[][] newValue = new byte[existing.length + 1][];
/* 100 */     if (insertPosition > 0)
/* 101 */       System.arraycopy(existing, 0, newValue, 0, insertPosition); 
/* 102 */     newValue[insertPosition] = toAdd;
/* 103 */     if (insertPosition < existing.length)
/* 104 */       System.arraycopy(existing, insertPosition, newValue, insertPosition + 1, existing.length - insertPosition); 
/* 105 */     return newValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[][] merge(byte[][] base, byte[][] additions) {
/* 112 */     int additionPointer = 0;
/* 113 */     int basePointer = 0;
/* 114 */     int added = 0;
/* 115 */     byte[][] result = new byte[base.length + additions.length][];
/* 116 */     while (basePointer < base.length && additionPointer < additions.length) {
/* 117 */       int comparison = compareStates(base[basePointer], additions[additionPointer]);
/* 118 */       if (comparison == 0) {
/* 119 */         result[added++] = base[basePointer++];
/*     */         
/* 121 */         additionPointer++; continue;
/* 122 */       }  if (comparison < 0) {
/* 123 */         result[added++] = base[basePointer++]; continue;
/*     */       } 
/* 125 */       result[added++] = additions[additionPointer++];
/*     */     } 
/*     */     
/* 128 */     byte[][] remaining = (basePointer == base.length) ? additions : base;
/* 129 */     int remainingPointer = (basePointer == base.length) ? additionPointer : basePointer;
/* 130 */     int remainingCount = remaining.length - remainingPointer;
/* 131 */     System.arraycopy(remaining, remainingPointer, result, added, remainingCount);
/* 132 */     added += remainingCount;
/* 133 */     if (added == base.length + additions.length)
/*     */     {
/* 135 */       return result;
/*     */     }
/* 137 */     byte[][] finalResult = new byte[added][];
/* 138 */     System.arraycopy(result, 0, finalResult, 0, finalResult.length);
/* 139 */     return finalResult;
/*     */   }
/*     */   
/*     */   private static int search(byte[][] existing, byte[] element) {
/* 143 */     return Arrays.binarySearch(existing, element, (Comparator)COMPARATOR);
/*     */   }
/*     */   
/*     */   public HistoryEntry(IPath path, byte[][] data) {
/* 147 */     super(path);
/* 148 */     this.data = data;
/*     */   }
/*     */   
/*     */   public HistoryEntry(IPath path, HistoryEntry base) {
/* 152 */     super(path);
/* 153 */     this.data = new byte[base.data.length][];
/* 154 */     System.arraycopy(base.data, 0, this.data, 0, this.data.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void compact() {
/* 162 */     if (!isDirty())
/*     */       return; 
/* 164 */     int occurrences = 0; byte b; int i; byte[][] arrayOfByte1;
/* 165 */     for (i = (arrayOfByte1 = this.data).length, b = 0; b < i; ) { byte[] d = arrayOfByte1[b];
/* 166 */       if (d != null)
/* 167 */         this.data[occurrences++] = d; 
/*     */       b++; }
/*     */     
/* 170 */     if (occurrences == this.data.length) {
/*     */       return;
/*     */     }
/* 173 */     if (occurrences == 0) {
/*     */       
/* 175 */       this.data = EMPTY_DATA;
/* 176 */       delete();
/*     */       return;
/*     */     } 
/* 179 */     byte[][] result = new byte[occurrences][];
/* 180 */     System.arraycopy(this.data, 0, result, 0, occurrences);
/* 181 */     this.data = result;
/*     */   }
/*     */   
/*     */   public void deleteOccurrence(int i) {
/* 185 */     markDirty();
/* 186 */     this.data[i] = null;
/*     */   }
/*     */   
/*     */   byte[][] getData() {
/* 190 */     return this.data;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOccurrences() {
/* 195 */     return this.data.length;
/*     */   }
/*     */   
/*     */   public long getTimestamp(int i) {
/* 199 */     return getTimestamp(this.data[i]);
/*     */   }
/*     */   
/*     */   public UniversalUniqueIdentifier getUUID(int i) {
/* 203 */     return new UniversalUniqueIdentifier(this.data[i]);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getValue() {
/* 208 */     return this.data;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 213 */     return (this.data.length == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void visited() {
/* 218 */     compact();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\HistoryBucket$HistoryEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */