/*     */ package org.eclipse.core.internal.propertytester;
/*     */ 
/*     */ import org.eclipse.core.expressions.PropertyTester;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourceAttributes;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourcePropertyTester
/*     */   extends PropertyTester
/*     */ {
/*     */   protected static final String EXTENSION = "extension";
/*     */   protected static final String NAME = "name";
/*     */   protected static final String PATH = "path";
/*     */   protected static final String PERSISTENT_PROPERTY = "persistentProperty";
/*     */   protected static final String PROJECT_NATURE = "projectNature";
/*     */   protected static final String PROJECT_PERSISTENT_PROPERTY = "projectPersistentProperty";
/*     */   protected static final String PROJECT_SESSION_PROPERTY = "projectSessionProperty";
/*     */   protected static final String READ_ONLY = "readOnly";
/*     */   protected static final String SESSION_PROPERTY = "sessionProperty";
/*     */   
/*     */   public boolean test(Object receiver, String method, Object[] args, Object expectedValue) {
/*  99 */     if (!(receiver instanceof IResource))
/* 100 */       return false; 
/* 101 */     IResource res = (IResource)receiver;
/* 102 */     if (method.equals("name"))
/* 103 */       return (new StringMatcher(toString(expectedValue))).match(res.getName()); 
/* 104 */     if (method.equals("path"))
/* 105 */       return (new StringMatcher(toString(expectedValue))).match(res.getFullPath().toString()); 
/* 106 */     if (method.equals("extension"))
/* 107 */       return (new StringMatcher(toString(expectedValue))).match(res.getFileExtension()); 
/* 108 */     if (method.equals("readOnly")) {
/* 109 */       ResourceAttributes attr = res.getResourceAttributes();
/* 110 */       return (((attr != null && attr.isReadOnly())) == toBoolean(expectedValue));
/* 111 */     }  if (method.equals("projectNature"))
/*     */       try {
/* 113 */         IProject proj = res.getProject();
/* 114 */         return (proj != null && proj.isAccessible() && proj.hasNature(toString(expectedValue)));
/* 115 */       } catch (CoreException coreException) {
/* 116 */         return false;
/*     */       }  
/* 118 */     if (method.equals("persistentProperty"))
/* 119 */       return testProperty(res, true, args, expectedValue); 
/* 120 */     if (method.equals("projectPersistentProperty"))
/* 121 */       return testProperty((IResource)res.getProject(), true, args, expectedValue); 
/* 122 */     if (method.equals("sessionProperty"))
/* 123 */       return testProperty(res, false, args, expectedValue); 
/* 124 */     if (method.equals("projectSessionProperty")) {
/* 125 */       return testProperty((IResource)res.getProject(), false, args, expectedValue);
/*     */     }
/* 127 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean testProperty(IResource resource, boolean persistentFlag, Object[] args, Object expectedValue) {
/*     */     String propertyName;
/*     */     String expectedVal;
/* 154 */     if (resource == null) {
/* 155 */       return false;
/*     */     }
/*     */     
/* 158 */     switch (args.length) {
/*     */       case 0:
/* 160 */         propertyName = toString(expectedValue);
/* 161 */         expectedVal = null;
/*     */         break;
/*     */       case 1:
/* 164 */         propertyName = toString(args[0]);
/* 165 */         expectedVal = null;
/*     */         break;
/*     */       default:
/* 168 */         propertyName = toString(args[0]);
/* 169 */         expectedVal = toString(args[1]);
/*     */         break;
/*     */     } 
/*     */     try {
/* 173 */       QualifiedName key = toQualifedName(propertyName);
/* 174 */       Object actualVal = persistentFlag ? resource.getPersistentProperty(key) : resource.getSessionProperty(key);
/* 175 */       if (actualVal == null)
/* 176 */         return false; 
/* 177 */       return !(expectedVal != null && !expectedVal.equals(actualVal.toString()));
/* 178 */     } catch (CoreException coreException) {
/*     */ 
/*     */       
/* 181 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean toBoolean(Object expectedValue) {
/* 193 */     if (expectedValue instanceof Boolean) {
/* 194 */       return ((Boolean)expectedValue).booleanValue();
/*     */     }
/* 196 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected QualifiedName toQualifedName(String name) {
/*     */     QualifiedName key;
/* 207 */     int dot = name.lastIndexOf('.');
/* 208 */     if (dot != -1) {
/* 209 */       key = new QualifiedName(name.substring(0, dot), name.substring(dot + 1));
/*     */     } else {
/* 211 */       key = new QualifiedName(null, name);
/*     */     } 
/* 213 */     return key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String toString(Object expectedValue) {
/* 226 */     return (expectedValue == null) ? "" : expectedValue.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\propertytester\ResourcePropertyTester.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */