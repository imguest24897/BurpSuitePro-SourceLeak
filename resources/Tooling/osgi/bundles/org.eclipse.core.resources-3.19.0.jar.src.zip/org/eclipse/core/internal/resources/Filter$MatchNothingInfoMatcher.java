/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import org.eclipse.core.filesystem.IFileInfo;
/*    */ import org.eclipse.core.resources.IContainer;
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.resources.filtermatchers.AbstractFileInfoMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MatchNothingInfoMatcher
/*    */   extends AbstractFileInfoMatcher
/*    */ {
/*    */   public boolean matches(IContainer parent, IFileInfo fileInfo) {
/* 42 */     return false;
/*    */   }
/*    */   
/*    */   public void initialize(IProject project, Object arguments) {}
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\Filter$MatchNothingInfoMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */