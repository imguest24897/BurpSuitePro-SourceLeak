/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NotifyRule
/*    */   implements ISchedulingRule
/*    */ {
/*    */   public boolean contains(ISchedulingRule rule) {
/* 53 */     return !(!(rule instanceof org.eclipse.core.resources.IResource) && !rule.getClass().equals(NotifyRule.class));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isConflicting(ISchedulingRule rule) {
/* 58 */     return contains(rule);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\WorkManager$NotifyRule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */