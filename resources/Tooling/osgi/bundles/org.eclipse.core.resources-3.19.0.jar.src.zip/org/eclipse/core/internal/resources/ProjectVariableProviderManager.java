/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.variableresolvers.PathVariableResolver;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProjectVariableProviderManager
/*     */ {
/*     */   private static Map<String, Descriptor> descriptors;
/*     */   private static Descriptor[] descriptorsArray;
/*     */   
/*     */   public static class Descriptor
/*     */   {
/*  36 */     PathVariableResolver provider = null;
/*  37 */     String name = null;
/*  38 */     String value = null;
/*     */     
/*     */     public Descriptor(IExtension extension, IConfigurationElement element) throws RuntimeException, CoreException {
/*  41 */       this.name = element.getAttribute("variable");
/*  42 */       this.value = element.getAttribute("value");
/*     */       try {
/*  44 */         String classAttribute = "class";
/*  45 */         if (element.getAttribute(classAttribute) != null)
/*  46 */           this.provider = (PathVariableResolver)element.createExecutableExtension(classAttribute); 
/*  47 */       } catch (CoreException e) {
/*  48 */         Policy.log((Throwable)e);
/*     */       } 
/*  50 */       if (this.name == null)
/*  51 */         fail(NLS.bind(Messages.mapping_invalidDef, extension.getUniqueIdentifier())); 
/*     */     }
/*     */     
/*     */     protected void fail(String reason) throws CoreException {
/*  55 */       throw new ResourceException(new Status(4, "org.eclipse.core.resources", 1, reason, null));
/*     */     }
/*     */     
/*     */     public String getName() {
/*  59 */       return this.name;
/*     */     }
/*     */     
/*     */     public String getValue(String variable, IResource resource) {
/*  63 */       if (this.value != null)
/*  64 */         return this.value; 
/*  65 */       return this.provider.getValue(variable, resource);
/*     */     }
/*     */     
/*     */     public String[] getVariableNames(String variable, IResource resource) {
/*  69 */       if (this.provider != null)
/*  70 */         return this.provider.getVariableNames(variable, resource); 
/*  71 */       if (this.name.equals(variable))
/*  72 */         return new String[] { variable }; 
/*  73 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  79 */   private static ProjectVariableProviderManager instance = new ProjectVariableProviderManager();
/*     */   
/*     */   public static ProjectVariableProviderManager getDefault() {
/*  82 */     return instance;
/*     */   }
/*     */   
/*     */   public Descriptor[] getDescriptors() {
/*  86 */     lazyInitialize();
/*  87 */     return descriptorsArray;
/*     */   }
/*     */   
/*     */   protected void lazyInitialize() {
/*  91 */     if (descriptors != null)
/*     */       return; 
/*  93 */     IExtensionPoint point = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.core.resources", "variableResolvers");
/*  94 */     IExtension[] extensions = point.getExtensions();
/*  95 */     descriptors = new HashMap<>(extensions.length * 2 + 1); byte b; int i; IExtension[] arrayOfIExtension1;
/*  96 */     for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension1[b];
/*  97 */       IConfigurationElement[] elements = extension.getConfigurationElements();
/*  98 */       int count = elements.length;
/*  99 */       for (int j = 0; j < count; j++) {
/* 100 */         IConfigurationElement element = elements[j];
/* 101 */         String elementName = element.getName();
/* 102 */         if (elementName.equalsIgnoreCase("variableResolver")) {
/* 103 */           Descriptor desc = null;
/*     */           try {
/* 105 */             desc = new Descriptor(extension, element);
/* 106 */           } catch (CoreException e) {
/* 107 */             Policy.log((Throwable)e);
/*     */           } 
/* 109 */           if (desc != null)
/* 110 */             descriptors.put(desc.getName(), desc); 
/*     */         } 
/*     */       }  b++; }
/*     */     
/* 114 */     descriptorsArray = (Descriptor[])descriptors.values().toArray((Object[])new Descriptor[descriptors.size()]);
/*     */   }
/*     */   
/*     */   public Descriptor findDescriptor(String name) {
/* 118 */     lazyInitialize();
/* 119 */     Descriptor result = descriptors.get(name);
/* 120 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ProjectVariableProviderManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */