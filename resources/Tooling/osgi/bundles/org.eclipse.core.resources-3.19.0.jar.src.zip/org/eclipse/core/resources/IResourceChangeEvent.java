package org.eclipse.core.resources;

public interface IResourceChangeEvent {
  public static final int POST_CHANGE = 1;
  
  public static final int PRE_CLOSE = 2;
  
  public static final int PRE_DELETE = 4;
  
  @Deprecated
  public static final int PRE_AUTO_BUILD = 8;
  
  public static final int PRE_BUILD = 8;
  
  @Deprecated
  public static final int POST_AUTO_BUILD = 16;
  
  public static final int POST_BUILD = 16;
  
  public static final int PRE_REFRESH = 32;
  
  IMarkerDelta[] findMarkerDeltas(String paramString, boolean paramBoolean);
  
  int getBuildKind();
  
  IResourceDelta getDelta();
  
  IResource getResource();
  
  Object getSource();
  
  int getType();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IResourceChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */