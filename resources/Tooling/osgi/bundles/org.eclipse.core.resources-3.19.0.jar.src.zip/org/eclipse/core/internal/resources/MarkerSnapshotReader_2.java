/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarkerSnapshotReader_2
/*     */   extends MarkerSnapshotReader
/*     */ {
/*     */   public static final byte INDEX = 1;
/*     */   public static final byte QNAME = 2;
/*     */   public static final byte ATTRIBUTE_NULL = 0;
/*     */   public static final byte ATTRIBUTE_BOOLEAN = 1;
/*     */   public static final byte ATTRIBUTE_INTEGER = 2;
/*     */   public static final byte ATTRIBUTE_STRING = 3;
/*     */   
/*     */   public MarkerSnapshotReader_2(Workspace workspace) {
/*  43 */     super(workspace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void read(DataInputStream input) throws IOException, CoreException {
/*  71 */     Path path = new Path(input.readUTF());
/*  72 */     int markersSize = input.readInt();
/*  73 */     MarkerSet markers = new MarkerSet(markersSize);
/*  74 */     ArrayList<String> readTypes = new ArrayList<>();
/*  75 */     for (int i = 0; i < markersSize; i++) {
/*  76 */       markers.add(readMarkerInfo(input, readTypes));
/*     */     }
/*     */     
/*  79 */     ResourceInfo info = this.workspace.getResourceInfo((IPath)path, false, false);
/*  80 */     if (info == null)
/*     */       return; 
/*  82 */     info.setMarkers(markers);
/*  83 */     info.clear(4096);
/*     */   }
/*     */   
/*     */   private Map<String, Object> readAttributes(DataInputStream input) throws IOException {
/*  87 */     short attributesSize = input.readShort();
/*  88 */     if (attributesSize == 0)
/*  89 */       return null; 
/*  90 */     Map<String, Object> result = new HashMap<>(attributesSize);
/*  91 */     for (int j = 0; j < attributesSize; j++) {
/*  92 */       String key = input.readUTF();
/*  93 */       byte type = input.readByte();
/*  94 */       Object value = null;
/*  95 */       switch (type) {
/*     */         case 2:
/*  97 */           value = Integer.valueOf(input.readInt());
/*     */           break;
/*     */         case 1:
/* 100 */           value = Boolean.valueOf(input.readBoolean());
/*     */           break;
/*     */         case 3:
/* 103 */           value = input.readUTF();
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 109 */       if (value != null) {
/* 110 */         result.put(key, value);
/*     */       }
/*     */     } 
/* 113 */     return result.isEmpty() ? null : result;
/*     */   }
/*     */   private MarkerInfo readMarkerInfo(DataInputStream input, List<String> readTypes) throws IOException, CoreException {
/*     */     Map<String, Object> map, map1;
/* 117 */     long creationTime, id = input.readLong();
/* 118 */     byte constant = input.readByte();
/* 119 */     String type = null;
/* 120 */     switch (constant) {
/*     */       case 2:
/* 122 */         type = input.readUTF();
/* 123 */         readTypes.add(type);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 133 */         map = readAttributes(input);
/* 134 */         creationTime = input.readLong();
/* 135 */         return new MarkerInfo(map, false, creationTime, type, id);case 1: type = readTypes.get(input.readInt()); map1 = readAttributes(input); creationTime = input.readLong(); return new MarkerInfo(map1, false, creationTime, type, id);
/*     */     } 
/*     */     String str1 = Messages.resources_readMarkers;
/*     */     throw new ResourceException(567, null, str1, null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\MarkerSnapshotReader_2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */