/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import java.util.regex.PatternSyntaxException;
/*    */ import org.eclipse.core.filesystem.IFileInfo;
/*    */ import org.eclipse.core.resources.IContainer;
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.resources.filtermatchers.AbstractFileInfoMatcher;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RegexFileInfoMatcher
/*    */   extends AbstractFileInfoMatcher
/*    */ {
/* 29 */   Pattern pattern = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean matches(IContainer parent, IFileInfo fileInfo) {
/* 37 */     if (this.pattern != null) {
/* 38 */       Matcher m = this.pattern.matcher(fileInfo.getName());
/* 39 */       return m.matches();
/*    */     } 
/* 41 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void initialize(IProject project, Object arguments) throws CoreException {
/* 46 */     if (arguments != null)
/*    */       try {
/* 48 */         this.pattern = Pattern.compile((String)arguments);
/* 49 */       } catch (PatternSyntaxException e) {
/* 50 */         throw new CoreException(new Status(4, "org.eclipse.core.resources", 2, e.getMessage(), e));
/*    */       }  
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\RegexFileInfoMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */