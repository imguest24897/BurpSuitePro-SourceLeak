/*     */ package org.eclipse.core.internal.events;
/*     */ 
/*     */ import org.eclipse.core.internal.resources.ICoreConstants;
/*     */ import org.eclipse.core.internal.resources.ResourceInfo;
/*     */ import org.eclipse.core.internal.watson.IElementComparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceComparator
/*     */   implements IElementComparator, ICoreConstants
/*     */ {
/*  32 */   protected static final ResourceComparator notificationSingleton = new ResourceComparator(true, false);
/*  33 */   protected static final ResourceComparator buildSingleton = new ResourceComparator(false, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean notification;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean save;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourceComparator getSaveComparator() {
/*  53 */     return new ResourceComparator(false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourceComparator getBuildComparator() {
/*  61 */     return buildSingleton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourceComparator getNotificationComparator() {
/*  69 */     return notificationSingleton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResourceComparator(boolean notification, boolean save) {
/*  78 */     this.notification = notification;
/*  79 */     this.save = save;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compare(Object o1, Object o2) {
/*  88 */     if (o1 == o2)
/*  89 */       return 0; 
/*  90 */     int result = 0;
/*  91 */     if (o1 == null)
/*  92 */       return ((ResourceInfo)o2).isSet(8) ? 8 : 1; 
/*  93 */     if (o2 == null)
/*  94 */       return ((ResourceInfo)o1).isSet(8) ? 16 : 2; 
/*  95 */     if (!(o1 instanceof ResourceInfo) || !(o2 instanceof ResourceInfo))
/*  96 */       return 0; 
/*  97 */     ResourceInfo oldElement = (ResourceInfo)o1;
/*  98 */     ResourceInfo newElement = (ResourceInfo)o2;
/*  99 */     if (!oldElement.isSet(8) && newElement.isSet(8))
/* 100 */       return 2; 
/* 101 */     if (oldElement.isSet(8) && !newElement.isSet(8))
/* 102 */       return 1; 
/* 103 */     if (!compareOpen(oldElement, newElement))
/* 104 */       result |= 0x4000; 
/* 105 */     if (!compareContents(oldElement, newElement))
/* 106 */       if (oldElement.getType() == 4) {
/* 107 */         result |= 0x80000;
/* 108 */       } else if (newElement.getType() == 1 || oldElement.getType() == 1) {
/* 109 */         result |= 0x100;
/*     */       }  
/* 111 */     if (!compareType(oldElement, newElement))
/* 112 */       result |= 0x8000; 
/* 113 */     if (!compareNodeIDs(oldElement, newElement)) {
/* 114 */       result |= 0x40000;
/*     */       
/* 116 */       if (oldElement.getType() == 1 && newElement.getType() == 1)
/* 117 */         result |= 0x100; 
/*     */     } 
/* 119 */     if (compareLocal(oldElement, newElement))
/* 120 */       result |= 0x200000; 
/* 121 */     if (!compareCharsets(oldElement, newElement))
/* 122 */       result |= 0x100000; 
/* 123 */     if (!compareDerived(oldElement, newElement))
/* 124 */       result |= 0x400000; 
/* 125 */     if (this.notification && !compareSync(oldElement, newElement))
/* 126 */       result |= 0x10000; 
/* 127 */     if (this.notification && !compareMarkers(oldElement, newElement))
/* 128 */       result |= 0x20000; 
/* 129 */     if (this.save && !compareUsed(oldElement, newElement))
/* 130 */       result |= 0x4; 
/* 131 */     return (result == 0) ? 0 : (result | 0x4);
/*     */   }
/*     */   
/*     */   private boolean compareDerived(ResourceInfo oldElement, ResourceInfo newElement) {
/* 135 */     return (oldElement.isSet(16384) == newElement.isSet(16384));
/*     */   }
/*     */   
/*     */   private boolean compareCharsets(ResourceInfo oldElement, ResourceInfo newElement) {
/* 139 */     return (oldElement.getCharsetGenerationCount() == newElement.getCharsetGenerationCount());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean compareContents(ResourceInfo oldElement, ResourceInfo newElement) {
/* 146 */     return (oldElement.getContentId() == newElement.getContentId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean compareLocal(ResourceInfo oldElement, ResourceInfo newElement) {
/* 154 */     if (!oldElement.isSet(65536) || !newElement.isSet(65536))
/* 155 */       return false; 
/* 156 */     long oldStamp = oldElement.getModificationStamp();
/* 157 */     long newStamp = newElement.getModificationStamp();
/* 158 */     return ((oldStamp == -1L || newStamp == -1L) && oldStamp != newStamp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean compareMarkers(ResourceInfo oldElement, ResourceInfo newElement) {
/* 165 */     boolean bothNull = (oldElement.getMarkers(false) == null && newElement.getMarkers(false) == null);
/* 166 */     return !(!bothNull && oldElement.getMarkerGenerationCount() != newElement.getMarkerGenerationCount());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean compareNodeIDs(ResourceInfo oldElement, ResourceInfo newElement) {
/* 173 */     return (oldElement.getNodeId() == newElement.getNodeId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean compareOpen(ResourceInfo oldElement, ResourceInfo newElement) {
/* 180 */     return (oldElement.isSet(1) == newElement.isSet(1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean compareSync(ResourceInfo oldElement, ResourceInfo newElement) {
/* 187 */     return (oldElement.getSyncInfoGenerationCount() == newElement.getSyncInfoGenerationCount());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean compareType(ResourceInfo oldElement, ResourceInfo newElement) {
/* 194 */     return (oldElement.getType() == newElement.getType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean compareUsed(ResourceInfo oldElement, ResourceInfo newElement) {
/* 201 */     return (oldElement.isSet(16) == newElement.isSet(16));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\ResourceComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */