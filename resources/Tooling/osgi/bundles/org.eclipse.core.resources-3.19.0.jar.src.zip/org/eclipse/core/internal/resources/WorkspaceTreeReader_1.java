/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.internal.events.BuilderPersistentInfo;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.internal.watson.ElementTree;
/*     */ import org.eclipse.core.internal.watson.ElementTreeReader;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WorkspaceTreeReader_1
/*     */   extends WorkspaceTreeReader
/*     */ {
/*     */   protected Workspace workspace;
/*     */   
/*     */   public WorkspaceTreeReader_1(Workspace workspace) {
/*  37 */     this.workspace = workspace;
/*     */   }
/*     */   
/*     */   protected int getVersion() {
/*  41 */     return 67305985;
/*     */   }
/*     */   
/*     */   protected void linkBuildersToTrees(List<BuilderPersistentInfo> buildersToBeLinked, ElementTree[] trees, int index, IProgressMonitor monitor) {
/*  45 */     monitor = Policy.monitorFor(monitor);
/*     */     try {
/*  47 */       ArrayList<BuilderPersistentInfo> infos = null;
/*  48 */       String projectName = null;
/*  49 */       for (BuilderPersistentInfo info : buildersToBeLinked) {
/*  50 */         if (!info.getProjectName().equals(projectName)) {
/*  51 */           if (infos != null) {
/*  52 */             IProject project = this.workspace.getRoot().getProject(projectName);
/*  53 */             this.workspace.getBuildManager().setBuildersPersistentInfo(project, infos);
/*     */           } 
/*  55 */           projectName = info.getProjectName();
/*  56 */           infos = new ArrayList<>(5);
/*     */         } 
/*  58 */         info.setLastBuildTree(trees[index++]);
/*  59 */         infos.add(info);
/*     */       } 
/*  61 */       if (infos != null) {
/*  62 */         IProject project = this.workspace.getRoot().getProject(projectName);
/*  63 */         this.workspace.getBuildManager().setBuildersPersistentInfo(project, infos);
/*     */       } 
/*     */     } finally {
/*  66 */       monitor.done();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void linkPluginsSavedStateToTrees(List<SavedState> states, ElementTree[] trees, IProgressMonitor monitor) {
/*  71 */     monitor = Policy.monitorFor(monitor);
/*     */     try {
/*  73 */       for (int i = 0; i < states.size(); i++) {
/*  74 */         SavedState state = states.get(i);
/*     */ 
/*     */         
/*  77 */         SaveManager saveManager = this.workspace.getSaveManager();
/*  78 */         if (!saveManager.isOldPluginTree(state.pluginId)) {
/*  79 */           state.oldTree = trees[i];
/*     */         } else {
/*     */           
/*  82 */           saveManager.clearDeltaExpiration(state.pluginId);
/*     */         } 
/*     */       } 
/*     */     } finally {
/*  86 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected BuilderPersistentInfo readBuilderInfo(IProject project, DataInputStream input, int index) throws IOException {
/*  92 */     String projectName = input.readUTF();
/*     */     
/*  94 */     if (project != null)
/*  95 */       projectName = project.getName(); 
/*  96 */     String builderName = input.readUTF();
/*  97 */     return new BuilderPersistentInfo(projectName, builderName, index);
/*     */   }
/*     */   
/*     */   protected void readBuildersPersistentInfo(IProject project, DataInputStream input, List<BuilderPersistentInfo> builders, IProgressMonitor monitor) throws IOException {
/* 101 */     monitor = Policy.monitorFor(monitor);
/*     */     try {
/* 103 */       int builderCount = input.readInt();
/* 104 */       for (int i = 0; i < builderCount; i++)
/* 105 */         builders.add(readBuilderInfo(project, input, i)); 
/*     */     } finally {
/* 107 */       monitor.done();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void readPluginsSavedStates(DataInputStream input, HashMap<String, SavedState> savedStates, List<SavedState> plugins, IProgressMonitor monitor) throws IOException, CoreException {
/* 112 */     monitor = Policy.monitorFor(monitor);
/*     */     try {
/* 114 */       int stateCount = input.readInt();
/* 115 */       for (int i = 0; i < stateCount; i++) {
/* 116 */         String pluginId = input.readUTF();
/* 117 */         SavedState state = new SavedState(this.workspace, pluginId, null, null);
/* 118 */         savedStates.put(pluginId, state);
/* 119 */         plugins.add(state);
/*     */       } 
/*     */     } finally {
/* 122 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ElementTree readSnapshotTree(DataInputStream input, ElementTree complete, IProgressMonitor monitor) throws CoreException {
/* 128 */     monitor = Policy.monitorFor(monitor);
/*     */     
/*     */     try {
/* 131 */       String message = Messages.resources_readingSnap;
/* 132 */       monitor.beginTask(message, 100);
/* 133 */       ElementTreeReader reader = new ElementTreeReader(this.workspace.getSaveManager());
/* 134 */       while (input.available() > 0) {
/* 135 */         readWorkspaceFields(input, Policy.subMonitorFor(monitor, 50));
/* 136 */         complete = reader.readDelta(complete, input);
/*     */         
/*     */         try {
/* 139 */           int version = input.readInt();
/* 140 */           if (version != getVersion())
/* 141 */             return WorkspaceTreeReader.getReader(this.workspace, version).readSnapshotTree(input, complete, monitor); 
/* 142 */         } catch (EOFException eOFException) {
/*     */           break;
/*     */         } 
/*     */       } 
/* 146 */       return complete;
/* 147 */     } catch (IOException e) {
/* 148 */       String message = Messages.resources_readWorkspaceSnap;
/* 149 */       throw new ResourceException(567, null, message, e);
/*     */     } finally {
/* 151 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void readTree(DataInputStream input, IProgressMonitor monitor) throws CoreException {
/* 157 */     monitor = Policy.monitorFor(monitor);
/*     */     
/*     */     try {
/* 160 */       String message = Messages.resources_reading;
/* 161 */       monitor.beginTask(message, 100);
/* 162 */       readWorkspaceFields(input, Policy.subMonitorFor(monitor, Policy.opWork * 20 / 100));
/*     */       
/* 164 */       HashMap<String, SavedState> savedStates = new HashMap<>(20);
/* 165 */       List<SavedState> pluginsToBeLinked = new ArrayList<>(20);
/* 166 */       readPluginsSavedStates(input, savedStates, pluginsToBeLinked, Policy.subMonitorFor(monitor, Policy.opWork * 10 / 100));
/* 167 */       this.workspace.getSaveManager().setPluginsSavedState(savedStates);
/*     */       
/* 169 */       List<BuilderPersistentInfo> buildersToBeLinked = new ArrayList<>(20);
/* 170 */       readBuildersPersistentInfo(null, input, buildersToBeLinked, Policy.subMonitorFor(monitor, Policy.opWork * 10 / 100));
/*     */       
/* 172 */       ElementTree[] trees = readTrees((IPath)Path.ROOT, input, Policy.subMonitorFor(monitor, Policy.opWork * 40 / 100));
/* 173 */       linkPluginsSavedStateToTrees(pluginsToBeLinked, trees, Policy.subMonitorFor(monitor, Policy.opWork * 10 / 100));
/* 174 */       linkBuildersToTrees(buildersToBeLinked, trees, pluginsToBeLinked.size(), Policy.subMonitorFor(monitor, Policy.opWork * 10 / 100));
/*     */     }
/* 176 */     catch (IOException e) {
/* 177 */       String message = Messages.resources_readWorkspaceTree;
/* 178 */       throw new ResourceException(567, null, message, e);
/*     */     } finally {
/* 180 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void readTree(IProject project, DataInputStream input, IProgressMonitor monitor) throws CoreException {
/* 186 */     monitor = Policy.monitorFor(monitor);
/*     */     
/*     */     try {
/* 189 */       String message = Messages.resources_reading;
/* 190 */       monitor.beginTask(message, 10);
/*     */       
/* 192 */       int numBuilders = input.readInt();
/*     */ 
/*     */       
/* 195 */       String[] builderNames = new String[numBuilders];
/* 196 */       for (int i = 0; i < numBuilders; i++) {
/* 197 */         String builderName = input.readUTF();
/* 198 */         builderNames[i] = builderName;
/*     */       } 
/* 200 */       monitor.worked(1);
/*     */ 
/*     */       
/* 203 */       ElementTree[] trees = readTrees(project.getFullPath(), input, Policy.subMonitorFor(monitor, 8));
/*     */ 
/*     */       
/* 206 */       if (numBuilders > 0) {
/* 207 */         ArrayList<BuilderPersistentInfo> infos = new ArrayList<>(trees.length * 2 + 1);
/* 208 */         for (int j = 0; j < numBuilders; j++) {
/* 209 */           BuilderPersistentInfo info = new BuilderPersistentInfo(project.getName(), builderNames[j], -1);
/* 210 */           info.setLastBuildTree(trees[j]);
/* 211 */           infos.add(info);
/*     */         } 
/* 213 */         this.workspace.getBuildManager().setBuildersPersistentInfo(project, infos);
/*     */       } 
/* 215 */       monitor.worked(1);
/*     */     }
/* 217 */     catch (IOException e) {
/* 218 */       String message = Messages.resources_readProjectTree;
/* 219 */       throw new ResourceException(567, null, message, e);
/*     */     } finally {
/* 221 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ElementTree[] readTrees(IPath root, DataInputStream input, IProgressMonitor monitor) throws IOException {
/* 229 */     monitor = Policy.monitorFor(monitor);
/*     */     try {
/* 231 */       String message = Messages.resources_reading;
/* 232 */       monitor.beginTask(message, 4);
/* 233 */       ElementTreeReader treeReader = new ElementTreeReader(this.workspace.getSaveManager());
/* 234 */       String newProjectName = "";
/* 235 */       if (this.renameProjectNode)
/*     */       {
/* 237 */         newProjectName = root.segment(0);
/*     */       }
/* 239 */       ElementTree[] trees = treeReader.readDeltaChain(input, newProjectName);
/* 240 */       monitor.worked(3);
/* 241 */       if (root.isRoot()) {
/*     */ 
/*     */         
/* 244 */         ElementTree newTree = trees[trees.length - 1];
/* 245 */         newTree.setTreeData(this.workspace.tree.getTreeData());
/* 246 */         this.workspace.tree = newTree;
/*     */       } else {
/*     */         
/* 249 */         this.workspace.linkTrees(root, trees);
/*     */       } 
/* 251 */       monitor.worked(1);
/* 252 */       return trees;
/*     */     } finally {
/* 254 */       monitor.done();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void readWorkspaceFields(DataInputStream input, IProgressMonitor monitor) throws IOException, CoreException {
/* 259 */     monitor = Policy.monitorFor(monitor);
/*     */     
/*     */     try {
/* 262 */       this.workspace.nextNodeId.set(input.readLong());
/*     */       
/* 264 */       input.readLong();
/*     */       
/* 266 */       this.workspace.nextMarkerId.set(input.readLong());
/*     */       
/* 268 */       ((Synchronizer)this.workspace.getSynchronizer()).readPartners(input);
/*     */     } finally {
/* 270 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\WorkspaceTreeReader_1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */