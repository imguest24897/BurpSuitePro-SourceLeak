/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URI;
/*     */ import org.eclipse.core.filesystem.EFS;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.internal.utils.FileUtil;
/*     */ import org.eclipse.core.resources.IPathVariableManager;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileStoreRoot
/*     */ {
/*     */   private int chop;
/*     */   private boolean isValid = true;
/*     */   private IPath localRoot;
/*     */   private IPath canonicalLocalRoot;
/*     */   private URI root;
/*     */   private URI canonicalRoot;
/*     */   
/*     */   FileStoreRoot(URI rootURI, IPath workspacePath) {
/*  65 */     Assert.isNotNull(rootURI);
/*  66 */     Assert.isNotNull(workspacePath);
/*  67 */     this.root = rootURI;
/*  68 */     this.chop = workspacePath.segmentCount();
/*  69 */     this.localRoot = toLocalPath(this.root);
/*     */   }
/*     */   
/*     */   private IPathVariableManager getManager(IPath workspacePath) {
/*  73 */     IWorkspaceRoot workspaceRoot = ResourcesPlugin.getWorkspace().getRoot();
/*  74 */     IResource resource = workspaceRoot.findMember(workspacePath);
/*  75 */     if (resource != null) {
/*  76 */       return resource.getPathVariableManager();
/*     */     }
/*  78 */     if (workspacePath.segmentCount() == 0) {
/*  79 */       return workspaceRoot.getPathVariableManager();
/*     */     }
/*  81 */     if (workspacePath.segmentCount() == 1) {
/*  82 */       return workspaceRoot.getProject(workspacePath.lastSegment()).getPathVariableManager();
/*     */     }
/*  84 */     return workspaceRoot.getFile(workspacePath).getPathVariableManager();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URI computeURI(IPath workspacePath) {
/*  93 */     return computeURI(workspacePath, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URI computeURI(IPath workspacePath, boolean canonical) {
/* 106 */     IPath childPath = workspacePath.removeFirstSegments(this.chop);
/* 107 */     URI rootURI = canonical ? getCanonicalRoot() : this.root;
/* 108 */     rootURI = getManager(workspacePath).resolveURI(rootURI);
/* 109 */     if (childPath.segmentCount() == 0)
/* 110 */       return rootURI; 
/*     */     try {
/* 112 */       return EFS.getStore(rootURI).getFileStore(childPath).toURI();
/* 113 */     } catch (CoreException coreException) {
/* 114 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IFileStore createStore(IPath workspacePath, IResource resource) throws CoreException {
/* 124 */     IPath childPath = workspacePath.removeFirstSegments(this.chop);
/*     */ 
/*     */ 
/*     */     
/* 128 */     URI uri = resource.getPathVariableManager().resolveURI(resource.isLinked() ? this.root : getCanonicalRoot());
/* 129 */     if (!uri.isAbsolute())
/*     */     {
/*     */       
/* 132 */       return EFS.getNullFileSystem().getStore(workspacePath);
/*     */     }
/* 134 */     IFileStore rootStore = EFS.getStore(uri);
/* 135 */     if (childPath.segmentCount() == 0)
/* 136 */       return rootStore; 
/* 137 */     return rootStore.getFileStore(childPath);
/*     */   }
/*     */   
/*     */   boolean isValid() {
/* 141 */     return this.isValid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IPath localLocation(IPath workspacePath, IResource resource) {
/* 153 */     return localLocation(workspacePath, resource, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IPath localLocation(IPath workspacePath, IResource resource, boolean canonical) {
/* 166 */     if (this.localRoot == null)
/* 167 */       return null; 
/* 168 */     IPath rootPath = canonical ? getCanonicalLocalRoot() : this.localRoot;
/*     */     
/* 170 */     if (workspacePath.segmentCount() <= this.chop) {
/* 171 */       location = rootPath;
/*     */     } else {
/* 173 */       location = rootPath.append(workspacePath.removeFirstSegments(this.chop));
/* 174 */     }  IPath location = resource.getPathVariableManager().resolvePath(location);
/*     */ 
/*     */ 
/*     */     
/* 178 */     if (location == null || !location.isAbsolute())
/* 179 */       return null; 
/* 180 */     return location;
/*     */   }
/*     */   
/*     */   void setValid(boolean value) {
/* 184 */     this.isValid = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IPath toLocalPath(URI uri) {
/*     */     try {
/* 192 */       File localFile = EFS.getStore(uri).toLocalFile(0, null);
/* 193 */       return (localFile == null) ? null : (IPath)new Path(localFile.getAbsolutePath());
/* 194 */     } catch (CoreException coreException) {
/* 195 */       return FileUtil.toPath(uri);
/*     */     } 
/*     */   }
/*     */   
/*     */   private synchronized IPath getCanonicalLocalRoot() {
/* 200 */     if (this.canonicalLocalRoot == null && this.localRoot != null) {
/* 201 */       this.canonicalLocalRoot = FileUtil.canonicalPath(this.localRoot);
/*     */     }
/* 203 */     return this.canonicalLocalRoot;
/*     */   }
/*     */   
/*     */   private synchronized URI getCanonicalRoot() {
/* 207 */     if (this.canonicalRoot == null) {
/* 208 */       this.canonicalRoot = FileUtil.canonicalURI(this.root);
/*     */     }
/* 210 */     return this.canonicalRoot;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 216 */     return this.root.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\FileStoreRoot.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */