/*      */ package org.eclipse.core.internal.localstore;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.net.URI;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import org.eclipse.core.filesystem.EFS;
/*      */ import org.eclipse.core.filesystem.IFileInfo;
/*      */ import org.eclipse.core.filesystem.IFileStore;
/*      */ import org.eclipse.core.filesystem.IFileTree;
/*      */ import org.eclipse.core.filesystem.URIUtil;
/*      */ import org.eclipse.core.internal.refresh.RefreshManager;
/*      */ import org.eclipse.core.internal.resources.File;
/*      */ import org.eclipse.core.internal.resources.Folder;
/*      */ import org.eclipse.core.internal.resources.LinkDescription;
/*      */ import org.eclipse.core.internal.resources.Project;
/*      */ import org.eclipse.core.internal.resources.ProjectDescription;
/*      */ import org.eclipse.core.internal.resources.Resource;
/*      */ import org.eclipse.core.internal.resources.ResourceException;
/*      */ import org.eclipse.core.internal.resources.ResourceInfo;
/*      */ import org.eclipse.core.internal.resources.Workspace;
/*      */ import org.eclipse.core.internal.utils.BitMask;
/*      */ import org.eclipse.core.internal.utils.FileUtil;
/*      */ import org.eclipse.core.internal.utils.Messages;
/*      */ import org.eclipse.core.internal.utils.Policy;
/*      */ import org.eclipse.core.resources.IContainer;
/*      */ import org.eclipse.core.resources.IFile;
/*      */ import org.eclipse.core.resources.IFolder;
/*      */ import org.eclipse.core.resources.IPathVariableManager;
/*      */ import org.eclipse.core.resources.IProject;
/*      */ import org.eclipse.core.resources.IProjectDescription;
/*      */ import org.eclipse.core.resources.IResource;
/*      */ import org.eclipse.core.resources.IWorkspaceRoot;
/*      */ import org.eclipse.core.resources.ResourceAttributes;
/*      */ import org.eclipse.core.resources.ResourcesPlugin;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.MultiStatus;
/*      */ import org.eclipse.core.runtime.Path;
/*      */ import org.eclipse.core.runtime.Preferences;
/*      */ import org.eclipse.core.runtime.SubMonitor;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ 
/*      */ public class FileSystemResourceManager implements ICoreConstants, IManager, Preferences.IPropertyChangeListener {
/*      */   public FileSystemResourceManager(Workspace workspace) {
/*   52 */     this.workspace = workspace;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected IHistoryStore _historyStore;
/*      */ 
/*      */   
/*      */   protected Workspace workspace;
/*      */ 
/*      */   
/*      */   private volatile boolean lightweightAutoRefreshEnabled;
/*      */ 
/*      */   
/*      */   protected ArrayList<IPath> allPathsForLocation(URI inputLocation) {
/*   67 */     URI canonicalLocation = FileUtil.canonicalURI(inputLocation);
/*      */ 
/*      */     
/*   70 */     ArrayList<IPath> results = allPathsForLocationNonCanonical(canonicalLocation);
/*   71 */     if (results.isEmpty() && canonicalLocation != inputLocation) {
/*   72 */       results = allPathsForLocationNonCanonical(inputLocation);
/*      */     }
/*   74 */     return results;
/*      */   }
/*      */   
/*      */   private ArrayList<IPath> allPathsForLocationNonCanonical(URI inputLocation) {
/*   78 */     URI location = inputLocation;
/*   79 */     boolean isFileLocation = "file".equals(inputLocation.getScheme());
/*   80 */     IWorkspaceRoot root = getWorkspace().getRoot();
/*   81 */     ArrayList<IPath> results = new ArrayList<>();
/*   82 */     if (URIUtil.equals(location, locationURIFor((IResource)root, true))) {
/*      */       
/*   84 */       results.add(Path.ROOT);
/*   85 */       return results;
/*      */     }  byte b; int i; IProject[] arrayOfIProject;
/*   87 */     for (i = (arrayOfIProject = root.getProjects(8)).length, b = 0; b < i; ) { IProject project = arrayOfIProject[b];
/*   88 */       if (project.exists()) {
/*      */ 
/*      */         
/*   91 */         URI testLocation = locationURIFor((IResource)project, true);
/*   92 */         if (testLocation != null) {
/*      */           
/*   94 */           boolean usingAnotherScheme = !inputLocation.getScheme().equals(testLocation.getScheme());
/*      */           
/*   96 */           if (isFileLocation && !"file".equals(testLocation.getScheme()))
/*   97 */             testLocation = getFileURI(testLocation); 
/*   98 */           if (testLocation != null) {
/*      */             
/*  100 */             URI relative = testLocation.relativize(location);
/*  101 */             if (!relative.isAbsolute() && !relative.equals(testLocation)) {
/*  102 */               Path path = new Path(relative.getPath());
/*  103 */               results.add(project.getFullPath().append((IPath)path));
/*      */             } 
/*  105 */             if (usingAnotherScheme) {
/*      */ 
/*      */               
/*  108 */               ProjectDescription description = ((Project)project).internalGetDescription();
/*  109 */               if (description != null) {
/*      */                 
/*  111 */                 HashMap<IPath, LinkDescription> links = description.getLinks();
/*  112 */                 if (links != null)
/*      */                 {
/*  114 */                   for (LinkDescription link : links.values())
/*  115 */                   { IResource resource = project.findMember(link.getProjectRelativePath());
/*  116 */                     IPathVariableManager pathMan = (resource == null) ? project.getPathVariableManager() : resource.getPathVariableManager();
/*  117 */                     testLocation = pathMan.resolveURI(link.getLocationURI());
/*      */                     
/*  119 */                     if (isFileLocation && !"file".equals(testLocation.getScheme()))
/*  120 */                       testLocation = getFileURI(testLocation); 
/*  121 */                     if (testLocation == null)
/*      */                       continue; 
/*  123 */                     relative = testLocation.relativize(location);
/*  124 */                     if (!relative.isAbsolute() && !relative.equals(testLocation))
/*  125 */                     { Path path = new Path(relative.getPath());
/*  126 */                       results.add(project.getFullPath().append(link.getProjectRelativePath()).append((IPath)path)); }  }  } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }  b++; }
/*  132 */      try { findLinkedResourcesPaths(inputLocation, results); }
/*  133 */     catch (CoreException e)
/*  134 */     { Policy.log((Throwable)e); }
/*      */     
/*  136 */     return results;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void asyncRefresh(IResource target) {
/*  144 */     if (this.lightweightAutoRefreshEnabled) {
/*  145 */       RefreshManager refreshManager = this.workspace.getRefreshManager();
/*      */       
/*  147 */       if (refreshManager != null) {
/*  148 */         refreshManager.refresh(target);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private void findLinkedResourcesPaths(URI inputLocation, ArrayList<IPath> results) throws CoreException {
/*  154 */     IPath suffix = null;
/*  155 */     IFileStore fileStore = EFS.getStore(inputLocation);
/*  156 */     while (fileStore != null) {
/*  157 */       IResource[] resources = this.workspace.getAliasManager().findResources(fileStore); byte b; int i; IResource[] arrayOfIResource1;
/*  158 */       for (i = (arrayOfIResource1 = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource1[b];
/*  159 */         if (resource.isLinked()) {
/*  160 */           IPath path = resource.getFullPath();
/*  161 */           if (suffix != null)
/*  162 */             path = path.append(suffix); 
/*  163 */           if (!results.contains(path))
/*  164 */             results.add(path); 
/*      */         }  b++; }
/*      */       
/*  167 */       if (suffix == null) {
/*  168 */         suffix = Path.fromPortableString(fileStore.getName());
/*      */       } else {
/*  170 */         suffix = Path.fromPortableString(fileStore.getName()).append(suffix);
/*  171 */       }  fileStore = fileStore.getParent();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private URI getFileURI(URI locationURI) {
/*      */     try {
/*  183 */       IFileStore testLocationStore = EFS.getStore(locationURI);
/*  184 */       File storeAsFile = testLocationStore.toLocalFile(0, null);
/*  185 */       if (storeAsFile != null)
/*  186 */         return URIUtil.toURI(storeAsFile.getAbsolutePath()); 
/*  187 */     } catch (CoreException coreException) {}
/*      */ 
/*      */     
/*  190 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IResource[] allResourcesFor(URI location, boolean files, int memberFlags) {
/*  229 */     ArrayList<IPath> result = allPathsForLocation(location);
/*  230 */     int count = 0;
/*  231 */     for (int i = 0, imax = result.size(); i < imax; i++) {
/*      */       
/*  233 */       IResource resource = resourceFor(result.get(i), files);
/*      */       
/*  235 */       if (resource == null || ((Resource)resource).isFiltered() || ((memberFlags & 0x8) == 0 && resource.isHidden(512)) || ((memberFlags & 0x2) == 0 && resource.isTeamPrivateMember(512))) {
/*  236 */         resource = null;
/*      */       }
/*  238 */       result.set(i, resource);
/*      */       
/*  240 */       if (resource != null) {
/*  241 */         count++;
/*      */       }
/*      */     } 
/*  244 */     IResource[] toReturn = files ? (IResource[])new IFile[count] : (IResource[])new IContainer[count];
/*  245 */     count = 0;
/*  246 */     for (IPath element : result) {
/*  247 */       IResource resource = (IResource)element;
/*  248 */       if (resource != null)
/*  249 */         toReturn[count++] = resource; 
/*      */     } 
/*  251 */     return toReturn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceAttributes attributes(IResource resource) {
/*  258 */     IFileStore store = getStore(resource);
/*  259 */     IFileInfo fileInfo = store.fetchInfo();
/*  260 */     if (!fileInfo.exists())
/*  261 */       return null; 
/*  262 */     return FileUtil.fileInfoToAttributes(fileInfo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IContainer containerForLocation(IPath location) {
/*  282 */     return (IContainer)resourceForLocation(location, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IResource resourceForLocation(IPath location, boolean files) {
/*  297 */     if (this.workspace.getRoot().getLocation().equals(location)) {
/*  298 */       if (!files)
/*  299 */         return resourceFor((IPath)Path.ROOT, false); 
/*  300 */       return null;
/*      */     } 
/*  302 */     int resultProjectPathSegments = 0;
/*  303 */     IResource result = null;
/*  304 */     IProject[] projects = getWorkspace().getRoot().getProjects(8); byte b; int i; IProject[] arrayOfIProject1;
/*  305 */     for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/*  306 */       IPath projectLocation = project.getLocation();
/*  307 */       if (projectLocation != null && projectLocation.isPrefixOf(location)) {
/*  308 */         int segmentsToRemove = projectLocation.segmentCount();
/*  309 */         if (segmentsToRemove > resultProjectPathSegments) {
/*  310 */           IPath path = project.getFullPath().append(location.removeFirstSegments(segmentsToRemove));
/*  311 */           IResource resource = resourceFor(path, files);
/*  312 */           if (resource != null && !((Resource)resource).isFiltered()) {
/*  313 */             resultProjectPathSegments = segmentsToRemove;
/*  314 */             result = resource;
/*      */           } 
/*      */         } 
/*      */       }  b++; }
/*      */     
/*  319 */     return result;
/*      */   }
/*      */   
/*      */   public void copy(IResource target, IResource destination, int updateFlags, IProgressMonitor monitor) throws CoreException {
/*  323 */     String title = NLS.bind(Messages.localstore_copying, target.getFullPath());
/*      */     
/*  325 */     SubMonitor subMonitor = SubMonitor.convert(monitor, title, 100);
/*  326 */     IFileStore destinationStore = getStore(destination);
/*  327 */     if (destinationStore.fetchInfo().exists()) {
/*  328 */       String message = NLS.bind(Messages.localstore_resourceExists, destination.getFullPath());
/*  329 */       throw new ResourceException(272, destination.getFullPath(), message, null);
/*      */     } 
/*  331 */     getHistoryStore().copyHistory(target, destination, false);
/*  332 */     CopyVisitor visitor = new CopyVisitor(target, destination, updateFlags, (IProgressMonitor)subMonitor.split(100));
/*  333 */     UnifiedTree tree = new UnifiedTree(target);
/*  334 */     tree.accept(visitor, 2);
/*  335 */     IStatus status = visitor.getStatus();
/*  336 */     if (!status.isOK()) {
/*  337 */       throw new ResourceException(status);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void delete(IResource target, int flags, IProgressMonitor monitor) throws CoreException {
/*  343 */     Resource resource = (Resource)target;
/*  344 */     int deleteWork = resource.countResources(2, false) * 2;
/*  345 */     boolean force = ((flags & 0x1) != 0);
/*  346 */     int refreshWork = 0;
/*  347 */     if (!force) {
/*  348 */       refreshWork = Math.min(deleteWork, 100);
/*      */     }
/*  350 */     String title = NLS.bind(Messages.localstore_deleting, resource.getFullPath());
/*      */     
/*  352 */     SubMonitor subMonitor = SubMonitor.convert(monitor, title, deleteWork + refreshWork);
/*  353 */     MultiStatus status = new MultiStatus("org.eclipse.core.resources", 273, Messages.localstore_deleteProblem, null);
/*  354 */     List<Resource> skipList = null;
/*  355 */     UnifiedTree tree = new UnifiedTree(target);
/*  356 */     if (!force) {
/*  357 */       CollectSyncStatusVisitor refreshVisitor = new CollectSyncStatusVisitor(Messages.localstore_deleteProblem, (IProgressMonitor)subMonitor.split(refreshWork));
/*  358 */       refreshVisitor.setIgnoreLocalDeletions(true);
/*  359 */       tree.accept(refreshVisitor, 2);
/*  360 */       status.merge((IStatus)refreshVisitor.getSyncStatus());
/*  361 */       skipList = refreshVisitor.getAffectedResources();
/*      */     } 
/*  363 */     DeleteVisitor deleteVisitor = new DeleteVisitor(skipList, flags, (IProgressMonitor)subMonitor.split(deleteWork), deleteWork);
/*  364 */     tree.accept(deleteVisitor, 2);
/*  365 */     status.merge((IStatus)deleteVisitor.getStatus());
/*  366 */     if (!status.isOK()) {
/*  367 */       throw new ResourceException(status);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean descriptionChanged(IFile descriptionFile, byte[] newContents) {
/*  380 */     int bufsize = (newContents.length > 4096) ? 8192 : (newContents.length * 2); 
/*  381 */     try { Exception exception1 = null, exception2 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {  }
/*      */       finally
/*  408 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (Exception e)
/*  409 */     { Policy.log(e);
/*      */ 
/*      */       
/*  412 */       return true; }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public int doGetEncoding(IFileStore store) throws CoreException {
/*      */     
/*  420 */     try { Exception exception1 = null, exception2 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {  }
/*      */       finally
/*  441 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (IOException e)
/*  442 */     { String message = NLS.bind(Messages.localstore_couldNotRead, store.toString());
/*  443 */       throw new ResourceException(271, null, message, e); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean fastIsSynchronized(File target) {
/*  453 */     ResourceInfo info = target.getResourceInfo(false, false);
/*  454 */     if (target.exists(target.getFlags(info), true)) {
/*  455 */       IFileInfo fileInfo = getStore((IResource)target).fetchInfo();
/*  456 */       if (!fileInfo.isDirectory() && info.getLocalSyncInfo() == fileInfo.getLastModified())
/*  457 */         return true; 
/*      */     } 
/*  459 */     return false;
/*      */   }
/*      */   
/*      */   public boolean fastIsSynchronized(Folder target) {
/*  463 */     ResourceInfo info = target.getResourceInfo(false, false);
/*  464 */     if (target.exists(target.getFlags(info), true)) {
/*  465 */       IFileInfo fileInfo = getStore((IResource)target).fetchInfo();
/*  466 */       if (!fileInfo.exists() && info.getLocalSyncInfo() == fileInfo.getLastModified())
/*  467 */         return true; 
/*      */     } 
/*  469 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IFile fileForLocation(IPath location) {
/*  487 */     return (IFile)resourceForLocation(location, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public int getEncoding(File target) throws CoreException {
/*  496 */     IFileStore store = getStore((IResource)target);
/*  497 */     if (!store.fetchInfo().exists()) {
/*  498 */       String message = NLS.bind(Messages.localstore_fileNotFound, store.toString());
/*  499 */       throw new ResourceException(271, target.getFullPath(), message, null);
/*      */     } 
/*  501 */     return doGetEncoding(store);
/*      */   }
/*      */   
/*      */   public IHistoryStore getHistoryStore() {
/*  505 */     if (this._historyStore == null) {
/*  506 */       IPath location = getWorkspace().getMetaArea().getHistoryStoreLocation();
/*  507 */       location.toFile().mkdirs();
/*  508 */       IFileStore store = EFS.getLocalFileSystem().getStore(location);
/*  509 */       this._historyStore = new HistoryStore2(getWorkspace(), store, 256);
/*      */     } 
/*  511 */     return this._historyStore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getLocalName(IFileStore target) {
/*  520 */     return target.fetchInfo().getName();
/*      */   }
/*      */   
/*      */   protected IPath getProjectDefaultLocation(IProject project) {
/*  524 */     return this.workspace.getRoot().getLocation().append(project.getFullPath());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IFileStore getStore(IResource target) {
/*      */     try {
/*  535 */       return getStoreRoot(target).createStore(target.getFullPath(), target);
/*  536 */     } catch (CoreException coreException) {
/*      */       
/*  538 */       return EFS.getNullFileSystem().getStore(target.getFullPath());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FileStoreRoot getStoreRoot(IResource target) {
/*  546 */     ResourceInfo info = this.workspace.getResourceInfo(target.getFullPath(), true, false);
/*      */     
/*  548 */     if (info != null) {
/*  549 */       FileStoreRoot fileStoreRoot = info.getFileStoreRoot();
/*  550 */       if (fileStoreRoot != null && fileStoreRoot.isValid())
/*  551 */         return fileStoreRoot; 
/*  552 */       if (info.isSet(524288)) {
/*  553 */         ProjectDescription description = ((Project)target.getProject()).internalGetDescription();
/*  554 */         if (description != null) {
/*  555 */           setLocation(target, info, description.getGroupLocationURI(target.getProjectRelativePath()));
/*  556 */           return info.getFileStoreRoot();
/*      */         } 
/*  558 */         return info.getFileStoreRoot();
/*      */       } 
/*  560 */       if (info.isSet(65536)) {
/*  561 */         ProjectDescription description = ((Project)target.getProject()).internalGetDescription();
/*  562 */         if (description != null) {
/*  563 */           URI linkLocation = description.getLinkLocationURI(target.getProjectRelativePath());
/*      */           
/*  565 */           if (linkLocation != null) {
/*  566 */             setLocation(target, info, linkLocation);
/*  567 */             return info.getFileStoreRoot();
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  572 */     IContainer parent = target.getParent();
/*  573 */     if (parent == null) {
/*      */ 
/*      */       
/*  576 */       info = this.workspace.getResourceInfo((IPath)Path.ROOT, false, true);
/*  577 */       IWorkspaceRoot rootResource = this.workspace.getRoot();
/*  578 */       setLocation((IResource)rootResource, info, URIUtil.toURI(rootResource.getLocation()));
/*  579 */       return info.getFileStoreRoot();
/*      */     } 
/*  581 */     FileStoreRoot root = getStoreRoot((IResource)parent);
/*  582 */     if (info != null)
/*  583 */       info.setFileStoreRoot(root); 
/*  584 */     return root;
/*      */   }
/*      */   
/*      */   protected Workspace getWorkspace() {
/*  588 */     return this.workspace;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasSavedContent(IProject project) {
/*  595 */     return getStore((IResource)project).fetchInfo().exists();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasSavedDescription(IProject project) {
/*  602 */     return getStore((IResource)project).getChild(".project").fetchInfo().exists();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IFileStore initializeStore(IResource target, URI location) throws CoreException {
/*  613 */     ResourceInfo info = ((Resource)target).getResourceInfo(false, true);
/*  614 */     setLocation(target, info, location);
/*  615 */     FileStoreRoot root = getStoreRoot(target);
/*  616 */     return root.createStore(target.getFullPath(), target);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean internalWrite(IProject target, IProjectDescription description, int updateFlags, boolean hasPublicChanges, boolean hasPrivateChanges) throws CoreException {
/*  628 */     if (hasPrivateChanges)
/*  629 */       getWorkspace().getMetaArea().writePrivateDescription(target); 
/*  630 */     if (!hasPublicChanges) {
/*  631 */       return false;
/*      */     }
/*  633 */     if (description == null) {
/*  634 */       return false;
/*      */     }
/*      */     
/*  637 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/*  638 */     IFile descriptionFile = target.getFile(".project");
/*      */     try {
/*  640 */       (new ModelObjectWriter()).write(description, out, descriptionFile.getLineSeparator(true));
/*  641 */     } catch (IOException e) {
/*  642 */       String msg = NLS.bind(Messages.resources_writeMeta, target.getFullPath());
/*  643 */       throw new ResourceException(568, target.getFullPath(), msg, e);
/*      */     } 
/*  645 */     byte[] newContents = out.toByteArray();
/*      */ 
/*      */     
/*  648 */     if (!descriptionFile.exists()) {
/*  649 */       this.workspace.createResource((IResource)descriptionFile, false);
/*      */     
/*      */     }
/*  652 */     else if (!descriptionChanged(descriptionFile, newContents)) {
/*  653 */       return false;
/*      */     } 
/*  655 */     ByteArrayInputStream in = new ByteArrayInputStream(newContents);
/*  656 */     IFileStore descriptionFileStore = ((Resource)descriptionFile).getStore();
/*  657 */     IFileInfo fileInfo = descriptionFileStore.fetchInfo();
/*      */     
/*  659 */     if (fileInfo.getAttribute(2)) {
/*  660 */       IStatus result = getWorkspace().validateEdit(new IFile[] { descriptionFile }, null);
/*  661 */       if (!result.isOK()) {
/*  662 */         throw new ResourceException(result);
/*      */       }
/*  664 */       fileInfo = descriptionFileStore.fetchInfo();
/*      */     } 
/*      */ 
/*      */     
/*  668 */     write(descriptionFile, in, fileInfo, 1, false, (IProgressMonitor)SubMonitor.convert(null));
/*  669 */     this.workspace.getAliasManager().updateAliases((IResource)descriptionFile, getStore((IResource)descriptionFile), 0, (IProgressMonitor)SubMonitor.convert(null));
/*      */ 
/*      */ 
/*      */     
/*  673 */     long lastModified = ((Resource)descriptionFile).getResourceInfo(false, false).getLocalSyncInfo();
/*  674 */     ResourceInfo info = ((Resource)target).getResourceInfo(false, true);
/*  675 */     updateLocalSync(info, lastModified);
/*      */ 
/*      */     
/*  678 */     getWorkspace().getMetaArea().clearOldDescription(target);
/*  679 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDescriptionSynchronized(IProject target) {
/*  690 */     IFile descriptionFile = target.getFile(".project");
/*  691 */     ResourceInfo projectInfo = ((Resource)target).getResourceInfo(false, false);
/*  692 */     if (projectInfo == null)
/*  693 */       return false; 
/*  694 */     return (projectInfo.getLocalSyncInfo() == getStore((IResource)descriptionFile).fetchInfo().getLastModified());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSynchronized(IResource target, int depth) {
/*      */     IProject[] projects;
/*      */     byte b;
/*      */     int i;
/*      */     IProject[] arrayOfIProject1;
/*  708 */     switch (target.getType()) {
/*      */       case 8:
/*  710 */         if (depth == 0) {
/*  711 */           return true;
/*      */         }
/*  713 */         depth = (depth == 1) ? 0 : depth;
/*  714 */         projects = ((IWorkspaceRoot)target).getProjects(8);
/*  715 */         for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/*  716 */           if (!isSynchronized((IResource)project, depth))
/*  717 */             return false; 
/*      */           b++; }
/*      */         
/*  720 */         return true;
/*      */       case 4:
/*  722 */         if (!target.isAccessible())
/*  723 */           return true; 
/*      */         break;
/*      */       case 2:
/*  726 */         if (fastIsSynchronized((Folder)target))
/*  727 */           return true; 
/*      */         break;
/*      */       case 1:
/*  730 */         if (fastIsSynchronized((File)target))
/*  731 */           return true; 
/*      */         break;
/*      */     } 
/*  734 */     IsSynchronizedVisitor visitor = new IsSynchronizedVisitor((IProgressMonitor)SubMonitor.convert(null));
/*  735 */     UnifiedTree tree = new UnifiedTree(target);
/*      */     try {
/*  737 */       tree.accept(visitor, depth);
/*  738 */     } catch (CoreException e) {
/*  739 */       Policy.log((Throwable)e);
/*  740 */       return false;
/*  741 */     } catch (ResourceChangedException e) {
/*      */       
/*  743 */       asyncRefresh(e.target);
/*      */       
/*  745 */       return false;
/*      */     } 
/*  747 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLightweightAutoRefreshEnabled() {
/*  758 */     return this.lightweightAutoRefreshEnabled;
/*      */   }
/*      */   
/*      */   public void link(Resource target, URI location, IFileInfo fileInfo) throws CoreException {
/*  762 */     initializeStore((IResource)target, location);
/*  763 */     ResourceInfo info = target.getResourceInfo(false, true);
/*  764 */     long lastModified = (fileInfo == null) ? 0L : fileInfo.getLastModified();
/*  765 */     if (lastModified == 0L)
/*  766 */       info.clearModificationStamp(); 
/*  767 */     updateLocalSync(info, lastModified);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath locationFor(IResource target) {
/*  778 */     return locationFor(target, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath locationFor(IResource target, boolean canonical) {
/*  790 */     return getStoreRoot(target).localLocation(target.getFullPath(), target, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URI locationURIFor(IResource target) {
/*  801 */     return locationURIFor(target, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URI locationURIFor(IResource target, boolean canonical) {
/*  813 */     return getStoreRoot(target).computeURI(target.getFullPath(), canonical);
/*      */   }
/*      */ 
/*      */   
/*      */   public void move(IResource source, IFileStore destination, int flags, IProgressMonitor monitor) throws CoreException {
/*  818 */     getStore(source).move(destination, 0, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void propertyChange(Preferences.PropertyChangeEvent event) {
/*  824 */     if ("refresh.lightweight.enabled".equals(event.getProperty()))
/*  825 */       this.lightweightAutoRefreshEnabled = Boolean.parseBoolean(event.getNewValue().toString()); 
/*      */   }
/*      */   
/*      */   public InputStream read(IFile target, boolean force, IProgressMonitor monitor) throws CoreException {
/*  829 */     IFileStore store = getStore((IResource)target);
/*  830 */     if (this.lightweightAutoRefreshEnabled || !force) {
/*  831 */       IFileInfo fileInfo = store.fetchInfo();
/*  832 */       if (!fileInfo.exists()) {
/*  833 */         asyncRefresh((IResource)target);
/*  834 */         String message = NLS.bind(Messages.localstore_fileNotFound, store.toString());
/*  835 */         throw new ResourceException(368, target.getFullPath(), message, null);
/*      */       } 
/*  837 */       ResourceInfo info = ((Resource)target).getResourceInfo(true, false);
/*  838 */       int flags = ((Resource)target).getFlags(info);
/*  839 */       ((Resource)target).checkExists(flags, true);
/*  840 */       if (fileInfo.getLastModified() != info.getLocalSyncInfo()) {
/*  841 */         asyncRefresh((IResource)target);
/*  842 */         if (!force) {
/*  843 */           String message = NLS.bind(Messages.localstore_resourceIsOutOfSync, target.getFullPath());
/*  844 */           throw new ResourceException(274, target.getFullPath(), message, null);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     try {
/*  849 */       return store.openInputStream(0, monitor);
/*  850 */     } catch (CoreException e) {
/*  851 */       if (e.getStatus().getCode() == 269) {
/*  852 */         String message = NLS.bind(Messages.localstore_fileNotFound, store.toString());
/*  853 */         throw new ResourceException(368, target.getFullPath(), message, e);
/*      */       } 
/*  855 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ProjectDescription read(IProject target, boolean creation) throws CoreException {
/*  872 */     URI projectLocation = null;
/*  873 */     ProjectDescription privateDescription = null;
/*  874 */     if (creation) {
/*  875 */       privateDescription = new ProjectDescription();
/*  876 */       getWorkspace().getMetaArea().readPrivateDescription(target, privateDescription);
/*  877 */       projectLocation = privateDescription.getLocationURI();
/*      */     } else {
/*  879 */       ProjectDescription projectDescription = ((Project)target).internalGetDescription();
/*  880 */       if (projectDescription != null && projectDescription.getLocationURI() != null) {
/*  881 */         projectLocation = projectDescription.getLocationURI();
/*      */       }
/*      */     } 
/*  884 */     boolean isDefaultLocation = (projectLocation == null);
/*  885 */     if (isDefaultLocation) {
/*  886 */       projectLocation = URIUtil.toURI(getProjectDefaultLocation(target));
/*      */     }
/*  888 */     IFileStore projectStore = initializeStore((IResource)target, projectLocation);
/*  889 */     IFileStore descriptionStore = projectStore.getChild(".project");
/*  890 */     ProjectDescription description = null;
/*      */     
/*  892 */     ResourceException error = null; try {
/*  893 */       Exception exception2, exception1 = null;
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  898 */     catch (OperationCanceledException e) {
/*  899 */       String msg = NLS.bind(Messages.resources_missingProjectMeta, target.getName());
/*  900 */       throw new ResourceException(567, target.getFullPath(), msg, e);
/*  901 */     } catch (CoreException e) {
/*      */       
/*  903 */       description = getWorkspace().getMetaArea().readOldDescription(target);
/*  904 */       if (description != null)
/*  905 */         return description; 
/*  906 */       if (!descriptionStore.fetchInfo().exists()) {
/*  907 */         String str = NLS.bind(Messages.resources_missingProjectMeta, target.getName());
/*  908 */         throw new ResourceException(567, target.getFullPath(), str, null);
/*      */       } 
/*  910 */       String msg = NLS.bind(Messages.resources_readProjectMeta, target.getName());
/*  911 */       error = new ResourceException(567, target.getFullPath(), msg, (Throwable)e);
/*  912 */     } catch (IOException iOException) {}
/*      */ 
/*      */     
/*  915 */     if (error == null && description == null) {
/*  916 */       String msg = NLS.bind(Messages.resources_readProjectMeta, target.getName());
/*  917 */       error = new ResourceException(567, target.getFullPath(), msg, null);
/*      */     } 
/*  919 */     if (description != null) {
/*  920 */       if (!isDefaultLocation)
/*  921 */         description.setLocationURI(projectLocation); 
/*  922 */       if (creation && privateDescription != null)
/*      */       {
/*  924 */         description.updateDynamicState(privateDescription); } 
/*      */     } 
/*  926 */     long lastModified = descriptionStore.fetchInfo().getLastModified();
/*  927 */     IFile descriptionFile = target.getFile(".project");
/*      */ 
/*      */     
/*  930 */     ResourceInfo info = ((Resource)descriptionFile).getResourceInfo(false, false);
/*  931 */     if (info == null) {
/*      */       
/*  933 */       info = getWorkspace().createResource((IResource)descriptionFile, false);
/*  934 */       updateLocalSync(info, lastModified);
/*      */     } 
/*      */ 
/*      */     
/*  938 */     if (!creation) {
/*  939 */       updateLocalSync(info, lastModified);
/*      */     }
/*      */ 
/*      */     
/*  943 */     info = ((Resource)target).getResourceInfo(false, true);
/*  944 */     updateLocalSync(info, lastModified);
/*      */     
/*  946 */     if (error != null)
/*  947 */       throw error; 
/*  948 */     return description;
/*      */   }
/*      */   
/*      */   public boolean refresh(IResource target, int depth, boolean updateAliases, IProgressMonitor monitor) throws CoreException {
/*  952 */     switch (target.getType()) {
/*      */       case 8:
/*  954 */         return refreshRoot((IWorkspaceRoot)target, depth, updateAliases, monitor);
/*      */       case 4:
/*  956 */         if (!target.isAccessible()) {
/*  957 */           return false;
/*      */         }
/*      */       case 1:
/*      */       case 2:
/*  961 */         return refreshResource(target, depth, updateAliases, monitor);
/*      */     } 
/*  963 */     return false;
/*      */   }
/*      */   
/*      */   protected boolean refreshResource(IResource target, int depth, boolean updateAliases, IProgressMonitor monitor) throws CoreException {
/*  967 */     String title = NLS.bind(Messages.localstore_refreshing, target.getFullPath());
/*  968 */     SubMonitor subMonitor = SubMonitor.convert(monitor, title, 100);
/*  969 */     IFileTree fileTree = null;
/*      */     
/*  971 */     if (depth != 0) {
/*  972 */       IFileStore fileStore = ((Resource)target).getStore();
/*  973 */       fileTree = fileStore.getFileSystem().fetchFileTree(fileStore, (IProgressMonitor)subMonitor.newChild(2));
/*      */     } 
/*  975 */     UnifiedTree tree = (fileTree == null) ? new UnifiedTree(target) : new UnifiedTree(target, fileTree);
/*  976 */     SubMonitor refreshMonitor = subMonitor.newChild(98);
/*  977 */     RefreshLocalVisitor visitor = updateAliases ? new RefreshLocalAliasVisitor((IProgressMonitor)refreshMonitor) : new RefreshLocalVisitor((IProgressMonitor)refreshMonitor);
/*  978 */     tree.accept(visitor, depth);
/*  979 */     IStatus result = visitor.getErrorStatus();
/*  980 */     if (!result.isOK())
/*  981 */       throw new ResourceException(result); 
/*  982 */     return visitor.resourcesChanged();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean refreshRoot(IWorkspaceRoot target, int depth, boolean updateAliases, IProgressMonitor monitor) throws CoreException {
/*  992 */     IProject[] projects = target.getProjects(8);
/*  993 */     String title = Messages.localstore_refreshingRoot;
/*  994 */     SubMonitor subMonitor = SubMonitor.convert(monitor, title, projects.length);
/*      */ 
/*      */     
/*  997 */     if (depth == 0)
/*  998 */       return false; 
/*  999 */     boolean changed = false;
/*      */     
/* 1001 */     depth = (depth == 1) ? 0 : depth; byte b; int i; IProject[] arrayOfIProject1;
/* 1002 */     for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/* 1003 */       changed |= refresh((IResource)project, depth, updateAliases, (IProgressMonitor)subMonitor.newChild(1)); b++; }
/*      */     
/* 1005 */     return changed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IResource resourceFor(IPath path, boolean files) {
/* 1015 */     int numSegments = path.segmentCount();
/* 1016 */     if (files && numSegments < 2)
/* 1017 */       return null; 
/* 1018 */     IWorkspaceRoot root = getWorkspace().getRoot();
/* 1019 */     if (path.isRoot())
/* 1020 */       return (IResource)root; 
/* 1021 */     if (numSegments == 1)
/* 1022 */       return (IResource)root.getProject(path.segment(0)); 
/* 1023 */     return files ? (IResource)root.getFile(path) : (IResource)root.getFolder(path);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long setLocalTimeStamp(IResource target, ResourceInfo info, long value) throws CoreException {
/* 1030 */     IFileStore store = getStore(target);
/* 1031 */     IFileInfo fileInfo = store.fetchInfo();
/* 1032 */     fileInfo.setLastModified(value);
/* 1033 */     store.putInfo(fileInfo, 2048, null);
/*      */     
/* 1035 */     fileInfo = store.fetchInfo();
/* 1036 */     long actualValue = fileInfo.getLastModified();
/* 1037 */     updateLocalSync(info, actualValue);
/* 1038 */     return actualValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLocation(IResource target, ResourceInfo info, URI location) {
/* 1049 */     FileStoreRoot oldRoot = info.getFileStoreRoot();
/* 1050 */     if (location != null) {
/* 1051 */       location = FileUtil.realURI(location);
/* 1052 */       info.setFileStoreRoot(new FileStoreRoot(location, target.getFullPath()));
/*      */     } else {
/*      */       
/* 1055 */       info.setFileStoreRoot(null);
/*      */     } 
/* 1057 */     if (oldRoot != null) {
/* 1058 */       oldRoot.setValid(false);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void setResourceAttributes(IResource resource, ResourceAttributes attributes) throws CoreException {
/*      */     int i;
/* 1065 */     IFileStore store = getStore(resource);
/*      */     
/* 1067 */     boolean refresh = false;
/* 1068 */     if (resource instanceof IContainer && (store.getFileSystem().attributes() & 0x4) != 0)
/* 1069 */       i = store.fetchInfo().getAttribute(4) ^ attributes.isExecutable(); 
/* 1070 */     store.putInfo(FileUtil.attributesToFileInfo(attributes), 1024, null);
/*      */     
/* 1072 */     if (i != 0) {
/* 1073 */       this.workspace.getRefreshManager().refresh(resource);
/*      */     }
/*      */   }
/*      */   
/*      */   public void shutdown(IProgressMonitor monitor) throws CoreException {
/* 1078 */     if (this._historyStore != null)
/* 1079 */       this._historyStore.shutdown(monitor); 
/* 1080 */     ResourcesPlugin.getPlugin().getPluginPreferences().removePropertyChangeListener(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public void startup(IProgressMonitor monitor) {
/* 1085 */     Preferences preferences = ResourcesPlugin.getPlugin().getPluginPreferences();
/* 1086 */     preferences.addPropertyChangeListener(this);
/* 1087 */     this.lightweightAutoRefreshEnabled = preferences.getBoolean("refresh.lightweight.enabled");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateLocalSync(ResourceInfo info, long localSyncInfo) {
/* 1094 */     info.setLocalSyncInfo(localSyncInfo);
/* 1095 */     if (localSyncInfo == -1L) {
/* 1096 */       info.clear(2);
/*      */     } else {
/* 1098 */       info.set(2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(IFile target, InputStream content, IFileInfo fileInfo, int updateFlags, boolean append, IProgressMonitor monitor) throws CoreException {
/* 1109 */     SubMonitor subMonitor = SubMonitor.convert(monitor, 4);
/*      */     try {
/* 1111 */       IFileStore store = getStore((IResource)target);
/* 1112 */       if (fileInfo.getAttribute(2)) {
/* 1113 */         String message = NLS.bind(Messages.localstore_couldNotWriteReadOnly, target.getFullPath());
/* 1114 */         throw new ResourceException(272, target.getFullPath(), message, null);
/*      */       } 
/* 1116 */       long lastModified = fileInfo.getLastModified();
/* 1117 */       if (BitMask.isSet(updateFlags, 1)) {
/* 1118 */         if (append && !target.isLocal(0) && !fileInfo.exists())
/*      */         {
/* 1120 */           String message = NLS.bind(Messages.resources_mustBeLocal, target.getFullPath());
/* 1121 */           throw new ResourceException(369, target.getFullPath(), message, null);
/*      */         }
/*      */       
/* 1124 */       } else if (target.isLocal(0)) {
/* 1125 */         ResourceInfo resourceInfo = ((Resource)target).getResourceInfo(true, false);
/* 1126 */         if (resourceInfo == null) {
/* 1127 */           throw new IllegalStateException("No ResourceInfo for: " + target);
/*      */         }
/*      */         
/* 1130 */         if (lastModified != resourceInfo.getLocalSyncInfo()) {
/* 1131 */           asyncRefresh((IResource)target);
/* 1132 */           String message = NLS.bind(Messages.localstore_resourceIsOutOfSync, target.getFullPath());
/* 1133 */           throw new ResourceException(274, target.getFullPath(), message, null);
/*      */         } 
/* 1135 */         if (!fileInfo.exists()) {
/* 1136 */           asyncRefresh((IResource)target);
/* 1137 */           String message = NLS.bind(Messages.localstore_resourceDoesNotExist, target.getFullPath());
/* 1138 */           throw new ResourceException(269, target.getFullPath(), message, null);
/*      */         } 
/*      */       } else {
/* 1141 */         if (fileInfo.exists()) {
/* 1142 */           String message = NLS.bind(Messages.localstore_resourceExists, target.getFullPath());
/* 1143 */           throw new ResourceException(268, target.getFullPath(), message, null);
/*      */         } 
/* 1145 */         if (append) {
/* 1146 */           String message = NLS.bind(Messages.resources_mustBeLocal, target.getFullPath());
/* 1147 */           throw new ResourceException(369, target.getFullPath(), message, null);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1152 */       if (BitMask.isSet(updateFlags, 2) && fileInfo.exists() && 
/* 1153 */         storeHistory((IResource)target))
/*      */       {
/* 1155 */         getHistoryStore().addState(target.getFullPath(), store, fileInfo, false); } 
/* 1156 */       if (!fileInfo.exists()) {
/* 1157 */         IFileStore parent = store.getParent();
/* 1158 */         IFileInfo parentInfo = parent.fetchInfo();
/* 1159 */         if (!parentInfo.exists()) {
/* 1160 */           parent.mkdir(0, null);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1166 */       boolean restoreHiddenAttribute = false;
/* 1167 */       if (fileInfo.exists() && fileInfo.getAttribute(16) && Platform.getOS().equals("win32")) {
/* 1168 */         fileInfo.setAttribute(16, false);
/* 1169 */         store.putInfo(fileInfo, 1024, (IProgressMonitor)subMonitor.split(1));
/* 1170 */         restoreHiddenAttribute = true;
/*      */       } else {
/* 1172 */         subMonitor.split(1);
/*      */       } 
/* 1174 */       int options = append ? 1 : 0;
/* 1175 */       OutputStream out = store.openOutputStream(options, (IProgressMonitor)subMonitor.split(1));
/* 1176 */       if (restoreHiddenAttribute) {
/* 1177 */         fileInfo.setAttribute(16, true);
/* 1178 */         store.putInfo(fileInfo, 1024, (IProgressMonitor)subMonitor.split(1));
/*      */       } else {
/* 1180 */         subMonitor.split(1);
/*      */       } 
/* 1182 */       FileUtil.transferStreams(content, out, store.toString(), (IProgressMonitor)subMonitor.split(1));
/*      */       
/* 1184 */       lastModified = store.fetchInfo().getLastModified();
/* 1185 */       ResourceInfo info = ((Resource)target).getResourceInfo(false, true);
/* 1186 */       if (info == null)
/*      */       {
/* 1188 */         throw new IllegalStateException("No ResourceInfo for: " + target);
/*      */       }
/* 1190 */       updateLocalSync(info, lastModified);
/* 1191 */       info.incrementContentId();
/* 1192 */       info.clear(393216);
/* 1193 */       this.workspace.updateModificationStamp(info);
/*      */     } finally {
/* 1195 */       FileUtil.safeClose(content);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write(IFolder target, boolean force, IProgressMonitor monitor) throws CoreException {
/* 1204 */     IFileStore store = getStore((IResource)target);
/* 1205 */     if (!force) {
/* 1206 */       IFileInfo fileInfo = store.fetchInfo();
/* 1207 */       if (fileInfo.isDirectory()) {
/* 1208 */         String message = NLS.bind(Messages.localstore_resourceExists, target.getFullPath());
/* 1209 */         throw new ResourceException(268, target.getFullPath(), message, null);
/*      */       } 
/* 1211 */       if (fileInfo.exists()) {
/* 1212 */         String message = NLS.bind(Messages.localstore_fileExists, target.getFullPath());
/* 1213 */         throw new ResourceException(274, target.getFullPath(), message, null);
/*      */       } 
/*      */     } 
/* 1216 */     store.mkdir(0, monitor);
/* 1217 */     ResourceInfo info = ((Resource)target).getResourceInfo(false, true);
/* 1218 */     updateLocalSync(info, store.fetchInfo().getLastModified());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeSilently(IProject target) throws CoreException {
/* 1227 */     IPath location = locationFor((IResource)target, false);
/*      */     
/* 1229 */     if (location == null)
/*      */       return; 
/* 1231 */     IFileStore projectStore = getStore((IResource)target);
/* 1232 */     projectStore.mkdir(0, null);
/*      */     
/* 1234 */     ProjectDescription projectDescription = ((Project)target).internalGetDescription();
/* 1235 */     if (projectDescription == null) {
/*      */       return;
/*      */     }
/* 1238 */     getWorkspace().getMetaArea().writePrivateDescription(target);
/*      */ 
/*      */     
/* 1241 */     IFileStore fileStore = projectStore.getChild(".project"); try {
/* 1242 */       Exception exception2, exception1 = null;
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1247 */     catch (IOException e) {
/* 1248 */       String msg = NLS.bind(Messages.resources_writeMeta, target.getFullPath());
/* 1249 */       throw new ResourceException(568, target.getFullPath(), msg, e);
/*      */     } 
/*      */     
/* 1252 */     getWorkspace().getMetaArea().clearOldDescription(target);
/*      */   }
/*      */   
/*      */   public static boolean storeHistory(IResource file) {
/* 1256 */     WorkspaceDescription description = ((Workspace)file.getWorkspace()).internalGetDescription();
/* 1257 */     return !(!description.isKeepDerivedState() && file.isDerived());
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\FileSystemResourceManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */