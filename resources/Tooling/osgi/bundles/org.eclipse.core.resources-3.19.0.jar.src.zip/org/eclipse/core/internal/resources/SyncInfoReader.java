/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.eclipse.core.internal.utils.Messages;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.QualifiedName;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SyncInfoReader
/*    */ {
/*    */   protected Workspace workspace;
/*    */   protected Synchronizer synchronizer;
/*    */   
/*    */   public SyncInfoReader(Workspace workspace, Synchronizer synchronizer) {
/* 39 */     this.workspace = workspace;
/* 40 */     this.synchronizer = synchronizer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected SyncInfoReader getReader(int formatVersion) throws IOException {
/* 47 */     switch (formatVersion) {
/*    */       case 2:
/* 49 */         return new SyncInfoReader_2(this.workspace, this.synchronizer);
/*    */       case 3:
/* 51 */         return new SyncInfoReader_3(this.workspace, this.synchronizer);
/*    */     } 
/* 53 */     throw new IOException(NLS.bind(Messages.resources_format, Integer.valueOf(formatVersion)));
/*    */   }
/*    */ 
/*    */   
/*    */   public void readPartners(DataInputStream input) throws CoreException {
/*    */     try {
/* 59 */       int size = input.readInt();
/* 60 */       Set<QualifiedName> registry = new HashSet<>(size);
/* 61 */       for (int i = 0; i < size; i++) {
/* 62 */         String qualifier = input.readUTF();
/* 63 */         String local = input.readUTF();
/* 64 */         registry.add(new QualifiedName(qualifier, local));
/*    */       } 
/* 66 */       this.synchronizer.setRegistry(registry);
/* 67 */     } catch (IOException e) {
/* 68 */       String message = NLS.bind(Messages.resources_readSync, e);
/* 69 */       throw new ResourceException(new ResourceStatus(566, message));
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void readSyncInfo(DataInputStream input) throws IOException, CoreException {
/* 76 */     int formatVersion = readVersionNumber(input);
/* 77 */     SyncInfoReader reader = getReader(formatVersion);
/* 78 */     reader.readSyncInfo(input);
/*    */   }
/*    */   
/*    */   protected static int readVersionNumber(DataInputStream input) throws IOException {
/* 82 */     return input.readInt();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\SyncInfoReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */