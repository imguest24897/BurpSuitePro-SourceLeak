/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.jobs.IJobManager;
/*     */ import org.eclipse.core.runtime.jobs.ILock;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WorkManager
/*     */   implements IManager
/*     */ {
/*     */   static class NotifyRule
/*     */     implements ISchedulingRule
/*     */   {
/*     */     public boolean contains(ISchedulingRule rule) {
/*  53 */       return !(!(rule instanceof org.eclipse.core.resources.IResource) && !rule.getClass().equals(NotifyRule.class));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isConflicting(ISchedulingRule rule) {
/*  58 */       return contains(rule);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   private final ThreadLocal<Boolean> checkInFailed = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean hasBuildChanges;
/*     */ 
/*     */ 
/*     */   
/*     */   private IJobManager jobManager;
/*     */ 
/*     */ 
/*     */   
/*     */   private final ILock lock;
/*     */ 
/*     */   
/*  81 */   private int nestedOperations = 0;
/*     */   
/*  83 */   private NotifyRule notifyRule = new NotifyRule();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean operationCanceled = false;
/*     */ 
/*     */   
/*  90 */   private int preparedOperations = 0;
/*     */   private Workspace workspace;
/*     */   
/*     */   public WorkManager(Workspace workspace) {
/*  94 */     this.workspace = workspace;
/*  95 */     this.jobManager = Job.getJobManager();
/*  96 */     this.lock = this.jobManager.newLock();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int beginUnprotected() {
/* 107 */     int depth = this.lock.getDepth();
/* 108 */     for (int i = 0; i < depth; i++)
/* 109 */       this.lock.release(); 
/* 110 */     return depth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkIn(ISchedulingRule rule, IProgressMonitor monitor) throws CoreException {
/* 118 */     boolean success = false;
/*     */     try {
/* 120 */       if (this.workspace.isTreeLocked()) {
/* 121 */         String msg = Messages.resources_cannotModify;
/* 122 */         throw new ResourceException(380, null, msg, null);
/*     */       } 
/* 124 */       this.jobManager.beginRule(rule, monitor);
/* 125 */       this.lock.acquire();
/* 126 */       incrementPreparedOperations();
/* 127 */       success = true;
/*     */     } finally {
/*     */       
/* 130 */       if (!success) {
/* 131 */         this.checkInFailed.set(Boolean.TRUE);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInFailed(ISchedulingRule rule) {
/* 144 */     if (this.checkInFailed.get() != null) {
/*     */       
/* 146 */       this.checkInFailed.set(null);
/*     */       
/* 148 */       if (!this.workspace.isTreeLocked())
/* 149 */         this.jobManager.endRule(rule); 
/* 150 */       return true;
/*     */     } 
/* 152 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void checkOut(ISchedulingRule rule) {
/* 159 */     decrementPreparedOperations();
/* 160 */     rebalanceNestedOperations();
/*     */     
/* 162 */     if (this.preparedOperations == 0) {
/* 163 */       this.hasBuildChanges = false;
/*     */     }
/* 165 */     this.operationCanceled = false;
/*     */     try {
/* 167 */       this.lock.release();
/*     */     } finally {
/*     */       
/* 170 */       this.jobManager.endRule(rule);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void decrementPreparedOperations() {
/* 180 */     this.preparedOperations--;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endUnprotected(int depth) {
/* 189 */     for (int i = 0; i < depth; i++) {
/* 190 */       this.lock.acquire();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ILock getLock() {
/* 197 */     return this.lock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule getNotifyRule() {
/* 204 */     return this.notifyRule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int getPreparedOperationDepth() {
/* 213 */     return this.preparedOperations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void incrementNestedOperations() {
/* 222 */     this.nestedOperations++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void incrementPreparedOperations() {
/* 231 */     this.preparedOperations++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isBalanced() {
/* 241 */     return (this.nestedOperations == this.preparedOperations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLockAlreadyAcquired() {
/* 249 */     boolean result = false;
/*     */     try {
/* 251 */       boolean success = this.lock.acquire(0L);
/* 252 */       if (success) {
/*     */ 
/*     */         
/* 255 */         result = (this.lock.getDepth() > 1);
/* 256 */         this.lock.release();
/*     */       } 
/* 258 */     } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */     
/* 261 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void operationCanceled() {
/* 270 */     this.operationCanceled = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rebalanceNestedOperations() {
/* 280 */     this.nestedOperations = this.preparedOperations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setBuild(boolean hasChanges) {
/* 288 */     if (hasChanges && Policy.DEBUG_BUILD_NEEDED) {
/* 289 */       Policy.debug("Set build hasChanges: " + hasChanges + " hasBuildChanges: " + this.hasBuildChanges);
/* 290 */       if (!this.hasBuildChanges && Policy.DEBUG_BUILD_NEEDED_STACK) {
/* 291 */         Policy.debug(new RuntimeException("Set build hasChanges!"));
/*     */       }
/*     */     } 
/*     */     
/* 295 */     this.hasBuildChanges = !(!this.hasBuildChanges && !hasChanges);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldBuild() {
/* 303 */     if (this.hasBuildChanges) {
/* 304 */       if (this.operationCanceled)
/* 305 */         return false; 
/* 306 */       return true;
/*     */     } 
/* 308 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown(IProgressMonitor monitor) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void startup(IProgressMonitor monitor) {
/* 318 */     this.jobManager.beginRule((ISchedulingRule)this.workspace.getRoot(), monitor);
/* 319 */     this.lock.acquire();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void postWorkspaceStartup() {
/*     */     try {
/* 329 */       this.lock.release();
/*     */     } finally {
/*     */       
/* 332 */       this.jobManager.endRule((ISchedulingRule)this.workspace.getRoot());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\WorkManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */