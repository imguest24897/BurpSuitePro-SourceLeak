/*     */ package org.eclipse.core.internal.events;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.dtree.DeltaDataTree;
/*     */ import org.eclipse.core.internal.dtree.IComparator;
/*     */ import org.eclipse.core.internal.dtree.NodeComparison;
/*     */ import org.eclipse.core.internal.resources.MarkerSet;
/*     */ import org.eclipse.core.internal.resources.Project;
/*     */ import org.eclipse.core.internal.resources.ResourceInfo;
/*     */ import org.eclipse.core.internal.resources.Workspace;
/*     */ import org.eclipse.core.internal.watson.ElementTree;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceDeltaFactory
/*     */ {
/*  35 */   protected static final ResourceDelta[] NO_CHILDREN = new ResourceDelta[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourceDelta computeDelta(Workspace workspace, ElementTree oldTree, ElementTree newTree, IPath root, long markerGeneration) {
/*  45 */     ResourceComparator comparator = (markerGeneration >= 0L) ? ResourceComparator.getNotificationComparator() : ResourceComparator.getBuildComparator();
/*  46 */     newTree.immutable();
/*  47 */     DeltaDataTree delta = null;
/*  48 */     if (Path.ROOT.equals(root)) {
/*  49 */       delta = newTree.getDataTree().compareWith(oldTree.getDataTree(), (IComparator)comparator);
/*     */     } else {
/*  51 */       delta = newTree.getDataTree().compareWith(oldTree.getDataTree(), (IComparator)comparator, root);
/*     */     } 
/*  53 */     delta = delta.asReverseComparisonTree((IComparator)comparator);
/*  54 */     IPath pathInTree = root.isRoot() ? (IPath)Path.ROOT : root;
/*  55 */     Path path = Path.ROOT;
/*     */ 
/*     */     
/*  58 */     Map<IPath, MarkerSet> allMarkerDeltas = null;
/*  59 */     if (markerGeneration >= 0L) {
/*  60 */       allMarkerDeltas = workspace.getMarkerManager().getMarkerDeltas(markerGeneration);
/*     */     }
/*     */     
/*  63 */     ResourceDeltaInfo deltaInfo = new ResourceDeltaInfo(workspace, allMarkerDeltas, comparator);
/*  64 */     ResourceDelta result = createDelta(workspace, delta, deltaInfo, pathInTree, (IPath)path);
/*     */ 
/*     */     
/*  67 */     deltaInfo.setNodeIDMap(computeNodeIDMap(result, new NodeIDMap()));
/*  68 */     result.fixMovesAndMarkers(oldTree);
/*     */ 
/*     */ 
/*     */     
/*  72 */     int segmentCount = result.getFullPath().segmentCount();
/*  73 */     if (segmentCount <= 1)
/*  74 */       checkForOpen(result, segmentCount); 
/*  75 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void checkForOpen(ResourceDelta delta, int segmentCount) {
/*  84 */     if (delta.getKind() == 1 && 
/*  85 */       delta.newInfo.isSet(1)) {
/*  86 */       delta.status |= 0x4000;
/*     */     }
/*  88 */     if (segmentCount == 1) {
/*     */       return;
/*     */     }
/*  91 */     ResourceDelta[] arrayOfResourceDelta1 = delta.children; byte b; int i; ResourceDelta[] arrayOfResourceDelta2;
/*  92 */     for (i = (arrayOfResourceDelta2 = arrayOfResourceDelta1).length, b = 0; b < i; ) { IResourceDelta element = arrayOfResourceDelta2[b];
/*  93 */       checkForOpen((ResourceDelta)element, 1);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static NodeIDMap computeNodeIDMap(ResourceDelta delta, NodeIDMap nodeIDMap) {
/* 101 */     ResourceDelta[] arrayOfResourceDelta1 = delta.children; byte b; int i; ResourceDelta[] arrayOfResourceDelta2;
/* 102 */     for (i = (arrayOfResourceDelta2 = arrayOfResourceDelta1).length, b = 0; b < i; ) { long oldID, newID; IResourceDelta element = arrayOfResourceDelta2[b];
/* 103 */       ResourceDelta child = (ResourceDelta)element;
/* 104 */       IPath path = child.getFullPath();
/* 105 */       switch (child.getKind()) {
/*     */         case 1:
/* 107 */           nodeIDMap.putNewPath(child.newInfo.getNodeId(), path);
/*     */           break;
/*     */         case 2:
/* 110 */           nodeIDMap.putOldPath(child.oldInfo.getNodeId(), path);
/*     */           break;
/*     */         case 4:
/* 113 */           oldID = child.oldInfo.getNodeId();
/* 114 */           newID = child.newInfo.getNodeId();
/*     */           
/* 116 */           if (oldID != newID) {
/* 117 */             nodeIDMap.putOldPath(oldID, path);
/* 118 */             nodeIDMap.putNewPath(newID, path);
/*     */           } 
/*     */           break;
/*     */       } 
/*     */       
/* 123 */       computeNodeIDMap(child, nodeIDMap); b++; }
/*     */     
/* 125 */     return nodeIDMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static ResourceDelta createDelta(Workspace workspace, DeltaDataTree delta, ResourceDeltaInfo deltaInfo, IPath pathInTree, IPath pathInDelta) {
/* 134 */     ResourceDelta result = new ResourceDelta(pathInTree, deltaInfo);
/*     */ 
/*     */     
/* 137 */     NodeComparison compare = (NodeComparison)delta.getData(pathInDelta);
/* 138 */     int comparison = compare.getUserComparison();
/* 139 */     result.setStatus(comparison);
/* 140 */     if (comparison == 0 || Path.ROOT.equals(pathInTree)) {
/* 141 */       ResourceInfo info = workspace.getResourceInfo(pathInTree, true, false);
/* 142 */       result.setOldInfo(info);
/* 143 */       result.setNewInfo(info);
/*     */     } else {
/* 145 */       result.setOldInfo((ResourceInfo)compare.getOldData());
/* 146 */       result.setNewInfo((ResourceInfo)compare.getNewData());
/*     */     } 
/*     */     
/* 149 */     IPath[] childKeys = delta.getChildren(pathInDelta);
/* 150 */     int numChildren = childKeys.length;
/* 151 */     if (numChildren == 0) {
/* 152 */       result.setChildren(NO_CHILDREN);
/*     */     } else {
/* 154 */       ResourceDelta[] children = new ResourceDelta[numChildren];
/* 155 */       for (int i = 0; i < numChildren; i++) {
/*     */         
/* 157 */         IPath newTreePath = (pathInTree == pathInDelta) ? childKeys[i] : pathInTree.append(childKeys[i].lastSegment());
/* 158 */         children[i] = createDelta(workspace, delta, deltaInfo, newTreePath, childKeys[i]);
/*     */       } 
/* 160 */       result.setChildren(children);
/*     */     } 
/*     */ 
/*     */     
/* 164 */     int status = result.status;
/* 165 */     if ((status & 0x1F) == 0 && numChildren != 0) {
/* 166 */       result.setStatus(status |= 0x4);
/*     */     }
/*     */     
/* 169 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IResourceDelta newEmptyDelta(IProject project) {
/* 179 */     ResourceDelta result = new ResourceDelta(project.getFullPath(), new ResourceDeltaInfo((Workspace)project.getWorkspace(), null, ResourceComparator.getBuildComparator()));
/* 180 */     result.setStatus(0);
/* 181 */     result.setChildren(NO_CHILDREN);
/* 182 */     ResourceInfo info = ((Project)project).getResourceInfo(true, false);
/* 183 */     result.setOldInfo(info);
/* 184 */     result.setNewInfo(info);
/* 185 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\ResourceDeltaFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */