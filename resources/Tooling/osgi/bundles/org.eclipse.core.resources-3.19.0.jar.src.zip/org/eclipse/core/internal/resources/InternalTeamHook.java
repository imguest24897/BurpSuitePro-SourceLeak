/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.resources.IResourceRuleFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InternalTeamHook
/*    */ {
/*    */   protected void setRuleFactory(IProject project, IResourceRuleFactory factory) {
/* 33 */     Workspace workspace = (Workspace)project.getWorkspace();
/* 34 */     ((Rules)workspace.getRuleFactory()).setRuleFactory(project, factory);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\InternalTeamHook.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */