/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.eclipse.core.internal.localstore.IHistoryStore;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.UniversalUniqueIdentifier;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IFileState;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.content.IContentTypeManager;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileState
/*     */   extends PlatformObject
/*     */   implements IFileState
/*     */ {
/*  28 */   private static final IWorkspace workspace = ResourcesPlugin.getWorkspace();
/*     */   protected long lastModified;
/*     */   protected UniversalUniqueIdentifier uuid;
/*     */   protected IHistoryStore store;
/*     */   protected IPath fullPath;
/*     */   
/*     */   public FileState(IHistoryStore store, IPath fullPath, long lastModified, UniversalUniqueIdentifier uuid) {
/*  35 */     this.store = store;
/*  36 */     this.lastModified = lastModified;
/*  37 */     this.uuid = uuid;
/*  38 */     this.fullPath = fullPath;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean exists() {
/*  43 */     return this.store.exists(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCharset() throws CoreException {
/*  49 */     IResource file = workspace.getRoot().findMember(this.fullPath);
/*  50 */     if (file != null && file.getType() == 1) {
/*  51 */       return ((IFile)file).getCharset();
/*     */     }
/*     */     
/*  54 */     IContentTypeManager contentTypeManager = Platform.getContentTypeManager(); 
/*  55 */     try { Exception exception1 = null, exception2 = null; 
/*     */       try {  }
/*     */       finally
/*  58 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (IOException e)
/*  59 */     { String message = NLS.bind(Messages.history_errorContentDescription, getFullPath());
/*  60 */       throw new ResourceException(381, getFullPath(), message, e); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getContents() throws CoreException {
/*  66 */     return this.store.getContents(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getFullPath() {
/*  71 */     return this.fullPath;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getModificationTime() {
/*  76 */     return this.lastModified;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  81 */     return this.fullPath.lastSegment();
/*     */   }
/*     */   
/*     */   public UniversalUniqueIdentifier getUUID() {
/*  85 */     return this.uuid;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/*  90 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  98 */     StringBuilder s = new StringBuilder();
/*  99 */     s.append("FileState(uuid: ");
/* 100 */     s.append(this.uuid.toString());
/* 101 */     s.append(", lastModified: ");
/* 102 */     s.append(this.lastModified);
/* 103 */     s.append(", path: ");
/* 104 */     s.append(this.fullPath);
/* 105 */     s.append(')');
/* 106 */     return s.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\FileState.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */