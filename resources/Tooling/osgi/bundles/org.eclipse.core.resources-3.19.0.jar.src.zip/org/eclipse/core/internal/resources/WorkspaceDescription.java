/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import org.eclipse.core.resources.IWorkspaceDescription;
/*     */ import org.eclipse.core.runtime.preferences.DefaultScope;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WorkspaceDescription
/*     */   extends ModelObject
/*     */   implements IWorkspaceDescription
/*     */ {
/*     */   protected boolean autoBuilding;
/*     */   protected String[] buildOrder;
/*     */   protected long fileStateLongevity;
/*     */   protected int maxBuildIterations;
/*     */   protected int maxFileStates;
/*     */   protected long maxFileStateSize;
/*     */   private boolean keepDerivedState;
/*     */   protected boolean applyFileStatePolicy;
/*     */   private long snapshotInterval;
/*     */   protected int operationsPerSnapshot;
/*     */   protected long deltaExpiration;
/*     */   private int parallelBuildsCount;
/*     */   
/*     */   public WorkspaceDescription(String name) {
/*  39 */     super(name);
/*     */     
/*  41 */     IEclipsePreferences node = DefaultScope.INSTANCE.getNode("org.eclipse.core.resources");
/*  42 */     this.autoBuilding = node.getBoolean("description.autobuilding", true);
/*  43 */     this.maxBuildIterations = node.getInt("description.maxbuilditerations", 10);
/*  44 */     this.applyFileStatePolicy = node.getBoolean("description.applyfilestatepolicy", true);
/*  45 */     this.fileStateLongevity = node.getLong("description.filestatelongevity", 604800000L);
/*  46 */     this.maxFileStates = node.getInt("description.maxfilestates", 50);
/*  47 */     this.maxFileStateSize = node.getLong("description.maxfilestatesize", 1048576L);
/*  48 */     this.keepDerivedState = node.getBoolean("description.keepDerivedState", 
/*  49 */         false);
/*  50 */     this.snapshotInterval = node.getLong("description.snapshotinterval", 300000L);
/*  51 */     this.operationsPerSnapshot = node.getInt("snapshots.operations", 100);
/*  52 */     this.deltaExpiration = node.getLong("delta.expiration", 2592000000L);
/*  53 */     this.parallelBuildsCount = node.getInt("maxConcurrentBuilds", 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getBuildOrder() {
/*  61 */     return getBuildOrder(true);
/*     */   }
/*     */   
/*     */   public String[] getBuildOrder(boolean makeCopy) {
/*  65 */     if (this.buildOrder == null)
/*  66 */       return null; 
/*  67 */     return makeCopy ? (String[])this.buildOrder.clone() : this.buildOrder;
/*     */   }
/*     */   
/*     */   public long getDeltaExpiration() {
/*  71 */     return this.deltaExpiration;
/*     */   }
/*     */   
/*     */   public void setDeltaExpiration(long value) {
/*  75 */     this.deltaExpiration = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getFileStateLongevity() {
/*  83 */     return this.fileStateLongevity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxBuildIterations() {
/*  91 */     return this.maxBuildIterations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxFileStates() {
/*  99 */     return this.maxFileStates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMaxFileStateSize() {
/* 107 */     return this.maxFileStateSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isApplyFileStatePolicy() {
/* 115 */     return this.applyFileStatePolicy;
/*     */   }
/*     */   
/*     */   public int getOperationsPerSnapshot() {
/* 119 */     return this.operationsPerSnapshot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getSnapshotInterval() {
/* 127 */     return this.snapshotInterval;
/*     */   }
/*     */   
/*     */   public void internalSetBuildOrder(String[] value) {
/* 131 */     this.buildOrder = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAutoBuilding() {
/* 139 */     return this.autoBuilding;
/*     */   }
/*     */   
/*     */   public void setOperationsPerSnapshot(int value) {
/* 143 */     this.operationsPerSnapshot = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoBuilding(boolean value) {
/* 151 */     this.autoBuilding = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuildOrder(String[] value) {
/* 159 */     this.buildOrder = (value == null) ? null : (String[])value.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFileStateLongevity(long time) {
/* 167 */     this.fileStateLongevity = time;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxBuildIterations(int number) {
/* 175 */     this.maxBuildIterations = number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxFileStates(int number) {
/* 183 */     this.maxFileStates = number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxFileStateSize(long size) {
/* 191 */     this.maxFileStateSize = size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplyFileStatePolicy(boolean apply) {
/* 199 */     this.applyFileStatePolicy = apply;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSnapshotInterval(long snapshotInterval) {
/* 207 */     this.snapshotInterval = snapshotInterval;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaxConcurrentBuilds() {
/* 212 */     return this.parallelBuildsCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMaxConcurrentBuilds(int n) {
/* 217 */     this.parallelBuildsCount = n;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isKeepDerivedState() {
/* 222 */     return this.keepDerivedState;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setKeepDerivedState(boolean keepDerivedState) {
/* 227 */     this.keepDerivedState = keepDerivedState;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\WorkspaceDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */