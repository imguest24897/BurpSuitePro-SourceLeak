/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.internal.resources.Resource;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnifiedTreeNode
/*     */   implements ILocalStoreConstants
/*     */ {
/*     */   protected UnifiedTreeNode child;
/*     */   protected boolean existsWorkspace;
/*     */   protected IFileInfo fileInfo;
/*     */   protected IResource resource;
/*     */   protected IFileStore store;
/*     */   protected UnifiedTree tree;
/*     */   
/*     */   public UnifiedTreeNode(UnifiedTree tree, IResource resource, IFileStore store, IFileInfo fileInfo, boolean existsWorkspace) {
/*  36 */     this.tree = tree;
/*  37 */     this.resource = resource;
/*  38 */     this.store = store;
/*  39 */     this.fileInfo = fileInfo;
/*  40 */     this.existsWorkspace = existsWorkspace;
/*     */   }
/*     */   
/*     */   public boolean existsInFileSystem() {
/*  44 */     return (this.fileInfo != null && this.fileInfo.exists());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isErrorInFileSystem() {
/*  52 */     return (this.fileInfo != null && this.fileInfo.getError() != 0);
/*     */   }
/*     */   
/*     */   public boolean existsInWorkspace() {
/*  56 */     return this.existsWorkspace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<UnifiedTreeNode> getChildren() {
/*  63 */     return this.tree.getChildren(this);
/*     */   }
/*     */   
/*     */   protected UnifiedTreeNode getFirstChild() {
/*  67 */     return this.child;
/*     */   }
/*     */   
/*     */   public long getLastModified() {
/*  71 */     return (this.fileInfo == null) ? 0L : this.fileInfo.getLastModified();
/*     */   }
/*     */   
/*     */   public int getLevel() {
/*  75 */     return this.tree.getLevel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocalName() {
/*  83 */     return (this.fileInfo == null) ? null : this.fileInfo.getName();
/*     */   }
/*     */   
/*     */   public IResource getResource() {
/*  87 */     return this.resource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileStore getStore() {
/*  95 */     if (this.store == null)
/*  96 */       this.store = ((Resource)this.resource).getStore(); 
/*  97 */     return this.store;
/*     */   }
/*     */   
/*     */   public boolean isFolder() {
/* 101 */     return (this.fileInfo == null) ? false : this.fileInfo.isDirectory();
/*     */   }
/*     */   
/*     */   public boolean isSymbolicLink() {
/* 105 */     return (this.fileInfo == null) ? false : this.fileInfo.getAttribute(32);
/*     */   }
/*     */   
/*     */   public void removeChildrenFromTree() {
/* 109 */     this.tree.removeNodeChildrenFromQueue(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reuse(UnifiedTree aTree, IResource aResource, IFileStore aStore, IFileInfo info, boolean existsInWorkspace) {
/* 116 */     this.tree = aTree;
/* 117 */     this.child = null;
/* 118 */     this.resource = aResource;
/* 119 */     this.store = aStore;
/* 120 */     this.fileInfo = info;
/* 121 */     this.existsWorkspace = existsInWorkspace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void releaseForGc() {
/* 129 */     this.child = null;
/* 130 */     this.resource = null;
/* 131 */     this.store = null;
/* 132 */     this.fileInfo = null;
/*     */   }
/*     */   
/*     */   public void setExistsWorkspace(boolean exists) {
/* 136 */     this.existsWorkspace = exists;
/*     */   }
/*     */   
/*     */   protected void setFirstChild(UnifiedTreeNode child) {
/* 140 */     this.child = child;
/*     */   }
/*     */   
/*     */   public void setResource(IResource resource) {
/* 144 */     this.resource = resource;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 149 */     String s = (this.resource == null) ? "null" : this.resource.getFullPath().toString();
/* 150 */     return "Node: " + s;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\UnifiedTreeNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */