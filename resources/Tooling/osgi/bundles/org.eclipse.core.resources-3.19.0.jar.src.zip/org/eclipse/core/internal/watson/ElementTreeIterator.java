/*     */ package org.eclipse.core.internal.watson;
/*     */ 
/*     */ import org.eclipse.core.internal.dtree.AbstractDataTreeNode;
/*     */ import org.eclipse.core.internal.dtree.DataTreeNode;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElementTreeIterator
/*     */   implements IPathRequestor
/*     */ {
/*  47 */   private String[] segments = new String[10];
/*     */ 
/*     */   
/*     */   private int nextFreeSegment;
/*     */ 
/*     */   
/*     */   private ElementTree tree;
/*     */ 
/*     */   
/*     */   private IPath path;
/*     */ 
/*     */   
/*     */   private DataTreeNode treeRoot;
/*     */ 
/*     */ 
/*     */   
/*     */   public ElementTreeIterator(ElementTree tree, IPath path) {
/*  64 */     this.tree = tree;
/*  65 */     this.path = path;
/*     */ 
/*     */     
/*  68 */     synchronized (tree) {
/*  69 */       this.treeRoot = (DataTreeNode)tree.getDataTree().safeCopyCompleteSubtree(path);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doIteration(DataTreeNode node, IElementContentVisitor visitor) {
/*  79 */     if (this.nextFreeSegment >= this.segments.length) {
/*  80 */       grow();
/*     */     }
/*  82 */     this.segments[this.nextFreeSegment++] = node.getName();
/*     */ 
/*     */     
/*  85 */     if (visitor.visitElement(this.tree, this, node.getData())) {
/*     */       
/*  87 */       AbstractDataTreeNode[] children = node.getChildren();
/*  88 */       int len = children.length;
/*  89 */       for (int i = 0; i < len; i++) {
/*  90 */         doIteration((DataTreeNode)children[i], visitor);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  95 */     this.nextFreeSegment--;
/*  96 */     if (this.nextFreeSegment < 0) {
/*  97 */       this.nextFreeSegment = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void grow() {
/* 105 */     int oldLen = this.segments.length;
/* 106 */     String[] newPaths = new String[oldLen * 2];
/* 107 */     System.arraycopy(this.segments, 0, newPaths, 0, oldLen);
/* 108 */     this.segments = newPaths;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void iterate(IElementContentVisitor visitor) {
/* 117 */     if (this.path.isRoot()) {
/*     */       
/* 119 */       if (visitor.visitElement(this.tree, this, this.tree.getTreeData())) {
/* 120 */         if (this.treeRoot == null)
/*     */           return; 
/* 122 */         AbstractDataTreeNode[] children = this.treeRoot.getChildren();
/* 123 */         int len = children.length;
/* 124 */         for (int i = 0; i < len; i++) {
/* 125 */           AbstractDataTreeNode node = children[i];
/* 126 */           if (node instanceof DataTreeNode) {
/* 127 */             doIteration((DataTreeNode)node, visitor);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } else {
/* 132 */       if (this.treeRoot == null)
/*     */         return; 
/* 134 */       push(this.path, this.path.segmentCount() - 1);
/* 135 */       doIteration(this.treeRoot, visitor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void push(IPath pathToPush, int toPush) {
/* 143 */     if (toPush <= 0)
/*     */       return; 
/* 145 */     for (int i = 0; i < toPush; i++) {
/* 146 */       if (this.nextFreeSegment >= this.segments.length) {
/* 147 */         grow();
/*     */       }
/* 149 */       this.segments[this.nextFreeSegment++] = pathToPush.segment(i);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String requestName() {
/* 155 */     if (this.nextFreeSegment == 0)
/* 156 */       return ""; 
/* 157 */     return this.segments[this.nextFreeSegment - 1];
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath requestPath() {
/* 162 */     if (this.nextFreeSegment == 0)
/* 163 */       return (IPath)Path.ROOT; 
/* 164 */     int length = this.nextFreeSegment;
/* 165 */     for (int i = 0; i < this.nextFreeSegment; i++) {
/* 166 */       length += this.segments[i].length();
/*     */     }
/* 168 */     StringBuilder pathBuf = new StringBuilder(length);
/* 169 */     for (int j = 0; j < this.nextFreeSegment; j++) {
/* 170 */       pathBuf.append('/');
/* 171 */       pathBuf.append(this.segments[j]);
/*     */     } 
/* 173 */     return (IPath)new Path(null, pathBuf.toString());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\watson\ElementTreeIterator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */