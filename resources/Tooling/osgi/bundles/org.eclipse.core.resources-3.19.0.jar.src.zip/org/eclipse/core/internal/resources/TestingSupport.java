/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import org.eclipse.core.resources.ResourcesPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TestingSupport
/*    */ {
/*    */   public static Properties getMasterTable() {
/* 30 */     return ((Workspace)ResourcesPlugin.getWorkspace()).getSaveManager().getMasterTable();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void waitForSnapshot() {
/*    */     try {
/* 39 */       (((Workspace)ResourcesPlugin.getWorkspace()).getSaveManager()).snapshotJob.join();
/* 40 */     } catch (InterruptedException e) {
/* 41 */       e.printStackTrace();
/* 42 */       throw new RuntimeException("Interrupted while waiting for snapshot");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\TestingSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */