/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.core.internal.utils.IStringPoolParticipant;
/*     */ import org.eclipse.core.internal.utils.StringPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarkerSet
/*     */   implements Cloneable, IStringPoolParticipant
/*     */ {
/*     */   protected static final int MINIMUM_SIZE = 5;
/*  23 */   protected int elementCount = 0;
/*     */   protected IMarkerSetElement[] elements;
/*     */   
/*     */   public MarkerSet() {
/*  27 */     this(5);
/*     */   }
/*     */ 
/*     */   
/*     */   public MarkerSet(int capacity) {
/*  32 */     this.elements = new IMarkerSetElement[Math.max(5, capacity * 2)];
/*     */   }
/*     */   
/*     */   public void add(IMarkerSetElement element) {
/*  36 */     if (element == null)
/*     */       return; 
/*  38 */     int hash = hashFor(element.getId()) % this.elements.length;
/*     */     
/*     */     int i;
/*  41 */     for (i = hash; i < this.elements.length; i++) {
/*  42 */       if (this.elements[i] == null) {
/*  43 */         this.elements[i] = element;
/*  44 */         this.elementCount++;
/*     */         
/*  46 */         if (shouldGrow()) {
/*  47 */           expand();
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*  53 */     for (i = 0; i < hash - 1; i++) {
/*  54 */       if (this.elements[i] == null) {
/*  55 */         this.elements[i] = element;
/*  56 */         this.elementCount++;
/*     */         
/*  58 */         if (shouldGrow()) {
/*  59 */           expand();
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*  65 */     expand();
/*  66 */     add(element); } public void addAll(IMarkerSetElement[] toAdd) {
/*     */     byte b;
/*     */     int i;
/*     */     IMarkerSetElement[] arrayOfIMarkerSetElement;
/*  70 */     for (i = (arrayOfIMarkerSetElement = toAdd).length, b = 0; b < i; ) { IMarkerSetElement element = arrayOfIMarkerSetElement[b];
/*  71 */       add(element);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   protected Object clone() {
/*     */     try {
/*  77 */       MarkerSet copy = (MarkerSet)super.clone();
/*     */       
/*  79 */       copy.elements = (IMarkerSetElement[])this.elements.clone();
/*  80 */       return copy;
/*  81 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*     */       
/*  83 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean contains(long id) {
/*  88 */     return (get(id) != null);
/*     */   }
/*     */   
/*     */   public IMarkerSetElement[] elements() {
/*  92 */     IMarkerSetElement[] result = new IMarkerSetElement[this.elementCount];
/*  93 */     int j = 0; byte b; int i; IMarkerSetElement[] arrayOfIMarkerSetElement1;
/*  94 */     for (i = (arrayOfIMarkerSetElement1 = this.elements).length, b = 0; b < i; ) { IMarkerSetElement element = arrayOfIMarkerSetElement1[b];
/*  95 */       if (element != null)
/*  96 */         result[j++] = element;  b++; }
/*     */     
/*  98 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void expand() {
/* 106 */     IMarkerSetElement[] array = new IMarkerSetElement[this.elements.length * 2];
/* 107 */     int maxArrayIndex = array.length - 1; byte b; int i; IMarkerSetElement[] arrayOfIMarkerSetElement1;
/* 108 */     for (i = (arrayOfIMarkerSetElement1 = this.elements).length, b = 0; b < i; ) { IMarkerSetElement element = arrayOfIMarkerSetElement1[b];
/* 109 */       if (element != null) {
/* 110 */         int hash = hashFor(element.getId()) % array.length;
/* 111 */         while (array[hash] != null) {
/* 112 */           hash++;
/* 113 */           if (hash > maxArrayIndex)
/* 114 */             hash = 0; 
/*     */         } 
/* 116 */         array[hash] = element;
/*     */       }  b++; }
/*     */     
/* 119 */     this.elements = array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMarkerSetElement get(long id) {
/* 127 */     if (this.elementCount == 0)
/* 128 */       return null; 
/* 129 */     int hash = hashFor(id) % this.elements.length;
/*     */     
/*     */     int i;
/* 132 */     for (i = hash; i < this.elements.length; i++) {
/* 133 */       IMarkerSetElement element = this.elements[i];
/* 134 */       if (element == null)
/* 135 */         return null; 
/* 136 */       if (element.getId() == id) {
/* 137 */         return element;
/*     */       }
/*     */     } 
/*     */     
/* 141 */     for (i = 0; i < hash - 1; i++) {
/* 142 */       IMarkerSetElement element = this.elements[i];
/* 143 */       if (element == null)
/* 144 */         return null; 
/* 145 */       if (element.getId() == id) {
/* 146 */         return element;
/*     */       }
/*     */     } 
/*     */     
/* 150 */     return null;
/*     */   }
/*     */   
/*     */   private int hashFor(long id) {
/* 154 */     return Math.abs((int)id);
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 158 */     return (this.elementCount == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void rehashTo(int anIndex) {
/* 167 */     int target = anIndex;
/* 168 */     int index = anIndex + 1;
/* 169 */     if (index >= this.elements.length)
/* 170 */       index = 0; 
/* 171 */     IMarkerSetElement element = this.elements[index];
/* 172 */     while (element != null) {
/* 173 */       boolean match; int hashIndex = hashFor(element.getId()) % this.elements.length;
/*     */       
/* 175 */       if (index < target) {
/* 176 */         match = !(hashIndex > target || hashIndex <= index);
/*     */       } else {
/* 178 */         match = !(hashIndex > target && hashIndex <= index);
/* 179 */       }  if (match) {
/* 180 */         this.elements[target] = element;
/* 181 */         target = index;
/*     */       } 
/* 183 */       index++;
/* 184 */       if (index >= this.elements.length)
/* 185 */         index = 0; 
/* 186 */       element = this.elements[index];
/*     */     } 
/* 188 */     this.elements[target] = null;
/*     */   }
/*     */   
/*     */   public void remove(long id) {
/* 192 */     int hash = hashFor(id) % this.elements.length;
/*     */     int i;
/* 194 */     for (i = hash; i < this.elements.length; i++) {
/* 195 */       IMarkerSetElement element = this.elements[i];
/* 196 */       if (element == null)
/*     */         return; 
/* 198 */       if (element.getId() == id) {
/* 199 */         rehashTo(i);
/* 200 */         this.elementCount--;
/*     */       } 
/*     */     } 
/*     */     
/* 204 */     for (i = 0; i < hash - 1; i++) {
/* 205 */       IMarkerSetElement element = this.elements[i];
/* 206 */       if (element == null)
/*     */         return; 
/* 208 */       if (element.getId() == id) {
/* 209 */         rehashTo(i);
/* 210 */         this.elementCount--;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void remove(IMarkerSetElement element) {
/* 216 */     remove(element.getId()); } public void removeAll(IMarkerSetElement[] toRemove) {
/*     */     byte b;
/*     */     int i;
/*     */     IMarkerSetElement[] arrayOfIMarkerSetElement;
/* 220 */     for (i = (arrayOfIMarkerSetElement = toRemove).length, b = 0; b < i; ) { IMarkerSetElement element = arrayOfIMarkerSetElement[b];
/* 221 */       remove(element);
/*     */       b++; }
/*     */   
/*     */   } private boolean shouldGrow() {
/* 225 */     return (this.elementCount > this.elements.length * 0.75D);
/*     */   }
/*     */   
/*     */   public int size() {
/* 229 */     return this.elementCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shareStrings(StringPool set) {
/* 238 */     IMarkerSetElement[] array = this.elements;
/* 239 */     if (array == null)
/*     */       return;  byte b; int i; IMarkerSetElement[] arrayOfIMarkerSetElement1;
/* 241 */     for (i = (arrayOfIMarkerSetElement1 = array).length, b = 0; b < i; ) { IMarkerSetElement o = arrayOfIMarkerSetElement1[b];
/* 242 */       if (o instanceof IStringPoolParticipant) {
/* 243 */         ((IStringPoolParticipant)o).shareStrings(set);
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public String toString() {
/* 250 */     return Arrays.toString((Object[])elements());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\MarkerSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */