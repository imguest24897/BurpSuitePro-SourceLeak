/*     */ package org.eclipse.core.internal.utils;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cache
/*     */ {
/*     */   KeyedHashSet entries;
/*     */   Entry head;
/*     */   private int maximumCapacity;
/*     */   Entry tail;
/*     */   private double threshold;
/*     */   
/*     */   public class Entry
/*     */     implements KeyedHashSet.KeyedElement
/*     */   {
/*     */     Object cached;
/*     */     Object key;
/*     */     Entry next;
/*     */     Entry previous;
/*     */     long timestamp;
/*     */     
/*     */     public Entry(Object key, Object cached, long timestamp) {
/*  32 */       this.key = key;
/*  33 */       this.cached = cached;
/*  34 */       this.timestamp = timestamp;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean compare(KeyedHashSet.KeyedElement other) {
/*  39 */       if (!(other instanceof Entry))
/*  40 */         return false; 
/*  41 */       Entry otherEntry = (Entry)other;
/*  42 */       return this.key.equals(otherEntry.key);
/*     */     }
/*     */ 
/*     */     
/*     */     public void discard() {
/*  47 */       unchain();
/*  48 */       this.cached = null;
/*  49 */       Cache.this.entries.remove(this);
/*     */     }
/*     */     
/*     */     public Object getCached() {
/*  53 */       return this.cached;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getKey() {
/*  58 */       return this.key;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getKeyHashCode() {
/*  63 */       return this.key.hashCode();
/*     */     }
/*     */     
/*     */     public Entry getNext() {
/*  67 */       return this.next;
/*     */     }
/*     */     
/*     */     public Entry getPrevious() {
/*  71 */       return this.previous;
/*     */     }
/*     */     
/*     */     public long getTimestamp() {
/*  75 */       return this.timestamp;
/*     */     }
/*     */     
/*     */     public boolean isHead() {
/*  79 */       return (this.previous == null);
/*     */     }
/*     */     
/*     */     public boolean isTail() {
/*  83 */       return (this.next == null);
/*     */     }
/*     */ 
/*     */     
/*     */     void makeHead() {
/*  88 */       Entry oldHead = Cache.this.head;
/*  89 */       Cache.this.head = this;
/*  90 */       this.next = oldHead;
/*  91 */       this.previous = null;
/*  92 */       if (oldHead == null) {
/*  93 */         Cache.this.tail = this;
/*     */       } else {
/*  95 */         oldHead.previous = this;
/*     */       } 
/*     */     }
/*     */     public void setCached(Object cached) {
/*  99 */       this.cached = cached;
/*     */     }
/*     */     
/*     */     public void setTimestamp(long timestamp) {
/* 103 */       this.timestamp = timestamp;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 108 */       return this.key + " -> " + this.cached + " [" + this.timestamp + ']';
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     void unchain() {
/* 114 */       if (Cache.this.tail == this) {
/* 115 */         Cache.this.tail = this.previous;
/*     */       } else {
/* 117 */         this.next.previous = this.previous;
/*     */       } 
/* 119 */       if (Cache.this.head == this) {
/* 120 */         Cache.this.head = this.next;
/*     */       } else {
/* 122 */         this.previous.next = this.next;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cache(int maximumCapacity) {
/* 133 */     this(Math.min(7, maximumCapacity), maximumCapacity, 0.25D);
/*     */   }
/*     */   
/*     */   public Cache(int initialCapacity, int maximumCapacity, double threshold) {
/* 137 */     Assert.isTrue((maximumCapacity >= initialCapacity), "maximum capacity < initial capacity");
/* 138 */     Assert.isTrue((threshold >= 0.0D && threshold <= 1.0D), "threshold should be between 0 and 1");
/* 139 */     Assert.isTrue((initialCapacity > 0), "initial capacity must be greater than zero");
/* 140 */     this.entries = new KeyedHashSet(initialCapacity);
/* 141 */     this.maximumCapacity = maximumCapacity;
/* 142 */     this.threshold = threshold;
/*     */   }
/*     */   
/*     */   public void addEntry(Object key, Object toCache) {
/* 146 */     addEntry(key, toCache, 0L);
/*     */   }
/*     */   
/*     */   public Entry addEntry(Object key, Object toCache, long timestamp) {
/* 150 */     Entry newHead = (Entry)this.entries.getByKey(key);
/* 151 */     if (newHead == null)
/* 152 */       this.entries.add(newHead = new Entry(key, toCache, timestamp)); 
/* 153 */     newHead.cached = toCache;
/* 154 */     newHead.timestamp = timestamp;
/* 155 */     newHead.makeHead();
/* 156 */     int extraEntries = this.entries.size() - this.maximumCapacity;
/* 157 */     if (extraEntries > this.maximumCapacity * this.threshold)
/*     */     {
/*     */       
/* 160 */       packEntries(extraEntries); } 
/* 161 */     return newHead;
/*     */   }
/*     */   
/*     */   public Entry getEntry(Object key) {
/* 165 */     return getEntry(key, true);
/*     */   }
/*     */   
/*     */   public Entry getEntry(Object key, boolean update) {
/* 169 */     Entry existing = (Entry)this.entries.getByKey(key);
/* 170 */     if (existing == null)
/* 171 */       return null; 
/* 172 */     if (!update)
/* 173 */       return existing; 
/* 174 */     existing.unchain();
/* 175 */     existing.makeHead();
/* 176 */     return existing;
/*     */   }
/*     */   
/*     */   public Entry getHead() {
/* 180 */     return this.head;
/*     */   }
/*     */   
/*     */   public Entry getTail() {
/* 184 */     return this.tail;
/*     */   }
/*     */ 
/*     */   
/*     */   private void packEntries(int extraEntries) {
/* 189 */     Entry current = this.tail;
/* 190 */     for (; current != null && extraEntries > 0; extraEntries--) {
/* 191 */       current.discard();
/* 192 */       current = current.previous;
/*     */     } 
/*     */   }
/*     */   
/*     */   public long size() {
/* 197 */     return this.entries.size();
/*     */   }
/*     */   
/*     */   public void discardAll() {
/* 201 */     this.entries.clear();
/* 202 */     this.head = this.tail = null;
/*     */   }
/*     */   
/*     */   public void dispose() {
/* 206 */     discardAll();
/* 207 */     this.entries = null;
/* 208 */     this.head = this.tail = null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\interna\\utils\Cache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */