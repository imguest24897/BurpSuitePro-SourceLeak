/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.resources.IProjectNatureDescriptor;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProjectNatureDescriptor
/*     */   implements IProjectNatureDescriptor
/*     */ {
/*     */   protected String id;
/*     */   protected String label;
/*     */   protected String[] requiredNatures;
/*     */   protected String[] natureSets;
/*     */   protected String[] builderIds;
/*     */   protected String[] contentTypeIds;
/*     */   protected boolean allowLinking = true;
/*     */   protected boolean hasCycle = false;
/*  39 */   protected byte colour = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ProjectNatureDescriptor(IExtension natureExtension) throws CoreException {
/*  46 */     readExtension(natureExtension);
/*     */   }
/*     */   
/*     */   protected void fail() throws CoreException {
/*  50 */     fail(NLS.bind(Messages.natures_invalidDefinition, this.id));
/*     */   }
/*     */   
/*     */   protected void fail(String reason) throws CoreException {
/*  54 */     throw new ResourceException(new Status(4, "org.eclipse.core.resources", 1, reason, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getBuilderIds() {
/*  62 */     return this.builderIds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getContentTypeIds() {
/*  70 */     return this.contentTypeIds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNatureId() {
/*  78 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLabel() {
/*  86 */     return this.label;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getRequiredNatureIds() {
/*  94 */     return this.requiredNatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getNatureSetIds() {
/* 102 */     return this.natureSets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLinkingAllowed() {
/* 110 */     return this.allowLinking;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void readExtension(IExtension natureExtension) throws CoreException {
/* 118 */     this.id = natureExtension.getUniqueIdentifier();
/* 119 */     if (this.id == null) {
/* 120 */       fail(Messages.natures_missingIdentifier);
/*     */     }
/* 122 */     this.label = natureExtension.getLabel();
/* 123 */     IConfigurationElement[] elements = natureExtension.getConfigurationElements();
/* 124 */     int count = elements.length;
/* 125 */     ArrayList<String> requiredList = new ArrayList<>(count);
/* 126 */     ArrayList<String> setList = new ArrayList<>(count);
/* 127 */     ArrayList<String> builderList = new ArrayList<>(count);
/* 128 */     ArrayList<String> contentTypeList = new ArrayList<>(count);
/* 129 */     for (int i = 0; i < count; i++) {
/* 130 */       IConfigurationElement element = elements[i];
/* 131 */       String name = element.getName();
/* 132 */       if (name.equalsIgnoreCase("requires-nature")) {
/* 133 */         String attribute = element.getAttribute("id");
/* 134 */         if (attribute == null)
/* 135 */           fail(); 
/* 136 */         requiredList.add(attribute);
/* 137 */       } else if (name.equalsIgnoreCase("one-of-nature")) {
/* 138 */         String attribute = element.getAttribute("id");
/* 139 */         if (attribute == null)
/* 140 */           fail(); 
/* 141 */         setList.add(attribute);
/* 142 */       } else if (name.equalsIgnoreCase("builder")) {
/* 143 */         String attribute = element.getAttribute("id");
/* 144 */         if (attribute == null)
/* 145 */           fail(); 
/* 146 */         builderList.add(attribute);
/* 147 */       } else if (name.equalsIgnoreCase("content-type")) {
/* 148 */         String attribute = element.getAttribute("id");
/* 149 */         if (attribute == null)
/* 150 */           fail(); 
/* 151 */         contentTypeList.add(attribute);
/* 152 */       } else if (name.equalsIgnoreCase("options")) {
/* 153 */         String attribute = element.getAttribute("allowLinking");
/*     */         
/* 155 */         this.allowLinking = !Boolean.FALSE.toString().equalsIgnoreCase(attribute);
/*     */       } 
/*     */     } 
/* 158 */     this.requiredNatures = requiredList.<String>toArray(new String[requiredList.size()]);
/* 159 */     this.natureSets = setList.<String>toArray(new String[setList.size()]);
/* 160 */     this.builderIds = builderList.<String>toArray(new String[builderList.size()]);
/* 161 */     this.contentTypeIds = contentTypeList.<String>toArray(new String[contentTypeList.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 169 */     return "ProjectNatureDescriptor(" + this.id + ")";
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ProjectNatureDescriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */