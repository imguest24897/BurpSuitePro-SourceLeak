/*      */ package org.eclipse.core.internal.dtree;
/*      */ 
/*      */ import java.util.Objects;
/*      */ import org.eclipse.core.internal.utils.Messages;
/*      */ import org.eclipse.core.internal.utils.StringPool;
/*      */ import org.eclipse.core.runtime.Assert;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DeltaDataTree
/*      */   extends AbstractDataTree
/*      */ {
/*      */   private volatile AbstractDataTreeNode rootNode;
/*      */   private volatile DeltaDataTree parent;
/*      */   
/*      */   public DeltaDataTree() {
/*   51 */     this.rootNode = new DataTreeNode(null, null);
/*   52 */     this.parent = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeltaDataTree(AbstractDataTreeNode rootNode) {
/*   61 */     Objects.requireNonNull(rootNode);
/*   62 */     this.rootNode = rootNode;
/*   63 */     this.parent = null;
/*      */   }
/*      */   
/*      */   protected DeltaDataTree(AbstractDataTreeNode rootNode, DeltaDataTree parent) {
/*   67 */     Objects.requireNonNull(rootNode);
/*   68 */     this.rootNode = rootNode;
/*   69 */     this.parent = parent;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addChild(IPath parentKey, String localName, AbstractDataTreeNode childNode) {
/*   80 */     if (!includes(parentKey))
/*   81 */       handleNotFound(parentKey); 
/*   82 */     childNode.setName(localName);
/*   83 */     assembleNode(parentKey, new NoDataDeltaNode(parentKey.lastSegment(), childNode));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   DeltaDataTree asBackwardDelta() {
/*   94 */     if (getParent() == null)
/*   95 */       return newEmptyDeltaTree(); 
/*   96 */     return new DeltaDataTree(getRootNode().asBackwardDelta(this, getParent(), rootKey()), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeltaDataTree asReverseComparisonTree(IComparator comparator) {
/*  108 */     if (this.rootNode.getName() == null) {
/*  109 */       AbstractDataTreeNode[] children = this.rootNode.getChildren();
/*  110 */       int nextChild = 0; byte b; int i; AbstractDataTreeNode[] arrayOfAbstractDataTreeNode1;
/*  111 */       for (i = (arrayOfAbstractDataTreeNode1 = children).length, b = 0; b < i; ) { AbstractDataTreeNode c = arrayOfAbstractDataTreeNode1[b];
/*  112 */         AbstractDataTreeNode newChild = c.asReverseComparisonNode(comparator);
/*  113 */         if (newChild != null) {
/*  114 */           children[nextChild++] = newChild;
/*      */         }
/*      */         b++; }
/*      */       
/*  118 */       if (nextChild < children.length) {
/*  119 */         AbstractDataTreeNode[] newChildren = new AbstractDataTreeNode[nextChild];
/*  120 */         System.arraycopy(children, 0, newChildren, 0, nextChild);
/*  121 */         this.rootNode.setChildren(newChildren);
/*      */       } 
/*      */     } else {
/*  124 */       this.rootNode.asReverseComparisonNode(comparator);
/*      */     } 
/*  126 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void assembleNode(IPath key, AbstractDataTreeNode deltaNode) {
/*  138 */     setRootNode(this.rootNode.assembleWith(deltaNode, key, 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeltaDataTree assembleWithForwardDelta(DeltaDataTree deltaTree) {
/*  161 */     return new DeltaDataTree(getRootNode().assembleWith(deltaTree.getRootNode()), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeltaDataTree basicCompare(DeltaDataTree other, IComparator comparator, IPath path) {
/*      */     DeltaDataTree newTree;
/*  171 */     if (this == other) {
/*  172 */       newTree = new DeltaDataTree();
/*  173 */       newTree.setRootData(new NodeComparison(null, null, 0, 0));
/*  174 */     } else if (other.hasAncestor(this)) {
/*  175 */       AbstractDataTreeNode assembled = other.searchNodeAt(path);
/*  176 */       DeltaDataTree tree = other;
/*      */ 
/*      */       
/*  179 */       while ((tree = tree.getParent()) != this) {
/*      */         
/*  181 */         AbstractDataTreeNode treeNode = tree.searchLocalNodeAt(path);
/*  182 */         if (treeNode != null) {
/*  183 */           assembled = treeNode.assembleWith(assembled);
/*      */         }
/*      */       } 
/*  186 */       AbstractDataTreeNode comparedRoot = assembled.compareWithParent(path, this, comparator);
/*  187 */       newTree = new DeltaDataTree(comparedRoot);
/*  188 */     } else if (hasAncestor(other)) {
/*  189 */       AbstractDataTreeNode assembled = asBackwardDelta().searchNodeAt(path);
/*  190 */       DeltaDataTree tree = this;
/*      */ 
/*      */       
/*  193 */       while ((tree = tree.getParent()) != other) {
/*  194 */         assembled = assembled.assembleWith(tree.asBackwardDelta().searchNodeAt(path));
/*      */       }
/*  196 */       AbstractDataTreeNode comparedRoot = assembled.compareWithParent(path, this, comparator);
/*  197 */       newTree = new DeltaDataTree(comparedRoot);
/*      */     } else {
/*      */       
/*  200 */       DataTreeNode thisCompleteRoot = (DataTreeNode)copyCompleteSubtree(path);
/*  201 */       DataTreeNode otherCompleteRoot = (DataTreeNode)other.copyCompleteSubtree(path);
/*  202 */       AbstractDataTreeNode comparedRoot = thisCompleteRoot.compareWith(otherCompleteRoot, comparator);
/*  203 */       newTree = new DeltaDataTree(comparedRoot);
/*      */     } 
/*  205 */     newTree.immutable();
/*  206 */     return newTree;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeltaDataTree collapseTo(DeltaDataTree collapseTo, IComparator comparator) {
/*  223 */     if (this == collapseTo || getParent() == collapseTo)
/*      */     {
/*  225 */       return this;
/*      */     }
/*      */ 
/*      */     
/*  229 */     DeltaDataTree c = collapseTo.forwardDeltaWith(this, comparator);
/*      */ 
/*      */     
/*  232 */     setParent(collapseTo);
/*  233 */     setRootNode(c.rootNode);
/*  234 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeltaDataTree compareWith(DeltaDataTree other, IComparator comparator) {
/*      */     DeltaDataTree newTree;
/*  246 */     if (this == other) {
/*  247 */       newTree = new DeltaDataTree();
/*  248 */       newTree.setRootData(new NodeComparison(null, null, 0, 0));
/*  249 */     } else if (other.hasAncestor(this)) {
/*      */       
/*  251 */       AbstractDataTreeNode assembled = other.getRootNode();
/*  252 */       DeltaDataTree tree = other;
/*      */ 
/*      */       
/*  255 */       while ((tree = tree.getParent()) != this) {
/*  256 */         assembled = tree.getRootNode().assembleWith(assembled);
/*      */       }
/*  258 */       AbstractDataTreeNode comparedRoot = assembled.compareWithParent(rootKey(), this, comparator);
/*  259 */       newTree = new DeltaDataTree(comparedRoot);
/*  260 */     } else if (hasAncestor(other)) {
/*  261 */       AbstractDataTreeNode assembled = asBackwardDelta().getRootNode();
/*  262 */       DeltaDataTree tree = this;
/*      */ 
/*      */       
/*  265 */       while ((tree = tree.getParent()) != other) {
/*  266 */         assembled = assembled.assembleWith(tree.asBackwardDelta().getRootNode());
/*      */       }
/*  268 */       AbstractDataTreeNode comparedRoot = assembled.compareWithParent(rootKey(), this, comparator);
/*  269 */       newTree = new DeltaDataTree(comparedRoot);
/*      */     } else {
/*      */       
/*  272 */       DataTreeNode thisCompleteRoot = (DataTreeNode)copyCompleteSubtree(rootKey());
/*  273 */       DataTreeNode otherCompleteRoot = (DataTreeNode)other.copyCompleteSubtree(rootKey());
/*  274 */       AbstractDataTreeNode comparedRoot = thisCompleteRoot.compareWith(otherCompleteRoot, comparator);
/*  275 */       newTree = new DeltaDataTree(comparedRoot);
/*      */     } 
/*  277 */     newTree.immutable();
/*  278 */     return newTree;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeltaDataTree compareWith(DeltaDataTree other, IComparator comparator, IPath path) {
/*  287 */     if (includes(path)) {
/*  288 */       if (other.includes(path)) {
/*  289 */         return basicCompare(other, comparator, path);
/*      */       }
/*  291 */       return new DeltaDataTree(AbstractDataTreeNode.convertToRemovedComparisonNode(copyCompleteSubtree(path), comparator.compare(getData(path), null)));
/*      */     } 
/*  293 */     if (other.includes(path))
/*      */     {
/*  295 */       return new DeltaDataTree(AbstractDataTreeNode.convertToAddedComparisonNode(other.copyCompleteSubtree(path), comparator.compare(null, other.getData(path))));
/*      */     }
/*  297 */     return createEmptyDelta();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeltaDataTree copy() {
/*  304 */     return new DeltaDataTree(this.rootNode, this.parent);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractDataTreeNode copyCompleteSubtree(IPath key) {
/*  315 */     AbstractDataTreeNode node = searchNodeAt(key);
/*  316 */     if (node == null) {
/*  317 */       handleNotFound(key);
/*  318 */       return null;
/*      */     } 
/*  320 */     if (node.isDelta()) {
/*  321 */       return naiveCopyCompleteSubtree(key);
/*      */     }
/*  323 */     return node.copy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void createChild(IPath parentKey, String localName) {
/*  331 */     createChild(parentKey, localName, (Object)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void createChild(IPath parentKey, String localName, Object data) {
/*  339 */     if (isImmutable())
/*  340 */       handleImmutableTree(); 
/*  341 */     addChild(parentKey, localName, new DataTreeNode(localName, data));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static DeltaDataTree createEmptyDelta() {
/*  350 */     return new DeltaDataTree(new NoDataDeltaNode(null), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void createSubtree(IPath key, AbstractDataTreeNode node) {
/*  358 */     if (isImmutable())
/*  359 */       handleImmutableTree(); 
/*  360 */     if (key.isRoot()) {
/*  361 */       setParent((DeltaDataTree)null);
/*  362 */       setRootNode(node);
/*      */     } else {
/*  364 */       addChild(key.removeLastSegments(1), key.lastSegment(), node);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deleteChild(IPath parentKey, String localName) {
/*  373 */     if (isImmutable()) {
/*  374 */       handleImmutableTree();
/*      */     }
/*  376 */     IPath childKey = parentKey.append(localName);
/*  377 */     if (!includes(childKey))
/*  378 */       handleNotFound(childKey); 
/*  379 */     assembleNode(parentKey, new NoDataDeltaNode(parentKey.lastSegment(), new DeletedNode(localName)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractDataTreeNode findNodeAt(IPath key) {
/*  389 */     AbstractDataTreeNode node = this.rootNode;
/*  390 */     int segmentCount = key.segmentCount();
/*  391 */     for (int i = 0; i < segmentCount; i++) {
/*  392 */       node = node.childAtOrNull(key.segment(i));
/*  393 */       if (node == null)
/*  394 */         return null; 
/*      */     } 
/*  396 */     return node;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeltaDataTree forwardDeltaWith(DeltaDataTree sourceTree, IComparator comparer) {
/*      */     DeltaDataTree newTree;
/*  423 */     if (this == sourceTree) {
/*  424 */       newTree = newEmptyDeltaTree();
/*  425 */     } else if (sourceTree.hasAncestor(this)) {
/*  426 */       AbstractDataTreeNode assembled = sourceTree.getRootNode();
/*  427 */       DeltaDataTree treeParent = sourceTree;
/*      */ 
/*      */       
/*  430 */       while ((treeParent = treeParent.getParent()) != this) {
/*  431 */         assembled = treeParent.getRootNode().assembleWith(assembled);
/*      */       }
/*  433 */       newTree = new DeltaDataTree(assembled, this);
/*  434 */       newTree.simplify(comparer);
/*  435 */     } else if (hasAncestor(sourceTree)) {
/*      */       
/*  437 */       newTree = sourceTree.forwardDeltaWith(this, comparer);
/*  438 */       newTree = newTree.asBackwardDelta();
/*      */     } else {
/*  440 */       DataTreeNode thisCompleteRoot = (DataTreeNode)copyCompleteSubtree(rootKey());
/*  441 */       DataTreeNode sourceTreeCompleteRoot = (DataTreeNode)sourceTree.copyCompleteSubtree(rootKey());
/*  442 */       AbstractDataTreeNode deltaRoot = thisCompleteRoot.forwardDeltaWith(sourceTreeCompleteRoot, comparer);
/*  443 */       newTree = new DeltaDataTree(deltaRoot, this);
/*      */     } 
/*  445 */     newTree.immutable();
/*  446 */     return newTree;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getChildCount(IPath parentKey) {
/*  454 */     return (getChildNodes(parentKey)).length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractDataTreeNode[] getChildNodes(IPath parentKey) {
/*  470 */     AbstractDataTreeNode[] childNodes = null;
/*  471 */     int keyLength = parentKey.segmentCount();
/*  472 */     for (DeltaDataTree tree = this; tree != null; tree = tree.parent) {
/*  473 */       AbstractDataTreeNode node = tree.rootNode;
/*  474 */       boolean complete = !node.isDelta();
/*  475 */       for (int i = 0; i < keyLength; i++) {
/*  476 */         node = node.childAtOrNull(parentKey.segment(i));
/*  477 */         if (node == null) {
/*      */           break;
/*      */         }
/*  480 */         if (!node.isDelta()) {
/*  481 */           complete = true;
/*      */         }
/*      */       } 
/*  484 */       if (node != null) {
/*  485 */         if (node.isDeleted()) {
/*      */           break;
/*      */         }
/*  488 */         if (childNodes == null) {
/*  489 */           childNodes = node.children;
/*      */         }
/*      */         else {
/*      */           
/*  493 */           childNodes = AbstractDataTreeNode.assembleWith(node.children, childNodes, !complete);
/*      */         } 
/*      */       } 
/*  496 */       if (complete) {
/*  497 */         if (childNodes != null) {
/*  498 */           return childNodes;
/*      */         }
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*  504 */     if (childNodes != null)
/*      */     {
/*      */       
/*  507 */       Assert.isTrue(false, Messages.dtree_malformedTree);
/*      */     }
/*      */ 
/*      */     
/*  511 */     handleNotFound(parentKey);
/*  512 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath[] getChildren(IPath parentKey) {
/*  520 */     AbstractDataTreeNode[] childNodes = getChildNodes(parentKey);
/*  521 */     int len = childNodes.length;
/*  522 */     if (len == 0)
/*  523 */       return NO_CHILDREN; 
/*  524 */     IPath[] answer = new IPath[len];
/*  525 */     for (int i = 0; i < len; i++)
/*  526 */       answer[i] = parentKey.append((childNodes[i]).name); 
/*  527 */     return answer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getData(IPath key) {
/*  547 */     int keyLength = key.segmentCount();
/*  548 */     for (DeltaDataTree tree = this; tree != null; tree = tree.parent) {
/*  549 */       AbstractDataTreeNode node = tree.rootNode;
/*  550 */       boolean complete = !node.isDelta();
/*  551 */       for (int i = 0; i < keyLength; i++) {
/*  552 */         node = node.childAtOrNull(key.segment(i));
/*  553 */         if (node == null) {
/*      */           break;
/*      */         }
/*  556 */         if (!node.isDelta()) {
/*  557 */           complete = true;
/*      */         }
/*      */       } 
/*  560 */       if (node != null) {
/*  561 */         if (node.hasData())
/*  562 */           return node.getData(); 
/*  563 */         if (node.isDeleted()) {
/*      */           break;
/*      */         }
/*      */       } 
/*  567 */       if (complete) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/*  572 */     handleNotFound(key);
/*  573 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getNameOfChild(IPath parentKey, int index) {
/*  581 */     AbstractDataTreeNode[] childNodes = getChildNodes(parentKey);
/*  582 */     return (childNodes[index]).name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getNamesOfChildren(IPath parentKey) {
/*  592 */     AbstractDataTreeNode[] childNodes = getChildNodes(parentKey);
/*  593 */     int len = childNodes.length;
/*  594 */     String[] namesOfChildren = new String[len];
/*  595 */     for (int i = 0; i < len; i++)
/*  596 */       namesOfChildren[i] = (childNodes[i]).name; 
/*  597 */     return namesOfChildren;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeltaDataTree getParent() {
/*  604 */     return this.parent;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractDataTreeNode getRootNode() {
/*  616 */     return this.rootNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean hasAncestor(DeltaDataTree ancestor) {
/*  625 */     DeltaDataTree myParent = this;
/*  626 */     while ((myParent = myParent.getParent()) != null) {
/*  627 */       if (myParent == ancestor) {
/*  628 */         return true;
/*      */       }
/*      */     } 
/*  631 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean includes(IPath key) {
/*  640 */     return (searchNodeAt(key) != null);
/*      */   }
/*      */   
/*      */   public boolean isEmptyDelta() {
/*  644 */     return ((this.rootNode.getChildren()).length == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DataTreeLookup lookup(IPath key) {
/*  657 */     int keyLength = key.segmentCount();
/*  658 */     for (DeltaDataTree tree = this; tree != null; tree = tree.parent) {
/*  659 */       int j; AbstractDataTreeNode node = tree.rootNode;
/*  660 */       boolean complete = !node.isDelta();
/*  661 */       for (int i = 0; i < keyLength; i++) {
/*  662 */         node = node.childAtOrNull(key.segment(i));
/*  663 */         if (node == null) {
/*      */           break;
/*      */         }
/*  666 */         j = complete | (node.isDelta() ? 0 : 1);
/*      */       } 
/*  668 */       if (node != null) {
/*  669 */         if (node.hasData())
/*  670 */           return DataTreeLookup.newLookup(key, true, node.getData(), (tree == this)); 
/*  671 */         if (node.isDeleted()) {
/*      */           break;
/*      */         }
/*      */       } 
/*  675 */       if (j != 0) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/*  680 */     return DataTreeLookup.newLookup(key, false, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DataTreeLookup lookupIgnoreCase(IPath key) {
/*  695 */     int keyLength = key.segmentCount();
/*  696 */     for (DeltaDataTree tree = this; tree != null; tree = tree.parent) {
/*  697 */       int j; AbstractDataTreeNode node = tree.rootNode;
/*  698 */       boolean complete = !node.isDelta();
/*  699 */       for (int i = 0; i < keyLength; i++) {
/*  700 */         node = node.childAtIgnoreCase(key.segment(i));
/*  701 */         if (node == null) {
/*      */           break;
/*      */         }
/*  704 */         j = complete | (node.isDelta() ? 0 : 1);
/*      */       } 
/*  706 */       if (node != null) {
/*  707 */         if (node.hasData())
/*  708 */           return DataTreeLookup.newLookup(key, true, node.getData(), (tree == this)); 
/*  709 */         if (node.isDeleted()) {
/*      */           break;
/*      */         }
/*      */       } 
/*  713 */       if (j != 0) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/*  718 */     return DataTreeLookup.newLookup(key, false, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void makeComplete() {
/*  727 */     AbstractDataTreeNode assembled = getRootNode();
/*  728 */     DeltaDataTree myParent = getParent();
/*  729 */     while (myParent != null) {
/*  730 */       assembled = myParent.getRootNode().assembleWith(assembled);
/*  731 */       myParent = myParent.getParent();
/*      */     } 
/*  733 */     setRootNode(assembled);
/*  734 */     setParent((DeltaDataTree)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractDataTreeNode naiveCopyCompleteSubtree(IPath key) {
/*      */     AbstractDataTreeNode[] childNodes;
/*  745 */     String[] childNames = getNamesOfChildren(key);
/*  746 */     int numChildren = childNames.length;
/*      */     
/*  748 */     if (numChildren == 0) {
/*  749 */       childNodes = AbstractDataTreeNode.NO_CHILDREN;
/*      */     } else {
/*  751 */       childNodes = new AbstractDataTreeNode[numChildren];
/*      */       
/*  753 */       for (int i = numChildren; --i >= 0;) {
/*  754 */         childNodes[i] = copyCompleteSubtree(key.append(childNames[i]));
/*      */       }
/*      */     } 
/*  757 */     return new DataTreeNode(key.lastSegment(), getData(key), childNodes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeltaDataTree newEmptyDeltaTree() {
/*  767 */     if (!isImmutable())
/*  768 */       throw new IllegalArgumentException(Messages.dtree_notImmutable); 
/*  769 */     return new DeltaDataTree(new NoDataDeltaNode(null), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeltaDataTree reroot() {
/*  785 */     reroot(this);
/*  786 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void reroot(DeltaDataTree sourceTree) {
/*  803 */     if (!sourceTree.isImmutable())
/*  804 */       handleImmutableTree(); 
/*  805 */     DeltaDataTree sourceParent = sourceTree.getParent();
/*  806 */     if (sourceParent == null)
/*      */       return; 
/*  808 */     reroot(sourceParent);
/*  809 */     DeltaDataTree backwardDelta = sourceTree.asBackwardDelta();
/*  810 */     DeltaDataTree complete = sourceParent.assembleWithForwardDelta(sourceTree);
/*  811 */     sourceTree.setRootNode(complete.getRootNode());
/*  812 */     sourceTree.setParent((DeltaDataTree)null);
/*  813 */     sourceParent.setRootNode(backwardDelta.getRootNode());
/*  814 */     sourceParent.setParent(sourceTree);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AbstractDataTreeNode safeCopyCompleteSubtree(IPath key) {
/*  825 */     AbstractDataTreeNode node = searchNodeAt(key);
/*  826 */     if (node == null)
/*  827 */       return null; 
/*  828 */     if (node.isDelta()) {
/*  829 */       return safeNaiveCopyCompleteSubtree(key);
/*      */     }
/*  831 */     return node.copy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractDataTreeNode safeNaiveCopyCompleteSubtree(IPath key) {
/*      */     try {
/*      */       AbstractDataTreeNode[] childNodes;
/*  844 */       String[] childNames = getNamesOfChildren(key);
/*  845 */       int numChildren = childNames.length;
/*      */       
/*  847 */       if (numChildren == 0) {
/*  848 */         childNodes = AbstractDataTreeNode.NO_CHILDREN;
/*      */       } else {
/*  850 */         childNodes = new AbstractDataTreeNode[numChildren];
/*      */         
/*  852 */         int actualChildCount = 0;
/*  853 */         for (int i = numChildren; --i >= 0; ) {
/*  854 */           childNodes[i] = safeCopyCompleteSubtree(key.append(childNames[i]));
/*  855 */           if (childNodes[i] != null) {
/*  856 */             actualChildCount++;
/*      */           }
/*      */         } 
/*  859 */         if (actualChildCount < numChildren) {
/*  860 */           AbstractDataTreeNode[] actualChildNodes = new AbstractDataTreeNode[actualChildCount];
/*  861 */           for (int iOld = 0, iNew = 0; iOld < numChildren; iOld++) {
/*  862 */             if (childNodes[iOld] != null)
/*  863 */               actualChildNodes[iNew++] = childNodes[iOld]; 
/*  864 */           }  childNodes = actualChildNodes;
/*      */         } 
/*      */       } 
/*  867 */       return new DataTreeNode(key.lastSegment(), getData(key), childNodes);
/*  868 */     } catch (ObjectNotFoundException objectNotFoundException) {
/*  869 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractDataTreeNode searchNodeAt(IPath key) {
/*  878 */     int keyLength = key.segmentCount();
/*  879 */     for (DeltaDataTree tree = this; tree != null; tree = tree.parent) {
/*  880 */       AbstractDataTreeNode node = tree.rootNode;
/*  881 */       boolean complete = !node.isDelta();
/*  882 */       for (int i = 0; i < keyLength; i++) {
/*  883 */         node = node.childAtOrNull(key.segment(i));
/*  884 */         if (node == null) {
/*      */           break;
/*      */         }
/*  887 */         if (!node.isDelta()) {
/*  888 */           complete = true;
/*      */         }
/*      */       } 
/*  891 */       if (node != null) {
/*  892 */         if (node.isDeleted())
/*      */           break; 
/*  894 */         return node;
/*      */       } 
/*  896 */       if (complete) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/*  901 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbstractDataTreeNode searchLocalNodeAt(IPath key) {
/*  910 */     int keyLength = key.segmentCount();
/*  911 */     DeltaDataTree tree = this;
/*  912 */     AbstractDataTreeNode node = tree.rootNode;
/*  913 */     boolean complete = !node.isDelta();
/*  914 */     for (int i = 0; i < keyLength; i++) {
/*  915 */       node = node.childAtOrNull(key.segment(i));
/*  916 */       if (node == null) {
/*      */         break;
/*      */       }
/*  919 */       if (!node.isDelta()) {
/*  920 */         complete = true;
/*      */       }
/*      */     } 
/*  923 */     if (node != null) {
/*  924 */       if (node.isDeleted())
/*  925 */         return null; 
/*  926 */       return node;
/*      */     } 
/*  928 */     if (complete)
/*      */     {
/*  930 */       return null;
/*      */     }
/*  932 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setData(IPath key, Object data) {
/*  939 */     if (isImmutable())
/*  940 */       handleImmutableTree(); 
/*  941 */     if (!includes(key))
/*  942 */       handleNotFound(key); 
/*  943 */     assembleNode(key, new DataDeltaNode(key.lastSegment(), data));
/*      */   }
/*      */   
/*      */   public void setRootData(Object data) {
/*  947 */     setData(rootKey(), data);
/*      */   }
/*      */   
/*      */   public Object getRootData() {
/*  951 */     return getData(rootKey());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setParent(DeltaDataTree aTree) {
/*  958 */     this.parent = aTree;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setRootNode(AbstractDataTreeNode aNode) {
/*  966 */     this.rootNode = aNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void simplify(IComparator comparer) {
/*  976 */     if (this.parent == null)
/*      */       return; 
/*  978 */     setRootNode(this.rootNode.simplifyWithParent(rootKey(), this.parent, comparer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void storeStrings(StringPool set) {
/*  985 */     AbstractDataTreeNode root = null;
/*  986 */     for (DeltaDataTree dad = this; dad != null; dad = dad.getParent()) {
/*  987 */       root = dad.getRootNode();
/*  988 */       if (root != null) {
/*  989 */         root.storeStrings(set);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*  996 */     DeltaDataTree root = getParent();
/*  997 */     if (root == null && isEmptyDelta()) {
/*  998 */       return String.valueOf(getClass().getSimpleName()) + " -> rootNode=" + this.rootNode.toShortString();
/*      */     }
/* 1000 */     int depth = (root == null) ? 0 : 1;
/* 1001 */     while (root != null && root.getParent() != null) {
/* 1002 */       root = root.getParent();
/* 1003 */       depth++;
/*      */     } 
/*      */     
/* 1006 */     return String.valueOf(getClass().getSimpleName()) + ' ' + getRootData() + 
/* 1007 */       "->" + ((this.parent == null) ? null : (String)this.parent.getRootData()) + 
/* 1008 */       "->...depth " + depth + "..." + 
/* 1009 */       "->" + ((this.parent == null) ? null : (String)root.getRootData()) + 
/* 1010 */       " rootNode=" + this.rootNode.toShortString();
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\dtree\DeltaDataTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */