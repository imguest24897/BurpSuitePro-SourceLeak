/*    */ package org.eclipse.core.internal.resources.projectvariables;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.eclipse.core.resources.IContainer;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.variableresolvers.PathVariableResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WorkspaceParentLocationVariableResolver
/*    */   extends PathVariableResolver
/*    */ {
/* 27 */   public static String NAME = "PARENT_LOC";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getVariableNames(String variable, IResource resource) {
/* 35 */     return new String[] { NAME };
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue(String variable, IResource resource) {
/* 40 */     IContainer parent = resource.getParent();
/* 41 */     if (parent != null) {
/* 42 */       URI locationURI = parent.getLocationURI();
/* 43 */       if (locationURI != null)
/* 44 */         return locationURI.toASCIIString(); 
/*    */     } 
/* 46 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\projectvariables\WorkspaceParentLocationVariableResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */