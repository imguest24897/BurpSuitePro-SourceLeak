/*    */ package org.eclipse.core.internal.resources.projectvariables;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.variableresolvers.PathVariableResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProjectLocationVariableResolver
/*    */   extends PathVariableResolver
/*    */ {
/* 25 */   public static String NAME = "PROJECT_LOC";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getVariableNames(String variable, IResource resource) {
/* 33 */     return new String[] { NAME };
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue(String variable, IResource resource) {
/* 38 */     if (resource.getProject().getLocationURI() != null)
/* 39 */       return resource.getProject().getLocationURI().toASCIIString(); 
/* 40 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\projectvariables\ProjectLocationVariableResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */