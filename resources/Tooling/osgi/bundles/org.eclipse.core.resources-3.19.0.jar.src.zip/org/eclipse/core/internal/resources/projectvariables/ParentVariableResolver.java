/*    */ package org.eclipse.core.internal.resources.projectvariables;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.eclipse.core.filesystem.URIUtil;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.variableresolvers.PathVariableResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParentVariableResolver
/*    */   extends PathVariableResolver
/*    */ {
/*    */   public static final String NAME = "PARENT";
/*    */   
/*    */   public String getValue(String variable, IResource resource) {
/* 39 */     int index = variable.indexOf('-');
/* 40 */     if (index == -1 || index == variable.length() - 1) {
/* 41 */       return null;
/*    */     }
/* 43 */     String countRemaining = variable.substring(index + 1);
/* 44 */     index = countRemaining.indexOf('-');
/* 45 */     if (index == -1 || index == variable.length() - 1) {
/* 46 */       return null;
/*    */     }
/* 48 */     String countString = countRemaining.substring(0, index);
/* 49 */     int count = 0;
/*    */     try {
/* 51 */       count = Integer.parseInt(countString);
/* 52 */       if (count < 0)
/* 53 */         return null; 
/* 54 */     } catch (NumberFormatException numberFormatException) {
/* 55 */       return null;
/*    */     } 
/* 57 */     String argument = countRemaining.substring(index + 1);
/*    */     
/* 59 */     URI value = resource.getPathVariableManager().getURIValue(argument);
/* 60 */     if (value == null)
/* 61 */       return null; 
/* 62 */     value = resource.getPathVariableManager().resolveURI(value);
/* 63 */     value = URIUtil.toURI(URIUtil.toPath(value).removeLastSegments(count));
/*    */     
/* 65 */     return value.toASCIIString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\projectvariables\ParentVariableResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */