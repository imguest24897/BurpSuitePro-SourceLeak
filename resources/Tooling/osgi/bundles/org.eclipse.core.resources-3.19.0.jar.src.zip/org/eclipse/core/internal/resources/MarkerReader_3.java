/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarkerReader_3
/*     */   extends MarkerReader
/*     */ {
/*     */   public static final byte INDEX = 1;
/*     */   public static final byte QNAME = 2;
/*     */   public static final byte ATTRIBUTE_NULL = 0;
/*     */   public static final byte ATTRIBUTE_BOOLEAN = 1;
/*     */   public static final byte ATTRIBUTE_INTEGER = 2;
/*     */   public static final byte ATTRIBUTE_STRING = 3;
/*     */   
/*     */   public MarkerReader_3(Workspace workspace) {
/*  43 */     super(workspace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void read(DataInputStream input, boolean generateDeltas) throws IOException, CoreException {
/*     */     try {
/*  72 */       List<String> readTypes = new ArrayList<>(5);
/*     */       while (true) {
/*  74 */         Path path = new Path(input.readUTF());
/*  75 */         int markersSize = input.readInt();
/*  76 */         MarkerSet markers = new MarkerSet(markersSize);
/*  77 */         for (int i = 0; i < markersSize; i++) {
/*  78 */           markers.add(readMarkerInfo(input, readTypes));
/*     */         }
/*     */ 
/*     */         
/*  82 */         ResourceInfo info = this.workspace.getResourceInfo((IPath)path, false, false);
/*  83 */         if (info == null)
/*     */           continue; 
/*  85 */         info.setMarkers(markers);
/*  86 */         if (generateDeltas) {
/*     */ 
/*     */           
/*  89 */           Resource resource = this.workspace.newResource((IPath)path, info.getType());
/*  90 */           IMarkerSetElement[] infos = markers.elements;
/*  91 */           ArrayList<MarkerDelta> deltas = new ArrayList<>(infos.length); byte b; int j; IMarkerSetElement[] arrayOfIMarkerSetElement1;
/*  92 */           for (j = (arrayOfIMarkerSetElement1 = infos).length, b = 0; b < j; ) { IMarkerSetElement info2 = arrayOfIMarkerSetElement1[b];
/*  93 */             if (info2 != null)
/*  94 */               deltas.add(new MarkerDelta(1, resource, (MarkerInfo)info2));  b++; }
/*  95 */            this.workspace.getMarkerManager().changedMarkers(resource, deltas.<IMarkerSetElement>toArray(new IMarkerSetElement[deltas.size()]));
/*     */         } 
/*     */       } 
/*  98 */     } catch (EOFException eOFException) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Map<String, Object> readAttributes(DataInputStream input) throws IOException {
/* 104 */     int attributesSize = input.readShort();
/* 105 */     if (attributesSize == 0)
/* 106 */       return null; 
/* 107 */     Map<String, Object> result = new HashMap<>(attributesSize);
/* 108 */     for (int j = 0; j < attributesSize; j++) {
/* 109 */       String key = input.readUTF();
/* 110 */       byte type = input.readByte();
/* 111 */       Object value = null;
/* 112 */       switch (type) {
/*     */         
/*     */         case 2:
/* 115 */           value = Integer.valueOf(input.readInt());
/*     */           break;
/*     */         case 1:
/* 118 */           value = Boolean.valueOf(input.readBoolean());
/*     */           break;
/*     */         case 3:
/* 121 */           value = input.readUTF();
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 127 */       if (value != null) {
/* 128 */         result.put(key, value);
/*     */       }
/*     */     } 
/* 131 */     return result.isEmpty() ? null : result;
/*     */   }
/*     */   private MarkerInfo readMarkerInfo(DataInputStream input, List<String> readTypes) throws IOException, CoreException {
/*     */     Map<String, Object> map, map1;
/* 135 */     long creationTime, id = input.readLong();
/* 136 */     String type = null;
/* 137 */     byte constant = input.readByte();
/* 138 */     switch (constant) {
/*     */       case 2:
/* 140 */         type = input.readUTF();
/* 141 */         readTypes.add(type);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 151 */         map = readAttributes(input);
/* 152 */         creationTime = input.readLong();
/* 153 */         return new MarkerInfo(map, false, creationTime, type, id);case 1: type = readTypes.get(input.readInt()); map1 = readAttributes(input); creationTime = input.readLong(); return new MarkerInfo(map1, false, creationTime, type, id);
/*     */     } 
/*     */     String str1 = Messages.resources_readMarkers;
/*     */     throw new ResourceException(567, null, str1, null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\MarkerReader_3.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */