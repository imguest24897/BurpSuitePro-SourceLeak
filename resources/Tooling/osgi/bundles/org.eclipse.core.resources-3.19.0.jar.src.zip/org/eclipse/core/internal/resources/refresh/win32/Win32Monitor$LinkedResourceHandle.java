/*     */ package org.eclipse.core.internal.resources.refresh.win32;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinkedResourceHandle
/*     */   extends Win32Monitor.ChainedHandle
/*     */ {
/*     */   private List<Win32Monitor.FileHandle> fileHandleChain;
/*     */   private IResource resource;
/*     */   
/*     */   public LinkedResourceHandle(IResource resource) {
/* 238 */     this.resource = resource;
/* 239 */     createFileHandleChain();
/*     */   }
/*     */   
/*     */   protected void createFileHandleChain() {
/* 243 */     this.fileHandleChain = new ArrayList<>(1);
/* 244 */     File file = new File(this.resource.getLocation().toOSString());
/* 245 */     file = file.getParentFile();
/* 246 */     while (file != null) {
/* 247 */       this.fileHandleChain.add(0, new Win32Monitor.FileHandle(Win32Monitor.this, file));
/* 248 */       file = file.getParentFile();
/*     */     } 
/* 250 */     int size = this.fileHandleChain.size();
/* 251 */     for (int i = 0; i < size; i++) {
/* 252 */       Win32Monitor.ChainedHandle handle = this.fileHandleChain.get(i);
/* 253 */       handle.setPrevious((i > 0) ? this.fileHandleChain.get(i - 1) : null);
/* 254 */       handle.setNext((i + 1 < size) ? this.fileHandleChain.get(i + 1) : this);
/*     */     } 
/* 256 */     setPrevious((size > 0) ? this.fileHandleChain.get(size - 1) : null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 261 */     super.destroy();
/* 262 */     for (Win32Monitor.FileHandle fileHandle : this.fileHandleChain) {
/* 263 */       Win32Monitor.Handle handle = fileHandle;
/* 264 */       handle.destroy();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean exists() {
/* 270 */     IPath location = this.resource.getLocation();
/* 271 */     return (location == null) ? false : location.toFile().exists();
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleNotification() {
/* 276 */     if (isOpen()) {
/* 277 */       postRefreshRequest(this.resource);
/* 278 */       findNextChange();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void open() {
/* 284 */     if (!isOpen()) {
/* 285 */       if (exists()) {
/* 286 */         openHandleOn(this.resource);
/*     */       }
/* 288 */       Win32Monitor.FileHandle handle = (Win32Monitor.FileHandle)getPrevious();
/* 289 */       if (handle != null && !handle.isOpen()) {
/* 290 */         handle.open();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void postRefreshRequest() {
/* 296 */     postRefreshRequest(this.resource);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 301 */     return this.resource.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\refresh\win32\Win32Monitor$LinkedResourceHandle.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */