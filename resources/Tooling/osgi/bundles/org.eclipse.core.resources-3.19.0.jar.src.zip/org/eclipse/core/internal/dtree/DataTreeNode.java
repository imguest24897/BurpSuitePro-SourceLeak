/*     */ package org.eclipse.core.internal.dtree;
/*     */ 
/*     */ import org.eclipse.core.internal.utils.IStringPoolParticipant;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.StringPool;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataTreeNode
/*     */   extends AbstractDataTreeNode
/*     */ {
/*     */   protected Object data;
/*     */   
/*     */   public DataTreeNode(String name, Object data) {
/*  35 */     super(name, AbstractDataTreeNode.NO_CHILDREN);
/*  36 */     this.data = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataTreeNode(String name, Object data, AbstractDataTreeNode[] children) {
/*  47 */     super(name, children);
/*  48 */     this.data = data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode asBackwardDelta(DeltaDataTree myTree, DeltaDataTree parentTree, IPath key) {
/*  56 */     if (parentTree.includes(key))
/*  57 */       return parentTree.copyCompleteSubtree(key); 
/*  58 */     return new DeletedNode(this.name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode asReverseComparisonNode(IComparator comparator) {
/*  68 */     NodeComparison comparison = null;
/*     */     try {
/*  70 */       comparison = ((NodeComparison)this.data).asReverseComparison(comparator);
/*  71 */     } catch (ClassCastException classCastException) {
/*  72 */       Assert.isTrue(false, Messages.dtree_reverse);
/*     */     } 
/*     */     
/*  75 */     int nextChild = 0; byte b; int i; AbstractDataTreeNode[] arrayOfAbstractDataTreeNode;
/*  76 */     for (i = (arrayOfAbstractDataTreeNode = this.children).length, b = 0; b < i; ) { AbstractDataTreeNode c = arrayOfAbstractDataTreeNode[b];
/*  77 */       AbstractDataTreeNode child = c.asReverseComparisonNode(comparator);
/*  78 */       if (child != null) {
/*  79 */         this.children[nextChild++] = child;
/*     */       }
/*     */       b++; }
/*     */     
/*  83 */     if (nextChild == 0 && comparison.getUserComparison() == 0)
/*     */     {
/*  85 */       return null;
/*     */     }
/*     */ 
/*     */     
/*  89 */     this.data = comparison;
/*     */ 
/*     */     
/*  92 */     if (nextChild < this.children.length) {
/*  93 */       AbstractDataTreeNode[] newChildren = new AbstractDataTreeNode[nextChild];
/*  94 */       System.arraycopy(this.children, 0, newChildren, 0, nextChild);
/*  95 */       this.children = newChildren;
/*     */     } 
/*     */     
/*  98 */     return this;
/*     */   }
/*     */   
/*     */   AbstractDataTreeNode compareWith(DataTreeNode other, IComparator comparator) {
/* 102 */     AbstractDataTreeNode[] comparedChildren = compareWith(this.children, other.children, comparator);
/* 103 */     Object oldData = this.data;
/* 104 */     Object newData = other.data;
/*     */ 
/*     */     
/* 107 */     int userComparison = 0;
/* 108 */     if (this.name != null) {
/* 109 */       userComparison = comparator.compare(oldData, newData);
/*     */     }
/*     */     
/* 112 */     return new DataTreeNode(this.name, new NodeComparison(oldData, newData, 4, userComparison), comparedChildren);
/*     */   }
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode compareWithParent(IPath key, DeltaDataTree parent, IComparator comparator) {
/* 117 */     if (!parent.includes(key))
/* 118 */       return convertToAddedComparisonNode(this, 1); 
/* 119 */     DataTreeNode inParent = (DataTreeNode)parent.copyCompleteSubtree(key);
/* 120 */     return inParent.compareWith(this, comparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode copy() {
/* 128 */     if (this.children.length > 0) {
/* 129 */       AbstractDataTreeNode[] childrenCopy = new AbstractDataTreeNode[this.children.length];
/* 130 */       System.arraycopy(this.children, 0, childrenCopy, 0, this.children.length);
/* 131 */       return new DataTreeNode(this.name, this.data, childrenCopy);
/*     */     } 
/* 133 */     return new DataTreeNode(this.name, this.data, this.children);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DataTreeNode copyWithNewChild(String localName, DataTreeNode childNode) {
/* 147 */     AbstractDataTreeNode[] children = this.children;
/* 148 */     int left = 0;
/* 149 */     int right = children.length - 1;
/* 150 */     while (left <= right) {
/* 151 */       int mid = (left + right) / 2;
/* 152 */       int compare = localName.compareTo((children[mid]).name);
/* 153 */       if (compare < 0) {
/* 154 */         right = mid - 1; continue;
/* 155 */       }  if (compare > 0) {
/* 156 */         left = mid + 1; continue;
/*     */       } 
/* 158 */       throw new Error();
/*     */     } 
/*     */ 
/*     */     
/* 162 */     AbstractDataTreeNode[] newChildren = new AbstractDataTreeNode[children.length + 1];
/* 163 */     System.arraycopy(children, 0, newChildren, 0, left);
/* 164 */     childNode.setName(localName);
/* 165 */     newChildren[left] = childNode;
/* 166 */     System.arraycopy(children, left, newChildren, left + 1, children.length - left);
/* 167 */     return new DataTreeNode(getName(), getData(), newChildren);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DataTreeNode copyWithoutChild(String localName) {
/*     */     DataTreeNode newNode;
/* 183 */     int index = indexOfChild(localName);
/* 184 */     if (index == -1) {
/* 185 */       newNode = (DataTreeNode)copy();
/*     */     } else {
/* 187 */       int newSize = size() - 1;
/* 188 */       AbstractDataTreeNode[] children = new AbstractDataTreeNode[newSize];
/* 189 */       newNode = new DataTreeNode(getName(), getData(), children);
/* 190 */       newNode.copyChildren(0, index - 1, this, 0);
/* 191 */       newNode.copyChildren(index, newSize - 1, this, index + 1);
/*     */     } 
/* 193 */     return newNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static AbstractDataTreeNode[] forwardDeltaWith(AbstractDataTreeNode[] oldNodes, AbstractDataTreeNode[] newNodes, IComparator comparer) {
/* 202 */     if (oldNodes.length == 0 && newNodes.length == 0) {
/* 203 */       return NO_CHILDREN;
/*     */     }
/*     */     
/* 206 */     AbstractDataTreeNode[] childDeltas = null;
/* 207 */     int numChildDeltas = 0;
/* 208 */     int childDeltaMax = 0;
/*     */ 
/*     */     
/* 211 */     int oldIndex = 0;
/* 212 */     int newIndex = 0;
/* 213 */     while (oldIndex < oldNodes.length && newIndex < newNodes.length) {
/* 214 */       String oldName = (oldNodes[oldIndex]).name;
/* 215 */       String newName = (newNodes[newIndex]).name;
/* 216 */       int compare = oldName.compareTo(newName);
/* 217 */       if (compare == 0) {
/* 218 */         AbstractDataTreeNode deltaNode = forwardDeltaWithOrNullIfEqual(oldNodes[oldIndex++], newNodes[newIndex++], comparer);
/* 219 */         if (deltaNode != null) {
/* 220 */           if (numChildDeltas >= childDeltaMax)
/* 221 */             if (childDeltas == null) {
/* 222 */               childDeltas = new AbstractDataTreeNode[childDeltaMax = 5];
/*     */             } else {
/* 224 */               System.arraycopy(childDeltas, 0, childDeltas = new AbstractDataTreeNode[childDeltaMax = childDeltaMax * 2 + 1], 0, numChildDeltas);
/*     */             }  
/* 226 */           childDeltas[numChildDeltas++] = deltaNode;
/*     */         }  continue;
/* 228 */       }  if (compare < 0) {
/* 229 */         if (numChildDeltas >= childDeltaMax)
/* 230 */           if (childDeltas == null) {
/* 231 */             childDeltas = new AbstractDataTreeNode[childDeltaMax = 5];
/*     */           } else {
/* 233 */             System.arraycopy(childDeltas, 0, childDeltas = new AbstractDataTreeNode[childDeltaMax = childDeltaMax * 2 + 1], 0, numChildDeltas);
/*     */           }  
/* 235 */         childDeltas[numChildDeltas++] = new DeletedNode(oldName);
/* 236 */         oldIndex++; continue;
/*     */       } 
/* 238 */       if (numChildDeltas >= childDeltaMax)
/* 239 */         if (childDeltas == null) {
/* 240 */           childDeltas = new AbstractDataTreeNode[childDeltaMax = 5];
/*     */         } else {
/* 242 */           System.arraycopy(childDeltas, 0, childDeltas = new AbstractDataTreeNode[childDeltaMax = childDeltaMax * 2 + 1], 0, numChildDeltas);
/*     */         }  
/* 244 */       childDeltas[numChildDeltas++] = newNodes[newIndex++];
/*     */     } 
/*     */     
/* 247 */     while (oldIndex < oldNodes.length) {
/* 248 */       if (numChildDeltas >= childDeltaMax)
/* 249 */         if (childDeltas == null) {
/* 250 */           childDeltas = new AbstractDataTreeNode[childDeltaMax = 5];
/*     */         } else {
/* 252 */           System.arraycopy(childDeltas, 0, childDeltas = new AbstractDataTreeNode[childDeltaMax = childDeltaMax * 2 + 1], 0, numChildDeltas);
/*     */         }  
/* 254 */       childDeltas[numChildDeltas++] = new DeletedNode((oldNodes[oldIndex++]).name);
/*     */     } 
/* 256 */     while (newIndex < newNodes.length) {
/* 257 */       if (numChildDeltas >= childDeltaMax)
/* 258 */         if (childDeltas == null) {
/* 259 */           childDeltas = new AbstractDataTreeNode[childDeltaMax = 5];
/*     */         } else {
/* 261 */           System.arraycopy(childDeltas, 0, childDeltas = new AbstractDataTreeNode[childDeltaMax = childDeltaMax * 2 + 1], 0, numChildDeltas);
/*     */         }  
/* 263 */       childDeltas[numChildDeltas++] = newNodes[newIndex++];
/*     */     } 
/*     */ 
/*     */     
/* 267 */     if (numChildDeltas == 0) {
/* 268 */       return NO_CHILDREN;
/*     */     }
/* 270 */     if (numChildDeltas < childDeltaMax) {
/* 271 */       System.arraycopy(childDeltas, 0, childDeltas = new AbstractDataTreeNode[numChildDeltas], 0, numChildDeltas);
/*     */     }
/* 273 */     return childDeltas;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractDataTreeNode forwardDeltaWith(DataTreeNode other, IComparator comparer) {
/* 281 */     AbstractDataTreeNode deltaNode = forwardDeltaWithOrNullIfEqual(this, other, comparer);
/* 282 */     if (deltaNode == null) {
/* 283 */       return new NoDataDeltaNode(this.name, NO_CHILDREN);
/*     */     }
/* 285 */     return deltaNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static AbstractDataTreeNode forwardDeltaWithOrNullIfEqual(AbstractDataTreeNode oldNode, AbstractDataTreeNode newNode, IComparator comparer) {
/* 294 */     AbstractDataTreeNode[] childDeltas = forwardDeltaWith(oldNode.children, newNode.children, comparer);
/* 295 */     Object newData = newNode.getData();
/* 296 */     if (comparer.compare(oldNode.getData(), newData) == 0) {
/* 297 */       if (childDeltas.length == 0) {
/* 298 */         return null;
/*     */       }
/* 300 */       return new NoDataDeltaNode(newNode.name, childDeltas);
/*     */     } 
/* 302 */     return new DataDeltaNode(newNode.name, newData, childDeltas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getData() {
/* 310 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasData() {
/* 318 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setData(Object o) {
/* 325 */     this.data = o;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode simplifyWithParent(IPath key, DeltaDataTree parent, IComparator comparer) {
/* 334 */     if (!parent.includes(key)) {
/* 335 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 340 */     DataTreeNode parentsNode = (DataTreeNode)parent.copyCompleteSubtree(key);
/* 341 */     return parentsNode.forwardDeltaWith(this, comparer);
/*     */   }
/*     */ 
/*     */   
/*     */   public void storeStrings(StringPool set) {
/* 346 */     super.storeStrings(set);
/*     */     
/* 348 */     Object o = this.data;
/* 349 */     if (o instanceof IStringPoolParticipant) {
/* 350 */       ((IStringPoolParticipant)o).shareStrings(set);
/*     */     }
/*     */   }
/*     */   
/*     */   int type() {
/* 355 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\dtree\DataTreeNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */