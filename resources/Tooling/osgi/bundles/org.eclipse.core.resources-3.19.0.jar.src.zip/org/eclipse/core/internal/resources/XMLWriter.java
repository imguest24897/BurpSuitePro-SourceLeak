/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLWriter
/*     */   extends PrintWriter
/*     */ {
/*     */   protected int tab;
/*     */   protected String lineSeparator;
/*     */   protected static final String XML_VERSION = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
/*     */   
/*     */   public XMLWriter(OutputStream output, String separator) {
/*  33 */     super(new OutputStreamWriter(output, StandardCharsets.UTF_8));
/*  34 */     this.tab = 0;
/*  35 */     this.lineSeparator = separator;
/*  36 */     println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
/*     */   }
/*     */   
/*     */   public void endTag(String name) {
/*  40 */     this.tab--;
/*  41 */     printTag(String.valueOf('/') + name, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void println(String x) {
/*  46 */     print(x);
/*  47 */     print(this.lineSeparator);
/*     */   }
/*     */   
/*     */   public void printSimpleTag(String name, Object value) {
/*  51 */     if (value != null) {
/*  52 */       printTag(name, null, true, false);
/*  53 */       print(getEscaped(String.valueOf(value)));
/*  54 */       printTag(String.valueOf('/') + name, (HashMap<String, Object>)null, false, true);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void printTabulation() {
/*  59 */     for (int i = 0; i < this.tab; i++)
/*  60 */       print('\t'); 
/*     */   }
/*     */   
/*     */   public void printTag(String name, HashMap<String, Object> parameters) {
/*  64 */     printTag(name, parameters, true, true);
/*     */   }
/*     */   
/*     */   public void printTag(String name, HashMap<String, Object> parameters, boolean shouldTab, boolean newLine) {
/*  68 */     StringBuilder sb = new StringBuilder();
/*  69 */     sb.append("<");
/*  70 */     sb.append(name);
/*  71 */     if (parameters != null)
/*  72 */       for (Map.Entry<String, Object> entry : parameters.entrySet()) {
/*  73 */         sb.append(" ");
/*  74 */         String key = entry.getKey();
/*  75 */         sb.append(key);
/*  76 */         sb.append("=\"");
/*  77 */         sb.append(getEscaped(String.valueOf(entry.getValue())));
/*  78 */         sb.append("\"");
/*     */       }  
/*  80 */     sb.append(">");
/*  81 */     if (shouldTab)
/*  82 */       printTabulation(); 
/*  83 */     if (newLine) {
/*  84 */       println(sb.toString());
/*     */     } else {
/*  86 */       print(sb.toString());
/*     */     } 
/*     */   }
/*     */   public void startTag(String name, HashMap<String, Object> parameters) {
/*  90 */     startTag(name, parameters, true);
/*     */   }
/*     */   
/*     */   public void startTag(String name, HashMap<String, Object> parameters, boolean newLine) {
/*  94 */     printTag(name, parameters, true, newLine);
/*  95 */     this.tab++;
/*     */   }
/*     */   
/*     */   private static void appendEscapedChar(StringBuilder buffer, char c) {
/*  99 */     String replacement = getReplacement(c);
/* 100 */     if (replacement != null) {
/* 101 */       buffer.append('&');
/* 102 */       buffer.append(replacement);
/* 103 */       buffer.append(';');
/*     */     } else {
/* 105 */       buffer.append(c);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String getEscaped(String s) {
/* 110 */     StringBuilder result = new StringBuilder(s.length() + 10);
/* 111 */     for (int i = 0; i < s.length(); i++)
/* 112 */       appendEscapedChar(result, s.charAt(i)); 
/* 113 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getReplacement(char c) {
/* 119 */     switch (c) {
/*     */       case '<':
/* 121 */         return "lt";
/*     */       case '>':
/* 123 */         return "gt";
/*     */       case '"':
/* 125 */         return "quot";
/*     */       case '\'':
/* 127 */         return "apos";
/*     */       case '&':
/* 129 */         return "amp";
/*     */     } 
/* 131 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\XMLWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */