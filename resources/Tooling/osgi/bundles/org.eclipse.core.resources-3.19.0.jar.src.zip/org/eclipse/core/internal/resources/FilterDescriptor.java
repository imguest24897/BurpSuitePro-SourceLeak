/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import org.eclipse.core.internal.utils.Policy;
/*    */ import org.eclipse.core.resources.IFilterMatcherDescriptor;
/*    */ import org.eclipse.core.resources.filtermatchers.AbstractFileInfoMatcher;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilterDescriptor
/*    */   implements IFilterMatcherDescriptor
/*    */ {
/*    */   private String id;
/*    */   private String name;
/*    */   private String description;
/*    */   private String argumentType;
/*    */   private boolean isFirst = false;
/*    */   private IConfigurationElement element;
/*    */   
/*    */   public FilterDescriptor(IConfigurationElement element) {
/* 31 */     this(element, true);
/*    */   }
/*    */   
/*    */   public FilterDescriptor(IConfigurationElement element, boolean instantiateFactory) {
/* 35 */     this.id = element.getAttribute("id");
/* 36 */     this.name = element.getAttribute("name");
/* 37 */     this.description = element.getAttribute("description");
/* 38 */     this.argumentType = element.getAttribute("argumentType");
/* 39 */     if (this.argumentType == null)
/* 40 */       this.argumentType = "none"; 
/* 41 */     this.element = element;
/* 42 */     String ordering = element.getAttribute("ordering");
/* 43 */     if (ordering != null) {
/* 44 */       this.isFirst = ordering.equals("first");
/*    */     }
/*    */   }
/*    */   
/*    */   public String getId() {
/* 49 */     return this.id;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 54 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 59 */     return this.description;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getArgumentType() {
/* 64 */     return this.argumentType;
/*    */   }
/*    */   
/*    */   public AbstractFileInfoMatcher createFilter() {
/*    */     try {
/* 69 */       return (AbstractFileInfoMatcher)this.element.createExecutableExtension("class");
/* 70 */     } catch (CoreException e) {
/* 71 */       Policy.log((Throwable)e);
/* 72 */       return null;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isFirstOrdering() {
/* 78 */     return this.isFirst;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\FilterDescriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */