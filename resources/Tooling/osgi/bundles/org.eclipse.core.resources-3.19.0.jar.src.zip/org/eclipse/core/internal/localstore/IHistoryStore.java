package org.eclipse.core.internal.localstore;

import java.io.InputStream;
import java.util.Set;
import org.eclipse.core.filesystem.IFileInfo;
import org.eclipse.core.filesystem.IFileStore;
import org.eclipse.core.internal.resources.IManager;
import org.eclipse.core.resources.IFileState;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IHistoryStore extends IManager {
  IFileState addState(IPath paramIPath, IFileStore paramIFileStore, IFileInfo paramIFileInfo, boolean paramBoolean);
  
  Set<IPath> allFiles(IPath paramIPath, int paramInt, IProgressMonitor paramIProgressMonitor);
  
  void clean(IProgressMonitor paramIProgressMonitor);
  
  void closeHistoryStore(IResource paramIResource);
  
  void copyHistory(IResource paramIResource1, IResource paramIResource2, boolean paramBoolean);
  
  boolean exists(IFileState paramIFileState);
  
  InputStream getContents(IFileState paramIFileState) throws CoreException;
  
  IFileState[] getStates(IPath paramIPath, IProgressMonitor paramIProgressMonitor);
  
  void remove(IPath paramIPath, IProgressMonitor paramIProgressMonitor);
  
  void removeGarbage();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\IHistoryStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */