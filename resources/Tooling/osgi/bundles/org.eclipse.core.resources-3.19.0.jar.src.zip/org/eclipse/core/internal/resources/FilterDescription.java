/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import org.eclipse.core.resources.FileInfoMatcherDescription;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceFilterDescription;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilterDescription
/*     */   implements IResourceFilterDescription, Comparable<FilterDescription>
/*     */ {
/*     */   private long id;
/*     */   private int type;
/*     */   private FileInfoMatcherDescription matcherDescription;
/*     */   private IResource resource;
/*     */   
/*     */   public FilterDescription() {
/*  43 */     this.type = -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public FilterDescription(IResource resource, int type, FileInfoMatcherDescription matcherDescription) {
/*  48 */     Assert.isNotNull(resource);
/*  49 */     this.type = type;
/*  50 */     this.matcherDescription = matcherDescription;
/*  51 */     this.resource = resource;
/*     */   }
/*     */   
/*     */   public boolean isInheritable() {
/*  55 */     return ((getType() & 0x10) != 0);
/*     */   }
/*     */   
/*     */   public static LinkedList<FilterDescription> copy(LinkedList<FilterDescription> originalDescriptions, IResource resource) {
/*  59 */     LinkedList<FilterDescription> copy = new LinkedList<>();
/*  60 */     for (FilterDescription desc : originalDescriptions) {
/*  61 */       FilterDescription newDesc = new FilterDescription(resource, desc.getType(), desc.getFileInfoMatcherDescription());
/*  62 */       copy.add(newDesc);
/*     */     } 
/*  64 */     return copy;
/*     */   }
/*     */   
/*     */   public long getId() {
/*  68 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(long id) {
/*  72 */     this.id = id;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getType() {
/*  77 */     return this.type;
/*     */   }
/*     */   
/*     */   public void setType(int type) {
/*  81 */     this.type = type;
/*     */   }
/*     */   
/*     */   public void setResource(IResource resource) {
/*  85 */     this.resource = resource;
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource getResource() {
/*  90 */     return this.resource;
/*     */   }
/*     */ 
/*     */   
/*     */   public FileInfoMatcherDescription getFileInfoMatcherDescription() {
/*  95 */     return this.matcherDescription;
/*     */   }
/*     */   
/*     */   public void setFileInfoMatcherDescription(FileInfoMatcherDescription matcherDescription) {
/*  99 */     this.matcherDescription = matcherDescription;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 104 */     return Long.hashCode(this.id);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 109 */     if (this == obj)
/* 110 */       return true; 
/* 111 */     if (obj == null)
/* 112 */       return false; 
/* 113 */     if (getClass() != obj.getClass())
/* 114 */       return false; 
/* 115 */     FilterDescription other = (FilterDescription)obj;
/* 116 */     if (this.id != other.id)
/* 117 */       return false; 
/* 118 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(FilterDescription that) {
/* 126 */     IPath path1 = getResource().getProjectRelativePath();
/* 127 */     IPath path2 = that.getResource().getProjectRelativePath();
/* 128 */     int count1 = path1.segmentCount();
/* 129 */     int compare = count1 - path2.segmentCount();
/* 130 */     if (compare != 0)
/* 131 */       return compare; 
/* 132 */     for (int i = 0; i < count1; i++) {
/* 133 */       compare = path1.segment(i).compareTo(path2.segment(i));
/* 134 */       if (compare != 0)
/* 135 */         return compare; 
/*     */     } 
/* 137 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void delete(int updateFlags, IProgressMonitor monitor) throws CoreException {
/* 142 */     ((Container)getResource()).removeFilter(this, updateFlags, monitor);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\FilterDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */