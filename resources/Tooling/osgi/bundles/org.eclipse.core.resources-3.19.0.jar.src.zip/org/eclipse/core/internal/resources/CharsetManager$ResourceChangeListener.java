/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceChangeEvent;
/*     */ import org.eclipse.core.resources.IResourceChangeListener;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResourceChangeListener
/*     */   implements IResourceChangeListener
/*     */ {
/*     */   private boolean moveSettingsIfDerivedChanged(IResourceDelta parent, IProject currentProject, Preferences projectPrefs, String[] affectedResources) {
/* 135 */     boolean resourceChanges = false;
/*     */     
/* 137 */     if ((parent.getFlags() & 0x400000) != 0) {
/*     */       
/* 139 */       IPath parentPath = parent.getResource().getProjectRelativePath(); byte b1; int j; String[] arrayOfString;
/* 140 */       for (j = (arrayOfString = affectedResources).length, b1 = 0; b1 < j; ) { String affectedResource = arrayOfString[b1];
/* 141 */         Path path = new Path(affectedResource);
/*     */         
/* 143 */         if (parentPath.isPrefixOf((IPath)path)) {
/* 144 */           IResource member = currentProject.findMember((IPath)path);
/* 145 */           if (member != null) {
/* 146 */             Preferences targetPrefs = CharsetManager.this.getPreferences(currentProject, true, member.isDerived(512));
/*     */             
/* 148 */             if (!projectPrefs.absolutePath().equals(targetPrefs.absolutePath())) {
/*     */               
/* 150 */               String currentValue = projectPrefs.get(affectedResource, null);
/* 151 */               projectPrefs.remove(affectedResource);
/* 152 */               targetPrefs.put(affectedResource, currentValue);
/* 153 */               resourceChanges = true;
/*     */             } 
/*     */           } 
/*     */         }  b1++; }
/*     */     
/*     */     }  byte b; int i;
/*     */     IResourceDelta[] arrayOfIResourceDelta;
/* 160 */     for (i = (arrayOfIResourceDelta = parent.getAffectedChildren()).length, b = 0; b < i; ) { IResourceDelta child = arrayOfIResourceDelta[b];
/* 161 */       resourceChanges = !(!moveSettingsIfDerivedChanged(child, currentProject, projectPrefs, affectedResources) && !resourceChanges); b++; }
/*     */     
/* 163 */     return resourceChanges;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void processEntryChanges(IResourceDelta projectDelta, Map<IProject, Boolean> projectsToSave) {
/* 169 */     IProject currentProject = (IProject)projectDelta.getResource();
/* 170 */     Preferences projectRegularPrefs = CharsetManager.this.getPreferences(currentProject, false, false, true);
/* 171 */     Preferences projectDerivedPrefs = CharsetManager.this.getPreferences(currentProject, false, true, true);
/* 172 */     Map<Boolean, String[]> affectedResourcesMap = (Map)new HashMap<>();
/*     */     
/*     */     try {
/* 175 */       if (projectRegularPrefs == null) {
/* 176 */         affectedResourcesMap.put(Boolean.FALSE, new String[0]);
/*     */       } else {
/* 178 */         affectedResourcesMap.put(Boolean.FALSE, projectRegularPrefs.keys());
/*     */       } 
/* 180 */       if (projectDerivedPrefs == null)
/* 181 */       { affectedResourcesMap.put(Boolean.TRUE, new String[0]); }
/*     */       else
/* 183 */       { affectedResourcesMap.put(Boolean.TRUE, projectDerivedPrefs.keys()); } 
/* 184 */     } catch (BackingStoreException e) {
/*     */       
/* 186 */       String message = Messages.resources_readingEncoding;
/* 187 */       Policy.log((IStatus)new ResourceStatus(383, currentProject.getFullPath(), message, (Throwable)e));
/*     */       return;
/*     */     } 
/* 190 */     for (Map.Entry<Boolean, String[]> entry : affectedResourcesMap.entrySet()) {
/* 191 */       Boolean isDerived = entry.getKey();
/* 192 */       String[] affectedResources = entry.getValue();
/* 193 */       Preferences projectPrefs = isDerived.booleanValue() ? projectDerivedPrefs : projectRegularPrefs; byte b; int i; String[] arrayOfString1;
/* 194 */       for (i = (arrayOfString1 = affectedResources).length, b = 0; b < i; ) { String affectedResource = arrayOfString1[b];
/* 195 */         IResourceDelta memberDelta = projectDelta.findMember((IPath)new Path(affectedResource));
/*     */         
/* 197 */         if (memberDelta != null)
/*     */         {
/* 199 */           if (memberDelta.getKind() == 2) {
/* 200 */             boolean shouldDisableCharsetDeltaJobForCurrentProject = false;
/*     */             
/* 202 */             String currentValue = projectPrefs.get(affectedResource, null);
/* 203 */             projectPrefs.remove(affectedResource);
/* 204 */             if ((memberDelta.getFlags() & 0x2000) != 0) {
/* 205 */               IPath movedToPath = memberDelta.getMovedToPath();
/* 206 */               IResource resource = CharsetManager.this.workspace.getRoot().findMember(movedToPath);
/* 207 */               if (resource != null) {
/* 208 */                 Preferences encodingSettings = CharsetManager.this.getPreferences(resource.getProject(), true, resource.isDerived(512));
/* 209 */                 if (currentValue == null || currentValue.trim().length() == 0) {
/* 210 */                   encodingSettings.remove(CharsetManager.getKeyFor(movedToPath));
/*     */                 } else {
/* 212 */                   encodingSettings.put(CharsetManager.getKeyFor(movedToPath), currentValue);
/* 213 */                 }  IProject targetProject = CharsetManager.this.workspace.getRoot().getProject(movedToPath.segment(0));
/* 214 */                 if (targetProject.equals(currentProject)) {
/*     */                   
/* 216 */                   shouldDisableCharsetDeltaJobForCurrentProject = true;
/*     */                 } else {
/* 218 */                   projectsToSave.put(targetProject, Boolean.FALSE);
/*     */                 } 
/*     */               } 
/* 221 */             }  projectsToSave.put(currentProject, Boolean.valueOf(shouldDisableCharsetDeltaJobForCurrentProject));
/*     */           }  }  b++; }
/*     */       
/* 224 */       if (moveSettingsIfDerivedChanged(projectDelta, currentProject, projectPrefs, affectedResources))
/*     */       {
/* 226 */         projectsToSave.put(currentProject, Boolean.TRUE);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resourceChanged(IResourceChangeEvent event) {
/* 237 */     IResourceDelta delta = event.getDelta();
/* 238 */     if (delta == null)
/*     */       return; 
/* 240 */     IResourceDelta[] projectDeltas = delta.getAffectedChildren();
/*     */     
/* 242 */     Map<IProject, Boolean> projectsToSave = new HashMap<>(); byte b; int i; IResourceDelta[] arrayOfIResourceDelta1;
/* 243 */     for (i = (arrayOfIResourceDelta1 = projectDeltas).length, b = 0; b < i; ) { IResourceDelta projectDelta = arrayOfIResourceDelta1[b];
/*     */       
/* 245 */       if (projectDelta.getKind() == 4 && (projectDelta.getFlags() & 0x4000) == 0)
/* 246 */         processEntryChanges(projectDelta, projectsToSave);  b++; }
/* 247 */      CharsetManager.this.job.addChanges(projectsToSave);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\CharsetManager$ResourceChangeListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */