package org.eclipse.core.resources;

public interface IWorkspaceDescription {
  String[] getBuildOrder();
  
  long getFileStateLongevity();
  
  int getMaxBuildIterations();
  
  int getMaxFileStates();
  
  long getMaxFileStateSize();
  
  boolean isKeepDerivedState();
  
  boolean isApplyFileStatePolicy();
  
  long getSnapshotInterval();
  
  boolean isAutoBuilding();
  
  void setAutoBuilding(boolean paramBoolean);
  
  void setBuildOrder(String[] paramArrayOfString);
  
  void setFileStateLongevity(long paramLong);
  
  void setMaxBuildIterations(int paramInt);
  
  void setMaxFileStates(int paramInt);
  
  void setMaxFileStateSize(long paramLong);
  
  void setKeepDerivedState(boolean paramBoolean);
  
  void setApplyFileStatePolicy(boolean paramBoolean);
  
  void setSnapshotInterval(long paramLong);
  
  void setMaxConcurrentBuilds(int paramInt);
  
  int getMaxConcurrentBuilds();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IWorkspaceDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */