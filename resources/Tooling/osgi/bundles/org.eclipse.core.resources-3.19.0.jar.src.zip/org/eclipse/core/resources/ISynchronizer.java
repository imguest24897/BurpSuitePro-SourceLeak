package org.eclipse.core.resources;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.QualifiedName;

public interface ISynchronizer {
  void accept(QualifiedName paramQualifiedName, IResource paramIResource, IResourceVisitor paramIResourceVisitor, int paramInt) throws CoreException;
  
  void add(QualifiedName paramQualifiedName);
  
  void flushSyncInfo(QualifiedName paramQualifiedName, IResource paramIResource, int paramInt) throws CoreException;
  
  QualifiedName[] getPartners();
  
  byte[] getSyncInfo(QualifiedName paramQualifiedName, IResource paramIResource) throws CoreException;
  
  void remove(QualifiedName paramQualifiedName);
  
  void setSyncInfo(QualifiedName paramQualifiedName, IResource paramIResource, byte[] paramArrayOfbyte) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\ISynchronizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */