/*      */ package org.eclipse.core.internal.resources;
/*      */ 
/*      */ import java.net.URI;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.TreeSet;
/*      */ import org.eclipse.core.filesystem.EFS;
/*      */ import org.eclipse.core.filesystem.IFileInfo;
/*      */ import org.eclipse.core.filesystem.IFileStore;
/*      */ import org.eclipse.core.filesystem.URIUtil;
/*      */ import org.eclipse.core.internal.events.LifecycleEvent;
/*      */ import org.eclipse.core.internal.utils.FileUtil;
/*      */ import org.eclipse.core.internal.utils.Messages;
/*      */ import org.eclipse.core.internal.utils.Policy;
/*      */ import org.eclipse.core.resources.IBuildConfiguration;
/*      */ import org.eclipse.core.resources.IContainer;
/*      */ import org.eclipse.core.resources.IFile;
/*      */ import org.eclipse.core.resources.IProject;
/*      */ import org.eclipse.core.resources.IProjectDescription;
/*      */ import org.eclipse.core.resources.IProjectNature;
/*      */ import org.eclipse.core.resources.IResource;
/*      */ import org.eclipse.core.resources.IWorkspaceRoot;
/*      */ import org.eclipse.core.resources.ResourcesPlugin;
/*      */ import org.eclipse.core.resources.team.IMoveDeleteHook;
/*      */ import org.eclipse.core.runtime.Assert;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.ICoreRunnable;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.MultiStatus;
/*      */ import org.eclipse.core.runtime.OperationCanceledException;
/*      */ import org.eclipse.core.runtime.Path;
/*      */ import org.eclipse.core.runtime.Platform;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.core.runtime.SubMonitor;
/*      */ import org.eclipse.core.runtime.content.IContentTypeMatcher;
/*      */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*      */ import org.eclipse.core.runtime.jobs.Job;
/*      */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ import org.osgi.service.prefs.BackingStoreException;
/*      */ import org.osgi.service.prefs.Preferences;
/*      */ 
/*      */ public class Project
/*      */   extends Container
/*      */   implements IProject
/*      */ {
/*      */   public static final int SNAPSHOT_SET_AUTOLOAD = 2;
/*      */   
/*      */   protected Project(IPath path, Workspace container) {
/*   57 */     super(path, container);
/*      */   }
/*      */   
/*      */   protected void assertCreateRequirements(IProjectDescription description) throws CoreException {
/*   61 */     checkDoesNotExist();
/*   62 */     checkDescription(this, description, false);
/*   63 */     URI location = description.getLocationURI();
/*   64 */     if (location != null) {
/*      */       return;
/*      */     }
/*   67 */     if (!Workspace.caseSensitive) {
/*   68 */       IFileStore store = getStore();
/*   69 */       IFileInfo localInfo = store.fetchInfo();
/*   70 */       if (localInfo.exists()) {
/*   71 */         String name = getLocalManager().getLocalName(store);
/*   72 */         if (name != null && !store.getName().equals(name)) {
/*   73 */           String msg = NLS.bind(Messages.resources_existsLocalDifferentCase, (new Path(store.toString())).removeLastSegments(1).append(name).toOSString());
/*   74 */           throw new ResourceException(275, getFullPath(), msg, null);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MultiStatus basicSetDescription(ProjectDescription description, int updateFlags) {
/*   86 */     String message = Messages.resources_projectDesc;
/*   87 */     MultiStatus result = new MultiStatus("org.eclipse.core.resources", 568, message, null);
/*   88 */     ProjectDescription current = internalGetDescription();
/*   89 */     current.setComment(description.getComment());
/*   90 */     current.setSnapshotLocationURI(description.getSnapshotLocationURI());
/*      */ 
/*      */     
/*   93 */     current.setBuildSpec(description.getBuildSpec(true));
/*      */ 
/*      */     
/*   96 */     boolean flushOrder = false;
/*   97 */     IProject[] oldReferences = current.getReferencedProjects();
/*   98 */     IProject[] newReferences = description.getReferencedProjects();
/*   99 */     if (!Arrays.equals((Object[])oldReferences, (Object[])newReferences)) {
/*  100 */       current.setReferencedProjects(newReferences);
/*  101 */       flushOrder = true;
/*      */     } 
/*      */     
/*  104 */     flushOrder |= current.updateDynamicState(description);
/*      */     
/*  106 */     if (flushOrder) {
/*  107 */       this.workspace.flushBuildOrder();
/*      */     }
/*      */     
/*  110 */     if ((updateFlags & 0x40) == 0) {
/*  111 */       this.workspace.getNatureManager().configureNatures(this, current, description, result);
/*      */     } else {
/*  113 */       current.setNatureIds(description.getNatureIds(false));
/*  114 */     }  return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public void build(int trigger, IProgressMonitor monitor) throws CoreException {
/*  119 */     if (!isAccessible())
/*      */       return; 
/*  121 */     internalBuild(getActiveBuildConfig(), trigger, (String)null, (Map<String, String>)null, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void build(int trigger, String builderName, Map<String, String> args, IProgressMonitor monitor) throws CoreException {
/*  126 */     Assert.isNotNull(builderName);
/*  127 */     if (!isAccessible())
/*      */       return; 
/*  129 */     internalBuild(getActiveBuildConfig(), trigger, builderName, args, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void build(IBuildConfiguration config, int trigger, IProgressMonitor monitor) throws CoreException {
/*  134 */     Assert.isNotNull(config);
/*      */     
/*  136 */     if (!isAccessible() || !hasBuildConfig(config.getName()))
/*      */       return; 
/*  138 */     internalBuild(config, trigger, (String)null, (Map<String, String>)null, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkAccessible(int flags) throws CoreException {
/*  150 */     super.checkAccessible(flags);
/*  151 */     if (!isOpen(flags)) {
/*  152 */       String message = NLS.bind(Messages.resources_mustBeOpen, getName());
/*  153 */       throw new ResourceException(372, getFullPath(), message, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkDescription(IProject project, IProjectDescription desc, boolean moving) throws CoreException {
/*  161 */     URI location = desc.getLocationURI();
/*  162 */     String message = Messages.resources_invalidProjDesc;
/*  163 */     MultiStatus status = new MultiStatus("org.eclipse.core.resources", 77, message, null);
/*  164 */     status.merge(this.workspace.validateName(desc.getName(), 4));
/*  165 */     if (moving) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  171 */       URI sourceLocation = internalGetDescription().getLocationURI();
/*  172 */       if (sourceLocation == null || !sourceLocation.equals(location)) {
/*  173 */         status.merge(this.workspace.validateProjectLocationURI(project, location));
/*      */       }
/*      */     } else {
/*  176 */       status.merge(this.workspace.validateProjectLocationURI(project, location));
/*  177 */     }  if (!status.isOK()) {
/*  178 */       throw new ResourceException(status);
/*      */     }
/*      */   }
/*      */   
/*      */   public void close(IProgressMonitor monitor) throws CoreException {
/*  183 */     String msg = NLS.bind(Messages.resources_closing_1, getName());
/*  184 */     SubMonitor subMonitor = SubMonitor.convert(monitor, msg, 100);
/*  185 */     ISchedulingRule rule = this.workspace.getRuleFactory().modifyRule(this);
/*  186 */     SubMonitor newChild = subMonitor.newChild(1);
/*      */     try {
/*  188 */       this.workspace.prepareOperation(rule, (IProgressMonitor)newChild);
/*  189 */       ResourceInfo info = getResourceInfo(false, false);
/*  190 */       int flags = getFlags(info);
/*  191 */       checkExists(flags, true);
/*  192 */       subMonitor.subTask(msg);
/*  193 */       if (!isOpen(flags)) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/*  198 */       this.workspace.beginOperation(true);
/*  199 */       this.workspace.broadcastEvent(LifecycleEvent.newEvent(1, this));
/*      */       
/*  201 */       this.workspace.flushBuildOrder();
/*  202 */       SubMonitor subMonitor1 = subMonitor.newChild(49, 1);
/*  203 */       IStatus saveStatus = this.workspace.getSaveManager().save(3, this, (IProgressMonitor)subMonitor1);
/*  204 */       internalClose((IProgressMonitor)subMonitor.newChild(49));
/*  205 */       if (saveStatus != null && !saveStatus.isOK())
/*  206 */         throw new ResourceException(saveStatus); 
/*  207 */     } catch (OperationCanceledException e) {
/*  208 */       this.workspace.getWorkManager().operationCanceled();
/*  209 */       throw e;
/*      */     } finally {
/*  211 */       subMonitor.done();
/*  212 */       this.workspace.endOperation(rule, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copy(IPath destination, int updateFlags, IProgressMonitor monitor) throws CoreException {
/*  221 */     monitor = Policy.monitorFor(monitor);
/*  222 */     if (destination.segmentCount() == 1) {
/*      */       
/*  224 */       String projectName = destination.segment(0);
/*  225 */       IProjectDescription desc = getDescription();
/*  226 */       desc.setName(projectName);
/*  227 */       desc.setLocation(null);
/*  228 */       ((ProjectDescription)desc).setSnapshotLocationURI(null);
/*  229 */       internalCopy(desc, updateFlags, monitor);
/*      */     } else {
/*      */       
/*  232 */       checkCopyRequirements(destination, 4, updateFlags);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copy(IProjectDescription destination, int updateFlags, IProgressMonitor monitor) throws CoreException {
/*  241 */     Assert.isNotNull(destination);
/*  242 */     internalCopy(destination, updateFlags, monitor);
/*      */   }
/*      */   
/*      */   protected void copyMetaArea(IProject source, IProject destination, IProgressMonitor monitor) throws CoreException {
/*  246 */     IFileStore oldMetaArea = EFS.getFileSystem("file").getStore(this.workspace.getMetaArea().locationFor((IResource)source));
/*  247 */     IFileStore newMetaArea = EFS.getFileSystem("file").getStore(this.workspace.getMetaArea().locationFor((IResource)destination));
/*  248 */     oldMetaArea.copy(newMetaArea, 0, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void create(IProgressMonitor monitor) throws CoreException {
/*  253 */     create((IProjectDescription)null, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void create(IProjectDescription description, IProgressMonitor monitor) throws CoreException {
/*  258 */     create(description, 0, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void create(IProjectDescription description, int updateFlags, IProgressMonitor monitor) throws CoreException {
/*  263 */     SubMonitor subMonitor = SubMonitor.convert(monitor, Messages.resources_create, 100);
/*  264 */     checkValidPath(this.path, 4, false);
/*  265 */     ISchedulingRule rule = this.workspace.getRuleFactory().createRule(this);
/*      */     try {
/*  267 */       this.workspace.prepareOperation(rule, (IProgressMonitor)subMonitor);
/*  268 */       if (description == null) {
/*  269 */         description = new ProjectDescription();
/*  270 */         description.setName(getName());
/*      */       } 
/*  272 */       assertCreateRequirements(description);
/*  273 */       this.workspace.broadcastEvent(LifecycleEvent.newEvent(8, this));
/*  274 */       this.workspace.beginOperation(true);
/*  275 */       this.workspace.createResource(this, updateFlags);
/*  276 */       this.workspace.getMetaArea().create(this);
/*  277 */       ProjectInfo info = (ProjectInfo)getResourceInfo(false, true);
/*      */ 
/*      */       
/*  280 */       ProjectDescription desc = (ProjectDescription)((ProjectDescription)description).clone();
/*  281 */       desc.setLocationURI(FileUtil.canonicalURI(description.getLocationURI()));
/*  282 */       desc.setName(getName());
/*  283 */       internalSetDescription(desc, false);
/*      */       
/*  285 */       boolean hasSavedDescription = getLocalManager().hasSavedDescription(this);
/*  286 */       boolean hasContent = hasSavedDescription;
/*      */       
/*  288 */       if (!hasSavedDescription) {
/*  289 */         hasContent = getLocalManager().hasSavedContent(this);
/*      */       }
/*      */       try {
/*  292 */         if (hasSavedDescription) {
/*  293 */           updateDescription();
/*      */           
/*  295 */           this.workspace.getMetaArea().writePrivateDescription(this);
/*      */         } else {
/*      */           
/*  298 */           writeDescription(1);
/*      */         } 
/*  300 */       } catch (CoreException e) {
/*  301 */         this.workspace.deleteResource(this);
/*  302 */         throw e;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  307 */       info.clearModificationStamp();
/*      */ 
/*      */       
/*  310 */       if (hasContent)
/*  311 */         info.set(1048576); 
/*  312 */       this.workspace.getSaveManager().requestSnapshot();
/*  313 */     } catch (OperationCanceledException e) {
/*  314 */       this.workspace.getWorkManager().operationCanceled();
/*  315 */       throw e;
/*      */     } finally {
/*  317 */       subMonitor.done();
/*  318 */       this.workspace.endOperation(rule, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void delete(boolean deleteContent, boolean force, IProgressMonitor monitor) throws CoreException {
/*  324 */     int updateFlags = force ? 1 : 0;
/*  325 */     updateFlags |= deleteContent ? 4 : 8;
/*  326 */     delete(updateFlags, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void delete(boolean force, IProgressMonitor monitor) throws CoreException {
/*  331 */     int updateFlags = force ? 1 : 0;
/*  332 */     delete(updateFlags, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void deleteResource(boolean convertToPhantom, MultiStatus status) throws CoreException {
/*  337 */     super.deleteResource(convertToPhantom, status);
/*      */     
/*  339 */     clearHistory(null);
/*      */     
/*  341 */     this.workspace.getMetaArea().delete(this);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void fixupAfterMoveSource() throws CoreException {
/*  346 */     this.workspace.deleteResource(this);
/*      */     
/*  348 */     ProjectPreferences.deleted(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public IBuildConfiguration getActiveBuildConfig() throws CoreException {
/*  353 */     ResourceInfo info = getResourceInfo(false, false);
/*  354 */     int flags = getFlags(info);
/*  355 */     checkAccessible(flags);
/*  356 */     return internalGetActiveBuildConfig();
/*      */   }
/*      */ 
/*      */   
/*      */   public IBuildConfiguration getBuildConfig(String configName) throws CoreException {
/*  361 */     if (configName == null)
/*  362 */       return getActiveBuildConfig(); 
/*  363 */     ProjectInfo info = (ProjectInfo)getResourceInfo(false, false);
/*  364 */     checkAccessible(getFlags(info));
/*  365 */     IBuildConfiguration[] configs = internalGetBuildConfigs(false); byte b; int i; IBuildConfiguration[] arrayOfIBuildConfiguration1;
/*  366 */     for (i = (arrayOfIBuildConfiguration1 = configs).length, b = 0; b < i; ) { IBuildConfiguration config = arrayOfIBuildConfiguration1[b];
/*  367 */       if (config.getName().equals(configName))
/*  368 */         return config; 
/*      */       b++; }
/*      */     
/*  371 */     throw new ResourceException(384, getFullPath(), null, null);
/*      */   }
/*      */ 
/*      */   
/*      */   public IBuildConfiguration[] getBuildConfigs() throws CoreException {
/*  376 */     ProjectInfo info = (ProjectInfo)getResourceInfo(false, false);
/*  377 */     checkAccessible(getFlags(info));
/*  378 */     return internalGetBuildConfigs(true);
/*      */   }
/*      */ 
/*      */   
/*      */   public IContentTypeMatcher getContentTypeMatcher() throws CoreException {
/*  383 */     return this.workspace.getContentDescriptionManager().getContentTypeMatcher(this);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDefaultCharset(boolean checkImplicit) {
/*  389 */     if (!exists())
/*  390 */       return checkImplicit ? ResourcesPlugin.getEncoding() : null; 
/*  391 */     return this.workspace.getCharsetManager().getCharsetFor(getFullPath(), checkImplicit);
/*      */   }
/*      */ 
/*      */   
/*      */   public IProjectDescription getDescription() throws CoreException {
/*  396 */     ResourceInfo info = getResourceInfo(false, false);
/*  397 */     checkAccessible(getFlags(info));
/*  398 */     ProjectDescription description = ((ProjectInfo)info).getDescription();
/*      */     
/*  400 */     if (description == null)
/*  401 */       checkAccessible(-1); 
/*  402 */     return (IProjectDescription)description.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public IProjectNature getNature(String natureID) throws CoreException {
/*  408 */     ProjectInfo info = (ProjectInfo)getResourceInfo(false, false);
/*  409 */     checkAccessible(getFlags(info));
/*  410 */     IProjectNature nature = info.getNature(natureID);
/*  411 */     if (nature == null) {
/*      */       
/*  413 */       if (!hasNature(natureID))
/*  414 */         return null; 
/*  415 */       nature = this.workspace.getNatureManager().createNature(this, natureID);
/*  416 */       info.setNature(natureID, nature);
/*      */     } 
/*  418 */     return nature;
/*      */   }
/*      */ 
/*      */   
/*      */   public IContainer getParent() {
/*  423 */     return (IContainer)this.workspace.getRoot();
/*      */   }
/*      */ 
/*      */   
/*      */   public IProject getProject() {
/*  428 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public IPath getProjectRelativePath() {
/*  433 */     return (IPath)Path.EMPTY;
/*      */   }
/*      */ 
/*      */   
/*      */   public IPath getRawLocation() {
/*  438 */     ProjectDescription description = internalGetDescription();
/*  439 */     return (description == null) ? null : description.getLocation();
/*      */   }
/*      */ 
/*      */   
/*      */   public URI getRawLocationURI() {
/*  444 */     ProjectDescription description = internalGetDescription();
/*  445 */     return (description == null) ? null : description.getLocationURI();
/*      */   }
/*      */ 
/*      */   
/*      */   public IBuildConfiguration[] getReferencedBuildConfigs(String configName, boolean includeMissing) throws CoreException {
/*  450 */     ResourceInfo info = getResourceInfo(false, false);
/*  451 */     checkAccessible(getFlags(info));
/*  452 */     ProjectDescription description = ((ProjectInfo)info).getDescription();
/*      */     
/*  454 */     if (description == null)
/*  455 */       checkAccessible(-1); 
/*  456 */     if (!hasBuildConfig(configName))
/*  457 */       throw new ResourceException(384, getFullPath(), null, null); 
/*  458 */     return internalGetReferencedBuildConfigs(configName, includeMissing);
/*      */   }
/*      */ 
/*      */   
/*      */   public IProject[] getReferencedProjects() throws CoreException {
/*  463 */     ResourceInfo info = getResourceInfo(false, false);
/*  464 */     checkAccessible(getFlags(info));
/*  465 */     ProjectDescription description = ((ProjectInfo)info).getDescription();
/*      */     
/*  467 */     if (description == null)
/*  468 */       checkAccessible(-1); 
/*  469 */     return description.getAllReferences(this, true);
/*      */   }
/*      */ 
/*      */   
/*      */   public void clearCachedDynamicReferences() {
/*  474 */     ResourceInfo info = getResourceInfo(false, false);
/*  475 */     if (info == null) {
/*      */       return;
/*      */     }
/*      */     
/*  479 */     ProjectDescription description = ((ProjectInfo)info).getDescription();
/*  480 */     if (description == null) {
/*      */       return;
/*      */     }
/*      */     
/*  484 */     description.clearCachedDynamicReferences(null);
/*      */   }
/*      */ 
/*      */   
/*      */   public IProject[] getReferencingProjects() {
/*  489 */     IProject[] projects = this.workspace.getRoot().getProjects(8);
/*  490 */     List<IProject> result = new ArrayList<>(projects.length); byte b; int i; IProject[] arrayOfIProject1;
/*  491 */     for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject p = arrayOfIProject1[b];
/*  492 */       Project project = (Project)p;
/*  493 */       if (project.isAccessible()) {
/*      */         
/*  495 */         ProjectDescription description = project.internalGetDescription();
/*  496 */         if (description != null) {
/*      */           
/*  498 */           IProject[] references = description.getAllReferences(project, false); byte b1; int j; IProject[] arrayOfIProject2;
/*  499 */           for (j = (arrayOfIProject2 = references).length, b1 = 0; b1 < j; ) { IProject reference = arrayOfIProject2[b1];
/*  500 */             if (reference.equals(this))
/*  501 */             { result.add(project); break; }  b1++; }
/*      */         
/*      */         } 
/*      */       }  b++; }
/*  505 */      return result.<IProject>toArray(new IProject[result.size()]);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getType() {
/*  510 */     return 4;
/*      */   }
/*      */ 
/*      */   
/*      */   public IPath getWorkingLocation(String id) {
/*  515 */     if (id == null || !exists())
/*  516 */       return null; 
/*  517 */     IPath result = this.workspace.getMetaArea().getWorkingLocation(this, id);
/*  518 */     result.toFile().mkdirs();
/*  519 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasBuildConfig(String configName) throws CoreException {
/*  524 */     ProjectInfo info = (ProjectInfo)getResourceInfo(false, false);
/*  525 */     checkAccessible(getFlags(info));
/*  526 */     return internalHasBuildConfig(configName);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasNature(String natureID) throws CoreException {
/*  531 */     checkAccessible(getFlags(getResourceInfo(false, false)));
/*      */ 
/*      */     
/*  534 */     IProjectDescription desc = internalGetDescription();
/*  535 */     if (desc == null)
/*  536 */       checkAccessible(-1); 
/*  537 */     return desc.hasNature(natureID);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void internalBuild(final IBuildConfiguration config, final int trigger, final String builderName, final Map<String, String> args, IProgressMonitor monitor) throws CoreException {
/*  544 */     ICoreRunnable buildRunnable = new ICoreRunnable()
/*      */       {
/*      */         public void run(IProgressMonitor innerMonitor) throws CoreException
/*      */         {
/*  548 */           ISchedulingRule projectBuildRule = Project.this.workspace.getBuildManager().getRule(config, trigger, 
/*  549 */               builderName, args);
/*  550 */           boolean relaxed = (Job.getJobManager().currentRule() == null && Project.this.workspace.isRelaxedRule(projectBuildRule));
/*      */ 
/*      */ 
/*      */           
/*  554 */           IWorkspaceRoot iWorkspaceRoot = relaxed ? null : Project.this.workspace.getRoot();
/*  555 */           SubMonitor subMonitor = SubMonitor.convert(innerMonitor, 100);
/*      */           try {
/*      */             try {
/*  558 */               Project.this.workspace.prepareOperation((ISchedulingRule)iWorkspaceRoot, innerMonitor);
/*  559 */               if (!shouldBuild())
/*      */                 return; 
/*  561 */               Project.this.workspace.beginOperation(true);
/*  562 */               Project.this.workspace.aboutToBuild(Project.this, trigger);
/*      */             } finally {
/*  564 */               Project.this.workspace.endOperation((ISchedulingRule)iWorkspaceRoot, false);
/*      */             } 
/*      */             
/*      */             try {
/*  568 */               Project.this.workspace.prepareOperation(projectBuildRule, innerMonitor);
/*      */               
/*  570 */               Project.this.workspace.beginOperation(false);
/*  571 */               IStatus result = Project.this.workspace.getBuildManager().build(config, trigger, builderName, args, 
/*  572 */                   (IProgressMonitor)subMonitor.split(100));
/*  573 */               if (!result.isOK())
/*  574 */                 throw new ResourceException(result); 
/*      */             } finally {
/*  576 */               Project.this.workspace.endOperation(projectBuildRule, false);
/*      */               try {
/*  578 */                 Project.this.workspace.prepareOperation((ISchedulingRule)iWorkspaceRoot, innerMonitor);
/*      */                 
/*  580 */                 Project.this.workspace.beginOperation(false);
/*  581 */                 Project.this.workspace.broadcastBuildEvent(Project.this, 16, trigger);
/*      */                 
/*  583 */                 if (Project.this.workspace.getElementTree().isImmutable())
/*  584 */                   Project.this.workspace.newWorkingTree(); 
/*      */               } finally {
/*  586 */                 Project.this.workspace.endOperation((ISchedulingRule)iWorkspaceRoot, false);
/*      */               } 
/*      */             } 
/*      */           } finally {
/*  590 */             subMonitor.done();
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private boolean shouldBuild() {
/*  599 */           ResourceInfo info = Project.this.getResourceInfo(false, false);
/*  600 */           int flags = Project.this.getFlags(info);
/*  601 */           if (!Project.this.exists(flags, true) || !Project.this.isOpen(flags)) {
/*  602 */             return false;
/*      */           }
/*  604 */           return true;
/*      */         }
/*      */       };
/*      */ 
/*      */     
/*  609 */     this.workspace.run(buildRunnable, (ISchedulingRule)null, 1, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void internalClose(IProgressMonitor monitor) throws CoreException {
/*  618 */     SubMonitor subMonitor = SubMonitor.convert(monitor, 2);
/*  619 */     this.workspace.flushBuildOrder();
/*  620 */     getMarkerManager().removeMarkers(this, 2);
/*  621 */     subMonitor.worked(1);
/*      */ 
/*      */     
/*  624 */     IResource[] members = members(11);
/*  625 */     subMonitor.setWorkRemaining(members.length); byte b; int i; IResource[] arrayOfIResource1;
/*  626 */     for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource member2 = arrayOfIResource1[b];
/*  627 */       Resource member = (Resource)member2;
/*  628 */       this.workspace.deleteResource(member);
/*  629 */       subMonitor.worked(1);
/*      */       b++; }
/*      */     
/*  632 */     ResourceInfo info = getResourceInfo(false, true);
/*  633 */     info.clear(1);
/*  634 */     info.clearSessionProperties();
/*  635 */     info.clearModificationStamp();
/*  636 */     info.clearCharsetGenerationCount();
/*  637 */     info.setSyncInfo(null);
/*      */   }
/*      */   
/*      */   protected void internalCopy(IProjectDescription destDesc, int updateFlags, IProgressMonitor monitor) throws CoreException {
/*  641 */     monitor = Policy.monitorFor(monitor);
/*      */     try {
/*  643 */       String message = NLS.bind(Messages.resources_copying, getFullPath());
/*  644 */       monitor.beginTask(message, 100);
/*  645 */       String destName = destDesc.getName();
/*  646 */       IPath destPath = (new Path(destName)).makeAbsolute();
/*  647 */       Project destination = (Project)this.workspace.getRoot().getProject(destName);
/*  648 */       ISchedulingRule rule = this.workspace.getRuleFactory().copyRule(this, destination);
/*      */       try {
/*  650 */         this.workspace.prepareOperation(rule, monitor);
/*      */ 
/*      */         
/*  653 */         assertCopyRequirements(destPath, 4, updateFlags);
/*  654 */         checkDescription(destination, destDesc, false);
/*  655 */         this.workspace.broadcastEvent(LifecycleEvent.newEvent(4, this, destination, updateFlags));
/*      */         
/*  657 */         this.workspace.beginOperation(true);
/*  658 */         getLocalManager().refresh(this, 2, true, Policy.subMonitorFor(monitor, Policy.opWork * 20 / 100));
/*      */ 
/*      */         
/*  661 */         getPropertyManager().closePropertyStore(this);
/*  662 */         getLocalManager().getHistoryStore().closeHistoryStore(this);
/*      */ 
/*      */         
/*  665 */         copyMetaArea(this, destination, Policy.subMonitorFor(monitor, Policy.opWork * 5 / 100));
/*      */ 
/*      */         
/*  668 */         internalCopyProjectOnly(destination, destDesc, Policy.subMonitorFor(monitor, Policy.opWork * 5 / 100));
/*      */ 
/*      */         
/*  671 */         destination.internalSetDescription(destDesc, false);
/*      */ 
/*      */         
/*  674 */         destination.getStore().mkdir(0, Policy.subMonitorFor(monitor, Policy.opWork * 5 / 100));
/*      */ 
/*      */ 
/*      */         
/*  678 */         message = Messages.resources_copyProblem;
/*  679 */         MultiStatus problems = new MultiStatus("org.eclipse.core.resources", 566, message, null);
/*      */         
/*  681 */         IResource[] children = members(10);
/*  682 */         int childCount = children.length;
/*  683 */         int childWork = (childCount > 1) ? (Policy.opWork * 50 / 100 / (childCount - 1)) : 0;
/*  684 */         for (int i = 0; i < childCount; i++) {
/*  685 */           IResource child = children[i];
/*  686 */           if (!isProjectDescriptionFile(child)) {
/*      */             try {
/*  688 */               child.copy(destPath.append(child.getName()), updateFlags, Policy.subMonitorFor(monitor, childWork));
/*  689 */             } catch (CoreException e) {
/*  690 */               problems.merge(e.getStatus());
/*      */             } 
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*      */         try {
/*  697 */           destination.writeDescription(1);
/*  698 */         } catch (CoreException e) {
/*      */           try {
/*  700 */             destination.delete(((updateFlags & 0x1) != 0), (IProgressMonitor)null);
/*  701 */           } catch (CoreException coreException) {}
/*      */ 
/*      */           
/*  704 */           throw e;
/*      */         } 
/*  706 */         monitor.worked(Policy.opWork * 5 / 100);
/*      */ 
/*      */         
/*  709 */         monitor.subTask(Messages.resources_updating);
/*  710 */         getLocalManager().refresh(destination, 2, true, Policy.subMonitorFor(monitor, Policy.opWork * 10 / 100));
/*  711 */         if (!problems.isOK())
/*  712 */           throw new ResourceException(problems); 
/*  713 */       } catch (OperationCanceledException e) {
/*  714 */         this.workspace.getWorkManager().operationCanceled();
/*  715 */         throw e;
/*      */       } finally {
/*  717 */         this.workspace.endOperation(rule, true);
/*      */       } 
/*      */     } finally {
/*  720 */       monitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void internalCopyProjectOnly(IResource destination, IProjectDescription destDesc, IProgressMonitor monitor) throws CoreException {
/*  729 */     getPropertyManager().closePropertyStore(this);
/*  730 */     getLocalManager().getHistoryStore().closeHistoryStore(this);
/*      */     
/*  732 */     this.workspace.copyTree(this, destination.getFullPath(), 0, 0, false);
/*  733 */     getPropertyManager().copy(this, destination, 0);
/*      */     
/*  735 */     ProjectInfo info = (ProjectInfo)((Resource)destination).getResourceInfo(false, true);
/*      */ 
/*      */     
/*  738 */     ProjectDescription projectDesc = (ProjectDescription)destDesc;
/*  739 */     ProjectDescription internalDesc = ((Project)destination.getProject()).internalGetDescription();
/*  740 */     projectDesc.setLinkDescriptions(internalDesc.getLinks());
/*  741 */     projectDesc.setFilterDescriptions(internalDesc.getFilters());
/*  742 */     projectDesc.setVariableDescriptions(internalDesc.getVariables());
/*      */ 
/*      */     
/*  745 */     info.description = null;
/*  746 */     info.natures = null;
/*  747 */     info.setMarkers(null);
/*  748 */     info.clearSessionProperties();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   IBuildConfiguration internalGetActiveBuildConfig() {
/*  757 */     String configName = (internalGetDescription()).activeConfiguration;
/*      */     try {
/*  759 */       if (configName != null)
/*  760 */         return getBuildConfig(configName); 
/*  761 */     } catch (CoreException coreException) {}
/*      */ 
/*      */     
/*  764 */     return internalGetBuildConfigs(false)[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IBuildConfiguration[] internalGetBuildConfigs(boolean makeCopy) {
/*  771 */     ProjectDescription desc = internalGetDescription();
/*  772 */     if (desc == null)
/*  773 */       return new IBuildConfiguration[] { new BuildConfiguration(this, "") }; 
/*  774 */     return desc.getBuildConfigs(this, makeCopy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ProjectDescription internalGetDescription() {
/*  784 */     ProjectInfo info = (ProjectInfo)getResourceInfo(false, false);
/*  785 */     if (info == null)
/*  786 */       return null; 
/*  787 */     return info.getDescription();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IBuildConfiguration[] internalGetReferencedBuildConfigs(String configName, boolean includeMissing) {
/*  796 */     ProjectDescription description = internalGetDescription();
/*  797 */     IBuildConfiguration[] refs = description.getAllBuildConfigReferences(this, configName, false);
/*  798 */     Collection<IBuildConfiguration> configs = new LinkedHashSet<>(refs.length); byte b; int i; IBuildConfiguration[] arrayOfIBuildConfiguration1;
/*  799 */     for (i = (arrayOfIBuildConfiguration1 = refs).length, b = 0; b < i; ) { IBuildConfiguration ref = arrayOfIBuildConfiguration1[b];
/*      */       try {
/*  801 */         configs.add(((BuildConfiguration)ref).getBuildConfig());
/*  802 */       } catch (CoreException coreException) {
/*      */ 
/*      */ 
/*      */         
/*  806 */         if (includeMissing)
/*  807 */           configs.add(ref); 
/*      */       }  b++; }
/*      */     
/*  810 */     return configs.<IBuildConfiguration>toArray(new IBuildConfiguration[configs.size()]);
/*      */   }
/*      */   
/*      */   boolean internalHasBuildConfig(String configName) {
/*  814 */     return internalGetDescription().hasBuildConfig(configName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void internalSetDescription(IProjectDescription value, boolean incrementContentId) {
/*  824 */     this.workspace.flushBuildOrder();
/*      */     
/*  826 */     ProjectInfo info = (ProjectInfo)getResourceInfo(false, true);
/*  827 */     info.setDescription((ProjectDescription)value);
/*  828 */     getLocalManager().setLocation(this, info, value.getLocationURI());
/*  829 */     if (incrementContentId) {
/*  830 */       info.incrementContentId();
/*      */       
/*  832 */       if (info.getModificationStamp() != -1L) {
/*  833 */         this.workspace.updateModificationStamp(info);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void internalSetLocal(boolean flag, int depth) throws CoreException {
/*  840 */     if (depth == 0)
/*      */       return; 
/*  842 */     if (depth == 1) {
/*  843 */       depth = 0;
/*      */     }
/*      */     
/*  846 */     IResource[] children = getChildren(0); byte b; int i; IResource[] arrayOfIResource1;
/*  847 */     for (i = (arrayOfIResource1 = children).length, b = 0; b < i; ) { IResource element = arrayOfIResource1[b];
/*  848 */       ((Resource)element).internalSetLocal(flag, depth);
/*      */       b++; }
/*      */   
/*      */   }
/*      */   public boolean isAccessible() {
/*  853 */     return isOpen();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDerived(int options) {
/*  859 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isLinked(int options) {
/*  864 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isVirtual() {
/*  869 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTeamPrivateMember(int options) {
/*  874 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean isLocal(int depth) {
/*  881 */     return isLocal(-1, depth);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean isLocal(int flags, int depth) {
/*  888 */     if (depth == 0)
/*  889 */       return true; 
/*  890 */     if (depth == 1) {
/*  891 */       depth = 0;
/*      */     }
/*      */     
/*  894 */     IResource[] children = getChildren(0); byte b; int i; IResource[] arrayOfIResource1;
/*  895 */     for (i = (arrayOfIResource1 = children).length, b = 0; b < i; ) { IResource element = arrayOfIResource1[b];
/*  896 */       if (!element.isLocal(depth))
/*  897 */         return false;  b++; }
/*  898 */      return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isNatureEnabled(String natureId) throws CoreException {
/*  903 */     checkAccessible(getFlags(getResourceInfo(false, false)));
/*  904 */     return this.workspace.getNatureManager().isNatureEnabled(this, natureId);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isOpen() {
/*  909 */     ResourceInfo info = getResourceInfo(false, false);
/*  910 */     return isOpen(getFlags(info));
/*      */   }
/*      */   
/*      */   public boolean isOpen(int flags) {
/*  914 */     return (flags != -1 && ResourceInfo.isSet(flags, 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isProjectDescriptionFile(IResource resource) {
/*  922 */     return (resource.getType() == 1 && resource.getFullPath().segmentCount() == 2 && resource.getName().equals(".project"));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadSnapshot(int options, URI snapshotLocation, IProgressMonitor monitor) throws CoreException {
/*  928 */     if (isOpen()) {
/*  929 */       String message = Messages.resources_projectMustNotBeOpen;
/*  930 */       MultiStatus status = new MultiStatus("org.eclipse.core.resources", 4, message, null);
/*  931 */       throw new CoreException(status);
/*      */     } 
/*  933 */     internalLoadSnapshot(options, snapshotLocation, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void internalLoadSnapshot(int options, URI snapshotLocation, IProgressMonitor monitor) throws CoreException {
/*  944 */     if ((options & 0x1) != 0) {
/*      */       
/*  946 */       snapshotLocation = this.workspace.getPathVariableManager().resolveURI(snapshotLocation);
/*  947 */       if (!snapshotLocation.isAbsolute()) {
/*  948 */         String message = NLS.bind(Messages.projRead_badSnapshotLocation, snapshotLocation.toString());
/*  949 */         throw new CoreException(new Status(2, "org.eclipse.core.resources", message, null));
/*      */       } 
/*      */       
/*  952 */       IPath snapshotPath = this.workspace.getMetaArea().getRefreshLocationFor(this);
/*  953 */       IFileStore snapshotFileStore = EFS.getStore(URIUtil.toURI(snapshotPath));
/*  954 */       EFS.getStore(snapshotLocation).copy(snapshotFileStore, 2, monitor);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void move(IProjectDescription destination, boolean force, IProgressMonitor monitor) throws CoreException {
/*  960 */     Assert.isNotNull(destination);
/*  961 */     move(destination, force ? 1 : 0, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void move(IProjectDescription description, int updateFlags, IProgressMonitor monitor) throws CoreException {
/*  966 */     Assert.isNotNull(description);
/*  967 */     monitor = Policy.monitorFor(monitor);
/*      */     try {
/*  969 */       String message = NLS.bind(Messages.resources_moving, getFullPath());
/*  970 */       monitor.beginTask(message, 100);
/*  971 */       IProject destination = this.workspace.getRoot().getProject(description.getName());
/*  972 */       ISchedulingRule rule = this.workspace.getRuleFactory().moveRule(this, (IResource)destination);
/*      */       try {
/*  974 */         this.workspace.prepareOperation(rule, monitor);
/*      */ 
/*      */         
/*  977 */         if (!getName().equals(description.getName())) {
/*  978 */           IPath destPath = Path.ROOT.append(description.getName());
/*  979 */           assertMoveRequirements(destPath, 4, updateFlags);
/*      */         } 
/*  981 */         checkDescription(destination, description, true);
/*  982 */         this.workspace.beginOperation(true);
/*  983 */         message = Messages.resources_moveProblem;
/*  984 */         MultiStatus status = new MultiStatus("org.eclipse.core.resources", 4, message, null);
/*  985 */         WorkManager workManager = this.workspace.getWorkManager();
/*  986 */         ResourceTree tree = new ResourceTree(getLocalManager(), workManager.getLock(), status, updateFlags);
/*  987 */         IMoveDeleteHook hook = this.workspace.getMoveDeleteHook();
/*  988 */         this.workspace.broadcastEvent(LifecycleEvent.newEvent(64, this, (IResource)destination, updateFlags));
/*  989 */         int depth = 0;
/*      */         try {
/*  991 */           depth = workManager.beginUnprotected();
/*  992 */           if (!hook.moveProject(tree, this, description, updateFlags, Policy.subMonitorFor(monitor, Policy.opWork / 2)))
/*  993 */             tree.standardMoveProject(this, description, updateFlags, Policy.subMonitorFor(monitor, Policy.opWork / 2)); 
/*      */         } finally {
/*  995 */           workManager.endUnprotected(depth);
/*      */         } 
/*      */         
/*  998 */         tree.makeInvalid();
/*  999 */         if (!tree.getStatus().isOK()) {
/* 1000 */           throw new ResourceException(tree.getStatus());
/*      */         }
/* 1002 */         this.workspace.getSaveManager().requestSnapshot();
/* 1003 */       } catch (OperationCanceledException e) {
/* 1004 */         this.workspace.getWorkManager().operationCanceled();
/* 1005 */         throw e;
/*      */       } finally {
/* 1007 */         this.workspace.endOperation(rule, true);
/*      */       } 
/*      */     } finally {
/* 1010 */       monitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void open(int updateFlags, IProgressMonitor monitor) throws CoreException {
/* 1016 */     monitor = Policy.monitorFor(monitor);
/* 1017 */     boolean encodingWritten = false;
/*      */     try {
/* 1019 */       String msg = NLS.bind(Messages.resources_opening_1, getName());
/* 1020 */       monitor.beginTask(msg, 100);
/* 1021 */       monitor.subTask(msg);
/* 1022 */       ISchedulingRule rule = this.workspace.getRuleFactory().modifyRule(this);
/*      */       try {
/* 1024 */         this.workspace.prepareOperation(rule, monitor);
/* 1025 */         ProjectInfo info = (ProjectInfo)getResourceInfo(false, false);
/* 1026 */         int flags = getFlags(info);
/* 1027 */         checkExists(flags, true);
/* 1028 */         if (isOpen(flags)) {
/*      */           return;
/*      */         }
/* 1031 */         this.workspace.beginOperation(true);
/*      */         
/* 1033 */         this.workspace.flushBuildOrder();
/* 1034 */         info = (ProjectInfo)getResourceInfo(false, true);
/* 1035 */         info.set(1);
/*      */         
/* 1037 */         boolean unknownChildren = info.isSet(1048576);
/* 1038 */         if (unknownChildren) {
/* 1039 */           info.clear(1048576);
/*      */         }
/*      */         
/* 1042 */         boolean used = info.isSet(16);
/* 1043 */         boolean snapshotLoaded = false;
/* 1044 */         if (!used && !this.workspace.getMetaArea().getRefreshLocationFor(this).toFile().exists()) {
/*      */           
/* 1046 */           boolean hasSavedDescription = getLocalManager().hasSavedDescription(this);
/* 1047 */           if (hasSavedDescription) {
/* 1048 */             ProjectDescription updatedDesc = info.getDescription();
/* 1049 */             if (updatedDesc != null) {
/* 1050 */               URI autoloadURI = updatedDesc.getSnapshotLocationURI();
/* 1051 */               if (autoloadURI != null) {
/*      */                 try {
/* 1053 */                   autoloadURI = getPathVariableManager().resolveURI(autoloadURI);
/* 1054 */                   internalLoadSnapshot(1, autoloadURI, Policy.subMonitorFor(monitor, Policy.opWork * 5 / 100));
/* 1055 */                   snapshotLoaded = true;
/* 1056 */                 } catch (CoreException ce) {
/*      */                   
/* 1058 */                   String msgerr = NLS.bind(Messages.projRead_cannotReadSnapshot, getName(), ce.getLocalizedMessage());
/* 1059 */                   Policy.log((IStatus)new Status(2, "org.eclipse.core.resources", msgerr));
/*      */                 } 
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/* 1065 */         boolean minorIssuesDuringRestore = false;
/* 1066 */         if (used) {
/* 1067 */           minorIssuesDuringRestore = this.workspace.getSaveManager().restore(this, Policy.subMonitorFor(monitor, Policy.opWork * 20 / 100));
/*      */         } else {
/* 1069 */           info.set(16);
/*      */           
/* 1071 */           IStatus result = reconcileLinksAndGroups(info.getDescription());
/* 1072 */           if (!result.isOK())
/* 1073 */             throw new CoreException(result); 
/* 1074 */           this.workspace.updateModificationStamp(info);
/* 1075 */           monitor.worked(Policy.opWork * (snapshotLoaded ? 15 : 20) / 100);
/*      */         } 
/* 1077 */         startup();
/*      */ 
/*      */         
/* 1080 */         if ((!used && unknownChildren) || !minorIssuesDuringRestore) {
/* 1081 */           boolean refreshed = false;
/* 1082 */           if (!used) {
/* 1083 */             refreshed = this.workspace.getSaveManager().restoreFromRefreshSnapshot(this, Policy.subMonitorFor(monitor, Policy.opWork * 20 / 100));
/* 1084 */             if (refreshed) {
/* 1085 */               monitor.worked(Policy.opWork * 60 / 100);
/*      */             }
/*      */           } 
/*      */           
/* 1089 */           if (!refreshed) {
/* 1090 */             if ((updateFlags & 0x80) != 0) {
/* 1091 */               this.workspace.refreshManager.refresh(this);
/* 1092 */               monitor.worked(Policy.opWork * 60 / 100);
/*      */             } else {
/* 1094 */               refreshLocal(2, Policy.subMonitorFor(monitor, Policy.opWork * 60 / 100));
/*      */             }
/*      */           
/*      */           }
/*      */         }
/* 1099 */         else if ((updateFlags & 0x80) != 0) {
/* 1100 */           this.workspace.refreshManager.refresh(this);
/* 1101 */           monitor.worked(Policy.opWork * 60 / 100);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1106 */         if (!used && !unknownChildren) {
/* 1107 */           writeEncodingAfterOpen(monitor);
/* 1108 */           encodingWritten = true;
/*      */         } 
/*      */         
/* 1111 */         this.workspace.getAliasManager().updateAliases(this, getStore(), 2, monitor);
/* 1112 */       } catch (OperationCanceledException e) {
/* 1113 */         this.workspace.getWorkManager().operationCanceled();
/* 1114 */         throw e;
/*      */       } finally {
/* 1116 */         this.workspace.endOperation(rule, true);
/*      */       } 
/*      */     } finally {
/* 1119 */       monitor.done();
/*      */     } 
/* 1121 */     if (!encodingWritten) {
/* 1122 */       ValidateProjectEncoding.scheduleProjectValidation((Workspace)getWorkspace(), this);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeEncodingAfterOpen(IProgressMonitor monitor) throws CoreException {
/* 1130 */     IPath settings = (new Path(".settings")).append("org.eclipse.core.resources")
/* 1131 */       .addFileExtension("prefs");
/* 1132 */     IFile file = getFile(settings);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1137 */     IPath location = file.getLocation();
/* 1138 */     if (!file.exists() && location != null && location.toFile().exists()) {
/* 1139 */       file.refreshLocal(0, monitor);
/*      */     }
/* 1141 */     String charset = this.workspace.getCharsetManager().getCharsetFor(getFullPath(), false);
/* 1142 */     if (charset == null) {
/* 1143 */       String encoding = ResourcesPlugin.getEncoding();
/* 1144 */       this.workspace.getCharsetManager().setCharsetFor(getFullPath(), encoding);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void open(IProgressMonitor monitor) throws CoreException {
/* 1150 */     open(0, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IStatus reconcileLinksAndGroups(ProjectDescription newDescription) {
/* 1163 */     String msg = Messages.links_errorLinkReconcile;
/* 1164 */     HashMap<IPath, LinkDescription> newLinks = newDescription.getLinks();
/* 1165 */     MultiStatus status = new MultiStatus("org.eclipse.core.resources", 76, msg, null);
/*      */     
/* 1167 */     ProjectDescription oldDescription = internalGetDescription();
/* 1168 */     if (oldDescription != null) {
/* 1169 */       HashMap<IPath, LinkDescription> oldLinks = oldDescription.getLinks();
/* 1170 */       if (oldLinks != null) {
/* 1171 */         for (LinkDescription oldLink : oldLinks.values()) {
/* 1172 */           Resource oldLinkResource = (Resource)findMember(oldLink.getProjectRelativePath());
/* 1173 */           if (oldLinkResource == null || !oldLinkResource.isLinked())
/*      */             continue; 
/* 1175 */           LinkDescription newLink = null;
/* 1176 */           if (newLinks != null) {
/* 1177 */             newLink = newLinks.get(oldLink.getProjectRelativePath());
/*      */           }
/* 1179 */           if (newLink == null || !newLink.getLocationURI().equals(oldLinkResource.getRawLocationURI()) || newLink.getType() != oldLinkResource.getType()) {
/*      */             try {
/* 1181 */               oldLinkResource.delete(0, (IProgressMonitor)null);
/*      */               
/* 1183 */               oldLinkResource.refreshLocal(2, null);
/* 1184 */             } catch (CoreException e) {
/* 1185 */               status.merge(e.getStatus());
/*      */             } 
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1196 */     if (newLinks == null) {
/* 1197 */       return (IStatus)status;
/*      */     }
/* 1199 */     TreeSet<LinkDescription> newLinksAndGroups = new TreeSet<>((arg0, arg1) -> {
/*      */           int numberOfSegments0 = arg0.getProjectRelativePath().segmentCount();
/*      */ 
/*      */           
/*      */           int numberOfSegments1 = arg1.getProjectRelativePath().segmentCount();
/*      */ 
/*      */           
/*      */           return (numberOfSegments0 != numberOfSegments1) ? (numberOfSegments0 - numberOfSegments1) : (arg0.equals(arg1) ? 0 : -1);
/*      */         });
/*      */     
/* 1209 */     if (newLinks != null) {
/* 1210 */       newLinksAndGroups.addAll(newLinks.values());
/*      */     }
/* 1212 */     for (LinkDescription newLink : newLinksAndGroups) {
/*      */       try {
/* 1214 */         Resource toLink = this.workspace.newResource(getFullPath().append(newLink.getProjectRelativePath()), newLink.getType());
/* 1215 */         IContainer parent = toLink.getParent();
/* 1216 */         if (parent != null && !parent.exists() && parent.getType() == 2)
/* 1217 */           ((Folder)parent).ensureExists(Policy.monitorFor(null)); 
/* 1218 */         if (!toLink.exists() || !toLink.isLinked()) {
/* 1219 */           if (newLink.isGroup()) {
/* 1220 */             ((Folder)toLink).create(8448, true, (IProgressMonitor)null); continue;
/*      */           } 
/* 1222 */           toLink.createLink(newLink.getLocationURI(), 272, (IProgressMonitor)null);
/*      */         } 
/* 1224 */       } catch (CoreException e) {
/* 1225 */         status.merge(e.getStatus());
/*      */       } 
/*      */     } 
/* 1228 */     return (IStatus)status;
/*      */   }
/*      */ 
/*      */   
/*      */   public void saveSnapshot(int options, URI snapshotLocation, IProgressMonitor monitor) throws CoreException {
/* 1233 */     monitor = Policy.monitorFor(monitor);
/*      */     try {
/* 1235 */       monitor.beginTask("", 100);
/*      */       
/* 1237 */       checkAccessible(getFlags(getResourceInfo(false, false)));
/*      */       
/* 1239 */       URI resolvedSnapshotLocation = getPathVariableManager().resolveURI(snapshotLocation);
/* 1240 */       if (resolvedSnapshotLocation == null || !resolvedSnapshotLocation.isAbsolute()) {
/* 1241 */         String message = NLS.bind(Messages.projRead_badSnapshotLocation, resolvedSnapshotLocation);
/* 1242 */         throw new CoreException(new Status(4, "org.eclipse.core.resources", message, null));
/*      */       } 
/* 1244 */       if ((options & 0x1) != 0) {
/*      */         
/*      */         try {
/* 1247 */           IProgressMonitor sub = Policy.subMonitorFor(monitor, Policy.opWork / 2);
/* 1248 */           this.workspace.getSaveManager().saveRefreshSnapshot(this, resolvedSnapshotLocation, sub);
/* 1249 */         } catch (OperationCanceledException e) {
/*      */           
/* 1251 */           throw e;
/*      */         } 
/*      */       }
/* 1254 */       if ((options & 0x2) != 0) {
/* 1255 */         IProgressMonitor sub = Policy.subMonitorFor(monitor, Policy.opWork / 2);
/*      */         
/* 1257 */         if (snapshotLocation != null && snapshotLocation.isAbsolute()) {
/* 1258 */           snapshotLocation = getPathVariableManager().convertToRelative(snapshotLocation, false, "PROJECT_LOC");
/*      */         }
/* 1260 */         IProjectDescription desc = getDescription();
/* 1261 */         ((ProjectDescription)desc).setSnapshotLocationURI(snapshotLocation);
/* 1262 */         setDescription(desc, 66, sub);
/*      */       } 
/*      */     } finally {
/* 1265 */       monitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDescription(IProjectDescription description, int updateFlags, IProgressMonitor monitor) throws CoreException {
/* 1274 */     monitor = Policy.monitorFor(monitor); try {
/*      */       IWorkspaceRoot iWorkspaceRoot;
/* 1276 */       monitor.beginTask(Messages.resources_setDesc, 100);
/* 1277 */       ISchedulingRule rule = null;
/* 1278 */       if ((updateFlags & 0x40) != 0) {
/* 1279 */         rule = this.workspace.getRuleFactory().modifyRule(this);
/*      */       } else {
/* 1281 */         iWorkspaceRoot = this.workspace.getRoot();
/*      */       } 
/*      */       try {
/* 1284 */         this.workspace.prepareOperation((ISchedulingRule)iWorkspaceRoot, monitor);
/* 1285 */         ResourceInfo info = getResourceInfo(false, false);
/* 1286 */         checkAccessible(getFlags(info));
/*      */         
/* 1288 */         ProjectDescription oldDescription = internalGetDescription();
/* 1289 */         ProjectDescription newDescription = (ProjectDescription)description;
/* 1290 */         boolean hasPublicChanges = oldDescription.hasPublicChanges(newDescription);
/* 1291 */         boolean hasPrivateChanges = oldDescription.hasPrivateChanges(newDescription);
/* 1292 */         if (!hasPublicChanges && !hasPrivateChanges)
/*      */           return; 
/* 1294 */         checkDescription(this, newDescription, false);
/*      */ 
/*      */         
/* 1297 */         boolean hadSavedDescription = true;
/* 1298 */         if ((updateFlags & 0x1) == 0) {
/* 1299 */           hadSavedDescription = getLocalManager().hasSavedDescription(this);
/* 1300 */           if (hadSavedDescription && !getLocalManager().isDescriptionSynchronized(this)) {
/* 1301 */             String message = NLS.bind(Messages.resources_projectDescSync, getName());
/* 1302 */             throw new ResourceException(274, getFullPath(), message, null);
/*      */           } 
/*      */         } 
/*      */         
/* 1306 */         if (!hadSavedDescription)
/* 1307 */           hadSavedDescription = this.workspace.getMetaArea().hasSavedProject(this); 
/* 1308 */         this.workspace.beginOperation(true);
/* 1309 */         MultiStatus status = basicSetDescription(newDescription, updateFlags);
/* 1310 */         if (hadSavedDescription && !status.isOK()) {
/* 1311 */           throw new CoreException(status);
/*      */         }
/* 1313 */         writeDescription(oldDescription, updateFlags, hasPublicChanges, hasPrivateChanges);
/*      */         
/* 1315 */         info = getResourceInfo(false, true);
/* 1316 */         info.incrementContentId();
/* 1317 */         this.workspace.updateModificationStamp(info);
/* 1318 */         if (!hadSavedDescription) {
/* 1319 */           String msg = NLS.bind(Messages.resources_missingProjectMetaRepaired, getName());
/* 1320 */           status.merge((IStatus)new ResourceStatus(234, getFullPath(), msg));
/*      */         } 
/* 1322 */         if (!status.isOK())
/* 1323 */           throw new CoreException(status); 
/*      */       } finally {
/* 1325 */         this.workspace.broadcastEvent(LifecycleEvent.newEvent(2, this));
/* 1326 */         this.workspace.endOperation((ISchedulingRule)iWorkspaceRoot, true);
/*      */       } 
/*      */     } finally {
/* 1329 */       monitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDescription(IProjectDescription description, IProgressMonitor monitor) throws CoreException {
/* 1336 */     setDescription(description, 2, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void startup() throws CoreException {
/* 1346 */     if (!isOpen())
/*      */       return; 
/* 1348 */     this.workspace.broadcastEvent(LifecycleEvent.newEvent(32, this));
/*      */   }
/*      */ 
/*      */   
/*      */   public void touch(IProgressMonitor monitor) throws CoreException {
/* 1353 */     monitor = Policy.monitorFor(monitor);
/*      */     try {
/* 1355 */       String message = NLS.bind(Messages.resources_touch, getFullPath());
/* 1356 */       monitor.beginTask(message, 100);
/* 1357 */       ISchedulingRule rule = this.workspace.getRuleFactory().modifyRule(this);
/*      */       try {
/* 1359 */         this.workspace.prepareOperation(rule, monitor);
/* 1360 */         this.workspace.beginOperation(true);
/* 1361 */         super.touch(Policy.subMonitorFor(monitor, Policy.opWork));
/* 1362 */       } catch (OperationCanceledException e) {
/* 1363 */         this.workspace.getWorkManager().operationCanceled();
/* 1364 */         throw e;
/*      */       } finally {
/* 1366 */         this.workspace.broadcastEvent(LifecycleEvent.newEvent(2, this));
/* 1367 */         this.workspace.endOperation(rule, true);
/*      */       } 
/*      */     } finally {
/* 1370 */       monitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void updateDescription() throws CoreException {
/* 1380 */     if (ProjectDescription.isWriting)
/*      */       return; 
/* 1382 */     ProjectDescription.isReading = true;
/*      */     try {
/* 1384 */       ProjectDescription description = getLocalManager().read(this, false);
/*      */       
/* 1386 */       IStatus result = null;
/* 1387 */       if (isOpen())
/* 1388 */         result = reconcileLinksAndGroups(description); 
/* 1389 */       internalSetDescription(description, true);
/* 1390 */       if (result != null && !result.isOK())
/* 1391 */         throw new CoreException(result); 
/*      */     } finally {
/* 1393 */       this.workspace.broadcastEvent(LifecycleEvent.newEvent(2, this));
/* 1394 */       ProjectDescription.isReading = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeDescription(int updateFlags) throws CoreException {
/* 1402 */     writeDescription(internalGetDescription(), updateFlags, true, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeDescription(IProjectDescription description, int updateFlags, boolean hasPublicChanges, boolean hasPrivateChanges) throws CoreException {
/* 1417 */     if (ProjectDescription.isReading)
/*      */       return; 
/* 1419 */     ProjectDescription.isWriting = true;
/*      */     try {
/* 1421 */       getLocalManager().internalWrite(this, description, updateFlags, hasPublicChanges, hasPrivateChanges);
/*      */     } finally {
/* 1423 */       ProjectDescription.isWriting = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String getDefaultLineSeparator() {
/* 1429 */     IEclipsePreferences iEclipsePreferences = Platform.getPreferencesService().getRootNode();
/*      */     
/* 1431 */     String value = getLineSeparatorFromPreferences(iEclipsePreferences.node("project").node(getProject().getName()));
/* 1432 */     if (value != null) {
/* 1433 */       return value;
/*      */     }
/* 1435 */     value = getLineSeparatorFromPreferences(iEclipsePreferences.node("instance"));
/* 1436 */     if (value != null) {
/* 1437 */       return value;
/*      */     }
/* 1439 */     value = getLineSeparatorFromPreferences(iEclipsePreferences.node("default"));
/* 1440 */     if (value != null) {
/* 1441 */       return value;
/*      */     }
/* 1443 */     return System.lineSeparator();
/*      */   }
/*      */ 
/*      */   
/*      */   private static String getLineSeparatorFromPreferences(Preferences node) {
/*      */     try {
/* 1449 */       if (node.nodeExists("org.eclipse.core.runtime"))
/* 1450 */         return node.node("org.eclipse.core.runtime").get("line.separator", null); 
/* 1451 */     } catch (BackingStoreException backingStoreException) {}
/*      */ 
/*      */     
/* 1454 */     return null;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\Project.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */