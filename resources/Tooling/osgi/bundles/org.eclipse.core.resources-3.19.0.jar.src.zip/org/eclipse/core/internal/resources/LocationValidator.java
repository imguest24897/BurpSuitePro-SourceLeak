/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.net.URI;
/*     */ import org.eclipse.core.filesystem.EFS;
/*     */ import org.eclipse.core.filesystem.URIUtil;
/*     */ import org.eclipse.core.internal.utils.FileUtil;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IFolder;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IProjectDescription;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocationValidator
/*     */ {
/*     */   private final Workspace workspace;
/*     */   
/*     */   public LocationValidator(Workspace workspace) {
/*  34 */     this.workspace = workspace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String toString(URI uri) {
/*     */     try {
/*  42 */       return EFS.getStore(uri).toString();
/*  43 */     } catch (CoreException coreException) {
/*     */       
/*  45 */       return uri.toString();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IStatus validateAbsolute(URI location, boolean error) {
/*  53 */     if (!location.isAbsolute()) {
/*     */       
/*  55 */       String message, schemeSpecificPart = location.getSchemeSpecificPart();
/*  56 */       if (schemeSpecificPart == null || schemeSpecificPart.isEmpty()) {
/*  57 */         message = Messages.links_noPath;
/*     */       } else {
/*  59 */         Path path = new Path(schemeSpecificPart);
/*  60 */         if (path.segmentCount() > 0) {
/*  61 */           message = NLS.bind(Messages.pathvar_undefined, location.toString(), path.segment(0));
/*     */         } else {
/*  63 */           message = Messages.links_noPath;
/*     */         } 
/*  65 */       }  int code = error ? 379 : 333;
/*  66 */       return (IStatus)new ResourceStatus(code, null, message);
/*     */     } 
/*  68 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateLinkLocation(IResource resource, IPath unresolvedLocation) {
/*     */     Path path;
/*  75 */     IPath location = resource.getPathVariableManager().resolvePath(unresolvedLocation);
/*  76 */     if (location.isEmpty()) {
/*  77 */       return (IStatus)new ResourceStatus(77, resource.getFullPath(), Messages.links_noPath);
/*     */     }
/*  79 */     if (!location.isAbsolute()) {
/*     */       
/*  81 */       String message = NLS.bind(Messages.pathvar_undefined, location.toOSString(), location.segment(0));
/*  82 */       return (IStatus)new ResourceStatus(333, resource.getFullPath(), message);
/*     */     } 
/*     */     
/*  85 */     if (location.getDevice() == null)
/*  86 */       path = new Path(location.toFile().getAbsolutePath()); 
/*  87 */     return validateLinkLocationURI(resource, URIUtil.toURI((IPath)path));
/*     */   }
/*     */   
/*     */   public IStatus validateLinkLocationURI(IResource resource, URI unresolvedLocation) {
/*  91 */     String schemeSpecificPart = unresolvedLocation.getSchemeSpecificPart();
/*  92 */     if (schemeSpecificPart == null || schemeSpecificPart.isEmpty()) {
/*  93 */       return (IStatus)new ResourceStatus(77, resource.getFullPath(), Messages.links_noPath);
/*     */     }
/*     */ 
/*     */     
/*  97 */     if (ResourcesPlugin.getPlugin().getPluginPreferences().getBoolean("description.disableLinking")) {
/*  98 */       String message = NLS.bind(Messages.links_workspaceVeto, resource.getName());
/*  99 */       return (IStatus)new ResourceStatus(77, resource.getFullPath(), message);
/*     */     } 
/*     */     
/* 102 */     int type = resource.getType();
/* 103 */     if (type != 2 && type != 1) {
/* 104 */       String message = NLS.bind(Messages.links_notFileFolder, resource.getName());
/* 105 */       return (IStatus)new ResourceStatus(77, resource.getFullPath(), message);
/*     */     } 
/* 107 */     IContainer parent = resource.getParent();
/* 108 */     if (!parent.isAccessible()) {
/* 109 */       String message = NLS.bind(Messages.links_parentNotAccessible, resource.getFullPath());
/* 110 */       return (IStatus)new ResourceStatus(77, resource.getFullPath(), message);
/*     */     } 
/* 112 */     URI location = resource.getPathVariableManager().resolveURI(unresolvedLocation);
/*     */     
/* 114 */     String[] natureIds = ((Project)resource.getProject()).internalGetDescription().getNatureIds();
/*     */     
/* 116 */     IStatus result = this.workspace.getNatureManager().validateLinkCreation(natureIds);
/* 117 */     if (!result.isOK()) {
/* 118 */       return result;
/*     */     }
/* 120 */     if (resource.getType() == 1) {
/* 121 */       result = this.workspace.getTeamHook().validateCreateLink((IFile)resource, 0, location);
/*     */     } else {
/* 123 */       result = this.workspace.getTeamHook().validateCreateLink((IFolder)resource, 0, location);
/* 124 */     }  if (!result.isOK()) {
/* 125 */       return result;
/*     */     }
/* 127 */     result = validateSegments(location);
/* 128 */     if (!result.isOK()) {
/* 129 */       return result;
/*     */     }
/* 131 */     result = validateAbsolute(location, false);
/* 132 */     if (!result.isOK()) {
/* 133 */       return result;
/*     */     }
/* 135 */     URI testLocation = this.workspace.getMetaArea().getLocation().toFile().toURI();
/* 136 */     if (FileUtil.isOverlapping(location, testLocation)) {
/* 137 */       String message = NLS.bind(Messages.links_invalidLocation, toString(location));
/* 138 */       return (IStatus)new ResourceStatus(77, resource.getFullPath(), message);
/*     */     } 
/*     */     
/* 141 */     testLocation = resource.getProject().getLocationURI();
/* 142 */     if (testLocation != null && FileUtil.isPrefixOf(location, testLocation)) {
/* 143 */       String message = NLS.bind(Messages.links_locationOverlapsProject, toString(location));
/* 144 */       return (IStatus)new ResourceStatus(77, resource.getFullPath(), message);
/*     */     } 
/*     */     
/*     */     byte b;
/*     */     int i;
/*     */     IProject[] arrayOfIProject;
/* 150 */     for (i = (arrayOfIProject = this.workspace.getRoot().getProjects(8)).length, b = 0; b < i; ) { IProject project = arrayOfIProject[b];
/*     */ 
/*     */       
/* 153 */       IProjectDescription desc = ((Project)project).internalGetDescription();
/* 154 */       testLocation = desc.getLocationURI();
/* 155 */       if (testLocation != null && FileUtil.isOverlapping(location, testLocation)) {
/* 156 */         String message = NLS.bind(Messages.links_overlappingResource, toString(location));
/* 157 */         return (IStatus)new ResourceStatus(235, resource.getFullPath(), message);
/*     */       } 
/*     */       
/* 160 */       if (project.isOpen()) {
/*     */         
/* 162 */         IResource[] children = null;
/*     */         try {
/* 164 */           children = project.members();
/* 165 */         } catch (CoreException coreException) {}
/*     */ 
/*     */         
/* 168 */         if (children != null) {
/*     */           byte b1; int j; IResource[] arrayOfIResource;
/* 170 */           for (j = (arrayOfIResource = children).length, b1 = 0; b1 < j; ) { IResource child = arrayOfIResource[b1];
/* 171 */             if (child.isLinked()) {
/* 172 */               testLocation = child.getLocationURI();
/* 173 */               if (testLocation != null && FileUtil.isOverlapping(location, testLocation))
/* 174 */               { String message = NLS.bind(Messages.links_overlappingResource, toString(location));
/* 175 */                 return (IStatus)new ResourceStatus(235, resource.getFullPath(), message); } 
/*     */             }  b1++; }
/*     */         
/*     */         } 
/*     */       }  b++; }
/* 180 */      return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateName(String segment, int type) {
/* 190 */     if (segment == null) {
/* 191 */       String message = Messages.resources_nameNull;
/* 192 */       return (IStatus)new ResourceStatus(77, null, message);
/*     */     } 
/*     */ 
/*     */     
/* 196 */     if (segment.length() == 0) {
/* 197 */       String message = Messages.resources_nameEmpty;
/* 198 */       return (IStatus)new ResourceStatus(77, null, message);
/*     */     } 
/*     */ 
/*     */     
/* 202 */     char[] chars = OS.INVALID_RESOURCE_CHARACTERS; byte b; int i; char[] arrayOfChar1;
/* 203 */     for (i = (arrayOfChar1 = chars).length, b = 0; b < i; ) { char c = arrayOfChar1[b];
/* 204 */       if (segment.indexOf(c) != -1) {
/* 205 */         String message = NLS.bind(Messages.resources_invalidCharInName, String.valueOf(c), segment);
/* 206 */         return (IStatus)new ResourceStatus(77, null, message);
/*     */       } 
/*     */       b++; }
/*     */     
/* 210 */     if (!OS.isNameValid(segment)) {
/* 211 */       String message = NLS.bind(Messages.resources_invalidName, segment);
/* 212 */       return (IStatus)new ResourceStatus(77, null, message);
/*     */     } 
/* 214 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validatePath(IPath path, int type, boolean lastSegmentOnly) {
/* 228 */     if (path == null) {
/* 229 */       String str = Messages.resources_pathNull;
/* 230 */       return (IStatus)new ResourceStatus(77, null, str);
/*     */     } 
/*     */ 
/*     */     
/* 234 */     if (path.getDevice() != null) {
/* 235 */       String str = NLS.bind(Messages.resources_invalidCharInPath, String.valueOf(':'), path);
/* 236 */       return (IStatus)new ResourceStatus(77, null, str);
/*     */     } 
/*     */ 
/*     */     
/* 240 */     if (path.isRoot()) {
/* 241 */       String str = Messages.resources_invalidRoot;
/* 242 */       return (IStatus)new ResourceStatus(77, null, str);
/*     */     } 
/*     */ 
/*     */     
/* 246 */     if (!path.isAbsolute()) {
/* 247 */       String str = NLS.bind(Messages.resources_mustBeAbsolute, path);
/* 248 */       return (IStatus)new ResourceStatus(77, null, str);
/*     */     } 
/*     */ 
/*     */     
/* 252 */     int numberOfSegments = path.segmentCount();
/* 253 */     if ((type & 0x4) != 0) {
/* 254 */       if (numberOfSegments == 1)
/* 255 */         return validateName(path.segment(0), 4); 
/* 256 */       if (type == 4) {
/* 257 */         String str = NLS.bind(Messages.resources_projectPath, path);
/* 258 */         return (IStatus)new ResourceStatus(77, null, str);
/*     */       } 
/*     */     } 
/* 261 */     if ((type & 0x3) != 0) {
/* 262 */       if (numberOfSegments < 2) {
/* 263 */         String str = NLS.bind(Messages.resources_resourcePath, path);
/* 264 */         return (IStatus)new ResourceStatus(77, null, str);
/*     */       } 
/* 266 */       int fileFolderType = type &= 0xFFFFFFFB;
/* 267 */       int segmentCount = path.segmentCount();
/* 268 */       if (lastSegmentOnly)
/* 269 */         return validateName(path.segment(segmentCount - 1), fileFolderType); 
/* 270 */       IStatus status = validateName(path.segment(0), 4);
/* 271 */       if (!status.isOK()) {
/* 272 */         return status;
/*     */       }
/* 274 */       for (int i = 1; i < segmentCount; i++) {
/* 275 */         status = validateName(path.segment(i), fileFolderType);
/* 276 */         if (!status.isOK())
/* 277 */           return status; 
/*     */       } 
/* 279 */       return Status.OK_STATUS;
/*     */     } 
/* 281 */     String message = NLS.bind(Messages.resources_invalidPath, path);
/* 282 */     return (IStatus)new ResourceStatus(77, null, message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validatePath(String path, int type) {
/* 290 */     if (path == null) {
/* 291 */       String message = Messages.resources_pathNull;
/* 292 */       return (IStatus)new ResourceStatus(77, null, message);
/*     */     } 
/* 294 */     return validatePath(Path.fromOSString(path), type, false);
/*     */   }
/*     */   public IStatus validateProjectLocation(IProject context, IPath unresolvedLocation) {
/*     */     IPath location;
/* 298 */     if (unresolvedLocation == null) {
/* 299 */       return validateProjectLocationURI(context, null);
/*     */     }
/* 301 */     if (context != null) {
/* 302 */       location = context.getPathVariableManager().resolvePath(unresolvedLocation);
/*     */     } else {
/* 304 */       location = this.workspace.getPathVariableManager().resolvePath(unresolvedLocation);
/*     */     } 
/* 306 */     if (!location.isAbsolute()) {
/*     */       String message;
/* 308 */       if (location.segmentCount() > 0) {
/* 309 */         message = NLS.bind(Messages.pathvar_undefined, location.toString(), location.segment(0));
/*     */       } else {
/* 311 */         message = Messages.links_noPath;
/* 312 */       }  return (IStatus)new ResourceStatus(379, null, message);
/*     */     } 
/* 314 */     return validateProjectLocationURI(context, URIUtil.toURI(location));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateProjectLocationURI(IProject context, URI unresolvedLocation) {
/*     */     URI location;
/* 321 */     if (context == null && unresolvedLocation == null) {
/* 322 */       throw new IllegalArgumentException("Either a project or a location must be provided");
/*     */     }
/*     */     
/* 325 */     boolean isMetadataLocation = false;
/*     */     
/* 327 */     if (unresolvedLocation != null) {
/* 328 */       if (URIUtil.equals(unresolvedLocation, URIUtil.toURI(Platform.getLocation().addTrailingSeparator().append(".metadata")))) {
/* 329 */         isMetadataLocation = true;
/*     */       }
/* 331 */     } else if (context != null && context.getName().equals(".metadata")) {
/* 332 */       isMetadataLocation = true;
/*     */     } 
/*     */ 
/*     */     
/* 336 */     if (isMetadataLocation) {
/* 337 */       String message = NLS.bind(Messages.resources_invalidPath, toString(URIUtil.toURI(Platform.getLocation().addTrailingSeparator().append(".metadata"))));
/* 338 */       return (IStatus)new ResourceStatus(77, null, message);
/*     */     } 
/*     */ 
/*     */     
/* 342 */     if (unresolvedLocation == null) {
/* 343 */       return Status.OK_STATUS;
/*     */     }
/* 345 */     if (context != null) {
/* 346 */       location = context.getPathVariableManager().resolveURI(unresolvedLocation);
/*     */     } else {
/* 348 */       location = this.workspace.getPathVariableManager().resolveURI(unresolvedLocation);
/*     */     } 
/* 350 */     IStatus result = validateSegments(location);
/* 351 */     if (!result.isOK())
/* 352 */       return result; 
/* 353 */     result = validateAbsolute(location, true);
/* 354 */     if (!result.isOK()) {
/* 355 */       return result;
/*     */     }
/*     */     try {
/* 358 */       EFS.getFileSystem(location.getScheme());
/* 359 */     } catch (CoreException e) {
/* 360 */       return e.getStatus();
/*     */     } 
/*     */     
/* 363 */     if (location.getScheme().equals("file")) {
/* 364 */       IPath locationPath = URIUtil.toPath(location);
/*     */       
/* 366 */       IPath defaultDefaultLocation = this.workspace.getRoot().getLocation();
/* 367 */       if (FileUtil.isPrefixOf(locationPath, defaultDefaultLocation)) {
/* 368 */         String message = NLS.bind(Messages.resources_overlapWorkspace, toString(location), defaultDefaultLocation.toOSString());
/* 369 */         return (IStatus)new ResourceStatus(77, null, message);
/*     */       } 
/*     */ 
/*     */       
/* 373 */       IPath parentPath = locationPath.removeLastSegments(1);
/* 374 */       if (FileUtil.isPrefixOf(parentPath, defaultDefaultLocation) && FileUtil.isPrefixOf(defaultDefaultLocation, parentPath) && (context == null || !locationPath.equals(defaultDefaultLocation.append(context.getName())))) {
/* 375 */         String message = NLS.bind(Messages.resources_overlapProject, toString(location), locationPath.lastSegment());
/* 376 */         return (IStatus)new ResourceStatus(77, null, message);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 382 */     IProject[] projects = this.workspace.getRoot().getProjects(8); byte b; int i; IProject[] arrayOfIProject1;
/* 383 */     for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/* 384 */       URI testLocation = project.getLocationURI();
/* 385 */       if (context != null && project.equals(context)) {
/*     */         
/* 387 */         if (URIUtil.equals(testLocation, location)) {
/*     */           continue;
/*     */         }
/* 390 */         if (!FileUtil.isPrefixOf(testLocation, location))
/*     */           continue; 
/* 392 */       } else if (!URIUtil.equals(testLocation, location)) {
/*     */         continue;
/*     */       } 
/*     */ 
/*     */       
/* 397 */       String message = NLS.bind(Messages.resources_overlapProject, toString(location), project.getName());
/* 398 */       return (IStatus)new ResourceStatus(77, null, message);
/*     */       
/*     */       b++; }
/*     */     
/* 402 */     if (context != null && context.exists() && context.isOpen()) {
/* 403 */       IResource[] children = null;
/*     */       try {
/* 405 */         children = context.members();
/* 406 */       } catch (CoreException coreException) {}
/*     */ 
/*     */       
/* 409 */       if (children != null) {
/* 410 */         IResource[] arrayOfIResource; for (int j = (arrayOfIResource = children).length; i < j; ) { IResource child = arrayOfIResource[i];
/* 411 */           if (child.isLinked()) {
/* 412 */             URI testLocation = child.getLocationURI();
/* 413 */             if (testLocation != null && FileUtil.isPrefixOf(testLocation, location)) {
/* 414 */               String message = NLS.bind(Messages.links_locationOverlapsLink, toString(location));
/* 415 */               return (IStatus)new ResourceStatus(235, context.getFullPath(), message);
/*     */             } 
/*     */           }  i++; }
/*     */       
/*     */       } 
/*     */     } 
/* 421 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IStatus validateSegments(URI location) {
/* 430 */     if ("file".equals(location.getScheme())) {
/* 431 */       Path path = new Path(location.getSchemeSpecificPart());
/* 432 */       int segmentCount = path.segmentCount();
/* 433 */       for (int i = 0; i < segmentCount; i++) {
/* 434 */         IStatus result = validateName(path.segment(i), 4);
/* 435 */         if (!result.isOK())
/* 436 */           return result; 
/*     */       } 
/*     */     } 
/* 439 */     return Status.OK_STATUS;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\LocationValidator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */