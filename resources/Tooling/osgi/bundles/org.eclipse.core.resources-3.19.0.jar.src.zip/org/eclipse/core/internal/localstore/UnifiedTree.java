/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Path;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.filesystem.IFileTree;
/*     */ import org.eclipse.core.internal.refresh.RefreshJob;
/*     */ import org.eclipse.core.internal.resources.Resource;
/*     */ import org.eclipse.core.internal.resources.ResourceInfo;
/*     */ import org.eclipse.core.internal.resources.Workspace;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnifiedTree
/*     */ {
/*  41 */   private static boolean disable_advanced_recursive_link_checks = (System.getProperty("org.eclipse.core.resources.disable_advanced_recursive_link_checks") != null);
/*     */ 
/*     */   
/*  44 */   protected static final UnifiedTreeNode childrenMarker = new UnifiedTreeNode(null, null, null, null, false);
/*     */   
/*  46 */   private static final Iterator<UnifiedTreeNode> EMPTY_ITERATOR = Collections.EMPTY_LIST.iterator();
/*     */ 
/*     */   
/*  49 */   protected static final UnifiedTreeNode levelMarker = new UnifiedTreeNode(null, null, null, null, false);
/*     */   
/*  51 */   private static final IFileInfo[] NO_CHILDREN = new IFileInfo[0];
/*     */ 
/*     */   
/*  54 */   private static final IResource[] NO_RESOURCES = new IResource[0];
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean childLevelValid;
/*     */ 
/*     */ 
/*     */   
/*     */   protected IFileTree fileTree;
/*     */ 
/*     */ 
/*     */   
/*  66 */   protected ArrayList<UnifiedTreeNode> freeNodes = new ArrayList<>();
/*     */ 
/*     */   
/*     */   protected int level;
/*     */ 
/*     */   
/*     */   protected LinkedList<UnifiedTreeNode> queue;
/*     */   
/*     */   protected PrefixPool pathPrefixHistory;
/*     */   
/*     */   protected PrefixPool rootPathHistory;
/*     */   
/*     */   protected IResource root;
/*     */ 
/*     */   
/*     */   public UnifiedTree(IResource root) {
/*  82 */     setRoot(root);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnifiedTree(IResource root, IFileTree fileTree) {
/*  94 */     this(root);
/*  95 */     this.fileTree = fileTree;
/*     */   }
/*     */   
/*     */   public void accept(IUnifiedTreeVisitor visitor) throws CoreException {
/*  99 */     accept(visitor, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(IUnifiedTreeVisitor visitor, int depth) throws CoreException {
/* 107 */     Assert.isNotNull(this.root);
/* 108 */     initializeQueue();
/* 109 */     setLevel(0, depth);
/* 110 */     while (!this.queue.isEmpty()) {
/* 111 */       UnifiedTreeNode node = this.queue.remove();
/* 112 */       if (isChildrenMarker(node))
/*     */         continue; 
/* 114 */       if (isLevelMarker(node)) {
/* 115 */         if (!setLevel(getLevel() + 1, depth))
/*     */           break; 
/*     */         continue;
/*     */       } 
/* 119 */       if (visitor.visit(node)) {
/* 120 */         addNodeChildrenToQueue(node);
/*     */       } else {
/* 122 */         removeNodeChildrenFromQueue(node);
/*     */       } 
/* 124 */       if (this.freeNodes.size() < 32767) {
/*     */         
/* 126 */         node.releaseForGc();
/* 127 */         this.freeNodes.add(node);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addChildren(UnifiedTreeNode node) {
/* 135 */     Resource parent = (Resource)node.getResource();
/*     */ 
/*     */     
/* 138 */     int parentType = parent.getType();
/* 139 */     if (parentType == 1 && !node.isFolder()) {
/*     */       return;
/*     */     }
/*     */     
/* 143 */     if (!parent.getProject().isAccessible()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 148 */     IFileInfo[] list = node.existsInFileSystem() ? getLocalList(node) : NO_CHILDREN;
/* 149 */     int localIndex = 0;
/*     */ 
/*     */     
/* 152 */     ResourceInfo resourceInfo = parent.getResourceInfo(false, false);
/* 153 */     int flags = parent.getFlags(resourceInfo);
/* 154 */     boolean unknown = ResourceInfo.isSet(flags, 1048576);
/*     */ 
/*     */     
/* 157 */     if (!unknown && (parentType == 2 || parentType == 4) && parent.exists(flags, true)) {
/* 158 */       IResource members[], target = null;
/* 159 */       UnifiedTreeNode child = null;
/*     */       
/*     */       try {
/* 162 */         members = ((IContainer)parent).members(10);
/* 163 */       } catch (CoreException coreException) {
/* 164 */         members = NO_RESOURCES;
/*     */       } 
/* 166 */       int workspaceIndex = 0;
/*     */       
/* 168 */       while (workspaceIndex < members.length) {
/* 169 */         target = members[workspaceIndex];
/* 170 */         String name = target.getName();
/* 171 */         IFileInfo localInfo = (localIndex < list.length) ? list[localIndex] : null;
/* 172 */         int comp = (localInfo != null) ? name.compareTo(localInfo.getName()) : -1;
/*     */         
/* 174 */         if (target.isLinked()) {
/*     */           
/* 176 */           child = createChildForLinkedResource(target);
/* 177 */           workspaceIndex++;
/*     */           
/* 179 */           if (comp == 0)
/* 180 */             localIndex++; 
/* 181 */         } else if (comp == 0) {
/*     */ 
/*     */           
/* 184 */           if (localInfo.getAttribute(32) && localInfo.isDirectory() && isRecursiveLink(node.getStore(), localInfo)) {
/* 185 */             child = createNode(target, null, null, true);
/*     */           } else {
/* 187 */             child = createNode(target, null, localInfo, true);
/* 188 */           }  localIndex++;
/* 189 */           workspaceIndex++;
/* 190 */         } else if (comp > 0) {
/*     */ 
/*     */           
/* 193 */           if (localInfo.getAttribute(32) && localInfo.isDirectory() && isRecursiveLink(node.getStore(), localInfo)) {
/* 194 */             child = null;
/*     */           } else {
/* 196 */             child = createChildNodeFromFileSystem(node, localInfo);
/* 197 */           }  localIndex++;
/*     */         } else {
/*     */           
/* 200 */           child = createNode(target, null, null, true);
/* 201 */           workspaceIndex++;
/*     */         } 
/* 203 */         if (child != null) {
/* 204 */           addChildToTree(node, child);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 209 */     addChildrenFromFileSystem(node, list, localIndex);
/*     */ 
/*     */     
/* 212 */     if (unknown) {
/*     */       
/* 214 */       resourceInfo = parent.getResourceInfo(false, false);
/* 215 */       if (resourceInfo != null) {
/* 216 */         resourceInfo.clear(1048576);
/*     */       }
/*     */     } 
/*     */     
/* 220 */     if (node.getFirstChild() != null)
/* 221 */       addChildrenMarker(); 
/*     */   }
/*     */   
/*     */   protected void addChildrenFromFileSystem(UnifiedTreeNode node, IFileInfo[] childInfos, int index) {
/* 225 */     if (childInfos == null)
/*     */       return; 
/* 227 */     for (int i = index; i < childInfos.length; i++) {
/* 228 */       IFileInfo info = childInfos[i];
/*     */       
/* 230 */       if (!info.getAttribute(32) || !info.isDirectory() || !isRecursiveLink(node.getStore(), info))
/* 231 */         addChildToTree(node, createChildNodeFromFileSystem(node, info)); 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void addChildrenMarker() {
/* 236 */     addElementToQueue(childrenMarker);
/*     */   }
/*     */   
/*     */   protected void addChildToTree(UnifiedTreeNode node, UnifiedTreeNode child) {
/* 240 */     if (node.getFirstChild() == null)
/* 241 */       node.setFirstChild(child); 
/* 242 */     addElementToQueue(child);
/*     */   }
/*     */   
/*     */   protected void addElementToQueue(UnifiedTreeNode target) {
/* 246 */     this.queue.add(target);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addNodeChildrenToQueue(UnifiedTreeNode node) {
/* 252 */     if (!this.childLevelValid || node.getFirstChild() != null)
/*     */       return; 
/* 254 */     addChildren(node);
/* 255 */     if (this.queue.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 259 */     UnifiedTreeNode nextNode = this.queue.peek();
/* 260 */     if (isChildrenMarker(nextNode))
/* 261 */       this.queue.remove(); 
/* 262 */     nextNode = this.queue.peek();
/* 263 */     if (isLevelMarker(nextNode)) {
/* 264 */       addElementToQueue(levelMarker);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addRootToQueue() {
/* 269 */     if (!this.root.getProject().isAccessible())
/*     */       return; 
/* 271 */     IFileStore store = ((Resource)this.root).getStore();
/* 272 */     IFileInfo fileInfo = (this.fileTree != null) ? this.fileTree.getFileInfo(store) : store.fetchInfo();
/* 273 */     UnifiedTreeNode node = createNode(this.root, store, fileInfo, this.root.exists());
/* 274 */     if (node.existsInFileSystem() || node.existsInWorkspace()) {
/* 275 */       addElementToQueue(node);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected UnifiedTreeNode createChildForLinkedResource(IResource target) {
/* 282 */     IFileStore store = ((Resource)target).getStore();
/* 283 */     return createNode(target, store, store.fetchInfo(), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UnifiedTreeNode createChildNodeFromFileSystem(UnifiedTreeNode parent, IFileInfo info) {
/* 290 */     IPath childPath = parent.getResource().getFullPath().append(info.getName());
/* 291 */     int type = info.isDirectory() ? 2 : 1;
/* 292 */     Resource resource = getWorkspace().newResource(childPath, type);
/* 293 */     return createNode((IResource)resource, null, info, resource.exists());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UnifiedTreeNode createNode(IResource resource, IFileStore store, IFileInfo info, boolean existsWorkspace) {
/* 306 */     UnifiedTreeNode node = null;
/* 307 */     int size = this.freeNodes.size();
/* 308 */     if (size > 0) {
/* 309 */       node = this.freeNodes.remove(size - 1);
/* 310 */       node.reuse(this, resource, store, info, existsWorkspace);
/* 311 */       return node;
/*     */     } 
/*     */     
/* 314 */     return new UnifiedTreeNode(this, resource, store, info, existsWorkspace);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Iterator<UnifiedTreeNode> getChildren(UnifiedTreeNode node) {
/* 319 */     if (node.getFirstChild() == null) {
/* 320 */       addNodeChildrenToQueue(node);
/*     */     }
/*     */     
/* 323 */     if (node.getFirstChild() == null) {
/* 324 */       return EMPTY_ITERATOR;
/*     */     }
/*     */     
/* 327 */     int index = this.queue.indexOf(node.getFirstChild());
/*     */ 
/*     */     
/* 330 */     if (index == -1) {
/* 331 */       return EMPTY_ITERATOR;
/*     */     }
/*     */     
/* 334 */     List<UnifiedTreeNode> result = new ArrayList<>(10);
/*     */     while (true) {
/* 336 */       UnifiedTreeNode child = this.queue.get(index);
/* 337 */       if (isChildrenMarker(child))
/*     */         break; 
/* 339 */       result.add(child);
/* 340 */       if (index == this.queue.size() - 1) {
/* 341 */         index = 0; continue;
/*     */       } 
/* 343 */       index++;
/*     */     } 
/*     */     
/* 346 */     return result.iterator();
/*     */   }
/*     */   
/*     */   protected int getLevel() {
/* 350 */     return this.level;
/*     */   }
/*     */   
/*     */   protected IFileInfo[] getLocalList(UnifiedTreeNode node) {
/*     */     try {
/* 355 */       IFileStore store = node.getStore();
/*     */       
/* 357 */       if (this.fileTree != null && (this.fileTree.getTreeRoot().equals(store) || this.fileTree.getTreeRoot().isParentOf(store))) {
/* 358 */         list = this.fileTree.getChildInfos(store);
/*     */       } else {
/* 360 */         list = store.childInfos(0, null);
/*     */       } 
/* 362 */       if (list == null || list.length == 0)
/* 363 */         return NO_CHILDREN; 
/* 364 */       IFileInfo[] list = ((Resource)node.getResource()).filterChildren(list, false);
/* 365 */       int size = list.length;
/* 366 */       if (size > 1)
/* 367 */         quickSort(list, 0, size - 1); 
/* 368 */       return list;
/* 369 */     } catch (CoreException coreException) {
/*     */       
/* 371 */       return NO_CHILDREN;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Workspace getWorkspace() {
/* 376 */     return (Workspace)this.root.getWorkspace();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initializeQueue() {
/* 381 */     if (this.queue == null) {
/* 382 */       this.queue = new LinkedList<>();
/*     */     } else {
/* 384 */       this.queue.clear();
/*     */     } 
/* 386 */     if (this.freeNodes == null) {
/* 387 */       this.freeNodes = new ArrayList<>(100);
/*     */     } else {
/* 389 */       this.freeNodes.clear();
/* 390 */     }  addRootToQueue();
/* 391 */     addElementToQueue(levelMarker);
/*     */   }
/*     */   
/*     */   protected boolean isChildrenMarker(UnifiedTreeNode node) {
/* 395 */     return (node == childrenMarker);
/*     */   }
/*     */   
/*     */   protected boolean isLevelMarker(UnifiedTreeNode node) {
/* 399 */     return (node == levelMarker);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class PatternHolder
/*     */   {
/* 405 */     private static final String REGEX = Platform.getOS().equals("win32") ? "\\.[.\\\\]*" : "\\.[./]*";
/* 406 */     public static final Pattern TRIVIAL_SYMLINK_PATTERN = Pattern.compile(REGEX);
/*     */     
/* 408 */     private static final String REGEX_BACK_REPEATING = Platform.getOS().equals("win32") ? "(\\.\\.\\\\)+.*" : "(\\.\\./)+.*";
/* 409 */     public static final Pattern REPEATING_BACKWARDS_PATTERN = Pattern.compile(REGEX_BACK_REPEATING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initLinkHistoriesIfNeeded() {
/* 417 */     if (this.pathPrefixHistory == null) {
/*     */       
/* 419 */       Job job = Job.getJobManager().currentJob();
/* 420 */       if (job instanceof RefreshJob) {
/*     */         
/* 422 */         RefreshJob refreshJob = (RefreshJob)job;
/* 423 */         this.pathPrefixHistory = refreshJob.getPathPrefixHistory();
/* 424 */         this.rootPathHistory = refreshJob.getRootPathHistory();
/*     */       } else {
/*     */         
/* 427 */         this.pathPrefixHistory = new PrefixPool(20);
/* 428 */         this.rootPathHistory = new PrefixPool(20);
/*     */       } 
/*     */     } 
/* 431 */     if (this.rootPathHistory.size() == 0) {
/*     */       
/* 433 */       IFileStore rootStore = ((Resource)this.root).getStore();
/*     */       try {
/* 435 */         File rootFile = rootStore.toLocalFile(0, null);
/* 436 */         if (rootFile != null) {
/* 437 */           IPath rootProjPath = this.root.getProject().getLocation();
/* 438 */           if (rootProjPath != null) {
/*     */             try {
/* 440 */               File rootProjFile = new File(rootProjPath.toOSString());
/* 441 */               this.rootPathHistory.insertShorter(String.valueOf(rootProjFile.getCanonicalPath()) + '/');
/* 442 */             } catch (IOException iOException) {}
/*     */           }
/*     */ 
/*     */           
/* 446 */           this.rootPathHistory.insertShorter(String.valueOf(rootFile.getCanonicalPath()) + '/');
/*     */         } 
/* 448 */       } catch (CoreException|IOException coreException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isRecursiveLink(IFileStore parentStore, IFileInfo localInfo) {
/* 474 */     String linkTarget = localInfo.getStringAttribute(64);
/* 475 */     if (linkTarget != null && PatternHolder.TRIVIAL_SYMLINK_PATTERN.matcher(linkTarget).matches()) {
/* 476 */       return true;
/*     */     }
/*     */     
/*     */     try {
/* 480 */       File parentFile = parentStore.toLocalFile(0, null);
/*     */ 
/*     */ 
/*     */       
/* 484 */       if (parentFile == null) {
/* 485 */         return false;
/*     */       }
/*     */       
/* 488 */       Path parent = parentFile.toPath();
/* 489 */       Path realParentPath = parent.toRealPath(new java.nio.file.LinkOption[0]);
/* 490 */       if (disable_advanced_recursive_link_checks) {
/*     */         
/* 492 */         if (linkTarget != null && PatternHolder.REPEATING_BACKWARDS_PATTERN.matcher(linkTarget).matches()) {
/* 493 */           Path targetPath = parent.resolve(linkTarget).normalize();
/*     */ 
/*     */           
/* 496 */           if (parent.normalize().startsWith(targetPath)) {
/* 497 */             return true;
/*     */           }
/*     */ 
/*     */           
/* 501 */           Path realTargetPath = targetPath.toRealPath(new java.nio.file.LinkOption[0]);
/* 502 */           if (realParentPath.startsWith(realTargetPath)) {
/* 503 */             return true;
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 510 */         return false;
/*     */       } 
/*     */       
/* 513 */       File childFile = new File(parentFile, localInfo.getName());
/* 514 */       String parentPath = String.valueOf(realParentPath.toString()) + File.separatorChar;
/* 515 */       String childPath = String.valueOf(childFile.toPath().toRealPath(new java.nio.file.LinkOption[0]).toString()) + File.separatorChar;
/*     */ 
/*     */       
/* 518 */       initLinkHistoriesIfNeeded();
/*     */       
/* 520 */       this.pathPrefixHistory.insertLonger(parentPath);
/* 521 */       if (this.pathPrefixHistory.containsAsPrefix(childPath)) {
/*     */         
/* 523 */         if (!this.rootPathHistory.insertShorter(childPath))
/*     */         {
/* 525 */           return true; } 
/*     */       } else {
/* 527 */         if (this.rootPathHistory.hasPrefixOf(childPath))
/*     */         {
/*     */ 
/*     */           
/* 531 */           return false;
/*     */         }
/*     */ 
/*     */         
/* 535 */         this.rootPathHistory.insertShorter(childPath);
/*     */       } 
/* 537 */     } catch (IOException|CoreException iOException) {}
/*     */ 
/*     */     
/* 540 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isValidLevel(int currentLevel, int depth) {
/* 544 */     switch (depth) {
/*     */       case 2:
/* 546 */         return true;
/*     */       case 1:
/* 548 */         return (currentLevel <= 1);
/*     */       case 0:
/* 550 */         return (currentLevel == 0);
/*     */     } 
/* 552 */     return (currentLevel + 1000 <= depth);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void quickSort(IFileInfo[] infos, int left, int right) {
/* 561 */     int originalLeft = left;
/* 562 */     int originalRight = right;
/* 563 */     IFileInfo mid = infos[(left + right) / 2]; while (true) {
/*     */       while (true)
/* 565 */       { if (mid.compareTo(infos[left]) <= 0)
/*     */         
/* 567 */         { while (infos[right].compareTo(mid) > 0)
/* 568 */             right--; 
/* 569 */           if (left <= right) {
/* 570 */             IFileInfo tmp = infos[left];
/* 571 */             infos[left] = infos[right];
/* 572 */             infos[right] = tmp;
/* 573 */             left++;
/* 574 */             right--;
/*     */           } 
/* 576 */           if (left > right)
/* 577 */             break;  continue; }  left++; }  if (originalLeft < right)
/* 578 */         quickSort(infos, originalLeft, right); 
/* 579 */       if (left < originalRight) {
/* 580 */         quickSort(infos, left, originalRight);
/*     */       }
/*     */       return;
/*     */     } 
/*     */     left++;
/*     */     continue;
/*     */   }
/*     */   
/*     */   protected void removeNodeChildrenFromQueue(UnifiedTreeNode node) {
/* 589 */     UnifiedTreeNode first = node.getFirstChild();
/* 590 */     if (first == null)
/*     */       return;  do {
/*     */     
/* 593 */     } while (!first.equals(this.queue.pollLast()));
/*     */ 
/*     */     
/* 596 */     node.setFirstChild(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean setLevel(int newLevel, int depth) {
/* 604 */     this.level = newLevel;
/* 605 */     this.childLevelValid = isValidLevel(this.level + 1, depth);
/* 606 */     return isValidLevel(this.level, depth);
/*     */   }
/*     */   
/*     */   private void setRoot(IResource root) {
/* 610 */     this.root = root;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\UnifiedTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */