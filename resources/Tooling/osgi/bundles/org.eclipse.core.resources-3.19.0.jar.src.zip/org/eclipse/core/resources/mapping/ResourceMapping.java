/*     */ package org.eclipse.core.resources.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import org.eclipse.core.internal.resources.mapping.ModelProviderManager;
/*     */ import org.eclipse.core.resources.IMarker;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResourceVisitor;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResourceMapping
/*     */   extends PlatformObject
/*     */ {
/*     */   public void accept(ResourceMappingContext context, IResourceVisitor visitor, IProgressMonitor monitor) throws CoreException {
/*  63 */     ResourceTraversal[] traversals = getTraversals(context, monitor); byte b; int i; ResourceTraversal[] arrayOfResourceTraversal1;
/*  64 */     for (i = (arrayOfResourceTraversal1 = traversals).length, b = 0; b < i; ) { ResourceTraversal traversal = arrayOfResourceTraversal1[b];
/*  65 */       traversal.accept(visitor);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(ResourceMapping mapping) {
/*  81 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  93 */     if (obj == this)
/*  94 */       return true; 
/*  95 */     if (obj instanceof ResourceMapping) {
/*  96 */       ResourceMapping other = (ResourceMapping)obj;
/*  97 */       return other.getModelObject().equals(getModelObject());
/*     */     } 
/*  99 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMarker[] findMarkers(String type, boolean includeSubtypes, IProgressMonitor monitor) throws CoreException {
/* 116 */     ResourceTraversal[] traversals = getTraversals(ResourceMappingContext.LOCAL_CONTEXT, monitor);
/* 117 */     ArrayList<IMarker> result = new ArrayList<>(); byte b; int i; ResourceTraversal[] arrayOfResourceTraversal1;
/* 118 */     for (i = (arrayOfResourceTraversal1 = traversals).length, b = 0; b < i; ) { ResourceTraversal traversal = arrayOfResourceTraversal1[b];
/* 119 */       traversal.doFindMarkers(result, type, includeSubtypes); b++; }
/* 120 */      return result.<IMarker>toArray(new IMarker[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Object getModelObject();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ModelProvider getModelProvider() {
/*     */     try {
/* 140 */       return ModelProviderManager.getDefault().getModelProvider(getModelProviderId());
/* 141 */     } catch (CoreException e) {
/* 142 */       throw new IllegalStateException(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getModelProviderId();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract IProject[] getProjects();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ResourceTraversal[] getTraversals(ResourceMappingContext paramResourceMappingContext, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 206 */     return getModelObject().hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\mapping\ResourceMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */