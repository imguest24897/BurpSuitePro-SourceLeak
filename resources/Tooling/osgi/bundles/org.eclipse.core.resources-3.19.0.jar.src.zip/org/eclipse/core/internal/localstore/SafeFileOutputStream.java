/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.StandardCopyOption;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SafeFileOutputStream
/*     */   extends OutputStream
/*     */ {
/*     */   protected File temp;
/*     */   protected File target;
/*     */   protected OutputStream output;
/*     */   protected boolean failed;
/*     */   protected static final String EXTENSION = ".bak";
/*     */   
/*     */   public SafeFileOutputStream(File file) throws IOException {
/*  40 */     this(file.getAbsolutePath(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SafeFileOutputStream(String targetPath, String tempPath) throws IOException {
/*  50 */     this.failed = false;
/*  51 */     this.target = new File(targetPath);
/*  52 */     createTempFile(tempPath);
/*  53 */     if (!this.target.exists()) {
/*  54 */       if (!this.temp.exists()) {
/*  55 */         this.output = new BufferedOutputStream(new FileOutputStream(this.target));
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*  61 */       Files.copy(this.temp.toPath(), this.target.toPath(), new CopyOption[0]);
/*     */     } 
/*  63 */     this.output = new BufferedOutputStream(new FileOutputStream(this.temp));
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*     */     try {
/*  69 */       this.output.close();
/*  70 */     } catch (IOException e) {
/*  71 */       this.failed = true;
/*  72 */       throw e;
/*     */     } 
/*  74 */     if (this.failed) {
/*  75 */       this.temp.delete();
/*     */     } else {
/*  77 */       commit();
/*     */     } 
/*     */   }
/*     */   protected void commit() throws IOException {
/*  81 */     if (!this.temp.exists())
/*     */       return; 
/*  83 */     Files.copy(this.temp.toPath(), this.target.toPath(), new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
/*  84 */     this.temp.delete();
/*     */   }
/*     */   
/*     */   protected void createTempFile(String tempPath) {
/*  88 */     if (tempPath == null)
/*  89 */       tempPath = String.valueOf(this.target.getAbsolutePath()) + ".bak"; 
/*  90 */     this.temp = new File(tempPath);
/*     */   }
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/*     */     try {
/*  96 */       this.output.flush();
/*  97 */     } catch (IOException e) {
/*  98 */       this.failed = true;
/*  99 */       throw e;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getTempFilePath() {
/* 104 */     return this.temp.getAbsolutePath();
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/*     */     try {
/* 110 */       this.output.write(b);
/* 111 */     } catch (IOException e) {
/* 112 */       this.failed = true;
/* 113 */       throw e;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\SafeFileOutputStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */