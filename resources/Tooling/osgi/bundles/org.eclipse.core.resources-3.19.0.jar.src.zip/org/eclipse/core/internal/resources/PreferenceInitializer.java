/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
/*     */ import org.eclipse.core.runtime.preferences.DefaultScope;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PreferenceInitializer
/*     */   extends AbstractPreferenceInitializer
/*     */ {
/*     */   public static final String PREF_OPERATIONS_PER_SNAPSHOT = "snapshots.operations";
/*     */   public static final String PREF_DELTA_EXPIRATION = "delta.expiration";
/*     */   public static final boolean PREF_AUTO_REFRESH_DEFAULT = false;
/*     */   public static final boolean PREF_LIGHTWEIGHT_AUTO_REFRESH_DEFAULT = true;
/*     */   public static final boolean PREF_DISABLE_LINKING_DEFAULT = false;
/*     */   public static final String PREF_ENCODING_DEFAULT = "";
/*     */   public static final boolean PREF_AUTO_BUILDING_DEFAULT = true;
/*     */   public static final String PREF_BUILD_ORDER_DEFAULT = "";
/*     */   public static final int PREF_MAX_BUILD_ITERATIONS_DEFAULT = 10;
/*     */   public static final boolean PREF_DEFAULT_BUILD_ORDER_DEFAULT = true;
/*     */   public static final long PREF_SNAPSHOT_INTERVAL_DEFAULT = 300000L;
/*     */   public static final int PREF_OPERATIONS_PER_SNAPSHOT_DEFAULT = 100;
/*     */   public static final boolean PREF_APPLY_FILE_STATE_POLICY_DEFAULT = true;
/*     */   public static final long PREF_FILE_STATE_LONGEVITY_DEFAULT = 604800000L;
/*     */   public static final long PREF_MAX_FILE_STATE_SIZE_DEFAULT = 1048576L;
/*     */   public static final boolean PREF_KEEP_DERIVED_STATE_DEFAULT = false;
/*     */   public static final int PREF_MAX_FILE_STATES_DEFAULT = 50;
/*     */   public static final long PREF_DELTA_EXPIRATION_DEFAULT = 2592000000L;
/*     */   public static final int PREF_MISSING_NATURE_MARKER_SEVERITY_DEFAULT = 1;
/*     */   public static final int PREF_MISSING_ENCODING_MARKER_SEVERITY_DEFAULT = 1;
/*     */   public static final int PREF_MAX_CONCURRENT_BUILDS_DEFAULT = 1;
/*     */   
/*     */   public void initializeDefaultPreferences() {
/*  73 */     IEclipsePreferences node = DefaultScope.INSTANCE.getNode("org.eclipse.core.resources");
/*     */     
/*  75 */     node.putBoolean("refresh.enabled", false);
/*  76 */     node.putBoolean("refresh.lightweight.enabled", true);
/*     */ 
/*     */     
/*  79 */     node.putBoolean("description.disableLinking", false);
/*     */ 
/*     */     
/*  82 */     node.putBoolean("description.autobuilding", true);
/*  83 */     node.put("description.buildorder", "");
/*  84 */     node.putInt("description.maxbuilditerations", 10);
/*  85 */     node.putBoolean("description.defaultbuildorder", true);
/*  86 */     node.putInt("missingNatureMarkerSeverity", 1);
/*  87 */     node.putInt("missingEncodingMarkerSeverity", 
/*  88 */         1);
/*     */ 
/*     */ 
/*     */     
/*  92 */     node.putBoolean("description.applyfilestatepolicy", true);
/*  93 */     node.putLong("description.filestatelongevity", 604800000L);
/*  94 */     node.putLong("description.maxfilestatesize", 1048576L);
/*  95 */     node.putInt("description.maxfilestates", 50);
/*  96 */     node.putBoolean("description.keepDerivedState", false);
/*     */ 
/*     */     
/*  99 */     node.putLong("description.snapshotinterval", 300000L);
/* 100 */     node.putInt("snapshots.operations", 100);
/* 101 */     node.putLong("delta.expiration", 2592000000L);
/*     */ 
/*     */     
/* 104 */     node.put("encoding", "");
/*     */ 
/*     */     
/* 107 */     node.putInt("maxConcurrentBuilds", 1);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\PreferenceInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */