/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import org.eclipse.core.internal.resources.ResourceException;
/*     */ import org.eclipse.core.internal.resources.Workspace;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BucketTree
/*     */ {
/*     */   public static final int DEPTH_INFINITE = 2147483647;
/*     */   public static final int DEPTH_ONE = 1;
/*     */   public static final int DEPTH_ZERO = 0;
/*     */   private static final int SEGMENT_QUOTA = 256;
/*  42 */   private static final char[][] HEX_STRINGS = new char[256][]; static {
/*  43 */     for (int i = 0; i < HEX_STRINGS.length; i++) {
/*  44 */       HEX_STRINGS[i] = Integer.toHexString(i).toCharArray();
/*     */     }
/*     */   }
/*     */   
/*     */   protected Bucket current;
/*     */   private Workspace workspace;
/*     */   
/*     */   public BucketTree(Workspace workspace, Bucket bucket) {
/*  52 */     this.current = bucket;
/*  53 */     this.workspace = workspace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(Bucket.Visitor visitor, IPath base, int depth) throws CoreException {
/*  67 */     if (Path.ROOT.equals(base)) {
/*  68 */       this.current.load(null, locationFor((IPath)Path.ROOT));
/*  69 */       if (this.current.accept(visitor, base, 0) != 0)
/*     */         return; 
/*  71 */       if (depth == 0)
/*     */         return; 
/*  73 */       boolean keepVisiting = true;
/*  74 */       depth--;
/*  75 */       IProject[] projects = this.workspace.getRoot().getProjects(8);
/*  76 */       for (int i = 0; keepVisiting && i < projects.length; i++) {
/*  77 */         IPath projectPath = projects[i].getFullPath();
/*  78 */         keepVisiting = internalAccept(visitor, projectPath, locationFor(projectPath), depth, 1);
/*     */       } 
/*     */     } else {
/*  81 */       internalAccept(visitor, base, locationFor(base), depth, 0);
/*     */     } 
/*     */   }
/*     */   public void close() throws CoreException {
/*  85 */     this.current.save();
/*  86 */     saveVersion();
/*     */   }
/*     */   
/*     */   public Bucket getCurrent() {
/*  90 */     return this.current;
/*     */   }
/*     */   
/*     */   public File getVersionFile() {
/*  94 */     return new File(locationFor((IPath)Path.ROOT), this.current.getVersionFileName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean internalAccept(Bucket.Visitor visitor, IPath base, File bucketDir, int depthRequested, int currentDepth) throws CoreException {
/* 103 */     this.current.load(base.segment(0), bucketDir);
/* 104 */     int outcome = this.current.accept(visitor, base, depthRequested);
/* 105 */     if (outcome != 0)
/* 106 */       return (outcome == 2); 
/* 107 */     if (depthRequested <= currentDepth)
/* 108 */       return true; 
/* 109 */     File[] subDirs = bucketDir.listFiles();
/* 110 */     if (subDirs == null)
/* 111 */       return true;  byte b; int i; File[] arrayOfFile1;
/* 112 */     for (i = (arrayOfFile1 = subDirs).length, b = 0; b < i; ) { File subDir = arrayOfFile1[b];
/* 113 */       if (subDir.isDirectory() && 
/* 114 */         !internalAccept(visitor, base, subDir, depthRequested, currentDepth + 1)) {
/* 115 */         return false;
/*     */       }
/*     */       b++; }
/*     */     
/* 119 */     return true;
/*     */   }
/*     */   
/*     */   public void loadBucketFor(IPath path) throws CoreException {
/* 123 */     this.current.load(Path.ROOT.equals(path) ? null : path.segment(0), locationFor(path));
/*     */   }
/*     */ 
/*     */   
/*     */   private File locationFor(IPath resourcePath) {
/* 128 */     IPath baseLocation = this.workspace.getMetaArea().locationFor(resourcePath).removeTrailingSeparator();
/* 129 */     int segmentCount = resourcePath.segmentCount();
/* 130 */     String locationString = baseLocation.toOSString();
/* 131 */     StringBuilder locationBuffer = new StringBuilder(locationString.length() + ".indexes".length() + 16);
/* 132 */     locationBuffer.append(locationString);
/* 133 */     locationBuffer.append(File.separatorChar);
/* 134 */     locationBuffer.append(".indexes");
/*     */     
/* 136 */     for (int i = 1; i < segmentCount - 1; i++) {
/*     */       
/* 138 */       locationBuffer.append(File.separatorChar);
/* 139 */       locationBuffer.append(translateSegment(resourcePath.segment(i)));
/*     */     } 
/* 141 */     return new File(locationBuffer.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void saveVersion() throws CoreException {
/* 148 */     File versionFile = getVersionFile();
/* 149 */     if (!versionFile.getParentFile().exists())
/* 150 */       versionFile.getParentFile().mkdirs();  try {
/* 151 */       Exception exception2, exception1 = null;
/*     */     }
/* 153 */     catch (IOException e) {
/* 154 */       String message = NLS.bind(Messages.resources_writeWorkspaceMeta, versionFile.getAbsolutePath());
/* 155 */       throw new ResourceException(568, null, message, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private char[] translateSegment(String segment) {
/* 161 */     return HEX_STRINGS[Math.abs(segment.hashCode()) % 256];
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\BucketTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */