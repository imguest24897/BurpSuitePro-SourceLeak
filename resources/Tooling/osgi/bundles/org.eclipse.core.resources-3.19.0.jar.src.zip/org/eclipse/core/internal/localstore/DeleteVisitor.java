/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.filesystem.provider.FileInfo;
/*     */ import org.eclipse.core.internal.resources.ICoreConstants;
/*     */ import org.eclipse.core.internal.resources.Resource;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeleteVisitor
/*     */   implements IUnifiedTreeVisitor, ICoreConstants
/*     */ {
/*     */   protected boolean force;
/*     */   protected boolean keepHistory;
/*     */   protected IProgressMonitor monitor;
/*     */   protected List<Resource> skipList;
/*     */   protected MultiStatus status;
/*     */   private int ticks;
/*     */   
/*     */   public DeleteVisitor(List<Resource> skipList, int flags, IProgressMonitor monitor, int ticks) {
/*  43 */     this.skipList = skipList;
/*  44 */     this.ticks = ticks;
/*  45 */     this.force = ((flags & 0x1) != 0);
/*  46 */     this.keepHistory = ((flags & 0x2) != 0);
/*  47 */     this.monitor = monitor;
/*  48 */     this.status = new MultiStatus("org.eclipse.core.resources", 273, Messages.localstore_deleteProblem, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void delete(UnifiedTreeNode node, boolean shouldKeepHistory) {
/*  55 */     Resource target = (Resource)node.getResource();
/*     */     try {
/*  57 */       boolean deleteLocalFile = (!target.isLinked() && node.existsInFileSystem());
/*  58 */       IFileStore localFile = deleteLocalFile ? node.getStore() : null;
/*  59 */       if (deleteLocalFile && shouldKeepHistory)
/*  60 */         recursiveKeepHistory(target.getLocalManager().getHistoryStore(), node); 
/*  61 */       node.removeChildrenFromTree();
/*     */       
/*  63 */       int work = (this.ticks < 0) ? 0 : this.ticks;
/*  64 */       this.ticks -= work;
/*  65 */       if (deleteLocalFile) {
/*  66 */         localFile.delete(0, Policy.subMonitorFor(this.monitor, work));
/*     */       } else {
/*  68 */         this.monitor.worked(work);
/*     */       } 
/*  70 */       if (node.existsInWorkspace())
/*  71 */         target.deleteResource(true, this.status); 
/*  72 */     } catch (CoreException e) {
/*  73 */       this.status.add(e.getStatus());
/*     */       
/*     */       try {
/*  76 */         target.refreshLocal(2, null);
/*  77 */       } catch (CoreException coreException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean equals(IResource one, IResource another) {
/*  87 */     return one.getFullPath().equals(another.getFullPath());
/*     */   }
/*     */   
/*     */   public MultiStatus getStatus() {
/*  91 */     return this.status;
/*     */   }
/*     */   
/*     */   protected boolean isAncestor(IResource one, IResource another) {
/*  95 */     return (one.getFullPath().isPrefixOf(another.getFullPath()) && !equals(one, another));
/*     */   }
/*     */   
/*     */   protected boolean isAncestorOfResourceToSkip(IResource resource) {
/*  99 */     if (this.skipList == null)
/* 100 */       return false; 
/* 101 */     for (IResource target : this.skipList) {
/* 102 */       if (isAncestor(resource, target))
/* 103 */         return true; 
/*     */     } 
/* 105 */     return false;
/*     */   }
/*     */   
/*     */   private void recursiveKeepHistory(IHistoryStore store, UnifiedTreeNode node) {
/* 109 */     IResource target = node.getResource();
/*     */     
/* 111 */     if (target.isLinked() || target.isVirtual() || node.isSymbolicLink())
/*     */       return; 
/* 113 */     if (node.isFolder()) {
/* 114 */       this.monitor.subTask(NLS.bind(Messages.localstore_deleting, target.getFullPath()));
/* 115 */       for (Iterator<UnifiedTreeNode> children = node.getChildren(); children.hasNext();)
/* 116 */         recursiveKeepHistory(store, children.next()); 
/*     */     } else {
/* 118 */       FileInfo fileInfo; IFileInfo info = node.fileInfo;
/* 119 */       if (info == null)
/* 120 */         fileInfo = new FileInfo(node.getLocalName()); 
/* 121 */       if (FileSystemResourceManager.storeHistory(node.getResource())) {
/* 122 */         store.addState(target.getFullPath(), node.getStore(), (IFileInfo)fileInfo, true);
/*     */       }
/*     */     } 
/* 125 */     this.monitor.worked(1);
/* 126 */     this.ticks--;
/*     */   }
/*     */   
/*     */   protected void removeFromSkipList(IResource resource) {
/* 130 */     if (this.skipList != null)
/* 131 */       this.skipList.remove(resource); 
/*     */   }
/*     */   
/*     */   protected boolean shouldSkip(IResource resource) {
/* 135 */     if (this.skipList == null)
/* 136 */       return false; 
/* 137 */     for (Resource element : this.skipList) {
/* 138 */       if (equals(resource, (IResource)element))
/* 139 */         return true; 
/* 140 */     }  return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean visit(UnifiedTreeNode node) {
/* 145 */     Policy.checkCanceled(this.monitor);
/* 146 */     Resource target = (Resource)node.getResource();
/* 147 */     if (shouldSkip((IResource)target)) {
/* 148 */       removeFromSkipList((IResource)target);
/* 149 */       int skipTicks = target.countResources(2, false);
/* 150 */       this.monitor.worked(skipTicks);
/* 151 */       this.ticks -= skipTicks;
/* 152 */       return false;
/*     */     } 
/* 154 */     if (isAncestorOfResourceToSkip((IResource)target))
/* 155 */       return true; 
/* 156 */     delete(node, this.keepHistory);
/* 157 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\DeleteVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */