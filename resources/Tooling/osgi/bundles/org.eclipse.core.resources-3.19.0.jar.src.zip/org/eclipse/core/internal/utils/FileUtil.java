/*     */ package org.eclipse.core.internal.utils;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.Closeable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import org.eclipse.core.filesystem.EFS;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.filesystem.IFileSystem;
/*     */ import org.eclipse.core.filesystem.URIUtil;
/*     */ import org.eclipse.core.internal.resources.ResourceException;
/*     */ import org.eclipse.core.internal.resources.Workspace;
/*     */ import org.eclipse.core.resources.ResourceAttributes;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileUtil
/*     */ {
/*  35 */   static final boolean MACOSX = "macosx".equals(getOS());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IFileInfo attributesToFileInfo(ResourceAttributes attributes) {
/*  43 */     IFileInfo fileInfo = EFS.createFileInfo();
/*  44 */     fileInfo.setAttribute(2, attributes.isReadOnly());
/*  45 */     fileInfo.setAttribute(4, attributes.isExecutable());
/*  46 */     fileInfo.setAttribute(8, attributes.isArchive());
/*  47 */     fileInfo.setAttribute(16, attributes.isHidden());
/*  48 */     fileInfo.setAttribute(32, attributes.isSymbolicLink());
/*  49 */     fileInfo.setAttribute(33554432, attributes.isSet(33554432));
/*  50 */     fileInfo.setAttribute(67108864, attributes.isSet(67108864));
/*  51 */     fileInfo.setAttribute(134217728, attributes.isSet(134217728));
/*  52 */     fileInfo.setAttribute(268435456, attributes.isSet(268435456));
/*  53 */     fileInfo.setAttribute(536870912, attributes.isSet(536870912));
/*  54 */     fileInfo.setAttribute(1073741824, attributes.isSet(1073741824));
/*  55 */     return fileInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IPath canonicalPath(IPath path) {
/*  62 */     if (path == null)
/*  63 */       return null; 
/*     */     try {
/*  65 */       String pathString = path.toOSString();
/*  66 */       String canonicalPath = (new File(pathString)).getCanonicalPath();
/*     */       
/*  68 */       if (canonicalPath.equals(pathString))
/*  69 */         return path; 
/*  70 */       return (IPath)new Path(canonicalPath);
/*  71 */     } catch (IOException iOException) {
/*  72 */       return path;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IPath realPath(IPath path) {
/*     */     IPath iPath;
/*  87 */     if (path == null)
/*  88 */       return null; 
/*  89 */     IFileSystem fileSystem = EFS.getLocalFileSystem();
/*  90 */     if (fileSystem.isCaseSensitive())
/*  91 */       return path; 
/*  92 */     Path path1 = path.isAbsolute() ? Path.ROOT : Path.EMPTY;
/*  93 */     String device = path.getDevice();
/*  94 */     if (device != null) {
/*  95 */       iPath = path1.setDevice(device.toUpperCase());
/*     */     }
/*  97 */     IFileStore fileStore = null;
/*  98 */     for (int i = 0; i < path.segmentCount(); i++) {
/*  99 */       String segment = path.segment(i);
/* 100 */       if (i == 0 && path.isUNC()) {
/* 101 */         iPath = iPath.append(segment.toUpperCase());
/* 102 */         iPath = iPath.makeUNC(true);
/*     */       }
/* 104 */       else if (MACOSX) {
/*     */ 
/*     */         
/* 107 */         String realName, names[] = iPath.toFile().list((dir, n) -> n.equalsIgnoreCase(paramString1));
/*     */         
/* 109 */         if (names == null || names.length == 0) {
/*     */ 
/*     */           
/* 112 */           iPath = iPath.append(path.removeFirstSegments(iPath.segmentCount())); break;
/*     */         } 
/* 114 */         if (names.length == 1) {
/* 115 */           realName = names[0];
/*     */         }
/*     */         else {
/*     */           
/* 119 */           realName = segment;
/*     */         } 
/* 121 */         iPath = iPath.append(realName);
/*     */       } else {
/* 123 */         if (fileStore == null)
/* 124 */           fileStore = fileSystem.getStore(iPath); 
/* 125 */         fileStore = fileStore.getChild(segment);
/* 126 */         IFileInfo info = fileStore.fetchInfo();
/* 127 */         if (!info.exists()) {
/*     */ 
/*     */           
/* 130 */           iPath = iPath.append(path.removeFirstSegments(iPath.segmentCount()));
/*     */           break;
/*     */         } 
/* 133 */         iPath = iPath.append(info.getName());
/*     */       } 
/*     */     } 
/*     */     
/* 137 */     if (path.hasTrailingSeparator()) {
/* 138 */       iPath = iPath.addTrailingSeparator();
/*     */     }
/*     */     
/* 141 */     return iPath.equals(path) ? path : iPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getOS() {
/* 149 */     return System.getProperty("osgi.os", "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI canonicalURI(URI uri) {
/* 156 */     if (uri == null)
/* 157 */       return null; 
/* 158 */     if ("file".equals(uri.getScheme())) {
/*     */       
/* 160 */       IPath inputPath = URIUtil.toPath(uri);
/* 161 */       IPath canonicalPath = canonicalPath(inputPath);
/* 162 */       if (inputPath == canonicalPath)
/* 163 */         return uri; 
/* 164 */       return URIUtil.toURI(canonicalPath);
/*     */     } 
/* 166 */     return uri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI realURI(URI uri) {
/* 176 */     if (uri == null)
/* 177 */       return null; 
/* 178 */     if ("file".equals(uri.getScheme())) {
/*     */       
/* 180 */       IPath inputPath = URIUtil.toPath(uri);
/* 181 */       IPath realPath = realPath(inputPath);
/* 182 */       if (inputPath == realPath)
/* 183 */         return uri; 
/* 184 */       return URIUtil.toURI(realPath);
/*     */     } 
/* 186 */     return uri;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean computeOverlap(IPath location1, IPath location2, boolean bothDirections) {
/*     */     Path path1, path2;
/* 197 */     IPath one = location1;
/* 198 */     IPath two = location2;
/*     */     
/* 200 */     if (!Workspace.caseSensitive) {
/* 201 */       path1 = new Path(location1.toOSString().toLowerCase());
/* 202 */       path2 = new Path(location2.toOSString().toLowerCase());
/*     */     } 
/* 204 */     return !(!path1.isPrefixOf((IPath)path2) && (!bothDirections || !path2.isPrefixOf((IPath)path1)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean computeOverlap(URI location1, URI location2, boolean bothDirections) {
/* 214 */     if (location1.equals(location2))
/* 215 */       return true; 
/* 216 */     String scheme1 = location1.getScheme();
/* 217 */     String scheme2 = location2.getScheme();
/* 218 */     if ((scheme1 == null) ? (scheme2 != null) : !scheme1.equals(scheme2))
/* 219 */       return false; 
/* 220 */     if ("file".equals(scheme1) && "file".equals(scheme2))
/* 221 */       return computeOverlap(URIUtil.toPath(location1), URIUtil.toPath(location2), bothDirections); 
/* 222 */     IFileSystem system = null;
/*     */     try {
/* 224 */       system = EFS.getFileSystem(scheme1);
/* 225 */     } catch (CoreException coreException) {}
/*     */ 
/*     */     
/* 228 */     if (system == null) {
/*     */       
/* 230 */       String string1 = location1.toString();
/* 231 */       String string2 = location2.toString();
/* 232 */       return !(!string1.startsWith(string2) && (!bothDirections || !string2.startsWith(string1)));
/*     */     } 
/* 234 */     IFileStore store1 = system.getStore(location1);
/* 235 */     IFileStore store2 = system.getStore(location2);
/* 236 */     return !(!store1.equals(store2) && !store1.isParentOf(store2) && (!bothDirections || !store2.isParentOf(store1)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourceAttributes fileInfoToAttributes(IFileInfo fileInfo) {
/* 245 */     ResourceAttributes attributes = new ResourceAttributes();
/* 246 */     attributes.setReadOnly(fileInfo.getAttribute(2));
/* 247 */     attributes.setArchive(fileInfo.getAttribute(8));
/* 248 */     attributes.setExecutable(fileInfo.getAttribute(4));
/* 249 */     attributes.setHidden(fileInfo.getAttribute(16));
/* 250 */     attributes.setSymbolicLink(fileInfo.getAttribute(32));
/* 251 */     attributes.set(33554432, fileInfo.getAttribute(33554432));
/* 252 */     attributes.set(67108864, fileInfo.getAttribute(67108864));
/* 253 */     attributes.set(134217728, fileInfo.getAttribute(134217728));
/* 254 */     attributes.set(268435456, fileInfo.getAttribute(268435456));
/* 255 */     attributes.set(536870912, fileInfo.getAttribute(536870912));
/* 256 */     attributes.set(1073741824, fileInfo.getAttribute(1073741824));
/* 257 */     return attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isOverlapping(URI location1, URI location2) {
/* 265 */     return computeOverlap(location1, location2, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPrefixOf(IPath location1, IPath location2) {
/* 273 */     return computeOverlap(location1, location2, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPrefixOf(URI location1, URI location2) {
/* 281 */     return computeOverlap(location1, location2, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void safeClose(Closeable stream) {
/*     */     try {
/* 305 */       if (stream != null)
/* 306 */         stream.close(); 
/* 307 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IPath toPath(URI uri) {
/* 320 */     if (uri == null)
/* 321 */       return null; 
/* 322 */     String scheme = uri.getScheme();
/*     */     
/* 324 */     if (scheme == null || "file".equals(scheme))
/* 325 */       return (IPath)new Path(uri.getSchemeSpecificPart()); 
/* 326 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final void transferStreams(InputStream source, OutputStream destination, String path, IProgressMonitor monitor) throws CoreException {
/* 331 */     SubMonitor subMonitor = SubMonitor.convert(monitor);
/*     */     
/*     */     try {
/* 334 */       if (source instanceof ByteArrayInputStream) {
/*     */         
/* 336 */         ((ByteArrayInputStream)source).transferTo(destination);
/* 337 */         subMonitor.split(1);
/*     */       } else {
/* 339 */         byte[] buffer = new byte[8192];
/*     */         while (true) {
/* 341 */           int bytesRead = -1;
/*     */           try {
/* 343 */             bytesRead = source.read(buffer);
/* 344 */           } catch (IOException e) {
/* 345 */             String msg = NLS.bind(Messages.localstore_failedReadDuringWrite, path);
/* 346 */             throw new ResourceException(271, new Path(path), msg, e);
/*     */           } 
/* 348 */           if (bytesRead == -1) {
/*     */             break;
/*     */           }
/* 351 */           destination.write(buffer, 0, bytesRead);
/* 352 */           subMonitor.split(1);
/*     */         } 
/*     */       } 
/*     */       
/* 356 */       destination.close();
/* 357 */     } catch (IOException e) {
/* 358 */       String msg = NLS.bind(Messages.localstore_couldNotWrite, path);
/* 359 */       throw new ResourceException(272, new Path(path), msg, e);
/*     */     } finally {
/*     */       
/* 362 */       safeClose(source);
/* 363 */       safeClose(destination);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\interna\\utils\FileUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */