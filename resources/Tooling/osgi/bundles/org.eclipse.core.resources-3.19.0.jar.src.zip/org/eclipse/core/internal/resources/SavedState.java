/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import org.eclipse.core.internal.events.ResourceDelta;
/*    */ import org.eclipse.core.internal.events.ResourceDeltaFactory;
/*    */ import org.eclipse.core.internal.utils.Policy;
/*    */ import org.eclipse.core.internal.watson.ElementTree;
/*    */ import org.eclipse.core.resources.IResourceChangeListener;
/*    */ import org.eclipse.core.resources.IResourceDelta;
/*    */ import org.eclipse.core.resources.ISavedState;
/*    */ import org.eclipse.core.resources.IWorkspaceRoot;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SavedState
/*    */   implements ISavedState
/*    */ {
/*    */   ElementTree oldTree;
/*    */   ElementTree newTree;
/*    */   SafeFileTable fileTable;
/*    */   String pluginId;
/*    */   Workspace workspace;
/*    */   
/*    */   SavedState(Workspace workspace, String pluginId, ElementTree oldTree, ElementTree newTree) throws CoreException {
/* 36 */     this.workspace = workspace;
/* 37 */     this.pluginId = pluginId;
/* 38 */     this.newTree = newTree;
/* 39 */     this.oldTree = oldTree;
/* 40 */     this.fileTable = restoreFileTable();
/*    */   }
/*    */   
/*    */   void forgetTrees() {
/* 44 */     this.newTree = null;
/* 45 */     this.oldTree = null;
/* 46 */     this.workspace.saveManager.clearDeltaExpiration(this.pluginId);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSaveNumber() {
/* 51 */     return this.workspace.getSaveManager().getSaveNumber(this.pluginId);
/*    */   }
/*    */   
/*    */   protected SafeFileTable getFileTable() {
/* 55 */     return this.fileTable;
/*    */   }
/*    */   
/*    */   protected SafeFileTable restoreFileTable() throws CoreException {
/* 59 */     if (this.fileTable == null)
/* 60 */       this.fileTable = new SafeFileTable(this.pluginId, this.workspace); 
/* 61 */     return this.fileTable;
/*    */   }
/*    */ 
/*    */   
/*    */   public IPath lookup(IPath file) {
/* 66 */     return getFileTable().lookup(file);
/*    */   }
/*    */ 
/*    */   
/*    */   public IPath[] getFiles() {
/* 71 */     return getFileTable().getFiles();
/*    */   }
/*    */ 
/*    */   
/*    */   public void processResourceChangeEvents(IResourceChangeListener listener) {
/*    */     try {
/* 77 */       IWorkspaceRoot iWorkspaceRoot = this.workspace.getRoot();
/*    */       try {
/* 79 */         this.workspace.prepareOperation((ISchedulingRule)iWorkspaceRoot, null);
/* 80 */         if (this.oldTree == null || this.newTree == null)
/*    */           return; 
/* 82 */         this.workspace.beginOperation(true);
/* 83 */         ResourceDelta delta = ResourceDeltaFactory.computeDelta(this.workspace, this.oldTree, this.newTree, (IPath)Path.ROOT, -1L);
/* 84 */         forgetTrees();
/* 85 */         this.workspace.getNotificationManager().broadcastChanges(listener, 16, (IResourceDelta)delta);
/*    */       } finally {
/* 87 */         this.workspace.endOperation((ISchedulingRule)iWorkspaceRoot, false);
/*    */       } 
/* 89 */     } catch (CoreException e) {
/*    */       
/* 91 */       Policy.log((Throwable)e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\SavedState.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */