/*    */ package org.eclipse.core.internal.resources.mapping;
/*    */ 
/*    */ import org.eclipse.core.resources.IContainer;
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*    */ import org.eclipse.core.resources.mapping.ResourceMappingContext;
/*    */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShallowResourceMapping
/*    */   extends ResourceMapping
/*    */ {
/*    */   private final ShallowContainer container;
/*    */   
/*    */   public ShallowResourceMapping(ShallowContainer container) {
/* 29 */     this.container = container;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getModelObject() {
/* 34 */     return this.container;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getModelProviderId() {
/* 39 */     return "org.eclipse.core.resources.modelProvider";
/*    */   }
/*    */ 
/*    */   
/*    */   public IProject[] getProjects() {
/* 44 */     return new IProject[] { this.container.getResource().getProject() };
/*    */   }
/*    */ 
/*    */   
/*    */   public ResourceTraversal[] getTraversals(ResourceMappingContext context, IProgressMonitor monitor) {
/* 49 */     return new ResourceTraversal[] { new ResourceTraversal(new IResource[] { (IResource)this.container.getResource() }, 1, 0) };
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean contains(ResourceMapping mapping) {
/* 54 */     if (mapping.getModelProviderId().equals(getModelProviderId())) {
/* 55 */       Object object = mapping.getModelObject();
/* 56 */       IContainer iContainer = this.container.getResource();
/*    */       
/* 58 */       if (object instanceof ShallowContainer) {
/* 59 */         ShallowContainer sc = (ShallowContainer)object;
/* 60 */         return sc.getResource().equals(iContainer);
/*    */       } 
/* 62 */       if (object instanceof IResource) {
/* 63 */         IResource other = (IResource)object;
/* 64 */         return (other.getType() == 1 && iContainer.getFullPath().equals(other.getFullPath().removeLastSegments(1)));
/*    */       } 
/*    */     } 
/* 67 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\mapping\ShallowResourceMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */