/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.events.BuilderPersistentInfo;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.internal.watson.ElementTree;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WorkspaceTreeReader_2
/*     */   extends WorkspaceTreeReader_1
/*     */ {
/*     */   private List<BuilderPersistentInfo> builderInfos;
/*     */   
/*     */   public WorkspaceTreeReader_2(Workspace workspace) {
/*  52 */     super(workspace);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getVersion() {
/*  57 */     return 67305986;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void readBuildersPersistentInfo(IProject project, DataInputStream input, List<BuilderPersistentInfo> builders, IProgressMonitor monitor) throws IOException {
/*  65 */     monitor = Policy.monitorFor(monitor);
/*     */     try {
/*  67 */       int builderCount = input.readInt();
/*  68 */       for (int i = 0; i < builderCount; i++) {
/*  69 */         BuilderPersistentInfo info = readBuilderInfo(project, input, i);
/*     */         
/*  71 */         int n = input.readInt();
/*  72 */         IProject[] projects = new IProject[n];
/*  73 */         for (int j = 0; j < n; j++)
/*  74 */           projects[j] = this.workspace.getRoot().getProject(input.readUTF()); 
/*  75 */         info.setInterestingProjects(projects);
/*  76 */         builders.add(info);
/*     */       } 
/*     */     } finally {
/*  79 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readTree(DataInputStream input, IProgressMonitor monitor) throws CoreException {
/*  89 */     monitor = Policy.monitorFor(monitor);
/*     */     
/*     */     try {
/*  92 */       String message = Messages.resources_reading;
/*  93 */       monitor.beginTask(message, 100);
/*     */       
/*  95 */       this.builderInfos = new ArrayList<>(20);
/*     */ 
/*     */ 
/*     */       
/*  99 */       readWorkspaceFields(input, Policy.subMonitorFor(monitor, Policy.opWork * 20 / 100));
/*     */       
/* 101 */       HashMap<String, SavedState> savedStates = new HashMap<>(20);
/* 102 */       List<SavedState> pluginsToBeLinked = new ArrayList<>(20);
/* 103 */       readPluginsSavedStates(input, savedStates, pluginsToBeLinked, Policy.subMonitorFor(monitor, Policy.opWork * 10 / 100));
/* 104 */       this.workspace.getSaveManager().setPluginsSavedState(savedStates);
/*     */       
/* 106 */       int treeIndex = pluginsToBeLinked.size();
/*     */       
/* 108 */       List<BuilderPersistentInfo> buildersToBeLinked = new ArrayList<>(20);
/* 109 */       readBuildersPersistentInfo((IProject)null, input, buildersToBeLinked, Policy.subMonitorFor(monitor, Policy.opWork * 10 / 100));
/*     */       
/* 111 */       ElementTree[] trees = readTrees((IPath)Path.ROOT, input, Policy.subMonitorFor(monitor, Policy.opWork * 40 / 100));
/* 112 */       linkPluginsSavedStateToTrees(pluginsToBeLinked, trees, Policy.subMonitorFor(monitor, Policy.opWork * 10 / 100));
/* 113 */       linkBuildersToTrees(buildersToBeLinked, trees, treeIndex, Policy.subMonitorFor(monitor, Policy.opWork * 10 / 100));
/*     */ 
/*     */       
/* 116 */       if (input.available() > 0) {
/* 117 */         treeIndex += buildersToBeLinked.size();
/*     */         
/* 119 */         buildersToBeLinked.clear();
/* 120 */         readBuildersPersistentInfo((IProject)null, input, buildersToBeLinked, Policy.subMonitorFor(monitor, Policy.opWork * 10 / 100));
/* 121 */         linkBuildersToTrees(buildersToBeLinked, trees, treeIndex, Policy.subMonitorFor(monitor, Policy.opWork * 10 / 100));
/*     */         
/* 123 */         for (BuilderPersistentInfo builderPersistentInfo : this.builderInfos) {
/* 124 */           builderPersistentInfo.setConfigName(input.readUTF());
/*     */         }
/*     */       } 
/*     */       
/* 128 */       setBuilderInfos(this.builderInfos);
/*     */     }
/* 130 */     catch (IOException e) {
/* 131 */       String message = Messages.resources_readProjectTree;
/* 132 */       throw new ResourceException(567, null, message, e);
/*     */     } finally {
/* 134 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readTree(IProject project, DataInputStream input, IProgressMonitor monitor) throws CoreException {
/* 144 */     monitor = Policy.monitorFor(monitor);
/*     */     
/*     */     try {
/* 147 */       String message = Messages.resources_reading;
/* 148 */       monitor.beginTask(message, 10);
/*     */       
/* 150 */       this.builderInfos = new ArrayList<>(20);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 155 */       int treeIndex = 0;
/*     */       
/* 157 */       List<BuilderPersistentInfo> buildersToBeLinked = new ArrayList<>(20);
/* 158 */       readBuildersPersistentInfo(project, input, buildersToBeLinked, Policy.subMonitorFor(monitor, 1));
/*     */       
/* 160 */       ElementTree[] trees = readTrees(project.getFullPath(), input, Policy.subMonitorFor(monitor, 8));
/* 161 */       linkBuildersToTrees(buildersToBeLinked, trees, treeIndex, Policy.subMonitorFor(monitor, 1));
/*     */ 
/*     */       
/* 164 */       if (input.available() > 0) {
/* 165 */         treeIndex += buildersToBeLinked.size();
/*     */         
/* 167 */         List<BuilderPersistentInfo> infos = new ArrayList<>(5);
/* 168 */         readBuildersPersistentInfo(project, input, infos, Policy.subMonitorFor(monitor, 1));
/* 169 */         linkBuildersToTrees(infos, trees, treeIndex, Policy.subMonitorFor(monitor, 1));
/*     */         
/* 171 */         for (BuilderPersistentInfo builderPersistentInfo : this.builderInfos) {
/* 172 */           builderPersistentInfo.setConfigName(input.readUTF());
/*     */         }
/*     */       } 
/*     */       
/* 176 */       setBuilderInfos(this.builderInfos);
/*     */     }
/* 178 */     catch (IOException e) {
/* 179 */       String message = Messages.resources_readProjectTree;
/* 180 */       throw new ResourceException(567, null, message, e);
/*     */     } finally {
/* 182 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void linkBuildersToTrees(List<BuilderPersistentInfo> buildersToBeLinked, ElementTree[] trees, int index, IProgressMonitor monitor) {
/* 193 */     monitor = Policy.monitorFor(monitor);
/*     */     try {
/* 195 */       for (int i = 0; i < buildersToBeLinked.size(); i++) {
/* 196 */         BuilderPersistentInfo info = buildersToBeLinked.get(i);
/* 197 */         info.setLastBuildTree(trees[index++]);
/* 198 */         this.builderInfos.add(info);
/*     */       } 
/*     */     } finally {
/* 201 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setBuilderInfos(List<BuilderPersistentInfo> infos) {
/* 209 */     Map<String, List<BuilderPersistentInfo>> groupedInfos = new HashMap<>();
/* 210 */     for (BuilderPersistentInfo info : infos) {
/* 211 */       if (!groupedInfos.containsKey(info.getProjectName()))
/* 212 */         groupedInfos.put(info.getProjectName(), new ArrayList<>()); 
/* 213 */       ((List<BuilderPersistentInfo>)groupedInfos.get(info.getProjectName())).add(info);
/*     */     } 
/* 215 */     for (Map.Entry<String, List<BuilderPersistentInfo>> entry : groupedInfos.entrySet()) {
/* 216 */       IProject proj = this.workspace.getRoot().getProject(entry.getKey());
/* 217 */       this.workspace.getBuildManager().setBuildersPersistentInfo(proj, entry.getValue());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\WorkspaceTreeReader_2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */