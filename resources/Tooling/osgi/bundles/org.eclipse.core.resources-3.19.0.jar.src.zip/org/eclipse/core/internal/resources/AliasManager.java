/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Consumer;
/*     */ import org.eclipse.core.filesystem.EFS;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.internal.events.ILifecycleListener;
/*     */ import org.eclipse.core.internal.events.LifecycleEvent;
/*     */ import org.eclipse.core.internal.localstore.FileSystemResourceManager;
/*     */ import org.eclipse.core.internal.utils.FileUtil;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceChangeEvent;
/*     */ import org.eclipse.core.resources.IResourceChangeListener;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AliasManager
/*     */   implements IManager, ILifecycleListener, IResourceChangeListener
/*     */ {
/*     */   class FindAliasesDoit
/*     */     implements Consumer<IResource>
/*     */   {
/*     */     private final int aliasType;
/*     */     private final IPath searchPath;
/*     */     
/*     */     public FindAliasesDoit(IResource aliasResource) {
/*  67 */       this.aliasType = aliasResource.getType();
/*  68 */       this.searchPath = aliasResource.getFullPath();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void accept(IResource match) {
/*  74 */       if (match.getFullPath().isPrefixOf(this.searchPath))
/*     */         return; 
/*  76 */       IPath aliasPath = null;
/*  77 */       switch (match.getType()) {
/*     */         
/*     */         case 4:
/*  80 */           if (AliasManager.this.suffix.segmentCount() > 0) {
/*  81 */             IResource testResource = ((IProject)match).findMember(AliasManager.this.suffix.segment(0));
/*  82 */             if (testResource != null && testResource.isLinked()) {
/*     */               return;
/*     */             }
/*     */           } 
/*  86 */           aliasPath = match.getFullPath().append(AliasManager.this.suffix);
/*     */           break;
/*     */         case 2:
/*  89 */           aliasPath = match.getFullPath().append(AliasManager.this.suffix);
/*     */           break;
/*     */         case 1:
/*  92 */           if (AliasManager.this.suffix.segmentCount() == 0)
/*  93 */             aliasPath = match.getFullPath(); 
/*     */           break;
/*     */       } 
/*  96 */       if (aliasPath != null) {
/*  97 */         if (this.aliasType == 1) {
/*  98 */           AliasManager.this.aliases.add(AliasManager.this.workspace.getRoot().getFile(aliasPath));
/*     */         }
/* 100 */         else if (aliasPath.segmentCount() == 1) {
/* 101 */           AliasManager.this.aliases.add(AliasManager.this.workspace.getRoot().getProject(aliasPath.lastSegment()));
/*     */         } else {
/* 103 */           AliasManager.this.aliases.add(AliasManager.this.workspace.getRoot().getFolder(aliasPath));
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   class LocationMap
/*     */   {
/*     */     private final SortedMap<IFileStore, Object> map;
/*     */ 
/*     */     
/*     */     LocationMap() {
/* 117 */       this.map = new TreeMap<>(IFileStore::compareTo);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean add(IFileStore location, IResource resource) {
/* 124 */       Object oldValue = this.map.get(location);
/* 125 */       if (oldValue == null) {
/* 126 */         this.map.put(location, resource);
/* 127 */         return true;
/*     */       } 
/* 129 */       if (oldValue instanceof IResource) {
/* 130 */         if (resource.equals(oldValue))
/* 131 */           return false; 
/* 132 */         ArrayList<Object> newValue = new ArrayList(2);
/* 133 */         newValue.add(oldValue);
/* 134 */         newValue.add(resource);
/* 135 */         this.map.put(location, newValue);
/* 136 */         return true;
/*     */       } 
/*     */       
/* 139 */       ArrayList<IResource> list = (ArrayList<IResource>)oldValue;
/* 140 */       if (list.contains(resource))
/* 141 */         return false; 
/* 142 */       list.add(resource);
/* 143 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void clear() {
/* 150 */       this.map.clear();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void matchingPrefixDo(IFileStore prefix, Consumer<IResource> doit) {
/*     */       SortedMap<IFileStore, Object> matching;
/* 159 */       IFileStore prefixParent = prefix.getParent();
/* 160 */       if (prefixParent != null) {
/*     */ 
/*     */         
/* 163 */         IFileStore endPoint = prefixParent.getChild(String.valueOf(prefix.getName()) + "\000");
/* 164 */         matching = this.map.subMap(prefix, endPoint);
/*     */       } else {
/* 166 */         matching = this.map;
/*     */       } 
/* 168 */       for (Object value : matching.values()) {
/* 169 */         if (value == null)
/*     */           return; 
/* 171 */         if (value instanceof java.util.List) {
/* 172 */           for (Object element : value) {
/* 173 */             if (element instanceof IResource)
/* 174 */               doit.accept((IResource)element); 
/*     */           } 
/*     */           continue;
/*     */         } 
/* 178 */         doit.accept((IResource)value);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void matchingResourcesDo(IFileStore location, Consumer<IResource> doit) {
/* 188 */       Object value = this.map.get(location);
/* 189 */       if (value == null)
/*     */         return; 
/* 191 */       if (value instanceof java.util.List) {
/* 192 */         for (Object element : value) {
/* 193 */           if (element instanceof IResource) {
/* 194 */             doit.accept((IResource)element);
/*     */           }
/*     */         } 
/*     */       } else {
/* 198 */         doit.accept((IResource)value);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void overLappingResourcesDo(Consumer<IResource> doit) {
/* 207 */       IFileStore previousStore = null;
/* 208 */       IResource previousResource = null;
/* 209 */       for (Map.Entry<IFileStore, Object> current : this.map.entrySet()) {
/*     */         
/* 211 */         IFileStore currentStore = current.getKey();
/* 212 */         IResource currentResource = null;
/* 213 */         Object value = current.getValue();
/* 214 */         if (value instanceof java.util.List) {
/* 215 */           for (Object element : value) {
/* 216 */             if (element instanceof IResource) {
/* 217 */               doit.accept(((IResource)element).getProject());
/*     */             }
/*     */           } 
/*     */         } else {
/*     */           
/* 222 */           currentResource = (IResource)value;
/*     */         } 
/* 224 */         if (previousStore != null)
/*     */         {
/*     */           
/* 227 */           if (previousStore.isParentOf(currentStore)) {
/*     */ 
/*     */             
/* 230 */             if (previousResource != null) {
/* 231 */               doit.accept(previousResource.getProject());
/*     */               
/* 233 */               previousResource = null;
/*     */             } 
/* 235 */             if (currentResource != null) {
/* 236 */               doit.accept(currentResource.getProject());
/*     */             }
/*     */             continue;
/*     */           } 
/*     */         }
/* 241 */         previousStore = currentStore;
/* 242 */         previousResource = currentResource;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean remove(IFileStore location, IResource resource) {
/* 251 */       Object oldValue = this.map.get(location);
/* 252 */       if (oldValue == null)
/* 253 */         return false; 
/* 254 */       if (oldValue instanceof IResource) {
/* 255 */         if (resource.equals(oldValue)) {
/* 256 */           this.map.remove(location);
/* 257 */           return true;
/*     */         } 
/* 259 */         return false;
/*     */       } 
/*     */       
/* 262 */       ArrayList<IResource> list = (ArrayList<IResource>)oldValue;
/* 263 */       boolean wasRemoved = list.remove(resource);
/* 264 */       if (list.isEmpty())
/* 265 */         this.map.remove(location); 
/* 266 */       return wasRemoved;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 273 */   protected final Set<IResource> aliasedProjects = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 279 */   protected final HashSet<IResource> aliases = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 286 */   private final Set<IResource> changedLinks = ConcurrentHashMap.newKeySet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile boolean changedProjects = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 298 */   protected final LocationMap locationsMap = new LocationMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 307 */   private int nonDefaultResourceCount = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath suffix;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Workspace workspace;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AliasManager(Workspace workspace) {
/* 321 */     this.workspace = workspace;
/*     */   }
/*     */   
/*     */   private void addToLocationsMap(IProject project) {
/* 325 */     IFileStore location = ((Resource)project).getStore();
/* 326 */     if (location != null)
/* 327 */       this.locationsMap.add(location, (IResource)project); 
/* 328 */     ProjectDescription description = ((Project)project).internalGetDescription();
/* 329 */     if (description == null)
/*     */       return; 
/* 331 */     if (description.getLocationURI() != null)
/* 332 */       this.nonDefaultResourceCount++; 
/* 333 */     HashMap<IPath, LinkDescription> links = description.getLinks();
/* 334 */     if (links == null)
/*     */       return; 
/* 336 */     for (LinkDescription linkDesc : links.values()) {
/* 337 */       IResource link = project.findMember(linkDesc.getProjectRelativePath());
/* 338 */       if (link != null) {
/*     */         try {
/* 340 */           URI locationURI = linkDesc.getLocationURI();
/* 341 */           locationURI = FileUtil.canonicalURI(locationURI);
/* 342 */           locationURI = link.getPathVariableManager().resolveURI(locationURI);
/* 343 */           addToLocationsMap(link, EFS.getStore(locationURI));
/* 344 */         } catch (CoreException coreException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void addToLocationsMap(IResource link, IFileStore location) {
/* 352 */     if (location != null && !link.isVirtual() && 
/* 353 */       this.locationsMap.add(location, link)) {
/* 354 */       this.nonDefaultResourceCount++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void buildAliasedProjectsSet() {
/* 361 */     this.aliasedProjects.clear();
/*     */     
/* 363 */     if (this.nonDefaultResourceCount <= 0) {
/*     */       return;
/*     */     }
/* 366 */     this.locationsMap.overLappingResourcesDo(this.aliasedProjects::add);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void buildLocationsMap() {
/* 374 */     this.locationsMap.clear();
/* 375 */     this.nonDefaultResourceCount = 0;
/*     */     
/* 377 */     IProject[] projects = this.workspace.getRoot().getProjects(8); byte b; int i; IProject[] arrayOfIProject1;
/* 378 */     for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/* 379 */       if (project.isAccessible()) {
/* 380 */         addToLocationsMap(project);
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkDeletion(Project project, IFileStore location) throws CoreException {
/* 394 */     if (project.exists() && !location.fetchInfo().exists()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 399 */       Assert.isTrue((this.workspace.getWorkManager().getLock().getDepth() > 0));
/* 400 */       project.deleteResource(false, (MultiStatus)null);
/* 401 */       return true;
/*     */     } 
/* 403 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource[] computeAliases(IResource resource, IFileStore location) {
/* 411 */     if (hasNoAliases(resource)) {
/* 412 */       return null;
/*     */     }
/* 414 */     this.aliases.clear();
/* 415 */     internalComputeAliases(resource, location);
/* 416 */     int size = this.aliases.size();
/* 417 */     if (size == 0)
/* 418 */       return null; 
/* 419 */     return this.aliases.<IResource>toArray(new IResource[size]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource[] findResources(IFileStore location) {
/* 426 */     ArrayList<IResource> resources = new ArrayList<>();
/* 427 */     this.locationsMap.matchingResourcesDo(location, resource -> { 
/* 428 */         }); return resources.<IResource>toArray(new IResource[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void computeDeepAliases(IResource resource, IFileStore location) {
/* 437 */     if (location == null) {
/*     */       return;
/*     */     }
/* 440 */     internalComputeAliases(resource, location);
/*     */     
/* 442 */     this.locationsMap.matchingPrefixDo(location, this.aliases::add);
/*     */     
/* 444 */     if (resource.getType() == 4) {
/*     */       try {
/* 446 */         IResource[] members = ((IProject)resource).members();
/* 447 */         FileSystemResourceManager localManager = this.workspace.getFileSystemManager(); byte b; int i; IResource[] arrayOfIResource1;
/* 448 */         for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource member = arrayOfIResource1[b];
/* 449 */           if (member.isLinked()) {
/* 450 */             IFileStore linkLocation = localManager.getStore(member);
/* 451 */             if (linkLocation != null)
/* 452 */               this.locationsMap.matchingPrefixDo(linkLocation, this.aliases::add); 
/*     */           }  b++; }
/*     */       
/* 455 */       } catch (CoreException coreException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleEvent(LifecycleEvent event) {
/*     */     Resource link;
/* 469 */     switch (event.kind) {
/*     */       case 1024:
/*     */       case 524288:
/* 472 */         link = (Resource)event.resource;
/* 473 */         if (link.isLinked()) {
/* 474 */           removeFromLocationsMap(link, link.getStore());
/*     */         }
/*     */       case 512:
/*     */       case 131072:
/*     */       case 262144:
/* 479 */         this.changedLinks.add(event.resource);
/*     */         break;
/*     */       case 256:
/* 482 */         this.changedLinks.add(event.newResource);
/*     */         break;
/*     */       case 2048:
/* 485 */         link = (Resource)event.resource;
/* 486 */         if (link.isLinked())
/* 487 */           removeFromLocationsMap(link, link.getStore()); 
/* 488 */         this.changedLinks.add(event.newResource);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasNoAliases(IResource resource) {
/*     */     int i;
/* 500 */     IProject project = resource.getProject();
/* 501 */     boolean noAliases = !this.aliasedProjects.contains(project);
/*     */ 
/*     */     
/* 504 */     if (checkStructuralChanges()) {
/* 505 */       i = noAliases & ((this.nonDefaultResourceCount > 0 && this.aliasedProjects.contains(project)) ? 0 : 1);
/*     */     }
/* 507 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void internalComputeAliases(IResource resource, IFileStore location) {
/* 515 */     IFileStore searchLocation = location;
/* 516 */     if (searchLocation == null) {
/* 517 */       searchLocation = ((Resource)resource).getStore();
/*     */     }
/* 519 */     if (searchLocation == null) {
/*     */       return;
/*     */     }
/* 522 */     this.suffix = (IPath)Path.EMPTY;
/* 523 */     FindAliasesDoit findAliases = new FindAliasesDoit(resource);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 530 */       this.locationsMap.matchingResourcesDo(searchLocation, findAliases);
/* 531 */       this.suffix = (new Path(searchLocation.getName())).append(this.suffix);
/* 532 */       searchLocation = searchLocation.getParent();
/* 533 */     } while (searchLocation != null);
/*     */   }
/*     */   
/*     */   private void removeFromLocationsMap(IResource link, IFileStore location) {
/* 537 */     if (location != null && 
/* 538 */       this.locationsMap.remove(location, link)) {
/* 539 */       this.nonDefaultResourceCount--;
/*     */     }
/*     */   }
/*     */   
/*     */   public void resourceChanged(IResourceChangeEvent event) {
/* 544 */     if (this.changedProjects) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 549 */     IResourceDelta delta = event.getDelta();
/* 550 */     if (delta == null) {
/*     */       return;
/*     */     }
/* 553 */     if ((delta.getAffectedChildren(3, 
/* 554 */         8)).length > 0) {
/* 555 */       this.changedProjects = true;
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 561 */     IResourceDelta[] changed = delta.getAffectedChildren(4, 8); byte b; int i; IResourceDelta[] arrayOfIResourceDelta1;
/* 562 */     for (i = (arrayOfIResourceDelta1 = changed).length, b = 0; b < i; ) { IResourceDelta element = arrayOfIResourceDelta1[b];
/* 563 */       if ((element.getFlags() & 0x80000) == 524288 || (element.getFlags() & 0x4000) == 16384) {
/* 564 */         this.changedProjects = true;
/*     */         return;
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public void shutdown(IProgressMonitor monitor) {
/* 572 */     this.workspace.removeResourceChangeListener(this);
/* 573 */     this.locationsMap.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void startup(IProgressMonitor monitor) {
/* 578 */     this.workspace.addLifecycleListener(this);
/* 579 */     this.workspace.addResourceChangeListener(this, 1);
/* 580 */     buildLocationsMap();
/* 581 */     buildAliasedProjectsSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateAliases(IResource resource, IFileStore location, int depth, IProgressMonitor monitor) throws CoreException {
/* 598 */     if (hasNoAliases(resource))
/*     */       return; 
/* 600 */     this.aliases.clear();
/* 601 */     if (depth == 0) {
/* 602 */       internalComputeAliases(resource, location);
/*     */     } else {
/* 604 */       computeDeepAliases(resource, location);
/* 605 */     }  if (this.aliases.isEmpty())
/*     */       return; 
/* 607 */     FileSystemResourceManager localManager = this.workspace.getFileSystemManager();
/* 608 */     HashSet<IResource> aliasesCopy = (HashSet<IResource>)this.aliases.clone();
/* 609 */     for (IResource alias : aliasesCopy) {
/* 610 */       monitor.subTask(NLS.bind(Messages.links_updatingDuplicate, alias.getFullPath()));
/* 611 */       if (alias.getType() == 4 && 
/* 612 */         checkDeletion((Project)alias, location)) {
/*     */         continue;
/*     */       }
/*     */       
/* 616 */       if (!((Resource)alias).isFiltered()) {
/* 617 */         localManager.refresh(alias, 2, false, null);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized boolean checkStructuralChanges() {
/* 636 */     boolean hadChanges = false;
/* 637 */     if (this.changedProjects) {
/*     */       
/* 639 */       this.changedProjects = false;
/* 640 */       this.changedLinks.clear();
/* 641 */       hadChanges = true;
/* 642 */       buildLocationsMap();
/*     */     } else {
/*     */       
/* 645 */       Collection<IResource> changedLinksSnapshots = new HashSet<>(this.changedLinks);
/* 646 */       this.changedLinks.removeAll(changedLinksSnapshots);
/* 647 */       hadChanges = !changedLinksSnapshots.isEmpty();
/* 648 */       for (IResource resource : changedLinksSnapshots) {
/* 649 */         if (resource.isAccessible() && resource.isLinked()) {
/* 650 */           addToLocationsMap(resource, ((Resource)resource).getStore());
/*     */         }
/*     */       } 
/*     */     } 
/* 654 */     if (hadChanges) {
/* 655 */       buildAliasedProjectsSet();
/*     */     }
/* 657 */     return hadChanges;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\AliasManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */