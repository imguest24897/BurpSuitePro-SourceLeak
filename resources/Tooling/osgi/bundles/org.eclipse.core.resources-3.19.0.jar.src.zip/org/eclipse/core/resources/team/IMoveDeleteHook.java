package org.eclipse.core.resources.team;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IMoveDeleteHook {
  boolean deleteFile(IResourceTree paramIResourceTree, IFile paramIFile, int paramInt, IProgressMonitor paramIProgressMonitor);
  
  boolean deleteFolder(IResourceTree paramIResourceTree, IFolder paramIFolder, int paramInt, IProgressMonitor paramIProgressMonitor);
  
  boolean deleteProject(IResourceTree paramIResourceTree, IProject paramIProject, int paramInt, IProgressMonitor paramIProgressMonitor);
  
  boolean moveFile(IResourceTree paramIResourceTree, IFile paramIFile1, IFile paramIFile2, int paramInt, IProgressMonitor paramIProgressMonitor);
  
  boolean moveFolder(IResourceTree paramIResourceTree, IFolder paramIFolder1, IFolder paramIFolder2, int paramInt, IProgressMonitor paramIProgressMonitor);
  
  boolean moveProject(IResourceTree paramIResourceTree, IProject paramIProject, IProjectDescription paramIProjectDescription, int paramInt, IProgressMonitor paramIProgressMonitor);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\team\IMoveDeleteHook.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */