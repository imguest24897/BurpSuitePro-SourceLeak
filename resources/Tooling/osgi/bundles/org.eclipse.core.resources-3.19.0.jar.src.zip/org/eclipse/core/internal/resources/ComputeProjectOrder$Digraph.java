/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Digraph<T>
/*     */ {
/*     */   public static class Vertex<T>
/*     */   {
/*     */     public static final String WHITE = "white";
/*     */     public static final String GREY = "grey";
/*     */     public static final String BLACK = "black";
/*  79 */     public String color = "white";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     public Vertex<T> predecessor = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int finishTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public T id;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     public List<Vertex<T>> adjacent = new ArrayList<>(3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Vertex(T id) {
/* 114 */       this.id = id;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Edge<T> {
/*     */     public final T from;
/*     */     public final T to;
/*     */     
/*     */     public Edge(T from, T to) {
/* 123 */       this.from = from;
/* 124 */       this.to = to;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 129 */       if (!(obj instanceof Edge)) {
/* 130 */         return false;
/*     */       }
/* 132 */       Edge<?> other = (Edge)obj;
/* 133 */       return (Objects.equals(this.from, other.from) && Objects.equals(this.to, other.to));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 138 */       return Objects.hash(new Object[] { this.from, this.to });
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 143 */       return (new StringBuilder()).append(this.from).append(" -> ").append(this.to).toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 153 */   public final List<Vertex<T>> vertexList = new ArrayList<>(100);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   public final Map<T, Vertex<T>> vertexMap = new LinkedHashMap<>(100);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int time;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initialized = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean cycles = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<T> clazz;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Digraph(Class<T> clazz) {
/* 193 */     this.clazz = clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void freeze() {
/* 202 */     if (!this.initialized) {
/* 203 */       this.initialized = true;
/*     */       
/* 205 */       DFS();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addVertex(T id) throws IllegalArgumentException {
/* 219 */     if (this.initialized) {
/* 220 */       throw new IllegalArgumentException();
/*     */     }
/* 222 */     Vertex<T> vertex = new Vertex<>(id);
/* 223 */     Vertex<T> existing = this.vertexMap.put(id, vertex);
/*     */     
/* 225 */     if (existing != null) {
/* 226 */       throw new IllegalArgumentException();
/*     */     }
/* 228 */     this.vertexList.add(vertex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addEdge(T fromId, T toId) throws IllegalArgumentException {
/* 244 */     if (this.initialized) {
/* 245 */       throw new IllegalArgumentException();
/*     */     }
/* 247 */     Vertex<T> fromVertex = this.vertexMap.get(fromId);
/* 248 */     Vertex<T> toVertex = this.vertexMap.get(toId);
/*     */     
/* 250 */     if (fromVertex == null) {
/* 251 */       throw new IllegalArgumentException();
/*     */     }
/* 253 */     if (toVertex == null) {
/* 254 */       throw new IllegalArgumentException();
/*     */     }
/* 256 */     fromVertex.adjacent.add(toVertex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> idsByDFSFinishTime(boolean increasing) {
/* 272 */     if (!this.initialized) {
/* 273 */       throw new IllegalArgumentException();
/*     */     }
/* 275 */     int len = this.vertexList.size();
/*     */     
/* 277 */     Object[] r = (Object[])Array.newInstance(this.clazz, len);
/* 278 */     for (Vertex<T> vertex : this.vertexList) {
/* 279 */       int f = vertex.finishTime;
/*     */       
/* 281 */       if (increasing) {
/* 282 */         r[f - 1] = vertex.id; continue;
/*     */       } 
/* 284 */       r[len - f] = vertex.id;
/*     */     } 
/*     */     
/* 287 */     return Arrays.asList((T[])r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsCycles() {
/* 298 */     if (!this.initialized) {
/* 299 */       throw new IllegalArgumentException();
/*     */     }
/* 301 */     return this.cycles;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T[]> nonTrivialComponents() {
/* 316 */     if (!this.initialized) {
/* 317 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */     
/* 321 */     Map<Vertex<T>, List<T>> components = new LinkedHashMap<>();
/* 322 */     for (Vertex<T> vertex : this.vertexList) {
/* 323 */       if (vertex.predecessor != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 328 */         Vertex<T> root = vertex;
/* 329 */         while (root.predecessor != null) {
/* 330 */           root = root.predecessor;
/*     */         }
/* 332 */         List<T> component = components.get(root);
/* 333 */         if (component == null) {
/* 334 */           component = new ArrayList<>(2);
/* 335 */           component.add(root.id);
/* 336 */           components.put(root, component);
/*     */         } 
/* 338 */         component.add(vertex.id);
/*     */       } 
/*     */     } 
/* 341 */     List<T[]> result = new ArrayList<>(components.size());
/* 342 */     for (List<T> component : components.values()) {
/* 343 */       if (component.size() > 1) {
/* 344 */         result.add(component.toArray((T[])Array.newInstance(this.clazz, component.size())));
/*     */       }
/*     */     } 
/* 347 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void DFS() {
/* 412 */     Integer NEXT_VERTEX_OBJECT = Integer.valueOf(1);
/* 413 */     Integer AFTER_NEXTED_DFS_VISIT_OBJECT = Integer.valueOf(4);
/*     */ 
/*     */ 
/*     */     
/* 417 */     this.time = 0;
/*     */     
/* 419 */     List<Object> stack = new ArrayList(Math.max(1, this.vertexList.size()));
/* 420 */     Iterator<Vertex<T>> allAdjacent = null;
/* 421 */     Vertex<T> vertex = null;
/* 422 */     Iterator<Vertex<T>> allV = this.vertexList.iterator();
/* 423 */     int state = 1; while (true) {
/*     */       Vertex<T> nextVertex;
/* 425 */       switch (state) {
/*     */         
/*     */         case 1:
/* 428 */           if (!allV.hasNext()) {
/*     */             break;
/*     */           }
/*     */           
/* 432 */           nextVertex = allV.next();
/* 433 */           if (nextVertex.color == "white") {
/* 434 */             stack.add(NEXT_VERTEX_OBJECT);
/* 435 */             vertex = nextVertex;
/* 436 */             state = 2;
/*     */             
/*     */             continue;
/*     */           } 
/* 440 */           state = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 2:
/* 446 */           vertex.color = "grey";
/* 447 */           allAdjacent = vertex.adjacent.iterator();
/* 448 */           state = 3;
/*     */ 
/*     */ 
/*     */         
/*     */         case 3:
/* 453 */           if (allAdjacent.hasNext()) {
/* 454 */             Vertex<T> adjVertex = allAdjacent.next();
/* 455 */             if (adjVertex.color == "white") {
/*     */               
/* 457 */               adjVertex.predecessor = vertex;
/* 458 */               stack.add(allAdjacent);
/* 459 */               stack.add(vertex);
/* 460 */               stack.add(AFTER_NEXTED_DFS_VISIT_OBJECT);
/* 461 */               vertex = adjVertex;
/* 462 */               state = 2;
/*     */               continue;
/*     */             } 
/* 465 */             if (adjVertex.color == "grey")
/*     */             {
/* 467 */               this.cycles = true;
/*     */             }
/* 469 */             state = 3;
/*     */             
/*     */             continue;
/*     */           } 
/* 473 */           vertex.color = "black";
/*     */           
/* 475 */           vertex.finishTime = ++this.time;
/* 476 */           state = ((Integer)stack.remove(stack.size() - 1)).intValue();
/*     */ 
/*     */         
/*     */         case 4:
/* 480 */           vertex = (Vertex<T>)stack.remove(stack.size() - 1);
/* 481 */           allAdjacent = (Iterator<Vertex<T>>)stack.remove(stack.size() - 1);
/* 482 */           state = 3;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<Edge<T>> getEdges() {
/* 489 */     int size = 0;
/* 490 */     for (Vertex<T> vertex : this.vertexList) {
/* 491 */       size += vertex.adjacent.size();
/*     */     }
/* 493 */     Collection<Edge<T>> res = new LinkedHashSet<>(size, 1.0F);
/* 494 */     this.vertexList.forEach(vertex -> vertex.adjacent.forEach(()));
/* 495 */     return res;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ComputeProjectOrder$Digraph.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */