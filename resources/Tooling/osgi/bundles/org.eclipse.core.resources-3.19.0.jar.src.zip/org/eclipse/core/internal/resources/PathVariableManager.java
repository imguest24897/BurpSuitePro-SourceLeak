/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.filesystem.URIUtil;
/*     */ import org.eclipse.core.internal.events.PathVariableChangeEvent;
/*     */ import org.eclipse.core.internal.utils.FileUtil;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.resources.IPathVariableChangeEvent;
/*     */ import org.eclipse.core.resources.IPathVariableChangeListener;
/*     */ import org.eclipse.core.resources.IPathVariableManager;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Preferences;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PathVariableManager
/*     */   implements IPathVariableManager, IManager
/*     */ {
/*     */   static final String VARIABLE_PREFIX = "pathvariable.";
/*  43 */   private Set<IPathVariableChangeListener> listeners = Collections.synchronizedSet(new HashSet<>());
/*  44 */   private Map<IProject, Collection<IPathVariableChangeListener>> projectListeners = Collections.synchronizedMap(new HashMap<>());
/*  45 */   private Preferences preferences = ResourcesPlugin.getPlugin().getPluginPreferences();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addChangeListener(IPathVariableChangeListener listener) {
/*  53 */     this.listeners.add(listener);
/*     */   }
/*     */   
/*     */   public synchronized void addChangeListener(IPathVariableChangeListener listener, IProject project) {
/*  57 */     Collection<IPathVariableChangeListener> list = this.projectListeners.get(project);
/*  58 */     if (list == null) {
/*  59 */       list = Collections.synchronizedSet(new HashSet<>());
/*  60 */       this.projectListeners.put(project, list);
/*     */     } 
/*  62 */     list.add(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkIsValidName(String name) throws CoreException {
/*  70 */     IStatus status = validateName(name);
/*  71 */     if (!status.isOK()) {
/*  72 */       throw new CoreException(status);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkIsValidValue(IPath newValue) throws CoreException {
/*  80 */     IStatus status = validateValue(newValue);
/*  81 */     if (!status.isOK()) {
/*  82 */       throw new CoreException(status);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fireVariableChangeEvent(String name, IPath value, int type) {
/* 102 */     fireVariableChangeEvent(this.listeners, name, value, type);
/*     */   }
/*     */   
/*     */   private void fireVariableChangeEvent(Collection<IPathVariableChangeListener> list, String name, IPath value, int type) {
/* 106 */     if (list.isEmpty()) {
/*     */       return;
/*     */     }
/* 109 */     IPathVariableChangeListener[] listenerArray = list.<IPathVariableChangeListener>toArray(new IPathVariableChangeListener[list.size()]);
/* 110 */     final PathVariableChangeEvent pve = new PathVariableChangeEvent(this, name, value, type); byte b; int i; IPathVariableChangeListener[] arrayOfIPathVariableChangeListener1;
/* 111 */     for (i = (arrayOfIPathVariableChangeListener1 = listenerArray).length, b = 0; b < i; ) { final IPathVariableChangeListener listener = arrayOfIPathVariableChangeListener1[b];
/* 112 */       ISafeRunnable job = new ISafeRunnable()
/*     */         {
/*     */           public void handleException(Throwable exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           public void run() throws Exception {
/* 120 */             listener.pathVariableChanged((IPathVariableChangeEvent)pve);
/*     */           }
/*     */         };
/* 123 */       SafeRunner.run(job);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   public void fireVariableChangeEvent(IProject project, String name, IPath value, int type) {
/* 128 */     Collection<IPathVariableChangeListener> list = this.projectListeners.get(project);
/* 129 */     if (list != null) {
/* 130 */       fireVariableChangeEvent(list, name, value, type);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String getKeyForName(String varName) {
/* 137 */     return "pathvariable." + varName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getPathVariableNames() {
/* 145 */     List<String> result = new LinkedList<>();
/* 146 */     String[] names = this.preferences.propertyNames(); byte b; int i; String[] arrayOfString1;
/* 147 */     for (i = (arrayOfString1 = names).length, b = 0; b < i; ) { String name = arrayOfString1[b];
/* 148 */       if (name.startsWith("pathvariable.")) {
/* 149 */         String key = name.substring("pathvariable.".length());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 157 */         if (validateName(key).isOK() && validateValue(getValue(key)).isOK())
/* 158 */           result.add(key); 
/*     */       }  b++; }
/*     */     
/* 161 */     return result.<String>toArray(new String[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IPath getValue(String varName) {
/* 175 */     String key = getKeyForName(varName);
/* 176 */     String value = this.preferences.getString(key);
/* 177 */     return (value.length() == 0) ? null : Path.fromPortableString(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefined(String varName) {
/* 185 */     return (getValue(varName) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeChangeListener(IPathVariableChangeListener listener) {
/* 193 */     this.listeners.remove(listener);
/*     */   }
/*     */   
/*     */   public synchronized void removeChangeListener(IPathVariableChangeListener listener, IProject project) {
/* 197 */     Collection<IPathVariableChangeListener> list = this.projectListeners.get(project);
/* 198 */     if (list != null) {
/* 199 */       list.remove(listener);
/* 200 */       if (list.isEmpty()) {
/* 201 */         this.projectListeners.remove(project);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IPath resolvePath(IPath path) {
/* 211 */     if (path == null || path.segmentCount() == 0 || path.isAbsolute() || path.getDevice() != null)
/* 212 */       return path; 
/* 213 */     IPath value = getValue(path.segment(0));
/* 214 */     return (value == null) ? path : value.append(path.removeFirstSegments(1));
/*     */   }
/*     */ 
/*     */   
/*     */   public URI resolveURI(URI uri) {
/* 219 */     if (uri == null || uri.isAbsolute())
/* 220 */       return uri; 
/* 221 */     String schemeSpecificPart = uri.getSchemeSpecificPart();
/* 222 */     if (schemeSpecificPart == null || schemeSpecificPart.isEmpty()) {
/* 223 */       return uri;
/*     */     }
/* 225 */     Path path = new Path(schemeSpecificPart);
/* 226 */     IPath resolved = resolvePath((IPath)path);
/* 227 */     return (path == resolved) ? uri : URIUtil.toURI(resolved);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String varName, IPath newValue) throws CoreException {
/*     */     int eventType;
/* 235 */     checkIsValidName(varName);
/*     */     
/* 237 */     if (newValue != null && newValue.isAbsolute())
/* 238 */       newValue = FileUtil.canonicalPath(newValue); 
/* 239 */     checkIsValidValue(newValue);
/*     */ 
/*     */     
/* 242 */     synchronized (this) {
/* 243 */       IPath currentValue = getValue(varName);
/* 244 */       boolean variableExists = (currentValue != null);
/* 245 */       if (!variableExists && newValue == null)
/*     */         return; 
/* 247 */       if (variableExists && currentValue.equals(newValue))
/*     */         return; 
/* 249 */       if (newValue == null) {
/* 250 */         this.preferences.setToDefault(getKeyForName(varName));
/* 251 */         eventType = 3;
/*     */       } else {
/* 253 */         this.preferences.setValue(getKeyForName(varName), newValue.toPortableString());
/* 254 */         eventType = variableExists ? 1 : 2;
/*     */       } 
/*     */     } 
/*     */     
/* 258 */     fireVariableChangeEvent(varName, newValue, eventType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown(IProgressMonitor monitor) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startup(IProgressMonitor monitor) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateName(String name) {
/* 284 */     String message = null;
/* 285 */     if (name.length() == 0) {
/* 286 */       message = Messages.pathvar_length;
/* 287 */       return (IStatus)new ResourceStatus(77, null, message);
/*     */     } 
/*     */     
/* 290 */     char first = name.charAt(0);
/* 291 */     if (!Character.isLetter(first) && first != '_') {
/* 292 */       message = NLS.bind(Messages.pathvar_beginLetter, String.valueOf(first));
/* 293 */       return (IStatus)new ResourceStatus(77, null, message);
/*     */     } 
/*     */     
/* 296 */     for (int i = 1; i < name.length(); i++) {
/* 297 */       char following = name.charAt(i);
/* 298 */       if (Character.isWhitespace(following))
/* 299 */         return (IStatus)new ResourceStatus(77, null, Messages.pathvar_whitespace); 
/* 300 */       if (!Character.isLetter(following) && !Character.isDigit(following) && following != '_') {
/* 301 */         message = NLS.bind(Messages.pathvar_invalidChar, String.valueOf(following));
/* 302 */         return (IStatus)new ResourceStatus(77, null, message);
/*     */       } 
/*     */     } 
/* 305 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateValue(IPath value) {
/* 313 */     if (value != null && (!value.isValidPath(value.toString()) || !value.isAbsolute())) {
/* 314 */       String message = Messages.pathvar_invalidValue;
/* 315 */       return (IStatus)new ResourceStatus(77, null, message);
/*     */     } 
/* 317 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URI convertToRelative(URI path, boolean force, String variableHint) throws CoreException {
/* 325 */     return PathVariableUtil.convertToRelative(this, path, (IResource)null, false, variableHint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URI getURIValue(String name) {
/* 333 */     IPath path = getValue(name);
/* 334 */     if (path != null)
/* 335 */       return URIUtil.toURI(path); 
/* 336 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setURIValue(String name, URI value) throws CoreException {
/* 344 */     setValue(name, (value != null) ? URIUtil.toPath(value) : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateValue(URI path) {
/* 352 */     return validateValue((path != null) ? URIUtil.toPath(path) : null);
/*     */   }
/*     */   
/*     */   public URI resolveURI(URI uri, IResource resource) {
/* 356 */     return resolveURI(uri);
/*     */   }
/*     */   
/*     */   public String[] getPathVariableNames(IResource resource) {
/* 360 */     return getPathVariableNames();
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getVariableRelativePathLocation(URI location) {
/*     */     try {
/* 366 */       URI result = convertToRelative(location, false, null);
/* 367 */       if (!result.equals(location))
/* 368 */         return result; 
/* 369 */     } catch (CoreException coreException) {}
/*     */ 
/*     */     
/* 372 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String convertToUserEditableFormat(String value, boolean locationFormat) {
/* 380 */     return PathVariableUtil.convertToUserEditableFormatInternal(value, locationFormat);
/*     */   }
/*     */ 
/*     */   
/*     */   public String convertFromUserEditableFormat(String userFormat, boolean locationFormat) {
/* 385 */     return PathVariableUtil.convertFromUserEditableFormatInternal(this, userFormat, locationFormat);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUserDefined(String name) {
/* 390 */     return (ProjectVariableProviderManager.getDefault().findDescriptor(name) == null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\PathVariableManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */