/*     */ package org.eclipse.core.internal.refresh;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.ICoreRunnable;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.core.runtime.jobs.MultiRule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MonitorJob
/*     */   extends Job
/*     */ {
/*     */   private final ICoreRunnable runnable;
/*     */   
/*     */   private MonitorJob(String name, MonitorRule rule, ICoreRunnable runnable) {
/*  37 */     super(name);
/*  38 */     this.runnable = runnable;
/*  39 */     setSystem(true);
/*  40 */     setRule(rule);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Job createSystem(String name, IResource resource, ICoreRunnable runnable) {
/*  52 */     return new MonitorJob(name, MonitorRule.create(resource), runnable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Job createSystem(String name, Collection<IResource> resources, ICoreRunnable runnable) {
/*  64 */     return new MonitorJob(name, MonitorRule.create(resources), runnable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MonitorRule
/*     */     implements ISchedulingRule
/*     */   {
/*  74 */     private static final ISchedulingRule[] SCHEDULING_RULE__EMPTY_ARR = new ISchedulingRule[0];
/*     */     
/*     */     private final ISchedulingRule resourceRule;
/*     */     
/*     */     MonitorRule(ISchedulingRule schedulingRule) {
/*  79 */       this.resourceRule = schedulingRule;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static MonitorRule create(IResource resource) {
/*  90 */       return new MonitorRule((ISchedulingRule)resource);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static MonitorRule create(Collection<IResource> resources) {
/* 101 */       return new MonitorRule(MultiRule.combine(resources.<ISchedulingRule>toArray(SCHEDULING_RULE__EMPTY_ARR)));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isConflicting(ISchedulingRule rule) {
/* 106 */       if (rule instanceof MonitorRule) {
/* 107 */         return this.resourceRule.isConflicting(((MonitorRule)rule).resourceRule);
/*     */       }
/* 109 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(ISchedulingRule rule) {
/* 114 */       if (rule instanceof MonitorRule) {
/* 115 */         return this.resourceRule.contains(((MonitorRule)rule).resourceRule);
/*     */       }
/* 117 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected IStatus run(IProgressMonitor monitor) {
/*     */     try {
/* 124 */       this.runnable.run(monitor);
/* 125 */     } catch (CoreException e) {
/* 126 */       IStatus st = e.getStatus();
/* 127 */       return (IStatus)new Status(st.getSeverity(), st.getPlugin(), st.getCode(), st.getMessage(), (Throwable)e);
/*     */     } 
/* 129 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean belongsTo(Object family) {
/* 134 */     return (ResourcesPlugin.FAMILY_AUTO_REFRESH == family);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\refresh\MonitorJob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */