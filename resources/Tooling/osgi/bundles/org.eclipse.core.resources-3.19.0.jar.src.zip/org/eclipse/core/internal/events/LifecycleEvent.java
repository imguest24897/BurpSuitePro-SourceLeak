/*    */ package org.eclipse.core.internal.events;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LifecycleEvent
/*    */ {
/*    */   public static final int PRE_PROJECT_CLOSE = 1;
/*    */   public static final int POST_PROJECT_CHANGE = 2;
/*    */   public static final int PRE_PROJECT_COPY = 4;
/*    */   public static final int PRE_PROJECT_CREATE = 8;
/*    */   public static final int PRE_PROJECT_DELETE = 16;
/*    */   public static final int PRE_PROJECT_OPEN = 32;
/*    */   public static final int PRE_PROJECT_MOVE = 64;
/*    */   public static final int PRE_LINK_COPY = 256;
/*    */   public static final int PRE_LINK_CREATE = 512;
/*    */   public static final int PRE_LINK_DELETE = 1024;
/*    */   public static final int PRE_LINK_MOVE = 2048;
/*    */   public static final int PRE_REFRESH = 4096;
/*    */   public static final int PRE_GROUP_COPY = 8192;
/*    */   public static final int PRE_GROUP_CREATE = 16384;
/*    */   public static final int PRE_GROUP_DELETE = 32768;
/*    */   public static final int PRE_GROUP_MOVE = 65536;
/*    */   public static final int PRE_FILTER_ADD = 131072;
/*    */   public static final int PRE_FILTER_REMOVE = 262144;
/*    */   public static final int PRE_LINK_CHANGE = 524288;
/*    */   public int kind;
/*    */   public IResource resource;
/*    */   public IResource newResource;
/*    */   public int updateFlags;
/* 73 */   private static final LifecycleEvent instance = new LifecycleEvent();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static LifecycleEvent newEvent(int kind, IResource resource) {
/* 80 */     instance.kind = kind;
/* 81 */     instance.resource = resource;
/* 82 */     instance.newResource = null;
/* 83 */     instance.updateFlags = 0;
/* 84 */     return instance;
/*    */   }
/*    */   
/*    */   public static LifecycleEvent newEvent(int kind, IResource oldResource, IResource newResource, int updateFlags) {
/* 88 */     instance.kind = kind;
/* 89 */     instance.resource = oldResource;
/* 90 */     instance.newResource = newResource;
/* 91 */     instance.updateFlags = updateFlags;
/* 92 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\LifecycleEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */