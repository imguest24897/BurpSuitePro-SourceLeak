/*     */ package org.eclipse.core.internal.dtree;
/*     */ 
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDataTree
/*     */ {
/*     */   private boolean immutable = false;
/*  38 */   protected static final IPath[] NO_CHILDREN = new IPath[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract AbstractDataTreeNode copyCompleteSubtree(IPath paramIPath);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void createChild(IPath paramIPath, String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void createChild(IPath paramIPath, String paramString, Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void createSubtree(IPath paramIPath, AbstractDataTreeNode paramAbstractDataTreeNode);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void deleteChild(IPath paramIPath, String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getChild(IPath parentKey, int index) {
/* 111 */     String child = getNameOfChild(parentKey, index);
/* 112 */     return parentKey.append(child);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract int getChildCount(IPath paramIPath);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract IPath[] getChildren(IPath paramIPath);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Object getData(IPath paramIPath);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract String getNameOfChild(IPath paramIPath, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String[] getNamesOfChildren(IPath paramIPath);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void handleImmutableTree() {
/* 169 */     throw new RuntimeException(Messages.dtree_immutable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void handleNotFound(IPath key) {
/* 178 */     throw new ObjectNotFoundException(NLS.bind(Messages.dtree_notFound, key));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void immutable() {
/* 185 */     this.immutable = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean includes(IPath paramIPath);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isImmutable() {
/* 201 */     return this.immutable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract DataTreeLookup lookup(IPath paramIPath);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final IPath rootKey() {
/* 217 */     return (IPath)Path.ROOT;
/*     */   }
/*     */   
/*     */   public boolean isRoot(IPath key) {
/* 221 */     return (key == rootKey());
/*     */   }
/*     */   
/* 224 */   private static final IPath[] ROOT_PATHS = new IPath[] { rootKey() };
/*     */   
/*     */   public IPath[] rootPaths() {
/* 227 */     return ROOT_PATHS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setData(IPath paramIPath, Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setImmutable(boolean bool) {
/* 248 */     this.immutable = bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setRootNode(AbstractDataTreeNode node) {
/* 259 */     throw new Error(Messages.dtree_subclassImplement);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\dtree\AbstractDataTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */