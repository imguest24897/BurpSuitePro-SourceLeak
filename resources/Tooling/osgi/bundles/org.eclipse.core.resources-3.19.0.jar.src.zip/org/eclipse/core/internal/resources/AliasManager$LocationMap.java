/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Map;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import java.util.function.Consumer;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LocationMap
/*     */ {
/* 117 */   private final SortedMap<IFileStore, Object> map = new TreeMap<>(IFileStore::compareTo);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(IFileStore location, IResource resource) {
/* 124 */     Object oldValue = this.map.get(location);
/* 125 */     if (oldValue == null) {
/* 126 */       this.map.put(location, resource);
/* 127 */       return true;
/*     */     } 
/* 129 */     if (oldValue instanceof IResource) {
/* 130 */       if (resource.equals(oldValue))
/* 131 */         return false; 
/* 132 */       ArrayList<Object> newValue = new ArrayList(2);
/* 133 */       newValue.add(oldValue);
/* 134 */       newValue.add(resource);
/* 135 */       this.map.put(location, newValue);
/* 136 */       return true;
/*     */     } 
/*     */     
/* 139 */     ArrayList<IResource> list = (ArrayList<IResource>)oldValue;
/* 140 */     if (list.contains(resource))
/* 141 */       return false; 
/* 142 */     list.add(resource);
/* 143 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 150 */     this.map.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void matchingPrefixDo(IFileStore prefix, Consumer<IResource> doit) {
/*     */     SortedMap<IFileStore, Object> matching;
/* 159 */     IFileStore prefixParent = prefix.getParent();
/* 160 */     if (prefixParent != null) {
/*     */ 
/*     */       
/* 163 */       IFileStore endPoint = prefixParent.getChild(String.valueOf(prefix.getName()) + "\000");
/* 164 */       matching = this.map.subMap(prefix, endPoint);
/*     */     } else {
/* 166 */       matching = this.map;
/*     */     } 
/* 168 */     for (Object value : matching.values()) {
/* 169 */       if (value == null)
/*     */         return; 
/* 171 */       if (value instanceof java.util.List) {
/* 172 */         for (Object element : value) {
/* 173 */           if (element instanceof IResource)
/* 174 */             doit.accept((IResource)element); 
/*     */         } 
/*     */         continue;
/*     */       } 
/* 178 */       doit.accept((IResource)value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void matchingResourcesDo(IFileStore location, Consumer<IResource> doit) {
/* 188 */     Object value = this.map.get(location);
/* 189 */     if (value == null)
/*     */       return; 
/* 191 */     if (value instanceof java.util.List) {
/* 192 */       for (Object element : value) {
/* 193 */         if (element instanceof IResource) {
/* 194 */           doit.accept((IResource)element);
/*     */         }
/*     */       } 
/*     */     } else {
/* 198 */       doit.accept((IResource)value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void overLappingResourcesDo(Consumer<IResource> doit) {
/* 207 */     IFileStore previousStore = null;
/* 208 */     IResource previousResource = null;
/* 209 */     for (Map.Entry<IFileStore, Object> current : this.map.entrySet()) {
/*     */       
/* 211 */       IFileStore currentStore = current.getKey();
/* 212 */       IResource currentResource = null;
/* 213 */       Object value = current.getValue();
/* 214 */       if (value instanceof java.util.List) {
/* 215 */         for (Object element : value) {
/* 216 */           if (element instanceof IResource) {
/* 217 */             doit.accept(((IResource)element).getProject());
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 222 */         currentResource = (IResource)value;
/*     */       } 
/* 224 */       if (previousStore != null)
/*     */       {
/*     */         
/* 227 */         if (previousStore.isParentOf(currentStore)) {
/*     */ 
/*     */           
/* 230 */           if (previousResource != null) {
/* 231 */             doit.accept(previousResource.getProject());
/*     */             
/* 233 */             previousResource = null;
/*     */           } 
/* 235 */           if (currentResource != null) {
/* 236 */             doit.accept(currentResource.getProject());
/*     */           }
/*     */           continue;
/*     */         } 
/*     */       }
/* 241 */       previousStore = currentStore;
/* 242 */       previousResource = currentResource;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean remove(IFileStore location, IResource resource) {
/* 251 */     Object oldValue = this.map.get(location);
/* 252 */     if (oldValue == null)
/* 253 */       return false; 
/* 254 */     if (oldValue instanceof IResource) {
/* 255 */       if (resource.equals(oldValue)) {
/* 256 */         this.map.remove(location);
/* 257 */         return true;
/*     */       } 
/* 259 */       return false;
/*     */     } 
/*     */     
/* 262 */     ArrayList<IResource> list = (ArrayList<IResource>)oldValue;
/* 263 */     boolean wasRemoved = list.remove(resource);
/* 264 */     if (list.isEmpty())
/* 265 */       this.map.remove(location); 
/* 266 */     return wasRemoved;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\AliasManager$LocationMap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */