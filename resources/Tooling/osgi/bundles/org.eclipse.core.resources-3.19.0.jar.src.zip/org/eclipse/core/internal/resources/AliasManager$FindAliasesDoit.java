/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FindAliasesDoit
/*     */   implements Consumer<IResource>
/*     */ {
/*     */   private final int aliasType;
/*     */   private final IPath searchPath;
/*     */   
/*     */   public FindAliasesDoit(IResource aliasResource) {
/*  67 */     this.aliasType = aliasResource.getType();
/*  68 */     this.searchPath = aliasResource.getFullPath();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(IResource match) {
/*  74 */     if (match.getFullPath().isPrefixOf(this.searchPath))
/*     */       return; 
/*  76 */     IPath aliasPath = null;
/*  77 */     switch (match.getType()) {
/*     */       
/*     */       case 4:
/*  80 */         if (AliasManager.this.suffix.segmentCount() > 0) {
/*  81 */           IResource testResource = ((IProject)match).findMember(AliasManager.this.suffix.segment(0));
/*  82 */           if (testResource != null && testResource.isLinked()) {
/*     */             return;
/*     */           }
/*     */         } 
/*  86 */         aliasPath = match.getFullPath().append(AliasManager.this.suffix);
/*     */         break;
/*     */       case 2:
/*  89 */         aliasPath = match.getFullPath().append(AliasManager.this.suffix);
/*     */         break;
/*     */       case 1:
/*  92 */         if (AliasManager.this.suffix.segmentCount() == 0)
/*  93 */           aliasPath = match.getFullPath(); 
/*     */         break;
/*     */     } 
/*  96 */     if (aliasPath != null)
/*  97 */       if (this.aliasType == 1) {
/*  98 */         AliasManager.this.aliases.add(AliasManager.this.workspace.getRoot().getFile(aliasPath));
/*     */       }
/* 100 */       else if (aliasPath.segmentCount() == 1) {
/* 101 */         AliasManager.this.aliases.add(AliasManager.this.workspace.getRoot().getProject(aliasPath.lastSegment()));
/*     */       } else {
/* 103 */         AliasManager.this.aliases.add(AliasManager.this.workspace.getRoot().getFolder(aliasPath));
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\AliasManager$FindAliasesDoit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */