/*    */ package org.eclipse.core.resources.variableresolvers;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PathVariableResolver
/*    */ {
/*    */   public String[] getVariableNames(String variable, IResource resource) {
/* 42 */     return null;
/*    */   }
/*    */   
/*    */   public abstract String getValue(String paramString, IResource paramIResource);
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\variableresolvers\PathVariableResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */