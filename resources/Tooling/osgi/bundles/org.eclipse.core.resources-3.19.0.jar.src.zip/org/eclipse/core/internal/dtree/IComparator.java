package org.eclipse.core.internal.dtree;

public interface IComparator {
  int compare(Object paramObject1, Object paramObject2);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\dtree\IComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */