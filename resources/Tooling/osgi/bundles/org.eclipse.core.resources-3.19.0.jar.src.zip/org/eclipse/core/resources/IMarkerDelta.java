package org.eclipse.core.resources;

import java.util.Map;

public interface IMarkerDelta {
  Object getAttribute(String paramString);
  
  int getAttribute(String paramString, int paramInt);
  
  String getAttribute(String paramString1, String paramString2);
  
  boolean getAttribute(String paramString, boolean paramBoolean);
  
  Map<String, Object> getAttributes();
  
  Object[] getAttributes(String[] paramArrayOfString);
  
  long getId();
  
  int getKind();
  
  IMarker getMarker();
  
  IResource getResource();
  
  String getType();
  
  boolean isSubtypeOf(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IMarkerDelta.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */