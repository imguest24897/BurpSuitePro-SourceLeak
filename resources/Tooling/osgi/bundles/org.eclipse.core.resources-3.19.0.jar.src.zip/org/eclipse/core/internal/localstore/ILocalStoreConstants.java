/*    */ package org.eclipse.core.internal.localstore;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ILocalStoreConstants
/*    */ {
/*    */   public static final int SIZE_LASTMODIFIED = 8;
/*    */   public static final int SIZE_COUNTER = 1;
/*    */   public static final int SIZE_KEY_SUFFIX = 9;
/* 26 */   public static final byte[] BEGIN_CHUNK = new byte[] { 64, -79, -117, -127, 35, -68, 20, 26, 37, -106, -25, -93, -109, -66, 30 };
/*    */ 
/*    */   
/* 29 */   public static final byte[] END_CHUNK = new byte[] { -64, 88, -5, -13, 35, -68, 20, 26, 81, -13, -116, 123, -69, 119, -58 };
/*    */ 
/*    */ 
/*    */   
/* 33 */   public static final int CHUNK_DELIMITER_SIZE = BEGIN_CHUNK.length;
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\ILocalStoreConstants.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */