/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import org.eclipse.core.filesystem.URIUtil;
/*     */ import org.eclipse.core.internal.resources.projectvariables.ProjectLocationVariableResolver;
/*     */ import org.eclipse.core.internal.resources.projectvariables.WorkspaceLocationVariableResolver;
/*     */ import org.eclipse.core.internal.resources.projectvariables.WorkspaceParentLocationVariableResolver;
/*     */ import org.eclipse.core.resources.IPathVariableManager;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PathVariableUtil
/*     */ {
/*     */   public static String getUniqueVariableName(String variable, IResource resource) {
/*  31 */     int index = 1;
/*  32 */     variable = getValidVariableName(variable);
/*  33 */     StringBuilder destVariable = new StringBuilder(variable);
/*     */     
/*  35 */     IPathVariableManager pathVariableManager = resource.getPathVariableManager();
/*  36 */     if (variable.startsWith("PARENT") || variable.startsWith(ProjectLocationVariableResolver.NAME)) {
/*  37 */       destVariable.insert(0, "copy_");
/*     */     }
/*  39 */     while (pathVariableManager.isDefined(destVariable.toString())) {
/*  40 */       destVariable.append(index);
/*  41 */       index++;
/*     */     } 
/*  43 */     return destVariable.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getValidVariableName(String variable) {
/*  48 */     int argumentIndex = variable.indexOf('-');
/*  49 */     if (argumentIndex != -1) {
/*  50 */       variable = variable.substring(0, argumentIndex);
/*     */     }
/*  52 */     variable = variable.trim();
/*  53 */     char first = variable.charAt(0);
/*  54 */     if (!Character.isLetter(first) && first != '_') {
/*  55 */       variable = String.valueOf('A') + variable;
/*     */     }
/*     */     
/*  58 */     StringBuilder builder = new StringBuilder();
/*  59 */     for (int i = 0; i < variable.length(); i++) {
/*  60 */       char c = variable.charAt(i);
/*  61 */       if ((Character.isLetter(c) || Character.isDigit(c) || c == '_') && !Character.isWhitespace(c))
/*  62 */         builder.append(c); 
/*     */     } 
/*  64 */     variable = builder.toString();
/*  65 */     return variable;
/*     */   }
/*     */   
/*     */   public static IPath convertToPathRelativeMacro(IPathVariableManager pathVariableManager, IPath originalPath, IResource resource, boolean force, String variableHint) throws CoreException {
/*  69 */     return convertToRelative(pathVariableManager, originalPath, resource, force, variableHint, true, true);
/*     */   }
/*     */   
/*     */   public static IPath convertToRelative(IPathVariableManager pathVariableManager, IPath originalPath, IResource resource, boolean force, String variableHint) throws CoreException {
/*  73 */     return convertToRelative(pathVariableManager, originalPath, resource, force, variableHint, true, false);
/*     */   }
/*     */   
/*     */   public static URI convertToRelative(IPathVariableManager pathVariableManager, URI originalPath, IResource resource, boolean force, String variableHint) throws CoreException {
/*  77 */     return URIUtil.toURI(convertToRelative(pathVariableManager, URIUtil.toPath(originalPath), resource, force, variableHint, true, false));
/*     */   }
/*     */   
/*     */   public static URI convertToRelative(IPathVariableManager pathVariableManager, URI originalPath, IResource resource, boolean force, String variableHint, boolean skipWorkspace, boolean generateMacro) throws CoreException {
/*  81 */     return URIUtil.toURI(convertToRelative(pathVariableManager, URIUtil.toPath(originalPath), resource, force, variableHint));
/*     */   }
/*     */   
/*     */   private static IPath convertToRelative(IPathVariableManager pathVariableManager, IPath originalPath, IResource resource, boolean force, String variableHint, boolean skipWorkspace, boolean generateMacro) throws CoreException {
/*  85 */     if (variableHint != null && pathVariableManager.isDefined(variableHint)) {
/*  86 */       IPath value = URIUtil.toPath(pathVariableManager.getURIValue(variableHint));
/*  87 */       if (value != null)
/*  88 */         return wrapInProperFormat(makeRelativeToVariable(pathVariableManager, originalPath, force, variableHint), generateMacro); 
/*     */     } 
/*  90 */     IPath path = convertToProperCase(originalPath);
/*  91 */     IPath newPath = null;
/*  92 */     int maxMatchLength = -1;
/*  93 */     String[] existingVariables = pathVariableManager.getPathVariableNames(); byte b; int i; String[] arrayOfString1;
/*  94 */     for (i = (arrayOfString1 = existingVariables).length, b = 0; b < i; ) { String variable = arrayOfString1[b];
/*  95 */       if (skipWorkspace)
/*     */       {
/*     */         
/*  98 */         if (variable.equals(WorkspaceLocationVariableResolver.NAME))
/*     */           continue; 
/*     */       }
/* 101 */       if (!variable.equals(WorkspaceParentLocationVariableResolver.NAME))
/*     */       {
/* 103 */         if (!variable.equals("PARENT")) {
/*     */ 
/*     */           
/* 106 */           IPath value = URIUtil.toPath(pathVariableManager.getURIValue(variable));
/* 107 */           if (value != null) {
/* 108 */             value = convertToProperCase(URIUtil.toPath(pathVariableManager.resolveURI(URIUtil.toURI(value))));
/* 109 */             if (value.isPrefixOf(path)) {
/* 110 */               int matchLength = value.segmentCount();
/* 111 */               if (matchLength > maxMatchLength) {
/* 112 */                 maxMatchLength = matchLength;
/* 113 */                 newPath = makeRelativeToVariable(pathVariableManager, originalPath, force, variable);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         }  }  continue; b++; }
/* 118 */      if (newPath != null) {
/* 119 */       return wrapInProperFormat(newPath, generateMacro);
/*     */     }
/* 121 */     if (force) {
/* 122 */       int originalSegmentCount = originalPath.segmentCount();
/* 123 */       for (int j = 0; j <= originalSegmentCount; j++) {
/* 124 */         IPath matchingPath = path.removeLastSegments(j);
/* 125 */         int minDifference = Integer.MAX_VALUE; byte b1; int k; String[] arrayOfString;
/* 126 */         for (k = (arrayOfString = existingVariables).length, b1 = 0; b1 < k; ) { String variable = arrayOfString[b1];
/* 127 */           if (!skipWorkspace || 
/* 128 */             !variable.equals(WorkspaceLocationVariableResolver.NAME))
/*     */           {
/*     */             
/* 131 */             if (!variable.equals(WorkspaceParentLocationVariableResolver.NAME))
/*     */             {
/* 133 */               if (!variable.equals("PARENT")) {
/*     */                 
/* 135 */                 IPath value = URIUtil.toPath(pathVariableManager.getURIValue(variable));
/* 136 */                 if (value != null) {
/* 137 */                   value = convertToProperCase(URIUtil.toPath(pathVariableManager.resolveURI(URIUtil.toURI(value))));
/* 138 */                   if (matchingPath.isPrefixOf(value)) {
/* 139 */                     int difference = value.segmentCount() - originalSegmentCount;
/* 140 */                     if (difference < minDifference) {
/* 141 */                       minDifference = difference;
/* 142 */                       newPath = makeRelativeToVariable(pathVariableManager, originalPath, force, variable);
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */               }  }  }  b1++; }
/* 147 */          if (newPath != null)
/* 148 */           return wrapInProperFormat(newPath, generateMacro); 
/*     */       } 
/* 150 */       if (originalSegmentCount == 0) {
/* 151 */         String variable = ProjectLocationVariableResolver.NAME;
/* 152 */         IPath value = URIUtil.toPath(pathVariableManager.getURIValue(variable));
/* 153 */         value = convertToProperCase(URIUtil.toPath(pathVariableManager.resolveURI(URIUtil.toURI(value))));
/* 154 */         if (originalPath.isPrefixOf(value))
/* 155 */           newPath = makeRelativeToVariable(pathVariableManager, originalPath, force, variable); 
/* 156 */         if (newPath != null) {
/* 157 */           return wrapInProperFormat(newPath, generateMacro);
/*     */         }
/*     */       } 
/*     */     } 
/* 161 */     if (skipWorkspace)
/* 162 */       return convertToRelative(pathVariableManager, originalPath, resource, force, variableHint, false, generateMacro); 
/* 163 */     return originalPath;
/*     */   }
/*     */   
/*     */   private static IPath wrapInProperFormat(IPath newPath, boolean generateMacro) {
/* 167 */     if (generateMacro)
/* 168 */       newPath = buildVariableMacro(newPath); 
/* 169 */     return newPath;
/*     */   }
/*     */   
/*     */   private static IPath makeRelativeToVariable(IPathVariableManager pathVariableManager, IPath originalPath, boolean force, String variableHint) {
/* 173 */     IPath path = convertToProperCase(originalPath);
/* 174 */     IPath value = URIUtil.toPath(pathVariableManager.getURIValue(variableHint));
/* 175 */     value = convertToProperCase(URIUtil.toPath(pathVariableManager.resolveURI(URIUtil.toURI(value))));
/* 176 */     int valueSegmentCount = value.segmentCount();
/* 177 */     if (value.isPrefixOf(path)) {
/*     */       
/* 179 */       IPath tmp = Path.fromOSString(variableHint);
/* 180 */       for (int j = valueSegmentCount; j < originalPath.segmentCount(); j++) {
/* 181 */         tmp = tmp.append(originalPath.segment(j));
/*     */       }
/* 183 */       return tmp;
/*     */     } 
/*     */     
/* 186 */     if (force && 
/* 187 */       devicesAreCompatible(path, value)) {
/*     */       
/* 189 */       int matchingFirstSegments = path.matchingFirstSegments(value);
/* 190 */       if (matchingFirstSegments >= 0) {
/* 191 */         String originalName = buildParentPathVariable(variableHint, valueSegmentCount - matchingFirstSegments, true);
/* 192 */         IPath tmp = Path.fromOSString(originalName);
/* 193 */         for (int j = matchingFirstSegments; j < originalPath.segmentCount(); j++) {
/* 194 */           tmp = tmp.append(originalPath.segment(j));
/*     */         }
/* 196 */         return tmp;
/*     */       } 
/*     */     } 
/*     */     
/* 200 */     return originalPath;
/*     */   }
/*     */   
/*     */   private static boolean devicesAreCompatible(IPath path, IPath value) {
/* 204 */     return (path.getDevice() != null && value.getDevice() != null) ? path.getDevice().equals(value.getDevice()) : ((path.getDevice() == value.getDevice()));
/*     */   }
/*     */   
/*     */   private static IPath convertToProperCase(IPath path) {
/* 208 */     if (Platform.getOS().equals("win32"))
/* 209 */       return Path.fromPortableString(path.toPortableString().toLowerCase()); 
/* 210 */     return path;
/*     */   }
/*     */   
/*     */   public static boolean isParentVariable(String variableString) {
/* 214 */     return variableString.startsWith("PARENT-");
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getParentVariableCount(String variableString) {
/* 219 */     String[] items = variableString.split("-");
/* 220 */     if (items.length == 3) {
/*     */       try {
/* 222 */         int count = Integer.parseInt(items[1]);
/* 223 */         return count;
/* 224 */       } catch (NumberFormatException numberFormatException) {}
/*     */     }
/*     */ 
/*     */     
/* 228 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getParentVariableArgument(String variableString) {
/* 233 */     String[] items = variableString.split("-");
/* 234 */     if (items.length == 3)
/* 235 */       return items[2]; 
/* 236 */     return null;
/*     */   }
/*     */   
/*     */   public static String buildParentPathVariable(String variable, int difference, boolean generateMacro) {
/* 240 */     String newString = "PARENT-" + difference + "-" + variable;
/*     */     
/* 242 */     if (!generateMacro)
/* 243 */       newString = "${" + newString + "}"; 
/* 244 */     return newString;
/*     */   }
/*     */   
/*     */   public static IPath buildVariableMacro(IPath relativeSrcValue) {
/* 248 */     String variable = relativeSrcValue.segment(0);
/* 249 */     variable = "${" + variable + "}";
/* 250 */     return Path.fromOSString(variable).append(relativeSrcValue.removeFirstSegments(1));
/*     */   }
/*     */   
/*     */   public static String convertFromUserEditableFormatInternal(IPathVariableManager manager, String userFormat, boolean locationFormat) {
/* 254 */     char pathPrefix = Character.MIN_VALUE;
/* 255 */     if (userFormat.length() > 0 && (userFormat.charAt(0) == '/' || userFormat.charAt(0) == '\\'))
/* 256 */       pathPrefix = userFormat.charAt(0); 
/* 257 */     String[] components = splitPathComponents(userFormat);
/* 258 */     for (int i = 0; i < components.length; i++) {
/* 259 */       if (components[i] != null)
/*     */       {
/* 261 */         if (isDotDot(components[i])) {
/* 262 */           int parentCount = 1;
/* 263 */           components[i] = null; int k;
/* 264 */           for (k = i + 1; k < components.length; k++) {
/* 265 */             if (components[k] != null)
/* 266 */               if (isDotDot(components[k])) {
/* 267 */                 parentCount++;
/* 268 */                 components[k] = null;
/*     */               } else {
/*     */                 break;
/*     */               }  
/*     */           } 
/* 273 */           if (i == 0) {
/* 274 */             components[0] = buildParentPathVariable(ProjectLocationVariableResolver.NAME, parentCount, false);
/*     */           } else {
/* 276 */             for (k = i - 1; k >= 0 && 
/* 277 */               parentCount != 0; k--) {
/*     */               
/* 279 */               if (components[k] != null) {
/*     */                 
/* 281 */                 String variable = extractVariable(components[k]);
/*     */                 
/* 283 */                 boolean hasVariableWithMacroSyntax = true;
/* 284 */                 if (variable.length() == 0 && locationFormat && k == 0) {
/* 285 */                   variable = components[k];
/* 286 */                   hasVariableWithMacroSyntax = false;
/*     */                 } 
/*     */                 
/*     */                 try {
/* 290 */                   if (variable.length() > 0) {
/* 291 */                     String prefix = "";
/* 292 */                     if (hasVariableWithMacroSyntax) {
/* 293 */                       int indexOfVariable = components[k].indexOf(variable) - "${".length();
/* 294 */                       prefix = components[k].substring(0, indexOfVariable);
/* 295 */                       String suffix = components[k].substring(indexOfVariable + "${".length() + variable.length() + "}".length());
/* 296 */                       if (suffix.length() != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */                         
/* 301 */                         String intermediateVariable = getValidVariableName(String.valueOf(variable) + suffix);
/* 302 */                         IPath intermediateValue = Path.fromPortableString(components[k]);
/* 303 */                         int intermediateVariableIndex = 1;
/* 304 */                         String originalIntermediateVariableName = intermediateVariable;
/* 305 */                         while (manager.isDefined(intermediateVariable)) {
/* 306 */                           IPath tmpValue = URIUtil.toPath(manager.getURIValue(intermediateVariable));
/* 307 */                           if (tmpValue.equals(intermediateValue))
/*     */                             break; 
/* 309 */                           intermediateVariable = String.valueOf(originalIntermediateVariableName) + intermediateVariableIndex;
/*     */                         } 
/* 311 */                         if (!manager.isDefined(intermediateVariable))
/* 312 */                           manager.setURIValue(intermediateVariable, URIUtil.toURI(intermediateValue)); 
/* 313 */                         variable = intermediateVariable;
/* 314 */                         prefix = "";
/*     */                       } 
/*     */                     } 
/* 317 */                     String newVariable = variable;
/* 318 */                     if (isParentVariable(variable))
/* 319 */                     { String argument = getParentVariableArgument(variable);
/* 320 */                       int count = getParentVariableCount(variable);
/* 321 */                       if (argument != null && count != -1) {
/* 322 */                         newVariable = buildParentPathVariable(argument, count + parentCount, locationFormat);
/*     */                       } else {
/* 324 */                         newVariable = buildParentPathVariable(variable, parentCount, locationFormat);
/*     */                       }  }
/* 326 */                     else { newVariable = buildParentPathVariable(variable, parentCount, locationFormat); }
/* 327 */                      components[k] = String.valueOf(prefix) + newVariable;
/*     */                     break;
/*     */                   } 
/* 330 */                   components[k] = null;
/* 331 */                   parentCount--;
/* 332 */                 } catch (CoreException coreException) {
/* 333 */                   components[k] = null;
/* 334 */                   parentCount--;
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         }  } 
/* 340 */     }  StringBuilder buffer = new StringBuilder();
/* 341 */     if (pathPrefix != '\000')
/* 342 */       buffer.append(pathPrefix); 
/* 343 */     for (int j = 0; j < components.length; j++) {
/* 344 */       if (components[j] != null) {
/* 345 */         if (j > 0)
/* 346 */           buffer.append(File.separator); 
/* 347 */         buffer.append(components[j]);
/*     */       } 
/*     */     } 
/* 350 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private static boolean isDotDot(String component) {
/* 354 */     return component.equals("..");
/*     */   }
/*     */   
/*     */   private static String[] splitPathComponents(String userFormat) {
/* 358 */     ArrayList<String> list = new ArrayList<>();
/* 359 */     StringBuilder buffer = new StringBuilder();
/* 360 */     for (int i = 0; i < userFormat.length(); i++) {
/* 361 */       char c = userFormat.charAt(i);
/* 362 */       if (c == '/' || c == '\\') {
/* 363 */         if (buffer.length() > 0)
/* 364 */           list.add(buffer.toString()); 
/* 365 */         buffer = new StringBuilder();
/*     */       } else {
/* 367 */         buffer.append(c);
/*     */       } 
/* 369 */     }  if (buffer.length() > 0)
/* 370 */       list.add(buffer.toString()); 
/* 371 */     return list.<String>toArray(new String[0]);
/*     */   }
/*     */   
/*     */   public static String convertToUserEditableFormatInternal(String value, boolean locationFormat) {
/* 375 */     StringBuilder buffer = new StringBuilder();
/* 376 */     if (locationFormat) {
/* 377 */       IPath path = Path.fromOSString(value);
/* 378 */       if (path.isAbsolute())
/* 379 */         return path.toOSString(); 
/* 380 */       int index = value.indexOf(File.separator);
/* 381 */       String variable = (index != -1) ? value.substring(0, index) : value;
/* 382 */       convertVariableToUserFormat(buffer, variable, variable, false);
/* 383 */       if (index != -1)
/* 384 */         buffer.append(value.substring(index)); 
/*     */     } else {
/* 386 */       String[] components = splitVariablesAndContent(value); byte b; int i; String[] arrayOfString1;
/* 387 */       for (i = (arrayOfString1 = components).length, b = 0; b < i; ) { String component = arrayOfString1[b];
/* 388 */         String variable = extractVariable(component);
/* 389 */         convertVariableToUserFormat(buffer, component, variable, true); b++; }
/*     */     
/*     */     } 
/* 392 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   private static void convertVariableToUserFormat(StringBuilder buffer, String component, String variable, boolean generateMacro) {
/* 396 */     if (isParentVariable(variable))
/* 397 */     { String argument = getParentVariableArgument(variable);
/* 398 */       int count = getParentVariableCount(variable);
/* 399 */       if (argument != null && count != -1) {
/* 400 */         buffer.append(generateMacro ? buildVariableMacro(Path.fromOSString(argument)) : Path.fromOSString(argument));
/* 401 */         for (int j = 0; j < count; j++) {
/* 402 */           buffer.append(String.valueOf(File.separator) + "..");
/*     */         }
/*     */       } else {
/* 405 */         buffer.append(component);
/*     */       }  }
/* 407 */     else { buffer.append(component); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String[] splitVariablesAndContent(String value) {
/* 419 */     LinkedList<String> result = new LinkedList<>();
/*     */     
/*     */     while (true) {
/* 422 */       int index = value.indexOf("${");
/* 423 */       if (index != -1) {
/* 424 */         int endIndex = getMatchingBrace(value, index);
/* 425 */         if (index > 0)
/* 426 */           result.add(value.substring(0, index)); 
/* 427 */         result.add(value.substring(index, endIndex + 1));
/* 428 */         value = value.substring(endIndex + 1); continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 432 */     if (value.length() > 0)
/* 433 */       result.add(value); 
/* 434 */     return result.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String[] splitVariableNames(String value) {
/* 447 */     LinkedList<String> result = new LinkedList<>();
/*     */     while (true) {
/* 449 */       int index = value.indexOf("${");
/* 450 */       if (index != -1) {
/* 451 */         int endIndex = getMatchingBrace(value, index);
/* 452 */         result.add(value.substring(index + 2, endIndex));
/* 453 */         value = value.substring(endIndex + 1); continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 457 */     return result.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String extractVariable(String segment) {
/* 468 */     int index = segment.indexOf("${");
/* 469 */     if (index != -1) {
/* 470 */       int endIndex = getMatchingBrace(segment, index);
/* 471 */       return segment.substring(index + 2, endIndex);
/*     */     } 
/* 473 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getMatchingBrace(String value, int index) {
/* 480 */     int scope = 0;
/* 481 */     for (int i = index + 1; i < value.length(); i++) {
/* 482 */       char c = value.charAt(i);
/* 483 */       if (c == '}') {
/* 484 */         if (scope == 0)
/* 485 */           return i; 
/* 486 */         scope--;
/*     */       } 
/* 488 */       if (c == '$' && 
/* 489 */         i + 1 < value.length() && value.charAt(i + 1) == '{') {
/* 490 */         scope++;
/*     */       }
/*     */     } 
/* 493 */     return value.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPreferred(String variableName) {
/* 503 */     return !(variableName.equals(WorkspaceLocationVariableResolver.NAME) || variableName.equals(WorkspaceParentLocationVariableResolver.NAME) || variableName.equals("PARENT"));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\PathVariableUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */