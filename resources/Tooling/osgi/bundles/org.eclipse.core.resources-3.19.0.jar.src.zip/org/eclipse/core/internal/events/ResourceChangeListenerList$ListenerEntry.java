/*    */ package org.eclipse.core.internal.events;
/*    */ 
/*    */ import org.eclipse.core.resources.IResourceChangeListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ListenerEntry
/*    */ {
/*    */   final int eventMask;
/*    */   final IResourceChangeListener listener;
/*    */   
/*    */   ListenerEntry(IResourceChangeListener listener, int eventMask) {
/* 41 */     this.listener = listener;
/* 42 */     this.eventMask = eventMask;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 47 */     StringBuilder sb = new StringBuilder();
/* 48 */     sb.append("Listener [eventMask=");
/* 49 */     sb.append(this.eventMask);
/* 50 */     sb.append(", ");
/* 51 */     sb.append(this.listener);
/* 52 */     sb.append("]");
/* 53 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\ResourceChangeListenerList$ListenerEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */