/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.internal.watson.IPathRequestor;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceVisitor;
/*     */ import org.eclipse.core.resources.ISynchronizer;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.ICoreRunnable;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Synchronizer
/*     */   implements ISynchronizer
/*     */ {
/*     */   protected Workspace workspace;
/*     */   protected SyncInfoWriter writer;
/*  35 */   protected Set<QualifiedName> registry = new HashSet<>(5);
/*     */ 
/*     */   
/*     */   public Synchronizer(Workspace workspace) {
/*  39 */     this.workspace = workspace;
/*  40 */     this.writer = new SyncInfoWriter(workspace, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(QualifiedName partner, IResource resource, IResourceVisitor visitor, int depth) throws CoreException {
/*  49 */     Assert.isLegal((partner != null));
/*  50 */     Assert.isLegal((resource != null));
/*  51 */     Assert.isLegal((visitor != null));
/*     */ 
/*     */     
/*  54 */     if (getSyncInfo(partner, resource) != null)
/*     */     {
/*  56 */       if (!visitor.visit(resource)) {
/*     */         return;
/*     */       }
/*     */     }
/*     */     
/*  61 */     if (depth == 0 || resource.getType() == 1)
/*     */       return; 
/*  63 */     if (depth == 1) {
/*  64 */       depth = 0;
/*     */     }
/*     */     
/*  67 */     IResource[] children = ((IContainer)resource).members(); byte b; int i; IResource[] arrayOfIResource1;
/*  68 */     for (i = (arrayOfIResource1 = children).length, b = 0; b < i; ) { IResource element = arrayOfIResource1[b];
/*  69 */       accept(partner, element, visitor, depth);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(QualifiedName partner) {
/*  77 */     Assert.isLegal((partner != null));
/*  78 */     this.registry.add(partner);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flushSyncInfo(QualifiedName partner, IResource root, int depth) throws CoreException {
/*  86 */     Assert.isLegal((partner != null));
/*  87 */     Assert.isLegal((root != null));
/*     */     
/*  89 */     ICoreRunnable body = monitor -> {
/*     */         IResourceVisitor visitor = ();
/*     */ 
/*     */ 
/*     */         
/*     */         paramIResource.accept(visitor, paramInt, true);
/*     */       };
/*     */ 
/*     */     
/*  98 */     this.workspace.run(body, (ISchedulingRule)root, 0, (IProgressMonitor)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QualifiedName[] getPartners() {
/* 106 */     return this.registry.<QualifiedName>toArray(new QualifiedName[this.registry.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Set<QualifiedName> getRegistry() {
/* 113 */     return this.registry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getSyncInfo(QualifiedName partner, IResource resource) throws CoreException {
/* 121 */     Assert.isLegal((partner != null));
/* 122 */     Assert.isLegal((resource != null));
/*     */     
/* 124 */     if (!isRegistered(partner)) {
/* 125 */       String message = NLS.bind(Messages.synchronizer_partnerNotRegistered, partner);
/* 126 */       throw new ResourceException(new ResourceStatus(375, message));
/*     */     } 
/*     */ 
/*     */     
/* 130 */     ResourceInfo info = this.workspace.getResourceInfo(resource.getFullPath(), true, false);
/* 131 */     return (info == null) ? null : info.getSyncInfo(partner, true);
/*     */   }
/*     */   
/*     */   protected boolean isRegistered(QualifiedName partner) {
/* 135 */     Assert.isLegal((partner != null));
/* 136 */     return this.registry.contains(partner);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readPartners(DataInputStream input) throws CoreException {
/* 143 */     SyncInfoReader reader = new SyncInfoReader(this.workspace, this);
/* 144 */     reader.readPartners(input);
/*     */   }
/*     */ 
/*     */   
/*     */   public void restore(IResource resource, IProgressMonitor monitor) throws CoreException {
/* 149 */     restoreFromSave(resource);
/* 150 */     restoreFromSnap(resource);
/*     */   }
/*     */   
/*     */   protected void restoreFromSave(IResource resource) throws CoreException {
/* 154 */     IPath sourceLocation = this.workspace.getMetaArea().getSyncInfoLocationFor(resource);
/* 155 */     IPath tempLocation = this.workspace.getMetaArea().getBackupLocationFor(sourceLocation);
/* 156 */     if (!sourceLocation.toFile().exists() && !tempLocation.toFile().exists())
/*     */       return;  try {
/* 158 */       Exception exception2, exception1 = null;
/*     */ 
/*     */     
/*     */     }
/* 162 */     catch (Exception e) {
/*     */       
/* 164 */       String msg = NLS.bind(Messages.resources_readMeta, sourceLocation);
/* 165 */       throw new ResourceException(567, sourceLocation, msg, e);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void restoreFromSnap(IResource resource) {
/* 170 */     IPath sourceLocation = this.workspace.getMetaArea().getSyncInfoSnapshotLocationFor(resource);
/* 171 */     if (!sourceLocation.toFile().exists())
/*     */       return;  
/* 173 */     try { Exception exception1 = null, exception2 = null;
/*     */       
/*     */       try {  }
/*     */       finally
/* 177 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (EOFException eOFException)
/*     */     {  }
/* 179 */     catch (Exception e)
/*     */     
/* 181 */     { String msg = NLS.bind(Messages.resources_readMeta, sourceLocation);
/* 182 */       Policy.log((IStatus)new ResourceStatus(567, sourceLocation, msg, e)); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(QualifiedName partner) {
/* 191 */     Assert.isLegal((partner != null));
/* 192 */     if (isRegistered(partner)) {
/*     */       
/*     */       try {
/* 195 */         flushSyncInfo(partner, (IResource)this.workspace.getRoot(), 2);
/* 196 */         this.registry.remove(partner);
/* 197 */       } catch (CoreException e) {
/*     */         
/* 199 */         Policy.log((Throwable)e);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void savePartners(DataOutputStream output) throws IOException {
/* 205 */     this.writer.savePartners(output);
/*     */   }
/*     */ 
/*     */   
/*     */   public void saveSyncInfo(ResourceInfo info, IPathRequestor requestor, DataOutputStream output, List<QualifiedName> writtenPartners) throws IOException {
/* 210 */     this.writer.saveSyncInfo(info, requestor, output, writtenPartners);
/*     */   }
/*     */   
/*     */   protected void setRegistry(Set<QualifiedName> registry) {
/* 214 */     this.registry = registry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSyncInfo(QualifiedName partner, IResource resource, byte[] info) throws CoreException {
/* 222 */     Assert.isLegal((partner != null));
/* 223 */     Assert.isLegal((resource != null));
/*     */     try {
/* 225 */       this.workspace.prepareOperation((ISchedulingRule)resource, null);
/* 226 */       this.workspace.beginOperation(true);
/* 227 */       if (!isRegistered(partner)) {
/* 228 */         String message = NLS.bind(Messages.synchronizer_partnerNotRegistered, partner);
/* 229 */         throw new ResourceException(new ResourceStatus(375, message));
/*     */       } 
/*     */       
/* 232 */       if (resource.getType() == 8) {
/*     */         return;
/*     */       }
/*     */       
/* 236 */       Resource target = (Resource)resource;
/* 237 */       ResourceInfo resourceInfo = this.workspace.getResourceInfo(target.getFullPath(), true, false);
/* 238 */       int flags = target.getFlags(resourceInfo);
/* 239 */       if (!target.exists(flags, false)) {
/* 240 */         if (info == null) {
/*     */           return;
/*     */         }
/* 243 */         target.checkValidPath(target.getFullPath(), target.getType(), false);
/* 244 */         Container parent = (Container)target.getParent();
/* 245 */         parent.checkAccessible(parent.getFlags(parent.getResourceInfo(true, false)));
/* 246 */         this.workspace.createResource(target, true);
/*     */       } 
/* 248 */       resourceInfo = target.getResourceInfo(true, true);
/* 249 */       resourceInfo.setSyncInfo(partner, info);
/* 250 */       resourceInfo.incrementSyncInfoGenerationCount();
/* 251 */       resourceInfo.set(8192);
/* 252 */       flags = target.getFlags(resourceInfo);
/* 253 */       if (target.isPhantom(flags) && resourceInfo.getSyncInfo(false) == null) {
/* 254 */         MultiStatus status = new MultiStatus("org.eclipse.core.resources", 566, 
/* 255 */             Messages.resources_deleteProblem, null);
/* 256 */         ((Resource)resource).deleteResource(false, status);
/* 257 */         if (!status.isOK())
/* 258 */           throw new ResourceException(status); 
/*     */       } 
/*     */     } finally {
/* 261 */       this.workspace.endOperation((ISchedulingRule)resource, false);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void snapSyncInfo(ResourceInfo info, IPathRequestor requestor, DataOutputStream output) throws IOException {
/* 266 */     this.writer.snapSyncInfo(info, requestor, output);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\Synchronizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */