/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import org.eclipse.core.internal.utils.Messages;
/*    */ import org.eclipse.core.internal.utils.Policy;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.variableresolvers.PathVariableResolver;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.core.runtime.IExtension;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Descriptor
/*    */ {
/* 36 */   PathVariableResolver provider = null;
/* 37 */   String name = null;
/* 38 */   String value = null;
/*    */   
/*    */   public Descriptor(IExtension extension, IConfigurationElement element) throws RuntimeException, CoreException {
/* 41 */     this.name = element.getAttribute("variable");
/* 42 */     this.value = element.getAttribute("value");
/*    */     try {
/* 44 */       String classAttribute = "class";
/* 45 */       if (element.getAttribute(classAttribute) != null)
/* 46 */         this.provider = (PathVariableResolver)element.createExecutableExtension(classAttribute); 
/* 47 */     } catch (CoreException e) {
/* 48 */       Policy.log((Throwable)e);
/*    */     } 
/* 50 */     if (this.name == null)
/* 51 */       fail(NLS.bind(Messages.mapping_invalidDef, extension.getUniqueIdentifier())); 
/*    */   }
/*    */   
/*    */   protected void fail(String reason) throws CoreException {
/* 55 */     throw new ResourceException(new Status(4, "org.eclipse.core.resources", 1, reason, null));
/*    */   }
/*    */   
/*    */   public String getName() {
/* 59 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getValue(String variable, IResource resource) {
/* 63 */     if (this.value != null)
/* 64 */       return this.value; 
/* 65 */     return this.provider.getValue(variable, resource);
/*    */   }
/*    */   
/*    */   public String[] getVariableNames(String variable, IResource resource) {
/* 69 */     if (this.provider != null)
/* 70 */       return this.provider.getVariableNames(variable, resource); 
/* 71 */     if (this.name.equals(variable))
/* 72 */       return new String[] { variable }; 
/* 73 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ProjectVariableProviderManager$Descriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */