package org.eclipse.core.resources;

import java.util.EventListener;
import org.eclipse.core.runtime.CoreException;

public interface ISaveParticipant extends EventListener {
  void doneSaving(ISaveContext paramISaveContext);
  
  void prepareToSave(ISaveContext paramISaveContext) throws CoreException;
  
  void rollback(ISaveContext paramISaveContext);
  
  void saving(ISaveContext paramISaveContext) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\ISaveParticipant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */