/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import org.eclipse.core.internal.utils.Policy;
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MasterTable
/*    */   extends Properties
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public synchronized Object put(Object key, Object value) {
/* 53 */     Object prev = super.put(key, value);
/* 54 */     if (prev != null && SaveManager.ROOT_SEQUENCE_NUMBER_KEY.equals(key)) {
/* 55 */       int prevSeqNum = Integer.parseInt((String)prev);
/* 56 */       int currSeqNum = Integer.parseInt((String)value);
/* 57 */       if (prevSeqNum > currSeqNum) {
/*    */         
/* 59 */         super.put(key, prev);
/*    */         
/* 61 */         String message = "Cannot set lower sequence number for root (previous: " + prevSeqNum + ", new: " + currSeqNum + "). Ignoring the new value.";
/* 62 */         Policy.log((IStatus)new Status(4, "org.eclipse.core.resources", 566, message, new IllegalArgumentException(message)));
/*    */       } 
/*    */     } 
/* 65 */     return prev;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\SaveManager$MasterTable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */