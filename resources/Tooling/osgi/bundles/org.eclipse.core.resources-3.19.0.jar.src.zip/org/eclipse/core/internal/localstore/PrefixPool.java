/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrefixPool
/*     */ {
/*     */   private String[] pool;
/*     */   private int size;
/*     */   
/*     */   public PrefixPool(int initialCapacity) {
/*  62 */     if (initialCapacity <= 0)
/*  63 */       throw new IllegalArgumentException("Illegal Capacity: " + initialCapacity); 
/*  64 */     this.pool = new String[initialCapacity];
/*  65 */     this.size = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  74 */     Arrays.fill((Object[])this.pool, 0, this.size, (Object)null);
/*  75 */     this.size = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  83 */     return this.size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkCapacity() {
/*  90 */     if (this.size + 1 >= this.pool.length) {
/*  91 */       String[] newprefixList = new String[2 * this.pool.length];
/*  92 */       System.arraycopy(this.pool, 0, newprefixList, 0, this.pool.length);
/*  93 */       Arrays.fill((Object[])this.pool, (Object)null);
/*  94 */       this.pool = newprefixList;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertLonger(String s) {
/* 115 */     for (int i = this.size - 1; i >= 0; i--) {
/* 116 */       if (this.pool[i].startsWith(s)) {
/*     */         return;
/*     */       }
/* 119 */       if (s.startsWith(this.pool[i])) {
/*     */         
/* 121 */         this.pool[i] = s;
/*     */         return;
/*     */       } 
/*     */     } 
/* 125 */     checkCapacity();
/* 126 */     this.pool[this.size] = s;
/* 127 */     this.size++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean insertShorter(String s) {
/* 149 */     boolean replaced = false;
/*     */     
/* 151 */     for (int i = this.size - 1; i >= 0; i--) {
/* 152 */       if (s.startsWith(this.pool[i]))
/*     */       {
/* 154 */         return false; } 
/* 155 */       if (this.pool[i].startsWith(s)) {
/* 156 */         if (replaced) {
/*     */ 
/*     */           
/* 159 */           System.arraycopy(this.pool, i + 1, this.pool, i, this.size - i - 1);
/* 160 */           this.size--;
/* 161 */           this.pool[this.size] = null;
/*     */         } else {
/*     */           
/* 164 */           this.pool[i] = s;
/* 165 */           replaced = true;
/*     */         } 
/*     */       }
/*     */     } 
/* 169 */     if (!replaced) {
/*     */       
/* 171 */       checkCapacity();
/* 172 */       this.pool[this.size] = s;
/* 173 */       this.size++;
/*     */     } 
/* 175 */     return replaced;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsAsPrefix(String s) {
/* 187 */     for (int i = this.size - 1; i >= 0; i--) {
/* 188 */       if (this.pool[i].startsWith(s)) {
/* 189 */         return true;
/*     */       }
/*     */     } 
/* 192 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasPrefixOf(String s) {
/* 203 */     for (int i = this.size - 1; i >= 0; i--) {
/* 204 */       if (s.startsWith(this.pool[i])) {
/* 205 */         return true;
/*     */       }
/*     */     } 
/* 208 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\PrefixPool.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */