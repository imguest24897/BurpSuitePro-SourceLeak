/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import org.eclipse.core.resources.IMarker;
/*     */ import org.eclipse.core.resources.IMarkerDelta;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarkerDelta
/*     */   implements IMarkerDelta, IMarkerSetElement
/*     */ {
/*     */   protected int kind;
/*     */   protected IResource resource;
/*     */   protected MarkerInfo info;
/*     */   
/*     */   public MarkerDelta(int kind, IResource resource, MarkerInfo info) {
/*  34 */     this.kind = kind;
/*  35 */     this.resource = resource;
/*  36 */     this.info = info;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getAttribute(String attributeName) {
/*  41 */     return this.info.getAttribute(attributeName);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getAttribute(String attributeName, int defaultValue) {
/*  46 */     Object value = this.info.getAttribute(attributeName);
/*  47 */     if (value instanceof Integer)
/*  48 */       return ((Integer)value).intValue(); 
/*  49 */     return defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAttribute(String attributeName, String defaultValue) {
/*  54 */     Object value = this.info.getAttribute(attributeName);
/*  55 */     if (value instanceof String)
/*  56 */       return (String)value; 
/*  57 */     return defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getAttribute(String attributeName, boolean defaultValue) {
/*  62 */     Object value = this.info.getAttribute(attributeName);
/*  63 */     if (value instanceof Boolean)
/*  64 */       return ((Boolean)value).booleanValue(); 
/*  65 */     return defaultValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> getAttributes() {
/*  70 */     return this.info.getAttributes();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getAttributes(String[] attributeNames) {
/*  75 */     return this.info.getAttributes(attributeNames);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getId() {
/*  80 */     return this.info.getId();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getKind() {
/*  85 */     return this.kind;
/*     */   }
/*     */ 
/*     */   
/*     */   public IMarker getMarker() {
/*  90 */     return new Marker(this.resource, getId());
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource getResource() {
/*  95 */     return this.resource;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/* 100 */     return this.info.getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSubtypeOf(String superType) {
/* 105 */     return ((Workspace)getResource().getWorkspace()).getMarkerManager().isSubtype(getType(), superType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<IPath, MarkerSet> merge(Map<IPath, MarkerSet> oldChanges, Map<IPath, MarkerSet> newChanges) {
/* 113 */     if (oldChanges == null)
/*     */     {
/* 115 */       return newChanges; } 
/* 116 */     if (newChanges == null)
/* 117 */       return oldChanges; 
/* 118 */     for (Map.Entry<IPath, MarkerSet> newEntry : newChanges.entrySet()) {
/* 119 */       IPath key = newEntry.getKey();
/* 120 */       MarkerSet oldSet = oldChanges.get(key);
/* 121 */       MarkerSet newSet = newEntry.getValue();
/* 122 */       if (oldSet == null) {
/* 123 */         oldChanges.put(key, newSet); continue;
/*     */       } 
/* 125 */       merge(oldSet, newSet.elements());
/*     */     } 
/* 127 */     return oldChanges;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static MarkerSet merge(MarkerSet oldChanges, IMarkerSetElement[] newChanges) {
/* 147 */     if (oldChanges == null) {
/* 148 */       MarkerSet result = new MarkerSet(newChanges.length); byte b1; int j; IMarkerSetElement[] arrayOfIMarkerSetElement1;
/* 149 */       for (j = (arrayOfIMarkerSetElement1 = newChanges).length, b1 = 0; b1 < j; ) { IMarkerSetElement newChange = arrayOfIMarkerSetElement1[b1];
/* 150 */         result.add(newChange); b1++; }
/* 151 */        return result;
/*     */     } 
/* 153 */     if (newChanges == null)
/* 154 */       return oldChanges;  byte b; int i;
/*     */     IMarkerSetElement[] arrayOfIMarkerSetElement;
/* 156 */     for (i = (arrayOfIMarkerSetElement = newChanges).length, b = 0; b < i; ) { IMarkerSetElement newChange = arrayOfIMarkerSetElement[b];
/* 157 */       MarkerDelta newDelta = (MarkerDelta)newChange;
/* 158 */       MarkerDelta oldDelta = (MarkerDelta)oldChanges.get(newDelta.getId());
/* 159 */       if (oldDelta == null) {
/* 160 */         oldChanges.add(newDelta);
/*     */       } else {
/*     */         
/* 163 */         switch (oldDelta.getKind()) {
/*     */           case 1:
/* 165 */             switch (newDelta.getKind()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               case 2:
/* 172 */                 oldChanges.remove(oldDelta);
/*     */                 break;
/*     */             } 
/*     */ 
/*     */             
/*     */             break;
/*     */           
/*     */           case 2:
/* 180 */             switch (newDelta.getKind()) {
/*     */             
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             break;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 4:
/* 193 */             switch (newDelta.getKind()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               case 2:
/* 200 */                 oldDelta.setKind(2);
/*     */                 break;
/*     */             } 
/*     */             
/*     */             break;
/*     */         } 
/*     */       } 
/*     */       b++; }
/*     */     
/* 209 */     return oldChanges;
/*     */   }
/*     */   
/*     */   private void setKind(int kind) {
/* 213 */     this.kind = kind;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 219 */     return String.valueOf(getClass().getSimpleName()) + "[resource=" + getResource() + ", attributes=" + (
/* 220 */       (getAttributes() == null) ? null : 
/* 221 */       getAttributes().entrySet().stream().map(e -> String.valueOf(e.getKey()) + "=" + e.getValue())
/* 222 */       .collect(Collectors.joining(", ", "{", "}"))) + 
/* 223 */       "]";
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\MarkerDelta.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */