package org.eclipse.core.resources;

import org.eclipse.core.runtime.CoreException;

public interface IResourceProxyVisitor {
  boolean visit(IResourceProxy paramIResourceProxy) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IResourceProxyVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */