/*     */ package org.eclipse.core.resources;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IResource
/*     */   extends IAdaptable, ISchedulingRule
/*     */ {
/*     */   public static final int FILE = 1;
/*     */   public static final int FOLDER = 2;
/*     */   public static final int PROJECT = 4;
/*     */   public static final int ROOT = 8;
/*     */   public static final int DEPTH_ZERO = 0;
/*     */   public static final int DEPTH_ONE = 1;
/*     */   public static final int DEPTH_INFINITE = 2;
/*     */   public static final int FORCE = 1;
/*     */   public static final int KEEP_HISTORY = 2;
/*     */   public static final int ALWAYS_DELETE_PROJECT_CONTENT = 4;
/*     */   public static final int NEVER_DELETE_PROJECT_CONTENT = 8;
/*     */   public static final int ALLOW_MISSING_LOCAL = 16;
/*     */   public static final int SHALLOW = 32;
/*     */   public static final int AVOID_NATURE_CONFIG = 64;
/*     */   public static final int BACKGROUND_REFRESH = 128;
/*     */   public static final int REPLACE = 256;
/*     */   public static final int CHECK_ANCESTORS = 512;
/*     */   public static final int DERIVED = 1024;
/*     */   public static final int TEAM_PRIVATE = 2048;
/*     */   public static final int HIDDEN = 4096;
/*     */   public static final int VIRTUAL = 8192;
/*     */   public static final int NULL_STAMP = -1;
/*     */   public static final int NONE = 0;
/*     */   
/*     */   void accept(IResourceProxyVisitor paramIResourceProxyVisitor, int paramInt) throws CoreException;
/*     */   
/*     */   void accept(IResourceProxyVisitor paramIResourceProxyVisitor, int paramInt1, int paramInt2) throws CoreException;
/*     */   
/*     */   void accept(IResourceVisitor paramIResourceVisitor) throws CoreException;
/*     */   
/*     */   void accept(IResourceVisitor paramIResourceVisitor, int paramInt, boolean paramBoolean) throws CoreException;
/*     */   
/*     */   void accept(IResourceVisitor paramIResourceVisitor, int paramInt1, int paramInt2) throws CoreException;
/*     */   
/*     */   void clearHistory(IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */   
/*     */   void copy(IPath paramIPath, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */   
/*     */   void copy(IPath paramIPath, int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */   
/*     */   void copy(IProjectDescription paramIProjectDescription, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */   
/*     */   void copy(IProjectDescription paramIProjectDescription, int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */   
/*     */   IMarker createMarker(String paramString) throws CoreException;
/*     */   
/*     */   default IMarker createMarker(String type, Map<String, ? extends Object> attributes) throws CoreException {
/* 977 */     IMarker marker = createMarker(type);
/* 978 */     marker.setAttributes(attributes);
/* 979 */     return marker;
/*     */   }
/*     */   
/*     */   IResourceProxy createProxy();
/*     */   
/*     */   void delete(boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */   
/*     */   void delete(int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */   
/*     */   void deleteMarkers(String paramString, boolean paramBoolean, int paramInt) throws CoreException;
/*     */   
/*     */   boolean equals(Object paramObject);
/*     */   
/*     */   boolean exists();
/*     */   
/*     */   IMarker findMarker(long paramLong) throws CoreException;
/*     */   
/*     */   IMarker[] findMarkers(String paramString, boolean paramBoolean, int paramInt) throws CoreException;
/*     */   
/*     */   int findMaxProblemSeverity(String paramString, boolean paramBoolean, int paramInt) throws CoreException;
/*     */   
/*     */   String getFileExtension();
/*     */   
/*     */   IPath getFullPath();
/*     */   
/*     */   long getLocalTimeStamp();
/*     */   
/*     */   IPath getLocation();
/*     */   
/*     */   URI getLocationURI();
/*     */   
/*     */   IMarker getMarker(long paramLong);
/*     */   
/*     */   long getModificationStamp();
/*     */   
/*     */   String getName();
/*     */   
/*     */   IPathVariableManager getPathVariableManager();
/*     */   
/*     */   IContainer getParent();
/*     */   
/*     */   Map<QualifiedName, String> getPersistentProperties() throws CoreException;
/*     */   
/*     */   String getPersistentProperty(QualifiedName paramQualifiedName) throws CoreException;
/*     */   
/*     */   IProject getProject();
/*     */   
/*     */   IPath getProjectRelativePath();
/*     */   
/*     */   IPath getRawLocation();
/*     */   
/*     */   URI getRawLocationURI();
/*     */   
/*     */   ResourceAttributes getResourceAttributes();
/*     */   
/*     */   Map<QualifiedName, Object> getSessionProperties() throws CoreException;
/*     */   
/*     */   Object getSessionProperty(QualifiedName paramQualifiedName) throws CoreException;
/*     */   
/*     */   int getType();
/*     */   
/*     */   IWorkspace getWorkspace();
/*     */   
/*     */   boolean isAccessible();
/*     */   
/*     */   boolean isDerived();
/*     */   
/*     */   boolean isDerived(int paramInt);
/*     */   
/*     */   boolean isHidden();
/*     */   
/*     */   boolean isHidden(int paramInt);
/*     */   
/*     */   boolean isLinked();
/*     */   
/*     */   boolean isVirtual();
/*     */   
/*     */   boolean isLinked(int paramInt);
/*     */   
/*     */   @Deprecated
/*     */   boolean isLocal(int paramInt);
/*     */   
/*     */   boolean isPhantom();
/*     */   
/*     */   @Deprecated
/*     */   boolean isReadOnly();
/*     */   
/*     */   boolean isSynchronized(int paramInt);
/*     */   
/*     */   boolean isTeamPrivateMember();
/*     */   
/*     */   boolean isTeamPrivateMember(int paramInt);
/*     */   
/*     */   void move(IPath paramIPath, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */   
/*     */   void move(IPath paramIPath, int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */   
/*     */   void move(IProjectDescription paramIProjectDescription, boolean paramBoolean1, boolean paramBoolean2, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */   
/*     */   void move(IProjectDescription paramIProjectDescription, int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */   
/*     */   void refreshLocal(int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */   
/*     */   void revertModificationStamp(long paramLong) throws CoreException;
/*     */   
/*     */   @Deprecated
/*     */   void setDerived(boolean paramBoolean) throws CoreException;
/*     */   
/*     */   void setDerived(boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */   
/*     */   void setHidden(boolean paramBoolean) throws CoreException;
/*     */   
/*     */   @Deprecated
/*     */   void setLocal(boolean paramBoolean, int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */   
/*     */   long setLocalTimeStamp(long paramLong) throws CoreException;
/*     */   
/*     */   void setPersistentProperty(QualifiedName paramQualifiedName, String paramString) throws CoreException;
/*     */   
/*     */   @Deprecated
/*     */   void setReadOnly(boolean paramBoolean);
/*     */   
/*     */   void setResourceAttributes(ResourceAttributes paramResourceAttributes) throws CoreException;
/*     */   
/*     */   void setSessionProperty(QualifiedName paramQualifiedName, Object paramObject) throws CoreException;
/*     */   
/*     */   void setTeamPrivateMember(boolean paramBoolean) throws CoreException;
/*     */   
/*     */   void touch(IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IResource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */