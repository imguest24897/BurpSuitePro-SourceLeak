package org.eclipse.core.resources;

import java.util.Map;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;

public interface IMarker extends IAdaptable {
  public static final String MARKER = "org.eclipse.core.resources.marker";
  
  public static final String TASK = "org.eclipse.core.resources.taskmarker";
  
  public static final String PROBLEM = "org.eclipse.core.resources.problemmarker";
  
  public static final String TEXT = "org.eclipse.core.resources.textmarker";
  
  public static final String BOOKMARK = "org.eclipse.core.resources.bookmark";
  
  public static final String SEVERITY = "severity";
  
  public static final String MESSAGE = "message";
  
  public static final String LOCATION = "location";
  
  public static final String PRIORITY = "priority";
  
  public static final String DONE = "done";
  
  public static final String CHAR_START = "charStart";
  
  public static final String CHAR_END = "charEnd";
  
  public static final String LINE_NUMBER = "lineNumber";
  
  public static final String TRANSIENT = "transient";
  
  public static final String USER_EDITABLE = "userEditable";
  
  public static final String SOURCE_ID = "sourceId";
  
  public static final int PRIORITY_HIGH = 2;
  
  public static final int PRIORITY_NORMAL = 1;
  
  public static final int PRIORITY_LOW = 0;
  
  public static final int SEVERITY_ERROR = 2;
  
  public static final int SEVERITY_WARNING = 1;
  
  public static final int SEVERITY_INFO = 0;
  
  void delete() throws CoreException;
  
  boolean equals(Object paramObject);
  
  boolean exists();
  
  Object getAttribute(String paramString) throws CoreException;
  
  int getAttribute(String paramString, int paramInt);
  
  String getAttribute(String paramString1, String paramString2);
  
  boolean getAttribute(String paramString, boolean paramBoolean);
  
  Map<String, Object> getAttributes() throws CoreException;
  
  Object[] getAttributes(String[] paramArrayOfString) throws CoreException;
  
  long getCreationTime() throws CoreException;
  
  long getId();
  
  IResource getResource();
  
  String getType() throws CoreException;
  
  boolean isSubtypeOf(String paramString) throws CoreException;
  
  void setAttribute(String paramString, int paramInt) throws CoreException;
  
  void setAttribute(String paramString, Object paramObject) throws CoreException;
  
  void setAttribute(String paramString, boolean paramBoolean) throws CoreException;
  
  void setAttributes(String[] paramArrayOfString, Object[] paramArrayOfObject) throws CoreException;
  
  void setAttributes(Map<String, ? extends Object> paramMap) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IMarker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */