/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarkerTypeDefinitionCache
/*     */ {
/*     */   protected HashMap<String, MarkerTypeDefinition> definitions;
/*     */   
/*     */   static class MarkerTypeDefinition
/*     */   {
/*     */     boolean isPersistent = false;
/*     */     Set<String> superTypes;
/*     */     
/*     */     MarkerTypeDefinition(IExtension ext) {
/*  29 */       IConfigurationElement[] elements = ext.getConfigurationElements(); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/*  30 */       for (i = (arrayOfIConfigurationElement1 = elements).length, b = 0; b < i; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b];
/*     */         
/*  32 */         String elementName = element.getName();
/*  33 */         if (elementName.equalsIgnoreCase("super")) {
/*  34 */           String aType = element.getAttribute("type");
/*  35 */           if (aType != null) {
/*  36 */             if (this.superTypes == null) {
/*  37 */               this.superTypes = new HashSet<>(8);
/*     */             }
/*     */ 
/*     */             
/*  41 */             this.superTypes.add(aType.intern());
/*     */           } 
/*     */         } 
/*     */         
/*  45 */         if (elementName.equalsIgnoreCase("persistent")) {
/*  46 */           String bool = element.getAttribute("value");
/*  47 */           if (bool != null) {
/*  48 */             this.isPersistent = Boolean.parseBoolean(bool);
/*     */           }
/*     */         } 
/*  51 */         if (elementName.equalsIgnoreCase("transient")) {
/*  52 */           String bool = element.getAttribute("value");
/*  53 */           if (bool != null) {
/*  54 */             this.isPersistent = !Boolean.parseBoolean(bool);
/*     */           }
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerTypeDefinitionCache() {
/*  68 */     loadDefinitions();
/*  69 */     HashSet<String> toCompute = new HashSet<>(this.definitions.keySet());
/*  70 */     for (String markerId : this.definitions.keySet()) {
/*  71 */       if (toCompute.contains(markerId)) {
/*  72 */         computeSuperTypes(markerId, toCompute);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Set<String> computeSuperTypes(String markerId, Set<String> toCompute) {
/*  85 */     MarkerTypeDefinition def = this.definitions.get(markerId);
/*  86 */     if (def == null || def.superTypes == null) {
/*     */       
/*  88 */       toCompute.remove(markerId);
/*  89 */       return null;
/*     */     } 
/*  91 */     Set<String> transitiveSuperTypes = new HashSet<>(def.superTypes);
/*  92 */     for (String superId : def.superTypes) {
/*  93 */       Set<String> toAdd = null;
/*  94 */       if (toCompute.contains(superId)) {
/*     */         
/*  96 */         toAdd = computeSuperTypes(superId, toCompute);
/*     */       } else {
/*     */         
/*  99 */         MarkerTypeDefinition parentDef = this.definitions.get(superId);
/* 100 */         if (parentDef != null)
/* 101 */           toAdd = parentDef.superTypes; 
/*     */       } 
/* 103 */       if (toAdd != null)
/* 104 */         transitiveSuperTypes.addAll(toAdd); 
/*     */     } 
/* 106 */     def.superTypes = transitiveSuperTypes;
/* 107 */     toCompute.remove(markerId);
/* 108 */     return transitiveSuperTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPersistent(String type) {
/* 115 */     MarkerTypeDefinition def = this.definitions.get(type);
/* 116 */     return (def != null && def.isPersistent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSubtype(String type, String superType) {
/* 124 */     if (type.equals(superType))
/* 125 */       return true; 
/* 126 */     MarkerTypeDefinition def = this.definitions.get(type);
/* 127 */     return (def != null && def.superTypes != null && def.superTypes.contains(superType));
/*     */   }
/*     */   
/*     */   private void loadDefinitions() {
/* 131 */     IExtensionPoint point = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.core.resources", "markers");
/* 132 */     IExtension[] types = point.getExtensions();
/* 133 */     this.definitions = new HashMap<>(types.length); byte b; int i; IExtension[] arrayOfIExtension1;
/* 134 */     for (i = (arrayOfIExtension1 = types).length, b = 0; b < i; ) { IExtension type = arrayOfIExtension1[b];
/* 135 */       String markerId = type.getUniqueIdentifier();
/* 136 */       if (markerId != null) {
/* 137 */         this.definitions.put(markerId.intern(), new MarkerTypeDefinition(type));
/*     */       } else {
/* 139 */         Policy.log(2, "Missing marker id from plugin: " + type.getContributor().getName(), null);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\MarkerTypeDefinitionCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */