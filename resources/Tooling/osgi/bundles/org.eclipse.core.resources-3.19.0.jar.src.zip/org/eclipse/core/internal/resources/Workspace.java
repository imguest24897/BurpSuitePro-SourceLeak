/*      */ package org.eclipse.core.internal.resources;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.management.ManagementFactory;
/*      */ import java.net.URI;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayDeque;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.Deque;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.SortedSet;
/*      */ import java.util.TreeSet;
/*      */ import java.util.concurrent.CopyOnWriteArrayList;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ import java.util.function.Predicate;
/*      */ import org.eclipse.core.filesystem.EFS;
/*      */ import org.eclipse.core.filesystem.IFileStore;
/*      */ import org.eclipse.core.filesystem.URIUtil;
/*      */ import org.eclipse.core.internal.events.BuildManager;
/*      */ import org.eclipse.core.internal.events.ILifecycleListener;
/*      */ import org.eclipse.core.internal.events.LifecycleEvent;
/*      */ import org.eclipse.core.internal.events.NotificationManager;
/*      */ import org.eclipse.core.internal.events.ResourceChangeEvent;
/*      */ import org.eclipse.core.internal.localstore.FileSystemResourceManager;
/*      */ import org.eclipse.core.internal.preferences.PreferencesService;
/*      */ import org.eclipse.core.internal.properties.IPropertyManager;
/*      */ import org.eclipse.core.internal.properties.PropertyManager2;
/*      */ import org.eclipse.core.internal.refresh.RefreshManager;
/*      */ import org.eclipse.core.internal.utils.Messages;
/*      */ import org.eclipse.core.internal.utils.Policy;
/*      */ import org.eclipse.core.internal.utils.StringPoolJob;
/*      */ import org.eclipse.core.internal.watson.ElementTree;
/*      */ import org.eclipse.core.internal.watson.ElementTreeIterator;
/*      */ import org.eclipse.core.internal.watson.IElementComparator;
/*      */ import org.eclipse.core.internal.watson.IElementContentVisitor;
/*      */ import org.eclipse.core.internal.watson.IPathRequestor;
/*      */ import org.eclipse.core.resources.IBuildConfiguration;
/*      */ import org.eclipse.core.resources.IContainer;
/*      */ import org.eclipse.core.resources.IFile;
/*      */ import org.eclipse.core.resources.IFileModificationValidator;
/*      */ import org.eclipse.core.resources.IFilterMatcherDescriptor;
/*      */ import org.eclipse.core.resources.IMarker;
/*      */ import org.eclipse.core.resources.IPathVariableManager;
/*      */ import org.eclipse.core.resources.IProject;
/*      */ import org.eclipse.core.resources.IProjectDescription;
/*      */ import org.eclipse.core.resources.IProjectNatureDescriptor;
/*      */ import org.eclipse.core.resources.IResource;
/*      */ import org.eclipse.core.resources.IResourceChangeListener;
/*      */ import org.eclipse.core.resources.IResourceRuleFactory;
/*      */ import org.eclipse.core.resources.ISaveParticipant;
/*      */ import org.eclipse.core.resources.ISavedState;
/*      */ import org.eclipse.core.resources.IWorkspace;
/*      */ import org.eclipse.core.resources.IWorkspaceDescription;
/*      */ import org.eclipse.core.resources.IWorkspaceRoot;
/*      */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*      */ import org.eclipse.core.resources.ResourcesPlugin;
/*      */ import org.eclipse.core.resources.team.IMoveDeleteHook;
/*      */ import org.eclipse.core.resources.team.TeamHook;
/*      */ import org.eclipse.core.runtime.Assert;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IConfigurationElement;
/*      */ import org.eclipse.core.runtime.ICoreRunnable;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.ISafeRunnable;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.MultiStatus;
/*      */ import org.eclipse.core.runtime.NullProgressMonitor;
/*      */ import org.eclipse.core.runtime.OperationCanceledException;
/*      */ import org.eclipse.core.runtime.Path;
/*      */ import org.eclipse.core.runtime.Platform;
/*      */ import org.eclipse.core.runtime.Plugin;
/*      */ import org.eclipse.core.runtime.SafeRunner;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.core.runtime.SubMonitor;
/*      */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*      */ import org.eclipse.core.runtime.jobs.Job;
/*      */ import org.eclipse.core.runtime.jobs.JobGroup;
/*      */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*      */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ import org.osgi.service.prefs.Preferences;
/*      */ import org.xml.sax.InputSource;
/*      */ 
/*      */ public class Workspace extends PlatformObject implements IWorkspace, ICoreConstants {
/*   96 */   public static final boolean caseSensitive = "macosx".equals(Platform.getOS()) ? false : (((new File("a")).compareTo(new File("A")) != 0));
/*      */ 
/*      */   
/*      */   protected WorkManager _workManager;
/*      */   
/*      */   protected AliasManager aliasManager;
/*      */   
/*      */   protected BuildManager buildManager;
/*      */   
/*  105 */   protected volatile IBuildConfiguration[] buildOrder = null;
/*      */   
/*      */   protected volatile ComputeProjectOrder.Digraph<IBuildConfiguration> buildOrderGraph;
/*      */   protected JobGroup buildJobGroup;
/*      */   protected CharsetManager charsetManager;
/*      */   protected ContentDescriptionManager contentDescriptionManager;
/*      */   protected boolean crashed = false;
/*  112 */   protected final IWorkspaceRoot defaultRoot = new WorkspaceRoot((IPath)Path.ROOT, this);
/*      */   protected WorkspacePreferences description;
/*      */   protected FileSystemResourceManager fileSystemManager;
/*  115 */   protected final CopyOnWriteArrayList<ILifecycleListener> lifecycleListeners = new CopyOnWriteArrayList<>();
/*      */ 
/*      */   
/*      */   protected final LocalMetaArea localMetaArea;
/*      */   
/*  120 */   protected final LocationValidator locationValidator = new LocationValidator(this);
/*      */ 
/*      */   
/*      */   protected MarkerManager markerManager;
/*      */   
/*  125 */   protected IMoveDeleteHook moveDeleteHook = null;
/*      */   protected NatureManager natureManager;
/*      */   protected FilterTypeManager filterManager;
/*  128 */   protected final AtomicLong nextMarkerId = new AtomicLong();
/*  129 */   protected final AtomicLong nextNodeId = new AtomicLong(1L);
/*      */ 
/*      */ 
/*      */   
/*      */   protected NotificationManager notificationManager;
/*      */ 
/*      */   
/*      */   protected boolean openFlag = false;
/*      */ 
/*      */   
/*      */   protected ElementTree operationTree;
/*      */ 
/*      */   
/*      */   protected PathVariableManager pathVariableManager;
/*      */ 
/*      */   
/*      */   protected IPropertyManager propertyManager;
/*      */ 
/*      */   
/*      */   protected RefreshManager refreshManager;
/*      */ 
/*      */   
/*      */   private IResourceRuleFactory ruleFactory;
/*      */ 
/*      */   
/*      */   protected SaveManager saveManager;
/*      */ 
/*      */   
/*      */   protected boolean shouldValidate = true;
/*      */ 
/*      */   
/*      */   private StringPoolJob stringPoolJob;
/*      */ 
/*      */   
/*      */   protected Synchronizer synchronizer;
/*      */ 
/*      */   
/*  166 */   protected TeamHook teamHook = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected volatile ElementTree tree;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  190 */   protected volatile Thread treeLocked = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  195 */   protected IFileModificationValidator validator = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class ProjectBuildConfigOrder
/*      */   {
/*      */     public IBuildConfiguration[] buildConfigurations;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasCycles;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IBuildConfiguration[][] knots;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ProjectBuildConfigOrder(IBuildConfiguration[] buildConfigurations, boolean hasCycles, IBuildConfiguration[][] knots) {
/*  219 */       this.buildConfigurations = buildConfigurations;
/*  220 */       this.hasCycles = hasCycles;
/*  221 */       this.knots = knots;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class BuildConfigurationComparator
/*      */     implements Comparator<IBuildConfiguration>
/*      */   {
/*      */     public int compare(IBuildConfiguration px, IBuildConfiguration py) {
/*  258 */       int cmp = py.getProject().getName().compareTo(px.getProject().getName());
/*  259 */       if (cmp == 0)
/*  260 */         cmp = py.getName().compareTo(px.getName()); 
/*  261 */       return cmp;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean clear(File root) {
/*  272 */     IFileStore fileStore = EFS.getLocalFileSystem().fromLocalFile(root);
/*      */     try {
/*  274 */       fileStore.delete(0, (IProgressMonitor)new NullProgressMonitor());
/*  275 */     } catch (CoreException coreException) {
/*  276 */       return false;
/*      */     } 
/*  278 */     return true;
/*      */   }
/*      */   
/*      */   public static WorkspaceDescription defaultWorkspaceDescription() {
/*  282 */     return new WorkspaceDescription("Workspace");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isDuplicate(Object[] array, int position) {
/*  290 */     if (array == null || position >= array.length)
/*  291 */       return false; 
/*  292 */     for (int j = position - 1; j >= 0; j--) {
/*  293 */       if (array[j].equals(array[position]))
/*  294 */         return true; 
/*  295 */     }  return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public Workspace() {
/*  300 */     this.localMetaArea = new LocalMetaArea(this);
/*  301 */     this.tree = new ElementTree();
/*      */     
/*  303 */     this.tree.immutable();
/*  304 */     this.treeLocked = Thread.currentThread();
/*  305 */     this.tree.setTreeData(newElement(8));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void aboutToBuild(Object source, int trigger) {
/*  316 */     broadcastPostChange();
/*  317 */     broadcastBuildEvent(source, 8, trigger);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addLifecycleListener(ILifecycleListener listener) {
/*  325 */     this.lifecycleListeners.addIfAbsent(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addResourceChangeListener(IResourceChangeListener listener) {
/*  330 */     this.notificationManager.addListener(listener, 7);
/*      */   }
/*      */ 
/*      */   
/*      */   public void addResourceChangeListener(IResourceChangeListener listener, int eventMask) {
/*  335 */     this.notificationManager.addListener(listener, eventMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ISavedState addSaveParticipant(Plugin plugin, ISaveParticipant participant) throws CoreException {
/*  344 */     Assert.isNotNull(plugin, "Plugin must not be null");
/*  345 */     Assert.isNotNull(participant, "Participant must not be null");
/*  346 */     return this.saveManager.addParticipant(plugin.getBundle().getSymbolicName(), participant);
/*      */   }
/*      */ 
/*      */   
/*      */   public ISavedState addSaveParticipant(String pluginId, ISaveParticipant participant) throws CoreException {
/*  351 */     Assert.isNotNull(pluginId, "Plugin id must not be null");
/*  352 */     Assert.isNotNull(participant, "Participant must not be null");
/*  353 */     return this.saveManager.addParticipant(pluginId, participant);
/*      */   }
/*      */   
/*      */   public void beginOperation(boolean createNewTree) throws CoreException {
/*  357 */     WorkManager workManager = getWorkManager();
/*  358 */     workManager.incrementNestedOperations();
/*  359 */     if (!workManager.isBalanced())
/*  360 */       Assert.isTrue(false, "Operation was not prepared."); 
/*  361 */     if (workManager.getPreparedOperationDepth() > 1) {
/*  362 */       if (createNewTree && this.tree.isImmutable()) {
/*  363 */         newWorkingTree();
/*      */       }
/*      */       return;
/*      */     } 
/*  367 */     this.operationTree = this.tree;
/*  368 */     if (createNewTree && this.tree.isImmutable())
/*  369 */       newWorkingTree(); 
/*      */   }
/*      */   
/*      */   public void broadcastBuildEvent(Object source, int type, int buildTrigger) {
/*  373 */     ResourceChangeEvent event = new ResourceChangeEvent(source, type, buildTrigger, null);
/*  374 */     this.notificationManager.broadcastChanges(this.tree, event, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void broadcastEvent(LifecycleEvent event) throws CoreException {
/*  382 */     for (ILifecycleListener listener : this.lifecycleListeners)
/*  383 */       listener.handleEvent(event); 
/*      */   }
/*      */   
/*      */   public void broadcastPostChange() {
/*  387 */     ResourceChangeEvent event = new ResourceChangeEvent(this, 1, 0, null);
/*  388 */     this.notificationManager.broadcastChanges(this.tree, event, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void recursivelyAddBuildConfigs(Collection<IBuildConfiguration> configs, IBuildConfiguration config) {
/*      */     try {
/*  398 */       IBuildConfiguration[] referenced = config.getProject().getReferencedBuildConfigs(config.getName(), false); byte b; int i; IBuildConfiguration[] arrayOfIBuildConfiguration1;
/*  399 */       for (i = (arrayOfIBuildConfiguration1 = referenced).length, b = 0; b < i; ) { IBuildConfiguration element = arrayOfIBuildConfiguration1[b];
/*  400 */         if (!configs.contains(element))
/*      */         
/*  402 */         { configs.add(element);
/*  403 */           recursivelyAddBuildConfigs(configs, element); }  b++; }
/*      */     
/*  405 */     } catch (CoreException coreException) {
/*      */       
/*  407 */       Assert.isTrue(false);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void build(int trigger, IProgressMonitor monitor) throws CoreException {
/*  413 */     buildInternal(EMPTY_BUILD_CONFIG_ARRAY, trigger, true, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void build(IBuildConfiguration[] configs, int trigger, boolean buildReferences, IProgressMonitor monitor) throws CoreException {
/*  418 */     if (configs.length == 0)
/*      */       return; 
/*  420 */     buildInternal(configs, trigger, buildReferences, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void buildInternal(IBuildConfiguration[] requestedConfigs, int trigger, boolean buildReferences, IProgressMonitor monitor) throws CoreException {
/*  437 */     boolean noEnclosingRule = (Job.getJobManager().currentRule() == null);
/*  438 */     int relaxed = (noEnclosingRule && requestedConfigs.length > 0 && allRelaxed(requestedConfigs, trigger)) ? 1 : 0;
/*  439 */     ISchedulingRule notificationRule = getRuleFactory().buildRule();
/*  440 */     ISchedulingRule currentRule = null;
/*  441 */     boolean buildParallel = (noEnclosingRule && getDescription().getMaxConcurrentBuilds() > 1 && getDescription().getBuildOrder() == null);
/*  442 */     SubMonitor subMonitor = SubMonitor.convert(monitor, 100);
/*  443 */     SubMonitor newChild = subMonitor.newChild(1);
/*      */     
/*      */     try {
/*      */       int i;
/*      */       IStatus result;
/*      */       try {
/*  449 */         prepareOperation(notificationRule, (IProgressMonitor)newChild);
/*  450 */         currentRule = notificationRule;
/*  451 */         beginOperation(true);
/*  452 */         aboutToBuild(this, trigger);
/*      */       } finally {
/*  454 */         if (relaxed) {
/*  455 */           endOperation(currentRule, false);
/*  456 */           prepareOperation(null, (IProgressMonitor)subMonitor.newChild(1));
/*  457 */           currentRule = null;
/*  458 */           beginOperation(false);
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  467 */         IBuildConfiguration[] allConfigs = requestedConfigs;
/*  468 */         ComputeProjectOrder.Digraph<IBuildConfiguration> buildGraph = null;
/*  469 */         if (allConfigs == EMPTY_BUILD_CONFIG_ARRAY) {
/*  470 */           if (trigger != 15) {
/*  471 */             if (getDescription().getBuildOrder() != null) {
/*  472 */               allConfigs = getBuildOrder();
/*      */             } else {
/*  474 */               buildGraph = getBuildGraph();
/*      */             } 
/*      */           } else {
/*      */             
/*  478 */             List<IBuildConfiguration> configArr = new ArrayList<>();
/*  479 */             IProject[] prjs = getRoot().getProjects(); byte b; int k; IProject[] arrayOfIProject1;
/*  480 */             for (k = (arrayOfIProject1 = prjs).length, b = 0; b < k; ) { IProject prj = arrayOfIProject1[b];
/*  481 */               if (prj.isAccessible())
/*  482 */                 configArr.addAll(Arrays.asList(prj.getBuildConfigs()));  b++; }
/*  483 */              allConfigs = configArr.<IBuildConfiguration>toArray(new IBuildConfiguration[configArr.size()]);
/*      */           } 
/*      */         } else {
/*      */           
/*  487 */           Set<IBuildConfiguration> refsList = new HashSet<>(); byte b; int k; IBuildConfiguration[] arrayOfIBuildConfiguration;
/*  488 */           for (k = (arrayOfIBuildConfiguration = allConfigs).length, b = 0; b < k; ) { IBuildConfiguration config = arrayOfIBuildConfiguration[b];
/*      */             
/*  490 */             if (config.getProject().isAccessible() && 
/*  491 */               config.getProject().hasBuildConfig(config.getName())) {
/*      */               
/*  493 */               refsList.add(config);
/*      */               
/*  495 */               if (buildReferences)
/*  496 */                 recursivelyAddBuildConfigs(refsList, config); 
/*      */             } 
/*      */             b++; }
/*      */           
/*  500 */           buildGraph = computeProjectBuildConfigOrderGraph(refsList);
/*      */         } 
/*  502 */         if (buildGraph != null) {
/*  503 */           buildGraph.freeze();
/*  504 */           if (Policy.DEBUG_BUILD_CYCLE && buildGraph.containsCycles()) {
/*  505 */             List<IBuildConfiguration[]> nonTrivialComponents = buildGraph.nonTrivialComponents();
/*  506 */             for (IBuildConfiguration[] iBuildConfigurations : nonTrivialComponents) {
/*  507 */               Policy.debug("Cycle: " + Arrays.toString((Object[])iBuildConfigurations));
/*      */             }
/*      */           } 
/*  510 */           allConfigs = (IBuildConfiguration[])(ComputeProjectOrder.computeVertexOrder((ComputeProjectOrder.Digraph)buildGraph, (Class)IBuildConfiguration.class)).vertexes;
/*      */         } 
/*      */         
/*  513 */         int j = buildParallel & ((buildGraph != null && buildGraph.vertexList.size() > 1) ? 1 : 0);
/*  514 */         if (j != 0) {
/*  515 */           relaxed = (noEnclosingRule && allRelaxed(allConfigs, trigger)) ? 1 : 0;
/*  516 */           i = j & relaxed;
/*      */         } 
/*  518 */         if (i != 0) {
/*  519 */           endOperation(currentRule, false);
/*  520 */           currentRule = null;
/*  521 */           result = getBuildManager().buildParallel(buildGraph, requestedConfigs, trigger, getBuildJobGroup(), 
/*  522 */               (IProgressMonitor)subMonitor.newChild(97));
/*      */         } else {
/*  524 */           result = getBuildManager().build(allConfigs, requestedConfigs, trigger, 
/*  525 */               (IProgressMonitor)subMonitor.newChild(97));
/*      */         } 
/*      */       } finally {
/*      */         
/*  529 */         if (relaxed != 0) {
/*  530 */           if (i == 0) {
/*  531 */             endOperation(currentRule, false);
/*      */           }
/*  533 */           prepareOperation(notificationRule, (IProgressMonitor)subMonitor.newChild(1));
/*  534 */           currentRule = notificationRule;
/*  535 */           beginOperation(false);
/*      */         } 
/*      */         
/*  538 */         broadcastBuildEvent(this, 16, trigger);
/*      */       } 
/*  540 */       if (!result.isOK())
/*  541 */         throw new ResourceException(result); 
/*      */     } finally {
/*  543 */       subMonitor.done();
/*      */       
/*  545 */       if (this.tree.isImmutable()) {
/*  546 */         newWorkingTree();
/*      */       }
/*  548 */       endOperation(currentRule, false);
/*      */     } 
/*      */   }
/*      */   
/*      */   private JobGroup getBuildJobGroup() {
/*  553 */     if (this.buildJobGroup == null || this.buildJobGroup.getMaxThreads() != this.description.getMaxConcurrentBuilds()) {
/*  554 */       this.buildJobGroup = new JobGroup(getClass().getName(), this.description.getMaxConcurrentBuilds(), 0);
/*      */     }
/*  556 */     return this.buildJobGroup;
/*      */   }
/*      */   
/*      */   private boolean allRelaxed(IBuildConfiguration[] requestedConfigs, int trigger) {
/*  560 */     return Arrays.<IBuildConfiguration>stream(requestedConfigs).map(cfg -> getBuildManager().getRule(cfg, paramInt, null, null)).allMatch(this::isRelaxedRule);
/*      */   }
/*      */   
/*      */   boolean isRelaxedRule(ISchedulingRule rule) {
/*  564 */     return !(rule != null && rule.contains((ISchedulingRule)getRoot()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean canCreateExtensions() {
/*  574 */     return (Platform.getBundle("org.eclipse.osgi").getState() != 16);
/*      */   }
/*      */ 
/*      */   
/*      */   public void checkpoint(boolean build) {
/*      */     try {
/*  580 */       ISchedulingRule rule = getWorkManager().getNotifyRule();
/*      */       try {
/*  582 */         prepareOperation(rule, null);
/*  583 */         beginOperation(true);
/*  584 */         broadcastPostChange();
/*      */       } finally {
/*  586 */         endOperation(rule, build);
/*      */       } 
/*  588 */     } catch (CoreException e) {
/*  589 */       Policy.log(e.getStatus().getSeverity(), e.getMessage(), (Throwable)e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close(IProgressMonitor monitor) throws CoreException {
/*  618 */     if (!isOpen())
/*      */       return; 
/*  620 */     String msg = Messages.resources_closing_0;
/*  621 */     SubMonitor subMonitor = SubMonitor.convert(monitor, msg, 20);
/*  622 */     subMonitor.subTask(msg);
/*      */     
/*  624 */     SubMonitor newChild = subMonitor.newChild(1);
/*      */     try {
/*      */       try {
/*  627 */         this.stringPoolJob.cancel();
/*      */         
/*  629 */         this.refreshManager.shutdown(null);
/*      */ 
/*      */         
/*  632 */         this.saveManager.shutdown(null);
/*  633 */         this.saveManager.reportSnapshotRequestor();
/*  634 */         prepareOperation((ISchedulingRule)getRoot(), (IProgressMonitor)newChild);
/*      */         
/*  636 */         this.notificationManager.shutdown(null);
/*  637 */         beginOperation(true);
/*  638 */         IProject[] projects = getRoot().getProjects(8);
/*  639 */         subMonitor.setWorkRemaining(projects.length + 2); byte b; int i; IProject[] arrayOfIProject1;
/*  640 */         for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/*      */           
/*  642 */           broadcastEvent(LifecycleEvent.newEvent(1, (IResource)project));
/*  643 */           subMonitor.worked(1);
/*      */           b++; }
/*      */         
/*  646 */         deleteResource((IResource)getRoot());
/*  647 */         this.openFlag = false;
/*      */       }
/*      */       finally {
/*      */         
/*  651 */         shutdown((IProgressMonitor)subMonitor.newChild(2, 1));
/*      */       } 
/*      */     } finally {
/*      */       
/*  655 */       Job.getJobManager().endRule((ISchedulingRule)getRoot());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ComputeProjectOrder.VertexOrder<IProject> computeFullProjectOrder() {
/*  688 */     SortedSet<IProject> allAccessibleProjects = new TreeSet<>(Comparator.<IProject, Comparable>comparing(IResource::getName).reversed());
/*  689 */     IProject[] allProjects = getRoot().getProjects(8);
/*      */     
/*  691 */     List<IProject[]> edges = (List)new ArrayList<>(allProjects.length); byte b; int i; IProject[] arrayOfIProject1;
/*  692 */     for (i = (arrayOfIProject1 = allProjects).length, b = 0; b < i; ) { IProject p = arrayOfIProject1[b];
/*  693 */       Project project = (Project)p;
/*      */       
/*  695 */       if (project.isAccessible()) {
/*      */         
/*  697 */         ProjectDescription desc = project.internalGetDescription();
/*  698 */         if (desc != null) {
/*      */ 
/*      */           
/*  701 */           IProject[] refs = desc.getAllReferences(project, false);
/*  702 */           allAccessibleProjects.add(project); byte b1; int j; IProject[] arrayOfIProject2;
/*  703 */           for (j = (arrayOfIProject2 = refs).length, b1 = 0; b1 < j; ) { IProject ref = arrayOfIProject2[b1];
/*      */             
/*  705 */             if (ref.isAccessible() && !ref.equals(project))
/*  706 */               edges.add(new IProject[] { project, ref });  b1++; } 
/*      */         } 
/*      */       }  b++; }
/*  709 */      return ComputeProjectOrder.computeVertexOrder(allAccessibleProjects, edges, IProject.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ComputeProjectOrder.VertexOrder<IBuildConfiguration> computeActiveBuildConfigOrder() {
/*  738 */     ComputeProjectOrder.Digraph<IBuildConfiguration> activeBuildConfigurationGraph = computeActiveBuildConfigGraph();
/*  739 */     return ComputeProjectOrder.computeVertexOrder(activeBuildConfigurationGraph, IBuildConfiguration.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ComputeProjectOrder.Digraph<IBuildConfiguration> computeActiveBuildConfigGraph() {
/*  749 */     SortedSet<IBuildConfiguration> allAccessibleBuildConfigs = new TreeSet<>(new BuildConfigurationComparator());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  755 */     IProject[] allProjects = getRoot().getProjects(8);
/*  756 */     List<IBuildConfiguration[]> edges = (List)new ArrayList<>(allProjects.length); byte b; int i;
/*      */     IProject[] arrayOfIProject1;
/*  758 */     for (i = (arrayOfIProject1 = allProjects).length, b = 0; b < i; ) { IProject allProject = arrayOfIProject1[b];
/*  759 */       Project project = (Project)allProject;
/*      */       
/*  761 */       if (project.isAccessible())
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*  766 */         if (!allAccessibleBuildConfigs.contains(project.internalGetActiveBuildConfig())) {
/*  767 */           allAccessibleBuildConfigs.add(project.internalGetActiveBuildConfig());
/*  768 */           Deque<IBuildConfiguration> stack = new ArrayDeque<>();
/*  769 */           stack.push(project.internalGetActiveBuildConfig());
/*      */           
/*  771 */           while (!stack.isEmpty()) {
/*  772 */             IBuildConfiguration buildConfiguration = stack.pop();
/*      */ 
/*      */ 
/*      */             
/*  776 */             Project subProject = (Project)buildConfiguration.getProject();
/*  777 */             IBuildConfiguration[] refs = subProject.internalGetReferencedBuildConfigs(buildConfiguration.getName(), false); byte b1; int j; IBuildConfiguration[] arrayOfIBuildConfiguration1;
/*  778 */             for (j = (arrayOfIBuildConfiguration1 = refs).length, b1 = 0; b1 < j; ) { IBuildConfiguration ref = arrayOfIBuildConfiguration1[b1];
/*      */               
/*  780 */               if (!ref.equals(buildConfiguration)) {
/*      */ 
/*      */ 
/*      */                 
/*  784 */                 edges.add(new IBuildConfiguration[] { buildConfiguration, ref });
/*      */ 
/*      */                 
/*  787 */                 if (!allAccessibleBuildConfigs.contains(ref))
/*      */                 
/*      */                 { 
/*  790 */                   allAccessibleBuildConfigs.add(ref);
/*      */ 
/*      */                   
/*  793 */                   stack.push(ref); } 
/*      */               }  b1++; }
/*      */           
/*      */           } 
/*      */         }  }  b++; }
/*  798 */      return ComputeProjectOrder.computeGraph(allAccessibleBuildConfigs, (Collection<IBuildConfiguration[]>)edges, IBuildConfiguration.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   private ComputeProjectOrder.VertexOrder<IBuildConfiguration> computeFullBuildConfigOrder() {
/*  828 */     ComputeProjectOrder.Digraph<IBuildConfiguration> graph = computeFullBuildConfigGraph();
/*  829 */     return ComputeProjectOrder.computeVertexOrder(graph, IBuildConfiguration.class);
/*      */   }
/*      */ 
/*      */   
/*      */   private ComputeProjectOrder.Digraph<IBuildConfiguration> computeFullBuildConfigGraph() {
/*  834 */     SortedSet<IBuildConfiguration> allAccessibleBuildConfigurations = new TreeSet<>(new BuildConfigurationComparator());
/*      */     
/*  836 */     IProject[] allProjects = getRoot().getProjects(8);
/*  837 */     List<IBuildConfiguration[]> edges = (List)new ArrayList<>(allProjects.length); byte b; int i;
/*      */     IProject[] arrayOfIProject1;
/*  839 */     for (i = (arrayOfIProject1 = allProjects).length, b = 0; b < i; ) { IProject p = arrayOfIProject1[b];
/*  840 */       Project project = (Project)p;
/*      */       
/*  842 */       if (project.isAccessible()) {
/*      */ 
/*      */         
/*  845 */         IBuildConfiguration[] configs = project.internalGetBuildConfigs(false); byte b1; int j; IBuildConfiguration[] arrayOfIBuildConfiguration1;
/*  846 */         for (j = (arrayOfIBuildConfiguration1 = configs).length, b1 = 0; b1 < j; ) { IBuildConfiguration config = arrayOfIBuildConfiguration1[b1];
/*  847 */           allAccessibleBuildConfigurations.add(config);
/*  848 */           IBuildConfiguration[] refs = project.internalGetReferencedBuildConfigs(config.getName(), false); byte b2; int k; IBuildConfiguration[] arrayOfIBuildConfiguration2;
/*  849 */           for (k = (arrayOfIBuildConfiguration2 = refs).length, b2 = 0; b2 < k; ) { IBuildConfiguration ref = arrayOfIBuildConfiguration2[b2];
/*      */             
/*  851 */             if (!ref.equals(config))
/*      */             
/*      */             { 
/*      */               
/*  855 */               allAccessibleBuildConfigurations.add(ref);
/*  856 */               edges.add(new IBuildConfiguration[] { config, ref }); }  b2++; }
/*      */            b1++; }
/*      */       
/*      */       }  b++; }
/*  860 */      return ComputeProjectOrder.computeGraph(allAccessibleBuildConfigurations, (Collection<IBuildConfiguration[]>)edges, IBuildConfiguration.class);
/*      */   }
/*      */   
/*      */   private static IWorkspace.ProjectOrder vertexOrderToProjectOrder(ComputeProjectOrder.VertexOrder<IProject> order) {
/*  864 */     IProject[] projects = new IProject[((IProject[])order.vertexes).length];
/*  865 */     System.arraycopy(order.vertexes, 0, projects, 0, ((IProject[])order.vertexes).length);
/*  866 */     IProject[][] knots = new IProject[((IProject[][])order.knots).length][];
/*  867 */     for (int i = 0; i < ((IProject[][])order.knots).length; i++) {
/*  868 */       knots[i] = new IProject[(((IProject[][])order.knots)[i]).length];
/*  869 */       System.arraycopy(((IProject[][])order.knots)[i], 0, knots[i], 0, (((IProject[][])order.knots)[i]).length);
/*      */     } 
/*  871 */     return new IWorkspace.ProjectOrder(projects, order.hasCycles, knots);
/*      */   }
/*      */   
/*      */   private static ProjectBuildConfigOrder vertexOrderToProjectBuildConfigOrder(ComputeProjectOrder.VertexOrder<IBuildConfiguration> order) {
/*  875 */     IBuildConfiguration[] buildConfigs = new IBuildConfiguration[((IBuildConfiguration[])order.vertexes).length];
/*  876 */     System.arraycopy(order.vertexes, 0, buildConfigs, 0, ((IBuildConfiguration[])order.vertexes).length);
/*  877 */     IBuildConfiguration[][] knots = new IBuildConfiguration[((IBuildConfiguration[][])order.knots).length][];
/*  878 */     for (int i = 0; i < ((IBuildConfiguration[][])order.knots).length; i++) {
/*  879 */       knots[i] = new IBuildConfiguration[(((IBuildConfiguration[][])order.knots)[i]).length];
/*  880 */       System.arraycopy(((IBuildConfiguration[][])order.knots)[i], 0, knots[i], 0, (((IBuildConfiguration[][])order.knots)[i]).length);
/*      */     } 
/*  882 */     return new ProjectBuildConfigOrder(buildConfigs, order.hasCycles, knots);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public IProject[][] computePrerequisiteOrder(IProject[] targets) {
/*  888 */     return computePrerequisiteOrder1(targets);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IProject[][] computePrerequisiteOrder1(IProject[] projects) {
/*  899 */     IWorkspace.ProjectOrder r = computeProjectOrder(projects);
/*  900 */     if (!r.hasCycles) {
/*  901 */       return new IProject[][] { r.projects, {} };
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  906 */     Set<IProject> bad = new HashSet<>();
/*      */     
/*  908 */     Set<IProject> keepers = new HashSet<>(Arrays.asList(r.projects)); byte b; int i; IProject[][] arrayOfIProject;
/*  909 */     for (i = (arrayOfIProject = r.knots).length, b = 0; b < i; ) { IProject[] knot = arrayOfIProject[b]; byte b1; int j; IProject[] arrayOfIProject1;
/*  910 */       for (j = (arrayOfIProject1 = knot).length, b1 = 0; b1 < j; ) { IProject project = arrayOfIProject1[b1];
/*      */         
/*  912 */         if (keepers.contains(project))
/*  913 */           bad.add(project);  b1++; }
/*      */       
/*      */       b++; }
/*      */     
/*  917 */     IProject[] result2 = new IProject[bad.size()];
/*  918 */     bad.toArray(result2);
/*      */     
/*  920 */     List<IProject> p = new LinkedList<>();
/*  921 */     p.addAll(Arrays.asList(r.projects));
/*  922 */     for (Iterator<IProject> it = p.listIterator(); it.hasNext(); ) {
/*  923 */       IProject project = it.next();
/*  924 */       if (bad.contains(project))
/*      */       {
/*  926 */         it.remove();
/*      */       }
/*      */     } 
/*  929 */     IProject[] result1 = new IProject[p.size()];
/*  930 */     p.toArray(result1);
/*  931 */     return new IProject[][] { result1, result2 };
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public IWorkspace.ProjectOrder computeProjectOrder(IProject[] projects) {
/*  937 */     ComputeProjectOrder.VertexOrder<IProject> fullProjectOrder = computeFullProjectOrder();
/*      */ 
/*      */     
/*  940 */     Set<IProject> projectSet = new HashSet<>(projects.length);
/*  941 */     projectSet.addAll(Arrays.asList(projects));
/*  942 */     Predicate<IProject> filter = vertex -> !paramSet.contains(vertex);
/*      */ 
/*      */     
/*  945 */     return vertexOrderToProjectOrder(ComputeProjectOrder.filterVertexOrder(fullProjectOrder, filter, IProject.class));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ProjectBuildConfigOrder computeProjectBuildConfigOrder(IBuildConfiguration[] buildConfigs) {
/*  984 */     ComputeProjectOrder.VertexOrder<IBuildConfiguration> fullBuildConfigOrder = computeFullBuildConfigOrder();
/*      */ 
/*      */     
/*  987 */     Set<IBuildConfiguration> projectConfigSet = new HashSet<>(buildConfigs.length);
/*  988 */     projectConfigSet.addAll(Arrays.asList(buildConfigs));
/*  989 */     Predicate<IBuildConfiguration> filter = vertex -> !paramSet.contains(vertex);
/*      */ 
/*      */     
/*  992 */     return vertexOrderToProjectBuildConfigOrder(ComputeProjectOrder.filterVertexOrder(fullBuildConfigOrder, filter, IBuildConfiguration.class));
/*      */   }
/*      */   
/*      */   private ComputeProjectOrder.Digraph<IBuildConfiguration> computeProjectBuildConfigOrderGraph(Collection<IBuildConfiguration> buildConfigs) {
/*  996 */     ComputeProjectOrder.Digraph<IBuildConfiguration> fullBuildConfigOrder = computeFullBuildConfigGraph();
/*      */ 
/*      */     
/*  999 */     Set<IBuildConfiguration> projectConfigSet = new HashSet<>(buildConfigs);
/* 1000 */     Predicate<IBuildConfiguration> filter = vertex -> !paramSet.contains(vertex);
/*      */ 
/*      */     
/* 1003 */     return ComputeProjectOrder.buildFilteredDigraph(fullBuildConfigOrder, filter, IBuildConfiguration.class);
/*      */   }
/*      */ 
/*      */   
/*      */   public IStatus copy(IResource[] resources, IPath destination, boolean force, IProgressMonitor monitor) throws CoreException {
/* 1008 */     int updateFlags = force ? 1 : 0;
/* 1009 */     return copy(resources, destination, updateFlags, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public IStatus copy(IResource[] resources, IPath destination, int updateFlags, IProgressMonitor monitor) throws CoreException {
/* 1015 */     Assert.isLegal((resources != null));
/*      */     
/* 1017 */     if (resources.length == 0) {
/* 1018 */       return Status.OK_STATUS;
/*      */     }
/*      */     
/* 1021 */     resources = (IResource[])resources.clone();
/* 1022 */     SubMonitor subMonitor = SubMonitor.convert(monitor, Messages.resources_copying_0, resources.length);
/* 1023 */     IPath parentPath = null;
/* 1024 */     String message = Messages.resources_copyProblem;
/* 1025 */     MultiStatus status = new MultiStatus("org.eclipse.core.resources", 566, message, null);
/*      */     try {
/* 1027 */       prepareOperation((ISchedulingRule)getRoot(), (IProgressMonitor)subMonitor);
/* 1028 */       beginOperation(true);
/* 1029 */       for (int i = 0; i < resources.length; i++) {
/* 1030 */         IResource resource = resources[i];
/* 1031 */         if (resource == null || isDuplicate((Object[])resources, i))
/* 1032 */         { subMonitor.split(1); }
/*      */         
/*      */         else
/*      */         
/* 1036 */         { if (parentPath == null)
/* 1037 */             parentPath = resource.getFullPath().removeLastSegments(1); 
/* 1038 */           if (parentPath.equals(resource.getFullPath().removeLastSegments(1))) {
/*      */             
/*      */             try {
/* 1041 */               IPath destinationPath = destination.append(resource.getName());
/* 1042 */               IStatus requirements = ((Resource)resource).checkCopyRequirements(destinationPath, resource.getType(), updateFlags);
/* 1043 */               if (requirements.isOK()) {
/*      */                 try {
/* 1045 */                   resource.copy(destinationPath, updateFlags, Policy.subMonitorFor(monitor, 1));
/* 1046 */                 } catch (CoreException e) {
/* 1047 */                   status.merge(e.getStatus());
/*      */                 } 
/*      */               } else {
/* 1050 */                 status.merge(requirements);
/*      */               } 
/* 1052 */             } catch (CoreException e) {
/* 1053 */               status.merge(e.getStatus());
/*      */             } 
/*      */           } else {
/* 1056 */             message = NLS.bind(Messages.resources_notChild, resources[i].getFullPath(), parentPath);
/* 1057 */             status.merge((IStatus)new ResourceStatus(76, resources[i].getFullPath(), message));
/*      */           } 
/* 1059 */           subMonitor.worked(1); } 
/*      */       } 
/* 1061 */     } catch (OperationCanceledException e) {
/* 1062 */       getWorkManager().operationCanceled();
/* 1063 */       throw e;
/*      */     } finally {
/* 1065 */       subMonitor.done();
/* 1066 */       endOperation((ISchedulingRule)getRoot(), true);
/*      */     } 
/* 1068 */     if (status.matches(4))
/* 1069 */       throw new ResourceException(status); 
/* 1070 */     return status.isOK() ? Status.OK_STATUS : (IStatus)status;
/*      */   }
/*      */   
/*      */   protected void copyTree(IResource source, IPath destination, int depth, int updateFlags, boolean keepSyncInfo) throws CoreException {
/* 1074 */     copyTree(source, destination, depth, updateFlags, keepSyncInfo, false, (source.getType() == 4));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void copyTree(IResource source, IPath destination, int depth, int updateFlags, boolean keepSyncInfo, boolean moveResources, boolean movingProject) throws CoreException {
/*      */     int destinationType;
/* 1082 */     IResource destinationResource = getRoot().findMember(destination, true);
/*      */     
/* 1084 */     if (destinationResource == null) {
/* 1085 */       if (source.getType() == 1) {
/* 1086 */         destinationType = 1;
/* 1087 */       } else if (destination.segmentCount() == 1) {
/* 1088 */         destinationType = 4;
/*      */       } else {
/* 1090 */         destinationType = 2;
/* 1091 */       }  destinationResource = newResource(destination, destinationType);
/*      */     } else {
/* 1093 */       destinationType = destinationResource.getType();
/*      */     } 
/*      */     
/* 1096 */     ResourceInfo sourceInfo = ((Resource)source).getResourceInfo(true, false);
/* 1097 */     if (destinationType != source.getType()) {
/* 1098 */       sourceInfo = (ResourceInfo)sourceInfo.clone();
/* 1099 */       sourceInfo.setType(destinationType);
/*      */     } 
/* 1101 */     ResourceInfo newInfo = createResource(destinationResource, sourceInfo, false, true, keepSyncInfo);
/*      */ 
/*      */ 
/*      */     
/* 1105 */     newInfo.setNodeId(sourceInfo.getNodeId());
/*      */ 
/*      */     
/* 1108 */     newInfo.setFlags(newInfo.getFlags() | sourceInfo.getFlags() & 0x2);
/* 1109 */     newInfo.setFileStoreRoot(null);
/*      */ 
/*      */     
/* 1112 */     newInfo.clear(393216);
/*      */ 
/*      */     
/* 1115 */     if (source.isLinked()) {
/*      */       LinkDescription linkDescription;
/* 1117 */       URI sourceLocationURI = transferVariableDefinition(source, destinationResource, source.getLocationURI());
/* 1118 */       if ((updateFlags & 0x20) != 0 || ((Resource)source).isUnderVirtual()) {
/*      */         
/* 1120 */         newInfo.set(65536);
/* 1121 */         linkDescription = new LinkDescription(destinationResource, sourceLocationURI);
/*      */       } else {
/*      */         
/* 1124 */         newInfo.clear(65536);
/* 1125 */         linkDescription = null;
/*      */       } 
/* 1127 */       if (moveResources && !movingProject && (
/* 1128 */         (Project)source.getProject()).internalGetDescription().setLinkLocation(source.getProjectRelativePath(), null)) {
/* 1129 */         ((Project)source.getProject()).writeDescription(updateFlags);
/*      */       }
/* 1131 */       Project project = (Project)destinationResource.getProject();
/* 1132 */       project.internalGetDescription().setLinkLocation(destinationResource.getProjectRelativePath(), linkDescription);
/* 1133 */       project.writeDescription(updateFlags);
/* 1134 */       newInfo.setFileStoreRoot(null);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1139 */     if (!movingProject && source instanceof Container && source.getProject().exists() && (
/* 1140 */       (Container)source).hasFilters()) {
/* 1141 */       Project sourceProject = (Project)source.getProject();
/* 1142 */       LinkedList<FilterDescription> originalDescriptions = sourceProject.internalGetDescription().getFilter(source.getProjectRelativePath());
/* 1143 */       LinkedList<FilterDescription> filterDescriptions = FilterDescription.copy(originalDescriptions, destinationResource);
/* 1144 */       if (moveResources && (
/* 1145 */         (Project)source.getProject()).internalGetDescription().setFilters(source.getProjectRelativePath(), null)) {
/* 1146 */         ((Project)source.getProject()).writeDescription(updateFlags);
/*      */       }
/* 1148 */       Project project = (Project)destinationResource.getProject();
/* 1149 */       project.internalGetDescription().setFilters(destinationResource.getProjectRelativePath(), filterDescriptions);
/* 1150 */       project.writeDescription(updateFlags);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1155 */     if (depth == 0 || source.getType() == 1)
/*      */       return; 
/* 1157 */     if (depth == 1) {
/* 1158 */       depth = 0;
/*      */     }
/* 1160 */     boolean projectCopy = (source.getType() == 4 && destinationType == 4);
/* 1161 */     if (projectCopy) {
/* 1162 */       IResource dotProject = ((Project)source).findMember(".project");
/* 1163 */       if (dotProject != null)
/* 1164 */         copyTree(dotProject, destination.append(dotProject.getName()), depth, updateFlags, keepSyncInfo, moveResources, movingProject); 
/*      */     } 
/* 1166 */     IResource[] children = ((IContainer)source).members(10); byte b; int i; IResource[] arrayOfIResource1;
/* 1167 */     for (i = (arrayOfIResource1 = children).length, b = 0; b < i; ) { IResource element = arrayOfIResource1[b];
/* 1168 */       String childName = element.getName();
/* 1169 */       if (!projectCopy || !childName.equals(".project")) {
/* 1170 */         IPath childPath = destination.append(childName);
/* 1171 */         copyTree(element, childPath, depth, updateFlags, keepSyncInfo, moveResources, movingProject);
/*      */       } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */   public URI transferVariableDefinition(IResource source, IResource dest, URI sourceURI) throws CoreException {
/* 1177 */     IPath srcLoc = source.getLocation();
/* 1178 */     IPath srcRawLoc = source.getRawLocation();
/* 1179 */     if (srcLoc != null && srcRawLoc != null && !srcLoc.equals(srcRawLoc))
/*      */     {
/* 1181 */       if (!source.getProject().equals(dest.getProject())) {
/* 1182 */         String variable = srcRawLoc.segment(0);
/* 1183 */         variable = copyVariable(source, dest, variable);
/* 1184 */         IPath newLocation = Path.fromPortableString(variable).append(srcRawLoc.removeFirstSegments(1));
/* 1185 */         sourceURI = toURI(newLocation);
/*      */       } else {
/* 1187 */         sourceURI = toURI(srcRawLoc);
/*      */       } 
/*      */     }
/* 1190 */     return sourceURI;
/*      */   }
/*      */   
/*      */   URI toURI(IPath path) {
/* 1194 */     if (path.isAbsolute())
/* 1195 */       return URIUtil.toURI(path); 
/*      */     try {
/* 1197 */       return new URI(null, null, path.toPortableString(), null);
/* 1198 */     } catch (URISyntaxException uRISyntaxException) {
/* 1199 */       return URIUtil.toURI(path);
/*      */     } 
/*      */   }
/*      */   
/*      */   String copyVariable(IResource source, IResource dest, String variable) throws CoreException {
/* 1204 */     IPathVariableManager destPathVariableManager = dest.getPathVariableManager();
/* 1205 */     IPathVariableManager srcPathVariableManager = source.getPathVariableManager();
/*      */     
/* 1207 */     IPath srcValue = URIUtil.toPath(srcPathVariableManager.getURIValue(variable));
/* 1208 */     if (srcValue == null)
/*      */     {
/* 1210 */       return PathVariableUtil.getUniqueVariableName(variable, dest); } 
/* 1211 */     IPath resolvedSrcValue = URIUtil.toPath(srcPathVariableManager.resolveURI(URIUtil.toURI(srcValue)));
/*      */     
/* 1213 */     boolean variableExisted = false;
/*      */     
/* 1215 */     if (destPathVariableManager.isDefined(variable)) {
/* 1216 */       variableExisted = true;
/* 1217 */       IPath destValue = URIUtil.toPath(destPathVariableManager.getURIValue(variable));
/* 1218 */       if (destValue != null && URIUtil.toPath(destPathVariableManager.resolveURI(URIUtil.toURI(destValue))).equals(resolvedSrcValue)) {
/* 1219 */         return variable;
/*      */       }
/*      */     } 
/* 1222 */     String[] variables = destPathVariableManager.getPathVariableNames(); byte b; int i; String[] arrayOfString1;
/* 1223 */     for (i = (arrayOfString1 = variables).length, b = 0; b < i; ) { String other = arrayOfString1[b];
/* 1224 */       if (PathVariableUtil.isPreferred(other)) {
/*      */         
/* 1226 */         IPath resolveDestVariable = URIUtil.toPath(destPathVariableManager.resolveURI(destPathVariableManager.getURIValue(other)));
/* 1227 */         if (resolveDestVariable != null && resolveDestVariable.equals(resolvedSrcValue)) {
/* 1228 */           return other;
/*      */         }
/*      */       } 
/*      */       
/*      */       b++; }
/*      */     
/* 1234 */     String destVariable = PathVariableUtil.getUniqueVariableName(variable, dest);
/*      */     
/* 1236 */     boolean shouldConvertToRelative = true;
/* 1237 */     if (!srcValue.equals(resolvedSrcValue) && !variableExisted) {
/*      */ 
/*      */       
/* 1240 */       String[] referencedVariables = PathVariableUtil.splitVariableNames(srcValue.toPortableString());
/* 1241 */       shouldConvertToRelative = false;
/*      */ 
/*      */       
/* 1244 */       if (referencedVariables.length == 1 && 
/* 1245 */         PathVariableUtil.isParentVariable(referencedVariables[0])) {
/* 1246 */         shouldConvertToRelative = true;
/*      */       }
/*      */       
/* 1249 */       if (!shouldConvertToRelative) {
/* 1250 */         String[] segments = PathVariableUtil.splitVariablesAndContent(srcValue.toPortableString());
/* 1251 */         StringBuilder result = new StringBuilder(); byte b1; int j; String[] arrayOfString2;
/* 1252 */         for (j = (arrayOfString2 = segments).length, b1 = 0; b1 < j; ) { String segment = arrayOfString2[b1];
/* 1253 */           String var = PathVariableUtil.extractVariable(segment);
/* 1254 */           if (var.length() > 0) {
/* 1255 */             String copiedVariable = copyVariable(source, dest, var);
/* 1256 */             int index = segment.indexOf(var);
/* 1257 */             if (index != -1) {
/* 1258 */               result.append(segment.substring(0, index));
/* 1259 */               result.append(copiedVariable);
/* 1260 */               int start = index + var.length();
/* 1261 */               int end = segment.length();
/* 1262 */               result.append(segment.substring(start, end));
/*      */             } 
/*      */           } else {
/* 1265 */             result.append(segment);
/*      */           }  b1++; }
/* 1267 */          srcValue = Path.fromPortableString(result.toString());
/*      */       } 
/*      */     } 
/* 1270 */     if (shouldConvertToRelative) {
/* 1271 */       IPath relativeSrcValue = PathVariableUtil.convertToPathRelativeMacro(destPathVariableManager, resolvedSrcValue, dest, true, null);
/* 1272 */       if (relativeSrcValue != null)
/* 1273 */         srcValue = relativeSrcValue; 
/*      */     } 
/* 1275 */     destPathVariableManager.setURIValue(destVariable, URIUtil.toURI(srcValue));
/* 1276 */     return destVariable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int countResources(IPath root, int depth, boolean phantom) {
/*      */     int[] count;
/*      */     IElementContentVisitor visitor;
/* 1287 */     if (!this.tree.includes(root))
/* 1288 */       return 0; 
/* 1289 */     switch (depth) {
/*      */       case 0:
/* 1291 */         return 1;
/*      */       case 1:
/* 1293 */         return 1 + this.tree.getChildCount(root);
/*      */       case 2:
/* 1295 */         count = new int[1];
/* 1296 */         visitor = ((aTree, requestor, elementContents) -> {
/*      */             if (paramBoolean || !((ResourceInfo)elementContents).isSet(8))
/*      */               paramArrayOfint[0] = paramArrayOfint[0] + 1; 
/*      */             return true;
/*      */           });
/* 1301 */         (new ElementTreeIterator(this.tree, root)).iterate(visitor);
/* 1302 */         return count[0];
/*      */     } 
/* 1304 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceInfo createResource(IResource resource, boolean phantom) throws CoreException {
/* 1317 */     return createResource(resource, null, phantom, false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceInfo createResource(IResource resource, int updateFlags) throws CoreException {
/* 1325 */     ResourceInfo info = createResource(resource, null, false, false, false);
/* 1326 */     if ((updateFlags & 0x400) != 0)
/* 1327 */       info.set(16384); 
/* 1328 */     if ((updateFlags & 0x800) != 0)
/* 1329 */       info.set(32768); 
/* 1330 */     if ((updateFlags & 0x1000) != 0) {
/* 1331 */       info.set(2097152);
/*      */     }
/*      */     
/* 1334 */     return info;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceInfo createResource(IResource resource, ResourceInfo info, boolean phantom, boolean overwrite, boolean keepSyncInfo) throws CoreException {
/* 1352 */     info = (info == null) ? newElement(resource.getType()) : (ResourceInfo)info.clone();
/* 1353 */     ResourceInfo original = getResourceInfo(resource.getFullPath(), true, false);
/* 1354 */     if (phantom) {
/* 1355 */       info.set(8);
/* 1356 */       info.clearModificationStamp();
/*      */     } 
/*      */     
/* 1359 */     if (original == null) {
/*      */ 
/*      */       
/* 1362 */       if (!keepSyncInfo)
/* 1363 */         info.setSyncInfo(null); 
/* 1364 */       this.tree.createElement(resource.getFullPath(), info);
/*      */     
/*      */     }
/* 1367 */     else if (overwrite || (!phantom && original.isSet(8))) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1374 */       if (!keepSyncInfo) {
/* 1375 */         info.setSyncInfo(original.getSyncInfo(true));
/*      */       }
/*      */       
/* 1378 */       info.set(4096);
/* 1379 */       this.tree.setElementData(resource.getFullPath(), info);
/*      */     } else {
/* 1381 */       String message = NLS.bind(Messages.resources_mustNotExist, resource.getFullPath());
/* 1382 */       throw new ResourceException(367, resource.getFullPath(), message, null);
/*      */     } 
/*      */     
/* 1385 */     return info;
/*      */   }
/*      */ 
/*      */   
/*      */   public IStatus delete(IResource[] resources, boolean force, IProgressMonitor monitor) throws CoreException {
/* 1390 */     int updateFlags = force ? 1 : 0;
/* 1391 */     updateFlags |= 0x2;
/* 1392 */     return delete(resources, updateFlags, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public IStatus delete(IResource[] resources, int updateFlags, IProgressMonitor monitor) throws CoreException {
/* 1398 */     String message = Messages.resources_deleteProblem;
/* 1399 */     MultiStatus result = new MultiStatus("org.eclipse.core.resources", 566, message, 
/* 1400 */         null);
/* 1401 */     if (resources.length == 0) {
/* 1402 */       return (IStatus)result;
/*      */     }
/* 1404 */     resources = (IResource[])resources.clone();
/* 1405 */     SubMonitor subMonitor = SubMonitor.convert(monitor, message, resources.length);
/*      */     try {
/* 1407 */       prepareOperation((ISchedulingRule)getRoot(), (IProgressMonitor)subMonitor);
/* 1408 */       beginOperation(true); byte b; int i; IResource[] arrayOfIResource;
/* 1409 */       for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource r = arrayOfIResource[b];
/* 1410 */         Resource resource = (Resource)r;
/* 1411 */         if (resource == null) {
/* 1412 */           subMonitor.split(1);
/*      */         } else {
/*      */           
/*      */           try {
/* 1416 */             resource.delete(updateFlags, (IProgressMonitor)subMonitor.newChild(1));
/* 1417 */           } catch (CoreException e) {
/*      */             
/* 1419 */             ResourceInfo info = resource.getResourceInfo(false, false);
/* 1420 */             if (resource.exists(resource.getFlags(info), false)) {
/* 1421 */               message = NLS.bind(Messages.resources_couldnotDelete, resource.getFullPath());
/* 1422 */               result.merge((IStatus)new ResourceStatus(273, resource.getFullPath(), 
/* 1423 */                     message));
/* 1424 */               result.merge(e.getStatus());
/*      */             } 
/*      */           } 
/* 1427 */           subMonitor.worked(1);
/*      */         }  b++; }
/* 1429 */        if (result.matches(4))
/* 1430 */         throw new ResourceException(result); 
/* 1431 */       return (IStatus)result;
/* 1432 */     } catch (OperationCanceledException e) {
/* 1433 */       getWorkManager().operationCanceled();
/* 1434 */       throw e;
/*      */     } finally {
/* 1436 */       subMonitor.done();
/* 1437 */       endOperation((ISchedulingRule)getRoot(), true);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void deleteMarkers(IMarker[] markers) throws CoreException {
/* 1443 */     Assert.isNotNull(markers);
/* 1444 */     if (markers.length == 0) {
/*      */       return;
/*      */     }
/* 1447 */     markers = (IMarker[])markers.clone();
/*      */     
/* 1449 */     try { prepareOperation(null, null);
/* 1450 */       beginOperation(true); byte b; int i; IMarker[] arrayOfIMarker;
/* 1451 */       for (i = (arrayOfIMarker = markers).length, b = 0; b < i; ) { IMarker marker = arrayOfIMarker[b];
/* 1452 */         if (marker != null && marker.getResource() != null)
/* 1453 */           this.markerManager.removeMarker(marker.getResource(), marker.getId());  b++; }
/*      */        }
/* 1455 */     finally { endOperation(null, false); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void deleteResource(IResource resource) {
/* 1467 */     IPath path = resource.getFullPath();
/* 1468 */     if (path.equals(Path.ROOT))
/* 1469 */     { IProject[] children = getRoot().getProjects(8); byte b; int i; IProject[] arrayOfIProject1;
/* 1470 */       for (i = (arrayOfIProject1 = children).length, b = 0; b < i; ) { IProject element = arrayOfIProject1[b];
/* 1471 */         this.tree.deleteElement(element.getFullPath()); b++; }
/*      */        }
/* 1473 */     else { this.tree.deleteElement(path); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void endOperation(ISchedulingRule rule, boolean build) throws CoreException {
/* 1483 */     WorkManager workManager = getWorkManager();
/*      */     
/* 1485 */     if (workManager.checkInFailed(rule)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1490 */     boolean hasTreeChanges = false;
/* 1491 */     boolean depthOne = false;
/*      */     
/* 1493 */     try { workManager.setBuild(build);
/*      */       
/* 1495 */       depthOne = (workManager.getPreparedOperationDepth() == 1);
/* 1496 */       if (!this.notificationManager.shouldNotify() && !depthOne) {
/* 1497 */         this.notificationManager.requestNotify();
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*      */       try {
/* 1503 */         this.notificationManager.beginNotify();
/*      */         
/* 1505 */         Assert.isTrue((workManager.getPreparedOperationDepth() > 0), "Mismatched begin/endOperation");
/*      */ 
/*      */ 
/*      */         
/* 1509 */         workManager.rebalanceNestedOperations();
/*      */ 
/*      */         
/* 1512 */         hasTreeChanges = workManager.shouldBuild();
/*      */         
/* 1514 */         if (hasTreeChanges)
/* 1515 */           hasTreeChanges = (this.operationTree != null && ElementTree.hasChanges(this.tree, this.operationTree, (IElementComparator)ResourceComparator.getBuildComparator(), true)); 
/* 1516 */         broadcastPostChange();
/*      */         
/* 1518 */         this.saveManager.snapshotIfNeeded(hasTreeChanges);
/*      */       } finally {
/*      */         
/* 1521 */         if (depthOne) {
/* 1522 */           this.tree.immutable();
/* 1523 */           this.operationTree = null;
/*      */         } else {
/* 1525 */           newWorkingTree();
/*      */         } 
/*      */       }  }
/* 1528 */     finally { workManager.checkOut(rule); }
/*      */     
/* 1530 */     if (depthOne) {
/* 1531 */       this.buildManager.endTopLevel(hasTreeChanges);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void flushBuildOrder() {
/* 1540 */     this.buildOrder = null;
/* 1541 */     this.buildOrderGraph = null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void forgetSavedTree(String pluginId) {
/* 1546 */     this.saveManager.forgetSavedTree(pluginId);
/*      */   }
/*      */   
/*      */   public AliasManager getAliasManager() {
/* 1550 */     return this.aliasManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BuildManager getBuildManager() {
/* 1557 */     return this.buildManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IBuildConfiguration[] getBuildOrder() {
/* 1589 */     if (this.buildOrder != null) {
/* 1590 */       return this.buildOrder;
/*      */     }
/*      */     
/* 1593 */     String[] order = this.description.getBuildOrder(false);
/* 1594 */     if (order != null) {
/* 1595 */       LinkedHashSet<IBuildConfiguration> configs = new LinkedHashSet<>();
/*      */       byte b;
/*      */       int i;
/*      */       String[] arrayOfString;
/* 1599 */       for (i = (arrayOfString = order).length, b = 0; b < i; ) { String element = arrayOfString[b];
/* 1600 */         IProject project = getRoot().getProject(element);
/* 1601 */         if (project.isAccessible()) {
/* 1602 */           configs.add(((Project)project).internalGetActiveBuildConfig());
/*      */         }
/*      */         b++; }
/*      */       
/* 1606 */       configs.addAll(Arrays.asList((vertexOrderToProjectBuildConfigOrder(computeActiveBuildConfigOrder())).buildConfigurations));
/*      */ 
/*      */       
/* 1609 */       IBuildConfiguration[] bo = new IBuildConfiguration[configs.size()];
/* 1610 */       configs.toArray((Object[])bo);
/* 1611 */       this.buildOrder = bo;
/*      */     }
/*      */     else {
/*      */       
/* 1615 */       ComputeProjectOrder.Digraph<IBuildConfiguration> buildGraph = getBuildGraph();
/* 1616 */       this.buildOrder = (vertexOrderToProjectBuildConfigOrder((ComputeProjectOrder.VertexOrder)ComputeProjectOrder.computeVertexOrder((ComputeProjectOrder.Digraph)buildGraph, (Class)IBuildConfiguration.class))).buildConfigurations;
/*      */     } 
/*      */     
/* 1619 */     return this.buildOrder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ComputeProjectOrder.Digraph<IBuildConfiguration> getBuildGraph() {
/* 1627 */     if (this.buildOrderGraph != null) {
/* 1628 */       return this.buildOrderGraph;
/*      */     }
/* 1630 */     String[] order = this.description.getBuildOrder(false);
/* 1631 */     if (order != null) {
/* 1632 */       return null;
/*      */     }
/* 1634 */     this.buildOrderGraph = computeActiveBuildConfigGraph();
/* 1635 */     return this.buildOrderGraph;
/*      */   }
/*      */   
/*      */   public CharsetManager getCharsetManager() {
/* 1639 */     return this.charsetManager;
/*      */   }
/*      */   
/*      */   public ContentDescriptionManager getContentDescriptionManager() {
/* 1643 */     return this.contentDescriptionManager;
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<IProject, IProject[]> getDanglingReferences() {
/* 1648 */     IProject[] projects = getRoot().getProjects(8);
/* 1649 */     Map<IProject, IProject[]> result = (Map)new HashMap<>(projects.length); byte b; int i; IProject[] arrayOfIProject1;
/* 1650 */     for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/* 1651 */       if (project.isAccessible()) {
/*      */ 
/*      */         
/* 1654 */         IProject[] refs = ((Project)project).internalGetDescription().getReferencedProjects(false);
/* 1655 */         List<IProject> dangling = new ArrayList<>(refs.length); byte b1; int j; IProject[] arrayOfIProject2;
/* 1656 */         for (j = (arrayOfIProject2 = refs).length, b1 = 0; b1 < j; ) { IProject ref = arrayOfIProject2[b1];
/* 1657 */           if (!ref.exists())
/* 1658 */             dangling.add(ref); 
/*      */           b1++; }
/*      */         
/* 1661 */         if (!dangling.isEmpty())
/* 1662 */           result.put(project, dangling.<IProject>toArray(new IProject[dangling.size()])); 
/*      */       }  b++; }
/*      */     
/* 1665 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public IWorkspaceDescription getDescription() {
/* 1670 */     WorkspaceDescription workingCopy = defaultWorkspaceDescription();
/* 1671 */     this.description.copyTo(workingCopy);
/* 1672 */     return workingCopy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ElementTree getElementTree() {
/* 1679 */     return this.tree;
/*      */   }
/*      */   
/*      */   public FileSystemResourceManager getFileSystemManager() {
/* 1683 */     return this.fileSystemManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MarkerManager getMarkerManager() {
/* 1690 */     return this.markerManager;
/*      */   }
/*      */   
/*      */   public LocalMetaArea getMetaArea() {
/* 1694 */     return this.localMetaArea;
/*      */   }
/*      */   
/*      */   protected IMoveDeleteHook getMoveDeleteHook() {
/* 1698 */     if (this.moveDeleteHook == null)
/* 1699 */       initializeMoveDeleteHook(); 
/* 1700 */     return this.moveDeleteHook;
/*      */   }
/*      */ 
/*      */   
/*      */   public IFilterMatcherDescriptor getFilterMatcherDescriptor(String filterMatcherId) {
/* 1705 */     return this.filterManager.getFilterDescriptor(filterMatcherId);
/*      */   }
/*      */ 
/*      */   
/*      */   public IFilterMatcherDescriptor[] getFilterMatcherDescriptors() {
/* 1710 */     return this.filterManager.getFilterDescriptors();
/*      */   }
/*      */ 
/*      */   
/*      */   public IProjectNatureDescriptor getNatureDescriptor(String natureId) {
/* 1715 */     return this.natureManager.getNatureDescriptor(natureId);
/*      */   }
/*      */ 
/*      */   
/*      */   public IProjectNatureDescriptor[] getNatureDescriptors() {
/* 1720 */     return this.natureManager.getNatureDescriptors();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NatureManager getNatureManager() {
/* 1727 */     return this.natureManager;
/*      */   }
/*      */   
/*      */   public NotificationManager getNotificationManager() {
/* 1731 */     return this.notificationManager;
/*      */   }
/*      */ 
/*      */   
/*      */   public IPathVariableManager getPathVariableManager() {
/* 1736 */     return this.pathVariableManager;
/*      */   }
/*      */   
/*      */   public IPropertyManager getPropertyManager() {
/* 1740 */     return this.propertyManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RefreshManager getRefreshManager() {
/* 1747 */     return this.refreshManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceInfo getResourceInfo(IPath path, boolean phantom, boolean mutable) {
/*      */     try {
/* 1760 */       if (path.segmentCount() == 0) {
/* 1761 */         ResourceInfo info = (ResourceInfo)this.tree.getTreeData();
/* 1762 */         Assert.isNotNull(info, "Tree root info must never be null");
/* 1763 */         return info;
/*      */       } 
/* 1765 */       ResourceInfo result = null;
/* 1766 */       if (!this.tree.includes(path))
/* 1767 */         return null; 
/* 1768 */       if (mutable) {
/* 1769 */         result = (ResourceInfo)this.tree.openElementData(path);
/*      */       } else {
/* 1771 */         result = (ResourceInfo)this.tree.getElementData(path);
/* 1772 */       }  if (result != null && !phantom && result.isSet(8))
/* 1773 */         return null; 
/* 1774 */       return result;
/* 1775 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 1776 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public IWorkspaceRoot getRoot() {
/* 1782 */     return this.defaultRoot;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IResourceRuleFactory getRuleFactory() {
/* 1789 */     if (this.ruleFactory == null)
/* 1790 */       this.ruleFactory = new Rules(this); 
/* 1791 */     return this.ruleFactory;
/*      */   }
/*      */   
/*      */   public SaveManager getSaveManager() {
/* 1795 */     return this.saveManager;
/*      */   }
/*      */ 
/*      */   
/*      */   public ISynchronizer getSynchronizer() {
/* 1800 */     return this.synchronizer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TeamHook getTeamHook() {
/* 1807 */     if (this.teamHook == null)
/* 1808 */       initializeTeamHook(); 
/* 1809 */     return this.teamHook;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WorkManager getWorkManager() throws CoreException {
/* 1817 */     if (this._workManager == null) {
/* 1818 */       String message = Messages.resources_shutdown;
/* 1819 */       throw new ResourceException(566, null, message, null);
/*      */     } 
/* 1821 */     return this._workManager;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initializeMoveDeleteHook() {
/*      */     
/* 1831 */     try { if (!canCreateExtensions())
/*      */         return; 
/* 1833 */       IConfigurationElement[] configs = Platform.getExtensionRegistry().getConfigurationElementsFor("org.eclipse.core.resources", "moveDeleteHook");
/*      */       
/* 1835 */       if (configs == null || configs.length == 0) {
/*      */         return;
/*      */       }
/*      */       
/* 1839 */       if (configs.length > 1) {
/*      */         
/* 1841 */         ResourceStatus resourceStatus = new ResourceStatus(4, 1, null, Messages.resources_oneHook, null);
/* 1842 */         Policy.log((IStatus)resourceStatus);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       }  }
/*      */     finally
/* 1860 */     { if (this.moveDeleteHook == null)
/* 1861 */         this.moveDeleteHook = new MoveDeleteHook();  }  if (this.moveDeleteHook == null) this.moveDeleteHook = new MoveDeleteHook();
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializePreferenceLookupOrder() throws CoreException {
/* 1870 */     PreferencesService service = PreferencesService.getDefault();
/* 1871 */     String[] original = service.getDefaultDefaultLookupOrder();
/* 1872 */     List<String> newOrder = new ArrayList<>();
/*      */     
/* 1874 */     newOrder.add("project");
/* 1875 */     newOrder.addAll(Arrays.asList(original));
/* 1876 */     service.setDefaultDefaultLookupOrder(newOrder.<String>toArray(new String[newOrder.size()]));
/* 1877 */     Preferences node = service.getRootNode().node("project");
/* 1878 */     if (node instanceof ProjectPreferences) {
/* 1879 */       ProjectPreferences projectPreferences = (ProjectPreferences)node;
/* 1880 */       projectPreferences.setWorkspace(this);
/*      */     } else {
/* 1882 */       throw new CoreException(Status.error(MessageFormat.format(
/* 1883 */               "Internal error while open workspace, expected ProjectPreferences for the scope {0} but got {1}", new Object[] {
/* 1884 */                 "project", node.getClass().getSimpleName()
/*      */               })));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initializeTeamHook() {
/*      */     
/* 1895 */     try { if (!canCreateExtensions())
/*      */         return; 
/* 1897 */       IConfigurationElement[] configs = Platform.getExtensionRegistry().getConfigurationElementsFor("org.eclipse.core.resources", "teamHook");
/*      */       
/* 1899 */       if (configs == null || configs.length == 0) {
/*      */         return;
/*      */       }
/*      */       
/* 1903 */       if (configs.length > 1) {
/*      */         
/* 1905 */         ResourceStatus resourceStatus = new ResourceStatus(4, 1, null, Messages.resources_oneTeamHook, null);
/* 1906 */         Policy.log((IStatus)resourceStatus);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       }  }
/*      */     finally
/* 1925 */     { if (this.teamHook == null)
/* 1926 */         this.teamHook = new TeamHook(this) {  };  }  if (this.teamHook == null) this.teamHook = new TeamHook(this)
/*      */         {
/*      */         
/*      */         };
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initializeValidator() {
/* 1937 */     this.shouldValidate = false;
/* 1938 */     if (!canCreateExtensions())
/*      */       return; 
/* 1940 */     IConfigurationElement[] configs = Platform.getExtensionRegistry().getConfigurationElementsFor("org.eclipse.core.resources", "fileModificationValidator");
/*      */     
/* 1942 */     if (configs == null || configs.length == 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1947 */     if (configs.length > 1) {
/*      */       
/* 1949 */       ResourceStatus resourceStatus = new ResourceStatus(4, 1, null, Messages.resources_oneValidator, null);
/* 1950 */       Policy.log((IStatus)resourceStatus);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*      */     try {
/* 1956 */       IConfigurationElement config = configs[0];
/* 1957 */       this.validator = (IFileModificationValidator)config.createExecutableExtension("class");
/* 1958 */       this.shouldValidate = true;
/* 1959 */     } catch (CoreException e) {
/*      */ 
/*      */       
/* 1962 */       if (canCreateExtensions()) {
/* 1963 */         ResourceStatus resourceStatus = new ResourceStatus(4, 1, null, Messages.resources_initValidator, (Throwable)e);
/* 1964 */         Policy.log((IStatus)resourceStatus);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public WorkspaceDescription internalGetDescription() {
/* 1970 */     return this.description;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAutoBuilding() {
/* 1975 */     return this.description.isAutoBuilding();
/*      */   }
/*      */   
/*      */   public boolean isOpen() {
/* 1979 */     return this.openFlag;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTreeLocked() {
/* 1984 */     return (this.treeLocked == Thread.currentThread());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void linkTrees(IPath path, ElementTree[] newTrees) {
/* 1991 */     this.tree = this.tree.mergeDeltaChain(path, newTrees);
/*      */   }
/*      */ 
/*      */   
/*      */   public IProjectDescription loadProjectDescription(InputStream stream) throws CoreException {
/* 1996 */     IProjectDescription result = (new ProjectDescriptionReader(this)).read(new InputSource(stream));
/* 1997 */     if (result == null) {
/* 1998 */       String message = NLS.bind(Messages.resources_errorReadProject, stream.toString());
/* 1999 */       Status status = new Status(4, "org.eclipse.core.resources", 567, message, null);
/* 2000 */       throw new ResourceException(status);
/*      */     } 
/* 2002 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public IProjectDescription loadProjectDescription(IPath path) throws CoreException {
/* 2007 */     IProjectDescription result = null;
/* 2008 */     IOException e = null;
/*      */     try {
/* 2010 */       result = (new ProjectDescriptionReader(this)).read(path);
/* 2011 */       if (result != null) {
/*      */ 
/*      */         
/* 2014 */         IPath user = path.removeLastSegments(1);
/* 2015 */         IPath platform = getRoot().getLocation().append(result.getName());
/* 2016 */         if (!user.toFile().equals(platform.toFile()))
/* 2017 */           result.setLocation(user); 
/*      */       } 
/* 2019 */     } catch (IOException ex) {
/* 2020 */       e = ex;
/*      */     } 
/* 2022 */     if (result == null || e != null) {
/* 2023 */       String message = NLS.bind(Messages.resources_errorReadProject, path.toOSString());
/* 2024 */       Status status = new Status(4, "org.eclipse.core.resources", 567, message, e);
/* 2025 */       throw new ResourceException(status);
/*      */     } 
/* 2027 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public IStatus move(IResource[] resources, IPath destination, boolean force, IProgressMonitor monitor) throws CoreException {
/* 2032 */     int updateFlags = force ? 1 : 0;
/* 2033 */     updateFlags |= 0x2;
/* 2034 */     return move(resources, destination, updateFlags, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public IStatus move(IResource[] resources, IPath destination, int updateFlags, IProgressMonitor monitor) throws CoreException {
/* 2039 */     Assert.isLegal((resources != null));
/*      */     
/* 2041 */     if (resources.length == 0) {
/* 2042 */       return Status.OK_STATUS;
/*      */     }
/* 2044 */     resources = (IResource[])resources.clone();
/*      */     
/* 2046 */     String message = Messages.resources_moving_0;
/* 2047 */     SubMonitor subMonitor = SubMonitor.convert(monitor, message, resources.length);
/* 2048 */     IPath parentPath = null;
/* 2049 */     message = Messages.resources_moveProblem;
/* 2050 */     MultiStatus status = new MultiStatus("org.eclipse.core.resources", 566, message, 
/* 2051 */         null);
/*      */     try {
/* 2053 */       prepareOperation((ISchedulingRule)getRoot(), (IProgressMonitor)subMonitor);
/* 2054 */       beginOperation(true);
/* 2055 */       for (int i = 0; i < resources.length; i++) {
/* 2056 */         Resource resource = (Resource)resources[i];
/* 2057 */         if (resource == null || isDuplicate((Object[])resources, i)) {
/* 2058 */           subMonitor.split(1);
/*      */         }
/*      */         else {
/*      */           
/* 2062 */           if (parentPath == null)
/* 2063 */             parentPath = resource.getFullPath().removeLastSegments(1); 
/* 2064 */           if (parentPath.equals(resource.getFullPath().removeLastSegments(1)))
/*      */           
/*      */           { try {
/* 2067 */               IStatus requirements = resource.checkMoveRequirements(destination.append(resource.getName()), 
/* 2068 */                   resource.getType(), updateFlags);
/* 2069 */               if (requirements.isOK()) {
/*      */                 try {
/* 2071 */                   resource.move(destination.append(resource.getName()), updateFlags, 
/* 2072 */                       (IProgressMonitor)subMonitor.newChild(1));
/* 2073 */                 } catch (CoreException e) {
/* 2074 */                   status.merge(e.getStatus());
/*      */                 } 
/*      */               } else {
/* 2077 */                 subMonitor.worked(1);
/* 2078 */                 status.merge(requirements);
/*      */               } 
/* 2080 */             } catch (CoreException e) {
/* 2081 */               subMonitor.worked(1);
/* 2082 */               status.merge(e.getStatus());
/*      */             }  }
/*      */           else
/* 2085 */           { subMonitor.worked(1);
/* 2086 */             message = NLS.bind(Messages.resources_notChild, resource.getFullPath(), parentPath);
/* 2087 */             status.merge((IStatus)new ResourceStatus(76, resource.getFullPath(), message)); } 
/*      */         } 
/*      */       } 
/* 2090 */     } catch (OperationCanceledException e) {
/* 2091 */       getWorkManager().operationCanceled();
/* 2092 */       throw e;
/*      */     } finally {
/* 2094 */       subMonitor.done();
/* 2095 */       endOperation((ISchedulingRule)getRoot(), true);
/*      */     } 
/* 2097 */     if (status.matches(4))
/* 2098 */       throw new ResourceException(status); 
/* 2099 */     return status.isOK() ? Status.OK_STATUS : (IStatus)status;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void move(Resource source, IPath destination, int depth, int updateFlags, boolean keepSyncInfo) throws CoreException {
/* 2113 */     copyTree(source, destination, depth, updateFlags, keepSyncInfo, true, (source.getType() == 4));
/* 2114 */     source.fixupAfterMoveSource();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ResourceInfo newElement(int type) {
/* 2121 */     ResourceInfo result = null;
/* 2122 */     switch (type) {
/*      */       case 1:
/*      */       case 2:
/* 2125 */         result = new ResourceInfo();
/*      */         break;
/*      */       case 4:
/* 2128 */         result = new ProjectInfo();
/*      */         break;
/*      */       case 8:
/* 2131 */         result = new RootInfo();
/*      */         break;
/*      */     } 
/* 2134 */     result.setNodeId(nextNodeId());
/* 2135 */     updateModificationStamp(result);
/* 2136 */     result.setType(type);
/* 2137 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public IBuildConfiguration newBuildConfig(String projectName, String configName) {
/* 2142 */     return new BuildConfiguration(getRoot().getProject(projectName), configName);
/*      */   }
/*      */ 
/*      */   
/*      */   public IProjectDescription newProjectDescription(String projectName) {
/* 2147 */     IProjectDescription result = new ProjectDescription();
/* 2148 */     result.setName(projectName);
/* 2149 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public Resource newResource(IPath path, int type) {
/* 2154 */     switch (type) {
/*      */       case 2:
/* 2156 */         if (path.segmentCount() < 2) {
/* 2157 */           String message = "Path must include project and resource name: " + path.toString();
/* 2158 */           Assert.isLegal(false, message);
/*      */         } 
/* 2160 */         return new Folder(path.makeAbsolute(), this);
/*      */       case 1:
/* 2162 */         if (path.segmentCount() < 2) {
/* 2163 */           String message = "Path must include project and resource name: " + path.toString();
/* 2164 */           Assert.isLegal(false, message);
/*      */         } 
/* 2166 */         return new File(path.makeAbsolute(), this);
/*      */       case 4:
/* 2168 */         return (Resource)getRoot().getProject(path.lastSegment());
/*      */       case 8:
/* 2170 */         return (Resource)getRoot();
/*      */     } 
/* 2172 */     Assert.isLegal(false);
/*      */     
/* 2174 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ElementTree newWorkingTree() {
/* 2184 */     synchronized (this) {
/* 2185 */       this.tree = this.tree.newEmptyDelta();
/* 2186 */       return this.tree;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long nextMarkerId() {
/* 2194 */     return this.nextMarkerId.getAndIncrement();
/*      */   }
/*      */   
/*      */   protected long nextNodeId() {
/* 2198 */     return this.nextNodeId.getAndIncrement();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IStatus open(IProgressMonitor monitor) throws CoreException {
/* 2229 */     if (!this.localMetaArea.hasSavedWorkspace()) {
/* 2230 */       this.localMetaArea.createMetaArea();
/*      */     }
/* 2232 */     PlatformURLResourceConnection.startup(getRoot().getLocation());
/*      */ 
/*      */ 
/*      */     
/* 2236 */     String message = Messages.resources_workspaceOpen;
/* 2237 */     Assert.isTrue(!isOpen(), message);
/* 2238 */     if (!getMetaArea().hasSavedWorkspace()) {
/* 2239 */       message = Messages.resources_readWorkspaceMeta;
/* 2240 */       throw new ResourceException(567, Platform.getLocation(), message, null);
/*      */     } 
/* 2242 */     this.description = new WorkspacePreferences();
/*      */ 
/*      */     
/* 2245 */     if (!this.localMetaArea.hasSavedProjects()) {
/* 2246 */       setExplicitWorkspaceEncoding();
/*      */     }
/* 2248 */     initializePreferenceLookupOrder();
/*      */ 
/*      */     
/* 2251 */     this.localMetaArea.locationFor((IResource)getRoot()).toFile().mkdirs();
/*      */     
/* 2253 */     SubMonitor subMonitor = SubMonitor.convert(null);
/* 2254 */     startup((IProgressMonitor)subMonitor);
/*      */     
/* 2256 */     this.notificationManager.startup(null);
/* 2257 */     this.openFlag = true;
/* 2258 */     if (this.crashed || refreshRequested()) {
/*      */       try {
/* 2260 */         this.refreshManager.refresh((IResource)getRoot());
/* 2261 */       } catch (RuntimeException e) {
/*      */         
/* 2263 */         return (IStatus)new ResourceStatus(566, (IPath)Path.ROOT, Messages.resources_errorMultiRefresh, e);
/*      */       } 
/*      */     }
/*      */     
/* 2267 */     this.stringPoolJob = new StringPoolJob();
/* 2268 */     this.stringPoolJob.addStringPoolParticipant(this.saveManager, (ISchedulingRule)getRoot());
/* 2269 */     return Status.OK_STATUS;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setExplicitWorkspaceEncoding() {
/* 2287 */     String defaultEncoding = Platform.getPreferencesService().getString("org.eclipse.core.resources", 
/* 2288 */         "encoding", null, null);
/*      */     
/* 2290 */     if (defaultEncoding == null || defaultEncoding.isBlank()) {
/*      */       
/* 2292 */       List<String> commandLineArgs = ManagementFactory.getRuntimeMXBean().getInputArguments();
/* 2293 */       for (String arg : commandLineArgs) {
/* 2294 */         if (arg.startsWith("-Dfile.encoding=")) {
/* 2295 */           defaultEncoding = arg.substring("-Dfile.encoding=".length());
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2301 */       if (defaultEncoding == null || defaultEncoding.isBlank()) {
/* 2302 */         defaultEncoding = "UTF-8";
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2312 */       IEclipsePreferences workspacePrefs = InstanceScope.INSTANCE.getNode("org.eclipse.core.resources");
/* 2313 */       workspacePrefs.put("encoding", defaultEncoding);
/* 2314 */       Assert.isTrue(defaultEncoding.equals(ResourcesPlugin.getEncoding()));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void prepareOperation(ISchedulingRule rule, IProgressMonitor monitor) throws CoreException {
/*      */     try {
/* 2328 */       ISchedulingRule buildRule = getRuleFactory().buildRule();
/* 2329 */       if (rule != null && buildRule != null && (rule.isConflicting(buildRule) || buildRule.isConflicting(rule)))
/* 2330 */         this.buildManager.interrupt(); 
/*      */     } finally {
/* 2332 */       getWorkManager().checkIn(rule, monitor);
/*      */     } 
/* 2334 */     if (!isOpen()) {
/* 2335 */       String message = Messages.resources_workspaceClosed;
/* 2336 */       throw new ResourceException(76, null, message, null);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected boolean refreshRequested() {
/* 2341 */     String[] args = Platform.getCommandLineArgs(); byte b; int i; String[] arrayOfString1;
/* 2342 */     for (i = (arrayOfString1 = args).length, b = 0; b < i; ) { String arg = arrayOfString1[b];
/* 2343 */       if (arg.equalsIgnoreCase("-refresh"))
/* 2344 */         return true;  b++; }
/* 2345 */      return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeResourceChangeListener(IResourceChangeListener listener) {
/* 2350 */     this.notificationManager.removeListener(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void removeSaveParticipant(Plugin plugin) {
/* 2356 */     Assert.isNotNull(plugin, "Plugin must not be null");
/* 2357 */     this.saveManager.removeParticipant(plugin.getBundle().getSymbolicName());
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeSaveParticipant(String pluginId) {
/* 2362 */     Assert.isNotNull(pluginId, "Plugin id must not be null");
/* 2363 */     this.saveManager.removeParticipant(pluginId);
/*      */   }
/*      */ 
/*      */   
/*      */   public void run(ICoreRunnable action, IProgressMonitor monitor) throws CoreException {
/* 2368 */     run(action, (ISchedulingRule)this.defaultRoot, 1, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void run(ICoreRunnable action, ISchedulingRule rule, int options, IProgressMonitor monitor) throws CoreException {
/* 2373 */     SubMonitor subMonitor = SubMonitor.convert(monitor, 100);
/* 2374 */     int depth = -1;
/* 2375 */     boolean avoidNotification = ((options & 0x1) != 0);
/*      */     try {
/* 2377 */       prepareOperation(rule, (IProgressMonitor)subMonitor);
/* 2378 */       beginOperation(true);
/* 2379 */       if (avoidNotification)
/* 2380 */         avoidNotification = this.notificationManager.beginAvoidNotify(); 
/* 2381 */       depth = getWorkManager().beginUnprotected();
/* 2382 */       action.run((IProgressMonitor)subMonitor.newChild(Policy.opWork));
/* 2383 */     } catch (OperationCanceledException e) {
/* 2384 */       getWorkManager().operationCanceled();
/* 2385 */       throw e;
/* 2386 */     } catch (CoreException e) {
/* 2387 */       if (e.getStatus().getSeverity() == 8)
/* 2388 */         getWorkManager().operationCanceled(); 
/* 2389 */       throw e;
/*      */     } finally {
/* 2391 */       subMonitor.done();
/* 2392 */       if (avoidNotification)
/* 2393 */         this.notificationManager.endAvoidNotify(); 
/* 2394 */       if (depth >= 0)
/* 2395 */         getWorkManager().endUnprotected(depth); 
/* 2396 */       endOperation(rule, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void run(IWorkspaceRunnable action, IProgressMonitor monitor) throws CoreException {
/* 2402 */     run((ICoreRunnable)action, (ISchedulingRule)this.defaultRoot, 1, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public void run(IWorkspaceRunnable action, ISchedulingRule rule, int options, IProgressMonitor monitor) throws CoreException {
/* 2407 */     run((ICoreRunnable)action, rule, options, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public IStatus save(boolean full, IProgressMonitor monitor) throws CoreException {
/* 2412 */     return save(full, false, monitor);
/*      */   }
/*      */ 
/*      */   
/*      */   public IStatus save(boolean full, boolean keepConsistencyWhenCanceled, IProgressMonitor monitor) throws CoreException {
/* 2417 */     if (full) {
/*      */       
/* 2419 */       if (getWorkManager().isLockAlreadyAcquired()) {
/* 2420 */         String message = Messages.resources_saveOp;
/* 2421 */         throw new ResourceException(76, null, message, new IllegalStateException());
/*      */       } 
/* 2423 */       return this.saveManager.save(1, keepConsistencyWhenCanceled, null, monitor);
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/* 2428 */       prepareOperation((ISchedulingRule)getRoot(), monitor);
/* 2429 */       beginOperation(false);
/* 2430 */       this.saveManager.requestSnapshot();
/* 2431 */       String message = Messages.resources_snapRequest;
/* 2432 */       return (IStatus)new ResourceStatus(0, message);
/*      */     } finally {
/* 2434 */       endOperation((ISchedulingRule)getRoot(), false);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setCrashed(boolean value) {
/* 2439 */     this.crashed = value;
/* 2440 */     if (this.crashed) {
/* 2441 */       String msg = "The workspace exited with unsaved changes in the previous session; refreshing workspace to recover changes.";
/* 2442 */       Policy.log((IStatus)new ResourceStatus(10035, msg));
/* 2443 */       if (Policy.DEBUG) {
/* 2444 */         Policy.debug(msg);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCrashed() {
/* 2452 */     return this.crashed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDescription(IWorkspaceDescription value) {
/* 2460 */     WorkspaceDescription newDescription = (WorkspaceDescription)value;
/* 2461 */     String[] newOrder = newDescription.getBuildOrder(false);
/* 2462 */     if (this.description.getBuildOrder(false) != null || newOrder != null) {
/* 2463 */       flushBuildOrder();
/*      */     }
/* 2465 */     this.description.copyFrom(newDescription);
/* 2466 */     ResourcesPlugin.getPlugin().savePluginPreferences();
/*      */   }
/*      */   
/*      */   public void setTreeLocked(boolean locked) {
/* 2470 */     Assert.isTrue(!(locked && this.treeLocked != null), "The workspace tree is already locked");
/* 2471 */     this.treeLocked = locked ? Thread.currentThread() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void shutdown(IProgressMonitor monitor) throws CoreException {
/* 2478 */     IManager[] managers = { (IManager)this.buildManager, (IManager)this.propertyManager, this.pathVariableManager, this.charsetManager, (IManager)this.fileSystemManager, 
/* 2479 */         this.markerManager, this._workManager, this.aliasManager, (IManager)this.refreshManager, this.contentDescriptionManager, this.natureManager, 
/* 2480 */         this.filterManager };
/* 2481 */     SubMonitor subMonitor = SubMonitor.convert(monitor, managers.length);
/*      */     try {
/* 2483 */       String message = Messages.resources_shutdownProblems;
/* 2484 */       MultiStatus status = new MultiStatus("org.eclipse.core.resources", 566, message, 
/* 2485 */           null); byte b; int i;
/*      */       IManager[] arrayOfIManager;
/* 2487 */       for (i = (arrayOfIManager = managers).length, b = 0; b < i; ) { IManager manager = arrayOfIManager[b];
/* 2488 */         if (manager == null) {
/* 2489 */           subMonitor.worked(1);
/*      */         } else {
/*      */           try {
/* 2492 */             manager.shutdown((IProgressMonitor)subMonitor.newChild(1));
/* 2493 */           } catch (Exception e) {
/* 2494 */             message = Messages.resources_shutdownProblems;
/* 2495 */             status.add((IStatus)new Status(4, "org.eclipse.core.resources", 566, 
/* 2496 */                   message, e));
/*      */           } 
/*      */         }  b++; }
/*      */       
/* 2500 */       this.buildManager = null;
/* 2501 */       this.notificationManager = null;
/* 2502 */       this.propertyManager = null;
/* 2503 */       this.pathVariableManager = null;
/* 2504 */       this.fileSystemManager = null;
/* 2505 */       this.markerManager = null;
/* 2506 */       this.synchronizer = null;
/* 2507 */       this.saveManager = null;
/* 2508 */       this._workManager = null;
/* 2509 */       this.aliasManager = null;
/* 2510 */       this.refreshManager = null;
/* 2511 */       this.charsetManager = null;
/* 2512 */       this.contentDescriptionManager = null;
/* 2513 */       if (!status.isOK())
/* 2514 */         throw new CoreException(status); 
/*      */     } finally {
/* 2516 */       subMonitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] sortNatureSet(String[] natureIds) {
/* 2522 */     return this.natureManager.sortNatureSet(natureIds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void startup(IProgressMonitor monitor) throws CoreException {
/*      */     try {
/* 2531 */       this._workManager = new WorkManager(this);
/* 2532 */       this._workManager.startup(null);
/* 2533 */       this.fileSystemManager = new FileSystemResourceManager(this);
/* 2534 */       this.fileSystemManager.startup(monitor);
/* 2535 */       this.pathVariableManager = new PathVariableManager();
/* 2536 */       this.pathVariableManager.startup(null);
/* 2537 */       this.natureManager = new NatureManager(this);
/* 2538 */       this.natureManager.startup(null);
/* 2539 */       this.filterManager = new FilterTypeManager();
/* 2540 */       this.filterManager.startup(null);
/* 2541 */       this.buildManager = new BuildManager(this, getWorkManager().getLock());
/* 2542 */       this.buildManager.startup(null);
/* 2543 */       this.notificationManager = new NotificationManager(this);
/* 2544 */       this.notificationManager.startup(null);
/* 2545 */       this.markerManager = new MarkerManager(this);
/* 2546 */       this.markerManager.startup(null);
/* 2547 */       this.synchronizer = new Synchronizer(this);
/* 2548 */       this.saveManager = new SaveManager(this);
/* 2549 */       this.saveManager.startup(null);
/* 2550 */       this.propertyManager = (IPropertyManager)new PropertyManager2(this);
/* 2551 */       this.propertyManager.startup(monitor);
/* 2552 */       this.charsetManager = new CharsetManager(this);
/* 2553 */       this.charsetManager.startup(null);
/* 2554 */       this.contentDescriptionManager = new ContentDescriptionManager(this);
/* 2555 */       this.contentDescriptionManager.startup(null);
/*      */ 
/*      */ 
/*      */       
/* 2559 */       this.refreshManager = new RefreshManager(this);
/* 2560 */       this.refreshManager.startup(null);
/*      */       
/* 2562 */       this.aliasManager = new AliasManager(this);
/* 2563 */       this.aliasManager.startup(null);
/*      */     } finally {
/*      */       
/* 2566 */       this.treeLocked = null;
/* 2567 */       this._workManager.postWorkspaceStartup();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toDebugString() {
/* 2576 */     StringBuilder buffer = new StringBuilder("\nDump of " + this + ":\n");
/* 2577 */     buffer.append("  parent: " + this.tree.getParent());
/* 2578 */     IElementContentVisitor visitor = (aTree, requestor, elementContents) -> {
/*      */         paramStringBuilder.append("\n  " + requestor.requestPath() + ": " + elementContents);
/*      */         return true;
/*      */       };
/* 2582 */     (new ElementTreeIterator(this.tree, (IPath)Path.ROOT)).iterate(visitor);
/* 2583 */     return buffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2589 */     return String.valueOf(getClass().getSimpleName()) + "[localMetaArea=" + this.localMetaArea.getLocation() + "]";
/*      */   }
/*      */   
/*      */   public void updateModificationStamp(ResourceInfo info) {
/* 2593 */     info.incrementModificationStamp();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public IStatus validateEdit(final IFile[] files, final Object context) {
/* 2599 */     if (!this.shouldValidate) {
/* 2600 */       String message = Messages.resources_readOnly2;
/* 2601 */       MultiStatus result = new MultiStatus("org.eclipse.core.resources", 279, message, null); byte b; int i; IFile[] arrayOfIFile;
/* 2602 */       for (i = (arrayOfIFile = files).length, b = 0; b < i; ) { IFile file = arrayOfIFile[b];
/* 2603 */         if (file.isReadOnly()) {
/* 2604 */           IPath filePath = file.getFullPath();
/* 2605 */           message = NLS.bind(Messages.resources_readOnly, filePath);
/* 2606 */           result.add((IStatus)new ResourceStatus(279, filePath, message));
/*      */         }  b++; }
/*      */       
/* 2609 */       return ((result.getChildren()).length == 0) ? Status.OK_STATUS : (IStatus)result;
/*      */     } 
/*      */     
/* 2612 */     if (this.validator == null) {
/* 2613 */       initializeValidator();
/*      */     }
/*      */     
/* 2616 */     if (this.validator == null) {
/* 2617 */       return Status.OK_STATUS;
/*      */     }
/* 2619 */     final IStatus[] status = new IStatus[1];
/* 2620 */     ISafeRunnable body = new ISafeRunnable()
/*      */       {
/*      */         public void handleException(Throwable exception) {
/* 2623 */           status[0] = (IStatus)new ResourceStatus(4, null, Messages.resources_errorValidator, exception);
/*      */         }
/*      */ 
/*      */         
/*      */         public void run() throws Exception {
/* 2628 */           Object c = context;
/*      */           
/* 2630 */           if (!(Workspace.this.validator instanceof org.eclipse.core.resources.team.FileModificationValidator) && 
/* 2631 */             c instanceof org.eclipse.core.resources.team.FileModificationValidationContext)
/* 2632 */             c = null; 
/* 2633 */           status[0] = Workspace.this.validator.validateEdit(files, c);
/*      */         }
/*      */       };
/* 2636 */     SafeRunner.run(body);
/* 2637 */     return status[0];
/*      */   }
/*      */ 
/*      */   
/*      */   public IStatus validateLinkLocation(IResource resource, IPath unresolvedLocation) {
/* 2642 */     return this.locationValidator.validateLinkLocation(resource, unresolvedLocation);
/*      */   }
/*      */ 
/*      */   
/*      */   public IStatus validateLinkLocationURI(IResource resource, URI unresolvedLocation) {
/* 2647 */     return this.locationValidator.validateLinkLocationURI(resource, unresolvedLocation);
/*      */   }
/*      */ 
/*      */   
/*      */   public IStatus validateName(String segment, int type) {
/* 2652 */     return this.locationValidator.validateName(segment, type);
/*      */   }
/*      */ 
/*      */   
/*      */   public IStatus validateNatureSet(String[] natureIds) {
/* 2657 */     return this.natureManager.validateNatureSet(natureIds);
/*      */   }
/*      */ 
/*      */   
/*      */   public IStatus validatePath(String path, int type) {
/* 2662 */     return this.locationValidator.validatePath(path, type);
/*      */   }
/*      */ 
/*      */   
/*      */   public IStatus validateProjectLocation(IProject context, IPath location) {
/* 2667 */     return this.locationValidator.validateProjectLocation(context, location);
/*      */   }
/*      */ 
/*      */   
/*      */   public IStatus validateProjectLocationURI(IProject project, URI location) {
/* 2672 */     return this.locationValidator.validateProjectLocationURI(project, location);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void validateSave(final IFile file) throws CoreException {
/* 2687 */     if (!this.shouldValidate) {
/*      */       return;
/*      */     }
/* 2690 */     if (this.validator == null) {
/* 2691 */       initializeValidator();
/*      */     }
/*      */     
/* 2694 */     if (this.validator == null) {
/*      */       return;
/*      */     }
/* 2697 */     final IStatus[] status = new IStatus[1];
/* 2698 */     ISafeRunnable body = new ISafeRunnable()
/*      */       {
/*      */         public void handleException(Throwable exception) {
/* 2701 */           status[0] = (IStatus)new ResourceStatus(4, null, Messages.resources_errorValidator, exception);
/*      */         }
/*      */ 
/*      */         
/*      */         public void run() throws Exception {
/* 2706 */           status[0] = Workspace.this.validator.validateSave(file);
/*      */         }
/*      */       };
/* 2709 */     SafeRunner.run(body);
/* 2710 */     if (!status[0].isOK()) {
/* 2711 */       throw new ResourceException(status[0]);
/*      */     }
/*      */   }
/*      */   
/*      */   public IStatus validateFiltered(IResource resource) {
/*      */     try {
/* 2717 */       if (((Resource)resource).isFilteredWithException(true))
/* 2718 */         return (IStatus)new ResourceStatus(4, Messages.resources_errorResourceIsFiltered); 
/* 2719 */     } catch (CoreException coreException) {}
/*      */ 
/*      */     
/* 2722 */     return Status.OK_STATUS;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\Workspace.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */