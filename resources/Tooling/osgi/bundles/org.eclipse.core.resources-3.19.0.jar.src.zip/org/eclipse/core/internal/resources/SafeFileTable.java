/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.Properties;
/*    */ import java.util.Set;
/*    */ import org.eclipse.core.internal.utils.Messages;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SafeFileTable
/*    */ {
/*    */   protected IPath location;
/*    */   protected Properties table;
/*    */   private Workspace workspace;
/*    */   
/*    */   public SafeFileTable(String pluginId, Workspace workspace) throws CoreException {
/* 35 */     this.workspace = workspace;
/* 36 */     this.location = getWorkspace().getMetaArea().getSafeTableLocationFor(pluginId);
/* 37 */     restore();
/*    */   }
/*    */   
/*    */   public IPath[] getFiles() {
/* 41 */     Set<Object> set = this.table.keySet();
/* 42 */     String[] keys = set.<String>toArray(new String[set.size()]);
/* 43 */     IPath[] files = new IPath[keys.length];
/* 44 */     for (int i = 0; i < keys.length; i++)
/* 45 */       files[i] = (IPath)new Path(keys[i]); 
/* 46 */     return files;
/*    */   }
/*    */   
/*    */   protected Workspace getWorkspace() {
/* 50 */     return this.workspace;
/*    */   }
/*    */   
/*    */   public IPath lookup(IPath file) {
/* 54 */     String result = this.table.getProperty(file.toOSString());
/* 55 */     return (result == null) ? null : (IPath)new Path(result);
/*    */   }
/*    */   
/*    */   public void map(IPath file, IPath aLocation) {
/* 59 */     if (aLocation == null) {
/* 60 */       this.table.remove(file);
/*    */     } else {
/* 62 */       this.table.setProperty(file.toOSString(), aLocation.toOSString());
/*    */     } 
/*    */   }
/*    */   public void restore() throws CoreException {
/* 66 */     File target = this.location.toFile();
/* 67 */     this.table = new Properties();
/* 68 */     if (!target.exists())
/*    */       return;  try {
/* 70 */       Exception exception2, exception1 = null;
/*    */     }
/* 72 */     catch (IOException e) {
/* 73 */       String message = Messages.resources_exSafeRead;
/* 74 */       throw new ResourceException(566, null, message, e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void save() throws CoreException {
/* 79 */     File target = this.location.toFile(); try {
/* 80 */       Exception exception2, exception1 = null;
/*    */     }
/* 82 */     catch (IOException e) {
/* 83 */       String message = Messages.resources_exSafeSave;
/* 84 */       throw new ResourceException(566, null, message, e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void setLocation(IPath location) {
/* 89 */     if (location != null)
/* 90 */       this.location = location; 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\SafeFileTable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */