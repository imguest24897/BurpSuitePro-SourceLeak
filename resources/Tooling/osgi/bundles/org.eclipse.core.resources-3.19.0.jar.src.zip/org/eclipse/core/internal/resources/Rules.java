/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.events.ILifecycleListener;
/*     */ import org.eclipse.core.internal.events.LifecycleEvent;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceRuleFactory;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.team.ResourceRuleFactory;
/*     */ import org.eclipse.core.resources.team.TeamHook;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.MultiRule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Rules
/*     */   implements IResourceRuleFactory, ILifecycleListener
/*     */ {
/*     */   private final IResourceRuleFactory defaultFactory;
/*  38 */   private final Map<String, IResourceRuleFactory> projectsToRules = Collections.synchronizedMap(new HashMap<>());
/*     */ 
/*     */   
/*     */   private final TeamHook teamHook;
/*     */   
/*     */   private final IWorkspaceRoot root;
/*     */ 
/*     */   
/*     */   Rules(Workspace workspace) {
/*  47 */     this.defaultFactory = (IResourceRuleFactory)new ResourceRuleFactory(workspace) {  }
/*     */       ;
/*  49 */     this.root = workspace.getRoot();
/*  50 */     this.teamHook = workspace.getTeamHook();
/*  51 */     workspace.addLifecycleListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule buildRule() {
/*  60 */     return (ISchedulingRule)this.root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule copyRule(IResource source, IResource destination) {
/*  68 */     if (source.getType() == 8 || destination.getType() == 8) {
/*  69 */       return (ISchedulingRule)this.root;
/*     */     }
/*  71 */     return factoryFor(destination).copyRule(source, destination);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule createRule(IResource resource) {
/*  79 */     if (resource.getType() == 8)
/*  80 */       return (ISchedulingRule)this.root; 
/*  81 */     return factoryFor(resource).createRule(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule deleteRule(IResource resource) {
/*  89 */     if (resource.getType() == 8)
/*  90 */       return (ISchedulingRule)this.root; 
/*  91 */     return factoryFor(resource).deleteRule(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IResourceRuleFactory factoryFor(IResource destination) {
/*  98 */     IResourceRuleFactory fac = this.projectsToRules.get(destination.getFullPath().segment(0));
/*  99 */     if (fac == null) {
/*     */       
/* 101 */       if (!destination.getProject().isAccessible()) {
/* 102 */         return this.defaultFactory;
/*     */       }
/* 104 */       fac = this.teamHook.getRuleFactory(destination.getProject());
/* 105 */       this.projectsToRules.put(destination.getFullPath().segment(0), fac);
/*     */     } 
/* 107 */     return fac;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleEvent(LifecycleEvent event) {
/* 115 */     switch (event.kind) {
/*     */       case 1:
/*     */       case 16:
/*     */       case 64:
/* 119 */         setRuleFactory((IProject)event.resource, null);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule charsetRule(IResource resource) {
/* 128 */     if (resource.getType() == 8)
/* 129 */       return null; 
/* 130 */     return factoryFor(resource).charsetRule(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule derivedRule(IResource resource) {
/* 139 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule markerRule(IResource resource) {
/* 148 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule modifyRule(IResource resource) {
/* 156 */     if (resource.getType() == 8)
/* 157 */       return (ISchedulingRule)this.root; 
/* 158 */     return factoryFor(resource).modifyRule(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule moveRule(IResource source, IResource destination) {
/* 166 */     if (source.getType() == 8 || destination.getType() == 8) {
/* 167 */       return (ISchedulingRule)this.root;
/*     */     }
/* 169 */     if (!source.getFullPath().segment(0).equals(destination.getFullPath().segment(0)))
/* 170 */       return MultiRule.combine(modifyRule((IResource)source.getProject()), modifyRule((IResource)destination.getProject())); 
/* 171 */     return factoryFor(source).moveRule(source, destination);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule refreshRule(IResource resource) {
/* 179 */     if (resource.getType() == 8)
/* 180 */       return (ISchedulingRule)this.root; 
/* 181 */     return factoryFor(resource).refreshRule(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setRuleFactory(IProject project, IResourceRuleFactory factory) {
/* 188 */     if (factory == null) {
/* 189 */       this.projectsToRules.remove(project.getName());
/*     */     } else {
/* 191 */       this.projectsToRules.put(project.getName(), factory);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule validateEditRule(IResource[] resources) {
/* 200 */     if (resources.length == 0) {
/* 201 */       return null;
/*     */     }
/* 203 */     if (resources.length == 1) {
/* 204 */       if (resources[0].getType() == 8)
/* 205 */         return (ISchedulingRule)this.root; 
/* 206 */       return factoryFor(resources[0]).validateEditRule(resources);
/*     */     } 
/*     */     
/* 209 */     HashSet<ISchedulingRule> rules = new HashSet<>();
/* 210 */     IResource[] oneResource = new IResource[1]; byte b; int i; IResource[] arrayOfIResource1;
/* 211 */     for (i = (arrayOfIResource1 = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource1[b];
/* 212 */       if (resource.getType() == 8)
/* 213 */         return (ISchedulingRule)this.root; 
/* 214 */       oneResource[0] = resource;
/* 215 */       ISchedulingRule rule = factoryFor(resource).validateEditRule(oneResource);
/* 216 */       if (rule != null)
/* 217 */         rules.add(rule);  b++; }
/*     */     
/* 219 */     if (rules.isEmpty())
/* 220 */       return null; 
/* 221 */     if (rules.size() == 1)
/* 222 */       return rules.iterator().next(); 
/* 223 */     ISchedulingRule[] ruleArray = rules.<ISchedulingRule>toArray(new ISchedulingRule[rules.size()]);
/* 224 */     return (ISchedulingRule)new MultiRule(ruleArray);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\Rules.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */