/*     */ package org.eclipse.core.internal.resources.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.resources.IMarkerDelta;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.resources.IResourceDeltaVisitor;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ProposedResourceDelta
/*     */   extends PlatformObject
/*     */   implements IResourceDelta
/*     */ {
/*  26 */   protected static int KIND_MASK = 255;
/*     */   
/*  28 */   private HashMap<String, ProposedResourceDelta> children = new HashMap<>(8);
/*     */   private IPath movedFromPath;
/*     */   private IPath movedToPath;
/*     */   private IResource resource;
/*     */   private int status;
/*     */   
/*     */   public ProposedResourceDelta(IResource resource) {
/*  35 */     this.resource = resource;
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(IResourceDeltaVisitor visitor) throws CoreException {
/*  40 */     accept(visitor, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(IResourceDeltaVisitor visitor, boolean includePhantoms) throws CoreException {
/*  45 */     accept(visitor, includePhantoms ? 1 : 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(IResourceDeltaVisitor visitor, int memberFlags) throws CoreException {
/*  50 */     if (!visitor.visit(this))
/*     */       return; 
/*  52 */     for (ProposedResourceDelta childDelta : this.children.values()) {
/*  53 */       childDelta.accept(visitor, memberFlags);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void add(ProposedResourceDelta delta) {
/*  62 */     if (this.children.isEmpty() && this.status == 0)
/*  63 */       setKind(4); 
/*  64 */     this.children.put(delta.getResource().getName(), delta);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addFlags(int flags) {
/*  73 */     this.status |= flags & (KIND_MASK ^ 0xFFFFFFFF);
/*     */   }
/*     */ 
/*     */   
/*     */   public IResourceDelta findMember(IPath path) {
/*  78 */     int segmentCount = path.segmentCount();
/*  79 */     if (segmentCount == 0) {
/*  80 */       return this;
/*     */     }
/*     */     
/*  83 */     ProposedResourceDelta current = this;
/*  84 */     for (int i = 0; i < segmentCount; i++) {
/*  85 */       current = current.children.get(path.segment(i));
/*  86 */       if (current == null)
/*  87 */         return null; 
/*     */     } 
/*  89 */     return current;
/*     */   }
/*     */ 
/*     */   
/*     */   public IResourceDelta[] getAffectedChildren() {
/*  94 */     return getAffectedChildren(7, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public IResourceDelta[] getAffectedChildren(int kindMask) {
/*  99 */     return getAffectedChildren(kindMask, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public IResourceDelta[] getAffectedChildren(int kindMask, int memberFlags) {
/* 104 */     List<ProposedResourceDelta> result = new ArrayList<>();
/* 105 */     for (ProposedResourceDelta child : this.children.values()) {
/* 106 */       if ((child.getKind() & kindMask) != 0)
/* 107 */         result.add(child); 
/*     */     } 
/* 109 */     return result.<IResourceDelta>toArray(new IResourceDelta[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ProposedResourceDelta getChild(String name) {
/* 117 */     return this.children.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFlags() {
/* 122 */     return this.status & (KIND_MASK ^ 0xFFFFFFFF);
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getFullPath() {
/* 127 */     return getResource().getFullPath();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getKind() {
/* 132 */     return this.status & KIND_MASK;
/*     */   }
/*     */ 
/*     */   
/*     */   public IMarkerDelta[] getMarkerDeltas() {
/* 137 */     return new IMarkerDelta[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getMovedFromPath() {
/* 142 */     return this.movedFromPath;
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getMovedToPath() {
/* 147 */     return this.movedToPath;
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getProjectRelativePath() {
/* 152 */     return getResource().getProjectRelativePath();
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource getResource() {
/* 157 */     return this.resource;
/*     */   }
/*     */   
/*     */   public void setFlags(int flags) {
/* 161 */     this.status = getKind() | flags & (KIND_MASK ^ 0xFFFFFFFF);
/*     */   }
/*     */   
/*     */   protected void setKind(int kind) {
/* 165 */     this.status = getFlags() | kind & KIND_MASK;
/*     */   }
/*     */   
/*     */   protected void setMovedFromPath(IPath path) {
/* 169 */     this.movedFromPath = path;
/*     */   }
/*     */   
/*     */   protected void setMovedToPath(IPath path) {
/* 173 */     this.movedToPath = path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 181 */     return "ProposedDelta(" + this.resource + ')';
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\mapping\ProposedResourceDelta.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */