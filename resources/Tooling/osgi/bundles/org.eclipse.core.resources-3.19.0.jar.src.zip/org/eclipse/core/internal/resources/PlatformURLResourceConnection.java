/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.net.URLDecoder;
/*     */ import org.eclipse.core.internal.boot.PlatformURLConnection;
/*     */ import org.eclipse.core.internal.boot.PlatformURLHandler;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlatformURLResourceConnection
/*     */   extends PlatformURLConnection
/*     */ {
/*     */   public static final String RESOURCE = "resource";
/*     */   public static final String RESOURCE_URL_STRING = "platform:/resource/";
/*     */   private static URL rootURL;
/*     */   
/*     */   public PlatformURLResourceConnection(URL url) {
/*  38 */     super(url);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean allowCaching() {
/*  43 */     return false;
/*     */   }
/*     */   
/*     */   protected URL resolve() throws IOException {
/*     */     IFile iFile;
/*  48 */     String filePath = this.url.getFile().trim();
/*  49 */     filePath = URLDecoder.decode(filePath, "UTF-8");
/*  50 */     IPath spec = (new Path(filePath)).makeRelative();
/*  51 */     if (!spec.segment(0).equals("resource"))
/*  52 */       throw new IOException(NLS.bind(Messages.url_badVariant, this.url)); 
/*  53 */     int count = spec.segmentCount();
/*     */     
/*  55 */     if (count == 1) {
/*  56 */       return rootURL;
/*     */     }
/*  58 */     IProject project = ResourcesPlugin.getWorkspace().getRoot().getProject(spec.segment(1));
/*  59 */     if (!project.exists()) {
/*  60 */       String message = NLS.bind(Messages.url_couldNotResolve_projectDoesNotExist, project.getName(), this.url.toExternalForm());
/*  61 */       throw new IOException(message);
/*     */     } 
/*     */     
/*  64 */     IResource resource = null;
/*  65 */     if (count == 2) {
/*  66 */       IProject iProject = project;
/*     */     } else {
/*  68 */       spec = spec.removeFirstSegments(2);
/*  69 */       iFile = project.getFile(spec);
/*     */     } 
/*     */     
/*  72 */     IPath result = iFile.getLocation();
/*     */     
/*  74 */     if (result == null) {
/*  75 */       URI uri = iFile.getLocationURI();
/*  76 */       if (uri != null) {
/*     */         try {
/*  78 */           URL url2 = uri.toURL();
/*  79 */           if (url2.getProtocol().equals("file"))
/*  80 */             return url2; 
/*  81 */         } catch (MalformedURLException malformedURLException) {
/*  82 */           String str = NLS.bind(Messages.url_couldNotResolve_URLProtocolHandlerCanNotResolveURL, uri.toString(), this.url.toExternalForm());
/*  83 */           throw new IOException(str);
/*     */         } 
/*     */       }
/*  86 */       String message = NLS.bind(Messages.url_couldNotResolve_resourceLocationCanNotBeDetermined, iFile.getFullPath(), this.url.toExternalForm());
/*  87 */       throw new IOException(message);
/*     */     } 
/*  89 */     return new URL("file", "", result.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void startup(IPath root) {
/*  99 */     if (rootURL != null)
/*     */       return; 
/*     */     try {
/* 102 */       rootURL = root.toFile().toURL();
/* 103 */     } catch (MalformedURLException malformedURLException) {
/*     */       return;
/*     */     } 
/*     */     
/* 107 */     PlatformURLHandler.register("resource", PlatformURLResourceConnection.class);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\PlatformURLResourceConnection.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */