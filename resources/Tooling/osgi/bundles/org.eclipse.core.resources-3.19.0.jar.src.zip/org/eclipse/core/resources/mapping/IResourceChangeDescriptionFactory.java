package org.eclipse.core.resources.mapping;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.runtime.IPath;

public interface IResourceChangeDescriptionFactory {
  void change(IFile paramIFile);
  
  void close(IProject paramIProject);
  
  void copy(IResource paramIResource, IPath paramIPath);
  
  void create(IResource paramIResource);
  
  void delete(IResource paramIResource);
  
  void delete(IProject paramIProject, boolean paramBoolean);
  
  IResourceDelta getDelta();
  
  void move(IResource paramIResource, IPath paramIPath);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\mapping\IResourceChangeDescriptionFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */