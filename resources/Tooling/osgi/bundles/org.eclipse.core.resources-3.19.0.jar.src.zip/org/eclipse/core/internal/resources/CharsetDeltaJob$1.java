/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import org.eclipse.core.internal.watson.IPathRequestor;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements CharsetDeltaJob.ICharsetListenerFilter
/*     */ {
/*     */   public IPath getRoot() {
/*  96 */     ResourceInfo currentInfo = ((Project)project).getResourceInfo(false, false);
/*  97 */     if (currentInfo == null)
/*  98 */       return null; 
/*  99 */     long currentId = currentInfo.getNodeId();
/* 100 */     if (currentId != projectId) {
/* 101 */       return null;
/*     */     }
/* 103 */     return project.getFullPath();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAffected(ResourceInfo info, IPathRequestor requestor) {
/* 109 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public IProject getProject() {
/* 114 */     return project;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\CharsetDeltaJob$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */