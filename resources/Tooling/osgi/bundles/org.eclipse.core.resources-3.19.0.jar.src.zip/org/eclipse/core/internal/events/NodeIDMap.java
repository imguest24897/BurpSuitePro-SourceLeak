/*     */ package org.eclipse.core.internal.events;
/*     */ 
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NodeIDMap
/*     */ {
/*  24 */   private static final int[] SIZES = new int[] { 13, 29, 71, 173, 349, 733, 1511, 3079, 6133, 16381, 32653, 65543, 131111, 262139, 524287, 1051601 };
/*     */   
/*     */   private static final double LOAD_FACTOR = 0.75D;
/*     */   
/*     */   private static final long LARGE_NUMBER = 2654435761L;
/*  29 */   int sizeOffset = 0;
/*  30 */   protected int elementCount = 0;
/*     */   
/*     */   protected long[] ids;
/*     */   
/*     */   protected IPath[] oldPaths;
/*     */   
/*     */   protected IPath[] newPaths;
/*     */   
/*     */   public NodeIDMap() {
/*  39 */     this.sizeOffset = 0;
/*  40 */     this.ids = new long[SIZES[this.sizeOffset]];
/*  41 */     this.oldPaths = new IPath[SIZES[this.sizeOffset]];
/*  42 */     this.newPaths = new IPath[SIZES[this.sizeOffset]];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void expand() {
/*     */     int newLength;
/*     */     try {
/*  52 */       newLength = SIZES[++this.sizeOffset];
/*  53 */     } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
/*     */       
/*  55 */       newLength = this.ids.length * 2;
/*     */     } 
/*  57 */     long[] grownIds = new long[newLength];
/*  58 */     IPath[] grownOldPaths = new IPath[newLength];
/*  59 */     IPath[] grownNewPaths = new IPath[newLength];
/*  60 */     int maxArrayIndex = newLength - 1;
/*  61 */     for (int i = 0; i < this.ids.length; i++) {
/*  62 */       long id = this.ids[i];
/*  63 */       if (id != 0L) {
/*  64 */         int hash = hashFor(id, newLength);
/*  65 */         while (grownIds[hash] != 0L) {
/*  66 */           hash++;
/*  67 */           if (hash > maxArrayIndex)
/*  68 */             hash = 0; 
/*     */         } 
/*  70 */         grownIds[hash] = id;
/*  71 */         grownOldPaths[hash] = this.oldPaths[i];
/*  72 */         grownNewPaths[hash] = this.newPaths[i];
/*     */       } 
/*     */     } 
/*  75 */     this.ids = grownIds;
/*  76 */     this.oldPaths = grownOldPaths;
/*  77 */     this.newPaths = grownNewPaths;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getIndex(long searchID) {
/*  85 */     int len = this.ids.length;
/*  86 */     int hash = hashFor(searchID, len);
/*     */     
/*     */     int i;
/*  89 */     for (i = hash; i < len; i++) {
/*  90 */       if (this.ids[i] == searchID) {
/*  91 */         return i;
/*     */       }
/*  93 */       if (this.ids[i] == 0L) {
/*  94 */         return -1;
/*     */       }
/*     */     } 
/*     */     
/*  98 */     for (i = 0; i < hash - 1; i++) {
/*  99 */       if (this.ids[i] == searchID) {
/* 100 */         return i;
/*     */       }
/* 102 */       if (this.ids[i] == 0L) {
/* 103 */         return -1;
/*     */       }
/*     */     } 
/* 106 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getNewPath(long nodeID) {
/* 114 */     int index = getIndex(nodeID);
/* 115 */     if (index == -1)
/* 116 */       return null; 
/* 117 */     return this.newPaths[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getOldPath(long nodeID) {
/* 125 */     int index = getIndex(nodeID);
/* 126 */     if (index == -1)
/* 127 */       return null; 
/* 128 */     return this.oldPaths[index];
/*     */   }
/*     */ 
/*     */   
/*     */   private int hashFor(long id, int size) {
/* 133 */     return (int)Math.abs(id * 2654435761L % size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 141 */     return (this.elementCount == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void put(long id, IPath oldPath, IPath newPath) {
/* 149 */     if (oldPath == null && newPath == null)
/*     */       return; 
/* 151 */     int hash = hashFor(id, this.ids.length);
/*     */     
/*     */     int i;
/* 154 */     for (i = hash; i < this.ids.length; i++) {
/* 155 */       if (this.ids[i] == id) {
/*     */         
/* 157 */         if (oldPath != null)
/* 158 */           this.oldPaths[i] = oldPath; 
/* 159 */         if (newPath != null)
/* 160 */           this.newPaths[i] = newPath; 
/*     */         return;
/*     */       } 
/* 163 */       if (this.ids[i] == 0L) {
/*     */         
/* 165 */         this.ids[i] = id;
/* 166 */         if (oldPath != null)
/* 167 */           this.oldPaths[i] = oldPath; 
/* 168 */         if (newPath != null)
/* 169 */           this.newPaths[i] = newPath; 
/* 170 */         this.elementCount++;
/*     */         
/* 172 */         if (shouldGrow()) {
/* 173 */           expand();
/*     */         }
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 179 */     for (i = 0; i < hash - 1; i++) {
/* 180 */       if (this.ids[i] == id) {
/*     */         
/* 182 */         if (oldPath != null)
/* 183 */           this.oldPaths[i] = oldPath; 
/* 184 */         if (newPath != null)
/* 185 */           this.newPaths[i] = newPath; 
/*     */         return;
/*     */       } 
/* 188 */       if (this.ids[i] == 0L) {
/*     */         
/* 190 */         this.ids[i] = id;
/* 191 */         if (oldPath != null)
/* 192 */           this.oldPaths[i] = oldPath; 
/* 193 */         if (newPath != null)
/* 194 */           this.newPaths[i] = newPath; 
/* 195 */         this.elementCount++;
/*     */         
/* 197 */         if (shouldGrow()) {
/* 198 */           expand();
/*     */         }
/*     */         return;
/*     */       } 
/*     */     } 
/* 203 */     expand();
/* 204 */     put(id, oldPath, newPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putOldPath(long id, IPath path) {
/* 211 */     put(id, path, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putNewPath(long id, IPath path) {
/* 218 */     put(id, null, path);
/*     */   }
/*     */   
/*     */   private boolean shouldGrow() {
/* 222 */     return (this.elementCount > this.ids.length * 0.75D);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\NodeIDMap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */