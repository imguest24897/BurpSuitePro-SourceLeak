/*     */ package org.eclipse.core.internal.resources.mapping;
/*     */ 
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IFolder;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.resources.mapping.IResourceChangeDescriptionFactory;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceChangeDescriptionFactory
/*     */   implements IResourceChangeDescriptionFactory
/*     */ {
/*  26 */   private ProposedResourceDelta root = new ProposedResourceDelta((IResource)ResourcesPlugin.getWorkspace().getRoot());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ProposedResourceDelta buildDeleteDelta(ProposedResourceDelta parentDelta, IResource resource, boolean deleteContent) {
/*  40 */     ProposedResourceDelta delta = parentDelta.getChild(resource.getName());
/*  41 */     if (delta == null) {
/*  42 */       delta = new ProposedResourceDelta(resource);
/*  43 */       parentDelta.add(delta);
/*     */     } 
/*  45 */     delta.setKind(2);
/*  46 */     if (deleteContent)
/*  47 */       delta.addFlags(8388608); 
/*  48 */     if (resource.getType() == 1) {
/*  49 */       return delta;
/*     */     }
/*     */     try {
/*  52 */       IResource[] members = ((IContainer)resource).members();
/*  53 */       int childCount = members.length;
/*  54 */       if (childCount > 0) {
/*  55 */         ProposedResourceDelta[] childDeltas = new ProposedResourceDelta[childCount];
/*  56 */         for (int i = 0; i < childCount; i++)
/*  57 */           childDeltas[i] = buildDeleteDelta(delta, members[i], deleteContent); 
/*     */       } 
/*  59 */     } catch (CoreException coreException) {}
/*     */ 
/*     */     
/*  62 */     return delta;
/*     */   }
/*     */ 
/*     */   
/*     */   public void change(IFile file) {
/*  67 */     ProposedResourceDelta delta = getDelta((IResource)file);
/*  68 */     if (delta.getKind() == 0) {
/*  69 */       delta.setKind(4);
/*     */     }
/*  71 */     if (delta.getKind() == 4 || (delta.getFlags() & 0x1000) != 0 || (delta.getFlags() & 0x800) != 0) {
/*  72 */       delta.addFlags(256);
/*     */     }
/*     */   }
/*     */   
/*     */   public void close(IProject project) {
/*  77 */     delete((IResource)project);
/*  78 */     ProposedResourceDelta delta = getDelta((IResource)project);
/*  79 */     delta.addFlags(16384);
/*     */   }
/*     */ 
/*     */   
/*     */   public void copy(IResource resource, IPath destination) {
/*  84 */     moveOrCopyDeep(resource, destination, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void create(IResource resource) {
/*  89 */     getDelta(resource).setKind(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void delete(IResource resource) {
/*  94 */     if (resource.getType() == 8) {
/*     */       
/*  96 */       IProject[] projects = ((IWorkspaceRoot)resource).getProjects(8); byte b; int i; IProject[] arrayOfIProject1;
/*  97 */       for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/*  98 */         buildDeleteDelta(this.root, (IResource)project, false); b++; }
/*     */     
/* 100 */     } else if (resource.getType() == 4) {
/* 101 */       buildDeleteDelta(this.root, resource, false);
/*     */     } else {
/*     */       
/* 104 */       buildDeleteDelta(getDelta((IResource)resource.getParent()), resource, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void delete(IProject project, boolean deleteContent) {
/* 110 */     buildDeleteDelta(this.root, (IResource)project, deleteContent);
/*     */   }
/*     */   
/*     */   private void fail(CoreException e) {
/* 114 */     Policy.log(e.getStatus().getSeverity(), "An internal error occurred while accumulating a change description.", (Throwable)e);
/*     */   }
/*     */ 
/*     */   
/*     */   public IResourceDelta getDelta() {
/* 119 */     return this.root;
/*     */   }
/*     */   
/*     */   ProposedResourceDelta getDelta(IResource resource) {
/* 123 */     ProposedResourceDelta delta = (ProposedResourceDelta)this.root.findMember(resource.getFullPath());
/* 124 */     if (delta != null) {
/* 125 */       return delta;
/*     */     }
/* 127 */     ProposedResourceDelta parent = getDelta((IResource)resource.getParent());
/* 128 */     delta = new ProposedResourceDelta(resource);
/* 129 */     parent.add(delta);
/* 130 */     return delta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IResource getDestinationResource(IResource source, IPath sourcePrefix, IPath destinationPrefix) {
/*     */     IFile iFile;
/*     */     IFolder iFolder;
/*     */     IProject iProject;
/* 141 */     IPath relativePath = source.getFullPath().removeFirstSegments(sourcePrefix.segmentCount());
/* 142 */     IPath destinationPath = destinationPrefix.append(relativePath);
/*     */     
/* 144 */     IWorkspaceRoot wsRoot = ResourcesPlugin.getWorkspace().getRoot();
/* 145 */     switch (source.getType()) {
/*     */       case 1:
/* 147 */         return (IResource)wsRoot.getFile(destinationPath);
/*     */       
/*     */       case 2:
/* 150 */         return (IResource)wsRoot.getFolder(destinationPath);
/*     */       
/*     */       case 4:
/* 153 */         return (IResource)wsRoot.getProject(destinationPath.segment(0));
/*     */     } 
/*     */ 
/*     */     
/* 157 */     IResource destination = null;
/*     */     
/* 159 */     return destination;
/*     */   }
/*     */ 
/*     */   
/*     */   public void move(IResource resource, IPath destination) {
/* 164 */     moveOrCopyDeep(resource, destination, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean moveOrCopy(IResource resource, IPath sourcePrefix, IPath destinationPrefix, boolean move) {
/* 177 */     ProposedResourceDelta sourceDelta = getDelta(resource);
/* 178 */     if (sourceDelta.getKind() == 2)
/*     */     {
/*     */       
/* 181 */       return false;
/*     */     }
/* 183 */     IResource destinationResource = getDestinationResource(resource, sourcePrefix, destinationPrefix);
/* 184 */     ProposedResourceDelta destinationDelta = getDelta(destinationResource);
/* 185 */     if ((destinationDelta.getKind() & 0x5) > 0)
/*     */     {
/*     */       
/* 188 */       return false;
/*     */     }
/*     */     
/* 191 */     IPath fromPath = resource.getFullPath();
/* 192 */     boolean wasAdded = false;
/* 193 */     int sourceFlags = sourceDelta.getFlags();
/* 194 */     if (move)
/*     */     {
/* 196 */       if (sourceDelta.getKind() == 1) {
/* 197 */         if ((sourceFlags & 0x1000) != 0) {
/*     */ 
/*     */           
/* 200 */           fromPath = sourceDelta.getMovedFromPath();
/* 201 */           sourceDelta.setMovedFromPath(null);
/*     */         } 
/*     */ 
/*     */         
/* 205 */         sourceDelta.setKind(0);
/* 206 */         wasAdded = true;
/*     */       } else {
/*     */         
/* 209 */         sourceDelta.setKind(2);
/* 210 */         sourceDelta.setFlags(8192);
/* 211 */         sourceDelta.setMovedToPath(destinationPrefix.append(fromPath.removeFirstSegments(sourcePrefix.segmentCount())));
/*     */       } 
/*     */     }
/*     */     
/* 215 */     if (destinationDelta.getKind() == 2) {
/*     */       
/* 217 */       destinationDelta.setKind(4);
/* 218 */       destinationDelta.addFlags(262144);
/*     */     } else {
/* 220 */       destinationDelta.setKind(1);
/*     */     } 
/* 222 */     if (!wasAdded || !fromPath.equals(resource.getFullPath())) {
/*     */       
/* 224 */       destinationDelta.addFlags(move ? 4096 : 2048);
/* 225 */       destinationDelta.setMovedFromPath(fromPath);
/*     */       
/* 227 */       if (move) {
/* 228 */         destinationDelta.addFlags(sourceFlags);
/*     */       }
/*     */     } 
/* 231 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void moveOrCopyDeep(IResource resource, IPath destination, boolean move) {
/* 239 */     IPath sourcePrefix = resource.getFullPath();
/* 240 */     IPath destinationPrefix = destination;
/*     */     
/*     */     try {
/* 243 */       if (resource.isAccessible()) {
/* 244 */         resource.accept(child -> moveOrCopy(child, paramIPath1, paramIPath2, paramBoolean));
/*     */       } else {
/*     */         
/* 247 */         moveOrCopy(resource, sourcePrefix, destination, move);
/*     */       } 
/* 249 */     } catch (CoreException e) {
/* 250 */       fail(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\mapping\ResourceChangeDescriptionFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */