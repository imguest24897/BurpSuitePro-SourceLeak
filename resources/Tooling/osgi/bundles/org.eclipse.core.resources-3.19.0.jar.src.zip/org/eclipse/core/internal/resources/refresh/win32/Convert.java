/*    */ package org.eclipse.core.internal.resources.refresh.win32;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Convert
/*    */ {
/* 27 */   private static String defaultEncoding = (new InputStreamReader(new ByteArrayInputStream(new byte[0]))).getEncoding();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static byte[] toPlatformBytes(String target) {
/* 41 */     if (defaultEncoding == null) {
/* 42 */       return target.getBytes();
/*    */     }
/*    */     try {
/* 45 */       return target.getBytes(defaultEncoding);
/* 46 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*    */       
/* 48 */       defaultEncoding = null;
/* 49 */       return target.getBytes();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\refresh\win32\Convert.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */