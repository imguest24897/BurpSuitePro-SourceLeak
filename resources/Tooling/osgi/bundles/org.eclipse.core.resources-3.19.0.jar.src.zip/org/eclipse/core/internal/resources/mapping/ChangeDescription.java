/*     */ package org.eclipse.core.internal.resources.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChangeDescription
/*     */ {
/*  27 */   private List<IResource> addedRoots = new ArrayList<>();
/*  28 */   private List<IResource> changedFiles = new ArrayList<>();
/*  29 */   private List<IResource> closedProjects = new ArrayList<>();
/*  30 */   private List<IResource> copiedRoots = new ArrayList<>();
/*  31 */   private List<IResource> movedRoots = new ArrayList<>();
/*  32 */   private List<IResource> removedRoots = new ArrayList<>();
/*     */   
/*     */   private IResource createSourceResource(IResourceDelta delta) {
/*  35 */     IPath sourcePath = delta.getMovedFromPath();
/*  36 */     IResource resource = delta.getResource();
/*  37 */     IWorkspaceRoot wsRoot = ResourcesPlugin.getWorkspace().getRoot();
/*  38 */     switch (resource.getType()) {
/*     */       case 4:
/*  40 */         return (IResource)wsRoot.getProject(sourcePath.segment(0));
/*     */       case 2:
/*  42 */         return (IResource)wsRoot.getFolder(sourcePath);
/*     */       case 1:
/*  44 */         return (IResource)wsRoot.getFile(sourcePath);
/*     */     } 
/*  46 */     return null;
/*     */   }
/*     */   
/*     */   private void ensureResourceCovered(IResource resource, List<IResource> list) {
/*  50 */     IPath path = resource.getFullPath();
/*  51 */     for (IResource root : list) {
/*  52 */       if (root.getFullPath().isPrefixOf(path)) {
/*     */         return;
/*     */       }
/*     */     } 
/*  56 */     list.add(resource);
/*     */   }
/*     */   
/*     */   public IResource[] getRootResources() {
/*  60 */     Set<IResource> result = new HashSet<>();
/*  61 */     result.addAll(this.addedRoots);
/*  62 */     result.addAll(this.changedFiles);
/*  63 */     result.addAll(this.closedProjects);
/*  64 */     result.addAll(this.copiedRoots);
/*  65 */     result.addAll(this.movedRoots);
/*  66 */     result.addAll(this.removedRoots);
/*  67 */     return result.<IResource>toArray(new IResource[result.size()]);
/*     */   }
/*     */   
/*     */   private void handleAdded(IResourceDelta delta) {
/*  71 */     if ((delta.getFlags() & 0x1000) != 0) {
/*  72 */       handleMove(delta);
/*  73 */     } else if ((delta.getFlags() & 0x800) != 0) {
/*  74 */       handleCopy(delta);
/*     */     } else {
/*  76 */       ensureResourceCovered(delta.getResource(), this.addedRoots);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleChange(IResourceDelta delta) {
/*  81 */     if ((delta.getFlags() & 0x40000) != 0) {
/*     */       
/*  83 */       handleAdded(delta);
/*  84 */     } else if (delta.getResource().getType() == 1) {
/*  85 */       ensureResourceCovered(delta.getResource(), this.changedFiles);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleCopy(IResourceDelta delta) {
/*  90 */     if ((delta.getFlags() & 0x800) != 0) {
/*  91 */       IResource source = createSourceResource(delta);
/*  92 */       ensureResourceCovered(source, this.copiedRoots);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleMove(IResourceDelta delta) {
/*  97 */     if ((delta.getFlags() & 0x2000) != 0) {
/*  98 */       this.movedRoots.add(delta.getResource());
/*  99 */     } else if ((delta.getFlags() & 0x1000) != 0) {
/* 100 */       IResource source = createSourceResource(delta);
/* 101 */       ensureResourceCovered(source, this.movedRoots);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleRemoved(IResourceDelta delta) {
/* 106 */     if ((delta.getFlags() & 0x4000) != 0) {
/* 107 */       this.closedProjects.add(delta.getResource());
/* 108 */     } else if ((delta.getFlags() & 0x2000) != 0) {
/* 109 */       handleMove(delta);
/*     */     } else {
/* 111 */       ensureResourceCovered(delta.getResource(), this.removedRoots);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean recordChange(IResourceDelta delta) {
/* 121 */     switch (delta.getKind()) {
/*     */       case 1:
/* 123 */         handleAdded(delta);
/* 124 */         return true;
/*     */       case 2:
/* 126 */         handleRemoved(delta);
/*     */ 
/*     */         
/* 129 */         return false;
/*     */       case 4:
/* 131 */         handleChange(delta);
/* 132 */         return true;
/*     */     } 
/* 134 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\mapping\ChangeDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */