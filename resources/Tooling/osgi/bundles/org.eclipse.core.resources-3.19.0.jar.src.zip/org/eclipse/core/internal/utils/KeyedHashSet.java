/*     */ package org.eclipse.core.internal.utils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyedHashSet
/*     */ {
/*     */   protected static final int MINIMUM_SIZE = 7;
/*     */   private int capacity;
/*  32 */   protected int elementCount = 0;
/*     */   protected KeyedElement[] elements;
/*     */   protected boolean replace;
/*     */   
/*     */   public KeyedHashSet(int capacity) {
/*  37 */     this(capacity, true);
/*     */   }
/*     */   
/*     */   public KeyedHashSet(int capacity, boolean replace) {
/*  41 */     this.elements = new KeyedElement[Math.max(7, capacity * 2)];
/*  42 */     this.replace = replace;
/*  43 */     this.capacity = capacity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(KeyedElement element) {
/*  52 */     int hash = hash(element);
/*     */     
/*     */     int i;
/*  55 */     for (i = hash; i < this.elements.length; i++) {
/*  56 */       if (this.elements[i] == null) {
/*  57 */         this.elements[i] = element;
/*  58 */         this.elementCount++;
/*     */         
/*  60 */         if (shouldGrow())
/*  61 */           expand(); 
/*  62 */         return true;
/*     */       } 
/*  64 */       if (this.elements[i].compare(element)) {
/*  65 */         if (this.replace)
/*  66 */           this.elements[i] = element; 
/*  67 */         return this.replace;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  72 */     for (i = 0; i < hash - 1; i++) {
/*  73 */       if (this.elements[i] == null) {
/*  74 */         this.elements[i] = element;
/*  75 */         this.elementCount++;
/*     */         
/*  77 */         if (shouldGrow())
/*  78 */           expand(); 
/*  79 */         return true;
/*     */       } 
/*  81 */       if (this.elements[i].compare(element)) {
/*  82 */         if (this.replace)
/*  83 */           this.elements[i] = element; 
/*  84 */         return this.replace;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  89 */     expand();
/*  90 */     return add(element);
/*     */   }
/*     */   
/*     */   public void clear() {
/*  94 */     this.elements = new KeyedElement[Math.max(7, this.capacity * 2)];
/*  95 */     this.elementCount = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void expand() {
/* 103 */     KeyedElement[] oldElements = this.elements;
/* 104 */     this.elements = new KeyedElement[this.elements.length * 2];
/*     */     
/* 106 */     int maxArrayIndex = this.elements.length - 1; byte b; int i; KeyedElement[] arrayOfKeyedElement1;
/* 107 */     for (i = (arrayOfKeyedElement1 = oldElements).length, b = 0; b < i; ) { KeyedElement element = arrayOfKeyedElement1[b];
/* 108 */       if (element != null) {
/* 109 */         int hash = hash(element);
/* 110 */         while (this.elements[hash] != null) {
/* 111 */           hash++;
/* 112 */           if (hash > maxArrayIndex)
/* 113 */             hash = 0; 
/*     */         } 
/* 115 */         this.elements[hash] = element;
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyedElement getByKey(Object key) {
/* 125 */     if (this.elementCount == 0)
/* 126 */       return null; 
/* 127 */     int hash = keyHash(key);
/*     */     
/*     */     int i;
/* 130 */     for (i = hash; i < this.elements.length; i++) {
/* 131 */       KeyedElement element = this.elements[i];
/* 132 */       if (element == null)
/* 133 */         return null; 
/* 134 */       if (element.getKey().equals(key)) {
/* 135 */         return element;
/*     */       }
/*     */     } 
/*     */     
/* 139 */     for (i = 0; i < hash - 1; i++) {
/* 140 */       KeyedElement element = this.elements[i];
/* 141 */       if (element == null)
/* 142 */         return null; 
/* 143 */       if (element.getKey().equals(key)) {
/* 144 */         return element;
/*     */       }
/*     */     } 
/*     */     
/* 148 */     return null;
/*     */   }
/*     */   
/*     */   private int hash(KeyedElement key) {
/* 152 */     return (key.getKeyHashCode() & Integer.MAX_VALUE) % this.elements.length;
/*     */   }
/*     */   
/*     */   private int keyHash(Object key) {
/* 156 */     return (key.hashCode() & Integer.MAX_VALUE) % this.elements.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void rehashTo(int anIndex) {
/* 165 */     int target = anIndex;
/* 166 */     int index = anIndex + 1;
/* 167 */     if (index >= this.elements.length)
/* 168 */       index = 0; 
/* 169 */     KeyedElement element = this.elements[index];
/* 170 */     while (element != null) {
/* 171 */       boolean match; int hashIndex = hash(element);
/*     */       
/* 173 */       if (index < target) {
/* 174 */         match = !(hashIndex > target || hashIndex <= index);
/*     */       } else {
/* 176 */         match = !(hashIndex > target && hashIndex <= index);
/* 177 */       }  if (match) {
/* 178 */         this.elements[target] = element;
/* 179 */         target = index;
/*     */       } 
/* 181 */       index++;
/* 182 */       if (index >= this.elements.length)
/* 183 */         index = 0; 
/* 184 */       element = this.elements[index];
/*     */     } 
/* 186 */     this.elements[target] = null;
/*     */   }
/*     */   
/*     */   public boolean remove(KeyedElement toRemove) {
/* 190 */     if (this.elementCount == 0) {
/* 191 */       return false;
/*     */     }
/* 193 */     int hash = hash(toRemove);
/*     */     int i;
/* 195 */     for (i = hash; i < this.elements.length; i++) {
/* 196 */       KeyedElement element = this.elements[i];
/* 197 */       if (element == null)
/* 198 */         return false; 
/* 199 */       if (element.compare(toRemove)) {
/* 200 */         rehashTo(i);
/* 201 */         this.elementCount--;
/* 202 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 206 */     for (i = 0; i < hash - 1; i++) {
/* 207 */       KeyedElement element = this.elements[i];
/* 208 */       if (element == null)
/* 209 */         return false; 
/* 210 */       if (element.compare(toRemove)) {
/* 211 */         rehashTo(i);
/* 212 */         this.elementCount--;
/* 213 */         return true;
/*     */       } 
/*     */     } 
/* 216 */     return false;
/*     */   }
/*     */   
/*     */   private boolean shouldGrow() {
/* 220 */     return (this.elementCount > this.elements.length * 0.75D);
/*     */   }
/*     */   
/*     */   public int size() {
/* 224 */     return this.elementCount;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 229 */     StringBuilder result = new StringBuilder(100);
/* 230 */     result.append('{');
/* 231 */     boolean first = true; byte b; int i; KeyedElement[] arrayOfKeyedElement;
/* 232 */     for (i = (arrayOfKeyedElement = this.elements).length, b = 0; b < i; ) { KeyedElement element = arrayOfKeyedElement[b];
/* 233 */       if (element != null) {
/* 234 */         if (first) {
/* 235 */           first = false;
/*     */         } else {
/* 237 */           result.append(", ");
/* 238 */         }  result.append(element);
/*     */       }  b++; }
/*     */     
/* 241 */     result.append('}');
/* 242 */     return result.toString();
/*     */   }
/*     */   
/*     */   public static interface KeyedElement {
/*     */     boolean compare(KeyedElement param1KeyedElement);
/*     */     
/*     */     Object getKey();
/*     */     
/*     */     int getKeyHashCode();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\interna\\utils\KeyedHashSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */