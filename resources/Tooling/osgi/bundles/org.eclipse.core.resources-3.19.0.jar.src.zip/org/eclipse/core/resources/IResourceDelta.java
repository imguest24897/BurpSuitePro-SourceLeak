package org.eclipse.core.resources;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IPath;

public interface IResourceDelta extends IAdaptable {
  public static final int NO_CHANGE = 0;
  
  public static final int ADDED = 1;
  
  public static final int REMOVED = 2;
  
  public static final int CHANGED = 4;
  
  public static final int ADDED_PHANTOM = 8;
  
  public static final int REMOVED_PHANTOM = 16;
  
  public static final int ALL_WITH_PHANTOMS = 31;
  
  public static final int CONTENT = 256;
  
  public static final int MOVED_FROM = 4096;
  
  public static final int MOVED_TO = 8192;
  
  public static final int COPIED_FROM = 2048;
  
  public static final int OPEN = 16384;
  
  public static final int TYPE = 32768;
  
  public static final int SYNC = 65536;
  
  public static final int MARKERS = 131072;
  
  public static final int REPLACED = 262144;
  
  public static final int DESCRIPTION = 524288;
  
  public static final int ENCODING = 1048576;
  
  public static final int LOCAL_CHANGED = 2097152;
  
  public static final int DERIVED_CHANGED = 4194304;
  
  public static final int DELETE_CONTENT_PROPOSED = 8388608;
  
  void accept(IResourceDeltaVisitor paramIResourceDeltaVisitor) throws CoreException;
  
  void accept(IResourceDeltaVisitor paramIResourceDeltaVisitor, boolean paramBoolean) throws CoreException;
  
  void accept(IResourceDeltaVisitor paramIResourceDeltaVisitor, int paramInt) throws CoreException;
  
  IResourceDelta findMember(IPath paramIPath);
  
  IResourceDelta[] getAffectedChildren();
  
  IResourceDelta[] getAffectedChildren(int paramInt);
  
  IResourceDelta[] getAffectedChildren(int paramInt1, int paramInt2);
  
  int getFlags();
  
  IPath getFullPath();
  
  int getKind();
  
  IMarkerDelta[] getMarkerDeltas();
  
  IPath getMovedFromPath();
  
  IPath getMovedToPath();
  
  IPath getProjectRelativePath();
  
  IResource getResource();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IResourceDelta.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */