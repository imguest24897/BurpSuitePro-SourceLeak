package org.eclipse.core.resources;

import java.net.URI;
import java.util.Map;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.content.IContentTypeMatcher;

public interface IProject extends IContainer, IAdaptable {
  public static final int SNAPSHOT_TREE = 1;
  
  void build(int paramInt, String paramString, Map<String, String> paramMap, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void build(int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void build(IBuildConfiguration paramIBuildConfiguration, int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void close(IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void create(IProjectDescription paramIProjectDescription, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void create(IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void create(IProjectDescription paramIProjectDescription, int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void delete(boolean paramBoolean1, boolean paramBoolean2, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  IBuildConfiguration getActiveBuildConfig() throws CoreException;
  
  IBuildConfiguration getBuildConfig(String paramString) throws CoreException;
  
  IBuildConfiguration[] getBuildConfigs() throws CoreException;
  
  IContentTypeMatcher getContentTypeMatcher() throws CoreException;
  
  IProjectDescription getDescription() throws CoreException;
  
  IFile getFile(String paramString);
  
  IFolder getFolder(String paramString);
  
  IProjectNature getNature(String paramString) throws CoreException;
  
  IPath getWorkingLocation(String paramString);
  
  IProject[] getReferencedProjects() throws CoreException;
  
  void clearCachedDynamicReferences();
  
  IProject[] getReferencingProjects();
  
  IBuildConfiguration[] getReferencedBuildConfigs(String paramString, boolean paramBoolean) throws CoreException;
  
  boolean hasBuildConfig(String paramString) throws CoreException;
  
  boolean hasNature(String paramString) throws CoreException;
  
  boolean isNatureEnabled(String paramString) throws CoreException;
  
  boolean isOpen();
  
  void loadSnapshot(int paramInt, URI paramURI, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void move(IProjectDescription paramIProjectDescription, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void open(int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void open(IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void saveSnapshot(int paramInt, URI paramURI, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void setDescription(IProjectDescription paramIProjectDescription, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void setDescription(IProjectDescription paramIProjectDescription, int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  String getDefaultLineSeparator() throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IProject.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */