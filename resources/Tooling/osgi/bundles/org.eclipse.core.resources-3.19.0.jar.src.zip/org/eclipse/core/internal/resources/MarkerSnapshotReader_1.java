/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarkerSnapshotReader_1
/*     */   extends MarkerSnapshotReader
/*     */ {
/*     */   public static final byte INDEX = 1;
/*     */   public static final byte QNAME = 2;
/*     */   public static final byte ATTRIBUTE_NULL = 0;
/*     */   public static final byte ATTRIBUTE_BOOLEAN = 1;
/*     */   public static final byte ATTRIBUTE_INTEGER = 2;
/*     */   public static final byte ATTRIBUTE_STRING = 3;
/*     */   
/*     */   public MarkerSnapshotReader_1(Workspace workspace) {
/*  43 */     super(workspace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void read(DataInputStream input) throws IOException, CoreException {
/*  70 */     Path path = new Path(input.readUTF());
/*  71 */     int markersSize = input.readInt();
/*  72 */     MarkerSet markers = new MarkerSet(markersSize);
/*  73 */     ArrayList<String> readTypes = new ArrayList<>();
/*  74 */     for (int i = 0; i < markersSize; i++) {
/*  75 */       markers.add(readMarkerInfo(input, readTypes));
/*     */     }
/*     */     
/*  78 */     ResourceInfo info = this.workspace.getResourceInfo((IPath)path, false, false);
/*  79 */     if (info == null)
/*     */       return; 
/*  81 */     info.setMarkers(markers);
/*  82 */     info.clear(4096);
/*     */   }
/*     */   
/*     */   private Map<String, Object> readAttributes(DataInputStream input) throws IOException {
/*  86 */     short attributesSize = input.readShort();
/*  87 */     if (attributesSize == 0)
/*  88 */       return null; 
/*  89 */     Map<String, Object> result = new HashMap<>(attributesSize);
/*  90 */     for (int j = 0; j < attributesSize; j++) {
/*  91 */       String key = input.readUTF();
/*  92 */       byte type = input.readByte();
/*  93 */       Object value = null;
/*  94 */       switch (type) {
/*     */         case 2:
/*  96 */           value = Integer.valueOf(input.readInt());
/*     */           break;
/*     */         case 1:
/*  99 */           value = Boolean.valueOf(input.readBoolean());
/*     */           break;
/*     */         case 3:
/* 102 */           value = input.readUTF();
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 108 */       if (value != null) {
/* 109 */         result.put(key, value);
/*     */       }
/*     */     } 
/* 112 */     return result.isEmpty() ? null : result; } private MarkerInfo readMarkerInfo(DataInputStream input, List<String> readTypes) throws IOException, CoreException {
/*     */     Map<String, Object> map, map1;
/*     */     long creationTime;
/*     */     MarkerInfo info;
/* 116 */     long id = input.readLong();
/* 117 */     byte constant = input.readByte();
/* 118 */     String type = null;
/* 119 */     switch (constant) {
/*     */       case 2:
/* 121 */         type = input.readUTF();
/* 122 */         readTypes.add(type);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 132 */         map = readAttributes(input);
/* 133 */         creationTime = 0L;
/* 134 */         info = new MarkerInfo(map, false, creationTime, type, id);
/* 135 */         return info;case 1: type = readTypes.get(input.readInt()); map1 = readAttributes(input); creationTime = 0L; info = new MarkerInfo(map1, false, creationTime, type, id); return info;
/*     */     } 
/*     */     String str1 = Messages.resources_readMarkers;
/*     */     throw new ResourceException(567, null, str1, null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\MarkerSnapshotReader_1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */