/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.net.URI;
/*    */ import org.eclipse.core.filesystem.EFS;
/*    */ import org.eclipse.core.filesystem.IFileInfo;
/*    */ import org.eclipse.core.filesystem.IFileStore;
/*    */ import org.eclipse.core.filesystem.provider.FileInfo;
/*    */ import org.eclipse.core.filesystem.provider.FileStore;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VirtualFileStore
/*    */   extends FileStore
/*    */ {
/*    */   private final URI location;
/*    */   
/*    */   public VirtualFileStore(URI location) {
/* 32 */     this.location = location;
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] childNames(int options, IProgressMonitor monitor) {
/* 37 */     return FileStore.EMPTY_STRING_ARRAY;
/*    */   }
/*    */ 
/*    */   
/*    */   public IFileInfo fetchInfo(int options, IProgressMonitor monitor) {
/* 42 */     FileInfo result = new FileInfo();
/* 43 */     result.setDirectory(true);
/* 44 */     result.setExists(true);
/* 45 */     result.setLastModified(1L);
/* 46 */     return (IFileInfo)result;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void delete(int options, IProgressMonitor monitor) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public IFileStore getChild(String name) {
/* 56 */     return EFS.getNullFileSystem().getStore((new Path(name)).makeAbsolute());
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 61 */     return "virtual";
/*    */   }
/*    */ 
/*    */   
/*    */   public IFileStore getParent() {
/* 66 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void move(IFileStore destination, int options, IProgressMonitor monitor) throws CoreException {
/* 71 */     destination.mkdir(0, monitor);
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream openInputStream(int options, IProgressMonitor monitor) {
/* 76 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public URI toURI() {
/* 81 */     return this.location;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\VirtualFileStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */