/*    */ package org.eclipse.core.internal.resources.mapping;
/*    */ 
/*    */ import org.eclipse.core.resources.IContainer;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.runtime.PlatformObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShallowContainer
/*    */   extends PlatformObject
/*    */ {
/*    */   private IContainer container;
/*    */   
/*    */   public ShallowContainer(IContainer container) {
/* 28 */     this.container = container;
/*    */   }
/*    */   
/*    */   public IContainer getResource() {
/* 32 */     return this.container;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 37 */     if (obj == this)
/* 38 */       return true; 
/* 39 */     if (obj instanceof ShallowContainer) {
/* 40 */       ShallowContainer other = (ShallowContainer)obj;
/* 41 */       return other.getResource().equals(getResource());
/*    */     } 
/* 43 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 48 */     return getResource().hashCode();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> T getAdapter(Class<T> adapter) {
/* 54 */     if (adapter == IResource.class || adapter == IContainer.class)
/* 55 */       return (T)this.container; 
/* 56 */     return (T)super.getAdapter(adapter);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\mapping\ShallowContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */