/*     */ package org.eclipse.core.internal.dtree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NodeComparison
/*     */ {
/*     */   private Object oldData;
/*     */   private Object newData;
/*     */   private int comparison;
/*     */   private int userInt;
/*     */   public static final int K_ADDED = 1;
/*     */   public static final int K_REMOVED = 2;
/*     */   public static final int K_CHANGED = 4;
/*     */   
/*     */   NodeComparison(Object oldData, Object newData, int realComparison, int userComparison) {
/*  48 */     this.oldData = oldData;
/*  49 */     this.newData = newData;
/*  50 */     this.comparison = realComparison;
/*  51 */     this.userInt = userComparison;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NodeComparison asReverseComparison(IComparator comparator) {
/*  59 */     Object tempData = this.oldData;
/*  60 */     this.oldData = this.newData;
/*  61 */     this.newData = tempData;
/*     */ 
/*     */     
/*  64 */     this.userInt = comparator.compare(this.oldData, this.newData);
/*     */     
/*  66 */     if (this.comparison == 1) {
/*  67 */       this.comparison = 2;
/*     */     }
/*  69 */     else if (this.comparison == 2) {
/*  70 */       this.comparison = 1;
/*     */     } 
/*     */     
/*  73 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getComparison() {
/*  82 */     return this.comparison;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getNewData() {
/*  89 */     return this.newData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getOldData() {
/*  96 */     return this.oldData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getUserComparison() {
/* 103 */     return this.userInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isUnchanged() {
/* 110 */     return (this.userInt == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 118 */     StringBuilder buf = new StringBuilder("NodeComparison(");
/* 119 */     switch (this.comparison)
/*     */     { case 1:
/* 121 */         buf.append("Added, ");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 135 */         buf.append(this.userInt);
/* 136 */         buf.append(")");
/* 137 */         return buf.toString();case 2: buf.append("Removed, "); buf.append(this.userInt); buf.append(")"); return buf.toString();case 4: buf.append("Changed, "); buf.append(this.userInt); buf.append(")"); return buf.toString();case 0: buf.append("No change, "); buf.append(this.userInt); buf.append(")"); return buf.toString(); }  buf.append("Corrupt(" + this.comparison + "), "); buf.append(this.userInt); buf.append(")"); return buf.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\dtree\NodeComparison.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */