/*     */ package org.eclipse.core.internal.dtree;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.IOException;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataTreeReader
/*     */ {
/*     */   protected IDataFlattener flatener;
/*     */   protected DataInput input;
/*     */   
/*     */   public DataTreeReader(IDataFlattener f) {
/*  40 */     this.flatener = f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasData(int nodeType) {
/*  47 */     switch (nodeType) {
/*     */       case 0:
/*     */       case 1:
/*  50 */         return true;
/*     */     } 
/*     */ 
/*     */     
/*  54 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractDataTreeNode readNode(IPath parentPath, String newProjectName) throws IOException {
/*     */     Path path;
/*     */     AbstractDataTreeNode[] children;
/*  66 */     String name = this.input.readUTF();
/*     */ 
/*     */     
/*  69 */     int nodeType = readNumber();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     if (parentPath != null) {
/*  76 */       if (parentPath.equals(Path.ROOT) && newProjectName.length() > 0 && name.length() > 0)
/*     */       {
/*  78 */         name = newProjectName;
/*     */       }
/*  80 */       IPath iPath = parentPath.append(name);
/*     */     } else {
/*  82 */       path = Path.ROOT;
/*     */     } 
/*     */     
/*  85 */     Object data = null;
/*  86 */     if (hasData(nodeType)) {
/*     */ 
/*     */       
/*  89 */       int dataFlag = readNumber();
/*  90 */       if (dataFlag != 0) {
/*  91 */         data = this.flatener.readData((IPath)path, this.input);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  96 */     int childCount = readNumber();
/*     */ 
/*     */ 
/*     */     
/* 100 */     if (childCount == 0) {
/* 101 */       children = AbstractDataTreeNode.NO_CHILDREN;
/*     */     } else {
/* 103 */       children = new AbstractDataTreeNode[childCount];
/* 104 */       for (int i = 0; i < childCount; i++) {
/* 105 */         children[i] = readNode((IPath)path, newProjectName);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 110 */     switch (nodeType) {
/*     */       case 0:
/* 112 */         return new DataTreeNode(name, data, children);
/*     */       case 1:
/* 114 */         return new DataDeltaNode(name, data, children);
/*     */       case 2:
/* 116 */         return new DeletedNode(name);
/*     */       case 3:
/* 118 */         return new NoDataDeltaNode(name, children);
/*     */     } 
/* 120 */     Assert.isTrue(false, Messages.dtree_switchError);
/* 121 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int readNumber() throws IOException {
/* 132 */     byte b = this.input.readByte();
/* 133 */     int number = b & 0xFF;
/*     */     
/* 135 */     if (number == 255) {
/* 136 */       number = this.input.readInt();
/*     */     }
/* 138 */     return number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeltaDataTree readTree(DeltaDataTree parent, DataInput input, String newProjectName) throws IOException {
/* 148 */     this.input = input;
/* 149 */     AbstractDataTreeNode root = readNode((IPath)Path.ROOT, newProjectName);
/* 150 */     return new DeltaDataTree(root, parent);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\dtree\DataTreeReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */