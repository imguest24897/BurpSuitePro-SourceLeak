package org.eclipse.core.resources;

import java.net.URI;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IWorkspaceRoot extends IContainer, IAdaptable {
  void delete(boolean paramBoolean1, boolean paramBoolean2, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  @Deprecated
  IContainer[] findContainersForLocation(IPath paramIPath);
  
  IContainer[] findContainersForLocationURI(URI paramURI);
  
  IContainer[] findContainersForLocationURI(URI paramURI, int paramInt);
  
  @Deprecated
  IFile[] findFilesForLocation(IPath paramIPath);
  
  IFile[] findFilesForLocationURI(URI paramURI);
  
  IFile[] findFilesForLocationURI(URI paramURI, int paramInt);
  
  IContainer getContainerForLocation(IPath paramIPath);
  
  IFile getFileForLocation(IPath paramIPath);
  
  IProject getProject(String paramString);
  
  IProject[] getProjects();
  
  IProject[] getProjects(int paramInt);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IWorkspaceRoot.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */