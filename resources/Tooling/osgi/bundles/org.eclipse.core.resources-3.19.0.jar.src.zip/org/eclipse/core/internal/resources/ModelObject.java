/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ModelObject
/*    */   implements Cloneable
/*    */ {
/*    */   protected String name;
/*    */   
/*    */   public ModelObject() {}
/*    */   
/*    */   public ModelObject(String name) {
/* 24 */     setName(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object clone() {
/*    */     try {
/* 30 */       return super.clone();
/* 31 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/* 32 */       return null;
/*    */     } 
/*    */   }
/*    */   
/*    */   public String getName() {
/* 37 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String value) {
/* 41 */     this.name = value;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ModelObject.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */