/*     */ package org.eclipse.core.internal.localstore;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Entry
/*     */ {
/*     */   private static final int STATE_CLEAR = 0;
/*     */   private static final int STATE_DELETED = 2;
/*     */   private static final int STATE_DIRTY = 1;
/*     */   private IPath path;
/*  70 */   private byte state = 0;
/*     */   
/*     */   protected Entry(IPath path) {
/*  73 */     this.path = path;
/*     */   }
/*     */   
/*     */   public void delete() {
/*  77 */     this.state = 2;
/*     */   }
/*     */   
/*     */   public abstract int getOccurrences();
/*     */   
/*     */   public IPath getPath() {
/*  83 */     return this.path;
/*     */   }
/*     */   
/*     */   public abstract Object getValue();
/*     */   
/*     */   public boolean isDeleted() {
/*  89 */     return (this.state == 2);
/*     */   }
/*     */   
/*     */   public boolean isDirty() {
/*  93 */     return (this.state == 1);
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/*  97 */     return (getOccurrences() == 0);
/*     */   }
/*     */   
/*     */   public void markDirty() {
/* 101 */     Assert.isTrue((this.state != 2));
/* 102 */     this.state = 1;
/*     */   }
/*     */   
/*     */   public void visited() {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\Bucket$Entry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */