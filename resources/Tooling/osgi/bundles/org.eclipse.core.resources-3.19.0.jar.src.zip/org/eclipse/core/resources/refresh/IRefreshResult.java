package org.eclipse.core.resources.refresh;

import org.eclipse.core.resources.IResource;

public interface IRefreshResult {
  void monitorFailed(IRefreshMonitor paramIRefreshMonitor, IResource paramIResource);
  
  void refresh(IResource paramIResource);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\refresh\IRefreshResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */