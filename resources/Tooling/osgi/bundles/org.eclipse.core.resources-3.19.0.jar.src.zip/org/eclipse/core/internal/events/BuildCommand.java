/*     */ package org.eclipse.core.internal.events;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.resources.ModelObject;
/*     */ import org.eclipse.core.resources.IBuildConfiguration;
/*     */ import org.eclipse.core.resources.ICommand;
/*     */ import org.eclipse.core.resources.IncrementalProjectBuilder;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BuildCommand
/*     */   extends ModelObject
/*     */   implements ICommand
/*     */ {
/*     */   private static final int MASK_AUTO = 1;
/*     */   private static final int MASK_INCREMENTAL = 2;
/*     */   private static final int MASK_FULL = 4;
/*     */   private static final int MASK_CLEAN = 8;
/*     */   private static final int MASK_CONFIGURABLE = 16;
/*     */   private static final int MASK_CONFIG_COMPUTED = 32;
/*     */   private static final int ALL_TRIGGERS = 15;
/*  54 */   protected HashMap<String, String> arguments = new HashMap<>(0);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean supportsConfigurationsCalculated;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean supportsConfigurations;
/*     */ 
/*     */ 
/*     */   
/*     */   private IncrementalProjectBuilder builder;
/*     */ 
/*     */ 
/*     */   
/*     */   private HashMap<IBuildConfiguration, IncrementalProjectBuilder> builders;
/*     */ 
/*     */ 
/*     */   
/*  76 */   private int triggers = 15;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private final Object builderLock = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int maskForTrigger(int trigger) {
/*  87 */     switch (trigger) {
/*     */       case 9:
/*  89 */         return 1;
/*     */       case 10:
/*  91 */         return 2;
/*     */       case 6:
/*  93 */         return 4;
/*     */       case 15:
/*  95 */         return 8;
/*     */     } 
/*  97 */     return 0;
/*     */   }
/*     */   
/*     */   public BuildCommand() {
/* 101 */     super("");
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 106 */     BuildCommand result = (BuildCommand)super.clone();
/* 107 */     if (result == null)
/* 108 */       return null; 
/* 109 */     result.setArguments(getArguments());
/*     */     
/* 111 */     result.setBuilders((Object)null);
/* 112 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void computeIsConfigurable() {
/* 120 */     this.triggers |= 0x20;
/* 121 */     IExtension extension = Platform.getExtensionRegistry().getExtension("org.eclipse.core.resources", "builders", this.name);
/* 122 */     if (extension != null) {
/* 123 */       IConfigurationElement[] configs = extension.getConfigurationElements();
/* 124 */       if (configs.length != 0) {
/* 125 */         String value = configs[0].getAttribute("isConfigurable");
/* 126 */         setConfigurable((value != null && value.equalsIgnoreCase(Boolean.TRUE.toString())));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 133 */     if (this == object)
/* 134 */       return true; 
/* 135 */     if (!(object instanceof BuildCommand))
/* 136 */       return false; 
/* 137 */     BuildCommand command = (BuildCommand)object;
/*     */     
/* 139 */     return (getBuilderName().equals(command.getBuilderName()) && getArguments(false).equals(command.getArguments(false)) && (this.triggers & 0xF) == (command.triggers & 0xF));
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getArguments() {
/* 144 */     return getArguments(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getArguments(boolean makeCopy) {
/* 149 */     return (this.arguments == null) ? null : (makeCopy ? (Map<String, String>)this.arguments.clone() : this.arguments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getBuilders() {
/* 158 */     synchronized (this.builderLock) {
/* 159 */       if (supportsConfigs()) {
/* 160 */         return (this.builders == null) ? null : new HashMap<>(this.builders);
/*     */       }
/* 162 */       return this.builder;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IncrementalProjectBuilder getBuilder(IBuildConfiguration config) {
/* 175 */     synchronized (this.builderLock) {
/* 176 */       if (this.builders != null && supportsConfigs())
/* 177 */         return this.builders.get(config); 
/* 178 */       return this.builder;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getBuilderName() {
/* 184 */     return getName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 190 */     return 37 * getName().hashCode() + (0xF & this.triggers);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBuilding(int trigger) {
/* 195 */     return ((this.triggers & maskForTrigger(trigger)) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConfigurable() {
/* 200 */     if ((this.triggers & 0x20) == 0)
/* 201 */       computeIsConfigurable(); 
/* 202 */     return ((this.triggers & 0x10) != 0);
/*     */   }
/*     */   
/*     */   public boolean supportsConfigs() {
/* 206 */     if (!this.supportsConfigurationsCalculated) {
/* 207 */       IExtension extension = Platform.getExtensionRegistry().getExtension("org.eclipse.core.resources", "builders", this.name);
/* 208 */       if (extension != null) {
/* 209 */         IConfigurationElement[] configs = extension.getConfigurationElements();
/* 210 */         if (configs.length != 0) {
/* 211 */           String value = configs[0].getAttribute("supportsConfigurations");
/* 212 */           this.supportsConfigurations = (value != null && value.equalsIgnoreCase(Boolean.TRUE.toString()));
/*     */         } 
/*     */       } 
/* 215 */       this.supportsConfigurationsCalculated = true;
/*     */     } 
/* 217 */     return this.supportsConfigurations;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setArguments(Map<String, String> value) {
/* 223 */     this.arguments = (value == null) ? null : new HashMap<>(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuilders(Object value) {
/* 235 */     synchronized (this.builderLock) {
/* 236 */       if (value == null) {
/* 237 */         this.builder = null;
/* 238 */         this.builders = null;
/*     */       }
/* 240 */       else if (value instanceof IncrementalProjectBuilder) {
/* 241 */         this.builder = (IncrementalProjectBuilder)value;
/*     */       } else {
/* 243 */         this.builders = new HashMap<>((Map<? extends IBuildConfiguration, ? extends IncrementalProjectBuilder>)value);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addBuilder(IBuildConfiguration config, IncrementalProjectBuilder newBuilder) {
/* 261 */     synchronized (this.builderLock) {
/*     */       
/* 263 */       IncrementalProjectBuilder configBuilder = (this.builders == null) ? null : this.builders.get(config);
/* 264 */       if (configBuilder == null && this.builder == null) {
/* 265 */         if (supportsConfigs()) {
/* 266 */           if (this.builders == null)
/* 267 */             this.builders = new HashMap<>(1); 
/* 268 */           this.builders.put(config, newBuilder);
/*     */         } else {
/* 270 */           this.builder = newBuilder;
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBuilderName(String value) {
/* 278 */     setName((value == null) ? "" : value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBuilding(int trigger, boolean value) {
/* 283 */     if (!isConfigurable())
/*     */       return; 
/* 285 */     if (value) {
/* 286 */       this.triggers |= maskForTrigger(trigger);
/*     */     } else {
/* 288 */       this.triggers &= maskForTrigger(trigger) ^ 0xFFFFFFFF;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfigurable(boolean value) {
/* 298 */     this.triggers |= 0x20;
/* 299 */     if (value) {
/* 300 */       this.triggers |= 0x10;
/*     */     } else {
/* 302 */       this.triggers = 15;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 310 */     return "BuildCommand(" + getName() + ")";
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\BuildCommand.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */