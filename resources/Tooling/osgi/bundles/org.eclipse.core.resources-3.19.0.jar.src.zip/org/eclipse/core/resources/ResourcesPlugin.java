/*     */ package org.eclipse.core.resources;
/*     */ 
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.internal.resources.Workspace;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Plugin;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.service.datalocation.Location;
/*     */ import org.eclipse.osgi.service.debug.DebugOptionsListener;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceReference;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ import org.osgi.util.tracker.ServiceTracker;
/*     */ import org.osgi.util.tracker.ServiceTrackerCustomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourcesPlugin
/*     */   extends Plugin
/*     */ {
/*     */   public static final String PI_RESOURCES = "org.eclipse.core.resources";
/*     */   public static final String PT_BUILDERS = "builders";
/*     */   public static final String PT_NATURES = "natures";
/*     */   public static final String PT_MARKERS = "markers";
/*     */   public static final String PT_FILE_MODIFICATION_VALIDATOR = "fileModificationValidator";
/*     */   public static final String PT_MOVE_DELETE_HOOK = "moveDeleteHook";
/*     */   public static final String PT_TEAM_HOOK = "teamHook";
/*     */   public static final String PT_REFRESH_PROVIDERS = "refreshProviders";
/*     */   public static final String PT_MODEL_PROVIDERS = "modelProviders";
/*     */   public static final String PT_VARIABLE_PROVIDERS = "variableResolvers";
/*     */   public static final String PT_FILTER_MATCHERS = "filterMatchers";
/* 140 */   public static final Object FAMILY_AUTO_BUILD = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   public static final Object FAMILY_AUTO_REFRESH = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   public static final Object FAMILY_MANUAL_BUILD = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   public static final Object FAMILY_MANUAL_REFRESH = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_ENCODING = "encoding";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String PREF_DESCRIPTION_PREFIX = "description.";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final String PREF_MAX_NOTIFICATION_DELAY = "maxnotifydelay";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_AUTO_BUILDING = "description.autobuilding";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_BUILD_ORDER = "description.buildorder";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_DEFAULT_BUILD_ORDER = "description.defaultbuildorder";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_MAX_BUILD_ITERATIONS = "description.maxbuilditerations";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_APPLY_FILE_STATE_POLICY = "description.applyfilestatepolicy";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_FILE_STATE_LONGEVITY = "description.filestatelongevity";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_MAX_FILE_STATE_SIZE = "description.maxfilestatesize";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_KEEP_DERIVED_STATE = "description.keepDerivedState";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_MAX_FILE_STATES = "description.maxfilestates";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_SNAPSHOT_INTERVAL = "description.snapshotinterval";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_DISABLE_LINKING = "description.disableLinking";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_AUTO_REFRESH = "refresh.enabled";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_LIGHTWEIGHT_AUTO_REFRESH = "refresh.lightweight.enabled";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_SEPARATE_DERIVED_ENCODINGS = "separateDerivedEncodings";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean DEFAULT_PREF_SEPARATE_DERIVED_ENCODINGS = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_MISSING_NATURE_MARKER_SEVERITY = "missingNatureMarkerSeverity";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_MISSING_ENCODING_MARKER_SEVERITY = "missingEncodingMarkerSeverity";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PREF_MAX_CONCURRENT_BUILDS = "maxConcurrentBuilds";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static volatile ResourcesPlugin plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ServiceRegistration<DebugOptionsListener> debugRegistration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ServiceTracker<Location, Workspace> instanceLocationTracker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkspaceInitCustomizer workspaceInitCustomizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String systemEncoding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getEncoding() {
/* 422 */     ResourcesPlugin resourcesPlugin = plugin;
/* 423 */     if (resourcesPlugin == null) {
/* 424 */       return getSystemEncoding();
/*     */     }
/* 426 */     Workspace workspace = resourcesPlugin.workspaceInitCustomizer.workspace;
/* 427 */     if (workspace == null) {
/* 428 */       return getSystemEncoding();
/*     */     }
/*     */     try {
/* 431 */       String enc = workspace.getRoot().getDefaultCharset(false);
/* 432 */       if (enc == null) {
/* 433 */         return getSystemEncoding();
/*     */       }
/* 435 */       return enc;
/* 436 */     } catch (CoreException coreException) {
/*     */       
/* 438 */       return getSystemEncoding();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getSystemEncoding() {
/* 452 */     if (systemEncoding == null) {
/* 453 */       String encoding = null;
/*     */       
/* 455 */       List<String> commandLineArgs = ManagementFactory.getRuntimeMXBean().getInputArguments();
/* 456 */       for (String arg : commandLineArgs) {
/* 457 */         if (arg.startsWith("-Dfile.encoding=")) {
/* 458 */           encoding = arg.substring("-Dfile.encoding=".length());
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 464 */       if (encoding == null || encoding.isBlank()) {
/* 465 */         encoding = Platform.getSystemCharset().name();
/*     */       }
/* 467 */       systemEncoding = encoding;
/*     */     } 
/* 469 */     return systemEncoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ResourcesPlugin getPlugin() {
/* 478 */     return plugin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IWorkspace getWorkspace() {
/* 494 */     ResourcesPlugin resourcesPlugin = plugin;
/* 495 */     if (resourcesPlugin == null)
/*     */     {
/*     */       
/* 498 */       throw new IllegalStateException(Messages.resources_workspaceClosedStatic);
/*     */     }
/* 500 */     Workspace workspace = resourcesPlugin.workspaceInitCustomizer.workspace;
/* 501 */     if (workspace == null) {
/* 502 */       throw new IllegalStateException(Messages.resources_workspaceClosedStatic);
/*     */     }
/* 504 */     return (IWorkspace)workspace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop(BundleContext context) throws Exception {
/* 514 */     super.stop(context);
/*     */ 
/*     */     
/* 517 */     this.debugRegistration.unregister();
/* 518 */     this.instanceLocationTracker.close();
/*     */ 
/*     */     
/* 521 */     getPlugin().savePluginPreferences();
/* 522 */     plugin = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(BundleContext context) throws Exception {
/* 532 */     super.start(context);
/* 533 */     this.workspaceInitCustomizer = new WorkspaceInitCustomizer(context);
/*     */     
/* 535 */     Hashtable<String, String> properties = new Hashtable<>(2);
/* 536 */     properties.put("listener.symbolic.name", "org.eclipse.core.resources");
/* 537 */     this.debugRegistration = context.registerService(DebugOptionsListener.class, Policy.RESOURCES_DEBUG_OPTIONS_LISTENER, 
/* 538 */         properties);
/* 539 */     this.instanceLocationTracker = new ServiceTracker(context, 
/* 540 */         context.createFilter(String.format("(&%s(%s=*))", new Object[] { Location.INSTANCE_FILTER, 
/* 541 */               "url"
/* 542 */             })), this.workspaceInitCustomizer);
/* 543 */     plugin = this;
/*     */     
/* 545 */     this.instanceLocationTracker.open();
/*     */   }
/*     */   
/*     */   private final class WorkspaceInitCustomizer implements ServiceTrackerCustomizer<Location, Workspace> {
/*     */     private final BundleContext context;
/*     */     private volatile Workspace workspace;
/*     */     private ServiceRegistration<IWorkspace> workspaceRegistration;
/*     */     
/*     */     private WorkspaceInitCustomizer(BundleContext context) {
/* 554 */       this.context = context;
/*     */     }
/*     */ 
/*     */     
/*     */     public Workspace addingService(ServiceReference<Location> reference) {
/* 559 */       if (this.workspace != null) {
/* 560 */         return null;
/*     */       }
/* 562 */       Location location = (Location)this.context.getService(reference);
/* 563 */       if (location == null) {
/* 564 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 568 */       this.workspace = new Workspace();
/*     */       
/*     */       try {
/* 571 */         IStatus result = this.workspace.open(null);
/* 572 */         if (!result.isOK())
/* 573 */           ResourcesPlugin.this.getLog().log(result); 
/* 574 */         this.workspaceRegistration = this.context.registerService(IWorkspace.class, this.workspace, null);
/* 575 */         return this.workspace;
/* 576 */       } catch (CoreException e) {
/* 577 */         ResourcesPlugin.this.getLog().log(e.getStatus());
/* 578 */       } catch (IllegalStateException e) {
/* 579 */         ResourcesPlugin.this.getLog().log(Status.error("Internal error open workspace", e));
/*     */       } 
/* 581 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void modifiedService(ServiceReference<Location> reference, Workspace service) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void removedService(ServiceReference<Location> reference, Workspace service) {
/* 592 */       if (service == this.workspace) {
/*     */         try {
/* 594 */           this.workspaceRegistration.unregister();
/* 595 */         } catch (RuntimeException e) {
/* 596 */           ResourcesPlugin.this.getLog().log((IStatus)Status.warning("Unregistering workspaces throws an exception", e));
/*     */         } 
/*     */         try {
/* 599 */           service.close(null);
/* 600 */         } catch (CoreException e) {
/* 601 */           ResourcesPlugin.this.getLog().log(e.getStatus());
/*     */         } finally {
/* 603 */           this.workspace = null;
/* 604 */           this.context.ungetService(reference);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\ResourcesPlugin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */