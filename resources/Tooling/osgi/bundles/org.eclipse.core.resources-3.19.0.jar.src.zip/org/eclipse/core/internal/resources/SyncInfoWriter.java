/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.internal.utils.ObjectMap;
/*     */ import org.eclipse.core.internal.watson.IPathRequestor;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncInfoWriter
/*     */ {
/*     */   protected Synchronizer synchronizer;
/*     */   protected Workspace workspace;
/*     */   public static final int SYNCINFO_SAVE_VERSION = 3;
/*     */   public static final int SYNCINFO_SNAP_VERSION = 3;
/*     */   public static final byte INDEX = 1;
/*     */   public static final byte QNAME = 2;
/*     */   
/*     */   public SyncInfoWriter(Workspace workspace, Synchronizer synchronizer) {
/*  37 */     this.workspace = workspace;
/*  38 */     this.synchronizer = synchronizer;
/*     */   }
/*     */   
/*     */   public void savePartners(DataOutputStream output) throws IOException {
/*  42 */     Set<QualifiedName> registry = this.synchronizer.getRegistry();
/*  43 */     output.writeInt(registry.size());
/*  44 */     for (QualifiedName qname : registry) {
/*  45 */       output.writeUTF(qname.getQualifier());
/*  46 */       output.writeUTF(qname.getLocalName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void saveSyncInfo(ResourceInfo info, IPathRequestor requestor, DataOutputStream output, List<QualifiedName> writtenPartners) throws IOException {
/*  65 */     ObjectMap<QualifiedName, Object> objectMap = info.getSyncInfo(false);
/*  66 */     if (objectMap == null) {
/*     */       return;
/*     */     }
/*     */     
/*  70 */     if (output.size() == 0)
/*  71 */       output.writeInt(3); 
/*  72 */     output.writeUTF(requestor.requestPath().toString());
/*  73 */     output.writeInt(objectMap.size());
/*  74 */     for (Map.Entry<QualifiedName, Object> entry : objectMap.entrySet()) {
/*  75 */       QualifiedName name = entry.getKey();
/*     */ 
/*     */       
/*  78 */       int index = writtenPartners.indexOf(name);
/*  79 */       if (index == -1) {
/*     */         
/*  81 */         output.writeByte(2);
/*  82 */         output.writeUTF(name.getQualifier());
/*  83 */         output.writeUTF(name.getLocalName());
/*  84 */         writtenPartners.add(name);
/*     */       } else {
/*  86 */         output.writeByte(1);
/*  87 */         output.writeInt(index);
/*     */       } 
/*  89 */       byte[] bytes = (byte[])entry.getValue();
/*  90 */       output.writeInt(bytes.length);
/*  91 */       output.write(bytes);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void snapSyncInfo(ResourceInfo info, IPathRequestor requestor, DataOutputStream output) throws IOException {
/* 108 */     if (!info.isSet(8192))
/*     */       return; 
/* 110 */     ObjectMap<QualifiedName, Object> objectMap = info.getSyncInfo(false);
/* 111 */     if (objectMap == null) {
/*     */       return;
/*     */     }
/* 114 */     output.writeInt(3);
/* 115 */     output.writeUTF(requestor.requestPath().toString());
/* 116 */     output.writeInt(objectMap.size());
/* 117 */     for (Map.Entry<QualifiedName, Object> entry : objectMap.entrySet()) {
/* 118 */       QualifiedName name = entry.getKey();
/* 119 */       output.writeUTF(name.getQualifier());
/* 120 */       output.writeUTF(name.getLocalName());
/* 121 */       byte[] bytes = (byte[])entry.getValue();
/* 122 */       output.writeInt(bytes.length);
/* 123 */       output.write(bytes);
/*     */     } 
/* 125 */     info.clear(8192);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\SyncInfoWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */