/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.internal.watson.ElementTree;
/*     */ import org.eclipse.core.internal.watson.ElementTreeIterator;
/*     */ import org.eclipse.core.internal.watson.IElementContentVisitor;
/*     */ import org.eclipse.core.internal.watson.IPathRequestor;
/*     */ import org.eclipse.core.resources.IMarker;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceVisitor;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarkerManager
/*     */   implements IManager
/*     */ {
/*  36 */   private static final MarkerInfo[] NO_MARKER_INFO = new MarkerInfo[0];
/*  37 */   private static final IMarker[] NO_MARKERS = new IMarker[0];
/*  38 */   protected MarkerTypeDefinitionCache cache = new MarkerTypeDefinitionCache();
/*  39 */   private final AtomicLong changeId = new AtomicLong();
/*  40 */   protected volatile Map<IPath, MarkerSet> currentDeltas = null;
/*  41 */   protected final MarkerDeltaManager deltaManager = new MarkerDeltaManager();
/*     */   
/*     */   protected final Workspace workspace;
/*  44 */   protected final MarkerWriter writer = new MarkerWriter(this);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerManager(Workspace workspace) {
/*  50 */     this.workspace = workspace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(IResource resource, MarkerInfo newMarker) throws CoreException {
/*  59 */     Resource target = (Resource)resource;
/*  60 */     ResourceInfo info = this.workspace.getResourceInfo(target.getFullPath(), false, false);
/*  61 */     target.checkExists(target.getFlags(info), false);
/*  62 */     info = this.workspace.getResourceInfo(resource.getFullPath(), false, true);
/*     */     
/*  64 */     if (info == null) {
/*     */       return;
/*     */     }
/*     */     
/*  68 */     if (isPersistent(newMarker)) {
/*  69 */       info.set(4096);
/*     */     }
/*  71 */     MarkerSet markers = info.getMarkers(true);
/*  72 */     if (markers == null)
/*  73 */       markers = new MarkerSet(1); 
/*  74 */     basicAdd(resource, markers, newMarker);
/*  75 */     if (!markers.isEmpty()) {
/*  76 */       info.setMarkers(markers);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void basicAdd(IResource resource, MarkerSet markers, MarkerInfo newMarker) {
/*  85 */     markers.add(newMarker);
/*  86 */     IMarkerSetElement[] changes = new IMarkerSetElement[1];
/*  87 */     changes[0] = new MarkerDelta(1, resource, newMarker);
/*  88 */     changedMarkers(resource, changes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MarkerInfo[] basicFindMatching(MarkerSet markers, String type, boolean includeSubtypes) {
/*  95 */     int size = markers.size();
/*  96 */     if (size <= 0)
/*  97 */       return NO_MARKER_INFO; 
/*  98 */     List<MarkerInfo> result = new ArrayList<>(size);
/*  99 */     IMarkerSetElement[] elements = markers.elements(); byte b; int i; IMarkerSetElement[] arrayOfIMarkerSetElement1;
/* 100 */     for (i = (arrayOfIMarkerSetElement1 = elements).length, b = 0; b < i; ) { IMarkerSetElement element = arrayOfIMarkerSetElement1[b];
/* 101 */       MarkerInfo marker = (MarkerInfo)element;
/*     */       
/* 103 */       if (type == null) {
/* 104 */         result.add(marker);
/*     */       }
/* 106 */       else if (includeSubtypes) {
/* 107 */         if (this.cache.isSubtype(marker.getType(), type)) {
/* 108 */           result.add(marker);
/*     */         }
/* 110 */       } else if (marker.getType().equals(type)) {
/* 111 */         result.add(marker);
/*     */       } 
/*     */       b++; }
/*     */     
/* 115 */     size = result.size();
/* 116 */     if (size <= 0)
/* 117 */       return NO_MARKER_INFO; 
/* 118 */     return result.<MarkerInfo>toArray(new MarkerInfo[size]);
/*     */   }
/*     */   
/*     */   protected int basicFindMaxSeverity(MarkerSet markers, String type, boolean includeSubtypes) {
/* 122 */     int max = -1;
/* 123 */     int size = markers.size();
/* 124 */     if (size <= 0)
/* 125 */       return max; 
/* 126 */     IMarkerSetElement[] elements = markers.elements(); byte b; int i; IMarkerSetElement[] arrayOfIMarkerSetElement1;
/* 127 */     for (i = (arrayOfIMarkerSetElement1 = elements).length, b = 0; b < i; ) { IMarkerSetElement element = arrayOfIMarkerSetElement1[b];
/* 128 */       MarkerInfo marker = (MarkerInfo)element;
/*     */       
/* 130 */       if (type == null) {
/* 131 */         max = Math.max(max, getSeverity(marker));
/*     */       }
/* 133 */       else if (includeSubtypes) {
/* 134 */         if (this.cache.isSubtype(marker.getType(), type)) {
/* 135 */           max = Math.max(max, getSeverity(marker));
/*     */         }
/* 137 */       } else if (marker.getType().equals(type)) {
/* 138 */         max = Math.max(max, getSeverity(marker));
/*     */       } 
/*     */       
/* 141 */       if (max >= 2)
/*     */         break; 
/*     */       b++; }
/*     */     
/* 145 */     return max;
/*     */   }
/*     */   
/*     */   private int getSeverity(MarkerInfo marker) {
/* 149 */     Object o = marker.getAttribute("severity");
/* 150 */     if (o instanceof Integer) {
/* 151 */       Integer i = (Integer)o;
/* 152 */       return i.intValue();
/*     */     } 
/* 154 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void basicRemoveMarkers(ResourceInfo info, IPathRequestor requestor, String type, boolean includeSubtypes) {
/*     */     MarkerInfo[] arrayOfMarkerInfo;
/*     */     IPath path;
/* 164 */     MarkerSet markers = info.getMarkers(false);
/* 165 */     if (markers == null) {
/*     */       return;
/*     */     }
/*     */     
/* 169 */     if (type == null) {
/*     */ 
/*     */       
/* 172 */       path = requestor.requestPath();
/* 173 */       info = this.workspace.getResourceInfo(path, false, true);
/* 174 */       info.setMarkers(null);
/* 175 */       IMarkerSetElement[] matching = markers.elements();
/*     */     } else {
/* 177 */       arrayOfMarkerInfo = basicFindMatching(markers, type, includeSubtypes);
/*     */       
/* 179 */       if (arrayOfMarkerInfo.length == 0) {
/*     */         return;
/*     */       }
/* 182 */       path = requestor.requestPath();
/* 183 */       info = this.workspace.getResourceInfo(path, false, true);
/*     */       
/* 185 */       markers = info.getMarkers(true);
/*     */ 
/*     */       
/* 188 */       if (markers.size() == arrayOfMarkerInfo.length) {
/* 189 */         info.setMarkers(null);
/*     */       } else {
/* 191 */         markers.removeAll((IMarkerSetElement[])arrayOfMarkerInfo);
/* 192 */         info.setMarkers(markers);
/*     */       } 
/*     */     } 
/* 195 */     info.set(4096);
/* 196 */     IMarkerSetElement[] changes = new IMarkerSetElement[arrayOfMarkerInfo.length];
/* 197 */     IResource resource = this.workspace.getRoot().findMember(path);
/* 198 */     for (int i = 0; i < arrayOfMarkerInfo.length; i++)
/* 199 */       changes[i] = new MarkerDelta(2, resource, arrayOfMarkerInfo[i]); 
/* 200 */     changedMarkers(resource, changes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void buildMarkers(IMarkerSetElement[] markers, IPath path, int type, ArrayList<IMarker> list) {
/* 209 */     if (markers.length == 0)
/*     */       return; 
/* 211 */     IResource resource = this.workspace.newResource(path, type);
/* 212 */     list.ensureCapacity(list.size() + markers.length); byte b; int i; IMarkerSetElement[] arrayOfIMarkerSetElement;
/* 213 */     for (i = (arrayOfIMarkerSetElement = markers).length, b = 0; b < i; ) { IMarkerSetElement marker = arrayOfIMarkerSetElement[b];
/* 214 */       list.add(new Marker(resource, ((MarkerInfo)marker).getId()));
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void changedMarkers(IResource resource, IMarkerSetElement[] changes) {
/* 223 */     if (changes == null || changes.length == 0)
/*     */       return; 
/* 225 */     long change = this.changeId.incrementAndGet();
/* 226 */     if (this.currentDeltas == null)
/* 227 */       this.currentDeltas = this.deltaManager.newGeneration(change); 
/* 228 */     IPath path = resource.getFullPath();
/* 229 */     MarkerSet previousChanges = this.currentDeltas.get(path);
/* 230 */     MarkerSet result = MarkerDelta.merge(previousChanges, changes);
/* 231 */     if (result.size() == 0) {
/* 232 */       this.currentDeltas.remove(path);
/*     */     } else {
/* 234 */       this.currentDeltas.put(path, result);
/* 235 */     }  ResourceInfo info = this.workspace.getResourceInfo(path, false, true);
/* 236 */     if (info != null) {
/* 237 */       info.incrementMarkerGenerationCount();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IMarker findMarker(IResource resource, long id) {
/* 244 */     MarkerInfo info = findMarkerInfo(resource, id);
/* 245 */     return (info == null) ? null : new Marker(resource, info.getId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerInfo findMarkerInfo(IResource resource, long id) {
/* 252 */     ResourceInfo info = this.workspace.getResourceInfo(resource.getFullPath(), false, false);
/* 253 */     if (info == null)
/* 254 */       return null; 
/* 255 */     MarkerSet markers = info.getMarkers(false);
/* 256 */     if (markers == null)
/* 257 */       return null; 
/* 258 */     return (MarkerInfo)markers.get(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMarker[] findMarkers(IResource target, String type, boolean includeSubtypes, int depth) {
/* 267 */     ArrayList<IMarker> result = new ArrayList<>();
/* 268 */     doFindMarkers(target, result, type, includeSubtypes, depth);
/* 269 */     if (result.isEmpty())
/* 270 */       return NO_MARKERS; 
/* 271 */     return result.<IMarker>toArray(new IMarker[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doFindMarkers(IResource target, ArrayList<IMarker> result, String type, boolean includeSubtypes, int depth) {
/* 283 */     if (depth == 2 && target.getType() != 1) {
/* 284 */       visitorFindMarkers(target.getFullPath(), result, type, includeSubtypes);
/*     */     } else {
/* 286 */       recursiveFindMarkers(target.getFullPath(), result, type, includeSubtypes, depth);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int findMaxProblemSeverity(IResource target, String type, boolean includeSubtypes, int depth) {
/* 295 */     if (depth == 2 && target.getType() != 1)
/* 296 */       return visitorFindMaxSeverity(target.getFullPath(), type, includeSubtypes); 
/* 297 */     return recursiveFindMaxSeverity(target.getFullPath(), type, includeSubtypes, depth);
/*     */   }
/*     */   
/*     */   public long getChangeId() {
/* 301 */     return this.changeId.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<IPath, MarkerSet> getMarkerDeltas(long startChangeId) {
/* 308 */     return this.deltaManager.assembleDeltas(startChangeId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasDelta(IPath path, long id) {
/* 316 */     if (this.currentDeltas == null)
/* 317 */       return false; 
/* 318 */     MarkerSet set = this.currentDeltas.get(path);
/* 319 */     if (set == null)
/* 320 */       return false; 
/* 321 */     return (set.get(id) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPersistent(MarkerInfo info) {
/* 328 */     if (!this.cache.isPersistent(info.getType()))
/* 329 */       return false; 
/* 330 */     Object isTransient = info.getAttribute("transient");
/* 331 */     return !(isTransient != null && isTransient instanceof Boolean && ((Boolean)isTransient).booleanValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPersistentType(String type) {
/* 338 */     return this.cache.isPersistent(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSubtype(String type, String superType) {
/* 345 */     return this.cache.isSubtype(type, superType);
/*     */   }
/*     */   
/*     */   public void moved(IResource source, IResource destination, int depth) throws CoreException {
/* 349 */     int count = destination.getFullPath().segmentCount();
/*     */ 
/*     */     
/* 352 */     IResourceVisitor visitor = resource -> {
/*     */         Resource r = (Resource)resource;
/*     */         
/*     */         ResourceInfo info = r.getResourceInfo(false, true);
/*     */         MarkerSet markers = info.getMarkers(false);
/*     */         if (markers == null) {
/*     */           return true;
/*     */         }
/*     */         info.set(4096);
/*     */         IMarkerSetElement[] removed = new IMarkerSetElement[markers.size()];
/*     */         IMarkerSetElement[] added = new IMarkerSetElement[markers.size()];
/*     */         IPath path = resource.getFullPath().removeFirstSegments(paramInt);
/*     */         path = paramIResource1.getFullPath().append(path);
/*     */         IResource sourceChild = this.workspace.newResource(path, resource.getType());
/*     */         IMarkerSetElement[] elements = markers.elements();
/*     */         for (int i = 0; i < elements.length; i++) {
/*     */           MarkerInfo markerInfo = (MarkerInfo)elements[i];
/*     */           MarkerDelta delta = new MarkerDelta(1, resource, markerInfo);
/*     */           added[i] = delta;
/*     */           delta = new MarkerDelta(2, sourceChild, markerInfo);
/*     */           removed[i] = delta;
/*     */         } 
/*     */         changedMarkers(resource, added);
/*     */         changedMarkers(sourceChild, removed);
/*     */         return true;
/*     */       };
/* 378 */     destination.accept(visitor, depth, 10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void recursiveFindMarkers(IPath path, ArrayList<IMarker> list, String type, boolean includeSubtypes, int depth) {
/* 386 */     ResourceInfo info = this.workspace.getResourceInfo(path, false, false);
/* 387 */     if (info == null)
/*     */       return; 
/* 389 */     MarkerSet markers = info.getMarkers(false);
/*     */ 
/*     */     
/* 392 */     if (markers != null) {
/*     */       MarkerInfo[] arrayOfMarkerInfo;
/* 394 */       if (type == null) {
/* 395 */         IMarkerSetElement[] matching = markers.elements();
/*     */       } else {
/* 397 */         arrayOfMarkerInfo = basicFindMatching(markers, type, includeSubtypes);
/* 398 */       }  buildMarkers((IMarkerSetElement[])arrayOfMarkerInfo, path, info.getType(), list);
/*     */     } 
/*     */ 
/*     */     
/* 402 */     if (depth == 0 || info.getType() == 1)
/*     */       return; 
/* 404 */     if (depth == 1)
/* 405 */       depth = 0;  byte b; int i; IPath[] arrayOfIPath;
/* 406 */     for (i = (arrayOfIPath = this.workspace.getElementTree().getChildren(path)).length, b = 0; b < i; ) { IPath child = arrayOfIPath[b];
/* 407 */       recursiveFindMarkers(child, list, type, includeSubtypes, depth);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int recursiveFindMaxSeverity(IPath path, String type, boolean includeSubtypes, int depth) {
/* 415 */     ResourceInfo info = this.workspace.getResourceInfo(path, false, false);
/* 416 */     if (info == null)
/* 417 */       return -1; 
/* 418 */     MarkerSet markers = info.getMarkers(false);
/*     */ 
/*     */     
/* 421 */     int max = -1;
/* 422 */     if (markers != null) {
/* 423 */       max = basicFindMaxSeverity(markers, type, includeSubtypes);
/* 424 */       if (max >= 2) {
/* 425 */         return max;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 430 */     if (depth == 0 || info.getType() == 1)
/* 431 */       return max; 
/* 432 */     if (depth == 1)
/* 433 */       depth = 0;  byte b; int i; IPath[] arrayOfIPath;
/* 434 */     for (i = (arrayOfIPath = this.workspace.getElementTree().getChildren(path)).length, b = 0; b < i; ) { IPath child = arrayOfIPath[b];
/* 435 */       max = Math.max(max, recursiveFindMaxSeverity(child, type, includeSubtypes, depth));
/* 436 */       if (max >= 2)
/*     */         break; 
/*     */       b++; }
/*     */     
/* 440 */     return max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void recursiveRemoveMarkers(final IPath path, String type, boolean includeSubtypes, int depth) {
/* 447 */     ResourceInfo info = this.workspace.getResourceInfo(path, false, false);
/* 448 */     if (info == null)
/*     */       return; 
/* 450 */     IPathRequestor requestor = new IPathRequestor()
/*     */       {
/*     */         public String requestName() {
/* 453 */           return path.lastSegment();
/*     */         }
/*     */ 
/*     */         
/*     */         public IPath requestPath() {
/* 458 */           return path;
/*     */         }
/*     */       };
/* 461 */     basicRemoveMarkers(info, requestor, type, includeSubtypes);
/*     */     
/* 463 */     if (depth == 0 || info.getType() == 1)
/*     */       return; 
/* 465 */     if (depth == 1)
/* 466 */       depth = 0;  byte b; int i; IPath[] arrayOfIPath;
/* 467 */     for (i = (arrayOfIPath = this.workspace.getElementTree().getChildren(path)).length, b = 0; b < i; ) { IPath child = arrayOfIPath[b];
/* 468 */       recursiveRemoveMarkers(child, type, includeSubtypes, depth);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeMarker(IResource resource, long id) {
/* 476 */     MarkerInfo markerInfo = findMarkerInfo(resource, id);
/* 477 */     if (markerInfo == null)
/*     */       return; 
/* 479 */     ResourceInfo info = ((Workspace)resource.getWorkspace()).getResourceInfo(resource.getFullPath(), false, true);
/*     */     
/* 481 */     MarkerSet markers = info.getMarkers(true);
/* 482 */     int size = markers.size();
/* 483 */     markers.remove(markerInfo);
/*     */     
/* 485 */     info.setMarkers((markers.size() == 0) ? null : markers);
/*     */     
/* 487 */     if (markers.size() != size) {
/* 488 */       if (isPersistent(markerInfo))
/* 489 */         info.set(4096); 
/* 490 */       IMarkerSetElement[] change = {
/* 491 */           new MarkerDelta(2, resource, markerInfo) };
/* 492 */       changedMarkers(resource, change);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeMarkers(IResource resource, int depth) {
/* 500 */     removeMarkers(resource, null, false, depth);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeMarkers(IResource target, String type, boolean includeSubtypes, int depth) {
/* 509 */     if (depth == 2 && target.getType() != 1) {
/* 510 */       visitorRemoveMarkers(target.getFullPath(), type, includeSubtypes);
/*     */     } else {
/* 512 */       recursiveRemoveMarkers(target.getFullPath(), type, includeSubtypes, depth);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void resetMarkerDeltas(long startId) {
/* 519 */     this.currentDeltas = null;
/* 520 */     this.deltaManager.resetDeltas(startId);
/*     */   }
/*     */ 
/*     */   
/*     */   public void restore(IResource resource, boolean generateDeltas, IProgressMonitor monitor) throws CoreException {
/* 525 */     restoreFromSave(resource, generateDeltas);
/* 526 */     restoreFromSnap(resource);
/*     */   }
/*     */   
/*     */   protected void restoreFromSave(IResource resource, boolean generateDeltas) throws CoreException {
/* 530 */     IPath sourceLocation = this.workspace.getMetaArea().getMarkersLocationFor(resource);
/* 531 */     IPath tempLocation = this.workspace.getMetaArea().getBackupLocationFor(sourceLocation);
/* 532 */     File sourceFile = new File(sourceLocation.toOSString());
/* 533 */     File tempFile = new File(tempLocation.toOSString());
/* 534 */     if (!sourceFile.exists() && !tempFile.exists())
/*     */       return;  try {
/* 536 */       Exception exception2, exception1 = null;
/*     */ 
/*     */     
/*     */     }
/* 540 */     catch (Exception e) {
/*     */       
/* 542 */       String msg = NLS.bind(Messages.resources_readMeta, sourceLocation);
/* 543 */       throw new ResourceException(567, sourceLocation, msg, e);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void restoreFromSnap(IResource resource) {
/* 548 */     IPath sourceLocation = this.workspace.getMetaArea().getMarkersSnapshotLocationFor(resource);
/* 549 */     if (!sourceLocation.toFile().exists())
/*     */       return;  
/* 551 */     try { Exception exception1 = null, exception2 = null;
/*     */       
/*     */       try {  }
/*     */       finally
/* 555 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (EOFException eOFException)
/*     */     {  }
/* 557 */     catch (Exception e)
/*     */     
/* 559 */     { String msg = NLS.bind(Messages.resources_readMeta, sourceLocation);
/* 560 */       Policy.log((IStatus)new ResourceStatus(567, sourceLocation, msg, e)); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void save(ResourceInfo info, IPathRequestor requestor, DataOutputStream output, List<String> list) throws IOException {
/* 566 */     this.writer.save(info, requestor, output, list);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown(IProgressMonitor monitor) {}
/*     */ 
/*     */   
/*     */   public void snap(ResourceInfo info, IPathRequestor requestor, DataOutputStream output) throws IOException {
/* 575 */     this.writer.snap(info, requestor, output);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startup(IProgressMonitor monitor) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void visitorFindMarkers(IPath path, ArrayList<IMarker> list, String type, boolean includeSubtypes) {
/* 588 */     IElementContentVisitor visitor = (tree, requestor, elementContents) -> {
/*     */         ResourceInfo info = (ResourceInfo)elementContents;
/*     */         if (info == null) {
/*     */           return false;
/*     */         }
/*     */         MarkerSet markers = info.getMarkers(false);
/*     */         if (markers != null) {
/*     */           MarkerInfo[] arrayOfMarkerInfo;
/*     */           if (paramString == null) {
/*     */             IMarkerSetElement[] matching = markers.elements();
/*     */           } else {
/*     */             arrayOfMarkerInfo = basicFindMatching(markers, paramString, paramBoolean);
/*     */           } 
/*     */           buildMarkers((IMarkerSetElement[])arrayOfMarkerInfo, requestor.requestPath(), info.getType(), paramArrayList);
/*     */         } 
/*     */         return true;
/*     */       };
/* 605 */     (new ElementTreeIterator(this.workspace.getElementTree(), path)).iterate(visitor);
/*     */   }
/*     */   
/*     */   private int visitorFindMaxSeverity(IPath path, final String type, final boolean includeSubtypes) {
/*     */     class MaxSeverityVisitor implements IElementContentVisitor {
/*     */       int max;
/*     */       
/*     */       MaxSeverityVisitor() {
/* 613 */         this.max = -1;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean visitElement(ElementTree tree, IPathRequestor requestor, Object elementContents) {
/* 618 */         if (this.max >= 2) {
/* 619 */           return false;
/*     */         }
/* 621 */         ResourceInfo info = (ResourceInfo)elementContents;
/* 622 */         if (info == null)
/* 623 */           return false; 
/* 624 */         MarkerSet markers = info.getMarkers(false);
/*     */ 
/*     */         
/* 627 */         if (markers != null) {
/* 628 */           this.max = Math.max(this.max, MarkerManager.this.basicFindMaxSeverity(markers, type, includeSubtypes));
/*     */         }
/* 630 */         return (this.max < 2);
/*     */       }
/*     */     };
/* 633 */     MaxSeverityVisitor visitor = new MaxSeverityVisitor();
/* 634 */     (new ElementTreeIterator(this.workspace.getElementTree(), path)).iterate(visitor);
/* 635 */     return visitor.max;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void visitorRemoveMarkers(IPath path, String type, boolean includeSubtypes) {
/* 642 */     IElementContentVisitor visitor = (tree, requestor, elementContents) -> {
/*     */         ResourceInfo info = (ResourceInfo)elementContents;
/*     */         if (info == null)
/*     */           return false; 
/*     */         basicRemoveMarkers(info, requestor, paramString, paramBoolean);
/*     */         return true;
/*     */       };
/* 649 */     (new ElementTreeIterator(this.workspace.getElementTree(), path)).iterate(visitor);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\MarkerManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */