/*    */ package org.eclipse.core.internal.utils;
/*    */ 
/*    */ import org.eclipse.osgi.service.debug.DebugOptions;
/*    */ import org.eclipse.osgi.service.debug.DebugOptionsListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements DebugOptionsListener
/*    */ {
/*    */   public void optionsChanged(DebugOptions options) {
/* 30 */     Policy.DEBUG_TRACE = options.newDebugTrace("org.eclipse.core.resources");
/* 31 */     Policy.DEBUG = options.getBooleanOption("org.eclipse.core.resources/debug", false);
/*    */     
/* 33 */     Policy.DEBUG_AUTO_REFRESH = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/refresh", false));
/*    */     
/* 35 */     Policy.DEBUG_BUILD_DELTA = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/delta", false));
/* 36 */     Policy.DEBUG_BUILD_CYCLE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/cycle", false));
/* 37 */     Policy.DEBUG_BUILD_FAILURE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/failure", false));
/* 38 */     Policy.DEBUG_BUILD_INTERRUPT = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/interrupt", false));
/* 39 */     Policy.DEBUG_BUILD_INVOKING = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/invoking", false));
/* 40 */     Policy.DEBUG_BUILD_NEEDED = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/needbuild", false));
/* 41 */     Policy.DEBUG_BUILD_NEEDED_DELTA = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/needbuilddelta", false));
/* 42 */     Policy.DEBUG_BUILD_NEEDED_STACK = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/needbuildstack", false));
/* 43 */     Policy.DEBUG_BUILD_STACK = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/stacktrace", false));
/*    */     
/* 45 */     Policy.DEBUG_CONTENT_TYPE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/contenttype", false));
/* 46 */     Policy.DEBUG_CONTENT_TYPE_CACHE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/contenttype/cache", false));
/* 47 */     Policy.DEBUG_HISTORY = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/history", false));
/* 48 */     Policy.DEBUG_NATURES = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/natures", false));
/* 49 */     Policy.DEBUG_NOTIFICATIONS = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/notifications", false));
/* 50 */     Policy.DEBUG_PREFERENCES = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/preferences", false));
/*    */     
/* 52 */     Policy.DEBUG_RESTORE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/restore", false));
/* 53 */     Policy.DEBUG_RESTORE_MARKERS = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/restore/markers", false));
/* 54 */     Policy.DEBUG_RESTORE_MASTERTABLE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/restore/mastertable", false));
/* 55 */     Policy.DEBUG_RESTORE_METAINFO = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/restore/metainfo", false));
/* 56 */     Policy.DEBUG_RESTORE_SNAPSHOTS = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/restore/snapshots", false));
/* 57 */     Policy.DEBUG_RESTORE_SYNCINFO = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/restore/syncinfo", false));
/* 58 */     Policy.DEBUG_RESTORE_TREE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/restore/tree", false));
/*    */     
/* 60 */     Policy.DEBUG_SAVE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/save", false));
/* 61 */     Policy.DEBUG_SAVE_MARKERS = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/save/markers", false));
/* 62 */     Policy.DEBUG_SAVE_MASTERTABLE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/save/mastertable", false));
/* 63 */     Policy.DEBUG_SAVE_METAINFO = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/save/metainfo", false));
/* 64 */     Policy.DEBUG_SAVE_SYNCINFO = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/save/syncinfo", false));
/* 65 */     Policy.DEBUG_SAVE_TREE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/save/tree", false));
/*    */     
/* 67 */     Policy.DEBUG_STRINGS = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/strings", false));
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\interna\\utils\Policy$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */