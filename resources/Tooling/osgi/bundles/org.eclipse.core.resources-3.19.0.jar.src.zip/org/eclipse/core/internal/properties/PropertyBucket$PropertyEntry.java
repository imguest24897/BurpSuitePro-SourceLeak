/*     */ package org.eclipse.core.internal.properties;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import org.eclipse.core.internal.localstore.Bucket;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyEntry
/*     */   extends Bucket.Entry
/*     */ {
/*     */   private static final Comparator<String[]> COMPARATOR;
/*     */   
/*     */   static {
/*  29 */     COMPARATOR = ((o1, o2) -> {
/*     */         int qualifierComparison = o1[0].compareTo(o2[0]);
/*     */         return (qualifierComparison != 0) ? qualifierComparison : o1[1].compareTo(o2[1]);
/*     */       });
/*  33 */   } private static final String[][] EMPTY_DATA = new String[0][];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[][] value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String[][] delete(String[][] existing, QualifiedName propertyName) {
/*  47 */     if (existing.length == 1) {
/*  48 */       return (existing[0][0].equals(propertyName.getQualifier()) && existing[0][1].equals(propertyName.getLocalName())) ? null : existing;
/*     */     }
/*  50 */     int deletePosition = search(existing, propertyName);
/*  51 */     if (deletePosition < 0)
/*     */     {
/*  53 */       return existing; } 
/*  54 */     String[][] newValue = new String[existing.length - 1][];
/*  55 */     if (deletePosition > 0)
/*     */     {
/*  57 */       System.arraycopy(existing, 0, newValue, 0, deletePosition); } 
/*  58 */     if (deletePosition < existing.length - 1)
/*     */     {
/*  60 */       System.arraycopy(existing, deletePosition + 1, newValue, deletePosition, newValue.length - deletePosition); } 
/*  61 */     return newValue;
/*     */   }
/*     */ 
/*     */   
/*     */   static String[][] insert(String[][] existing, QualifiedName propertyName, String propertyValue) {
/*  66 */     int index = search(existing, propertyName);
/*  67 */     if (index >= 0) {
/*     */       
/*  69 */       existing[index][2] = propertyValue;
/*  70 */       return existing;
/*     */     } 
/*     */     
/*  73 */     int insertPosition = -index - 1;
/*  74 */     String[][] newValue = new String[existing.length + 1][];
/*  75 */     if (insertPosition > 0)
/*  76 */       System.arraycopy(existing, 0, newValue, 0, insertPosition); 
/*  77 */     (new String[3])[0] = propertyName.getQualifier(); (new String[3])[1] = propertyName.getLocalName(); (new String[3])[2] = propertyValue; newValue[insertPosition] = new String[3];
/*  78 */     if (insertPosition < existing.length)
/*  79 */       System.arraycopy(existing, insertPosition, newValue, insertPosition + 1, existing.length - insertPosition); 
/*  80 */     return newValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object merge(String[][] base, String[][] additions) {
/*  87 */     int additionPointer = 0;
/*  88 */     int basePointer = 0;
/*  89 */     int added = 0;
/*  90 */     String[][] result = new String[base.length + additions.length][];
/*  91 */     while (basePointer < base.length && additionPointer < additions.length) {
/*  92 */       int comparison = COMPARATOR.compare(base[basePointer], additions[additionPointer]);
/*  93 */       if (comparison == 0) {
/*  94 */         result[added++] = additions[additionPointer++];
/*     */         
/*  96 */         basePointer++; continue;
/*  97 */       }  if (comparison < 0) {
/*  98 */         result[added++] = base[basePointer++]; continue;
/*     */       } 
/* 100 */       result[added++] = additions[additionPointer++];
/*     */     } 
/*     */     
/* 103 */     String[][] remaining = (basePointer == base.length) ? additions : base;
/* 104 */     int remainingPointer = (basePointer == base.length) ? additionPointer : basePointer;
/* 105 */     int remainingCount = remaining.length - remainingPointer;
/* 106 */     System.arraycopy(remaining, remainingPointer, result, added, remainingCount);
/* 107 */     added += remainingCount;
/* 108 */     if (added == base.length + additions.length)
/*     */     {
/* 110 */       return result;
/*     */     }
/* 112 */     String[][] finalResult = new String[added][];
/* 113 */     System.arraycopy(result, 0, finalResult, 0, finalResult.length);
/* 114 */     return finalResult;
/*     */   }
/*     */   
/*     */   private static int search(String[][] existing, QualifiedName propertyName) {
/* 118 */     return Arrays.binarySearch(existing, new String[] { propertyName.getQualifier(), propertyName.getLocalName() }, (Comparator)COMPARATOR);
/*     */   }
/*     */   
/*     */   public PropertyEntry(IPath path, PropertyEntry base) {
/* 122 */     super(path);
/*     */     
/* 124 */     int xLen = base.value.length;
/* 125 */     this.value = new String[xLen][];
/* 126 */     for (int i = 0; i < xLen; i++) {
/* 127 */       int yLen = (base.value[i]).length;
/* 128 */       this.value[i] = new String[yLen];
/* 129 */       System.arraycopy(base.value[i], 0, this.value[i], 0, yLen);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PropertyEntry(IPath path, String[][] value) {
/* 139 */     super(path);
/* 140 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void compact() {
/* 148 */     if (!isDirty())
/*     */       return; 
/* 150 */     int occurrences = 0; byte b; int i; String[][] arrayOfString1;
/* 151 */     for (i = (arrayOfString1 = this.value).length, b = 0; b < i; ) { String[] s = arrayOfString1[b];
/* 152 */       if (s != null)
/* 153 */         this.value[occurrences++] = s; 
/*     */       b++; }
/*     */     
/* 156 */     if (occurrences == this.value.length) {
/*     */       return;
/*     */     }
/* 159 */     if (occurrences == 0) {
/*     */       
/* 161 */       this.value = EMPTY_DATA;
/* 162 */       delete();
/*     */       return;
/*     */     } 
/* 165 */     String[][] result = new String[occurrences][];
/* 166 */     System.arraycopy(this.value, 0, result, 0, occurrences);
/* 167 */     this.value = result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOccurrences() {
/* 172 */     return (this.value == null) ? 0 : this.value.length;
/*     */   }
/*     */   
/*     */   public String getProperty(QualifiedName name) {
/* 176 */     int index = search(this.value, name);
/* 177 */     return (index < 0) ? null : this.value[index][2];
/*     */   }
/*     */   
/*     */   public QualifiedName getPropertyName(int i) {
/* 181 */     return new QualifiedName(this.value[i][0], this.value[i][1]);
/*     */   }
/*     */   
/*     */   public String getPropertyValue(int i) {
/* 185 */     return this.value[i][2];
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getValue() {
/* 190 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public void visited() {
/* 195 */     compact();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\properties\PropertyBucket$PropertyEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */