/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import org.eclipse.core.resources.ProjectScope;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.content.IContentType;
/*    */ import org.eclipse.core.runtime.content.IContentTypeManager;
/*    */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*    */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*    */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ProjectContentTypeSelectionPolicy
/*    */   implements IContentTypeManager.ISelectionPolicy, IScopeContext
/*    */ {
/*    */   private Project project;
/*    */   private IScopeContext projectScope;
/*    */   
/*    */   public ProjectContentTypeSelectionPolicy(Project project) {
/* 52 */     this.project = project;
/* 53 */     this.projectScope = (IScopeContext)new ProjectScope(project);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 58 */     if (this == obj)
/* 59 */       return true; 
/* 60 */     if (!(obj instanceof IScopeContext))
/* 61 */       return false; 
/* 62 */     IScopeContext other = (IScopeContext)obj;
/* 63 */     if (!getName().equals(other.getName()))
/* 64 */       return false; 
/* 65 */     IPath location = getLocation();
/* 66 */     return (location == null) ? ((other.getLocation() == null)) : location.equals(other.getLocation());
/*    */   }
/*    */   
/*    */   private IScopeContext getDelegate() {
/* 70 */     if (!ProjectContentTypes.usesContentTypePreferences(this.project.getName()))
/* 71 */       return InstanceScope.INSTANCE; 
/* 72 */     return this.projectScope;
/*    */   }
/*    */ 
/*    */   
/*    */   public IPath getLocation() {
/* 77 */     return getDelegate().getLocation();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 82 */     return getDelegate().getName();
/*    */   }
/*    */ 
/*    */   
/*    */   public IEclipsePreferences getNode(String qualifier) {
/* 87 */     return getDelegate().getNode(qualifier);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 92 */     return getName().hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public IContentType[] select(IContentType[] candidates, boolean fileName, boolean content) {
/* 97 */     return ProjectContentTypes.this.select(this.project, candidates, fileName, content);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ProjectContentTypes$ProjectContentTypeSelectionPolicy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */