package org.eclipse.core.resources;

public interface IFilterMatcherDescriptor {
  public static final String ARGUMENT_TYPE_FILTER_MATCHER = "filterMatcher";
  
  public static final String ARGUMENT_TYPE_FILTER_MATCHERS = "filterMatchers";
  
  public static final String ARGUMENT_TYPE_NONE = "none";
  
  public static final String ARGUMENT_TYPE_STRING = "string";
  
  String getArgumentType();
  
  String getDescription();
  
  String getId();
  
  String getName();
  
  boolean isFirstOrdering();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IFilterMatcherDescriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */