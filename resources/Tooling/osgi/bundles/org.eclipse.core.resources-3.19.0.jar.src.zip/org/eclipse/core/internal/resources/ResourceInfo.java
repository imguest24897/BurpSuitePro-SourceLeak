/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.localstore.FileStoreRoot;
/*     */ import org.eclipse.core.internal.utils.IStringPoolParticipant;
/*     */ import org.eclipse.core.internal.utils.ObjectMap;
/*     */ import org.eclipse.core.internal.utils.StringPool;
/*     */ import org.eclipse.core.internal.watson.IElementTreeData;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceInfo
/*     */   implements IElementTreeData, ICoreConstants, IStringPoolParticipant
/*     */ {
/*     */   protected static final int LOWER = 65535;
/*     */   protected static final int UPPER = -65536;
/*     */   protected volatile int charsetAndContentId;
/*     */   protected FileStoreRoot fileStoreRoot;
/*     */   protected int flags;
/*  50 */   protected volatile long localInfo = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected volatile int markerAndSyncStamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MarkerSet markers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long modStamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected volatile long nodeId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectMap<QualifiedName, Object> sessionProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectMap<QualifiedName, Object> syncInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int getBits(int flags, int mask, int start) {
/*  97 */     return (flags & mask) >> start;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getType(int flags) {
/* 105 */     return getBits(flags, 3840, 8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSet(int flags, int mask) {
/* 112 */     return ((flags & mask) == mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear(int mask) {
/* 119 */     this.flags &= mask ^ 0xFFFFFFFF;
/*     */   }
/*     */   
/*     */   public void clearModificationStamp() {
/* 123 */     this.modStamp = -1L;
/*     */   }
/*     */   
/*     */   public void clearCharsetGenerationCount() {
/* 127 */     this.charsetAndContentId = getContentId();
/*     */   }
/*     */   
/*     */   public synchronized void clearSessionProperties() {
/* 131 */     this.sessionProperties = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/* 137 */       return super.clone();
/* 138 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/* 139 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getCharsetGenerationCount() {
/* 144 */     return this.charsetAndContentId >> 16;
/*     */   }
/*     */   
/*     */   public int getContentId() {
/* 148 */     return this.charsetAndContentId & 0xFFFF;
/*     */   }
/*     */   
/*     */   public FileStoreRoot getFileStoreRoot() {
/* 152 */     return this.fileStoreRoot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFlags() {
/* 159 */     return this.flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLocalSyncInfo() {
/* 166 */     return this.localInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMarkerGenerationCount() {
/* 174 */     return this.markerAndSyncStamp >> 16;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerSet getMarkers() {
/* 182 */     return getMarkers(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MarkerSet getMarkers(boolean makeCopy) {
/* 190 */     if (this.markers == null)
/* 191 */       return null; 
/* 192 */     return makeCopy ? (MarkerSet)this.markers.clone() : this.markers;
/*     */   }
/*     */   
/*     */   public long getModificationStamp() {
/* 196 */     return this.modStamp;
/*     */   }
/*     */   
/*     */   public long getNodeId() {
/* 200 */     return this.nodeId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getPropertyStore() {
/* 207 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<QualifiedName, Object> getSessionProperties() {
/* 217 */     ObjectMap<QualifiedName, Object> temp = this.sessionProperties;
/* 218 */     if (temp == null) {
/* 219 */       temp = new ObjectMap(5);
/*     */     } else {
/* 221 */       temp = (ObjectMap<QualifiedName, Object>)this.sessionProperties.clone();
/* 222 */     }  return (Map<QualifiedName, Object>)temp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getSessionProperty(QualifiedName name) {
/* 230 */     ObjectMap<QualifiedName, Object> objectMap = this.sessionProperties;
/* 231 */     if (objectMap == null)
/* 232 */       return null; 
/* 233 */     return objectMap.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized ObjectMap<QualifiedName, Object> getSyncInfo(boolean makeCopy) {
/* 243 */     if (this.syncInfo == null)
/* 244 */       return null; 
/* 245 */     return makeCopy ? (ObjectMap<QualifiedName, Object>)this.syncInfo.clone() : this.syncInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized byte[] getSyncInfo(QualifiedName id, boolean makeCopy) {
/* 251 */     if (this.syncInfo == null)
/* 252 */       return null; 
/* 253 */     byte[] b = (byte[])this.syncInfo.get(id);
/* 254 */     return (b == null) ? null : (makeCopy ? (byte[])b.clone() : b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSyncInfoGenerationCount() {
/* 262 */     return this.markerAndSyncStamp & 0xFFFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getType() {
/* 270 */     return getType(this.flags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void incrementCharsetGenerationCount() {
/* 279 */     this.charsetAndContentId = (this.charsetAndContentId + 65535 + 1 & 0xFFFF0000) + (this.charsetAndContentId & 0xFFFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void incrementContentId() {
/* 287 */     this.charsetAndContentId = (this.charsetAndContentId & 0xFFFF0000) + (this.charsetAndContentId + 1 & 0xFFFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void incrementMarkerGenerationCount() {
/* 296 */     this.markerAndSyncStamp = (this.markerAndSyncStamp + 65535 + 1 & 0xFFFF0000) + (this.markerAndSyncStamp & 0xFFFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void incrementModificationStamp() {
/* 305 */     this.modStamp++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void incrementSyncInfoGenerationCount() {
/* 314 */     this.markerAndSyncStamp = (this.markerAndSyncStamp & 0xFFFF0000) + (this.markerAndSyncStamp + 1 & 0xFFFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSet(int mask) {
/* 321 */     return ((this.flags & mask) == mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readFrom(int newFlags, DataInput input) throws IOException {
/* 328 */     this.flags = newFlags;
/* 329 */     this.localInfo = input.readLong();
/* 330 */     this.nodeId = input.readLong();
/* 331 */     this.charsetAndContentId = input.readInt() & 0xFFFF;
/* 332 */     this.modStamp = input.readLong();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(int mask) {
/* 339 */     this.flags |= mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setBits(int mask, int start, int value) {
/* 346 */     int baseMask = mask >> start;
/* 347 */     int newValue = (value & baseMask) << start;
/*     */     
/* 349 */     int temp = this.flags;
/* 350 */     temp &= mask ^ 0xFFFFFFFF;
/* 351 */     temp |= newValue;
/* 352 */     this.flags = temp;
/*     */   }
/*     */   
/*     */   public void setFileStoreRoot(FileStoreRoot fileStoreRoot) {
/* 356 */     this.fileStoreRoot = fileStoreRoot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setFlags(int value) {
/* 363 */     this.flags = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocalSyncInfo(long info) {
/* 370 */     this.localInfo = info;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMarkers(MarkerSet value) {
/* 378 */     this.markers = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModificationStamp(long value) {
/* 385 */     this.modStamp = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNodeId(long id) {
/* 392 */     this.nodeId = id;
/*     */ 
/*     */     
/* 395 */     if (this.modStamp == 0L) {
/* 396 */       this.modStamp = this.nodeId;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPropertyStore(Object value) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setSessionProperty(QualifiedName name, Object value) {
/* 413 */     if (value == null)
/* 414 */     { if (this.sessionProperties == null)
/*     */         return; 
/* 416 */       ObjectMap<QualifiedName, Object> temp = (ObjectMap<QualifiedName, Object>)this.sessionProperties.clone();
/* 417 */       temp.remove(name);
/* 418 */       if (temp.isEmpty()) {
/* 419 */         this.sessionProperties = null;
/*     */       } else {
/* 421 */         this.sessionProperties = temp;
/*     */       }  }
/* 423 */     else { ObjectMap<QualifiedName, Object> temp = this.sessionProperties;
/* 424 */       if (temp == null) {
/* 425 */         temp = new ObjectMap(5);
/*     */       } else {
/* 427 */         temp = (ObjectMap<QualifiedName, Object>)this.sessionProperties.clone();
/* 428 */       }  temp.put(name, value);
/* 429 */       this.sessionProperties = temp; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSyncInfo(ObjectMap<QualifiedName, Object> syncInfo) {
/* 439 */     this.syncInfo = syncInfo;
/*     */   }
/*     */   
/*     */   public synchronized void setSyncInfo(QualifiedName id, byte[] value) {
/* 443 */     if (value == null) {
/*     */       
/* 445 */       if (this.syncInfo == null)
/*     */         return; 
/* 447 */       this.syncInfo.remove(id);
/* 448 */       if (this.syncInfo.isEmpty()) {
/* 449 */         this.syncInfo = null;
/*     */       }
/*     */     } else {
/* 452 */       if (this.syncInfo == null)
/* 453 */         this.syncInfo = new ObjectMap(5); 
/* 454 */       this.syncInfo.put(id, value.clone());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(int value) {
/* 463 */     setBits(3840, 8, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shareStrings(StringPool set) {
/* 471 */     ObjectMap<QualifiedName, Object> map = this.syncInfo;
/* 472 */     if (map != null)
/* 473 */       map.shareStrings(set); 
/* 474 */     map = this.sessionProperties;
/* 475 */     if (map != null)
/* 476 */       map.shareStrings(set); 
/* 477 */     MarkerSet markerSet = this.markers;
/* 478 */     if (markerSet != null) {
/* 479 */       markerSet.shareStrings(set);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTo(DataOutput output) throws IOException {
/* 486 */     output.writeLong(this.localInfo);
/* 487 */     output.writeLong(this.nodeId);
/* 488 */     output.writeInt(getContentId());
/* 489 */     output.writeLong(this.modStamp);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 495 */     return this.fileStoreRoot + " modStamp=" + this.modStamp;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ResourceInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */