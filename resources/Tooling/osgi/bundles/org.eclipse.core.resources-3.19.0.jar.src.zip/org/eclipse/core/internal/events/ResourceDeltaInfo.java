/*    */ package org.eclipse.core.internal.events;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.stream.Collectors;
/*    */ import org.eclipse.core.internal.resources.MarkerSet;
/*    */ import org.eclipse.core.internal.resources.Workspace;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceDeltaInfo
/*    */ {
/*    */   protected Workspace workspace;
/*    */   protected Map<IPath, MarkerSet> allMarkerDeltas;
/*    */   protected NodeIDMap nodeIDMap;
/*    */   protected ResourceComparator comparator;
/*    */   
/*    */   public ResourceDeltaInfo(Workspace workspace, Map<IPath, MarkerSet> markerDeltas, ResourceComparator comparator) {
/* 31 */     this.workspace = workspace;
/* 32 */     this.allMarkerDeltas = markerDeltas;
/* 33 */     this.comparator = comparator;
/*    */   }
/*    */   
/*    */   public ResourceComparator getComparator() {
/* 37 */     return this.comparator;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Map<IPath, MarkerSet> getMarkerDeltas() {
/* 44 */     return this.allMarkerDeltas;
/*    */   }
/*    */   
/*    */   public NodeIDMap getNodeIDMap() {
/* 48 */     return this.nodeIDMap;
/*    */   }
/*    */   
/*    */   public Workspace getWorkspace() {
/* 52 */     return this.workspace;
/*    */   }
/*    */   
/*    */   public void setMarkerDeltas(Map<IPath, MarkerSet> value) {
/* 56 */     this.allMarkerDeltas = value;
/*    */   }
/*    */   
/*    */   public void setNodeIDMap(NodeIDMap map) {
/* 60 */     this.nodeIDMap = map;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 66 */     return String.valueOf(getClass().getSimpleName()) + "[allMarkerDeltas=" + (
/* 67 */       (this.allMarkerDeltas == null) ? null : 
/* 68 */       this.allMarkerDeltas.entrySet().stream().map(e -> (new StringBuilder()).append(e.getKey()).append("=").append(e.getValue()).toString())
/* 69 */       .collect(Collectors.joining(", ", "{", "}"))) + 
/* 70 */       "]";
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\ResourceDeltaInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */