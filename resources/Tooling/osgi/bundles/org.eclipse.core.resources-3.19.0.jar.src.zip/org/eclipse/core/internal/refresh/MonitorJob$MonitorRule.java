/*     */ package org.eclipse.core.internal.refresh;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.MultiRule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MonitorRule
/*     */   implements ISchedulingRule
/*     */ {
/*  74 */   private static final ISchedulingRule[] SCHEDULING_RULE__EMPTY_ARR = new ISchedulingRule[0];
/*     */   
/*     */   private final ISchedulingRule resourceRule;
/*     */   
/*     */   MonitorRule(ISchedulingRule schedulingRule) {
/*  79 */     this.resourceRule = schedulingRule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MonitorRule create(IResource resource) {
/*  90 */     return new MonitorRule((ISchedulingRule)resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MonitorRule create(Collection<IResource> resources) {
/* 101 */     return new MonitorRule(MultiRule.combine(resources.<ISchedulingRule>toArray(SCHEDULING_RULE__EMPTY_ARR)));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isConflicting(ISchedulingRule rule) {
/* 106 */     if (rule instanceof MonitorRule) {
/* 107 */       return this.resourceRule.isConflicting(((MonitorRule)rule).resourceRule);
/*     */     }
/* 109 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(ISchedulingRule rule) {
/* 114 */     if (rule instanceof MonitorRule) {
/* 115 */       return this.resourceRule.contains(((MonitorRule)rule).resourceRule);
/*     */     }
/* 117 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\refresh\MonitorJob$MonitorRule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */