/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import org.eclipse.core.resources.IResourceStatus;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceException
/*     */   extends CoreException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public ResourceException(int code, IPath path, String message, Throwable exception) {
/*  38 */     super((IStatus)new ResourceStatus(code, path, message, provideStackTrace(message, exception)));
/*     */   }
/*     */   
/*     */   private static Throwable provideStackTrace(String message, Throwable exception) {
/*  42 */     return (exception != null) ? exception : new Exception(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceException(IStatus status) {
/*  52 */     super(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace() {
/*  62 */     printStackTrace(System.err);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintStream output) {
/*  72 */     synchronized (output) {
/*  73 */       IStatus status = getStatus();
/*  74 */       if (status.getException() != null) {
/*  75 */         String path = "()";
/*  76 */         if (status instanceof IResourceStatus)
/*  77 */           path = "(" + ((IResourceStatus)status).getPath() + ")"; 
/*  78 */         output.print(String.valueOf(getClass().getName()) + path + "[" + status.getCode() + "]: ");
/*  79 */         status.getException().printStackTrace(output);
/*     */       } else {
/*  81 */         super.printStackTrace(output);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printStackTrace(PrintWriter output) {
/*  92 */     synchronized (output) {
/*  93 */       IStatus status = getStatus();
/*  94 */       if (status.getException() != null) {
/*  95 */         String path = "()";
/*  96 */         if (status instanceof IResourceStatus)
/*  97 */           path = "(" + ((IResourceStatus)status).getPath() + ")"; 
/*  98 */         output.print(String.valueOf(getClass().getName()) + path + "[" + status.getCode() + "]: ");
/*  99 */         status.getException().printStackTrace(output);
/*     */       } else {
/* 101 */         super.printStackTrace(output);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ResourceException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */