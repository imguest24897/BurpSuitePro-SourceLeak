package org.eclipse.core.internal.dtree;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.eclipse.core.runtime.IPath;

public interface IDataFlattener {
  Object readData(IPath paramIPath, DataInput paramDataInput) throws IOException;
  
  void writeData(IPath paramIPath, Object paramObject, DataOutput paramDataOutput) throws IOException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\dtree\IDataFlattener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */