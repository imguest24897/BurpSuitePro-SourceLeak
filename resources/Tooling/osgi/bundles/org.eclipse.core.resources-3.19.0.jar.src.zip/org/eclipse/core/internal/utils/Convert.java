/*    */ package org.eclipse.core.internal.utils;
/*    */ 
/*    */ import java.nio.charset.StandardCharsets;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Convert
/*    */ {
/*    */   public static String fromUTF8(byte[] b) {
/* 24 */     return new String(b, StandardCharsets.UTF_8);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static byte[] toUTF8(String s) {
/* 31 */     return s.getBytes(StandardCharsets.UTF_8);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static byte[] longToBytes(long value) {
/* 42 */     byte[] bytes = new byte[8];
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 51 */     for (int i = 0; i < bytes.length; i++) {
/* 52 */       bytes[bytes.length - 1 - i] = (byte)(int)value;
/* 53 */       value >>>= 8L;
/*    */     } 
/*    */     
/* 56 */     return bytes;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static long bytesToLong(byte[] value) {
/* 66 */     long longValue = 0L; byte b;
/*    */     int i;
/*    */     byte[] arrayOfByte;
/* 69 */     for (i = (arrayOfByte = value).length, b = 0; b < i; ) { byte element = arrayOfByte[b];
/*    */       
/* 71 */       longValue <<= 8L;
/* 72 */       longValue ^= (element & 0xFF);
/*    */       b++; }
/*    */     
/* 75 */     return longValue;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\interna\\utils\Convert.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */