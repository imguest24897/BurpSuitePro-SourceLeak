/*     */ package org.eclipse.core.internal.refresh;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import org.eclipse.core.internal.resources.Resource;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.refresh.IRefreshMonitor;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.osgi.framework.Bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PollingMonitor
/*     */   extends Job
/*     */   implements IRefreshMonitor
/*     */ {
/*     */   private static final long MAX_DURATION = 250L;
/*     */   private static final long HOT_ROOT_DECAY = 90000L;
/*     */   private static final long MIN_FREQUENCY = 4000L;
/*     */   private final ArrayList<IResource> resourceRoots;
/*     */   private final ArrayList<IResource> toRefresh;
/*     */   private IResource hotRoot;
/*     */   private long hotRootTime;
/*     */   private final RefreshManager refreshManager;
/*     */   private boolean firstRun = true;
/*     */   
/*     */   public PollingMonitor(RefreshManager manager) {
/*  83 */     super(Messages.refresh_pollJob);
/*  84 */     this.refreshManager = manager;
/*  85 */     setPriority(50);
/*  86 */     setSystem(true);
/*  87 */     this.resourceRoots = new ArrayList<>();
/*  88 */     this.toRefresh = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void monitor(IResource root) {
/*  95 */     this.resourceRoots.add(root);
/*  96 */     schedule(4000L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IStatus run(IProgressMonitor monitor) {
/* 105 */     if (this.firstRun) {
/* 106 */       this.firstRun = false;
/* 107 */       Bundle bundle1 = Platform.getBundle("org.eclipse.core.resources");
/* 108 */       long waitStart = System.currentTimeMillis();
/* 109 */       while (bundle1.getState() == 8) {
/*     */         try {
/* 111 */           Thread.sleep(10000L);
/* 112 */         } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */ 
/*     */         
/* 116 */         if (System.currentTimeMillis() - waitStart > 90000L)
/*     */           break; 
/*     */       } 
/*     */     } 
/* 120 */     long time = System.currentTimeMillis();
/*     */     
/* 122 */     if (this.toRefresh.isEmpty()) {
/* 123 */       beginIteration();
/* 124 */       if (Policy.DEBUG_AUTO_REFRESH)
/* 125 */         Policy.debug("Auto-refresh: New polling iteration on " + this.toRefresh.size() + " roots"); 
/*     */     } 
/* 127 */     int oldSize = this.toRefresh.size();
/* 128 */     if (Policy.DEBUG_AUTO_REFRESH) {
/* 129 */       Policy.debug("Auto-refresh: started polling");
/*     */     }
/* 131 */     if (time - this.hotRootTime > 90000L) {
/* 132 */       this.hotRoot = null;
/* 133 */     } else if (this.hotRoot != null && !monitor.isCanceled()) {
/* 134 */       poll(this.hotRoot);
/*     */     } 
/* 136 */     long loopStart = System.currentTimeMillis();
/* 137 */     while (!this.toRefresh.isEmpty() && 
/* 138 */       !monitor.isCanceled()) {
/*     */       
/* 140 */       poll(this.toRefresh.remove(this.toRefresh.size() - 1));
/*     */       
/* 142 */       if (System.currentTimeMillis() - loopStart > 250L)
/*     */         break; 
/*     */     } 
/* 145 */     time = System.currentTimeMillis() - time;
/* 146 */     if (Policy.DEBUG_AUTO_REFRESH) {
/* 147 */       Policy.debug("Auto-refresh: polled " + (oldSize - this.toRefresh.size()) + " roots in " + time + "ms");
/*     */     }
/*     */     
/* 150 */     long delay = Math.max(4000L, time * 20L);
/*     */     
/* 152 */     if (!getJobManager().isIdle())
/* 153 */       delay *= 2L; 
/* 154 */     if (Policy.DEBUG_AUTO_REFRESH) {
/* 155 */       Policy.debug("Auto-refresh: rescheduling polling job in: " + (delay / 1000L) + " seconds");
/*     */     }
/* 157 */     Bundle bundle = Platform.getBundle("org.eclipse.core.resources");
/* 158 */     if (bundle != null && bundle.getState() == 32)
/* 159 */       schedule(delay); 
/* 160 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void runOnce() {
/* 170 */     synchronized (this) {
/*     */ 
/*     */ 
/*     */       
/* 174 */       IProject[] projects = this.refreshManager.getWorkspace().getRoot().getProjects(8);
/* 175 */       this.toRefresh.addAll((Collection)Arrays.asList((Object[])projects));
/*     */     } 
/* 177 */     schedule(4000L);
/*     */   }
/*     */   
/*     */   private void poll(IResource resource) {
/* 181 */     if (resource.isSynchronized(2)) {
/*     */       return;
/*     */     }
/* 184 */     if (resource.isLinked() && !((Resource)resource).getStore().fetchInfo().exists()) {
/*     */       return;
/*     */     }
/* 187 */     this.refreshManager.refresh(resource);
/* 188 */     this.hotRoot = resource;
/* 189 */     this.hotRootTime = System.currentTimeMillis();
/* 190 */     if (Policy.DEBUG_AUTO_REFRESH) {
/* 191 */       Policy.debug("Auto-refresh: new hot root: " + resource);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean shouldRun() {
/* 197 */     return !(this.resourceRoots.isEmpty() && this.toRefresh.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void beginIteration() {
/* 206 */     this.toRefresh.addAll(this.resourceRoots);
/* 207 */     if (this.hotRoot != null) {
/* 208 */       this.toRefresh.remove(this.hotRoot);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void unmonitor(IResource resource) {
/* 216 */     if (resource == null) {
/* 217 */       this.resourceRoots.clear();
/*     */     } else {
/* 219 */       this.resourceRoots.remove(resource);
/* 220 */     }  if (this.resourceRoots.isEmpty())
/* 221 */       cancel(); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\refresh\PollingMonitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */