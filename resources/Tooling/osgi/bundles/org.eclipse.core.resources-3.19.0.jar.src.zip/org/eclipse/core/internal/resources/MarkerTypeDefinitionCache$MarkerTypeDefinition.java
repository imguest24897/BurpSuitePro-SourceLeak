/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.core.runtime.IExtension;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MarkerTypeDefinition
/*    */ {
/*    */   boolean isPersistent = false;
/*    */   Set<String> superTypes;
/*    */   
/*    */   MarkerTypeDefinition(IExtension ext) {
/* 29 */     IConfigurationElement[] elements = ext.getConfigurationElements(); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 30 */     for (i = (arrayOfIConfigurationElement1 = elements).length, b = 0; b < i; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b];
/*    */       
/* 32 */       String elementName = element.getName();
/* 33 */       if (elementName.equalsIgnoreCase("super")) {
/* 34 */         String aType = element.getAttribute("type");
/* 35 */         if (aType != null) {
/* 36 */           if (this.superTypes == null) {
/* 37 */             this.superTypes = new HashSet<>(8);
/*    */           }
/*    */ 
/*    */           
/* 41 */           this.superTypes.add(aType.intern());
/*    */         } 
/*    */       } 
/*    */       
/* 45 */       if (elementName.equalsIgnoreCase("persistent")) {
/* 46 */         String bool = element.getAttribute("value");
/* 47 */         if (bool != null) {
/* 48 */           this.isPersistent = Boolean.parseBoolean(bool);
/*    */         }
/*    */       } 
/* 51 */       if (elementName.equalsIgnoreCase("transient")) {
/* 52 */         String bool = element.getAttribute("value");
/* 53 */         if (bool != null)
/* 54 */           this.isPersistent = !Boolean.parseBoolean(bool); 
/*    */       } 
/*    */       b++; }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\MarkerTypeDefinitionCache$MarkerTypeDefinition.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */