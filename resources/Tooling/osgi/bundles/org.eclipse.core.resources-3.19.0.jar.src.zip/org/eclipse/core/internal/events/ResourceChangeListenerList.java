/*     */ package org.eclipse.core.internal.events;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.eclipse.core.resources.IResourceChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceChangeListenerList
/*     */ {
/*     */   static final class ListenerEntry
/*     */   {
/*     */     final int eventMask;
/*     */     final IResourceChangeListener listener;
/*     */     
/*     */     ListenerEntry(IResourceChangeListener listener, int eventMask) {
/*  41 */       this.listener = listener;
/*  42 */       this.eventMask = eventMask;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  47 */       StringBuilder sb = new StringBuilder();
/*  48 */       sb.append("Listener [eventMask=");
/*  49 */       sb.append(this.eventMask);
/*  50 */       sb.append(", ");
/*  51 */       sb.append(this.listener);
/*  52 */       sb.append("]");
/*  53 */       return sb.toString();
/*     */     }
/*     */   }
/*     */   
/*  57 */   private volatile int count1 = 0;
/*  58 */   private volatile int count2 = 0;
/*  59 */   private volatile int count4 = 0;
/*  60 */   private volatile int count8 = 0;
/*  61 */   private volatile int count16 = 0;
/*  62 */   private volatile int count32 = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   private final CopyOnWriteArrayList<ListenerEntry> listeners = new CopyOnWriteArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void add(IResourceChangeListener listener, int mask) {
/*  77 */     Objects.requireNonNull(listener);
/*  78 */     if (mask == 0) {
/*  79 */       remove(listener);
/*     */       return;
/*     */     } 
/*  82 */     ListenerEntry entry = new ListenerEntry(listener, mask);
/*  83 */     int oldSize = this.listeners.size();
/*     */     
/*  85 */     for (int i = 0; i < oldSize; i++) {
/*  86 */       ListenerEntry oldEntry = this.listeners.get(i);
/*  87 */       if (oldEntry.listener == listener) {
/*  88 */         removing(oldEntry.eventMask);
/*  89 */         adding(mask);
/*  90 */         this.listeners.set(i, entry);
/*     */         return;
/*     */       } 
/*     */     } 
/*  94 */     adding(mask);
/*  95 */     this.listeners.add(entry);
/*     */   }
/*     */   
/*     */   private void adding(int mask) {
/*  99 */     if ((mask & 0x1) != 0)
/* 100 */       this.count1++; 
/* 101 */     if ((mask & 0x2) != 0)
/* 102 */       this.count2++; 
/* 103 */     if ((mask & 0x4) != 0)
/* 104 */       this.count4++; 
/* 105 */     if ((mask & 0x8) != 0)
/* 106 */       this.count8++; 
/* 107 */     if ((mask & 0x10) != 0)
/* 108 */       this.count16++; 
/* 109 */     if ((mask & 0x20) != 0) {
/* 110 */       this.count32++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListenerEntry[] getListeners() {
/* 118 */     return (ListenerEntry[])this.listeners.toArray(paramInt -> new ListenerEntry[paramInt]);
/*     */   }
/*     */   
/*     */   public boolean hasListenerFor(int event) {
/* 122 */     switch (event) {
/*     */       case 1:
/* 124 */         return (this.count1 > 0);
/*     */       case 2:
/* 126 */         return (this.count2 > 0);
/*     */       case 4:
/* 128 */         return (this.count4 > 0);
/*     */       case 8:
/* 130 */         return (this.count8 > 0);
/*     */       case 16:
/* 132 */         return (this.count16 > 0);
/*     */       case 32:
/* 134 */         return (this.count32 > 0);
/*     */     } 
/* 136 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void remove(IResourceChangeListener listener) {
/* 147 */     Objects.requireNonNull(listener);
/* 148 */     int oldSize = this.listeners.size();
/* 149 */     for (int i = 0; i < oldSize; i++) {
/* 150 */       ListenerEntry oldEntry = this.listeners.get(i);
/* 151 */       if (oldEntry.listener == listener) {
/* 152 */         removing(oldEntry.eventMask);
/* 153 */         this.listeners.remove(i);
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized void clear() {
/* 160 */     this.listeners.clear();
/* 161 */     this.count1 = 0;
/* 162 */     this.count2 = 0;
/* 163 */     this.count4 = 0;
/* 164 */     this.count8 = 0;
/* 165 */     this.count16 = 0;
/* 166 */     this.count32 = 0;
/*     */   }
/*     */   
/*     */   private void removing(int mask) {
/* 170 */     if ((mask & 0x1) != 0)
/* 171 */       this.count1--; 
/* 172 */     if ((mask & 0x2) != 0)
/* 173 */       this.count2--; 
/* 174 */     if ((mask & 0x4) != 0)
/* 175 */       this.count4--; 
/* 176 */     if ((mask & 0x8) != 0)
/* 177 */       this.count8--; 
/* 178 */     if ((mask & 0x10) != 0)
/* 179 */       this.count16--; 
/* 180 */     if ((mask & 0x20) != 0) {
/* 181 */       this.count32--;
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString() {
/* 186 */     StringBuilder builder = new StringBuilder();
/* 187 */     builder.append("ResourceChangeListenerList [");
/* 188 */     if (this.listeners != null) {
/* 189 */       builder.append("listeners=");
/* 190 */       builder.append(this.listeners.toString());
/*     */     } 
/* 192 */     builder.append("]");
/* 193 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\ResourceChangeListenerList.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */