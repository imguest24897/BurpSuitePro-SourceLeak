/*     */ package org.eclipse.core.internal.events;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.resources.ICoreConstants;
/*     */ import org.eclipse.core.internal.watson.ElementTree;
/*     */ import org.eclipse.core.resources.IBuildConfiguration;
/*     */ import org.eclipse.core.resources.IBuildContext;
/*     */ import org.eclipse.core.resources.ICommand;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InternalBuilder
/*     */ {
/*     */   static BuildManager buildManager;
/*     */   private ICommand command;
/*     */   private boolean forgetStateRequested = false;
/*     */   private boolean rememberStateRequested = false;
/*  39 */   private IProject[] interestingProjects = ICoreConstants.EMPTY_PROJECT_ARRAY;
/*     */ 
/*     */   
/*     */   private String label;
/*     */ 
/*     */   
/*     */   private String natureId;
/*     */ 
/*     */   
/*     */   private ElementTree oldState;
/*     */ 
/*     */   
/*     */   private String pluginId;
/*     */ 
/*     */   
/*     */   private IBuildConfiguration buildConfiguration;
/*     */ 
/*     */   
/*  57 */   private IBuildContext context = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean callOnEmptyDelta = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract IProject[] build(int paramInt, Map<String, String> paramMap, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean callOnEmptyDelta() {
/*  73 */     return this.callOnEmptyDelta;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void clean(IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */   
/*     */   final void clearLastBuiltStateRequests() {
/*  84 */     this.forgetStateRequested = false;
/*  85 */     this.rememberStateRequested = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void forgetLastBuiltState() {
/*  92 */     this.oldState = null;
/*  93 */     this.forgetStateRequested = true;
/*  94 */     this.rememberStateRequested = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void rememberLastBuiltState() {
/* 101 */     this.rememberStateRequested = !this.forgetStateRequested;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ICommand getCommand() {
/* 108 */     return (ICommand)((BuildCommand)this.command).clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IResourceDelta getDelta(IProject aProject) {
/* 116 */     return buildManager.getDelta(aProject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IBuildContext getContext() {
/* 123 */     return this.context;
/*     */   }
/*     */   
/*     */   final IProject[] getInterestingProjects() {
/* 127 */     return this.interestingProjects;
/*     */   }
/*     */   
/*     */   final String getLabel() {
/* 131 */     return this.label;
/*     */   }
/*     */   
/*     */   final ElementTree getLastBuiltTree() {
/* 135 */     return this.oldState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String getNatureId() {
/* 143 */     return this.natureId;
/*     */   }
/*     */   
/*     */   final String getPluginId() {
/* 147 */     return this.pluginId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IProject getProject() {
/* 154 */     return this.buildConfiguration.getProject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IBuildConfiguration getBuildConfig() {
/* 161 */     return this.buildConfiguration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasBeenBuilt(IProject aProject) {
/* 168 */     return buildManager.hasBeenBuilt(aProject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInterrupted() {
/* 175 */     return buildManager.autoBuildJob.isInterrupted();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void needRebuild() {
/* 182 */     buildManager.requestRebuild();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void requestProjectRebuild(boolean processOtherBuilders) {
/* 189 */     buildManager.requestRebuild(getProject(), processOtherBuilders);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void requestProjectsRebuild(Collection<IProject> projects) {
/* 196 */     buildManager.requestRebuild(projects, getProject());
/*     */   }
/*     */   
/*     */   final void setCallOnEmptyDelta(boolean value) {
/* 200 */     this.callOnEmptyDelta = value;
/*     */   }
/*     */   
/*     */   final void setCommand(ICommand value) {
/* 204 */     this.command = value;
/*     */   }
/*     */   
/*     */   final void setInterestingProjects(IProject[] value) {
/* 208 */     this.interestingProjects = value;
/*     */   }
/*     */   
/*     */   final void setLabel(String value) {
/* 212 */     this.label = value;
/*     */   }
/*     */   
/*     */   final void setLastBuiltTree(ElementTree value) {
/* 216 */     this.oldState = value;
/*     */   }
/*     */   
/*     */   final void setNatureId(String id) {
/* 220 */     this.natureId = id;
/*     */   }
/*     */   
/*     */   final void setPluginId(String value) {
/* 224 */     this.pluginId = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setBuildConfig(IBuildConfiguration value) {
/* 232 */     Assert.isNotNull(value);
/* 233 */     this.buildConfiguration = value;
/* 234 */     if (this.context == null) {
/* 235 */       this.context = new BuildContext(this.buildConfiguration);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setContext(IBuildContext context) {
/* 243 */     this.context = context;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void startupOnInitialize();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean wasForgetStateRequested() {
/* 256 */     return this.forgetStateRequested;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean wasRememberStateRequested() {
/* 264 */     return this.rememberStateRequested;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\InternalBuilder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */