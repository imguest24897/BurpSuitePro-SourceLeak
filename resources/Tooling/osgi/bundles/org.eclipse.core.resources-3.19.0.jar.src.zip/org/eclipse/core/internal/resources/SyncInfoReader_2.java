/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.ObjectMap;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncInfoReader_2
/*     */   extends SyncInfoReader
/*     */ {
/*     */   public static final int INDEX = 1;
/*     */   public static final int QNAME = 2;
/*     */   
/*     */   public SyncInfoReader_2(Workspace workspace, Synchronizer synchronizer) {
/*  38 */     super(workspace, synchronizer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readSyncInfo(DataInputStream input) throws IOException, CoreException {
/*     */     try {
/*  58 */       List<QualifiedName> readPartners = new ArrayList<>(5);
/*     */       while (true) {
/*  60 */         Path path = new Path(input.readUTF());
/*  61 */         readSyncInfo((IPath)path, input, readPartners);
/*     */       } 
/*  63 */     } catch (EOFException eOFException) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void readSyncInfo(IPath path, DataInputStream input, List<QualifiedName> readPartners) throws IOException, CoreException {
/*  69 */     int size = input.readInt();
/*  70 */     ObjectMap<QualifiedName, Object> table = new ObjectMap(size);
/*  71 */     for (int i = 0; i < size; i++) {
/*  72 */       String qualifier, local, msg; QualifiedName name = null;
/*  73 */       int type = input.readInt();
/*  74 */       switch (type) {
/*     */         case 2:
/*  76 */           qualifier = input.readUTF();
/*  77 */           local = input.readUTF();
/*  78 */           name = new QualifiedName(qualifier, local);
/*  79 */           readPartners.add(name);
/*     */           break;
/*     */         case 1:
/*  82 */           name = readPartners.get(input.readInt());
/*     */           break;
/*     */         
/*     */         default:
/*  86 */           msg = NLS.bind(Messages.resources_readSync, (path == null) ? "" : path.toString());
/*  87 */           throw new ResourceException(567, path, msg, null);
/*     */       } 
/*     */       
/*  90 */       int length = input.readInt();
/*  91 */       byte[] bytes = new byte[length];
/*  92 */       input.readFully(bytes);
/*     */       
/*  94 */       table.put(name, bytes);
/*     */     } 
/*     */     
/*  97 */     ResourceInfo info = this.workspace.getResourceInfo(path, true, false);
/*  98 */     if (info == null)
/*     */       return; 
/* 100 */     info.setSyncInfo(table);
/* 101 */     info.clear(8192);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\SyncInfoReader_2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */