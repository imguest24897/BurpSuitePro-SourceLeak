package org.eclipse.core.internal.utils;

public interface KeyedElement {
  boolean compare(KeyedElement paramKeyedElement);
  
  Object getKey();
  
  int getKeyHashCode();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\interna\\utils\KeyedHashSet$KeyedElement.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */