package org.eclipse.core.resources;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.ICoreRunnable;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IWorkspaceRunnable extends ICoreRunnable {
  void run(IProgressMonitor paramIProgressMonitor) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IWorkspaceRunnable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */