/*     */ package org.eclipse.core.internal.utils;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubProgressMonitor;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.osgi.service.debug.DebugOptions;
/*     */ import org.eclipse.osgi.service.debug.DebugOptionsListener;
/*     */ import org.eclipse.osgi.service.debug.DebugTrace;
/*     */ import org.osgi.framework.Bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Policy
/*     */ {
/*     */   static DebugTrace DEBUG_TRACE;
/*     */   
/*  27 */   public static final DebugOptionsListener RESOURCES_DEBUG_OPTIONS_LISTENER = new DebugOptionsListener()
/*     */     {
/*     */       public void optionsChanged(DebugOptions options) {
/*  30 */         Policy.DEBUG_TRACE = options.newDebugTrace("org.eclipse.core.resources");
/*  31 */         Policy.DEBUG = options.getBooleanOption("org.eclipse.core.resources/debug", false);
/*     */         
/*  33 */         Policy.DEBUG_AUTO_REFRESH = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/refresh", false));
/*     */         
/*  35 */         Policy.DEBUG_BUILD_DELTA = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/delta", false));
/*  36 */         Policy.DEBUG_BUILD_CYCLE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/cycle", false));
/*  37 */         Policy.DEBUG_BUILD_FAILURE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/failure", false));
/*  38 */         Policy.DEBUG_BUILD_INTERRUPT = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/interrupt", false));
/*  39 */         Policy.DEBUG_BUILD_INVOKING = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/invoking", false));
/*  40 */         Policy.DEBUG_BUILD_NEEDED = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/needbuild", false));
/*  41 */         Policy.DEBUG_BUILD_NEEDED_DELTA = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/needbuilddelta", false));
/*  42 */         Policy.DEBUG_BUILD_NEEDED_STACK = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/needbuildstack", false));
/*  43 */         Policy.DEBUG_BUILD_STACK = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/build/stacktrace", false));
/*     */         
/*  45 */         Policy.DEBUG_CONTENT_TYPE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/contenttype", false));
/*  46 */         Policy.DEBUG_CONTENT_TYPE_CACHE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/contenttype/cache", false));
/*  47 */         Policy.DEBUG_HISTORY = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/history", false));
/*  48 */         Policy.DEBUG_NATURES = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/natures", false));
/*  49 */         Policy.DEBUG_NOTIFICATIONS = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/notifications", false));
/*  50 */         Policy.DEBUG_PREFERENCES = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/preferences", false));
/*     */         
/*  52 */         Policy.DEBUG_RESTORE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/restore", false));
/*  53 */         Policy.DEBUG_RESTORE_MARKERS = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/restore/markers", false));
/*  54 */         Policy.DEBUG_RESTORE_MASTERTABLE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/restore/mastertable", false));
/*  55 */         Policy.DEBUG_RESTORE_METAINFO = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/restore/metainfo", false));
/*  56 */         Policy.DEBUG_RESTORE_SNAPSHOTS = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/restore/snapshots", false));
/*  57 */         Policy.DEBUG_RESTORE_SYNCINFO = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/restore/syncinfo", false));
/*  58 */         Policy.DEBUG_RESTORE_TREE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/restore/tree", false));
/*     */         
/*  60 */         Policy.DEBUG_SAVE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/save", false));
/*  61 */         Policy.DEBUG_SAVE_MARKERS = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/save/markers", false));
/*  62 */         Policy.DEBUG_SAVE_MASTERTABLE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/save/mastertable", false));
/*  63 */         Policy.DEBUG_SAVE_METAINFO = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/save/metainfo", false));
/*  64 */         Policy.DEBUG_SAVE_SYNCINFO = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/save/syncinfo", false));
/*  65 */         Policy.DEBUG_SAVE_TREE = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/save/tree", false));
/*     */         
/*  67 */         Policy.DEBUG_STRINGS = (Policy.DEBUG && options.getBooleanOption("org.eclipse.core.resources/strings", false));
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   public static final boolean buildOnCancel = false;
/*     */   
/*     */   public static boolean DEBUG = false;
/*     */   
/*     */   public static boolean DEBUG_AUTO_REFRESH = false;
/*     */   
/*     */   public static boolean DEBUG_BUILD_DELTA = false;
/*     */   
/*     */   public static boolean DEBUG_BUILD_CYCLE = false;
/*     */   
/*     */   public static boolean DEBUG_BUILD_FAILURE = false;
/*     */   
/*     */   public static boolean DEBUG_BUILD_INTERRUPT = false;
/*     */   
/*     */   public static boolean DEBUG_BUILD_INVOKING = false;
/*     */   
/*     */   public static boolean DEBUG_BUILD_NEEDED = false;
/*     */   
/*     */   public static boolean DEBUG_BUILD_NEEDED_DELTA = false;
/*     */   public static boolean DEBUG_BUILD_NEEDED_STACK = false;
/*     */   public static boolean DEBUG_BUILD_STACK = false;
/*     */   public static boolean DEBUG_CONTENT_TYPE = false;
/*     */   public static boolean DEBUG_CONTENT_TYPE_CACHE = false;
/*     */   public static boolean DEBUG_HISTORY = false;
/*     */   public static boolean DEBUG_NATURES = false;
/*     */   public static boolean DEBUG_NOTIFICATIONS = false;
/*     */   public static boolean DEBUG_PREFERENCES = false;
/*     */   public static boolean DEBUG_RESTORE = false;
/*     */   public static boolean DEBUG_RESTORE_MARKERS = false;
/*     */   public static boolean DEBUG_RESTORE_MASTERTABLE = false;
/*     */   public static boolean DEBUG_RESTORE_METAINFO = false;
/*     */   public static boolean DEBUG_RESTORE_SNAPSHOTS = false;
/*     */   public static boolean DEBUG_RESTORE_SYNCINFO = false;
/*     */   public static boolean DEBUG_RESTORE_TREE = false;
/*     */   public static boolean DEBUG_SAVE = false;
/*     */   public static boolean DEBUG_SAVE_MARKERS = false;
/*     */   public static boolean DEBUG_SAVE_MASTERTABLE = false;
/*     */   public static boolean DEBUG_SAVE_METAINFO = false;
/*     */   public static boolean DEBUG_SAVE_SYNCINFO = false;
/*     */   public static boolean DEBUG_SAVE_TREE = false;
/*     */   public static boolean DEBUG_STRINGS = false;
/*     */   public static final long MAX_BUILD_DELAY = 1000L;
/*     */   public static final long MIN_BUILD_DELAY = 100L;
/* 115 */   public static int opWork = 100;
/*     */   public static final int totalWork = 100;
/*     */   
/*     */   public static void checkCanceled(IProgressMonitor monitor) {
/* 119 */     if (monitor.isCanceled()) {
/* 120 */       throw new OperationCanceledException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void debug(String message) {
/* 128 */     StringBuilder output = new StringBuilder();
/* 129 */     Job currentJob = Job.getJobManager().currentJob();
/* 130 */     if (currentJob != null) {
/* 131 */       output.append(currentJob.getClass().getName());
/* 132 */       output.append("(");
/* 133 */       output.append(currentJob.getName());
/* 134 */       output.append("): ");
/*     */     } 
/* 136 */     output.append(message);
/* 137 */     DEBUG_TRACE.trace(null, output.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void debug(Throwable t) {
/* 144 */     StringWriter writer = new StringWriter();
/* 145 */     t.printStackTrace(new PrintWriter(writer));
/* 146 */     String str = writer.toString();
/* 147 */     if (str.endsWith("\n"))
/* 148 */       str = str.substring(0, str.length() - 2); 
/* 149 */     debug(str);
/*     */   }
/*     */   
/*     */   public static void log(int severity, String message, Throwable t) {
/* 153 */     if (message == null)
/* 154 */       message = ""; 
/* 155 */     log((IStatus)new Status(severity, "org.eclipse.core.resources", 1, message, t));
/*     */   }
/*     */   
/*     */   public static void log(IStatus status) {
/* 159 */     Bundle bundle = Platform.getBundle("org.eclipse.core.resources");
/* 160 */     if (bundle == null)
/*     */       return; 
/* 162 */     Platform.getLog(bundle).log(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void log(Throwable t) {
/* 170 */     log(4, "Internal Error", t);
/*     */   }
/*     */   
/*     */   public static IProgressMonitor monitorFor(IProgressMonitor monitor) {
/* 174 */     return (monitor == null) ? (IProgressMonitor)new NullProgressMonitor() : monitor;
/*     */   }
/*     */   
/*     */   public static IProgressMonitor subMonitorFor(IProgressMonitor monitor, int ticks) {
/* 178 */     if (monitor == null)
/* 179 */       return (IProgressMonitor)new NullProgressMonitor(); 
/* 180 */     if (monitor instanceof NullProgressMonitor)
/* 181 */       return monitor; 
/* 182 */     return (IProgressMonitor)new SubProgressMonitor(monitor, ticks);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\interna\\utils\Policy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */