package org.eclipse.core.resources.team;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;

public interface IResourceTree {
  public static final long NULL_TIMESTAMP = 0L;
  
  void addToLocalHistory(IFile paramIFile);
  
  boolean isSynchronized(IResource paramIResource, int paramInt);
  
  long computeTimestamp(IFile paramIFile);
  
  long getTimestamp(IFile paramIFile);
  
  void updateMovedFileTimestamp(IFile paramIFile, long paramLong);
  
  void failed(IStatus paramIStatus);
  
  void deletedFile(IFile paramIFile);
  
  void deletedFolder(IFolder paramIFolder);
  
  void deletedProject(IProject paramIProject);
  
  void movedFile(IFile paramIFile1, IFile paramIFile2);
  
  void movedFolderSubtree(IFolder paramIFolder1, IFolder paramIFolder2);
  
  boolean movedProjectSubtree(IProject paramIProject, IProjectDescription paramIProjectDescription);
  
  void standardDeleteFile(IFile paramIFile, int paramInt, IProgressMonitor paramIProgressMonitor);
  
  void standardDeleteFolder(IFolder paramIFolder, int paramInt, IProgressMonitor paramIProgressMonitor);
  
  void standardDeleteProject(IProject paramIProject, int paramInt, IProgressMonitor paramIProgressMonitor);
  
  void standardMoveFile(IFile paramIFile1, IFile paramIFile2, int paramInt, IProgressMonitor paramIProgressMonitor);
  
  void standardMoveFolder(IFolder paramIFolder1, IFolder paramIFolder2, int paramInt, IProgressMonitor paramIProgressMonitor);
  
  void standardMoveProject(IProject paramIProject, IProjectDescription paramIProjectDescription, int paramInt, IProgressMonitor paramIProgressMonitor);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\team\IResourceTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */