/*     */ package org.eclipse.core.internal.utils;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.IJobManager;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.core.runtime.jobs.MultiRule;
/*     */ import org.osgi.framework.Bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringPoolJob
/*     */   extends Job
/*     */ {
/*     */   private static final long INITIAL_DELAY = 300000L;
/*     */   private static final long RESCHEDULE_DELAY = 900000L;
/*     */   private long lastDuration;
/*  34 */   private Map<IStringPoolParticipant, ISchedulingRule> participants = Collections.synchronizedMap(new HashMap<>(10));
/*     */   
/*  36 */   private final Bundle systemBundle = Platform.getBundle("org.eclipse.osgi");
/*     */   
/*     */   public StringPoolJob() {
/*  39 */     super(Messages.utils_stringJobName);
/*  40 */     setSystem(true);
/*  41 */     setPriority(50);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addStringPoolParticipant(IStringPoolParticipant participant, ISchedulingRule rule) {
/*  63 */     this.participants.put(participant, rule);
/*  64 */     if (getState() == 1) {
/*  65 */       wakeUp(300000L);
/*     */     } else {
/*  67 */       schedule(300000L);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeStringPoolParticipant(IStringPoolParticipant participant) {
/*  79 */     this.participants.remove(participant);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected IStatus run(IProgressMonitor monitor) {
/*  85 */     if (this.systemBundle.getState() == 16) {
/*  86 */       return Status.OK_STATUS;
/*     */     }
/*     */     
/*  89 */     Map.Entry[] entries = (Map.Entry[])this.participants.entrySet().toArray((Object[])new Map.Entry[this.participants.size()]);
/*  90 */     ISchedulingRule[] rules = new ISchedulingRule[entries.length];
/*  91 */     IStringPoolParticipant[] toRun = new IStringPoolParticipant[entries.length];
/*  92 */     for (int i = 0; i < toRun.length; i++) {
/*  93 */       toRun[i] = entries[i].getKey();
/*  94 */       rules[i] = entries[i].getValue();
/*     */     } 
/*  96 */     ISchedulingRule rule = MultiRule.combine(rules);
/*  97 */     long start = -1L;
/*  98 */     int savings = 0;
/*  99 */     IJobManager jobManager = Job.getJobManager();
/*     */     try {
/* 101 */       jobManager.beginRule(rule, monitor);
/* 102 */       start = System.currentTimeMillis();
/* 103 */       savings = shareStrings(toRun, monitor);
/*     */     } finally {
/* 105 */       jobManager.endRule(rule);
/*     */     } 
/* 107 */     if (start > 0L) {
/* 108 */       this.lastDuration = System.currentTimeMillis() - start;
/* 109 */       if (Policy.DEBUG_STRINGS) {
/* 110 */         Policy.debug("String sharing saved " + savings + " bytes in: " + this.lastDuration);
/*     */       }
/*     */     } 
/* 113 */     long scheduleDelay = Math.max(900000L, this.lastDuration * 100L);
/* 114 */     if (Policy.DEBUG_STRINGS)
/* 115 */       Policy.debug("Rescheduling string sharing job in: " + scheduleDelay); 
/* 116 */     schedule(scheduleDelay);
/* 117 */     return Status.OK_STATUS;
/*     */   }
/*     */   
/*     */   private int shareStrings(IStringPoolParticipant[] toRun, IProgressMonitor monitor) {
/* 121 */     final StringPool pool = new StringPool(); byte b; int i; IStringPoolParticipant[] arrayOfIStringPoolParticipant;
/* 122 */     for (i = (arrayOfIStringPoolParticipant = toRun).length, b = 0; b < i; ) { final IStringPoolParticipant current = arrayOfIStringPoolParticipant[b];
/* 123 */       if (monitor.isCanceled())
/*     */         break; 
/* 125 */       SafeRunner.run(new ISafeRunnable()
/*     */           {
/*     */             public void handleException(Throwable exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             public void run() {
/* 133 */               current.shareStrings(pool); }
/*     */           });
/*     */       b++; }
/*     */     
/* 137 */     return pool.getSavedStringCount();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\interna\\utils\StringPoolJob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */