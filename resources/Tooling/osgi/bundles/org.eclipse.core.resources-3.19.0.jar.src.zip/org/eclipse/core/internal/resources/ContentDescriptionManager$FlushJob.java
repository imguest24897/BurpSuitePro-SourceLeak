/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FlushJob
/*     */   extends InternalWorkspaceJob
/*     */ {
/*     */   private final Set<IPath> toFlush;
/*     */   private boolean fullFlush;
/*     */   
/*     */   public FlushJob(Workspace workspace) {
/*  53 */     super(Messages.resources_flushingContentDescriptionCache, workspace);
/*  54 */     setSystem(true);
/*  55 */     setUser(false);
/*  56 */     setPriority(30);
/*  57 */     setRule((ISchedulingRule)workspace.getRoot());
/*  58 */     this.toFlush = new LinkedHashSet<>(5);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean belongsTo(Object family) {
/*  63 */     return "org.eclipse.core.resources.contentDescriptionCacheFamily".equals(family);
/*     */   }
/*     */ 
/*     */   
/*     */   public IStatus runInWorkspace(IProgressMonitor monitor) {
/*  68 */     if (monitor.isCanceled())
/*  69 */       return Status.CANCEL_STATUS; 
/*     */     try {
/*  71 */       monitor.beginTask("", Policy.opWork);
/*     */ 
/*     */       
/*  74 */       IWorkspaceRoot iWorkspaceRoot = ContentDescriptionManager.this.workspace.getRoot();
/*     */       try {
/*  76 */         ContentDescriptionManager.this.workspace.prepareOperation((ISchedulingRule)iWorkspaceRoot, monitor);
/*  77 */         ContentDescriptionManager.this.workspace.beginOperation(true);
/*     */ 
/*     */         
/*  80 */         if (ContentDescriptionManager.this.systemBundle.getState() != 16)
/*  81 */           ContentDescriptionManager.this.doFlushCache(monitor, getPathsToFlush()); 
/*     */       } finally {
/*  83 */         ContentDescriptionManager.this.workspace.endOperation((ISchedulingRule)iWorkspaceRoot, false);
/*     */       } 
/*  85 */     } catch (OperationCanceledException operationCanceledException) {
/*  86 */       return Status.CANCEL_STATUS;
/*  87 */     } catch (CoreException e) {
/*  88 */       return e.getStatus();
/*     */     } finally {
/*  90 */       monitor.done();
/*     */     } 
/*  92 */     return Status.OK_STATUS;
/*     */   }
/*     */   
/*     */   private Set<IPath> getPathsToFlush() {
/*  96 */     synchronized (this.toFlush) {
/*     */       try {
/*  98 */         if (this.fullFlush) {
/*  99 */           return Collections.EMPTY_SET;
/*     */         }
/* 101 */         return new LinkedHashSet<>(this.toFlush);
/*     */       } finally {
/* 103 */         this.fullFlush = false;
/* 104 */         this.toFlush.clear();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void flush(IProject project) {
/* 113 */     if (Policy.DEBUG_CONTENT_TYPE_CACHE)
/* 114 */       Policy.debug("Scheduling flushing of content type cache for " + ((project == null) ? (String)Path.ROOT : (String)project.getFullPath())); 
/* 115 */     synchronized (this.toFlush) {
/* 116 */       if (!this.fullFlush)
/* 117 */         if (project == null) {
/* 118 */           this.fullFlush = true;
/*     */         } else {
/* 120 */           this.toFlush.add(project.getFullPath());
/*     */         }  
/* 122 */     }  schedule(1000L);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ContentDescriptionManager$FlushJob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */