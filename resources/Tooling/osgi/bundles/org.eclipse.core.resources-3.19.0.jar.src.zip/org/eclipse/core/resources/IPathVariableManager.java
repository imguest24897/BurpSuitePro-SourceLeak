package org.eclipse.core.resources;

import java.net.URI;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IStatus;

public interface IPathVariableManager {
  URI convertToRelative(URI paramURI, boolean paramBoolean, String paramString) throws CoreException;
  
  @Deprecated
  void setValue(String paramString, IPath paramIPath) throws CoreException;
  
  void setURIValue(String paramString, URI paramURI) throws CoreException;
  
  @Deprecated
  IPath getValue(String paramString);
  
  URI getURIValue(String paramString);
  
  String[] getPathVariableNames();
  
  void addChangeListener(IPathVariableChangeListener paramIPathVariableChangeListener);
  
  void removeChangeListener(IPathVariableChangeListener paramIPathVariableChangeListener);
  
  URI resolveURI(URI paramURI);
  
  @Deprecated
  IPath resolvePath(IPath paramIPath);
  
  boolean isDefined(String paramString);
  
  boolean isUserDefined(String paramString);
  
  IStatus validateName(String paramString);
  
  IStatus validateValue(IPath paramIPath);
  
  IStatus validateValue(URI paramURI);
  
  URI getVariableRelativePathLocation(URI paramURI);
  
  String convertToUserEditableFormat(String paramString, boolean paramBoolean);
  
  String convertFromUserEditableFormat(String paramString, boolean paramBoolean);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\IPathVariableManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */