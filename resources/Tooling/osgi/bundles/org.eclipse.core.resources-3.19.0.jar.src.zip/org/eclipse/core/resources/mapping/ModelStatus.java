/*    */ package org.eclipse.core.resources.mapping;
/*    */ 
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModelStatus
/*    */   extends Status
/*    */ {
/*    */   private final String modelProviderId;
/*    */   
/*    */   public ModelStatus(int severity, String pluginId, String modelProviderId, String message) {
/* 46 */     super(severity, pluginId, 0, message, null);
/* 47 */     Assert.isNotNull(modelProviderId);
/* 48 */     this.modelProviderId = modelProviderId;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getModelProviderId() {
/* 57 */     return this.modelProviderId;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\mapping\ModelStatus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */