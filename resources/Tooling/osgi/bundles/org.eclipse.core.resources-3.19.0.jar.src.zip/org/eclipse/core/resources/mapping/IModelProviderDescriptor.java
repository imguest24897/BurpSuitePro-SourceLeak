package org.eclipse.core.resources.mapping;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;

public interface IModelProviderDescriptor {
  String[] getExtendedModels();
  
  String getId();
  
  String getLabel();
  
  IResource[] getMatchingResources(IResource[] paramArrayOfIResource) throws CoreException;
  
  ResourceTraversal[] getMatchingTraversals(ResourceTraversal[] paramArrayOfResourceTraversal) throws CoreException;
  
  ModelProvider getModelProvider() throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\mapping\IModelProviderDescriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */