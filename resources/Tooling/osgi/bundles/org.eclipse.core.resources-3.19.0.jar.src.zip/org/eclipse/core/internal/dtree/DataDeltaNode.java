/*     */ package org.eclipse.core.internal.dtree;
/*     */ 
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataDeltaNode
/*     */   extends DataTreeNode
/*     */ {
/*     */   DataDeltaNode(String name, Object data) {
/*  30 */     super(name, data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DataDeltaNode(String name, Object data, AbstractDataTreeNode[] children) {
/*  37 */     super(name, data, children);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode asBackwardDelta(DeltaDataTree myTree, DeltaDataTree parentTree, IPath key) {
/*     */     AbstractDataTreeNode[] newChildren;
/*  46 */     if (this.children.length == 0) {
/*  47 */       newChildren = NO_CHILDREN;
/*     */     } else {
/*  49 */       newChildren = new AbstractDataTreeNode[this.children.length];
/*  50 */       for (int i = this.children.length; --i >= 0;) {
/*  51 */         newChildren[i] = this.children[i].asBackwardDelta(myTree, parentTree, key.append(this.children[i].getName()));
/*     */       }
/*     */     } 
/*  54 */     return new DataDeltaNode(this.name, parentTree.getData(key), newChildren);
/*     */   }
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode compareWithParent(IPath key, DeltaDataTree parent, IComparator comparator) {
/*  59 */     AbstractDataTreeNode[] comparedChildren = compareWithParent(this.children, key, parent, comparator);
/*  60 */     Object oldData = parent.getData(key);
/*  61 */     Object newData = this.data;
/*     */     
/*  63 */     int userComparison = 0;
/*  64 */     if (!parent.isRoot(key))
/*     */     {
/*  66 */       userComparison = comparator.compare(oldData, newData);
/*     */     }
/*  68 */     return new DataTreeNode(key.lastSegment(), new NodeComparison(oldData, newData, 4, userComparison), comparedChildren);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode copy() {
/*     */     AbstractDataTreeNode[] childrenCopy;
/*  78 */     if (this.children.length == 0) {
/*  79 */       childrenCopy = NO_CHILDREN;
/*     */     } else {
/*  81 */       childrenCopy = new AbstractDataTreeNode[this.children.length];
/*  82 */       System.arraycopy(this.children, 0, childrenCopy, 0, this.children.length);
/*     */     } 
/*  84 */     return new DataDeltaNode(this.name, this.data, childrenCopy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isDelta() {
/*  93 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode simplifyWithParent(IPath key, DeltaDataTree parent, IComparator comparer) {
/* 101 */     AbstractDataTreeNode[] simplifiedChildren = simplifyWithParent(this.children, key, parent, comparer);
/*     */     
/* 103 */     if (!key.isRoot() && comparer.compare(parent.getData(key), this.data) == 0)
/* 104 */       return new NoDataDeltaNode(this.name, simplifiedChildren); 
/* 105 */     return new DataDeltaNode(this.name, this.data, simplifiedChildren);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int type() {
/* 113 */     return 1;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\dtree\DataDeltaNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */