/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceChangeEvent;
/*     */ import org.eclipse.core.resources.IResourceChangeListener;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.resources.ProjectScope;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharsetManager
/*     */   implements IManager
/*     */ {
/*     */   private static final String PROJECT_KEY = "<project>";
/*     */   private CharsetDeltaJob charsetListener;
/*     */   CharsetManagerJob job;
/*     */   private IResourceChangeListener resourceChangeListener;
/*     */   private IEclipsePreferences.IPreferenceChangeListener preferenceChangeListener;
/*     */   
/*     */   private class CharsetManagerJob
/*     */     extends Job
/*     */   {
/*     */     private static final int CHARSET_UPDATE_DELAY = 500;
/*  47 */     private List<Map.Entry<IProject, Boolean>> asyncChanges = new ArrayList<>();
/*     */     
/*     */     public CharsetManagerJob() {
/*  50 */       super(Messages.resources_charsetUpdating);
/*  51 */       setSystem(true);
/*  52 */       setPriority(10);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean belongsTo(Object family) {
/*  57 */       return (CharsetManager.class == family);
/*     */     }
/*     */     
/*     */     public void addChanges(Map<IProject, Boolean> newChanges) {
/*  61 */       if (newChanges.isEmpty())
/*     */         return; 
/*  63 */       synchronized (this.asyncChanges) {
/*  64 */         this.asyncChanges.addAll(newChanges.entrySet());
/*  65 */         this.asyncChanges.notify();
/*     */       } 
/*  67 */       schedule(500L);
/*     */     }
/*     */     
/*     */     public Map.Entry<IProject, Boolean> getNextChange() {
/*  71 */       synchronized (this.asyncChanges) {
/*  72 */         return this.asyncChanges.isEmpty() ? null : this.asyncChanges.remove(this.asyncChanges.size() - 1);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     protected IStatus run(IProgressMonitor monitor) {
/*  78 */       MultiStatus result = new MultiStatus("org.eclipse.core.resources", 382, Messages.resources_updatingEncoding, null);
/*  79 */       monitor = Policy.monitorFor(monitor);
/*     */       
/*  81 */       try { monitor.beginTask(Messages.resources_charsetUpdating, 100);
/*  82 */         ISchedulingRule rule = CharsetManager.this.workspace.getRuleFactory().modifyRule((IResource)CharsetManager.this.workspace.getRoot());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */          }
/*     */       
/* 114 */       catch (CoreException ce)
/* 115 */       { return ce.getStatus(); }
/*     */       finally
/* 117 */       { monitor.done(); }  monitor.done();
/*     */       
/* 119 */       return (IStatus)result;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean shouldRun() {
/* 124 */       synchronized (this.asyncChanges) {
/* 125 */         return !this.asyncChanges.isEmpty();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class ResourceChangeListener
/*     */     implements IResourceChangeListener
/*     */   {
/*     */     private boolean moveSettingsIfDerivedChanged(IResourceDelta parent, IProject currentProject, Preferences projectPrefs, String[] affectedResources) {
/* 135 */       boolean resourceChanges = false;
/*     */       
/* 137 */       if ((parent.getFlags() & 0x400000) != 0) {
/*     */         
/* 139 */         IPath parentPath = parent.getResource().getProjectRelativePath(); byte b1; int j; String[] arrayOfString;
/* 140 */         for (j = (arrayOfString = affectedResources).length, b1 = 0; b1 < j; ) { String affectedResource = arrayOfString[b1];
/* 141 */           Path path = new Path(affectedResource);
/*     */           
/* 143 */           if (parentPath.isPrefixOf((IPath)path)) {
/* 144 */             IResource member = currentProject.findMember((IPath)path);
/* 145 */             if (member != null) {
/* 146 */               Preferences targetPrefs = CharsetManager.this.getPreferences(currentProject, true, member.isDerived(512));
/*     */               
/* 148 */               if (!projectPrefs.absolutePath().equals(targetPrefs.absolutePath())) {
/*     */                 
/* 150 */                 String currentValue = projectPrefs.get(affectedResource, null);
/* 151 */                 projectPrefs.remove(affectedResource);
/* 152 */                 targetPrefs.put(affectedResource, currentValue);
/* 153 */                 resourceChanges = true;
/*     */               } 
/*     */             } 
/*     */           }  b1++; }
/*     */       
/*     */       }  byte b; int i;
/*     */       IResourceDelta[] arrayOfIResourceDelta;
/* 160 */       for (i = (arrayOfIResourceDelta = parent.getAffectedChildren()).length, b = 0; b < i; ) { IResourceDelta child = arrayOfIResourceDelta[b];
/* 161 */         resourceChanges = !(!moveSettingsIfDerivedChanged(child, currentProject, projectPrefs, affectedResources) && !resourceChanges); b++; }
/*     */       
/* 163 */       return resourceChanges;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void processEntryChanges(IResourceDelta projectDelta, Map<IProject, Boolean> projectsToSave) {
/* 169 */       IProject currentProject = (IProject)projectDelta.getResource();
/* 170 */       Preferences projectRegularPrefs = CharsetManager.this.getPreferences(currentProject, false, false, true);
/* 171 */       Preferences projectDerivedPrefs = CharsetManager.this.getPreferences(currentProject, false, true, true);
/* 172 */       Map<Boolean, String[]> affectedResourcesMap = (Map)new HashMap<>();
/*     */       
/*     */       try {
/* 175 */         if (projectRegularPrefs == null) {
/* 176 */           affectedResourcesMap.put(Boolean.FALSE, new String[0]);
/*     */         } else {
/* 178 */           affectedResourcesMap.put(Boolean.FALSE, projectRegularPrefs.keys());
/*     */         } 
/* 180 */         if (projectDerivedPrefs == null)
/* 181 */         { affectedResourcesMap.put(Boolean.TRUE, new String[0]); }
/*     */         else
/* 183 */         { affectedResourcesMap.put(Boolean.TRUE, projectDerivedPrefs.keys()); } 
/* 184 */       } catch (BackingStoreException e) {
/*     */         
/* 186 */         String message = Messages.resources_readingEncoding;
/* 187 */         Policy.log((IStatus)new ResourceStatus(383, currentProject.getFullPath(), message, (Throwable)e));
/*     */         return;
/*     */       } 
/* 190 */       for (Map.Entry<Boolean, String[]> entry : affectedResourcesMap.entrySet()) {
/* 191 */         Boolean isDerived = entry.getKey();
/* 192 */         String[] affectedResources = entry.getValue();
/* 193 */         Preferences projectPrefs = isDerived.booleanValue() ? projectDerivedPrefs : projectRegularPrefs; byte b; int i; String[] arrayOfString1;
/* 194 */         for (i = (arrayOfString1 = affectedResources).length, b = 0; b < i; ) { String affectedResource = arrayOfString1[b];
/* 195 */           IResourceDelta memberDelta = projectDelta.findMember((IPath)new Path(affectedResource));
/*     */           
/* 197 */           if (memberDelta != null)
/*     */           {
/* 199 */             if (memberDelta.getKind() == 2) {
/* 200 */               boolean shouldDisableCharsetDeltaJobForCurrentProject = false;
/*     */               
/* 202 */               String currentValue = projectPrefs.get(affectedResource, null);
/* 203 */               projectPrefs.remove(affectedResource);
/* 204 */               if ((memberDelta.getFlags() & 0x2000) != 0) {
/* 205 */                 IPath movedToPath = memberDelta.getMovedToPath();
/* 206 */                 IResource resource = CharsetManager.this.workspace.getRoot().findMember(movedToPath);
/* 207 */                 if (resource != null) {
/* 208 */                   Preferences encodingSettings = CharsetManager.this.getPreferences(resource.getProject(), true, resource.isDerived(512));
/* 209 */                   if (currentValue == null || currentValue.trim().length() == 0) {
/* 210 */                     encodingSettings.remove(CharsetManager.getKeyFor(movedToPath));
/*     */                   } else {
/* 212 */                     encodingSettings.put(CharsetManager.getKeyFor(movedToPath), currentValue);
/* 213 */                   }  IProject targetProject = CharsetManager.this.workspace.getRoot().getProject(movedToPath.segment(0));
/* 214 */                   if (targetProject.equals(currentProject)) {
/*     */                     
/* 216 */                     shouldDisableCharsetDeltaJobForCurrentProject = true;
/*     */                   } else {
/* 218 */                     projectsToSave.put(targetProject, Boolean.FALSE);
/*     */                   } 
/*     */                 } 
/* 221 */               }  projectsToSave.put(currentProject, Boolean.valueOf(shouldDisableCharsetDeltaJobForCurrentProject));
/*     */             }  }  b++; }
/*     */         
/* 224 */         if (moveSettingsIfDerivedChanged(projectDelta, currentProject, projectPrefs, affectedResources))
/*     */         {
/* 226 */           projectsToSave.put(currentProject, Boolean.TRUE);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void resourceChanged(IResourceChangeEvent event) {
/* 237 */       IResourceDelta delta = event.getDelta();
/* 238 */       if (delta == null)
/*     */         return; 
/* 240 */       IResourceDelta[] projectDeltas = delta.getAffectedChildren();
/*     */       
/* 242 */       Map<IProject, Boolean> projectsToSave = new HashMap<>(); byte b; int i; IResourceDelta[] arrayOfIResourceDelta1;
/* 243 */       for (i = (arrayOfIResourceDelta1 = projectDeltas).length, b = 0; b < i; ) { IResourceDelta projectDelta = arrayOfIResourceDelta1[b];
/*     */         
/* 245 */         if (projectDelta.getKind() == 4 && (projectDelta.getFlags() & 0x4000) == 0)
/* 246 */           processEntryChanges(projectDelta, projectsToSave);  b++; }
/* 247 */        CharsetManager.this.job.addChanges(projectsToSave);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 256 */   protected final Bundle systemBundle = Platform.getBundle("org.eclipse.osgi");
/*     */   Workspace workspace;
/*     */   
/*     */   public CharsetManager(Workspace workspace) {
/* 260 */     this.workspace = workspace;
/*     */   }
/*     */   
/*     */   void flushPreferences(Preferences projectPrefs, boolean shouldDisableCharsetDeltaJob) throws BackingStoreException {
/* 264 */     if (projectPrefs != null) {
/*     */       try {
/* 266 */         if (shouldDisableCharsetDeltaJob)
/* 267 */           this.charsetListener.setDisabled(true); 
/* 268 */         projectPrefs.flush();
/*     */       } finally {
/* 270 */         if (shouldDisableCharsetDeltaJob) {
/* 271 */           this.charsetListener.setDisabled(false);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCharsetFor(IPath resourcePath, boolean recurse) {
/* 287 */     Assert.isLegal((resourcePath.segmentCount() >= 1));
/* 288 */     IProject project = this.workspace.getRoot().getProject(resourcePath.segment(0));
/*     */     
/* 290 */     Preferences prefs = getPreferences(project, false, false);
/* 291 */     Preferences derivedPrefs = getPreferences(project, false, true);
/*     */     
/* 293 */     if (prefs == null && derivedPrefs == null)
/*     */     {
/*     */       
/* 296 */       return recurse ? ResourcesPlugin.getEncoding() : null;
/*     */     }
/* 298 */     return internalGetCharsetFor(prefs, derivedPrefs, resourcePath, recurse);
/*     */   }
/*     */   
/*     */   static String getKeyFor(IPath resourcePath) {
/* 302 */     return (resourcePath.segmentCount() > 1) ? resourcePath.removeFirstSegments(1).toString() : "<project>";
/*     */   }
/*     */   
/*     */   Preferences getPreferences(IProject project, boolean create, boolean isDerived) {
/* 306 */     return getPreferences(project, create, isDerived, isDerivedEncodingStoredSeparately(project));
/*     */   }
/*     */   
/*     */   Preferences getPreferences(IProject project, boolean create, boolean isDerived, boolean isDerivedEncodingStoredSeparately) {
/* 310 */     boolean localIsDerived = isDerivedEncodingStoredSeparately ? isDerived : false;
/* 311 */     String qualifier = localIsDerived ? "org.eclipse.core.resources.derived" : "org.eclipse.core.resources";
/* 312 */     if (create)
/*     */     {
/* 314 */       return (new ProjectScope(project)).getNode(qualifier).node("encoding");
/*     */     }
/* 316 */     Preferences node = Platform.getPreferencesService().getRootNode().node("project");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 322 */       if (!node.nodeExists(project.getName()))
/* 323 */         return null; 
/* 324 */       node = node.node(project.getName());
/* 325 */       if (!node.nodeExists(qualifier))
/* 326 */         return null; 
/* 327 */       node = node.node(qualifier);
/* 328 */       if (!node.nodeExists("encoding"))
/* 329 */         return null; 
/* 330 */       return node.node("encoding");
/* 331 */     } catch (BackingStoreException e) {
/*     */       
/* 333 */       String message = Messages.resources_readingEncoding;
/* 334 */       Policy.log((IStatus)new ResourceStatus(383, project.getFullPath(), message, (Throwable)e));
/*     */       
/* 336 */       return null;
/*     */     } 
/*     */   }
/*     */   private String internalGetCharsetFor(Preferences prefs, Preferences derivedPrefs, IPath resourcePath, boolean recurse) {
/* 340 */     String charset = null;
/*     */ 
/*     */     
/* 343 */     if (prefs != null) {
/* 344 */       charset = prefs.get(getKeyFor(resourcePath), null);
/*     */     }
/*     */     
/* 347 */     if (charset == null && derivedPrefs != null) {
/* 348 */       charset = derivedPrefs.get(getKeyFor(resourcePath), null);
/*     */     }
/* 350 */     if (!recurse) {
/* 351 */       return charset;
/*     */     }
/* 353 */     while (charset == null && resourcePath.segmentCount() > 1) {
/* 354 */       resourcePath = resourcePath.removeLastSegments(1);
/*     */       
/* 356 */       if (prefs != null)
/* 357 */         charset = prefs.get(getKeyFor(resourcePath), null); 
/* 358 */       if (charset == null && derivedPrefs != null) {
/* 359 */         charset = derivedPrefs.get(getKeyFor(resourcePath), null);
/*     */       }
/*     */     } 
/*     */     
/* 363 */     return (charset == null) ? ResourcesPlugin.getEncoding() : charset;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isDerivedEncodingStoredSeparately(IProject project) {
/* 368 */     Preferences node = Platform.getPreferencesService().getRootNode().node("project");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 374 */       if (!node.nodeExists(project.getName()))
/* 375 */         return false; 
/* 376 */       node = node.node(project.getName());
/* 377 */       if (!node.nodeExists("org.eclipse.core.resources"))
/* 378 */         return false; 
/* 379 */       node = node.node("org.eclipse.core.resources");
/* 380 */       return node.getBoolean("separateDerivedEncodings", false);
/* 381 */     } catch (BackingStoreException e) {
/*     */       
/* 383 */       String message = Messages.resources_readingEncoding;
/* 384 */       Policy.log((IStatus)new ResourceStatus(383, project.getFullPath(), message, (Throwable)e));
/* 385 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void mergeEncodingPreferences(IProject project) {
/* 390 */     Preferences projectRegularPrefs = null;
/* 391 */     Preferences projectDerivedPrefs = getPreferences(project, false, true, true);
/* 392 */     if (projectDerivedPrefs == null)
/*     */       return; 
/*     */     try {
/* 395 */       boolean prefsChanged = false;
/*     */       
/* 397 */       String[] affectedResources = projectDerivedPrefs.keys(); byte b; int i; String[] arrayOfString1;
/* 398 */       for (i = (arrayOfString1 = affectedResources).length, b = 0; b < i; ) { String path = arrayOfString1[b];
/* 399 */         String value = projectDerivedPrefs.get(path, null);
/* 400 */         projectDerivedPrefs.remove(path);
/*     */         
/* 402 */         if (projectRegularPrefs == null)
/* 403 */           projectRegularPrefs = getPreferences(project, true, false, false); 
/* 404 */         projectRegularPrefs.put(path, value);
/* 405 */         prefsChanged = true; b++; }
/*     */       
/* 407 */       if (prefsChanged) {
/* 408 */         Map<IProject, Boolean> projectsToSave = new HashMap<>();
/*     */         
/* 410 */         projectsToSave.put(project, Boolean.TRUE);
/* 411 */         this.job.addChanges(projectsToSave);
/*     */       } 
/* 413 */     } catch (BackingStoreException e) {
/*     */       
/* 415 */       String message = Messages.resources_readingEncoding;
/* 416 */       Policy.log((IStatus)new ResourceStatus(383, project.getFullPath(), message, (Throwable)e));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void projectPreferencesChanged(IProject project) {
/* 421 */     this.charsetListener.charsetPreferencesChanged(project);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCharsetFor(IPath resourcePath, String newCharset) throws CoreException {
/* 426 */     if (resourcePath.segmentCount() == 0) {
/* 427 */       IEclipsePreferences resourcesPreferences = InstanceScope.INSTANCE.getNode("org.eclipse.core.resources");
/* 428 */       if (newCharset != null) {
/* 429 */         resourcesPreferences.put("encoding", newCharset);
/*     */       } else {
/* 431 */         resourcesPreferences.remove("encoding");
/*     */       }  try {
/* 433 */         resourcesPreferences.flush();
/* 434 */       } catch (BackingStoreException e) {
/* 435 */         IProject project = this.workspace.getRoot().getProject(resourcePath.segment(0));
/* 436 */         String message = Messages.resources_savingEncoding;
/* 437 */         throw new ResourceException(382, project.getFullPath(), message, e);
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 442 */     IResource resource = this.workspace.getRoot().findMember(resourcePath);
/* 443 */     if (resource != null) {
/*     */       
/*     */       try {
/* 446 */         Preferences encodingSettings = getPreferences(resource.getProject(), true, resource.isDerived(512));
/* 447 */         if (newCharset == null || newCharset.trim().length() == 0) {
/* 448 */           encodingSettings.remove(getKeyFor(resourcePath));
/*     */         } else {
/* 450 */           encodingSettings.put(getKeyFor(resourcePath), newCharset);
/* 451 */         }  flushPreferences(encodingSettings, true);
/* 452 */         if (resource instanceof IProject) {
/* 453 */           IProject project = (IProject)resource;
/* 454 */           ValidateProjectEncoding.scheduleProjectValidation(this.workspace, project);
/*     */         } 
/* 456 */       } catch (BackingStoreException e) {
/* 457 */         IProject project = this.workspace.getRoot().getProject(resourcePath.segment(0));
/* 458 */         String message = Messages.resources_savingEncoding;
/* 459 */         throw new ResourceException(382, project.getFullPath(), message, e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void shutdown(IProgressMonitor monitor) {
/* 466 */     InstanceScope.INSTANCE.getNode("org.eclipse.core.resources")
/* 467 */       .removePreferenceChangeListener(this.preferenceChangeListener);
/*     */     
/* 469 */     this.workspace.removeResourceChangeListener(this.resourceChangeListener);
/* 470 */     if (this.charsetListener != null)
/* 471 */       this.charsetListener.shutdown(); 
/*     */   }
/*     */   
/*     */   protected void splitEncodingPreferences(IProject project) {
/* 475 */     Preferences projectRegularPrefs = getPreferences(project, false, false, false);
/* 476 */     Preferences projectDerivedPrefs = null;
/* 477 */     if (projectRegularPrefs == null)
/*     */       return; 
/*     */     try {
/* 480 */       boolean prefsChanged = false;
/*     */       
/* 482 */       String[] affectedResources = projectRegularPrefs.keys(); byte b; int i; String[] arrayOfString1;
/* 483 */       for (i = (arrayOfString1 = affectedResources).length, b = 0; b < i; ) { String path = arrayOfString1[b];
/* 484 */         IResource resource = project.findMember(path);
/* 485 */         if (resource != null && 
/* 486 */           resource.isDerived(512)) {
/* 487 */           String value = projectRegularPrefs.get(path, null);
/* 488 */           projectRegularPrefs.remove(path);
/*     */           
/* 490 */           if (projectDerivedPrefs == null)
/* 491 */             projectDerivedPrefs = getPreferences(project, true, true, true); 
/* 492 */           projectDerivedPrefs.put(path, value);
/* 493 */           prefsChanged = true;
/*     */         } 
/*     */         b++; }
/*     */       
/* 497 */       if (prefsChanged) {
/* 498 */         Map<IProject, Boolean> projectsToSave = new HashMap<>();
/*     */         
/* 500 */         projectsToSave.put(project, Boolean.TRUE);
/* 501 */         this.job.addChanges(projectsToSave);
/*     */       } 
/* 503 */     } catch (BackingStoreException e) {
/*     */       
/* 505 */       String message = Messages.resources_readingEncoding;
/* 506 */       Policy.log((IStatus)new ResourceStatus(383, project.getFullPath(), message, (Throwable)e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void startup(IProgressMonitor monitor) {
/* 512 */     this.job = new CharsetManagerJob();
/* 513 */     this.resourceChangeListener = new ResourceChangeListener();
/* 514 */     this.workspace.addResourceChangeListener(this.resourceChangeListener, 1);
/* 515 */     this.charsetListener = new CharsetDeltaJob(this.workspace);
/* 516 */     this.charsetListener.startup();
/* 517 */     ValidateProjectEncoding.scheduleWorkspaceValidation(this.workspace);
/* 518 */     initPreferenceChangeListener();
/*     */   }
/*     */   
/*     */   private void initPreferenceChangeListener() {
/* 522 */     this.preferenceChangeListener = (event -> {
/*     */         if ("missingEncodingMarkerSeverity".equals(event.getKey())) {
/*     */           ValidateProjectEncoding.scheduleWorkspaceValidation(this.workspace);
/*     */         }
/*     */       });
/*     */     
/* 528 */     InstanceScope.INSTANCE.getNode("org.eclipse.core.resources")
/* 529 */       .addPreferenceChangeListener(this.preferenceChangeListener);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\CharsetManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */