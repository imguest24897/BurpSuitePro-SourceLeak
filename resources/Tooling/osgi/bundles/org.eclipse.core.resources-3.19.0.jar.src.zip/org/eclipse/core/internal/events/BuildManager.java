/*      */ package org.eclipse.core.internal.events;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.function.Supplier;
/*      */ import org.eclipse.core.internal.resources.ComputeProjectOrder;
/*      */ import org.eclipse.core.internal.resources.Project;
/*      */ import org.eclipse.core.internal.resources.Workspace;
/*      */ import org.eclipse.core.internal.utils.Messages;
/*      */ import org.eclipse.core.internal.utils.Policy;
/*      */ import org.eclipse.core.internal.watson.ElementTree;
/*      */ import org.eclipse.core.resources.IBuildConfiguration;
/*      */ import org.eclipse.core.resources.IBuildContext;
/*      */ import org.eclipse.core.resources.ICommand;
/*      */ import org.eclipse.core.resources.IProject;
/*      */ import org.eclipse.core.resources.IProjectDescription;
/*      */ import org.eclipse.core.resources.IResourceDelta;
/*      */ import org.eclipse.core.resources.IncrementalProjectBuilder;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IConfigurationElement;
/*      */ import org.eclipse.core.runtime.IExtension;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.ISafeRunnable;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.MultiStatus;
/*      */ import org.eclipse.core.runtime.OperationCanceledException;
/*      */ import org.eclipse.core.runtime.QualifiedName;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.core.runtime.jobs.ILock;
/*      */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*      */ import org.eclipse.core.runtime.jobs.Job;
/*      */ import org.eclipse.core.runtime.jobs.JobGroup;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ 
/*      */ public class BuildManager implements ICoreConstants, IManager, ILifecycleListener {
/*      */   private static final String BUILDER_INIT = "BuilderInitInfo";
/*      */   private static final int TOTAL_BUILD_WORK = 100000;
/*      */   final AutoBuildJob autoBuildJob;
/*      */   
/*      */   static class DeltaCache<E> {
/*   47 */     private final Map<IPath, E> deltas = new HashMap<>();
/*      */     private ElementTree newTree;
/*      */     private ElementTree oldTree;
/*      */     
/*      */     public void flush() {
/*   52 */       this.deltas.clear();
/*   53 */       this.oldTree = null;
/*   54 */       this.newTree = null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public E computeIfAbsent(IPath project, ElementTree anOldTree, ElementTree aNewTree, Supplier<E> calculator) {
/*   62 */       if (!areEqual(this.oldTree, anOldTree) || !areEqual(this.newTree, aNewTree)) {
/*   63 */         this.oldTree = anOldTree;
/*   64 */         this.newTree = aNewTree;
/*   65 */         this.deltas.clear();
/*      */       } 
/*   67 */       return this.deltas.computeIfAbsent(project, p -> param1Supplier.get());
/*      */     }
/*      */     
/*      */     private static boolean areEqual(ElementTree cached, ElementTree requested) {
/*   71 */       return !ElementTree.hasChanges(requested, cached, ResourceComparator.getBuildComparator(), true);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   class MissingBuilder
/*      */     extends IncrementalProjectBuilder
/*      */   {
/*      */     private boolean hasBeenBuilt = false;
/*      */     private String name;
/*      */     
/*      */     MissingBuilder(String name) {
/*   83 */       this.name = name;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected IProject[] build(int kind, Map<String, String> args, IProgressMonitor monitor) {
/*   91 */       if (!this.hasBeenBuilt && Policy.DEBUG_BUILD_FAILURE) {
/*   92 */         this.hasBeenBuilt = true;
/*   93 */         String msg = NLS.bind(Messages.events_skippingBuilder, this.name, getProject().getName());
/*   94 */         Policy.log(2, msg, null);
/*      */       } 
/*   96 */       return null;
/*      */     }
/*      */     
/*      */     String getName() {
/*  100 */       return this.name;
/*      */     }
/*      */ 
/*      */     
/*      */     public ISchedulingRule getRule(int kind, Map<String, String> args) {
/*  105 */       return null;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  114 */   private final Set<IProject> builtProjects = Collections.synchronizedSet(new HashSet<>());
/*      */ 
/*      */   
/*      */   protected final Set<InternalBuilder> currentBuilders;
/*      */ 
/*      */   
/*      */   private ElementTree currentLastBuiltTree;
/*      */   
/*      */   private ElementTree currentTree;
/*      */   
/*  124 */   private final DeltaCache<IResourceDelta> deltaCache = new DeltaCache<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ILock lock;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean earlyExitFromBuildLoopAllowed;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean rebuildRequested;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Set<IProject> projectsToRebuild;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Map<IProject, Boolean> restartBuildImmediately;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean parallelBuild;
/*      */ 
/*      */ 
/*      */   
/*  158 */   private final Bundle systemBundle = Platform.getBundle("org.eclipse.osgi");
/*      */ 
/*      */   
/*  161 */   private Object builderInitializationLock = new Object();
/*      */ 
/*      */   
/*  164 */   private long timeStamp = -1L;
/*  165 */   private long overallTimeStamp = -1L;
/*      */   private Workspace workspace;
/*      */   
/*      */   public BuildManager(Workspace workspace, ILock workspaceLock) {
/*  169 */     this.workspace = workspace;
/*  170 */     this.currentBuilders = Collections.synchronizedSet(new HashSet<>());
/*  171 */     this.autoBuildJob = new AutoBuildJob(workspace);
/*  172 */     this.projectsToRebuild = ConcurrentHashMap.newKeySet();
/*  173 */     this.restartBuildImmediately = new ConcurrentHashMap<>();
/*  174 */     this.lock = workspaceLock;
/*  175 */     InternalBuilder.buildManager = this;
/*  176 */     setEarlyExitFromBuildLoopAllowed(
/*  177 */         Boolean.getBoolean("org.eclipse.core.resources.allowEarlyBuildLoopExit"));
/*      */   }
/*      */   
/*      */   private void basicBuild(int trigger, IncrementalProjectBuilder builder, Map<String, String> args, MultiStatus status, IProgressMonitor monitor) {
/*  181 */     IncrementalProjectBuilder incrementalProjectBuilder = builder;
/*      */     try {
/*  183 */       this.currentBuilders.add(incrementalProjectBuilder);
/*      */       
/*  185 */       incrementalProjectBuilder.clearLastBuiltStateRequests();
/*      */       
/*  187 */       boolean clean = (trigger == 15);
/*  188 */       this.currentLastBuiltTree = incrementalProjectBuilder.getLastBuiltTree();
/*      */ 
/*      */       
/*  191 */       boolean isBuilding = builder.getCommand().isBuilding(trigger);
/*      */ 
/*      */       
/*  194 */       if (!clean && this.currentLastBuiltTree == null) {
/*      */         
/*  196 */         if (trigger == 9 && !isBuilding) {
/*      */           return;
/*      */         }
/*  199 */         trigger = 6;
/*  200 */         isBuilding = !(!isBuilding && !builder.getCommand().isBuilding(trigger));
/*      */       } 
/*      */ 
/*      */       
/*  204 */       if (!isBuilding) {
/*  205 */         if (clean) {
/*  206 */           incrementalProjectBuilder.setLastBuiltTree(null);
/*      */         }
/*      */         
/*      */         return;
/*      */       } 
/*  211 */       this.currentTree = (trigger == 6 || clean) ? null : this.workspace.getElementTree();
/*  212 */       int depth = -1;
/*  213 */       ISchedulingRule rule = null;
/*      */       
/*      */       try { String message;
/*  216 */         if (!needsBuild((InternalBuilder)incrementalProjectBuilder, trigger)) {
/*      */           
/*  218 */           monitor.beginTask("", 1);
/*  219 */           monitor.done();
/*      */           return;
/*      */         } 
/*  222 */         rule = builder.getRule(trigger, args);
/*  223 */         String name = incrementalProjectBuilder.getLabel();
/*      */         
/*  225 */         if (name != null) {
/*  226 */           message = NLS.bind(Messages.events_invoking_2, name, builder.getProject().getFullPath());
/*      */         } else {
/*  228 */           message = NLS.bind(Messages.events_invoking_1, builder.getProject().getFullPath());
/*      */         } 
/*  230 */         monitor.subTask(message);
/*  231 */         hookStartBuild(builder, trigger);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */          }
/*      */       
/*      */       finally
/*      */       
/*      */       { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  250 */         if (depth >= 0) {
/*  251 */           getWorkManager().endUnprotected(depth);
/*      */         }
/*  253 */         if (rule != null) {
/*  254 */           Job.getJobManager().endRule(rule);
/*      */         }
/*      */         
/*  257 */         if (clean || incrementalProjectBuilder.wasForgetStateRequested()) {
/*  258 */           incrementalProjectBuilder.setLastBuiltTree(null);
/*  259 */         } else if (incrementalProjectBuilder.wasRememberStateRequested()) {
/*      */ 
/*      */           
/*  262 */           if (trigger == 6) {
/*  263 */             incrementalProjectBuilder.setLastBuiltTree(null);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/*  268 */           ElementTree lastTree = this.workspace.getElementTree();
/*  269 */           lastTree.immutable();
/*  270 */           incrementalProjectBuilder.setLastBuiltTree(lastTree);
/*      */         } 
/*  272 */         hookEndBuild(builder); }  if (depth >= 0) getWorkManager().endUnprotected(depth);  if (rule != null) Job.getJobManager().endRule(rule);  if (clean || incrementalProjectBuilder.wasForgetStateRequested()) { incrementalProjectBuilder.setLastBuiltTree(null); } else if (incrementalProjectBuilder.wasRememberStateRequested()) { if (trigger == 6) incrementalProjectBuilder.setLastBuiltTree(null);  } else { ElementTree lastTree = this.workspace.getElementTree(); lastTree.immutable(); incrementalProjectBuilder.setLastBuiltTree(lastTree); }  hookEndBuild(builder);
/*      */     } finally {
/*      */       
/*  275 */       this.currentBuilders.remove(incrementalProjectBuilder);
/*  276 */       this.currentTree = null;
/*  277 */       this.currentLastBuiltTree = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void basicBuild(IBuildConfiguration buildConfiguration, int trigger, IBuildContext context, ICommand[] commands, MultiStatus status, IProgressMonitor monitor) {
/*  283 */     int remainingIterations = Math.max(1, this.workspace.getDescription().getMaxBuildIterations());
/*      */ 
/*      */ 
/*      */     
/*  287 */     int[] triggers = new int[commands.length];
/*  288 */     Arrays.fill(triggers, trigger);
/*  289 */     boolean shouldRebuild = true;
/*      */     try {
/*  291 */       while (shouldRebuild) {
/*  292 */         shouldRebuild = false;
/*      */ 
/*      */         
/*  295 */         int[] nextTriggers = null;
/*  296 */         for (int i = 0; i < commands.length; i++) {
/*  297 */           int currentTrigger = triggers[i];
/*  298 */           checkCanceled(currentTrigger, monitor);
/*  299 */           BuildCommand command = (BuildCommand)commands[i];
/*  300 */           IProgressMonitor sub = Policy.subMonitorFor(monitor, 1);
/*  301 */           IncrementalProjectBuilder builder = getBuilder(buildConfiguration, command, i, status, context);
/*  302 */           if (builder != null) {
/*  303 */             basicBuild(currentTrigger, builder, command.getArguments(false), status, sub);
/*      */ 
/*      */             
/*  306 */             IProject project = builder.getProject();
/*  307 */             Boolean restartImmediately = this.restartBuildImmediately.remove(project);
/*      */             
/*  309 */             remainingIterations--;
/*  310 */             if (restartImmediately != null && remainingIterations > 0) {
/*  311 */               if (!restartImmediately.booleanValue()) {
/*      */                 
/*  313 */                 shouldRebuild = true;
/*      */                 
/*  315 */                 if (trigger != 9) {
/*  316 */                   nextTriggers = new int[triggers.length];
/*  317 */                   Arrays.fill(nextTriggers, 10);
/*      */                 }
/*      */               
/*      */               }
/*  321 */               else if (i > 0) {
/*      */                 
/*  323 */                 shouldRebuild = true;
/*      */                 
/*  325 */                 if (trigger != 9) {
/*  326 */                   nextTriggers = Arrays.copyOf(triggers, triggers.length);
/*  327 */                   Arrays.fill(nextTriggers, 0, i + 1, 
/*  328 */                       10);
/*      */                 } 
/*      */                 
/*      */                 break;
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/*  337 */         if (nextTriggers != null) {
/*  338 */           triggers = nextTriggers;
/*      */         }
/*      */       } 
/*  341 */     } catch (CoreException e) {
/*  342 */       status.add(e.getStatus());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IStatus basicBuild(IBuildConfiguration buildConfiguration, int trigger, IBuildContext context, IProgressMonitor monitor) {
/*      */     try {
/*  352 */       hookStartBuild(new IBuildConfiguration[] { buildConfiguration }, trigger);
/*  353 */       MultiStatus status = new MultiStatus("org.eclipse.core.resources", 566, Messages.events_errors, null);
/*  354 */       basicBuild(buildConfiguration, trigger, context, status, monitor);
/*  355 */       return (IStatus)status;
/*      */     } finally {
/*  357 */       hookEndBuild(trigger);
/*      */     } 
/*      */   }
/*      */   private void basicBuild(final IBuildConfiguration buildConfiguration, final int trigger, final IBuildContext context, final MultiStatus status, final IProgressMonitor monitor) {
/*      */     try {
/*      */       final ICommand[] commands;
/*  363 */       final IProject project = buildConfiguration.getProject();
/*      */       
/*  365 */       if (project.isAccessible()) {
/*  366 */         commands = ((Project)project).internalGetDescription().getBuildSpec(false);
/*      */       } else {
/*  368 */         commands = null;
/*  369 */       }  int work = (commands == null) ? 0 : commands.length;
/*  370 */       monitor.beginTask(NLS.bind(Messages.events_building_1, project.getFullPath()), work);
/*  371 */       if (work == 0)
/*      */         return; 
/*  373 */       ISafeRunnable code = new ISafeRunnable()
/*      */         {
/*      */           public void handleException(Throwable e) {
/*  376 */             if (e instanceof OperationCanceledException) {
/*  377 */               if (Policy.DEBUG_BUILD_INVOKING)
/*  378 */                 Policy.debug("Build canceled"); 
/*  379 */               throw (OperationCanceledException)e;
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/*  384 */             String errorText = e.getMessage();
/*  385 */             if (errorText == null)
/*  386 */               errorText = NLS.bind(Messages.events_unknown, e.getClass().getName(), project.getName()); 
/*  387 */             status.add((IStatus)new Status(2, "org.eclipse.core.resources", 566, errorText, e));
/*      */           }
/*      */ 
/*      */           
/*      */           public void run() throws Exception {
/*  392 */             BuildManager.this.basicBuild(buildConfiguration, trigger, context, commands, status, monitor);
/*      */           }
/*      */         };
/*  395 */       SafeRunner.run(code);
/*      */     } finally {
/*  397 */       monitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IStatus basicBuild(IBuildConfiguration buildConfiguration, int trigger, String builderName, Map<String, String> args, IProgressMonitor monitor) {
/*  406 */     IProject project = buildConfiguration.getProject();
/*  407 */     monitor = Policy.monitorFor(monitor);
/*      */     try {
/*  409 */       String message = NLS.bind(Messages.events_building_1, project.getFullPath());
/*  410 */       monitor.beginTask(message, 1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  428 */       monitor.done();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void basicBuildLoop(IBuildConfiguration[] configs, IBuildConfiguration[] requestedConfigs, int trigger, MultiStatus status, IProgressMonitor monitor) {
/*  436 */     int projectWork = (configs.length > 0) ? (100000 / configs.length) : 0;
/*  437 */     int maxIterations = this.workspace.getDescription().getMaxBuildIterations();
/*      */ 
/*      */     
/*  440 */     maxIterations = Math.max(configs.length * 2, maxIterations);
/*  441 */     if (maxIterations <= 0) {
/*  442 */       maxIterations = 1;
/*      */     }
/*      */     
/*  445 */     this.rebuildRequested = true;
/*  446 */     boolean rebuildSomething = true;
/*  447 */     for (int iter = 0; rebuildSomething && iter < maxIterations; iter++) {
/*      */       
/*  449 */       boolean rebuildAll = this.rebuildRequested;
/*  450 */       boolean lastIteration = (iter == maxIterations - 1);
/*      */       
/*  452 */       if (rebuildAll) {
/*      */         
/*  454 */         basicBuildLoop(configs, requestedConfigs, trigger, status, monitor, projectWork, lastIteration);
/*      */       } else {
/*      */         
/*  457 */         List<IBuildConfiguration> allConfigs = Arrays.asList(this.workspace.getBuildOrder());
/*  458 */         IBuildConfiguration[] configurations = (IBuildConfiguration[])allConfigs.stream()
/*  459 */           .filter(c -> this.projectsToRebuild.contains(c.getProject())).toArray(paramInt -> new IBuildConfiguration[paramInt]);
/*  460 */         basicBuildLoop(configurations, requestedConfigs, trigger, status, monitor, projectWork, lastIteration);
/*      */       } 
/*  462 */       if (this.rebuildRequested) {
/*  463 */         rebuildSomething = true;
/*  464 */         this.projectsToRebuild.clear();
/*  465 */         this.restartBuildImmediately.clear();
/*  466 */       } else if (!this.projectsToRebuild.isEmpty()) {
/*  467 */         rebuildSomething = true;
/*      */       } else {
/*  469 */         rebuildSomething = false;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  475 */       if (trigger != 9) {
/*  476 */         trigger = 10;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void basicBuildLoop(IBuildConfiguration[] configs, IBuildConfiguration[] requestedConfigs, int trigger, MultiStatus status, IProgressMonitor monitor, int projectWork, boolean lastIteration) {
/*  489 */     if (this.rebuildRequested) {
/*  490 */       this.builtProjects.clear();
/*      */     } else {
/*  492 */       this.builtProjects.removeAll(this.projectsToRebuild);
/*      */     } 
/*      */ 
/*      */     
/*  496 */     this.rebuildRequested = false;
/*  497 */     this.projectsToRebuild.clear();
/*  498 */     this.restartBuildImmediately.clear(); byte b;
/*      */     int i;
/*      */     IBuildConfiguration[] arrayOfIBuildConfiguration;
/*  501 */     for (i = (arrayOfIBuildConfiguration = configs).length, b = 0; b < i; ) { IBuildConfiguration config = arrayOfIBuildConfiguration[b];
/*  502 */       if (config.getProject().isAccessible()) {
/*  503 */         IBuildContext context = new BuildContext(config, requestedConfigs, configs);
/*      */ 
/*      */         
/*  506 */         basicBuild(config, trigger, context, status, Policy.subMonitorFor(monitor, projectWork));
/*  507 */         this.builtProjects.add(config.getProject());
/*      */ 
/*      */         
/*  510 */         if ((!this.rebuildRequested && this.projectsToRebuild.isEmpty()) || 
/*  511 */           !isEarlyExitFromBuildLoopAllowed() || 
/*  512 */           lastIteration) {
/*      */           continue;
/*      */         }
/*      */         break;
/*      */       } 
/*      */       continue;
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IStatus build(IBuildConfiguration[] configs, IBuildConfiguration[] requestedConfigs, int trigger, IProgressMonitor monitor) {
/*  530 */     monitor = Policy.monitorFor(monitor);
/*      */     try {
/*  532 */       monitor.beginTask(Messages.events_building_0, 100000);
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  542 */       endBuild(trigger, monitor);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IStatus buildParallel(ComputeProjectOrder.Digraph<IBuildConfiguration> configs, IBuildConfiguration[] requestedConfigs, int trigger, JobGroup buildJobGroup, IProgressMonitor monitor) {
/*  552 */     this.parallelBuild = true;
/*  553 */     monitor = Policy.monitorFor(monitor);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*      */     
/*      */     } finally {
/*  566 */       endBuild(trigger, monitor);
/*  567 */       this.parallelBuild = false;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void endBuild(int trigger, IProgressMonitor monitor) {
/*  572 */     boolean cancelledBuild = monitor.isCanceled();
/*  573 */     monitor.done();
/*  574 */     if (trigger == 10 || trigger == 6) {
/*  575 */       this.autoBuildJob.avoidBuild();
/*  576 */     } else if (cancelledBuild) {
/*      */       
/*  578 */       this.autoBuildJob.avoidBuildIfNotInterrupted();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void parallelBuildLoop(ComputeProjectOrder.Digraph<IBuildConfiguration> configs, IBuildConfiguration[] requestedConfigs, int trigger, JobGroup buildJobGroup, MultiStatus status, IProgressMonitor monitor) {
/*  583 */     int projectWork = (configs.vertexList.size() > 0) ? (100000 / configs.vertexList.size()) : 0;
/*  584 */     this.builtProjects.clear();
/*  585 */     GraphProcessor<IBuildConfiguration> graphProcessor = new GraphProcessor<>(configs, IBuildConfiguration.class, (config, graphCrawler) -> {
/*      */           IBuildContext context = new BuildContext(config, paramArrayOfIBuildConfiguration, graphCrawler.getSequentialOrder());
/*      */           try {
/*      */             this.workspace.prepareOperation(null, paramIProgressMonitor);
/*      */             this.workspace.beginOperation(false);
/*      */             basicBuild(config, paramInt1, context, paramMultiStatus, Policy.subMonitorFor(paramIProgressMonitor, paramInt2));
/*      */             this.workspace.endOperation(null, false);
/*      */             this.builtProjects.add(config.getProject());
/*  593 */           } catch (CoreException ex) {
/*      */             paramMultiStatus.add((IStatus)new Status(4, "org.eclipse.core.resources", ex.getMessage(), (Throwable)ex));
/*      */           } 
/*  596 */         }config -> getRule(config, paramInt, null, Collections.emptyMap()), buildJobGroup);
/*  597 */     graphProcessor.processGraphWithParallelJobs();
/*      */     try {
/*  599 */       Job.getJobManager().join(graphProcessor, monitor);
/*  600 */     } catch (OperationCanceledException|InterruptedException e) {
/*  601 */       status.add((IStatus)new Status(4, "org.eclipse.core.resources", e.getMessage(), e));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IStatus build(IBuildConfiguration buildConfiguration, int trigger, String builderName, Map<String, String> args, IProgressMonitor monitor) {
/*  610 */     monitor = Policy.monitorFor(monitor);
/*  611 */     this.rebuildRequested = false;
/*  612 */     this.projectsToRebuild.clear();
/*  613 */     this.restartBuildImmediately.clear();
/*  614 */     if (builderName == null) {
/*  615 */       IBuildContext context = new BuildContext(buildConfiguration);
/*  616 */       return basicBuild(buildConfiguration, trigger, context, monitor);
/*      */     } 
/*  618 */     return basicBuild(buildConfiguration, trigger, builderName, args, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkCanceled(int trigger, IProgressMonitor monitor) {
/*  626 */     if (this.systemBundle.getState() == 16)
/*  627 */       throw new OperationCanceledException(); 
/*  628 */     Policy.checkCanceled(monitor);
/*      */     
/*  630 */     if (trigger != 9) {
/*      */       return;
/*      */     }
/*  633 */     if (this.autoBuildJob.isInterrupted()) {
/*  634 */       throw new OperationCanceledException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayList<BuilderPersistentInfo> createBuildersPersistentInfo(IProject project) throws CoreException {
/*  657 */     ArrayList<BuilderPersistentInfo> oldInfos = getBuildersPersistentInfo(project);
/*      */     
/*  659 */     ProjectDescription desc = ((Project)project).internalGetDescription();
/*  660 */     ICommand[] commands = desc.getBuildSpec(false);
/*  661 */     if (commands.length == 0)
/*  662 */       return null; 
/*  663 */     IBuildConfiguration[] configs = project.getBuildConfigs();
/*      */ 
/*      */     
/*  666 */     ArrayList<BuilderPersistentInfo> newInfos = new ArrayList<>(commands.length * configs.length);
/*  667 */     for (int i = 0; i < commands.length; i++) {
/*  668 */       BuildCommand command = (BuildCommand)commands[i];
/*  669 */       String builderName = command.getBuilderName();
/*      */ 
/*      */       
/*  672 */       boolean supportsConfigs = command.supportsConfigs();
/*  673 */       int numberConfigs = supportsConfigs ? configs.length : 1;
/*      */       
/*  675 */       for (int j = 0; j < numberConfigs; j++) {
/*  676 */         IBuildConfiguration config = configs[j];
/*  677 */         BuilderPersistentInfo info = null;
/*  678 */         IncrementalProjectBuilder builder = ((BuildCommand)commands[i]).getBuilder(config);
/*  679 */         if (builder == null) {
/*      */           
/*  681 */           if (oldInfos != null)
/*  682 */             info = getBuilderInfo(oldInfos, builderName, supportsConfigs ? config.getName() : null, i); 
/*  683 */         } else if (!(builder instanceof MissingBuilder)) {
/*  684 */           ElementTree oldTree = builder.getLastBuiltTree();
/*      */           
/*  686 */           if (oldTree != null) {
/*      */             
/*  688 */             info = new BuilderPersistentInfo(project.getName(), supportsConfigs ? config.getName() : null, builderName, i);
/*  689 */             info.setLastBuildTree(oldTree);
/*  690 */             info.setInterestingProjects(builder.getInterestingProjects());
/*      */           } 
/*      */         } 
/*  693 */         if (info != null)
/*  694 */           newInfos.add(info); 
/*      */       } 
/*      */     } 
/*  697 */     return newInfos;
/*      */   }
/*      */   
/*      */   private String debugBuilder() {
/*  701 */     return (this.currentBuilders == null) ? "<no builder>" : this.currentBuilders.getClass().getName();
/*      */   }
/*      */   
/*      */   private String debugProject() {
/*  705 */     if (this.currentBuilders == null)
/*  706 */       return "<no project>"; 
/*  707 */     return "[" + (String)this.currentBuilders.stream().map(builder -> builder.getProject().getFullPath().toString()).collect(Collectors.joining(",")) + "]";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String debugTrigger(int trigger) {
/*  716 */     switch (trigger) {
/*      */       case 6:
/*  718 */         return "FULL_BUILD";
/*      */       case 15:
/*  720 */         return "CLEAN_BUILD";
/*      */     } 
/*      */ 
/*      */     
/*  724 */     return "INCREMENTAL_BUILD";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void endTopLevel(boolean needsBuild) {
/*  732 */     this.autoBuildJob.build(needsBuild);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void waitForAutoBuild() {
/*  739 */     waitFor(this.autoBuildJob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void waitForAutoBuildOff() {
/*  746 */     waitFor(this.autoBuildJob.noBuildJob);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void waitFor(Job job) {
/*  752 */     while (job.getState() != 0) {
/*      */       
/*  754 */       while (job.getState() != 4 && job.getState() != 0) {
/*  755 */         Job.getJobManager().wakeUp(ResourcesPlugin.FAMILY_AUTO_BUILD);
/*  756 */         Thread.yield();
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  763 */         Job.getJobManager().join(ResourcesPlugin.FAMILY_AUTO_BUILD, null);
/*  764 */       } catch (OperationCanceledException|InterruptedException operationCanceledException) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean getBooleanAttribute(IConfigurationElement element, String name) {
/*  775 */     String valueString = element.getAttribute(name);
/*  776 */     return (valueString != null && valueString.equalsIgnoreCase(Boolean.TRUE.toString()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IncrementalProjectBuilder getBuilder(IBuildConfiguration buildConfiguration, ICommand command, int buildSpecIndex, MultiStatus status) throws CoreException {
/*  789 */     BuildCommand buildCommand = (BuildCommand)command;
/*  790 */     IncrementalProjectBuilder incrementalProjectBuilder = buildCommand.getBuilder(buildConfiguration);
/*  791 */     String builderName = command.getBuilderName();
/*  792 */     IProject project = buildConfiguration.getProject();
/*      */     
/*  794 */     if (incrementalProjectBuilder == null) {
/*      */       InternalBuilder internalBuilder;
/*      */ 
/*      */       
/*      */       BuilderPersistentInfo info;
/*      */ 
/*      */       
/*  801 */       synchronized (this.builderInitializationLock) {
/*      */         
/*  803 */         BuilderPersistentInfo builderInitInProgress = getBuilderInitInfo(project, builderName);
/*  804 */         if (builderInitInProgress != null) {
/*  805 */           info = builderInitInProgress;
/*      */         } else {
/*  807 */           info = removePersistentBuilderInfo(builderName, buildConfiguration, buildSpecIndex);
/*  808 */           setBuilderInitInfo(project, builderName, info);
/*      */         } 
/*      */       } 
/*      */       
/*  812 */       incrementalProjectBuilder = buildCommand.getBuilder(buildConfiguration);
/*  813 */       if (incrementalProjectBuilder == null)
/*      */       {
/*      */         
/*  816 */         internalBuilder = initializeBuilder(command, builderName, buildConfiguration, info, status);
/*      */       }
/*      */       
/*  819 */       synchronized (this.builderInitializationLock) {
/*      */ 
/*      */ 
/*      */         
/*  823 */         IncrementalProjectBuilder incrementalProjectBuilder1 = buildCommand.getBuilder(buildConfiguration);
/*  824 */         if (incrementalProjectBuilder1 == null) {
/*  825 */           buildCommand.addBuilder(buildConfiguration, (IncrementalProjectBuilder)internalBuilder);
/*      */         } else {
/*  827 */           incrementalProjectBuilder = incrementalProjectBuilder1;
/*      */         } 
/*  829 */         setBuilderInitInfo(project, builderName, null);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  834 */     incrementalProjectBuilder.setBuildConfig(buildConfiguration);
/*  835 */     if (!validateNature((InternalBuilder)incrementalProjectBuilder, builderName)) {
/*      */ 
/*      */       
/*  838 */       incrementalProjectBuilder.setLastBuiltTree(null);
/*  839 */       return null;
/*      */     } 
/*  841 */     return incrementalProjectBuilder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IncrementalProjectBuilder getBuilder(IBuildConfiguration buildConfiguration, ICommand command, int buildSpecIndex, MultiStatus status, IBuildContext context) throws CoreException {
/*  856 */     IncrementalProjectBuilder incrementalProjectBuilder = getBuilder(buildConfiguration, command, buildSpecIndex, status);
/*  857 */     if (incrementalProjectBuilder != null)
/*  858 */       incrementalProjectBuilder.setContext(context); 
/*  859 */     return incrementalProjectBuilder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BuilderPersistentInfo getBuilderInfo(ArrayList<BuilderPersistentInfo> infos, String builderName, String configName, int buildSpecIndex) {
/*  872 */     BuilderPersistentInfo nameMatch = null;
/*  873 */     for (BuilderPersistentInfo info : infos) {
/*      */ 
/*      */       
/*  876 */       if (info.getBuilderName().equals(builderName) && (info.getConfigName() == null || info.getConfigName().equals(configName))) {
/*      */         
/*  878 */         if (nameMatch == null) {
/*  879 */           nameMatch = info;
/*      */         }
/*  881 */         if (buildSpecIndex == -1 || info.getBuildSpecIndex() == -1 || buildSpecIndex == info.getBuildSpecIndex()) {
/*  882 */           return info;
/*      */         }
/*      */       } 
/*      */     } 
/*  886 */     return nameMatch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayList<BuilderPersistentInfo> getBuildersPersistentInfo(IProject project) throws CoreException {
/*  896 */     return (ArrayList<BuilderPersistentInfo>)project.getSessionProperty(K_BUILD_LIST);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ICommand getCommand(IProject project, String builderName, Map<String, String> args) {
/*  907 */     ICommand[] buildSpec = ((Project)project).internalGetDescription().getBuildSpec(false); byte b; int i; ICommand[] arrayOfICommand1;
/*  908 */     for (i = (arrayOfICommand1 = buildSpec).length, b = 0; b < i; ) { ICommand element = arrayOfICommand1[b];
/*  909 */       if (element.getBuilderName().equals(builderName))
/*  910 */         return element;  b++; }
/*      */     
/*  912 */     BuildCommand result = new BuildCommand();
/*  913 */     result.setBuilderName(builderName);
/*  914 */     result.setArguments(args);
/*  915 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   IResourceDelta getDelta(IProject project) {
/*      */     try {
/*  936 */       this.lock.acquire();
/*  937 */       if (this.currentTree == null) {
/*  938 */         if (Policy.DEBUG_BUILD_FAILURE)
/*  939 */           Policy.debug("Build: no tree for delta " + debugBuilder() + " [" + debugProject() + "]"); 
/*  940 */         return null;
/*      */       } 
/*  942 */       Set<InternalBuilder> interestedBuilders = getInterestedBuilders(project);
/*      */       
/*  944 */       if (interestedBuilders.isEmpty()) {
/*  945 */         if (Policy.DEBUG_BUILD_FAILURE)
/*  946 */           Policy.debug("Build: project not interesting for current builders " + debugBuilder() + " [" + debugProject() + "] " + project.getFullPath()); 
/*  947 */         return null;
/*      */       } 
/*      */ 
/*      */       
/*  951 */       return getDeltaCached(project, this.currentLastBuiltTree, this.currentTree);
/*      */     } finally {
/*  953 */       this.lock.release();
/*      */     } 
/*      */   }
/*      */   
/*      */   private IResourceDelta getDeltaCached(IProject project, ElementTree oldTree, ElementTree newTree) {
/*  958 */     IPath fullPath = project.getFullPath();
/*  959 */     IResourceDelta resultDelta = this.deltaCache.computeIfAbsent(fullPath, oldTree, newTree, () -> {
/*      */           IResourceDelta result;
/*      */           
/*      */           long startTime = 0L;
/*      */           if (Policy.DEBUG_BUILD_DELTA) {
/*      */             startTime = System.currentTimeMillis();
/*      */             Policy.debug("Computing delta for project: " + paramIProject.getName());
/*      */           } 
/*      */           if (!paramIProject.exists() && !paramElementTree1.includes(paramIPath) && !paramElementTree2.includes(paramIPath)) {
/*      */             result = null;
/*      */           } else {
/*      */             result = ResourceDeltaFactory.computeDelta(this.workspace, paramElementTree2, paramElementTree1, paramIPath, -1L);
/*      */           } 
/*      */           if (Policy.DEBUG_BUILD_FAILURE && result == null) {
/*      */             Policy.debug("Build: no delta " + debugBuilder() + " [" + debugProject() + "] " + paramIPath);
/*      */           }
/*      */           if (Policy.DEBUG_BUILD_DELTA) {
/*      */             Policy.debug("Finished computing delta, time: " + (System.currentTimeMillis() - startTime) + "ms" + ((ResourceDelta)result).toDeepDebugString());
/*      */           }
/*      */           return result;
/*      */         });
/*  980 */     return resultDelta;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ISafeRunnable getSafeRunnable(final InternalBuilder currentBuilder, final int trigger, final Map<String, String> args, final MultiStatus status, final IProgressMonitor monitor) {
/*  988 */     return new ISafeRunnable()
/*      */       {
/*      */         public void handleException(Throwable e) {
/*  991 */           if (e instanceof OperationCanceledException) {
/*  992 */             if (Policy.DEBUG_BUILD_INVOKING) {
/*  993 */               Policy.debug("Build canceled");
/*      */             }
/*      */             
/*  996 */             currentBuilder.forgetLastBuiltState();
/*  997 */             throw (OperationCanceledException)e;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1003 */           String builderName = currentBuilder.getLabel();
/* 1004 */           if (builderName == null || builderName.length() == 0)
/* 1005 */             builderName = currentBuilder.getClass().getName(); 
/* 1006 */           String pluginId = currentBuilder.getPluginId();
/* 1007 */           String message = NLS.bind(Messages.events_builderError, builderName, currentBuilder.getProject().getName());
/* 1008 */           status.add((IStatus)new Status(4, pluginId, 75, message, e));
/*      */ 
/*      */           
/* 1011 */           if (e instanceof CoreException) {
/* 1012 */             status.add(((CoreException)e).getStatus());
/*      */           }
/*      */         }
/*      */         
/*      */         public void run() throws Exception {
/* 1017 */           IProject[] prereqs = null;
/*      */           
/* 1019 */           if (trigger != 15) {
/* 1020 */             prereqs = currentBuilder.build(trigger, args, monitor);
/*      */           }
/* 1022 */           else if (currentBuilder instanceof IIncrementalProjectBuilder2) {
/* 1023 */             ((IIncrementalProjectBuilder2)currentBuilder).clean(args, monitor);
/*      */           } else {
/* 1025 */             currentBuilder.clean(monitor);
/*      */           } 
/*      */           
/* 1028 */           if (prereqs == null)
/* 1029 */             prereqs = new IProject[0]; 
/* 1030 */           currentBuilder.setInterestingProjects((IProject[])prereqs.clone());
/*      */         }
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WorkManager getWorkManager() {
/*      */     try {
/* 1041 */       return this.workspace.getWorkManager();
/* 1042 */     } catch (CoreException coreException) {
/*      */ 
/*      */ 
/*      */       
/* 1046 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void handleEvent(LifecycleEvent event) {
/* 1051 */     IProject project = null;
/* 1052 */     switch (event.kind) {
/*      */       case 16:
/*      */       case 64:
/* 1055 */         project = (IProject)event.resource;
/*      */         
/* 1057 */         if (project.isAccessible()) {
/* 1058 */           setBuildersPersistentInfo(project, null);
/*      */         }
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   boolean hasBeenBuilt(IProject project) {
/* 1067 */     return this.builtProjects.contains(project);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void hookEndBuild(IncrementalProjectBuilder builder) {
/* 1075 */     if (ResourceStats.TRACE_BUILDERS)
/* 1076 */       ResourceStats.endBuild(); 
/* 1077 */     if (!Policy.DEBUG_BUILD_INVOKING || this.timeStamp == -1L)
/*      */       return; 
/* 1079 */     Policy.debug("Builder finished: " + toString((InternalBuilder)builder) + " time: " + (System.currentTimeMillis() - this.timeStamp) + "ms");
/* 1080 */     this.timeStamp = -1L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void hookEndBuild(int trigger) {
/* 1089 */     this.builtProjects.clear();
/* 1090 */     this.deltaCache.flush();
/*      */     
/* 1092 */     if (trigger == 15)
/* 1093 */       this.autoBuildJob.forceBuild(); 
/* 1094 */     if (Policy.DEBUG_BUILD_INVOKING) {
/* 1095 */       Policy.debug("Top-level build-end time: " + (System.currentTimeMillis() - this.overallTimeStamp));
/* 1096 */       this.overallTimeStamp = -1L;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void hookStartBuild(IncrementalProjectBuilder builder, int trigger) {
/* 1105 */     if (ResourceStats.TRACE_BUILDERS)
/* 1106 */       ResourceStats.startBuild(builder); 
/* 1107 */     if (Policy.DEBUG_BUILD_INVOKING) {
/* 1108 */       this.timeStamp = System.currentTimeMillis();
/* 1109 */       Policy.debug("Invoking (" + debugTrigger(trigger) + ") on builder: " + toString((InternalBuilder)builder));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void hookStartBuild(IBuildConfiguration[] configs, int trigger) {
/* 1119 */     if (Policy.DEBUG_BUILD_STACK)
/* 1120 */       Policy.debug(new RuntimeException("Starting build: " + debugTrigger(trigger))); 
/* 1121 */     if (Policy.DEBUG_BUILD_INVOKING) {
/* 1122 */       this.overallTimeStamp = System.currentTimeMillis();
/* 1123 */       StringBuilder sb = new StringBuilder("Top-level build-start of: "); byte b; int i; IBuildConfiguration[] arrayOfIBuildConfiguration;
/* 1124 */       for (i = (arrayOfIBuildConfiguration = configs).length, b = 0; b < i; ) { IBuildConfiguration config = arrayOfIBuildConfiguration[b];
/* 1125 */         sb.append(config).append(", "); b++; }
/* 1126 */        sb.append(debugTrigger(trigger));
/* 1127 */       Policy.debug(sb.toString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private InternalBuilder initializeBuilder(ICommand command, String builderName, IBuildConfiguration buildConfiguration, BuilderPersistentInfo info, MultiStatus status) {
/*      */     IncrementalProjectBuilder incrementalProjectBuilder;
/* 1139 */     IProject project = buildConfiguration.getProject();
/* 1140 */     InternalBuilder builder = null;
/*      */     try {
/* 1142 */       incrementalProjectBuilder = instantiateBuilder(builderName);
/* 1143 */     } catch (CoreException e) {
/* 1144 */       status.add((IStatus)new ResourceStatus(75, project.getFullPath(), NLS.bind(Messages.events_instantiate_1, builderName), (Throwable)e));
/* 1145 */       status.add(e.getStatus());
/*      */     } 
/* 1147 */     if (incrementalProjectBuilder == null)
/*      */     {
/* 1149 */       incrementalProjectBuilder = new MissingBuilder(builderName);
/*      */     }
/*      */     
/* 1152 */     if (info != null) {
/* 1153 */       ElementTree tree = info.getLastBuiltTree();
/* 1154 */       if (tree != null) {
/* 1155 */         incrementalProjectBuilder.setLastBuiltTree(tree);
/*      */       }
/* 1157 */       incrementalProjectBuilder.setInterestingProjects(info.getInterestingProjects());
/*      */     } 
/* 1159 */     incrementalProjectBuilder.setCommand(command);
/* 1160 */     incrementalProjectBuilder.setBuildConfig(buildConfiguration);
/* 1161 */     incrementalProjectBuilder.startupOnInitialize();
/* 1162 */     return (InternalBuilder)incrementalProjectBuilder;
/*      */   }
/*      */   
/*      */   private BuilderPersistentInfo removePersistentBuilderInfo(String builderName, IBuildConfiguration buildConfiguration, int buildSpecIndex) throws CoreException {
/* 1166 */     IProject project = buildConfiguration.getProject();
/* 1167 */     ArrayList<BuilderPersistentInfo> infos = getBuildersPersistentInfo(project);
/* 1168 */     if (infos != null) {
/* 1169 */       BuilderPersistentInfo info = getBuilderInfo(infos, builderName, buildConfiguration.getName(), buildSpecIndex);
/* 1170 */       if (info != null) {
/* 1171 */         infos.remove(info);
/*      */         
/* 1173 */         if (infos.isEmpty()) {
/* 1174 */           setBuildersPersistentInfo(project, null);
/*      */         }
/* 1176 */         return info;
/*      */       } 
/*      */     } 
/*      */     
/* 1180 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private IncrementalProjectBuilder instantiateBuilder(String builderName) throws CoreException {
/* 1188 */     IExtension extension = Platform.getExtensionRegistry().getExtension("org.eclipse.core.resources", "builders", builderName);
/* 1189 */     if (extension == null)
/* 1190 */       return null; 
/* 1191 */     IConfigurationElement[] configs = extension.getConfigurationElements();
/* 1192 */     if (configs.length == 0)
/* 1193 */       return null; 
/* 1194 */     String natureId = null;
/* 1195 */     if (getBooleanAttribute(configs[0], "hasNature")) {
/*      */       
/* 1197 */       String builderId = extension.getUniqueIdentifier();
/* 1198 */       natureId = this.workspace.getNatureManager().findNatureForBuilder(builderId);
/* 1199 */       if (natureId == null) {
/* 1200 */         return null;
/*      */       }
/*      */     } 
/* 1203 */     InternalBuilder builder = (InternalBuilder)configs[0].createExecutableExtension("run");
/* 1204 */     builder.setPluginId(extension.getContributor().getName());
/* 1205 */     builder.setLabel(extension.getLabel());
/* 1206 */     builder.setNatureId(natureId);
/* 1207 */     builder.setCallOnEmptyDelta(getBooleanAttribute(configs[0], "callOnEmptyDelta"));
/* 1208 */     return (IncrementalProjectBuilder)builder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void interrupt() {
/* 1216 */     this.autoBuildJob.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAutobuildBuildPending() {
/* 1223 */     return (this.autoBuildJob.getState() != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isInterestingProject(InternalBuilder currentBuilder, IProject project) {
/* 1232 */     if (project.equals(currentBuilder.getProject()))
/* 1233 */       return true; 
/* 1234 */     IProject[] interestingProjects = currentBuilder.getInterestingProjects(); byte b; int i; IProject[] arrayOfIProject1;
/* 1235 */     for (i = (arrayOfIProject1 = interestingProjects).length, b = 0; b < i; ) { IProject interestingProject = arrayOfIProject1[b];
/* 1236 */       if (interestingProject.equals(project))
/* 1237 */         return true; 
/*      */       b++; }
/*      */     
/* 1240 */     return false;
/*      */   }
/*      */   
/*      */   private Set<InternalBuilder> getInterestedBuilders(IProject project) {
/* 1244 */     Set<InternalBuilder> res = new HashSet<>();
/* 1245 */     for (InternalBuilder builder : this.currentBuilders) {
/* 1246 */       if (isInterestingProject(builder, project)) {
/* 1247 */         res.add(builder);
/*      */       }
/*      */     } 
/* 1250 */     return res;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean needsBuild(InternalBuilder builder, int trigger) {
/* 1266 */     switch (trigger) {
/*      */       case 15:
/* 1268 */         return true;
/*      */       case 6:
/* 1270 */         return true;
/*      */       case 10:
/* 1272 */         for (InternalBuilder currentBuilder : this.currentBuilders) {
/* 1273 */           if (currentBuilder.callOnEmptyDelta()) {
/* 1274 */             return true;
/*      */           }
/*      */         } 
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 1281 */     ElementTree oldTree = builder.getLastBuiltTree();
/* 1282 */     ElementTree newTree = this.workspace.getElementTree();
/*      */ 
/*      */     
/* 1285 */     if (hasDelta(builder, builder.getProject(), oldTree, newTree)) {
/* 1286 */       return true;
/*      */     }
/*      */ 
/*      */     
/* 1290 */     IProject[] projects = builder.getInterestingProjects(); byte b; int i; IProject[] arrayOfIProject1;
/* 1291 */     for (i = (arrayOfIProject1 = projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/* 1292 */       if (project != builder.getProject() && 
/* 1293 */         hasDelta(builder, project, oldTree, newTree))
/* 1294 */         return true; 
/*      */       b++; }
/*      */     
/* 1297 */     return false;
/*      */   }
/*      */   
/*      */   private boolean hasDelta(InternalBuilder builder, IProject project, ElementTree oldTree, ElementTree newTree) {
/* 1301 */     IResourceDelta delta = getDeltaCached(project, this.currentLastBuiltTree, this.currentTree);
/* 1302 */     if (delta == null) {
/* 1303 */       return false;
/*      */     }
/* 1305 */     IResourceDelta[] children = delta.getAffectedChildren();
/* 1306 */     boolean hasDelta = !(delta.getKind() == 0 && children.length <= 0);
/* 1307 */     if (hasDelta && Policy.DEBUG_BUILD_NEEDED) {
/* 1308 */       Policy.debug(String.valueOf(toString(builder)) + " needs building because of changes in: " + project.getName());
/* 1309 */       if (Policy.DEBUG_BUILD_NEEDED_DELTA) {
/* 1310 */         debugPrintDeltaRecursive(delta);
/*      */       }
/*      */     } 
/* 1313 */     return hasDelta;
/*      */   }
/*      */   
/*      */   private void debugPrintDeltaRecursive(IResourceDelta delta) {
/* 1317 */     if (delta.getKind() != 0)
/* 1318 */       Policy.debug(((ResourceDelta)delta).toDebugString());  byte b; int i;
/*      */     IResourceDelta[] arrayOfIResourceDelta;
/* 1320 */     for (i = (arrayOfIResourceDelta = delta.getAffectedChildren()).length, b = 0; b < i; ) { IResourceDelta childDelta = arrayOfIResourceDelta[b];
/* 1321 */       debugPrintDeltaRecursive(childDelta);
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void removeBuilders(IProject project, String builderId) throws CoreException {
/* 1330 */     IProjectDescription desc = project.getDescription();
/* 1331 */     ICommand[] oldSpec = desc.getBuildSpec();
/* 1332 */     int oldLength = oldSpec.length;
/* 1333 */     if (oldLength == 0)
/*      */       return; 
/* 1335 */     int remaining = 0;
/*      */     
/* 1337 */     for (int i = 0; i < oldSpec.length; i++) {
/* 1338 */       if (oldSpec[i].getBuilderName().equals(builderId)) {
/* 1339 */         oldSpec[i] = null;
/*      */       } else {
/* 1341 */         remaining++;
/*      */       } 
/*      */     } 
/* 1344 */     if (remaining == oldSpec.length)
/*      */       return; 
/* 1346 */     ICommand[] newSpec = new ICommand[remaining];
/* 1347 */     for (int j = 0, newIndex = 0; j < oldLength; j++) {
/* 1348 */       if (oldSpec[j] != null)
/* 1349 */         newSpec[newIndex++] = oldSpec[j]; 
/*      */     } 
/* 1351 */     desc.setBuildSpec(newSpec);
/* 1352 */     project.setDescription(desc, 0, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void requestRebuild() {
/* 1361 */     this.rebuildRequested = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void requestRebuild(IProject project, boolean processOtherBuilders) {
/* 1379 */     if (project == null) {
/*      */       return;
/*      */     }
/* 1382 */     this.restartBuildImmediately.put(project, Boolean.valueOf(!processOtherBuilders));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void requestRebuild(Collection<IProject> toBeRebuilt, IProject current) {
/* 1400 */     for (IProject project : toBeRebuilt) {
/* 1401 */       if ((project != null && hasBeenBuilt(project)) || project.equals(current)) {
/* 1402 */         requestRebuildOnNextRound(project);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void requestRebuildOnNextRound(IProject project) {
/* 1413 */     this.projectsToRebuild.add(project);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBuildersPersistentInfo(IProject project, List<BuilderPersistentInfo> list) {
/*      */     try {
/* 1425 */       project.setSessionProperty(K_BUILD_LIST, list);
/* 1426 */     } catch (CoreException e) {
/*      */ 
/*      */       
/* 1429 */       logProjectAccessError(project, e, "Project missing in setBuildersPersistentInfo");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setBuilderInitInfo(IProject project, String builderName, BuilderPersistentInfo info) {
/*      */     try {
/* 1435 */       project.setSessionProperty(keyForBuilderInfo(builderName), info);
/* 1436 */     } catch (CoreException e) {
/*      */ 
/*      */       
/* 1439 */       logProjectAccessError(project, e, "Project missing in setBuilderInitInfo");
/*      */     } 
/*      */   }
/*      */   
/*      */   private BuilderPersistentInfo getBuilderInitInfo(IProject project, String builderName) {
/*      */     try {
/* 1445 */       return (BuilderPersistentInfo)project.getSessionProperty(keyForBuilderInfo(builderName));
/* 1446 */     } catch (CoreException e) {
/*      */ 
/*      */       
/* 1449 */       logProjectAccessError(project, e, "Project missing in getBuilderInitInfo");
/*      */       
/* 1451 */       return null;
/*      */     } 
/*      */   }
/*      */   private void logProjectAccessError(IProject project, CoreException e, String message) {
/* 1455 */     Policy.log((IStatus)new ResourceStatus(4, 1, project.getFullPath(), message, (Throwable)e));
/*      */   }
/*      */   
/*      */   private static QualifiedName keyForBuilderInfo(String builderName) {
/* 1459 */     return new QualifiedName("org.eclipse.core.resources", "BuilderInitInfo" + builderName);
/*      */   }
/*      */ 
/*      */   
/*      */   public void shutdown(IProgressMonitor monitor) {
/* 1464 */     this.autoBuildJob.cancel();
/*      */   }
/*      */ 
/*      */   
/*      */   public void startup(IProgressMonitor monitor) {
/* 1469 */     this.workspace.addLifecycleListener(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String toString(InternalBuilder builder) {
/* 1477 */     String name = builder.getClass().getName();
/* 1478 */     name = name.substring(name.lastIndexOf('.') + 1);
/* 1479 */     if (builder instanceof MissingBuilder)
/* 1480 */       name = String.valueOf(name) + ": '" + ((MissingBuilder)builder).getName() + "'"; 
/* 1481 */     return String.valueOf(name) + "(" + builder.getBuildConfig() + ")";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean validateNature(InternalBuilder builder, String builderId) throws CoreException {
/* 1501 */     String nature = builder.getNatureId();
/* 1502 */     if (nature == null)
/* 1503 */       return true; 
/* 1504 */     IProject project = builder.getProject();
/* 1505 */     if (!project.hasNature(nature)) {
/*      */       
/* 1507 */       removeBuilders(project, builderId);
/* 1508 */       return false;
/*      */     } 
/* 1510 */     return project.isNatureEnabled(nature);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ISchedulingRule getRule(IBuildConfiguration buildConfiguration, int trigger, String builderName, Map<String, String> buildArgs) {
/* 1517 */     IProject project = buildConfiguration.getProject();
/* 1518 */     MultiStatus status = new MultiStatus("org.eclipse.core.resources", 566, Messages.events_errors, null);
/* 1519 */     if (builderName == null) {
/*      */       
/* 1521 */       if (project.isAccessible()) {
/* 1522 */         Set<ISchedulingRule> rules = new HashSet<>();
/* 1523 */         ICommand[] commands = ((Project)project).internalGetDescription().getBuildSpec(false);
/* 1524 */         boolean hasNullBuildRule = false;
/* 1525 */         BuildContext context = new BuildContext(buildConfiguration);
/* 1526 */         for (int i = 0; i < commands.length; i++) {
/* 1527 */           BuildCommand command = (BuildCommand)commands[i];
/* 1528 */           Map<String, String> allArgs = command.getArguments(true);
/* 1529 */           if (allArgs == null) {
/* 1530 */             allArgs = buildArgs;
/* 1531 */           } else if (buildArgs != null) {
/* 1532 */             allArgs.putAll(buildArgs);
/*      */           } 
/*      */           try {
/* 1535 */             IncrementalProjectBuilder builder = getBuilder(buildConfiguration, command, i, status, context);
/* 1536 */             if (builder != null) {
/* 1537 */               ISchedulingRule builderRule = builder.getRule(trigger, allArgs);
/* 1538 */               if (builderRule != null)
/* 1539 */               { rules.add(builderRule); }
/*      */               else
/* 1541 */               { hasNullBuildRule = true; } 
/*      */             } 
/* 1543 */           } catch (CoreException e) {
/* 1544 */             status.add(e.getStatus());
/*      */           } 
/*      */         } 
/* 1547 */         if (rules.isEmpty()) {
/* 1548 */           return null;
/*      */         }
/*      */         
/* 1551 */         if (!hasNullBuildRule) {
/* 1552 */           return (ISchedulingRule)new MultiRule(rules.<ISchedulingRule>toArray(new ISchedulingRule[rules.size()]));
/*      */         }
/*      */       } 
/*      */     } else {
/* 1556 */       ICommand command = getCommand(project, builderName, buildArgs);
/* 1557 */       Map<String, String> allArgs = new HashMap<>();
/* 1558 */       if (command.getArguments() != null) {
/* 1559 */         allArgs.putAll(command.getArguments());
/*      */       }
/* 1561 */       if (buildArgs != null) {
/* 1562 */         allArgs.putAll(buildArgs);
/*      */       }
/*      */       try {
/* 1565 */         IncrementalProjectBuilder builder = getBuilder(buildConfiguration, command, -1, status);
/* 1566 */         if (builder != null) {
/* 1567 */           return builder.getRule(trigger, allArgs);
/*      */         }
/* 1569 */       } catch (CoreException e) {
/* 1570 */         status.add(e.getStatus());
/*      */       } 
/*      */     } 
/*      */     
/* 1574 */     if (!status.isOK())
/* 1575 */       Policy.log((IStatus)status); 
/* 1576 */     return (ISchedulingRule)this.workspace.getRoot();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEarlyExitFromBuildLoopAllowed() {
/* 1585 */     return this.earlyExitFromBuildLoopAllowed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEarlyExitFromBuildLoopAllowed(boolean earlyExitFromBuildLoopAllowed) {
/* 1596 */     this.earlyExitFromBuildLoopAllowed = earlyExitFromBuildLoopAllowed;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\events\BuildManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */