/*    */ package org.eclipse.core.internal.localstore;
/*    */ 
/*    */ import java.io.BufferedInputStream;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FilterInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SafeFileInputStream
/*    */   extends FilterInputStream
/*    */ {
/*    */   protected static final String EXTENSION = ".bak";
/*    */   private static final int DEFAUT_BUFFER_SIZE = 2048;
/*    */   
/*    */   public SafeFileInputStream(File file) throws IOException {
/* 30 */     this(file.getAbsolutePath(), null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SafeFileInputStream(String targetPath, String tempPath) throws IOException {
/* 37 */     super(getInputStream(targetPath, tempPath, 2048));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SafeFileInputStream(String targetPath, String tempPath, int bufferSize) throws IOException {
/* 44 */     super(getInputStream(targetPath, tempPath, bufferSize));
/*    */   }
/*    */   
/*    */   private static InputStream getInputStream(String targetPath, String tempPath, int bufferSize) throws IOException {
/* 48 */     File target = new File(targetPath);
/* 49 */     if (!target.exists()) {
/* 50 */       if (tempPath == null)
/* 51 */         tempPath = String.valueOf(target.getAbsolutePath()) + ".bak"; 
/* 52 */       target = new File(tempPath);
/*    */     } 
/* 54 */     return new BufferedInputStream(new FileInputStream(target), bufferSize);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\localstore\SafeFileInputStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */