/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import java.io.DataInputStream;
/*    */ import java.io.IOException;
/*    */ import org.eclipse.core.internal.utils.Messages;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MarkerSnapshotReader
/*    */ {
/*    */   protected Workspace workspace;
/*    */   
/*    */   public MarkerSnapshotReader(Workspace workspace) {
/* 28 */     this.workspace = workspace;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MarkerSnapshotReader getReader(int formatVersion) throws IOException {
/* 35 */     switch (formatVersion) {
/*    */       case 1:
/* 37 */         return new MarkerSnapshotReader_1(this.workspace);
/*    */       case 2:
/* 39 */         return new MarkerSnapshotReader_2(this.workspace);
/*    */     } 
/* 41 */     throw new IOException(NLS.bind(Messages.resources_format, Integer.valueOf(formatVersion)));
/*    */   }
/*    */ 
/*    */   
/*    */   public void read(DataInputStream input) throws IOException, CoreException {
/* 46 */     int formatVersion = readVersionNumber(input);
/* 47 */     MarkerSnapshotReader reader = getReader(formatVersion);
/* 48 */     reader.read(input);
/*    */   }
/*    */   
/*    */   protected static int readVersionNumber(DataInputStream input) throws IOException {
/* 52 */     return input.readInt();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\MarkerSnapshotReader.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */