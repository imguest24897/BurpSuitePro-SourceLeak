/*     */ package org.eclipse.core.internal.dtree;
/*     */ 
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataTreeWriter
/*     */ {
/*     */   protected IDataFlattener flatener;
/*     */   protected DataOutput output;
/*     */   public static final int D_INFINITE = -1;
/*     */   
/*     */   public DataTreeWriter(IDataFlattener f) {
/*  43 */     this.flatener = f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeNode(AbstractDataTreeNode node, IPath path, int depth) throws IOException {
/*  53 */     int type = node.type();
/*     */ 
/*     */     
/*  56 */     String name = node.getName();
/*  57 */     if (name == null) {
/*  58 */       name = "";
/*     */     }
/*  60 */     this.output.writeUTF(name);
/*     */ 
/*     */     
/*  63 */     writeNumber(type);
/*     */ 
/*     */     
/*  66 */     if (node.hasData()) {
/*  67 */       Object data = node.getData();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  73 */       if (data == null) {
/*  74 */         writeNumber(0);
/*     */       } else {
/*  76 */         writeNumber(1);
/*  77 */         this.flatener.writeData(path, node.getData(), this.output);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  83 */     if (depth > 0 || depth == -1) {
/*  84 */       AbstractDataTreeNode[] children = node.getChildren();
/*     */ 
/*     */       
/*  87 */       writeNumber(children.length);
/*     */ 
/*     */       
/*  90 */       int newDepth = (depth == -1) ? -1 : (depth - 1); byte b; int i; AbstractDataTreeNode[] arrayOfAbstractDataTreeNode1;
/*  91 */       for (i = (arrayOfAbstractDataTreeNode1 = children).length, b = 0; b < i; ) { AbstractDataTreeNode element = arrayOfAbstractDataTreeNode1[b];
/*  92 */         writeNode(element, path.append(element.getName()), newDepth);
/*     */         b++; }
/*     */     
/*     */     } else {
/*  96 */       writeNumber(0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeNumber(int number) throws IOException {
/* 106 */     if (number >= 0 && number < 255) {
/* 107 */       this.output.writeByte(number);
/*     */     } else {
/* 109 */       this.output.writeByte(255);
/* 110 */       this.output.writeInt(number);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void writeSingleNode(AbstractDataTreeNode node, IPath path) throws IOException {
/* 120 */     String name = node.getName();
/* 121 */     if (name == null) {
/* 122 */       name = "";
/*     */     }
/* 124 */     this.output.writeUTF(name);
/*     */ 
/*     */     
/* 127 */     writeNumber(node.type());
/*     */ 
/*     */     
/* 130 */     if (node.hasData()) {
/* 131 */       Object data = node.getData();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 137 */       if (data == null) {
/* 138 */         writeNumber(0);
/*     */       } else {
/* 140 */         writeNumber(1);
/* 141 */         this.flatener.writeData(path, node.getData(), this.output);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTree(DeltaDataTree tree, IPath path, int depth, DataOutput output) throws IOException {
/*     */     IPath iPath;
/* 158 */     this.output = output;
/*     */     
/* 160 */     AbstractDataTreeNode node = tree.getRootNode();
/* 161 */     Path path1 = Path.ROOT;
/* 162 */     String[] segments = path.segments(); byte b; int i; String[] arrayOfString1;
/* 163 */     for (i = (arrayOfString1 = segments).length, b = 0; b < i; ) { String nextSegment = arrayOfString1[b];
/*     */       
/* 165 */       writeSingleNode(node, (IPath)path1);
/*     */       
/* 167 */       iPath = path1.append(nextSegment);
/* 168 */       node = node.childAtOrNull(nextSegment);
/*     */ 
/*     */       
/* 171 */       if (node != null) {
/* 172 */         writeNumber(1);
/*     */       } else {
/*     */         
/* 175 */         writeNumber(0);
/*     */         return;
/*     */       } 
/*     */       b++; }
/*     */     
/* 180 */     Assert.isTrue(iPath.equals(path), "dtree.navigationError");
/*     */ 
/*     */     
/* 183 */     writeNode(node, path, depth);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\dtree\DataTreeWriter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */