/*     */ package org.eclipse.core.internal.resources.refresh.win32;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Win32Natives
/*     */ {
/*     */   public static final long INVALID_HANDLE_VALUE;
/*     */   public static final int ERROR_SUCCESS;
/*     */   public static final int ERROR_INVALID_HANDLE;
/*     */   public static final int ERROR_ACCESS_DENIED = 5;
/*     */   public static int FILE_NOTIFY_ALL;
/*     */   public static final int MAXIMUM_WAIT_OBJECTS;
/*     */   public static final int MAX_PATH;
/*     */   public static final int INFINITE;
/*     */   public static final int WAIT_TIMEOUT;
/*     */   public static final int WAIT_OBJECT_0;
/*     */   public static final int WAIT_ABANDONED_0;
/*     */   public static final int WAIT_FAILED;
/*     */   public static final int FILE_NOTIFY_CHANGE_FILE_NAME;
/*     */   public static final int FILE_NOTIFY_CHANGE_DIR_NAME;
/*     */   public static final int FILE_NOTIFY_CHANGE_ATTRIBUTES;
/*     */   public static final int FILE_NOTIFY_CHANGE_SIZE;
/*     */   public static final int FILE_NOTIFY_CHANGE_LAST_WRITE;
/*     */   public static final int FILE_NOTIFY_CHANGE_SECURITY;
/*     */   
/*     */   static {
/* 115 */     System.loadLibrary("win32refresh");
/* 116 */   } public static final boolean UNICODE = IsUnicode(); static {
/* 117 */     INVALID_HANDLE_VALUE = INVALID_HANDLE_VALUE();
/* 118 */     ERROR_SUCCESS = ERROR_SUCCESS();
/* 119 */     ERROR_INVALID_HANDLE = ERROR_INVALID_HANDLE();
/*     */     
/* 121 */     MAXIMUM_WAIT_OBJECTS = MAXIMUM_WAIT_OBJECTS();
/* 122 */     MAX_PATH = MAX_PATH();
/* 123 */     INFINITE = INFINITE();
/*     */     
/* 125 */     WAIT_TIMEOUT = WAIT_TIMEOUT();
/* 126 */     WAIT_OBJECT_0 = WAIT_OBJECT_0();
/* 127 */     WAIT_ABANDONED_0 = WAIT_ABANDONED_0();
/* 128 */     WAIT_FAILED = WAIT_FAILED();
/*     */     
/* 130 */     FILE_NOTIFY_CHANGE_FILE_NAME = FILE_NOTIFY_CHANGE_FILE_NAME();
/* 131 */     FILE_NOTIFY_CHANGE_DIR_NAME = FILE_NOTIFY_CHANGE_DIR_NAME();
/* 132 */     FILE_NOTIFY_CHANGE_ATTRIBUTES = FILE_NOTIFY_CHANGE_ATTRIBUTES();
/* 133 */     FILE_NOTIFY_CHANGE_SIZE = FILE_NOTIFY_CHANGE_SIZE();
/* 134 */     FILE_NOTIFY_CHANGE_LAST_WRITE = FILE_NOTIFY_CHANGE_LAST_WRITE();
/* 135 */     FILE_NOTIFY_CHANGE_SECURITY = FILE_NOTIFY_CHANGE_SECURITY();
/* 136 */     FILE_NOTIFY_ALL = FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_DIR_NAME | FILE_NOTIFY_CHANGE_ATTRIBUTES | FILE_NOTIFY_CHANGE_SIZE | FILE_NOTIFY_CHANGE_LAST_WRITE | FILE_NOTIFY_CHANGE_SECURITY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long FindFirstChangeNotification(String lpPathName, boolean bWatchSubtree, int dwNotifyFilter) {
/* 161 */     if (UNICODE)
/* 162 */       return FindFirstChangeNotificationW(lpPathName, bWatchSubtree, dwNotifyFilter); 
/* 163 */     return FindFirstChangeNotificationA(Convert.toPlatformBytes(lpPathName), bWatchSubtree, dwNotifyFilter);
/*     */   }
/*     */   
/*     */   private static native long FindFirstChangeNotificationW(String paramString, boolean paramBoolean, int paramInt);
/*     */   
/*     */   private static native long FindFirstChangeNotificationA(byte[] paramArrayOfbyte, boolean paramBoolean, int paramInt);
/*     */   
/*     */   public static native boolean FindCloseChangeNotification(long paramLong);
/*     */   
/*     */   public static native boolean FindNextChangeNotification(long paramLong);
/*     */   
/*     */   public static native int WaitForMultipleObjects(int paramInt1, long[] paramArrayOflong, boolean paramBoolean, int paramInt2);
/*     */   
/*     */   private static native boolean IsUnicode();
/*     */   
/*     */   public static native int GetLastError();
/*     */   
/*     */   private static native int FILE_NOTIFY_CHANGE_LAST_WRITE();
/*     */   
/*     */   private static native int FILE_NOTIFY_CHANGE_DIR_NAME();
/*     */   
/*     */   private static native int FILE_NOTIFY_CHANGE_ATTRIBUTES();
/*     */   
/*     */   private static native int FILE_NOTIFY_CHANGE_SIZE();
/*     */   
/*     */   private static native int FILE_NOTIFY_CHANGE_FILE_NAME();
/*     */   
/*     */   private static native int FILE_NOTIFY_CHANGE_SECURITY();
/*     */   
/*     */   private static native int MAXIMUM_WAIT_OBJECTS();
/*     */   
/*     */   private static native int MAX_PATH();
/*     */   
/*     */   private static native int INFINITE();
/*     */   
/*     */   private static native int WAIT_OBJECT_0();
/*     */   
/*     */   private static native int WAIT_ABANDONED_0();
/*     */   
/*     */   private static native int WAIT_FAILED();
/*     */   
/*     */   private static native int WAIT_TIMEOUT();
/*     */   
/*     */   private static native int ERROR_INVALID_HANDLE();
/*     */   
/*     */   private static native int ERROR_SUCCESS();
/*     */   
/*     */   private static native long INVALID_HANDLE_VALUE();
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\refresh\win32\Win32Natives.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */