/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import org.eclipse.core.internal.events.BuildCommand;
/*     */ import org.eclipse.core.resources.ICommand;
/*     */ import org.eclipse.core.resources.IProjectNature;
/*     */ import org.eclipse.core.runtime.content.IContentTypeMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProjectInfo
/*     */   extends ResourceInfo
/*     */ {
/*     */   protected ProjectDescription description;
/*     */   protected HashMap<String, IProjectNature> natures;
/*     */   protected Object propertyStore;
/*     */   protected IContentTypeMatcher matcher;
/*     */   
/*     */   public synchronized void discardNatures() {
/*  43 */     this.natures = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void fixupAfterMove() {
/*  58 */     this.natures = null;
/*     */     
/*  60 */     this.propertyStore = null;
/*  61 */     if (this.description != null) {
/*  62 */       ICommand[] buildSpec = this.description.getBuildSpec(false); byte b; int i; ICommand[] arrayOfICommand1;
/*  63 */       for (i = (arrayOfICommand1 = buildSpec).length, b = 0; b < i; ) { ICommand element = arrayOfICommand1[b];
/*  64 */         ((BuildCommand)element).setBuilders(null);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ProjectDescription getDescription() {
/*  72 */     return this.description;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IContentTypeMatcher getMatcher() {
/*  79 */     return this.matcher;
/*     */   }
/*     */ 
/*     */   
/*     */   public IProjectNature getNature(String natureId) {
/*  84 */     HashMap<String, IProjectNature> temp = this.natures;
/*  85 */     if (temp == null)
/*  86 */       return null; 
/*  87 */     return temp.get(natureId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getPropertyStore() {
/*  95 */     return this.propertyStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(ProjectDescription value) {
/* 102 */     if (this.description != null) {
/*     */ 
/*     */ 
/*     */       
/* 106 */       ICommand[] oldSpec = this.description.buildSpec;
/* 107 */       ICommand[] newSpec = value.buildSpec;
/* 108 */       value.buildSpec = oldSpec;
/* 109 */       value.setBuildSpec(newSpec);
/*     */     } 
/* 111 */     this.description = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMatcher(IContentTypeMatcher matcher) {
/* 118 */     this.matcher = matcher;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setNature(String natureId, IProjectNature value) {
/* 124 */     if (value == null)
/* 125 */     { if (this.natures == null)
/*     */         return; 
/* 127 */       HashMap<String, IProjectNature> temp = (HashMap<String, IProjectNature>)this.natures.clone();
/* 128 */       temp.remove(natureId);
/* 129 */       if (temp.isEmpty()) {
/* 130 */         this.natures = null;
/*     */       } else {
/* 132 */         this.natures = temp;
/*     */       }  }
/* 134 */     else { HashMap<String, IProjectNature> temp = this.natures;
/* 135 */       if (temp == null) {
/* 136 */         temp = new HashMap<>(5);
/*     */       } else {
/* 138 */         temp = (HashMap<String, IProjectNature>)this.natures.clone();
/* 139 */       }  temp.put(natureId, value);
/* 140 */       this.natures = temp; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPropertyStore(Object value) {
/* 149 */     this.propertyStore = value;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ProjectInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */