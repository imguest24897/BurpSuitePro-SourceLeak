/*    */ package org.eclipse.core.internal.resources;
/*    */ 
/*    */ import org.eclipse.core.internal.utils.Policy;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ import org.eclipse.core.runtime.OperationCanceledException;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.core.runtime.jobs.Job;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class InternalWorkspaceJob
/*    */   extends Job
/*    */ {
/*    */   private Workspace workspace;
/*    */   
/*    */   public InternalWorkspaceJob(String name, Workspace workspace) {
/* 29 */     super(name);
/* 30 */     this.workspace = workspace;
/*    */   }
/*    */ 
/*    */   
/*    */   public final IStatus run(IProgressMonitor monitor) {
/* 35 */     monitor = Policy.monitorFor(monitor);
/*    */     try {
/* 37 */       int depth = -1;
/* 38 */       WorkManager workManager = this.workspace.getWorkManager();
/*    */       try {
/* 40 */         this.workspace.prepareOperation(null, monitor);
/* 41 */         this.workspace.beginOperation(true);
/* 42 */         depth = workManager.beginUnprotected();
/* 43 */         return runInWorkspace(monitor);
/* 44 */       } catch (OperationCanceledException operationCanceledException) {
/* 45 */         workManager.operationCanceled();
/* 46 */         return Status.CANCEL_STATUS;
/*    */       } finally {
/* 48 */         if (depth >= 0)
/* 49 */           workManager.endUnprotected(depth); 
/* 50 */         this.workspace.endOperation(null, false);
/*    */       } 
/* 52 */     } catch (CoreException e) {
/* 53 */       return e.getStatus();
/*    */     } 
/*    */   }
/*    */   
/*    */   protected abstract IStatus runInWorkspace(IProgressMonitor paramIProgressMonitor) throws CoreException;
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\InternalWorkspaceJob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */