/*    */ package org.eclipse.core.internal.properties;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.eclipse.core.internal.localstore.Bucket;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PropertyCopyVisitor
/*    */   extends Bucket.Visitor
/*    */ {
/* 38 */   private List<PropertyBucket.PropertyEntry> changes = new ArrayList<>();
/*    */   private IPath destination;
/*    */   private IPath source;
/*    */   
/*    */   public PropertyCopyVisitor(IPath source, IPath destination) {
/* 43 */     this.source = source;
/* 44 */     this.destination = destination;
/*    */   }
/*    */ 
/*    */   
/*    */   public void afterSaving(Bucket bucket) throws CoreException {
/* 49 */     saveChanges((PropertyBucket)bucket);
/* 50 */     this.changes.clear();
/*    */   }
/*    */   
/*    */   private void saveChanges(PropertyBucket bucket) throws CoreException {
/* 54 */     if (this.changes.isEmpty()) {
/*    */       return;
/*    */     }
/* 57 */     Iterator<PropertyBucket.PropertyEntry> i = this.changes.iterator();
/* 58 */     PropertyBucket.PropertyEntry entry = i.next();
/* 59 */     PropertyManager2.this.tree.loadBucketFor(entry.getPath());
/* 60 */     bucket.setProperties(entry);
/* 61 */     while (i.hasNext())
/* 62 */       bucket.setProperties(i.next()); 
/* 63 */     bucket.save();
/*    */   }
/*    */ 
/*    */   
/*    */   public int visit(Bucket.Entry entry) {
/* 68 */     PropertyBucket.PropertyEntry sourceEntry = (PropertyBucket.PropertyEntry)entry;
/* 69 */     IPath destinationPath = this.destination.append(sourceEntry.getPath().removeFirstSegments(this.source.segmentCount()));
/* 70 */     PropertyBucket.PropertyEntry destinationEntry = new PropertyBucket.PropertyEntry(destinationPath, sourceEntry);
/* 71 */     this.changes.add(destinationEntry);
/* 72 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\properties\PropertyManager2$PropertyCopyVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */