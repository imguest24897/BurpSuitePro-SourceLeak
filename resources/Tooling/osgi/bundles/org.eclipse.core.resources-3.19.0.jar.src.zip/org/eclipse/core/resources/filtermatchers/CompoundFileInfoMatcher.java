/*    */ package org.eclipse.core.resources.filtermatchers;
/*    */ 
/*    */ import org.eclipse.core.internal.resources.FilterDescriptor;
/*    */ import org.eclipse.core.resources.FileInfoMatcherDescription;
/*    */ import org.eclipse.core.resources.IFilterMatcherDescriptor;
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CompoundFileInfoMatcher
/*    */   extends AbstractFileInfoMatcher
/*    */ {
/*    */   protected AbstractFileInfoMatcher[] matchers;
/*    */   
/*    */   private AbstractFileInfoMatcher instantiate(IProject project, FileInfoMatcherDescription filter) throws CoreException {
/* 30 */     IFilterMatcherDescriptor desc = project.getWorkspace().getFilterMatcherDescriptor(filter.getId());
/* 31 */     if (desc != null) {
/* 32 */       AbstractFileInfoMatcher matcher = ((FilterDescriptor)desc).createFilter();
/* 33 */       matcher.initialize(project, filter.getArguments());
/* 34 */       return matcher;
/*    */     } 
/* 36 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public final void initialize(IProject project, Object arguments) throws CoreException {
/* 41 */     FileInfoMatcherDescription[] filters = (FileInfoMatcherDescription[])arguments;
/* 42 */     this.matchers = new AbstractFileInfoMatcher[(filters != null) ? filters.length : 0];
/* 43 */     for (int i = 0; i < this.matchers.length; i++)
/* 44 */       this.matchers[i] = instantiate(project, filters[i]); 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\filtermatchers\CompoundFileInfoMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */