/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.internal.events.ILifecycleListener;
/*     */ import org.eclipse.core.internal.events.LifecycleEvent;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IProjectNature;
/*     */ import org.eclipse.core.resources.IProjectNatureDescriptor;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ public class NatureManager
/*     */   implements ILifecycleListener, IManager
/*     */ {
/*     */   private Map<String, IProjectNatureDescriptor> descriptors;
/*  36 */   private final Map<Project, String[]> natureEnablements = (Map)new HashMap<>(20);
/*     */   
/*     */   private Map<String, String> buildersToNatures;
/*     */   
/*     */   private static final byte WHITE = 0;
/*     */   
/*     */   private static final byte GREY = 1;
/*     */   
/*     */   private static final byte BLACK = 2;
/*     */   
/*     */   private Workspace workspace;
/*     */   
/*     */   protected NatureManager(Workspace workspace) {
/*  49 */     this.workspace = workspace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] computeNatureEnablements(Project project) {
/*  58 */     ProjectDescription description = project.internalGetDescription();
/*  59 */     if (description == null)
/*  60 */       return new String[0]; 
/*  61 */     String[] natureIds = description.getNatureIds();
/*  62 */     int count = natureIds.length;
/*  63 */     if (count == 0) {
/*  64 */       return natureIds;
/*     */     }
/*     */     
/*  67 */     HashSet<String> candidates = new HashSet<>(count * 2);
/*     */     
/*  69 */     HashMap<String, ArrayList<String>> setsToNatures = new HashMap<>(count);
/*  70 */     for (int i = 0; i < count; i++) {
/*  71 */       String id = natureIds[i];
/*  72 */       ProjectNatureDescriptor desc = (ProjectNatureDescriptor)getNatureDescriptor(id);
/*  73 */       if (desc != null) {
/*     */         
/*  75 */         if (!desc.hasCycle) {
/*  76 */           candidates.add(id);
/*     */         }
/*  78 */         String[] setIds = desc.getNatureSetIds(); byte b1; int k; String[] arrayOfString2;
/*  79 */         for (k = (arrayOfString2 = setIds).length, b1 = 0; b1 < k; ) { String set = arrayOfString2[b1];
/*  80 */           ArrayList<String> current = setsToNatures.get(set);
/*  81 */           if (current == null) {
/*  82 */             current = new ArrayList<>(5);
/*  83 */             setsToNatures.put(set, current);
/*     */           } 
/*  85 */           current.add(id); b1++; }
/*     */       
/*     */       } 
/*     */     } 
/*  89 */     for (ArrayList<String> setMembers : setsToNatures.values()) {
/*  90 */       if (setMembers.size() > 1) {
/*  91 */         candidates.removeAll(setMembers);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  97 */     String[] orderedCandidates = candidates.<String>toArray(new String[candidates.size()]);
/*  98 */     orderedCandidates = sortNatureSet(orderedCandidates); byte b; int j; String[] arrayOfString1;
/*  99 */     for (j = (arrayOfString1 = orderedCandidates).length, b = 0; b < j; ) { String id = arrayOfString1[b];
/* 100 */       IProjectNatureDescriptor desc = getNatureDescriptor(id);
/* 101 */       String[] required = desc.getRequiredNatureIds(); byte b1; int k; String[] arrayOfString2;
/* 102 */       for (k = (arrayOfString2 = required).length, b1 = 0; b1 < k; ) { String t = arrayOfString2[b1];
/* 103 */         if (!candidates.contains(t)) {
/* 104 */           candidates.remove(id); break;
/*     */         } 
/*     */         b1++; }
/*     */       
/*     */       b++; }
/*     */     
/* 110 */     return candidates.<String>toArray(new String[candidates.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized IProjectNatureDescriptor getNatureDescriptor(String natureId) {
/* 117 */     lazyInitialize();
/* 118 */     return this.descriptors.get(natureId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized IProjectNatureDescriptor[] getNatureDescriptors() {
/* 125 */     lazyInitialize();
/* 126 */     Collection<IProjectNatureDescriptor> values = this.descriptors.values();
/* 127 */     return values.<IProjectNatureDescriptor>toArray(new IProjectNatureDescriptor[values.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void handleEvent(LifecycleEvent event) {
/* 132 */     switch (event.kind) {
/*     */       case 1:
/*     */       case 2:
/*     */       case 16:
/*     */       case 32:
/*     */       case 64:
/* 138 */         flushEnablements((IProject)event.resource);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configureNature(final Project project, final String natureID, final MultiStatus errors) {
/* 146 */     ISafeRunnable code = new ISafeRunnable()
/*     */       {
/*     */         public void run() throws Exception {
/* 149 */           IProjectNature nature = NatureManager.this.createNature(project, natureID);
/* 150 */           nature.configure();
/* 151 */           ProjectInfo info = (ProjectInfo)project.getResourceInfo(false, true);
/* 152 */           info.setNature(natureID, nature);
/*     */         }
/*     */ 
/*     */         
/*     */         public void handleException(Throwable exception) {
/* 157 */           if (exception instanceof CoreException) {
/* 158 */             errors.add(((CoreException)exception).getStatus());
/*     */           } else {
/* 160 */             errors.add((IStatus)new ResourceStatus(566, project.getFullPath(), NLS.bind(Messages.resources_errorNature, natureID), exception));
/*     */           }  }
/*     */       };
/* 163 */     if (Policy.DEBUG_NATURES) {
/* 164 */       Policy.debug("Configuring nature: " + natureID + " on project: " + project.getName());
/*     */     }
/* 166 */     SafeRunner.run(code);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configureNatures(Project project, ProjectDescription oldDescription, ProjectDescription newDescription, MultiStatus status) {
/* 179 */     HashSet<String> oldNatures = new HashSet<>(Arrays.asList(oldDescription.getNatureIds(false)));
/* 180 */     HashSet<String> newNatures = new HashSet<>(Arrays.asList(newDescription.getNatureIds(false)));
/* 181 */     if (oldNatures.equals(newNatures))
/*     */       return; 
/* 183 */     HashSet<String> deletions = (HashSet<String>)oldNatures.clone();
/* 184 */     HashSet<String> additions = (HashSet<String>)newNatures.clone();
/* 185 */     additions.removeAll(oldNatures);
/* 186 */     deletions.removeAll(newNatures);
/*     */     
/* 188 */     IStatus result = validateAdditions(newNatures, additions, project);
/* 189 */     if (!result.isOK()) {
/* 190 */       status.merge(result);
/*     */       return;
/*     */     } 
/* 193 */     result = validateRemovals(newNatures, deletions);
/* 194 */     if (!result.isOK()) {
/* 195 */       status.merge(result);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 200 */     oldDescription.setNatureIds(newDescription.getNatureIds(true));
/* 201 */     flushEnablements(project);
/*     */     
/* 203 */     String[] ordered = null;
/* 204 */     if (deletions.size() > 0) {
/* 205 */       ordered = sortNatureSet(deletions.<String>toArray(new String[deletions.size()]));
/* 206 */       for (int i = ordered.length; --i >= 0;)
/* 207 */         deconfigureNature(project, ordered[i], status); 
/*     */     } 
/* 209 */     if (additions.size() > 0) {
/* 210 */       ordered = sortNatureSet(additions.<String>toArray(new String[additions.size()])); byte b; int i; String[] arrayOfString;
/* 211 */       for (i = (arrayOfString = ordered).length, b = 0; b < i; ) { String element = arrayOfString[b];
/* 212 */         configureNature(project, element, status);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected IProjectNature createNature(Project project, String natureID) throws CoreException {
/* 220 */     IExtension extension = Platform.getExtensionRegistry().getExtension("org.eclipse.core.resources", "natures", natureID);
/* 221 */     if (extension == null) {
/* 222 */       String message = NLS.bind(Messages.resources_natureExtension, natureID);
/* 223 */       throw new ResourceException(2, project.getFullPath(), message, null);
/*     */     } 
/* 225 */     IConfigurationElement[] configs = extension.getConfigurationElements();
/* 226 */     if (configs.length < 1) {
/* 227 */       String message = NLS.bind(Messages.resources_natureClass, natureID);
/* 228 */       throw new ResourceException(2, project.getFullPath(), message, null);
/*     */     } 
/*     */     
/* 231 */     IConfigurationElement config = null;
/* 232 */     for (int i = 0; config == null && i < configs.length; i++) {
/* 233 */       if ("runtime".equalsIgnoreCase(configs[i].getName()))
/* 234 */         config = configs[i]; 
/* 235 */     }  if (config == null) {
/* 236 */       String message = NLS.bind(Messages.resources_natureFormat, natureID);
/* 237 */       throw new ResourceException(2, project.getFullPath(), message, null);
/*     */     } 
/*     */     try {
/* 240 */       IProjectNature nature = (IProjectNature)config.createExecutableExtension("run");
/* 241 */       nature.setProject(project);
/* 242 */       return nature;
/* 243 */     } catch (ClassCastException e) {
/* 244 */       String message = NLS.bind(Messages.resources_natureImplement, natureID);
/* 245 */       throw new ResourceException(2, project.getFullPath(), message, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void deconfigureNature(final Project project, final String natureID, final MultiStatus status) {
/* 253 */     final ProjectInfo info = (ProjectInfo)project.getResourceInfo(false, true);
/* 254 */     IProjectNature existingNature = info.getNature(natureID);
/* 255 */     if (existingNature == null) {
/*     */       
/*     */       try {
/* 258 */         existingNature = createNature(project, natureID);
/* 259 */       } catch (CoreException coreException) {
/*     */         return;
/*     */       } 
/*     */     }
/*     */     
/* 264 */     final IProjectNature nature = existingNature;
/* 265 */     ISafeRunnable code = new ISafeRunnable()
/*     */       {
/*     */         public void run() throws Exception {
/* 268 */           nature.deconfigure();
/* 269 */           info.setNature(natureID, null);
/*     */         }
/*     */ 
/*     */         
/*     */         public void handleException(Throwable exception) {
/* 274 */           if (exception instanceof CoreException) {
/* 275 */             status.add(((CoreException)exception).getStatus());
/*     */           } else {
/* 277 */             status.add((IStatus)new ResourceStatus(566, project.getFullPath(), NLS.bind(Messages.resources_natureDeconfig, natureID), exception));
/*     */           }  }
/*     */       };
/* 280 */     if (Policy.DEBUG_NATURES) {
/* 281 */       Policy.debug("Deconfiguring nature: " + natureID + " on project: " + project.getName());
/*     */     }
/* 283 */     SafeRunner.run(code);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void detectCycles() {
/* 290 */     Collection<IProjectNatureDescriptor> values = this.descriptors.values();
/* 291 */     ProjectNatureDescriptor[] natures = values.<ProjectNatureDescriptor>toArray(new ProjectNatureDescriptor[values.size()]); byte b; int i; ProjectNatureDescriptor[] arrayOfProjectNatureDescriptor1;
/* 292 */     for (i = (arrayOfProjectNatureDescriptor1 = natures).length, b = 0; b < i; ) { ProjectNatureDescriptor nature = arrayOfProjectNatureDescriptor1[b];
/* 293 */       if (nature.colour == 0) {
/* 294 */         hasCycles(nature);
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   protected IStatus failure(String reason) {
/* 301 */     return (IStatus)new ResourceStatus(35, reason);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized String findNatureForBuilder(String builderID) {
/* 309 */     if (this.buildersToNatures == null) {
/* 310 */       this.buildersToNatures = new HashMap<>(10);
/* 311 */       IProjectNatureDescriptor[] descs = getNatureDescriptors(); byte b; int i; IProjectNatureDescriptor[] arrayOfIProjectNatureDescriptor1;
/* 312 */       for (i = (arrayOfIProjectNatureDescriptor1 = descs).length, b = 0; b < i; ) { IProjectNatureDescriptor desc = arrayOfIProjectNatureDescriptor1[b];
/* 313 */         String natureId = desc.getNatureId();
/* 314 */         String[] builders = ((ProjectNatureDescriptor)desc).getBuilderIds(); byte b1; int j; String[] arrayOfString1;
/* 315 */         for (j = (arrayOfString1 = builders).length, b1 = 0; b1 < j; ) { String builder = arrayOfString1[b1];
/*     */           
/* 317 */           this.buildersToNatures.put(builder, natureId); b1++; }
/*     */          b++; }
/*     */     
/*     */     } 
/* 321 */     return this.buildersToNatures.get(builderID);
/*     */   }
/*     */   
/*     */   private synchronized void flushEnablements(IProject project) {
/* 325 */     this.natureEnablements.remove(project);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized String[] getEnabledNatures(Project project) {
/* 333 */     String[] enabled = this.natureEnablements.get(project);
/* 334 */     if (enabled != null)
/* 335 */       return enabled; 
/* 336 */     enabled = computeNatureEnablements(project);
/* 337 */     this.natureEnablements.put(project, enabled);
/* 338 */     return enabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasCycles(ProjectNatureDescriptor desc) {
/* 347 */     if (desc.colour == 2)
/*     */     {
/* 349 */       return desc.hasCycle;
/*     */     }
/*     */     
/* 352 */     if (desc.colour == 1) {
/* 353 */       desc.hasCycle = true;
/* 354 */       desc.colour = 2;
/* 355 */       return true;
/*     */     } 
/*     */     
/* 358 */     desc.colour = 1;
/*     */ 
/*     */     
/* 361 */     String[] required = desc.getRequiredNatureIds(); byte b; int i; String[] arrayOfString1;
/* 362 */     for (i = (arrayOfString1 = required).length, b = 0; b < i; ) { String element = arrayOfString1[b];
/* 363 */       ProjectNatureDescriptor dependency = (ProjectNatureDescriptor)getNatureDescriptor(element);
/*     */       
/* 365 */       if (dependency != null && hasCycles(dependency)) {
/* 366 */         desc.hasCycle = true;
/* 367 */         desc.colour = 2;
/* 368 */         return true;
/*     */       }  b++; }
/*     */     
/* 371 */     desc.hasCycle = false;
/* 372 */     desc.colour = 2;
/* 373 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean hasLinks(IProject project) {
/*     */     try {
/* 381 */       IResource[] children = project.members(); byte b; int i; IResource[] arrayOfIResource1;
/* 382 */       for (i = (arrayOfIResource1 = children).length, b = 0; b < i; ) { IResource element = arrayOfIResource1[b];
/* 383 */         if (element.isLinked())
/* 384 */           return true;  b++; } 
/* 385 */     } catch (CoreException e) {
/*     */       
/* 387 */       Policy.log(e.getStatus());
/*     */     } 
/* 389 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String hasSetOverlap(IProjectNatureDescriptor one, IProjectNatureDescriptor two) {
/* 398 */     if (one == null || two == null) {
/* 399 */       return null;
/*     */     }
/*     */     
/* 402 */     String[] setsOne = one.getNatureSetIds();
/* 403 */     String[] setsTwo = two.getNatureSetIds(); byte b; int i; String[] arrayOfString1;
/* 404 */     for (i = (arrayOfString1 = setsOne).length, b = 0; b < i; ) { String element = arrayOfString1[b]; byte b1; int j; String[] arrayOfString;
/* 405 */       for (j = (arrayOfString = setsTwo).length, b1 = 0; b1 < j; ) { String element2 = arrayOfString[b1];
/* 406 */         if (element.equals(element2))
/* 407 */           return element;  b1++; }
/*     */       
/*     */       b++; }
/*     */     
/* 411 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void insert(ArrayList<String> list, Set<String> seen, String id) {
/* 418 */     if (seen.contains(id))
/*     */       return; 
/* 420 */     seen.add(id);
/*     */     
/* 422 */     IProjectNatureDescriptor desc = getNatureDescriptor(id);
/* 423 */     if (desc != null) {
/* 424 */       String[] prereqs = desc.getRequiredNatureIds(); byte b; int i; String[] arrayOfString1;
/* 425 */       for (i = (arrayOfString1 = prereqs).length, b = 0; b < i; ) { String prereq = arrayOfString1[b];
/* 426 */         insert(list, seen, prereq); b++; }
/*     */     
/* 428 */     }  list.add(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNatureEnabled(Project project, String id) {
/* 437 */     String[] enabled = getEnabledNatures(project); byte b; int i; String[] arrayOfString1;
/* 438 */     for (i = (arrayOfString1 = enabled).length, b = 0; b < i; ) { String element = arrayOfString1[b];
/* 439 */       if (element.equals(id))
/* 440 */         return true;  b++; }
/*     */     
/* 442 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void lazyInitialize() {
/* 450 */     if (this.descriptors != null)
/*     */       return; 
/* 452 */     IExtensionPoint point = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.core.resources", "natures");
/* 453 */     IExtension[] extensions = point.getExtensions();
/* 454 */     this.descriptors = new HashMap<>(extensions.length * 2 + 1); byte b; int i; IExtension[] arrayOfIExtension1;
/* 455 */     for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension1[b];
/* 456 */       IProjectNatureDescriptor desc = null;
/*     */       try {
/* 458 */         desc = new ProjectNatureDescriptor(extension);
/* 459 */       } catch (CoreException e) {
/* 460 */         Policy.log(e.getStatus());
/*     */       } 
/* 462 */       if (desc != null) {
/* 463 */         this.descriptors.put(desc.getNatureId(), desc);
/*     */       }
/*     */       b++; }
/*     */     
/* 467 */     detectCycles();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown(IProgressMonitor monitor) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] sortNatureSet(String[] natureIds) {
/* 479 */     int count = natureIds.length;
/* 480 */     if (count == 0)
/* 481 */       return natureIds; 
/* 482 */     ArrayList<String> result = new ArrayList<>(count);
/* 483 */     HashSet<String> seen = new HashSet<>(count);
/* 484 */     for (int i = 0; i < count; i++) {
/* 485 */       insert(result, seen, natureIds[i]);
/*     */     }
/* 487 */     seen.clear();
/* 488 */     seen.addAll(Arrays.asList(natureIds));
/* 489 */     for (Iterator<String> it = result.iterator(); it.hasNext(); ) {
/* 490 */       Object id = it.next();
/* 491 */       if (!seen.contains(id))
/* 492 */         it.remove(); 
/*     */     } 
/* 494 */     return result.<String>toArray(new String[result.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void startup(IProgressMonitor monitor) {
/* 499 */     this.workspace.addLifecycleListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IStatus validateAdditions(HashSet<String> newNatures, HashSet<String> additions, IProject project) {
/* 513 */     Boolean hasLinks = null;
/*     */     
/* 515 */     for (String id : additions) {
/*     */       
/* 517 */       IProjectNatureDescriptor desc = getNatureDescriptor(id);
/* 518 */       if (desc == null) {
/* 519 */         return failure(NLS.bind(Messages.natures_missingNature, id));
/*     */       }
/*     */       
/* 522 */       if (((ProjectNatureDescriptor)desc).hasCycle) {
/* 523 */         return failure(NLS.bind(Messages.natures_hasCycle, id));
/*     */       }
/*     */       
/* 526 */       String[] required = desc.getRequiredNatureIds(); byte b; int i; String[] arrayOfString1;
/* 527 */       for (i = (arrayOfString1 = required).length, b = 0; b < i; ) { String r = arrayOfString1[b];
/* 528 */         if (!newNatures.contains(r)) {
/* 529 */           return failure(NLS.bind(Messages.natures_missingPrerequisite, id, r));
/*     */         }
/*     */         b++; }
/*     */       
/* 533 */       for (String current : newNatures) {
/* 534 */         if (!current.equals(id)) {
/* 535 */           String overlap = hasSetOverlap(desc, getNatureDescriptor(current));
/* 536 */           if (overlap != null) {
/* 537 */             return failure(NLS.bind(Messages.natures_multipleSetMembers, overlap));
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 542 */       if (!desc.isLinkingAllowed()) {
/* 543 */         if (hasLinks == null) {
/* 544 */           hasLinks = hasLinks(project) ? Boolean.TRUE : Boolean.FALSE;
/*     */         }
/* 546 */         if (hasLinks.booleanValue())
/* 547 */           return failure(NLS.bind(Messages.links_vetoNature, project.getName(), id)); 
/*     */       } 
/*     */     } 
/* 550 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateLinkCreation(String[] natureIds) {
/*     */     byte b;
/*     */     int i;
/*     */     String[] arrayOfString;
/* 562 */     for (i = (arrayOfString = natureIds).length, b = 0; b < i; ) { String natureId = arrayOfString[b];
/* 563 */       IProjectNatureDescriptor desc = getNatureDescriptor(natureId);
/* 564 */       if (desc != null && !desc.isLinkingAllowed()) {
/* 565 */         String msg = NLS.bind(Messages.links_natureVeto, desc.getLabel());
/* 566 */         return (IStatus)new ResourceStatus(378, msg);
/*     */       }  b++; }
/*     */     
/* 569 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IStatus validateRemovals(HashSet<String> newNatures, HashSet<String> deletions) {
/* 584 */     for (String currentID : newNatures) {
/* 585 */       IProjectNatureDescriptor desc = getNatureDescriptor(currentID);
/* 586 */       if (desc != null) {
/* 587 */         String[] required = desc.getRequiredNatureIds(); byte b; int i; String[] arrayOfString1;
/* 588 */         for (i = (arrayOfString1 = required).length, b = 0; b < i; ) { String element = arrayOfString1[b];
/* 589 */           if (deletions.contains(element))
/* 590 */             return failure(NLS.bind(Messages.natures_invalidRemoval, element, currentID)); 
/*     */           b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 595 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateNatureSet(String[] natureIds) {
/* 602 */     int count = natureIds.length;
/* 603 */     if (count == 0)
/* 604 */       return Status.OK_STATUS; 
/* 605 */     String msg = Messages.natures_invalidSet;
/* 606 */     MultiStatus result = new MultiStatus("org.eclipse.core.resources", 35, msg, null);
/*     */ 
/*     */     
/* 609 */     HashSet<String> natures = new HashSet<>(count * 2);
/*     */     
/* 611 */     HashSet<String> sets = new HashSet<>(count); int i;
/* 612 */     for (i = 0; i < count; i++) {
/* 613 */       String id = natureIds[i];
/* 614 */       ProjectNatureDescriptor desc = (ProjectNatureDescriptor)getNatureDescriptor(id);
/* 615 */       if (desc == null) {
/* 616 */         result.add(failure(NLS.bind(Messages.natures_missingNature, id)));
/*     */       } else {
/*     */         
/* 619 */         if (desc.hasCycle)
/* 620 */           result.add(failure(NLS.bind(Messages.natures_hasCycle, id))); 
/* 621 */         if (!natures.add(id)) {
/* 622 */           result.add(failure(NLS.bind(Messages.natures_duplicateNature, id)));
/*     */         }
/* 624 */         String[] setIds = desc.getNatureSetIds(); byte b; int j; String[] arrayOfString1;
/* 625 */         for (j = (arrayOfString1 = setIds).length, b = 0; b < j; ) { String setId = arrayOfString1[b];
/* 626 */           if (!sets.add(setId))
/* 627 */             result.add(failure(NLS.bind(Messages.natures_multipleSetMembers, setId))); 
/*     */           b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 632 */     for (i = 0; i < count; i++) {
/* 633 */       IProjectNatureDescriptor desc = getNatureDescriptor(natureIds[i]);
/* 634 */       if (desc != null) {
/*     */         
/* 636 */         String[] required = desc.getRequiredNatureIds(); byte b; int j; String[] arrayOfString1;
/* 637 */         for (j = (arrayOfString1 = required).length, b = 0; b < j; ) { String r = arrayOfString1[b];
/* 638 */           if (!natures.contains(r))
/* 639 */             result.add(failure(NLS.bind(Messages.natures_missingPrerequisite, natureIds[i], r))); 
/*     */           b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 644 */     return result.isOK() ? Status.OK_STATUS : (IStatus)result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\NatureManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */