/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MarkerReader_1
/*     */   extends MarkerReader
/*     */ {
/*     */   public static final int INDEX = 1;
/*     */   public static final int QNAME = 2;
/*     */   public static final int ATTRIBUTE_NULL = -1;
/*     */   public static final int ATTRIBUTE_BOOLEAN = 0;
/*     */   public static final int ATTRIBUTE_INTEGER = 1;
/*     */   public static final int ATTRIBUTE_STRING = 2;
/*     */   
/*     */   public MarkerReader_1(Workspace workspace) {
/*  42 */     super(workspace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void read(DataInputStream input, boolean generateDeltas) throws IOException, CoreException {
/*     */     try {
/*  70 */       List<String> readTypes = new ArrayList<>(5);
/*     */       while (true) {
/*  72 */         Path path = new Path(input.readUTF());
/*  73 */         int markersSize = input.readInt();
/*  74 */         MarkerSet markers = new MarkerSet(markersSize);
/*  75 */         for (int i = 0; i < markersSize; i++) {
/*  76 */           markers.add(readMarkerInfo(input, readTypes));
/*     */         }
/*     */ 
/*     */         
/*  80 */         ResourceInfo info = this.workspace.getResourceInfo((IPath)path, false, false);
/*  81 */         if (info == null)
/*     */           continue; 
/*  83 */         info.setMarkers(markers);
/*  84 */         if (generateDeltas) {
/*  85 */           Resource resource = this.workspace.newResource((IPath)path, info.getType());
/*     */ 
/*     */           
/*  88 */           IMarkerSetElement[] infos = markers.elements;
/*  89 */           ArrayList<MarkerDelta> deltas = new ArrayList<>(infos.length); byte b; int j; IMarkerSetElement[] arrayOfIMarkerSetElement1;
/*  90 */           for (j = (arrayOfIMarkerSetElement1 = infos).length, b = 0; b < j; ) { IMarkerSetElement info2 = arrayOfIMarkerSetElement1[b];
/*  91 */             if (info2 != null)
/*  92 */               deltas.add(new MarkerDelta(1, resource, (MarkerInfo)info2));  b++; }
/*  93 */            this.workspace.getMarkerManager().changedMarkers(resource, deltas.<IMarkerSetElement>toArray(new IMarkerSetElement[deltas.size()]));
/*     */         } 
/*     */       } 
/*  96 */     } catch (EOFException eOFException) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Map<String, Object> readAttributes(DataInputStream input) throws IOException {
/* 102 */     int attributesSize = input.readInt();
/* 103 */     if (attributesSize == 0)
/* 104 */       return null; 
/* 105 */     Map<String, Object> result = new HashMap<>(attributesSize);
/* 106 */     for (int j = 0; j < attributesSize; j++) {
/* 107 */       String key = input.readUTF();
/* 108 */       int type = input.readInt();
/* 109 */       Object value = null;
/* 110 */       switch (type) {
/*     */         case 1:
/* 112 */           value = Integer.valueOf(input.readInt());
/*     */           break;
/*     */         case 0:
/* 115 */           value = Boolean.valueOf(input.readBoolean());
/*     */           break;
/*     */         case 2:
/* 118 */           value = input.readUTF();
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 124 */       if (value != null)
/* 125 */         result.put(key, value); 
/*     */     } 
/* 127 */     return result.isEmpty() ? null : result;
/*     */   }
/*     */   private MarkerInfo readMarkerInfo(DataInputStream input, List<String> readTypes) throws IOException, CoreException {
/*     */     Map<String, Object> map, map1;
/* 131 */     long creationTime, id = input.readLong();
/* 132 */     int constant = input.readInt();
/* 133 */     String type = null;
/* 134 */     switch (constant) {
/*     */       case 2:
/* 136 */         type = input.readUTF();
/* 137 */         readTypes.add(type);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 147 */         map = readAttributes(input);
/* 148 */         creationTime = 0L;
/* 149 */         return new MarkerInfo(map, false, creationTime, type, id);case 1: type = readTypes.get(input.readInt()); map1 = readAttributes(input); creationTime = 0L; return new MarkerInfo(map1, false, creationTime, type, id);
/*     */     } 
/*     */     String str1 = Messages.resources_readMarkers;
/*     */     throw new ResourceException(567, null, str1, null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\MarkerReader_1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */