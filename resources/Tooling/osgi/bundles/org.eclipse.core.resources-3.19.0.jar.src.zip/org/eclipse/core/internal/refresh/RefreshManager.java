/*     */ package org.eclipse.core.internal.refresh;
/*     */ 
/*     */ import org.eclipse.core.internal.resources.IManager;
/*     */ import org.eclipse.core.internal.resources.Workspace;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.resources.refresh.IRefreshMonitor;
/*     */ import org.eclipse.core.resources.refresh.IRefreshResult;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Preferences;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RefreshManager
/*     */   implements IRefreshResult, IManager, Preferences.IPropertyChangeListener
/*     */ {
/*     */   public static final String DEBUG_PREFIX = "Auto-refresh: ";
/*     */   volatile MonitorManager monitors;
/*     */   private volatile RefreshJob refreshJob;
/*     */   private Workspace workspace;
/*     */   
/*     */   public RefreshManager(Workspace workspace) {
/*  46 */     this.workspace = workspace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void manageAutoRefresh(boolean enabled, IProgressMonitor progressMonitor) {
/*  54 */     if (this.refreshJob == null) {
/*     */       return;
/*     */     }
/*  57 */     SubMonitor subMonitor = SubMonitor.convert(progressMonitor, 1);
/*  58 */     if (enabled) {
/*  59 */       this.monitors.start((IProgressMonitor)subMonitor.split(1));
/*     */     } else {
/*  61 */       this.refreshJob.cancel();
/*  62 */       this.monitors.stop();
/*     */     } 
/*     */   }
/*     */   
/*     */   Workspace getWorkspace() {
/*  67 */     return this.workspace;
/*     */   }
/*     */ 
/*     */   
/*     */   public void monitorFailed(IRefreshMonitor monitor, IResource resource) {
/*  72 */     if (this.monitors != null) {
/*  73 */       this.monitors.monitorFailed(monitor, resource);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void propertyChange(Preferences.PropertyChangeEvent event) {
/*  84 */     String property = event.getProperty();
/*  85 */     if ("refresh.enabled".equals(property)) {
/*  86 */       Preferences preferences = ResourcesPlugin.getPlugin().getPluginPreferences();
/*  87 */       boolean autoRefresh = preferences.getBoolean("refresh.enabled");
/*  88 */       String jobName = autoRefresh ? Messages.refresh_installMonitorsOnWorkspace : Messages.refresh_uninstallMonitorsOnWorkspace;
/*  89 */       MonitorJob.createSystem(jobName, (IResource)getWorkspace().getRoot(), monitor -> manageAutoRefresh(paramBoolean, monitor))
/*  90 */         .schedule();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh(IResource resource) {
/*  97 */     if (this.refreshJob != null) {
/*  98 */       this.refreshJob.refresh(resource);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown(IProgressMonitor monitor) {
/* 108 */     if (this.refreshJob == null) {
/*     */       return;
/*     */     }
/*     */     
/* 112 */     ResourcesPlugin.getPlugin().getPluginPreferences().removePropertyChangeListener(this);
/* 113 */     if (this.monitors != null) {
/* 114 */       this.monitors.stop();
/* 115 */       this.monitors = null;
/*     */     } 
/* 117 */     if (this.refreshJob != null) {
/* 118 */       this.refreshJob.stop();
/* 119 */       this.refreshJob = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startup(IProgressMonitor monitor) {
/* 129 */     this.refreshJob = new RefreshJob(this.workspace);
/* 130 */     this.monitors = new MonitorManager((IWorkspace)this.workspace, this);
/*     */     
/* 132 */     Preferences preferences = ResourcesPlugin.getPlugin().getPluginPreferences();
/* 133 */     preferences.addPropertyChangeListener(this);
/* 134 */     boolean autoRefresh = preferences.getBoolean("refresh.enabled");
/* 135 */     if (autoRefresh) {
/* 136 */       SubMonitor subMonitor = SubMonitor.convert(monitor, 1);
/* 137 */       manageAutoRefresh(autoRefresh, (IProgressMonitor)subMonitor.split(1));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\refresh\RefreshManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */