/*     */ package org.eclipse.core.internal.utils;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectMap<K, V>
/*     */   implements Map<K, V>, IStringPoolParticipant
/*     */ {
/*     */   protected static final int DEFAULT_SIZE = 16;
/*     */   protected static final int GROW_SIZE = 10;
/*  32 */   protected int count = 0;
/*  33 */   protected Object[] elements = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectMap() {
/*  39 */     this(16);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectMap(int initialCapacity) {
/*  47 */     if (initialCapacity > 0) {
/*  48 */       this.elements = new Object[Math.max(initialCapacity * 2, 0)];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectMap(Map<? extends K, ? extends V> map) {
/*  57 */     this(map.size());
/*  58 */     putAll(map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  66 */     this.elements = null;
/*  67 */     this.count = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/*  75 */     return new ObjectMap(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/*  83 */     if (this.elements == null || this.count == 0)
/*  84 */       return false; 
/*  85 */     for (int i = 0; i < this.elements.length; i += 2) {
/*  86 */       if (this.elements[i] != null && this.elements[i].equals(key))
/*  87 */         return true; 
/*  88 */     }  return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/*  96 */     if (this.elements == null || this.count == 0)
/*  97 */       return false; 
/*  98 */     for (int i = 1; i < this.elements.length; i += 2) {
/*  99 */       if (this.elements[i] != null && this.elements[i].equals(value))
/* 100 */         return true; 
/* 101 */     }  return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Map.Entry<K, V>> entrySet() {
/* 112 */     return (this.count == 0) ? Collections.EMPTY_SET : toHashMap().entrySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 120 */     if (!(o instanceof Map))
/* 121 */       return false; 
/* 122 */     Map<Object, Object> other = (Map<Object, Object>)o;
/*     */     
/* 124 */     if (this.count != other.size()) {
/* 125 */       return false;
/*     */     }
/*     */     
/* 128 */     if (!keySet().equals(other.keySet())) {
/* 129 */       return false;
/*     */     }
/*     */     
/* 132 */     for (int i = 0; i < this.elements.length; i += 2) {
/* 133 */       if (this.elements[i] != null && !this.elements[i + 1].equals(other.get(this.elements[i])))
/* 134 */         return false; 
/*     */     } 
/* 136 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V get(Object key) {
/* 144 */     if (this.elements == null || this.count == 0)
/* 145 */       return null; 
/* 146 */     for (int i = 0; i < this.elements.length; i += 2) {
/* 147 */       if (this.elements[i] != null && this.elements[i].equals(key))
/* 148 */         return (V)this.elements[i + 1]; 
/* 149 */     }  return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void grow() {
/* 157 */     Object[] expanded = new Object[this.elements.length + 10];
/* 158 */     System.arraycopy(this.elements, 0, expanded, 0, this.elements.length);
/* 159 */     this.elements = expanded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 167 */     int hash = 0;
/* 168 */     for (int i = 0; i < this.elements.length; i += 2) {
/* 169 */       if (this.elements[i] != null) {
/* 170 */         hash += this.elements[i].hashCode();
/*     */       }
/*     */     } 
/* 173 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 181 */     return (this.count == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<K> keySet() {
/* 192 */     Set<K> result = new HashSet<>(size());
/* 193 */     for (int i = 0; i < this.elements.length; i += 2) {
/* 194 */       if (this.elements[i] != null) {
/* 195 */         result.add((K)this.elements[i]);
/*     */       }
/*     */     } 
/* 198 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V put(K key, V value) {
/* 206 */     if (key == null)
/* 207 */       throw new NullPointerException(); 
/* 208 */     if (value == null) {
/* 209 */       return remove(key);
/*     */     }
/*     */     
/* 212 */     if (this.elements == null)
/* 213 */       this.elements = new Object[16]; 
/* 214 */     if (this.count == 0) {
/* 215 */       this.elements[0] = key;
/* 216 */       this.elements[1] = value;
/* 217 */       this.count++;
/* 218 */       return null;
/*     */     } 
/*     */     
/* 221 */     int emptyIndex = -1;
/*     */     
/* 223 */     for (int i = 0; i < this.elements.length; i += 2) {
/* 224 */       if (this.elements[i] != null) {
/* 225 */         if (this.elements[i].equals(key)) {
/* 226 */           Object oldValue = this.elements[i + 1];
/* 227 */           this.elements[i + 1] = value;
/* 228 */           return (V)oldValue;
/*     */         } 
/* 230 */       } else if (emptyIndex == -1) {
/*     */         
/* 232 */         emptyIndex = i;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 237 */     if (emptyIndex == -1) {
/* 238 */       emptyIndex = this.count * 2;
/*     */     }
/*     */ 
/*     */     
/* 242 */     if (this.elements.length <= this.count * 2)
/* 243 */       grow(); 
/* 244 */     this.elements[emptyIndex] = key;
/* 245 */     this.elements[emptyIndex + 1] = value;
/* 246 */     this.count++;
/* 247 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(Map<? extends K, ? extends V> map) {
/* 255 */     for (Map.Entry<? extends K, ? extends V> e : map.entrySet()) {
/* 256 */       put(e.getKey(), e.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V remove(Object key) {
/* 264 */     if (this.elements == null || this.count == 0)
/* 265 */       return null; 
/* 266 */     for (int i = 0; i < this.elements.length; i += 2) {
/* 267 */       if (this.elements[i] != null && this.elements[i].equals(key)) {
/* 268 */         this.elements[i] = null;
/* 269 */         Object result = this.elements[i + 1];
/* 270 */         this.elements[i + 1] = null;
/* 271 */         this.count--;
/* 272 */         return (V)result;
/*     */       } 
/*     */     } 
/* 275 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 283 */     return this.count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shareStrings(StringPool set) {
/* 292 */     Object[] array = this.elements;
/* 293 */     if (array == null)
/*     */       return; 
/* 295 */     for (int i = 0; i < array.length; i++) {
/* 296 */       Object o = array[i];
/* 297 */       if (o instanceof String)
/* 298 */         array[i] = set.add((String)o); 
/* 299 */       if (o instanceof IStringPoolParticipant) {
/* 300 */         ((IStringPoolParticipant)o).shareStrings(set);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private HashMap<K, V> toHashMap() {
/* 308 */     HashMap<K, V> result = new HashMap<>(size());
/* 309 */     for (int i = 0; i < this.elements.length; i += 2) {
/* 310 */       if (this.elements[i] != null) {
/* 311 */         result.put((K)this.elements[i], (V)this.elements[i + 1]);
/*     */       }
/*     */     } 
/* 314 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<V> values() {
/* 325 */     Set<V> result = new HashSet<>(size());
/* 326 */     for (int i = 1; i < this.elements.length; i += 2) {
/* 327 */       if (this.elements[i] != null) {
/* 328 */         result.add((V)this.elements[i]);
/*     */       }
/*     */     } 
/* 331 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\interna\\utils\ObjectMap.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */