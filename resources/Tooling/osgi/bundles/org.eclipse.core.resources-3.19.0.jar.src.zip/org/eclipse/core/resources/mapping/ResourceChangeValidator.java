/*     */ package org.eclipse.core.resources.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.internal.resources.mapping.ChangeDescription;
/*     */ import org.eclipse.core.internal.resources.mapping.ResourceChangeDescriptionFactory;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.Policy;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ResourceChangeValidator
/*     */ {
/*     */   private static ResourceChangeValidator instance;
/*     */   
/*     */   public static ResourceChangeValidator getValidator() {
/*  60 */     if (instance == null)
/*  61 */       instance = new ResourceChangeValidator(); 
/*  62 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IStatus combineResults(IStatus[] result) {
/*  74 */     List<IStatus> notOK = new ArrayList<>(); byte b; int i; IStatus[] arrayOfIStatus;
/*  75 */     for (i = (arrayOfIStatus = result).length, b = 0; b < i; ) { IStatus status = arrayOfIStatus[b];
/*  76 */       if (!status.isOK())
/*  77 */         notOK.add(status); 
/*     */       b++; }
/*     */     
/*  80 */     if (notOK.isEmpty()) {
/*  81 */       return Status.OK_STATUS;
/*     */     }
/*  83 */     if (notOK.size() == 1) {
/*  84 */       return notOK.get(0);
/*     */     }
/*  86 */     return (IStatus)new MultiStatus("org.eclipse.core.resources", 0, notOK.<IStatus>toArray(new IStatus[notOK.size()]), Messages.mapping_multiProblems, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResourceChangeDescriptionFactory createDeltaFactory() {
/*  96 */     return (IResourceChangeDescriptionFactory)new ResourceChangeDescriptionFactory();
/*     */   }
/*     */   
/*     */   private ModelProvider[] getProviders(IResource[] resources) {
/* 100 */     IModelProviderDescriptor[] descriptors = ModelProvider.getModelProviderDescriptors();
/* 101 */     List<ModelProvider> result = new ArrayList<>(); byte b; int i; IModelProviderDescriptor[] arrayOfIModelProviderDescriptor1;
/* 102 */     for (i = (arrayOfIModelProviderDescriptor1 = descriptors).length, b = 0; b < i; ) { IModelProviderDescriptor descriptor = arrayOfIModelProviderDescriptor1[b];
/*     */       try {
/* 104 */         IResource[] matchingResources = descriptor.getMatchingResources(resources);
/* 105 */         if (matchingResources.length > 0) {
/* 106 */           result.add(descriptor.getModelProvider());
/*     */         }
/* 108 */       } catch (CoreException e) {
/* 109 */         Policy.log(e.getStatus().getSeverity(), NLS.bind("Could not instantiate provider {0}", descriptor.getId()), (Throwable)e);
/*     */       }  b++; }
/*     */     
/* 112 */     return result.<ModelProvider>toArray(new ModelProvider[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IResource[] getRootResources(IResourceDelta root) {
/* 119 */     ChangeDescription changeDescription = new ChangeDescription();
/*     */     try {
/* 121 */       root.accept(delta -> paramChangeDescription.recordChange(delta));
/* 122 */     } catch (CoreException e) {
/*     */ 
/*     */       
/* 125 */       Policy.log(4, "Internal error", (Throwable)e);
/*     */     } 
/* 127 */     return changeDescription.getRootResources();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateChange(IResourceDelta delta, IProgressMonitor monitor) {
/* 150 */     monitor = Policy.monitorFor(monitor);
/*     */     try {
/* 152 */       IResource[] resources = getRootResources(delta);
/* 153 */       ModelProvider[] providers = getProviders(resources);
/* 154 */       if (providers.length == 0)
/* 155 */         return Status.OK_STATUS; 
/* 156 */       monitor.beginTask(Messages.mapping_validate, providers.length);
/* 157 */       IStatus[] result = new IStatus[providers.length];
/* 158 */       for (int i = 0; i < providers.length; i++)
/* 159 */         result[i] = providers[i].validateChange(delta, Policy.subMonitorFor(monitor, 1)); 
/* 160 */       return combineResults(result);
/*     */     } finally {
/* 162 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\resources\mapping\ResourceChangeValidator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */