/*     */ package org.eclipse.core.internal.dtree;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.stream.Collectors;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.internal.utils.StringPool;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDataTreeNode
/*     */ {
/*  33 */   static final AbstractDataTreeNode[] NO_CHILDREN = new AbstractDataTreeNode[0];
/*     */ 
/*     */   
/*     */   protected AbstractDataTreeNode[] children;
/*     */ 
/*     */   
/*     */   protected String name;
/*     */ 
/*     */   
/*     */   public static final int T_COMPLETE_NODE = 0;
/*     */   
/*     */   public static final int T_DELTA_NODE = 1;
/*     */   
/*     */   public static final int T_DELETED_NODE = 2;
/*     */   
/*     */   public static final int T_NO_DATA_DELTA_NODE = 3;
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode(String name, AbstractDataTreeNode[] children) {
/*  52 */     this.name = name;
/*  53 */     if (children == null || children.length == 0) {
/*  54 */       this.children = NO_CHILDREN;
/*     */     } else {
/*  56 */       this.children = children;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract AbstractDataTreeNode asBackwardDelta(DeltaDataTree paramDeltaDataTree1, DeltaDataTree paramDeltaDataTree2, IPath paramIPath);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode asReverseComparisonNode(IComparator comparator) {
/*  74 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static AbstractDataTreeNode[] assembleWith(AbstractDataTreeNode[] oldNodes, AbstractDataTreeNode[] newNodes, boolean keepDeleted) {
/*  87 */     if (newNodes.length == 0) {
/*  88 */       return oldNodes;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  93 */     AbstractDataTreeNode[] resultNodes = new AbstractDataTreeNode[oldNodes.length + newNodes.length];
/*     */ 
/*     */     
/*  96 */     int oldIndex = 0;
/*  97 */     int newIndex = 0;
/*  98 */     int resultIndex = 0;
/*  99 */     while (oldIndex < oldNodes.length && newIndex < newNodes.length) {
/* 100 */       int log2 = 31 - Integer.numberOfLeadingZeros(oldNodes.length - oldIndex);
/* 101 */       if (log2 > 1 && newNodes.length - newIndex <= (oldNodes.length - oldIndex) / log2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 107 */         String key = (newNodes[newIndex]).name;
/*     */         
/* 109 */         int left = oldIndex;
/* 110 */         int right = oldNodes.length - 1;
/* 111 */         boolean found = false;
/* 112 */         while (left <= right) {
/* 113 */           int mid = (left + right) / 2;
/* 114 */           int i = key.compareTo((oldNodes[mid]).name);
/* 115 */           if (i < 0) {
/* 116 */             right = mid - 1; continue;
/* 117 */           }  if (i > 0) {
/* 118 */             left = mid + 1; continue;
/*     */           } 
/* 120 */           left = mid;
/* 121 */           found = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 126 */         int toCopy = left - oldIndex;
/* 127 */         System.arraycopy(oldNodes, oldIndex, resultNodes, resultIndex, toCopy);
/* 128 */         resultIndex += toCopy;
/* 129 */         if (found) {
/* 130 */           AbstractDataTreeNode node = oldNodes[left++].assembleWith(newNodes[newIndex++]);
/* 131 */           if (node != null && (!node.isDeleted() || keepDeleted)) {
/* 132 */             resultNodes[resultIndex++] = node;
/*     */           }
/*     */         } else {
/* 135 */           AbstractDataTreeNode node = newNodes[newIndex++];
/* 136 */           if (!node.isDeleted() || keepDeleted) {
/* 137 */             resultNodes[resultIndex++] = node;
/*     */           }
/*     */         } 
/* 140 */         oldIndex = left; continue;
/*     */       } 
/* 142 */       int compare = (oldNodes[oldIndex]).name.compareTo((newNodes[newIndex]).name);
/* 143 */       if (compare == 0) {
/* 144 */         AbstractDataTreeNode node = oldNodes[oldIndex++].assembleWith(newNodes[newIndex++]);
/* 145 */         if (node != null && (!node.isDeleted() || keepDeleted))
/* 146 */           resultNodes[resultIndex++] = node;  continue;
/*     */       } 
/* 148 */       if (compare < 0) {
/* 149 */         resultNodes[resultIndex++] = oldNodes[oldIndex++]; continue;
/* 150 */       }  if (compare > 0) {
/* 151 */         AbstractDataTreeNode node = newNodes[newIndex++];
/* 152 */         if (!node.isDeleted() || keepDeleted) {
/* 153 */           resultNodes[resultIndex++] = node;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 158 */     while (oldIndex < oldNodes.length) {
/* 159 */       resultNodes[resultIndex++] = oldNodes[oldIndex++];
/*     */     }
/* 161 */     while (newIndex < newNodes.length) {
/* 162 */       AbstractDataTreeNode resultNode = newNodes[newIndex++];
/* 163 */       if (!resultNode.isDeleted() || keepDeleted) {
/* 164 */         resultNodes[resultIndex++] = resultNode;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 169 */     if (resultIndex < resultNodes.length) {
/* 170 */       System.arraycopy(resultNodes, 0, resultNodes = new AbstractDataTreeNode[resultIndex], 0, resultIndex);
/*     */     }
/* 172 */     return resultNodes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode assembleWith(AbstractDataTreeNode node) {
/* 182 */     if (!node.isDelta() || isDeleted()) {
/* 183 */       return node;
/*     */     }
/*     */ 
/*     */     
/* 187 */     if (node.hasData()) {
/* 188 */       if (isDelta()) {
/*     */ 
/*     */         
/* 191 */         AbstractDataTreeNode[] arrayOfAbstractDataTreeNode1 = assembleWith(this.children, node.children, true);
/* 192 */         return new DataDeltaNode(this.name, node.getData(), arrayOfAbstractDataTreeNode1);
/*     */       } 
/*     */ 
/*     */       
/* 196 */       AbstractDataTreeNode[] arrayOfAbstractDataTreeNode = assembleWith(this.children, node.children, false);
/* 197 */       return new DataTreeNode(this.name, node.getData(), arrayOfAbstractDataTreeNode);
/*     */     } 
/* 199 */     if (isDelta()) {
/* 200 */       AbstractDataTreeNode[] arrayOfAbstractDataTreeNode = assembleWith(this.children, node.children, true);
/* 201 */       if (hasData())
/* 202 */         return new DataDeltaNode(this.name, getData(), arrayOfAbstractDataTreeNode); 
/* 203 */       return new NoDataDeltaNode(this.name, arrayOfAbstractDataTreeNode);
/*     */     } 
/* 205 */     AbstractDataTreeNode[] assembledChildren = assembleWith(this.children, node.children, false);
/* 206 */     return new DataTreeNode(this.name, getData(), assembledChildren);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode assembleWith(AbstractDataTreeNode node, IPath key, int keyIndex) {
/* 215 */     int keyLen = key.segmentCount();
/* 216 */     if (keyIndex == keyLen) {
/* 217 */       return assembleWith(node);
/*     */     }
/*     */ 
/*     */     
/* 221 */     int childIndex = indexOfChild(key.segment(keyIndex));
/* 222 */     if (childIndex >= 0) {
/* 223 */       AbstractDataTreeNode copy = copy();
/* 224 */       copy.children[childIndex] = this.children[childIndex].assembleWith(node, key, keyIndex + 1);
/* 225 */       return copy;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 230 */     for (int i = keyLen - 2; i >= keyIndex; i--) {
/* 231 */       node = new NoDataDeltaNode(key.segment(i), node);
/*     */     }
/* 233 */     node = new NoDataDeltaNode(this.name, node);
/* 234 */     return assembleWith(node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode childAt(String localName) {
/* 241 */     AbstractDataTreeNode node = childAtOrNull(localName);
/* 242 */     if (node != null) {
/* 243 */       return node;
/*     */     }
/* 245 */     throw new ObjectNotFoundException(NLS.bind(Messages.dtree_missingChild, localName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode childAtOrNull(String localName) {
/* 256 */     int index = indexOfChild(localName);
/* 257 */     return (index >= 0) ? this.children[index] : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AbstractDataTreeNode childAtIgnoreCase(String localName) {
/* 270 */     AbstractDataTreeNode result = null; byte b; int i; AbstractDataTreeNode[] arrayOfAbstractDataTreeNode;
/* 271 */     for (i = (arrayOfAbstractDataTreeNode = this.children).length, b = 0; b < i; ) { AbstractDataTreeNode element = arrayOfAbstractDataTreeNode[b];
/* 272 */       if (element.getName().equalsIgnoreCase(localName))
/*     */       {
/* 274 */         if (element.isDeleted()) {
/* 275 */           result = element;
/*     */         } else {
/* 277 */           return element;
/*     */         }  }  b++; }
/*     */     
/* 280 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static AbstractDataTreeNode[] compareWith(AbstractDataTreeNode[] oldNodes, AbstractDataTreeNode[] newNodes, IComparator comparator) {
/* 287 */     int oldLen = oldNodes.length;
/* 288 */     int newLen = newNodes.length;
/* 289 */     int oldIndex = 0;
/* 290 */     int newIndex = 0;
/* 291 */     AbstractDataTreeNode[] comparedNodes = new AbstractDataTreeNode[oldLen + newLen];
/* 292 */     int count = 0;
/*     */     
/* 294 */     while (oldIndex < oldLen && newIndex < newLen) {
/* 295 */       DataTreeNode oldNode = (DataTreeNode)oldNodes[oldIndex];
/* 296 */       DataTreeNode newNode = (DataTreeNode)newNodes[newIndex];
/* 297 */       int compare = oldNode.name.compareTo(newNode.name);
/* 298 */       if (compare < 0) {
/*     */         
/* 300 */         int userComparison = comparator.compare(oldNode.getData(), null);
/* 301 */         if (userComparison != 0) {
/* 302 */           comparedNodes[count++] = convertToRemovedComparisonNode(oldNode, userComparison);
/*     */         }
/* 304 */         oldIndex++; continue;
/* 305 */       }  if (compare > 0) {
/*     */         
/* 307 */         int userComparison = comparator.compare(null, newNode.getData());
/* 308 */         if (userComparison != 0) {
/* 309 */           comparedNodes[count++] = convertToAddedComparisonNode(newNode, userComparison);
/*     */         }
/* 311 */         newIndex++; continue;
/*     */       } 
/* 313 */       AbstractDataTreeNode comparedNode = oldNode.compareWith(newNode, comparator);
/* 314 */       NodeComparison comparison = (NodeComparison)comparedNode.getData();
/*     */ 
/*     */       
/* 317 */       if (!comparison.isUnchanged() || comparedNode.size() != 0) {
/* 318 */         comparedNodes[count++] = comparedNode;
/*     */       }
/* 320 */       oldIndex++;
/* 321 */       newIndex++;
/*     */     } 
/*     */     
/* 324 */     while (oldIndex < oldLen) {
/* 325 */       DataTreeNode oldNode = (DataTreeNode)oldNodes[oldIndex++];
/*     */ 
/*     */       
/* 328 */       int userComparison = comparator.compare(oldNode.getData(), null);
/* 329 */       if (userComparison != 0) {
/* 330 */         comparedNodes[count++] = convertToRemovedComparisonNode(oldNode, userComparison);
/*     */       }
/*     */     } 
/* 333 */     while (newIndex < newLen) {
/* 334 */       DataTreeNode newNode = (DataTreeNode)newNodes[newIndex++];
/*     */ 
/*     */       
/* 337 */       int userComparison = comparator.compare(null, newNode.getData());
/* 338 */       if (userComparison != 0) {
/* 339 */         comparedNodes[count++] = convertToAddedComparisonNode(newNode, userComparison);
/*     */       }
/*     */     } 
/*     */     
/* 343 */     if (count == 0) {
/* 344 */       return NO_CHILDREN;
/*     */     }
/* 346 */     if (count < comparedNodes.length) {
/* 347 */       System.arraycopy(comparedNodes, 0, comparedNodes = new AbstractDataTreeNode[count], 0, count);
/*     */     }
/* 349 */     return comparedNodes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static AbstractDataTreeNode[] compareWithParent(AbstractDataTreeNode[] nodes, IPath key, DeltaDataTree parent, IComparator comparator) {
/* 356 */     AbstractDataTreeNode[] comparedNodes = new AbstractDataTreeNode[nodes.length];
/* 357 */     int count = 0; byte b; int i; AbstractDataTreeNode[] arrayOfAbstractDataTreeNode1;
/* 358 */     for (i = (arrayOfAbstractDataTreeNode1 = nodes).length, b = 0; b < i; ) { AbstractDataTreeNode node = arrayOfAbstractDataTreeNode1[b];
/* 359 */       AbstractDataTreeNode comparedNode = node.compareWithParent(key.append(node.getName()), parent, comparator);
/* 360 */       NodeComparison comparison = (NodeComparison)comparedNode.getData();
/*     */       
/* 362 */       if (!comparison.isUnchanged() || comparedNode.size() != 0)
/* 363 */         comparedNodes[count++] = comparedNode; 
/*     */       b++; }
/*     */     
/* 366 */     if (count == 0) {
/* 367 */       return NO_CHILDREN;
/*     */     }
/* 369 */     if (count < comparedNodes.length) {
/* 370 */       System.arraycopy(comparedNodes, 0, comparedNodes = new AbstractDataTreeNode[count], 0, count);
/*     */     }
/* 372 */     return comparedNodes;
/*     */   }
/*     */   
/*     */   abstract AbstractDataTreeNode compareWithParent(IPath paramIPath, DeltaDataTree paramDeltaDataTree, IComparator paramIComparator);
/*     */   
/*     */   static AbstractDataTreeNode convertToAddedComparisonNode(AbstractDataTreeNode newNode, int userComparison) {
/* 378 */     AbstractDataTreeNode[] convertedChildren, children = newNode.getChildren();
/* 379 */     int n = children.length;
/*     */     
/* 381 */     if (n == 0) {
/* 382 */       convertedChildren = NO_CHILDREN;
/*     */     } else {
/* 384 */       convertedChildren = new AbstractDataTreeNode[n];
/* 385 */       for (int i = 0; i < n; i++) {
/* 386 */         convertedChildren[i] = convertToAddedComparisonNode(children[i], userComparison);
/*     */       }
/*     */     } 
/* 389 */     return new DataTreeNode(newNode.name, new NodeComparison(null, newNode.getData(), 1, userComparison), convertedChildren);
/*     */   }
/*     */   
/*     */   static AbstractDataTreeNode convertToRemovedComparisonNode(AbstractDataTreeNode oldNode, int userComparison) {
/* 393 */     AbstractDataTreeNode[] convertedChildren, children = oldNode.getChildren();
/* 394 */     int n = children.length;
/*     */     
/* 396 */     if (n == 0) {
/* 397 */       convertedChildren = NO_CHILDREN;
/*     */     } else {
/* 399 */       convertedChildren = new AbstractDataTreeNode[n];
/* 400 */       for (int i = 0; i < n; i++) {
/* 401 */         convertedChildren[i] = convertToRemovedComparisonNode(children[i], userComparison);
/*     */       }
/*     */     } 
/* 404 */     return new DataTreeNode(oldNode.name, new NodeComparison(oldNode.getData(), null, 2, userComparison), convertedChildren);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract AbstractDataTreeNode copy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void copyChildren(int from, int to, AbstractDataTreeNode otherNode, int start) {
/* 418 */     int other = start;
/* 419 */     for (int i = from; i <= to; i++, other++) {
/* 420 */       this.children[i] = otherNode.children[other];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractDataTreeNode[] getChildren() {
/* 428 */     return this.children;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getData() {
/* 435 */     throw new AbstractMethodError(Messages.dtree_subclassImplement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 442 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasData() {
/* 449 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean includesChild(String localName) {
/* 457 */     return (indexOfChild(localName) != -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int indexOfChild(String localName) {
/* 464 */     AbstractDataTreeNode[] nodes = this.children;
/* 465 */     int left = 0;
/* 466 */     int right = nodes.length - 1;
/* 467 */     while (left <= right) {
/* 468 */       int mid = (left + right) / 2;
/* 469 */       int compare = localName.compareTo((nodes[mid]).name);
/* 470 */       if (compare < 0) {
/* 471 */         right = mid - 1; continue;
/* 472 */       }  if (compare > 0) {
/* 473 */         left = mid + 1; continue;
/*     */       } 
/* 475 */       return mid;
/*     */     } 
/*     */     
/* 478 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isDeleted() {
/* 485 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isDelta() {
/* 493 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isEmptyDelta() {
/* 500 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String[] namesOfChildren() {
/* 507 */     String[] names = new String[this.children.length];
/*     */     
/* 509 */     for (int i = this.children.length; --i >= 0;)
/* 510 */       names[i] = this.children[i].getName(); 
/* 511 */     return names;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void replaceChild(String localName, DataTreeNode node) {
/* 518 */     int i = indexOfChild(localName);
/* 519 */     if (i >= 0) {
/* 520 */       this.children[i] = node;
/*     */     } else {
/* 522 */       throw new ObjectNotFoundException(NLS.bind(Messages.dtree_missingChild, localName));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setChildren(AbstractDataTreeNode[] newChildren) {
/* 530 */     this.children = newChildren;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setName(String s) {
/* 537 */     this.name = s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static AbstractDataTreeNode[] simplifyWithParent(AbstractDataTreeNode[] nodes, IPath key, DeltaDataTree parent, IComparator comparer) {
/* 544 */     int nodeCount = nodes.length;
/* 545 */     if (nodeCount == 0)
/* 546 */       return NO_CHILDREN; 
/* 547 */     AbstractDataTreeNode[] simplifiedNodes = new AbstractDataTreeNode[nodeCount];
/* 548 */     int simplifiedCount = 0;
/* 549 */     for (int i = 0; i < nodeCount; i++) {
/* 550 */       AbstractDataTreeNode node = nodes[i];
/* 551 */       AbstractDataTreeNode simplifiedNode = node.simplifyWithParent(key.append(node.getName()), parent, comparer);
/* 552 */       if (!simplifiedNode.isEmptyDelta()) {
/* 553 */         simplifiedNodes[simplifiedCount++] = simplifiedNode;
/*     */       }
/*     */     } 
/* 556 */     if (simplifiedCount == 0) {
/* 557 */       return NO_CHILDREN;
/*     */     }
/* 559 */     if (simplifiedCount < simplifiedNodes.length) {
/* 560 */       System.arraycopy(simplifiedNodes, 0, simplifiedNodes = new AbstractDataTreeNode[simplifiedCount], 0, simplifiedCount);
/*     */     }
/* 562 */     return simplifiedNodes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract AbstractDataTreeNode simplifyWithParent(IPath paramIPath, DeltaDataTree paramDeltaDataTree, IComparator paramIComparator);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int size() {
/* 574 */     return this.children.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void storeStrings(StringPool set) {
/* 581 */     this.name = set.add(this.name);
/*     */     
/* 583 */     AbstractDataTreeNode[] nodes = this.children;
/* 584 */     if (nodes != null) {
/* 585 */       for (int i = nodes.length; --i >= 0;) {
/* 586 */         nodes[i].storeStrings(set);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 595 */     return toShortString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String toLongString() {
/* 607 */     return String.valueOf(toShortString()) + "\n" + getChildrenString(1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   String toShortString() {
/* 613 */     return String.valueOf((getName() == null) ? "" : (String.valueOf(getName()) + " ")) + getClass().getSimpleName() + (
/* 614 */       ((getChildren()).length == 0) ? "" : (
/* 615 */       " with " + (getChildren()).length + " children"));
/*     */   }
/*     */   
/*     */   private String getChildrenString(int depth) {
/* 619 */     int MAXDEPTH = 2;
/* 620 */     String indent = "   ".repeat(depth);
/* 621 */     return (depth > MAXDEPTH) ? "" : 
/* 622 */       Arrays.<AbstractDataTreeNode>stream(getChildren())
/* 623 */       .map(n -> String.valueOf(paramString) + n.toShortString() + "\n" + n.getChildrenString(paramInt + 1))
/* 624 */       .collect(Collectors.joining());
/*     */   }
/*     */   
/*     */   abstract int type();
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\dtree\AbstractDataTreeNode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */