/*    */ package org.eclipse.core.internal.dtree;
/*    */ 
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DataTreeLookup
/*    */ {
/*    */   public final IPath key;
/*    */   public final boolean isPresent;
/*    */   public final Object data;
/*    */   public final boolean foundInFirstDelta;
/*    */   
/*    */   private DataTreeLookup(IPath key, boolean isPresent, Object data, boolean foundInFirstDelta) {
/* 32 */     this.key = key;
/* 33 */     this.isPresent = isPresent;
/* 34 */     this.data = data;
/* 35 */     this.foundInFirstDelta = foundInFirstDelta;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static DataTreeLookup newLookup(IPath nodeKey, boolean isPresent, Object data) {
/* 42 */     return new DataTreeLookup(nodeKey, isPresent, data, false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static DataTreeLookup newLookup(IPath nodeKey, boolean isPresent, Object data, boolean foundInFirstDelta) {
/* 49 */     return new DataTreeLookup(nodeKey, isPresent, data, foundInFirstDelta);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\dtree\DataTreeLookup.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */