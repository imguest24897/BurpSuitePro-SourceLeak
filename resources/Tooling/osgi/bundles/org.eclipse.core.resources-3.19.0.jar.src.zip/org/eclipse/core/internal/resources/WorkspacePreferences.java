/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.Preferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WorkspacePreferences
/*     */   extends WorkspaceDescription
/*     */ {
/*     */   public static final String PROJECT_SEPARATOR = "/";
/*     */   private Preferences preferences;
/*     */   
/*     */   public static String convertStringArraytoString(String[] array) {
/*  44 */     if (array == null || array.length == 0)
/*  45 */       return ""; 
/*  46 */     StringBuilder sb = new StringBuilder(); byte b; int i; String[] arrayOfString;
/*  47 */     for (i = (arrayOfString = array).length, b = 0; b < i; ) { String element = arrayOfString[b];
/*  48 */       sb.append(element);
/*  49 */       sb.append("/"); b++; }
/*     */     
/*  51 */     sb.deleteCharAt(sb.length() - 1);
/*  52 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] convertStringToStringArray(String string, String separator) {
/*  60 */     List<String> list = new ArrayList<>();
/*  61 */     for (StringTokenizer tokenizer = new StringTokenizer(string, separator); tokenizer.hasMoreTokens();)
/*  62 */       list.add(tokenizer.nextToken()); 
/*  63 */     return list.<String>toArray(new String[list.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void copyFromTo(WorkspaceDescription source, WorkspaceDescription target) {
/*  71 */     target.setAutoBuilding(source.isAutoBuilding());
/*  72 */     target.setBuildOrder(source.getBuildOrder());
/*  73 */     target.setMaxBuildIterations(source.getMaxBuildIterations());
/*  74 */     target.setApplyFileStatePolicy(source.isApplyFileStatePolicy());
/*  75 */     target.setFileStateLongevity(source.getFileStateLongevity());
/*  76 */     target.setMaxFileStates(source.getMaxFileStates());
/*  77 */     target.setMaxFileStateSize(source.getMaxFileStateSize());
/*  78 */     target.setKeepDerivedState(source.isKeepDerivedState());
/*  79 */     target.setSnapshotInterval(source.getSnapshotInterval());
/*  80 */     target.setOperationsPerSnapshot(source.getOperationsPerSnapshot());
/*  81 */     target.setDeltaExpiration(source.getDeltaExpiration());
/*  82 */     target.setMaxConcurrentBuilds(source.getMaxConcurrentBuilds());
/*     */   }
/*     */   
/*     */   public WorkspacePreferences() {
/*  86 */     super("Workspace");
/*  87 */     this.preferences = ResourcesPlugin.getPlugin().getPluginPreferences();
/*     */     
/*  89 */     String version = this.preferences.getString("version");
/*  90 */     if (!"1".equals(version)) {
/*  91 */       upgradeVersion(version);
/*     */     }
/*     */     
/*  94 */     super.setAutoBuilding(this.preferences.getBoolean("description.autobuilding"));
/*  95 */     super.setSnapshotInterval(this.preferences.getInt("description.snapshotinterval"));
/*  96 */     super.setMaxBuildIterations(this.preferences.getInt("description.maxbuilditerations"));
/*  97 */     super.setApplyFileStatePolicy(this.preferences.getBoolean("description.applyfilestatepolicy"));
/*  98 */     super.setMaxFileStates(this.preferences.getInt("description.maxfilestates"));
/*  99 */     super.setMaxFileStateSize(this.preferences.getLong("description.maxfilestatesize"));
/* 100 */     super.setFileStateLongevity(this.preferences.getLong("description.filestatelongevity"));
/* 101 */     super.setOperationsPerSnapshot(this.preferences.getInt("snapshots.operations"));
/* 102 */     super.setDeltaExpiration(this.preferences.getLong("delta.expiration"));
/* 103 */     super.setMaxConcurrentBuilds(this.preferences.getInt("maxConcurrentBuilds"));
/* 104 */     super.setKeepDerivedState(this.preferences.getBoolean("description.keepDerivedState"));
/*     */ 
/*     */ 
/*     */     
/* 108 */     this.preferences.addPropertyChangeListener(event -> synchronizeWithPreferences(event.getProperty()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 116 */     throw new UnsupportedOperationException("clone() is not supported in " + getClass().getName());
/*     */   }
/*     */   
/*     */   public void copyFrom(WorkspaceDescription source) {
/* 120 */     copyFromTo(source, this);
/*     */   }
/*     */   
/*     */   public void copyTo(WorkspaceDescription target) {
/* 124 */     copyFromTo(this, target);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getBuildOrder() {
/* 132 */     boolean defaultBuildOrder = this.preferences.getBoolean("description.defaultbuildorder");
/* 133 */     if (defaultBuildOrder)
/* 134 */       return null; 
/* 135 */     return convertStringToStringArray(this.preferences.getString("description.buildorder"), "/");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getBuildOrder(boolean makeCopy) {
/* 145 */     return getBuildOrder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoBuilding(boolean value) {
/* 153 */     this.preferences.setValue("description.autobuilding", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBuildOrder(String[] value) {
/* 161 */     this.preferences.setValue("description.defaultbuildorder", (value == null));
/* 162 */     this.preferences.setValue("description.buildorder", convertStringArraytoString(value));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDeltaExpiration(long value) {
/* 167 */     this.preferences.setValue("delta.expiration", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplyFileStatePolicy(boolean apply) {
/* 175 */     this.preferences.setValue("description.applyfilestatepolicy", apply);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFileStateLongevity(long time) {
/* 183 */     this.preferences.setValue("description.filestatelongevity", time);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxBuildIterations(int number) {
/* 191 */     this.preferences.setValue("description.maxbuilditerations", number);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxFileStates(int number) {
/* 199 */     this.preferences.setValue("description.maxfilestates", number);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxFileStateSize(long size) {
/* 207 */     this.preferences.setValue("description.maxfilestatesize", size);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setOperationsPerSnapshot(int value) {
/* 212 */     this.preferences.setValue("snapshots.operations", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMaxConcurrentBuilds(int n) {
/* 217 */     this.preferences.setValue("maxConcurrentBuilds", n);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setKeepDerivedState(boolean keepDerivedState) {
/* 222 */     this.preferences.setValue("description.keepDerivedState", keepDerivedState);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSnapshotInterval(long delay) {
/* 230 */     this.preferences.setValue("description.snapshotinterval", delay);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void synchronizeWithPreferences(String property) {
/* 237 */     if (property.equals("description.autobuilding")) {
/* 238 */       super.setAutoBuilding(this.preferences.getBoolean("description.autobuilding"));
/* 239 */     } else if (property.equals("description.snapshotinterval")) {
/* 240 */       super.setSnapshotInterval(this.preferences.getLong("description.snapshotinterval"));
/* 241 */     } else if (property.equals("description.maxbuilditerations")) {
/* 242 */       super.setMaxBuildIterations(this.preferences.getInt("description.maxbuilditerations"));
/* 243 */     } else if (property.equals("description.applyfilestatepolicy")) {
/* 244 */       super.setApplyFileStatePolicy(this.preferences.getBoolean("description.applyfilestatepolicy"));
/* 245 */     } else if (property.equals("description.maxfilestates")) {
/* 246 */       super.setMaxFileStates(this.preferences.getInt("description.maxfilestates"));
/* 247 */     } else if (property.equals("description.maxfilestatesize")) {
/* 248 */       super.setMaxFileStateSize(this.preferences.getLong("description.maxfilestatesize"));
/* 249 */     } else if (property.equals("description.filestatelongevity")) {
/* 250 */       super.setFileStateLongevity(this.preferences.getLong("description.filestatelongevity"));
/* 251 */     } else if (property.equals("snapshots.operations")) {
/* 252 */       super.setOperationsPerSnapshot(this.preferences.getInt("snapshots.operations"));
/* 253 */     } else if (property.equals("delta.expiration")) {
/* 254 */       super.setDeltaExpiration(this.preferences.getLong("delta.expiration"));
/* 255 */     } else if (property.equals("maxConcurrentBuilds")) {
/* 256 */       super.setMaxConcurrentBuilds(this.preferences.getInt("maxConcurrentBuilds"));
/* 257 */     } else if (property.equals("description.keepDerivedState")) {
/* 258 */       super.setKeepDerivedState(this.preferences.getBoolean("description.keepDerivedState"));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void upgradeVersion(String oldVersion) {
/* 263 */     if (oldVersion.length() == 0)
/*     */     {
/* 265 */       if (!this.preferences.getBoolean("description.defaultbuildorder")) {
/* 266 */         String oldOrder = this.preferences.getString("description.buildorder");
/* 267 */         setBuildOrder(convertStringToStringArray(oldOrder, ":"));
/*     */       } 
/*     */     }
/* 270 */     this.preferences.setValue("version", "1");
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\WorkspacePreferences.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */