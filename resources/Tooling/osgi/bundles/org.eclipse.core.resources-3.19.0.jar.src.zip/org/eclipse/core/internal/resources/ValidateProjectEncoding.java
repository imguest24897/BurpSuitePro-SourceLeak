/*     */ package org.eclipse.core.internal.resources;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.internal.utils.Messages;
/*     */ import org.eclipse.core.resources.IMarker;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidateProjectEncoding
/*     */   extends InternalWorkspaceJob
/*     */ {
/*     */   public static final String MARKER_ID = "noExplicitEncoding";
/*  31 */   public static final String MARKER_TYPE = String.valueOf(ResourcesPlugin.getPlugin().getBundle().getSymbolicName()) + "." + 
/*  32 */     "noExplicitEncoding";
/*     */ 
/*     */   
/*     */   public static final int SEVERITY_IGNORE = -1;
/*     */   
/*     */   private final IProject[] projects;
/*     */ 
/*     */   
/*     */   public static void scheduleWorkspaceValidation(Workspace workspace) {
/*  41 */     IProject[] projects = workspace.getRoot().getProjects();
/*  42 */     ValidateProjectEncoding validateProjectEncoding = new ValidateProjectEncoding(workspace, projects);
/*  43 */     validateProjectEncoding.setRule((ISchedulingRule)workspace.getRoot());
/*  44 */     validateProjectEncoding.schedule();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void scheduleProjectValidation(Workspace workspace, IProject project) {
/*  49 */     boolean shouldScheduleValidation = shouldScheduleValidation(project);
/*  50 */     if (shouldScheduleValidation) {
/*  51 */       ValidateProjectEncoding validateProjectEncoding = new ValidateProjectEncoding(workspace, new IProject[] { project });
/*  52 */       validateProjectEncoding.setRule((ISchedulingRule)project);
/*  53 */       validateProjectEncoding.schedule();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ValidateProjectEncoding(Workspace workspace, IProject... projects) {
/*  60 */     super(Messages.resources_checkExplicitEncoding_jobName, workspace);
/*  61 */     setSystem(true);
/*  62 */     this.projects = projects;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean belongsTo(Object family) {
/*  67 */     return (family == ValidateProjectEncoding.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public IStatus runInWorkspace(IProgressMonitor monitor) {
/*  72 */     if (monitor.isCanceled()) {
/*  73 */       return Status.CANCEL_STATUS;
/*     */     }
/*  75 */     SubMonitor subMonitor = SubMonitor.convert(monitor, this.projects.length); byte b; int i; IProject[] arrayOfIProject;
/*  76 */     for (i = (arrayOfIProject = this.projects).length, b = 0; b < i; ) { IProject project = arrayOfIProject[b];
/*  77 */       subMonitor.checkCanceled();
/*  78 */       subMonitor.setTaskName(NLS.bind(Messages.resources_checkExplicitEncoding_taskName, project.getName()));
/*  79 */       updateMissingEncodingMarker(project);
/*  80 */       subMonitor.worked(1); b++; }
/*     */     
/*  82 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void updateMissingEncodingMarker(IProject project) {
/*     */     try {
/*  92 */       if (project.isAccessible() && !project.isHidden()) {
/*  93 */         int severity = getSeverity();
/*  94 */         String defaultCharset = getDefaultCharset(project);
/*  95 */         if (severity != -1 && defaultCharset == null) {
/*  96 */           createOrUpdateMissingEncodingMarker(project, severity);
/*     */         } else {
/*  98 */           deleteEncodingMarkers(project);
/*     */         } 
/*     */       } 
/* 101 */     } catch (CoreException e) {
/* 102 */       logException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getSeverity() {
/* 114 */     int severity = 1;
/* 115 */     severity = Platform.getPreferencesService().getInt("org.eclipse.core.resources", 
/* 116 */         "missingEncodingMarkerSeverity", severity, null);
/* 117 */     return severity;
/*     */   }
/*     */   
/*     */   private static boolean shouldScheduleValidation(IProject project) {
/* 121 */     boolean shouldScheduleValidation = true;
/*     */     try {
/* 123 */       if (project.isHidden()) {
/* 124 */         shouldScheduleValidation = false;
/* 125 */       } else if (project.isAccessible()) {
/* 126 */         String defaultCharset = getDefaultCharset(project);
/* 127 */         boolean hasDefaultEncoding = (defaultCharset != null);
/* 128 */         IMarker[] encodingMarkers = getEncodingMarkers(project);
/* 129 */         boolean hasEncodingMarkers = (encodingMarkers != null && encodingMarkers.length > 0);
/* 130 */         if (hasEncodingMarkers && !hasDefaultEncoding) {
/*     */           
/* 132 */           shouldScheduleValidation = false;
/* 133 */         } else if (!hasEncodingMarkers && hasDefaultEncoding) {
/*     */           
/* 135 */           shouldScheduleValidation = false;
/*     */         } 
/*     */       } 
/* 138 */     } catch (CoreException e) {
/* 139 */       logException(e);
/*     */     } 
/* 141 */     return shouldScheduleValidation;
/*     */   }
/*     */   
/*     */   private static String getDefaultCharset(IProject project) throws CoreException {
/* 145 */     boolean checkImplicit = false;
/* 146 */     String defaultCharset = project.getDefaultCharset(checkImplicit);
/* 147 */     return defaultCharset;
/*     */   }
/*     */   
/*     */   private static void createOrUpdateMissingEncodingMarker(IProject project, int severity) throws CoreException {
/* 151 */     String message = NLS.bind(Messages.resources_checkExplicitEncoding_problemText, project.getName());
/*     */     
/* 153 */     String[] attributeNames = { "message", "location" };
/* 154 */     Object[] attributevalues = { message, project.getFullPath().toString() };
/*     */     
/* 156 */     IMarker[] existing = project.findMarkers(MARKER_TYPE, false, 1); byte b; int j; IMarker[] arrayOfIMarker1;
/* 157 */     for (j = (arrayOfIMarker1 = existing).length, b = 0; b < j; ) { IMarker marker = arrayOfIMarker1[b];
/* 158 */       Object[] markerValues = marker.getAttributes(attributeNames);
/* 159 */       if (Arrays.equals(attributevalues, markerValues)) {
/* 160 */         updateMarkerSeverity(marker, severity);
/*     */         return;
/*     */       } 
/*     */       b++; }
/*     */     
/* 165 */     Map<String, Object> attributes = new HashMap<>();
/* 166 */     for (int i = 0; i < attributeNames.length; i++) {
/* 167 */       attributes.put(attributeNames[i], attributevalues[i]);
/*     */     }
/* 169 */     attributes.put("severity", Integer.valueOf(severity));
/* 170 */     project.createMarker(MARKER_TYPE, attributes);
/*     */   }
/*     */   
/*     */   private static void updateMarkerSeverity(IMarker marker, int severity) throws CoreException {
/* 174 */     int currentSeverity = ((Integer)marker.getAttribute("severity")).intValue();
/*     */     
/* 176 */     if (currentSeverity != severity) {
/* 177 */       marker.setAttribute("severity", severity);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void deleteEncodingMarkers(IProject project) throws CoreException {
/* 182 */     IMarker[] existing = getEncodingMarkers(project); byte b; int i; IMarker[] arrayOfIMarker1;
/* 183 */     for (i = (arrayOfIMarker1 = existing).length, b = 0; b < i; ) { IMarker marker = arrayOfIMarker1[b];
/* 184 */       marker.delete();
/*     */       b++; }
/*     */   
/*     */   }
/*     */   private static IMarker[] getEncodingMarkers(IProject project) throws CoreException {
/* 189 */     IMarker[] existing = project.findMarkers(MARKER_TYPE, false, 1);
/* 190 */     return existing;
/*     */   }
/*     */   
/*     */   private static void logException(CoreException e) {
/* 194 */     boolean logException = true;
/* 195 */     if (e instanceof ResourceException) {
/* 196 */       int code = e.getStatus().getCode();
/* 197 */       if (code == 368 || code == 372) {
/* 198 */         logException = false;
/*     */       }
/*     */     } 
/* 201 */     if (logException)
/* 202 */       ResourcesPlugin.getPlugin().getLog().log(e.getStatus()); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.resources-3.19.0.jar!\org\eclipse\core\internal\resources\ValidateProjectEncoding.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */