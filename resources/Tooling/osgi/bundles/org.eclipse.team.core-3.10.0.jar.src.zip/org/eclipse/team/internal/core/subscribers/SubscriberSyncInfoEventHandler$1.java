/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.SubProgressMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   extends SubProgressMonitor
/*     */ {
/*     */   boolean dispatching;
/*     */   
/*     */   null(IProgressMonitor $anonymous0, int $anonymous1) {
/* 116 */     super($anonymous0, $anonymous1);
/* 117 */     this.dispatching = false;
/*     */   }
/*     */   public void subTask(String name) {
/* 120 */     dispatch();
/* 121 */     super.subTask(name);
/*     */   }
/*     */   private void dispatch() {
/* 124 */     if (this.dispatching)
/*     */       return;  try {
/* 126 */       this.dispatching = true;
/* 127 */       SubscriberSyncInfoEventHandler.this.handlePreemptiveEvents((IProgressMonitor)this);
/* 128 */       SubscriberSyncInfoEventHandler.this.handlePendingDispatch((IProgressMonitor)this);
/*     */     } finally {
/* 130 */       this.dispatching = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void worked(int work) {
/* 135 */     dispatch();
/* 136 */     super.worked(work);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SubscriberSyncInfoEventHandler$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */