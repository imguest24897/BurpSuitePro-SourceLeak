/*     */ package org.eclipse.team.internal.core.streams;
/*     */ 
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.io.OutputStream;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PollingOutputStream
/*     */   extends FilterOutputStream
/*     */ {
/*     */   private int numAttempts;
/*     */   private IProgressMonitor monitor;
/*     */   private boolean cancellable;
/*     */   
/*     */   public PollingOutputStream(OutputStream out, int numAttempts, IProgressMonitor monitor) {
/*  48 */     super(out);
/*  49 */     this.numAttempts = numAttempts;
/*  50 */     this.monitor = monitor;
/*  51 */     this.cancellable = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int b) throws IOException {
/*  63 */     int attempts = 0;
/*     */     while (true) {
/*  65 */       if (checkCancellation()) throw new OperationCanceledException(); 
/*     */       try {
/*  67 */         this.out.write(b);
/*     */         return;
/*  69 */       } catch (InterruptedIOException interruptedIOException) {
/*  70 */         if (++attempts == this.numAttempts)
/*  71 */           throw new InterruptedIOException(Messages.PollingOutputStream_writeTimeout); 
/*  72 */         if (Policy.DEBUG_STREAMS) System.out.println("write retry=" + attempts);
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] buffer, int off, int len) throws IOException {
/*  86 */     int count = 0;
/*  87 */     int attempts = 0;
/*     */     while (true) {
/*  89 */       if (checkCancellation()) throw new OperationCanceledException(); 
/*     */       try {
/*  91 */         this.out.write(buffer, off, len);
/*     */         return;
/*  93 */       } catch (InterruptedIOException e) {
/*  94 */         int amount = e.bytesTransferred;
/*  95 */         if (amount != 0) {
/*  96 */           len -= amount;
/*  97 */           if (len <= 0)
/*  98 */             return;  off += amount;
/*  99 */           count += amount;
/* 100 */           attempts = 0;
/*     */         } 
/* 102 */         if (++attempts == this.numAttempts) {
/* 103 */           e = new InterruptedIOException(Messages.PollingOutputStream_writeTimeout);
/* 104 */           e.bytesTransferred = count;
/* 105 */           throw e;
/*     */         } 
/* 107 */         if (Policy.DEBUG_STREAMS) System.out.println("write retry=" + attempts);
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 121 */     int count = 0;
/* 122 */     int attempts = 0;
/*     */     while (true) {
/* 124 */       if (checkCancellation()) throw new OperationCanceledException(); 
/*     */       try {
/* 126 */         this.out.flush();
/*     */         return;
/* 128 */       } catch (InterruptedIOException e) {
/* 129 */         int amount = e.bytesTransferred;
/* 130 */         if (amount != 0) {
/* 131 */           count += amount;
/* 132 */           attempts = 0;
/*     */         } 
/* 134 */         if (++attempts == this.numAttempts) {
/* 135 */           e = new InterruptedIOException(Messages.PollingOutputStream_writeTimeout);
/* 136 */           e.bytesTransferred = count;
/* 137 */           throw e;
/*     */         } 
/* 139 */         if (Policy.DEBUG_STREAMS) System.out.println("write retry=" + attempts);
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*     */     boolean stop;
/* 153 */     int attempts = this.numAttempts - 1;
/*     */     try {
/* 155 */       this.out.flush();
/* 156 */       attempts = 0;
/*     */     } finally {
/* 158 */       boolean bool = false;
/* 159 */       while (!bool) {
/*     */         try {
/* 161 */           this.out.close();
/* 162 */           bool = true;
/* 163 */         } catch (InterruptedIOException interruptedIOException) {
/* 164 */           if (checkCancellation()) throw new OperationCanceledException(); 
/* 165 */           if (++attempts == this.numAttempts)
/* 166 */             throw new InterruptedIOException(Messages.PollingOutputStream_closeTimeout); 
/* 167 */           if (Policy.DEBUG_STREAMS) System.out.println("close retry=" + attempts);
/*     */         
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIsCancellable(boolean cancellable) {
/* 180 */     this.cancellable = cancellable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkCancellation() {
/* 190 */     if (this.cancellable) {
/* 191 */       return this.monitor.isCanceled();
/*     */     }
/* 193 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\streams\PollingOutputStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */