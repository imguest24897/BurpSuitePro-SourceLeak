/*     */ package org.eclipse.team.internal.core;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.eclipse.core.resources.IStorage;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ import org.eclipse.team.core.IFileContentManager;
/*     */ import org.eclipse.team.core.IStringMapping;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileContentManager
/*     */   implements IFileContentManager
/*     */ {
/*     */   private static final String PREF_TEAM_EXTENSION_TYPES = "file_types";
/*     */   private static final String PREF_TEAM_FILENAME_TYPES = "cvs_mode_for_file_without_extensions";
/*     */   private final UserStringMappings fUserExtensionMappings;
/*     */   private final UserStringMappings fUserNameMappings;
/*     */   private PluginStringMappings fPluginExtensionMappings;
/*     */   private IContentType textContentType;
/*     */   
/*     */   private static class StringMapping
/*     */     implements IStringMapping
/*     */   {
/*     */     private final String fString;
/*     */     private final int fType;
/*     */     
/*     */     public StringMapping(String string, int type) {
/*  51 */       this.fString = string;
/*  52 */       this.fType = type;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getString() {
/*  57 */       return this.fString;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getType() {
/*  62 */       return this.fType;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class UserExtensionMappings
/*     */     extends UserStringMappings {
/*     */     public UserExtensionMappings(String key) {
/*  69 */       super(key);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Map<String, Integer> loadMappingsFromPreferences() {
/*  74 */       Map<String, Integer> result = super.loadMappingsFromPreferences();
/*  75 */       if (loadMappingsFromOldWorkspace(result)) {
/*  76 */         TeamPlugin.getPlugin().savePluginPreferences();
/*     */       }
/*  78 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean loadMappingsFromOldWorkspace(Map<String, Integer> map) {
/*  92 */       String STATE_FILE = ".fileTypes";
/*  93 */       IPath pluginStateLocation = TeamPlugin.getPlugin().getStateLocation().append(STATE_FILE);
/*  94 */       File f = pluginStateLocation.toFile();
/*     */       
/*  96 */       if (!f.exists())
/*  97 */         return false; 
/*     */       try {
/*  99 */         Exception exception2, exception1 = null;
/*     */       }
/* 101 */       catch (IOException ex) {
/* 102 */         TeamPlugin.log(4, ex.getMessage(), ex);
/* 103 */         return false;
/*     */       } finally {
/* 105 */         f.delete();
/*     */       } 
/*     */       
/* 108 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Map<String, Integer> readOldFormatExtensionMappings(DataInputStream input) throws IOException {
/* 118 */       Map<String, Integer> result = new TreeMap<>();
/* 119 */       int numberOfMappings = 0;
/*     */       try {
/* 121 */         numberOfMappings = input.readInt();
/* 122 */       } catch (EOFException eOFException) {
/*     */ 
/*     */         
/* 125 */         return Collections.emptyMap();
/*     */       } 
/* 127 */       for (int i = 0; i < numberOfMappings; i++) {
/* 128 */         String extension = input.readUTF();
/* 129 */         int type = input.readInt();
/* 130 */         result.put(extension, Integer.valueOf(type));
/*     */       } 
/* 132 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileContentManager() {
/* 141 */     this.fUserExtensionMappings = new UserExtensionMappings("file_types");
/* 142 */     this.fUserNameMappings = new UserStringMappings("cvs_mode_for_file_without_extensions");
/* 143 */     this.fPluginExtensionMappings = new PluginStringMappings("fileTypes", "extension");
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTypeForName(String filename) {
/* 148 */     int userType = this.fUserNameMappings.getType(filename);
/*     */ 
/*     */     
/* 151 */     return userType;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTypeForExtension(String extension) {
/* 156 */     int userType = this.fUserExtensionMappings.getType(extension);
/* 157 */     int pluginType = this.fPluginExtensionMappings.getType(extension);
/* 158 */     return (userType != 0) ? userType : pluginType;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addNameMappings(String[] names, int[] types) {
/* 163 */     this.fUserNameMappings.addStringMappings(names, types);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addExtensionMappings(String[] extensions, int[] types) {
/* 168 */     this.fUserExtensionMappings.addStringMappings(extensions, types);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNameMappings(String[] names, int[] types) {
/* 173 */     this.fUserNameMappings.setStringMappings(names, types);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExtensionMappings(String[] extensions, int[] types) {
/* 178 */     this.fUserExtensionMappings.setStringMappings(extensions, types);
/*     */   }
/*     */ 
/*     */   
/*     */   public IStringMapping[] getNameMappings() {
/* 183 */     return getMappings(this.fUserNameMappings, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public IStringMapping[] getExtensionMappings() {
/* 188 */     return getMappings(this.fUserExtensionMappings, this.fPluginExtensionMappings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getType(IStorage storage) {
/* 195 */     String name = storage.getName(); int type;
/* 196 */     if (name != null && (type = getTypeForName(name)) != 0) {
/* 197 */       return type;
/*     */     }
/* 199 */     String extension = getFileExtension(name);
/* 200 */     if (extension != null && (type = getTypeForExtension(extension)) != 0) {
/* 201 */       return type;
/*     */     }
/* 203 */     IContentType contentType = Platform.getContentTypeManager().findContentTypeFor(name);
/* 204 */     if (contentType != null) {
/* 205 */       IContentType textType = getTextContentType();
/* 206 */       if (contentType.isKindOf(textType)) {
/* 207 */         return 1;
/*     */       }
/*     */     } 
/*     */     
/* 211 */     return 0;
/*     */   }
/*     */   
/*     */   private IContentType getTextContentType() {
/* 215 */     if (this.textContentType == null)
/* 216 */       this.textContentType = Platform.getContentTypeManager().getContentType("org.eclipse.core.runtime.text"); 
/* 217 */     return this.textContentType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IStringMapping[] getDefaultNameMappings() {
/* 223 */     return new IStringMapping[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public IStringMapping[] getDefaultExtensionMappings() {
/* 228 */     return getStringMappings(this.fPluginExtensionMappings.referenceMap());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isKnownExtension(String extension) {
/* 233 */     return !(!this.fUserExtensionMappings.referenceMap().containsKey(extension) && 
/* 234 */       !this.fPluginExtensionMappings.referenceMap().containsKey(extension));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isKnownFilename(String filename) {
/* 239 */     return this.fUserNameMappings.referenceMap().containsKey(filename);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String getFileExtension(String name) {
/* 244 */     if (name == null)
/* 245 */       return null; 
/* 246 */     int index = name.lastIndexOf('.');
/* 247 */     if (index == -1)
/* 248 */       return null; 
/* 249 */     if (index == name.length() - 1)
/* 250 */       return ""; 
/* 251 */     return name.substring(index + 1);
/*     */   }
/*     */   
/*     */   private static IStringMapping[] getStringMappings(Map map) {
/* 255 */     IStringMapping[] result = new IStringMapping[map.size()];
/* 256 */     int index = 0;
/* 257 */     for (Object element : map.entrySet()) {
/* 258 */       Map.Entry entry = (Map.Entry)element;
/* 259 */       result[index++] = new StringMapping((String)entry.getKey(), ((Integer)entry.getValue()).intValue());
/*     */     } 
/* 261 */     return result;
/*     */   }
/*     */   
/*     */   private IStringMapping[] getMappings(UserStringMappings userMappings, PluginStringMappings pluginMappings) {
/* 265 */     Map<String, Integer> mappings = new HashMap<>();
/* 266 */     if (pluginMappings != null)
/* 267 */       mappings.putAll(pluginMappings.referenceMap()); 
/* 268 */     mappings.putAll(userMappings.referenceMap());
/* 269 */     return getStringMappings(mappings);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\FileContentManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */