package org.eclipse.team.core;

@Deprecated
public interface IFileTypeInfo {
  String getExtension();
  
  int getType();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\IFileTypeInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */