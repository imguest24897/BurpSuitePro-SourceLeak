/*    */ package org.eclipse.team.internal.core.subscribers;
/*    */ 
/*    */ import org.eclipse.core.resources.IFile;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.team.core.diff.DiffFilter;
/*    */ import org.eclipse.team.core.diff.IDiff;
/*    */ import org.eclipse.team.core.history.IFileRevision;
/*    */ import org.eclipse.team.core.mapping.provider.ResourceDiffTree;
/*    */ import org.eclipse.team.internal.core.mapping.SyncInfoToDiffConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentComparisonDiffFilter
/*    */   extends DiffFilter
/*    */ {
/* 27 */   ContentComparator criteria = new ContentComparator(false);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ContentComparisonDiffFilter() {
/* 33 */     this(false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ContentComparisonDiffFilter(boolean ignoreWhitespace) {
/* 40 */     this.criteria = new ContentComparator(ignoreWhitespace);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean compareContents(IFile local, IFileRevision remote, IProgressMonitor monitor) {
/* 53 */     Assert.isNotNull(local);
/* 54 */     Assert.isNotNull(remote);
/* 55 */     return this.criteria.compare((IResource)local, remote, monitor);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean select(IDiff diff, IProgressMonitor monitor) {
/* 60 */     IFileRevision remote = SyncInfoToDiffConverter.getRemote(diff);
/* 61 */     IResource local = ResourceDiffTree.getResourceFor(diff);
/* 62 */     if (local == null) return true; 
/* 63 */     if (local.getType() != 1) return false; 
/* 64 */     if (remote == null) return !local.exists(); 
/* 65 */     if (!local.exists()) return false; 
/* 66 */     return compareContents((IFile)local, remote, monitor);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\ContentComparisonDiffFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */