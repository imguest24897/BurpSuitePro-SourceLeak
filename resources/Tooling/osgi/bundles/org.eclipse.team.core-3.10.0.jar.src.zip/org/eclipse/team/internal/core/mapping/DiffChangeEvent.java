/*     */ package org.eclipse.team.internal.core.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.team.core.diff.IDiff;
/*     */ import org.eclipse.team.core.diff.IDiffChangeEvent;
/*     */ import org.eclipse.team.core.diff.IDiffTree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiffChangeEvent
/*     */   implements IDiffChangeEvent
/*     */ {
/*     */   private final IDiffTree tree;
/*  38 */   private Map<IPath, IDiff> changedResources = new HashMap<>();
/*  39 */   private Set<IPath> removedResources = new HashSet<>();
/*  40 */   private Map<IPath, IDiff> addedResources = new HashMap<>();
/*     */   
/*     */   private boolean reset = false;
/*     */   
/*  44 */   private List<IStatus> errors = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiffChangeEvent(IDiffTree tree) {
/*  51 */     this.tree = tree;
/*     */   }
/*     */ 
/*     */   
/*     */   public IDiffTree getTree() {
/*  56 */     return this.tree;
/*     */   }
/*     */ 
/*     */   
/*     */   public IDiff[] getAdditions() {
/*  61 */     return (IDiff[])this.addedResources.values().toArray((Object[])new IDiff[this.addedResources.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath[] getRemovals() {
/*  66 */     return this.removedResources.<IPath>toArray(new IPath[this.removedResources.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public IDiff[] getChanges() {
/*  71 */     return (IDiff[])this.changedResources.values().toArray((Object[])new IDiff[this.changedResources.size()]);
/*     */   }
/*     */   
/*     */   public void added(IDiff delta) {
/*  75 */     if (this.removedResources.contains(delta.getPath())) {
/*     */       
/*  77 */       this.removedResources.remove(delta.getPath());
/*  78 */       changed(delta);
/*     */     } else {
/*  80 */       this.addedResources.put(delta.getPath(), delta);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removed(IPath path, IDiff delta) {
/*  85 */     if (this.changedResources.containsKey(path)) {
/*     */       
/*  87 */       this.changedResources.remove(path);
/*  88 */     } else if (this.addedResources.containsKey(path)) {
/*     */       
/*  90 */       this.addedResources.remove(path);
/*     */       return;
/*     */     } 
/*  93 */     this.removedResources.add(path);
/*     */   }
/*     */   
/*     */   public void changed(IDiff delta) {
/*  97 */     if (this.addedResources.containsKey(delta.getPath())) {
/*     */       
/*  99 */       this.addedResources.put(delta.getPath(), delta);
/*     */       return;
/*     */     } 
/* 102 */     this.changedResources.put(delta.getPath(), delta);
/*     */   }
/*     */   
/*     */   public void reset() {
/* 106 */     this.reset = true;
/*     */   }
/*     */   
/*     */   public boolean isReset() {
/* 110 */     return this.reset;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 114 */     return (this.changedResources.isEmpty() && this.removedResources.isEmpty() && this.addedResources.isEmpty());
/*     */   }
/*     */   
/*     */   public void errorOccurred(IStatus status) {
/* 118 */     this.errors.add(status);
/*     */   }
/*     */ 
/*     */   
/*     */   public IStatus[] getErrors() {
/* 123 */     return this.errors.<IStatus>toArray(new IStatus[this.errors.size()]);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\DiffChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */