/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.core.subscribers.Subscriber;
/*     */ import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
/*     */ import org.eclipse.team.core.synchronize.SyncInfo;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncInfoWorkingSetFilter
/*     */   extends FastSyncInfoFilter
/*     */ {
/*     */   private IResource[] resources;
/*     */   
/*     */   public boolean select(SyncInfo info) {
/*  39 */     if (isEmpty()) return true; 
/*  40 */     return isIncluded(info.getLocal());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isIncluded(IResource resource) {
/*     */     byte b;
/*     */     int i;
/*     */     IResource[] arrayOfIResource;
/*  49 */     for (i = (arrayOfIResource = this.resources).length, b = 0; b < i; ) { IResource setResource = arrayOfIResource[b];
/*  50 */       if (isParent(setResource, resource))
/*  51 */         return true; 
/*     */       b++; }
/*     */     
/*  54 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isParent(IResource parent, IResource child) {
/*  58 */     return parent.getFullPath().isPrefixOf(child.getFullPath());
/*     */   }
/*     */   
/*     */   public IResource[] getRoots(Subscriber subscriber) {
/*  62 */     IResource[] roots = subscriber.roots();
/*  63 */     if (isEmpty()) return roots;
/*     */ 
/*     */     
/*  66 */     Set<IResource> result = new HashSet<>(); byte b; int i; IResource[] arrayOfIResource1;
/*  67 */     for (i = (arrayOfIResource1 = roots).length, b = 0; b < i; ) { IResource resource = arrayOfIResource1[b];
/*  68 */       result.addAll(Arrays.asList(getIntersectionWithSet(subscriber, resource))); b++; }
/*     */     
/*  70 */     return result.<IResource>toArray(new IResource[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IResource[] getIntersectionWithSet(Subscriber subscriber, IResource resource) {
/*  78 */     List<IResource> result = new ArrayList<>(); byte b; int i; IResource[] arrayOfIResource;
/*  79 */     for (i = (arrayOfIResource = this.resources).length, b = 0; b < i; ) { IResource setResource = arrayOfIResource[b];
/*  80 */       if (setResource != null)
/*  81 */         if (isParent(resource, setResource)) {
/*     */           try {
/*  83 */             if (subscriber.isSupervised(setResource)) {
/*  84 */               result.add(setResource);
/*     */             }
/*  86 */           } catch (TeamException e) {
/*     */             
/*  88 */             TeamPlugin.log((CoreException)e);
/*  89 */             result.add(setResource);
/*     */           } 
/*  91 */         } else if (isParent(setResource, resource)) {
/*  92 */           result.add(resource);
/*     */         }  
/*     */       b++; }
/*     */     
/*  96 */     return result.<IResource>toArray(new IResource[result.size()]);
/*     */   }
/*     */   
/*     */   public void setWorkingSet(IResource[] resources) {
/* 100 */     this.resources = resources;
/*     */   }
/*     */   
/*     */   public IResource[] getWorkingSet() {
/* 104 */     return this.resources;
/*     */   }
/*     */   
/*     */   private boolean isEmpty() {
/* 108 */     return !(this.resources != null && this.resources.length != 0);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SyncInfoWorkingSetFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */