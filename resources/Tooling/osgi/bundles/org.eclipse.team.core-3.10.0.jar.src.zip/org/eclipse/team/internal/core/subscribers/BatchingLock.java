/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.core.runtime.jobs.MultiRule;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BatchingLock
/*     */ {
/*  51 */   static final ISchedulingRule NULL_SCHEDULING_RULE = new ISchedulingRule()
/*     */     {
/*     */       public boolean contains(ISchedulingRule rule) {
/*  54 */         return false;
/*     */       }
/*     */       
/*     */       public boolean isConflicting(ISchedulingRule rule) {
/*  58 */         return false;
/*     */       }
/*     */     };
/*     */   public static interface IFlushOperation {
/*     */     void flush(BatchingLock.ThreadInfo param1ThreadInfo, IProgressMonitor param1IProgressMonitor) throws TeamException; }
/*  63 */   public static class ThreadInfo { private Set<IResource> changedResources = new HashSet<>();
/*     */     private BatchingLock.IFlushOperation operation;
/*  65 */     private List<ISchedulingRule> rules = new ArrayList<>();
/*     */     public ThreadInfo(BatchingLock.IFlushOperation operation) {
/*  67 */       this.operation = operation;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ISchedulingRule pushRule(ISchedulingRule resource, IProgressMonitor monitor) {
/*  78 */       ISchedulingRule rule = getRuleForResoure(resource);
/*  79 */       if (rule != BatchingLock.NULL_SCHEDULING_RULE) {
/*  80 */         boolean success = false;
/*     */         try {
/*  82 */           Job.getJobManager().beginRule(rule, monitor);
/*  83 */           addRule(rule);
/*  84 */           success = true;
/*     */         } finally {
/*  86 */           if (!success) {
/*     */             
/*     */             try {
/*     */ 
/*     */ 
/*     */               
/*  92 */               Job.getJobManager().endRule(rule);
/*  93 */             } catch (RuntimeException e) {
/*     */               
/*  95 */               TeamPlugin.log(4, "Failed to end scheduling rule", e);
/*     */             }
/*     */           
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 102 */         addRule(rule);
/*     */       } 
/* 104 */       return rule;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void popRule(ISchedulingRule rule, IProgressMonitor monitor) throws TeamException {
/*     */       ISchedulingRule stackedRule;
/*     */       try {
/* 118 */         if (isFlushRequired()) {
/* 119 */           flush(monitor);
/*     */         }
/*     */       } finally {
/* 122 */         ISchedulingRule iSchedulingRule = removeRule();
/* 123 */         if (rule == null) {
/* 124 */           rule = BatchingLock.NULL_SCHEDULING_RULE;
/*     */         }
/* 126 */         Assert.isTrue(iSchedulingRule.equals(rule), "end for resource '" + rule + "' does not match stacked rule '" + iSchedulingRule + "'");
/* 127 */         if (rule != BatchingLock.NULL_SCHEDULING_RULE)
/* 128 */           Job.getJobManager().endRule(rule); 
/*     */       } 
/*     */     }
/*     */     
/*     */     private ISchedulingRule getRuleForResoure(ISchedulingRule resourceRule) {
/*     */       ISchedulingRule rule;
/* 134 */       if (resourceRule instanceof IResource) {
/* 135 */         IResource resource = (IResource)resourceRule;
/* 136 */         if (resource.getType() == 8) {
/*     */           
/* 138 */           rule = BatchingLock.NULL_SCHEDULING_RULE;
/* 139 */         } else if (resource.getType() == 4) {
/* 140 */           IResource iResource = resource;
/*     */         } else {
/* 142 */           IContainer iContainer = resource.getParent();
/*     */         } 
/* 144 */       } else if (resourceRule instanceof MultiRule) {
/*     */         
/* 146 */         ISchedulingRule[] rules = ((MultiRule)resourceRule).getChildren();
/* 147 */         Set<ISchedulingRule> projects = new HashSet<>(); byte b; int i; ISchedulingRule[] arrayOfISchedulingRule1;
/* 148 */         for (i = (arrayOfISchedulingRule1 = rules).length, b = 0; b < i; ) { ISchedulingRule childRule = arrayOfISchedulingRule1[b];
/* 149 */           if (childRule instanceof IResource)
/* 150 */             projects.add(((IResource)childRule).getProject()); 
/*     */           b++; }
/*     */         
/* 153 */         if (projects.isEmpty()) {
/* 154 */           rule = BatchingLock.NULL_SCHEDULING_RULE;
/* 155 */         } else if (projects.size() == 1) {
/* 156 */           rule = projects.iterator().next();
/*     */         } else {
/* 158 */           MultiRule multiRule = new MultiRule(projects.<ISchedulingRule>toArray(new ISchedulingRule[projects.size()]));
/*     */         } 
/*     */       } else {
/*     */         
/* 162 */         rule = BatchingLock.NULL_SCHEDULING_RULE;
/*     */       } 
/* 164 */       return rule;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isNested() {
/* 173 */       return !this.rules.isEmpty();
/*     */     }
/*     */     public void addChangedResource(IResource resource) {
/* 176 */       this.changedResources.add(resource);
/*     */     }
/*     */     public boolean isEmpty() {
/* 179 */       return this.changedResources.isEmpty();
/*     */     }
/*     */     public IResource[] getChangedResources() {
/* 182 */       return this.changedResources.<IResource>toArray(new IResource[this.changedResources.size()]);
/*     */     }
/*     */     public void flush(IProgressMonitor monitor) throws TeamException {
/*     */       try {
/* 186 */         this.operation.flush(this, monitor);
/* 187 */       } catch (OutOfMemoryError e) {
/* 188 */         throw e;
/* 189 */       } catch (Error e) {
/* 190 */         handleAbortedFlush(e);
/* 191 */         throw e;
/* 192 */       } catch (RuntimeException e) {
/* 193 */         handleAbortedFlush(e);
/* 194 */         throw e;
/*     */       }
/*     */       finally {
/*     */         
/* 198 */         this.changedResources.clear();
/*     */       } 
/*     */     }
/*     */     private boolean isFlushRequired() {
/* 202 */       return !(this.rules.size() != 1 && !remainingRulesAreNull());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean remainingRulesAreNull() {
/* 208 */       for (int i = 0; i < this.rules.size() - 1; i++) {
/* 209 */         ISchedulingRule rule = this.rules.get(i);
/* 210 */         if (rule != BatchingLock.NULL_SCHEDULING_RULE) {
/* 211 */           return false;
/*     */         }
/*     */       } 
/* 214 */       return true;
/*     */     }
/*     */     private void handleAbortedFlush(Throwable t) {
/* 217 */       TeamPlugin.log(4, Messages.BatchingLock_11, t);
/*     */     }
/*     */     private void addRule(ISchedulingRule rule) {
/* 220 */       this.rules.add(rule);
/*     */     }
/*     */     private ISchedulingRule removeRule() {
/* 223 */       return this.rules.remove(this.rules.size() - 1);
/*     */     }
/*     */     public boolean ruleContains(IResource resource) {
/* 226 */       for (ISchedulingRule rule : this.rules) {
/* 227 */         if (rule != BatchingLock.NULL_SCHEDULING_RULE && rule.contains((ISchedulingRule)resource)) {
/* 228 */           return true;
/*     */         }
/*     */       } 
/* 231 */       return false;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 239 */   private Map<Thread, ThreadInfo> infos = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ThreadInfo getThreadInfo() {
/* 246 */     Thread thisThread = Thread.currentThread();
/* 247 */     synchronized (this.infos) {
/* 248 */       ThreadInfo info = this.infos.get(thisThread);
/* 249 */       return info;
/*     */     } 
/*     */   }
/*     */   
/*     */   private ThreadInfo getThreadInfo(IResource resource) {
/* 254 */     synchronized (this.infos) {
/* 255 */       for (ThreadInfo info : this.infos.values()) {
/* 256 */         if (info.ruleContains(resource)) {
/* 257 */           return info;
/*     */         }
/*     */       } 
/* 260 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public ISchedulingRule acquire(ISchedulingRule resourceRule, IFlushOperation operation, IProgressMonitor monitor) {
/* 265 */     ThreadInfo info = getThreadInfo();
/* 266 */     boolean added = false;
/* 267 */     synchronized (this.infos) {
/* 268 */       if (info == null) {
/* 269 */         info = createThreadInfo(operation);
/* 270 */         Thread thisThread = Thread.currentThread();
/* 271 */         this.infos.put(thisThread, info);
/* 272 */         added = true;
/* 273 */         if (Policy.DEBUG_THREADING) System.out.println("[" + thisThread.getName() + "] acquired batching lock on " + resourceRule); 
/*     */       } 
/*     */     } 
/*     */     try {
/* 277 */       return info.pushRule(resourceRule, monitor);
/* 278 */     } catch (OperationCanceledException e) {
/*     */ 
/*     */       
/* 281 */       if (added) {
/* 282 */         synchronized (this.infos) {
/* 283 */           this.infos.remove(Thread.currentThread());
/*     */         } 
/*     */       }
/* 286 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ThreadInfo createThreadInfo(IFlushOperation operation) {
/* 298 */     return new ThreadInfo(operation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release(ISchedulingRule rule, IProgressMonitor monitor) throws TeamException {
/* 311 */     ThreadInfo info = getThreadInfo();
/* 312 */     Assert.isNotNull(info, "Unmatched acquire/release.");
/* 313 */     Assert.isTrue(info.isNested(), "Unmatched acquire/release.");
/* 314 */     info.popRule(rule, monitor);
/* 315 */     synchronized (this.infos) {
/* 316 */       if (!info.isNested()) {
/* 317 */         Thread thisThread = Thread.currentThread();
/* 318 */         if (Policy.DEBUG_THREADING) System.out.println("[" + thisThread.getName() + "] released batching lock"); 
/* 319 */         this.infos.remove(thisThread);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void resourceChanged(IResource resource) {
/* 325 */     ThreadInfo info = getThreadInfo();
/* 326 */     Assert.isNotNull(info, "Folder changed outside of resource lock");
/* 327 */     info.addChangedResource(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush(IProgressMonitor monitor) throws TeamException {
/* 336 */     ThreadInfo info = getThreadInfo();
/* 337 */     Assert.isNotNull(info, "Flush requested outside of resource lock");
/* 338 */     info.flush(monitor);
/*     */   }
/*     */   
/*     */   public boolean isWithinActiveOperationScope(IResource resource) {
/* 342 */     synchronized (this.infos) {
/* 343 */       return (getThreadInfo(resource) != null);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\BatchingLock.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */