/*     */ package org.eclipse.team.core.subscribers;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.ProgressMonitorWrapper;
/*     */ import org.eclipse.team.core.diff.DiffFilter;
/*     */ import org.eclipse.team.core.mapping.IResourceDiffTree;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScopeManager;
/*     */ import org.eclipse.team.core.mapping.provider.MergeContext;
/*     */ import org.eclipse.team.core.mapping.provider.ResourceDiffTree;
/*     */ import org.eclipse.team.core.synchronize.SyncInfo;
/*     */ import org.eclipse.team.internal.core.mapping.GroupProgressMonitor;
/*     */ import org.eclipse.team.internal.core.subscribers.SubscriberDiffTreeEventHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SubscriberMergeContext
/*     */   extends MergeContext
/*     */ {
/*     */   private Subscriber subscriber;
/*     */   private SubscriberDiffTreeEventHandler handler;
/*     */   private final ISynchronizationScopeManager manager;
/*     */   
/*     */   protected SubscriberMergeContext(Subscriber subscriber, ISynchronizationScopeManager manager) {
/*  52 */     super(manager, getType(subscriber), (IResourceDiffTree)new ResourceDiffTree());
/*  53 */     this.subscriber = subscriber;
/*  54 */     this.manager = manager;
/*     */   }
/*     */   
/*     */   private static int getType(Subscriber subscriber) {
/*  58 */     return subscriber.getResourceComparator().isThreeWay() ? 
/*  59 */       3 : 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initialize() {
/*  67 */     this.handler = new SubscriberDiffTreeEventHandler(this.subscriber, this.manager, (ResourceDiffTree)getDiffTree(), getDiffFilter());
/*  68 */     this.handler.setJobFamily(this);
/*  69 */     this.handler.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DiffFilter getDiffFilter() {
/*  78 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh(ResourceTraversal[] traversals, int flags, IProgressMonitor monitor) throws CoreException {
/*  84 */     GroupProgressMonitor group = getGroup(monitor);
/*  85 */     if (group != null)
/*  86 */       this.handler.setProgressGroupHint(group.getGroup(), group.getTicks()); 
/*  87 */     this.handler.initializeIfNeeded();
/*  88 */     this.subscriber.refresh(traversals, monitor);
/*     */   }
/*     */   
/*     */   private GroupProgressMonitor getGroup(IProgressMonitor monitor) {
/*  92 */     if (monitor instanceof GroupProgressMonitor) {
/*  93 */       return (GroupProgressMonitor)monitor;
/*     */     }
/*  95 */     if (monitor instanceof ProgressMonitorWrapper) {
/*  96 */       ProgressMonitorWrapper wrapper = (ProgressMonitorWrapper)monitor;
/*  97 */       return getGroup(wrapper.getWrappedProgressMonitor());
/*     */     } 
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 104 */     this.handler.shutdown();
/* 105 */     super.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SyncInfo getSyncInfo(IResource resource) throws CoreException {
/* 115 */     return this.handler.getSubscriber().getSyncInfo(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subscriber getSubscriber() {
/* 123 */     return this.subscriber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void runInBackground(IWorkspaceRunnable runnable) {
/* 133 */     this.handler.run(runnable, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getAdapter(Class<T> adapter) {
/* 139 */     if (adapter == SubscriberDiffTreeEventHandler.class)
/* 140 */       return (T)this.handler; 
/* 141 */     return (T)super.getAdapter(adapter);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\subscribers\SubscriberMergeContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */