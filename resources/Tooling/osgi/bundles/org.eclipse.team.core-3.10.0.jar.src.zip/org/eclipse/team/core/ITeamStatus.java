package org.eclipse.team.core;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IStatus;

public interface ITeamStatus extends IStatus {
  public static final int RESOURCE_SYNC_INFO_ERROR = 1;
  
  public static final int SYNC_INFO_SET_ERROR = 2;
  
  public static final int SYNC_INFO_SET_CANCELLATION = 3;
  
  public static final int READ_ONLY_LOCAL = 279;
  
  IResource getResource();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\ITeamStatus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */