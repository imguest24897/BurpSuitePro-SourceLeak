/*     */ package org.eclipse.team.core.variants;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.core.TeamStatus;
/*     */ import org.eclipse.team.core.subscribers.ISubscriberChangeEvent;
/*     */ import org.eclipse.team.core.subscribers.Subscriber;
/*     */ import org.eclipse.team.core.subscribers.SubscriberChangeEvent;
/*     */ import org.eclipse.team.core.synchronize.SyncInfo;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResourceVariantTreeSubscriber
/*     */   extends Subscriber
/*     */ {
/*     */   public SyncInfo getSyncInfo(IResource resource) throws TeamException {
/*     */     IResourceVariant baseResource;
/*  53 */     if (!isSupervised(resource)) return null; 
/*  54 */     IResourceVariant remoteResource = getRemoteTree().getResourceVariant(resource);
/*     */     
/*  56 */     if (getResourceComparator().isThreeWay()) {
/*  57 */       baseResource = getBaseTree().getResourceVariant(resource);
/*     */     } else {
/*  59 */       baseResource = null;
/*     */     } 
/*  61 */     return getSyncInfo(resource, baseResource, remoteResource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SyncInfo getSyncInfo(IResource local, IResourceVariant base, IResourceVariant remote) throws TeamException {
/*  74 */     SyncInfo info = new SyncInfo(local, base, remote, getResourceComparator());
/*  75 */     info.init();
/*  76 */     return info;
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource[] members(IResource resource) throws TeamException {
/*  81 */     if (resource.getType() == 1) {
/*  82 */       return new IResource[0];
/*     */     }
/*     */     try {
/*  85 */       Set<IResource> allMembers = new HashSet<>();
/*     */       try {
/*  87 */         allMembers.addAll(Arrays.asList(((IContainer)resource).members()));
/*  88 */       } catch (CoreException e) {
/*  89 */         if (e.getStatus().getCode() != 368)
/*     */         {
/*     */           
/*  92 */           throw e;
/*     */         }
/*     */       } 
/*  95 */       allMembers.addAll(Arrays.asList(internalMembers(getRemoteTree(), resource)));
/*  96 */       if (getResourceComparator().isThreeWay()) {
/*  97 */         allMembers.addAll(Arrays.asList(internalMembers(getBaseTree(), resource)));
/*     */       }
/*  99 */       for (Iterator<IResource> iterator = allMembers.iterator(); iterator.hasNext(); ) {
/* 100 */         IResource member = iterator.next();
/* 101 */         if (!member.exists() && !getRemoteTree().hasResourceVariant(member)) {
/*     */           
/* 103 */           iterator.remove(); continue;
/* 104 */         }  if (!isSupervised(member))
/*     */         {
/* 106 */           iterator.remove();
/*     */         }
/*     */       } 
/* 109 */       return allMembers.<IResource>toArray(new IResource[allMembers.size()]);
/* 110 */     } catch (CoreException e) {
/* 111 */       throw TeamException.asTeamException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void refresh(IResource[] resources, int depth, IProgressMonitor monitor) throws TeamException {
/* 117 */     monitor = Policy.monitorFor(monitor);
/* 118 */     List<IStatus> errors = new ArrayList<>();
/* 119 */     List<IStatus> cancels = new ArrayList<>();
/*     */     try {
/* 121 */       monitor.beginTask(null, 1000 * resources.length); byte b; int i; IResource[] arrayOfIResource;
/* 122 */       for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/* 123 */         if (resource.getProject().isAccessible()) {
/* 124 */           IStatus status = refresh(resource, depth, Policy.subMonitorFor(monitor, 1000));
/* 125 */           if (status.getSeverity() == 8) {
/* 126 */             cancels.add(status);
/* 127 */           } else if (!status.isOK()) {
/* 128 */             errors.add(status);
/*     */           } 
/*     */         }  b++; }
/*     */     
/*     */     } finally {
/* 133 */       monitor.done();
/*     */     } 
/* 135 */     if (!errors.isEmpty()) {
/* 136 */       int numSuccess = resources.length - errors.size() - cancels.size();
/* 137 */       if (!cancels.isEmpty()) {
/* 138 */         errors.addAll(cancels);
/* 139 */         throw new TeamException(new MultiStatus("org.eclipse.team.core", 0, 
/* 140 */               (IStatus[])errors.toArray(new IStatus[errors.size()]), 
/* 141 */               NLS.bind(
/* 142 */                 Messages.ResourceVariantTreeSubscriber_3, 
/* 143 */                 new Object[] { getName(), 
/* 144 */                   Integer.toString(numSuccess), 
/* 145 */                   Integer.toString(resources.length), 
/* 146 */                   Integer.toString(cancels.size())
/* 147 */                 }), null)
/*     */             {
/*     */               public int getSeverity()
/*     */               {
/* 151 */                 return 4;
/*     */               }
/*     */             });
/*     */       } 
/* 155 */       throw new TeamException(new MultiStatus("org.eclipse.team.core", 0, 
/* 156 */             (IStatus[])errors.toArray(new IStatus[errors.size()]), 
/* 157 */             NLS.bind(Messages.ResourceVariantTreeSubscriber_1, new Object[] { getName(), Integer.toString(numSuccess), Integer.toString(resources.length) }), null));
/*     */     } 
/* 159 */     if (!cancels.isEmpty()) {
/* 160 */       throw new OperationCanceledException((
/* 161 */           (IStatus)cancels.get(0)).getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract IResourceVariantTree getBaseTree();
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract IResourceVariantTree getRemoteTree();
/*     */ 
/*     */ 
/*     */   
/*     */   private IStatus refresh(IResource resource, int depth, IProgressMonitor monitor) {
/* 176 */     monitor = Policy.monitorFor(monitor);
/*     */     try {
/* 178 */       monitor.beginTask(null, 100);
/* 179 */       Set<IResource> allChanges = new HashSet<>();
/* 180 */       if (getResourceComparator().isThreeWay()) {
/* 181 */         IResource[] baseChanges = getBaseTree().refresh(new IResource[] { resource }, depth, Policy.subMonitorFor(monitor, 25));
/* 182 */         allChanges.addAll(Arrays.asList(baseChanges));
/*     */       } 
/* 184 */       IResource[] remoteChanges = getRemoteTree().refresh(new IResource[] { resource }, depth, Policy.subMonitorFor(monitor, 75));
/* 185 */       allChanges.addAll(Arrays.asList(remoteChanges));
/* 186 */       IResource[] changedResources = allChanges.<IResource>toArray(new IResource[allChanges.size()]);
/* 187 */       fireTeamResourceChange((ISubscriberChangeEvent[])SubscriberChangeEvent.asSyncChangedDeltas(this, changedResources));
/* 188 */       return Status.OK_STATUS;
/* 189 */     } catch (TeamException e) {
/* 190 */       return (IStatus)new TeamStatus(4, "org.eclipse.team.core", 0, NLS.bind(Messages.ResourceVariantTreeSubscriber_2, (Object[])new String[] { resource.getFullPath().toString(), e.getMessage() }), (Throwable)e, resource);
/* 191 */     } catch (OperationCanceledException e) {
/* 192 */       return (IStatus)new TeamStatus(8, "org.eclipse.team.core", 0, NLS.bind(
/* 193 */             Messages.ResourceVariantTreeSubscriber_4, 
/* 194 */             (Object[])new String[] { resource.getFullPath().toString() }), (Throwable)e, 
/* 195 */           resource);
/*     */     } finally {
/* 197 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private IResource[] internalMembers(IResourceVariantTree tree, IResource resource) throws TeamException, CoreException {
/*     */     IResource[] members;
/*     */     try {
/* 205 */       members = tree.members(resource);
/* 206 */     } catch (CoreException e) {
/* 207 */       if (!isSupervised(resource) || e.getStatus().getCode() == 368)
/*     */       {
/*     */         
/* 210 */         return new IResource[0];
/*     */       }
/* 212 */       throw e;
/*     */     } 
/* 214 */     return members;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\variants\ResourceVariantTreeSubscriber.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */