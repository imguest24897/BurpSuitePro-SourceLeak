package org.eclipse.team.core.subscribers;

import java.util.EventListener;

public interface ISubscriberChangeListener extends EventListener {
  void subscriberResourceChanged(ISubscriberChangeEvent[] paramArrayOfISubscriberChangeEvent);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\subscribers\ISubscriberChangeListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */