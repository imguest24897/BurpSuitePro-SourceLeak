/*     */ package org.eclipse.team.core.subscribers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*     */ import org.eclipse.core.resources.mapping.ResourceMappingContext;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.ITeamStatus;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.core.TeamStatus;
/*     */ import org.eclipse.team.core.diff.IDiff;
/*     */ import org.eclipse.team.core.diff.IDiffVisitor;
/*     */ import org.eclipse.team.core.diff.IThreeWayDiff;
/*     */ import org.eclipse.team.core.synchronize.SyncInfo;
/*     */ import org.eclipse.team.core.synchronize.SyncInfoSet;
/*     */ import org.eclipse.team.core.variants.IResourceVariantComparator;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ import org.eclipse.team.internal.core.mapping.SyncInfoToDiffConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Subscriber
/*     */ {
/*  81 */   private List<ISubscriberChangeListener> listeners = new ArrayList<>(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isSupervised(IResource paramIResource) throws TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract IResource[] members(IResource paramIResource) throws TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract IResource[] roots();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract SyncInfo getSyncInfo(IResource paramIResource) throws TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract IResourceVariantComparator getResourceComparator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void refresh(IResource[] paramArrayOfIResource, int paramInt, IProgressMonitor paramIProgressMonitor) throws TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addListener(ISubscriberChangeListener listener) {
/* 227 */     synchronized (this.listeners) {
/* 228 */       if (!this.listeners.contains(listener)) {
/* 229 */         this.listeners.add(listener);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeListener(ISubscriberChangeListener listener) {
/* 241 */     synchronized (this.listeners) {
/* 242 */       this.listeners.remove(listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void collectOutOfSync(IResource[] resources, int depth, SyncInfoSet set, IProgressMonitor monitor) {
/*     */     try {
/* 267 */       monitor.beginTask(null, 100 * resources.length); byte b; int i; IResource[] arrayOfIResource;
/* 268 */       for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/* 269 */         IProgressMonitor subMonitor = Policy.subMonitorFor(monitor, 100);
/* 270 */         subMonitor.beginTask(null, -1);
/* 271 */         collect(resource, depth, set, subMonitor);
/* 272 */         subMonitor.done(); b++; }
/*     */     
/*     */     } finally {
/* 275 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireTeamResourceChange(final ISubscriberChangeEvent[] deltas) {
/*     */     ISubscriberChangeListener[] allListeners;
/* 288 */     synchronized (this.listeners) {
/* 289 */       allListeners = this.listeners.<ISubscriberChangeListener>toArray(new ISubscriberChangeListener[this.listeners.size()]);
/*     */     }  byte b; int i;
/*     */     ISubscriberChangeListener[] arrayOfISubscriberChangeListener1;
/* 292 */     for (i = (arrayOfISubscriberChangeListener1 = allListeners).length, b = 0; b < i; ) { final ISubscriberChangeListener listener = arrayOfISubscriberChangeListener1[b];
/* 293 */       SafeRunner.run(new ISafeRunnable()
/*     */           {
/*     */             public void handleException(Throwable exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             public void run() throws Exception {
/* 301 */               listener.subscriberResourceChanged(deltas);
/*     */             }
/*     */           });
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void collect(IResource resource, int depth, SyncInfoSet set, IProgressMonitor monitor) {
/* 317 */     Policy.checkCanceled(monitor);
/*     */     
/* 319 */     if (resource.getType() != 1 && 
/* 320 */       depth != 0) {
/*     */       try {
/* 322 */         IResource[] members = members(resource); byte b; int i; IResource[] arrayOfIResource1;
/* 323 */         for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource member = arrayOfIResource1[b];
/* 324 */           collect(member, (depth == 2) ? 
/* 325 */               2 : 
/* 326 */               0, set, monitor); b++; }
/*     */       
/* 328 */       } catch (TeamException e) {
/* 329 */         set.addError((ITeamStatus)new TeamStatus(4, "org.eclipse.team.core", 2, NLS.bind(Messages.SubscriberEventHandler_8, (Object[])new String[] { resource.getFullPath().toString(), e.getMessage() }), (Throwable)e, resource));
/*     */       } 
/*     */     }
/*     */     
/* 333 */     monitor.subTask(NLS.bind(Messages.SubscriberEventHandler_2, (Object[])new String[] { resource.getFullPath().toString() }));
/*     */     try {
/* 335 */       SyncInfo info = getSyncInfo(resource);
/* 336 */       if (info == null || info.getKind() == 0) {
/*     */ 
/*     */         
/* 339 */         set.remove(resource);
/*     */       } else {
/* 341 */         set.add(info);
/*     */       } 
/* 343 */     } catch (TeamException e) {
/* 344 */       set.addError((ITeamStatus)new TeamStatus(
/* 345 */             4, "org.eclipse.team.core", 1, 
/* 346 */             NLS.bind(Messages.SubscriberEventHandler_9, (Object[])new String[] { resource.getFullPath().toString(), e.getMessage()
/* 347 */               }), (Throwable)e, resource));
/*     */     } 
/*     */     
/* 350 */     monitor.worked(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDiff getDiff(IResource resource) throws CoreException {
/* 380 */     SyncInfo info = getSyncInfo(resource);
/* 381 */     if (info == null || info.getKind() == 0)
/* 382 */       return null; 
/* 383 */     return SyncInfoToDiffConverter.getDefault().getDeltaFor(info);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(ResourceTraversal[] traversals, IDiffVisitor visitor) throws CoreException {
/*     */     byte b;
/*     */     int i;
/*     */     ResourceTraversal[] arrayOfResourceTraversal;
/* 403 */     for (i = (arrayOfResourceTraversal = traversals).length, b = 0; b < i; ) { ResourceTraversal traversal = arrayOfResourceTraversal[b];
/* 404 */       accept(traversal.getResources(), traversal.getDepth(), visitor);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void accept(IResource[] resources, int depth, IDiffVisitor visitor) throws CoreException {
/*     */     byte b;
/*     */     int i;
/*     */     IResource[] arrayOfIResource;
/* 430 */     for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/* 431 */       accept(resource, depth, visitor);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   private void accept(IResource resource, int depth, IDiffVisitor visitor) throws CoreException {
/* 436 */     IDiff node = getDiff(resource);
/* 437 */     if (node != null && node.getKind() != 0 && 
/* 438 */       !visitor.visit(node)) {
/*     */       return;
/*     */     }
/* 441 */     if (depth != 0) {
/* 442 */       IResource[] members = members(resource);
/* 443 */       int newDepth = (depth == 2) ? 2 : 0; byte b; int i; IResource[] arrayOfIResource1;
/* 444 */       for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource member = arrayOfIResource1[b];
/* 445 */         accept(member, newDepth, visitor);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh(ResourceTraversal[] traversals, IProgressMonitor monitor) throws TeamException {
/* 469 */     monitor.beginTask(null, 100 * traversals.length); byte b; int i; ResourceTraversal[] arrayOfResourceTraversal;
/* 470 */     for (i = (arrayOfResourceTraversal = traversals).length, b = 0; b < i; ) { ResourceTraversal traversal = arrayOfResourceTraversal[b];
/* 471 */       refresh(traversal.getResources(), traversal.getDepth(), Policy.subMonitorFor(monitor, 100)); b++; }
/*     */     
/* 473 */     monitor.done();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getState(ResourceMapping mapping, int stateMask, IProgressMonitor monitor) throws CoreException {
/* 504 */     ResourceTraversal[] traversals = mapping.getTraversals((ResourceMappingContext)new SubscriberResourceMappingContext(this, true), monitor);
/* 505 */     int[] direction = new int[1];
/* 506 */     int[] kind = new int[1];
/* 507 */     accept(traversals, diff -> {
/*     */           if (diff instanceof IThreeWayDiff) {
/*     */             IThreeWayDiff twd = (IThreeWayDiff)diff;
/*     */             
/*     */             paramArrayOfint1[0] = paramArrayOfint1[0] | twd.getDirection();
/*     */           } 
/*     */           int diffKind = diff.getKind();
/*     */           if (paramArrayOfint2[0] == 0) {
/*     */             paramArrayOfint2[0] = diffKind;
/*     */           }
/*     */           if (paramArrayOfint2[0] != diffKind) {
/*     */             paramArrayOfint2[0] = 4;
/*     */           }
/*     */           return (diffKind == 4);
/*     */         });
/* 522 */     return (direction[0] | kind[0]) & stateMask;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\subscribers\Subscriber.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */