/*     */ package org.eclipse.team.core.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceChangeEvent;
/*     */ import org.eclipse.core.resources.IResourceChangeListener;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.team.core.RepositoryProvider;
/*     */ import org.eclipse.team.core.RepositoryProviderType;
/*     */ import org.eclipse.team.internal.core.IRepositoryProviderListener;
/*     */ import org.eclipse.team.internal.core.RepositoryProviderManager;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ChangeTracker
/*     */ {
/*  45 */   private Map<IProject, IChangeGroupingRequestor> trackedProjects = new HashMap<>();
/*     */   private boolean disposed;
/*  47 */   private ChangeListener changeListener = new ChangeListener();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ChangeListener
/*     */     implements IResourceChangeListener, IRepositoryProviderListener
/*     */   {
/*     */     public void resourceChanged(IResourceChangeEvent event) {
/*  58 */       if (ChangeTracker.this.disposed)
/*  59 */         return;  IResourceDelta delta = event.getDelta();
/*  60 */       IResourceDelta[] projectDeltas = delta.getAffectedChildren(7); byte b; int i; IResourceDelta[] arrayOfIResourceDelta1;
/*  61 */       for (i = (arrayOfIResourceDelta1 = projectDeltas).length, b = 0; b < i; ) { IResourceDelta projectDelta = arrayOfIResourceDelta1[b];
/*  62 */         IResource resource = projectDelta.getResource();
/*  63 */         if (resource.getType() == 4) {
/*  64 */           IProject project = (IProject)resource;
/*  65 */           if (ChangeTracker.this.isProjectOfInterest(project)) {
/*  66 */             if (ChangeTracker.this.isProjectTracked(project)) {
/*  67 */               IResource[] resources = ChangeTracker.this.getProjectChanges(project, projectDelta);
/*  68 */               if (resources.length > 0)
/*  69 */                 ChangeTracker.this.handleChanges(project, resources); 
/*     */             } else {
/*  71 */               ChangeTracker.this.trackProject(project);
/*     */             } 
/*     */           } else {
/*  74 */             ChangeTracker.this.stopTrackingProject(project);
/*     */           } 
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void providerMapped(RepositoryProvider provider) {
/*  86 */       if (ChangeTracker.this.disposed)
/*  87 */         return;  if (ChangeTracker.this.isProjectOfInterest(provider.getProject())) {
/*  88 */         ChangeTracker.this.trackProject(provider.getProject());
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void providerUnmapped(IProject project) {
/*  98 */       if (ChangeTracker.this.disposed)
/*  99 */         return;  ChangeTracker.this.stopTrackingProject(project);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 115 */     ResourcesPlugin.getWorkspace().addResourceChangeListener(this.changeListener, 1);
/* 116 */     RepositoryProviderManager.getInstance().addListener(this.changeListener);
/* 117 */     IProject[] allProjects = ResourcesPlugin.getWorkspace().getRoot().getProjects(); byte b; int i; IProject[] arrayOfIProject1;
/* 118 */     for (i = (arrayOfIProject1 = allProjects).length, b = 0; b < i; ) { IProject project = arrayOfIProject1[b];
/* 119 */       if (isProjectOfInterest(project)) {
/* 120 */         trackProject(project);
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 129 */     this.disposed = true;
/* 130 */     ResourcesPlugin.getWorkspace().removeResourceChangeListener(this.changeListener);
/* 131 */     RepositoryProviderManager.getInstance().removeListener(this.changeListener);
/*     */   }
/*     */   
/*     */   private IResource[] getProjectChanges(IProject project, IResourceDelta projectDelta) {
/* 135 */     List<IResource> result = new ArrayList<>();
/*     */     try {
/* 137 */       projectDelta.accept(delta -> {
/*     */             if ((isResourceOfInterest(delta.getResource()) & isChangeOfInterest(delta)) != 0) {
/*     */               paramList.add(delta.getResource());
/*     */             }
/*     */             return true;
/*     */           });
/* 143 */     } catch (CoreException e) {
/* 144 */       TeamPlugin.log(e);
/*     */     } 
/* 146 */     return result.<IResource>toArray(new IResource[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isChangeOfInterest(IResourceDelta delta) {
/* 155 */     return ((delta.getKind() & 0x7) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopTrackingProject(IProject project) {
/* 164 */     this.trackedProjects.remove(project);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean isProjectTracked(IProject project) {
/* 173 */     return this.trackedProjects.containsKey(project);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isProjectOfInterest(IProject project) {
/* 188 */     return project.isAccessible();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean trackProject(IProject project) {
/* 220 */     if (RepositoryProvider.isShared(project)) {
/*     */       try {
/* 222 */         String currentId = project.getPersistentProperty(TeamPlugin.PROVIDER_PROP_KEY);
/* 223 */         if (currentId != null) {
/* 224 */           RepositoryProviderType type = RepositoryProviderType.getProviderType(currentId);
/* 225 */           if (type != null) {
/* 226 */             IChangeGroupingRequestor collector = getCollector(type);
/* 227 */             if (collector != null) {
/* 228 */               this.trackedProjects.put(project, collector);
/*     */ 
/*     */ 
/*     */               
/* 232 */               projectTracked(project);
/* 233 */               return true;
/*     */             } 
/*     */           } 
/*     */         } 
/* 237 */       } catch (CoreException e) {
/* 238 */         TeamPlugin.log(e);
/*     */       } 
/*     */     }
/* 241 */     return false;
/*     */   }
/*     */   
/*     */   private IChangeGroupingRequestor getCollector(RepositoryProviderType type) {
/* 245 */     if (type != null) {
/* 246 */       IChangeGroupingRequestor o = (IChangeGroupingRequestor)type.getAdapter(IChangeGroupingRequestor.class);
/* 247 */       if (o != null) {
/* 248 */         return o;
/*     */       }
/*     */     } 
/* 251 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void projectTracked(IProject project) {
/* 260 */     handleProjectChange(project);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void ensureGrouped(IProject project, String name, IFile[] files) throws CoreException {
/* 271 */     IChangeGroupingRequestor collector = getCollector(project);
/* 272 */     if (collector != null) {
/* 273 */       collector.ensureChangesGrouped(project, files, name);
/*     */     }
/*     */   }
/*     */   
/*     */   private IChangeGroupingRequestor getCollector(IProject project) {
/* 278 */     return this.trackedProjects.get(project);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isModified(IFile file) throws CoreException {
/* 290 */     IChangeGroupingRequestor collector = getCollector(file.getProject());
/* 291 */     if (collector != null)
/* 292 */       return collector.isModified(file); 
/* 293 */     return false;
/*     */   }
/*     */   
/*     */   protected abstract boolean isResourceOfInterest(IResource paramIResource);
/*     */   
/*     */   protected abstract void handleChanges(IProject paramIProject, IResource[] paramArrayOfIResource);
/*     */   
/*     */   protected abstract void handleProjectChange(IProject paramIProject);
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\ChangeTracker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */