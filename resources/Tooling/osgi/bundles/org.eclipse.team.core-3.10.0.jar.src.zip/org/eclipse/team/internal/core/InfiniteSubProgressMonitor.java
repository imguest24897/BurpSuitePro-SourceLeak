/*    */ package org.eclipse.team.internal.core;
/*    */ 
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.SubProgressMonitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InfiniteSubProgressMonitor
/*    */   extends SubProgressMonitor
/*    */ {
/*    */   int totalWork;
/*    */   int halfWay;
/*    */   int currentIncrement;
/*    */   int nextProgress;
/*    */   int worked;
/*    */   
/*    */   public InfiniteSubProgressMonitor(IProgressMonitor monitor, int ticks) {
/* 45 */     this(monitor, ticks, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InfiniteSubProgressMonitor(IProgressMonitor monitor, int ticks, int style) {
/* 55 */     super(monitor, ticks, style);
/*    */   }
/*    */ 
/*    */   
/*    */   public void beginTask(String name, int totalWork) {
/* 60 */     super.beginTask(name, totalWork);
/* 61 */     this.totalWork = totalWork;
/* 62 */     this.halfWay = totalWork / 2;
/* 63 */     this.currentIncrement = 1;
/* 64 */     this.nextProgress = this.currentIncrement;
/* 65 */     this.worked = 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public void worked(int work) {
/* 70 */     if (this.worked >= this.totalWork)
/* 71 */       return;  if (--this.nextProgress <= 0) {
/* 72 */       super.worked(1);
/* 73 */       this.worked++;
/* 74 */       if (this.worked >= this.halfWay) {
/*    */ 
/*    */         
/* 77 */         this.currentIncrement *= 2;
/* 78 */         this.halfWay += (this.totalWork - this.halfWay) / 2;
/*    */       } 
/*    */       
/* 81 */       this.nextProgress = this.currentIncrement;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void subTask(String name) {
/* 93 */     if (name != null && !name.isEmpty())
/* 94 */       super.subTask(name); 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\InfiniteSubProgressMonitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */