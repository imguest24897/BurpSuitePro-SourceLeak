package org.eclipse.team.core.mapping;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.mapping.ModelProvider;
import org.eclipse.core.resources.mapping.ResourceMapping;
import org.eclipse.core.resources.mapping.ResourceMappingContext;
import org.eclipse.core.resources.mapping.ResourceTraversal;

public interface ISynchronizationScope {
  IProject[] getProjects();
  
  ResourceMappingContext getContext();
  
  ResourceMapping[] getInputMappings();
  
  ISynchronizationScope asInputScope();
  
  ResourceMapping[] getMappings();
  
  ResourceTraversal[] getTraversals();
  
  IResource[] getRoots();
  
  boolean contains(IResource paramIResource);
  
  void addScopeChangeListener(ISynchronizationScopeChangeListener paramISynchronizationScopeChangeListener);
  
  void removeScopeChangeListener(ISynchronizationScopeChangeListener paramISynchronizationScopeChangeListener);
  
  ResourceTraversal[] getTraversals(ResourceMapping paramResourceMapping);
  
  boolean hasAdditionalMappings();
  
  boolean hasAdditonalResources();
  
  ModelProvider[] getModelProviders();
  
  ResourceMapping[] getMappings(String paramString);
  
  ResourceTraversal[] getTraversals(String paramString);
  
  ResourceMapping getMapping(Object paramObject);
  
  void refresh(ResourceMapping[] paramArrayOfResourceMapping);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\ISynchronizationScope.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */