/*     */ package org.eclipse.team.core.history.provider;
/*     */ 
/*     */ import java.net.URI;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IStorage;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.team.core.history.IFileRevision;
/*     */ import org.eclipse.team.core.history.ITag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FileRevision
/*     */   implements IFileRevision
/*     */ {
/*     */   private static final class LocalFileRevision
/*     */     extends FileRevision
/*     */   {
/*     */     private final IFile file;
/*     */     
/*     */     private LocalFileRevision(IFile file) {
/*  41 */       this.file = file;
/*     */     }
/*     */ 
/*     */     
/*     */     public IStorage getStorage(IProgressMonitor monitor) {
/*  46 */       return (IStorage)this.file;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getName() {
/*  51 */       return this.file.getName();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean exists() {
/*  56 */       return this.file.exists();
/*     */     }
/*     */ 
/*     */     
/*     */     public long getTimestamp() {
/*  61 */       return this.file.getLocalTimeStamp();
/*     */     }
/*     */ 
/*     */     
/*     */     public URI getURI() {
/*  66 */       return this.file.getLocationURI();
/*     */     }
/*     */ 
/*     */     
/*     */     public IFileRevision withAllProperties(IProgressMonitor monitor) throws CoreException {
/*  71 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isPropertyMissing() {
/*  76 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  81 */       return this.file.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/*  86 */       if (obj == this)
/*  87 */         return true; 
/*  88 */       if (obj instanceof LocalFileRevision) {
/*  89 */         LocalFileRevision other = (LocalFileRevision)obj;
/*  90 */         return other.file.equals(this.file);
/*     */       } 
/*  92 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static IFileRevision getFileRevisionFor(IFile file) {
/* 106 */     return new LocalFileRevision(file);
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/* 111 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTimestamp() {
/* 116 */     return -1L;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean exists() {
/* 121 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentIdentifier() {
/* 126 */     return null;
/*     */   }
/*     */   
/*     */   public String getAuthor() {
/* 130 */     return null;
/*     */   }
/*     */   
/*     */   public String getComment() {
/* 134 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITag[] getBranches() {
/* 143 */     return new ITag[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public ITag[] getTags() {
/* 148 */     return new ITag[0];
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\history\provider\FileRevision.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */