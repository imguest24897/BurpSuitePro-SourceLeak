/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.team.core.ITeamStatus;
/*     */ import org.eclipse.team.core.TeamStatus;
/*     */ import org.eclipse.team.core.synchronize.SyncInfo;
/*     */ import org.eclipse.team.core.synchronize.SyncInfoSet;
/*     */ import org.eclipse.team.internal.core.BackgroundEventHandler;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   extends SyncInfoSet
/*     */ {
/*     */   public void add(SyncInfo info) {
/* 144 */     super.add(info);
/* 145 */     SubscriberSyncInfoEventHandler.this.queueDispatchEvent(
/* 146 */         (BackgroundEventHandler.Event)new SubscriberSyncInfoEventHandler.SubscriberSyncInfoEvent(SubscriberSyncInfoEventHandler.this, info.getLocal(), 2, 0, info));
/*     */   }
/*     */   
/*     */   public void addError(ITeamStatus status) {
/* 150 */     if (status instanceof TeamStatus) {
/* 151 */       TeamStatus ts = (TeamStatus)status;
/* 152 */       IResource resource = ts.getResource();
/* 153 */       if (resource != null && !resource.getProject().isAccessible()) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 159 */     super.addError(status);
/* 160 */     TeamPlugin.getPlugin().getLog().log((IStatus)status);
/* 161 */     SubscriberSyncInfoEventHandler.this.syncSetInput.handleError(status);
/*     */   }
/*     */   
/*     */   public void remove(IResource resource) {
/* 165 */     super.remove(resource);
/* 166 */     SubscriberSyncInfoEventHandler.this.queueDispatchEvent(
/* 167 */         (BackgroundEventHandler.Event)new SubscriberEventHandler.SubscriberEvent(SubscriberSyncInfoEventHandler.this, resource, 1, 0));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SubscriberSyncInfoEventHandler$2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */