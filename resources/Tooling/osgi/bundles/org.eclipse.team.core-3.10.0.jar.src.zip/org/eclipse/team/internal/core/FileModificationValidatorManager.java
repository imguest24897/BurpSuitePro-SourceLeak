/*     */ package org.eclipse.team.internal.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.team.FileModificationValidationContext;
/*     */ import org.eclipse.core.resources.team.FileModificationValidator;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.team.core.RepositoryProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileModificationValidatorManager
/*     */   extends FileModificationValidator
/*     */ {
/*     */   private FileModificationValidator defaultValidator;
/*     */   
/*     */   public IStatus validateEdit(IFile[] files, FileModificationValidationContext context) {
/*  41 */     ArrayList<IStatus> returnStati = new ArrayList<>();
/*     */ 
/*     */     
/*  44 */     Map<RepositoryProvider, List<IFile>> providersToFiles = new HashMap<>(files.length); byte b;
/*     */     int i;
/*     */     IFile[] arrayOfIFile;
/*  47 */     for (i = (arrayOfIFile = files).length, b = 0; b < i; ) { IFile file = arrayOfIFile[b];
/*  48 */       RepositoryProvider provider = RepositoryProvider.getProvider(file.getProject());
/*     */       
/*  50 */       if (!providersToFiles.containsKey(provider)) {
/*  51 */         providersToFiles.put(provider, new ArrayList<>());
/*     */       }
/*     */       
/*  54 */       ((List<IFile>)providersToFiles.get(provider)).add(file);
/*     */       b++; }
/*     */     
/*  57 */     Iterator<RepositoryProvider> providersIterator = providersToFiles.keySet().iterator();
/*     */     
/*  59 */     boolean allOK = true;
/*     */ 
/*     */     
/*  62 */     while (providersIterator.hasNext()) {
/*  63 */       RepositoryProvider provider = providersIterator.next();
/*  64 */       List<IFile> filesList = providersToFiles.get(provider);
/*  65 */       IFile[] filesArray = filesList.<IFile>toArray(new IFile[filesList.size()]);
/*  66 */       FileModificationValidator validator = getDefaultValidator();
/*     */ 
/*     */       
/*  69 */       if (provider != null) {
/*  70 */         FileModificationValidator v = provider.getFileModificationValidator2();
/*  71 */         if (v != null) validator = v;
/*     */       
/*     */       } 
/*  74 */       IStatus status = validator.validateEdit(filesArray, context);
/*  75 */       if (!status.isOK()) {
/*  76 */         allOK = false;
/*     */       }
/*  78 */       returnStati.add(status);
/*     */     } 
/*     */     
/*  81 */     if (returnStati.size() == 1) {
/*  82 */       return returnStati.get(0);
/*     */     }
/*     */     
/*  85 */     return (IStatus)new MultiStatus("org.eclipse.team.core", 0, returnStati.<IStatus>toArray(new IStatus[returnStati.size()]), 
/*  86 */         allOK ? Messages.ok : Messages.FileModificationValidator_editFailed, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public IStatus validateSave(IFile file) {
/*  91 */     RepositoryProvider provider = RepositoryProvider.getProvider(file.getProject());
/*  92 */     FileModificationValidator validator = getDefaultValidator();
/*     */ 
/*     */     
/*  95 */     if (provider != null) {
/*  96 */       FileModificationValidator v = provider.getFileModificationValidator2();
/*  97 */       if (v != null) validator = v;
/*     */     
/*     */     } 
/* 100 */     return validator.validateSave(file);
/*     */   }
/*     */   
/*     */   private synchronized FileModificationValidator getDefaultValidator() {
/* 104 */     if (this.defaultValidator == null) {
/* 105 */       this.defaultValidator = new DefaultFileModificationValidator();
/*     */     }
/* 107 */     return this.defaultValidator;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\FileModificationValidatorManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */