/*     */ package org.eclipse.team.internal.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.ILog;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExceptionCollector
/*     */ {
/*  37 */   private List<IStatus> statuses = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private String message;
/*     */ 
/*     */   
/*     */   private String pluginId;
/*     */ 
/*     */   
/*     */   private int severity;
/*     */ 
/*     */   
/*     */   private ILog log;
/*     */ 
/*     */ 
/*     */   
/*     */   public ExceptionCollector(String message, String pluginId, int severity, ILog log) {
/*  55 */     this.message = message;
/*  56 */     this.pluginId = pluginId;
/*  57 */     this.severity = severity;
/*  58 */     this.log = log;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  65 */     this.statuses.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus getStatus() {
/*  76 */     if (this.statuses.isEmpty()) {
/*  77 */       return Status.OK_STATUS;
/*     */     }
/*  79 */     MultiStatus multiStatus = new MultiStatus(this.pluginId, this.severity, this.message, null);
/*  80 */     Iterator<IStatus> it = this.statuses.iterator();
/*  81 */     while (it.hasNext()) {
/*  82 */       IStatus status = it.next();
/*  83 */       multiStatus.merge(status);
/*     */     } 
/*  85 */     return (IStatus)multiStatus;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleException(CoreException exception) {
/*  98 */     if (this.log != null) {
/*  99 */       this.log.log((IStatus)new Status(this.severity, this.pluginId, 0, this.message, (Throwable)exception));
/*     */     }
/*     */     
/* 102 */     IStatus exceptionStatus = exception.getStatus();
/*     */     
/* 104 */     Status status = new Status(exceptionStatus.getSeverity(), exceptionStatus.getPlugin(), exceptionStatus.getCode(), exceptionStatus.getMessage(), (Throwable)exception);
/* 105 */     recordStatus((IStatus)status);
/* 106 */     IStatus[] children = status.getChildren(); byte b; int i; IStatus[] arrayOfIStatus1;
/* 107 */     for (i = (arrayOfIStatus1 = children).length, b = 0; b < i; ) { IStatus status2 = arrayOfIStatus1[b];
/* 108 */       recordStatus(status2);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   private void recordStatus(IStatus status) {
/* 113 */     this.statuses.add(status);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\ExceptionCollector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */