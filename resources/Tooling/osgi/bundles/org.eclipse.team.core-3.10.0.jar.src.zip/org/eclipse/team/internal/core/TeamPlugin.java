/*     */ package org.eclipse.team.internal.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Plugin;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ import org.eclipse.core.runtime.content.IContentTypeManager;
/*     */ import org.eclipse.osgi.service.debug.DebugOptionsListener;
/*     */ import org.eclipse.team.core.RepositoryProviderType;
/*     */ import org.eclipse.team.core.Team;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.internal.core.mapping.IStreamMergerDelegate;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.ServiceRegistration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TeamPlugin
/*     */   extends Plugin
/*     */ {
/*     */   public static final String ID = "org.eclipse.team.core";
/*     */   public static final String PROVIDER_EXTENSION = "repository-provider-type";
/*     */   public static final String FILE_TYPES_EXTENSION = "fileTypes";
/*     */   public static final String IGNORE_EXTENSION = "ignore";
/*     */   public static final String PROJECT_SET_EXTENSION = "projectSets";
/*     */   public static final String REPOSITORY_EXTENSION = "repository";
/*     */   public static final String DEFAULT_FILE_MODIFICATION_VALIDATOR_EXTENSION = "defaultFileModificationValidator";
/*  82 */   public static final QualifiedName PROVIDER_PROP_KEY = new QualifiedName("org.eclipse.team.core", "repository");
/*     */ 
/*     */   
/*     */   public static final String EXTENSION_POINT_BUNDLE_IMPORTERS = "org.eclipse.team.core.bundleImporters";
/*     */ 
/*     */   
/*     */   private static TeamPlugin plugin;
/*     */ 
/*     */   
/*     */   private ServiceRegistration debugRegistration;
/*     */ 
/*     */   
/*     */   private IStreamMergerDelegate mergerDelegate;
/*     */ 
/*     */   
/*     */   public TeamPlugin() {
/*  98 */     plugin = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void start(BundleContext context) throws Exception {
/* 103 */     super.start(context);
/*     */ 
/*     */     
/* 106 */     Hashtable<String, String> properties = new Hashtable<>(2);
/* 107 */     properties.put("listener.symbolic.name", "org.eclipse.team.core");
/* 108 */     this.debugRegistration = context.registerService(DebugOptionsListener.class, Policy.DEBUG_OPTIONS_LISTENER, properties);
/*     */     
/* 110 */     Team.startup();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop(BundleContext context) throws Exception {
/*     */     try {
/* 117 */       this.debugRegistration.unregister();
/* 118 */       this.debugRegistration = null;
/*     */       
/* 120 */       Team.shutdown();
/* 121 */       ResourceVariantCache.shutdown();
/*     */     } finally {
/* 123 */       super.stop(context);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TeamPlugin getPlugin() {
/* 133 */     return plugin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void log(int severity, String message, Throwable e) {
/* 143 */     plugin.getLog().log((IStatus)new Status(severity, "org.eclipse.team.core", 0, message, e));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void log(CoreException e) {
/* 152 */     log(e.getStatus().getSeverity(), e.getMessage(), (Throwable)e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TeamException wrapException(CoreException e) {
/* 159 */     IStatus status = e.getStatus();
/* 160 */     return new TeamException((IStatus)new Status(status.getSeverity(), "org.eclipse.team.core", status.getCode(), status.getMessage(), (Throwable)e));
/*     */   }
/*     */   
/*     */   public static String getCharset(String name, InputStream stream) throws IOException {
/* 164 */     IContentDescription description = getContentDescription(name, stream);
/* 165 */     return (description == null) ? null : description.getCharset();
/*     */   }
/*     */ 
/*     */   
/*     */   public static IContentDescription getContentDescription(String name, InputStream stream) throws IOException {
/* 170 */     IContentTypeManager contentTypeManager = Platform.getContentTypeManager();
/*     */     try {
/* 172 */       return contentTypeManager.getDescriptionFor(stream, name, IContentDescription.ALL);
/*     */     } finally {
/* 174 */       if (stream != null) {
/*     */         try {
/* 176 */           stream.close();
/* 177 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static RepositoryProviderType getAliasType(String id) {
/* 184 */     IExtensionPoint extension = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.team.core", "repository");
/* 185 */     if (extension != null) {
/* 186 */       IExtension[] extensions = extension.getExtensions(); byte b; int i; IExtension[] arrayOfIExtension1;
/* 187 */       for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension ext = arrayOfIExtension1[b];
/* 188 */         IConfigurationElement[] configElements = ext.getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 189 */         for (j = (arrayOfIConfigurationElement1 = configElements).length, b1 = 0; b1 < j; ) { IConfigurationElement configElement = arrayOfIConfigurationElement1[b1];
/* 190 */           String aliasId = configElement.getAttribute("canImportId");
/* 191 */           if (aliasId != null && aliasId.equals(id)) {
/* 192 */             String extensionId = configElement.getAttribute("id");
/* 193 */             if (extensionId != null)
/* 194 */               return RepositoryProviderType.getProviderType(extensionId); 
/*     */           }  b1++; }
/*     */         
/*     */         b++; }
/*     */     
/*     */     } 
/* 200 */     return null;
/*     */   }
/*     */   
/*     */   public static IPath[] getMetaFilePaths(String id) {
/* 204 */     IExtensionPoint extension = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.team.core", "repository");
/* 205 */     if (extension != null) {
/* 206 */       IExtension[] extensions = extension.getExtensions(); byte b; int i; IExtension[] arrayOfIExtension1;
/* 207 */       for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension ext = arrayOfIExtension1[b];
/* 208 */         IConfigurationElement[] configElements = ext.getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 209 */         for (j = (arrayOfIConfigurationElement1 = configElements).length, b1 = 0; b1 < j; ) { IConfigurationElement configElement = arrayOfIConfigurationElement1[b1];
/* 210 */           String extensionId = configElement.getAttribute("id");
/* 211 */           String metaFilePaths = configElement.getAttribute("metaFilePaths");
/* 212 */           if (extensionId != null && extensionId.equals(id) && metaFilePaths != null)
/* 213 */             return getPaths(metaFilePaths); 
/*     */           b1++; }
/*     */         
/*     */         b++; }
/*     */     
/*     */     } 
/* 219 */     return null;
/*     */   }
/*     */   
/*     */   private static IPath[] getPaths(String metaFilePaths) {
/* 223 */     List<IPath> result = new ArrayList<>();
/* 224 */     StringTokenizer t = new StringTokenizer(metaFilePaths, ",");
/* 225 */     while (t.hasMoreTokens()) {
/* 226 */       String next = t.nextToken();
/* 227 */       Path path = new Path(null, next);
/* 228 */       result.add(path);
/*     */     } 
/* 230 */     return result.<IPath>toArray(new IPath[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMergerDelegate(IStreamMergerDelegate merger) {
/* 240 */     this.mergerDelegate = merger;
/*     */   }
/*     */   
/*     */   public IStreamMergerDelegate getMergerDelegate() {
/* 244 */     return this.mergerDelegate;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\TeamPlugin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */