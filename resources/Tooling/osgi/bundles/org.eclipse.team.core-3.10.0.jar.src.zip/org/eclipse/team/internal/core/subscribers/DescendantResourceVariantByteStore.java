/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.core.variants.ResourceVariantByteStore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DescendantResourceVariantByteStore
/*     */   extends ResourceVariantByteStore
/*     */ {
/*     */   ResourceVariantByteStore baseStore;
/*     */   ResourceVariantByteStore remoteStore;
/*     */   
/*     */   public DescendantResourceVariantByteStore(ResourceVariantByteStore baseCache, ResourceVariantByteStore remoteCache) {
/*  49 */     this.baseStore = baseCache;
/*  50 */     this.remoteStore = remoteCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  59 */     this.remoteStore.dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getBytes(IResource resource) throws TeamException {
/*  64 */     byte[] remoteBytes = this.remoteStore.getBytes(resource);
/*  65 */     byte[] baseBytes = this.baseStore.getBytes(resource);
/*  66 */     if (baseBytes == null)
/*     */     {
/*  68 */       return remoteBytes;
/*     */     }
/*  70 */     if (remoteBytes == null) {
/*  71 */       if (isVariantKnown(resource))
/*     */       {
/*     */         
/*  74 */         return remoteBytes;
/*     */       }
/*     */ 
/*     */       
/*  78 */       return baseBytes;
/*     */     } 
/*     */     
/*  81 */     if (isDescendant(resource, baseBytes, remoteBytes))
/*     */     {
/*  83 */       return remoteBytes;
/*     */     }
/*     */ 
/*     */     
/*  87 */     return baseBytes;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setBytes(IResource resource, byte[] bytes) throws TeamException {
/*  92 */     byte[] baseBytes = this.baseStore.getBytes(resource);
/*  93 */     if (baseBytes != null && equals(baseBytes, bytes))
/*     */     {
/*  95 */       return this.remoteStore.flushBytes(resource, 0);
/*     */     }
/*  97 */     return this.remoteStore.setBytes(resource, bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean flushBytes(IResource resource, int depth) throws TeamException {
/* 103 */     return this.remoteStore.flushBytes(resource, depth);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isVariantKnown(IResource paramIResource) throws TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean isDescendant(IResource paramIResource, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean deleteBytes(IResource resource) throws TeamException {
/* 134 */     return this.remoteStore.deleteBytes(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceVariantByteStore getBaseStore() {
/* 142 */     return this.baseStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceVariantByteStore getRemoteStore() {
/* 151 */     return this.remoteStore;
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource[] members(IResource resource) throws TeamException {
/* 156 */     IResource[] remoteMembers = getRemoteStore().members(resource);
/* 157 */     IResource[] baseMembers = getBaseStore().members(resource);
/* 158 */     Set<IResource> members = new HashSet<>();
/* 159 */     Collections.addAll(members, remoteMembers); byte b; int i; IResource[] arrayOfIResource1;
/* 160 */     for (i = (arrayOfIResource1 = baseMembers).length, b = 0; b < i; ) { IResource member = arrayOfIResource1[b];
/*     */ 
/*     */       
/* 163 */       if (!isVariantKnown(member))
/* 164 */         members.add(member); 
/*     */       b++; }
/*     */     
/* 167 */     return members.<IResource>toArray(new IResource[members.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void run(IResource root, IWorkspaceRunnable runnable, IProgressMonitor monitor) throws TeamException {
/* 172 */     this.remoteStore.run(root, runnable, monitor);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\DescendantResourceVariantByteStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */