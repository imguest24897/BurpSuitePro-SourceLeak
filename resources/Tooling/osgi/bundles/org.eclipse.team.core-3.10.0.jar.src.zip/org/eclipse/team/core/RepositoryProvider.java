/*     */ package org.eclipse.team.core;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.filesystem.URIUtil;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IFileModificationValidator;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IProjectDescription;
/*     */ import org.eclipse.core.resources.IProjectNature;
/*     */ import org.eclipse.core.resources.IProjectNatureDescriptor;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceProxy;
/*     */ import org.eclipse.core.resources.IResourceRuleFactory;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.resources.team.FileModificationValidationContext;
/*     */ import org.eclipse.core.resources.team.FileModificationValidator;
/*     */ import org.eclipse.core.resources.team.IMoveDeleteHook;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.ILock;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.history.IFileHistoryProvider;
/*     */ import org.eclipse.team.core.subscribers.Subscriber;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.PessimisticResourceRuleFactory;
/*     */ import org.eclipse.team.internal.core.RepositoryProviderManager;
/*     */ import org.eclipse.team.internal.core.TeamHookDispatcher;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RepositoryProvider
/*     */   implements IProjectNature, IAdaptable
/*     */ {
/*     */   private static final String TEAM_SETID = "org.eclipse.team.repository-provider";
/*  95 */   private static final List<String> AllProviderTypeIds = initializeAllProviderTypes();
/*     */ 
/*     */   
/*     */   private IProject project;
/*     */ 
/*     */   
/* 101 */   private static final ILock mappingLock = Job.getJobManager().newLock();
/*     */ 
/*     */   
/* 104 */   private static final Object NOT_MAPPED = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void map(IProject project, String id) throws TeamException {
/* 121 */     ISchedulingRule rule = ResourcesPlugin.getWorkspace().getRuleFactory().modifyRule((IResource)project);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 129 */       Job.getJobManager().beginRule(rule, null);
/*     */       try {
/* 131 */         mappingLock.acquire();
/* 132 */         RepositoryProvider existingProvider = null;
/*     */         
/* 134 */         if (project.getPersistentProperty(TeamPlugin.PROVIDER_PROP_KEY) != null) {
/* 135 */           existingProvider = getProvider(project);
/*     */         }
/*     */ 
/*     */         
/* 139 */         if (existingProvider != null) {
/* 140 */           if (existingProvider.getID().equals(id)) {
/*     */             return;
/*     */           }
/* 143 */           unmap(project);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 148 */         RepositoryProvider provider = mapNewProvider(project, id);
/*     */ 
/*     */         
/*     */         try {
/* 152 */           project.setPersistentProperty(TeamPlugin.PROVIDER_PROP_KEY, id);
/* 153 */         } catch (CoreException outer) {
/*     */           
/*     */           try {
/* 156 */             project.setSessionProperty(TeamPlugin.PROVIDER_PROP_KEY, null);
/* 157 */           } catch (CoreException inner) {
/*     */             
/* 159 */             TeamPlugin.log(4, NLS.bind(Messages.RepositoryProvider_couldNotClearAfterError, (Object[])new String[] { project.getName(), id }), (Throwable)inner);
/*     */           } 
/* 161 */           throw outer;
/*     */         } 
/*     */         
/* 164 */         provider.configure();
/*     */ 
/*     */         
/* 167 */         project.touch(null);
/*     */ 
/*     */ 
/*     */         
/* 171 */         TeamHookDispatcher.setProviderRuleFactory(project, provider.getRuleFactory());
/*     */ 
/*     */         
/* 174 */         RepositoryProviderManager.getInstance().providerMapped(provider);
/*     */       } finally {
/* 176 */         mappingLock.release();
/*     */       } 
/* 178 */     } catch (CoreException e) {
/* 179 */       throw TeamPlugin.wrapException(e);
/*     */     } finally {
/* 181 */       Job.getJobManager().endRule(rule);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static RepositoryProvider mapNewProvider(IProject project, String id) throws TeamException {
/* 197 */     RepositoryProvider provider = newProvider(id);
/*     */     
/* 199 */     if (provider == null) {
/* 200 */       throw new TeamException(NLS.bind(Messages.RepositoryProvider_couldNotInstantiateProvider, new String[] { project.getName(), id }));
/*     */     }
/*     */     
/* 203 */     if (!provider.canHandleLinkedResourceURI()) {
/*     */       try {
/* 205 */         project.accept(proxy -> {
/*     */               if (proxy.isLinked() && (!paramRepositoryProvider.canHandleLinkedResources() || proxy.requestFullPath().segmentCount() > 2 || !"file".equals(proxy.requestResource().getLocationURI().getScheme()))) {
/*     */                 throw new TeamException(new Status(4, "org.eclipse.team.core", 378, NLS.bind(Messages.RepositoryProvider_linkedURIsExist, new String[] { paramIProject.getName(), paramString }), null));
/*     */               }
/*     */ 
/*     */ 
/*     */               
/*     */               return true;
/* 213 */             }0);
/* 214 */       } catch (CoreException e) {
/* 215 */         if (e instanceof TeamException) {
/* 216 */           TeamException te = (TeamException)e;
/* 217 */           throw te;
/*     */         } 
/* 219 */         throw new TeamException(e);
/*     */       } 
/*     */     }
/* 222 */     if (!provider.canHandleLinkedResources()) {
/*     */       try {
/* 224 */         IResource[] members = project.members(); byte b; int i; IResource[] arrayOfIResource1;
/* 225 */         for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource resource = arrayOfIResource1[b];
/* 226 */           if (resource.isLinked())
/* 227 */             throw new TeamException(new Status(4, "org.eclipse.team.core", 378, NLS.bind(Messages.RepositoryProvider_linkedResourcesExist, new String[] { project.getName(), id }), null)); 
/*     */           b++; }
/*     */       
/* 230 */       } catch (CoreException e) {
/* 231 */         throw TeamPlugin.wrapException(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 237 */       project.setSessionProperty(TeamPlugin.PROVIDER_PROP_KEY, provider);
/* 238 */       provider.setProject(project);
/* 239 */     } catch (CoreException e) {
/* 240 */       throw TeamPlugin.wrapException(e);
/*     */     } 
/* 242 */     return provider;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static RepositoryProvider mapExistingProvider(IProject project, String id) throws TeamException {
/*     */     try {
/* 249 */       mappingLock.acquire();
/*     */ 
/*     */       
/*     */       try {
/* 253 */         String currentId = project.getPersistentProperty(TeamPlugin.PROVIDER_PROP_KEY);
/* 254 */         if (currentId == null)
/*     */         {
/* 256 */           return null;
/*     */         }
/* 258 */         if (!currentId.equals(id))
/*     */         {
/*     */ 
/*     */           
/* 262 */           return lookupProviderProp(project);
/*     */         }
/* 264 */       } catch (CoreException e) {
/* 265 */         throw TeamPlugin.wrapException(e);
/*     */       } 
/* 267 */       return mapNewProvider(project, id);
/*     */     } finally {
/* 269 */       mappingLock.release();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void unmap(IProject project) throws TeamException {
/* 278 */     ISchedulingRule rule = ResourcesPlugin.getWorkspace().getRuleFactory().modifyRule((IResource)project);
/*     */     
/*     */     try {
/* 281 */       Job.getJobManager().beginRule(rule, null);
/*     */       try {
/* 283 */         mappingLock.acquire();
/* 284 */         String id = project.getPersistentProperty(TeamPlugin.PROVIDER_PROP_KEY);
/*     */ 
/*     */         
/* 287 */         if (id == null) {
/* 288 */           throw new TeamException(NLS.bind(Messages.RepositoryProvider_No_Provider_Registered, new String[] { project.getName() }));
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 293 */         RepositoryProvider provider = getProvider(project);
/* 294 */         if (provider == null)
/*     */         {
/*     */ 
/*     */           
/* 298 */           TeamPlugin.log(4, NLS.bind(Messages.RepositoryProvider_couldNotInstantiateProvider, (Object[])new String[] { project.getName(), id }), null);
/*     */         }
/*     */         
/* 301 */         if (provider != null) provider.deconfigure();
/*     */         
/* 303 */         project.setSessionProperty(TeamPlugin.PROVIDER_PROP_KEY, null);
/* 304 */         project.setPersistentProperty(TeamPlugin.PROVIDER_PROP_KEY, null);
/*     */         
/* 306 */         if (provider != null) provider.deconfigured();
/*     */ 
/*     */         
/* 309 */         project.touch(null);
/*     */ 
/*     */ 
/*     */         
/* 313 */         TeamHookDispatcher.setProviderRuleFactory(project, null);
/*     */ 
/*     */         
/* 316 */         RepositoryProviderManager.getInstance().providerUnmapped(project);
/*     */       } finally {
/* 318 */         mappingLock.release();
/*     */       } 
/* 320 */     } catch (CoreException e) {
/* 321 */       throw TeamPlugin.wrapException(e);
/*     */     } finally {
/* 323 */       Job.getJobManager().endRule(rule);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static RepositoryProvider lookupProviderProp(IProject project) throws CoreException {
/* 331 */     Object provider = project.getSessionProperty(TeamPlugin.PROVIDER_PROP_KEY);
/* 332 */     if (provider instanceof RepositoryProvider) {
/* 333 */       return (RepositoryProvider)provider;
/*     */     }
/* 335 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void configure() throws CoreException {
/*     */     try {
/* 367 */       configureProject();
/* 368 */     } catch (CoreException e) {
/*     */       try {
/* 370 */         unmap(getProject());
/* 371 */       } catch (TeamException e2) {
/* 372 */         throw new CoreException(new Status(4, "org.eclipse.team.core", 0, String.valueOf(Messages.RepositoryProvider_Error_removing_nature_from_project___1) + getID(), e2));
/*     */       } 
/* 374 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void deconfigured() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IFileModificationValidator getFileModificationValidator() {
/* 407 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileModificationValidator getFileModificationValidator2() {
/* 432 */     final IFileModificationValidator fileModificationValidator = getFileModificationValidator();
/* 433 */     if (fileModificationValidator == null)
/* 434 */       return null; 
/* 435 */     return new FileModificationValidator()
/*     */       {
/*     */         public IStatus validateSave(IFile file) {
/* 438 */           return fileModificationValidator.validateSave(file);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public IStatus validateEdit(IFile[] files, FileModificationValidationContext context) {
/*     */           Object shell;
/* 445 */           if (context == null) {
/* 446 */             shell = null;
/*     */           } else {
/* 448 */             shell = context.getShell();
/* 449 */           }  return fileModificationValidator.validateEdit(files, shell);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileHistoryProvider getFileHistoryProvider() {
/* 462 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IMoveDeleteHook getMoveDeleteHook() {
/* 477 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 491 */     return NLS.bind(Messages.RepositoryProvider_toString, (Object[])new String[] { getProject().getName(), getID() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String[] getAllProviderTypeIds() {
/* 500 */     IProjectNatureDescriptor[] desc = ResourcesPlugin.getWorkspace().getNatureDescriptors();
/* 501 */     Set<String> teamSet = new HashSet<>();
/*     */     
/* 503 */     teamSet.addAll(AllProviderTypeIds); byte b; int i;
/*     */     IProjectNatureDescriptor[] arrayOfIProjectNatureDescriptor1;
/* 505 */     for (i = (arrayOfIProjectNatureDescriptor1 = desc).length, b = 0; b < i; ) { IProjectNatureDescriptor d = arrayOfIProjectNatureDescriptor1[b];
/* 506 */       String[] setIds = d.getNatureSetIds(); byte b1; int j; String[] arrayOfString1;
/* 507 */       for (j = (arrayOfString1 = setIds).length, b1 = 0; b1 < j; ) { String setId = arrayOfString1[b1];
/* 508 */         if (setId.equals("org.eclipse.team.repository-provider"))
/* 509 */           teamSet.add(d.getNatureId());  b1++; }
/*     */       
/*     */       b++; }
/*     */     
/* 513 */     return teamSet.<String>toArray(new String[teamSet.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final RepositoryProvider getProvider(IProject project) {
/*     */     try {
/* 526 */       if (project.isAccessible()) {
/*     */ 
/*     */ 
/*     */         
/* 530 */         RepositoryProvider provider = lookupProviderProp(project);
/* 531 */         if (provider != null) {
/* 532 */           return provider;
/*     */         }
/*     */         
/* 535 */         if (isMarkedAsUnshared(project)) {
/* 536 */           return null;
/*     */         }
/*     */ 
/*     */         
/* 540 */         String id = project.getPersistentProperty(TeamPlugin.PROVIDER_PROP_KEY);
/* 541 */         if (id != null) {
/* 542 */           return mapExistingProvider(project, id);
/*     */         }
/*     */ 
/*     */         
/* 546 */         IProjectDescription projectDesc = project.getDescription();
/* 547 */         String[] natureIds = projectDesc.getNatureIds();
/* 548 */         IWorkspace workspace = ResourcesPlugin.getWorkspace(); byte b;
/*     */         int i;
/*     */         String[] arrayOfString1;
/* 551 */         for (i = (arrayOfString1 = natureIds).length, b = 0; b < i; ) { String natureId = arrayOfString1[b];
/* 552 */           IProjectNatureDescriptor desc = workspace.getNatureDescriptor(natureId);
/*     */           
/* 554 */           if (desc != null) {
/* 555 */             String[] setIds = desc.getNatureSetIds(); byte b1; int j; String[] arrayOfString2;
/* 556 */             for (j = (arrayOfString2 = setIds).length, b1 = 0; b1 < j; ) { String setId = arrayOfString2[b1];
/* 557 */               if (setId.equals("org.eclipse.team.repository-provider"))
/* 558 */                 return getProvider(project, natureId);  b1++; }
/*     */           
/*     */           } 
/*     */           b++; }
/*     */         
/* 563 */         markAsUnshared(project);
/*     */       } 
/* 565 */     } catch (CoreException e) {
/* 566 */       if (!isAcceptableException(e)) {
/* 567 */         TeamPlugin.log(e);
/*     */       }
/* 569 */       markAsUnshared(project);
/*     */     } 
/* 571 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isAcceptableException(CoreException e) {
/* 580 */     return (e.getStatus().getCode() == 368);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final RepositoryProvider getProvider(IProject project, String id) {
/*     */     try {
/* 594 */       if (project.isAccessible()) {
/*     */         
/* 596 */         RepositoryProvider provider = lookupProviderProp(project);
/* 597 */         if (provider != null) {
/* 598 */           if (provider.getID().equals(id)) {
/* 599 */             return provider;
/*     */           }
/* 601 */           return null;
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 606 */         if (isMarkedAsUnshared(project)) {
/* 607 */           return null;
/*     */         }
/*     */         
/* 610 */         String existingID = project.getPersistentProperty(TeamPlugin.PROVIDER_PROP_KEY);
/* 611 */         if (id.equals(existingID)) {
/*     */           
/* 613 */           RepositoryProvider newProvider = mapExistingProvider(project, id);
/* 614 */           if (newProvider != null && newProvider.getID().equals(id)) {
/* 615 */             return newProvider;
/*     */           }
/*     */           
/* 618 */           return null;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 627 */         IProjectNatureDescriptor desc = ResourcesPlugin.getWorkspace().getNatureDescriptor(id);
/* 628 */         if (desc == null) {
/* 629 */           return null;
/*     */         }
/* 631 */         String[] setIds = desc.getNatureSetIds(); byte b; int i; String[] arrayOfString1;
/* 632 */         for (i = (arrayOfString1 = setIds).length, b = 0; b < i; ) { String setId = arrayOfString1[b];
/* 633 */           if (setId.equals("org.eclipse.team.repository-provider"))
/* 634 */             return (RepositoryProvider)project.getNature(id); 
/*     */           b++; }
/*     */         
/* 637 */         markAsUnshared(project);
/*     */       } 
/* 639 */     } catch (CoreException e) {
/* 640 */       if (!isAcceptableException(e)) {
/* 641 */         TeamPlugin.log(e);
/*     */       }
/* 643 */       markAsUnshared(project);
/*     */     } 
/* 645 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isShared(IProject project) {
/* 664 */     if (!project.isAccessible()) return false; 
/*     */     try {
/* 666 */       if (lookupProviderProp(project) != null) return true;
/*     */ 
/*     */       
/* 669 */       if (isMarkedAsUnshared(project))
/* 670 */         return false; 
/* 671 */       boolean shared = (project.getPersistentProperty(TeamPlugin.PROVIDER_PROP_KEY) != null);
/* 672 */       if (!shared)
/* 673 */         markAsUnshared(project); 
/* 674 */       return shared;
/* 675 */     } catch (CoreException e) {
/* 676 */       TeamPlugin.log(e);
/* 677 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isMarkedAsUnshared(IProject project) {
/*     */     try {
/* 683 */       return (project.getSessionProperty(TeamPlugin.PROVIDER_PROP_KEY) == NOT_MAPPED);
/* 684 */     } catch (CoreException coreException) {
/* 685 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void markAsUnshared(IProject project) {
/*     */     try {
/* 691 */       project.setSessionProperty(TeamPlugin.PROVIDER_PROP_KEY, NOT_MAPPED);
/* 692 */     } catch (CoreException coreException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IProject getProject() {
/* 699 */     return this.project;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProject(IProject project) {
/* 704 */     this.project = project;
/*     */   }
/*     */   
/*     */   private static List<String> initializeAllProviderTypes() {
/* 708 */     List<String> allIDs = new ArrayList<>();
/*     */     
/* 710 */     TeamPlugin plugin = TeamPlugin.getPlugin();
/* 711 */     if (plugin != null) {
/* 712 */       IExtensionPoint extension = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.team.core", "repository");
/* 713 */       if (extension != null) {
/* 714 */         IExtension[] extensions = extension.getExtensions(); byte b; int i; IExtension[] arrayOfIExtension1;
/* 715 */         for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension e = arrayOfIExtension1[b];
/* 716 */           IConfigurationElement[] configElements = e.getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 717 */           for (j = (arrayOfIConfigurationElement1 = configElements).length, b1 = 0; b1 < j; ) { IConfigurationElement configElement = arrayOfIConfigurationElement1[b1];
/* 718 */             String extensionId = configElement.getAttribute("id");
/* 719 */             allIDs.add(extensionId); b1++; }
/*     */            b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 724 */     return allIDs;
/*     */   }
/*     */   
/*     */   private static RepositoryProvider newProvider(String id) {
/* 728 */     TeamPlugin plugin = TeamPlugin.getPlugin();
/* 729 */     if (plugin != null) {
/* 730 */       IExtensionPoint extension = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.team.core", "repository");
/* 731 */       if (extension != null) {
/* 732 */         IExtension[] extensions = extension.getExtensions(); byte b; int i; IExtension[] arrayOfIExtension1;
/* 733 */         for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension ext = arrayOfIExtension1[b];
/* 734 */           IConfigurationElement[] configElements = ext.getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 735 */           for (j = (arrayOfIConfigurationElement1 = configElements).length, b1 = 0; b1 < j; ) { IConfigurationElement configElement = arrayOfIConfigurationElement1[b1];
/* 736 */             String extensionId = configElement.getAttribute("id");
/* 737 */             if (extensionId != null && extensionId.equals(id)) {
/*     */               try {
/* 739 */                 return (RepositoryProvider)configElement.createExecutableExtension("class");
/* 740 */               } catch (CoreException e) {
/* 741 */                 TeamPlugin.log(e);
/* 742 */               } catch (ClassCastException e) {
/* 743 */                 String className = configElement.getAttribute("class");
/* 744 */                 TeamPlugin.log(4, NLS.bind(Messages.RepositoryProvider_invalidClass, (Object[])new String[] { id, className }), e);
/*     */               } 
/* 746 */               return null;
/*     */             }  b1++; }
/*     */            b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 752 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IStatus validateCreateLink(IResource resource, int updateFlags, IPath location) {
/* 775 */     if (canHandleLinkedResources()) {
/* 776 */       return (IStatus)Team.OK_STATUS;
/*     */     }
/* 778 */     return (IStatus)new Status(4, "org.eclipse.team.core", 378, NLS.bind(Messages.RepositoryProvider_linkedResourcesNotSupported, (Object[])new String[] { getProject().getName(), getID() }), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateCreateLink(IResource resource, int updateFlags, URI location) {
/* 800 */     if (resource.getProjectRelativePath().segmentCount() == 1 && "file".equals(location.getScheme()))
/*     */     {
/*     */       
/* 803 */       return validateCreateLink(resource, updateFlags, URIUtil.toPath(location));
/*     */     }
/* 805 */     if (canHandleLinkedResourceURI()) {
/* 806 */       return (IStatus)Team.OK_STATUS;
/*     */     }
/* 808 */     return (IStatus)new Status(4, "org.eclipse.team.core", 378, NLS.bind(Messages.RepositoryProvider_linkedURIsNotSupported, (Object[])new String[] { getProject().getName(), getID() }), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean canHandleLinkedResources() {
/* 830 */     return canHandleLinkedResourceURI();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canHandleLinkedResourceURI() {
/* 854 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T getAdapter(Class<T> adapter) {
/* 859 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResourceRuleFactory getRuleFactory() {
/* 881 */     return (IResourceRuleFactory)new PessimisticResourceRuleFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Subscriber getSubscriber() {
/* 894 */     RepositoryProviderType type = RepositoryProviderType.getProviderType(getID());
/* 895 */     if (type != null)
/* 896 */       return type.getSubscriber(); 
/* 897 */     return null;
/*     */   }
/*     */   
/*     */   public abstract void configureProject() throws CoreException;
/*     */   
/*     */   public abstract String getID();
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\RepositoryProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */