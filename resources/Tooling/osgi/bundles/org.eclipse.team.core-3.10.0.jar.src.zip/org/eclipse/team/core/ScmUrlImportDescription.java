/*     */ package org.eclipse.team.core;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScmUrlImportDescription
/*     */ {
/*     */   private String url;
/*     */   private String project;
/*     */   private HashMap<String, Object> properties;
/*     */   
/*     */   public ScmUrlImportDescription(String url, String project) {
/*  41 */     this.url = url;
/*  42 */     this.project = project;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProject() {
/*  49 */     return this.project;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUrl() {
/*  58 */     return this.url;
/*     */   }
/*     */   
/*     */   public URI getUri() {
/*  62 */     return URI.create(this.url.replaceAll("\"", ""));
/*     */   }
/*     */   
/*     */   public void setUrl(String url) {
/*  66 */     this.url = url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setProperty(String key, Object value) {
/*  78 */     if (this.properties == null) {
/*  79 */       this.properties = new HashMap<>();
/*     */     }
/*  81 */     if (value == null) {
/*  82 */       this.properties.remove(key);
/*     */     } else {
/*  84 */       this.properties.put(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object getProperty(String key) {
/*  97 */     if (this.properties == null) {
/*  98 */       return null;
/*     */     }
/* 100 */     return this.properties.get(key);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\ScmUrlImportDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */