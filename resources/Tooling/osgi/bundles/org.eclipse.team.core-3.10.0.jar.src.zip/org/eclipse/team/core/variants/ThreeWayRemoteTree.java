/*     */ package org.eclipse.team.core.variants;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ThreeWayRemoteTree
/*     */   extends ResourceVariantTree
/*     */ {
/*     */   private ThreeWaySubscriber subscriber;
/*     */   
/*     */   static class RemoteResourceVariantByteStore
/*     */     extends ResourceVariantByteStore
/*     */   {
/*     */     private ThreeWaySynchronizer synchronizer;
/*     */     
/*     */     public RemoteResourceVariantByteStore(ThreeWaySynchronizer synchronizer) {
/*  41 */       this.synchronizer = synchronizer;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {}
/*     */ 
/*     */     
/*     */     public byte[] getBytes(IResource resource) throws TeamException {
/*  49 */       return getSynchronizer().getRemoteBytes(resource);
/*     */     }
/*     */     
/*     */     public boolean setBytes(IResource resource, byte[] bytes) throws TeamException {
/*  53 */       return getSynchronizer().setRemoteBytes(resource, bytes);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean flushBytes(IResource resource, int depth) throws TeamException {
/*  59 */       return false;
/*     */     }
/*     */     public boolean isVariantKnown(IResource resource) throws TeamException {
/*  62 */       return getSynchronizer().hasSyncBytes(resource);
/*     */     }
/*     */     
/*     */     public boolean deleteBytes(IResource resource) throws TeamException {
/*  66 */       return getSynchronizer().removeRemoteBytes(resource);
/*     */     }
/*     */     
/*     */     public IResource[] members(IResource resource) throws TeamException {
/*  70 */       return this.synchronizer.members(resource);
/*     */     }
/*     */     private ThreeWaySynchronizer getSynchronizer() {
/*  73 */       return this.synchronizer;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ThreeWayRemoteTree(ThreeWaySubscriber subscriber) {
/*  84 */     super(new RemoteResourceVariantByteStore(subscriber.getSynchronizer()));
/*  85 */     this.subscriber = subscriber;
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource[] roots() {
/*  90 */     return getSubscriber().roots();
/*     */   }
/*     */ 
/*     */   
/*     */   public IResourceVariant getResourceVariant(IResource resource) throws TeamException {
/*  95 */     return getSubscriber().getResourceVariant(resource, getByteStore().getBytes(resource));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ThreeWaySubscriber getSubscriber() {
/* 103 */     return this.subscriber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IResource[] collectChanges(IResource local, IResourceVariant remote, int depth, IProgressMonitor monitor) throws TeamException {
/* 110 */     IResource[][] resources = new IResource[1][];
/* 111 */     getSubscriber().getSynchronizer().run(local, monitor1 -> paramArrayOfIResource[0] = collectChanges(paramIResource, paramIResourceVariant, paramInt, monitor1), 
/*     */         
/* 113 */         monitor);
/* 114 */     return resources[0];
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\variants\ThreeWayRemoteTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */