/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.team.core.ITeamStatus;
/*     */ import org.eclipse.team.core.synchronize.ISyncInfoSetChangeEvent;
/*     */ import org.eclipse.team.core.synchronize.ISyncInfoSetChangeListener;
/*     */ import org.eclipse.team.core.synchronize.SyncInfo;
/*     */ import org.eclipse.team.core.synchronize.SyncInfoSet;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncSetInputFromSyncSet
/*     */   extends SyncSetInput
/*     */   implements ISyncInfoSetChangeListener
/*     */ {
/*     */   SubscriberSyncInfoSet inputSyncSet;
/*     */   
/*     */   public SyncSetInputFromSyncSet(SubscriberSyncInfoSet set, SubscriberEventHandler handler) {
/*  33 */     super(handler);
/*  34 */     this.inputSyncSet = set;
/*  35 */     this.inputSyncSet.addSyncSetChangedListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void disconnect() {
/*  40 */     if (this.inputSyncSet == null)
/*  41 */       return;  this.inputSyncSet.removeSyncSetChangedListener(this);
/*  42 */     this.inputSyncSet = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void fetchInput(IProgressMonitor monitor) {
/*  47 */     if (this.inputSyncSet == null)
/*  48 */       return;  SyncInfo[] infos = this.inputSyncSet.getSyncInfos(); byte b; int i; SyncInfo[] arrayOfSyncInfo1;
/*  49 */     for (i = (arrayOfSyncInfo1 = infos).length, b = 0; b < i; ) { SyncInfo info = arrayOfSyncInfo1[b];
/*  50 */       collect(info, monitor);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public void syncInfoChanged(ISyncInfoSetChangeEvent event, IProgressMonitor monitor) {
/*  56 */     SubscriberSyncInfoSet subscriberSyncInfoSet = getSyncSet();
/*     */     try {
/*  58 */       subscriberSyncInfoSet.beginInput();
/*  59 */       monitor.beginTask(null, 105);
/*  60 */       syncSetChanged(event.getChangedResources(), Policy.subMonitorFor(monitor, 50));
/*  61 */       syncSetChanged(event.getAddedResources(), Policy.subMonitorFor(monitor, 50));
/*  62 */       remove(event.getRemovedResources());
/*     */     } finally {
/*  64 */       subscriberSyncInfoSet.endInput(Policy.subMonitorFor(monitor, 5));
/*     */     } 
/*     */   } private void syncSetChanged(SyncInfo[] infos, IProgressMonitor monitor) { byte b;
/*     */     int i;
/*     */     SyncInfo[] arrayOfSyncInfo;
/*  69 */     for (i = (arrayOfSyncInfo = infos).length, b = 0; b < i; ) { SyncInfo info = arrayOfSyncInfo[b];
/*  70 */       collect(info, monitor);
/*     */       b++; }
/*     */      } private void remove(IResource[] resources) { byte b;
/*     */     int i;
/*     */     IResource[] arrayOfIResource;
/*  75 */     for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/*  76 */       remove(resource);
/*     */       b++; }
/*     */      }
/*     */   
/*     */   public void reset() {
/*  81 */     this.inputSyncSet.connect(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void syncInfoSetReset(SyncInfoSet set, IProgressMonitor monitor) {
/*  86 */     if (this.inputSyncSet == null) {
/*  87 */       set.removeSyncSetChangedListener(this);
/*     */     } else {
/*  89 */       SubscriberSyncInfoSet subscriberSyncInfoSet = getSyncSet();
/*     */       try {
/*  91 */         subscriberSyncInfoSet.beginInput();
/*  92 */         monitor.beginTask(null, 100);
/*  93 */         subscriberSyncInfoSet.clear();
/*  94 */         fetchInput(Policy.subMonitorFor(monitor, 95));
/*     */       } finally {
/*  96 */         subscriberSyncInfoSet.endInput(Policy.subMonitorFor(monitor, 5));
/*  97 */         monitor.done();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void syncInfoSetErrors(SyncInfoSet set, ITeamStatus[] errors, IProgressMonitor monitor) {
/* 104 */     SubscriberSyncInfoSet syncSet = getSyncSet();
/*     */     try {
/* 106 */       syncSet.beginInput(); byte b; int i; ITeamStatus[] arrayOfITeamStatus;
/* 107 */       for (i = (arrayOfITeamStatus = errors).length, b = 0; b < i; ) { ITeamStatus status = arrayOfITeamStatus[b];
/* 108 */         syncSet.addError(status); b++; }
/*     */     
/*     */     } finally {
/* 111 */       syncSet.endInput(monitor);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SyncSetInputFromSyncSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */