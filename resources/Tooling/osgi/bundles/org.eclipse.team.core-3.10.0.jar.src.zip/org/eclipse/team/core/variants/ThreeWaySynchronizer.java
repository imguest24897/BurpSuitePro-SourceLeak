/*     */ package org.eclipse.team.core.variants;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.core.runtime.jobs.ILock;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ import org.eclipse.team.internal.core.subscribers.BatchingLock;
/*     */ import org.eclipse.team.internal.core.subscribers.SyncByteConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThreeWaySynchronizer
/*     */ {
/*     */   private BatchingLock.IFlushOperation flushOperation;
/*  66 */   private static final byte[] IGNORED_BYTES = "i".getBytes();
/*     */ 
/*     */   
/*     */   private ILock lock;
/*     */ 
/*     */   
/*     */   private BatchingLock batchingLock;
/*     */   
/*     */   private ResourceVariantByteStore cache;
/*     */   
/*     */   private Set<ISynchronizerChangeListener> listeners;
/*     */ 
/*     */   
/*     */   public ThreeWaySynchronizer(QualifiedName name) {
/*  80 */     this(new PersistantResourceVariantByteStore(name));
/*     */   } public ThreeWaySynchronizer(ResourceVariantByteStore store) {
/*     */     this.flushOperation = ((info, monitor) -> {
/*     */         if (info != null && !info.isEmpty())
/*     */           broadcastSyncChanges(info.getChangedResources()); 
/*     */       });
/*     */     this.lock = Job.getJobManager().newLock();
/*     */     this.batchingLock = new BatchingLock();
/*     */     this.listeners = new HashSet<>();
/*  89 */     this.cache = store;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addListener(ISynchronizerChangeListener listener) {
/* 106 */     synchronized (this.listeners) {
/* 107 */       this.listeners.add(listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeListener(ISynchronizerChangeListener listener) {
/* 118 */     synchronized (this.listeners) {
/* 119 */       this.listeners.remove(listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBaseBytes(IResource resource) throws TeamException {
/*     */     try {
/* 135 */       beginOperation();
/* 136 */       byte[] syncBytes = internalGetSyncBytes(resource);
/* 137 */       if (syncBytes == null) return null; 
/* 138 */       byte[] baseBytes = getSlot(syncBytes, 1);
/* 139 */       if (baseBytes == null || baseBytes.length == 0) return null; 
/* 140 */       return baseBytes;
/*     */     } finally {
/* 142 */       endOperation();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBaseBytes(IResource resource, byte[] baseBytes) throws TeamException {
/* 160 */     Assert.isNotNull(baseBytes);
/* 161 */     ISchedulingRule rule = null;
/*     */     try {
/* 163 */       rule = beginBatching((ISchedulingRule)resource, null);
/*     */       try {
/* 165 */         beginOperation();
/* 166 */         String base = new String(baseBytes);
/* 167 */         String[] slots = {
/* 168 */             Long.valueOf(resource.getModificationStamp()).toString(), 
/* 169 */             base, 
/* 170 */             base
/*     */           };
/* 172 */         byte[] syncBytes = toBytes(slots);
/* 173 */         internalSetSyncBytes(resource, syncBytes);
/* 174 */         this.batchingLock.resourceChanged(resource);
/*     */       } finally {
/* 176 */         endOperation();
/*     */       } 
/*     */     } finally {
/* 179 */       if (rule != null) endBatching(rule, null);
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocallyModified(IResource resource) throws TeamException {
/* 194 */     return !((internalGetSyncBytes(resource) != null || isIgnored(resource)) && 
/* 195 */       getLocalTimestamp(resource) == resource.getModificationStamp() && (
/* 196 */       getBaseBytes(resource) == null || resource.exists()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getRemoteBytes(IResource resource) throws TeamException {
/*     */     try {
/* 211 */       beginOperation();
/* 212 */       byte[] syncBytes = internalGetSyncBytes(resource);
/* 213 */       if (syncBytes == null) return null; 
/* 214 */       byte[] remoteBytes = getSlot(syncBytes, 2);
/* 215 */       if (remoteBytes == null || remoteBytes.length == 0) return null; 
/* 216 */       return remoteBytes;
/*     */     } finally {
/* 218 */       endOperation();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setRemoteBytes(IResource resource, byte[] remoteBytes) throws TeamException {
/* 236 */     Assert.isNotNull(remoteBytes);
/* 237 */     ISchedulingRule rule = null;
/*     */     try {
/* 239 */       rule = beginBatching((ISchedulingRule)resource, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 262 */       if (rule != null) endBatching(rule, null);
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeRemoteBytes(IResource resource) throws TeamException {
/* 274 */     ISchedulingRule rule = null;
/*     */     try {
/* 276 */       rule = beginBatching((ISchedulingRule)resource, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 293 */       if (rule != null) endBatching(rule, null);
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasSyncBytes(IResource resource) throws TeamException {
/* 304 */     return (internalGetSyncBytes(resource) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIgnored(IResource resource) throws TeamException {
/* 315 */     byte[] bytes = this.cache.getBytes(resource);
/* 316 */     return (bytes != null && equals(bytes, IGNORED_BYTES));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnored(IResource resource) throws TeamException {
/* 328 */     internalSetSyncBytes(resource, IGNORED_BYTES);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource[] members(IResource resource) throws TeamException {
/* 340 */     if (resource.getType() == 1) {
/* 341 */       return new IResource[0];
/*     */     }
/*     */     try {
/* 344 */       Set<IResource> potentialChildren = new HashSet<>();
/* 345 */       IContainer container = (IContainer)resource;
/* 346 */       if (container.exists()) {
/* 347 */         potentialChildren.addAll(Arrays.asList(container.members()));
/*     */       }
/* 349 */       potentialChildren.addAll(Arrays.asList(this.cache.members(resource)));
/* 350 */       List<IResource> result = new ArrayList<>();
/* 351 */       for (IResource child : potentialChildren) {
/* 352 */         if (child.exists() || hasSyncBytes(child)) {
/* 353 */           result.add(child);
/*     */         }
/*     */       } 
/* 356 */       return result.<IResource>toArray(new IResource[result.size()]);
/* 357 */     } catch (CoreException e) {
/* 358 */       throw TeamException.asTeamException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush(IResource resource, int depth) throws TeamException {
/* 370 */     ISchedulingRule rule = null;
/*     */     try {
/* 372 */       rule = beginBatching((ISchedulingRule)resource, null);
/*     */       try {
/* 374 */         beginOperation();
/* 375 */         if (this.cache.flushBytes(resource, depth)) {
/* 376 */           this.batchingLock.resourceChanged(resource);
/*     */         }
/*     */       } finally {
/* 379 */         endOperation();
/*     */       } 
/*     */     } finally {
/* 382 */       if (rule != null) endBatching(rule, null);
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(IResource resourceRule, IWorkspaceRunnable runnable, IProgressMonitor monitor) throws TeamException {
/* 395 */     monitor = Policy.monitorFor(monitor);
/* 396 */     monitor.beginTask(null, 100);
/* 397 */     ISchedulingRule rule = beginBatching((ISchedulingRule)resourceRule, Policy.subMonitorFor(monitor, 10));
/*     */     try {
/* 399 */       this.cache.run(resourceRule, runnable, Policy.subMonitorFor(monitor, 80));
/* 400 */     } catch (CoreException e) {
/* 401 */       throw TeamException.asTeamException(e);
/*     */     } finally {
/* 403 */       if (rule != null) endBatching(rule, Policy.subMonitorFor(monitor, 10)); 
/* 404 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void broadcastSyncChanges(final IResource[] resources) {
/*     */     ISynchronizerChangeListener[] allListeners;
/* 411 */     synchronized (this.listeners) {
/* 412 */       allListeners = this.listeners.<ISynchronizerChangeListener>toArray(new ISynchronizerChangeListener[this.listeners.size()]);
/*     */     }  byte b; int i;
/*     */     ISynchronizerChangeListener[] arrayOfISynchronizerChangeListener1;
/* 415 */     for (i = (arrayOfISynchronizerChangeListener1 = allListeners).length, b = 0; b < i; ) { final ISynchronizerChangeListener listener = arrayOfISynchronizerChangeListener1[b];
/* 416 */       SafeRunner.run(new ISafeRunnable()
/*     */           {
/*     */             public void handleException(Throwable exception) {}
/*     */ 
/*     */ 
/*     */             
/*     */             public void run() throws Exception {
/* 423 */               listener.syncStateChanged(resources);
/*     */             }
/*     */           });
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] internalGetSyncBytes(IResource resource) throws TeamException {
/* 436 */     byte[] bytes = this.cache.getBytes(resource);
/* 437 */     if (bytes != null && equals(bytes, IGNORED_BYTES)) return null; 
/* 438 */     return bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean internalSetSyncBytes(IResource resource, byte[] syncBytes) throws TeamException {
/* 445 */     return this.cache.setBytes(resource, syncBytes);
/*     */   }
/*     */   
/*     */   private byte[] getSlot(byte[] syncBytes, int i) {
/* 449 */     return SyncByteConverter.getSlot(syncBytes, i, false);
/*     */   }
/*     */   
/*     */   private byte[] setSlot(byte[] syncBytes, int i, byte[] insertBytes) throws TeamException {
/* 453 */     return SyncByteConverter.setSlot(syncBytes, i, insertBytes);
/*     */   }
/*     */   
/*     */   private byte[] toBytes(String[] slots) {
/* 457 */     return SyncByteConverter.toBytes(slots);
/*     */   }
/*     */   
/*     */   private long getLocalTimestamp(IResource resource) throws TeamException {
/*     */     try {
/* 462 */       beginOperation();
/* 463 */       byte[] syncBytes = internalGetSyncBytes(resource);
/* 464 */       if (syncBytes == null) return -1L; 
/* 465 */       byte[] bytes = getSlot(syncBytes, 0);
/* 466 */       if (bytes == null || bytes.length == 0) return -1L; 
/* 467 */       return Long.parseLong(new String(bytes));
/*     */     } finally {
/* 469 */       endOperation();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean equals(byte[] syncBytes, byte[] oldBytes) {
/* 474 */     if (syncBytes.length != oldBytes.length) return false; 
/* 475 */     for (int i = 0; i < oldBytes.length; i++) {
/* 476 */       if (oldBytes[i] != syncBytes[i]) return false; 
/*     */     } 
/* 478 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void beginOperation() {
/* 490 */     if (ResourcesPlugin.getWorkspace().isTreeLocked())
/* 491 */       return;  this.lock.acquire();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void endOperation() {
/* 499 */     if (ResourcesPlugin.getWorkspace().isTreeLocked())
/* 500 */       return;  this.lock.release();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ISchedulingRule beginBatching(ISchedulingRule resourceRule, IProgressMonitor monitor) {
/* 510 */     return this.batchingLock.acquire(resourceRule, this.flushOperation, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void endBatching(ISchedulingRule rule, IProgressMonitor monitor) throws TeamException {
/* 518 */     this.batchingLock.release(rule, monitor);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\variants\ThreeWaySynchronizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */