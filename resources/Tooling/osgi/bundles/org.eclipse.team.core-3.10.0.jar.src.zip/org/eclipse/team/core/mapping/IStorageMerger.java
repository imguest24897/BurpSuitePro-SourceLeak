package org.eclipse.team.core.mapping;

import java.io.OutputStream;
import org.eclipse.core.resources.IStorage;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;

public interface IStorageMerger {
  public static final int OK = 0;
  
  public static final int CONFLICT = 1;
  
  public static final int INTERNAL_ERROR = 2;
  
  public static final int UNSUPPORTED_ENCODING = 3;
  
  IStatus merge(OutputStream paramOutputStream, String paramString, IStorage paramIStorage1, IStorage paramIStorage2, IStorage paramIStorage3, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  boolean canMergeWithoutAncestor();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\IStorageMerger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */