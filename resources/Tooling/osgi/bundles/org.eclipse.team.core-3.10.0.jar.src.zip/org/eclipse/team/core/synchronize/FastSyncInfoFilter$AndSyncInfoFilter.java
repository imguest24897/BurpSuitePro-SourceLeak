/*    */ package org.eclipse.team.core.synchronize;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AndSyncInfoFilter
/*    */   extends FastSyncInfoFilter.CompoundSyncInfoFilter
/*    */ {
/*    */   public AndSyncInfoFilter(FastSyncInfoFilter[] filters) {
/* 72 */     super(filters); } public boolean select(SyncInfo info) {
/*    */     byte b;
/*    */     int i;
/*    */     FastSyncInfoFilter[] arrayOfFastSyncInfoFilter;
/* 76 */     for (i = (arrayOfFastSyncInfoFilter = this.filters).length, b = 0; b < i; ) { FastSyncInfoFilter filter = arrayOfFastSyncInfoFilter[b];
/* 77 */       if (!filter.select(info))
/* 78 */         return false; 
/*    */       b++; }
/*    */     
/* 81 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\synchronize\FastSyncInfoFilter$AndSyncInfoFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */