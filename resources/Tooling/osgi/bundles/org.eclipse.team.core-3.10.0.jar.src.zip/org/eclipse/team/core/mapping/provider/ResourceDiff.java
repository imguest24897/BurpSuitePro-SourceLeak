/*    */ package org.eclipse.team.core.mapping.provider;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ import org.eclipse.team.core.diff.provider.TwoWayDiff;
/*    */ import org.eclipse.team.core.history.IFileRevision;
/*    */ import org.eclipse.team.core.mapping.IResourceDiff;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceDiff
/*    */   extends TwoWayDiff
/*    */   implements IResourceDiff
/*    */ {
/*    */   private final IFileRevision before;
/*    */   private final IFileRevision after;
/*    */   private final IResource resource;
/*    */   
/*    */   public ResourceDiff(IResource resource, int kind, int flags, IFileRevision before, IFileRevision after) {
/* 44 */     super(resource.getFullPath(), kind, flags);
/* 45 */     this.resource = resource;
/* 46 */     this.before = before;
/* 47 */     this.after = after;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ResourceDiff(IResource resource, int kind) {
/* 59 */     this(resource, kind, 0, null, null);
/* 60 */     Assert.isTrue((resource.getType() != 1));
/*    */   }
/*    */ 
/*    */   
/*    */   public IFileRevision getBeforeState() {
/* 65 */     return this.before;
/*    */   }
/*    */ 
/*    */   
/*    */   public IFileRevision getAfterState() {
/* 70 */     return this.after;
/*    */   }
/*    */ 
/*    */   
/*    */   public IResource getResource() {
/* 75 */     return this.resource;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 80 */     if (obj == this)
/* 81 */       return true; 
/* 82 */     if (super.equals(obj) && 
/* 83 */       obj instanceof ResourceDiff) {
/* 84 */       ResourceDiff other = (ResourceDiff)obj;
/* 85 */       return (getResource().equals(getResource()) && 
/* 86 */         revisionsEqual(getBeforeState(), other.getBeforeState()) && 
/* 87 */         revisionsEqual(getAfterState(), other.getAfterState()));
/*    */     } 
/*    */     
/* 90 */     return false;
/*    */   }
/*    */   
/*    */   private boolean revisionsEqual(IFileRevision revision, IFileRevision revision2) {
/* 94 */     if (revision == null)
/* 95 */       return (revision2 == null); 
/* 96 */     if (revision2 == null)
/* 97 */       return false; 
/* 98 */     return revision.equals(revision2);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\provider\ResourceDiff.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */