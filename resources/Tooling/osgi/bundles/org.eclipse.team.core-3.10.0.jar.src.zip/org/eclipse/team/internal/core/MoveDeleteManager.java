/*     */ package org.eclipse.team.internal.core;
/*     */ 
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IFolder;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IProjectDescription;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.team.IMoveDeleteHook;
/*     */ import org.eclipse.core.resources.team.IResourceTree;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.team.core.RepositoryProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MoveDeleteManager
/*     */   implements IMoveDeleteHook
/*     */ {
/*  29 */   private static final IMoveDeleteHook DEFAULT_HOOK = new DefaultMoveDeleteHook();
/*     */   
/*     */   private IMoveDeleteHook getHookFor(IResource resource) {
/*  32 */     IProject project = resource.getProject();
/*  33 */     RepositoryProvider provider = RepositoryProvider.getProvider(project);
/*  34 */     if (provider == null) {
/*  35 */       return DEFAULT_HOOK;
/*     */     }
/*  37 */     IMoveDeleteHook hook = provider.getMoveDeleteHook();
/*  38 */     if (hook == null) {
/*  39 */       return DEFAULT_HOOK;
/*     */     }
/*  41 */     return hook;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean deleteFile(IResourceTree tree, IFile file, int updateFlags, IProgressMonitor monitor) {
/*  51 */     return getHookFor((IResource)file).deleteFile(tree, file, updateFlags, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean deleteFolder(IResourceTree tree, IFolder folder, int updateFlags, IProgressMonitor monitor) {
/*  61 */     return getHookFor((IResource)folder).deleteFolder(tree, folder, updateFlags, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean deleteProject(IResourceTree tree, IProject project, int updateFlags, IProgressMonitor monitor) {
/*  71 */     return getHookFor((IResource)project).deleteProject(tree, project, updateFlags, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean moveFile(IResourceTree tree, IFile source, IFile destination, int updateFlags, IProgressMonitor monitor) {
/*  82 */     return getHookFor((IResource)source).moveFile(tree, source, destination, updateFlags, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean moveFolder(IResourceTree tree, IFolder source, IFolder destination, int updateFlags, IProgressMonitor monitor) {
/*  93 */     return getHookFor((IResource)source).moveFolder(tree, source, destination, updateFlags, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean moveProject(IResourceTree tree, IProject source, IProjectDescription description, int updateFlags, IProgressMonitor monitor) {
/* 104 */     return getHookFor((IResource)source).moveProject(tree, source, description, updateFlags, monitor);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\MoveDeleteManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */