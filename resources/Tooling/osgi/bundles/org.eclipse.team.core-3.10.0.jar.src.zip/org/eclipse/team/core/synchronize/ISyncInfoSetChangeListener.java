package org.eclipse.team.core.synchronize;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.team.core.ITeamStatus;

public interface ISyncInfoSetChangeListener {
  void syncInfoSetReset(SyncInfoSet paramSyncInfoSet, IProgressMonitor paramIProgressMonitor);
  
  void syncInfoChanged(ISyncInfoSetChangeEvent paramISyncInfoSetChangeEvent, IProgressMonitor paramIProgressMonitor);
  
  void syncInfoSetErrors(SyncInfoSet paramSyncInfoSet, ITeamStatus[] paramArrayOfITeamStatus, IProgressMonitor paramIProgressMonitor);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\synchronize\ISyncInfoSetChangeListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */