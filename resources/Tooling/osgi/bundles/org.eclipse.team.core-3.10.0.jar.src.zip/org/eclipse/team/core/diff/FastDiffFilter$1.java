/*    */ package org.eclipse.team.core.diff;
/*    */ 
/*    */ import org.eclipse.team.core.diff.provider.Diff;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends FastDiffFilter
/*    */ {
/*    */   public boolean select(IDiff node) {
/* 35 */     int status = ((Diff)node).getStatus(); byte b; int i, arrayOfInt[];
/* 36 */     for (i = (arrayOfInt = states).length, b = 0; b < i; ) { int state = arrayOfInt[b];
/* 37 */       if ((status & mask) == state)
/* 38 */         return true; 
/*    */       b++; }
/*    */     
/* 41 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\diff\FastDiffFilter$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */