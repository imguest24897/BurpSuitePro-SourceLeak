/*    */ package org.eclipse.team.core.diff;
/*    */ 
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.team.core.diff.provider.Diff;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FastDiffFilter
/*    */   extends DiffFilter
/*    */ {
/*    */   public static final FastDiffFilter getStateFilter(final int[] states, final int mask) {
/* 32 */     return new FastDiffFilter()
/*    */       {
/*    */         public boolean select(IDiff node) {
/* 35 */           int status = ((Diff)node).getStatus(); byte b; int i, arrayOfInt[];
/* 36 */           for (i = (arrayOfInt = states).length, b = 0; b < i; ) { int state = arrayOfInt[b];
/* 37 */             if ((status & mask) == state)
/* 38 */               return true; 
/*    */             b++; }
/*    */           
/* 41 */           return false;
/*    */         }
/*    */       };
/*    */   }
/*    */ 
/*    */   
/*    */   public final boolean select(IDiff diff, IProgressMonitor monitor) {
/* 48 */     return select(diff);
/*    */   }
/*    */   
/*    */   public abstract boolean select(IDiff paramIDiff);
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\diff\FastDiffFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */