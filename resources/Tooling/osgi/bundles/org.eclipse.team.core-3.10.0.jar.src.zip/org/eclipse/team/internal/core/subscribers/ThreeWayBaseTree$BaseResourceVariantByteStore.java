/*    */ package org.eclipse.team.internal.core.subscribers;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.team.core.TeamException;
/*    */ import org.eclipse.team.core.variants.ResourceVariantByteStore;
/*    */ import org.eclipse.team.core.variants.ThreeWaySubscriber;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BaseResourceVariantByteStore
/*    */   extends ResourceVariantByteStore
/*    */ {
/*    */   private ThreeWaySubscriber subscriber;
/*    */   
/*    */   public BaseResourceVariantByteStore(ThreeWaySubscriber subscriber) {
/* 40 */     this.subscriber = subscriber;
/*    */   }
/*    */ 
/*    */   
/*    */   public void dispose() {}
/*    */ 
/*    */   
/*    */   public byte[] getBytes(IResource resource) throws TeamException {
/* 48 */     return this.subscriber.getSynchronizer().getBaseBytes(resource);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean setBytes(IResource resource, byte[] bytes) throws TeamException {
/* 53 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean flushBytes(IResource resource, int depth) throws TeamException {
/* 58 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean deleteBytes(IResource resource) throws TeamException {
/* 63 */     return false;
/*    */   }
/*    */   
/*    */   public IResource[] members(IResource resource) throws TeamException {
/* 67 */     return this.subscriber.getSynchronizer().members(resource);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\ThreeWayBaseTree$BaseResourceVariantByteStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */