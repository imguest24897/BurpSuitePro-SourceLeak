package org.eclipse.team.core.importing.provisional;

import java.util.Map;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.team.core.ScmUrlImportDescription;

public interface IBundleImporterDelegate {
  ScmUrlImportDescription[] validateImport(Map[] paramArrayOfMap);
  
  IProject[] performImport(ScmUrlImportDescription[] paramArrayOfScmUrlImportDescription, IProgressMonitor paramIProgressMonitor) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\importing\provisional\IBundleImporterDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */