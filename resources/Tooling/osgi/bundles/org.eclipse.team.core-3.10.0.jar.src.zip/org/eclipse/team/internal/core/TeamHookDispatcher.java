/*     */ package org.eclipse.team.internal.core;
/*     */ 
/*     */ import java.net.URI;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IFolder;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceRuleFactory;
/*     */ import org.eclipse.core.resources.team.TeamHook;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.team.core.RepositoryProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TeamHookDispatcher
/*     */   extends TeamHook
/*     */ {
/*     */   private static TeamHookDispatcher instance;
/*     */   
/*     */   public static void setProviderRuleFactory(IProject project, IResourceRuleFactory factory) {
/*  37 */     if (instance != null) {
/*  38 */       if (factory == null) {
/*  39 */         factory = instance.defaultFactory;
/*     */       }
/*  41 */       instance.setRuleFactory(project, factory);
/*     */     } 
/*     */   }
/*     */   
/*     */   public TeamHookDispatcher() {
/*  46 */     instance = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public IStatus validateCreateLink(IFile file, int updateFlags, IPath location) {
/*  51 */     RepositoryProvider provider = getProvider((IResource)file);
/*  52 */     if (provider == null) {
/*  53 */       return super.validateCreateLink(file, updateFlags, location);
/*     */     }
/*  55 */     return provider.validateCreateLink((IResource)file, updateFlags, location);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateCreateLink(IFile file, int updateFlags, URI location) {
/*  61 */     RepositoryProvider provider = getProvider((IResource)file);
/*  62 */     if (provider == null) {
/*  63 */       return super.validateCreateLink(file, updateFlags, location);
/*     */     }
/*  65 */     return provider.validateCreateLink((IResource)file, updateFlags, location);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateCreateLink(IFolder folder, int updateFlags, IPath location) {
/*  71 */     RepositoryProvider provider = getProvider((IResource)folder);
/*  72 */     if (provider == null) {
/*  73 */       return super.validateCreateLink(folder, updateFlags, location);
/*     */     }
/*  75 */     return provider.validateCreateLink((IResource)folder, updateFlags, location);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateCreateLink(IFolder folder, int updateFlags, URI location) {
/*  81 */     RepositoryProvider provider = getProvider((IResource)folder);
/*  82 */     if (provider == null) {
/*  83 */       return super.validateCreateLink(folder, updateFlags, location);
/*     */     }
/*  85 */     return provider.validateCreateLink((IResource)folder, updateFlags, location);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RepositoryProvider getProvider(IResource resource) {
/*  95 */     return RepositoryProvider.getProvider(resource.getProject());
/*     */   }
/*     */ 
/*     */   
/*     */   public IResourceRuleFactory getRuleFactory(IProject project) {
/* 100 */     if (RepositoryProvider.isShared(project)) {
/* 101 */       RepositoryProvider provider = getProvider((IResource)project);
/*     */       
/* 103 */       if (provider != null) {
/* 104 */         return provider.getRuleFactory();
/*     */       }
/*     */     } 
/*     */     
/* 108 */     return super.getRuleFactory(project);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\TeamHookDispatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */