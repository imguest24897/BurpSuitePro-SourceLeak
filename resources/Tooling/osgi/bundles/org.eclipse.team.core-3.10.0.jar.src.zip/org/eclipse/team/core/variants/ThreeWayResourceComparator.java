/*    */ package org.eclipse.team.core.variants;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.team.core.TeamException;
/*    */ import org.eclipse.team.internal.core.TeamPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ThreeWayResourceComparator
/*    */   implements IResourceVariantComparator
/*    */ {
/*    */   private ThreeWaySynchronizer synchronizer;
/*    */   
/*    */   public ThreeWayResourceComparator(ThreeWaySynchronizer synchronizer) {
/* 41 */     this.synchronizer = synchronizer;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean compare(IResource local, IResourceVariant remote) {
/* 47 */     if (((local.getType() == 1)) == remote.isContainer()) {
/* 48 */       return false;
/*    */     }
/*    */     
/*    */     try {
/* 52 */       if (local.getType() == 1 && getSynchronizer().isLocallyModified(local)) {
/* 53 */         return false;
/*    */       }
/*    */       
/* 56 */       if (getSynchronizer().getBaseBytes(local) == null) return false;
/*    */       
/* 58 */       return equals(getSynchronizer().getBaseBytes(local), getBytes(remote));
/* 59 */     } catch (TeamException e) {
/* 60 */       TeamPlugin.log((CoreException)e);
/* 61 */       return false;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean compare(IResourceVariant base, IResourceVariant remote) {
/* 67 */     byte[] bytes1 = getBytes(base);
/* 68 */     byte[] bytes2 = getBytes(remote);
/* 69 */     return equals(bytes1, bytes2);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isThreeWay() {
/* 74 */     return true;
/*    */   }
/*    */   
/*    */   private ThreeWaySynchronizer getSynchronizer() {
/* 78 */     return this.synchronizer;
/*    */   }
/*    */   
/*    */   private byte[] getBytes(IResourceVariant remote) {
/* 82 */     return remote.asBytes();
/*    */   }
/*    */   
/*    */   private boolean equals(byte[] syncBytes, byte[] oldBytes) {
/* 86 */     if (syncBytes.length != oldBytes.length) return false; 
/* 87 */     for (int i = 0; i < oldBytes.length; i++) {
/* 88 */       if (oldBytes[i] != syncBytes[i]) return false; 
/*    */     } 
/* 90 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\variants\ThreeWayResourceComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */