package org.eclipse.team.core.history;

public interface IFileHistory {
  IFileRevision[] getFileRevisions();
  
  IFileRevision getFileRevision(String paramString);
  
  IFileRevision[] getContributors(IFileRevision paramIFileRevision);
  
  IFileRevision[] getTargets(IFileRevision paramIFileRevision);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\history\IFileHistory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */