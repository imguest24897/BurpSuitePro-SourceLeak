/*    */ package org.eclipse.team.core.diff.provider;
/*    */ 
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.team.core.diff.ITwoWayDiff;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TwoWayDiff
/*    */   extends Diff
/*    */   implements ITwoWayDiff
/*    */ {
/*    */   protected static final int FLAG_MASK = 65280;
/*    */   
/*    */   public TwoWayDiff(IPath path, int kind, int flags) {
/* 48 */     super(path, kind & 0xFF | flags & 0xFFFFFF00);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getFlags() {
/* 53 */     return getStatus() & 0xFFFFFF00;
/*    */   }
/*    */ 
/*    */   
/*    */   public IPath getToPath() {
/* 58 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public IPath getFromPath() {
/* 63 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 68 */     if (obj == this)
/* 69 */       return true; 
/* 70 */     if (super.equals(obj) && 
/* 71 */       obj instanceof TwoWayDiff) {
/* 72 */       TwoWayDiff other = (TwoWayDiff)obj;
/* 73 */       return (pathsEqual(getFromPath(), other.getFromPath()) && pathsEqual(getToPath(), other.getToPath()));
/*    */     } 
/*    */     
/* 76 */     return false;
/*    */   }
/*    */   
/*    */   private boolean pathsEqual(IPath path1, IPath path2) {
/* 80 */     if (path1 == null)
/* 81 */       return (path2 == null); 
/* 82 */     if (path2 == null)
/* 83 */       return false; 
/* 84 */     return path1.equals(path2);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\diff\provider\TwoWayDiff.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */