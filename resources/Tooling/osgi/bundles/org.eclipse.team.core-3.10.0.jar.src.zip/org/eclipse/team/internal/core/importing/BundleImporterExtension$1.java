/*    */ package org.eclipse.team.internal.core.importing;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.team.core.RepositoryProviderType;
/*    */ import org.eclipse.team.core.importing.provisional.BundleImporterDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends BundleImporterDelegate
/*    */ {
/*    */   private Set<String> supportedValues;
/*    */   private RepositoryProviderType providerType;
/*    */   
/*    */   protected Set getSupportedValues() {
/* 73 */     if (this.supportedValues == null) {
/* 74 */       IConfigurationElement[] supported = BundleImporterExtension.this.element.getChildren("supports");
/* 75 */       this.supportedValues = new HashSet<>(supported.length); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 76 */       for (i = (arrayOfIConfigurationElement1 = supported).length, b = 0; b < i; ) { IConfigurationElement s = arrayOfIConfigurationElement1[b];
/* 77 */         this.supportedValues.add(s.getAttribute("prefix")); b++; }
/*    */     
/*    */     } 
/* 80 */     return this.supportedValues;
/*    */   }
/*    */   
/*    */   protected RepositoryProviderType getProviderType() {
/* 84 */     if (this.providerType == null)
/* 85 */       this.providerType = RepositoryProviderType.getProviderType(BundleImporterExtension.this.element.getAttribute("repository")); 
/* 86 */     return this.providerType;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\importing\BundleImporterExtension$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */