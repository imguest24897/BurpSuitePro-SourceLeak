/*     */ package org.eclipse.team.core.synchronize;
/*     */ 
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastSyncInfoFilter
/*     */   extends SyncInfoFilter
/*     */ {
/*     */   public static FastSyncInfoFilter getDirectionAndChangeFilter(int direction, int change) {
/*  41 */     return new AndSyncInfoFilter(new FastSyncInfoFilter[] { new SyncInfoDirectionFilter(direction), new SyncInfoChangeTypeFilter(change) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class CompoundSyncInfoFilter
/*     */     extends FastSyncInfoFilter
/*     */   {
/*     */     protected FastSyncInfoFilter[] filters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected CompoundSyncInfoFilter(FastSyncInfoFilter[] filters) {
/*  59 */       this.filters = filters;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class AndSyncInfoFilter
/*     */     extends CompoundSyncInfoFilter
/*     */   {
/*     */     public AndSyncInfoFilter(FastSyncInfoFilter[] filters) {
/*  72 */       super(filters); } public boolean select(SyncInfo info) {
/*     */       byte b;
/*     */       int i;
/*     */       FastSyncInfoFilter[] arrayOfFastSyncInfoFilter;
/*  76 */       for (i = (arrayOfFastSyncInfoFilter = this.filters).length, b = 0; b < i; ) { FastSyncInfoFilter filter = arrayOfFastSyncInfoFilter[b];
/*  77 */         if (!filter.select(info))
/*  78 */           return false; 
/*     */         b++; }
/*     */       
/*  81 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class AutomergableFilter
/*     */     extends FastSyncInfoFilter
/*     */   {
/*     */     public boolean select(SyncInfo info) {
/*  91 */       return ((info.getKind() & 0x20) != 0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class PseudoConflictFilter
/*     */     extends FastSyncInfoFilter
/*     */   {
/*     */     public boolean select(SyncInfo info) {
/* 101 */       return (info.getKind() != 0 && (info.getKind() & 0x10) == 0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class OrSyncInfoFilter
/*     */     extends CompoundSyncInfoFilter
/*     */   {
/*     */     public OrSyncInfoFilter(FastSyncInfoFilter[] filters) {
/* 114 */       super(filters); } public boolean select(SyncInfo info) {
/*     */       byte b;
/*     */       int i;
/*     */       FastSyncInfoFilter[] arrayOfFastSyncInfoFilter;
/* 118 */       for (i = (arrayOfFastSyncInfoFilter = this.filters).length, b = 0; b < i; ) { FastSyncInfoFilter filter = arrayOfFastSyncInfoFilter[b];
/* 119 */         if (filter.select(info))
/* 120 */           return true; 
/*     */         b++; }
/*     */       
/* 123 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class SyncInfoChangeTypeFilter
/*     */     extends FastSyncInfoFilter
/*     */   {
/* 131 */     private int[] changeFilters = new int[] { 1, 2, 3 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SyncInfoChangeTypeFilter(int[] changeFilters) {
/* 139 */       this.changeFilters = changeFilters;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SyncInfoChangeTypeFilter(int change) {
/* 148 */       this(new int[] { change });
/*     */     }
/*     */     
/*     */     public boolean select(SyncInfo info) {
/* 152 */       int syncKind = info.getKind(); byte b; int i, arrayOfInt[];
/* 153 */       for (i = (arrayOfInt = this.changeFilters).length, b = 0; b < i; ) { int filter = arrayOfInt[b];
/* 154 */         if ((syncKind & 0x3) == filter)
/* 155 */           return true;  b++; }
/*     */       
/* 157 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class SyncInfoDirectionFilter
/*     */     extends FastSyncInfoFilter
/*     */   {
/* 165 */     int[] directionFilters = new int[] { 4, 8, 12 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SyncInfoDirectionFilter(int[] directionFilters) {
/* 173 */       this.directionFilters = directionFilters;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SyncInfoDirectionFilter(int direction) {
/* 182 */       this(new int[] { direction });
/*     */     }
/*     */     
/*     */     public boolean select(SyncInfo info) {
/* 186 */       int syncKind = info.getKind(); byte b; int i, arrayOfInt[];
/* 187 */       for (i = (arrayOfInt = this.directionFilters).length, b = 0; b < i; ) { int filter = arrayOfInt[b];
/* 188 */         if ((syncKind & 0xC) == filter)
/* 189 */           return true;  b++; }
/*     */       
/* 191 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean select(SyncInfo info) {
/* 203 */     return (info.getKind() != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean select(SyncInfo info, IProgressMonitor monitor) {
/* 208 */     return select(info);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\synchronize\FastSyncInfoFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */