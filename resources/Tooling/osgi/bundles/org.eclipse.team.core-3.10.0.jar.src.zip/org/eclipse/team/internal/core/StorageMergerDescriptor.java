/*    */ package org.eclipse.team.internal.core;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.team.core.mapping.IStorageMerger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StorageMergerDescriptor
/*    */ {
/*    */   private static final String CLASS_ATTRIBUTE = "class";
/*    */   private IConfigurationElement fElement;
/*    */   
/*    */   public StorageMergerDescriptor(IConfigurationElement element) {
/* 33 */     this.fElement = element;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IStorageMerger createStreamMerger() {
/*    */     try {
/* 41 */       return (IStorageMerger)this.fElement.createExecutableExtension("class");
/* 42 */     } catch (CoreException coreException) {
/*    */       
/* 44 */       return null;
/* 45 */     } catch (ClassCastException classCastException) {
/*    */       
/* 47 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\StorageMergerDescriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */