/*    */ package org.eclipse.team.core.mapping;
/*    */ 
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.IResourceChangeEvent;
/*    */ import org.eclipse.core.resources.IResourceChangeListener;
/*    */ import org.eclipse.core.resources.IResourceDelta;
/*    */ import org.eclipse.team.core.RepositoryProvider;
/*    */ import org.eclipse.team.internal.core.IRepositoryProviderListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ChangeListener
/*    */   implements IResourceChangeListener, IRepositoryProviderListener
/*    */ {
/*    */   public void resourceChanged(IResourceChangeEvent event) {
/* 58 */     if (ChangeTracker.this.disposed)
/* 59 */       return;  IResourceDelta delta = event.getDelta();
/* 60 */     IResourceDelta[] projectDeltas = delta.getAffectedChildren(7); byte b; int i; IResourceDelta[] arrayOfIResourceDelta1;
/* 61 */     for (i = (arrayOfIResourceDelta1 = projectDeltas).length, b = 0; b < i; ) { IResourceDelta projectDelta = arrayOfIResourceDelta1[b];
/* 62 */       IResource resource = projectDelta.getResource();
/* 63 */       if (resource.getType() == 4) {
/* 64 */         IProject project = (IProject)resource;
/* 65 */         if (ChangeTracker.this.isProjectOfInterest(project)) {
/* 66 */           if (ChangeTracker.this.isProjectTracked(project)) {
/* 67 */             IResource[] resources = ChangeTracker.this.getProjectChanges(project, projectDelta);
/* 68 */             if (resources.length > 0)
/* 69 */               ChangeTracker.this.handleChanges(project, resources); 
/*    */           } else {
/* 71 */             ChangeTracker.this.trackProject(project);
/*    */           } 
/*    */         } else {
/* 74 */           ChangeTracker.this.stopTrackingProject(project);
/*    */         } 
/*    */       } 
/*    */       b++; }
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void providerMapped(RepositoryProvider provider) {
/* 86 */     if (ChangeTracker.this.disposed)
/* 87 */       return;  if (ChangeTracker.this.isProjectOfInterest(provider.getProject())) {
/* 88 */       ChangeTracker.this.trackProject(provider.getProject());
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void providerUnmapped(IProject project) {
/* 98 */     if (ChangeTracker.this.disposed)
/* 99 */       return;  ChangeTracker.this.stopTrackingProject(project);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\ChangeTracker$ChangeListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */