/*     */ package org.eclipse.team.internal.core.streams;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InterruptedIOException;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeoutInputStream
/*     */   extends FilterInputStream
/*     */ {
/*     */   private final long readTimeout;
/*     */   private final long closeTimeout;
/*     */   private boolean closeRequested = false;
/*     */   private Thread thread;
/*     */   private byte[] iobuffer;
/*  45 */   private int head = 0;
/*  46 */   private int length = 0;
/*  47 */   private IOException ioe = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean waitingForClose = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean growWhenFull = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TimeoutInputStream(InputStream in, int bufferSize, long readTimeout, long closeTimeout) {
/*  63 */     super(in);
/*  64 */     this.readTimeout = readTimeout;
/*  65 */     this.closeTimeout = closeTimeout;
/*  66 */     this.iobuffer = new byte[bufferSize];
/*  67 */     this.thread = new Thread(this::runThread, "TimeoutInputStream");
/*  68 */     this.thread.setDaemon(true);
/*  69 */     this.thread.start();
/*     */   }
/*     */   
/*     */   public TimeoutInputStream(InputStream in, int bufferSize, long readTimeout, long closeTimeout, boolean growWhenFull) {
/*  73 */     this(in, bufferSize, readTimeout, closeTimeout);
/*  74 */     this.growWhenFull = growWhenFull;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*     */     Thread oldThread;
/*  89 */     synchronized (this) {
/*  90 */       if (this.thread == null)
/*  91 */         return;  oldThread = this.thread;
/*  92 */       this.closeRequested = true;
/*  93 */       this.thread.interrupt();
/*  94 */       checkError();
/*     */     } 
/*  96 */     if (this.closeTimeout == -1L)
/*     */       return;  try {
/*  98 */       oldThread.join(this.closeTimeout);
/*  99 */     } catch (InterruptedException interruptedException) {
/* 100 */       Thread.currentThread().interrupt();
/*     */     } 
/* 102 */     synchronized (this) {
/* 103 */       checkError();
/* 104 */       if (this.thread != null) throw new InterruptedIOException();
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int available() throws IOException {
/* 114 */     if (this.length == 0) checkError(); 
/* 115 */     return (this.length > 0) ? this.length : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int read() throws IOException {
/* 126 */     if (!syncFill()) return -1; 
/* 127 */     int b = this.iobuffer[this.head++] & 0xFF;
/* 128 */     if (this.head == this.iobuffer.length) this.head = 0; 
/* 129 */     this.length--;
/* 130 */     notify();
/* 131 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int read(byte[] buffer, int off, int len) throws IOException {
/* 142 */     if (!syncFill()) return -1; 
/* 143 */     int pos = off;
/* 144 */     if (len > this.length) len = this.length; 
/* 145 */     while (len-- > 0) {
/* 146 */       buffer[pos++] = this.iobuffer[this.head++];
/* 147 */       if (this.head == this.iobuffer.length) this.head = 0; 
/* 148 */       this.length--;
/*     */     } 
/* 150 */     notify();
/* 151 */     return pos - off;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized long skip(long count) throws IOException {
/* 162 */     long amount = 0L;
/*     */ 
/*     */     
/* 165 */     try { while (syncFill())
/* 166 */       { int skip = (int)Math.min(count - amount, this.length);
/* 167 */         this.head = (this.head + skip) % this.iobuffer.length;
/* 168 */         this.length -= skip;
/* 169 */         amount += skip;
/* 170 */         if (amount >= count)
/* 171 */           break;  }  } catch (InterruptedIOException e)
/* 172 */     { e.bytesTransferred = (int)amount;
/* 173 */       throw e; }
/*     */     
/* 175 */     notify();
/* 176 */     return amount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 184 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean syncFill() throws IOException {
/* 193 */     if (this.length != 0) return true; 
/* 194 */     checkError();
/* 195 */     if (this.waitingForClose) return false; 
/* 196 */     notify();
/*     */     try {
/* 198 */       wait(this.readTimeout);
/* 199 */     } catch (InterruptedException interruptedException) {
/* 200 */       Thread.currentThread().interrupt();
/*     */     } 
/* 202 */     if (this.length != 0) return true; 
/* 203 */     checkError();
/* 204 */     if (this.waitingForClose) return false; 
/* 205 */     throw new InterruptedIOException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkError() throws IOException {
/* 212 */     if (this.ioe != null) {
/* 213 */       IOException e = this.ioe;
/* 214 */       this.ioe = null;
/* 215 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void runThread() {
/*     */     
/* 224 */     try { readUntilDone(); }
/* 225 */     catch (IOException e)
/* 226 */     { synchronized (this) { this.ioe = e; }
/*     */       
/* 228 */       waitUntilClosed(); } finally { waitUntilClosed();
/*     */       
/* 230 */       try { this.in.close(); }
/* 231 */       catch (IOException e)
/* 232 */       { synchronized (this) { this.ioe = e; }
/*     */          }
/* 234 */       finally { synchronized (this) {
/* 235 */           this.thread = null;
/* 236 */           notify();
/*     */         }  }
/*     */        }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void waitUntilClosed() {
/* 246 */     this.waitingForClose = true;
/* 247 */     notify();
/* 248 */     while (!this.closeRequested) {
/*     */       try {
/* 250 */         wait();
/* 251 */       } catch (InterruptedException interruptedException) {
/* 252 */         this.closeRequested = true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void readUntilDone() throws IOException {
/*     */     while (true) {
/*     */       int off;
/*     */       int len;
/*     */       int count;
/* 263 */       synchronized (this) {
/* 264 */         while (isBufferFull()) {
/* 265 */           if (this.closeRequested)
/* 266 */             return;  waitForRead();
/*     */         } 
/* 268 */         off = (this.head + this.length) % this.iobuffer.length;
/* 269 */         len = ((this.head > off) ? this.head : this.iobuffer.length) - off;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 275 */       try { count = this.in.read(this.iobuffer, off, len);
/* 276 */         if (count == -1)
/* 277 */           return;  } catch (InterruptedIOException e)
/* 278 */       { count = e.bytesTransferred; }
/*     */       
/* 280 */       synchronized (this) {
/* 281 */         this.length += count;
/* 282 */         notify();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void waitForRead() {
/*     */     try {
/* 294 */       if (this.growWhenFull) {
/*     */         
/* 296 */         wait(this.readTimeout);
/*     */       } else {
/* 298 */         wait();
/*     */       } 
/* 300 */     } catch (InterruptedException interruptedException) {
/* 301 */       this.closeRequested = true;
/*     */     } 
/*     */     
/* 304 */     if (this.growWhenFull && isBufferFull()) {
/* 305 */       growBuffer();
/*     */     }
/*     */   }
/*     */   
/*     */   private synchronized void growBuffer() {
/* 310 */     int newSize = 2 * this.iobuffer.length;
/* 311 */     if (newSize > this.iobuffer.length) {
/* 312 */       if (Policy.DEBUG_STREAMS) {
/* 313 */         System.out.println("InputStream growing to " + newSize + " bytes");
/*     */       }
/* 315 */       byte[] newBuffer = new byte[newSize];
/* 316 */       int pos = 0;
/* 317 */       int len = this.length;
/* 318 */       while (len-- > 0) {
/* 319 */         newBuffer[pos++] = this.iobuffer[this.head++];
/* 320 */         if (this.head == this.iobuffer.length) this.head = 0; 
/*     */       } 
/* 322 */       this.iobuffer = newBuffer;
/* 323 */       this.head = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isBufferFull() {
/* 329 */     return (this.length == this.iobuffer.length);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\streams\TimeoutInputStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */