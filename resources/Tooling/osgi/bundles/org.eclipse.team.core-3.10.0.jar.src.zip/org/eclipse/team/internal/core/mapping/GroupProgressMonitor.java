/*    */ package org.eclipse.team.internal.core.mapping;
/*    */ 
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.ProgressMonitorWrapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GroupProgressMonitor
/*    */   extends ProgressMonitorWrapper
/*    */   implements IProgressMonitor
/*    */ {
/*    */   private final IProgressMonitor group;
/*    */   private final int ticks;
/*    */   
/*    */   public GroupProgressMonitor(IProgressMonitor monitor, IProgressMonitor group, int groupTicks) {
/* 26 */     super(monitor);
/* 27 */     this.group = group;
/* 28 */     this.ticks = groupTicks;
/*    */   }
/*    */   
/*    */   public IProgressMonitor getGroup() {
/* 32 */     return this.group;
/*    */   }
/*    */   
/*    */   public int getTicks() {
/* 36 */     return this.ticks;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\GroupProgressMonitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */