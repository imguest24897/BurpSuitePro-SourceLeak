package org.eclipse.team.core.diff;

import org.eclipse.core.runtime.IProgressMonitor;

public abstract class DiffFilter {
  public abstract boolean select(IDiff paramIDiff, IProgressMonitor paramIProgressMonitor);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\diff\DiffFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */