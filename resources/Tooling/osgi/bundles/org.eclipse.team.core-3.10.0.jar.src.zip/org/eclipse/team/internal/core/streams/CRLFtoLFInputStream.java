/*     */ package org.eclipse.team.internal.core.streams;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InterruptedIOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CRLFtoLFInputStream
/*     */   extends FilterInputStream
/*     */ {
/*     */   private boolean pendingByte = false;
/*  30 */   private int lastByte = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CRLFtoLFInputStream(InputStream in) {
/*  37 */     super(in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/*  49 */     if (!this.pendingByte) {
/*  50 */       this.lastByte = this.in.read();
/*  51 */       this.pendingByte = true;
/*     */     } 
/*  53 */     if (this.lastByte == 13) {
/*  54 */       this.lastByte = this.in.read();
/*  55 */       if (this.lastByte != 10) {
/*  56 */         if (this.lastByte == -1) this.pendingByte = false; 
/*  57 */         return 13;
/*     */       } 
/*     */     } 
/*  60 */     this.pendingByte = false;
/*  61 */     return this.lastByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] buffer, int off, int len) throws IOException {
/*  74 */     if (len == 0)
/*  75 */       return 0; 
/*  76 */     if (len == 1) {
/*  77 */       int b = read();
/*  78 */       if (b == -1) return -1; 
/*  79 */       buffer[off] = (byte)b;
/*  80 */       return 1;
/*     */     } 
/*     */ 
/*     */     
/*  84 */     int count = 0;
/*  85 */     if (this.pendingByte) {
/*  86 */       buffer[off] = (byte)this.lastByte;
/*  87 */       this.pendingByte = false;
/*  88 */       count = 1;
/*     */     } 
/*  90 */     InterruptedIOException iioe = null;
/*     */     try {
/*  92 */       len = this.in.read(buffer, off + count, len - count);
/*  93 */       if (len == -1) {
/*  94 */         return (count == 0) ? -1 : count;
/*     */       }
/*  96 */     } catch (InterruptedIOException e) {
/*  97 */       len = e.bytesTransferred;
/*  98 */       iioe = e;
/*     */     } 
/* 100 */     count += len;
/*     */ 
/*     */     
/* 103 */     int j = off;
/* 104 */     for (int i = off; i < off + count; i++) {
/* 105 */       this.lastByte = buffer[i];
/* 106 */       if (this.lastByte == 13) {
/* 107 */         if (this.pendingByte) {
/* 108 */           buffer[j++] = 13;
/*     */         } else {
/* 110 */           this.pendingByte = true;
/*     */         } 
/*     */       } else {
/* 113 */         if (this.pendingByte) {
/* 114 */           if (this.lastByte != 10) buffer[j++] = 13; 
/* 115 */           this.pendingByte = false;
/*     */         } 
/* 117 */         buffer[j++] = (byte)this.lastByte;
/*     */       } 
/*     */     } 
/* 120 */     if (iioe != null) {
/* 121 */       iioe.bytesTransferred = j - off;
/* 122 */       throw iioe;
/*     */     } 
/* 124 */     return j - off;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long skip(long count) throws IOException {
/* 135 */     int actualCount = 0;
/*     */     try {
/* 137 */       for (; count-- > 0L && read() != -1; actualCount++);
/* 138 */       return actualCount;
/* 139 */     } catch (InterruptedIOException e) {
/* 140 */       e.bytesTransferred = actualCount;
/* 141 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/* 153 */     return this.in.available() / 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 161 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\streams\CRLFtoLFInputStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */