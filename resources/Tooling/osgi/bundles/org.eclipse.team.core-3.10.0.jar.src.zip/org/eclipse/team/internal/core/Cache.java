/*    */ package org.eclipse.team.internal.core;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.eclipse.core.runtime.ISafeRunnable;
/*    */ import org.eclipse.core.runtime.ListenerList;
/*    */ import org.eclipse.core.runtime.SafeRunner;
/*    */ import org.eclipse.team.core.ICache;
/*    */ import org.eclipse.team.core.ICacheListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Cache
/*    */   implements ICache
/*    */ {
/*    */   Map<String, Object> properties;
/*    */   ListenerList<ICacheListener> listeners;
/*    */   
/*    */   public synchronized void put(String name, Object value) {
/* 40 */     if (this.properties == null) {
/* 41 */       this.properties = new HashMap<>();
/*    */     }
/* 43 */     this.properties.put(name, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized Object get(String name) {
/* 48 */     if (this.properties == null)
/* 49 */       return null; 
/* 50 */     return this.properties.get(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void remove(String name) {
/* 55 */     if (this.properties != null)
/* 56 */       this.properties.remove(name); 
/* 57 */     if (this.properties.isEmpty()) {
/* 58 */       this.properties = null;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized void addCacheListener(ICacheListener listener) {
/* 65 */     if (this.listeners == null)
/* 66 */       this.listeners = new ListenerList(1); 
/* 67 */     this.listeners.add(listener);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized void removeDisposeListener(ICacheListener listener) {
/* 73 */     removeCacheListener(listener);
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void removeCacheListener(ICacheListener listener) {
/* 78 */     if (this.listeners != null)
/* 79 */       this.listeners.remove(listener); 
/*    */   }
/*    */   
/*    */   public void dispose() {
/* 83 */     if (this.listeners != null) {
/* 84 */       for (ICacheListener listener : this.listeners) {
/* 85 */         SafeRunner.run(new ISafeRunnable()
/*    */             {
/*    */               public void run() throws Exception {
/* 88 */                 listener.cacheDisposed(Cache.this);
/*    */               }
/*    */ 
/*    */ 
/*    */ 
/*    */               
/*    */               public void handleException(Throwable exception) {}
/*    */             });
/*    */       } 
/*    */     }
/* 98 */     this.properties = null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\Cache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */