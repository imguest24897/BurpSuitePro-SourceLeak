/*     */ package org.eclipse.team.core.mapping.provider;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.team.core.diff.FastDiffFilter;
/*     */ import org.eclipse.team.core.diff.IDiff;
/*     */ import org.eclipse.team.core.diff.IDiffVisitor;
/*     */ import org.eclipse.team.core.diff.IThreeWayDiff;
/*     */ import org.eclipse.team.core.diff.ITwoWayDiff;
/*     */ import org.eclipse.team.core.diff.provider.DiffTree;
/*     */ import org.eclipse.team.core.mapping.IResourceDiff;
/*     */ import org.eclipse.team.core.mapping.IResourceDiffTree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceDiffTree
/*     */   extends DiffTree
/*     */   implements IResourceDiffTree
/*     */ {
/*     */   public static IResource getResourceFor(IDiff node) {
/*  49 */     if (node instanceof IResourceDiff) {
/*  50 */       IResourceDiff rd = (IResourceDiff)node;
/*  51 */       return rd.getResource();
/*     */     } 
/*  53 */     if (node instanceof IThreeWayDiff) {
/*  54 */       IThreeWayDiff twd = (IThreeWayDiff)node;
/*  55 */       ITwoWayDiff iTwoWayDiff = twd.getLocalChange();
/*  56 */       if (iTwoWayDiff != null)
/*  57 */         return getResourceFor((IDiff)iTwoWayDiff); 
/*  58 */       iTwoWayDiff = twd.getRemoteChange();
/*  59 */       if (iTwoWayDiff != null)
/*  60 */         return getResourceFor((IDiff)iTwoWayDiff); 
/*     */     } 
/*  62 */     Assert.isLegal(false);
/*  63 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IDiff getDiff(IResource resource) {
/*  68 */     return getDiff(resource.getFullPath());
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource getResource(IDiff diff) {
/*  73 */     if (diff instanceof IThreeWayDiff) {
/*  74 */       IThreeWayDiff twd = (IThreeWayDiff)diff;
/*  75 */       IResourceDiff localChange = (IResourceDiff)twd.getLocalChange();
/*  76 */       if (localChange != null)
/*  77 */         return localChange.getResource(); 
/*  78 */       return ((IResourceDiff)twd.getRemoteChange()).getResource();
/*     */     } 
/*  80 */     return ((IResourceDiff)diff).getResource();
/*     */   }
/*     */   public void accept(ResourceTraversal[] traversals, IDiffVisitor visitor) {
/*     */     byte b;
/*     */     int i;
/*     */     ResourceTraversal[] arrayOfResourceTraversal;
/*  86 */     for (i = (arrayOfResourceTraversal = traversals).length, b = 0; b < i; ) { ResourceTraversal traversal = arrayOfResourceTraversal[b];
/*  87 */       IResource[] resources = traversal.getResources(); byte b1; int j; IResource[] arrayOfIResource1;
/*  88 */       for (j = (arrayOfIResource1 = resources).length, b1 = 0; b1 < j; ) { IResource resource = arrayOfIResource1[b1];
/*  89 */         accept(resource.getFullPath(), visitor, traversal.getDepth());
/*     */         b1++; }
/*     */       
/*     */       b++; }
/*     */   
/*     */   }
/*     */   public IDiff[] getDiffs(ResourceTraversal[] traversals) {
/*  96 */     Set<IDiff> result = new HashSet<>(); byte b; int i; ResourceTraversal[] arrayOfResourceTraversal;
/*  97 */     for (i = (arrayOfResourceTraversal = traversals).length, b = 0; b < i; ) { ResourceTraversal traversal = arrayOfResourceTraversal[b];
/*  98 */       IResource[] resources = traversal.getResources(); byte b1; int j; IResource[] arrayOfIResource1;
/*  99 */       for (j = (arrayOfIResource1 = resources).length, b1 = 0; b1 < j; ) { IResource resource = arrayOfIResource1[b1];
/* 100 */         internalGetDiffs(resource, traversal.getDepth(), result); b1++; }
/*     */        b++; }
/*     */     
/* 103 */     return result.<IDiff>toArray(new IDiff[result.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public IDiff[] getDiffs(IResource resource, int depth) {
/* 108 */     Set<IDiff> result = new HashSet<>();
/* 109 */     internalGetDiffs(resource, depth, result);
/* 110 */     return result.<IDiff>toArray(new IDiff[result.size()]);
/*     */   }
/*     */   
/*     */   private void internalGetDiffs(IResource resource, int depth, Set<IDiff> result) {
/* 114 */     accept(resource.getFullPath(), diff -> paramSet.add(diff), depth);
/*     */   }
/*     */   
/*     */   private IResource internalGetResource(IPath fullPath, boolean container) {
/* 118 */     if (container) {
/* 119 */       if (fullPath.segmentCount() == 1)
/* 120 */         return (IResource)ResourcesPlugin.getWorkspace().getRoot().getProject(fullPath.segment(0)); 
/* 121 */       return (IResource)ResourcesPlugin.getWorkspace().getRoot().getFolder(fullPath);
/*     */     } 
/* 123 */     return (IResource)ResourcesPlugin.getWorkspace().getRoot().getFile(fullPath);
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource[] members(IResource resource) {
/* 128 */     List<IResource> result = new ArrayList<>();
/* 129 */     IPath[] paths = getChildren(resource.getFullPath()); byte b; int i; IPath[] arrayOfIPath1;
/* 130 */     for (i = (arrayOfIPath1 = paths).length, b = 0; b < i; ) { IPath path = arrayOfIPath1[b];
/* 131 */       IDiff node = getDiff(path);
/* 132 */       if (node == null) {
/* 133 */         result.add(internalGetResource(path, true));
/*     */       } else {
/* 135 */         result.add(getResource(node));
/*     */       }  b++; }
/*     */     
/* 138 */     return result.<IResource>toArray(new IResource[result.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource[] getAffectedResources() {
/* 143 */     List<IResource> result = new ArrayList<>();
/* 144 */     IDiff[] nodes = getDiffs(); byte b; int i; IDiff[] arrayOfIDiff1;
/* 145 */     for (i = (arrayOfIDiff1 = nodes).length, b = 0; b < i; ) { IDiff node = arrayOfIDiff1[b];
/* 146 */       result.add(getResource(node)); b++; }
/*     */     
/* 148 */     return result.<IResource>toArray(new IResource[result.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(IDiff delta) {
/* 153 */     Assert.isTrue(!(!(delta instanceof IResourceDiff) && !(delta instanceof IThreeWayDiff)));
/* 154 */     super.add(delta);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(IResource resource) {
/* 163 */     remove(resource.getFullPath());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasMatchingDiffs(ResourceTraversal[] traversals, FastDiffFilter filter) {
/* 168 */     RuntimeException found = new RuntimeException();
/*     */     try {
/* 170 */       accept(traversals, delta -> {
/*     */             if (paramFastDiffFilter.select(delta)) {
/*     */               throw paramRuntimeException;
/*     */             }
/*     */             return false;
/*     */           });
/* 176 */     } catch (RuntimeException e) {
/* 177 */       if (e == found)
/* 178 */         return true; 
/* 179 */       throw e;
/*     */     } 
/* 181 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\provider\ResourceDiffTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */