/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.ListenerList;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ChangeSetManager
/*     */ {
/*  30 */   private ListenerList<IChangeSetChangeListener> listeners = new ListenerList(1);
/*     */ 
/*     */   
/*     */   private Set<ChangeSet> sets;
/*     */   
/*     */   private boolean initializing;
/*     */ 
/*     */   
/*     */   protected Object[] getListeners() {
/*  39 */     return this.listeners.getListeners();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireNameChangedEvent(final ChangeSet set) {
/*  48 */     if (this.initializing)
/*     */       return; 
/*  50 */     if (contains(set)) {
/*  51 */       Object[] listeners = getListeners(); byte b; int i; Object[] arrayOfObject1;
/*  52 */       for (i = (arrayOfObject1 = listeners).length, b = 0; b < i; ) { Object l = arrayOfObject1[b];
/*  53 */         final IChangeSetChangeListener listener = (IChangeSetChangeListener)l;
/*  54 */         SafeRunner.run(new ISafeRunnable()
/*     */             {
/*     */               public void handleException(Throwable exception) {}
/*     */ 
/*     */ 
/*     */               
/*     */               public void run() throws Exception {
/*  61 */                 listener.nameChanged(set);
/*     */               }
/*     */             });
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireDefaultChangedEvent(final ChangeSet oldSet, final ChangeSet defaultSet) {
/*  75 */     if (this.initializing)
/*     */       return; 
/*  77 */     Object[] listeners = getListeners(); byte b; int i; Object[] arrayOfObject1;
/*  78 */     for (i = (arrayOfObject1 = listeners).length, b = 0; b < i; ) { Object l = arrayOfObject1[b];
/*  79 */       final IChangeSetChangeListener listener = (IChangeSetChangeListener)l;
/*  80 */       SafeRunner.run(new ISafeRunnable()
/*     */           {
/*     */             public void handleException(Throwable exception) {}
/*     */ 
/*     */ 
/*     */             
/*     */             public void run() throws Exception {
/*  87 */               listener.defaultSetChanged(oldSet, defaultSet);
/*     */             }
/*     */           });
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(ChangeSet set) {
/*  98 */     if (!contains(set)) {
/*  99 */       internalGetSets().add(set);
/* 100 */       handleSetAdded(set);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleSetAdded(final ChangeSet set) {
/* 109 */     if (this.initializing)
/*     */       return; 
/* 111 */     Object[] listeners = getListeners(); byte b; int i; Object[] arrayOfObject1;
/* 112 */     for (i = (arrayOfObject1 = listeners).length, b = 0; b < i; ) { Object l = arrayOfObject1[b];
/* 113 */       final IChangeSetChangeListener listener = (IChangeSetChangeListener)l;
/* 114 */       SafeRunner.run(new ISafeRunnable()
/*     */           {
/*     */             public void handleException(Throwable exception) {}
/*     */ 
/*     */ 
/*     */             
/*     */             public void run() throws Exception {
/* 121 */               listener.setAdded(set);
/*     */             }
/*     */           });
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(ChangeSet set) {
/* 132 */     if (contains(set)) {
/* 133 */       internalGetSets().remove(set);
/* 134 */       handleSetRemoved(set);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleSetRemoved(final ChangeSet set) {
/* 143 */     if (this.initializing)
/*     */       return; 
/* 145 */     Object[] listeners = getListeners(); byte b; int i; Object[] arrayOfObject1;
/* 146 */     for (i = (arrayOfObject1 = listeners).length, b = 0; b < i; ) { Object l = arrayOfObject1[b];
/* 147 */       final IChangeSetChangeListener listener = (IChangeSetChangeListener)l;
/* 148 */       SafeRunner.run(new ISafeRunnable()
/*     */           {
/*     */             public void handleException(Throwable exception) {}
/*     */ 
/*     */ 
/*     */             
/*     */             public void run() throws Exception {
/* 155 */               listener.setRemoved(set);
/*     */             }
/*     */           });
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(ChangeSet set) {
/* 167 */     return internalGetSets().contains(set);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addListener(IChangeSetChangeListener listener) {
/* 175 */     this.listeners.add(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeListener(IChangeSetChangeListener listener) {
/* 183 */     this.listeners.remove(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChangeSet[] getSets() {
/* 191 */     Set<ChangeSet> sets = internalGetSets();
/* 192 */     return sets.<ChangeSet>toArray(new ChangeSet[sets.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireResourcesChangedEvent(final ChangeSet changeSet, final IPath[] allAffectedResources) {
/* 208 */     if (this.initializing)
/*     */       return; 
/* 210 */     Object[] listeners = getListeners(); byte b; int i; Object[] arrayOfObject1;
/* 211 */     for (i = (arrayOfObject1 = listeners).length, b = 0; b < i; ) { Object l = arrayOfObject1[b];
/* 212 */       final IChangeSetChangeListener listener = (IChangeSetChangeListener)l;
/* 213 */       SafeRunner.run(new ISafeRunnable()
/*     */           {
/*     */             public void handleException(Throwable exception) {}
/*     */ 
/*     */ 
/*     */             
/*     */             public void run() throws Exception {
/* 220 */               listener.resourcesChanged(changeSet, allAffectedResources);
/*     */             }
/*     */           });
/*     */       b++; }
/*     */   
/*     */   }
/*     */   private Set<ChangeSet> internalGetSets() {
/* 227 */     if (this.sets == null) {
/* 228 */       this.sets = Collections.synchronizedSet(new HashSet<>());
/*     */       try {
/* 230 */         this.initializing = true;
/* 231 */         initializeSets();
/*     */       } finally {
/* 233 */         this.initializing = false;
/*     */       } 
/*     */     } 
/* 236 */     return this.sets;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void initializeSets();
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInitialized() {
/* 246 */     return (this.sets != null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\ChangeSetManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */