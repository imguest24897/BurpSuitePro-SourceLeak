package org.eclipse.team.core;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.IProgressMonitor;

@Deprecated
public interface IProjectSetSerializer {
  String[] asReference(IProject[] paramArrayOfIProject, Object paramObject, IProgressMonitor paramIProgressMonitor) throws TeamException;
  
  IProject[] addToWorkspace(String[] paramArrayOfString, String paramString, Object paramObject, IProgressMonitor paramIProgressMonitor) throws TeamException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\IProjectSetSerializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */