/*     */ package org.eclipse.team.internal.core.mapping;
/*     */ 
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.core.diff.IDiff;
/*     */ import org.eclipse.team.core.diff.IThreeWayDiff;
/*     */ import org.eclipse.team.core.diff.ITwoWayDiff;
/*     */ import org.eclipse.team.core.diff.provider.ThreeWayDiff;
/*     */ import org.eclipse.team.core.history.IFileRevision;
/*     */ import org.eclipse.team.core.mapping.IResourceDiff;
/*     */ import org.eclipse.team.core.mapping.provider.ResourceDiff;
/*     */ import org.eclipse.team.core.synchronize.SyncInfo;
/*     */ import org.eclipse.team.core.variants.IResourceVariant;
/*     */ import org.eclipse.team.core.variants.IResourceVariantComparator;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.history.LocalFileRevision;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncInfoToDiffConverter
/*     */ {
/*     */   private static SyncInfoToDiffConverter instance;
/*     */   
/*     */   private static class PrecalculatedSyncInfo
/*     */     extends SyncInfo
/*     */   {
/*     */     public int kind;
/*     */     
/*     */     public PrecalculatedSyncInfo(int kind, IResource local, IResourceVariant base, IResourceVariant remote, IResourceVariantComparator comparator) {
/*  43 */       super(local, base, remote, comparator);
/*  44 */       this.kind = kind;
/*     */     }
/*     */ 
/*     */     
/*     */     protected int calculateKind() throws TeamException {
/*  49 */       return this.kind;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String diffKindToString(int kind) {
/*  57 */     String label = "";
/*  58 */     if (kind == 0) {
/*  59 */       label = Messages.RemoteSyncElement_insync;
/*     */     } else {
/*  61 */       switch (kind) { case 4:
/*  62 */           label = Messages.RemoteSyncElement_change; break;
/*  63 */         case 1: label = Messages.RemoteSyncElement_addition; break;
/*  64 */         case 2: label = Messages.RemoteSyncElement_deletion; break; }
/*     */     
/*     */     } 
/*  67 */     return label;
/*     */   }
/*     */   
/*     */   public static String diffDirectionToString(int direction) {
/*  71 */     switch (direction) { case 768:
/*  72 */         return Messages.RemoteSyncElement_conflicting;
/*  73 */       case 256: return Messages.RemoteSyncElement_outgoing;
/*  74 */       case 512: return Messages.RemoteSyncElement_incoming; }
/*     */     
/*  76 */     return "";
/*     */   }
/*     */   
/*     */   public static String diffStatusToString(int status) {
/*  80 */     int kind = status & 0xFF;
/*  81 */     String label = diffKindToString(kind);
/*  82 */     int direction = status & 0x300;
/*  83 */     if (direction != 0)
/*  84 */       label = NLS.bind(Messages.concatStrings, (Object[])new String[] { diffDirectionToString(direction), label }); 
/*  85 */     return label;
/*     */   }
/*     */   
/*     */   public static int asDiffFlags(int syncInfoFlags) {
/*  89 */     if (syncInfoFlags == 0)
/*  90 */       return 0; 
/*  91 */     int kind = SyncInfo.getChange(syncInfoFlags);
/*  92 */     int diffFlags = 0;
/*  93 */     switch (kind) {
/*     */       case 1:
/*  95 */         diffFlags = 1;
/*     */         break;
/*     */       case 2:
/*  98 */         diffFlags = 2;
/*     */         break;
/*     */       case 3:
/* 101 */         diffFlags = 4;
/*     */         break;
/*     */     } 
/* 104 */     int direction = SyncInfo.getDirection(syncInfoFlags);
/* 105 */     switch (direction) {
/*     */       case 8:
/* 107 */         diffFlags |= 0x200;
/*     */         break;
/*     */       case 4:
/* 110 */         diffFlags |= 0x100;
/*     */         break;
/*     */       case 12:
/* 113 */         diffFlags |= 0x300;
/*     */         break;
/*     */     } 
/* 116 */     return diffFlags;
/*     */   }
/*     */   
/*     */   private static int asSyncInfoKind(IThreeWayDiff diff) {
/* 120 */     int kind = diff.getKind();
/* 121 */     if (diff.getKind() == 0)
/* 122 */       return 0; 
/* 123 */     int syncKind = 0;
/* 124 */     switch (kind) {
/*     */       case 1:
/* 126 */         syncKind = 1;
/*     */         break;
/*     */       case 2:
/* 129 */         syncKind = 2;
/*     */         break;
/*     */       case 4:
/* 132 */         syncKind = 3;
/*     */         break;
/*     */     } 
/* 135 */     int direction = diff.getDirection();
/* 136 */     switch (direction) {
/*     */       case 512:
/* 138 */         syncKind |= 0x8;
/*     */         break;
/*     */       case 256:
/* 141 */         syncKind |= 0x4;
/*     */         break;
/*     */       case 768:
/* 144 */         syncKind |= 0xC;
/*     */         break;
/*     */     } 
/* 147 */     return syncKind;
/*     */   }
/*     */   
/*     */   public IDiff getDeltaFor(SyncInfo info) {
/* 151 */     if (info.getComparator().isThreeWay()) {
/* 152 */       ITwoWayDiff local = getLocalDelta(info);
/* 153 */       ITwoWayDiff remote = getRemoteDelta(info);
/* 154 */       return (IDiff)new ThreeWayDiff(local, remote);
/*     */     } 
/* 156 */     if (info.getKind() != 0) {
/* 157 */       int kind; IResourceVariant remote = info.getRemote();
/* 158 */       IResource local = info.getLocal();
/*     */       
/* 160 */       if (remote == null) {
/* 161 */         kind = 2;
/* 162 */       } else if (!local.exists()) {
/* 163 */         kind = 1;
/*     */       } else {
/* 165 */         kind = 4;
/*     */       } 
/* 167 */       if (local.getType() == 1) {
/* 168 */         IFileRevision after = asFileState(remote);
/* 169 */         IFileRevision before = getFileRevisionFor((IFile)local);
/* 170 */         return (IDiff)new ResourceDiff(info.getLocal(), kind, 0, before, after);
/*     */       } 
/*     */       
/* 173 */       return (IDiff)new ResourceDiff(info.getLocal(), kind);
/*     */     } 
/* 175 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private ITwoWayDiff getRemoteDelta(SyncInfo info) {
/* 180 */     int direction = SyncInfo.getDirection(info.getKind());
/* 181 */     if (direction == 8 || direction == 12) {
/* 182 */       int kind; IResourceVariant ancestor = info.getBase();
/* 183 */       IResourceVariant remote = info.getRemote();
/*     */       
/* 185 */       if (ancestor == null) {
/* 186 */         kind = 1;
/* 187 */       } else if (remote == null) {
/* 188 */         kind = 2;
/*     */       } else {
/* 190 */         kind = 4;
/*     */       } 
/*     */       
/* 193 */       if (info.getLocal().getType() == 1) {
/* 194 */         IFileRevision before = asFileState(ancestor);
/* 195 */         IFileRevision after = asFileState(remote);
/* 196 */         return (ITwoWayDiff)new ResourceDiff(info.getLocal(), kind, 0, before, after);
/*     */       } 
/*     */       
/* 199 */       return (ITwoWayDiff)new ResourceDiff(info.getLocal(), kind);
/*     */     } 
/* 201 */     return null;
/*     */   }
/*     */   
/*     */   private IFileRevision asFileState(IResourceVariant variant) {
/* 205 */     if (variant == null)
/* 206 */       return null; 
/* 207 */     return (IFileRevision)asFileRevision(variant);
/*     */   }
/*     */   
/*     */   private IFileRevision getFileRevisionFor(IFile file) {
/* 211 */     return (IFileRevision)new LocalFileRevision(file);
/*     */   }
/*     */   
/*     */   protected ResourceVariantFileRevision asFileRevision(IResourceVariant variant) {
/* 215 */     return new ResourceVariantFileRevision(variant);
/*     */   }
/*     */   
/*     */   private ITwoWayDiff getLocalDelta(SyncInfo info) {
/* 219 */     int direction = SyncInfo.getDirection(info.getKind());
/* 220 */     if (direction == 4 || direction == 12) {
/* 221 */       int kind; IResourceVariant ancestor = info.getBase();
/* 222 */       IResource local = info.getLocal();
/*     */       
/* 224 */       if (ancestor == null) {
/* 225 */         kind = 1;
/* 226 */       } else if (!local.exists()) {
/* 227 */         kind = 2;
/*     */       } else {
/* 229 */         kind = 4;
/*     */       } 
/* 231 */       if (local.getType() == 1) {
/* 232 */         IFileRevision before = asFileState(ancestor);
/* 233 */         IFileRevision after = getFileRevisionFor((IFile)local);
/* 234 */         return (ITwoWayDiff)new ResourceDiff(info.getLocal(), kind, 0, before, after);
/*     */       } 
/*     */       
/* 237 */       return (ITwoWayDiff)new ResourceDiff(info.getLocal(), kind);
/*     */     } 
/*     */     
/* 240 */     return null;
/*     */   }
/*     */   
/*     */   public static IResourceVariant getRemoteVariant(IThreeWayDiff twd) {
/* 244 */     IFileRevision revision = getRemote(twd);
/* 245 */     if (revision != null)
/* 246 */       return asResourceVariant(revision); 
/* 247 */     return null;
/*     */   }
/*     */   
/*     */   public static IResourceVariant getBaseVariant(IThreeWayDiff twd) {
/* 251 */     IResourceDiff diff = (IResourceDiff)twd.getRemoteChange();
/* 252 */     if (diff != null)
/* 253 */       return asResourceVariant(diff.getBeforeState()); 
/* 254 */     diff = (IResourceDiff)twd.getLocalChange();
/* 255 */     if (diff != null)
/* 256 */       return asResourceVariant(diff.getBeforeState()); 
/* 257 */     return null;
/*     */   }
/*     */   
/*     */   public SyncInfo asSyncInfo(IDiff diff, IResourceVariantComparator comparator) {
/* 261 */     if (diff instanceof ResourceDiff) {
/* 262 */       int kind; ResourceDiff rd = (ResourceDiff)diff;
/* 263 */       IResource local = rd.getResource();
/* 264 */       IFileRevision afterState = rd.getAfterState();
/* 265 */       IResourceVariant remote = asResourceVariant(afterState);
/*     */       
/* 267 */       if (remote == null) {
/* 268 */         kind = 2;
/* 269 */       } else if (!local.exists()) {
/* 270 */         kind = 1;
/*     */       } else {
/* 272 */         kind = 3;
/*     */       } 
/* 274 */       SyncInfo info = createSyncInfo(comparator, kind, local, null, remote);
/* 275 */       return info;
/* 276 */     }  if (diff instanceof IThreeWayDiff) {
/* 277 */       IThreeWayDiff twd = (IThreeWayDiff)diff;
/* 278 */       IResource local = getLocal(twd);
/* 279 */       if (local != null) {
/* 280 */         IResourceVariant remote = getRemoteVariant(twd);
/* 281 */         IResourceVariant base = getBaseVariant(twd);
/* 282 */         int kind = asSyncInfoKind(twd);
/* 283 */         SyncInfo info = createSyncInfo(comparator, kind, local, base, remote);
/* 284 */         return info;
/*     */       } 
/*     */     } 
/* 287 */     return null;
/*     */   }
/*     */   
/*     */   protected SyncInfo createSyncInfo(IResourceVariantComparator comparator, int kind, IResource local, IResourceVariant base, IResourceVariant remote) {
/* 291 */     PrecalculatedSyncInfo info = new PrecalculatedSyncInfo(kind, local, base, remote, comparator);
/*     */     try {
/* 293 */       info.init();
/* 294 */     } catch (TeamException teamException) {}
/*     */ 
/*     */     
/* 297 */     return info;
/*     */   }
/*     */   
/*     */   private static IResource getLocal(IThreeWayDiff twd) {
/* 301 */     IResourceDiff diff = (IResourceDiff)twd.getRemoteChange();
/* 302 */     if (diff != null)
/* 303 */       return diff.getResource(); 
/* 304 */     diff = (IResourceDiff)twd.getLocalChange();
/* 305 */     if (diff != null)
/* 306 */       return diff.getResource(); 
/* 307 */     return null;
/*     */   }
/*     */   
/*     */   public static IResourceVariant asResourceVariant(IFileRevision revision) {
/* 311 */     if (revision == null)
/* 312 */       return null; 
/* 313 */     if (revision instanceof ResourceVariantFileRevision) {
/* 314 */       ResourceVariantFileRevision rvfr = (ResourceVariantFileRevision)revision;
/* 315 */       return rvfr.getVariant();
/*     */     } 
/* 317 */     if (revision instanceof IAdaptable) {
/* 318 */       IAdaptable adaptable = (IAdaptable)revision;
/* 319 */       Object o = adaptable.getAdapter(IResourceVariant.class);
/* 320 */       if (o instanceof IResourceVariant) {
/* 321 */         return (IResourceVariant)o;
/*     */       }
/*     */     } 
/* 324 */     return null;
/*     */   }
/*     */   
/*     */   public static IFileRevision getRemote(IDiff diff) {
/* 328 */     if (diff instanceof IResourceDiff) {
/* 329 */       IResourceDiff rd = (IResourceDiff)diff;
/* 330 */       return rd.getAfterState();
/*     */     } 
/* 332 */     if (diff instanceof IThreeWayDiff) {
/* 333 */       IThreeWayDiff twd = (IThreeWayDiff)diff;
/* 334 */       return getRemote(twd);
/*     */     } 
/* 336 */     return null;
/*     */   }
/*     */   
/*     */   public static IFileRevision getRemote(IThreeWayDiff twd) {
/* 340 */     IResourceDiff rd = (IResourceDiff)twd.getRemoteChange();
/* 341 */     if (rd != null)
/* 342 */       return rd.getAfterState(); 
/* 343 */     rd = (IResourceDiff)twd.getLocalChange();
/* 344 */     if (rd != null)
/* 345 */       return rd.getBeforeState(); 
/* 346 */     return null;
/*     */   }
/*     */   
/*     */   public static SyncInfoToDiffConverter getDefault() {
/* 350 */     if (instance == null)
/* 351 */       instance = new SyncInfoToDiffConverter(); 
/* 352 */     return instance;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\SyncInfoToDiffConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */