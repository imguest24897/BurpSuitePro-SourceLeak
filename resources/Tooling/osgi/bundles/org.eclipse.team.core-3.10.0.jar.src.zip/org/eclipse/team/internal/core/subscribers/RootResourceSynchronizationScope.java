/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*     */ import org.eclipse.core.resources.mapping.ResourceMappingContext;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScope;
/*     */ import org.eclipse.team.internal.core.mapping.AbstractResourceMappingScope;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RootResourceSynchronizationScope
/*     */   extends AbstractResourceMappingScope
/*     */ {
/*     */   private IResource[] roots;
/*     */   
/*     */   public RootResourceSynchronizationScope(IResource[] roots) {
/*  36 */     this.roots = roots;
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceTraversal[] getTraversals() {
/*  41 */     return new ResourceTraversal[] { new ResourceTraversal(this.roots, 2, 0) };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRoots(IResource[] roots) {
/*  50 */     this.roots = roots;
/*  51 */     fireTraversalsChangedEvent(getTraversals(), getMappings());
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceMapping[] getInputMappings() {
/*  56 */     return getMappings();
/*     */   }
/*     */ 
/*     */   
/*     */   public ISynchronizationScope asInputScope() {
/*  61 */     return (ISynchronizationScope)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceMapping[] getMappings() {
/*  66 */     List<ResourceMapping> result = new ArrayList<>(); byte b; int i; IResource[] arrayOfIResource;
/*  67 */     for (i = (arrayOfIResource = this.roots).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/*  68 */       Object o = resource.getAdapter(ResourceMapping.class);
/*  69 */       if (o instanceof ResourceMapping)
/*  70 */         result.add((ResourceMapping)o); 
/*     */       b++; }
/*     */     
/*  73 */     return result.<ResourceMapping>toArray(new ResourceMapping[result.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceTraversal[] getTraversals(ResourceMapping mapping) {
/*  78 */     Object object = mapping.getModelObject();
/*  79 */     if (object instanceof IResource) {
/*  80 */       IResource resource = (IResource)object;
/*  81 */       return new ResourceTraversal[] { new ResourceTraversal(new IResource[] { resource }, 2, 0) };
/*     */     } 
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAdditionalMappings() {
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAdditonalResources() {
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public IProject[] getProjects() {
/*  98 */     return ResourcesPlugin.getWorkspace().getRoot().getProjects();
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceMappingContext getContext() {
/* 103 */     return ResourceMappingContext.LOCAL_CONTEXT;
/*     */   }
/*     */   
/*     */   public void refresh(ResourceMapping[] mappings) {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\RootResourceSynchronizationScope.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */