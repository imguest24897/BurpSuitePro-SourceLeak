/*     */ package org.eclipse.team.internal.core.history;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IFileState;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.core.history.IFileRevision;
/*     */ import org.eclipse.team.core.history.provider.FileHistory;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalFileHistory
/*     */   extends FileHistory
/*     */ {
/*     */   protected IFile file;
/*     */   protected IFileRevision[] revisions;
/*     */   private final boolean includeCurrent;
/*     */   
/*     */   public LocalFileHistory(IFile file, boolean includeCurrent) {
/*  38 */     this.file = file;
/*  39 */     this.includeCurrent = includeCurrent;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileRevision[] getContributors(IFileRevision revision) {
/*  45 */     IFileRevision[] revisions = getFileRevisions();
/*     */ 
/*     */ 
/*     */     
/*  49 */     IFileRevision fileRevision = null; byte b; int i; IFileRevision[] arrayOfIFileRevision1;
/*  50 */     for (i = (arrayOfIFileRevision1 = revisions).length, b = 0; b < i; ) { IFileRevision r = arrayOfIFileRevision1[b];
/*  51 */       if (((LocalFileRevision)r).isPredecessorOf(revision)) {
/*     */         
/*  53 */         if (fileRevision == null) {
/*  54 */           fileRevision = r;
/*     */         }
/*     */ 
/*     */         
/*  58 */         if (fileRevision != null && r.getTimestamp() > fileRevision.getTimestamp())
/*  59 */           fileRevision = r; 
/*     */       } 
/*     */       b++; }
/*     */     
/*  63 */     if (fileRevision == null)
/*  64 */       return new IFileRevision[0]; 
/*  65 */     return new IFileRevision[] { fileRevision };
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileRevision getFileRevision(String id) {
/*  70 */     if (this.revisions != null) {
/*  71 */       byte b; int i; IFileRevision[] arrayOfIFileRevision; for (i = (arrayOfIFileRevision = this.revisions).length, b = 0; b < i; ) { IFileRevision revision = arrayOfIFileRevision[b];
/*  72 */         if (revision.getContentIdentifier().equals(id))
/*  73 */           return revision; 
/*     */         b++; }
/*     */     
/*     */     } 
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileRevision[] getFileRevisions() {
/*  82 */     if (this.revisions == null)
/*  83 */       return new IFileRevision[0]; 
/*  84 */     return this.revisions;
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileRevision[] getTargets(IFileRevision revision) {
/*  89 */     IFileRevision[] revisions = getFileRevisions();
/*  90 */     ArrayList<IFileRevision> directDescendents = new ArrayList<>(); byte b; int i;
/*     */     IFileRevision[] arrayOfIFileRevision1;
/*  92 */     for (i = (arrayOfIFileRevision1 = revisions).length, b = 0; b < i; ) { IFileRevision r = arrayOfIFileRevision1[b];
/*  93 */       if (((LocalFileRevision)r).isDescendentOf(revision))
/*  94 */         directDescendents.add(r); 
/*     */       b++; }
/*     */     
/*  97 */     return directDescendents.<IFileRevision>toArray(new IFileRevision[directDescendents.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh(IProgressMonitor monitor) throws TeamException {
/* 107 */     monitor.beginTask(Messages.LocalFileHistory_RefreshLocalHistory, 300);
/*     */     
/*     */     try {
/* 110 */       LocalFileRevision currentRevision = 
/* 111 */         includeRevisionForFile() ? new LocalFileRevision(this.file) : null;
/* 112 */       IFileState[] fileStates = this.file.getHistory(monitor);
/* 113 */       int numRevisions = fileStates.length + ((currentRevision != null) ? 1 : 0);
/* 114 */       this.revisions = (IFileRevision[])new LocalFileRevision[numRevisions];
/* 115 */       for (int i = 0; i < fileStates.length; i++) {
/* 116 */         this.revisions[i] = (IFileRevision)new LocalFileRevision(fileStates[i]);
/*     */       }
/* 118 */       if (currentRevision != null)
/* 119 */         this.revisions[fileStates.length] = (IFileRevision)currentRevision; 
/* 120 */     } catch (CoreException e) {
/* 121 */       throw TeamException.asTeamException(e);
/*     */     } finally {
/* 123 */       monitor.done();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean includeRevisionForFile() {
/* 128 */     return (this.file.exists() && this.includeCurrent);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\history\LocalFileHistory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */