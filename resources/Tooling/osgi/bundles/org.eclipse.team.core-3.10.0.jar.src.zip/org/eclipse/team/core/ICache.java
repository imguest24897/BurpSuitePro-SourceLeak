package org.eclipse.team.core;

public interface ICache {
  void put(String paramString, Object paramObject);
  
  Object get(String paramString);
  
  void remove(String paramString);
  
  void addCacheListener(ICacheListener paramICacheListener);
  
  void removeCacheListener(ICacheListener paramICacheListener);
  
  @Deprecated
  void removeDisposeListener(ICacheListener paramICacheListener);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\ICache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */