/*    */ package org.eclipse.team.internal.core;
/*    */ 
/*    */ import org.eclipse.core.text.StringMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WildcardStringMatcher
/*    */ {
/*    */   private final StringMatcher fMatcher;
/*    */   private final boolean fPathPattern;
/*    */   
/*    */   public WildcardStringMatcher(String pattern) {
/* 45 */     this.fMatcher = new StringMatcher(pattern, true, false);
/* 46 */     this.fPathPattern = (pattern.indexOf('/') != -1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isPathPattern() {
/* 55 */     return this.fPathPattern;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean match(String text) {
/* 67 */     return this.fMatcher.match(text);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\WildcardStringMatcher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */