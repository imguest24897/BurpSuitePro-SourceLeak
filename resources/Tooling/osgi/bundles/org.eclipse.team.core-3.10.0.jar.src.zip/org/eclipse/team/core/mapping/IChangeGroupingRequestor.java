package org.eclipse.team.core.mapping;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;

public interface IChangeGroupingRequestor {
  void ensureChangesGrouped(IProject paramIProject, IFile[] paramArrayOfIFile, String paramString) throws CoreException;
  
  boolean isModified(IFile paramIFile) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\IChangeGroupingRequestor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */