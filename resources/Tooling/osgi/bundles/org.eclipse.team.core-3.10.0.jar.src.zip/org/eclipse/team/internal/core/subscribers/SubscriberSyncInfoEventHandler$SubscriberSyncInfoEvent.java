/*    */ package org.eclipse.team.internal.core.subscribers;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.team.core.synchronize.SyncInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SubscriberSyncInfoEvent
/*    */   extends SubscriberEventHandler.SubscriberEvent
/*    */ {
/*    */   private final SyncInfo result;
/*    */   
/*    */   public SubscriberSyncInfoEvent(IResource resource, int type, int depth, SyncInfo result) {
/* 48 */     super(resource, type, depth);
/* 49 */     this.result = result;
/*    */   }
/*    */   public SyncInfo getResult() {
/* 52 */     return this.result;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SubscriberSyncInfoEventHandler$SubscriberSyncInfoEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */