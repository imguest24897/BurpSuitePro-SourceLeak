/*     */ package org.eclipse.team.internal.core;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.StringTokenizer;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.mapping.IStorageMerger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StorageMergerRegistry
/*     */ {
/*     */   private static final String ID_ATTRIBUTE = "id";
/*     */   private static final String EXTENSIONS_ATTRIBUTE = "extensions";
/*     */   private static final String CONTENT_TYPE_ID_ATTRIBUTE = "contentTypeId";
/*     */   private static final String STORAGE_MERGER_EXTENSION_POINT = "storageMergers";
/*  33 */   private static final Object STORAGE_MERGER = "storageMerger";
/*     */   
/*     */   private static final String CONTENT_TYPE_BINDING = "contentTypeBinding";
/*     */   
/*     */   private static final String STORAGE_MERGER_ID_ATTRIBUTE = "storageMergerId";
/*     */   
/*     */   private static boolean NORMALIZE_CASE = true;
/*     */   private static StorageMergerRegistry instance;
/*     */   private HashMap<String, Object> fIdMap;
/*     */   private HashMap<String, Object> fExtensionMap;
/*     */   private HashMap<IContentType, Object> fContentTypeBindings;
/*     */   private boolean fRegistriesInitialized;
/*     */   
/*     */   public static StorageMergerRegistry getInstance() {
/*  47 */     if (instance == null) {
/*  48 */       instance = new StorageMergerRegistry();
/*     */     }
/*  50 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStorageMerger createStreamMerger(String type) {
/*  61 */     initializeRegistry();
/*  62 */     StorageMergerDescriptor descriptor = (StorageMergerDescriptor)search(type);
/*  63 */     if (descriptor != null)
/*  64 */       return descriptor.createStreamMerger(); 
/*  65 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStorageMerger createStreamMerger(IContentType type) {
/*  76 */     initializeRegistry();
/*  77 */     StorageMergerDescriptor descriptor = (StorageMergerDescriptor)search(type);
/*  78 */     if (descriptor != null)
/*  79 */       return descriptor.createStreamMerger(); 
/*  80 */     return null;
/*     */   }
/*     */   
/*     */   private void initializeRegistry() {
/*  84 */     if (!this.fRegistriesInitialized) {
/*  85 */       registerExtensions();
/*  86 */       this.fRegistriesInitialized = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerExtensions() {
/*  95 */     IExtensionRegistry registry = Platform.getExtensionRegistry();
/*     */ 
/*     */     
/*  98 */     IConfigurationElement[] elements = registry.getConfigurationElementsFor("org.eclipse.team.core", "storageMergers"); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/*  99 */     for (i = (arrayOfIConfigurationElement1 = elements).length, b = 0; b < i; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b];
/* 100 */       if (STORAGE_MERGER.equals(element.getName())) {
/* 101 */         register(element, new StorageMergerDescriptor(element));
/* 102 */       } else if ("contentTypeBinding".equals(element.getName())) {
/* 103 */         createBinding(element, "storageMergerId");
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   } private static String normalizeCase(String s) {
/* 108 */     if (NORMALIZE_CASE && s != null)
/* 109 */       return s.toUpperCase(); 
/* 110 */     return s;
/*     */   }
/*     */   
/*     */   void register(IConfigurationElement element, Object data) {
/* 114 */     String id = element.getAttribute("id");
/* 115 */     if (id != null) {
/* 116 */       if (this.fIdMap == null)
/* 117 */         this.fIdMap = new HashMap<>(); 
/* 118 */       this.fIdMap.put(id, data);
/*     */     } 
/*     */     
/* 121 */     String types = element.getAttribute("extensions");
/* 122 */     if (types != null) {
/* 123 */       if (this.fExtensionMap == null)
/* 124 */         this.fExtensionMap = new HashMap<>(); 
/* 125 */       StringTokenizer tokenizer = new StringTokenizer(types, ",");
/* 126 */       while (tokenizer.hasMoreElements()) {
/* 127 */         String extension = tokenizer.nextToken().trim();
/* 128 */         this.fExtensionMap.put(normalizeCase(extension), data);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void createBinding(IConfigurationElement element, String idAttributeName) {
/* 134 */     String type = element.getAttribute("contentTypeId");
/* 135 */     String id = element.getAttribute(idAttributeName);
/* 136 */     if (id == null)
/* 137 */       logErrorMessage(NLS.bind("Target attribute id '{0}' missing", idAttributeName)); 
/* 138 */     if (type != null && id != null && this.fIdMap != null) {
/* 139 */       Object o = this.fIdMap.get(id);
/* 140 */       if (o != null) {
/* 141 */         IContentType ct = Platform.getContentTypeManager().getContentType(type);
/* 142 */         if (ct != null) {
/* 143 */           if (this.fContentTypeBindings == null)
/* 144 */             this.fContentTypeBindings = new HashMap<>(); 
/* 145 */           this.fContentTypeBindings.put(ct, o);
/*     */         } else {
/* 147 */           logErrorMessage(NLS.bind("Content type id '{0}' not found", type));
/*     */         } 
/*     */       } else {
/* 150 */         logErrorMessage(NLS.bind("Target '{0}' not found", id));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void logErrorMessage(String string) {
/* 156 */     TeamPlugin.log(4, string, null);
/*     */   }
/*     */   
/*     */   Object search(IContentType type) {
/* 160 */     if (this.fContentTypeBindings != null)
/* 161 */       for (; type != null; type = type.getBaseType()) {
/* 162 */         Object data = this.fContentTypeBindings.get(type);
/* 163 */         if (data != null) {
/* 164 */           return data;
/*     */         }
/*     */       }  
/* 167 */     return null;
/*     */   }
/*     */   
/*     */   Object search(String extension) {
/* 171 */     if (this.fExtensionMap != null)
/* 172 */       return this.fExtensionMap.get(normalizeCase(extension)); 
/* 173 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\StorageMergerRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */