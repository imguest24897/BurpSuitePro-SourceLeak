package org.eclipse.team.core.synchronize;

import org.eclipse.core.resources.IResource;

public interface ISyncInfoSetChangeEvent {
  SyncInfo[] getAddedResources();
  
  SyncInfo[] getChangedResources();
  
  IResource[] getRemovedResources();
  
  SyncInfoSet getSet();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\synchronize\ISyncInfoSetChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */