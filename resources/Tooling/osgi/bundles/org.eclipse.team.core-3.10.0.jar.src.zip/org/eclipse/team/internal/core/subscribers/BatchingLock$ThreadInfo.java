/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.core.runtime.jobs.MultiRule;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThreadInfo
/*     */ {
/*  63 */   private Set<IResource> changedResources = new HashSet<>();
/*     */   private BatchingLock.IFlushOperation operation;
/*  65 */   private List<ISchedulingRule> rules = new ArrayList<>();
/*     */   public ThreadInfo(BatchingLock.IFlushOperation operation) {
/*  67 */     this.operation = operation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule pushRule(ISchedulingRule resource, IProgressMonitor monitor) {
/*  78 */     ISchedulingRule rule = getRuleForResoure(resource);
/*  79 */     if (rule != BatchingLock.NULL_SCHEDULING_RULE) {
/*  80 */       boolean success = false;
/*     */       try {
/*  82 */         Job.getJobManager().beginRule(rule, monitor);
/*  83 */         addRule(rule);
/*  84 */         success = true;
/*     */       } finally {
/*  86 */         if (!success) {
/*     */           
/*     */           try {
/*     */ 
/*     */ 
/*     */             
/*  92 */             Job.getJobManager().endRule(rule);
/*  93 */           } catch (RuntimeException e) {
/*     */             
/*  95 */             TeamPlugin.log(4, "Failed to end scheduling rule", e);
/*     */           }
/*     */         
/*     */         }
/*     */       } 
/*     */     } else {
/*     */       
/* 102 */       addRule(rule);
/*     */     } 
/* 104 */     return rule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void popRule(ISchedulingRule rule, IProgressMonitor monitor) throws TeamException {
/*     */     ISchedulingRule stackedRule;
/*     */     try {
/* 118 */       if (isFlushRequired()) {
/* 119 */         flush(monitor);
/*     */       }
/*     */     } finally {
/* 122 */       ISchedulingRule iSchedulingRule = removeRule();
/* 123 */       if (rule == null) {
/* 124 */         rule = BatchingLock.NULL_SCHEDULING_RULE;
/*     */       }
/* 126 */       Assert.isTrue(iSchedulingRule.equals(rule), "end for resource '" + rule + "' does not match stacked rule '" + iSchedulingRule + "'");
/* 127 */       if (rule != BatchingLock.NULL_SCHEDULING_RULE)
/* 128 */         Job.getJobManager().endRule(rule); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private ISchedulingRule getRuleForResoure(ISchedulingRule resourceRule) {
/*     */     ISchedulingRule rule;
/* 134 */     if (resourceRule instanceof IResource) {
/* 135 */       IResource resource = (IResource)resourceRule;
/* 136 */       if (resource.getType() == 8) {
/*     */         
/* 138 */         rule = BatchingLock.NULL_SCHEDULING_RULE;
/* 139 */       } else if (resource.getType() == 4) {
/* 140 */         IResource iResource = resource;
/*     */       } else {
/* 142 */         IContainer iContainer = resource.getParent();
/*     */       } 
/* 144 */     } else if (resourceRule instanceof MultiRule) {
/*     */       
/* 146 */       ISchedulingRule[] rules = ((MultiRule)resourceRule).getChildren();
/* 147 */       Set<ISchedulingRule> projects = new HashSet<>(); byte b; int i; ISchedulingRule[] arrayOfISchedulingRule1;
/* 148 */       for (i = (arrayOfISchedulingRule1 = rules).length, b = 0; b < i; ) { ISchedulingRule childRule = arrayOfISchedulingRule1[b];
/* 149 */         if (childRule instanceof IResource)
/* 150 */           projects.add(((IResource)childRule).getProject()); 
/*     */         b++; }
/*     */       
/* 153 */       if (projects.isEmpty()) {
/* 154 */         rule = BatchingLock.NULL_SCHEDULING_RULE;
/* 155 */       } else if (projects.size() == 1) {
/* 156 */         rule = projects.iterator().next();
/*     */       } else {
/* 158 */         MultiRule multiRule = new MultiRule(projects.<ISchedulingRule>toArray(new ISchedulingRule[projects.size()]));
/*     */       } 
/*     */     } else {
/*     */       
/* 162 */       rule = BatchingLock.NULL_SCHEDULING_RULE;
/*     */     } 
/* 164 */     return rule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNested() {
/* 173 */     return !this.rules.isEmpty();
/*     */   }
/*     */   public void addChangedResource(IResource resource) {
/* 176 */     this.changedResources.add(resource);
/*     */   }
/*     */   public boolean isEmpty() {
/* 179 */     return this.changedResources.isEmpty();
/*     */   }
/*     */   public IResource[] getChangedResources() {
/* 182 */     return this.changedResources.<IResource>toArray(new IResource[this.changedResources.size()]);
/*     */   }
/*     */   public void flush(IProgressMonitor monitor) throws TeamException {
/*     */     try {
/* 186 */       this.operation.flush(this, monitor);
/* 187 */     } catch (OutOfMemoryError e) {
/* 188 */       throw e;
/* 189 */     } catch (Error e) {
/* 190 */       handleAbortedFlush(e);
/* 191 */       throw e;
/* 192 */     } catch (RuntimeException e) {
/* 193 */       handleAbortedFlush(e);
/* 194 */       throw e;
/*     */     }
/*     */     finally {
/*     */       
/* 198 */       this.changedResources.clear();
/*     */     } 
/*     */   }
/*     */   private boolean isFlushRequired() {
/* 202 */     return !(this.rules.size() != 1 && !remainingRulesAreNull());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean remainingRulesAreNull() {
/* 208 */     for (int i = 0; i < this.rules.size() - 1; i++) {
/* 209 */       ISchedulingRule rule = this.rules.get(i);
/* 210 */       if (rule != BatchingLock.NULL_SCHEDULING_RULE) {
/* 211 */         return false;
/*     */       }
/*     */     } 
/* 214 */     return true;
/*     */   }
/*     */   private void handleAbortedFlush(Throwable t) {
/* 217 */     TeamPlugin.log(4, Messages.BatchingLock_11, t);
/*     */   }
/*     */   private void addRule(ISchedulingRule rule) {
/* 220 */     this.rules.add(rule);
/*     */   }
/*     */   private ISchedulingRule removeRule() {
/* 223 */     return this.rules.remove(this.rules.size() - 1);
/*     */   }
/*     */   public boolean ruleContains(IResource resource) {
/* 226 */     for (ISchedulingRule rule : this.rules) {
/* 227 */       if (rule != BatchingLock.NULL_SCHEDULING_RULE && rule.contains((ISchedulingRule)resource)) {
/* 228 */         return true;
/*     */       }
/*     */     } 
/* 231 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\BatchingLock$ThreadInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */