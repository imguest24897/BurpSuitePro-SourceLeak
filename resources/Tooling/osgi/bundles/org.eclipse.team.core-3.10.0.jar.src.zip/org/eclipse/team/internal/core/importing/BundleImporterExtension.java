/*     */ package org.eclipse.team.internal.core.importing;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.team.core.RepositoryProviderType;
/*     */ import org.eclipse.team.core.ScmUrlImportDescription;
/*     */ import org.eclipse.team.core.importing.provisional.BundleImporterDelegate;
/*     */ import org.eclipse.team.core.importing.provisional.IBundleImporter;
/*     */ import org.eclipse.team.core.importing.provisional.IBundleImporterDelegate;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BundleImporterExtension
/*     */   implements IBundleImporter
/*     */ {
/*     */   private IBundleImporterDelegate delegate;
/*     */   private IConfigurationElement element;
/*     */   
/*     */   public BundleImporterExtension(IConfigurationElement element) {
/*  47 */     this.element = element;
/*     */   }
/*     */ 
/*     */   
/*     */   public ScmUrlImportDescription[] validateImport(Map[] manifests) {
/*     */     try {
/*  53 */       return getDelegate().validateImport(manifests);
/*  54 */     } catch (CoreException e) {
/*  55 */       TeamPlugin.log(e);
/*  56 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized IBundleImporterDelegate getDelegate() throws CoreException {
/*  67 */     if (this.delegate == null) {
/*  68 */       this.delegate = (IBundleImporterDelegate)new BundleImporterDelegate() {
/*     */           private Set<String> supportedValues;
/*     */           private RepositoryProviderType providerType;
/*     */           
/*     */           protected Set getSupportedValues() {
/*  73 */             if (this.supportedValues == null) {
/*  74 */               IConfigurationElement[] supported = BundleImporterExtension.this.element.getChildren("supports");
/*  75 */               this.supportedValues = new HashSet<>(supported.length); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/*  76 */               for (i = (arrayOfIConfigurationElement1 = supported).length, b = 0; b < i; ) { IConfigurationElement s = arrayOfIConfigurationElement1[b];
/*  77 */                 this.supportedValues.add(s.getAttribute("prefix")); b++; }
/*     */             
/*     */             } 
/*  80 */             return this.supportedValues;
/*     */           }
/*     */           
/*     */           protected RepositoryProviderType getProviderType() {
/*  84 */             if (this.providerType == null)
/*  85 */               this.providerType = RepositoryProviderType.getProviderType(BundleImporterExtension.this.element.getAttribute("repository")); 
/*  86 */             return this.providerType;
/*     */           }
/*     */         };
/*     */     }
/*  90 */     return this.delegate;
/*     */   }
/*     */ 
/*     */   
/*     */   public IProject[] performImport(ScmUrlImportDescription[] descriptions, IProgressMonitor monitor) throws CoreException {
/*  95 */     return getDelegate().performImport(descriptions, monitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getId() {
/* 100 */     return this.element.getAttribute("id");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 105 */     return this.element.getAttribute("description");
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 110 */     return this.element.getAttribute("name");
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\importing\BundleImporterExtension.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */