/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.team.core.diff.IDiff;
/*     */ import org.eclipse.team.core.mapping.IResourceDiffTree;
/*     */ import org.eclipse.team.core.mapping.provider.ResourceDiffTree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiffChangeSet
/*     */   extends ChangeSet
/*     */ {
/*  24 */   private final ResourceDiffTree tree = new ResourceDiffTree();
/*     */ 
/*     */   
/*     */   public DiffChangeSet() {}
/*     */ 
/*     */   
/*     */   public DiffChangeSet(String name) {
/*  31 */     super(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResourceDiffTree getDiffTree() {
/*  39 */     return (IResourceDiffTree)this.tree;
/*     */   }
/*     */   
/*     */   protected ResourceDiffTree internalGetDiffTree() {
/*  43 */     return this.tree;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource[] getResources() {
/*  52 */     return this.tree.getAffectedResources();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  61 */     return this.tree.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(IResource local) {
/*  71 */     return (this.tree.getDiff(local) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(IDiff diff) {
/*  80 */     if (isValidChange(diff)) {
/*  81 */       this.tree.add(diff);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isValidChange(IDiff diff) {
/*  93 */     return (diff != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(IDiff[] diffs) {
/*     */     try {
/* 103 */       this.tree.beginInput(); byte b; int i; IDiff[] arrayOfIDiff;
/* 104 */       for (i = (arrayOfIDiff = diffs).length, b = 0; b < i; ) { IDiff diff = arrayOfIDiff[b];
/* 105 */         add(diff); b++; }
/*     */     
/*     */     } finally {
/* 108 */       this.tree.endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(IResource resource) {
/* 118 */     if (contains(resource)) {
/* 119 */       this.tree.remove(resource);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rootRemoved(IResource resource, int depth) {
/* 131 */     IDiff[] diffs = this.tree.getDiffs(resource, depth);
/* 132 */     if (diffs.length > 0) {
/*     */       try {
/* 134 */         this.tree.beginInput(); byte b; int i; IDiff[] arrayOfIDiff;
/* 135 */         for (i = (arrayOfIDiff = diffs).length, b = 0; b < i; ) { IDiff diff = arrayOfIDiff[b];
/* 136 */           IResource r = this.tree.getResource(diff);
/* 137 */           if (r != null)
/* 138 */             this.tree.remove(r);  b++; }
/*     */       
/*     */       } finally {
/* 141 */         this.tree.endInput(null);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean contains(IPath path) {
/* 147 */     return (getDiffTree().getDiff(path) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsChildren(IResource resource, int depth) {
/* 152 */     return ((getDiffTree().getDiffs(resource, depth)).length > 0);
/*     */   }
/*     */   
/*     */   public void remove(IPath[] paths) {
/*     */     try {
/* 157 */       this.tree.beginInput(); byte b; int i; IPath[] arrayOfIPath;
/* 158 */       for (i = (arrayOfIPath = paths).length, b = 0; b < i; ) { IPath path = arrayOfIPath[b];
/* 159 */         this.tree.remove(path); b++; }
/*     */     
/*     */     } finally {
/* 162 */       this.tree.endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(IResource[] resources) {
/*     */     try {
/* 169 */       this.tree.beginInput(); byte b; int i; IResource[] arrayOfIResource;
/* 170 */       for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/* 171 */         this.tree.remove(resource); b++; }
/*     */     
/*     */     } finally {
/* 174 */       this.tree.endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getComment() {
/* 180 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\DiffChangeSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */