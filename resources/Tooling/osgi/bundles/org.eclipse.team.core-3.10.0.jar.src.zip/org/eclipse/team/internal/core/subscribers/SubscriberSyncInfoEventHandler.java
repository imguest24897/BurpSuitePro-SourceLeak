/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.SubProgressMonitor;
/*     */ import org.eclipse.team.core.ITeamStatus;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.core.TeamStatus;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScope;
/*     */ import org.eclipse.team.core.subscribers.Subscriber;
/*     */ import org.eclipse.team.core.synchronize.SyncInfo;
/*     */ import org.eclipse.team.core.synchronize.SyncInfoSet;
/*     */ import org.eclipse.team.internal.core.BackgroundEventHandler;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubscriberSyncInfoEventHandler
/*     */   extends SubscriberEventHandler
/*     */ {
/*     */   private final SyncSetInputFromSubscriber syncSetInput;
/*     */   
/*     */   private class SubscriberSyncInfoEvent
/*     */     extends SubscriberEventHandler.SubscriberEvent
/*     */   {
/*     */     private final SyncInfo result;
/*     */     
/*     */     public SubscriberSyncInfoEvent(IResource resource, int type, int depth, SyncInfo result) {
/*  48 */       super(resource, type, depth);
/*  49 */       this.result = result;
/*     */     }
/*     */     public SyncInfo getResult() {
/*  52 */       return this.result;
/*     */     }
/*     */   }
/*     */   
/*     */   public static ISynchronizationScope createScope(IResource[] roots, Subscriber subscriber) {
/*  57 */     if (roots == null)
/*  58 */       roots = subscriber.roots(); 
/*  59 */     return (ISynchronizationScope)new RootResourceSynchronizationScope(roots);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubscriberSyncInfoEventHandler(Subscriber subscriber, IResource[] roots) {
/*  69 */     super(subscriber, createScope(roots, subscriber));
/*  70 */     this.syncSetInput = new SyncSetInputFromSubscriber(subscriber, this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handleException(CoreException e, IResource resource, int code, String message) {
/*  75 */     super.handleException(e, resource, code, message);
/*  76 */     this.syncSetInput.handleError((ITeamStatus)new TeamStatus(4, "org.eclipse.team.core", code, message, (Throwable)e, resource));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handleCancel(OperationCanceledException e) {
/*  81 */     super.handleCancel(e);
/*  82 */     this.syncSetInput.handleError((ITeamStatus)new TeamStatus(4, "org.eclipse.team.core", 3, Messages.SubscriberEventHandler_12, (Throwable)e, (IResource)ResourcesPlugin.getWorkspace().getRoot()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SyncSetInputFromSubscriber getSyncSetInput() {
/*  90 */     return this.syncSetInput;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handleChange(IResource resource) throws TeamException {
/*  95 */     SyncInfo info = this.syncSetInput.getSubscriber().getSyncInfo(resource);
/*     */     
/*  97 */     if (info == null) {
/*  98 */       queueDispatchEvent(
/*  99 */           (BackgroundEventHandler.Event)new SubscriberEventHandler.SubscriberEvent(this, resource, 1, 0));
/*     */     } else {
/* 101 */       queueDispatchEvent(
/* 102 */           (BackgroundEventHandler.Event)new SubscriberSyncInfoEvent(resource, 2, 0, info));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void collectAll(IResource resource, int depth, IProgressMonitor monitor) {
/* 112 */     monitor.beginTask(null, -1);
/*     */ 
/*     */     
/*     */     try {
/* 116 */       SubProgressMonitor subProgressMonitor = new SubProgressMonitor(monitor, -1) {
/*     */           boolean dispatching = false;
/*     */           
/*     */           public void subTask(String name) {
/* 120 */             dispatch();
/* 121 */             super.subTask(name);
/*     */           }
/*     */           private void dispatch() {
/* 124 */             if (this.dispatching)
/*     */               return;  try {
/* 126 */               this.dispatching = true;
/* 127 */               SubscriberSyncInfoEventHandler.this.handlePreemptiveEvents((IProgressMonitor)this);
/* 128 */               SubscriberSyncInfoEventHandler.this.handlePendingDispatch((IProgressMonitor)this);
/*     */             } finally {
/* 130 */               this.dispatching = false;
/*     */             } 
/*     */           }
/*     */           
/*     */           public void worked(int work) {
/* 135 */             dispatch();
/* 136 */             super.worked(work);
/*     */           }
/*     */         };
/*     */ 
/*     */       
/* 141 */       SyncInfoSet collectionSet = new SyncInfoSet()
/*     */         {
/*     */           public void add(SyncInfo info) {
/* 144 */             super.add(info);
/* 145 */             SubscriberSyncInfoEventHandler.this.queueDispatchEvent(
/* 146 */                 (BackgroundEventHandler.Event)new SubscriberSyncInfoEventHandler.SubscriberSyncInfoEvent(info.getLocal(), 2, 0, info));
/*     */           }
/*     */           
/*     */           public void addError(ITeamStatus status) {
/* 150 */             if (status instanceof TeamStatus) {
/* 151 */               TeamStatus ts = (TeamStatus)status;
/* 152 */               IResource resource = ts.getResource();
/* 153 */               if (resource != null && !resource.getProject().isAccessible()) {
/*     */                 return;
/*     */               }
/*     */             } 
/*     */ 
/*     */             
/* 159 */             super.addError(status);
/* 160 */             TeamPlugin.getPlugin().getLog().log((IStatus)status);
/* 161 */             SubscriberSyncInfoEventHandler.this.syncSetInput.handleError(status);
/*     */           }
/*     */           
/*     */           public void remove(IResource resource) {
/* 165 */             super.remove(resource);
/* 166 */             SubscriberSyncInfoEventHandler.this.queueDispatchEvent(
/* 167 */                 (BackgroundEventHandler.Event)new SubscriberEventHandler.SubscriberEvent(SubscriberSyncInfoEventHandler.this, resource, 1, 0));
/*     */           }
/*     */         };
/*     */       
/* 171 */       this.syncSetInput.getSubscriber().collectOutOfSync(new IResource[] { resource }, depth, collectionSet, (IProgressMonitor)subProgressMonitor);
/*     */     } finally {
/*     */       
/* 174 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void dispatchEvents(SubscriberEventHandler.SubscriberEvent[] events, IProgressMonitor monitor) {
/* 181 */     SubscriberSyncInfoSet syncSet = this.syncSetInput.getSyncSet();
/*     */     try {
/* 183 */       syncSet.beginInput(); byte b; int i; SubscriberEventHandler.SubscriberEvent[] arrayOfSubscriberEvent;
/* 184 */       for (i = (arrayOfSubscriberEvent = events).length, b = 0; b < i; ) { SubscriberEventHandler.SubscriberEvent event = arrayOfSubscriberEvent[b];
/* 185 */         switch (event.getType()) {
/*     */           case 2:
/* 187 */             if (event instanceof SubscriberSyncInfoEvent) {
/* 188 */               SubscriberSyncInfoEvent se = (SubscriberSyncInfoEvent)event;
/* 189 */               this.syncSetInput.collect(se.getResult(), monitor);
/*     */             } 
/*     */             break;
/*     */           case 1:
/* 193 */             syncSet.remove(event.getResource(), event.getDepth()); break;
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } finally {
/* 198 */       syncSet.endInput(monitor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset(IResource[] roots) {
/* 215 */     RootResourceSynchronizationScope scope = (RootResourceSynchronizationScope)getScope();
/* 216 */     if (roots == null)
/* 217 */       roots = getSubscriber().roots(); 
/* 218 */     scope.setRoots(roots);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void reset(ResourceTraversal[] oldTraversals, ResourceTraversal[] newTraversals) {
/* 224 */     run(monitor -> this.syncSetInput.reset(monitor), false);
/*     */     
/* 226 */     super.reset(oldTraversals, newTraversals);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SubscriberSyncInfoEventHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */