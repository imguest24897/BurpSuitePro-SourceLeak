/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.diff.IDiff;
/*     */ import org.eclipse.team.core.diff.IDiffChangeEvent;
/*     */ import org.eclipse.team.core.diff.IDiffChangeListener;
/*     */ import org.eclipse.team.core.diff.IDiffTree;
/*     */ import org.eclipse.team.core.diff.IThreeWayDiff;
/*     */ import org.eclipse.team.core.mapping.IChangeGroupingRequestor;
/*     */ import org.eclipse.team.core.mapping.IResourceDiffTree;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ import org.eclipse.team.internal.core.mapping.CompoundResourceTraversal;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ActiveChangeSetManager
/*     */   extends ChangeSetManager
/*     */   implements IDiffChangeListener, IChangeGroupingRequestor
/*     */ {
/*     */   private static final String CTX_DEFAULT_SET = "defaultSet";
/*     */   private ActiveChangeSet defaultSet;
/*     */   
/*     */   protected ChangeSet getChangeSet(IResourceDiffTree tree) {
/*  63 */     ChangeSet[] sets = getSets(); byte b; int i; ChangeSet[] arrayOfChangeSet1;
/*  64 */     for (i = (arrayOfChangeSet1 = sets).length, b = 0; b < i; ) { ChangeSet changeSet = arrayOfChangeSet1[b];
/*  65 */       if (((DiffChangeSet)changeSet).getDiffTree() == tree)
/*  66 */         return changeSet; 
/*     */       b++; }
/*     */     
/*  69 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(ChangeSet set) {
/*  74 */     Assert.isTrue(set instanceof ActiveChangeSet);
/*  75 */     super.add(set);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handleSetAdded(ChangeSet set) {
/*  80 */     Assert.isTrue(set instanceof ActiveChangeSet);
/*  81 */     ((DiffChangeSet)set).getDiffTree().addDiffChangeListener(getDiffTreeListener());
/*  82 */     super.handleSetAdded(set);
/*  83 */     handleAddedResources(set, ((ActiveChangeSet)set).internalGetDiffTree().getDiffs());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handleSetRemoved(ChangeSet set) {
/*  88 */     ((DiffChangeSet)set).getDiffTree().removeDiffChangeListener(getDiffTreeListener());
/*  89 */     super.handleSetRemoved(set);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IDiffChangeListener getDiffTreeListener() {
/*  99 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void diffsChanged(IDiffChangeEvent event, IProgressMonitor monitor) {
/* 104 */     IResourceDiffTree tree = (IResourceDiffTree)event.getTree();
/* 105 */     handleSyncSetChange(tree, event.getAdditions(), getAllResources(event));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void propertyChanged(IDiffTree tree, int property, IPath[] paths) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isModified(IFile file) throws CoreException {
/* 115 */     IDiff diff = getDiff((IResource)file);
/* 116 */     if (diff != null)
/* 117 */       return isModified(diff); 
/* 118 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isModified(IDiff diff) {
/* 127 */     if (diff != null) {
/* 128 */       if (diff instanceof IThreeWayDiff) {
/* 129 */         IThreeWayDiff twd = (IThreeWayDiff)diff;
/* 130 */         int dir = twd.getDirection();
/* 131 */         return !(dir != 256 && dir != 768);
/*     */       } 
/* 133 */       return (diff.getKind() != 0);
/*     */     } 
/*     */     
/* 136 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActiveChangeSet getSet(String name) {
/* 145 */     ChangeSet[] sets = getSets(); byte b; int i; ChangeSet[] arrayOfChangeSet1;
/* 146 */     for (i = (arrayOfChangeSet1 = sets).length, b = 0; b < i; ) { ChangeSet set = arrayOfChangeSet1[b];
/* 147 */       if (set.getName().equals(name) && set instanceof ActiveChangeSet)
/* 148 */         return (ActiveChangeSet)set; 
/*     */       b++; }
/*     */     
/* 151 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActiveChangeSet createSet(String title, IFile[] files) throws CoreException {
/* 163 */     List<IDiff> infos = new ArrayList<>(); byte b; int i; IFile[] arrayOfIFile;
/* 164 */     for (i = (arrayOfIFile = files).length, b = 0; b < i; ) { IFile file = arrayOfIFile[b];
/* 165 */       IDiff diff = getDiff((IResource)file);
/* 166 */       if (diff != null)
/* 167 */         infos.add(diff); 
/*     */       b++; }
/*     */     
/* 170 */     return createSet(title, infos.<IDiff>toArray(new IDiff[infos.size()]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActiveChangeSet createSet(String title, IDiff[] diffs) {
/* 183 */     ActiveChangeSet commitSet = doCreateSet(title);
/* 184 */     if (diffs != null && diffs.length > 0) {
/* 185 */       commitSet.add(diffs);
/*     */     }
/* 187 */     return commitSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ActiveChangeSet doCreateSet(String name) {
/* 196 */     return new ActiveChangeSet(this, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract IDiff getDiff(IResource paramIResource) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isSingleSetPerResource() {
/* 209 */     return true;
/*     */   }
/*     */   
/*     */   private IPath[] getAllResources(IDiffChangeEvent event) {
/* 213 */     Set<IPath> allResources = new HashSet<>();
/* 214 */     IDiff[] addedResources = event.getAdditions(); byte b; int i; IDiff[] arrayOfIDiff1;
/* 215 */     for (i = (arrayOfIDiff1 = addedResources).length, b = 0; b < i; ) { IDiff diff = arrayOfIDiff1[b];
/* 216 */       allResources.add(diff.getPath()); b++; }
/*     */     
/* 218 */     IDiff[] changedResources = event.getChanges(); IDiff[] arrayOfIDiff2;
/* 219 */     for (int j = (arrayOfIDiff2 = changedResources).length; i < j; ) { IDiff diff = arrayOfIDiff2[i];
/* 220 */       allResources.add(diff.getPath()); i++; }
/*     */     
/* 222 */     IPath[] removals = event.getRemovals();
/* 223 */     Collections.addAll(allResources, removals);
/* 224 */     return allResources.<IPath>toArray(new IPath[allResources.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleAddedResources(ChangeSet set, IDiff[] diffs) {
/* 233 */     if (isSingleSetPerResource() && ((ActiveChangeSet)set).isUserCreated()) {
/* 234 */       IResource[] resources = new IResource[diffs.length];
/* 235 */       for (int i = 0; i < resources.length; i++) {
/* 236 */         resources[i] = ((DiffChangeSet)set).getDiffTree().getResource(diffs[i]);
/*     */       }
/*     */       
/* 239 */       ChangeSet[] sets = getSets(); byte b; int j; ChangeSet[] arrayOfChangeSet1;
/* 240 */       for (j = (arrayOfChangeSet1 = sets).length, b = 0; b < j; ) { ChangeSet otherSet = arrayOfChangeSet1[b];
/* 241 */         if (otherSet != set && ((ActiveChangeSet)otherSet).isUserCreated())
/* 242 */           otherSet.remove(resources); 
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleSyncSetChange(IResourceDiffTree tree, IDiff[] addedDiffs, IPath[] allAffectedResources) {
/* 249 */     ChangeSet changeSet = getChangeSet(tree);
/* 250 */     if (tree.isEmpty() && changeSet != null) {
/* 251 */       remove(changeSet);
/*     */     }
/* 253 */     fireResourcesChangedEvent(changeSet, allAffectedResources);
/* 254 */     handleAddedResources(changeSet, addedDiffs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void makeDefault(ActiveChangeSet set) {
/* 267 */     if (set != null && !contains(set)) {
/* 268 */       add(set);
/*     */     }
/* 270 */     ActiveChangeSet oldSet = this.defaultSet;
/* 271 */     this.defaultSet = set;
/* 272 */     fireDefaultChangedEvent(oldSet, this.defaultSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefault(ActiveChangeSet set) {
/* 282 */     return (set == this.defaultSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ActiveChangeSet getDefaultSet() {
/* 291 */     return this.defaultSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceTraversal[] adjustInputTraversals(ResourceTraversal[] traversals) {
/* 301 */     CompoundResourceTraversal traversal = new CompoundResourceTraversal();
/* 302 */     traversal.addTraversals(traversals);
/* 303 */     ChangeSet[] sets = getSets(); byte b; int i; ChangeSet[] arrayOfChangeSet1;
/* 304 */     for (i = (arrayOfChangeSet1 = sets).length, b = 0; b < i; ) { ChangeSet set = arrayOfChangeSet1[b];
/* 305 */       handleIntersect(traversal, set); b++; }
/*     */     
/* 307 */     return traversal.asTraversals();
/*     */   }
/*     */   
/*     */   private void handleIntersect(CompoundResourceTraversal traversal, ChangeSet set) {
/* 311 */     IResource[] resources = set.getResources(); byte b; int i; IResource[] arrayOfIResource1;
/* 312 */     for (i = (arrayOfIResource1 = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource1[b];
/* 313 */       if (traversal.isCovered(resource, 0)) {
/* 314 */         traversal.addResources(resources, 0);
/*     */         return;
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void save(Preferences prefs) {
/* 327 */     if (!isInitialized()) {
/*     */       return;
/*     */     }
/*     */     try {
/* 331 */       String[] oldSetNames = prefs.childrenNames(); byte b1; int j; String[] arrayOfString1;
/* 332 */       for (j = (arrayOfString1 = oldSetNames).length, b1 = 0; b1 < j; ) { String string = arrayOfString1[b1];
/* 333 */         prefs.node(string).removeNode(); b1++; }
/*     */     
/* 335 */     } catch (BackingStoreException e) {
/* 336 */       TeamPlugin.log(4, NLS.bind(Messages.SubscriberChangeSetCollector_5, (Object[])new String[] { getName() }), (Throwable)e);
/*     */     } 
/* 338 */     ChangeSet[] sets = getSets(); byte b; int i; ChangeSet[] arrayOfChangeSet1;
/* 339 */     for (i = (arrayOfChangeSet1 = sets).length, b = 0; b < i; ) { ChangeSet set = arrayOfChangeSet1[b];
/* 340 */       if (set instanceof ActiveChangeSet && !set.isEmpty()) {
/*     */ 
/*     */ 
/*     */         
/* 344 */         String childPrefName = escapePrefName(((ActiveChangeSet)set).getTitle());
/* 345 */         Preferences child = prefs.node(childPrefName);
/* 346 */         ((ActiveChangeSet)set).save(child);
/*     */       }  b++; }
/*     */     
/* 349 */     if (getDefaultSet() != null) {
/* 350 */       prefs.put("defaultSet", getDefaultSet().getTitle());
/*     */     } else {
/*     */       
/* 353 */       prefs.remove("defaultSet");
/*     */     } 
/*     */     try {
/* 356 */       prefs.flush();
/* 357 */     } catch (BackingStoreException e) {
/* 358 */       TeamPlugin.log(4, NLS.bind(Messages.SubscriberChangeSetCollector_3, (Object[])new String[] { getName() }), (Throwable)e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String escapePrefName(String string) {
/* 372 */     StringBuilder out = new StringBuilder();
/* 373 */     for (int i = 0; i < string.length(); i++) {
/* 374 */       char c = string.charAt(i);
/* 375 */       switch (c) {
/*     */         case '/':
/* 377 */           out.append("\\s");
/*     */           break;
/*     */         case '\\':
/* 380 */           out.append("\\\\");
/*     */           break;
/*     */         default:
/* 383 */           out.append(c); break;
/*     */       } 
/*     */     } 
/* 386 */     return out.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void load(Preferences prefs) {
/* 396 */     String defaultSetTitle = prefs.get("defaultSet", null);
/*     */     try {
/* 398 */       String[] childNames = prefs.childrenNames(); byte b; int i; String[] arrayOfString1;
/* 399 */       for (i = (arrayOfString1 = childNames).length, b = 0; b < i; ) { String string = arrayOfString1[b];
/* 400 */         Preferences childPrefs = prefs.node(string);
/* 401 */         ActiveChangeSet set = createSet(childPrefs);
/* 402 */         if (!set.isEmpty()) {
/* 403 */           if (getDefaultSet() == null && defaultSetTitle != null && set.getTitle().equals(defaultSetTitle)) {
/* 404 */             makeDefault(set);
/*     */           }
/* 406 */           add(set);
/*     */         }  b++; }
/*     */     
/* 409 */     } catch (BackingStoreException e) {
/* 410 */       TeamPlugin.log(4, NLS.bind(Messages.SubscriberChangeSetCollector_4, (Object[])new String[] { getName() }), (Throwable)e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String getName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ActiveChangeSet createSet(Preferences childPrefs) {
/* 429 */     ActiveChangeSet changeSet = doCreateSet((String)null);
/* 430 */     changeSet.init(childPrefs);
/* 431 */     return changeSet;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ensureChangesGrouped(IProject project, IFile[] files, String name) throws CoreException {
/* 437 */     ActiveChangeSet set = getSet(name);
/* 438 */     if (set == null) {
/* 439 */       set = createSet(name, files);
/* 440 */       set.setUserCreated(false);
/* 441 */       add(set);
/*     */     } else {
/* 443 */       set.setUserCreated(false);
/* 444 */       set.add((IResource[])files);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\ActiveChangeSetManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */