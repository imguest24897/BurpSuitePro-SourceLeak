/*    */ package org.eclipse.team.internal.core;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.SortedMap;
/*    */ import java.util.TreeMap;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.core.runtime.IExtension;
/*    */ import org.eclipse.core.runtime.IExtensionPoint;
/*    */ import org.eclipse.core.runtime.Platform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PluginStringMappings
/*    */ {
/*    */   private final String fExtensionID;
/*    */   private final String fAttributeName;
/*    */   private SortedMap<String, Integer> fMappings;
/*    */   
/*    */   public PluginStringMappings(String extensionID, String stringAttributeName) {
/* 38 */     this.fExtensionID = extensionID;
/* 39 */     this.fAttributeName = stringAttributeName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private SortedMap<String, Integer> loadPluginPatterns() {
/* 48 */     SortedMap<String, Integer> result = new TreeMap<>();
/*    */     
/* 50 */     TeamPlugin plugin = TeamPlugin.getPlugin();
/* 51 */     if (plugin == null) {
/* 52 */       return result;
/*    */     }
/* 54 */     IExtensionPoint extension = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.team.core", this.fExtensionID);
/* 55 */     if (extension == null) {
/* 56 */       return result;
/*    */     }
/* 58 */     IExtension[] extensions = extension.getExtensions(); byte b; int i;
/*    */     IExtension[] arrayOfIExtension1;
/* 60 */     for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension e = arrayOfIExtension1[b];
/* 61 */       IConfigurationElement[] configElements = e.getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 62 */       for (j = (arrayOfIConfigurationElement1 = configElements).length, b1 = 0; b1 < j; ) { IConfigurationElement configElement = arrayOfIConfigurationElement1[b1];
/* 63 */         String ext = configElement.getAttribute(this.fAttributeName);
/* 64 */         String type = configElement.getAttribute("type");
/* 65 */         if (ext != null && type != null)
/*    */         {
/* 67 */           if (type.equals("text")) {
/* 68 */             result.put(ext, Integer.valueOf(1));
/* 69 */           } else if (type.equals("binary")) {
/* 70 */             result.put(ext, Integer.valueOf(2));
/*    */           }  }  b1++; }
/*    */        b++; }
/*    */     
/* 74 */     return result;
/*    */   }
/*    */   
/*    */   public Map<String, Integer> referenceMap() {
/* 78 */     if (this.fMappings == null) {
/* 79 */       this.fMappings = loadPluginPatterns();
/*    */     }
/* 81 */     return this.fMappings;
/*    */   }
/*    */   
/*    */   public int getType(String filename) {
/* 85 */     Map<String, Integer> mappings = referenceMap();
/* 86 */     return mappings.containsKey(filename) ? ((Integer)mappings.get(filename)).intValue() : 0;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\PluginStringMappings.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */