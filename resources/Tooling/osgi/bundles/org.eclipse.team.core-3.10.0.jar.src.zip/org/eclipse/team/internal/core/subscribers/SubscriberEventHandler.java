/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*     */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.jobs.IJobChangeEvent;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScope;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScopeChangeListener;
/*     */ import org.eclipse.team.core.subscribers.Subscriber;
/*     */ import org.eclipse.team.internal.core.BackgroundEventHandler;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SubscriberEventHandler
/*     */   extends BackgroundEventHandler
/*     */ {
/*  47 */   private List<BackgroundEventHandler.Event> resultCache = new ArrayList<>();
/*     */   
/*     */   private boolean started = false;
/*     */   
/*     */   private boolean initializing = true;
/*     */   
/*     */   private IProgressMonitor progressGroup;
/*     */   
/*     */   private int ticks;
/*     */   
/*     */   private final Subscriber subscriber;
/*     */   
/*     */   private ISynchronizationScope scope;
/*     */   private ISynchronizationScopeChangeListener scopeChangeListener;
/*     */   
/*     */   class SubscriberEvent
/*     */     extends BackgroundEventHandler.ResourceEvent
/*     */   {
/*     */     static final int REMOVAL = 1;
/*     */     static final int CHANGE = 2;
/*     */     static final int INITIALIZE = 3;
/*     */     
/*     */     SubscriberEvent(IResource resource, int type, int depth) {
/*  70 */       super(resource, type, depth);
/*     */     }
/*     */     
/*     */     protected String getTypeString() {
/*  74 */       switch (getType()) {
/*     */         case 1:
/*  76 */           return "REMOVAL";
/*     */         case 2:
/*  78 */           return "CHANGE";
/*     */         case 3:
/*  80 */           return "INITIALIZE";
/*     */       } 
/*  82 */       return "INVALID";
/*     */     }
/*     */     
/*     */     public ResourceTraversal asTraversal() {
/*  86 */       return new ResourceTraversal(new IResource[] { getResource() }, getDepth(), 0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubscriberEventHandler(Subscriber subscriber, ISynchronizationScope scope) {
/*  99 */     super(NLS.bind(Messages.SubscriberEventHandler_jobName, (Object[])new String[] { subscriber.getName() }), NLS.bind(Messages.SubscriberEventHandler_errors, (Object[])new String[] { subscriber.getName() }));
/* 100 */     this.subscriber = subscriber;
/* 101 */     this.scope = scope;
/* 102 */     this.scopeChangeListener = ((scope1, newMappings, newTraversals) -> reset(new ResourceTraversal[0], scope1.getTraversals()));
/* 103 */     this.scope.addScopeChangeListener(this.scopeChangeListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void reset(ResourceTraversal[] oldTraversals, ResourceTraversal[] newTraversals) {
/* 112 */     reset(newTraversals, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void start() {
/* 122 */     this.started = true;
/* 123 */     ResourceTraversal[] traversals = this.scope.getTraversals();
/* 124 */     reset(traversals, 3);
/* 125 */     this.initializing = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void queueEvent(BackgroundEventHandler.Event event, boolean front) {
/* 131 */     if (this.started) {
/* 132 */       super.queueEvent(event, front);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void schedule() {
/* 140 */     Job job = getEventHandlerJob();
/* 141 */     if (job.getState() == 0) {
/* 142 */       if (this.progressGroup != null) {
/* 143 */         job.setSystem(false);
/* 144 */         job.setProgressGroup(this.progressGroup, this.ticks);
/*     */       } else {
/* 146 */         job.setSystem(isSystemJob());
/*     */       } 
/*     */     }
/* 149 */     getEventHandlerJob().schedule();
/*     */   }
/*     */   
/*     */   protected boolean isSystemJob() {
/* 153 */     return !this.initializing;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void jobDone(IJobChangeEvent event) {
/* 159 */     super.jobDone(event);
/* 160 */     this.progressGroup = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void change(IResource resource, int depth) {
/* 170 */     queueEvent((BackgroundEventHandler.Event)new SubscriberEvent(resource, 2, depth), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(IResource resource) {
/* 179 */     queueEvent(
/* 180 */         (BackgroundEventHandler.Event)new SubscriberEvent(resource, 1, 2), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void collect(IResource resource, int depth, IProgressMonitor monitor) {
/* 192 */     Policy.checkCanceled(monitor);
/*     */ 
/*     */     
/* 195 */     handlePreemptiveEvents(monitor);
/*     */     
/* 197 */     if (resource.getType() != 1 && 
/* 198 */       depth != 0) {
/*     */       try {
/* 200 */         IResource[] members = 
/* 201 */           getSubscriber().members(resource); byte b; int i; IResource[] arrayOfIResource1;
/* 202 */         for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource member = arrayOfIResource1[b];
/* 203 */           collect(member, (depth == 2) ? 
/* 204 */               2 : 
/* 205 */               0, monitor); b++; }
/*     */       
/* 207 */       } catch (TeamException e) {
/*     */ 
/*     */         
/* 210 */         if (resource.getProject().isAccessible()) {
/* 211 */           handleException((CoreException)e, resource, 2, NLS.bind(Messages.SubscriberEventHandler_8, (Object[])new String[] { resource.getFullPath().toString(), e.getMessage() }));
/*     */         }
/*     */       } 
/*     */     }
/* 215 */     monitor.subTask(NLS.bind(Messages.SubscriberEventHandler_2, (Object[])new String[] { resource.getFullPath().toString() }));
/*     */     try {
/* 217 */       handleChange(resource);
/* 218 */       handlePendingDispatch(monitor);
/* 219 */     } catch (CoreException e) {
/* 220 */       handleException(e, resource, 1, NLS.bind(Messages.SubscriberEventHandler_9, (Object[])new String[] { resource.getFullPath().toString(), e.getMessage() }));
/*     */     } 
/* 222 */     monitor.worked(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Subscriber getSubscriber() {
/* 230 */     return this.subscriber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handlePendingDispatch(IProgressMonitor monitor) {
/* 241 */     if (isReadyForDispatch(false)) {
/*     */       try {
/* 243 */         dispatchEvents(Policy.subMonitorFor(monitor, 5));
/* 244 */       } catch (TeamException e) {
/* 245 */         handleException((CoreException)e, (IResource)null, 2, e.getMessage());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleException(CoreException e, IResource resource, int code, String message) {
/* 257 */     handleException(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reset(ResourceTraversal[] traversals, int type) {
/*     */     byte b;
/*     */     int i;
/*     */     ResourceTraversal[] arrayOfResourceTraversal;
/* 286 */     for (i = (arrayOfResourceTraversal = traversals).length, b = 0; b < i; ) { ResourceTraversal traversal = arrayOfResourceTraversal[b];
/* 287 */       IResource[] resources = traversal.getResources(); byte b1; int j; IResource[] arrayOfIResource1;
/* 288 */       for (j = (arrayOfIResource1 = resources).length, b1 = 0; b1 < j; ) { IResource resource = arrayOfIResource1[b1];
/* 289 */         queueEvent((BackgroundEventHandler.Event)new SubscriberEvent(resource, type, traversal.getDepth()), false);
/*     */         b1++; }
/*     */       
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processEvent(BackgroundEventHandler.Event event, IProgressMonitor monitor) {
/*     */     try {
/* 299 */       int type = event.getType();
/* 300 */       switch (type) {
/*     */         case 1000:
/* 302 */           executeRunnable(event, monitor);
/*     */           break;
/*     */         case 1:
/* 305 */           queueDispatchEvent(event);
/*     */           break;
/*     */         case 2:
/* 308 */           collect(
/* 309 */               event.getResource(), (
/* 310 */               (BackgroundEventHandler.ResourceEvent)event).getDepth(), 
/* 311 */               monitor);
/*     */           break;
/*     */         case 3:
/* 314 */           monitor.subTask(NLS.bind(Messages.SubscriberEventHandler_2, (Object[])new String[] { event.getResource().getFullPath().toString() }));
/* 315 */           collectAll(
/* 316 */               event.getResource(), (
/* 317 */               (BackgroundEventHandler.ResourceEvent)event).getDepth(), 
/* 318 */               Policy.subMonitorFor(monitor, 64));
/*     */           break;
/*     */       } 
/* 321 */     } catch (OperationCanceledException e) {
/*     */ 
/*     */       
/* 324 */       handleCancel(e);
/* 325 */     } catch (RuntimeException e) {
/*     */       
/* 327 */       if (event.getType() == 1000) {
/* 328 */         handleException((CoreException)new TeamException(Messages.SubscriberEventHandler_10, e));
/*     */       } else {
/* 330 */         handleException((CoreException)new TeamException(Messages.SubscriberEventHandler_10, e), event.getResource(), 2, NLS.bind(Messages.SubscriberEventHandler_11, (Object[])new String[] { event.getResource().getFullPath().toString(), e.getMessage() }));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void queueDispatchEvent(BackgroundEventHandler.Event event) {
/* 340 */     this.resultCache.add(event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleCancel(OperationCanceledException e) {
/* 348 */     this.resultCache.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void executeRunnable(BackgroundEventHandler.Event event, IProgressMonitor monitor) {
/*     */     try {
/* 357 */       dispatchEvents(Policy.subMonitorFor(monitor, 1));
/* 358 */     } catch (TeamException e) {
/* 359 */       handleException((CoreException)e, (IResource)null, 2, e.getMessage());
/*     */     } 
/*     */     try {
/* 362 */       ((BackgroundEventHandler.RunnableEvent)event).run(Policy.subMonitorFor(monitor, 1));
/* 363 */     } catch (CoreException e) {
/* 364 */       handleException(e, (IResource)null, 2, e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean doDispatchEvents(IProgressMonitor monitor) {
/* 370 */     if (!this.resultCache.isEmpty()) {
/* 371 */       dispatchEvents(this.resultCache.<SubscriberEvent>toArray(new SubscriberEvent[this.resultCache.size()]), monitor);
/* 372 */       this.resultCache.clear();
/* 373 */       return true;
/*     */     } 
/* 375 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(IWorkspaceRunnable runnable, boolean frontOnQueue) {
/* 389 */     queueEvent((BackgroundEventHandler.Event)new BackgroundEventHandler.RunnableEvent(runnable, frontOnQueue), frontOnQueue);
/*     */   }
/*     */   
/*     */   public void setProgressGroupHint(IProgressMonitor progressGroup, int ticks) {
/* 393 */     this.progressGroup = progressGroup;
/* 394 */     this.ticks = ticks;
/*     */   }
/*     */   
/*     */   protected void handlePreemptiveEvents(IProgressMonitor monitor) {
/* 398 */     BackgroundEventHandler.Event event = peek();
/* 399 */     if (event instanceof BackgroundEventHandler.RunnableEvent && ((BackgroundEventHandler.RunnableEvent)event).isPreemtive()) {
/* 400 */       executeRunnable(nextElement(), monitor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ISynchronizationScope getScope() {
/* 410 */     return this.scope;
/*     */   }
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 415 */     super.shutdown();
/* 416 */     this.scope.removeScopeChangeListener(this.scopeChangeListener);
/*     */   }
/*     */   
/*     */   protected abstract void handleChange(IResource paramIResource) throws CoreException;
/*     */   
/*     */   protected abstract void collectAll(IResource paramIResource, int paramInt, IProgressMonitor paramIProgressMonitor);
/*     */   
/*     */   protected abstract void dispatchEvents(SubscriberEvent[] paramArrayOfSubscriberEvent, IProgressMonitor paramIProgressMonitor);
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SubscriberEventHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */