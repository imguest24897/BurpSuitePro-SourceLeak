/*     */ package org.eclipse.team.core.variants;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.eclipse.core.resources.IEncodedStorage;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ResourceVariantStorage
/*     */   implements IEncodedStorage
/*     */ {
/*     */   public InputStream getContents() throws CoreException {
/*  76 */     if (!CachedResourceVariant.this.isContentsCached())
/*     */     {
/*     */       
/*  79 */       throw new TeamException(NLS.bind(Messages.CachedResourceVariant_0, new String[] { this.this$0.getCachePath() }));
/*     */     }
/*  81 */     return CachedResourceVariant.this.getCachedContents();
/*     */   }
/*     */   
/*     */   public IPath getFullPath() {
/*  85 */     return CachedResourceVariant.this.getDisplayPath();
/*     */   }
/*     */   
/*     */   public String getName() {
/*  89 */     return CachedResourceVariant.this.getName();
/*     */   }
/*     */   
/*     */   public boolean isReadOnly() {
/*  93 */     return true;
/*     */   }
/*     */   
/*     */   public <T> T getAdapter(Class<T> adapter) {
/*  97 */     return (T)CachedResourceVariant.this.getAdapter(adapter);
/*     */   }
/*     */   
/*     */   public String getCharset() throws CoreException {
/* 101 */     InputStream contents = getContents();
/*     */     try {
/* 103 */       String charSet = TeamPlugin.getCharset(getName(), contents);
/* 104 */       return charSet;
/* 105 */     } catch (IOException e) {
/* 106 */       throw new TeamException(new Status(4, "org.eclipse.team.core", 381, NLS.bind(Messages.CachedResourceVariant_1, new String[] { getFullPath().toString() }), e));
/*     */     } finally {
/*     */       try {
/* 109 */         contents.close();
/* 110 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\variants\CachedResourceVariant$ResourceVariantStorage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */