package org.eclipse.team.core.diff;

public interface IThreeWayDiff extends IDiff {
  public static final int OUTGOING = 256;
  
  public static final int INCOMING = 512;
  
  public static final int CONFLICTING = 768;
  
  public static final int DIRECTION_MASK = 768;
  
  ITwoWayDiff getLocalChange();
  
  ITwoWayDiff getRemoteChange();
  
  int getDirection();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\diff\IThreeWayDiff.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */