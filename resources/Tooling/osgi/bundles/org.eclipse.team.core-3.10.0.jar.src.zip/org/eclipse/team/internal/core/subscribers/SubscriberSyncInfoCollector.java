/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.team.core.subscribers.Subscriber;
/*     */ import org.eclipse.team.core.synchronize.SyncInfo;
/*     */ import org.eclipse.team.core.synchronize.SyncInfoFilter;
/*     */ import org.eclipse.team.core.synchronize.SyncInfoTree;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SubscriberSyncInfoCollector
/*     */   extends SubscriberResourceCollector
/*     */ {
/*     */   private final SyncSetInputFromSubscriber subscriberInput;
/*     */   private SyncSetInputFromSyncSet filteredInput;
/*     */   private SubscriberSyncInfoEventHandler eventHandler;
/*     */   private IResource[] roots;
/*     */   
/*     */   public SubscriberSyncInfoCollector(Subscriber subscriber, IResource[] roots) {
/*  54 */     super(subscriber);
/*  55 */     this.roots = roots;
/*  56 */     this.eventHandler = new SubscriberSyncInfoEventHandler(subscriber, roots);
/*  57 */     this.subscriberInput = this.eventHandler.getSyncSetInput();
/*  58 */     this.filteredInput = new SyncSetInputFromSyncSet(this.subscriberInput.getSyncSet(), getEventHandler());
/*  59 */     this.filteredInput.setFilter(new SyncInfoFilter()
/*     */         {
/*     */           public boolean select(SyncInfo info, IProgressMonitor monitor) {
/*  62 */             return true;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void setProgressGroup(IProgressMonitor monitor, int ticks) {
/*  69 */     getEventHandler().setProgressGroupHint(monitor, ticks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/*  76 */     this.eventHandler.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void waitForCollector(IProgressMonitor monitor) {
/*  87 */     monitor.worked(1);
/*  88 */     int i = 0;
/*     */     
/*     */     do {
/*     */       try {
/*  92 */         Thread.sleep(5L);
/*  93 */       } catch (InterruptedException interruptedException) {}
/*     */       
/*  95 */       Policy.checkCanceled(monitor);
/*     */ 
/*     */       
/*  98 */       i = (this.eventHandler.getEventHandlerJob().getState() == 0) ? (i + 1) : 0;
/*     */     
/*     */     }
/* 101 */     while (i != 50);
/*     */ 
/*     */     
/* 104 */     monitor.worked(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/* 114 */     this.eventHandler.reset(getRoots());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 124 */     this.eventHandler.shutdown();
/* 125 */     this.subscriberInput.disconnect();
/* 126 */     if (this.filteredInput != null) {
/* 127 */       this.filteredInput.disconnect();
/*     */     }
/* 129 */     super.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource[] getRoots() {
/* 140 */     if (this.roots == null) {
/* 141 */       return super.getRoots();
/*     */     }
/* 143 */     return this.roots;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAllRootsIncluded() {
/* 155 */     return (this.roots == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SubscriberEventHandler getEventHandler() {
/* 166 */     return this.eventHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SyncInfoTree getSubscriberSyncInfoSet() {
/* 177 */     return this.subscriberInput.getSyncSet();
/*     */   }
/*     */   
/*     */   public SyncInfoTree getSyncInfoSet() {
/* 181 */     return this.filteredInput.getSyncSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilter(SyncInfoFilter filter) {
/* 190 */     this.filteredInput.setFilter(filter);
/* 191 */     this.filteredInput.reset();
/*     */   }
/*     */   
/*     */   public void setRoots(IResource[] roots) {
/* 195 */     this.roots = roots;
/* 196 */     reset();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean hasMembers(IResource resource) {
/* 201 */     return getSubscriberSyncInfoSet().hasMembers(resource);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void remove(IResource resource) {
/* 206 */     this.eventHandler.remove(resource);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void change(IResource resource, int depth) {
/* 211 */     this.eventHandler.change(resource, depth);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SubscriberSyncInfoCollector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */