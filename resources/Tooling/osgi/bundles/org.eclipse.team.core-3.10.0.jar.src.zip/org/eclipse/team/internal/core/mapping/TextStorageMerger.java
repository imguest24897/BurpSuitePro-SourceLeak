/*     */ package org.eclipse.team.internal.core.mapping;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import org.eclipse.compare.rangedifferencer.RangeDifference;
/*     */ import org.eclipse.compare.rangedifferencer.RangeDifferencer;
/*     */ import org.eclipse.core.resources.IStorage;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.team.core.mapping.IStorageMerger;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextStorageMerger
/*     */   implements IStorageMerger
/*     */ {
/*     */   public IStatus merge(OutputStream output, String outputEncoding, IStorage ancestor, IStorage target, IStorage other, IProgressMonitor monitor) throws CoreException {
/*     */     LineComparator a;
/*     */     LineComparator t;
/*     */     LineComparator o;
/*     */     try {
/*  41 */       a = LineComparator.create(ancestor, outputEncoding);
/*  42 */       t = LineComparator.create(target, outputEncoding);
/*  43 */       o = LineComparator.create(other, outputEncoding);
/*  44 */     } catch (UnsupportedEncodingException e) {
/*  45 */       throw new CoreException(new Status(4, "org.eclipse.team.core", 3, Messages.TextAutoMerge_inputEncodingError, e));
/*  46 */     } catch (IOException e) {
/*  47 */       throw new CoreException(new Status(4, "org.eclipse.team.core", 2, e.getMessage(), e));
/*     */     } 
/*     */     
/*     */     try {
/*  51 */       boolean firstLine = true;
/*  52 */       String lineSeparator = System.getProperty("line.separator");
/*  53 */       if (lineSeparator == null) {
/*  54 */         lineSeparator = "\n";
/*     */       }
/*  56 */       RangeDifference[] diffs = RangeDifferencer.findRanges(monitor, a, t, o); byte b; int i;
/*     */       RangeDifference[] arrayOfRangeDifference1;
/*  58 */       for (i = (arrayOfRangeDifference1 = diffs).length, b = 0; b < i; ) { int j; RangeDifference rd = arrayOfRangeDifference1[b];
/*  59 */         switch (rd.kind()) {
/*     */           case 0:
/*     */           case 2:
/*     */           case 4:
/*  63 */             for (j = rd.rightStart(); j < rd.rightEnd(); j++) {
/*  64 */               String s = o.getLine(j);
/*  65 */               if (!firstLine)
/*  66 */                 output.write(lineSeparator.getBytes(outputEncoding)); 
/*  67 */               output.write(s.getBytes(outputEncoding));
/*  68 */               firstLine = false;
/*     */             } 
/*     */             break;
/*     */           
/*     */           case 3:
/*  73 */             for (j = rd.leftStart(); j < rd.leftEnd(); j++) {
/*  74 */               String s = t.getLine(j);
/*  75 */               if (!firstLine)
/*  76 */                 output.write(lineSeparator.getBytes(outputEncoding)); 
/*  77 */               output.write(s.getBytes(outputEncoding));
/*  78 */               firstLine = false;
/*     */             } 
/*     */             break;
/*     */           
/*     */           case 1:
/*  83 */             return (IStatus)new Status(2, "org.eclipse.team.core", 1, Messages.TextAutoMerge_conflict, null);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/*     */         b++; }
/*     */     
/*  90 */     } catch (UnsupportedEncodingException e) {
/*  91 */       throw new CoreException(new Status(4, "org.eclipse.team.core", 3, Messages.TextAutoMerge_outputEncodingError, e));
/*  92 */     } catch (IOException e) {
/*  93 */       return (IStatus)new Status(4, "org.eclipse.team.core", 2, Messages.TextAutoMerge_outputIOError, e);
/*     */     } 
/*     */     
/*  96 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canMergeWithoutAncestor() {
/* 101 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\TextStorageMerger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */