/*     */ package org.eclipse.team.internal.core.streams;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InterruptedIOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LFtoCRLFInputStream
/*     */   extends FilterInputStream
/*     */ {
/*     */   private boolean mustReturnLF = false;
/*     */   
/*     */   public LFtoCRLFInputStream(InputStream in) {
/*  36 */     super(in);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/*  48 */     if (this.mustReturnLF) {
/*  49 */       this.mustReturnLF = false;
/*  50 */       return 10;
/*     */     } 
/*  52 */     int b = this.in.read();
/*  53 */     if (b == 10) {
/*  54 */       this.mustReturnLF = true;
/*  55 */       b = 13;
/*     */     } 
/*  57 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] buffer, int off, int len) throws IOException {
/*  70 */     if (len == 0)
/*  71 */       return 0; 
/*  72 */     if (len == 1) {
/*  73 */       int b = read();
/*  74 */       if (b == -1) return -1; 
/*  75 */       buffer[off] = (byte)b;
/*  76 */       return 1;
/*     */     } 
/*     */     
/*  79 */     int count = 0;
/*  80 */     if (this.mustReturnLF) {
/*  81 */       this.mustReturnLF = false;
/*  82 */       buffer[off++] = 10;
/*  83 */       len--;
/*  84 */       count = 1;
/*  85 */       if (len < 2) return count;
/*     */     
/*     */     } 
/*     */     
/*  89 */     len /= 2;
/*  90 */     int j = off + len;
/*  91 */     InterruptedIOException iioe = null;
/*     */     try {
/*  93 */       len = this.in.read(buffer, j, len);
/*  94 */       if (len == -1) {
/*  95 */         return (count == 0) ? -1 : count;
/*     */       }
/*  97 */     } catch (InterruptedIOException e) {
/*  98 */       len = e.bytesTransferred;
/*  99 */       iioe = e;
/*     */     } 
/* 101 */     count += len;
/*     */     
/* 103 */     while (len-- > 0) {
/* 104 */       byte b = buffer[j++];
/* 105 */       if (b == 10) {
/* 106 */         buffer[off++] = 13;
/* 107 */         count++;
/*     */       } 
/* 109 */       buffer[off++] = b;
/*     */     } 
/* 111 */     if (iioe != null) {
/* 112 */       iioe.bytesTransferred = count;
/* 113 */       throw iioe;
/*     */     } 
/* 115 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long skip(long count) throws IOException {
/* 126 */     int actualCount = 0;
/*     */     try {
/* 128 */       for (; count-- > 0L && read() != -1; actualCount++);
/* 129 */       return actualCount;
/* 130 */     } catch (InterruptedIOException e) {
/* 131 */       e.bytesTransferred = actualCount;
/* 132 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/* 144 */     return this.in.available();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 152 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\streams\LFtoCRLFInputStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */