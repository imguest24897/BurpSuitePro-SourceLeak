/*    */ package org.eclipse.team.internal.core;
/*    */ 
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.NullProgressMonitor;
/*    */ import org.eclipse.core.runtime.OperationCanceledException;
/*    */ import org.eclipse.core.runtime.SubMonitor;
/*    */ import org.eclipse.osgi.service.debug.DebugOptions;
/*    */ import org.eclipse.osgi.service.debug.DebugOptionsListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Policy
/*    */ {
/*    */   public static boolean DEBUG = false;
/*    */   public static boolean DEBUG_STREAMS = false;
/*    */   public static boolean DEBUG_REFRESH_JOB = true;
/*    */   public static boolean DEBUG_BACKGROUND_EVENTS = false;
/*    */   public static boolean DEBUG_THREADING = false;
/*    */   static final DebugOptionsListener DEBUG_OPTIONS_LISTENER;
/*    */   
/*    */   static {
/* 31 */     DEBUG_OPTIONS_LISTENER = (options -> {
/*    */         DEBUG = options.getBooleanOption("org.eclipse.team.core/debug", false);
/* 33 */         DEBUG_STREAMS = (DEBUG && options.getBooleanOption("org.eclipse.team.core/streams", false));
/* 34 */         DEBUG_REFRESH_JOB = (DEBUG && options.getBooleanOption("org.eclipse.team.core/refreshjob", false));
/* 35 */         DEBUG_BACKGROUND_EVENTS = (DEBUG && options.getBooleanOption("org.eclipse.team.core/backgroundevents", false));
/* 36 */         DEBUG_THREADING = (DEBUG && options.getBooleanOption("org.eclipse.team.core/threading", false));
/*    */       });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void checkCanceled(IProgressMonitor monitor) {
/* 45 */     if (monitor != null && monitor.isCanceled())
/* 46 */       throw new OperationCanceledException(); 
/*    */   }
/*    */   public static IProgressMonitor monitorFor(IProgressMonitor monitor) {
/* 49 */     if (monitor == null)
/* 50 */       return (IProgressMonitor)new NullProgressMonitor(); 
/* 51 */     return monitor;
/*    */   }
/*    */   
/*    */   public static IProgressMonitor subMonitorFor(IProgressMonitor monitor, int ticks) {
/* 55 */     if (monitor == null)
/* 56 */       return (IProgressMonitor)new NullProgressMonitor(); 
/* 57 */     if (monitor instanceof NullProgressMonitor)
/* 58 */       return monitor; 
/* 59 */     return (IProgressMonitor)SubMonitor.convert(monitor, ticks);
/*    */   }
/*    */   
/*    */   public static IProgressMonitor infiniteSubMonitorFor(IProgressMonitor monitor, int ticks) {
/* 63 */     if (monitor == null)
/* 64 */       return (IProgressMonitor)new NullProgressMonitor(); 
/* 65 */     if (monitor instanceof NullProgressMonitor)
/* 66 */       return monitor; 
/* 67 */     return (IProgressMonitor)new InfiniteSubProgressMonitor(monitor, ticks);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\Policy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */