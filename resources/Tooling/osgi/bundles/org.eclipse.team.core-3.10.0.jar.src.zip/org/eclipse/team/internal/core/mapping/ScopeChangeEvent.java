/*     */ package org.eclipse.team.internal.core.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScope;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScopeChangeEvent
/*     */ {
/*     */   private final ISynchronizationScope scope;
/*     */   private final ResourceMapping[] originalMappings;
/*     */   private final ResourceTraversal[] originalTraversals;
/*     */   private boolean expanded;
/*     */   private boolean contracted;
/*     */   
/*     */   public ScopeChangeEvent(ISynchronizationScope scope) {
/*  35 */     this.scope = scope;
/*  36 */     this.originalMappings = scope.getMappings();
/*  37 */     this.originalTraversals = scope.getTraversals();
/*     */   }
/*     */   
/*     */   public boolean hasAdditionalMappings() {
/*  41 */     return ((this.scope.getMappings()).length > this.originalMappings.length);
/*     */   }
/*     */   
/*     */   public ResourceTraversal[] getUncoveredTraversals(CompoundResourceTraversal traversal) {
/*  45 */     CompoundResourceTraversal originals = new CompoundResourceTraversal();
/*  46 */     originals.addTraversals(this.originalTraversals);
/*  47 */     return originals.getUncoveredTraversals(traversal);
/*     */   }
/*     */   
/*     */   public void setExpanded(boolean expanded) {
/*  51 */     this.expanded = expanded;
/*     */   }
/*     */   
/*     */   public boolean isExpanded() {
/*  55 */     return this.expanded;
/*     */   }
/*     */   
/*     */   public void setContracted(boolean contracted) {
/*  59 */     this.contracted = contracted;
/*     */   }
/*     */   
/*     */   public boolean isContracted() {
/*  63 */     return this.contracted;
/*     */   }
/*     */   
/*     */   public ResourceMapping[] getChangedMappings() {
/*  67 */     ResourceMapping[] changedMappings, currentMappings = this.scope.getMappings();
/*     */     
/*  69 */     if (currentMappings.length > this.originalMappings.length) {
/*     */       
/*  71 */       Set<ResourceMapping> originalSet = new HashSet<>();
/*  72 */       List<ResourceMapping> result = new ArrayList<>();
/*  73 */       Collections.addAll(originalSet, this.originalMappings); byte b; int i; ResourceMapping[] arrayOfResourceMapping;
/*  74 */       for (i = (arrayOfResourceMapping = currentMappings).length, b = 0; b < i; ) { ResourceMapping mapping = arrayOfResourceMapping[b];
/*  75 */         if (!originalSet.contains(mapping))
/*  76 */           result.add(mapping); 
/*     */         b++; }
/*     */       
/*  79 */       changedMappings = result.<ResourceMapping>toArray(new ResourceMapping[result.size()]);
/*  80 */     } else if (isContracted()) {
/*     */       
/*  82 */       Set<ResourceMapping> finalSet = new HashSet<>();
/*  83 */       List<ResourceMapping> result = new ArrayList<>();
/*  84 */       Collections.addAll(finalSet, currentMappings); byte b; int i; ResourceMapping[] arrayOfResourceMapping;
/*  85 */       for (i = (arrayOfResourceMapping = this.originalMappings).length, b = 0; b < i; ) { ResourceMapping mapping = arrayOfResourceMapping[b];
/*  86 */         if (!finalSet.contains(mapping))
/*  87 */           result.add(mapping); 
/*     */         b++; }
/*     */       
/*  90 */       changedMappings = result.<ResourceMapping>toArray(new ResourceMapping[result.size()]);
/*     */     } else {
/*  92 */       changedMappings = new ResourceMapping[0];
/*     */     } 
/*  94 */     return changedMappings;
/*     */   }
/*     */   
/*     */   public ResourceTraversal[] getChangedTraversals(CompoundResourceTraversal refreshTraversals) {
/*     */     ResourceTraversal[] changesTraversals;
/*  99 */     if (isExpanded()) {
/* 100 */       changesTraversals = getUncoveredTraversals(refreshTraversals);
/* 101 */     } else if (isContracted()) {
/* 102 */       CompoundResourceTraversal finalTraversals = new CompoundResourceTraversal();
/* 103 */       finalTraversals.addTraversals(this.scope.getTraversals());
/* 104 */       changesTraversals = finalTraversals.getUncoveredTraversals(this.originalTraversals);
/*     */     } else {
/* 106 */       changesTraversals = new ResourceTraversal[0];
/*     */     } 
/* 108 */     return changesTraversals;
/*     */   }
/*     */   
/*     */   public boolean shouldFireChange() {
/* 112 */     return !(!isExpanded() && !isContracted() && !hasAdditionalMappings());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\ScopeChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */