/*    */ package org.eclipse.team.internal.core;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.IWorkspaceRoot;
/*    */ import org.eclipse.core.resources.ResourcesPlugin;
/*    */ import org.eclipse.core.resources.team.ResourceRuleFactory;
/*    */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PessimisticResourceRuleFactory
/*    */   extends ResourceRuleFactory
/*    */ {
/* 29 */   IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
/*    */ 
/*    */   
/*    */   public ISchedulingRule copyRule(IResource source, IResource destination) {
/* 33 */     return (ISchedulingRule)this.root;
/*    */   }
/*    */   
/*    */   public ISchedulingRule createRule(IResource resource) {
/* 37 */     return (ISchedulingRule)this.root;
/*    */   }
/*    */   
/*    */   public ISchedulingRule deleteRule(IResource resource) {
/* 41 */     return (ISchedulingRule)this.root;
/*    */   }
/*    */   
/*    */   public ISchedulingRule modifyRule(IResource resource) {
/* 45 */     return (ISchedulingRule)this.root;
/*    */   }
/*    */   
/*    */   public ISchedulingRule moveRule(IResource source, IResource destination) {
/* 49 */     return (ISchedulingRule)this.root;
/*    */   }
/*    */   
/*    */   public ISchedulingRule refreshRule(IResource resource) {
/* 53 */     return (ISchedulingRule)this.root;
/*    */   }
/*    */   
/*    */   public ISchedulingRule validateEditRule(IResource[] resources) {
/* 57 */     return (ISchedulingRule)this.root;
/*    */   }
/*    */ 
/*    */   
/*    */   public ISchedulingRule charsetRule(IResource resource) {
/* 62 */     return (ISchedulingRule)this.root;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\PessimisticResourceRuleFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */