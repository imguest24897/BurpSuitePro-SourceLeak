/*    */ package org.eclipse.team.core.synchronize;
/*    */ 
/*    */ import org.eclipse.core.resources.IFile;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.team.core.variants.IResourceVariant;
/*    */ import org.eclipse.team.internal.core.subscribers.ContentComparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentComparisonSyncInfoFilter
/*    */   extends SyncInfoFilter
/*    */ {
/* 45 */   ContentComparator criteria = new ContentComparator(false);
/*    */ 
/*    */ 
/*    */   
/*    */   public ContentComparisonSyncInfoFilter() {
/* 50 */     this(false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ContentComparisonSyncInfoFilter(boolean ignoreWhitespace) {
/* 57 */     this.criteria = new ContentComparator(ignoreWhitespace);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean select(SyncInfo info, IProgressMonitor monitor) {
/* 62 */     IResourceVariant remote = info.getRemote();
/* 63 */     IResource local = info.getLocal();
/* 64 */     if (local.getType() != 1) return true; 
/* 65 */     if (remote == null) return !local.exists(); 
/* 66 */     if (!local.exists()) return false; 
/* 67 */     return compareContents((IFile)local, remote, monitor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean compareContents(IFile local, IResourceVariant remote, IProgressMonitor monitor) {
/* 80 */     Assert.isNotNull(local);
/* 81 */     Assert.isNotNull(remote);
/* 82 */     return this.criteria.compare((IResource)local, remote, monitor);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\synchronize\SyncInfoFilter$ContentComparisonSyncInfoFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */