/*    */ package org.eclipse.team.internal.core.mapping;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.team.core.TeamException;
/*    */ import org.eclipse.team.core.synchronize.SyncInfo;
/*    */ import org.eclipse.team.core.variants.IResourceVariant;
/*    */ import org.eclipse.team.core.variants.IResourceVariantComparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PrecalculatedSyncInfo
/*    */   extends SyncInfo
/*    */ {
/*    */   public int kind;
/*    */   
/*    */   public PrecalculatedSyncInfo(int kind, IResource local, IResourceVariant base, IResourceVariant remote, IResourceVariantComparator comparator) {
/* 43 */     super(local, base, remote, comparator);
/* 44 */     this.kind = kind;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int calculateKind() throws TeamException {
/* 49 */     return this.kind;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\SyncInfoToDiffConverter$PrecalculatedSyncInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */