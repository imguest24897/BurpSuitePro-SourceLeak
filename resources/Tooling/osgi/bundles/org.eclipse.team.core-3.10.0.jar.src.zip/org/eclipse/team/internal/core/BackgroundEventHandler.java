/*     */ package org.eclipse.team.internal.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.jobs.IJobChangeEvent;
/*     */ import org.eclipse.core.runtime.jobs.IJobChangeListener;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.core.runtime.jobs.JobChangeAdapter;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BackgroundEventHandler
/*     */ {
/*     */   public static final int RUNNABLE_EVENT = 1000;
/*  68 */   private List<Event> awaitingProcessing = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private Job eventHandlerJob;
/*     */ 
/*     */   
/*     */   private boolean shutdown;
/*     */ 
/*     */   
/*     */   private ExceptionCollector errors;
/*     */ 
/*     */   
/*  80 */   private long timeOfLastDispatch = 0L;
/*     */ 
/*     */   
/*     */   private int dispatchCount;
/*     */ 
/*     */   
/*     */   private static final long DISPATCH_DELAY = 1500L;
/*     */ 
/*     */   
/*     */   private static final long LONG_DISPATCH_DELAY = 10000L;
/*     */ 
/*     */   
/*     */   private static final int DISPATCH_THRESHOLD = 3;
/*     */   
/*     */   private static final long WAIT_DELAY = 100L;
/*     */   
/*     */   private String jobName;
/*     */ 
/*     */   
/*     */   public static class Event
/*     */   {
/*     */     private int type;
/*     */ 
/*     */     
/*     */     public Event(int type) {
/* 105 */       this.type = type;
/*     */     }
/*     */     public int getType() {
/* 108 */       return this.type;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 112 */       StringBuilder buffer = new StringBuilder();
/* 113 */       buffer.append("Background Event: ");
/* 114 */       buffer.append(getTypeString());
/* 115 */       return buffer.toString();
/*     */     }
/*     */     public IResource getResource() {
/* 118 */       return null;
/*     */     }
/*     */     protected String getTypeString() {
/* 121 */       return String.valueOf(this.type);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ResourceEvent
/*     */     extends Event
/*     */   {
/*     */     private IResource resource;
/*     */     private int depth;
/*     */     
/*     */     public ResourceEvent(IResource resource, int type, int depth) {
/* 132 */       super(type);
/* 133 */       this.resource = resource;
/* 134 */       this.depth = depth;
/*     */     }
/*     */     public int getDepth() {
/* 137 */       return this.depth;
/*     */     }
/*     */     
/*     */     public IResource getResource() {
/* 141 */       return this.resource;
/*     */     }
/*     */     
/*     */     public String toString() {
/* 145 */       StringBuilder buffer = new StringBuilder();
/* 146 */       buffer.append("resource: ");
/* 147 */       buffer.append(this.resource.getFullPath());
/* 148 */       buffer.append(" type: ");
/* 149 */       buffer.append(getTypeString());
/* 150 */       buffer.append(" depth: ");
/* 151 */       buffer.append(getDepthString());
/* 152 */       return buffer.toString();
/*     */     }
/*     */     protected String getDepthString() {
/* 155 */       switch (this.depth) {
/*     */         case 0:
/* 157 */           return "DEPTH_ZERO";
/*     */         case 1:
/* 159 */           return "DEPTH_ONE";
/*     */         case 2:
/* 161 */           return "DEPTH_INFINITE";
/*     */       } 
/* 163 */       return "INVALID";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class RunnableEvent
/*     */     extends Event
/*     */   {
/*     */     private IWorkspaceRunnable runnable;
/*     */ 
/*     */     
/*     */     private boolean preemtive;
/*     */ 
/*     */ 
/*     */     
/*     */     public RunnableEvent(IWorkspaceRunnable runnable, boolean preemtive) {
/* 180 */       super(1000);
/* 181 */       this.runnable = runnable;
/* 182 */       this.preemtive = preemtive;
/*     */     }
/*     */     public void run(IProgressMonitor monitor) throws CoreException {
/* 185 */       this.runnable.run(monitor);
/*     */     }
/*     */     public boolean isPreemtive() {
/* 188 */       return this.preemtive;
/*     */     }
/*     */   }
/*     */   
/*     */   protected BackgroundEventHandler(String jobName, String errorTitle) {
/* 193 */     this.jobName = jobName;
/* 194 */     this.errors = 
/* 195 */       new ExceptionCollector(
/* 196 */         errorTitle, 
/* 197 */         "org.eclipse.team.core", 
/* 198 */         4, 
/* 199 */         null);
/*     */     
/* 201 */     createEventHandlingJob();
/* 202 */     schedule();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void createEventHandlingJob() {
/* 210 */     this.eventHandlerJob = new Job(getName())
/*     */       {
/*     */         public IStatus run(IProgressMonitor monitor) {
/* 213 */           return BackgroundEventHandler.this.processEvents(monitor);
/*     */         }
/*     */         
/*     */         public boolean shouldRun() {
/* 217 */           return !BackgroundEventHandler.this.isQueueEmpty();
/*     */         }
/*     */         
/*     */         public boolean shouldSchedule() {
/* 221 */           return !BackgroundEventHandler.this.isQueueEmpty();
/*     */         }
/*     */         
/*     */         public boolean belongsTo(Object family) {
/* 225 */           return BackgroundEventHandler.this.belongsTo(family);
/*     */         }
/*     */       };
/* 228 */     this.eventHandlerJob.addJobChangeListener((IJobChangeListener)new JobChangeAdapter()
/*     */         {
/*     */           public void done(IJobChangeEvent event) {
/* 231 */             BackgroundEventHandler.this.jobDone(event);
/*     */           }
/*     */         });
/* 234 */     this.eventHandlerJob.setSystem(true);
/* 235 */     this.eventHandlerJob.setPriority(20);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean belongsTo(Object family) {
/* 245 */     return (getJobFamiliy() == family);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getJobFamiliy() {
/* 255 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void jobDone(IJobChangeEvent event) {
/* 264 */     if (isShutdown()) {
/*     */       
/* 266 */       synchronized (this) {
/* 267 */         this.awaitingProcessing.clear();
/*     */       } 
/* 269 */     } else if (!isQueueEmpty()) {
/*     */       
/* 271 */       schedule();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void schedule() {
/* 279 */     this.eventHandlerJob.schedule();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 287 */     this.shutdown = true;
/* 288 */     this.eventHandlerJob.cancel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isShutdown() {
/* 296 */     return this.shutdown;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void queueEvent(Event event, boolean front) {
/* 305 */     if (Policy.DEBUG_BACKGROUND_EVENTS) {
/* 306 */       System.out.println("Event queued on " + getName() + ":" + event.toString());
/*     */     }
/* 308 */     if (front) {
/* 309 */       this.awaitingProcessing.add(0, event);
/*     */     } else {
/* 311 */       this.awaitingProcessing.add(event);
/*     */     } 
/* 313 */     if (!isShutdown() && this.eventHandlerJob != null) {
/* 314 */       if (this.eventHandlerJob.getState() == 0) {
/* 315 */         schedule();
/*     */       } else {
/* 317 */         notify();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getName() {
/* 327 */     return this.jobName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized Event nextElement() {
/* 335 */     if (isShutdown() || isQueueEmpty()) {
/* 336 */       return null;
/*     */     }
/* 338 */     return this.awaitingProcessing.remove(0);
/*     */   }
/*     */   
/*     */   protected synchronized Event peek() {
/* 342 */     if (isShutdown() || isQueueEmpty()) {
/* 343 */       return null;
/*     */     }
/* 345 */     return this.awaitingProcessing.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized boolean isQueueEmpty() {
/* 353 */     return this.awaitingProcessing.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IStatus processEvents(IProgressMonitor monitor) {
/* 369 */     this.errors.clear();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 374 */       monitor.beginTask(null, -1);
/* 375 */       IProgressMonitor subMonitor = Policy.infiniteSubMonitorFor(monitor, 90);
/* 376 */       subMonitor.beginTask(null, 1024);
/*     */ 
/*     */       
/* 379 */       this.timeOfLastDispatch = System.currentTimeMillis();
/* 380 */       this.dispatchCount = 1; Event event;
/* 381 */       while ((event = nextElement()) != null && !isShutdown()) {
/*     */         try {
/* 383 */           processEvent(event, subMonitor);
/* 384 */           if (Policy.DEBUG_BACKGROUND_EVENTS) {
/* 385 */             System.out.println("Event processed on " + getName() + ":" + event.toString());
/*     */           }
/* 387 */           if (isReadyForDispatch(true)) {
/* 388 */             dispatchEvents(Policy.subMonitorFor(subMonitor, 1));
/*     */           }
/* 390 */         } catch (CoreException e) {
/*     */           
/* 392 */           handleException(e);
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 396 */       monitor.done();
/*     */     } 
/* 398 */     return this.errors.getStatus();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void dispatchEvents(IProgressMonitor monitor) throws TeamException {
/* 408 */     if (doDispatchEvents(monitor))
/*     */     {
/* 410 */       this.dispatchCount++;
/*     */     }
/* 412 */     this.timeOfLastDispatch = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean doDispatchEvents(IProgressMonitor paramIProgressMonitor) throws TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isReadyForDispatch(boolean wait) {
/* 436 */     if (isDispatchDelayExceeded()) {
/* 437 */       return true;
/*     */     }
/* 439 */     synchronized (this) {
/*     */       
/* 441 */       if (!isQueueEmpty() || !wait) {
/* 442 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 447 */         wait(getDispatchWaitDelay());
/* 448 */       } catch (InterruptedException interruptedException) {}
/*     */     } 
/*     */ 
/*     */     
/* 452 */     return !(!isQueueEmpty() && !isDispatchDelayExceeded());
/*     */   }
/*     */   
/*     */   private boolean isDispatchDelayExceeded() {
/* 456 */     long duration = System.currentTimeMillis() - this.timeOfLastDispatch;
/* 457 */     return !((this.dispatchCount >= 3 || duration < getShortDispatchDelay()) && 
/* 458 */       duration < getLongDispatchDelay());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long getDispatchWaitDelay() {
/* 466 */     return 100L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long getShortDispatchDelay() {
/* 477 */     return 1500L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long getLongDispatchDelay() {
/* 487 */     return 10000L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleException(CoreException e) {
/* 495 */     this.errors.handleException(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void processEvent(Event paramEvent, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Job getEventHandlerJob() {
/* 519 */     return this.eventHandlerJob;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\BackgroundEventHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */