/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.core.variants.IResourceVariant;
/*     */ import org.eclipse.team.core.variants.ResourceVariantByteStore;
/*     */ import org.eclipse.team.core.variants.ResourceVariantTree;
/*     */ import org.eclipse.team.core.variants.ThreeWaySubscriber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ThreeWayBaseTree
/*     */   extends ResourceVariantTree
/*     */ {
/*     */   private ThreeWaySubscriber subscriber;
/*     */   
/*     */   static class BaseResourceVariantByteStore
/*     */     extends ResourceVariantByteStore
/*     */   {
/*     */     private ThreeWaySubscriber subscriber;
/*     */     
/*     */     public BaseResourceVariantByteStore(ThreeWaySubscriber subscriber) {
/*  40 */       this.subscriber = subscriber;
/*     */     }
/*     */ 
/*     */     
/*     */     public void dispose() {}
/*     */ 
/*     */     
/*     */     public byte[] getBytes(IResource resource) throws TeamException {
/*  48 */       return this.subscriber.getSynchronizer().getBaseBytes(resource);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean setBytes(IResource resource, byte[] bytes) throws TeamException {
/*  53 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean flushBytes(IResource resource, int depth) throws TeamException {
/*  58 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean deleteBytes(IResource resource) throws TeamException {
/*  63 */       return false;
/*     */     }
/*     */     
/*     */     public IResource[] members(IResource resource) throws TeamException {
/*  67 */       return this.subscriber.getSynchronizer().members(resource);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ThreeWayBaseTree(ThreeWaySubscriber subscriber) {
/*  77 */     super(new BaseResourceVariantByteStore(subscriber));
/*  78 */     this.subscriber = subscriber;
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource[] refresh(IResource[] resources, int depth, IProgressMonitor monitor) throws TeamException {
/*  83 */     return new IResource[0];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected IResourceVariant[] fetchMembers(IResourceVariant variant, IProgressMonitor progress) throws TeamException {
/*  89 */     return new IResourceVariant[0];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected IResourceVariant fetchVariant(IResource resource, int depth, IProgressMonitor monitor) throws TeamException {
/*  95 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource[] roots() {
/* 100 */     return getSubscriber().roots();
/*     */   }
/*     */ 
/*     */   
/*     */   public IResourceVariant getResourceVariant(IResource resource) throws TeamException {
/* 105 */     return getSubscriber().getResourceVariant(resource, getByteStore().getBytes(resource));
/*     */   }
/*     */   
/*     */   private ThreeWaySubscriber getSubscriber() {
/* 109 */     return this.subscriber;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\ThreeWayBaseTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */