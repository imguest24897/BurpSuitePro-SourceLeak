/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.core.history.IFileRevision;
/*     */ import org.eclipse.team.core.variants.IResourceVariant;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractContentComparator
/*     */ {
/*     */   private boolean ignoreWhitespace = false;
/*     */   
/*     */   public AbstractContentComparator(boolean ignoreWhitespace) {
/*  43 */     this.ignoreWhitespace = ignoreWhitespace;
/*     */   }
/*     */   
/*     */   public boolean compare(IResource e1, IResourceVariant e2, IProgressMonitor monitor) {
/*  47 */     return compareObjects(e1, e2, monitor);
/*     */   }
/*     */   
/*     */   public boolean compare(IResource e1, IFileRevision e2, IProgressMonitor monitor) {
/*  51 */     return compareObjects(e1, e2, monitor);
/*     */   }
/*     */   
/*     */   private boolean compareObjects(Object e1, Object e2, IProgressMonitor monitor) {
/*  55 */     InputStream is1 = null;
/*  56 */     InputStream is2 = null;
/*     */     try {
/*  58 */       monitor.beginTask(null, 100);
/*  59 */       is1 = getContents(e1, Policy.subMonitorFor(monitor, 30));
/*  60 */       is2 = getContents(e2, Policy.subMonitorFor(monitor, 30));
/*  61 */       return contentsEqual(Policy.subMonitorFor(monitor, 40), is1, is2, shouldIgnoreWhitespace());
/*  62 */     } catch (TeamException e) {
/*  63 */       TeamPlugin.log((CoreException)e);
/*  64 */       return false;
/*     */     } finally {
/*     */       try {
/*     */         try {
/*  68 */           if (is1 != null) {
/*  69 */             is1.close();
/*     */           }
/*     */         } finally {
/*  72 */           if (is2 != null) {
/*  73 */             is2.close();
/*     */           }
/*     */         } 
/*  76 */       } catch (IOException iOException) {}
/*     */ 
/*     */       
/*  79 */       monitor.done();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean shouldIgnoreWhitespace() {
/*  84 */     return this.ignoreWhitespace;
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract boolean contentsEqual(IProgressMonitor paramIProgressMonitor, InputStream paramInputStream1, InputStream paramInputStream2, boolean paramBoolean);
/*     */ 
/*     */   
/*     */   private InputStream getContents(Object resource, IProgressMonitor monitor) throws TeamException {
/*     */     try {
/*  93 */       if (resource instanceof IFile)
/*  94 */         return new BufferedInputStream(((IFile)resource).getContents()); 
/*  95 */       if (resource instanceof IResourceVariant) {
/*  96 */         IResourceVariant remote = (IResourceVariant)resource;
/*  97 */         if (!remote.isContainer()) {
/*  98 */           return new BufferedInputStream(remote.getStorage(monitor)
/*  99 */               .getContents());
/*     */         }
/* 101 */       } else if (resource instanceof IFileRevision) {
/* 102 */         IFileRevision remote = (IFileRevision)resource;
/* 103 */         return new BufferedInputStream(remote.getStorage(monitor)
/* 104 */             .getContents());
/*     */       } 
/* 106 */       return null;
/* 107 */     } catch (CoreException e) {
/* 108 */       throw TeamException.asTeamException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\AbstractContentComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */