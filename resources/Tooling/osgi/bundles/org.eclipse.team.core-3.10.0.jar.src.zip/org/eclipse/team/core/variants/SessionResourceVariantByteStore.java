/*     */ package org.eclipse.team.core.variants;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionResourceVariantByteStore
/*     */   extends ResourceVariantByteStore
/*     */ {
/*  35 */   private static final byte[] NO_REMOTE = new byte[0];
/*  36 */   private Map<IResource, List<IResource>> membersCache = new HashMap<>();
/*     */   
/*  38 */   private Map<IResource, byte[]> syncBytesCache = (Map)new HashMap<>();
/*     */ 
/*     */   
/*     */   public boolean deleteBytes(IResource resource) throws TeamException {
/*  42 */     return flushBytes(resource, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  47 */     this.syncBytesCache.clear();
/*  48 */     this.membersCache.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean flushBytes(IResource resource, int depth) throws TeamException {
/*  53 */     if (getSyncBytesCache().containsKey(resource)) {
/*  54 */       if (depth != 0) {
/*  55 */         IResource[] members = members(resource); byte b; int i; IResource[] arrayOfIResource1;
/*  56 */         for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource child = arrayOfIResource1[b];
/*  57 */           flushBytes(child, (depth == 2) ? 2 : 0); b++; }
/*     */       
/*     */       } 
/*  60 */       getSyncBytesCache().remove(resource);
/*  61 */       internalRemoveFromParent(resource);
/*  62 */       return true;
/*     */     } 
/*  64 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getBytes(IResource resource) throws TeamException {
/*  69 */     byte[] syncBytes = internalGetSyncBytes(resource);
/*  70 */     if (syncBytes != null && equals(syncBytes, NO_REMOTE))
/*     */     {
/*  72 */       return null;
/*     */     }
/*  74 */     return syncBytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  82 */     return this.syncBytesCache.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource[] members(IResource resource) {
/*  87 */     List<IResource> members = this.membersCache.get(resource);
/*  88 */     if (members == null) {
/*  89 */       return new IResource[0];
/*     */     }
/*  91 */     return members.<IResource>toArray(new IResource[members.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setBytes(IResource resource, byte[] bytes) throws TeamException {
/*  96 */     Assert.isNotNull(bytes);
/*  97 */     byte[] oldBytes = internalGetSyncBytes(resource);
/*  98 */     if (oldBytes != null && equals(oldBytes, bytes)) return false; 
/*  99 */     internalSetSyncInfo(resource, bytes);
/* 100 */     return true;
/*     */   }
/*     */   
/*     */   private Map<IResource, byte[]> getSyncBytesCache() {
/* 104 */     return this.syncBytesCache;
/*     */   }
/*     */   
/*     */   private void internalAddToParent(IResource resource) {
/* 108 */     IContainer parent = resource.getParent();
/* 109 */     if (parent == null)
/* 110 */       return;  List<IResource> members = this.membersCache.get(parent);
/* 111 */     if (members == null) {
/* 112 */       members = new ArrayList<>();
/* 113 */       this.membersCache.put(parent, members);
/*     */     } 
/* 115 */     members.add(resource);
/*     */   }
/*     */   
/*     */   private byte[] internalGetSyncBytes(IResource resource) {
/* 119 */     return getSyncBytesCache().get(resource);
/*     */   }
/*     */   
/*     */   private void internalRemoveFromParent(IResource resource) {
/* 123 */     IContainer parent = resource.getParent();
/* 124 */     List members = this.membersCache.get(parent);
/* 125 */     if (members != null) {
/* 126 */       members.remove(resource);
/* 127 */       if (members.isEmpty()) {
/* 128 */         this.membersCache.remove(parent);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void internalSetSyncInfo(IResource resource, byte[] bytes) {
/* 134 */     getSyncBytesCache().put(resource, bytes);
/* 135 */     internalAddToParent(resource);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\variants\SessionResourceVariantByteStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */