/*     */ package org.eclipse.team.internal.core.mapping;
/*     */ 
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*     */ import org.eclipse.core.resources.mapping.ResourceMappingContext;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScope;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceMappingInputScope
/*     */   extends AbstractResourceMappingScope
/*     */ {
/*     */   ISynchronizationScope wrappedScope;
/*     */   
/*     */   public ResourceMappingInputScope(ISynchronizationScope wrappedScope) {
/*  32 */     this.wrappedScope = wrappedScope;
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceMapping[] getInputMappings() {
/*  37 */     return this.wrappedScope.getInputMappings();
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceMapping[] getMappings() {
/*  42 */     return getInputMappings();
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceTraversal[] getTraversals() {
/*  47 */     CompoundResourceTraversal result = new CompoundResourceTraversal();
/*  48 */     ResourceMapping[] mappings = getMappings(); byte b; int i; ResourceMapping[] arrayOfResourceMapping1;
/*  49 */     for (i = (arrayOfResourceMapping1 = mappings).length, b = 0; b < i; ) { ResourceMapping mapping = arrayOfResourceMapping1[b];
/*  50 */       ResourceTraversal[] traversals = getTraversals(mapping);
/*  51 */       result.addTraversals(traversals); b++; }
/*     */     
/*  53 */     return result.asTraversals();
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceTraversal[] getTraversals(ResourceMapping mapping) {
/*  58 */     if (!contains(mapping)) {
/*  59 */       return null;
/*     */     }
/*  61 */     return this.wrappedScope.getTraversals(mapping);
/*     */   }
/*     */   
/*     */   private boolean contains(ResourceMapping mapping) {
/*  65 */     ResourceMapping[] mappings = getMappings(); byte b; int i; ResourceMapping[] arrayOfResourceMapping1;
/*  66 */     for (i = (arrayOfResourceMapping1 = mappings).length, b = 0; b < i; ) { ResourceMapping child = arrayOfResourceMapping1[b];
/*  67 */       if (child.equals(mapping))
/*  68 */         return true; 
/*     */       b++; }
/*     */     
/*  71 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAdditionalMappings() {
/*  76 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAdditonalResources() {
/*  81 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISynchronizationScope asInputScope() {
/*  86 */     return (ISynchronizationScope)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public IProject[] getProjects() {
/*  91 */     return this.wrappedScope.getProjects();
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceMappingContext getContext() {
/*  96 */     return this.wrappedScope.getContext();
/*     */   }
/*     */ 
/*     */   
/*     */   public void refresh(ResourceMapping[] mappings) {
/* 101 */     this.wrappedScope.refresh(mappings);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\ResourceMappingInputScope.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */