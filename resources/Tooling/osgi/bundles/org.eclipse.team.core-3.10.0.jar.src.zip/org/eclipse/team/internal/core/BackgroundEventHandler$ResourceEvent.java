/*     */ package org.eclipse.team.internal.core;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceEvent
/*     */   extends BackgroundEventHandler.Event
/*     */ {
/*     */   private IResource resource;
/*     */   private int depth;
/*     */   
/*     */   public ResourceEvent(IResource resource, int type, int depth) {
/* 132 */     super(type);
/* 133 */     this.resource = resource;
/* 134 */     this.depth = depth;
/*     */   }
/*     */   public int getDepth() {
/* 137 */     return this.depth;
/*     */   }
/*     */   
/*     */   public IResource getResource() {
/* 141 */     return this.resource;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 145 */     StringBuilder buffer = new StringBuilder();
/* 146 */     buffer.append("resource: ");
/* 147 */     buffer.append(this.resource.getFullPath());
/* 148 */     buffer.append(" type: ");
/* 149 */     buffer.append(getTypeString());
/* 150 */     buffer.append(" depth: ");
/* 151 */     buffer.append(getDepthString());
/* 152 */     return buffer.toString();
/*     */   }
/*     */   protected String getDepthString() {
/* 155 */     switch (this.depth) {
/*     */       case 0:
/* 157 */         return "DEPTH_ZERO";
/*     */       case 1:
/* 159 */         return "DEPTH_ONE";
/*     */       case 2:
/* 161 */         return "DEPTH_INFINITE";
/*     */     } 
/* 163 */     return "INVALID";
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\BackgroundEventHandler$ResourceEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */