/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncByteConverter
/*     */ {
/*     */   protected static final byte SEPARATOR_BYTE = 47;
/*     */   
/*     */   public static byte[] setSlot(byte[] syncBytes, int slot, byte[] newBytes) throws TeamException {
/*  36 */     int start = startOfSlot(syncBytes, slot);
/*  37 */     if (start == -1) {
/*  38 */       throw new TeamException(NLS.bind(Messages.SyncByteConverter_1, new String[] { new String(syncBytes) }));
/*     */     }
/*  40 */     int end = startOfSlot(syncBytes, slot + 1);
/*  41 */     int totalLength = start + 1 + newBytes.length;
/*  42 */     if (end != -1) {
/*  43 */       totalLength += syncBytes.length - end;
/*     */     }
/*  45 */     byte[] result = new byte[totalLength];
/*  46 */     System.arraycopy(syncBytes, 0, result, 0, start + 1);
/*  47 */     System.arraycopy(newBytes, 0, result, start + 1, newBytes.length);
/*  48 */     if (end != -1) {
/*  49 */       System.arraycopy(syncBytes, end, result, start + 1 + newBytes.length, syncBytes.length - end);
/*     */     }
/*  51 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int startOfSlot(byte[] syncBytes, int slot) {
/*  64 */     int count = 0;
/*  65 */     for (int j = 0; j < syncBytes.length; j++) {
/*     */       
/*  67 */       count++;
/*  68 */       if (syncBytes[j] == 47 && count == slot) return j;
/*     */     
/*     */     } 
/*  71 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getOffsetOfDelimeter(byte[] bytes, byte delimiter, int start, int n) {
/*  83 */     int count = 0;
/*  84 */     for (int i = start; i < bytes.length; i++) {
/*  85 */       if (bytes[i] == delimiter) count++; 
/*  86 */       if (count == n) return i;
/*     */     
/*     */     } 
/*  89 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getSlot(byte[] bytes, int index, boolean includeRest) {
/*     */     int start, length;
/* 101 */     byte delimiter = 47;
/*     */     
/* 103 */     if (index == 0) {
/*     */       
/* 105 */       start = -1;
/*     */     } else {
/* 107 */       start = getOffsetOfDelimeter(bytes, delimiter, 0, index);
/* 108 */       if (start == -1) return null;
/*     */     
/*     */     } 
/* 111 */     int end = getOffsetOfDelimeter(bytes, delimiter, start + 1, 1);
/*     */ 
/*     */     
/* 114 */     if (end == -1 || includeRest) {
/* 115 */       length = bytes.length - start - 1;
/*     */     } else {
/* 117 */       length = end - start - 1;
/*     */     } 
/* 119 */     byte[] result = new byte[length];
/* 120 */     System.arraycopy(bytes, start + 1, result, 0, length);
/* 121 */     return result;
/*     */   }
/*     */   
/*     */   public static byte[] toBytes(String[] slots) {
/* 125 */     StringBuilder buffer = new StringBuilder(); byte b; int i; String[] arrayOfString;
/* 126 */     for (i = (arrayOfString = slots).length, b = 0; b < i; ) { String string = arrayOfString[b];
/* 127 */       buffer.append(string);
/* 128 */       buffer.append(new String(new byte[] { 47 })); b++; }
/*     */     
/* 130 */     return buffer.toString().getBytes();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SyncByteConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */