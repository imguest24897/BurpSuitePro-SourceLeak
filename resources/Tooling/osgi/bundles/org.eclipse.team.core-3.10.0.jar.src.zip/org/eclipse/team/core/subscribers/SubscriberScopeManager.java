/*     */ package org.eclipse.team.core.subscribers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.resources.mapping.ModelProvider;
/*     */ import org.eclipse.core.resources.mapping.RemoteResourceMappingContext;
/*     */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*     */ import org.eclipse.core.resources.mapping.ResourceMappingContext;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScopeParticipant;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScopeParticipantFactory;
/*     */ import org.eclipse.team.core.mapping.provider.SynchronizationScopeManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubscriberScopeManager
/*     */   extends SynchronizationScopeManager
/*     */   implements ISubscriberChangeListener
/*     */ {
/*     */   private final Subscriber subscriber;
/*  49 */   private Map<ModelProvider, ISynchronizationScopeParticipant> participants = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubscriberScopeManager(String name, ResourceMapping[] inputMappings, Subscriber subscriber, boolean consultModels) {
/*  59 */     this(name, inputMappings, subscriber, SubscriberResourceMappingContext.createContext(subscriber), consultModels);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubscriberScopeManager(String name, ResourceMapping[] inputMappings, Subscriber subscriber, RemoteResourceMappingContext context, boolean consultModels) {
/*  71 */     super(name, inputMappings, (ResourceMappingContext)context, consultModels);
/*  72 */     this.subscriber = subscriber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Subscriber getSubscriber() {
/*  80 */     return this.subscriber;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  85 */     for (ISynchronizationScopeParticipant participant : this.participants.values()) {
/*  86 */       participant.dispose();
/*     */     }
/*  88 */     super.dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   public void initialize(IProgressMonitor monitor) throws CoreException {
/*  93 */     ResourcesPlugin.getWorkspace().run(monitor1 -> {
/*     */           initialize(monitor1);
/*     */           hookupParticipants();
/*     */           getSubscriber().addListener(this);
/*  97 */         }getSchedulingRule(), 0, monitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceTraversal[] refresh(ResourceMapping[] mappings, IProgressMonitor monitor) throws CoreException {
/* 102 */     List<ResourceTraversal[]> result = (List)new ArrayList<>(1);
/* 103 */     ResourcesPlugin.getWorkspace().run(monitor1 -> {
/*     */           paramList.add(refresh(paramArrayOfResourceMapping, monitor1));
/*     */           hookupParticipants();
/* 106 */         }getSchedulingRule(), 0, monitor);
/* 107 */     if (result.isEmpty())
/* 108 */       return new ResourceTraversal[0]; 
/* 109 */     return result.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void hookupParticipants() {
/*     */     byte b;
/*     */     int i;
/*     */     ModelProvider[] arrayOfModelProvider;
/* 119 */     for (i = (arrayOfModelProvider = getScope().getModelProviders()).length, b = 0; b < i; ) { ModelProvider provider = arrayOfModelProvider[b];
/* 120 */       if (!this.participants.containsKey(provider)) {
/* 121 */         ISynchronizationScopeParticipant p = createParticipant(provider);
/* 122 */         if (p != null) {
/* 123 */           this.participants.put(provider, p);
/*     */         }
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ISynchronizationScopeParticipant createParticipant(ModelProvider provider) {
/* 133 */     Object factoryObject = provider.getAdapter(ISynchronizationScopeParticipantFactory.class);
/* 134 */     if (factoryObject instanceof ISynchronizationScopeParticipantFactory) {
/* 135 */       ISynchronizationScopeParticipantFactory factory = (ISynchronizationScopeParticipantFactory)factoryObject;
/* 136 */       return factory.createParticipant(provider, getScope());
/*     */     } 
/* 138 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscriberResourceChanged(ISubscriberChangeEvent[] deltas) {
/* 143 */     List<IResource> changedResources = new ArrayList<>();
/* 144 */     List<IProject> changedProjects = new ArrayList<>(); byte b; int i; ISubscriberChangeEvent[] arrayOfISubscriberChangeEvent;
/* 145 */     for (i = (arrayOfISubscriberChangeEvent = deltas).length, b = 0; b < i; ) { ISubscriberChangeEvent event = arrayOfISubscriberChangeEvent[b];
/* 146 */       if ((event.getFlags() & 0x6) != 0) {
/* 147 */         changedProjects.add(event.getResource().getProject());
/*     */       }
/* 149 */       if ((event.getFlags() & 0x1) != 0)
/* 150 */         changedResources.add(event.getResource()); 
/*     */       b++; }
/*     */     
/* 153 */     fireChange(changedResources.<IResource>toArray(new IResource[changedResources.size()]), changedProjects.<IProject>toArray(new IProject[changedProjects.size()]));
/*     */   }
/*     */   
/*     */   private void fireChange(final IResource[] resources, final IProject[] projects) {
/* 157 */     final Set<ResourceMapping> result = new HashSet<>();
/* 158 */     for (ISynchronizationScopeParticipant participant : this.participants.values()) {
/* 159 */       SafeRunner.run(new ISafeRunnable()
/*     */           {
/*     */             public void run() throws Exception {
/*     */               ResourceMapping[] arrayOfResourceMapping;
/* 163 */               int i = (arrayOfResourceMapping = participant.handleContextChange(SubscriberScopeManager.this.getScope(), resources, projects)).length; byte b = 0; for (; b < i; b++) { ResourceMapping mapping = arrayOfResourceMapping[b];
/* 164 */                 result.add(mapping); }
/*     */             
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             public void handleException(Throwable exception) {}
/*     */           });
/*     */     } 
/* 173 */     if (!result.isEmpty())
/* 174 */       refresh(result.<ResourceMapping>toArray(new ResourceMapping[result.size()])); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\subscribers\SubscriberScopeManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */