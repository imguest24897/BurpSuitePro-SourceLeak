package org.eclipse.team.core.diff;

import org.eclipse.core.runtime.IPath;

public interface ITwoWayDiff extends IDiff {
  public static final int CONTENT = 256;
  
  public static final int MOVE_FROM = 512;
  
  public static final int MOVE_TO = 1024;
  
  public static final int COPY_FROM = 2048;
  
  public static final int REPLACE = 4096;
  
  int getFlags();
  
  IPath getFromPath();
  
  IPath getToPath();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\diff\ITwoWayDiff.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */