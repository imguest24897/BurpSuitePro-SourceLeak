package org.eclipse.team.core.mapping;

import org.eclipse.core.resources.IResource;
import org.eclipse.team.core.diff.ITwoWayDiff;
import org.eclipse.team.core.history.IFileRevision;

public interface IResourceDiff extends ITwoWayDiff {
  public static final int OPEN = 65536;
  
  public static final int DESCRIPTION = 131072;
  
  IResource getResource();
  
  IFileRevision getBeforeState();
  
  IFileRevision getAfterState();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\IResourceDiff.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */