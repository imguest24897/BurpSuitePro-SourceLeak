/*    */ package org.eclipse.team.internal.core.subscribers;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.team.core.subscribers.Subscriber;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SubscriberDiffCollector
/*    */   extends SubscriberResourceCollector
/*    */ {
/*    */   public SubscriberDiffCollector(Subscriber subscriber) {
/* 82 */     super(subscriber);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean hasMembers(IResource resource) {
/* 87 */     return ((SubscriberDiffTreeEventHandler.this.tree.members(resource)).length > 0);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void remove(IResource resource) {
/* 92 */     SubscriberDiffTreeEventHandler.this.remove(resource);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void change(IResource resource, int depth) {
/* 97 */     SubscriberDiffTreeEventHandler.this.change(resource, depth);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SubscriberDiffTreeEventHandler$SubscriberDiffCollector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */