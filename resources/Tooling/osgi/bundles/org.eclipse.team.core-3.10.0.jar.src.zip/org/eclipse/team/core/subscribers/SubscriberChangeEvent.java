/*    */ package org.eclipse.team.core.subscribers;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubscriberChangeEvent
/*    */   implements ISubscriberChangeEvent
/*    */ {
/*    */   private Subscriber subscriber;
/*    */   private int flags;
/*    */   private IResource resource;
/*    */   
/*    */   public SubscriberChangeEvent(Subscriber subscriber, int flags, IResource resource) {
/* 40 */     this.subscriber = subscriber;
/* 41 */     this.flags = flags;
/* 42 */     this.resource = resource;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getFlags() {
/* 47 */     return this.flags;
/*    */   }
/*    */ 
/*    */   
/*    */   public IResource getResource() {
/* 52 */     return this.resource;
/*    */   }
/*    */ 
/*    */   
/*    */   public Subscriber getSubscriber() {
/* 57 */     return this.subscriber;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static SubscriberChangeEvent[] asSyncChangedDeltas(Subscriber subscriber, IResource[] resources) {
/* 68 */     SubscriberChangeEvent[] deltas = new SubscriberChangeEvent[resources.length];
/* 69 */     for (int i = 0; i < resources.length; i++) {
/* 70 */       IResource resource = resources[i];
/* 71 */       deltas[i] = new SubscriberChangeEvent(subscriber, 1, resource);
/*    */     } 
/* 73 */     return deltas;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\subscribers\SubscriberChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */