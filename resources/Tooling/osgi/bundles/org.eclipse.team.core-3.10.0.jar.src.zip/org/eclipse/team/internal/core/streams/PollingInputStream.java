/*     */ package org.eclipse.team.internal.core.streams;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InterruptedIOException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PollingInputStream
/*     */   extends FilterInputStream
/*     */ {
/*     */   private int numAttempts;
/*     */   private IProgressMonitor monitor;
/*     */   private boolean cancellable;
/*     */   
/*     */   public PollingInputStream(InputStream in, int numAttempts, IProgressMonitor monitor) {
/*  50 */     super(in);
/*  51 */     this.numAttempts = numAttempts;
/*  52 */     this.monitor = monitor;
/*  53 */     this.cancellable = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws InterruptedIOException {
/*     */     boolean stop;
/*  67 */     int attempts = 0;
/*     */     try {
/*  69 */       readPendingInput();
/*  70 */     } catch (IOException e) {
/*     */ 
/*     */       
/*  73 */       TeamPlugin.log(4, e.getMessage(), e);
/*     */     } finally {
/*  75 */       boolean bool = false;
/*  76 */       while (!bool) {
/*     */         try {
/*  78 */           if (this.in != null)
/*  79 */             this.in.close(); 
/*  80 */           bool = true;
/*  81 */         } catch (InterruptedIOException interruptedIOException) {
/*  82 */           if (checkCancellation()) throw new OperationCanceledException(); 
/*  83 */           if (++attempts == this.numAttempts)
/*  84 */             throw new InterruptedIOException(Messages.PollingInputStream_closeTimeout); 
/*  85 */           if (Policy.DEBUG_STREAMS) System.out.println("close retry=" + attempts); 
/*  86 */         } catch (IOException iOException) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 103 */     int attempts = 0;
/*     */     while (true) {
/* 105 */       if (checkCancellation()) throw new OperationCanceledException(); 
/*     */       try {
/* 107 */         return this.in.read();
/* 108 */       } catch (InterruptedIOException interruptedIOException) {
/* 109 */         if (++attempts == this.numAttempts)
/* 110 */           throw new InterruptedIOException(Messages.PollingInputStream_readTimeout); 
/* 111 */         if (Policy.DEBUG_STREAMS) System.out.println("read retry=" + attempts);
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] buffer, int off, int len) throws IOException {
/* 129 */     int attempts = 0;
/*     */     while (true) {
/* 131 */       if (checkCancellation()) throw new OperationCanceledException(); 
/*     */       try {
/* 133 */         return this.in.read(buffer, off, len);
/* 134 */       } catch (InterruptedIOException e) {
/* 135 */         if (e.bytesTransferred != 0) return e.bytesTransferred; 
/* 136 */         if (++attempts == this.numAttempts)
/* 137 */           throw new InterruptedIOException(Messages.PollingInputStream_readTimeout); 
/* 138 */         if (Policy.DEBUG_STREAMS) System.out.println("read retry=" + attempts);
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long skip(long count) throws IOException {
/* 154 */     int attempts = 0;
/*     */     while (true) {
/* 156 */       if (checkCancellation()) throw new OperationCanceledException(); 
/*     */       try {
/* 158 */         return this.in.skip(count);
/* 159 */       } catch (InterruptedIOException e) {
/* 160 */         if (e.bytesTransferred != 0) return e.bytesTransferred; 
/* 161 */         if (++attempts == this.numAttempts)
/* 162 */           throw new InterruptedIOException(Messages.PollingInputStream_readTimeout); 
/* 163 */         if (Policy.DEBUG_STREAMS) System.out.println("read retry=" + attempts);
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void readPendingInput() throws IOException {
/*     */     int available;
/* 173 */     byte[] buffer = new byte[2048];
/*     */     do {
/* 175 */       available = this.in.available();
/* 176 */       if (available < 1)
/* 177 */         break;  if (available <= buffer.length) continue;  available = buffer.length;
/* 178 */     } while (this.in.read(buffer, 0, available) >= 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIsCancellable(boolean cancellable) {
/* 189 */     this.cancellable = cancellable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkCancellation() {
/* 199 */     if (this.cancellable) {
/* 200 */       return this.monitor.isCanceled();
/*     */     }
/* 202 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\streams\PollingInputStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */