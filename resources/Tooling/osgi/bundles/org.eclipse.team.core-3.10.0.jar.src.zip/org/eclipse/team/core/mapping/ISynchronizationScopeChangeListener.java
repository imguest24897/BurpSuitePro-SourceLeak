package org.eclipse.team.core.mapping;

import java.util.EventListener;
import org.eclipse.core.resources.mapping.ResourceMapping;
import org.eclipse.core.resources.mapping.ResourceTraversal;

public interface ISynchronizationScopeChangeListener extends EventListener {
  void scopeChanged(ISynchronizationScope paramISynchronizationScope, ResourceMapping[] paramArrayOfResourceMapping, ResourceTraversal[] paramArrayOfResourceTraversal);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\ISynchronizationScopeChangeListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */