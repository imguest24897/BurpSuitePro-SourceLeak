/*     */ package org.eclipse.team.core.mapping.provider;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.resources.mapping.IModelProviderDescriptor;
/*     */ import org.eclipse.core.resources.mapping.ModelProvider;
/*     */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*     */ import org.eclipse.core.resources.mapping.ResourceMappingContext;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.MultiRule;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScope;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScopeManager;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ import org.eclipse.team.internal.core.mapping.CompoundResourceTraversal;
/*     */ import org.eclipse.team.internal.core.mapping.ResourceMappingScope;
/*     */ import org.eclipse.team.internal.core.mapping.ScopeChangeEvent;
/*     */ import org.eclipse.team.internal.core.mapping.ScopeManagerEventHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SynchronizationScopeManager
/*     */   extends PlatformObject
/*     */   implements ISynchronizationScopeManager
/*     */ {
/*     */   private static final int MAX_ITERATION = 10;
/*     */   private final ResourceMappingContext context;
/*     */   private final boolean consultModels;
/*     */   private ISynchronizationScope scope;
/*     */   private boolean initialized;
/*     */   private ScopeManagerEventHandler handler;
/*     */   private final String name;
/*     */   
/*     */   public static ResourceMapping[] getMappingsFromProviders(ResourceTraversal[] traversals, ResourceMappingContext context, IProgressMonitor monitor) throws CoreException {
/* 100 */     Set<ResourceMapping> result = new HashSet<>();
/* 101 */     IModelProviderDescriptor[] descriptors = 
/* 102 */       ModelProvider.getModelProviderDescriptors(); byte b; int i; IModelProviderDescriptor[] arrayOfIModelProviderDescriptor1;
/* 103 */     for (i = (arrayOfIModelProviderDescriptor1 = descriptors).length, b = 0; b < i; ) { IModelProviderDescriptor descriptor = arrayOfIModelProviderDescriptor1[b];
/* 104 */       ResourceMapping[] mappings = getMappings(descriptor, traversals, 
/* 105 */           context, monitor);
/* 106 */       result.addAll(Arrays.asList(mappings));
/* 107 */       Policy.checkCanceled(monitor); b++; }
/*     */     
/* 109 */     return result.<ResourceMapping>toArray(new ResourceMapping[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ResourceMapping[] getMappings(IModelProviderDescriptor descriptor, ResourceTraversal[] traversals, ResourceMappingContext context, IProgressMonitor monitor) throws CoreException {
/* 116 */     ResourceTraversal[] matchingTraversals = descriptor.getMatchingTraversals(
/* 117 */         traversals);
/* 118 */     return descriptor.getModelProvider().getMappings(matchingTraversals, 
/* 119 */         context, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SynchronizationScopeManager(String name, ResourceMapping[] inputMappings, ResourceMappingContext resourceMappingContext, boolean consultModels) {
/* 134 */     this.name = name;
/* 135 */     this.context = resourceMappingContext;
/* 136 */     this.consultModels = consultModels;
/* 137 */     this.scope = createScope(inputMappings);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInitialized() {
/* 142 */     return this.initialized;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule getSchedulingRule() {
/* 154 */     Set<IProject> projects = new HashSet<>();
/* 155 */     ResourceMapping[] mappings = this.scope.getInputMappings(); byte b; int i; ResourceMapping[] arrayOfResourceMapping1;
/* 156 */     for (i = (arrayOfResourceMapping1 = mappings).length, b = 0; b < i; ) { ResourceMapping mapping = arrayOfResourceMapping1[b];
/* 157 */       Object modelObject = mapping.getModelObject();
/* 158 */       if (modelObject instanceof IResource) {
/* 159 */         IResource resource = (IResource)modelObject;
/* 160 */         if (resource.getType() == 8)
/*     */         {
/*     */           
/* 163 */           return (ISchedulingRule)ResourcesPlugin.getWorkspace().getRoot(); } 
/* 164 */         projects.add(resource.getProject());
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 169 */         return (ISchedulingRule)ResourcesPlugin.getWorkspace().getRoot();
/*     */       }  b++; }
/*     */     
/* 172 */     return MultiRule.combine((ISchedulingRule[])projects.toArray((Object[])new IProject[projects.size()]));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(IProgressMonitor monitor) throws CoreException {
/* 178 */     ResourcesPlugin.getWorkspace().run(this::internalPrepareContext, 
/* 179 */         getSchedulingRule(), 0, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceTraversal[] refresh(ResourceMapping[] mappings, IProgressMonitor monitor) throws CoreException {
/* 185 */     ResourceTraversal[][] traversals = { {} };
/* 186 */     IWorkspace workspace = ResourcesPlugin.getWorkspace();
/* 187 */     workspace.run(monitor1 -> paramArrayOfResourceTraversal[0] = internalRefreshScope(paramArrayOfResourceMapping, true, monitor1), 
/* 188 */         getSchedulingRule(), 0, monitor);
/* 189 */     return traversals[0];
/*     */   }
/*     */   private void internalPrepareContext(IProgressMonitor monitor) throws CoreException {
/*     */     ResourceTraversal[] newTraversals;
/* 193 */     if (this.initialized)
/*     */       return; 
/* 195 */     monitor.beginTask(null, -1);
/*     */     
/* 197 */     ((ResourceMappingScope)this.scope).reset();
/* 198 */     ResourceMapping[] targetMappings = this.scope.getInputMappings();
/*     */     
/* 200 */     boolean firstTime = true;
/* 201 */     boolean hasAdditionalResources = false;
/* 202 */     int count = 0;
/*     */     do {
/* 204 */       Policy.checkCanceled(monitor);
/* 205 */       newTraversals = addMappingsToScope(targetMappings, 
/* 206 */           Policy.subMonitorFor(monitor, -1));
/* 207 */       if (newTraversals.length <= 0 || !this.consultModels)
/* 208 */         continue;  ResourceTraversal[] adjusted = adjustInputTraversals(newTraversals);
/* 209 */       targetMappings = getMappingsFromProviders(adjusted, 
/* 210 */           this.context, 
/* 211 */           Policy.subMonitorFor(monitor, -1));
/* 212 */       if (firstTime) {
/* 213 */         firstTime = false;
/* 214 */       } else if (!hasAdditionalResources) {
/* 215 */         hasAdditionalResources = (newTraversals.length != 0);
/*     */       }
/*     */     
/* 218 */     } while ((this.consultModels & ((newTraversals.length != 0) ? 1 : 0)) != 0 && count++ < 10);
/* 219 */     setHasAdditionalMappings(this.scope, (this.consultModels && internalHasAdditionalMappings()));
/* 220 */     setHasAdditionalResources((this.consultModels && hasAdditionalResources));
/* 221 */     monitor.done();
/* 222 */     this.initialized = true;
/* 223 */     fireMappingsChangedEvent(this.scope.getMappings(), this.scope.getTraversals());
/*     */   }
/*     */   
/*     */   private ResourceTraversal[] internalRefreshScope(ResourceMapping[] mappings, boolean checkForContraction, IProgressMonitor monitor) throws CoreException {
/* 227 */     monitor.beginTask(null, 100 * mappings.length + 100);
/* 228 */     ScopeChangeEvent change = new ScopeChangeEvent(this.scope);
/* 229 */     CompoundResourceTraversal refreshTraversals = new CompoundResourceTraversal();
/* 230 */     CompoundResourceTraversal removedTraversals = new CompoundResourceTraversal(); byte b; int i; ResourceMapping[] arrayOfResourceMapping;
/* 231 */     for (i = (arrayOfResourceMapping = mappings).length, b = 0; b < i; ) { ResourceMapping mapping = arrayOfResourceMapping[b];
/* 232 */       ResourceTraversal[] previousTraversals = this.scope.getTraversals(mapping);
/* 233 */       ResourceTraversal[] mappingTraversals = mapping.getTraversals(
/* 234 */           this.context, Policy.subMonitorFor(monitor, 100));
/* 235 */       refreshTraversals.addTraversals(mappingTraversals);
/* 236 */       ResourceTraversal[] uncovered = getUncoveredTraversals(mappingTraversals);
/* 237 */       if (checkForContraction && previousTraversals != null && previousTraversals.length > 0) {
/* 238 */         ResourceTraversal[] removed = getUncoveredTraversals(mappingTraversals, previousTraversals);
/* 239 */         removedTraversals.addTraversals(removed);
/*     */       } 
/* 241 */       if (uncovered.length > 0) {
/* 242 */         change.setExpanded(true);
/* 243 */         ResourceTraversal[] result = performExpandScope(mapping, mappingTraversals, uncovered, monitor);
/* 244 */         refreshTraversals.addTraversals(result);
/*     */       } 
/*     */       b++; }
/*     */     
/* 248 */     if (checkForContraction && (removedTraversals.getRoots()).length > 0) {
/*     */ 
/*     */       
/* 251 */       ((ResourceMappingScope)this.scope).reset();
/* 252 */       internalRefreshScope(this.scope.getInputMappings(), false, monitor);
/* 253 */       change.setContracted(true);
/*     */     } 
/*     */     
/* 256 */     if (change.shouldFireChange())
/* 257 */       fireMappingsChangedEvent(change.getChangedMappings(), change.getChangedTraversals(refreshTraversals)); 
/* 258 */     monitor.done();
/* 259 */     return refreshTraversals.asTraversals();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ResourceTraversal[] getUncoveredTraversals(ResourceTraversal[] newTraversals, ResourceTraversal[] previousTraversals) {
/* 265 */     CompoundResourceTraversal t = new CompoundResourceTraversal();
/* 266 */     t.addTraversals(newTraversals);
/* 267 */     return t.getUncoveredTraversals(previousTraversals);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResourceTraversal[] performExpandScope(ResourceMapping mapping, ResourceTraversal[] mappingTraversals, ResourceTraversal[] uncovered, IProgressMonitor monitor) throws CoreException {
/* 274 */     ResourceMapping ancestor = findAncestor(mapping);
/* 275 */     if (ancestor == null) {
/* 276 */       uncovered = addMappingToScope(mapping, mappingTraversals);
/* 277 */       addResourcesToScope(uncovered, monitor);
/* 278 */       return mappingTraversals;
/*     */     } 
/* 280 */     ResourceTraversal[] ancestorTraversals = ancestor.getTraversals(
/* 281 */         this.context, Policy.subMonitorFor(monitor, 100));
/* 282 */     uncovered = addMappingToScope(ancestor, ancestorTraversals);
/* 283 */     addResourcesToScope(uncovered, monitor);
/* 284 */     return ancestorTraversals;
/*     */   }
/*     */ 
/*     */   
/*     */   private ResourceMapping findAncestor(ResourceMapping mapping) {
/* 289 */     ResourceMapping[] mappings = this.scope.getMappings(mapping.getModelProviderId()); byte b; int i; ResourceMapping[] arrayOfResourceMapping1;
/* 290 */     for (i = (arrayOfResourceMapping1 = mappings).length, b = 0; b < i; ) { ResourceMapping m = arrayOfResourceMapping1[b];
/* 291 */       if (m.contains(mapping))
/* 292 */         return m; 
/*     */       b++; }
/*     */     
/* 295 */     return null;
/*     */   }
/*     */   
/*     */   private ResourceTraversal[] getUncoveredTraversals(ResourceTraversal[] traversals) {
/* 299 */     return ((ResourceMappingScope)this.scope).getCompoundTraversal().getUncoveredTraversals(traversals);
/*     */   }
/*     */   
/*     */   private void addResourcesToScope(ResourceTraversal[] newTraversals, IProgressMonitor monitor) throws CoreException {
/* 303 */     if (!this.consultModels) {
/*     */       return;
/*     */     }
/* 306 */     int count = 0;
/*     */     do {
/* 308 */       ResourceTraversal[] adjusted = adjustInputTraversals(newTraversals);
/* 309 */       ResourceMapping[] targetMappings = getMappingsFromProviders(adjusted, 
/* 310 */           this.context, Policy.subMonitorFor(monitor, -1));
/* 311 */       newTraversals = addMappingsToScope(targetMappings, 
/* 312 */           Policy.subMonitorFor(monitor, -1));
/* 313 */     } while (newTraversals.length != 0 && count++ < 10);
/* 314 */     if (!this.scope.hasAdditionalMappings()) {
/* 315 */       setHasAdditionalMappings(this.scope, internalHasAdditionalMappings());
/*     */     }
/* 317 */     if (!this.scope.hasAdditonalResources()) {
/* 318 */       setHasAdditionalResources(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fireMappingsChangedEvent(ResourceMapping[] newMappings, ResourceTraversal[] newTraversals) {
/* 328 */     ((ResourceMappingScope)this.scope).fireTraversalsChangedEvent(newTraversals, newMappings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setHasAdditionalMappings(ISynchronizationScope scope, boolean hasAdditionalMappings) {
/* 340 */     ((ResourceMappingScope)scope).setHasAdditionalMappings(hasAdditionalMappings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setHasAdditionalResources(boolean hasAdditionalResources) {
/* 351 */     ((ResourceMappingScope)this.scope).setHasAdditionalResources(hasAdditionalResources);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ISynchronizationScope createScope(ResourceMapping[] inputMappings) {
/* 363 */     return (ISynchronizationScope)new ResourceMappingScope(inputMappings, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceTraversal[] adjustInputTraversals(ResourceTraversal[] traversals) {
/* 381 */     return traversals;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private ResourceTraversal[] addMappingsToScope(ResourceMapping[] targetMappings, IProgressMonitor monitor) throws CoreException {
/* 387 */     CompoundResourceTraversal result = new CompoundResourceTraversal();
/* 388 */     ResourceMappingContext context = this.context; byte b; int i; ResourceMapping[] arrayOfResourceMapping;
/* 389 */     for (i = (arrayOfResourceMapping = targetMappings).length, b = 0; b < i; ) { ResourceMapping mapping = arrayOfResourceMapping[b];
/* 390 */       if (this.scope.getTraversals(mapping) == null) {
/* 391 */         ResourceTraversal[] traversals = mapping.getTraversals(context, 
/* 392 */             Policy.subMonitorFor(monitor, 100));
/* 393 */         ResourceTraversal[] newOnes = addMappingToScope(mapping, traversals);
/* 394 */         result.addTraversals(newOnes);
/*     */       } 
/* 396 */       Policy.checkCanceled(monitor); b++; }
/*     */     
/* 398 */     return result.asTraversals();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ResourceTraversal[] addMappingToScope(ResourceMapping mapping, ResourceTraversal[] traversals) {
/* 412 */     return ((ResourceMappingScope)this.scope).addMapping(mapping, traversals);
/*     */   }
/*     */   
/*     */   private boolean internalHasAdditionalMappings() {
/* 416 */     ResourceMapping[] inputMappings = this.scope.getInputMappings();
/* 417 */     ResourceMapping[] mappings = this.scope.getMappings();
/* 418 */     if (inputMappings.length == mappings.length) {
/* 419 */       Set<ResourceMapping> testSet = new HashSet<>();
/* 420 */       Collections.addAll(testSet, mappings); byte b; int i; ResourceMapping[] arrayOfResourceMapping;
/* 421 */       for (i = (arrayOfResourceMapping = inputMappings).length, b = 0; b < i; ) { ResourceMapping mapping = arrayOfResourceMapping[b];
/* 422 */         if (!testSet.contains(mapping))
/* 423 */           return true; 
/*     */         b++; }
/*     */       
/* 426 */       return false;
/*     */     } 
/* 428 */     return true;
/*     */   }
/*     */   
/*     */   public ResourceMappingContext getContext() {
/* 432 */     return this.context;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISynchronizationScope getScope() {
/* 437 */     return this.scope;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 442 */     if (this.handler != null) {
/* 443 */       this.handler.shutdown();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refresh(ResourceMapping[] mappings) {
/* 452 */     getHandler().refresh(mappings);
/*     */   }
/*     */   
/*     */   private synchronized ScopeManagerEventHandler getHandler() {
/* 456 */     if (this.handler == null)
/* 457 */       this.handler = new ScopeManagerEventHandler(this); 
/* 458 */     return this.handler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 467 */     return this.name;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\provider\SynchronizationScopeManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */