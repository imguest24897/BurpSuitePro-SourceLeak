/*    */ package org.eclipse.team.core;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StringMappingWrapper
/*    */   implements IFileTypeInfo
/*    */ {
/*    */   private final IStringMapping fMapping;
/*    */   
/*    */   public StringMappingWrapper(IStringMapping mapping) {
/* 73 */     this.fMapping = mapping;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getExtension() {
/* 78 */     return this.fMapping.getString();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getType() {
/* 83 */     return this.fMapping.getType();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\Team$StringMappingWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */