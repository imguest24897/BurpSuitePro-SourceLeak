package org.eclipse.team.core.diff;

import org.eclipse.core.runtime.IPath;

public interface IDiff {
  public static final int NO_CHANGE = 0;
  
  public static final int ADD = 1;
  
  public static final int REMOVE = 2;
  
  public static final int CHANGE = 4;
  
  IPath getPath();
  
  int getKind();
  
  String toDiffString();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\diff\IDiff.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */