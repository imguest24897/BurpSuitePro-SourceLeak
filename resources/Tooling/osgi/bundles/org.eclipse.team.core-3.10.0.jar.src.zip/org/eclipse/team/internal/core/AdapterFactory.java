/*    */ package org.eclipse.team.internal.core;
/*    */ 
/*    */ import org.eclipse.core.resources.mapping.ModelProvider;
/*    */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*    */ import org.eclipse.core.runtime.IAdapterFactory;
/*    */ import org.eclipse.team.internal.core.mapping.ModelProviderResourceMapping;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AdapterFactory
/*    */   implements IAdapterFactory
/*    */ {
/*    */   public <T> T getAdapter(Object adaptableObject, Class<T> adapterType) {
/* 26 */     if (adaptableObject instanceof ModelProvider && adapterType == ResourceMapping.class) {
/* 27 */       ModelProvider mp = (ModelProvider)adaptableObject;
/* 28 */       return (T)new ModelProviderResourceMapping(mp);
/*    */     } 
/* 30 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?>[] getAdapterList() {
/* 35 */     return new Class[] { ResourceMapping.class };
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\AdapterFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */