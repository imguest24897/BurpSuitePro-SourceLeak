package org.eclipse.team.core;

import org.eclipse.core.resources.IStorage;

public interface IFileContentManager {
  int getType(IStorage paramIStorage);
  
  boolean isKnownFilename(String paramString);
  
  boolean isKnownExtension(String paramString);
  
  int getTypeForName(String paramString);
  
  int getTypeForExtension(String paramString);
  
  void addNameMappings(String[] paramArrayOfString, int[] paramArrayOfint);
  
  void addExtensionMappings(String[] paramArrayOfString, int[] paramArrayOfint);
  
  void setNameMappings(String[] paramArrayOfString, int[] paramArrayOfint);
  
  void setExtensionMappings(String[] paramArrayOfString, int[] paramArrayOfint);
  
  IStringMapping[] getNameMappings();
  
  IStringMapping[] getExtensionMappings();
  
  IStringMapping[] getDefaultNameMappings();
  
  IStringMapping[] getDefaultExtensionMappings();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\IFileContentManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */