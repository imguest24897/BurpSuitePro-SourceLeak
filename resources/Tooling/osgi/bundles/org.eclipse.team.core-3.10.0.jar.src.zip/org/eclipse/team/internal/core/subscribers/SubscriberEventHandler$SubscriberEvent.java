/*    */ package org.eclipse.team.internal.core.subscribers;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*    */ import org.eclipse.team.internal.core.BackgroundEventHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SubscriberEvent
/*    */   extends BackgroundEventHandler.ResourceEvent
/*    */ {
/*    */   static final int REMOVAL = 1;
/*    */   static final int CHANGE = 2;
/*    */   static final int INITIALIZE = 3;
/*    */   
/*    */   SubscriberEvent(IResource resource, int type, int depth) {
/* 70 */     super(resource, type, depth);
/*    */   }
/*    */   
/*    */   protected String getTypeString() {
/* 74 */     switch (getType()) {
/*    */       case 1:
/* 76 */         return "REMOVAL";
/*    */       case 2:
/* 78 */         return "CHANGE";
/*    */       case 3:
/* 80 */         return "INITIALIZE";
/*    */     } 
/* 82 */     return "INVALID";
/*    */   }
/*    */   
/*    */   public ResourceTraversal asTraversal() {
/* 86 */     return new ResourceTraversal(new IResource[] { getResource() }, getDepth(), 0);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SubscriberEventHandler$SubscriberEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */