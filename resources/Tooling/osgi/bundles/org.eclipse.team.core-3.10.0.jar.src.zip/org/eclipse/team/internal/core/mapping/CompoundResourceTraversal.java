/*     */ package org.eclipse.team.internal.core.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompoundResourceTraversal
/*     */ {
/*  33 */   private Set<IResource> deepFolders = new HashSet<>();
/*  34 */   private Set<IResource> shallowFolders = new HashSet<>();
/*  35 */   private Set<IResource> zeroFolders = new HashSet<>();
/*  36 */   private Set<IResource> files = new HashSet<>(); public synchronized void addTraversals(ResourceTraversal[] traversals) { byte b;
/*     */     int i;
/*     */     ResourceTraversal[] arrayOfResourceTraversal;
/*  39 */     for (i = (arrayOfResourceTraversal = traversals).length, b = 0; b < i; ) { ResourceTraversal traversal = arrayOfResourceTraversal[b];
/*  40 */       addTraversal(traversal);
/*     */       b++; }
/*     */      }
/*     */   
/*     */   public synchronized void addTraversal(ResourceTraversal traversal) {
/*  45 */     IResource[] resources = traversal.getResources(); byte b; int i; IResource[] arrayOfIResource1;
/*  46 */     for (i = (arrayOfIResource1 = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource1[b];
/*  47 */       addResource(resource, traversal.getDepth());
/*     */       b++; }
/*     */   
/*     */   }
/*     */   public synchronized void addResource(IResource resource, int depth) {
/*  52 */     if (resource.getType() == 1 && 
/*  53 */       !isCovered(resource, 0)) {
/*  54 */       this.files.add(resource);
/*     */     }
/*  56 */     switch (depth) {
/*     */       case 2:
/*  58 */         addDeepFolder(resource);
/*     */         break;
/*     */       case 1:
/*  61 */         addShallowFolder(resource);
/*     */         break;
/*     */       case 0:
/*  64 */         addZeroFolder(resource);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addShallowFolder(IResource resource) {
/*  70 */     if (!isCovered(resource, 1)) {
/*  71 */       this.shallowFolders.add(resource);
/*  72 */       removeDescendants(resource, 1);
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized boolean isCovered(IResource resource, int depth) {
/*  77 */     IPath fullPath = resource.getFullPath();
/*     */     
/*  79 */     for (IResource deepFolder : this.deepFolders) {
/*  80 */       if (deepFolder.getFullPath().isPrefixOf(fullPath)) {
/*  81 */         return true;
/*     */       }
/*     */     } 
/*     */     
/*  85 */     if (resource.getType() == 1) {
/*  86 */       return !(!this.shallowFolders.contains(resource.getParent()) && !this.files.contains(resource));
/*     */     }
/*     */     
/*  89 */     switch (depth) {
/*     */       case 1:
/*  91 */         return this.shallowFolders.contains(resource);
/*     */       case 0:
/*  93 */         return !(!this.shallowFolders.contains(resource.getParent()) && !this.zeroFolders.contains(resource));
/*     */     } 
/*  95 */     return false;
/*     */   }
/*     */   
/*     */   private void addZeroFolder(IResource resource) {
/*  99 */     if (!isCovered(resource, 0))
/* 100 */       this.zeroFolders.add(resource); 
/*     */   }
/*     */   
/*     */   private void addDeepFolder(IResource resource) {
/* 104 */     if (!isCovered(resource, 2)) {
/* 105 */       this.deepFolders.add(resource);
/* 106 */       removeDescendants(resource, 2);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void removeDescendants(IResource resource, int depth) {
/* 111 */     IPath fullPath = resource.getFullPath();
/*     */     
/* 113 */     for (Iterator<IResource> iterator1 = this.files.iterator(); iterator1.hasNext(); ) {
/* 114 */       IResource child = iterator1.next();
/* 115 */       switch (depth) {
/*     */         case 2:
/* 117 */           if (fullPath.isPrefixOf(child.getFullPath())) {
/* 118 */             iterator1.remove();
/*     */           }
/*     */         
/*     */         case 1:
/* 122 */           if (fullPath.equals(child.getFullPath().removeLastSegments(1))) {
/* 123 */             iterator1.remove();
/*     */           }
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 129 */     if (depth == 2) {
/* 130 */       for (Iterator<IResource> iterator = this.shallowFolders.iterator(); iterator.hasNext(); ) {
/* 131 */         IResource child = iterator.next();
/* 132 */         if (fullPath.isPrefixOf(child.getFullPath())) {
/* 133 */           iterator.remove();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 138 */     for (Iterator<IResource> iter = this.zeroFolders.iterator(); iter.hasNext(); ) {
/* 139 */       IResource child = iter.next();
/* 140 */       switch (depth) {
/*     */         case 2:
/* 142 */           if (fullPath.isPrefixOf(child.getFullPath())) {
/* 143 */             iter.remove();
/*     */           }
/*     */ 
/*     */         
/*     */         case 1:
/* 148 */           if (fullPath.equals(child.getFullPath().removeLastSegments(1))) {
/* 149 */             iter.remove();
/*     */           }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void add(CompoundResourceTraversal compoundTraversal) {
/* 160 */     addResources(
/* 161 */         compoundTraversal.deepFolders.<IResource>toArray(new IResource[compoundTraversal.deepFolders.size()]), 
/* 162 */         2);
/* 163 */     addResources(
/* 164 */         compoundTraversal.shallowFolders.<IResource>toArray(new IResource[compoundTraversal.shallowFolders.size()]), 
/* 165 */         1);
/* 166 */     addResources(
/* 167 */         compoundTraversal.zeroFolders.<IResource>toArray(new IResource[compoundTraversal.zeroFolders.size()]), 
/* 168 */         0);
/* 169 */     addResources(
/* 170 */         compoundTraversal.files.<IResource>toArray(new IResource[compoundTraversal.files.size()]), 
/* 171 */         0); } public synchronized void addResources(IResource[] resources, int depth) {
/*     */     byte b;
/*     */     int i;
/*     */     IResource[] arrayOfIResource;
/* 175 */     for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/* 176 */       addResource(resource, depth);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized IResource[] getUncoveredResources(ResourceTraversal[] traversals) {
/* 187 */     CompoundResourceTraversal newTraversals = new CompoundResourceTraversal();
/* 188 */     newTraversals.addTraversals(traversals);
/* 189 */     return getUncoveredResources(newTraversals);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IResource[] getUncoveredResources(CompoundResourceTraversal otherTraversal) {
/* 196 */     Set<IResource> result = new HashSet<>();
/* 197 */     for (IResource resource : otherTraversal.files) {
/* 198 */       if (!isCovered(resource, 0)) {
/* 199 */         result.add(resource);
/*     */       }
/*     */     } 
/* 202 */     for (IResource resource : otherTraversal.zeroFolders) {
/* 203 */       if (!isCovered(resource, 0)) {
/* 204 */         result.add(resource);
/*     */       }
/*     */     } 
/* 207 */     for (IResource resource : otherTraversal.shallowFolders) {
/* 208 */       if (!isCovered(resource, 1)) {
/* 209 */         result.add(resource);
/*     */       }
/*     */     } 
/* 212 */     for (IResource resource : otherTraversal.deepFolders) {
/* 213 */       if (!isCovered(resource, 2)) {
/* 214 */         result.add(resource);
/*     */       }
/*     */     } 
/* 217 */     return result.<IResource>toArray(new IResource[result.size()]);
/*     */   }
/*     */   
/*     */   public synchronized ResourceTraversal[] asTraversals() {
/* 221 */     List<ResourceTraversal> result = new ArrayList<>();
/* 222 */     if (!this.files.isEmpty() || !this.zeroFolders.isEmpty()) {
/* 223 */       Set<IResource> combined = new HashSet<>();
/* 224 */       combined.addAll(this.files);
/* 225 */       combined.addAll(this.zeroFolders);
/* 226 */       result.add(new ResourceTraversal(combined.<IResource>toArray(new IResource[combined.size()]), 0, 0));
/*     */     } 
/* 228 */     if (!this.shallowFolders.isEmpty()) {
/* 229 */       result.add(new ResourceTraversal(this.shallowFolders.<IResource>toArray(new IResource[this.shallowFolders.size()]), 1, 0));
/*     */     }
/* 231 */     if (!this.deepFolders.isEmpty()) {
/* 232 */       result.add(new ResourceTraversal(this.deepFolders.<IResource>toArray(new IResource[this.deepFolders.size()]), 2, 0));
/*     */     }
/* 234 */     return result.<ResourceTraversal>toArray(new ResourceTraversal[result.size()]);
/*     */   }
/*     */   
/*     */   public synchronized IResource[] getRoots() {
/* 238 */     List<IResource> result = new ArrayList<>();
/* 239 */     result.addAll(this.files);
/* 240 */     result.addAll(this.zeroFolders);
/* 241 */     result.addAll(this.shallowFolders);
/* 242 */     result.addAll(this.deepFolders);
/* 243 */     return result.<IResource>toArray(new IResource[result.size()]);
/*     */   }
/*     */   
/*     */   public synchronized ResourceTraversal[] getUncoveredTraversals(ResourceTraversal[] traversals) {
/* 247 */     CompoundResourceTraversal other = new CompoundResourceTraversal();
/* 248 */     other.addTraversals(traversals);
/* 249 */     return getUncoveredTraversals(other);
/*     */   }
/*     */   
/*     */   public ResourceTraversal[] getUncoveredTraversals(CompoundResourceTraversal otherTraversal) {
/* 253 */     synchronized (otherTraversal) {
/* 254 */       CompoundResourceTraversal uncovered = new CompoundResourceTraversal();
/* 255 */       for (IResource resource : otherTraversal.files) {
/* 256 */         if (!isCovered(resource, 0)) {
/* 257 */           uncovered.addResource(resource, 0);
/*     */         }
/*     */       } 
/* 260 */       for (IResource resource : otherTraversal.zeroFolders) {
/* 261 */         if (!isCovered(resource, 0)) {
/* 262 */           uncovered.addResource(resource, 0);
/*     */         }
/*     */       } 
/* 265 */       for (IResource resource : otherTraversal.shallowFolders) {
/* 266 */         if (!isCovered(resource, 1)) {
/* 267 */           uncovered.addResource(resource, 1);
/*     */         }
/*     */       } 
/* 270 */       for (IResource resource : otherTraversal.deepFolders) {
/* 271 */         if (!isCovered(resource, 2)) {
/* 272 */           uncovered.addResource(resource, 2);
/*     */         }
/*     */       } 
/* 275 */       return uncovered.asTraversals();
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized void clear() {
/* 280 */     this.deepFolders.clear();
/* 281 */     this.shallowFolders.clear();
/* 282 */     this.zeroFolders.clear();
/* 283 */     this.files.clear();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\CompoundResourceTraversal.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */