/*     */ package org.eclipse.team.core.subscribers;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IStorage;
/*     */ import org.eclipse.core.resources.mapping.RemoteResourceMappingContext;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.core.synchronize.SyncInfo;
/*     */ import org.eclipse.team.core.variants.IResourceVariant;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubscriberResourceMappingContext
/*     */   extends RemoteResourceMappingContext
/*     */ {
/*     */   private final Subscriber subscriber;
/*  51 */   private Set<IResource> shallowRefresh = new HashSet<>();
/*  52 */   private Set<IResource> deepRefresh = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean autoRefresh;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RemoteResourceMappingContext createContext(Subscriber subscriber) {
/*  63 */     return new SubscriberResourceMappingContext(subscriber, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubscriberResourceMappingContext(Subscriber subscriber, boolean autoRefresh) {
/*  73 */     this.subscriber = subscriber;
/*  74 */     this.autoRefresh = autoRefresh;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean hasRemoteChange(IResource resource, IProgressMonitor monitor) throws CoreException {
/*     */     try {
/*  80 */       monitor.beginTask(null, 100);
/*  81 */       ensureRefreshed(resource, 1, 0, monitor);
/*  82 */       SyncInfo syncInfo = this.subscriber.getSyncInfo(resource);
/*  83 */       validateRemote(resource, syncInfo);
/*  84 */       if (syncInfo == null) return false; 
/*  85 */       int direction = SyncInfo.getDirection(syncInfo.getKind());
/*  86 */       return !(direction != 8 && direction != 12);
/*     */     } finally {
/*  88 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasLocalChange(IResource resource, IProgressMonitor monitor) throws CoreException {
/*  94 */     SyncInfo syncInfo = this.subscriber.getSyncInfo(resource);
/*  95 */     if (syncInfo == null) return false; 
/*  96 */     int direction = SyncInfo.getDirection(syncInfo.getKind());
/*  97 */     return !(direction != 4 && direction != 12);
/*     */   }
/*     */ 
/*     */   
/*     */   public final IStorage fetchRemoteContents(IFile file, IProgressMonitor monitor) throws CoreException {
/*     */     try {
/* 103 */       monitor.beginTask(null, 100);
/* 104 */       ensureRefreshed((IResource)file, 0, 1, Policy.subMonitorFor(monitor, 10));
/* 105 */       SyncInfo syncInfo = this.subscriber.getSyncInfo((IResource)file);
/* 106 */       IResourceVariant remote = validateRemote((IResource)file, syncInfo);
/* 107 */       if (remote == null) {
/* 108 */         return null;
/*     */       }
/* 110 */       return remote.getStorage(Policy.subMonitorFor(monitor, 90));
/*     */     } finally {
/* 112 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final IStorage fetchBaseContents(IFile file, IProgressMonitor monitor) throws CoreException {
/*     */     try {
/* 119 */       monitor.beginTask(null, 100);
/* 120 */       ensureRefreshed((IResource)file, 0, 1, Policy.subMonitorFor(monitor, 10));
/* 121 */       SyncInfo syncInfo = this.subscriber.getSyncInfo((IResource)file);
/* 122 */       IResourceVariant base = validateBase((IResource)file, syncInfo);
/* 123 */       if (base == null) {
/* 124 */         return null;
/*     */       }
/* 126 */       return base.getStorage(Policy.subMonitorFor(monitor, 90));
/*     */     } finally {
/* 128 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final IResource[] fetchMembers(IContainer container, IProgressMonitor monitor) throws CoreException {
/*     */     try {
/* 135 */       monitor.beginTask(null, 100);
/* 136 */       ensureRefreshed((IResource)container, 1, 0, Policy.subMonitorFor(monitor, 100));
/* 137 */       SyncInfo syncInfo = this.subscriber.getSyncInfo((IResource)container);
/* 138 */       if (validateRemote((IResource)container, syncInfo) == null)
/*     */       {
/* 140 */         return new IResource[0];
/*     */       }
/* 142 */       return this.subscriber.members((IResource)container);
/*     */     } finally {
/* 144 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public final void refresh(ResourceTraversal[] traversals, int flags, IProgressMonitor monitor) throws CoreException {
/* 150 */     this.subscriber.refresh(traversals, monitor); byte b; int i; ResourceTraversal[] arrayOfResourceTraversal;
/* 151 */     for (i = (arrayOfResourceTraversal = traversals).length, b = 0; b < i; ) { ResourceTraversal traversal = arrayOfResourceTraversal[b];
/* 152 */       refreshed(traversal.getResources(), traversal.getDepth());
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void refresh(IResource[] resources, int depth, int flags, IProgressMonitor monitor) throws TeamException {
/* 171 */     this.subscriber.refresh(resources, depth, monitor);
/* 172 */     refreshed(resources, depth);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void refreshed(IResource[] resources, int depth) {
/*     */     byte b;
/*     */     int i;
/*     */     IResource[] arrayOfIResource;
/* 183 */     for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/*     */       
/* 185 */       if (depth == 1 || resource.getType() == 1) {
/* 186 */         this.shallowRefresh.add(resource);
/* 187 */       } else if (depth == 2) {
/* 188 */         this.deepRefresh.add(resource);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureRefreshed(IResource resource, int depth, int flags, IProgressMonitor monitor) throws TeamException {
/* 198 */     if (this.autoRefresh) {
/* 199 */       if (depth == 2) {
/*     */         
/* 201 */         if (wasRefreshedDeeply(resource)) {
/*     */           return;
/*     */         }
/* 204 */         if (resource.getType() == 1 && wasRefreshedShallow(resource)) {
/*     */           return;
/*     */         }
/* 207 */       } else if (wasRefreshedShallow(resource)) {
/*     */         return;
/*     */       } 
/* 210 */       refresh(new IResource[] { resource }, depth, flags, monitor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean wasRefreshedShallow(IResource resource) {
/* 220 */     if (this.shallowRefresh.contains(resource))
/* 221 */       return true; 
/* 222 */     if (resource.getType() == 1 && this.shallowRefresh.contains(resource.getParent()))
/* 223 */       return true; 
/* 224 */     if (wasRefreshedDeeply(resource))
/* 225 */       return true; 
/* 226 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean wasRefreshedDeeply(IResource resource) {
/* 233 */     if (resource.getType() == 8)
/* 234 */       return false; 
/* 235 */     if (this.deepRefresh.contains(resource))
/* 236 */       return true; 
/* 237 */     return wasRefreshedDeeply((IResource)resource.getParent());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IResourceVariant validateRemote(IResource resource, SyncInfo syncInfo) throws CoreException {
/* 245 */     if (syncInfo == null) return null; 
/* 246 */     IResourceVariant remote = syncInfo.getRemote();
/* 247 */     if (remote == null) return null; 
/* 248 */     return validateRemote(resource, remote);
/*     */   }
/*     */   
/*     */   private IResourceVariant validateRemote(IResource resource, IResourceVariant remote) throws CoreException {
/* 252 */     boolean containerExpected = (resource.getType() != 1);
/* 253 */     if (remote.isContainer() && !containerExpected)
/* 254 */       throw new CoreException(new Status(4, "org.eclipse.team.core", 366, String.valueOf(Messages.SubscriberResourceMappingContext_0) + resource.getFullPath().toString(), null)); 
/* 255 */     if (!remote.isContainer() && containerExpected) {
/* 256 */       throw new CoreException(new Status(4, "org.eclipse.team.core", 366, String.valueOf(Messages.SubscriberResourceMappingContext_1) + resource.getFullPath().toString(), null));
/*     */     }
/* 258 */     return remote;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IResourceVariant validateBase(IResource resource, SyncInfo syncInfo) throws CoreException {
/* 266 */     if (syncInfo == null) return null; 
/* 267 */     IResourceVariant base = syncInfo.getBase();
/* 268 */     if (base == null) return null; 
/* 269 */     return validateRemote(resource, base);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoRefresh(boolean autoRefresh) {
/* 281 */     this.autoRefresh = autoRefresh;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isThreeWay() {
/* 286 */     return this.subscriber.getResourceComparator().isThreeWay();
/*     */   }
/*     */   
/*     */   public boolean contentDiffers(IFile file, IProgressMonitor monitor) throws CoreException {
/* 290 */     return !(!hasRemoteChange((IResource)file, monitor) && !hasLocalChange((IResource)file, monitor));
/*     */   }
/*     */ 
/*     */   
/*     */   public IProject[] getProjects() {
/* 295 */     Set<IProject> projects = new HashSet<>();
/* 296 */     IResource[] roots = this.subscriber.roots(); byte b; int i; IResource[] arrayOfIResource1;
/* 297 */     for (i = (arrayOfIResource1 = roots).length, b = 0; b < i; ) { IResource resource = arrayOfIResource1[b];
/* 298 */       projects.add(resource.getProject()); b++; }
/*     */     
/* 300 */     return projects.<IProject>toArray(new IProject[projects.size()]);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\subscribers\SubscriberResourceMappingContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */