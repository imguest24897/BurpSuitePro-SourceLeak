/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.ListenerList;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScope;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScopeChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSynchronizationScope
/*     */   implements ISynchronizationScope
/*     */ {
/*  37 */   private ListenerList<ISynchronizationScopeChangeListener> listeners = new ListenerList(1);
/*     */ 
/*     */   
/*     */   public IResource[] getRoots() {
/*  41 */     List<IResource> result = new ArrayList<>();
/*  42 */     ResourceTraversal[] traversals = getTraversals(); byte b; int i; ResourceTraversal[] arrayOfResourceTraversal1;
/*  43 */     for (i = (arrayOfResourceTraversal1 = traversals).length, b = 0; b < i; ) { ResourceTraversal traversal = arrayOfResourceTraversal1[b];
/*  44 */       IResource[] resources = traversal.getResources(); byte b1; int j; IResource[] arrayOfIResource1;
/*  45 */       for (j = (arrayOfIResource1 = resources).length, b1 = 0; b1 < j; ) { IResource resource = arrayOfIResource1[b1];
/*  46 */         accumulateRoots(result, resource); b1++; }
/*     */        b++; }
/*     */     
/*  49 */     return result.<IResource>toArray(new IResource[result.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(IResource resource) {
/*  54 */     ResourceTraversal[] traversals = getTraversals(); byte b; int i; ResourceTraversal[] arrayOfResourceTraversal1;
/*  55 */     for (i = (arrayOfResourceTraversal1 = traversals).length, b = 0; b < i; ) { ResourceTraversal traversal = arrayOfResourceTraversal1[b];
/*  56 */       if (traversal.contains(resource))
/*  57 */         return true;  b++; }
/*     */     
/*  59 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void accumulateRoots(List<IResource> roots, IResource resource) {
/*  67 */     IPath resourcePath = resource.getFullPath();
/*  68 */     for (Iterator<IResource> iter = roots.iterator(); iter.hasNext(); ) {
/*  69 */       IResource root = iter.next();
/*  70 */       IPath rootPath = root.getFullPath();
/*     */       
/*  72 */       if (rootPath.isPrefixOf(resourcePath)) {
/*     */         return;
/*     */       }
/*  75 */       if (resourcePath.isPrefixOf(rootPath)) {
/*  76 */         iter.remove();
/*     */       }
/*     */     } 
/*  79 */     roots.add(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fireTraversalsChangedEvent(final ResourceTraversal[] newTraversals, final ResourceMapping[] newMappings) {
/*  88 */     Object[] allListeners = this.listeners.getListeners(); byte b; int i; Object[] arrayOfObject1;
/*  89 */     for (i = (arrayOfObject1 = allListeners).length, b = 0; b < i; ) { final Object listener = arrayOfObject1[b];
/*  90 */       SafeRunner.run(new ISafeRunnable()
/*     */           {
/*     */             public void run() throws Exception {
/*  93 */               ((ISynchronizationScopeChangeListener)listener).scopeChanged(AbstractSynchronizationScope.this, newMappings, newTraversals);
/*     */             }
/*     */ 
/*     */             
/*     */             public void handleException(Throwable exception) {}
/*     */           });
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void addScopeChangeListener(ISynchronizationScopeChangeListener listener) {
/* 105 */     this.listeners.add(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeScopeChangeListener(ISynchronizationScopeChangeListener listener) {
/* 110 */     this.listeners.remove(listener);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\AbstractSynchronizationScope.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */