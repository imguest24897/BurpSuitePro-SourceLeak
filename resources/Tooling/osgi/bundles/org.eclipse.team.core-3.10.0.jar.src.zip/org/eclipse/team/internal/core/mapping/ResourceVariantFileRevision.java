/*    */ package org.eclipse.team.internal.core.mapping;
/*    */ 
/*    */ import org.eclipse.core.resources.IStorage;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IAdaptable;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.Platform;
/*    */ import org.eclipse.team.core.history.IFileRevision;
/*    */ import org.eclipse.team.core.history.provider.FileRevision;
/*    */ import org.eclipse.team.core.variants.IResourceVariant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResourceVariantFileRevision
/*    */   extends FileRevision
/*    */   implements IAdaptable
/*    */ {
/*    */   private final IResourceVariant variant;
/*    */   
/*    */   public ResourceVariantFileRevision(IResourceVariant variant) {
/* 29 */     this.variant = variant;
/*    */   }
/*    */ 
/*    */   
/*    */   public IStorage getStorage(IProgressMonitor monitor) throws CoreException {
/* 34 */     return this.variant.getStorage(monitor);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 39 */     return this.variant.getName();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getContentIdentifier() {
/* 44 */     return this.variant.getContentIdentifier();
/*    */   }
/*    */   
/*    */   public IResourceVariant getVariant() {
/* 48 */     return this.variant;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isPropertyMissing() {
/* 53 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public IFileRevision withAllProperties(IProgressMonitor monitor) throws CoreException {
/* 58 */     return (IFileRevision)this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> T getAdapter(Class<T> adapter) {
/* 64 */     if (adapter == IResourceVariant.class)
/* 65 */       return (T)this.variant; 
/* 66 */     Object object = Platform.getAdapterManager().getAdapter(this, adapter);
/* 67 */     if (object != null)
/* 68 */       return (T)object; 
/* 69 */     if (this.variant instanceof IAdaptable) {
/* 70 */       IAdaptable adaptable = (IAdaptable)this.variant;
/* 71 */       return (T)adaptable.getAdapter(adapter);
/*    */     } 
/* 73 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 78 */     if (obj instanceof ResourceVariantFileRevision) {
/* 79 */       ResourceVariantFileRevision fileRevision = (ResourceVariantFileRevision)obj;
/* 80 */       return fileRevision.getVariant().equals(getVariant());
/*    */     } 
/* 82 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 87 */     return getVariant().hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\ResourceVariantFileRevision.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */