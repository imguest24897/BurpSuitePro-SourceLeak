package org.eclipse.team.core.importing.provisional;

public interface IBundleImporter extends IBundleImporterDelegate {
  String getId();
  
  String getDescription();
  
  String getName();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\importing\provisional\IBundleImporter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */