/*     */ package org.eclipse.team.core;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ProjectSetCapability
/*     */ {
/*     */   public static final String SCHEME_SCM = "scm";
/*     */   private IProjectSetSerializer serializer;
/*     */   
/*     */   public static void ensureBackwardsCompatible(RepositoryProviderType type, ProjectSetCapability capability) {
/*  64 */     if (capability != null) {
/*  65 */       IProjectSetSerializer oldSerializer = Team.getProjectSetSerializer(type.getID());
/*  66 */       if (oldSerializer != null) {
/*  67 */         capability.setSerializer(oldSerializer);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void projectSetCreated(File file, Object context, IProgressMonitor monitor) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void projectSetCreated(File file, ProjectSetSerializationContext context, IProgressMonitor monitor) {
/* 113 */     projectSetCreated(file, context.getShell(), monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] asReference(IProject[] providerProjects, ProjectSetSerializationContext context, IProgressMonitor monitor) throws TeamException {
/* 156 */     if (this.serializer != null) {
/* 157 */       return this.serializer.asReference(providerProjects, context.getShell(), monitor);
/*     */     }
/* 159 */     throw new TeamException(Messages.ProjectSetCapability_0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IProject[] addToWorkspace(String[] referenceStrings, ProjectSetSerializationContext context, IProgressMonitor monitor) throws TeamException {
/* 206 */     if (this.serializer != null) {
/* 207 */       return this.serializer.addToWorkspace(referenceStrings, context.getFilename(), context.getShell(), monitor);
/*     */     }
/* 209 */     throw new TeamException(Messages.ProjectSetCapability_1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IProject[] confirmOverwrite(ProjectSetSerializationContext context, IProject[] projects) throws TeamException {
/* 242 */     Collection<IProject> existingProjects = new ArrayList<>(); byte b1; int i; IProject[] arrayOfIProject1;
/* 243 */     for (i = (arrayOfIProject1 = projects).length, b1 = 0; b1 < i; ) { IProject eachProj = arrayOfIProject1[b1];
/* 244 */       if (eachProj.exists()) {
/* 245 */         existingProjects.add(eachProj);
/* 246 */       } else if ((new File(eachProj.getParent().getLocation().toFile(), eachProj.getName())).exists()) {
/* 247 */         existingProjects.add(eachProj);
/*     */       }  b1++; }
/*     */     
/* 250 */     if (existingProjects.isEmpty()) {
/* 251 */       return projects;
/*     */     }
/*     */ 
/*     */     
/* 255 */     IProject[] confirmed = 
/* 256 */       context.confirmOverwrite(
/* 257 */         existingProjects.<IProject>toArray(
/* 258 */           new IProject[existingProjects.size()]));
/* 259 */     if (confirmed == null)
/* 260 */       return null; 
/* 261 */     if (existingProjects.size() == confirmed.length) {
/* 262 */       return projects;
/*     */     }
/*     */ 
/*     */     
/* 266 */     Collection<IProject> result = new ArrayList<>(projects.length);
/* 267 */     result.addAll(Arrays.asList(projects));
/* 268 */     result.removeAll(existingProjects); byte b2; int j; IProject[] arrayOfIProject2;
/* 269 */     for (j = (arrayOfIProject2 = confirmed).length, b2 = 0; b2 < j; ) { IProject eachProj = arrayOfIProject2[b2];
/* 270 */       if (existingProjects.contains(eachProj))
/* 271 */         result.add(eachProj);  b2++; }
/*     */     
/* 273 */     return result.<IProject>toArray(new IProject[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setSerializer(IProjectSetSerializer serializer) {
/* 282 */     this.serializer = serializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URI getURI(String referenceString) {
/* 297 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProject(String referenceString) {
/* 312 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String asReference(URI uri, String projectName) {
/* 344 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\ProjectSetCapability.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */