/*    */ package org.eclipse.team.internal.core.mapping;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ import org.eclipse.team.core.TeamException;
/*    */ import org.eclipse.team.core.mapping.ISynchronizationScopeManager;
/*    */ import org.eclipse.team.core.mapping.provider.SynchronizationScopeManager;
/*    */ import org.eclipse.team.internal.core.BackgroundEventHandler;
/*    */ import org.eclipse.team.internal.core.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScopeManagerEventHandler
/*    */   extends BackgroundEventHandler
/*    */ {
/*    */   public static final int REFRESH = 10;
/* 33 */   private Set<ResourceMapping> toRefresh = new HashSet<>();
/*    */   private ISynchronizationScopeManager manager;
/*    */   
/*    */   static class ResourceMappingEvent
/*    */     extends BackgroundEventHandler.Event {
/*    */     public ResourceMappingEvent(ResourceMapping[] mappings) {
/* 39 */       super(10);
/* 40 */       this.mappings = mappings;
/*    */     }
/*    */     private final ResourceMapping[] mappings; }
/*    */   
/*    */   public ScopeManagerEventHandler(SynchronizationScopeManager manager) {
/* 45 */     super(NLS.bind(Messages.ScopeManagerEventHandler_0, manager.getName()), NLS.bind(Messages.ScopeManagerEventHandler_1, manager.getName()));
/* 46 */     this.manager = (ISynchronizationScopeManager)manager;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean doDispatchEvents(IProgressMonitor monitor) throws TeamException {
/* 52 */     ResourceMapping[] mappings = this.toRefresh.<ResourceMapping>toArray(new ResourceMapping[this.toRefresh.size()]);
/* 53 */     this.toRefresh.clear();
/* 54 */     if (mappings.length > 0) {
/*    */       try {
/* 56 */         this.manager.refresh(mappings, monitor);
/* 57 */       } catch (CoreException e) {
/* 58 */         throw TeamException.asTeamException(e);
/*    */       } 
/*    */     }
/* 61 */     return (mappings.length > 0);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void processEvent(BackgroundEventHandler.Event event, IProgressMonitor monitor) throws CoreException {
/* 67 */     if (event instanceof ResourceMappingEvent) {
/* 68 */       ResourceMappingEvent rme = (ResourceMappingEvent)event;
/* 69 */       Collections.addAll(this.toRefresh, rme.mappings);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void refresh(ResourceMapping[] mappings) {
/* 75 */     queueEvent(new ResourceMappingEvent(mappings), false);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Object getJobFamiliy() {
/* 80 */     return this.manager;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\ScopeManagerEventHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */