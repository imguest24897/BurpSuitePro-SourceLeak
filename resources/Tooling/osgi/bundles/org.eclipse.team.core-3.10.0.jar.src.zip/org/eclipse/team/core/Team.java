/*     */ package org.eclipse.team.core;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.SortedMap;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.TreeMap;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceChangeListener;
/*     */ import org.eclipse.core.resources.IStorage;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Preferences;
/*     */ import org.eclipse.core.runtime.RegistryFactory;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.importing.provisional.IBundleImporter;
/*     */ import org.eclipse.team.core.mapping.IStorageMerger;
/*     */ import org.eclipse.team.internal.core.FileContentManager;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ import org.eclipse.team.internal.core.StorageMergerRegistry;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ import org.eclipse.team.internal.core.TeamResourceChangeListener;
/*     */ import org.eclipse.team.internal.core.WildcardStringMatcher;
/*     */ import org.eclipse.team.internal.core.importing.BundleImporterExtension;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Team
/*     */ {
/*     */   private static final String PREF_TEAM_IGNORES = "ignore_files";
/*     */   private static final String PREF_TEAM_SEPARATOR = "\n";
/*     */   
/*     */   private static class StringMappingWrapper
/*     */     implements IFileTypeInfo
/*     */   {
/*     */     private final IStringMapping fMapping;
/*     */     
/*     */     public StringMappingWrapper(IStringMapping mapping) {
/*  73 */       this.fMapping = mapping;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getExtension() {
/*  78 */       return this.fMapping.getString();
/*     */     }
/*     */ 
/*     */     
/*     */     public int getType() {
/*  83 */       return this.fMapping.getType();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public static final Status OK_STATUS = new Status(0, "org.eclipse.team.core", 0, Messages.ok, null);
/*     */ 
/*     */   
/*     */   public static final int UNKNOWN = 0;
/*     */ 
/*     */   
/*     */   public static final int TEXT = 1;
/*     */ 
/*     */   
/*     */   public static final int BINARY = 2;
/*     */   
/*     */   protected static SortedMap<String, Boolean> globalIgnore;
/*     */   
/*     */   protected static SortedMap<String, Boolean> pluginIgnore;
/*     */   
/*     */   private static WildcardStringMatcher[] ignoreMatchers;
/*     */   
/* 107 */   private static final FileContentManager fFileContentManager = new FileContentManager();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<IBundleImporter> fBundleImporters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static int getType(IStorage storage) {
/* 128 */     return fFileContentManager.getType(storage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isIgnoredHint(IResource resource) {
/* 141 */     if (resource.isDerived()) return true; 
/* 142 */     return matchesEnabledIgnore(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static boolean isIgnoredHint(IFile file) {
/* 153 */     if (file.isDerived()) return true; 
/* 154 */     return matchesEnabledIgnore((IResource)file);
/*     */   }
/*     */   
/*     */   private static boolean matchesEnabledIgnore(IResource resource) {
/* 158 */     WildcardStringMatcher[] matchers = getStringMatchers(); byte b; int i; WildcardStringMatcher[] arrayOfWildcardStringMatcher1;
/* 159 */     for (i = (arrayOfWildcardStringMatcher1 = matchers).length, b = 0; b < i; ) { WildcardStringMatcher matcher = arrayOfWildcardStringMatcher1[b];
/* 160 */       String resourceName = resource.getName();
/* 161 */       if (matcher.isPathPattern()) {
/* 162 */         resourceName = resource.getFullPath().toString();
/*     */       }
/* 164 */       if (matcher.match(resourceName))
/* 165 */         return true; 
/*     */       b++; }
/*     */     
/* 168 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static boolean isIgnored(IFile file) {
/* 179 */     return matchesEnabledIgnore((IResource)file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static IFileTypeInfo[] getAllTypes() {
/* 191 */     IStringMapping[] mappings = fFileContentManager.getExtensionMappings();
/* 192 */     IFileTypeInfo[] infos = new IFileTypeInfo[mappings.length];
/* 193 */     for (int i = 0; i < infos.length; i++) {
/* 194 */       infos[i] = new StringMappingWrapper(mappings[i]);
/*     */     }
/* 196 */     return infos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized IIgnoreInfo[] getAllIgnores() {
/* 207 */     initializeIgnores();
/* 208 */     IIgnoreInfo[] result = getIgnoreInfo(globalIgnore);
/* 209 */     return result;
/*     */   }
/*     */   
/*     */   private static void initializeIgnores() {
/* 213 */     if (globalIgnore == null) {
/* 214 */       globalIgnore = new TreeMap<>();
/* 215 */       pluginIgnore = new TreeMap<>();
/* 216 */       ignoreMatchers = null;
/*     */       try {
/* 218 */         readIgnoreState();
/* 219 */       } catch (TeamException e) {
/* 220 */         TeamPlugin.log(4, Messages.Team_Error_loading_ignore_state_from_disk_1, (Throwable)e);
/*     */       } 
/* 222 */       initializePluginIgnores(pluginIgnore, globalIgnore);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static IIgnoreInfo[] getIgnoreInfo(Map gIgnore) {
/* 227 */     IIgnoreInfo[] result = new IIgnoreInfo[gIgnore.size()];
/* 228 */     Iterator<Map.Entry> e = gIgnore.entrySet().iterator();
/* 229 */     int i = 0;
/* 230 */     while (e.hasNext()) {
/* 231 */       Map.Entry entry = e.next();
/* 232 */       String pattern = (String)entry.getKey();
/* 233 */       boolean enabled = ((Boolean)entry.getValue()).booleanValue();
/* 234 */       result[i++] = new IIgnoreInfo(pattern, enabled) {
/*     */           private String p;
/*     */           private boolean e1;
/*     */           
/*     */           public String getPattern() {
/* 239 */             return this.p;
/*     */           }
/*     */           
/*     */           public boolean getEnabled() {
/* 243 */             return this.e1;
/*     */           }
/*     */         };
/*     */     } 
/* 247 */     return result;
/*     */   }
/*     */   
/*     */   private static synchronized WildcardStringMatcher[] getStringMatchers() {
/* 251 */     if (ignoreMatchers == null) {
/* 252 */       IIgnoreInfo[] ignorePatterns = getAllIgnores();
/* 253 */       ArrayList<WildcardStringMatcher> matchers = new ArrayList<>(ignorePatterns.length); byte b; int i; IIgnoreInfo[] arrayOfIIgnoreInfo1;
/* 254 */       for (i = (arrayOfIIgnoreInfo1 = ignorePatterns).length, b = 0; b < i; ) { IIgnoreInfo ignorePattern = arrayOfIIgnoreInfo1[b];
/* 255 */         if (ignorePattern.getEnabled())
/* 256 */           matchers.add(new WildcardStringMatcher(ignorePattern.getPattern())); 
/*     */         b++; }
/*     */       
/* 259 */       ignoreMatchers = new WildcardStringMatcher[matchers.size()];
/* 260 */       ignoreMatchers = matchers.<WildcardStringMatcher>toArray(ignoreMatchers);
/*     */     } 
/* 262 */     return ignoreMatchers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void setAllTypes(String[] extensions, int[] types) {
/* 282 */     fFileContentManager.addExtensionMappings(extensions, types);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setAllIgnores(String[] patterns, boolean[] enabled) {
/* 292 */     initializeIgnores();
/* 293 */     globalIgnore = new TreeMap<>();
/* 294 */     ignoreMatchers = null;
/* 295 */     for (int i = 0; i < patterns.length; i++) {
/* 296 */       globalIgnore.put(patterns[i], Boolean.valueOf(enabled[i]));
/*     */     }
/*     */     
/* 299 */     StringBuilder buf = new StringBuilder();
/* 300 */     for (Map.Entry<String, Boolean> entry : globalIgnore.entrySet()) {
/* 301 */       String pattern = (String)entry.getKey();
/* 302 */       Boolean value = (Boolean)entry.getValue();
/* 303 */       boolean isCustom = !(pluginIgnore.containsKey(pattern) && (
/* 304 */         (Boolean)pluginIgnore.get(pattern)).equals(value));
/* 305 */       if (isCustom) {
/* 306 */         buf.append(pattern);
/* 307 */         buf.append("\n");
/* 308 */         boolean en = value.booleanValue();
/* 309 */         buf.append(en);
/* 310 */         buf.append("\n");
/*     */       } 
/*     */     } 
/* 313 */     TeamPlugin.getPlugin().getPluginPreferences().setValue("ignore_files", buf.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initializePluginIgnores(SortedMap<String, Boolean> pIgnore, SortedMap<String, Boolean> gIgnore) {
/* 325 */     TeamPlugin plugin = TeamPlugin.getPlugin();
/* 326 */     if (plugin != null) {
/* 327 */       IExtensionPoint extension = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.team.core", "ignore");
/* 328 */       if (extension != null) {
/* 329 */         IExtension[] extensions = extension.getExtensions(); byte b; int i; IExtension[] arrayOfIExtension1;
/* 330 */         for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension ext = arrayOfIExtension1[b];
/* 331 */           IConfigurationElement[] configElements = ext.getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 332 */           for (j = (arrayOfIConfigurationElement1 = configElements).length, b1 = 0; b1 < j; ) { IConfigurationElement configElement = arrayOfIConfigurationElement1[b1];
/* 333 */             String pattern = configElement.getAttribute("pattern");
/* 334 */             if (pattern != null) {
/* 335 */               String selected = configElement.getAttribute("enabled");
/* 336 */               if (selected == null)
/*     */               {
/* 338 */                 selected = configElement.getAttribute("selected");
/*     */               }
/* 340 */               boolean enabled = (selected != null && 
/* 341 */                 selected.equalsIgnoreCase("true"));
/* 342 */               if (!pIgnore.containsKey(pattern)) {
/* 343 */                 pIgnore.put(pattern, Boolean.valueOf(enabled));
/* 344 */               } else if (!Boolean.valueOf(enabled).equals(
/* 345 */                   pIgnore.get(pattern))) {
/* 346 */                 if (Policy.DEBUG)
/*     */                 {
/* 348 */                   TeamPlugin.log(2, 
/* 349 */                       NLS.bind(
/* 350 */                         Messages.Team_Conflict_occured_for_ignored_resources_pattern, 
/* 351 */                         new Object[] {
/* 352 */                           pattern, 
/* 353 */                           collectContributingExtentionsToDisplay(
/* 354 */                             pattern, 
/* 355 */                             extensions)
/* 356 */                         }), null);
/*     */                 }
/*     */ 
/*     */                 
/* 360 */                 if (!enabled)
/* 361 */                   pIgnore.put(pattern, 
/* 362 */                       Boolean.FALSE); 
/*     */               } 
/*     */             } 
/*     */             b1++; }
/*     */           
/*     */           b++; }
/*     */         
/* 369 */         Iterator<String> it = pIgnore.keySet().iterator();
/* 370 */         while (it.hasNext()) {
/* 371 */           String pattern = it.next();
/* 372 */           if (!gIgnore.containsKey(pattern)) {
/* 373 */             gIgnore.put(pattern, pIgnore.get(pattern));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static String collectContributingExtentionsToDisplay(String patternToFind, IExtension[] extensions) {
/* 382 */     StringBuilder sb = new StringBuilder();
/* 383 */     boolean isFirst = true; byte b; int i; IExtension[] arrayOfIExtension;
/* 384 */     for (i = (arrayOfIExtension = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension[b];
/* 385 */       IConfigurationElement[] configElements = extension.getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 386 */       for (j = (arrayOfIConfigurationElement1 = configElements).length, b1 = 0; b1 < j; ) { IConfigurationElement configElement = arrayOfIConfigurationElement1[b1];
/* 387 */         if (patternToFind.equals(configElement.getAttribute("pattern"))) {
/* 388 */           if (!isFirst) {
/* 389 */             sb.append(", ");
/*     */           }
/* 391 */           isFirst = false;
/* 392 */           sb.append(extension.getContributor().getName());
/*     */         }  b1++; }
/*     */        b++; }
/*     */     
/* 396 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void readIgnoreState() throws TeamException {
/* 405 */     if (readBackwardCompatibleIgnoreState())
/* 406 */       return;  Preferences pref = TeamPlugin.getPlugin().getPluginPreferences();
/* 407 */     if (!pref.contains("ignore_files"))
/* 408 */       return;  pref.addPropertyChangeListener(event -> {
/*     */           if (event.getProperty().equals("ignore_files")) {
/*     */             globalIgnore = null;
/*     */           }
/*     */         });
/*     */     
/* 414 */     String prefIgnores = pref.getString("ignore_files");
/* 415 */     StringTokenizer tok = new StringTokenizer(prefIgnores, "\n");
/*     */     
/*     */     try {
/*     */       while (true) {
/* 419 */         String pattern = tok.nextToken();
/* 420 */         if (pattern.length() == 0)
/* 421 */           return;  String enabled = tok.nextToken();
/* 422 */         globalIgnore.put(pattern, Boolean.valueOf(enabled));
/*     */       } 
/* 424 */     } catch (NoSuchElementException noSuchElementException) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean readBackwardCompatibleIgnoreState() throws TeamException {
/* 433 */     String GLOBALIGNORE_FILE = ".globalIgnores";
/* 434 */     IPath pluginStateLocation = TeamPlugin.getPlugin().getStateLocation().append(GLOBALIGNORE_FILE);
/* 435 */     File f = pluginStateLocation.toFile();
/* 436 */     if (!f.exists()) return false; 
/*     */     try {
/* 438 */       Exception exception1 = null, exception2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*     */       
/*     */       } finally {
/* 452 */         exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); } 
/* 453 */       }  f.delete();
/* 454 */     } catch (FileNotFoundException fileNotFoundException) {
/*     */     
/* 456 */     } catch (IOException ex) {
/* 457 */       throw new TeamException(new Status(4, "org.eclipse.team.core", 0, Messages.Team_readError, ex));
/*     */     } 
/* 459 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void startup() {
/* 468 */     ResourcesPlugin.getWorkspace().addResourceChangeListener((IResourceChangeListener)new TeamResourceChangeListener(), 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void shutdown() {
/* 477 */     TeamPlugin.getPlugin().savePluginPreferences();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static IProjectSetSerializer getProjectSetSerializer(String id) {
/* 486 */     TeamPlugin plugin = TeamPlugin.getPlugin();
/* 487 */     if (plugin != null) {
/* 488 */       IExtensionPoint extension = RegistryFactory.getRegistry().getExtensionPoint("org.eclipse.team.core", "projectSets");
/* 489 */       if (extension != null) {
/* 490 */         IExtension[] extensions = extension.getExtensions(); byte b; int i; IExtension[] arrayOfIExtension1;
/* 491 */         for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension ext = arrayOfIExtension1[b];
/* 492 */           IConfigurationElement[] configElements = ext.getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 493 */           for (j = (arrayOfIConfigurationElement1 = configElements).length, b1 = 0; b1 < j; ) { IConfigurationElement configElement = arrayOfIConfigurationElement1[b1];
/* 494 */             String extensionId = configElement.getAttribute("id");
/* 495 */             if (extensionId != null && extensionId.equals(id))
/*     */               try {
/* 497 */                 return (IProjectSetSerializer)configElement.createExecutableExtension("class");
/* 498 */               } catch (CoreException e) {
/* 499 */                 TeamPlugin.log(e);
/* 500 */                 return null;
/*     */               }   b1++; }
/*     */           
/*     */           b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 507 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IIgnoreInfo[] getDefaultIgnores() {
/* 519 */     SortedMap<String, Boolean> gIgnore = new TreeMap<>();
/* 520 */     SortedMap<String, Boolean> pIgnore = new TreeMap<>();
/* 521 */     initializePluginIgnores(pIgnore, gIgnore);
/* 522 */     return getIgnoreInfo(gIgnore);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static IFileTypeInfo[] getDefaultTypes() {
/* 536 */     return asFileTypeInfo(getFileContentManager().getDefaultExtensionMappings());
/*     */   }
/*     */   
/*     */   private static IFileTypeInfo[] asFileTypeInfo(IStringMapping[] mappings) {
/* 540 */     IFileTypeInfo[] infos = new IFileTypeInfo[mappings.length];
/* 541 */     for (int i = 0; i < infos.length; i++) {
/* 542 */       infos[i] = new StringMappingWrapper(mappings[i]);
/*     */     }
/* 544 */     return infos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IFileContentManager getFileContentManager() {
/* 558 */     return (IFileContentManager)fFileContentManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStorageMerger createMerger(IContentType type) {
/* 572 */     return StorageMergerRegistry.getInstance().createStreamMerger(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStorageMerger createMerger(String extension) {
/* 586 */     return StorageMergerRegistry.getInstance().createStreamMerger(extension);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IStorageMerger createStorageMerger(IContentType type) {
/* 601 */     return createMerger(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IStorageMerger createStorageMerger(String extension) {
/* 616 */     return createMerger(extension);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized IBundleImporter[] getBundleImporters() {
/* 634 */     if (fBundleImporters == null) {
/* 635 */       fBundleImporters = new ArrayList<>();
/* 636 */       IExtensionPoint point = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.team.core.bundleImporters");
/* 637 */       if (point != null) {
/* 638 */         IConfigurationElement[] infos = point.getConfigurationElements(); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 639 */         for (i = (arrayOfIConfigurationElement1 = infos).length, b = 0; b < i; ) { IConfigurationElement info = arrayOfIConfigurationElement1[b];
/* 640 */           fBundleImporters.add(new BundleImporterExtension(info)); b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 644 */     return fBundleImporters.<IBundleImporter>toArray(new IBundleImporter[fBundleImporters.size()]);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\Team.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */