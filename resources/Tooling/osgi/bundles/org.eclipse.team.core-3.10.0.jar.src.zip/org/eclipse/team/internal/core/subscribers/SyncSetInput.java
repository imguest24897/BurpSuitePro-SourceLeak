/*    */ package org.eclipse.team.internal.core.subscribers;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.team.core.TeamException;
/*    */ import org.eclipse.team.core.synchronize.FastSyncInfoFilter;
/*    */ import org.eclipse.team.core.synchronize.SyncInfo;
/*    */ import org.eclipse.team.core.synchronize.SyncInfoFilter;
/*    */ import org.eclipse.team.internal.core.Policy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SyncSetInput
/*    */ {
/*    */   private SubscriberSyncInfoSet syncSet;
/* 30 */   private SyncInfoFilter filter = (SyncInfoFilter)new FastSyncInfoFilter();
/*    */   
/*    */   public SyncSetInput(SubscriberEventHandler handler) {
/* 33 */     this.syncSet = new SubscriberSyncInfoSet(handler);
/*    */   }
/*    */   
/*    */   public SubscriberSyncInfoSet getSyncSet() {
/* 37 */     return this.syncSet;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected abstract void fetchInput(IProgressMonitor paramIProgressMonitor) throws TeamException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract void disconnect();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void reset(IProgressMonitor monitor) throws TeamException {
/*    */     try {
/* 58 */       this.syncSet.beginInput();
/* 59 */       monitor = Policy.monitorFor(monitor);
/* 60 */       monitor.beginTask(null, 100);
/* 61 */       this.syncSet.clear();
/* 62 */       fetchInput(Policy.subMonitorFor(monitor, 90));
/*    */     } finally {
/* 64 */       this.syncSet.endInput(Policy.subMonitorFor(monitor, 10));
/* 65 */       monitor.done();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void collect(SyncInfo info, IProgressMonitor monitor) {
/* 73 */     boolean isOutOfSync = this.filter.select(info, monitor);
/* 74 */     SyncInfo oldInfo = this.syncSet.getSyncInfo(info.getLocal());
/* 75 */     boolean wasOutOfSync = (oldInfo != null);
/* 76 */     if (isOutOfSync) {
/* 77 */       this.syncSet.add(info);
/* 78 */     } else if (wasOutOfSync) {
/* 79 */       this.syncSet.remove(info.getLocal());
/*    */     } 
/*    */   }
/*    */   
/*    */   protected void remove(IResource resource) {
/* 84 */     SyncInfo oldInfo = this.syncSet.getSyncInfo(resource);
/* 85 */     if (oldInfo != null) {
/* 86 */       this.syncSet.remove(resource);
/*    */     }
/*    */   }
/*    */   
/*    */   public SyncInfoFilter getFilter() {
/* 91 */     return this.filter;
/*    */   }
/*    */   
/*    */   public void setFilter(SyncInfoFilter filter) {
/* 95 */     this.filter = filter;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SyncSetInput.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */