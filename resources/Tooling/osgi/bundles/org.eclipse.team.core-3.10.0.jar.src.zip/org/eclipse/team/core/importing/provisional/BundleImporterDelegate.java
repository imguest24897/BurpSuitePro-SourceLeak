/*     */ package org.eclipse.team.core.importing.provisional;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.osgi.util.ManifestElement;
/*     */ import org.eclipse.team.core.ProjectSetCapability;
/*     */ import org.eclipse.team.core.ProjectSetSerializationContext;
/*     */ import org.eclipse.team.core.RepositoryProviderType;
/*     */ import org.eclipse.team.core.ScmUrlImportDescription;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ import org.osgi.framework.BundleException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BundleImporterDelegate
/*     */   implements IBundleImporterDelegate
/*     */ {
/*     */   private static final String ATTR_PROJECT = "project";
/*     */   public static final String ECLIPSE_SOURCE_REFERENCES = "Eclipse-SourceReferences";
/*     */   
/*     */   protected abstract Set getSupportedValues();
/*     */   
/*     */   protected abstract RepositoryProviderType getProviderType();
/*     */   
/*     */   public ScmUrlImportDescription[] validateImport(Map[] manifests) {
/*  60 */     ScmUrlImportDescription[] results = new ScmUrlImportDescription[manifests.length];
/*  61 */     if (getProviderType() != null) {
/*  62 */       for (int i = 0; i < manifests.length; i++) {
/*  63 */         Map manifest = manifests[i];
/*  64 */         String value = (String)manifest.get("Eclipse-SourceReferences");
/*  65 */         if (value != null && value.length() > 8) {
/*  66 */           String prefix = value.substring(0, 8);
/*  67 */           if (getSupportedValues().contains(prefix)) {
/*     */             try {
/*  69 */               ManifestElement[] elements = ManifestElement.parseHeader("Eclipse-SourceReferences", value); byte b; int j; ManifestElement[] arrayOfManifestElement1;
/*  70 */               for (j = (arrayOfManifestElement1 = elements).length, b = 0; b < j; ) { ManifestElement element = arrayOfManifestElement1[b];
/*  71 */                 String url = element.toString();
/*  72 */                 String project = element.getAttribute("project");
/*  73 */                 if (project == null) {
/*  74 */                   String bsn = manifests[i].get("Bundle-SymbolicName");
/*  75 */                   if (bsn != null) {
/*  76 */                     ManifestElement[] bsnElement = ManifestElement.parseHeader("Bundle-SymbolicName", bsn);
/*  77 */                     project = bsnElement[0].getValue();
/*     */                   } 
/*     */                 } 
/*  80 */                 results[i] = new ScmUrlImportDescription(url, project); b++; }
/*     */             
/*  82 */             } catch (BundleException e) {
/*  83 */               TeamPlugin.log(4, "An exception occured while parsing a manifest header", (Throwable)e);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*  89 */     return results;
/*     */   }
/*     */ 
/*     */   
/*     */   public IProject[] performImport(ScmUrlImportDescription[] descriptions, IProgressMonitor monitor) throws CoreException {
/*  94 */     List<String> references = new ArrayList<>();
/*  95 */     ProjectSetCapability psfCapability = getProviderType().getProjectSetCapability();
/*  96 */     IProject[] result = null;
/*  97 */     if (psfCapability != null) {
/*     */       byte b; int i; ScmUrlImportDescription[] arrayOfScmUrlImportDescription;
/*  99 */       for (i = (arrayOfScmUrlImportDescription = descriptions).length, b = 0; b < i; ) { ScmUrlImportDescription description = arrayOfScmUrlImportDescription[b];
/* 100 */         references.add(psfCapability.asReference(description.getUri(), description.getProject()));
/*     */         b++; }
/*     */       
/* 103 */       if (!references.isEmpty()) {
/* 104 */         SubMonitor subMonitor = SubMonitor.convert(monitor, references.size());
/* 105 */         result = psfCapability.addToWorkspace(references.<String>toArray(new String[references.size()]), new ProjectSetSerializationContext(), (IProgressMonitor)subMonitor);
/* 106 */         subMonitor.done();
/*     */       } 
/*     */     } 
/* 109 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\importing\provisional\BundleImporterDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */