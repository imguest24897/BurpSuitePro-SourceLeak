/*     */ package org.eclipse.team.core.mapping.provider;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IFolder;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceRuleFactory;
/*     */ import org.eclipse.core.resources.IStorage;
/*     */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.MultiRule;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.diff.IDiff;
/*     */ import org.eclipse.team.core.diff.IThreeWayDiff;
/*     */ import org.eclipse.team.core.history.IFileRevision;
/*     */ import org.eclipse.team.core.mapping.DelegatingStorageMerger;
/*     */ import org.eclipse.team.core.mapping.IMergeContext;
/*     */ import org.eclipse.team.core.mapping.IMergeStatus;
/*     */ import org.eclipse.team.core.mapping.IResourceDiff;
/*     */ import org.eclipse.team.core.mapping.IResourceDiffTree;
/*     */ import org.eclipse.team.core.mapping.IStorageMerger;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScopeManager;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ import org.eclipse.team.internal.core.mapping.SyncInfoToDiffConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MergeContext
/*     */   extends SynchronizationContext
/*     */   implements IMergeContext
/*     */ {
/*     */   protected MergeContext(ISynchronizationScopeManager manager, int type, IResourceDiffTree deltaTree) {
/*  83 */     super(manager, type, deltaTree);
/*     */   }
/*     */ 
/*     */   
/*     */   public void reject(IDiff[] diffs, IProgressMonitor monitor) throws CoreException {
/*  88 */     run(monitor1 -> {
/*     */           IDiff[] arrayOfIDiff; int i = (arrayOfIDiff = paramArrayOfIDiff).length; for (byte b = 0; b < i; b++) {
/*     */             IDiff node = arrayOfIDiff[b]; reject(node, monitor1);
/*     */           } 
/*  92 */         }getMergeRule(diffs), 0, monitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public void markAsMerged(IDiff[] nodes, boolean inSyncHint, IProgressMonitor monitor) throws CoreException {
/*  97 */     run(monitor1 -> {
/*     */           IDiff[] arrayOfIDiff; int i = (arrayOfIDiff = paramArrayOfIDiff).length; for (byte b = 0; b < i; b++) {
/*     */             IDiff node = arrayOfIDiff[b]; markAsMerged(node, paramBoolean, monitor1);
/*     */           } 
/* 101 */         }getMergeRule(nodes), 0, monitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public IStatus merge(IDiff[] deltas, boolean force, IProgressMonitor monitor) throws CoreException {
/* 106 */     List<IFile> failedFiles = new ArrayList<>();
/* 107 */     run(monitor1 -> {
/*     */           try {
/*     */             monitor1.beginTask(null, paramArrayOfIDiff.length * 100); IDiff[] arrayOfIDiff; int i = (arrayOfIDiff = paramArrayOfIDiff).length;
/*     */             for (byte b = 0; b < i; b++) {
/*     */               IDiff delta = arrayOfIDiff[b];
/*     */               IStatus s = merge(delta, paramBoolean, Policy.subMonitorFor(monitor1, 100));
/*     */               if (!s.isOK())
/*     */                 if (s.getCode() == 1) {
/*     */                   paramList.addAll(Arrays.asList(((IMergeStatus)s).getConflictingFiles()));
/*     */                 } else {
/*     */                   throw new CoreException(s);
/*     */                 }  
/*     */             } 
/*     */           } finally {
/*     */             monitor1.done();
/*     */           } 
/* 123 */         }getMergeRule(deltas), 1, monitor);
/* 124 */     if (failedFiles.isEmpty()) {
/* 125 */       return Status.OK_STATUS;
/*     */     }
/* 127 */     return (IStatus)new MergeStatus("org.eclipse.team.core", Messages.MergeContext_0, failedFiles.<IFile>toArray(new IFile[failedFiles.size()]));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus merge(IDiff diff, boolean ignoreLocalChanges, IProgressMonitor monitor) throws CoreException {
/* 133 */     Policy.checkCanceled(monitor);
/* 134 */     IResource resource = getDiffTree().getResource(diff);
/* 135 */     if (resource.getType() != 1) {
/* 136 */       if (diff instanceof IThreeWayDiff) {
/* 137 */         IThreeWayDiff twd = (IThreeWayDiff)diff;
/* 138 */         if ((ignoreLocalChanges || getMergeType() == 2) && 
/* 139 */           resource.getType() == 2 && 
/* 140 */           twd.getKind() == 1 && 
/* 141 */           twd.getDirection() == 256 && ((
/* 142 */           (IFolder)resource).members()).length == 0) {
/*     */           
/* 144 */           ((IFolder)resource).delete(false, monitor);
/* 145 */         } else if (resource.getType() == 2 && 
/* 146 */           !resource.exists() && 
/* 147 */           twd.getKind() == 1 && 
/* 148 */           twd.getDirection() == 512) {
/* 149 */           ensureParentsExist(resource, monitor);
/* 150 */           ((IFolder)resource).create(false, true, monitor);
/* 151 */           makeInSync(diff, monitor);
/*     */         } 
/*     */       } 
/* 154 */       return Status.OK_STATUS;
/*     */     } 
/* 156 */     if (diff instanceof IThreeWayDiff && !ignoreLocalChanges && getMergeType() == 3) {
/* 157 */       IThreeWayDiff twDelta = (IThreeWayDiff)diff;
/* 158 */       int direction = twDelta.getDirection();
/* 159 */       if (direction == 256)
/*     */       {
/* 161 */         return Status.OK_STATUS;
/*     */       }
/* 163 */       if (direction == 512) {
/*     */         
/* 165 */         performReplace(diff, monitor);
/* 166 */         return Status.OK_STATUS;
/*     */       } 
/*     */       
/* 169 */       int type = twDelta.getKind();
/* 170 */       if (type == 2) {
/* 171 */         makeInSync(diff, monitor);
/* 172 */         return Status.OK_STATUS;
/*     */       } 
/*     */       
/* 175 */       IResourceDiff remoteChange = (IResourceDiff)twDelta.getRemoteChange();
/* 176 */       IFileRevision remote = null;
/* 177 */       if (remoteChange != null) {
/* 178 */         remote = remoteChange.getAfterState();
/*     */       }
/* 180 */       if (remote == null || !getLocalFile(diff).exists())
/*     */       {
/*     */         
/* 183 */         return (IStatus)new MergeStatus("org.eclipse.team.core", NLS.bind(Messages.MergeContext_1, (Object[])new String[] { diff.getPath().toString() }), new IFile[] { getLocalFile(diff) });
/*     */       }
/*     */ 
/*     */       
/* 187 */       return performThreeWayMerge(twDelta, monitor);
/*     */     } 
/* 189 */     performReplace(diff, monitor);
/* 190 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IStatus performThreeWayMerge(IThreeWayDiff diff, IProgressMonitor monitor) throws CoreException {
/* 207 */     IStatus[] result = { Status.OK_STATUS };
/* 208 */     run(monitor1 -> {
/*     */           IStorage ancestorStorage; monitor1.beginTask(null, 100); IResourceDiff localDiff = (IResourceDiff)paramIThreeWayDiff.getLocalChange();
/*     */           IResourceDiff remoteDiff = (IResourceDiff)paramIThreeWayDiff.getRemoteChange();
/*     */           IStorageMerger merger = getAdapter(IStorageMerger.class);
/*     */           if (merger == null)
/*     */             merger = DelegatingStorageMerger.getInstance(); 
/*     */           IFile file = (IFile)localDiff.getResource();
/*     */           monitor1.subTask(NLS.bind(Messages.MergeContext_5, file.getFullPath().toString()));
/*     */           String osEncoding = file.getCharset();
/*     */           IFileRevision ancestorState = localDiff.getBeforeState();
/*     */           IFileRevision remoteState = remoteDiff.getAfterState();
/*     */           if (ancestorState != null) {
/*     */             ancestorStorage = ancestorState.getStorage(Policy.subMonitorFor(monitor1, 30));
/*     */           } else {
/*     */             ancestorStorage = null;
/*     */           } 
/*     */           IStorage remoteStorage = remoteState.getStorage(Policy.subMonitorFor(monitor1, 30));
/*     */           OutputStream os = getTempOutputStream(file);
/*     */           try {
/*     */             MergeStatus mergeStatus;
/*     */             IStatus status = merger.merge(os, osEncoding, ancestorStorage, (IStorage)file, remoteStorage, Policy.subMonitorFor(monitor1, 30));
/*     */             if (status.isOK()) {
/*     */               file.setContents(getTempInputStream(file, os), false, true, Policy.subMonitorFor(monitor1, 5));
/*     */               markAsMerged((IDiff)paramIThreeWayDiff, false, Policy.subMonitorFor(monitor1, 5));
/*     */             } else {
/*     */               mergeStatus = new MergeStatus(status.getPlugin(), status.getMessage(), new IFile[] { file });
/*     */             } 
/*     */             paramArrayOfIStatus[0] = (IStatus)mergeStatus;
/*     */           } finally {
/*     */             disposeTempOutputStream(file, os);
/*     */           } 
/*     */           monitor1.done();
/* 240 */         }getMergeRule((IDiff)diff), 1, monitor);
/* 241 */     return result[0];
/*     */   }
/*     */   
/*     */   private void disposeTempOutputStream(IFile file, OutputStream output) {
/* 245 */     if (output instanceof ByteArrayOutputStream) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 251 */       if (output != null)
/* 252 */         output.close(); 
/* 253 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 256 */     File tmpFile = getTempFile(file);
/* 257 */     if (tmpFile.exists())
/* 258 */       tmpFile.delete(); 
/*     */   }
/*     */   
/*     */   private OutputStream getTempOutputStream(IFile file) throws CoreException {
/* 262 */     File tmpFile = getTempFile(file);
/* 263 */     if (tmpFile.exists())
/* 264 */       tmpFile.delete(); 
/* 265 */     File parent = tmpFile.getParentFile();
/* 266 */     if (!parent.exists())
/* 267 */       parent.mkdirs(); 
/*     */     try {
/* 269 */       return new BufferedOutputStream(new FileOutputStream(tmpFile));
/* 270 */     } catch (FileNotFoundException e) {
/* 271 */       TeamPlugin.log(4, NLS.bind("Could not open temporary file {0} for writing: {1}", (Object[])new String[] { tmpFile.getAbsolutePath(), e.getMessage() }), e);
/* 272 */       return new ByteArrayOutputStream();
/*     */     } 
/*     */   }
/*     */   
/*     */   private InputStream getTempInputStream(IFile file, OutputStream output) throws CoreException {
/* 277 */     if (output instanceof ByteArrayOutputStream) {
/* 278 */       ByteArrayOutputStream baos = (ByteArrayOutputStream)output;
/* 279 */       return new ByteArrayInputStream(baos.toByteArray());
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 284 */       if (output != null)
/* 285 */         output.close(); 
/* 286 */     } catch (IOException iOException) {}
/*     */ 
/*     */     
/* 289 */     File tmpFile = getTempFile(file);
/*     */     try {
/* 291 */       return new BufferedInputStream(new FileInputStream(tmpFile));
/* 292 */     } catch (FileNotFoundException e) {
/* 293 */       throw new CoreException(new Status(4, "org.eclipse.team.core", 2, NLS.bind(Messages.MergeContext_4, new String[] { tmpFile.getAbsolutePath(), e.getMessage() }), e));
/*     */     } 
/*     */   }
/*     */   
/*     */   private File getTempFile(IFile file) {
/* 298 */     return TeamPlugin.getPlugin().getStateLocation().append(".tmp").append(String.valueOf(file.getName()) + ".tmp").toFile();
/*     */   }
/*     */   
/*     */   private IFile getLocalFile(IDiff delta) {
/* 302 */     return ResourcesPlugin.getWorkspace().getRoot().getFile(delta.getPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void performReplace(IDiff diff, IProgressMonitor monitor) throws CoreException {
/*     */     IResourceDiff d;
/* 323 */     IFile file = getLocalFile(diff);
/* 324 */     IFileRevision remote = null;
/* 325 */     if (diff instanceof IResourceDiff) {
/* 326 */       d = (IResourceDiff)diff;
/* 327 */       remote = d.getAfterState();
/*     */     } else {
/* 329 */       d = (IResourceDiff)((IThreeWayDiff)diff).getRemoteChange();
/* 330 */       if (d != null)
/* 331 */         remote = d.getAfterState(); 
/*     */     } 
/* 333 */     if (d == null) {
/* 334 */       d = (IResourceDiff)((IThreeWayDiff)diff).getLocalChange();
/* 335 */       if (d != null) {
/* 336 */         remote = d.getBeforeState();
/*     */       }
/*     */     } 
/*     */     
/* 340 */     if (d != null) {
/* 341 */       performReplace(diff, file, remote, monitor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void performReplace(IDiff diff, IFile file, IFileRevision remote, IProgressMonitor monitor) throws CoreException {
/* 364 */     run(monitor1 -> {
/*     */           try {
/*     */             monitor1.beginTask(null, 100);
/*     */             monitor1.subTask(NLS.bind(Messages.MergeContext_6, paramIFile.getFullPath().toString()));
/*     */             if ((paramIFileRevision == null || !paramIFileRevision.exists()) && paramIFile.exists()) {
/*     */               paramIFile.delete(false, true, Policy.subMonitorFor(monitor1, 95));
/*     */             } else if (paramIFileRevision != null) {
/*     */               ensureParentsExist((IResource)paramIFile, monitor1);
/*     */               InputStream stream = paramIFileRevision.getStorage(monitor1).getContents();
/*     */               stream = new BufferedInputStream(stream);
/*     */               try {
/*     */                 if (paramIFile.exists()) {
/*     */                   paramIFile.setContents(stream, false, true, Policy.subMonitorFor(monitor1, 95));
/*     */                 } else {
/*     */                   paramIFile.create(stream, false, Policy.subMonitorFor(monitor1, 95));
/*     */                 } 
/*     */               } finally {
/*     */                 try {
/*     */                   stream.close();
/* 383 */                 } catch (IOException iOException) {}
/*     */               } 
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/*     */             makeInSync(paramIDiff, Policy.subMonitorFor(monitor1, 5));
/*     */           } finally {
/*     */             monitor1.done();
/*     */           } 
/* 393 */         }getMergeRule(diff), 1, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void ensureParentsExist(IResource resource, IProgressMonitor monitor) throws CoreException {
/* 408 */     IContainer parent = resource.getParent();
/* 409 */     if (parent.getType() != 2) {
/*     */       return;
/*     */     }
/*     */     
/* 413 */     if (!parent.exists()) {
/* 414 */       ensureParentsExist((IResource)parent, monitor);
/* 415 */       ((IFolder)parent).create(false, true, monitor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(IWorkspaceRunnable runnable, ISchedulingRule rule, int flags, IProgressMonitor monitor) throws CoreException {
/* 426 */     ResourcesPlugin.getWorkspace().run(runnable, rule, flags, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule getMergeRule(IDiff diff) {
/*     */     IContainer iContainer;
/*     */     ISchedulingRule rule;
/* 437 */     IResource resource = getDiffTree().getResource(diff);
/* 438 */     IResourceRuleFactory ruleFactory = ResourcesPlugin.getWorkspace().getRuleFactory();
/*     */     
/* 440 */     if (!resource.exists()) {
/*     */       
/* 442 */       IContainer parent = resource.getParent();
/* 443 */       while (!parent.exists()) {
/* 444 */         iContainer = parent;
/* 445 */         parent = parent.getParent();
/*     */       } 
/* 447 */       rule = ruleFactory.createRule((IResource)iContainer);
/* 448 */     } else if (SyncInfoToDiffConverter.getRemote(diff) == null) {
/* 449 */       rule = ruleFactory.deleteRule((IResource)iContainer);
/*     */     } else {
/* 451 */       rule = ruleFactory.modifyRule((IResource)iContainer);
/*     */     } 
/* 453 */     return rule;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISchedulingRule getMergeRule(IDiff[] deltas) {
/* 458 */     ISchedulingRule result = null; byte b; int i; IDiff[] arrayOfIDiff;
/* 459 */     for (i = (arrayOfIDiff = deltas).length, b = 0; b < i; ) { IDiff node = arrayOfIDiff[b];
/* 460 */       ISchedulingRule rule = getMergeRule(node);
/* 461 */       if (result == null) {
/* 462 */         result = rule;
/*     */       } else {
/* 464 */         result = MultiRule.combine(result, rule);
/*     */       }  b++; }
/*     */     
/* 467 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMergeType() {
/* 472 */     return getType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getAdapter(Class<T> adapter) {
/* 478 */     if (adapter == IStorageMerger.class) {
/* 479 */       return (T)DelegatingStorageMerger.getInstance();
/*     */     }
/* 481 */     return (T)super.getAdapter(adapter);
/*     */   }
/*     */   
/*     */   protected abstract void makeInSync(IDiff paramIDiff, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\provider\MergeContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */