/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceChangeEvent;
/*     */ import org.eclipse.core.resources.IResourceChangeListener;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.team.core.subscribers.ISubscriberChangeEvent;
/*     */ import org.eclipse.team.core.subscribers.ISubscriberChangeListener;
/*     */ import org.eclipse.team.core.subscribers.Subscriber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SubscriberResourceCollector
/*     */   implements IResourceChangeListener, ISubscriberChangeListener
/*     */ {
/*     */   Subscriber subscriber;
/*     */   
/*     */   public SubscriberResourceCollector(Subscriber subscriber) {
/*  43 */     Assert.isNotNull(subscriber);
/*  44 */     this.subscriber = subscriber;
/*  45 */     ResourcesPlugin.getWorkspace().addResourceChangeListener(this, 1);
/*  46 */     subscriber.addListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subscriber getSubscriber() {
/*  55 */     return this.subscriber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  62 */     getSubscriber().removeListener(this);
/*  63 */     ResourcesPlugin.getWorkspace().removeResourceChangeListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscriberResourceChanged(ISubscriberChangeEvent[] deltas) {
/*     */     try {
/*  69 */       beginInput();
/*  70 */       IResource[] roots = getRoots(); byte b; int i; ISubscriberChangeEvent[] arrayOfISubscriberChangeEvent;
/*  71 */       for (i = (arrayOfISubscriberChangeEvent = deltas).length, b = 0; b < i; ) { ISubscriberChangeEvent delta = arrayOfISubscriberChangeEvent[b];
/*  72 */         switch (delta.getFlags()) {
/*     */           case 1:
/*  74 */             if (isAllRootsIncluded() || isDescendantOfRoot(delta.getResource(), roots)) {
/*  75 */               change(delta.getResource(), 0);
/*     */             }
/*     */             break;
/*     */           case 4:
/*  79 */             remove(delta.getResource());
/*     */             break;
/*     */           case 2:
/*  82 */             if (isAllRootsIncluded() || isDescendantOfRoot(delta.getResource(), roots))
/*  83 */               change(delta.getResource(), 2); 
/*     */             break;
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } finally {
/*  89 */       endInput();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void beginInput() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void endInput() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resourceChanged(IResourceChangeEvent event) {
/*     */     try {
/* 116 */       beginInput();
/* 117 */       processDelta(event.getDelta(), getRoots());
/*     */     } finally {
/* 119 */       endInput();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processDelta(IResourceDelta delta, IResource[] roots) {
/* 130 */     IResource resource = delta.getResource();
/* 131 */     int kind = delta.getKind();
/*     */     
/* 133 */     if (resource.getType() == 4)
/*     */     {
/* 135 */       if ((kind & 0x2) != 0 || ((
/* 136 */         delta.getFlags() & 0x4000) != 0 && !((IProject)resource).isOpen()) || 
/* 137 */         !isAncestorOfRoot(resource, roots))
/*     */       {
/* 139 */         if (hasMembers(resource)) {
/* 140 */           remove(resource);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 145 */     boolean visitChildren = false;
/* 146 */     if (isDescendantOfRoot(resource, roots)) {
/* 147 */       visitChildren = true;
/*     */ 
/*     */       
/* 150 */       if ((delta.getFlags() & 0x8000) != 0) {
/* 151 */         remove(resource);
/* 152 */         change(resource, 2);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 157 */       int changeFlags = delta.getFlags();
/* 158 */       if ((changeFlags & 0x4100) != 0) {
/* 159 */         change(resource, 0);
/*     */       }
/*     */ 
/*     */       
/* 163 */       if ((delta.getKind() & 0x3) != 0) {
/* 164 */         change(resource, 0);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 169 */     if (visitChildren || isAncestorOfRoot(resource, roots)) {
/* 170 */       IResourceDelta[] affectedChildren = delta.getAffectedChildren(7); byte b; int i; IResourceDelta[] arrayOfIResourceDelta1;
/* 171 */       for (i = (arrayOfIResourceDelta1 = affectedChildren).length, b = 0; b < i; ) { IResourceDelta c = arrayOfIResourceDelta1[b];
/* 172 */         processDelta(c, roots);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IResource[] getRoots() {
/* 184 */     return getSubscriber().roots();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean hasMembers(IResource paramIResource);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void remove(IResource paramIResource);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void change(IResource paramIResource, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isAllRootsIncluded() {
/* 219 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isAncestorOfRoot(IResource parent, IResource[] roots) {
/* 224 */     if (parent.getType() == 8) return true;  byte b; int i; IResource[] arrayOfIResource;
/* 225 */     for (i = (arrayOfIResource = roots).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/* 226 */       if (parent.getFullPath().isPrefixOf(resource.getFullPath()))
/* 227 */         return true; 
/*     */       b++; }
/*     */     
/* 230 */     return false; } private boolean isDescendantOfRoot(IResource resource, IResource[] roots) {
/*     */     byte b;
/*     */     int i;
/*     */     IResource[] arrayOfIResource;
/* 234 */     for (i = (arrayOfIResource = roots).length, b = 0; b < i; ) { IResource root = arrayOfIResource[b];
/* 235 */       if (root.getFullPath().isPrefixOf(resource.getFullPath()))
/* 236 */         return true; 
/*     */       b++; }
/*     */     
/* 239 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SubscriberResourceCollector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */