/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.eclipse.team.core.synchronize.SyncInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncInfoStatistics
/*     */ {
/*  27 */   protected Map<Integer, Long> stats = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(SyncInfo info) {
/*  35 */     Long count = this.stats.get(Integer.valueOf(info.getKind()));
/*  36 */     if (count == null) {
/*  37 */       count = Long.valueOf(0L);
/*     */     }
/*  39 */     this.stats.put(Integer.valueOf(info.getKind()), Long.valueOf(count.longValue() + 1L));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(SyncInfo info) {
/*  48 */     Integer kind = Integer.valueOf(info.getKind());
/*  49 */     Long count = this.stats.get(kind);
/*  50 */     if (count != null) {
/*     */ 
/*     */ 
/*     */       
/*  54 */       long newCount = (count.intValue() - 1);
/*  55 */       if (newCount > 0L) {
/*  56 */         this.stats.put(kind, Long.valueOf(newCount));
/*     */       } else {
/*  58 */         this.stats.remove(kind);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long countFor(int kind, int mask) {
/*  74 */     if (mask == 0) {
/*  75 */       Long long_ = this.stats.get(Integer.valueOf(kind));
/*  76 */       return (long_ == null) ? 0L : long_.longValue();
/*     */     } 
/*  78 */     Iterator<Integer> it = this.stats.keySet().iterator();
/*  79 */     long count = 0L;
/*  80 */     while (it.hasNext()) {
/*  81 */       Integer key = it.next();
/*  82 */       if ((key.intValue() & mask) == kind) {
/*  83 */         count += ((Long)this.stats.get(key)).intValue();
/*     */       }
/*     */     } 
/*  86 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  95 */     this.stats.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 103 */     StringBuilder out = new StringBuilder();
/* 104 */     for (Integer kind : this.stats.keySet()) {
/* 105 */       out.append(String.valueOf(SyncInfo.kindToString(kind.intValue())) + ": " + this.stats.get(kind) + "\n");
/*     */     }
/* 107 */     return out.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SyncInfoStatistics.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */