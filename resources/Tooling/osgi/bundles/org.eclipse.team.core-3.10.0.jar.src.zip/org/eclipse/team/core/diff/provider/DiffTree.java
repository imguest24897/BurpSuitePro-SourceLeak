/*     */ package org.eclipse.team.core.diff.provider;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.ListenerList;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.core.runtime.jobs.ILock;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.team.core.diff.FastDiffFilter;
/*     */ import org.eclipse.team.core.diff.IDiff;
/*     */ import org.eclipse.team.core.diff.IDiffChangeEvent;
/*     */ import org.eclipse.team.core.diff.IDiffChangeListener;
/*     */ import org.eclipse.team.core.diff.IDiffTree;
/*     */ import org.eclipse.team.core.diff.IDiffVisitor;
/*     */ import org.eclipse.team.core.diff.IThreeWayDiff;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ import org.eclipse.team.internal.core.mapping.DiffChangeEvent;
/*     */ import org.eclipse.team.internal.core.mapping.PathTree;
/*     */ import org.eclipse.team.internal.core.subscribers.DiffTreeStatistics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiffTree
/*     */   implements IDiffTree
/*     */ {
/*     */   public static final int START_CLIENT_PROPERTY_RANGE = 1024;
/*  58 */   private ListenerList<IDiffChangeListener> listeners = new ListenerList();
/*     */   
/*  60 */   private PathTree pathTree = new PathTree();
/*     */   
/*  62 */   private ILock lock = Job.getJobManager().newLock();
/*     */   
/*  64 */   private DiffTreeStatistics statistics = new DiffTreeStatistics();
/*     */   
/*     */   private DiffChangeEvent changes;
/*     */   
/*     */   private boolean lockedForModification;
/*     */   
/*  70 */   private Map<Integer, Set<IPath>> propertyChanges = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DiffTree() {
/*  76 */     resetChanges();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addDiffChangeListener(IDiffChangeListener listener) {
/*  81 */     this.listeners.add(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeDiffChangeListener(IDiffChangeListener listener) {
/*  86 */     this.listeners.remove(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void accept(IPath path, IDiffVisitor visitor, int depth) {
/*  91 */     IDiff delta = getDiff(path);
/*  92 */     if (delta == null || visitor.visit(delta)) {
/*  93 */       if (depth == 0)
/*     */         return; 
/*  95 */       IPath[] children = getChildren(path); byte b; int i; IPath[] arrayOfIPath1;
/*  96 */       for (i = (arrayOfIPath1 = children).length, b = 0; b < i; ) { IPath child = arrayOfIPath1[b];
/*  97 */         accept(child, visitor, (depth == 1) ? 0 : 2);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   public IDiff getDiff(IPath path) {
/* 104 */     return (IDiff)this.pathTree.get(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath[] getChildren(IPath path) {
/* 109 */     return this.pathTree.getChildren(path);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 114 */     return this.pathTree.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(IDiff delta) {
/*     */     try {
/* 134 */       beginInput();
/* 135 */       IDiff oldDiff = getDiff(delta.getPath());
/* 136 */       internalAdd(delta);
/* 137 */       if (oldDiff != null) {
/* 138 */         internalChanged(delta);
/*     */       } else {
/* 140 */         internalAdded(delta);
/*     */       } 
/*     */     } finally {
/* 143 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(IPath path) {
/*     */     try {
/* 165 */       beginInput();
/* 166 */       IDiff delta = getDiff(path);
/* 167 */       if (delta != null) {
/* 168 */         internalRemove(delta);
/* 169 */         internalRemoved(path, delta);
/*     */       } 
/*     */     } finally {
/* 172 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*     */     try {
/* 181 */       beginInput();
/* 182 */       this.pathTree.clear();
/* 183 */       this.statistics.clear();
/* 184 */       internalReset();
/*     */     } finally {
/* 186 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beginInput() {
/* 215 */     this.lock.acquire();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endInput(IProgressMonitor monitor) {
/*     */     try {
/* 227 */       if (this.lock.getDepth() == 1)
/*     */       {
/*     */         
/* 230 */         fireChanges(Policy.monitorFor(monitor));
/*     */       }
/*     */     } finally {
/* 233 */       this.lock.release();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void fireChanges(final IProgressMonitor monitor) {
/* 239 */     final DiffChangeEvent event = getChangeEvent();
/* 240 */     resetChanges();
/* 241 */     final Map<Integer, Set<IPath>> propertyChanges = this.propertyChanges;
/* 242 */     this.propertyChanges = new HashMap<>();
/*     */     
/* 244 */     if (event.isEmpty() && !event.isReset() && propertyChanges.isEmpty())
/* 245 */       return;  Object[] listeners = this.listeners.getListeners(); byte b; int i; Object[] arrayOfObject1;
/* 246 */     for (i = (arrayOfObject1 = listeners).length, b = 0; b < i; ) { Object l = arrayOfObject1[b];
/* 247 */       final IDiffChangeListener listener = (IDiffChangeListener)l;
/* 248 */       SafeRunner.run(new ISafeRunnable()
/*     */           {
/*     */             public void handleException(Throwable exception) {}
/*     */ 
/*     */ 
/*     */             
/*     */             public void run() throws Exception {
/*     */               try {
/* 256 */                 DiffTree.this.lockedForModification = true;
/* 257 */                 if (!event.isEmpty() || event.isReset())
/* 258 */                   listener.diffsChanged((IDiffChangeEvent)event, Policy.subMonitorFor(monitor, 100)); 
/* 259 */                 for (Integer key : propertyChanges.keySet()) {
/* 260 */                   Set<IPath> paths = (Set<IPath>)propertyChanges.get(key);
/* 261 */                   listener.propertyChanged(DiffTree.this, key.intValue(), paths.<IPath>toArray(
/* 262 */                         new IPath[paths.size()]));
/*     */                 } 
/*     */               } finally {
/*     */                 
/* 266 */                 DiffTree.this.lockedForModification = false;
/*     */               }  }
/*     */           });
/*     */       b++; }
/*     */     
/* 271 */     monitor.done();
/*     */   }
/*     */   
/*     */   private DiffChangeEvent getChangeEvent() {
/* 275 */     return this.changes;
/*     */   }
/*     */   
/*     */   private void resetChanges() {
/* 279 */     this.changes = createEmptyChangeEvent();
/*     */   }
/*     */   
/*     */   private DiffChangeEvent createEmptyChangeEvent() {
/* 283 */     return new DiffChangeEvent(this);
/*     */   }
/*     */   
/*     */   private void internalAdd(IDiff delta) {
/* 287 */     Assert.isTrue(!this.lockedForModification);
/* 288 */     IDiff oldDiff = (IDiff)this.pathTree.get(delta.getPath());
/* 289 */     this.pathTree.put(delta.getPath(), delta);
/* 290 */     if (oldDiff == null) {
/* 291 */       this.statistics.add(delta);
/*     */     } else {
/* 293 */       this.statistics.remove(oldDiff);
/* 294 */       this.statistics.add(delta);
/*     */     } 
/* 296 */     boolean isConflict = false;
/* 297 */     if (delta instanceof IThreeWayDiff) {
/* 298 */       IThreeWayDiff twd = (IThreeWayDiff)delta;
/* 299 */       isConflict = (twd.getDirection() == 768);
/*     */     } 
/* 301 */     setPropertyToRoot(delta, 2, isConflict);
/*     */   }
/*     */   
/*     */   private void internalRemove(IDiff delta) {
/* 305 */     Assert.isTrue(!this.lockedForModification);
/* 306 */     this.statistics.remove(delta);
/* 307 */     setPropertyToRoot(delta, 2, false);
/* 308 */     setPropertyToRoot(delta, 1, false);
/* 309 */     this.pathTree.remove(delta.getPath());
/*     */   }
/*     */   
/*     */   private void internalAdded(IDiff delta) {
/* 313 */     this.changes.added(delta);
/*     */   }
/*     */   
/*     */   private void internalChanged(IDiff delta) {
/* 317 */     this.changes.changed(delta);
/*     */   }
/*     */   private void internalRemoved(IPath path, IDiff delta) {
/* 320 */     this.changes.removed(path, delta);
/*     */   }
/*     */   
/*     */   private void internalReset() {
/* 324 */     this.changes.reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath[] getPaths() {
/* 332 */     return this.pathTree.getPaths();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDiff[] getDiffs() {
/* 340 */     return (IDiff[])this.pathTree.values().toArray((Object[])new IDiff[this.pathTree.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public long countFor(int state, int mask) {
/* 345 */     if (state == 0)
/* 346 */       return size(); 
/* 347 */     return this.statistics.countFor(state, mask);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/* 352 */     return this.pathTree.size();
/*     */   }
/*     */   
/*     */   public void setPropertyToRoot(IDiff node, int property, boolean value) {
/*     */     try {
/* 357 */       beginInput();
/* 358 */       IPath[] paths = this.pathTree.setPropogatedProperty(node.getPath(), property, value);
/* 359 */       accumulatePropertyChanges(property, paths);
/*     */     } finally {
/* 361 */       endInput(null);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void accumulatePropertyChanges(int property, IPath[] paths) {
/* 366 */     Integer key = Integer.valueOf(property);
/* 367 */     Set<IPath> changes = this.propertyChanges.get(key);
/* 368 */     if (changes == null) {
/* 369 */       changes = new HashSet<>();
/* 370 */       this.propertyChanges.put(key, changes);
/*     */     } 
/* 372 */     Collections.addAll(changes, paths);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getProperty(IPath path, int property) {
/* 377 */     return this.pathTree.getProperty(path, property);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBusy(IDiff[] diffs, IProgressMonitor monitor) {
/*     */     try {
/* 383 */       beginInput(); byte b; int i; IDiff[] arrayOfIDiff;
/* 384 */       for (i = (arrayOfIDiff = diffs).length, b = 0; b < i; ) { IDiff node = arrayOfIDiff[b];
/* 385 */         setPropertyToRoot(node, 1, true); b++; }
/*     */     
/*     */     } finally {
/* 388 */       endInput(monitor);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearBusy(IProgressMonitor monitor) {
/*     */     try {
/* 395 */       beginInput();
/* 396 */       IPath[] paths = this.pathTree.getPaths(); byte b; int i; IPath[] arrayOfIPath1;
/* 397 */       for (i = (arrayOfIPath1 = paths).length, b = 0; b < i; ) { IPath path = arrayOfIPath1[b];
/* 398 */         IPath[] changed = this.pathTree.setPropogatedProperty(path, 1, false);
/* 399 */         accumulatePropertyChanges(1, changed); b++; }
/*     */     
/*     */     } finally {
/* 402 */       endInput(monitor);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasMatchingDiffs(IPath path, FastDiffFilter filter) {
/* 408 */     RuntimeException found = new RuntimeException();
/*     */     try {
/* 410 */       accept(path, delta -> {
/*     */             if (paramFastDiffFilter.select(delta)) {
/*     */               throw paramRuntimeException;
/*     */             }
/*     */             return false;
/* 415 */           }2);
/* 416 */     } catch (RuntimeException e) {
/* 417 */       if (e == found)
/* 418 */         return true; 
/* 419 */       throw e;
/*     */     } 
/* 421 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reportError(IStatus status) {
/*     */     try {
/* 434 */       beginInput();
/* 435 */       getChangeEvent().errorOccurred(status);
/*     */     } finally {
/* 437 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\diff\provider\DiffTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */