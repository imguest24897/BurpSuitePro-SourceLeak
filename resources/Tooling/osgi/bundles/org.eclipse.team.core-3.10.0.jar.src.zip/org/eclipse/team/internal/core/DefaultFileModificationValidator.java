/*     */ package org.eclipse.team.internal.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.team.FileModificationValidationContext;
/*     */ import org.eclipse.core.resources.team.FileModificationValidator;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.TeamStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultFileModificationValidator
/*     */   extends FileModificationValidator
/*     */ {
/*     */   private FileModificationValidator uiValidator;
/*     */   
/*     */   protected IStatus getDefaultStatus(IFile file) {
/*  44 */     return 
/*  45 */       file.isReadOnly() ? 
/*  46 */       (IStatus)new TeamStatus(4, "org.eclipse.team.core", 279, NLS.bind(Messages.FileModificationValidator_fileIsReadOnly, (Object[])new String[] { file.getFullPath().toString() }), null, (IResource)file) : 
/*  47 */       Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */   
/*     */   public IStatus validateEdit(IFile[] files, FileModificationValidationContext context) {
/*  52 */     IFile[] readOnlyFiles = getReadOnly(files);
/*  53 */     if (readOnlyFiles.length == 0)
/*  54 */       return Status.OK_STATUS; 
/*  55 */     synchronized (this) {
/*  56 */       if (this.uiValidator == null)
/*  57 */         this.uiValidator = loadUIValidator(); 
/*     */     } 
/*  59 */     if (this.uiValidator != null) {
/*  60 */       return this.uiValidator.validateEdit(files, context);
/*     */     }
/*     */     
/*  63 */     return getStatus(files);
/*     */   }
/*     */   
/*     */   protected IStatus getStatus(IFile[] files) {
/*  67 */     if (files.length == 1) {
/*  68 */       return getDefaultStatus(files[0]);
/*     */     }
/*     */     
/*  71 */     Status[] arrayOfStatus = new Status[files.length];
/*  72 */     boolean allOK = true;
/*     */     
/*  74 */     for (int i = 0; i < files.length; i++) {
/*  75 */       arrayOfStatus[i] = (Status)getDefaultStatus(files[i]);
/*  76 */       if (!arrayOfStatus[i].isOK()) {
/*  77 */         allOK = false;
/*     */       }
/*     */     } 
/*  80 */     return (IStatus)new MultiStatus("org.eclipse.team.core", 
/*  81 */         0, (IStatus[])arrayOfStatus, 
/*  82 */         allOK ? 
/*  83 */         Messages.ok : 
/*  84 */         Messages.FileModificationValidator_someReadOnly, 
/*  85 */         null);
/*     */   }
/*     */   
/*     */   private IFile[] getReadOnly(IFile[] files) {
/*  89 */     List<IFile> result = new ArrayList<>(files.length); byte b; int i; IFile[] arrayOfIFile;
/*  90 */     for (i = (arrayOfIFile = files).length, b = 0; b < i; ) { IFile file = arrayOfIFile[b];
/*  91 */       if (file.isReadOnly())
/*  92 */         result.add(file); 
/*     */       b++; }
/*     */     
/*  95 */     return result.<IFile>toArray(new IFile[result.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public IStatus validateSave(IFile file) {
/* 100 */     if (!file.isReadOnly())
/* 101 */       return Status.OK_STATUS; 
/* 102 */     synchronized (this) {
/* 103 */       if (this.uiValidator == null)
/* 104 */         this.uiValidator = loadUIValidator(); 
/*     */     } 
/* 106 */     if (this.uiValidator != null) {
/* 107 */       return this.uiValidator.validateSave(file);
/*     */     }
/* 109 */     return getDefaultStatus(file);
/*     */   }
/*     */   
/*     */   private FileModificationValidator loadUIValidator() {
/* 113 */     IExtensionPoint extension = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.team.core", "defaultFileModificationValidator");
/* 114 */     if (extension != null) {
/* 115 */       IExtension[] extensions = extension.getExtensions();
/* 116 */       if (extensions.length > 0) {
/* 117 */         IConfigurationElement[] configElements = extensions[0].getConfigurationElements();
/* 118 */         if (configElements.length > 0) {
/*     */           try {
/* 120 */             Object o = configElements[0].createExecutableExtension("class");
/* 121 */             if (o instanceof FileModificationValidator) {
/* 122 */               return (FileModificationValidator)o;
/*     */             }
/* 124 */           } catch (CoreException e) {
/* 125 */             TeamPlugin.log(e);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 130 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\DefaultFileModificationValidator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */