/*    */ package org.eclipse.team.internal.core.mapping;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.ResourcesPlugin;
/*    */ import org.eclipse.core.resources.mapping.ModelProvider;
/*    */ import org.eclipse.core.resources.mapping.RemoteResourceMappingContext;
/*    */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*    */ import org.eclipse.core.resources.mapping.ResourceMappingContext;
/*    */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.team.internal.core.Policy;
/*    */ import org.eclipse.team.internal.core.TeamPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModelProviderResourceMapping
/*    */   extends ResourceMapping
/*    */ {
/*    */   ModelProvider provider;
/*    */   
/*    */   public ModelProviderResourceMapping(ModelProvider provider) {
/* 37 */     this.provider = provider;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getModelObject() {
/* 42 */     return this.provider;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getModelProviderId() {
/* 49 */     return "org.eclipse.core.resources.modelProvider";
/*    */   }
/*    */ 
/*    */   
/*    */   public IProject[] getProjects() {
/* 54 */     IProject[] projects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
/*    */     try {
/* 56 */       IResource[] resources = this.provider.getDescriptor().getMatchingResources((IResource[])projects);
/* 57 */       Set<IProject> result = new HashSet<>(); byte b; int i; IResource[] arrayOfIResource1;
/* 58 */       for (i = (arrayOfIResource1 = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource1[b];
/* 59 */         if (resource.isAccessible())
/* 60 */           result.add(resource.getProject());  b++; }
/*    */       
/* 62 */       return result.<IProject>toArray(new IProject[result.size()]);
/* 63 */     } catch (CoreException e) {
/* 64 */       TeamPlugin.log(e);
/*    */       
/* 66 */       return projects;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public ResourceTraversal[] getTraversals(ResourceMappingContext context, IProgressMonitor monitor) throws CoreException {
/* 72 */     monitor = Policy.monitorFor(monitor);
/*    */     try {
/* 74 */       monitor.beginTask(null, 100);
/* 75 */       ResourceMapping[] mappings = this.provider.getMappings(getProviderResources(context), context, Policy.subMonitorFor(monitor, 50));
/* 76 */       return this.provider.getTraversals(mappings, context, Policy.subMonitorFor(monitor, 50));
/*    */     } finally {
/* 78 */       monitor.done();
/*    */     } 
/*    */   }
/*    */   
/*    */   private IResource[] getProviderResources(ResourceMappingContext context) {
/*    */     try {
/* 84 */       if (context instanceof RemoteResourceMappingContext) {
/* 85 */         RemoteResourceMappingContext rrmc = (RemoteResourceMappingContext)context;
/* 86 */         return this.provider.getDescriptor().getMatchingResources((IResource[])rrmc.getProjects());
/*    */       } 
/* 88 */     } catch (CoreException e) {
/* 89 */       TeamPlugin.log(e);
/*    */     } 
/* 91 */     return (IResource[])getProjects();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean contains(ResourceMapping mapping) {
/* 96 */     return mapping.getModelProviderId().equals(getModelProviderId());
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\ModelProviderResourceMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */