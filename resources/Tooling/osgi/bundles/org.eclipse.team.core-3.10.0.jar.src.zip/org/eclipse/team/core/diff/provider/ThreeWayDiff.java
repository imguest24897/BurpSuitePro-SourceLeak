/*     */ package org.eclipse.team.core.diff.provider;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.diff.IThreeWayDiff;
/*     */ import org.eclipse.team.core.diff.ITwoWayDiff;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.mapping.SyncInfoToDiffConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThreeWayDiff
/*     */   extends Diff
/*     */   implements IThreeWayDiff
/*     */ {
/*     */   private final ITwoWayDiff localChange;
/*     */   private final ITwoWayDiff remoteChange;
/*     */   
/*     */   public ThreeWayDiff(ITwoWayDiff localChange, ITwoWayDiff remoteChange) {
/*  44 */     super(calculatePath(localChange, remoteChange), calculateKind(localChange, remoteChange) | calculateDirection(localChange, remoteChange));
/*  45 */     this.localChange = localChange;
/*  46 */     this.remoteChange = remoteChange;
/*     */   }
/*     */   
/*     */   private static IPath calculatePath(ITwoWayDiff localChange, ITwoWayDiff remoteChange) {
/*  50 */     if (localChange != null && remoteChange != null)
/*  51 */       Assert.isTrue(localChange.getPath().equals(remoteChange.getPath())); 
/*  52 */     if (localChange != null)
/*  53 */       return localChange.getPath(); 
/*  54 */     if (remoteChange != null)
/*  55 */       return remoteChange.getPath(); 
/*  56 */     Assert.isLegal(false, "Either or local or remote change must be supplied");
/*  57 */     return null;
/*     */   }
/*     */   
/*     */   private static int calculateDirection(ITwoWayDiff localChange, ITwoWayDiff remoteChange) {
/*  61 */     int direction = 0;
/*  62 */     if (localChange != null && localChange.getKind() != 0) {
/*  63 */       direction |= 0x100;
/*     */     }
/*  65 */     if (remoteChange != null && remoteChange.getKind() != 0) {
/*  66 */       direction |= 0x200;
/*     */     }
/*  68 */     return direction;
/*     */   }
/*     */   
/*     */   private static int calculateKind(ITwoWayDiff localChange, ITwoWayDiff remoteChange) {
/*  72 */     int localKind = 0;
/*  73 */     if (localChange != null)
/*  74 */       localKind = localChange.getKind(); 
/*  75 */     int remoteKind = 0;
/*  76 */     if (remoteChange != null)
/*  77 */       remoteKind = remoteChange.getKind(); 
/*  78 */     if (localKind == 0 || localKind == remoteKind)
/*  79 */       return remoteKind; 
/*  80 */     if (remoteKind == 0)
/*  81 */       return localKind; 
/*  82 */     return 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITwoWayDiff getLocalChange() {
/*  87 */     return this.localChange;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITwoWayDiff getRemoteChange() {
/*  92 */     return this.remoteChange;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDirection() {
/*  97 */     return getStatus() & 0x300;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toDiffString() {
/* 102 */     int kind = getKind();
/* 103 */     String label = "";
/* 104 */     if (kind == 0) {
/* 105 */       label = super.toDiffString();
/*     */     } else {
/* 107 */       label = SyncInfoToDiffConverter.diffDirectionToString(getDirection());
/* 108 */       label = NLS.bind(Messages.concatStrings, (Object[])new String[] { label, super.toDiffString() });
/*     */     } 
/* 110 */     return label;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 115 */     if (obj == this)
/* 116 */       return true; 
/* 117 */     if (super.equals(obj) && 
/* 118 */       obj instanceof ThreeWayDiff) {
/* 119 */       ThreeWayDiff other = (ThreeWayDiff)obj;
/* 120 */       return (changesEqual(getLocalChange(), other.getLocalChange()) && 
/* 121 */         changesEqual(getRemoteChange(), other.getRemoteChange()));
/*     */     } 
/*     */     
/* 124 */     return false;
/*     */   }
/*     */   
/*     */   private boolean changesEqual(ITwoWayDiff diff, ITwoWayDiff diff2) {
/* 128 */     if (diff == null)
/* 129 */       return (diff2 == null); 
/* 130 */     if (diff2 == null)
/* 131 */       return false; 
/* 132 */     return diff.equals(diff2);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\diff\provider\ThreeWayDiff.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */