/*     */ package org.eclipse.team.internal.core.history;
/*     */ 
/*     */ import java.net.URI;
/*     */ import org.eclipse.core.filesystem.URIUtil;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IFileState;
/*     */ import org.eclipse.core.resources.IStorage;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.history.IFileRevision;
/*     */ import org.eclipse.team.core.history.ITag;
/*     */ import org.eclipse.team.core.history.provider.FileRevision;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalFileRevision
/*     */   extends FileRevision
/*     */ {
/*     */   private IFileState state;
/*     */   private IFile file;
/*     */   private IFileRevision baseRevision;
/*     */   
/*     */   public LocalFileRevision(IFileState state) {
/*  52 */     this.state = state;
/*  53 */     this.file = null;
/*  54 */     this.baseRevision = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalFileRevision(IFile file) {
/*  65 */     this.file = file;
/*  66 */     this.baseRevision = null;
/*  67 */     this.state = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentIdentifier() {
/*  72 */     if (this.file != null)
/*  73 */       return (this.baseRevision == null) ? NLS.bind(Messages.LocalFileRevision_currentVersion, "") : NLS.bind(Messages.LocalFileRevision_currentVersion, this.baseRevision.getContentIdentifier()); 
/*  74 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAuthor() {
/*  79 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getComment() {
/*  84 */     if (this.file != null)
/*  85 */       return Messages.LocalFileRevision_currentVersionTag; 
/*  86 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ITag[] getTags() {
/*  91 */     return new ITag[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public IStorage getStorage(IProgressMonitor monitor) throws CoreException {
/*  96 */     if (this.file != null) {
/*  97 */       return (IStorage)this.file;
/*     */     }
/*  99 */     return (IStorage)this.state;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 104 */     if (this.file != null) {
/* 105 */       return this.file.getName();
/*     */     }
/*     */     
/* 108 */     return this.state.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getTimestamp() {
/* 113 */     if (this.file != null) {
/* 114 */       return this.file.getLocalTimeStamp();
/*     */     }
/*     */     
/* 117 */     return this.state.getModificationTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean exists() {
/* 126 */     if (this.file != null) {
/* 127 */       return this.file.exists();
/*     */     }
/*     */     
/* 130 */     return this.state.exists();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBaseRevision(IFileRevision baseRevision) {
/* 138 */     this.baseRevision = baseRevision;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPropertyMissing() {
/* 143 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileRevision withAllProperties(IProgressMonitor monitor) {
/* 149 */     return (IFileRevision)this;
/*     */   }
/*     */   
/*     */   public boolean isPredecessorOf(IFileRevision revision) {
/* 153 */     long compareRevisionTime = revision.getTimestamp();
/* 154 */     return (getTimestamp() < compareRevisionTime);
/*     */   }
/*     */   
/*     */   public boolean isDescendentOf(IFileRevision revision) {
/* 158 */     long compareRevisionTime = revision.getTimestamp();
/* 159 */     return (getTimestamp() > compareRevisionTime);
/*     */   }
/*     */ 
/*     */   
/*     */   public URI getURI() {
/* 164 */     if (this.file != null) {
/* 165 */       return this.file.getLocationURI();
/*     */     }
/* 167 */     return URIUtil.toURI(this.state.getFullPath());
/*     */   }
/*     */   
/*     */   public IFile getFile() {
/* 171 */     return this.file;
/*     */   }
/*     */   
/*     */   public IFileState getState() {
/* 175 */     return this.state;
/*     */   }
/*     */   
/*     */   public boolean isCurrentState() {
/* 179 */     return (this.file != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 184 */     if (obj == this)
/* 185 */       return true; 
/* 186 */     if (obj instanceof LocalFileRevision) {
/* 187 */       LocalFileRevision other = (LocalFileRevision)obj;
/* 188 */       if (this.file != null && other.file != null)
/* 189 */         return this.file.equals(other.file); 
/* 190 */       if (this.state != null && other.state != null)
/* 191 */         return statesEqual(this.state, other.state); 
/*     */     } 
/* 193 */     return false;
/*     */   }
/*     */   
/*     */   private boolean statesEqual(IFileState s1, IFileState s2) {
/* 197 */     return (s1.getFullPath().equals(s2.getFullPath()) && s1.getModificationTime() == s2.getModificationTime());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 202 */     if (this.file != null)
/* 203 */       return this.file.hashCode(); 
/* 204 */     if (this.state != null)
/* 205 */       return (int)this.state.getModificationTime(); 
/* 206 */     return super.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\history\LocalFileRevision.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */