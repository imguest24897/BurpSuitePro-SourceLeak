/*    */ package org.eclipse.team.internal.core.mapping;
/*    */ 
/*    */ import java.io.FilterInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TrailingLineFeedDetector
/*    */   extends FilterInputStream
/*    */ {
/*    */   boolean trailingLF = false;
/*    */   
/*    */   protected TrailingLineFeedDetector(InputStream in) {
/* 46 */     super(in);
/*    */   }
/*    */ 
/*    */   
/*    */   public int read() throws IOException {
/* 51 */     int c = super.read();
/* 52 */     this.trailingLF = isLineFeed(c);
/* 53 */     return c;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int read(byte[] buffer, int off, int len) throws IOException {
/* 63 */     int length = super.read(buffer, off, len);
/* 64 */     if (length != -1) {
/* 65 */       int index = off + length - 1;
/* 66 */       if (index >= buffer.length)
/* 67 */         index = buffer.length - 1; 
/* 68 */       this.trailingLF = isLineFeed(buffer[index]);
/*    */     } 
/* 70 */     return length;
/*    */   }
/*    */   
/*    */   private boolean isLineFeed(int c) {
/* 74 */     return (c != -1 && c == 10);
/*    */   }
/*    */   
/*    */   public boolean hadTrailingLineFeed() {
/* 78 */     return this.trailingLF;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\LineComparator$TrailingLineFeedDetector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */