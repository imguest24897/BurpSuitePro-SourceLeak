/*     */ package org.eclipse.team.core.mapping;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.mapping.ModelProvider;
/*     */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.core.runtime.jobs.MultiRule;
/*     */ import org.eclipse.team.core.diff.IDiff;
/*     */ import org.eclipse.team.core.mapping.provider.MergeStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResourceMappingMerger
/*     */   implements IResourceMappingMerger
/*     */ {
/*     */   public IStatus validateMerge(IMergeContext mergeContext, IProgressMonitor monitor) {
/*  51 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract ModelProvider getModelProvider();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISchedulingRule getMergeRule(IMergeContext context) {
/*  73 */     ResourceMapping[] mappings = context.getScope().getMappings(getModelProvider().getId());
/*  74 */     ISchedulingRule iSchedulingRule = null; byte b; int i; ResourceMapping[] arrayOfResourceMapping1;
/*  75 */     for (i = (arrayOfResourceMapping1 = mappings).length, b = 0; b < i; ) { ResourceMapping mapping = arrayOfResourceMapping1[b];
/*  76 */       IProject[] mappingProjects = mapping.getProjects(); byte b1; int j; IProject[] arrayOfIProject1;
/*  77 */       for (j = (arrayOfIProject1 = mappingProjects).length, b1 = 0; b1 < j; ) { IProject iProject1, project = arrayOfIProject1[b1];
/*  78 */         if (iSchedulingRule == null) {
/*  79 */           iProject1 = project;
/*     */         } else {
/*  81 */           iSchedulingRule = MultiRule.combine((ISchedulingRule)iProject1, (ISchedulingRule)project);
/*     */         }  b1++; }
/*     */        b++; }
/*     */     
/*  85 */     return iSchedulingRule;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus merge(IMergeContext mergeContext, IProgressMonitor monitor) throws CoreException {
/*  99 */     IDiff[] deltas = getSetToMerge(mergeContext);
/* 100 */     IStatus status = mergeContext.merge(deltas, false, monitor);
/* 101 */     return covertFilesToMappings(status, mergeContext);
/*     */   }
/*     */   
/*     */   private IDiff[] getSetToMerge(IMergeContext mergeContext) {
/* 105 */     ResourceMapping[] mappings = mergeContext.getScope().getMappings(getModelProvider().getDescriptor().getId());
/* 106 */     Set<IDiff> result = new HashSet<>(); byte b; int i; ResourceMapping[] arrayOfResourceMapping1;
/* 107 */     for (i = (arrayOfResourceMapping1 = mappings).length, b = 0; b < i; ) { ResourceMapping mapping = arrayOfResourceMapping1[b];
/* 108 */       ResourceTraversal[] traversals = mergeContext.getScope().getTraversals(mapping);
/* 109 */       IDiff[] deltas = mergeContext.getDiffTree().getDiffs(traversals);
/* 110 */       Collections.addAll(result, deltas); b++; }
/*     */     
/* 112 */     return result.<IDiff>toArray(new IDiff[result.size()]);
/*     */   }
/*     */   
/*     */   private IStatus covertFilesToMappings(IStatus status, IMergeContext mergeContext) {
/* 116 */     if (status.getCode() == 1)
/*     */     {
/* 118 */       return (IStatus)new MergeStatus(status.getPlugin(), status.getMessage(), mergeContext.getScope().getMappings(getModelProvider().getDescriptor().getId()));
/*     */     }
/* 120 */     return status;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\ResourceMappingMerger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */