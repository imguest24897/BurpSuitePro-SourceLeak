/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.util.Date;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.team.core.synchronize.SyncInfo;
/*     */ import org.eclipse.team.core.synchronize.SyncInfoTree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CheckedInChangeSet
/*     */   extends ChangeSet
/*     */ {
/*  36 */   private final SyncInfoTree set = new SyncInfoTree();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getAuthor();
/*     */ 
/*     */   
/*     */   public abstract Date getDate();
/*     */ 
/*     */   
/*     */   public SyncInfoTree getSyncInfoSet() {
/*  47 */     return this.set;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource[] getResources() {
/*  56 */     return this.set.getResources();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  65 */     return this.set.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(IResource local) {
/*  75 */     return (this.set.getSyncInfo(local) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(SyncInfo info) {
/*  84 */     if (isValidChange(info)) {
/*  85 */       this.set.add(info);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isValidChange(SyncInfo info) {
/*  97 */     return (info != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(SyncInfo[] infos) {
/*     */     try {
/* 107 */       this.set.beginInput(); byte b; int i; SyncInfo[] arrayOfSyncInfo;
/* 108 */       for (i = (arrayOfSyncInfo = infos).length, b = 0; b < i; ) { SyncInfo info = arrayOfSyncInfo[b];
/* 109 */         add(info); b++; }
/*     */     
/*     */     } finally {
/* 112 */       this.set.endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(IResource resource) {
/* 122 */     if (contains(resource)) {
/* 123 */       this.set.remove(resource);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(IResource[] resources) {
/*     */     byte b;
/*     */     int i;
/*     */     IResource[] arrayOfIResource;
/* 133 */     for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/* 134 */       remove(resource);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rootRemoved(IResource resource, int depth) {
/* 146 */     SyncInfo[] infos = this.set.getSyncInfos(resource, depth);
/* 147 */     if (infos.length > 0) {
/* 148 */       IResource[] resources = new IResource[infos.length];
/* 149 */       for (int i = 0; i < resources.length; i++) {
/* 150 */         resources[i] = infos[i].getLocal();
/*     */       }
/* 152 */       this.set.removeAll(resources);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean containsChildren(IResource resource, int depth) {
/* 158 */     return ((this.set.getSyncInfos(resource, depth)).length > 0);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\CheckedInChangeSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */