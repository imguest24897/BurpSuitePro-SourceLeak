/*    */ package org.eclipse.team.core.mapping.provider;
/*    */ 
/*    */ import org.eclipse.core.resources.IFile;
/*    */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.team.core.mapping.IMergeStatus;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MergeStatus
/*    */   extends Status
/*    */   implements IMergeStatus
/*    */ {
/*    */   private ResourceMapping[] conflictingMappings;
/*    */   private IFile[] conflictingFiles;
/*    */   
/*    */   public MergeStatus(String pluginId, String message, ResourceMapping[] conflictingMappings) {
/* 48 */     super(4, pluginId, 1, message, null);
/* 49 */     this.conflictingMappings = conflictingMappings;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MergeStatus(String pluginId, String message, IFile[] files) {
/* 60 */     super(4, pluginId, 1, message, null);
/* 61 */     this.conflictingFiles = files;
/*    */   }
/*    */ 
/*    */   
/*    */   public ResourceMapping[] getConflictingMappings() {
/* 66 */     return this.conflictingMappings;
/*    */   }
/*    */ 
/*    */   
/*    */   public IFile[] getConflictingFiles() {
/* 71 */     return this.conflictingFiles;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\provider\MergeStatus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */