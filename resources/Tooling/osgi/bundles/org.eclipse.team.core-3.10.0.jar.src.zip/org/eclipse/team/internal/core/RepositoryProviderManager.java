/*    */ package org.eclipse.team.internal.core;
/*    */ 
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.runtime.ListenerList;
/*    */ import org.eclipse.team.core.RepositoryProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RepositoryProviderManager
/*    */   implements IRepositoryProviderListener
/*    */ {
/*    */   private static RepositoryProviderManager instance;
/* 23 */   private ListenerList<IRepositoryProviderListener> listeners = new ListenerList();
/*    */   
/*    */   public static synchronized RepositoryProviderManager getInstance() {
/* 26 */     if (instance == null) {
/* 27 */       instance = new RepositoryProviderManager();
/*    */     }
/* 29 */     return instance;
/*    */   }
/*    */ 
/*    */   
/*    */   public void providerMapped(RepositoryProvider provider) {
/* 34 */     Object[] allListeners = this.listeners.getListeners(); byte b; int i; Object[] arrayOfObject1;
/* 35 */     for (i = (arrayOfObject1 = allListeners).length, b = 0; b < i; ) { Object l = arrayOfObject1[b];
/* 36 */       IRepositoryProviderListener listener = (IRepositoryProviderListener)l;
/* 37 */       listener.providerMapped(provider);
/*    */       b++; }
/*    */   
/*    */   }
/*    */   
/*    */   public void providerUnmapped(IProject project) {
/* 43 */     Object[] allListeners = this.listeners.getListeners(); byte b; int i; Object[] arrayOfObject1;
/* 44 */     for (i = (arrayOfObject1 = allListeners).length, b = 0; b < i; ) { Object l = arrayOfObject1[b];
/* 45 */       IRepositoryProviderListener listener = (IRepositoryProviderListener)l;
/* 46 */       listener.providerUnmapped(project);
/*    */       b++; }
/*    */   
/*    */   }
/*    */   public void addListener(IRepositoryProviderListener listener) {
/* 51 */     this.listeners.add(listener);
/*    */   }
/*    */   
/*    */   public void removeListener(IRepositoryProviderListener listener) {
/* 55 */     this.listeners.remove(listener);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\RepositoryProviderManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */