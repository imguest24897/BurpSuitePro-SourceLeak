package org.eclipse.team.internal.core.subscribers;

import org.eclipse.core.runtime.IPath;

public interface IChangeSetChangeListener {
  void setAdded(ChangeSet paramChangeSet);
  
  void defaultSetChanged(ChangeSet paramChangeSet1, ChangeSet paramChangeSet2);
  
  void setRemoved(ChangeSet paramChangeSet);
  
  void nameChanged(ChangeSet paramChangeSet);
  
  void resourcesChanged(ChangeSet paramChangeSet, IPath[] paramArrayOfIPath);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\IChangeSetChangeListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */