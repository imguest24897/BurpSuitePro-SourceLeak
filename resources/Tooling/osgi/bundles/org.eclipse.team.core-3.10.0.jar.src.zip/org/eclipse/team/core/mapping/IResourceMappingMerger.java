package org.eclipse.team.core.mapping;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.jobs.ISchedulingRule;

public interface IResourceMappingMerger {
  IStatus merge(IMergeContext paramIMergeContext, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  ISchedulingRule getMergeRule(IMergeContext paramIMergeContext);
  
  IStatus validateMerge(IMergeContext paramIMergeContext, IProgressMonitor paramIProgressMonitor);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\IResourceMappingMerger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */