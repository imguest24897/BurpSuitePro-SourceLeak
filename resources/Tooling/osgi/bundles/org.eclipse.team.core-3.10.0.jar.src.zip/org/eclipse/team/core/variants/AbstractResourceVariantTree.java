/*     */ package org.eclipse.team.core.variants;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractResourceVariantTree
/*     */   implements IResourceVariantTree
/*     */ {
/*     */   public IResource[] refresh(IResource[] resources, int depth, IProgressMonitor monitor) throws TeamException {
/*  66 */     List<IResource> changedResources = new ArrayList<>();
/*  67 */     monitor.beginTask(null, 100 * resources.length); byte b; int i; IResource[] arrayOfIResource;
/*  68 */     for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/*  69 */       IResource[] changed = refresh(resource, depth, Policy.subMonitorFor(monitor, 100));
/*  70 */       changedResources.addAll(Arrays.asList(changed)); b++; }
/*     */     
/*  72 */     monitor.done();
/*  73 */     return changedResources.<IResource>toArray(new IResource[changedResources.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IResource[] refresh(IResource resource, int depth, IProgressMonitor monitor) throws TeamException {
/*  93 */     IResource[] changedResources = null;
/*  94 */     monitor.beginTask(null, 100);
/*     */     try {
/*  96 */       monitor.setTaskName(NLS.bind(Messages.SynchronizationCacheRefreshOperation_0, (Object[])new String[] { resource.getFullPath().makeRelative().toString() }));
/*     */ 
/*     */       
/*  99 */       IResourceVariant tree = fetchVariant(resource, depth, Policy.subMonitorFor(monitor, 70));
/*     */ 
/*     */       
/* 102 */       IProgressMonitor sub = Policy.infiniteSubMonitorFor(monitor, 30);
/*     */       try {
/* 104 */         sub.beginTask(null, 64);
/* 105 */         changedResources = collectChanges(resource, tree, depth, Policy.subMonitorFor(sub, 64));
/*     */       } finally {
/* 107 */         sub.done();
/*     */       } 
/*     */     } finally {
/* 110 */       monitor.done();
/*     */     } 
/* 112 */     if (changedResources == null) return new IResource[0]; 
/* 113 */     return changedResources;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IResource[] collectChanges(IResource local, IResourceVariant remote, int depth, IProgressMonitor monitor) throws TeamException {
/* 127 */     List<IResource> changedResources = new ArrayList<>();
/* 128 */     collectChanges(local, remote, changedResources, depth, monitor);
/* 129 */     return changedResources.<IResource>toArray(new IResource[changedResources.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract IResourceVariant[] fetchMembers(IResourceVariant paramIResourceVariant, IProgressMonitor paramIProgressMonitor) throws TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract IResourceVariant fetchVariant(IResource paramIResource, int paramInt, IProgressMonitor paramIProgressMonitor) throws TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IResource[] collectedMembers(IResource local, IResource[] members) throws TeamException {
/* 168 */     return new IResource[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean setVariant(IResource paramIResource, IResourceVariant paramIResourceVariant) throws TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void collectChanges(IResource local, IResourceVariant remote, Collection<IResource> changedResources, int depth, IProgressMonitor monitor) throws TeamException {
/* 183 */     boolean changed = setVariant(local, remote);
/* 184 */     if (changed) {
/* 185 */       changedResources.add(local);
/*     */     }
/* 187 */     if (depth == 0)
/* 188 */       return;  Map<IResource, IResourceVariant> children = mergedMembers(local, remote, monitor);
/* 189 */     for (IResource localChild : children.keySet()) {
/* 190 */       IResourceVariant remoteChild = children.get(localChild);
/* 191 */       collectChanges(localChild, remoteChild, changedResources, 
/* 192 */           (depth == 2) ? 2 : 0, 
/* 193 */           monitor);
/*     */     } 
/*     */     
/* 196 */     IResource[] cleared = collectedMembers(local, (IResource[])children.keySet().toArray((Object[])new IResource[children.size()]));
/* 197 */     changedResources.addAll(Arrays.asList(cleared));
/* 198 */     monitor.worked(1);
/*     */   }
/*     */ 
/*     */   
/*     */   private Map<IResource, IResourceVariant> mergedMembers(IResource local, IResourceVariant remote, IProgressMonitor progress) throws TeamException {
/*     */     IResourceVariant[] remoteChildren;
/* 204 */     Map<IResource, IResourceVariant> mergedResources = new HashMap<>();
/*     */ 
/*     */     
/* 207 */     if (remote == null) {
/* 208 */       remoteChildren = new IResourceVariant[0];
/*     */     } else {
/* 210 */       remoteChildren = fetchMembers(remote, progress);
/*     */     } 
/*     */ 
/*     */     
/* 214 */     IResource[] localChildren = members(local);
/*     */     
/* 216 */     if (remoteChildren.length > 0 || localChildren.length > 0) {
/* 217 */       Set<String> allSet = new HashSet<>(20);
/* 218 */       Map<String, IResource> localSet = null;
/* 219 */       Map<String, IResourceVariant> remoteSet = null;
/*     */       
/* 221 */       if (localChildren.length > 0) {
/* 222 */         localSet = new HashMap<>(10); byte b; int i; IResource[] arrayOfIResource;
/* 223 */         for (i = (arrayOfIResource = localChildren).length, b = 0; b < i; ) { IResource localChild = arrayOfIResource[b];
/* 224 */           String name = localChild.getName();
/* 225 */           localSet.put(name, localChild);
/* 226 */           allSet.add(name);
/*     */           b++; }
/*     */       
/*     */       } 
/* 230 */       if (remoteChildren.length > 0) {
/* 231 */         remoteSet = new HashMap<>(10); byte b; int i; IResourceVariant[] arrayOfIResourceVariant;
/* 232 */         for (i = (arrayOfIResourceVariant = remoteChildren).length, b = 0; b < i; ) { IResourceVariant remoteChild = arrayOfIResourceVariant[b];
/* 233 */           String name = remoteChild.getName();
/* 234 */           remoteSet.put(name, remoteChild);
/* 235 */           allSet.add(name);
/*     */           b++; }
/*     */       
/*     */       } 
/* 239 */       for (String keyChildName : allSet) {
/* 240 */         Policy.checkCanceled(progress);
/*     */         
/* 242 */         IResource localChild = 
/* 243 */           (localSet != null) ? localSet.get(keyChildName) : null;
/*     */         
/* 245 */         IResourceVariant remoteChild = 
/* 246 */           (remoteSet != null) ? remoteSet.get(keyChildName) : null;
/*     */         
/* 248 */         if (localChild == null) {
/*     */           
/* 250 */           Assert.isTrue((remoteChild != null));
/* 251 */           boolean isContainer = remoteChild.isContainer();
/* 252 */           localChild = getResourceChild(local, keyChildName, isContainer);
/*     */         } 
/* 254 */         if (localChild == null) {
/* 255 */           TeamPlugin.log(4, NLS.bind("File {0} cannot be the parent of remote resource {1}", 
/* 256 */                 new Object[] { local.getFullPath(), keyChildName }), null); continue;
/*     */         } 
/* 258 */         mergedResources.put(localChild, remoteChild);
/*     */       } 
/*     */     } 
/*     */     
/* 262 */     return mergedResources;
/*     */   }
/*     */   
/*     */   private IResource getResourceChild(IResource parent, String childName, boolean isContainer) {
/* 266 */     if (parent.getType() == 1) {
/* 267 */       return null;
/*     */     }
/* 269 */     if (isContainer) {
/* 270 */       return (IResource)((IContainer)parent).getFolder((IPath)new Path(null, childName));
/*     */     }
/* 272 */     return (IResource)((IContainer)parent).getFile((IPath)new Path(null, childName));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\variants\AbstractResourceVariantTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */