package org.eclipse.team.core.history;

import org.eclipse.core.filesystem.IFileStore;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IFileHistoryProvider {
  public static final int NONE = 0;
  
  public static final int SINGLE_REVISION = 1;
  
  public static final int SINGLE_LINE_OF_DESCENT = 2;
  
  IFileHistory getFileHistoryFor(IResource paramIResource, int paramInt, IProgressMonitor paramIProgressMonitor);
  
  IFileRevision getWorkspaceFileRevision(IResource paramIResource);
  
  IFileHistory getFileHistoryFor(IFileStore paramIFileStore, int paramInt, IProgressMonitor paramIProgressMonitor);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\history\IFileHistoryProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */