/*    */ package org.eclipse.team.core.diff.provider;
/*    */ 
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.team.core.diff.IDiff;
/*    */ import org.eclipse.team.internal.core.mapping.SyncInfoToDiffConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Diff
/*    */   implements IDiff
/*    */ {
/*    */   public static final int KIND_MASK = 255;
/*    */   private final IPath path;
/*    */   private final int status;
/*    */   
/*    */   protected Diff(IPath path, int status) {
/* 52 */     this.path = path;
/* 53 */     this.status = status;
/*    */   }
/*    */ 
/*    */   
/*    */   public IPath getPath() {
/* 58 */     return this.path;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getKind() {
/* 63 */     return getStatus() & 0xFF;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final int getStatus() {
/* 75 */     return this.status;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toDiffString() {
/* 80 */     int kind = getKind();
/* 81 */     String label = SyncInfoToDiffConverter.diffKindToString(kind);
/* 82 */     return label;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 87 */     return getPath().hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 92 */     if (obj == this)
/* 93 */       return true; 
/* 94 */     if (obj instanceof Diff) {
/* 95 */       Diff other = (Diff)obj;
/* 96 */       return (other.getPath().equals(getPath()) && getStatus() == other.getStatus());
/*    */     } 
/* 98 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\diff\provider\Diff.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */