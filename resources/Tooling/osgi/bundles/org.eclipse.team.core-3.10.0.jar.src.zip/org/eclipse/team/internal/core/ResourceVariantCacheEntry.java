/*     */ package org.eclipse.team.internal.core;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Date;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.jobs.ILock;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.core.variants.CachedResourceVariant;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceVariantCacheEntry
/*     */ {
/*     */   public static final int UNINITIALIZED = 0;
/*     */   public static final int READY = 1;
/*     */   public static final int DISPOSED = 2;
/*     */   private String id;
/*     */   private String filePath;
/*     */   private ResourceVariantCache cache;
/*  46 */   private int state = 0;
/*     */   private long lastAccess;
/*     */   private CachedResourceVariant resourceVariant;
/*     */   private ILock lock;
/*     */   
/*     */   public ResourceVariantCacheEntry(ResourceVariantCache cache, ILock lock, String id, String filePath) {
/*  52 */     this.lock = lock;
/*  53 */     this.state = 0;
/*  54 */     this.cache = cache;
/*  55 */     this.id = id;
/*  56 */     this.filePath = filePath;
/*  57 */     registerHit();
/*     */   }
/*     */   
/*     */   public InputStream getContents() throws TeamException {
/*  61 */     if (this.state != 1) return null; 
/*  62 */     registerHit();
/*  63 */     File ioFile = getFile();
/*     */     
/*     */     try {
/*  66 */       if (ioFile.exists()) {
/*  67 */         return new FileInputStream(ioFile);
/*     */       }
/*  69 */     } catch (IOException e) {
/*     */       
/*  71 */       this.cache.purgeFromCache(this);
/*  72 */       throw e;
/*     */     }
/*  74 */     catch (IOException e) {
/*     */       
/*  76 */       throw new TeamException(NLS.bind(Messages.RemoteContentsCache_fileError, new String[] { ioFile.getAbsolutePath() }), e);
/*     */     } 
/*     */     
/*  79 */     return new ByteArrayInputStream(new byte[0]);
/*     */   }
/*     */   
/*     */   protected File getFile() {
/*  83 */     return new File(this.cache.getCachePath().toFile(), this.filePath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContents(InputStream stream, IProgressMonitor monitor) throws TeamException {
/*  96 */     beginOperation();
/*     */     try {
/*  98 */       internalSetContents(stream, monitor);
/*     */     } finally {
/* 100 */       endOperation();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void endOperation() {
/* 105 */     this.lock.release();
/*     */   }
/*     */   
/*     */   private void beginOperation() {
/* 109 */     this.lock.acquire();
/*     */   }
/*     */ 
/*     */   
/*     */   private void internalSetContents(InputStream stream, IProgressMonitor monitor) throws TeamException {
/* 114 */     if (this.state == 2) {
/* 115 */       throw new TeamException(NLS.bind(Messages.RemoteContentsCacheEntry_3, new String[] { this.cache.getName(), this.id }));
/*     */     }
/*     */     
/* 118 */     registerHit();
/* 119 */     File ioFile = getFile();
/*     */     
/*     */     try {
/*     */       OutputStream out;
/*     */       
/*     */       try {
/* 125 */         if (this.state == 0) {
/* 126 */           out = new BufferedOutputStream(new FileOutputStream(ioFile));
/*     */         }
/*     */         else {
/*     */           
/* 130 */           out = new ByteArrayOutputStream();
/*     */         } 
/* 132 */       } catch (FileNotFoundException e) {
/* 133 */         throw new TeamException(NLS.bind(Messages.RemoteContentsCache_fileError, new String[] { ioFile.getAbsolutePath() }), e);
/*     */       } 
/*     */ 
/*     */       
/*     */       try {
/*     */         try {
/* 139 */           byte[] buffer = new byte[1024];
/*     */           int read;
/* 141 */           while ((read = stream.read(buffer)) >= 0) {
/* 142 */             Policy.checkCanceled(monitor);
/* 143 */             out.write(buffer, 0, read);
/*     */           } 
/*     */         } finally {
/* 146 */           out.close();
/*     */         } 
/* 148 */       } catch (IOException e) {
/*     */         
/* 150 */         this.cache.purgeFromCache(this);
/* 151 */         throw e;
/*     */       } 
/*     */ 
/*     */       
/* 155 */       this.state = 1;
/* 156 */     } catch (IOException e) {
/* 157 */       OutputStream out; throw new TeamException(NLS.bind(Messages.RemoteContentsCache_fileError, new String[] { ioFile.getAbsolutePath() }), out);
/*     */     } finally {
/*     */       try {
/* 160 */         stream.close();
/* 161 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getState() {
/* 172 */     return this.state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getSize() {
/* 179 */     if (this.state != 1) return 0L; 
/* 180 */     File ioFile = getFile();
/* 181 */     if (ioFile.exists()) {
/* 182 */       return ioFile.length();
/*     */     }
/* 184 */     return 0L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getLastAccessTimeStamp() {
/* 191 */     return this.lastAccess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerHit() {
/* 200 */     this.lastAccess = (new Date()).getTime();
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 205 */     beginOperation();
/*     */     try {
/* 207 */       this.state = 2;
/* 208 */       this.cache.purgeFromCache(this);
/*     */     } finally {
/* 210 */       endOperation();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getId() {
/* 216 */     return this.id;
/*     */   }
/*     */   
/*     */   public CachedResourceVariant getResourceVariant() {
/* 220 */     return this.resourceVariant;
/*     */   }
/*     */   
/*     */   public void setResourceVariant(CachedResourceVariant resourceVariant) {
/* 224 */     this.resourceVariant = resourceVariant;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\ResourceVariantCacheEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */