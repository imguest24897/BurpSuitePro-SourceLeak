/*     */ package org.eclipse.team.core;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.team.core.subscribers.Subscriber;
/*     */ import org.eclipse.team.internal.core.DefaultProjectSetCapability;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RepositoryProviderType
/*     */   extends PlatformObject
/*     */ {
/*  70 */   private static Map<String, RepositoryProviderType> allProviderTypes = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String id;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String scheme;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RepositoryProviderType getProviderType(String id) {
/*  88 */     RepositoryProviderType type = allProviderTypes.get(id);
/*     */     
/*  90 */     if (type != null) {
/*  91 */       return type;
/*     */     }
/*     */ 
/*     */     
/*  95 */     return newProviderType(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RepositoryProviderType getTypeForScheme(String scheme) {
/* 109 */     for (RepositoryProviderType type : allProviderTypes.values()) {
/* 110 */       if (type.getFileSystemScheme() != null && type.getFileSystemScheme().equals(scheme))
/* 111 */         return type; 
/*     */     } 
/* 113 */     return findProviderForScheme(scheme);
/*     */   }
/*     */   
/*     */   private static RepositoryProviderType findProviderForScheme(String scheme) {
/* 117 */     IExtensionPoint extension = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.team.core", "repository");
/* 118 */     if (extension != null) {
/* 119 */       IExtension[] extensions = extension.getExtensions(); byte b; int i; IExtension[] arrayOfIExtension1;
/* 120 */       for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension ext = arrayOfIExtension1[b];
/* 121 */         IConfigurationElement[] configElements = ext.getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 122 */         for (j = (arrayOfIConfigurationElement1 = configElements).length, b1 = 0; b1 < j; ) { IConfigurationElement configElement = arrayOfIConfigurationElement1[b1];
/* 123 */           String extensionId = configElement.getAttribute("id");
/* 124 */           String typeScheme = configElement.getAttribute("fileSystemScheme");
/* 125 */           if (typeScheme != null && typeScheme.equals(scheme) && extensionId != null)
/* 126 */             return newProviderType(extensionId);  b1++; }
/*     */         
/*     */         b++; }
/*     */     
/*     */     } 
/* 131 */     return null;
/*     */   }
/*     */   
/*     */   private void setID(String id) {
/* 135 */     this.id = id;
/*     */   }
/*     */   
/*     */   private static RepositoryProviderType newProviderType(String id) {
/* 139 */     IExtensionPoint extension = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.team.core", "repository");
/* 140 */     if (extension != null) {
/* 141 */       IExtension[] extensions = extension.getExtensions(); byte b; int i; IExtension[] arrayOfIExtension1;
/* 142 */       for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension ext = arrayOfIExtension1[b];
/* 143 */         IConfigurationElement[] configElements = ext.getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 144 */         for (j = (arrayOfIConfigurationElement1 = configElements).length, b1 = 0; b1 < j; ) { IConfigurationElement configElement = arrayOfIConfigurationElement1[b1];
/* 145 */           String extensionId = configElement.getAttribute("id");
/* 146 */           if (extensionId != null && extensionId.equals(id)) {
/*     */             try {
/*     */               RepositoryProviderType providerType;
/*     */               
/* 150 */               if (configElement.getAttribute("typeClass") == null) {
/* 151 */                 providerType = new DefaultRepositoryProviderType();
/*     */               } else {
/* 153 */                 providerType = (RepositoryProviderType)configElement.createExecutableExtension("typeClass");
/*     */               } 
/* 155 */               providerType.setID(id);
/* 156 */               allProviderTypes.put(id, providerType);
/* 157 */               String scheme = configElement.getAttribute("fileSystemScheme");
/* 158 */               providerType.setFileSystemScheme(scheme);
/* 159 */               return providerType;
/* 160 */             } catch (CoreException e) {
/* 161 */               TeamPlugin.log(e);
/* 162 */             } catch (ClassCastException e) {
/* 163 */               String className = configElement.getAttribute("typeClass");
/* 164 */               TeamPlugin.log(4, "Class " + className + " registered for repository provider type id " + id + " is not a subclass of RepositoryProviderType", e);
/*     */             } 
/* 166 */             return null;
/*     */           }  b1++; }
/*     */          b++; }
/*     */     
/*     */     } 
/* 171 */     return null;
/*     */   }
/*     */   
/*     */   private void setFileSystemScheme(String scheme) {
/* 175 */     this.scheme = scheme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getID() {
/* 185 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProjectSetCapability getProjectSetCapability() {
/* 212 */     IProjectSetSerializer oldSerializer = Team.getProjectSetSerializer(getID());
/* 213 */     if (oldSerializer != null) {
/* 214 */       DefaultProjectSetCapability defaultProjectSetCapability = new DefaultProjectSetCapability();
/* 215 */       defaultProjectSetCapability.setSerializer(oldSerializer);
/* 216 */       return (ProjectSetCapability)defaultProjectSetCapability;
/*     */     } 
/* 218 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void metaFilesDetected(IProject project, IContainer[] containers) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Subscriber getSubscriber() {
/* 251 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getFileSystemScheme() {
/* 264 */     return this.scheme;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\RepositoryProviderType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */