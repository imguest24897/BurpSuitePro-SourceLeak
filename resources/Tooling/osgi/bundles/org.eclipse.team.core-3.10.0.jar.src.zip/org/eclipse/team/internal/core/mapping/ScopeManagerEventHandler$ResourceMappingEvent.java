/*    */ package org.eclipse.team.internal.core.mapping;
/*    */ 
/*    */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*    */ import org.eclipse.team.internal.core.BackgroundEventHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ResourceMappingEvent
/*    */   extends BackgroundEventHandler.Event
/*    */ {
/*    */   private final ResourceMapping[] mappings;
/*    */   
/*    */   public ResourceMappingEvent(ResourceMapping[] mappings) {
/* 39 */     super(10);
/* 40 */     this.mappings = mappings;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\ScopeManagerEventHandler$ResourceMappingEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */