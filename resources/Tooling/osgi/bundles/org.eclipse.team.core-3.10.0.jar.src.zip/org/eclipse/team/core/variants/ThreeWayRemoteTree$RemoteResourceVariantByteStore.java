/*    */ package org.eclipse.team.core.variants;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.team.core.TeamException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RemoteResourceVariantByteStore
/*    */   extends ResourceVariantByteStore
/*    */ {
/*    */   private ThreeWaySynchronizer synchronizer;
/*    */   
/*    */   public RemoteResourceVariantByteStore(ThreeWaySynchronizer synchronizer) {
/* 41 */     this.synchronizer = synchronizer;
/*    */   }
/*    */ 
/*    */   
/*    */   public void dispose() {}
/*    */ 
/*    */   
/*    */   public byte[] getBytes(IResource resource) throws TeamException {
/* 49 */     return getSynchronizer().getRemoteBytes(resource);
/*    */   }
/*    */   
/*    */   public boolean setBytes(IResource resource, byte[] bytes) throws TeamException {
/* 53 */     return getSynchronizer().setRemoteBytes(resource, bytes);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean flushBytes(IResource resource, int depth) throws TeamException {
/* 59 */     return false;
/*    */   }
/*    */   public boolean isVariantKnown(IResource resource) throws TeamException {
/* 62 */     return getSynchronizer().hasSyncBytes(resource);
/*    */   }
/*    */   
/*    */   public boolean deleteBytes(IResource resource) throws TeamException {
/* 66 */     return getSynchronizer().removeRemoteBytes(resource);
/*    */   }
/*    */   
/*    */   public IResource[] members(IResource resource) throws TeamException {
/* 70 */     return this.synchronizer.members(resource);
/*    */   }
/*    */   private ThreeWaySynchronizer getSynchronizer() {
/* 73 */     return this.synchronizer;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\variants\ThreeWayRemoteTree$RemoteResourceVariantByteStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */