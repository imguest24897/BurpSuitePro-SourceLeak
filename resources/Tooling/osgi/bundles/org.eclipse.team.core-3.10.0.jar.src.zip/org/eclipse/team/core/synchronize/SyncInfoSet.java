/*     */ package org.eclipse.team.core.synchronize;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.core.runtime.jobs.ILock;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.team.core.ITeamStatus;
/*     */ import org.eclipse.team.core.TeamStatus;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ import org.eclipse.team.internal.core.subscribers.SyncInfoStatistics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncInfoSet
/*     */ {
/*  56 */   private Map<IPath, SyncInfo> resources = Collections.synchronizedMap(new HashMap<>());
/*     */ 
/*     */   
/*  59 */   private SyncInfoStatistics statistics = new SyncInfoStatistics();
/*     */ 
/*     */   
/*  62 */   private Map<IResource, ITeamStatus> errors = new HashMap<>();
/*     */ 
/*     */   
/*     */   private boolean lockedForModification;
/*     */ 
/*     */   
/*     */   private ILock lock;
/*     */ 
/*     */   
/*     */   private Set<ISyncInfoSetChangeListener> listeners;
/*     */ 
/*     */   
/*     */   private SyncInfoSetChangeEvent changes;
/*     */ 
/*     */ 
/*     */   
/*     */   public SyncInfoSet(SyncInfo[] infos) {
/*  79 */     this(); byte b; int i;
/*     */     SyncInfo[] arrayOfSyncInfo;
/*  81 */     for (i = (arrayOfSyncInfo = infos).length, b = 0; b < i; ) { SyncInfo info = arrayOfSyncInfo[b];
/*  82 */       internalAdd(info);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized SyncInfo[] getSyncInfos() {
/*  92 */     return (SyncInfo[])this.resources.values().toArray((Object[])new SyncInfo[this.resources.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource[] getResources() {
/* 103 */     SyncInfo[] infos = getSyncInfos();
/* 104 */     List<IResource> resources = new ArrayList<>(); byte b; int i; SyncInfo[] arrayOfSyncInfo1;
/* 105 */     for (i = (arrayOfSyncInfo1 = infos).length, b = 0; b < i; ) { SyncInfo info = arrayOfSyncInfo1[b];
/* 106 */       resources.add(info.getLocal()); b++; }
/*     */     
/* 108 */     return resources.<IResource>toArray(new IResource[resources.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized SyncInfo getSyncInfo(IResource resource) {
/* 120 */     return this.resources.get(resource.getFullPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int size() {
/* 130 */     return this.resources.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long countFor(int kind, int mask) {
/* 150 */     return this.statistics.countFor(kind, mask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasConflicts() {
/* 161 */     return (countFor(12, 12) > 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean isEmpty() {
/* 170 */     return this.resources.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void internalAdd(SyncInfo info) {
/* 179 */     Assert.isTrue(!this.lockedForModification);
/* 180 */     IResource local = info.getLocal();
/* 181 */     IPath path = local.getFullPath();
/* 182 */     SyncInfo oldSyncInfo = this.resources.put(path, info);
/* 183 */     if (oldSyncInfo == null) {
/* 184 */       this.statistics.add(info);
/*     */     } else {
/* 186 */       this.statistics.remove(oldSyncInfo);
/* 187 */       this.statistics.add(info);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized SyncInfo internalRemove(IResource resource) {
/* 198 */     Assert.isTrue(!this.lockedForModification);
/* 199 */     IPath path = resource.getFullPath();
/* 200 */     SyncInfo info = this.resources.remove(path);
/* 201 */     if (info != null) {
/* 202 */       this.statistics.remove(info);
/*     */     }
/* 204 */     return info;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSyncSetChangedListener(ISyncInfoSetChangeListener listener) {
/* 214 */     synchronized (this.listeners) {
/* 215 */       this.listeners.add(listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeSyncSetChangedListener(ISyncInfoSetChangeListener listener) {
/* 226 */     synchronized (this.listeners) {
/* 227 */       this.listeners.remove(listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*     */     try {
/* 236 */       beginInput();
/* 237 */       this.errors.clear();
/* 238 */       this.resources.clear();
/* 239 */       this.statistics.clear();
/* 240 */       getChangeEvent().reset();
/*     */     } finally {
/* 242 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void run(IWorkspaceRunnable runnable, IProgressMonitor monitor) {
/* 262 */     monitor = Policy.monitorFor(monitor);
/* 263 */     monitor.beginTask(null, 100);
/*     */     try {
/* 265 */       beginInput();
/* 266 */       runnable.run(Policy.subMonitorFor(monitor, 80));
/* 267 */     } catch (CoreException e) {
/* 268 */       addError((ITeamStatus)new TeamStatus(4, "org.eclipse.team.core", 2, e.getMessage(), (Throwable)e, null));
/*     */     } finally {
/* 270 */       endInput(Policy.subMonitorFor(monitor, 20));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect(ISyncInfoSetChangeListener listener, IProgressMonitor monitor) {
/* 292 */     run(monitor1 -> {
/*     */           try {
/*     */             monitor1.beginTask(null, 100);
/*     */             addSyncSetChangedListener(paramISyncInfoSetChangeListener);
/*     */             paramISyncInfoSetChangeListener.syncInfoSetReset(this, Policy.subMonitorFor(monitor1, 95));
/*     */           } finally {
/*     */             monitor1.done();
/*     */           } 
/* 300 */         }monitor);
/*     */   }
/*     */   public SyncInfoSet() {
/* 303 */     this.lock = Job.getJobManager().newLock();
/*     */     
/* 305 */     this.listeners = Collections.synchronizedSet(new HashSet<>());
/*     */     
/* 307 */     this.changes = createEmptyChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(SyncInfo info) {
/*     */     try {
/* 326 */       beginInput();
/* 327 */       boolean alreadyExists = (getSyncInfo(info.getLocal()) != null);
/* 328 */       internalAdd(info);
/* 329 */       if (alreadyExists) {
/* 330 */         getChangeEvent().changed(info);
/*     */       } else {
/* 332 */         getChangeEvent().added(info);
/*     */       } 
/*     */     } finally {
/* 335 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAll(SyncInfoSet set) {
/*     */     try {
/* 346 */       beginInput();
/* 347 */       SyncInfo[] infos = set.getSyncInfos(); byte b; int i; SyncInfo[] arrayOfSyncInfo1;
/* 348 */       for (i = (arrayOfSyncInfo1 = infos).length, b = 0; b < i; ) { SyncInfo info = arrayOfSyncInfo1[b];
/* 349 */         add(info); b++; }
/*     */     
/*     */     } finally {
/* 352 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(IResource resource) {
/*     */     try {
/* 363 */       beginInput();
/* 364 */       internalRemove(resource);
/* 365 */       getChangeEvent().removed(resource);
/*     */     } finally {
/* 367 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAll(IResource[] resources) {
/*     */     try {
/* 378 */       beginInput(); byte b; int i; IResource[] arrayOfIResource;
/* 379 */       for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/* 380 */         remove(resource); b++; }
/*     */     
/*     */     } finally {
/* 383 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeConflictingNodes() {
/* 391 */     rejectNodes(new FastSyncInfoFilter.SyncInfoDirectionFilter(12));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeOutgoingNodes() {
/* 398 */     rejectNodes(new FastSyncInfoFilter.SyncInfoDirectionFilter(4));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeIncomingNodes() {
/* 405 */     rejectNodes(new FastSyncInfoFilter.SyncInfoDirectionFilter(8));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNodes(FastSyncInfoFilter filter) {
/* 415 */     SyncInfo[] infos = getSyncInfos(); byte b; int i; SyncInfo[] arrayOfSyncInfo1;
/* 416 */     for (i = (arrayOfSyncInfo1 = infos).length, b = 0; b < i; ) { SyncInfo info = arrayOfSyncInfo1[b];
/* 417 */       if (info != null && filter.select(info))
/* 418 */         return true; 
/*     */       b++; }
/*     */     
/* 421 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectNodes(FastSyncInfoFilter filter) {
/*     */     try {
/* 432 */       beginInput();
/* 433 */       SyncInfo[] infos = getSyncInfos(); byte b; int i; SyncInfo[] arrayOfSyncInfo1;
/* 434 */       for (i = (arrayOfSyncInfo1 = infos).length, b = 0; b < i; ) { SyncInfo info = arrayOfSyncInfo1[b];
/* 435 */         if (info == null || !filter.select(info))
/* 436 */           remove(info.getLocal()); 
/*     */         b++; }
/*     */     
/*     */     } finally {
/* 440 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rejectNodes(FastSyncInfoFilter filter) {
/*     */     try {
/* 452 */       beginInput();
/* 453 */       SyncInfo[] infos = getSyncInfos(); byte b; int i; SyncInfo[] arrayOfSyncInfo1;
/* 454 */       for (i = (arrayOfSyncInfo1 = infos).length, b = 0; b < i; ) { SyncInfo info = arrayOfSyncInfo1[b];
/* 455 */         if (info != null && filter.select(info))
/* 456 */           remove(info.getLocal()); 
/*     */         b++; }
/*     */     
/*     */     } finally {
/* 460 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SyncInfo[] getNodes(FastSyncInfoFilter filter) {
/* 471 */     List<SyncInfo> result = new ArrayList<>();
/* 472 */     SyncInfo[] infos = getSyncInfos(); byte b; int i; SyncInfo[] arrayOfSyncInfo1;
/* 473 */     for (i = (arrayOfSyncInfo1 = infos).length, b = 0; b < i; ) { SyncInfo info = arrayOfSyncInfo1[b];
/* 474 */       if (info != null && filter.select(info))
/* 475 */         result.add(info); 
/*     */       b++; }
/*     */     
/* 478 */     return result.<SyncInfo>toArray(new SyncInfo[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasIncomingChanges() {
/* 488 */     return (countFor(8, 12) > 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasOutgoingChanges() {
/* 498 */     return (countFor(4, 12) > 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beginInput() {
/* 526 */     this.lock.acquire();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endInput(IProgressMonitor monitor) {
/*     */     try {
/* 537 */       if (this.lock.getDepth() == 1)
/*     */       {
/*     */         
/* 540 */         fireChanges(Policy.monitorFor(monitor));
/*     */       }
/*     */     } finally {
/* 543 */       this.lock.release();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void resetChanges() {
/* 552 */     this.changes = createEmptyChangeEvent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SyncInfoSetChangeEvent createEmptyChangeEvent() {
/* 562 */     return new SyncInfoSetChangeEvent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void fireChanges(final IProgressMonitor monitor) {
/* 568 */     final SyncInfoSetChangeEvent event = getChangeEvent();
/* 569 */     resetChanges();
/*     */ 
/*     */ 
/*     */     
/* 573 */     if (event.isEmpty() && !event.isReset())
/* 574 */       return;  ISyncInfoSetChangeListener[] allListeners = getListeners();
/*     */     
/* 576 */     final ITeamStatus[] newErrors = event.getErrors();
/* 577 */     monitor.beginTask(null, 100 + ((newErrors.length > 0) ? 50 : 0) * allListeners.length); byte b; int i; ISyncInfoSetChangeListener[] arrayOfISyncInfoSetChangeListener1;
/* 578 */     for (i = (arrayOfISyncInfoSetChangeListener1 = allListeners).length, b = 0; b < i; ) { final ISyncInfoSetChangeListener listener = arrayOfISyncInfoSetChangeListener1[b];
/* 579 */       SafeRunner.run(new ISafeRunnable()
/*     */           {
/*     */             public void handleException(Throwable exception) {}
/*     */ 
/*     */ 
/*     */             
/*     */             public void run() throws Exception {
/*     */               try {
/* 587 */                 SyncInfoSet.this.lockedForModification = true;
/* 588 */                 if (event.isReset()) {
/* 589 */                   listener.syncInfoSetReset(SyncInfoSet.this, Policy.subMonitorFor(monitor, 100));
/*     */                 } else {
/* 591 */                   listener.syncInfoChanged(event, Policy.subMonitorFor(monitor, 100));
/*     */                 } 
/* 593 */                 if (newErrors.length > 0) {
/* 594 */                   listener.syncInfoSetErrors(SyncInfoSet.this, newErrors, Policy.subMonitorFor(monitor, 50));
/*     */                 }
/*     */               } finally {
/* 597 */                 SyncInfoSet.this.lockedForModification = false;
/*     */               }  }
/*     */           });
/*     */       b++; }
/*     */     
/* 602 */     monitor.done();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ISyncInfoSetChangeListener[] getListeners() {
/*     */     ISyncInfoSetChangeListener[] allListeners;
/* 611 */     synchronized (this.listeners) {
/* 612 */       allListeners = this.listeners.<ISyncInfoSetChangeListener>toArray(new ISyncInfoSetChangeListener[this.listeners.size()]);
/*     */     } 
/* 614 */     return allListeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SyncInfoSetChangeEvent getChangeEvent() {
/* 627 */     return this.changes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addError(ITeamStatus status) {
/*     */     try {
/* 646 */       beginInput();
/* 647 */       this.errors.put(status.getResource(), status);
/* 648 */       getChangeEvent().errorOccurred(status);
/*     */     } finally {
/* 650 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITeamStatus[] getErrors() {
/* 661 */     return (ITeamStatus[])this.errors.values().toArray((Object[])new ITeamStatus[this.errors.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator iterator() {
/* 672 */     return this.resources.values().iterator();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\synchronize\SyncInfoSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */