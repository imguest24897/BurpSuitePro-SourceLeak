/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.team.core.synchronize.SyncInfo;
/*     */ import org.eclipse.team.core.synchronize.SyncInfoFilter;
/*     */ import org.eclipse.team.core.synchronize.SyncInfoSet;
/*     */ import org.eclipse.team.core.synchronize.SyncInfoTree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WorkingSetFilteredSyncInfoCollector
/*     */ {
/*     */   private WorkingSetSyncSetInput workingSetInput;
/*     */   private SyncSetInputFromSyncSet filteredInput;
/*     */   private SubscriberEventHandler eventHandler;
/*     */   
/*     */   public WorkingSetFilteredSyncInfoCollector(SubscriberSyncInfoCollector collector, IResource[] roots) {
/*  51 */     this.eventHandler = collector.getEventHandler();
/*     */     
/*  53 */     this.workingSetInput = new WorkingSetSyncSetInput((SubscriberSyncInfoSet)collector.getSyncInfoSet(), getEventHandler());
/*  54 */     this.filteredInput = new SyncSetInputFromSyncSet(this.workingSetInput.getSyncSet(), getEventHandler());
/*  55 */     this.filteredInput.setFilter(new SyncInfoFilter()
/*     */         {
/*     */           public boolean select(SyncInfo info, IProgressMonitor monitor) {
/*  58 */             return true;
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SyncInfoTree getSyncInfoTree() {
/*  70 */     return this.filteredInput.getSyncSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() {
/*  80 */     this.workingSetInput.reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  89 */     this.workingSetInput.disconnect();
/*  90 */     if (this.filteredInput != null) {
/*  91 */       this.filteredInput.disconnect();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SubscriberEventHandler getEventHandler() {
/* 103 */     return this.eventHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilter(SyncInfoFilter filter) {
/* 112 */     this.filteredInput.setFilter(filter);
/* 113 */     this.filteredInput.reset();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SyncInfoSet getWorkingSetSyncInfoSet() {
/* 123 */     return (SyncInfoSet)this.workingSetInput.getSyncSet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(IWorkspaceRunnable runnable) {
/* 131 */     this.eventHandler.run(runnable, true);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\WorkingSetFilteredSyncInfoCollector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */