/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.team.core.synchronize.ISyncInfoTreeChangeEvent;
/*     */ import org.eclipse.team.core.synchronize.SyncInfoSet;
/*     */ import org.eclipse.team.core.synchronize.SyncInfoSetChangeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncInfoTreeChangeEvent
/*     */   extends SyncInfoSetChangeEvent
/*     */   implements ISyncInfoTreeChangeEvent
/*     */ {
/*  27 */   private Set<IResource> removedSubtrees = new HashSet<>();
/*  28 */   private Set<IResource> addedSubtrees = new HashSet<>();
/*     */   
/*     */   public SyncInfoTreeChangeEvent(SyncInfoSet set) {
/*  31 */     super(set);
/*     */   }
/*     */   
/*     */   public void removedSubtreeRoot(IResource root) {
/*  35 */     if (this.addedSubtrees.contains(root)) {
/*     */       
/*  37 */       this.addedSubtrees.remove(root);
/*  38 */     } else if (!isDescendantOfAddedRoot(root)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  45 */       for (Iterator<IResource> iter = this.removedSubtrees.iterator(); iter.hasNext(); ) {
/*  46 */         IResource element = iter.next();
/*     */         
/*  48 */         if (root.equals(element))
/*  49 */           return;  if (isParent(root, element)) {
/*     */           
/*  51 */           iter.remove(); continue;
/*  52 */         }  if (isParent(element, root)) {
/*     */           return;
/*     */         }
/*     */       } 
/*     */       
/*  57 */       this.removedSubtrees.add(root);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isParent(IResource root, IResource element) {
/*  62 */     return root.getFullPath().isPrefixOf(element.getFullPath());
/*     */   }
/*     */   
/*     */   public void addedSubtreeRoot(IResource parent) {
/*  66 */     if (this.removedSubtrees.contains(parent)) {
/*     */ 
/*     */ 
/*     */       
/*  70 */       reset();
/*     */     
/*     */     }
/*  73 */     else if (!isDescendantOfAddedRoot(parent)) {
/*  74 */       this.addedSubtrees.add(parent);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isDescendantOfAddedRoot(IResource resource) {
/*  80 */     for (IResource root : this.addedSubtrees) {
/*  81 */       if (isParent(root, resource))
/*     */       {
/*  83 */         return true;
/*     */       }
/*     */     } 
/*  86 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource[] getAddedSubtreeRoots() {
/*  91 */     return this.addedSubtrees.<IResource>toArray(new IResource[this.addedSubtrees.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource[] getRemovedSubtreeRoots() {
/*  96 */     return this.removedSubtrees.<IResource>toArray(new IResource[this.removedSubtrees.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 101 */     return (super.isEmpty() && this.removedSubtrees.isEmpty() && this.addedSubtrees.isEmpty());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SyncInfoTreeChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */