/*     */ package org.eclipse.team.internal.core;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.jobs.ILock;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.core.variants.CachedResourceVariant;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceVariantCache
/*     */ {
/*     */   private static final String CACHE_DIRECTORY = ".cache";
/*     */   private static final long CACHE_FILE_LIFESPAN = 3600000L;
/*  41 */   private static Map<String, ResourceVariantCache> caches = new HashMap<>();
/*     */   
/*     */   private String name;
/*     */   
/*     */   private Map<String, ResourceVariantCacheEntry> cacheEntries;
/*     */   
/*     */   private long lastCacheCleanup;
/*     */   private int cacheDirSize;
/*  49 */   private ILock lock = Job.getJobManager().newLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void enableCaching(String cacheId) {
/*  58 */     if (isCachingEnabled(cacheId))
/*  59 */       return;  ResourceVariantCache cache = new ResourceVariantCache(cacheId);
/*  60 */     cache.createCacheDirectory();
/*  61 */     caches.put(cacheId, cache);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isCachingEnabled(String cacheId) {
/*  73 */     return (getCache(cacheId) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void disableCache(String cacheId) {
/*  82 */     ResourceVariantCache cache = getCache(cacheId);
/*  83 */     if (cache == null) {
/*     */       return;
/*     */     }
/*     */     
/*  87 */     caches.remove(cacheId);
/*  88 */     cache.deleteCacheDirectory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized ResourceVariantCache getCache(String cacheId) {
/*  97 */     return caches.get(cacheId);
/*     */   }
/*     */   
/*     */   public static synchronized void shutdown() {
/* 101 */     String[] keys = (String[])caches.keySet().toArray((Object[])new String[caches.size()]); byte b; int i; String[] arrayOfString1;
/* 102 */     for (i = (arrayOfString1 = keys).length, b = 0; b < i; ) { String id = arrayOfString1[b];
/* 103 */       disableCache(id);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   private ResourceVariantCache(String name) {
/* 108 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasEntry(String id) {
/* 117 */     return (internalGetCacheEntry(id) != null);
/*     */   }
/*     */   
/*     */   protected IPath getCachePath() {
/* 121 */     return getStateLocation().append(".cache").append(this.name);
/*     */   }
/*     */   
/*     */   private IPath getStateLocation() {
/* 125 */     return TeamPlugin.getPlugin().getStateLocation();
/*     */   }
/*     */   
/*     */   private synchronized void clearOldCacheEntries() {
/* 129 */     long current = (new Date()).getTime();
/* 130 */     if (this.lastCacheCleanup != -1L && current - this.lastCacheCleanup < 3600000L)
/* 131 */       return;  List<ResourceVariantCacheEntry> stale = new ArrayList<>();
/* 132 */     for (ResourceVariantCacheEntry entry : this.cacheEntries.values()) {
/* 133 */       long lastHit = entry.getLastAccessTimeStamp();
/* 134 */       if (current - lastHit > 3600000L) {
/* 135 */         stale.add(entry);
/*     */       }
/*     */     } 
/* 138 */     for (ResourceVariantCacheEntry entry : stale) {
/* 139 */       entry.dispose();
/*     */     }
/*     */   }
/*     */   
/*     */   private synchronized void purgeFromCache(String id) {
/* 144 */     ResourceVariantCacheEntry entry = this.cacheEntries.get(id);
/* 145 */     File f = entry.getFile();
/*     */     try {
/* 147 */       deleteFile(f);
/* 148 */     } catch (TeamException teamException) {}
/*     */ 
/*     */ 
/*     */     
/* 152 */     this.cacheEntries.remove(id);
/*     */   }
/*     */   
/*     */   private synchronized void createCacheDirectory() {
/* 156 */     IPath cacheLocation = getCachePath();
/* 157 */     File file = cacheLocation.toFile();
/* 158 */     if (file.exists()) {
/*     */       try {
/* 160 */         deleteFile(file);
/* 161 */       } catch (TeamException e) {
/*     */         
/* 163 */         File[] fileList = file.listFiles();
/* 164 */         if (file.exists() && (!file.isDirectory() || (fileList != null && fileList.length != 0))) {
/* 165 */           TeamPlugin.log((CoreException)e);
/*     */         }
/*     */       } 
/*     */     }
/* 169 */     if (!file.exists() && !file.mkdirs()) {
/* 170 */       TeamPlugin.log((CoreException)new TeamException(NLS.bind(Messages.RemoteContentsCache_fileError, (Object[])new String[] { file.getAbsolutePath() })));
/*     */     }
/* 172 */     this.cacheEntries = new HashMap<>();
/* 173 */     this.lastCacheCleanup = -1L;
/* 174 */     this.cacheDirSize = 0;
/*     */   }
/*     */   
/*     */   private synchronized void deleteCacheDirectory() {
/* 178 */     this.cacheEntries = null;
/* 179 */     this.lastCacheCleanup = -1L;
/* 180 */     this.cacheDirSize = 0;
/* 181 */     IPath cacheLocation = getCachePath();
/* 182 */     File file = cacheLocation.toFile();
/* 183 */     if (file.exists()) {
/*     */       try {
/* 185 */         deleteFile(file);
/* 186 */       } catch (TeamException teamException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void deleteFile(File file) throws TeamException {
/* 194 */     if (file.isDirectory()) {
/* 195 */       File[] children = file.listFiles();
/* 196 */       if (children == null)
/* 197 */         throw new TeamException(NLS.bind(Messages.RemoteContentsCache_fileError, new String[] { file.getAbsolutePath() }));  byte b; int i;
/*     */       File[] arrayOfFile1;
/* 199 */       for (i = (arrayOfFile1 = children).length, b = 0; b < i; ) { File f = arrayOfFile1[b];
/* 200 */         deleteFile(f); b++; }
/*     */     
/*     */     } 
/* 203 */     if (!file.delete()) {
/* 204 */       throw new TeamException(NLS.bind(Messages.RemoteContentsCache_fileError, new String[] { file.getAbsolutePath() }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void purgeFromCache(ResourceVariantCacheEntry entry) {
/* 214 */     purgeFromCache(entry.getId());
/*     */   }
/*     */   
/*     */   private synchronized ResourceVariantCacheEntry internalGetCacheEntry(String id) {
/* 218 */     if (this.cacheEntries == null)
/*     */     {
/* 220 */       throw new IllegalStateException(NLS.bind(Messages.RemoteContentsCache_cacheDisposed, new String[] { this.name }));
/*     */     }
/* 222 */     ResourceVariantCacheEntry entry = this.cacheEntries.get(id);
/* 223 */     if (entry != null) {
/* 224 */       entry.registerHit();
/*     */     }
/* 226 */     return entry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceVariantCacheEntry getCacheEntry(String id) {
/* 234 */     return internalGetCacheEntry(id);
/*     */   }
/*     */   
/*     */   public synchronized ResourceVariantCacheEntry add(String id, CachedResourceVariant resource) {
/* 238 */     clearOldCacheEntries();
/* 239 */     String filePath = String.valueOf(this.cacheDirSize++);
/* 240 */     ResourceVariantCacheEntry entry = new ResourceVariantCacheEntry(this, this.lock, id, filePath);
/* 241 */     entry.setResourceVariant(resource);
/* 242 */     this.cacheEntries.put(id, entry);
/* 243 */     return entry;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 247 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceVariantCacheEntry[] getEntries() {
/* 254 */     return (ResourceVariantCacheEntry[])this.cacheEntries.values().toArray((Object[])new ResourceVariantCacheEntry[this.cacheEntries.size()]);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\ResourceVariantCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */