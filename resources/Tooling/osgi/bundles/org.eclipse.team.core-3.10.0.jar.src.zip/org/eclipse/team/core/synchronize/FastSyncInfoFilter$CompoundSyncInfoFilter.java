/*    */ package org.eclipse.team.core.synchronize;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CompoundSyncInfoFilter
/*    */   extends FastSyncInfoFilter
/*    */ {
/*    */   protected FastSyncInfoFilter[] filters;
/*    */   
/*    */   protected CompoundSyncInfoFilter(FastSyncInfoFilter[] filters) {
/* 59 */     this.filters = filters;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\synchronize\FastSyncInfoFilter$CompoundSyncInfoFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */