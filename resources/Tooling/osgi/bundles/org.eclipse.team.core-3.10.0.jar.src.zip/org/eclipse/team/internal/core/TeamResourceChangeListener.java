/*     */ package org.eclipse.team.internal.core;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceChangeEvent;
/*     */ import org.eclipse.core.resources.IResourceChangeListener;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.team.core.RepositoryProvider;
/*     */ import org.eclipse.team.core.RepositoryProviderType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TeamResourceChangeListener
/*     */   implements IResourceChangeListener
/*     */ {
/*  45 */   private static final Map<String, IPath[]> metaFilePaths = (Map)new HashMap<>(); static {
/*  46 */     String[] ids = RepositoryProvider.getAllProviderTypeIds(); byte b; int i; String[] arrayOfString1;
/*  47 */     for (i = (arrayOfString1 = ids).length, b = 0; b < i; ) { String id = arrayOfString1[b];
/*  48 */       IPath[] paths = TeamPlugin.getMetaFilePaths(id);
/*  49 */       if (paths != null) {
/*  50 */         metaFilePaths.put(id, paths);
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public void resourceChanged(IResourceChangeEvent event) {
/*  57 */     IResourceDelta[] projectDeltas = event.getDelta().getAffectedChildren(); byte b; int i; IResourceDelta[] arrayOfIResourceDelta1;
/*  58 */     for (i = (arrayOfIResourceDelta1 = projectDeltas).length, b = 0; b < i; ) { IResourceDelta delta = arrayOfIResourceDelta1[b];
/*  59 */       IResource resource = delta.getResource();
/*  60 */       IProject project = resource.getProject();
/*  61 */       if (!RepositoryProvider.isShared(project)) {
/*     */         
/*  63 */         handleUnsharedProjectChanges(project, delta);
/*     */ 
/*     */       
/*     */       }
/*  67 */       else if (delta.getKind() == 1 && (
/*  68 */         delta.getFlags() & 0x1000) != 0) {
/*     */         
/*  70 */         RepositoryProvider provider = RepositoryProvider.getProvider(project);
/*  71 */         if (provider != null)
/*     */         {
/*  73 */           if (!provider.getProject().equals(project))
/*     */           {
/*  75 */             provider.setProject(project); }  } 
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */   private void handleUnsharedProjectChanges(IProject project, IResourceDelta delta) {
/*  81 */     String repositoryId = null;
/*  82 */     Set<IContainer> metaFileContainers = new HashSet<>();
/*  83 */     Set<String> badIds = new HashSet<>();
/*  84 */     IFile[] files = getAddedFiles(delta); byte b; int i; IFile[] arrayOfIFile1;
/*  85 */     for (i = (arrayOfIFile1 = files).length, b = 0; b < i; ) { IFile file = arrayOfIFile1[b];
/*  86 */       String typeId = getMetaFileType(file);
/*  87 */       if (typeId != null) {
/*     */         
/*  89 */         if (repositoryId == null) {
/*  90 */           repositoryId = typeId;
/*  91 */         } else if (!repositoryId.equals(typeId) && !badIds.contains(typeId)) {
/*  92 */           TeamPlugin.log(2, "Meta files for two repository types (" + repositoryId + " and " + typeId + " was found in project " + project.getName() + ".", null);
/*  93 */           badIds.add(typeId);
/*     */         } 
/*  95 */         if (typeId.equals(repositoryId)) {
/*  96 */           IContainer container = getContainer(typeId, file);
/*  97 */           metaFileContainers.add(container);
/*     */         } 
/*     */       }  b++; }
/*     */     
/* 101 */     if (repositoryId != null) {
/* 102 */       RepositoryProviderType type = RepositoryProviderType.getProviderType(repositoryId);
/* 103 */       type.metaFilesDetected(project, metaFileContainers.<IContainer>toArray(new IContainer[metaFileContainers.size()]));
/*     */     } 
/*     */   }
/*     */   private IContainer getContainer(String typeId, IFile file) {
/*     */     IContainer iContainer;
/* 108 */     IPath[] paths = metaFilePaths.get(typeId);
/* 109 */     IPath foundPath = null;
/* 110 */     IPath projectRelativePath = file.getProjectRelativePath(); byte b; int i; IPath[] arrayOfIPath1;
/* 111 */     for (i = (arrayOfIPath1 = paths).length, b = 0; b < i; ) { IPath path = arrayOfIPath1[b];
/* 112 */       if (isSuffix(projectRelativePath, path))
/* 113 */         foundPath = path; 
/*     */       b++; }
/*     */     
/* 116 */     IFile iFile = file;
/* 117 */     if (foundPath != null) {
/* 118 */       for (int j = 0; j < foundPath.segmentCount(); j++) {
/* 119 */         iContainer = iFile.getParent();
/*     */       }
/*     */     }
/* 122 */     if (iContainer.getType() == 1) {
/* 123 */       return file.getParent();
/*     */     }
/* 125 */     return iContainer;
/*     */   }
/*     */   
/*     */   private String getMetaFileType(IFile file) {
/* 129 */     for (String id : metaFilePaths.keySet()) {
/* 130 */       IPath[] paths = metaFilePaths.get(id); byte b; int i; IPath[] arrayOfIPath1;
/* 131 */       for (i = (arrayOfIPath1 = paths).length, b = 0; b < i; ) { IPath path = arrayOfIPath1[b];
/* 132 */         if (isSuffix(file.getProjectRelativePath(), path))
/* 133 */           return id; 
/*     */         b++; }
/*     */     
/*     */     } 
/* 137 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isSuffix(IPath path, IPath suffix) {
/* 141 */     if (path.segmentCount() < suffix.segmentCount())
/* 142 */       return false; 
/* 143 */     for (int i = 0; i < suffix.segmentCount(); i++) {
/* 144 */       if (!suffix.segment(i).equals(path.segment(path.segmentCount() - suffix.segmentCount() + i))) {
/* 145 */         return false;
/*     */       }
/*     */     } 
/* 148 */     return true;
/*     */   }
/*     */   
/*     */   private IFile[] getAddedFiles(IResourceDelta delta) {
/* 152 */     List<IFile> result = new ArrayList<>();
/*     */     try {
/* 154 */       delta.accept(delta1 -> {
/*     */             if ((delta1.getKind() & 0x1) != 0 && delta1.getResource().getType() == 1) {
/*     */               paramList.add((IFile)delta1.getResource());
/*     */             }
/*     */             
/*     */             return true;
/*     */           });
/* 161 */     } catch (CoreException e) {
/* 162 */       TeamPlugin.log(4, "An error occurred while scanning for meta-file changes", (Throwable)e);
/*     */     } 
/* 164 */     return result.<IFile>toArray(new IFile[result.size()]);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\TeamResourceChangeListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */