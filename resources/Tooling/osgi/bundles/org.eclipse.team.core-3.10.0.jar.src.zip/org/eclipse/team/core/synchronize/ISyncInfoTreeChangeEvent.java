package org.eclipse.team.core.synchronize;

import org.eclipse.core.resources.IResource;

public interface ISyncInfoTreeChangeEvent extends ISyncInfoSetChangeEvent {
  IResource[] getAddedSubtreeRoots();
  
  IResource[] getRemovedSubtreeRoots();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\synchronize\ISyncInfoTreeChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */