package org.eclipse.team.core.variants;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.team.core.TeamException;

public interface IResourceVariantTree {
  IResource[] roots();
  
  IResource[] members(IResource paramIResource) throws TeamException;
  
  IResourceVariant getResourceVariant(IResource paramIResource) throws TeamException;
  
  boolean hasResourceVariant(IResource paramIResource) throws TeamException;
  
  IResource[] refresh(IResource[] paramArrayOfIResource, int paramInt, IProgressMonitor paramIProgressMonitor) throws TeamException;
  
  void flushVariants(IResource paramIResource, int paramInt) throws TeamException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\variants\IResourceVariantTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */