/*     */ package org.eclipse.team.internal.core.streams;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InterruptedIOException;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SizeConstrainedInputStream
/*     */   extends FilterInputStream
/*     */ {
/*     */   private boolean discardOnClose;
/*     */   private long bytesRemaining;
/*     */   
/*     */   public SizeConstrainedInputStream(InputStream in, long size, boolean discardOnClose) {
/*  45 */     super(in);
/*  46 */     this.bytesRemaining = size;
/*  47 */     this.discardOnClose = discardOnClose;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*     */     try {
/*  58 */       if (this.discardOnClose) {
/*  59 */         do {  } while (this.bytesRemaining != 0L && skip(this.bytesRemaining) != 0L);
/*     */       }
/*  61 */     } catch (OperationCanceledException operationCanceledException) {
/*     */ 
/*     */     
/*     */     } finally {
/*     */       
/*  66 */       this.bytesRemaining = 0L;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/*  77 */     int amount = this.in.available();
/*  78 */     if (amount > this.bytesRemaining) amount = (int)this.bytesRemaining; 
/*  79 */     return amount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/*  91 */     if (this.bytesRemaining == 0L) return -1; 
/*  92 */     int b = this.in.read();
/*  93 */     if (b != -1) this.bytesRemaining--; 
/*  94 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] buffer, int offset, int length) throws IOException {
/* 106 */     if (length > this.bytesRemaining) {
/* 107 */       if (this.bytesRemaining == 0L) return -1; 
/* 108 */       length = (int)this.bytesRemaining;
/*     */     } 
/*     */     try {
/* 111 */       int count = this.in.read(buffer, offset, length);
/* 112 */       if (count != -1) this.bytesRemaining -= count; 
/* 113 */       return count;
/* 114 */     } catch (InterruptedIOException e) {
/* 115 */       this.bytesRemaining -= e.bytesTransferred;
/* 116 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long skip(long amount) throws IOException {
/* 129 */     if (amount > this.bytesRemaining) amount = this.bytesRemaining; 
/*     */     try {
/* 131 */       long count = this.in.skip(amount);
/* 132 */       this.bytesRemaining -= count;
/* 133 */       return count;
/* 134 */     } catch (InterruptedIOException e) {
/* 135 */       this.bytesRemaining -= e.bytesTransferred;
/* 136 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 145 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\streams\SizeConstrainedInputStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */