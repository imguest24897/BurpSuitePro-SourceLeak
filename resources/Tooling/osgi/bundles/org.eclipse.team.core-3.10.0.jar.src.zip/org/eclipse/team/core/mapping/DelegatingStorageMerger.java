/*     */ package org.eclipse.team.core.mapping;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IStorage;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ import org.eclipse.core.runtime.content.IContentTypeManager;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.Team;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.StorageMergerRegistry;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ import org.eclipse.team.internal.core.mapping.IStreamMergerDelegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingStorageMerger
/*     */   implements IStorageMerger
/*     */ {
/*     */   private static DelegatingStorageMerger instance;
/*     */   
/*     */   public static IStorageMerger createTextMerger() {
/*  63 */     return Team.createMerger(Platform.getContentTypeManager().getContentType("org.eclipse.core.runtime.text"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStorageMerger getInstance() {
/*  80 */     if (instance == null)
/*  81 */       instance = new DelegatingStorageMerger(); 
/*  82 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus merge(OutputStream output, String outputEncoding, IStorage ancestor, IStorage target, IStorage other, IProgressMonitor monitor) throws CoreException {
/*  89 */     IStorageMerger merger = createDelegateMerger(target);
/*  90 */     if (merger == null)
/*  91 */       return (IStatus)new Status(2, "org.eclipse.team.core", 1, 
/*  92 */           Messages.DelegatingStorageMerger_0, null); 
/*  93 */     if (ancestor == null && !merger.canMergeWithoutAncestor()) {
/*  94 */       return (IStatus)new Status(2, "org.eclipse.team.core", 1, 
/*  95 */           NLS.bind(Messages.MergeContext_1, (Object[])new String[] { target.getFullPath().toString() }), null);
/*     */     }
/*  97 */     return merger.merge(output, outputEncoding, ancestor, target, other, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IStorageMerger createDelegateMerger(IStorage target) throws CoreException {
/* 110 */     IStorageMerger merger = null;
/* 111 */     CoreException exception = null;
/*     */     try {
/* 113 */       IContentType type = getContentType(target);
/* 114 */       if (type != null)
/* 115 */         merger = getMerger(type); 
/* 116 */     } catch (CoreException e) {
/* 117 */       exception = e;
/*     */     } 
/*     */ 
/*     */     
/* 121 */     if (merger == null) {
/* 122 */       merger = getMerger(target.getName());
/* 123 */       if (merger == null) {
/*     */         
/* 125 */         int type = getType(target);
/* 126 */         if (type == 1)
/* 127 */           merger = createTextMerger(); 
/* 128 */         if (merger == null)
/*     */         {
/* 130 */           merger = findAndWrapStreamMerger(target);
/*     */         }
/*     */       } 
/*     */     } 
/* 134 */     if (exception != null) {
/* 135 */       if (merger == null)
/*     */       {
/* 137 */         throw exception;
/*     */       }
/*     */       
/* 140 */       TeamPlugin.log(exception);
/*     */     } 
/*     */     
/* 143 */     return merger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getType(IStorage target) {
/* 156 */     return Team.getFileContentManager().getType(target);
/*     */   }
/*     */   
/*     */   private IStorageMerger findAndWrapStreamMerger(IStorage target) {
/* 160 */     IStreamMergerDelegate mergerDelegate = TeamPlugin.getPlugin().getMergerDelegate();
/* 161 */     if (mergerDelegate != null) {
/* 162 */       IStorageMerger merger = mergerDelegate.findMerger(target);
/* 163 */       return merger;
/*     */     } 
/* 165 */     return null;
/*     */   }
/*     */   
/*     */   private IStorageMerger getMerger(String name) {
/* 169 */     String extension = getExtension(name);
/* 170 */     if (extension != null)
/* 171 */       return StorageMergerRegistry.getInstance().createStreamMerger(extension); 
/* 172 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getExtension(String name) {
/* 182 */     int index = name.lastIndexOf('.');
/* 183 */     if (index == -1) {
/* 184 */       return null;
/*     */     }
/* 186 */     return name.substring(index + 1);
/*     */   }
/*     */   
/*     */   private IStorageMerger getMerger(IContentType type) {
/* 190 */     return Team.createMerger(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IContentType getContentType(IStorage target) throws CoreException {
/* 203 */     if (target instanceof IFile) {
/* 204 */       IFile file = (IFile)target;
/* 205 */       IContentDescription contentDescription = file.getContentDescription();
/* 206 */       if (contentDescription != null) {
/* 207 */         IContentType contentType = contentDescription.getContentType();
/* 208 */         return contentType;
/*     */       } 
/*     */     } else {
/* 211 */       IContentTypeManager manager = Platform.getContentTypeManager();
/*     */       try {
/* 213 */         IContentType type = manager.findContentTypeFor(target
/* 214 */             .getContents(), target.getName());
/* 215 */         return type;
/* 216 */       } catch (IOException e) {
/* 217 */         String name = target.getName();
/* 218 */         if (target.getFullPath() != null) {
/* 219 */           name = target.getFullPath().toString();
/*     */         }
/* 221 */         throw new TeamException(new Status(
/* 222 */               4, 
/* 223 */               "org.eclipse.team.core", 
/* 224 */               2, 
/* 225 */               NLS.bind(Messages.DelegatingStorageMerger_1, name), e));
/*     */       } 
/*     */     } 
/* 228 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canMergeWithoutAncestor() {
/* 233 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\DelegatingStorageMerger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */