/*    */ package org.eclipse.team.internal.core.subscribers;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CollectorChangeEvent
/*    */ {
/* 39 */   Set<ChangeSet> added = new HashSet<>();
/* 40 */   Set<ChangeSet> removed = new HashSet<>();
/* 41 */   Map<ChangeSet, IPath[]> changed = (Map)new HashMap<>();
/*    */   private final BatchingChangeSetManager collector;
/*    */   
/*    */   public CollectorChangeEvent(BatchingChangeSetManager collector) {
/* 45 */     this.collector = collector;
/*    */   }
/*    */   
/*    */   private void setAdded(ChangeSet set) {
/* 49 */     this.added.add(set);
/* 50 */     this.removed.remove(set);
/*    */   }
/*    */   
/*    */   private void setRemoved(ChangeSet set) {
/* 54 */     this.added.remove(set);
/* 55 */     this.removed.add(set);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private void changed(ChangeSet changeSet, IPath[] allAffectedResources) {
/* 61 */     if (this.added.contains(changeSet))
/*    */       return; 
/* 63 */     IPath[] paths = this.changed.get(changeSet);
/* 64 */     if (paths == null) {
/* 65 */       this.changed.put(changeSet, allAffectedResources);
/*    */     } else {
/* 67 */       Set<IPath> allPaths = new HashSet<>();
/* 68 */       Collections.addAll(allPaths, paths);
/* 69 */       Collections.addAll(allPaths, allAffectedResources);
/* 70 */       this.changed.put(changeSet, allPaths.<IPath>toArray(new IPath[allPaths.size()]));
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean isEmpty() {
/* 75 */     return (this.changed.isEmpty() && this.added.isEmpty() && this.removed.isEmpty());
/*    */   }
/*    */   
/*    */   public ChangeSet[] getAddedSets() {
/* 79 */     return this.added.<ChangeSet>toArray(new ChangeSet[this.added.size()]);
/*    */   }
/*    */   
/*    */   public ChangeSet[] getRemovedSets() {
/* 83 */     return this.removed.<ChangeSet>toArray(new ChangeSet[this.removed.size()]);
/*    */   }
/*    */   
/*    */   public ChangeSet[] getChangedSets() {
/* 87 */     return (ChangeSet[])this.changed.keySet().toArray((Object[])new ChangeSet[this.changed.size()]);
/*    */   }
/*    */   
/*    */   public IPath[] getChangesFor(ChangeSet set) {
/* 91 */     return this.changed.get(set);
/*    */   }
/*    */   
/*    */   public BatchingChangeSetManager getSource() {
/* 95 */     return this.collector;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\BatchingChangeSetManager$CollectorChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */