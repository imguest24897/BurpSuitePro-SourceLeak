/*     */ package org.eclipse.team.core.variants;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResourceVariantByteStore
/*     */ {
/*     */   public abstract void dispose();
/*     */   
/*     */   public abstract byte[] getBytes(IResource paramIResource) throws TeamException;
/*     */   
/*     */   public abstract boolean setBytes(IResource paramIResource, byte[] paramArrayOfbyte) throws TeamException;
/*     */   
/*     */   public abstract boolean flushBytes(IResource paramIResource, int paramInt) throws TeamException;
/*     */   
/*     */   public abstract boolean deleteBytes(IResource paramIResource) throws TeamException;
/*     */   
/*     */   public abstract IResource[] members(IResource paramIResource) throws TeamException;
/*     */   
/*     */   protected boolean equals(byte[] syncBytes1, byte[] syncBytes2) {
/* 113 */     if (syncBytes1 == null)
/* 114 */       return (syncBytes2 == null); 
/* 115 */     if (syncBytes2 == null) {
/* 116 */       return false;
/*     */     }
/* 118 */     if (syncBytes1.length != syncBytes2.length) return false; 
/* 119 */     for (int i = 0; i < syncBytes1.length; i++) {
/* 120 */       if (syncBytes1[i] != syncBytes2[i]) return false; 
/*     */     } 
/* 122 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(IResource root, IWorkspaceRunnable runnable, IProgressMonitor monitor) throws TeamException {
/*     */     try {
/* 138 */       runnable.run(monitor);
/* 139 */     } catch (CoreException e) {
/* 140 */       throw TeamException.asTeamException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\variants\ResourceVariantByteStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */