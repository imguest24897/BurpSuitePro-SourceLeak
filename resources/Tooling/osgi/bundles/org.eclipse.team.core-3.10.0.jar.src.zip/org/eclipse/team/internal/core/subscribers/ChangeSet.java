/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ChangeSet
/*     */ {
/*     */   private String name;
/*     */   
/*     */   protected ChangeSet() {}
/*     */   
/*     */   public ChangeSet(String name) {
/*  39 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract IResource[] getResources();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isEmpty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean contains(IResource paramIResource);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void remove(IResource paramIResource);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(IResource[] resources) {
/*     */     byte b;
/*     */     int i;
/*     */     IResource[] arrayOfIResource;
/*  72 */     for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/*  73 */       remove(resource);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void rootRemoved(IResource paramIResource, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getComment();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  97 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setName(String name) {
/* 107 */     this.name = name;
/*     */   }
/*     */   
/*     */   public abstract boolean containsChildren(IResource paramIResource, int paramInt);
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\ChangeSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */