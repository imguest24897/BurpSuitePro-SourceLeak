/*     */ package org.eclipse.team.core.synchronize;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IFolder;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ import org.eclipse.team.internal.core.subscribers.SyncInfoTreeChangeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncInfoTree
/*     */   extends SyncInfoSet
/*     */ {
/*  45 */   protected Map<IPath, Set<IResource>> parents = Collections.synchronizedMap(new HashMap<>());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SyncInfoTree() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SyncInfoTree(SyncInfo[] infos) {
/*  60 */     super(infos); byte b; int i; SyncInfo[] arrayOfSyncInfo;
/*  61 */     for (i = (arrayOfSyncInfo = infos).length, b = 0; b < i; ) { SyncInfo info = arrayOfSyncInfo[b];
/*  62 */       IResource local = info.getLocal();
/*  63 */       addToParents(local, local);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean hasMembers(IResource resource) {
/*  76 */     if (resource.getType() == 1) return false; 
/*  77 */     IContainer parent = (IContainer)resource;
/*  78 */     if (parent.getType() == 8) return !isEmpty(); 
/*  79 */     IPath path = parent.getFullPath();
/*  80 */     Set allDescendants = this.parents.get(path);
/*  81 */     return (allDescendants != null && !allDescendants.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized SyncInfo[] getSyncInfos(IResource resource, int depth) {
/* 105 */     if (depth == 0 || resource.getType() == 1) {
/* 106 */       SyncInfo info = getSyncInfo(resource);
/* 107 */       if (info == null) {
/* 108 */         return new SyncInfo[0];
/*     */       }
/* 110 */       return new SyncInfo[] { info };
/*     */     } 
/*     */     
/* 113 */     if (depth == 1) {
/* 114 */       List<SyncInfo> result = new ArrayList<>();
/* 115 */       SyncInfo info = getSyncInfo(resource);
/* 116 */       if (info != null) {
/* 117 */         result.add(info);
/*     */       }
/* 119 */       IResource[] members = members(resource); byte b; int i; IResource[] arrayOfIResource1;
/* 120 */       for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource member = arrayOfIResource1[b];
/* 121 */         info = getSyncInfo(member);
/* 122 */         if (info != null)
/* 123 */           result.add(info); 
/*     */         b++; }
/*     */       
/* 126 */       return result.<SyncInfo>toArray(new SyncInfo[result.size()]);
/*     */     } 
/*     */     
/* 129 */     if (resource.getType() == 8) {
/* 130 */       return getSyncInfos();
/*     */     }
/*     */     
/* 133 */     return internalGetDeepSyncInfo((IContainer)resource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized SyncInfo[] internalGetDeepSyncInfo(IContainer resource) {
/* 143 */     List<SyncInfo> infos = new ArrayList<>();
/* 144 */     IResource[] children = internalGetOutOfSyncDescendants(resource); byte b; int i; IResource[] arrayOfIResource1;
/* 145 */     for (i = (arrayOfIResource1 = children).length, b = 0; b < i; ) { IResource child = arrayOfIResource1[b];
/* 146 */       SyncInfo info = getSyncInfo(child);
/* 147 */       if (info != null) {
/* 148 */         infos.add(info);
/*     */       } else {
/* 150 */         TeamPlugin.log(1, String.valueOf(Messages.SyncInfoTree_0) + child.getFullPath(), null);
/*     */       }  b++; }
/*     */     
/* 153 */     return infos.<SyncInfo>toArray(new SyncInfo[infos.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   protected SyncInfoSetChangeEvent createEmptyChangeEvent() {
/* 158 */     return (SyncInfoSetChangeEvent)new SyncInfoTreeChangeEvent(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(SyncInfo info) {
/*     */     try {
/* 164 */       beginInput();
/* 165 */       boolean alreadyExists = (getSyncInfo(info.getLocal()) != null);
/* 166 */       super.add(info);
/* 167 */       if (!alreadyExists) {
/* 168 */         IResource local = info.getLocal();
/* 169 */         addToParents(local, local);
/*     */       } 
/*     */     } finally {
/* 172 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(IResource resource) {
/*     */     try {
/* 179 */       beginInput();
/* 180 */       super.remove(resource);
/* 181 */       removeFromParents(resource, resource);
/*     */     } finally {
/* 183 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*     */     try {
/* 191 */       beginInput();
/* 192 */       super.clear();
/* 193 */       synchronized (this) {
/* 194 */         this.parents.clear();
/*     */       } 
/*     */     } finally {
/* 197 */       endInput(null);
/*     */     } 
/*     */   }
/*     */   
/*     */   private synchronized boolean addToParents(IResource resource, IResource parent) {
/* 202 */     if (parent.getType() == 8) {
/* 203 */       return false;
/*     */     }
/*     */     
/* 206 */     boolean addedParent = false;
/* 207 */     if (parent.getType() == 1) {
/*     */       
/* 209 */       addedParent = true;
/*     */     } else {
/* 211 */       Set<IResource> children = this.parents.get(parent.getFullPath());
/* 212 */       if (children == null) {
/* 213 */         children = new HashSet<>();
/* 214 */         this.parents.put(parent.getFullPath(), children);
/*     */         
/* 216 */         addedParent = true;
/*     */       } 
/* 218 */       children.add(resource);
/*     */     } 
/*     */     
/* 221 */     if (!addToParents(resource, (IResource)parent.getParent()) && addedParent) {
/* 222 */       internalAddedSubtreeRoot(parent);
/*     */     }
/* 224 */     return addedParent;
/*     */   }
/*     */   
/*     */   private synchronized boolean removeFromParents(IResource resource, IResource parent) {
/* 228 */     if (parent.getType() == 8) {
/* 229 */       return false;
/*     */     }
/*     */     
/* 232 */     boolean removedParent = false;
/* 233 */     if (parent.getType() == 1) {
/*     */       
/* 235 */       removedParent = true;
/*     */     } else {
/* 237 */       Set<IResource> children = this.parents.get(parent.getFullPath());
/* 238 */       if (children != null) {
/* 239 */         children.remove(resource);
/* 240 */         if (children.isEmpty()) {
/* 241 */           this.parents.remove(parent.getFullPath());
/* 242 */           removedParent = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 247 */     if (!removeFromParents(resource, (IResource)parent.getParent()) && removedParent) {
/* 248 */       internalRemovedSubtreeRoot(parent);
/*     */     }
/* 250 */     return removedParent;
/*     */   }
/*     */   
/*     */   private void internalAddedSubtreeRoot(IResource parent) {
/* 254 */     ((SyncInfoTreeChangeEvent)getChangeEvent()).addedSubtreeRoot(parent);
/*     */   }
/*     */   
/*     */   private void internalRemovedSubtreeRoot(IResource parent) {
/* 258 */     ((SyncInfoTreeChangeEvent)getChangeEvent()).removedSubtreeRoot(parent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(IResource resource, int depth) {
/*     */     try {
/* 276 */       beginInput();
/* 277 */       if (getSyncInfo(resource) != null) {
/* 278 */         remove(resource);
/*     */       }
/* 280 */       if (depth == 0 || resource.getType() == 1)
/* 281 */         return;  if (depth == 1) {
/* 282 */         IResource[] members = members(resource); byte b; int i; IResource[] arrayOfIResource1;
/* 283 */         for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource member = arrayOfIResource1[b];
/* 284 */           if (getSyncInfo(member) != null)
/* 285 */             remove(member); 
/*     */           b++; }
/*     */       
/* 288 */       } else if (depth == 2) {
/* 289 */         IResource[] toRemove = internalGetOutOfSyncDescendants((IContainer)resource); byte b; int i; IResource[] arrayOfIResource1;
/* 290 */         for (i = (arrayOfIResource1 = toRemove).length, b = 0; b < i; ) { IResource t = arrayOfIResource1[b];
/* 291 */           remove(t); b++; }
/*     */       
/*     */       } 
/*     */     } finally {
/* 295 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized IResource[] internalGetOutOfSyncDescendants(IContainer resource) {
/* 305 */     Set<IResource> allChildren = this.parents.get(resource.getFullPath());
/* 306 */     if (allChildren == null) return new IResource[0]; 
/* 307 */     return allChildren.<IResource>toArray(new IResource[allChildren.size()]);
/*     */   }
/*     */   
/*     */   private synchronized IResource[] internalMembers(IWorkspaceRoot root) {
/* 311 */     Set<IPath> possibleChildren = this.parents.keySet();
/* 312 */     Set<IResource> children = new HashSet<>();
/* 313 */     for (IPath next : possibleChildren) {
/* 314 */       IResource element = root.findMember(next);
/* 315 */       if (element != null) {
/* 316 */         children.add(element.getProject());
/*     */       }
/*     */     } 
/* 319 */     return children.<IResource>toArray(new IResource[children.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized IResource[] members(IResource resource) {
/* 331 */     if (resource.getType() == 1) return new IResource[0]; 
/* 332 */     IContainer parent = (IContainer)resource;
/* 333 */     if (parent.getType() == 8) return internalMembers((IWorkspaceRoot)parent);
/*     */ 
/*     */     
/* 336 */     Set<IResource> children = new HashSet<>();
/* 337 */     IPath path = parent.getFullPath();
/* 338 */     Set possibleChildren = this.parents.get(path);
/* 339 */     if (possibleChildren != null) {
/* 340 */       for (Object next : possibleChildren) {
/* 341 */         IFolder iFolder; IResource element = (IResource)next;
/* 342 */         IPath childPath = element.getFullPath();
/* 343 */         IResource modelObject = null;
/* 344 */         if (childPath.segmentCount() == path.segmentCount() + 1) {
/* 345 */           modelObject = element;
/*     */         }
/* 347 */         else if (childPath.segmentCount() > path.segmentCount()) {
/* 348 */           IFolder iFolder1 = parent.getFolder((IPath)new Path(null, childPath.segment(path.segmentCount())));
/* 349 */           iFolder = iFolder1;
/*     */         } 
/* 351 */         if (iFolder != null) {
/* 352 */           children.add(iFolder);
/*     */         }
/*     */       } 
/*     */     }
/* 356 */     return children.<IResource>toArray(new IResource[children.size()]);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\synchronize\SyncInfoTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */