/*     */ package org.eclipse.team.core.synchronize;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.team.core.ITeamStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncInfoSetChangeEvent
/*     */   implements ISyncInfoSetChangeEvent
/*     */ {
/*     */   private SyncInfoSet set;
/*  38 */   private Map<IResource, SyncInfo> changedResources = new HashMap<>();
/*  39 */   private Set<IResource> removedResources = new HashSet<>();
/*  40 */   private Map<IResource, SyncInfo> addedResources = new HashMap<>();
/*     */   
/*     */   private boolean reset = false;
/*     */   
/*  44 */   private List<ITeamStatus> errors = new ArrayList<>();
/*     */ 
/*     */   
/*     */   public SyncInfoSetChangeEvent(SyncInfoSet set) {
/*  48 */     this.set = set;
/*     */   }
/*     */   
/*     */   public void added(SyncInfo info) {
/*  52 */     if (this.removedResources.contains(info.getLocal())) {
/*     */       
/*  54 */       this.removedResources.remove(info.getLocal());
/*  55 */       changed(info);
/*     */     } else {
/*  57 */       this.addedResources.put(info.getLocal(), info);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removed(IResource resource) {
/*  62 */     if (this.changedResources.containsKey(resource)) {
/*     */       
/*  64 */       this.changedResources.remove(resource);
/*  65 */     } else if (this.addedResources.containsKey(resource)) {
/*     */       
/*  67 */       this.addedResources.remove(resource);
/*     */       return;
/*     */     } 
/*  70 */     this.removedResources.add(resource);
/*     */   }
/*     */   
/*     */   public void changed(SyncInfo info) {
/*  74 */     IResource resource = info.getLocal();
/*  75 */     if (this.addedResources.containsKey(resource)) {
/*     */       
/*  77 */       this.addedResources.put(resource, info);
/*     */       return;
/*     */     } 
/*  80 */     this.changedResources.put(resource, info);
/*     */   }
/*     */ 
/*     */   
/*     */   public SyncInfo[] getAddedResources() {
/*  85 */     return (SyncInfo[])this.addedResources.values().toArray((Object[])new SyncInfo[this.addedResources.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public SyncInfo[] getChangedResources() {
/*  90 */     return (SyncInfo[])this.changedResources.values().toArray((Object[])new SyncInfo[this.changedResources.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource[] getRemovedResources() {
/*  95 */     return this.removedResources.<IResource>toArray(new IResource[this.removedResources.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public SyncInfoSet getSet() {
/* 100 */     return this.set;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 104 */     this.reset = true;
/*     */   }
/*     */   
/*     */   public boolean isReset() {
/* 108 */     return this.reset;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 112 */     return (this.changedResources.isEmpty() && this.removedResources.isEmpty() && this.addedResources.isEmpty() && this.errors.isEmpty());
/*     */   }
/*     */   
/*     */   public void errorOccurred(ITeamStatus status) {
/* 116 */     this.errors.add(status);
/*     */   }
/*     */   
/*     */   public ITeamStatus[] getErrors() {
/* 120 */     return this.errors.<ITeamStatus>toArray(new ITeamStatus[this.errors.size()]);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\synchronize\SyncInfoSetChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */