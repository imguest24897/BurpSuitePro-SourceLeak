/*     */ package org.eclipse.team.core.variants;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.eclipse.core.resources.IEncodedStorage;
/*     */ import org.eclipse.core.resources.IStorage;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.ResourceVariantCache;
/*     */ import org.eclipse.team.internal.core.ResourceVariantCacheEntry;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CachedResourceVariant
/*     */   extends PlatformObject
/*     */   implements IResourceVariant
/*     */ {
/*     */   private IStorage storage;
/*     */   
/*     */   class ResourceVariantStorage
/*     */     implements IEncodedStorage
/*     */   {
/*     */     public InputStream getContents() throws CoreException {
/*  76 */       if (!CachedResourceVariant.this.isContentsCached())
/*     */       {
/*     */         
/*  79 */         throw new TeamException(NLS.bind(Messages.CachedResourceVariant_0, new String[] { this.this$0.getCachePath() }));
/*     */       }
/*  81 */       return CachedResourceVariant.this.getCachedContents();
/*     */     }
/*     */     
/*     */     public IPath getFullPath() {
/*  85 */       return CachedResourceVariant.this.getDisplayPath();
/*     */     }
/*     */     
/*     */     public String getName() {
/*  89 */       return CachedResourceVariant.this.getName();
/*     */     }
/*     */     
/*     */     public boolean isReadOnly() {
/*  93 */       return true;
/*     */     }
/*     */     
/*     */     public <T> T getAdapter(Class<T> adapter) {
/*  97 */       return (T)CachedResourceVariant.this.getAdapter(adapter);
/*     */     }
/*     */     
/*     */     public String getCharset() throws CoreException {
/* 101 */       InputStream contents = getContents();
/*     */       try {
/* 103 */         String charSet = TeamPlugin.getCharset(getName(), contents);
/* 104 */         return charSet;
/* 105 */       } catch (IOException e) {
/* 106 */         throw new TeamException(new Status(4, "org.eclipse.team.core", 381, NLS.bind(Messages.CachedResourceVariant_1, new String[] { getFullPath().toString() }), e));
/*     */       } finally {
/*     */         try {
/* 109 */           contents.close();
/* 110 */         } catch (IOException iOException) {}
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStorage getStorage(IProgressMonitor monitor) throws TeamException {
/* 119 */     if (isContainer()) return null; 
/* 120 */     ensureContentsCached(monitor);
/* 121 */     if (this.storage == null) {
/* 122 */       this.storage = (IStorage)new ResourceVariantStorage();
/*     */     }
/* 124 */     return this.storage;
/*     */   }
/*     */ 
/*     */   
/*     */   private void ensureContentsCached(IProgressMonitor monitor) throws TeamException {
/* 129 */     if (!isContentsCached()) {
/* 130 */       fetchContents(monitor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void fetchContents(IProgressMonitor paramIProgressMonitor) throws TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setContents(InputStream stream, IProgressMonitor monitor) throws TeamException {
/* 155 */     Assert.isTrue(!isContainer());
/* 156 */     if (!isHandleCached()) cacheHandle(); 
/* 157 */     getCacheEntry().setContents(stream, monitor);
/*     */   }
/*     */   
/*     */   private ResourceVariantCacheEntry getCacheEntry() {
/* 161 */     return getCache().getCacheEntry(getCachePath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isContentsCached() {
/* 175 */     if (isContainer() || !isHandleCached()) {
/* 176 */       return false;
/*     */     }
/* 178 */     ResourceVariantCacheEntry entry = getCache().getCacheEntry(getCachePath());
/* 179 */     return (entry.getState() == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InputStream getCachedContents() throws TeamException {
/* 192 */     if (isContainer() || !isContentsCached()) return null; 
/* 193 */     return getCache().getCacheEntry(getCachePath()).getContents();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isHandleCached() {
/* 208 */     return getCache().hasEntry(getCachePath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String getCachePath();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getSize() {
/* 232 */     if (isContainer() || !isContentsCached()) return 0L; 
/* 233 */     ResourceVariantCacheEntry entry = getCacheEntry();
/* 234 */     if (entry == null || entry.getState() != 1) {
/* 235 */       return 0L;
/*     */     }
/* 237 */     return entry.getSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResourceVariantCache getCache() {
/* 245 */     ResourceVariantCache.enableCaching(getCacheId());
/* 246 */     return ResourceVariantCache.getCache(getCacheId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String getCacheId();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CachedResourceVariant getCachedHandle() {
/* 268 */     ResourceVariantCacheEntry entry = getCacheEntry();
/* 269 */     if (entry == null) return null; 
/* 270 */     return entry.getResourceVariant();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cacheHandle() {
/* 286 */     getCache().add(getCachePath(), this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getDisplayPath() {
/* 300 */     return (IPath)new Path(null, getCachePath());
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\variants\CachedResourceVariant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */