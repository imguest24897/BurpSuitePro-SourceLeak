package org.eclipse.team.core.mapping;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.mapping.ResourceMapping;
import org.eclipse.core.runtime.IStatus;

public interface IMergeStatus extends IStatus {
  public static final int CONFLICTS = 1;
  
  public static final int INTERNAL_ERROR = 2;
  
  ResourceMapping[] getConflictingMappings();
  
  IFile[] getConflictingFiles();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\IMergeStatus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */