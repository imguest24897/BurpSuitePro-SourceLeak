/*     */ package org.eclipse.team.core.synchronize;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.core.variants.IResourceVariant;
/*     */ import org.eclipse.team.core.variants.IResourceVariantComparator;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyncInfo
/*     */   implements IAdaptable
/*     */ {
/*     */   public static final int IN_SYNC = 0;
/*     */   public static final int ADDITION = 1;
/*     */   public static final int DELETION = 2;
/*     */   public static final int CHANGE = 3;
/*     */   public static final int CHANGE_MASK = 3;
/*     */   public static final int OUTGOING = 4;
/*     */   public static final int INCOMING = 8;
/*     */   public static final int CONFLICTING = 12;
/*     */   public static final int DIRECTION_MASK = 12;
/*     */   public static final int PSEUDO_CONFLICT = 16;
/*     */   public static final int AUTOMERGE_CONFLICT = 32;
/*     */   public static final int MANUAL_CONFLICT = 64;
/*     */   private IResource local;
/*     */   private IResourceVariant base;
/*     */   private IResourceVariant remote;
/*     */   private IResourceVariantComparator comparator;
/*     */   private int syncKind;
/*     */   
/*     */   public SyncInfo(IResource local, IResourceVariant base, IResourceVariant remote, IResourceVariantComparator comparator) {
/* 166 */     Assert.isNotNull(local);
/* 167 */     Assert.isNotNull(comparator);
/* 168 */     this.local = local;
/* 169 */     this.base = base;
/* 170 */     this.remote = remote;
/* 171 */     this.comparator = comparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource getLocal() {
/* 181 */     return this.local;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocalContentIdentifier() {
/* 191 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocalAuthor(IProgressMonitor monitor) {
/* 204 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResourceVariant getBase() {
/* 218 */     return this.base;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResourceVariant getRemote() {
/* 232 */     return this.remote;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResourceVariantComparator getComparator() {
/* 243 */     return this.comparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getKind() {
/* 252 */     return this.syncKind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInSync(int kind) {
/* 263 */     return (kind == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getDirection(int kind) {
/* 275 */     return kind & 0xC;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getChange(int kind) {
/* 288 */     return kind & 0x3;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 293 */     if (other == this) return true; 
/* 294 */     if (other instanceof SyncInfo) {
/* 295 */       return equalNodes(this, (SyncInfo)other);
/*     */     }
/* 297 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 302 */     return getLocal().hashCode();
/*     */   }
/*     */   
/*     */   private boolean equalNodes(SyncInfo node1, SyncInfo node2) {
/* 306 */     if (node1 == null || node2 == null) {
/* 307 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 311 */     IResource local1 = null;
/* 312 */     if (node1.getLocal() != null)
/* 313 */       local1 = node1.getLocal(); 
/* 314 */     IResource local2 = null;
/* 315 */     if (node2.getLocal() != null)
/* 316 */       local2 = node2.getLocal(); 
/* 317 */     if (!equalObjects(local1, local2)) return false;
/*     */ 
/*     */     
/* 320 */     IResourceVariant base1 = null;
/* 321 */     if (node1.getBase() != null)
/* 322 */       base1 = node1.getBase(); 
/* 323 */     IResourceVariant base2 = null;
/* 324 */     if (node2.getBase() != null)
/* 325 */       base2 = node2.getBase(); 
/* 326 */     if (!equalObjects(base1, base2)) return false;
/*     */ 
/*     */     
/* 329 */     IResourceVariant remote1 = null;
/* 330 */     if (node1.getRemote() != null)
/* 331 */       remote1 = node1.getRemote(); 
/* 332 */     IResourceVariant remote2 = null;
/* 333 */     if (node2.getRemote() != null)
/* 334 */       remote2 = node2.getRemote(); 
/* 335 */     if (!equalObjects(remote1, remote2)) return false;
/*     */     
/* 337 */     return true;
/*     */   }
/*     */   
/*     */   private boolean equalObjects(Object o1, Object o2) {
/* 341 */     if (o1 == null && o2 == null) return true; 
/* 342 */     if (o1 == null || o2 == null) return false; 
/* 343 */     return o1.equals(o2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getAdapter(Class<T> adapter) {
/* 349 */     if (adapter == IResource.class) {
/* 350 */       return (T)getLocal();
/*     */     }
/* 352 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 357 */     return String.valueOf(getLocal().getName()) + " " + kindToString(getKind());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String kindToString(int kind) {
/* 368 */     String label = "";
/* 369 */     if (kind == 0) {
/* 370 */       label = Messages.RemoteSyncElement_insync;
/*     */     } else {
/* 372 */       switch (kind & 0xC) { case 12:
/* 373 */           label = Messages.RemoteSyncElement_conflicting; break;
/* 374 */         case 4: label = Messages.RemoteSyncElement_outgoing; break;
/* 375 */         case 8: label = Messages.RemoteSyncElement_incoming; break; }
/*     */       
/* 377 */       switch (kind & 0x3) { case 3:
/* 378 */           label = NLS.bind(Messages.concatStrings, (Object[])new String[] { label, Messages.RemoteSyncElement_change }); break;
/* 379 */         case 1: label = NLS.bind(Messages.concatStrings, (Object[])new String[] { label, Messages.RemoteSyncElement_addition }); break;
/* 380 */         case 2: label = NLS.bind(Messages.concatStrings, (Object[])new String[] { label, Messages.RemoteSyncElement_deletion }); break; }
/*     */       
/* 382 */       if ((kind & 0x40) != 0) {
/* 383 */         label = NLS.bind(Messages.concatStrings, (Object[])new String[] { label, Messages.RemoteSyncElement_manual });
/*     */       }
/* 385 */       if ((kind & 0x20) != 0) {
/* 386 */         label = NLS.bind(Messages.concatStrings, (Object[])new String[] { label, Messages.RemoteSyncElement_auto });
/*     */       }
/*     */     } 
/* 389 */     return NLS.bind(Messages.RemoteSyncElement_delimit, (Object[])new String[] { label });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void init() throws TeamException {
/* 401 */     this.syncKind = calculateKind();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int calculateKind() throws TeamException {
/* 415 */     int description = 0;
/*     */     
/* 417 */     boolean localExists = this.local.exists();
/*     */     
/* 419 */     if (this.comparator.isThreeWay()) {
/* 420 */       if (this.base == null)
/* 421 */       { if (this.remote == null) {
/* 422 */           if (!localExists) {
/* 423 */             description = 0;
/*     */           } else {
/* 425 */             description = 5;
/*     */           }
/*     */         
/* 428 */         } else if (!localExists) {
/* 429 */           description = 9;
/*     */         } else {
/* 431 */           description = 13;
/* 432 */           if (this.comparator.compare(this.local, this.remote)) {
/* 433 */             description |= 0x10;
/*     */           }
/*     */         }
/*     */          }
/*     */       
/* 438 */       else if (!localExists)
/* 439 */       { if (this.remote == null) {
/* 440 */           description = 30;
/*     */         }
/* 442 */         else if (this.comparator.compare(this.base, this.remote)) {
/* 443 */           description = 6;
/*     */         } else {
/* 445 */           description = 15;
/*     */         }
/*     */          }
/* 448 */       else if (this.remote == null)
/* 449 */       { if (this.comparator.compare(this.local, this.base)) {
/* 450 */           description = 10;
/*     */         } else {
/* 452 */           description = 15;
/*     */         }  }
/* 454 */       else { boolean ay = this.comparator.compare(this.local, this.base);
/* 455 */         boolean am = this.comparator.compare(this.base, this.remote);
/* 456 */         if (!ay || !am)
/*     */         {
/* 458 */           if (ay && !am) {
/* 459 */             description = 11;
/* 460 */           } else if (!ay && am) {
/* 461 */             description = 7;
/*     */           }
/* 463 */           else if (!this.comparator.compare(this.local, this.remote)) {
/* 464 */             description = 15;
/*     */           }
/*     */         
/*     */         } }
/*     */ 
/*     */     
/*     */     }
/* 471 */     else if (this.remote == null) {
/* 472 */       if (!localExists) {
/* 473 */         Assert.isTrue(false);
/*     */       } else {
/*     */         
/* 476 */         description = 2;
/*     */       }
/*     */     
/* 479 */     } else if (!localExists) {
/* 480 */       description = 1;
/*     */     }
/* 482 */     else if (!this.comparator.compare(this.local, this.remote)) {
/* 483 */       description = 3;
/*     */     } 
/*     */ 
/*     */     
/* 487 */     return description;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\synchronize\SyncInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */