/*     */ package org.eclipse.team.internal.core.mapping;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.eclipse.compare.rangedifferencer.IRangeComparator;
/*     */ import org.eclipse.core.resources.IEncodedStorage;
/*     */ import org.eclipse.core.resources.IStorage;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class LineComparator
/*     */   implements IRangeComparator
/*     */ {
/*     */   private String[] fLines;
/*     */   
/*     */   private static class TrailingLineFeedDetector
/*     */     extends FilterInputStream
/*     */   {
/*     */     boolean trailingLF = false;
/*     */     
/*     */     protected TrailingLineFeedDetector(InputStream in) {
/*  46 */       super(in);
/*     */     }
/*     */ 
/*     */     
/*     */     public int read() throws IOException {
/*  51 */       int c = super.read();
/*  52 */       this.trailingLF = isLineFeed(c);
/*  53 */       return c;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int read(byte[] buffer, int off, int len) throws IOException {
/*  63 */       int length = super.read(buffer, off, len);
/*  64 */       if (length != -1) {
/*  65 */         int index = off + length - 1;
/*  66 */         if (index >= buffer.length)
/*  67 */           index = buffer.length - 1; 
/*  68 */         this.trailingLF = isLineFeed(buffer[index]);
/*     */       } 
/*  70 */       return length;
/*     */     }
/*     */     
/*     */     private boolean isLineFeed(int c) {
/*  74 */       return (c != -1 && c == 10);
/*     */     }
/*     */     
/*     */     public boolean hadTrailingLineFeed() {
/*  78 */       return this.trailingLF;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static LineComparator create(IStorage storage, String outputEncoding) throws CoreException, IOException {
/*  85 */     InputStream is = new BufferedInputStream(storage.getContents());
/*     */     try {
/*  87 */       String encoding = getEncoding(storage, outputEncoding);
/*  88 */       return new LineComparator(is, encoding);
/*     */     } finally {
/*     */       try {
/*  91 */         is.close();
/*  92 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getEncoding(IStorage storage, String outputEncoding) throws CoreException {
/* 100 */     if (storage instanceof IEncodedStorage) {
/* 101 */       IEncodedStorage es = (IEncodedStorage)storage;
/* 102 */       String charset = es.getCharset();
/* 103 */       if (charset != null)
/* 104 */         return charset; 
/*     */     } 
/* 106 */     return outputEncoding;
/*     */   }
/*     */ 
/*     */   
/*     */   public LineComparator(InputStream is, String encoding) throws IOException {
/* 111 */     TrailingLineFeedDetector trailingLineFeedDetector = new TrailingLineFeedDetector(
/* 112 */         is);
/* 113 */     Exception exception1 = null, exception2 = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getLine(int ix) {
/* 132 */     return this.fLines[ix];
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRangeCount() {
/* 137 */     return this.fLines.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean rangesEqual(int thisIndex, IRangeComparator other, int otherIndex) {
/* 143 */     String s1 = this.fLines[thisIndex];
/* 144 */     String s2 = ((LineComparator)other).fLines[otherIndex];
/* 145 */     return s1.equals(s2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean skipRangeComparison(int length, int maxLength, IRangeComparator other) {
/* 151 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\LineComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */