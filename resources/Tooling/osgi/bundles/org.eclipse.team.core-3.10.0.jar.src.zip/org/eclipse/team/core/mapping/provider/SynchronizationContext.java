/*     */ package org.eclipse.team.core.mapping.provider;
/*     */ 
/*     */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.team.core.ICache;
/*     */ import org.eclipse.team.core.mapping.IResourceDiffTree;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationContext;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScope;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScopeManager;
/*     */ import org.eclipse.team.internal.core.Cache;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SynchronizationContext
/*     */   extends PlatformObject
/*     */   implements ISynchronizationContext
/*     */ {
/*     */   private final int type;
/*     */   private final IResourceDiffTree diffTree;
/*     */   private Cache cache;
/*     */   private final ISynchronizationScopeManager manager;
/*     */   
/*     */   protected SynchronizationContext(ISynchronizationScopeManager manager, int type, IResourceDiffTree diffTree) {
/*  51 */     this.manager = manager;
/*  52 */     this.type = type;
/*  53 */     this.diffTree = diffTree;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISynchronizationScope getScope() {
/*  58 */     return getScopeManager().getScope();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISynchronizationScopeManager getScopeManager() {
/*  66 */     return this.manager;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getType() {
/*  71 */     return this.type;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  76 */     if (this.cache != null) {
/*  77 */       this.cache.dispose();
/*     */     }
/*  79 */     this.manager.dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized ICache getCache() {
/*  84 */     if (this.cache == null) {
/*  85 */       this.cache = new Cache();
/*     */     }
/*  87 */     return (ICache)this.cache;
/*     */   }
/*     */ 
/*     */   
/*     */   public IResourceDiffTree getDiffTree() {
/*  92 */     return this.diffTree;
/*     */   }
/*     */ 
/*     */   
/*     */   public void refresh(ResourceMapping[] mappings, IProgressMonitor monitor) throws CoreException {
/*  97 */     monitor.beginTask(null, 100);
/*  98 */     ISynchronizationScopeManager manager = getScopeManager();
/*  99 */     if (manager == null) {
/*     */       
/* 101 */       refresh(getScope().getTraversals(), 0, Policy.subMonitorFor(monitor, 50));
/*     */     } else {
/* 103 */       ResourceTraversal[] traversals = manager.refresh(mappings, Policy.subMonitorFor(monitor, 50));
/* 104 */       if (traversals.length > 0)
/* 105 */         refresh(traversals, 0, Policy.subMonitorFor(monitor, 50)); 
/*     */     } 
/* 107 */     monitor.done();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\provider\SynchronizationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */