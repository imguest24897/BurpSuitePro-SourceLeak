/*    */ package org.eclipse.team.internal.core.mapping;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Node
/*    */ {
/*    */   Object payload;
/*    */   Set<IPath> descendantsWithPayload;
/*    */   int flags;
/*    */   
/*    */   public boolean isEmpty() {
/* 36 */     return (this.payload == null && (this.descendantsWithPayload == null || this.descendantsWithPayload.isEmpty()));
/*    */   }
/*    */   public Object getPayload() {
/* 39 */     return this.payload;
/*    */   }
/*    */   public void setPayload(Object payload) {
/* 42 */     this.payload = payload;
/*    */   }
/*    */   public boolean hasDescendants() {
/* 45 */     return (this.descendantsWithPayload != null && !this.descendantsWithPayload.isEmpty());
/*    */   }
/*    */   public boolean hasFlag(int propertyBit) {
/* 48 */     return ((this.flags & propertyBit) != 0);
/*    */   }
/*    */   public void setProperty(int propertyBit, boolean value) {
/* 51 */     if (value) {
/* 52 */       this.flags |= propertyBit;
/*    */     } else {
/* 54 */       this.flags ^= propertyBit;
/*    */     } 
/*    */   } public boolean descendantHasFlag(int property) {
/* 57 */     if (hasDescendants()) {
/* 58 */       for (IPath path : this.descendantsWithPayload) {
/* 59 */         Node child = PathTree.this.getNode(path);
/* 60 */         if (child.hasFlag(property)) {
/* 61 */           return true;
/*    */         }
/*    */       } 
/*    */     }
/* 65 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\PathTree$Node.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */