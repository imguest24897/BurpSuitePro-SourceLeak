package org.eclipse.team.core.diff;

import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IDiffTree {
  public static final int P_BUSY_HINT = 1;
  
  public static final int P_HAS_DESCENDANT_CONFLICTS = 2;
  
  void addDiffChangeListener(IDiffChangeListener paramIDiffChangeListener);
  
  void removeDiffChangeListener(IDiffChangeListener paramIDiffChangeListener);
  
  void accept(IPath paramIPath, IDiffVisitor paramIDiffVisitor, int paramInt);
  
  IDiff getDiff(IPath paramIPath);
  
  IPath[] getChildren(IPath paramIPath);
  
  int size();
  
  boolean isEmpty();
  
  long countFor(int paramInt1, int paramInt2);
  
  void setBusy(IDiff[] paramArrayOfIDiff, IProgressMonitor paramIProgressMonitor);
  
  boolean getProperty(IPath paramIPath, int paramInt);
  
  void clearBusy(IProgressMonitor paramIProgressMonitor);
  
  boolean hasMatchingDiffs(IPath paramIPath, FastDiffFilter paramFastDiffFilter);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\diff\IDiffTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */