package org.eclipse.team.core.subscribers;

import org.eclipse.core.resources.IResource;

public interface ISubscriberChangeEvent {
  public static final int NO_CHANGE = 0;
  
  public static final int SYNC_CHANGED = 1;
  
  public static final int ROOT_ADDED = 2;
  
  public static final int ROOT_REMOVED = 4;
  
  int getFlags();
  
  IResource getResource();
  
  Subscriber getSubscriber();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\subscribers\ISubscriberChangeEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */