/*     */ package org.eclipse.team.core.synchronize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OrSyncInfoFilter
/*     */   extends FastSyncInfoFilter.CompoundSyncInfoFilter
/*     */ {
/*     */   public OrSyncInfoFilter(FastSyncInfoFilter[] filters) {
/* 114 */     super(filters); } public boolean select(SyncInfo info) {
/*     */     byte b;
/*     */     int i;
/*     */     FastSyncInfoFilter[] arrayOfFastSyncInfoFilter;
/* 118 */     for (i = (arrayOfFastSyncInfoFilter = this.filters).length, b = 0; b < i; ) { FastSyncInfoFilter filter = arrayOfFastSyncInfoFilter[b];
/* 119 */       if (filter.select(info))
/* 120 */         return true; 
/*     */       b++; }
/*     */     
/* 123 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\synchronize\FastSyncInfoFilter$OrSyncInfoFilter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */