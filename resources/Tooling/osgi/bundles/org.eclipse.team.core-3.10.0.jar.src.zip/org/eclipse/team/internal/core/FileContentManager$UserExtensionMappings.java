/*     */ package org.eclipse.team.internal.core;
/*     */ 
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UserExtensionMappings
/*     */   extends UserStringMappings
/*     */ {
/*     */   public UserExtensionMappings(String key) {
/*  69 */     super(key);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Map<String, Integer> loadMappingsFromPreferences() {
/*  74 */     Map<String, Integer> result = super.loadMappingsFromPreferences();
/*  75 */     if (loadMappingsFromOldWorkspace(result)) {
/*  76 */       TeamPlugin.getPlugin().savePluginPreferences();
/*     */     }
/*  78 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean loadMappingsFromOldWorkspace(Map<String, Integer> map) {
/*  92 */     String STATE_FILE = ".fileTypes";
/*  93 */     IPath pluginStateLocation = TeamPlugin.getPlugin().getStateLocation().append(STATE_FILE);
/*  94 */     File f = pluginStateLocation.toFile();
/*     */     
/*  96 */     if (!f.exists())
/*  97 */       return false; 
/*     */     try {
/*  99 */       Exception exception2, exception1 = null;
/*     */     }
/* 101 */     catch (IOException ex) {
/* 102 */       TeamPlugin.log(4, ex.getMessage(), ex);
/* 103 */       return false;
/*     */     } finally {
/* 105 */       f.delete();
/*     */     } 
/*     */     
/* 108 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Integer> readOldFormatExtensionMappings(DataInputStream input) throws IOException {
/* 118 */     Map<String, Integer> result = new TreeMap<>();
/* 119 */     int numberOfMappings = 0;
/*     */     try {
/* 121 */       numberOfMappings = input.readInt();
/* 122 */     } catch (EOFException eOFException) {
/*     */ 
/*     */       
/* 125 */       return Collections.emptyMap();
/*     */     } 
/* 127 */     for (int i = 0; i < numberOfMappings; i++) {
/* 128 */       String extension = input.readUTF();
/* 129 */       int type = input.readInt();
/* 130 */       result.put(extension, Integer.valueOf(type));
/*     */     } 
/* 132 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\FileContentManager$UserExtensionMappings.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */