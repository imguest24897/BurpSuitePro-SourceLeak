/*    */ package org.eclipse.team.internal.core.subscribers;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.team.core.synchronize.SyncInfoFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WorkingSetSyncSetInput
/*    */   extends SyncSetInputFromSyncSet
/*    */ {
/* 20 */   private SyncInfoWorkingSetFilter workingSetFilter = new SyncInfoWorkingSetFilter();
/*    */   
/*    */   public WorkingSetSyncSetInput(SubscriberSyncInfoSet set, SubscriberEventHandler handler) {
/* 23 */     super(set, handler);
/* 24 */     setFilter((SyncInfoFilter)this.workingSetFilter);
/*    */   }
/*    */   
/*    */   public void setWorkingSet(IResource[] resources) {
/* 28 */     this.workingSetFilter.setWorkingSet(resources);
/*    */   }
/*    */   
/*    */   public IResource[] getWorkingSet() {
/* 32 */     return this.workingSetFilter.getWorkingSet();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\WorkingSetSyncSetInput.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */