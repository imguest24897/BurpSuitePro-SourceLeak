/*     */ package org.eclipse.team.core;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TeamException
/*     */   extends CoreException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final int OK = 0;
/*     */   public static final int NOT_CHECKED_IN = -1;
/*     */   public static final int NOT_CHECKED_OUT = -2;
/*     */   public static final int NO_REMOTE_RESOURCE = -3;
/*     */   public static final int IO_FAILED = -4;
/*     */   public static final int NOT_AUTHORIZED = -5;
/*     */   public static final int UNABLE = -6;
/*     */   public static final int CONFLICT = -7;
/*     */   
/*     */   public TeamException(IStatus status) {
/*  67 */     super(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TeamException(String message, Throwable e) {
/*  79 */     super((IStatus)new Status(4, "org.eclipse.team.core", 0, message, e));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TeamException(String message) {
/*  88 */     this(message, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TeamException(CoreException e) {
/*  97 */     super((IStatus)asStatus(e));
/*     */   }
/*     */   
/*     */   private static Status asStatus(CoreException e) {
/* 101 */     IStatus status = e.getStatus();
/* 102 */     return new Status(status.getSeverity(), status.getPlugin(), status.getCode(), status.getMessage(), (Throwable)e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TeamException asTeamException(CoreException e) {
/* 112 */     if (e instanceof TeamException) {
/* 113 */       return (TeamException)e;
/*     */     }
/* 115 */     return new TeamException(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TeamException asTeamException(InvocationTargetException e) {
/* 125 */     Throwable target = e.getTargetException();
/* 126 */     if (target instanceof TeamException) {
/* 127 */       return (TeamException)target;
/*     */     }
/* 129 */     return new TeamException((IStatus)new Status(4, "org.eclipse.team.core", -6, (target.getMessage() != null) ? target.getMessage() : "", target));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\TeamException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */