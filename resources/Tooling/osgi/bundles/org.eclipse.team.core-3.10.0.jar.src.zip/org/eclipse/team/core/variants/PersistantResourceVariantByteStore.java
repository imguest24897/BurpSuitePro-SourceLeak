/*     */ package org.eclipse.team.core.variants;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ISynchronizer;
/*     */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.QualifiedName;
/*     */ import org.eclipse.core.runtime.jobs.ISchedulingRule;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PersistantResourceVariantByteStore
/*     */   extends ResourceVariantByteStore
/*     */ {
/*  40 */   private static final byte[] NO_REMOTE = new byte[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private QualifiedName syncName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PersistantResourceVariantByteStore(QualifiedName name) {
/*  52 */     this.syncName = name;
/*  53 */     getSynchronizer().add(this.syncName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  58 */     getSynchronizer().remove(getSyncName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QualifiedName getSyncName() {
/*  66 */     return this.syncName;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getBytes(IResource resource) throws TeamException {
/*  71 */     byte[] syncBytes = internalGetSyncBytes(resource);
/*  72 */     if (syncBytes != null && equals(syncBytes, NO_REMOTE))
/*     */     {
/*  74 */       return null;
/*     */     }
/*  76 */     return syncBytes;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean setBytes(IResource resource, byte[] bytes) throws TeamException {
/*  81 */     Assert.isNotNull(bytes);
/*  82 */     byte[] oldBytes = internalGetSyncBytes(resource);
/*  83 */     if (oldBytes != null && equals(oldBytes, bytes)) return false; 
/*     */     try {
/*  85 */       getSynchronizer().setSyncInfo(getSyncName(), resource, bytes);
/*  86 */       return true;
/*  87 */     } catch (CoreException e) {
/*  88 */       throw TeamException.asTeamException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean flushBytes(IResource resource, int depth) throws TeamException {
/*  94 */     if (resource.exists() || resource.isPhantom()) {
/*     */       try {
/*  96 */         if (depth != 0 || internalGetSyncBytes(resource) != null) {
/*  97 */           getSynchronizer().flushSyncInfo(getSyncName(), resource, depth);
/*  98 */           return true;
/*     */         } 
/* 100 */       } catch (CoreException e) {
/* 101 */         throw TeamException.asTeamException(e);
/*     */       } 
/*     */     }
/* 104 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVariantKnown(IResource resource) throws TeamException {
/* 123 */     return (internalGetSyncBytes(resource) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean deleteBytes(IResource resource) throws TeamException {
/* 135 */     return setBytes(resource, NO_REMOTE);
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource[] members(IResource resource) throws TeamException {
/* 140 */     if (resource.getType() == 1) {
/* 141 */       return new IResource[0];
/*     */     }
/*     */     
/*     */     try {
/* 145 */       IResource[] members = ((IContainer)resource).members(true);
/* 146 */       List<IResource> filteredMembers = new ArrayList<>(members.length); byte b; int i; IResource[] arrayOfIResource1;
/* 147 */       for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource member = arrayOfIResource1[b];
/* 148 */         if (getBytes(member) != null)
/* 149 */           filteredMembers.add(member); 
/*     */         b++; }
/*     */       
/* 152 */       return filteredMembers.<IResource>toArray(new IResource[filteredMembers.size()]);
/* 153 */     } catch (CoreException e) {
/* 154 */       throw TeamException.asTeamException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private ISynchronizer getSynchronizer() {
/* 159 */     return ResourcesPlugin.getWorkspace().getSynchronizer();
/*     */   }
/*     */   
/*     */   private byte[] internalGetSyncBytes(IResource resource) throws TeamException {
/*     */     try {
/* 164 */       return getSynchronizer().getSyncInfo(getSyncName(), resource);
/* 165 */     } catch (CoreException e) {
/* 166 */       throw TeamException.asTeamException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(IResource root, IWorkspaceRunnable runnable, IProgressMonitor monitor) throws TeamException {
/*     */     try {
/* 174 */       ResourcesPlugin.getWorkspace().run(runnable, (ISchedulingRule)root, 0, monitor);
/* 175 */     } catch (CoreException e) {
/* 176 */       throw TeamException.asTeamException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\variants\PersistantResourceVariantByteStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */