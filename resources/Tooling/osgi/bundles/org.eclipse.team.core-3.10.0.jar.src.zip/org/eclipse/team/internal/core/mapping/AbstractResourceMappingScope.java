/*    */ package org.eclipse.team.internal.core.mapping;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.eclipse.core.resources.mapping.ModelProvider;
/*    */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*    */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*    */ import org.eclipse.team.internal.core.subscribers.AbstractSynchronizationScope;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractResourceMappingScope
/*    */   extends AbstractSynchronizationScope
/*    */ {
/*    */   public ResourceMapping getMapping(Object modelObject) {
/* 31 */     ResourceMapping[] mappings = getMappings(); byte b; int i; ResourceMapping[] arrayOfResourceMapping1;
/* 32 */     for (i = (arrayOfResourceMapping1 = mappings).length, b = 0; b < i; ) { ResourceMapping mapping = arrayOfResourceMapping1[b];
/* 33 */       if (mapping.getModelObject().equals(modelObject))
/* 34 */         return mapping;  b++; }
/*    */     
/* 36 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public ResourceMapping[] getMappings(String id) {
/* 41 */     Set<ResourceMapping> result = new HashSet<>();
/* 42 */     ResourceMapping[] mappings = getMappings(); byte b; int i; ResourceMapping[] arrayOfResourceMapping1;
/* 43 */     for (i = (arrayOfResourceMapping1 = mappings).length, b = 0; b < i; ) { ResourceMapping mapping = arrayOfResourceMapping1[b];
/* 44 */       if (mapping.getModelProviderId().equals(id))
/* 45 */         result.add(mapping); 
/*    */       b++; }
/*    */     
/* 48 */     return result.<ResourceMapping>toArray(new ResourceMapping[result.size()]);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ResourceTraversal[] getTraversals(String modelProviderId) {
/* 54 */     ResourceMapping[] mappings = getMappings(modelProviderId);
/* 55 */     CompoundResourceTraversal traversal = new CompoundResourceTraversal(); byte b; int i; ResourceMapping[] arrayOfResourceMapping1;
/* 56 */     for (i = (arrayOfResourceMapping1 = mappings).length, b = 0; b < i; ) { ResourceMapping mapping = arrayOfResourceMapping1[b];
/* 57 */       ResourceTraversal[] traversals = getTraversals(mapping);
/* 58 */       if (traversals != null)
/* 59 */         traversal.addTraversals(traversals);  b++; }
/*    */     
/* 61 */     return traversal.asTraversals();
/*    */   }
/*    */ 
/*    */   
/*    */   public ModelProvider[] getModelProviders() {
/* 66 */     Set<ModelProvider> result = new HashSet<>();
/* 67 */     ResourceMapping[] mappings = getMappings(); byte b; int i; ResourceMapping[] arrayOfResourceMapping1;
/* 68 */     for (i = (arrayOfResourceMapping1 = mappings).length, b = 0; b < i; ) { ResourceMapping mapping = arrayOfResourceMapping1[b];
/* 69 */       ModelProvider modelProvider = mapping.getModelProvider();
/* 70 */       if (modelProvider != null)
/* 71 */         result.add(modelProvider);  b++; }
/*    */     
/* 73 */     return result.<ModelProvider>toArray(new ModelProvider[result.size()]);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\AbstractResourceMappingScope.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */