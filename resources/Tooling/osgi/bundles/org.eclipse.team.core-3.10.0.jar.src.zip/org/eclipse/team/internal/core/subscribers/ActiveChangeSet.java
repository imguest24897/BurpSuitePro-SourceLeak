/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IFolder;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.team.core.diff.IDiff;
/*     */ import org.eclipse.team.core.mapping.provider.ResourceDiffTree;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ import org.osgi.service.prefs.Preferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ActiveChangeSet
/*     */   extends DiffChangeSet
/*     */ {
/*     */   private static final String CTX_TITLE = "title";
/*     */   private static final String CTX_COMMENT = "comment";
/*     */   private static final String CTX_RESOURCES = "resources";
/*     */   private static final String CTX_USER_CREATED = "userCreated";
/*     */   private final ActiveChangeSetManager manager;
/*     */   private String comment;
/*     */   private boolean userCreated = true;
/*     */   
/*     */   public ActiveChangeSet(ActiveChangeSetManager manager, String title) {
/*  53 */     super(title);
/*  54 */     this.manager = manager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTitle() {
/*  64 */     return getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTitle(String title) {
/*  74 */     setName(title);
/*  75 */     getManager().fireNameChangedEvent(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getComment() {
/*  85 */     if (this.comment == null) {
/*  86 */       return getTitle();
/*     */     }
/*  88 */     return this.comment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setComment(String comment) {
/*  99 */     if (comment != null && comment.equals(getTitle())) {
/* 100 */       this.comment = null;
/*     */     } else {
/* 102 */       this.comment = comment;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isValidChange(IDiff diff) {
/* 111 */     return getManager().isModified(diff);
/*     */   }
/*     */   
/*     */   private void addResource(IResource resource) throws CoreException {
/* 115 */     IDiff diff = getManager().getDiff(resource);
/* 116 */     if (diff != null) {
/* 117 */       add(diff);
/*     */     }
/*     */   }
/*     */   
/*     */   private ActiveChangeSetManager getManager() {
/* 122 */     return this.manager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasComment() {
/* 130 */     return (this.comment != null);
/*     */   }
/*     */   
/*     */   public void save(Preferences prefs) {
/* 134 */     prefs.put("title", getTitle());
/* 135 */     if (this.comment != null) {
/* 136 */       prefs.put("comment", this.comment);
/*     */     }
/* 138 */     if (!isEmpty()) {
/* 139 */       StringBuilder buffer = new StringBuilder();
/* 140 */       IResource[] resources = getResources(); byte b; int i; IResource[] arrayOfIResource1;
/* 141 */       for (i = (arrayOfIResource1 = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource1[b];
/* 142 */         buffer.append(resource.getFullPath().toString());
/* 143 */         buffer.append('\n'); b++; }
/*     */       
/* 145 */       prefs.put("resources", buffer.toString());
/*     */     } 
/* 147 */     prefs.putBoolean("userCreated", isUserCreated());
/*     */   }
/*     */   
/*     */   public void init(Preferences prefs) {
/* 151 */     setName(prefs.get("title", ""));
/* 152 */     this.comment = prefs.get("comment", null);
/* 153 */     String resourcePaths = prefs.get("resources", null);
/* 154 */     if (resourcePaths != null) {
/* 155 */       ResourceDiffTree tree = internalGetDiffTree();
/*     */       try {
/* 157 */         tree.beginInput();
/* 158 */         IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
/* 159 */         StringTokenizer tokenizer = new StringTokenizer(resourcePaths, "\n");
/* 160 */         while (tokenizer.hasMoreTokens()) {
/* 161 */           String next = tokenizer.nextToken();
/* 162 */           if (next.trim().length() > 0) {
/* 163 */             IResource resource = getResource(root, next);
/*     */             
/*     */             try {
/* 166 */               if (resource != null && getManager().getDiff(resource) != null) {
/* 167 */                 addResource(resource);
/*     */               }
/* 169 */             } catch (CoreException e) {
/* 170 */               TeamPlugin.log(e);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } finally {
/* 175 */         tree.endInput(null);
/*     */       } 
/*     */     } 
/* 178 */     this.userCreated = prefs.getBoolean("userCreated", true);
/*     */   }
/*     */   private IResource getResource(IWorkspaceRoot root, String next) {
/*     */     IFile iFile;
/* 182 */     IResource resource = root.findMember(next);
/* 183 */     if (resource == null) {
/*     */       
/* 185 */       Path path = new Path(null, next);
/* 186 */       if (next.charAt(next.length() - 1) == '/') {
/* 187 */         if (path.segmentCount() == 1) {
/*     */           
/* 189 */           IProject iProject = root.getProject(path.lastSegment());
/*     */         } else {
/*     */           
/* 192 */           IFolder iFolder = root.getFolder((IPath)path);
/*     */         } 
/*     */       } else {
/*     */         
/* 196 */         iFile = root.getFile((IPath)path);
/*     */       } 
/*     */     } 
/* 199 */     return (IResource)iFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(IResource[] resources) throws CoreException {
/* 208 */     List<IDiff> toAdd = new ArrayList<>(); byte b; int i; IResource[] arrayOfIResource;
/* 209 */     for (i = (arrayOfIResource = resources).length, b = 0; b < i; ) { IResource resource = arrayOfIResource[b];
/* 210 */       IDiff diff = getManager().getDiff(resource);
/* 211 */       if (diff != null)
/* 212 */         toAdd.add(diff); 
/*     */       b++; }
/*     */     
/* 215 */     if (!toAdd.isEmpty()) {
/* 216 */       add(toAdd.<IDiff>toArray(new IDiff[toAdd.size()]));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserCreated(boolean userCreated) {
/* 225 */     this.userCreated = userCreated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUserCreated() {
/* 233 */     return this.userCreated;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\ActiveChangeSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */