package org.eclipse.team.core.mapping;

import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.team.core.diff.IDiff;

public interface IMergeContext extends ISynchronizationContext {
  int getMergeType();
  
  void markAsMerged(IDiff paramIDiff, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void markAsMerged(IDiff[] paramArrayOfIDiff, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  IStatus merge(IDiff paramIDiff, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  IStatus merge(IDiff[] paramArrayOfIDiff, boolean paramBoolean, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void reject(IDiff paramIDiff, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void reject(IDiff[] paramArrayOfIDiff, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  void run(IWorkspaceRunnable paramIWorkspaceRunnable, ISchedulingRule paramISchedulingRule, int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  ISchedulingRule getMergeRule(IDiff paramIDiff);
  
  ISchedulingRule getMergeRule(IDiff[] paramArrayOfIDiff);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\IMergeContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */