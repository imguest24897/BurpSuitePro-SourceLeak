package org.eclipse.team.core.mapping;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.mapping.ResourceTraversal;
import org.eclipse.team.core.diff.FastDiffFilter;
import org.eclipse.team.core.diff.IDiff;
import org.eclipse.team.core.diff.IDiffTree;
import org.eclipse.team.core.diff.IDiffVisitor;

public interface IResourceDiffTree extends IDiffTree {
  IDiff getDiff(IResource paramIResource);
  
  IResource getResource(IDiff paramIDiff);
  
  void accept(ResourceTraversal[] paramArrayOfResourceTraversal, IDiffVisitor paramIDiffVisitor);
  
  IDiff[] getDiffs(ResourceTraversal[] paramArrayOfResourceTraversal);
  
  IDiff[] getDiffs(IResource paramIResource, int paramInt);
  
  IResource[] members(IResource paramIResource);
  
  IResource[] getAffectedResources();
  
  boolean hasMatchingDiffs(ResourceTraversal[] paramArrayOfResourceTraversal, FastDiffFilter paramFastDiffFilter);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\mapping\IResourceDiffTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */