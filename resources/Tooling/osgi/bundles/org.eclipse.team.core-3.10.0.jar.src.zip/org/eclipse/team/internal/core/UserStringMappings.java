/*     */ package org.eclipse.team.internal.core;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.StringTokenizer;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.Preferences;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UserStringMappings
/*     */   implements Preferences.IPropertyChangeListener
/*     */ {
/*  31 */   public static final Integer BINARY = Integer.valueOf(2);
/*  32 */   public static final Integer TEXT = Integer.valueOf(1);
/*  33 */   public static final Integer UNKNOWN = Integer.valueOf(0);
/*     */   
/*     */   private static final String PREF_TEAM_SEPARATOR = "\n";
/*     */   
/*     */   private final Preferences fPreferences;
/*     */   
/*     */   private final String fKey;
/*     */   
/*     */   private Map<String, Integer> fMap;
/*     */   
/*     */   public UserStringMappings(String key) {
/*  44 */     this.fKey = key;
/*  45 */     this.fPreferences = TeamPlugin.getPlugin().getPluginPreferences();
/*  46 */     this.fPreferences.addPropertyChangeListener(this);
/*     */   }
/*     */   
/*     */   public Map<String, Integer> referenceMap() {
/*  50 */     if (this.fMap == null) {
/*  51 */       this.fMap = loadMappingsFromPreferences();
/*     */     }
/*  53 */     return this.fMap;
/*     */   }
/*     */   
/*     */   public void addStringMappings(String[] names, int[] types) {
/*  57 */     Assert.isTrue((names.length == types.length));
/*  58 */     Map<String, Integer> map = referenceMap();
/*     */     
/*  60 */     for (int i = 0; i < names.length; i++) {
/*  61 */       switch (types[i]) { case 2:
/*  62 */           map.put(names[i], BINARY); break;
/*  63 */         case 1: map.put(names[i], TEXT); break;
/*  64 */         case 0: map.put(names[i], UNKNOWN); break; }
/*     */     
/*     */     } 
/*  67 */     save();
/*     */   }
/*     */   
/*     */   public void setStringMappings(String[] names, int[] types) {
/*  71 */     Assert.isTrue((names.length == types.length));
/*  72 */     referenceMap().clear();
/*  73 */     addStringMappings(names, types);
/*     */   }
/*     */   
/*     */   public int getType(String string) {
/*  77 */     if (string == null)
/*  78 */       return 0; 
/*  79 */     Integer type = referenceMap().get(string);
/*  80 */     return (type != null) ? type.intValue() : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void propertyChange(Preferences.PropertyChangeEvent event) {
/*  85 */     if (event.getProperty().equals(this.fKey)) {
/*  86 */       this.fMap = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void save() {
/*  91 */     StringBuilder buffer = new StringBuilder();
/*  92 */     Iterator<String> e = this.fMap.keySet().iterator();
/*     */     
/*  94 */     while (e.hasNext()) {
/*  95 */       String filename = e.next();
/*  96 */       buffer.append(filename);
/*  97 */       buffer.append("\n");
/*  98 */       Integer type = this.fMap.get(filename);
/*  99 */       buffer.append(type);
/* 100 */       buffer.append("\n");
/*     */     } 
/* 102 */     TeamPlugin.getPlugin().getPluginPreferences().setValue(this.fKey, buffer.toString());
/*     */   }
/*     */   
/*     */   protected Map<String, Integer> loadMappingsFromPreferences() {
/* 106 */     Map<String, Integer> result = new HashMap<>();
/*     */     
/* 108 */     if (!this.fPreferences.contains(this.fKey)) {
/* 109 */       return result;
/*     */     }
/* 111 */     String prefTypes = this.fPreferences.getString(this.fKey);
/* 112 */     StringTokenizer tok = new StringTokenizer(prefTypes, "\n");
/*     */     try {
/* 114 */       while (tok.hasMoreElements()) {
/* 115 */         String name = tok.nextToken();
/* 116 */         String mode = tok.nextToken();
/* 117 */         result.put(name, Integer.valueOf(mode));
/*     */       } 
/* 119 */     } catch (NoSuchElementException noSuchElementException) {}
/*     */     
/* 121 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\UserStringMappings.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */