/*     */ package org.eclipse.team.internal.core.streams;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InterruptedIOException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ProgressMonitorInputStream
/*     */   extends FilterInputStream
/*     */ {
/*     */   private IProgressMonitor monitor;
/*     */   private int updateIncrement;
/*     */   private long bytesTotal;
/*  35 */   private long bytesRead = 0L;
/*  36 */   private long lastUpdate = -1L;
/*  37 */   private long nextUpdate = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProgressMonitorInputStream(InputStream in, long bytesTotal, int updateIncrement, IProgressMonitor monitor) {
/*  47 */     super(in);
/*  48 */     this.bytesTotal = bytesTotal;
/*  49 */     this.updateIncrement = updateIncrement;
/*  50 */     this.monitor = monitor;
/*  51 */     update(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void updateMonitor(long paramLong1, long paramLong2, IProgressMonitor paramIProgressMonitor);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*     */     try {
/*  64 */       this.in.close();
/*     */     } finally {
/*  66 */       update(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/*  79 */     int b = this.in.read();
/*  80 */     if (b != -1) {
/*  81 */       this.bytesRead++;
/*  82 */       update(false);
/*     */     } 
/*  84 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] buffer, int offset, int length) throws IOException {
/*     */     try {
/*  97 */       int count = this.in.read(buffer, offset, length);
/*  98 */       if (count != -1) {
/*  99 */         this.bytesRead += count;
/* 100 */         update(false);
/*     */       } 
/* 102 */       return count;
/* 103 */     } catch (InterruptedIOException e) {
/* 104 */       this.bytesRead += e.bytesTransferred;
/* 105 */       update(false);
/* 106 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long skip(long amount) throws IOException {
/*     */     try {
/* 120 */       long count = this.in.skip(amount);
/* 121 */       this.bytesRead += count;
/* 122 */       update(false);
/* 123 */       return count;
/* 124 */     } catch (InterruptedIOException e) {
/* 125 */       this.bytesRead += e.bytesTransferred;
/* 126 */       update(false);
/* 127 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean markSupported() {
/* 136 */     return false;
/*     */   }
/*     */   
/*     */   private void update(boolean now) {
/* 140 */     if (this.bytesRead >= this.nextUpdate || now) {
/* 141 */       this.nextUpdate = this.bytesRead - this.bytesRead % this.updateIncrement;
/* 142 */       if (this.nextUpdate != this.lastUpdate) updateMonitor(this.nextUpdate, this.bytesTotal, this.monitor); 
/* 143 */       this.lastUpdate = this.nextUpdate;
/* 144 */       this.nextUpdate += this.updateIncrement;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\streams\ProgressMonitorInputStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */