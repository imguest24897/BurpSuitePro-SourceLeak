/*    */ package org.eclipse.team.internal.core.subscribers;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.team.core.synchronize.ISyncInfoSetChangeListener;
/*    */ import org.eclipse.team.core.synchronize.SyncInfoSet;
/*    */ import org.eclipse.team.core.synchronize.SyncInfoTree;
/*    */ import org.eclipse.team.internal.core.Policy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SubscriberSyncInfoSet
/*    */   extends SyncInfoTree
/*    */ {
/*    */   protected SubscriberEventHandler handler;
/*    */   
/*    */   public SubscriberSyncInfoSet(SubscriberEventHandler handler) {
/* 40 */     this.handler = handler;
/*    */   }
/*    */ 
/*    */   
/*    */   public void connect(ISyncInfoSetChangeListener listener, IProgressMonitor monitor) {
/* 45 */     if (this.handler == null) {
/* 46 */       super.connect(listener, monitor);
/*    */     } else {
/* 48 */       connect(listener);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void connect(ISyncInfoSetChangeListener listener) {
/* 59 */     if (this.handler == null)
/*    */     {
/* 61 */       throw new UnsupportedOperationException();
/*    */     }
/* 63 */     this.handler.run(monitor -> {
/*    */           try {
/*    */             beginInput();
/*    */             monitor.beginTask(null, 100);
/*    */             removeSyncSetChangedListener(paramISyncInfoSetChangeListener);
/*    */             addSyncSetChangedListener(paramISyncInfoSetChangeListener);
/*    */             paramISyncInfoSetChangeListener.syncInfoSetReset((SyncInfoSet)this, Policy.subMonitorFor(monitor, 95));
/*    */           } finally {
/*    */             endInput(Policy.subMonitorFor(monitor, 5));
/*    */             monitor.done();
/*    */           } 
/* 74 */         }true);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SubscriberSyncInfoSet.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */