/*     */ package org.eclipse.team.core.variants;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ResourceVariantTree
/*     */   extends AbstractResourceVariantTree
/*     */ {
/*     */   private ResourceVariantByteStore store;
/*     */   
/*     */   protected ResourceVariantTree(ResourceVariantByteStore store) {
/*  39 */     this.store = store;
/*     */   }
/*     */ 
/*     */   
/*     */   public IResource[] members(IResource resource) throws TeamException {
/*  44 */     return getByteStore().members(resource);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasResourceVariant(IResource resource) throws TeamException {
/*  49 */     return (getByteStore().getBytes(resource) != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void flushVariants(IResource resource, int depth) throws TeamException {
/*  54 */     getByteStore().flushBytes(resource, depth);
/*     */   }
/*     */   
/*     */   protected boolean setVariant(IResource local, IResourceVariant remote) throws TeamException {
/*     */     boolean changed;
/*  59 */     ResourceVariantByteStore cache = getByteStore();
/*  60 */     byte[] newRemoteBytes = getBytes(local, remote);
/*     */     
/*  62 */     if (newRemoteBytes == null) {
/*  63 */       changed = cache.deleteBytes(local);
/*     */     } else {
/*  65 */       changed = cache.setBytes(local, newRemoteBytes);
/*     */     } 
/*  67 */     return changed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceVariantByteStore getByteStore() {
/*  80 */     return this.store;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] getBytes(IResource local, IResourceVariant remote) throws TeamException {
/*  92 */     if (remote == null) return null; 
/*  93 */     return remote.asBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IResource[] collectChanges(IResource local, IResourceVariant remote, int depth, IProgressMonitor monitor) throws TeamException {
/* 100 */     IResource[][] resources = new IResource[1][];
/* 101 */     getByteStore().run(local, monitor1 -> paramArrayOfIResource[0] = access$0(this, paramIResource, paramIResourceVariant, paramInt, monitor1), monitor);
/* 102 */     return resources[0];
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\variants\ResourceVariantTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */