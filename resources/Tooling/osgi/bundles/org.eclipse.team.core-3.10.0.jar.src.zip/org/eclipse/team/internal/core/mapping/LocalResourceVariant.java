/*    */ package org.eclipse.team.internal.core.mapping;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.IStorage;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.team.core.TeamException;
/*    */ import org.eclipse.team.core.variants.IResourceVariant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalResourceVariant
/*    */   implements IResourceVariant
/*    */ {
/*    */   private final IResource resource;
/*    */   
/*    */   public LocalResourceVariant(IResource resource) {
/* 29 */     this.resource = resource;
/*    */   }
/*    */ 
/*    */   
/*    */   public byte[] asBytes() {
/* 34 */     return getContentIdentifier().getBytes();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getContentIdentifier() {
/* 39 */     return (new Date(this.resource.getLocalTimeStamp())).toString();
/*    */   }
/*    */ 
/*    */   
/*    */   public IStorage getStorage(IProgressMonitor monitor) throws TeamException {
/* 44 */     if (this.resource.getType() == 1) {
/* 45 */       return (IStorage)this.resource;
/*    */     }
/* 47 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isContainer() {
/* 52 */     return (this.resource.getType() != 1);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 57 */     return this.resource.getName();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\LocalResourceVariant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */