/*    */ package org.eclipse.team.core;
/*    */ 
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.ResourcesPlugin;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TeamStatus
/*    */   extends Status
/*    */   implements ITeamStatus
/*    */ {
/*    */   private IResource resource;
/*    */   
/*    */   public TeamStatus(int severity, String pluginId, int code, String message, Throwable exception, IResource resource) {
/* 43 */     super(severity, pluginId, code, message, exception);
/* 44 */     if (resource == null) {
/* 45 */       this.resource = (IResource)ResourcesPlugin.getWorkspace().getRoot();
/*    */     } else {
/* 47 */       this.resource = resource;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IResource getResource() {
/* 57 */     return this.resource;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\TeamStatus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */