/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.core.diff.IDiff;
/*     */ import org.eclipse.team.core.mapping.provider.ResourceDiffTree;
/*     */ import org.eclipse.team.internal.core.BackgroundEventHandler;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EventHandler
/*     */   extends BackgroundEventHandler
/*     */ {
/*  57 */   private List<BackgroundEventHandler.Event> dispatchEvents = new ArrayList<>();
/*     */   
/*     */   protected EventHandler(String jobName, String errorTitle) {
/*  60 */     super(jobName, errorTitle);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processEvent(BackgroundEventHandler.Event event, IProgressMonitor monitor) throws CoreException {
/*  66 */     if (isShutdown())
/*  67 */       throw new OperationCanceledException(); 
/*  68 */     this.dispatchEvents.add(event);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean doDispatchEvents(IProgressMonitor monitor) throws TeamException {
/*  73 */     if (this.dispatchEvents.isEmpty()) {
/*  74 */       return false;
/*     */     }
/*  76 */     if (isShutdown())
/*  77 */       throw new OperationCanceledException(); 
/*  78 */     ResourceDiffTree[] locked = null;
/*     */     try {
/*  80 */       locked = beginDispath();
/*  81 */       for (BackgroundEventHandler.Event event : this.dispatchEvents) {
/*  82 */         switch (event.getType()) {
/*     */           case 1:
/*  84 */             handleRemove(event.getResource());
/*     */             break;
/*     */           case 2:
/*  87 */             handleChange(event.getResource(), ((BackgroundEventHandler.ResourceEvent)event).getDepth());
/*     */             break;
/*     */         } 
/*     */ 
/*     */         
/*  92 */         if (isShutdown())
/*  93 */           throw new OperationCanceledException(); 
/*     */       } 
/*  95 */     } catch (CoreException e) {
/*  96 */       throw TeamException.asTeamException(e);
/*     */     } finally {
/*     */       try {
/*  99 */         endDispatch(locked, monitor);
/*     */       } finally {
/* 101 */         this.dispatchEvents.clear();
/*     */       } 
/*     */     } 
/* 104 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResourceDiffTree[] beginDispath() {
/* 113 */     ChangeSet[] sets = SubscriberChangeSetManager.this.getSets();
/* 114 */     List<ResourceDiffTree> lockedSets = new ArrayList<>(); try {
/*     */       byte b; int i; ChangeSet[] arrayOfChangeSet;
/* 116 */       for (i = (arrayOfChangeSet = sets).length, b = 0; b < i; ) { ChangeSet s = arrayOfChangeSet[b];
/* 117 */         ActiveChangeSet set = (ActiveChangeSet)s;
/* 118 */         ResourceDiffTree tree = set.internalGetDiffTree();
/* 119 */         lockedSets.add(tree);
/* 120 */         tree.beginInput(); b++; }
/*     */       
/* 122 */       return lockedSets.<ResourceDiffTree>toArray(new ResourceDiffTree[lockedSets.size()]);
/* 123 */     } catch (RuntimeException e) {
/*     */       try {
/* 125 */         for (ResourceDiffTree tree : lockedSets) {
/*     */           try {
/* 127 */             tree.endInput(null);
/* 128 */           } catch (Throwable throwable) {}
/*     */         }
/*     */       
/*     */       }
/* 132 */       catch (Throwable throwable) {}
/*     */ 
/*     */       
/* 135 */       throw e;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void endDispatch(ResourceDiffTree[] locked, IProgressMonitor monitor) {
/* 140 */     if (locked == null) {
/*     */       return;
/*     */     }
/*     */     
/* 144 */     monitor.beginTask(null, 100 * locked.length); byte b; int i; ResourceDiffTree[] arrayOfResourceDiffTree;
/* 145 */     for (i = (arrayOfResourceDiffTree = locked).length, b = 0; b < i; ) { ResourceDiffTree tree = arrayOfResourceDiffTree[b];
/*     */       try {
/* 147 */         tree.endInput(Policy.subMonitorFor(monitor, 100));
/* 148 */       } catch (RuntimeException e) {
/*     */ 
/*     */         
/* 151 */         TeamPlugin.log(4, Messages.SubscriberChangeSetCollector_0, e);
/* 152 */         throw e;
/*     */       }  b++; }
/*     */     
/* 155 */     monitor.done();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void queueEvent(BackgroundEventHandler.Event event, boolean front) {
/* 161 */     super.queueEvent(event, front);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleRemove(IResource resource) {
/* 168 */     ChangeSet[] sets = SubscriberChangeSetManager.this.getSets(); byte b; int i; ChangeSet[] arrayOfChangeSet1;
/* 169 */     for (i = (arrayOfChangeSet1 = sets).length, b = 0; b < i; ) { ChangeSet set = arrayOfChangeSet1[b];
/*     */ 
/*     */       
/* 172 */       if (!set.isEmpty()) {
/* 173 */         set.rootRemoved(resource, 2);
/* 174 */         if (set.isEmpty()) {
/* 175 */           SubscriberChangeSetManager.this.remove(set);
/*     */         }
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleChange(IResource resource, int depth) throws CoreException {
/* 185 */     IDiff diff = SubscriberChangeSetManager.this.getDiff(resource);
/* 186 */     if (SubscriberChangeSetManager.this.isModified(diff)) {
/* 187 */       ActiveChangeSet[] containingSets = getContainingSets(resource);
/* 188 */       if (containingSets.length == 0) {
/*     */ 
/*     */         
/* 191 */         if (SubscriberChangeSetManager.this.getDefaultSet() != null)
/* 192 */           SubscriberChangeSetManager.this.getDefaultSet().add(diff); 
/*     */       } else {
/*     */         byte b; int i; ActiveChangeSet[] arrayOfActiveChangeSet;
/* 195 */         for (i = (arrayOfActiveChangeSet = containingSets).length, b = 0; b < i; ) { ActiveChangeSet set = arrayOfActiveChangeSet[b];
/*     */           
/* 197 */           set.add(diff); b++; }
/*     */       
/*     */       } 
/*     */     } else {
/* 201 */       removeFromAllSets(resource);
/*     */     } 
/* 203 */     if (depth != 0) {
/* 204 */       IResource[] members = SubscriberChangeSetManager.this.getSubscriber().members(resource); byte b; int i; IResource[] arrayOfIResource1;
/* 205 */       for (i = (arrayOfIResource1 = members).length, b = 0; b < i; ) { IResource member = arrayOfIResource1[b];
/* 206 */         handleChange(member, (depth == 1) ? 0 : 2);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */   private void removeFromAllSets(IResource resource) {
/* 212 */     List<ChangeSet> toRemove = new ArrayList<>();
/* 213 */     ChangeSet[] sets = SubscriberChangeSetManager.this.getSets(); byte b; int i; ChangeSet[] arrayOfChangeSet1;
/* 214 */     for (i = (arrayOfChangeSet1 = sets).length, b = 0; b < i; ) { ChangeSet set = arrayOfChangeSet1[b];
/* 215 */       if (set.contains(resource)) {
/* 216 */         set.remove(resource);
/* 217 */         if (set.isEmpty())
/* 218 */           toRemove.add(set); 
/*     */       } 
/*     */       b++; }
/*     */     
/* 222 */     for (ChangeSet element : toRemove) {
/* 223 */       ActiveChangeSet set = (ActiveChangeSet)element;
/* 224 */       SubscriberChangeSetManager.this.remove(set);
/*     */     } 
/*     */   }
/*     */   
/*     */   private ActiveChangeSet[] getContainingSets(IResource resource) {
/* 229 */     Set<ActiveChangeSet> result = new HashSet<>();
/* 230 */     ChangeSet[] sets = SubscriberChangeSetManager.this.getSets(); byte b; int i; ChangeSet[] arrayOfChangeSet1;
/* 231 */     for (i = (arrayOfChangeSet1 = sets).length, b = 0; b < i; ) { ChangeSet set = arrayOfChangeSet1[b];
/* 232 */       if (set.contains(resource))
/* 233 */         result.add((ActiveChangeSet)set); 
/*     */       b++; }
/*     */     
/* 236 */     return result.<ActiveChangeSet>toArray(new ActiveChangeSet[result.size()]);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SubscriberChangeSetManager$EventHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */