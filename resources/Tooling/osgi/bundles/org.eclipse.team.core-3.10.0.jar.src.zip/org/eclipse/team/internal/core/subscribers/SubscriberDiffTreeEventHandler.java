/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.eclipse.team.core.TeamStatus;
/*     */ import org.eclipse.team.core.diff.DiffFilter;
/*     */ import org.eclipse.team.core.diff.IDiff;
/*     */ import org.eclipse.team.core.mapping.IResourceDiffTree;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScopeManager;
/*     */ import org.eclipse.team.core.mapping.provider.ResourceDiffTree;
/*     */ import org.eclipse.team.core.subscribers.Subscriber;
/*     */ import org.eclipse.team.internal.core.BackgroundEventHandler;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SubscriberDiffTreeEventHandler
/*     */   extends SubscriberEventHandler
/*     */ {
/*     */   private static final int STATE_NEW = 0;
/*     */   public static final int STATE_STARTED = 1;
/*     */   private static final int STATE_OK_TO_INITIALIZE = 3;
/*     */   private static final int STATE_COLLECTING_CHANGES = 5;
/*     */   private static final int STATE_SHUTDOWN = 8;
/*     */   private static final int EXCEPTION_NONE = 0;
/*     */   private static final int EXCEPTION_CANCELED = 1;
/*     */   private static final int EXCEPTION_ERROR = 2;
/*     */   private ResourceDiffTree tree;
/*     */   private SubscriberDiffCollector collector;
/*     */   private ISynchronizationScopeManager manager;
/*     */   private Object family;
/*     */   private DiffFilter filter;
/*  58 */   private int state = 0;
/*  59 */   private int exceptionState = 0;
/*     */ 
/*     */   
/*     */   private class SubscriberDiffChangedEvent
/*     */     extends SubscriberEventHandler.SubscriberEvent
/*     */   {
/*     */     private final IDiff node;
/*     */     
/*     */     public SubscriberDiffChangedEvent(IResource resource, int type, int depth, IDiff node) {
/*  68 */       super(resource, type, depth);
/*  69 */       this.node = node;
/*     */     }
/*     */     public IDiff getChangedNode() {
/*  72 */       return this.node;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class SubscriberDiffCollector
/*     */     extends SubscriberResourceCollector
/*     */   {
/*     */     public SubscriberDiffCollector(Subscriber subscriber) {
/*  82 */       super(subscriber);
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean hasMembers(IResource resource) {
/*  87 */       return ((SubscriberDiffTreeEventHandler.this.tree.members(resource)).length > 0);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void remove(IResource resource) {
/*  92 */       SubscriberDiffTreeEventHandler.this.remove(resource);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void change(IResource resource, int depth) {
/*  97 */       SubscriberDiffTreeEventHandler.this.change(resource, depth);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SubscriberDiffTreeEventHandler(Subscriber subscriber, ISynchronizationScopeManager manager, ResourceDiffTree tree, DiffFilter filter) {
/* 109 */     super(subscriber, manager.getScope());
/* 110 */     this.manager = manager;
/* 111 */     this.tree = tree;
/* 112 */     this.collector = new SubscriberDiffCollector(subscriber);
/* 113 */     this.filter = filter;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reset(ResourceTraversal[] traversals, int type) {
/* 119 */     this.exceptionState = 0;
/* 120 */     if (!this.manager.isInitialized() && this.state == 3) {
/*     */       
/* 122 */       queueEvent((BackgroundEventHandler.Event)new BackgroundEventHandler.RunnableEvent(monitor -> {
/*     */               if (this.state == 3) {
/*     */                 try {
/*     */                   prepareScope(monitor);
/*     */                   
/*     */                   this.state = 5;
/*     */                 } finally {
/*     */                   if (this.state != 5) {
/*     */                     this.state = 1;
/*     */                     
/*     */                     if (this.exceptionState == 0) {
/*     */                       this.exceptionState = 1;
/*     */                     }
/*     */                   } 
/*     */                 } 
/*     */               }
/* 138 */             }true), true);
/* 139 */     } else if (this.manager.isInitialized()) {
/* 140 */       this.state = 5;
/* 141 */       super.reset(traversals, type);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void reset() {
/* 146 */     reset(getScope().getTraversals(), 
/* 147 */         3);
/*     */   }
/*     */   
/*     */   protected void prepareScope(IProgressMonitor monitor) {
/*     */     try {
/* 152 */       this.manager.initialize(monitor);
/* 153 */     } catch (CoreException e) {
/* 154 */       handleException(e);
/*     */     } 
/* 156 */     ResourceTraversal[] traversals = this.manager.getScope().getTraversals();
/* 157 */     if (traversals.length > 0) {
/* 158 */       reset(traversals, 3);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void handleChange(IResource resource) throws CoreException {
/* 163 */     IDiff node = getSubscriber().getDiff(resource);
/* 164 */     if (node == null) {
/* 165 */       queueDispatchEvent(
/* 166 */           (BackgroundEventHandler.Event)new SubscriberEventHandler.SubscriberEvent(this, resource, 1, 0));
/*     */     }
/* 168 */     else if (isInScope(resource)) {
/* 169 */       queueDispatchEvent(
/* 170 */           (BackgroundEventHandler.Event)new SubscriberDiffChangedEvent(resource, 2, 0, node));
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isInScope(IResource resource) {
/* 175 */     return this.manager.getScope().contains(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void collectAll(IResource resource, int depth, IProgressMonitor monitor) {
/* 181 */     Policy.checkCanceled(monitor);
/* 182 */     monitor.beginTask(null, -1);
/* 183 */     ResourceTraversal[] traversals = { new ResourceTraversal(new IResource[] { resource }, depth, 0) };
/*     */     try {
/* 185 */       getSubscriber().accept(traversals, diff -> {
/*     */             Policy.checkCanceled(paramIProgressMonitor);
/*     */             
/*     */             paramIProgressMonitor.subTask(NLS.bind(Messages.SubscriberDiffTreeEventHandler_0, this.tree.getResource(diff).getFullPath().toString()));
/*     */             
/*     */             queueDispatchEvent((BackgroundEventHandler.Event)new SubscriberDiffChangedEvent(this.tree.getResource(diff), 2, 0, diff));
/*     */             
/*     */             handlePreemptiveEvents(paramIProgressMonitor);
/*     */             handlePendingDispatch(paramIProgressMonitor);
/*     */             return true;
/*     */           });
/* 196 */     } catch (CoreException e) {
/* 197 */       if (resource.getProject().isAccessible())
/* 198 */         handleException(e, resource, 2, e.getMessage()); 
/*     */     } finally {
/* 200 */       monitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void dispatchEvents(SubscriberEventHandler.SubscriberEvent[] events, IProgressMonitor monitor) {
/*     */     try {
/* 208 */       this.tree.beginInput(); byte b; int i; SubscriberEventHandler.SubscriberEvent[] arrayOfSubscriberEvent;
/* 209 */       for (i = (arrayOfSubscriberEvent = events).length, b = 0; b < i; ) { IDiff[] nodesToRemove; byte b1; int j; IDiff[] arrayOfIDiff1; SubscriberEventHandler.SubscriberEvent event = arrayOfSubscriberEvent[b];
/* 210 */         switch (event.getType()) {
/*     */           case 2:
/* 212 */             if (event instanceof SubscriberDiffChangedEvent) {
/* 213 */               SubscriberDiffChangedEvent se = (SubscriberDiffChangedEvent)event;
/* 214 */               IDiff changedNode = se.getChangedNode();
/* 215 */               if (changedNode.getKind() == 0) {
/* 216 */                 this.tree.remove(changedNode.getPath()); break;
/*     */               } 
/* 218 */               addDiff(changedNode, monitor);
/*     */             } 
/*     */             break;
/*     */           
/*     */           case 1:
/* 223 */             nodesToRemove = this.tree.getDiffs(new ResourceTraversal[] { event.asTraversal() });
/* 224 */             for (j = (arrayOfIDiff1 = nodesToRemove).length, b1 = 0; b1 < j; ) { IDiff node = arrayOfIDiff1[b1];
/* 225 */               this.tree.remove(node.getPath()); b1++; }
/*     */              break;
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } finally {
/* 231 */       this.tree.endInput(monitor);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addDiff(IDiff diff, IProgressMonitor monitor) {
/* 236 */     if (this.filter == null || this.filter.select(diff, monitor)) {
/* 237 */       this.tree.add(diff);
/*     */     } else {
/* 239 */       this.tree.remove(diff.getPath());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResourceDiffTree getTree() {
/* 249 */     return (IResourceDiffTree)this.tree;
/*     */   }
/*     */ 
/*     */   
/*     */   public Subscriber getSubscriber() {
/* 254 */     return super.getSubscriber();
/*     */   }
/*     */ 
/*     */   
/*     */   public void shutdown() {
/* 259 */     this.state = 8;
/* 260 */     this.collector.dispose();
/* 261 */     super.shutdown();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object getJobFamiliy() {
/* 266 */     return this.family;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJobFamily(Object family) {
/* 274 */     this.family = family;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handleException(CoreException e, IResource resource, int code, String message) {
/* 279 */     super.handleException(e, resource, code, message);
/* 280 */     this.tree.reportError((IStatus)new TeamStatus(4, "org.eclipse.team.core", code, message, (Throwable)e, resource));
/* 281 */     this.exceptionState = 2;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void handleCancel(OperationCanceledException e) {
/* 286 */     super.handleCancel(e);
/* 287 */     this.tree.reportError((IStatus)new TeamStatus(4, "org.eclipse.team.core", 3, Messages.SubscriberEventHandler_12, (Throwable)e, (IResource)ResourcesPlugin.getWorkspace().getRoot()));
/* 288 */     if (this.exceptionState == 0)
/* 289 */       this.exceptionState = 1; 
/*     */   }
/*     */   
/*     */   public DiffFilter getFilter() {
/* 293 */     return this.filter;
/*     */   }
/*     */   
/*     */   public void setFilter(DiffFilter filter) {
/* 297 */     this.filter = filter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void initializeIfNeeded() {
/* 305 */     if (this.state == 1) {
/* 306 */       this.state = 3;
/* 307 */       reset(getScope().getTraversals(), 3);
/* 308 */     } else if (this.exceptionState != 0) {
/* 309 */       reset(getScope().getTraversals(), 3);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void start() {
/* 315 */     super.start();
/* 316 */     if (this.state == 0)
/* 317 */       this.state = 1; 
/*     */   }
/*     */   
/*     */   public int getState() {
/* 321 */     return this.state;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isSystemJob() {
/* 326 */     if (this.manager != null && !this.manager.isInitialized())
/* 327 */       return false; 
/* 328 */     return super.isSystemJob();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void remove(IResource resource) {
/* 334 */     if (this.state == 1)
/*     */       return; 
/* 336 */     super.remove(resource);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void change(IResource resource, int depth) {
/* 342 */     if (this.state == 1)
/*     */       return; 
/* 344 */     super.change(resource, depth);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\SubscriberDiffTreeEventHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */