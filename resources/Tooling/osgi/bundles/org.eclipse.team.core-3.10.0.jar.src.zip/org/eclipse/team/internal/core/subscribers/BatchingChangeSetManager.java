/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.core.runtime.jobs.ILock;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.team.internal.core.Policy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BatchingChangeSetManager
/*     */   extends ChangeSetManager
/*     */ {
/*  35 */   private ILock lock = Job.getJobManager().newLock();
/*     */   public static interface IChangeSetCollectorChangeListener {
/*     */     void changeSetChanges(BatchingChangeSetManager.CollectorChangeEvent param1CollectorChangeEvent, IProgressMonitor param1IProgressMonitor); }
/*     */   
/*  39 */   public static class CollectorChangeEvent { Set<ChangeSet> added = new HashSet<>();
/*  40 */     Set<ChangeSet> removed = new HashSet<>();
/*  41 */     Map<ChangeSet, IPath[]> changed = (Map)new HashMap<>();
/*     */     private final BatchingChangeSetManager collector;
/*     */     
/*     */     public CollectorChangeEvent(BatchingChangeSetManager collector) {
/*  45 */       this.collector = collector;
/*     */     }
/*     */     
/*     */     private void setAdded(ChangeSet set) {
/*  49 */       this.added.add(set);
/*  50 */       this.removed.remove(set);
/*     */     }
/*     */     
/*     */     private void setRemoved(ChangeSet set) {
/*  54 */       this.added.remove(set);
/*  55 */       this.removed.add(set);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void changed(ChangeSet changeSet, IPath[] allAffectedResources) {
/*  61 */       if (this.added.contains(changeSet))
/*     */         return; 
/*  63 */       IPath[] paths = this.changed.get(changeSet);
/*  64 */       if (paths == null) {
/*  65 */         this.changed.put(changeSet, allAffectedResources);
/*     */       } else {
/*  67 */         Set<IPath> allPaths = new HashSet<>();
/*  68 */         Collections.addAll(allPaths, paths);
/*  69 */         Collections.addAll(allPaths, allAffectedResources);
/*  70 */         this.changed.put(changeSet, allPaths.<IPath>toArray(new IPath[allPaths.size()]));
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean isEmpty() {
/*  75 */       return (this.changed.isEmpty() && this.added.isEmpty() && this.removed.isEmpty());
/*     */     }
/*     */     
/*     */     public ChangeSet[] getAddedSets() {
/*  79 */       return this.added.<ChangeSet>toArray(new ChangeSet[this.added.size()]);
/*     */     }
/*     */     
/*     */     public ChangeSet[] getRemovedSets() {
/*  83 */       return this.removed.<ChangeSet>toArray(new ChangeSet[this.removed.size()]);
/*     */     }
/*     */     
/*     */     public ChangeSet[] getChangedSets() {
/*  87 */       return (ChangeSet[])this.changed.keySet().toArray((Object[])new ChangeSet[this.changed.size()]);
/*     */     }
/*     */     
/*     */     public IPath[] getChangesFor(ChangeSet set) {
/*  91 */       return this.changed.get(set);
/*     */     }
/*     */     
/*     */     public BatchingChangeSetManager getSource() {
/*  95 */       return this.collector;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   private CollectorChangeEvent changes = new CollectorChangeEvent(this);
/*     */   
/*     */   public void beginInput() {
/* 106 */     this.lock.acquire();
/*     */   }
/*     */   
/*     */   public void endInput(IProgressMonitor monitor) {
/*     */     try {
/* 111 */       if (this.lock.getDepth() == 1)
/*     */       {
/*     */         
/* 114 */         fireChanges(Policy.monitorFor(monitor));
/*     */       }
/*     */     } finally {
/* 117 */       this.lock.release();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void fireChanges(final IProgressMonitor monitor) {
/* 122 */     if (this.changes.isEmpty()) {
/*     */       return;
/*     */     }
/* 125 */     final CollectorChangeEvent event = this.changes;
/* 126 */     this.changes = new CollectorChangeEvent(this);
/* 127 */     Object[] listeners = getListeners(); byte b; int i; Object[] arrayOfObject1;
/* 128 */     for (i = (arrayOfObject1 = listeners).length, b = 0; b < i; ) { Object l = arrayOfObject1[b];
/* 129 */       IChangeSetChangeListener listener = (IChangeSetChangeListener)l;
/* 130 */       if (listener instanceof IChangeSetCollectorChangeListener) {
/* 131 */         final IChangeSetCollectorChangeListener csccl = (IChangeSetCollectorChangeListener)listener;
/* 132 */         SafeRunner.run(new ISafeRunnable()
/*     */             {
/*     */               public void handleException(Throwable exception) {}
/*     */ 
/*     */ 
/*     */               
/*     */               public void run() throws Exception {
/* 139 */                 csccl.changeSetChanges(event, monitor);
/*     */               }
/*     */             });
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public void add(ChangeSet set) {
/*     */     try {
/* 149 */       beginInput();
/* 150 */       super.add(set);
/* 151 */       this.changes.setAdded(set);
/*     */     } finally {
/* 153 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(ChangeSet set) {
/*     */     try {
/* 160 */       beginInput();
/* 161 */       super.remove(set);
/* 162 */       this.changes.setRemoved(set);
/*     */     } finally {
/* 164 */       endInput(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void fireResourcesChangedEvent(ChangeSet changeSet, IPath[] allAffectedResources) {
/* 170 */     super.fireResourcesChangedEvent(changeSet, allAffectedResources);
/*     */     try {
/* 172 */       beginInput();
/* 173 */       this.changes.changed(changeSet, allAffectedResources);
/*     */     } finally {
/* 175 */       endInput(null);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void initializeSets() {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\BatchingChangeSetManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */