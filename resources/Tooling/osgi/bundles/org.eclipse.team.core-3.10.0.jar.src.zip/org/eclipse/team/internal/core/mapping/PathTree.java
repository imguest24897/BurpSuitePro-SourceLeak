/*     */ package org.eclipse.team.internal.core.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PathTree
/*     */ {
/*     */   class Node
/*     */   {
/*     */     Object payload;
/*     */     Set<IPath> descendantsWithPayload;
/*     */     int flags;
/*     */     
/*     */     public boolean isEmpty() {
/*  36 */       return (this.payload == null && (this.descendantsWithPayload == null || this.descendantsWithPayload.isEmpty()));
/*     */     }
/*     */     public Object getPayload() {
/*  39 */       return this.payload;
/*     */     }
/*     */     public void setPayload(Object payload) {
/*  42 */       this.payload = payload;
/*     */     }
/*     */     public boolean hasDescendants() {
/*  45 */       return (this.descendantsWithPayload != null && !this.descendantsWithPayload.isEmpty());
/*     */     }
/*     */     public boolean hasFlag(int propertyBit) {
/*  48 */       return ((this.flags & propertyBit) != 0);
/*     */     }
/*     */     public void setProperty(int propertyBit, boolean value) {
/*  51 */       if (value) {
/*  52 */         this.flags |= propertyBit;
/*     */       } else {
/*  54 */         this.flags ^= propertyBit;
/*     */       } 
/*     */     } public boolean descendantHasFlag(int property) {
/*  57 */       if (hasDescendants()) {
/*  58 */         for (IPath path : this.descendantsWithPayload) {
/*  59 */           Node child = PathTree.this.getNode(path);
/*  60 */           if (child.hasFlag(property)) {
/*  61 */             return true;
/*     */           }
/*     */         } 
/*     */       }
/*  65 */       return false;
/*     */     }
/*     */   }
/*     */   
/*  69 */   private Map<IPath, Node> objects = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object get(IPath path) {
/*  78 */     Node node = getNode(path);
/*  79 */     if (node == null)
/*  80 */       return null; 
/*  81 */     return node.getPayload();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object put(IPath path, Object object) {
/*  93 */     Node node = getNode(path);
/*  94 */     if (node == null) {
/*  95 */       node = addNode(path);
/*     */     }
/*  97 */     Object previous = node.getPayload();
/*  98 */     node.setPayload(object);
/*  99 */     if (previous == null) {
/* 100 */       addToParents(path, path);
/*     */     }
/* 102 */     return previous;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Object remove(IPath path) {
/* 114 */     Node node = getNode(path);
/* 115 */     if (node == null)
/* 116 */       return null; 
/* 117 */     Object previous = node.getPayload();
/* 118 */     node.setPayload(null);
/* 119 */     if (previous != null) {
/* 120 */       removeFromParents(path, path);
/* 121 */       if (node.isEmpty()) {
/* 122 */         removeNode(path);
/*     */       }
/*     */     } 
/* 125 */     return previous;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean hasChildren(IPath path) {
/* 135 */     if (path.isEmpty()) return !this.objects.isEmpty(); 
/* 136 */     Node node = getNode(path);
/* 137 */     if (node == null)
/* 138 */       return false; 
/* 139 */     return node.hasDescendants();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized IPath[] getChildren(IPath path) {
/* 150 */     Set<IPath> children = new HashSet<>();
/* 151 */     Node node = getNode(path);
/* 152 */     if (node != null) {
/* 153 */       Set<IPath> possibleChildren = node.descendantsWithPayload;
/* 154 */       if (possibleChildren != null) {
/* 155 */         for (IPath next : possibleChildren) {
/* 156 */           IPath descendantPath = next;
/* 157 */           IPath childPath = null;
/* 158 */           if (descendantPath.segmentCount() == path.segmentCount() + 1) {
/* 159 */             childPath = descendantPath;
/* 160 */           } else if (descendantPath.segmentCount() > path.segmentCount()) {
/* 161 */             childPath = descendantPath.removeLastSegments(descendantPath.segmentCount() - path.segmentCount() - 1);
/*     */           } 
/* 163 */           if (childPath != null) {
/* 164 */             children.add(childPath);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 169 */     return children.<IPath>toArray(new IPath[children.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean addToParents(IPath path, IPath parent) {
/* 174 */     boolean addedParent = false;
/* 175 */     if (path == parent) {
/*     */       
/* 177 */       addedParent = true;
/*     */     } else {
/* 179 */       Node node = getNode(parent);
/* 180 */       if (node == null)
/* 181 */         node = addNode(parent); 
/* 182 */       Set<IPath> children = node.descendantsWithPayload;
/* 183 */       if (children == null) {
/* 184 */         children = new HashSet<>();
/* 185 */         node.descendantsWithPayload = children;
/*     */         
/* 187 */         addedParent = true;
/*     */       } 
/* 189 */       children.add(path);
/*     */     } 
/*     */     
/* 192 */     if (parent.segmentCount() == 0 || !addToParents(path, parent.removeLastSegments(1)));
/*     */ 
/*     */ 
/*     */     
/* 196 */     return addedParent;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean removeFromParents(IPath path, IPath parent) {
/* 201 */     boolean removedParent = false;
/* 202 */     Node node = getNode(parent);
/* 203 */     if (node == null) {
/*     */       
/* 205 */       removedParent = true;
/*     */     } else {
/* 207 */       Set<IPath> children = node.descendantsWithPayload;
/* 208 */       if (children == null) {
/*     */         
/* 210 */         removedParent = true;
/*     */       } else {
/* 212 */         children.remove(path);
/* 213 */         if (children.isEmpty()) {
/* 214 */           node.descendantsWithPayload = null;
/* 215 */           if (node.isEmpty())
/* 216 */             removeNode(parent); 
/* 217 */           removedParent = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 222 */     if (parent.segmentCount() == 0 || !removeFromParents(path, parent.removeLastSegments(1)));
/*     */ 
/*     */ 
/*     */     
/* 226 */     return removedParent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void clear() {
/* 233 */     this.objects.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean isEmpty() {
/* 241 */     return this.objects.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized IPath[] getPaths() {
/* 249 */     List<IPath> result = new ArrayList<>();
/* 250 */     for (IPath path : this.objects.keySet()) {
/* 251 */       Node node = getNode(path);
/* 252 */       if (node.getPayload() != null)
/* 253 */         result.add(path); 
/*     */     } 
/* 255 */     return result.<IPath>toArray(new IPath[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Collection<Object> values() {
/* 263 */     List<Object> result = new ArrayList();
/* 264 */     for (IPath path : this.objects.keySet()) {
/* 265 */       Node node = getNode(path);
/* 266 */       if (node.getPayload() != null)
/* 267 */         result.add(node.getPayload()); 
/*     */     } 
/* 269 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 277 */     return values().size();
/*     */   }
/*     */   
/*     */   private Node getNode(IPath path) {
/* 281 */     return this.objects.get(path);
/*     */   }
/*     */ 
/*     */   
/*     */   private Node addNode(IPath path) {
/* 286 */     Node node = new Node();
/* 287 */     this.objects.put(path, node);
/* 288 */     return node;
/*     */   }
/*     */   
/*     */   private Object removeNode(IPath path) {
/* 292 */     return this.objects.remove(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized IPath[] setPropogatedProperty(IPath path, int property, boolean value) {
/* 305 */     Set<IPath> changed = new HashSet<>();
/* 306 */     internalSetPropertyBit(path, property, value, changed);
/* 307 */     return changed.<IPath>toArray(new IPath[changed.size()]);
/*     */   }
/*     */   
/*     */   private void internalSetPropertyBit(IPath path, int property, boolean value, Set<IPath> changed) {
/* 311 */     if (path.segmentCount() == 0)
/*     */       return; 
/* 313 */     Node node = getNode(path);
/* 314 */     if (node == null) {
/*     */       return;
/*     */     }
/* 317 */     if (value == node.hasFlag(property)) {
/*     */       return;
/*     */     }
/* 320 */     if (!value && node.descendantHasFlag(property))
/*     */       return; 
/* 322 */     node.setProperty(property, value);
/* 323 */     changed.add(path);
/* 324 */     internalSetPropertyBit(path.removeLastSegments(1), property, value, changed);
/*     */   }
/*     */   
/*     */   public synchronized boolean getProperty(IPath path, int property) {
/* 328 */     if (path.segmentCount() == 0)
/* 329 */       return false; 
/* 330 */     Node node = getNode(path);
/* 331 */     if (node == null)
/* 332 */       return false; 
/* 333 */     return node.hasFlag(property);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\PathTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */