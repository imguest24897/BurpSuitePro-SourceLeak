/*     */ package org.eclipse.team.internal.core.streams;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.io.OutputStream;
/*     */ import org.eclipse.team.internal.core.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TimeoutOutputStream
/*     */   extends FilterOutputStream
/*     */ {
/*     */   private final long writeTimeout;
/*     */   private final long closeTimeout;
/*     */   private byte[] iobuffer;
/*  42 */   private int head = 0;
/*  43 */   private int length = 0;
/*     */   
/*     */   private boolean closeRequested = false;
/*     */   
/*     */   private boolean flushRequested = false;
/*     */   private Thread thread;
/*     */   private boolean waitingForClose = false;
/*  50 */   private IOException ioe = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TimeoutOutputStream(OutputStream out, int bufferSize, long writeTimeout, long closeTimeout) {
/*  63 */     super(new BufferedOutputStream(out, bufferSize));
/*  64 */     this.writeTimeout = writeTimeout;
/*  65 */     this.closeTimeout = closeTimeout;
/*  66 */     this.iobuffer = new byte[bufferSize];
/*  67 */     this.thread = new Thread(this::runThread, "TimeoutOutputStream");
/*  68 */     this.thread.setDaemon(true);
/*  69 */     this.thread.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*     */     Thread oldThread;
/*  85 */     synchronized (this) {
/*  86 */       if (this.thread == null)
/*  87 */         return;  oldThread = this.thread;
/*  88 */       this.closeRequested = true;
/*  89 */       this.thread.interrupt();
/*  90 */       checkError();
/*     */     } 
/*  92 */     if (this.closeTimeout == -1L)
/*     */       return;  try {
/*  94 */       oldThread.join(this.closeTimeout);
/*  95 */     } catch (InterruptedException interruptedException) {
/*  96 */       Thread.currentThread().interrupt();
/*     */     } 
/*  98 */     synchronized (this) {
/*  99 */       checkError();
/* 100 */       if (this.thread != null) throw new InterruptedIOException();
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void write(int b) throws IOException {
/* 112 */     syncCommit(true);
/* 113 */     this.iobuffer[(this.head + this.length) % this.iobuffer.length] = (byte)b;
/* 114 */     this.length++;
/* 115 */     notify();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void write(byte[] buffer, int off, int len) throws IOException {
/* 126 */     int amount = 0;
/*     */     try {
/*     */       do {
/* 129 */         syncCommit(true);
/* 130 */         while (amount < len && this.length != this.iobuffer.length) {
/* 131 */           this.iobuffer[(this.head + this.length) % this.iobuffer.length] = buffer[off++];
/* 132 */           this.length++;
/* 133 */           amount++;
/*     */         } 
/* 135 */       } while (amount < len);
/* 136 */     } catch (InterruptedIOException e) {
/* 137 */       e.bytesTransferred = amount;
/* 138 */       throw e;
/*     */     } 
/* 140 */     notify();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void flush() throws IOException {
/* 151 */     int oldLength = this.length;
/* 152 */     this.flushRequested = true;
/*     */     try {
/* 154 */       syncCommit(false);
/* 155 */     } catch (InterruptedIOException e) {
/* 156 */       e.bytesTransferred = oldLength - this.length;
/* 157 */       throw e;
/*     */     } 
/* 159 */     notify();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void syncCommit(boolean partial) throws IOException {
/* 168 */     checkError();
/* 169 */     if ((partial && this.length != this.iobuffer.length) || this.length == 0)
/* 170 */       return;  if (this.waitingForClose) throw new IOException(Messages.TimeoutOutputStream_cannotWriteToStream); 
/* 171 */     notify();
/*     */     try {
/* 173 */       wait(this.writeTimeout);
/* 174 */     } catch (InterruptedException interruptedException) {
/* 175 */       Thread.currentThread().interrupt();
/*     */     } 
/* 177 */     checkError();
/* 178 */     if ((partial && this.length != this.iobuffer.length) || this.length == 0)
/* 179 */       return;  throw new InterruptedIOException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkError() throws IOException {
/* 186 */     if (this.ioe != null) {
/* 187 */       IOException e = this.ioe;
/* 188 */       this.ioe = null;
/* 189 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void runThread() {
/*     */     
/* 198 */     try { writeUntilDone(); }
/* 199 */     catch (IOException e)
/* 200 */     { synchronized (this) { this.ioe = e; }
/*     */       
/* 202 */       waitUntilClosed(); } finally { waitUntilClosed();
/*     */       
/* 204 */       try { this.out.close(); }
/* 205 */       catch (IOException e)
/* 206 */       { synchronized (this) { this.ioe = e; }
/*     */          }
/* 208 */       finally { synchronized (this) {
/* 209 */           this.thread = null;
/* 210 */           notify();
/*     */         }  }
/*     */        }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void waitUntilClosed() {
/* 220 */     this.waitingForClose = true;
/* 221 */     notify();
/* 222 */     while (!this.closeRequested) {
/*     */       try {
/* 224 */         wait();
/* 225 */       } catch (InterruptedException interruptedException) {
/* 226 */         this.closeRequested = true;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeUntilDone() throws IOException {
/* 235 */     int bytesUntilFlush = -1; while (true) {
/*     */       int off;
/*     */       int len;
/* 238 */       synchronized (this) {
/*     */         while (true) {
/* 240 */           if (this.closeRequested && this.length == 0)
/* 241 */             return;  if (this.length != 0 || this.flushRequested)
/*     */             break;  try {
/* 243 */             wait();
/* 244 */           } catch (InterruptedException interruptedException) {
/* 245 */             this.closeRequested = true;
/*     */           } 
/*     */         } 
/* 248 */         off = this.head;
/* 249 */         len = this.iobuffer.length - this.head;
/* 250 */         if (len > this.length) len = this.length; 
/* 251 */         if (this.flushRequested && bytesUntilFlush < 0) {
/* 252 */           this.flushRequested = false;
/* 253 */           bytesUntilFlush = this.length;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 258 */       if (len != 0) {
/*     */         
/*     */         try {
/*     */ 
/*     */           
/* 263 */           this.out.write(this.iobuffer, off, len);
/* 264 */         } catch (InterruptedIOException e) {
/* 265 */           len = e.bytesTransferred;
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 270 */       if (bytesUntilFlush >= 0) {
/* 271 */         bytesUntilFlush -= len;
/* 272 */         if (bytesUntilFlush <= 0) {
/*     */           
/*     */           try {
/* 275 */             this.out.flush();
/* 276 */           } catch (InterruptedIOException interruptedIOException) {}
/*     */           
/* 278 */           bytesUntilFlush = -1;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 283 */       if (len != 0)
/* 284 */         synchronized (this) {
/* 285 */           this.head = (this.head + len) % this.iobuffer.length;
/* 286 */           this.length -= len;
/* 287 */           notify();
/*     */         }  
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\streams\TimeoutOutputStream.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */