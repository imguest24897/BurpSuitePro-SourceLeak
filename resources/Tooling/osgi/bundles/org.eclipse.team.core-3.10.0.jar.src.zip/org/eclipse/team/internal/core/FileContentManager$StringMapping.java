/*    */ package org.eclipse.team.internal.core;
/*    */ 
/*    */ import org.eclipse.team.core.IStringMapping;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StringMapping
/*    */   implements IStringMapping
/*    */ {
/*    */   private final String fString;
/*    */   private final int fType;
/*    */   
/*    */   public StringMapping(String string, int type) {
/* 51 */     this.fString = string;
/* 52 */     this.fType = type;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getString() {
/* 57 */     return this.fString;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getType() {
/* 62 */     return this.fType;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\FileContentManager$StringMapping.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */