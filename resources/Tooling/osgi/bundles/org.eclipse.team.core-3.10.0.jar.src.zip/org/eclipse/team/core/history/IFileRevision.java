package org.eclipse.team.core.history;

import java.net.URI;
import org.eclipse.core.resources.IStorage;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IFileRevision {
  IStorage getStorage(IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  String getName();
  
  URI getURI();
  
  long getTimestamp();
  
  boolean exists();
  
  String getContentIdentifier();
  
  String getAuthor();
  
  String getComment();
  
  ITag[] getBranches();
  
  ITag[] getTags();
  
  boolean isPropertyMissing();
  
  IFileRevision withAllProperties(IProgressMonitor paramIProgressMonitor) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\history\IFileRevision.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */