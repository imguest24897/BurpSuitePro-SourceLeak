/*     */ package org.eclipse.team.core.variants;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.team.core.Team;
/*     */ import org.eclipse.team.core.TeamException;
/*     */ import org.eclipse.team.core.subscribers.ISubscriberChangeEvent;
/*     */ import org.eclipse.team.core.subscribers.SubscriberChangeEvent;
/*     */ import org.eclipse.team.internal.core.TeamPlugin;
/*     */ import org.eclipse.team.internal.core.subscribers.ThreeWayBaseTree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ThreeWaySubscriber
/*     */   extends ResourceVariantTreeSubscriber
/*     */   implements ISynchronizerChangeListener
/*     */ {
/*     */   private ThreeWayResourceComparator comparator;
/*     */   private ThreeWayBaseTree baseTree;
/*     */   private ThreeWayRemoteTree remoteTree;
/*     */   private ThreeWaySynchronizer synchronizer;
/*     */   
/*     */   protected ThreeWaySubscriber(ThreeWaySynchronizer synchronizer) {
/*  53 */     this.synchronizer = synchronizer;
/*  54 */     this.baseTree = new ThreeWayBaseTree(this);
/*  55 */     getSynchronizer().addListener(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final IResourceVariantTree getBaseTree() {
/*  60 */     return (IResourceVariantTree)this.baseTree;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final IResourceVariantTree getRemoteTree() {
/*  65 */     if (this.remoteTree == null) {
/*  66 */       this.remoteTree = createRemoteTree();
/*     */     }
/*  68 */     return this.remoteTree;
/*     */   }
/*     */ 
/*     */   
/*     */   public final IResourceVariantComparator getResourceComparator() {
/*  73 */     if (this.comparator == null) {
/*  74 */       this.comparator = new ThreeWayResourceComparator(getSynchronizer());
/*     */     }
/*  76 */     return this.comparator;
/*     */   }
/*     */ 
/*     */   
/*     */   public void syncStateChanged(IResource[] resources) {
/*  81 */     fireTeamResourceChange((ISubscriberChangeEvent[])SubscriberChangeEvent.asSyncChangedDeltas(this, resources));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSupervised(IResource resource) throws TeamException {
/*  93 */     if (!isChildOfRoot(resource)) return false; 
/*  94 */     if (getSynchronizer().isIgnored(resource)) return false; 
/*  95 */     if (Team.isIgnoredHint(resource)) return false; 
/*  96 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ThreeWaySynchronizer getSynchronizer() {
/* 104 */     return this.synchronizer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract IResourceVariant getResourceVariant(IResource paramIResource, byte[] paramArrayOfbyte) throws TeamException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract ThreeWayRemoteTree createRemoteTree();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleRootChanged(IResource resource, boolean added) {
/* 137 */     if (added) {
/* 138 */       rootAdded(resource);
/*     */     } else {
/* 140 */       rootRemoved(resource);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void rootAdded(IResource resource) {
/* 145 */     SubscriberChangeEvent delta = new SubscriberChangeEvent(this, 2, resource);
/* 146 */     fireTeamResourceChange((ISubscriberChangeEvent[])new SubscriberChangeEvent[] { delta });
/*     */   }
/*     */   
/*     */   private void rootRemoved(IResource resource) {
/*     */     try {
/* 151 */       getSynchronizer().flush(resource, 2);
/* 152 */     } catch (TeamException e) {
/* 153 */       TeamPlugin.log((CoreException)e);
/*     */     } 
/* 155 */     SubscriberChangeEvent delta = new SubscriberChangeEvent(this, 4, resource);
/* 156 */     fireTeamResourceChange((ISubscriberChangeEvent[])new SubscriberChangeEvent[] { delta });
/*     */   }
/*     */   
/*     */   private boolean isChildOfRoot(IResource resource) {
/* 160 */     IResource[] roots = roots();
/* 161 */     IPath fullPath = resource.getFullPath(); byte b; int i; IResource[] arrayOfIResource1;
/* 162 */     for (i = (arrayOfIResource1 = roots).length, b = 0; b < i; ) { IResource root = arrayOfIResource1[b];
/* 163 */       if (root.getFullPath().isPrefixOf(fullPath))
/* 164 */         return true; 
/*     */       b++; }
/*     */     
/* 167 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\core\variants\ThreeWaySubscriber.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */