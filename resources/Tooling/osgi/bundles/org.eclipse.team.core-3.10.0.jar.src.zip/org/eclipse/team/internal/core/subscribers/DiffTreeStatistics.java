/*     */ package org.eclipse.team.internal.core.subscribers;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.team.core.diff.IDiff;
/*     */ import org.eclipse.team.core.diff.IThreeWayDiff;
/*     */ import org.eclipse.team.core.synchronize.SyncInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DiffTreeStatistics
/*     */ {
/*  30 */   protected Map<Integer, Long> stats = Collections.synchronizedMap(new HashMap<>());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int state) {
/*  38 */     Long count = this.stats.get(Integer.valueOf(state));
/*  39 */     if (count == null) {
/*  40 */       count = Long.valueOf(0L);
/*     */     }
/*  42 */     this.stats.put(Integer.valueOf(state), Long.valueOf(count.longValue() + 1L));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(int state) {
/*  51 */     Integer kind = Integer.valueOf(state);
/*  52 */     Long count = this.stats.get(kind);
/*  53 */     if (count != null) {
/*     */ 
/*     */ 
/*     */       
/*  57 */       long newCount = (count.intValue() - 1);
/*  58 */       if (newCount > 0L) {
/*  59 */         this.stats.put(kind, Long.valueOf(newCount));
/*     */       } else {
/*  61 */         this.stats.remove(kind);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long countFor(int state, int mask) {
/*  77 */     if (mask == 0) {
/*  78 */       Long long_ = this.stats.get(Integer.valueOf(state));
/*  79 */       return (long_ == null) ? 0L : long_.longValue();
/*     */     } 
/*  81 */     Set<Integer> keySet = this.stats.keySet();
/*  82 */     long count = 0L;
/*  83 */     synchronized (this.stats) {
/*  84 */       Iterator<Integer> it = keySet.iterator();
/*  85 */       while (it.hasNext()) {
/*  86 */         Integer key = it.next();
/*  87 */         if ((key.intValue() & mask) == state) {
/*  88 */           count += ((Long)this.stats.get(key)).intValue();
/*     */         }
/*     */       } 
/*     */     } 
/*  92 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 101 */     this.stats.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 109 */     StringBuilder out = new StringBuilder();
/* 110 */     for (Integer kind : this.stats.keySet()) {
/* 111 */       out.append(String.valueOf(SyncInfo.kindToString(kind.intValue())) + ": " + this.stats.get(kind) + "\n");
/*     */     }
/* 113 */     return out.toString();
/*     */   }
/*     */   
/*     */   public void add(IDiff delta) {
/* 117 */     int state = getState(delta);
/* 118 */     add(state);
/*     */   }
/*     */   
/*     */   public void remove(IDiff delta) {
/* 122 */     int state = getState(delta);
/* 123 */     remove(state);
/*     */   }
/*     */   
/*     */   private int getState(IDiff delta) {
/* 127 */     int state = delta.getKind();
/* 128 */     if (delta instanceof IThreeWayDiff) {
/* 129 */       IThreeWayDiff twd = (IThreeWayDiff)delta;
/* 130 */       state |= twd.getDirection();
/*     */     } 
/* 132 */     return state;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\DiffTreeStatistics.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */