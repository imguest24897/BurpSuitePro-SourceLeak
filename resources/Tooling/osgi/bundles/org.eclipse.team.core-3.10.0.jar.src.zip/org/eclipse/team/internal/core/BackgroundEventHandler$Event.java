/*     */ package org.eclipse.team.internal.core;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Event
/*     */ {
/*     */   private int type;
/*     */   
/*     */   public Event(int type) {
/* 105 */     this.type = type;
/*     */   }
/*     */   public int getType() {
/* 108 */     return this.type;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 112 */     StringBuilder buffer = new StringBuilder();
/* 113 */     buffer.append("Background Event: ");
/* 114 */     buffer.append(getTypeString());
/* 115 */     return buffer.toString();
/*     */   }
/*     */   public IResource getResource() {
/* 118 */     return null;
/*     */   }
/*     */   protected String getTypeString() {
/* 121 */     return String.valueOf(this.type);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\BackgroundEventHandler$Event.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */