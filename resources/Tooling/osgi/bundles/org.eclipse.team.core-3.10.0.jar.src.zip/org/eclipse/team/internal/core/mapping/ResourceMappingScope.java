/*     */ package org.eclipse.team.internal.core.mapping;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.resources.mapping.RemoteResourceMappingContext;
/*     */ import org.eclipse.core.resources.mapping.ResourceMapping;
/*     */ import org.eclipse.core.resources.mapping.ResourceMappingContext;
/*     */ import org.eclipse.core.resources.mapping.ResourceTraversal;
/*     */ import org.eclipse.team.core.mapping.ISynchronizationScope;
/*     */ import org.eclipse.team.core.mapping.provider.SynchronizationScopeManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceMappingScope
/*     */   extends AbstractResourceMappingScope
/*     */ {
/*     */   private ResourceMapping[] inputMappings;
/*  41 */   private final Map<ResourceMapping, ResourceTraversal[]> mappingsToTraversals = (Map)Collections.synchronizedMap(new HashMap<>());
/*     */   private boolean hasAdditionalMappings;
/*     */   private boolean hasAdditionalResources;
/*  44 */   private final CompoundResourceTraversal compoundTraversal = new CompoundResourceTraversal();
/*     */   private final SynchronizationScopeManager manager;
/*     */   
/*     */   public ResourceMappingScope(ResourceMapping[] selectedMappings, SynchronizationScopeManager manager) {
/*  48 */     this.inputMappings = selectedMappings;
/*  49 */     this.manager = manager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceTraversal[] addMapping(ResourceMapping mapping, ResourceTraversal[] traversals) {
/*  60 */     ResourceTraversal[] newTraversals = this.compoundTraversal.getUncoveredTraversals(traversals);
/*  61 */     this.mappingsToTraversals.put(mapping, traversals);
/*  62 */     this.compoundTraversal.addTraversals(traversals);
/*  63 */     return newTraversals;
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceMapping[] getInputMappings() {
/*  68 */     return this.inputMappings;
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceMapping[] getMappings() {
/*  73 */     if (this.mappingsToTraversals.isEmpty())
/*  74 */       return this.inputMappings; 
/*  75 */     return (ResourceMapping[])this.mappingsToTraversals.keySet().toArray((Object[])new ResourceMapping[this.mappingsToTraversals.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceTraversal[] getTraversals() {
/*  80 */     return this.compoundTraversal.asTraversals();
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceTraversal[] getTraversals(ResourceMapping mapping) {
/*  85 */     return this.mappingsToTraversals.get(mapping);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAdditionalMappings() {
/*  90 */     return this.hasAdditionalMappings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHasAdditionalMappings(boolean hasAdditionalMappings) {
/*  99 */     this.hasAdditionalMappings = hasAdditionalMappings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHasAdditionalResources(boolean hasAdditionalResources) {
/* 108 */     this.hasAdditionalResources = hasAdditionalResources;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAdditonalResources() {
/* 113 */     return this.hasAdditionalResources;
/*     */   }
/*     */   
/*     */   public CompoundResourceTraversal getCompoundTraversal() {
/* 117 */     return this.compoundTraversal;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISynchronizationScope asInputScope() {
/* 122 */     return (ISynchronizationScope)new ResourceMappingInputScope((ISynchronizationScope)this);
/*     */   }
/*     */ 
/*     */   
/*     */   public IProject[] getProjects() {
/* 127 */     ResourceMappingContext context = getContext();
/* 128 */     if (context instanceof RemoteResourceMappingContext) {
/* 129 */       RemoteResourceMappingContext rrmc = (RemoteResourceMappingContext)context;
/* 130 */       return rrmc.getProjects();
/*     */     } 
/* 132 */     return ResourcesPlugin.getWorkspace().getRoot().getProjects();
/*     */   }
/*     */ 
/*     */   
/*     */   public ResourceMappingContext getContext() {
/* 137 */     return this.manager.getContext();
/*     */   }
/*     */ 
/*     */   
/*     */   public void refresh(ResourceMapping[] mappings) {
/* 142 */     this.manager.refresh(mappings);
/*     */   }
/*     */   
/*     */   public void reset() {
/* 146 */     this.mappingsToTraversals.clear();
/* 147 */     this.compoundTraversal.clear();
/* 148 */     this.hasAdditionalMappings = false;
/* 149 */     this.hasAdditionalResources = false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\mapping\ResourceMappingScope.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */