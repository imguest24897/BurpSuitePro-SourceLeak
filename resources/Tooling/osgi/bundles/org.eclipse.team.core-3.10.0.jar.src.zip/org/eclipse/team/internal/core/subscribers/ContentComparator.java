/*    */ package org.eclipse.team.internal.core.subscribers;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContentComparator
/*    */   extends AbstractContentComparator
/*    */ {
/*    */   public ContentComparator(boolean ignoreWhitespace) {
/* 30 */     super(ignoreWhitespace);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean contentsEqual(IProgressMonitor monitor, InputStream is1, InputStream is2, boolean ignoreWhitespace) {
/*    */     
/* 47 */     try { if (is1 == is2) {
/* 48 */         return true;
/*    */       }
/* 50 */       if (is1 == null && is2 == null) {
/* 51 */         return true;
/*    */       }
/* 53 */       if (is1 == null || is2 == null) {
/* 54 */         return false;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/*    */       }
/*    */ 
/*    */ 
/*    */ 
/*    */       
/*    */        }
/*    */     
/* 68 */     catch (IOException iOException)
/*    */     
/*    */     { try {
/*    */         try {
/* 72 */           if (is1 != null) {
/* 73 */             is1.close();
/*    */           }
/*    */         } finally {
/* 76 */           if (is2 != null) {
/* 77 */             is2.close();
/*    */           }
/*    */         } 
/* 80 */       } catch (IOException iOException1) {} } finally { try { try { if (is1 != null) is1.close();  } finally { if (is2 != null) is2.close();  }  } catch (IOException iOException) {} }  try { try { if (is1 != null) is1.close();  } finally { if (is2 != null) is2.close();  }  } catch (IOException iOException) {}
/*    */ 
/*    */ 
/*    */     
/* 84 */     return false;
/*    */   }
/*    */   
/*    */   private boolean isWhitespace(int c) {
/* 88 */     if (c == -1)
/* 89 */       return false; 
/* 90 */     return Character.isWhitespace((char)c);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.team.core-3.10.0.jar!\org\eclipse\team\internal\core\subscribers\ContentComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */