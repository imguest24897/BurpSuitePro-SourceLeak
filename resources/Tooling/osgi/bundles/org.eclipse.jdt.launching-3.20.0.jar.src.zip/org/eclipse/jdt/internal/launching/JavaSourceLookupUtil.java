/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*     */ import org.eclipse.debug.core.sourcelookup.containers.DirectorySourceContainer;
/*     */ import org.eclipse.debug.core.sourcelookup.containers.ExternalArchiveSourceContainer;
/*     */ import org.eclipse.debug.core.sourcelookup.containers.FolderSourceContainer;
/*     */ import org.eclipse.debug.core.sourcelookup.containers.ProjectSourceContainer;
/*     */ import org.eclipse.jdt.core.IJavaModel;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry;
/*     */ import org.eclipse.jdt.launching.sourcelookup.containers.JavaProjectSourceContainer;
/*     */ import org.eclipse.jdt.launching.sourcelookup.containers.PackageFragmentRootSourceContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaSourceLookupUtil
/*     */ {
/*     */   public static ISourceContainer[] translate(IRuntimeClasspathEntry[] entries) {
/*  55 */     List<ISourceContainer> containers = new ArrayList<>(entries.length);
/*  56 */     for (int i = 0; i < entries.length; i++) {
/*  57 */       IPackageFragmentRoot root; IResource resource; PackageFragmentRootSourceContainer packageFragmentRootSourceContainer; IRuntimeClasspathEntry entry = entries[i];
/*  58 */       switch (entry.getType()) {
/*     */         case 2:
/*  60 */           if (entry.getPath().lastSegment().equals("jrt-fs.jar")) {
/*  61 */             getPackageFragmentRootContainers(entry, containers); break;
/*     */           } 
/*  63 */           root = getPackageFragmentRoot(entry);
/*  64 */           if (root == null) {
/*  65 */             addSourceAttachment(entry, containers); break;
/*     */           } 
/*  67 */           packageFragmentRootSourceContainer = new PackageFragmentRootSourceContainer(root);
/*  68 */           if (!containers.contains(packageFragmentRootSourceContainer)) {
/*  69 */             containers.add(packageFragmentRootSourceContainer);
/*     */           }
/*     */           break;
/*     */ 
/*     */         
/*     */         case 1:
/*  75 */           resource = entry.getResource();
/*  76 */           if (resource != null && resource.getType() == 4) {
/*  77 */             ProjectSourceContainer projectSourceContainer; IJavaProject javaProject = JavaCore.create((IProject)resource);
/*  78 */             ISourceContainer container = null;
/*  79 */             if (javaProject.exists()) {
/*  80 */               JavaProjectSourceContainer javaProjectSourceContainer = new JavaProjectSourceContainer(javaProject);
/*  81 */             } else if (resource.exists()) {
/*  82 */               projectSourceContainer = new ProjectSourceContainer((IProject)resource, false);
/*     */             } 
/*  84 */             if (projectSourceContainer != null && !containers.contains(projectSourceContainer)) {
/*  85 */               containers.add(projectSourceContainer);
/*     */             }
/*     */           } 
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/*  94 */     return containers.<ISourceContainer>toArray(new ISourceContainer[containers.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void addSourceAttachment(IRuntimeClasspathEntry entry, List<ISourceContainer> containers) {
/* 105 */     String path = entry.getSourceAttachmentLocation();
/* 106 */     ISourceContainer container = null;
/* 107 */     if (path == null)
/*     */     {
/* 109 */       path = entry.getLocation();
/*     */     }
/* 111 */     if (path != null) {
/*     */       ExternalArchiveSourceContainer externalArchiveSourceContainer;
/* 113 */       File file = new File(path);
/* 114 */       if (file.isDirectory()) {
/* 115 */         IResource resource = entry.getResource();
/* 116 */         if (resource instanceof IContainer) {
/* 117 */           FolderSourceContainer folderSourceContainer = new FolderSourceContainer((IContainer)resource, false);
/*     */         } else {
/* 119 */           DirectorySourceContainer directorySourceContainer = new DirectorySourceContainer(file, false);
/*     */         } 
/*     */       } else {
/* 122 */         externalArchiveSourceContainer = new ExternalArchiveSourceContainer(path, true);
/*     */       } 
/* 124 */       if (!containers.contains(externalArchiveSourceContainer)) {
/* 125 */         containers.add(externalArchiveSourceContainer);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isSourceAttachmentEqual(IPackageFragmentRoot root, IRuntimeClasspathEntry entry) throws JavaModelException {
/* 146 */     IPath entryPath = entry.getSourceAttachmentPath();
/* 147 */     if (entryPath == null) {
/* 148 */       return true;
/*     */     }
/* 150 */     IPath rootPath = root.getSourceAttachmentPath();
/* 151 */     if (rootPath == null)
/*     */     {
/* 153 */       return false;
/*     */     }
/* 155 */     return rootPath.equals(entryPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IPackageFragmentRoot getPackageFragmentRoot(IRuntimeClasspathEntry entry) {
/* 168 */     IResource resource = entry.getResource();
/* 169 */     if (resource != null) {
/*     */       
/* 171 */       IProject project = resource.getProject();
/* 172 */       IJavaProject jp = JavaCore.create(project);
/*     */       try {
/* 174 */         if (project.isOpen() && jp.exists()) {
/* 175 */           IPackageFragmentRoot root = jp.findPackageFragmentRoot(resource.getFullPath());
/* 176 */           if (root != null && isSourceAttachmentEqual(root, entry))
/*     */           {
/* 178 */             return root;
/*     */           }
/*     */         } 
/* 181 */       } catch (JavaModelException e) {
/* 182 */         LaunchingPlugin.log((Throwable)e);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 188 */     IJavaModel model = JavaCore.create(ResourcesPlugin.getWorkspace().getRoot());
/* 189 */     IPath entryPath = entry.getPath();
/*     */     try {
/* 191 */       IJavaProject[] jps = model.getJavaProjects();
/* 192 */       for (int i = 0; i < jps.length; i++) {
/* 193 */         IJavaProject jp = jps[i];
/* 194 */         IProject p = jp.getProject();
/* 195 */         if (p.isOpen()) {
/* 196 */           IPackageFragmentRoot[] allRoots = jp.getPackageFragmentRoots();
/* 197 */           for (int j = 0; j < allRoots.length; j++) {
/* 198 */             IPackageFragmentRoot root = allRoots[j];
/* 199 */             if (root.getPath().equals(entryPath) && isSourceAttachmentEqual(root, entry))
/*     */             {
/* 201 */               return root;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 206 */     } catch (JavaModelException e) {
/* 207 */       LaunchingPlugin.log((Throwable)e);
/*     */     } 
/* 209 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void getPackageFragmentRootContainers(IRuntimeClasspathEntry entry, List<ISourceContainer> containers) {
/* 224 */     IJavaModel model = JavaCore.create(ResourcesPlugin.getWorkspace().getRoot());
/* 225 */     IPath entryPath = entry.getPath();
/* 226 */     boolean found = false;
/*     */     try {
/* 228 */       IJavaProject[] jps = model.getJavaProjects();
/* 229 */       for (int i = 0; i < jps.length; i++) {
/* 230 */         IJavaProject jp = jps[i];
/* 231 */         IProject p = jp.getProject();
/* 232 */         if (p.isOpen()) {
/* 233 */           IPackageFragmentRoot[] allRoots = jp.getPackageFragmentRoots();
/* 234 */           for (int j = 0; j < allRoots.length; j++) {
/* 235 */             IPackageFragmentRoot root = allRoots[j];
/* 236 */             if (root.getPath().equals(entryPath) && isSourceAttachmentEqual(root, entry)) {
/* 237 */               PackageFragmentRootSourceContainer container = new PackageFragmentRootSourceContainer(root);
/* 238 */               if (!containers.contains(container)) {
/* 239 */                 containers.add(container);
/* 240 */                 found = true;
/*     */               }
/*     */             
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 247 */     } catch (JavaModelException e) {
/* 248 */       LaunchingPlugin.log((Throwable)e);
/*     */     } 
/*     */     
/* 251 */     if (!found)
/* 252 */       addSourceAttachment(entry, containers); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\JavaSourceLookupUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */