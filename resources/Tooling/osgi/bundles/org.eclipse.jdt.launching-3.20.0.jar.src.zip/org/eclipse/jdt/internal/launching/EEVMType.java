/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.jdt.launching.AbstractVMInstallType;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstallType;
/*     */ import org.eclipse.jdt.launching.LibraryLocation;
/*     */ import org.eclipse.jdt.launching.environments.ExecutionEnvironmentDescription;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EEVMType
/*     */   extends AbstractVMInstallType
/*     */ {
/*     */   public static final String ID_EE_VM_TYPE = "org.eclipse.jdt.launching.EEVMType";
/*     */   public static final String VAR_EE_HOME = "${ee.home}";
/*  49 */   private static final String[] REQUIRED_PROPERTIES = new String[] {
/*  50 */       "-Dee.executable", 
/*  51 */       "-Dee.bootclasspath", 
/*  52 */       "-Dee.language.level", 
/*  53 */       "-Djava.home"
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL getJavadocLocation(Map<String, String> properties) {
/*  63 */     String javadoc = getProperty("-Dee.javadoc", properties);
/*  64 */     if (javadoc != null && javadoc.length() > 0) {
/*     */       try {
/*  66 */         URL url = new URL(javadoc);
/*  67 */         if ("file".equalsIgnoreCase(url.getProtocol())) {
/*  68 */           File file = new File(url.getFile());
/*  69 */           url = file.getCanonicalFile().toURI().toURL();
/*     */         } 
/*  71 */         return url;
/*  72 */       } catch (MalformedURLException e) {
/*  73 */         LaunchingPlugin.log(e);
/*  74 */         return null;
/*  75 */       } catch (IOException e) {
/*  76 */         LaunchingPlugin.log(e);
/*  77 */         return null;
/*     */       } 
/*     */     }
/*  80 */     String version = getProperty("-Dee.language.level", properties);
/*  81 */     if (version != null) {
/*  82 */       return StandardVMType.getDefaultJavadocLocation(version);
/*     */     }
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL getIndexLocation(Map<String, String> properties) {
/*  96 */     String index = getProperty("-Dee.index", properties);
/*  97 */     if (index != null && index.length() > 0) {
/*     */       try {
/*  99 */         URL url = new URL(index);
/* 100 */         if ("file".equalsIgnoreCase(url.getProtocol())) {
/* 101 */           File file = new File(url.getFile());
/* 102 */           url = file.getCanonicalFile().toURI().toURL();
/*     */         } 
/* 104 */         return url;
/* 105 */       } catch (MalformedURLException e) {
/* 106 */         LaunchingPlugin.log(e);
/* 107 */         return null;
/* 108 */       } catch (IOException e) {
/* 109 */         LaunchingPlugin.log(e);
/* 110 */         return null;
/*     */       } 
/*     */     }
/* 113 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IStatus validateDefinitionFile(ExecutionEnvironmentDescription description) {
/* 124 */     for (int i = 0; i < REQUIRED_PROPERTIES.length; i++) {
/* 125 */       String key = REQUIRED_PROPERTIES[i];
/* 126 */       String property = description.getProperty(key);
/* 127 */       if (property == null) {
/* 128 */         return (IStatus)new Status(4, LaunchingPlugin.getUniqueIdentifier(), NLS.bind(LaunchingMessages.EEVMType_1, (Object[])new String[] { key }));
/*     */       }
/*     */     } 
/* 131 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getProperty(String property, Map<String, String> properties) {
/* 143 */     return properties.get(property);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IVMInstall doCreateVMInstall(String id) {
/* 151 */     return (IVMInstall)new EEVMInstall((IVMInstallType)this, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File detectInstallLocation() {
/* 159 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LibraryLocation[] getDefaultLibraryLocations(File installLocationOrDefinitionFile) {
/* 167 */     return new LibraryLocation[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 175 */     return LaunchingMessages.EEVMType_2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateInstallLocation(File installLocation) {
/* 183 */     if (installLocation.exists()) {
/* 184 */       return (IStatus)new Status(1, "org.eclipse.jdt.launching", LaunchingMessages.EEVMType_4);
/*     */     }
/* 186 */     return (IStatus)new Status(4, "org.eclipse.jdt.launching", NLS.bind(LaunchingMessages.EEVMType_3, (Object[])new String[] { installLocation.getPath() }));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\EEVMType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */