/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import com.sun.jdi.VMDisconnectedException;
/*     */ import com.sun.jdi.VirtualMachine;
/*     */ import com.sun.jdi.connect.AttachingConnector;
/*     */ import com.sun.jdi.connect.Connector;
/*     */ import com.sun.jdi.connect.IllegalConnectorArgumentsException;
/*     */ import java.io.IOException;
/*     */ import java.net.ConnectException;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubProgressMonitor;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.model.IDebugTarget;
/*     */ import org.eclipse.jdi.Bootstrap;
/*     */ import org.eclipse.jdi.TimeoutException;
/*     */ import org.eclipse.jdt.debug.core.JDIDebugModel;
/*     */ import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
/*     */ import org.eclipse.jdt.launching.IVMConnector;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SocketAttachConnector
/*     */   implements IVMConnector
/*     */ {
/*     */   protected static AttachingConnector getAttachingConnector() throws CoreException {
/*  60 */     AttachingConnector connector = null;
/*  61 */     Iterator<AttachingConnector> iter = Bootstrap.virtualMachineManager().attachingConnectors().iterator();
/*  62 */     while (iter.hasNext()) {
/*  63 */       AttachingConnector lc = iter.next();
/*  64 */       if (lc.name().equals("com.sun.jdi.SocketAttach")) {
/*  65 */         connector = lc;
/*     */         break;
/*     */       } 
/*     */     } 
/*  69 */     if (connector == null) {
/*  70 */       abort(LaunchingMessages.SocketAttachConnector_Socket_attaching_connector_not_available_3, null, 114);
/*     */     }
/*  72 */     return connector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIdentifier() {
/*  80 */     return IJavaLaunchConfigurationConstants.ID_SOCKET_ATTACH_VM_CONNECTOR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  88 */     return LaunchingMessages.SocketAttachConnector_Standard__Socket_Attach__4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void abort(String message, Throwable exception, int code) throws CoreException {
/* 102 */     throw new CoreException(new Status(4, LaunchingPlugin.getUniqueIdentifier(), code, message, exception));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect(Map<String, String> arguments, IProgressMonitor monitor, ILaunch launch) throws CoreException {
/*     */     NullProgressMonitor nullProgressMonitor;
/* 110 */     if (monitor == null) {
/* 111 */       nullProgressMonitor = new NullProgressMonitor();
/*     */     }
/*     */     
/* 114 */     SubProgressMonitor subProgressMonitor = new SubProgressMonitor((IProgressMonitor)nullProgressMonitor, 1);
/* 115 */     subProgressMonitor.beginTask(LaunchingMessages.SocketAttachConnector_Connecting____1, 2);
/* 116 */     subProgressMonitor.subTask(LaunchingMessages.SocketAttachConnector_Configuring_connection____1);
/*     */     
/* 118 */     AttachingConnector connector = getAttachingConnector();
/* 119 */     String portNumberString = arguments.get("port");
/* 120 */     if (portNumberString == null) {
/* 121 */       abort(LaunchingMessages.SocketAttachConnector_Port_unspecified_for_remote_connection__2, null, 111);
/*     */     }
/* 123 */     String host = arguments.get("hostname");
/* 124 */     if (host == null) {
/* 125 */       abort(LaunchingMessages.SocketAttachConnector_Hostname_unspecified_for_remote_connection__4, null, 109);
/*     */     }
/* 127 */     Map<String, Connector.Argument> map = connector.defaultArguments();
/*     */     
/* 129 */     Connector.Argument param = map.get("hostname");
/* 130 */     param.setValue(host);
/* 131 */     param = map.get("port");
/* 132 */     param.setValue(portNumberString);
/*     */     
/* 134 */     String timeoutString = arguments.get("timeout");
/* 135 */     if (timeoutString != null) {
/* 136 */       param = map.get("timeout");
/* 137 */       param.setValue(timeoutString);
/*     */     } 
/*     */     
/* 140 */     ILaunchConfiguration configuration = launch.getLaunchConfiguration();
/* 141 */     boolean allowTerminate = false;
/* 142 */     if (configuration != null) {
/* 143 */       allowTerminate = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_ALLOW_TERMINATE, false);
/*     */     }
/* 145 */     subProgressMonitor.worked(1);
/* 146 */     subProgressMonitor.subTask(LaunchingMessages.SocketAttachConnector_Establishing_connection____2);
/*     */     try {
/* 148 */       VirtualMachine vm = connector.attach(map);
/* 149 */       String vmLabel = constructVMLabel(vm, host, portNumberString, configuration);
/* 150 */       IDebugTarget debugTarget = JDIDebugModel.newDebugTarget(launch, vm, vmLabel, null, allowTerminate, true);
/* 151 */       launch.addDebugTarget(debugTarget);
/* 152 */       subProgressMonitor.worked(1);
/* 153 */       subProgressMonitor.done();
/* 154 */     } catch (TimeoutException e) {
/* 155 */       abort(LaunchingMessages.SocketAttachConnector_0, (Throwable)e, 113);
/* 156 */     } catch (UnknownHostException e) {
/* 157 */       abort(NLS.bind(LaunchingMessages.SocketAttachConnector_Failed_to_connect_to_remote_VM_because_of_unknown_host____0___1, (Object[])new String[] { host }), e, 113);
/* 158 */     } catch (ConnectException e) {
/* 159 */       abort(LaunchingMessages.SocketAttachConnector_Failed_to_connect_to_remote_VM_as_connection_was_refused_2, e, 113);
/* 160 */     } catch (IOException e) {
/* 161 */       abort(LaunchingMessages.SocketAttachConnector_Failed_to_connect_to_remote_VM_1, e, 113);
/* 162 */     } catch (IllegalConnectorArgumentsException e) {
/* 163 */       abort(LaunchingMessages.SocketAttachConnector_Failed_to_connect_to_remote_VM_1, e, 113);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String constructVMLabel(VirtualMachine vm, String host, String port, ILaunchConfiguration configuration) {
/* 176 */     String name = null;
/*     */     try {
/* 178 */       name = vm.name();
/* 179 */     } catch (TimeoutException timeoutException) {
/*     */     
/* 181 */     } catch (VMDisconnectedException vMDisconnectedException) {}
/*     */ 
/*     */     
/* 184 */     if (name == null) {
/* 185 */       if (configuration == null) {
/* 186 */         name = "";
/*     */       } else {
/* 188 */         name = configuration.getName();
/*     */       } 
/*     */     }
/* 191 */     StringBuilder buffer = new StringBuilder(name);
/* 192 */     if (!"".equals(name)) {
/* 193 */       buffer.append(' ');
/*     */     }
/* 195 */     buffer.append('[');
/* 196 */     buffer.append(host);
/* 197 */     buffer.append(':');
/* 198 */     buffer.append(port);
/* 199 */     buffer.append(']');
/* 200 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Connector.Argument> getDefaultArguments() throws CoreException {
/* 208 */     Map<String, Connector.Argument> def = getAttachingConnector().defaultArguments();
/* 209 */     Connector.IntegerArgument arg = (Connector.IntegerArgument)def.get("port");
/* 210 */     arg.setValue(8000);
/* 211 */     return def;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getArgumentOrder() {
/* 219 */     List<String> list = new ArrayList<>(2);
/* 220 */     list.add("hostname");
/* 221 */     list.add("port");
/* 222 */     return list;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\SocketAttachConnector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */