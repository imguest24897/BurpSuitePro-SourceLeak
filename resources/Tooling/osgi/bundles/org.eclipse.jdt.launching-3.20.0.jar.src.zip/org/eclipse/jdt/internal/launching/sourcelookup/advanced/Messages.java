/*    */ package org.eclipse.jdt.internal.launching.sourcelookup.advanced;
/*    */ 
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Messages
/*    */   extends NLS
/*    */ {
/*    */   private static final String BUNDLE_NAME = "org.eclipse.jdt.internal.launching.sourcelookup.advanced.messages";
/*    */   public static String BackgroundProcessingJob_name;
/*    */   public static String BackgroundProcessingJob_failed;
/*    */   
/*    */   static {
/* 24 */     NLS.initializeMessages("org.eclipse.jdt.internal.launching.sourcelookup.advanced.messages", Messages.class);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\sourcelookup\advanced\Messages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */