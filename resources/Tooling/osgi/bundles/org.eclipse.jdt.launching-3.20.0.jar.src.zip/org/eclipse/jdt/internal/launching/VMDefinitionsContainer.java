/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.jdt.launching.AbstractVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstall2;
/*     */ import org.eclipse.jdt.launching.IVMInstallType;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.jdt.launching.LibraryLocation;
/*     */ import org.eclipse.jdt.launching.VMStandin;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VMDefinitionsContainer
/*     */ {
/* 114 */   private Map<IVMInstallType, List<IVMInstall>> fVMTypeToVMMap = new HashMap<>(10);
/* 115 */   private List<IVMInstall> fInvalidVMList = new ArrayList<>(10);
/* 116 */   private List<IVMInstall> fVMList = new ArrayList<>(10);
/*     */ 
/*     */   
/*     */   private String fDefaultVMInstallCompositeID;
/*     */ 
/*     */   
/*     */   private String fDefaultVMInstallConnectorTypeID;
/*     */ 
/*     */   
/*     */   private MultiStatus fStatus;
/*     */ 
/*     */ 
/*     */   
/*     */   public void addVM(IVMInstall vm) {
/* 130 */     if (!this.fVMList.contains(vm)) {
/* 131 */       IVMInstallType vmInstallType = vm.getVMInstallType();
/* 132 */       List<IVMInstall> vmList = this.fVMTypeToVMMap.get(vmInstallType);
/* 133 */       if (vmList == null) {
/* 134 */         vmList = new ArrayList<>(3);
/* 135 */         this.fVMTypeToVMMap.put(vmInstallType, vmList);
/*     */       } 
/* 137 */       vmList.add(vm);
/* 138 */       File installLocation = vm.getInstallLocation();
/* 139 */       if (installLocation == null || vmInstallType.validateInstallLocation(installLocation).getSeverity() == 4) {
/* 140 */         this.fInvalidVMList.add(vm);
/*     */       }
/* 142 */       this.fVMList.add(vm);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addVMList(List<IVMInstall> vmList) {
/* 157 */     Iterator<IVMInstall> iterator = vmList.iterator();
/* 158 */     while (iterator.hasNext()) {
/* 159 */       addVM(iterator.next());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<IVMInstallType, List<IVMInstall>> getVMTypeToVMMap() {
/* 171 */     return this.fVMTypeToVMMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<IVMInstall> getVMList() {
/* 182 */     return this.fVMList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<IVMInstall> getValidVMList() {
/* 192 */     List<IVMInstall> vms = getVMList();
/* 193 */     List<IVMInstall> resultList = new ArrayList<>(vms.size());
/* 194 */     resultList.addAll(vms);
/* 195 */     resultList.removeAll(this.fInvalidVMList);
/* 196 */     return resultList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultVMInstallCompositeID() {
/* 208 */     return this.fDefaultVMInstallCompositeID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultVMInstallCompositeID(String id) {
/* 220 */     this.fDefaultVMInstallCompositeID = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultVMInstallConnectorTypeID() {
/* 229 */     return this.fDefaultVMInstallConnectorTypeID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultVMInstallConnectorTypeID(String id) {
/* 238 */     this.fDefaultVMInstallConnectorTypeID = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAsXML() throws CoreException {
/* 253 */     Document doc = DebugPlugin.newDocument();
/* 254 */     Element config = doc.createElement("vmSettings");
/* 255 */     doc.appendChild(config);
/*     */ 
/*     */     
/* 258 */     if (getDefaultVMInstallCompositeID() != null) {
/* 259 */       config.setAttribute("defaultVM", getDefaultVMInstallCompositeID());
/*     */     }
/*     */ 
/*     */     
/* 263 */     if (getDefaultVMInstallConnectorTypeID() != null) {
/* 264 */       config.setAttribute("defaultVMConnector", getDefaultVMInstallConnectorTypeID());
/*     */     }
/*     */ 
/*     */     
/* 268 */     Set<IVMInstallType> vmInstallTypeSet = getVMTypeToVMMap().keySet();
/* 269 */     Iterator<IVMInstallType> keyIterator = vmInstallTypeSet.iterator();
/* 270 */     while (keyIterator.hasNext()) {
/* 271 */       IVMInstallType vmInstallType = keyIterator.next();
/* 272 */       Element vmTypeElement = vmTypeAsElement(doc, vmInstallType);
/* 273 */       config.appendChild(vmTypeElement);
/*     */     } 
/*     */ 
/*     */     
/* 277 */     return DebugPlugin.serializeDocument(doc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Element vmTypeAsElement(Document doc, IVMInstallType vmType) {
/* 290 */     Element element = doc.createElement("vmType");
/* 291 */     element.setAttribute("id", vmType.getId());
/*     */ 
/*     */     
/* 294 */     List<IVMInstall> vmList = getVMTypeToVMMap().get(vmType);
/* 295 */     Iterator<IVMInstall> vmIterator = vmList.iterator();
/* 296 */     while (vmIterator.hasNext()) {
/* 297 */       IVMInstall vm = vmIterator.next();
/* 298 */       Element vmElement = vmAsElement(doc, vm);
/* 299 */       element.appendChild(vmElement);
/*     */     } 
/*     */     
/* 302 */     return element;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Element vmAsElement(Document doc, IVMInstall vm) {
/* 315 */     Element element = doc.createElement("vm");
/* 316 */     element.setAttribute("id", vm.getId());
/* 317 */     element.setAttribute("name", vm.getName());
/*     */ 
/*     */     
/* 320 */     String installPath = "";
/* 321 */     File installLocation = vm.getInstallLocation();
/* 322 */     if (installLocation != null) {
/* 323 */       installPath = installLocation.getAbsolutePath();
/*     */     }
/* 325 */     element.setAttribute("path", installPath);
/*     */ 
/*     */     
/* 328 */     LibraryLocation[] libraryLocations = vm.getLibraryLocations();
/* 329 */     if (libraryLocations != null) {
/* 330 */       Element libLocationElement = libraryLocationsAsElement(doc, libraryLocations);
/* 331 */       element.appendChild(libLocationElement);
/*     */     } 
/*     */ 
/*     */     
/* 335 */     URL url = vm.getJavadocLocation();
/* 336 */     if (url != null) {
/* 337 */       element.setAttribute("javadocURL", url.toExternalForm());
/*     */     }
/*     */     
/* 340 */     if (vm instanceof IVMInstall2) {
/* 341 */       String vmArgs = ((IVMInstall2)vm).getVMArgs();
/* 342 */       if (vmArgs != null && vmArgs.length() > 0) {
/* 343 */         element.setAttribute("vmargs", vmArgs);
/*     */       }
/*     */     } else {
/* 346 */       String[] vmArgs = vm.getVMArguments();
/* 347 */       if (vmArgs != null && vmArgs.length > 0) {
/* 348 */         StringBuilder buffer = new StringBuilder();
/* 349 */         for (int i = 0; i < vmArgs.length; i++) {
/* 350 */           buffer.append(String.valueOf(vmArgs[i]) + " ");
/*     */         }
/* 352 */         element.setAttribute("vmargs", buffer.toString());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 357 */     if (vm instanceof AbstractVMInstall) {
/* 358 */       Map<String, String> attributes = ((AbstractVMInstall)vm).getAttributes();
/* 359 */       if (!attributes.isEmpty()) {
/* 360 */         Element attrElement = doc.createElement("attributeMap");
/* 361 */         Iterator<Map.Entry<String, String>> iterator = attributes.entrySet().iterator();
/* 362 */         while (iterator.hasNext()) {
/* 363 */           Map.Entry<String, String> entry = iterator.next();
/* 364 */           Element entryElement = doc.createElement("entry");
/* 365 */           entryElement.setAttribute("key", entry.getKey());
/* 366 */           entryElement.setAttribute("value", entry.getValue());
/* 367 */           attrElement.appendChild(entryElement);
/*     */         } 
/* 369 */         element.appendChild(attrElement);
/*     */       } 
/*     */     } 
/*     */     
/* 373 */     return element;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Element libraryLocationsAsElement(Document doc, LibraryLocation[] locations) {
/* 385 */     Element root = doc.createElement("libraryLocations");
/* 386 */     for (int i = 0; i < locations.length; i++) {
/* 387 */       Element element = doc.createElement("libraryLocation");
/* 388 */       element.setAttribute("jreJar", locations[i].getSystemLibraryPath().toString());
/* 389 */       element.setAttribute("jreSrc", locations[i].getSystemLibrarySourcePath().toString());
/* 390 */       IPath annotationsPath = locations[i].getExternalAnnotationsPath();
/* 391 */       if (annotationsPath != null && !annotationsPath.isEmpty()) {
/* 392 */         element.setAttribute("jreExternalAnns", annotationsPath.toString());
/*     */       }
/*     */       
/* 395 */       IPath packageRootPath = locations[i].getPackageRootPath();
/* 396 */       if (packageRootPath != null) {
/* 397 */         element.setAttribute("pkgRoot", packageRootPath.toString());
/*     */       }
/*     */       
/* 400 */       URL javadocURL = locations[i].getJavadocLocation();
/* 401 */       if (javadocURL != null) {
/* 402 */         element.setAttribute("jreJavadoc", javadocURL.toExternalForm());
/*     */       }
/* 404 */       URL indexURL = locations[i].getIndexLocation();
/* 405 */       if (indexURL != null) {
/* 406 */         element.setAttribute("jreIndex", indexURL.toExternalForm());
/*     */       }
/* 408 */       root.appendChild(element);
/*     */     } 
/* 410 */     return root;
/*     */   }
/*     */   
/*     */   public static VMDefinitionsContainer parseXMLIntoContainer(InputStream inputStream) throws IOException {
/* 414 */     VMDefinitionsContainer container = new VMDefinitionsContainer();
/* 415 */     parseXMLIntoContainer(inputStream, container);
/* 416 */     return container;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void parseXMLIntoContainer(InputStream inputStream, VMDefinitionsContainer container) throws IOException {
/* 446 */     Element config = null;
/*     */     try {
/* 448 */       Exception exception2, exception1 = null;
/*     */ 
/*     */     
/*     */     }
/* 452 */     catch (SAXException sAXException) {
/* 453 */       throw new IOException(LaunchingMessages.JavaRuntime_badFormat);
/* 454 */     } catch (ParserConfigurationException parserConfigurationException) {
/* 455 */       throw new IOException(LaunchingMessages.JavaRuntime_badFormat);
/*     */     } 
/*     */ 
/*     */     
/* 459 */     if (!config.getNodeName().equalsIgnoreCase("vmSettings")) {
/* 460 */       throw new IOException(LaunchingMessages.JavaRuntime_badFormat);
/*     */     }
/*     */ 
/*     */     
/* 464 */     container.setDefaultVMInstallCompositeID(config.getAttribute("defaultVM"));
/* 465 */     container.setDefaultVMInstallConnectorTypeID(config.getAttribute("defaultVMConnector"));
/*     */ 
/*     */     
/* 468 */     NodeList list = config.getChildNodes();
/* 469 */     int length = list.getLength();
/* 470 */     for (int i = 0; i < length; i++) {
/* 471 */       Node node = list.item(i);
/* 472 */       short type = node.getNodeType();
/* 473 */       if (type == 1) {
/* 474 */         Element vmTypeElement = (Element)node;
/* 475 */         if (vmTypeElement.getNodeName().equalsIgnoreCase("vmType")) {
/* 476 */           populateVMTypes(vmTypeElement, container);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void populateVMTypes(Element vmTypeElement, VMDefinitionsContainer container) {
/* 491 */     String id = vmTypeElement.getAttribute("id");
/* 492 */     IVMInstallType vmType = JavaRuntime.getVMInstallType(id);
/* 493 */     if (vmType != null) {
/*     */       
/* 495 */       NodeList vmNodeList = vmTypeElement.getElementsByTagName("vm");
/* 496 */       for (int i = 0; i < vmNodeList.getLength(); i++) {
/* 497 */         populateVMForType(vmType, (Element)vmNodeList.item(i), container);
/*     */       }
/*     */     } else {
/*     */       
/* 501 */       NodeList vmNodeList = vmTypeElement.getElementsByTagName("vm");
/* 502 */       for (int i = 0; i < vmNodeList.getLength(); i++) {
/* 503 */         Status status1; Element vmElement = (Element)vmNodeList.item(i);
/* 504 */         String installPath = vmElement.getAttribute("path");
/* 505 */         String name = vmElement.getAttribute("name");
/* 506 */         IStatus status = null;
/* 507 */         if (name != null) {
/* 508 */           status1 = new Status(1, "org.eclipse.jdt.launching", 
/* 509 */               NLS.bind(LaunchingMessages.VMDefinitionsContainer_0, (Object[])new String[] { name }));
/* 510 */         } else if (installPath != null) {
/* 511 */           status1 = new Status(1, "org.eclipse.jdt.launching", 
/* 512 */               NLS.bind(LaunchingMessages.VMDefinitionsContainer_0, (Object[])new String[] { installPath }));
/*     */         } else {
/* 514 */           status1 = new Status(1, "org.eclipse.jdt.launching", 
/* 515 */               NLS.bind(LaunchingMessages.VMDefinitionsContainer_2, (Object[])new String[] { id }));
/*     */         } 
/* 517 */         container.addStatus((IStatus)status1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void populateVMForType(IVMInstallType vmType, Element vmElement, VMDefinitionsContainer container) {
/* 531 */     String id = vmElement.getAttribute("id");
/* 532 */     if (id != null) {
/*     */ 
/*     */       
/* 535 */       String installPath = vmElement.getAttribute("path");
/* 536 */       String name = vmElement.getAttribute("name");
/* 537 */       if (name == null) {
/* 538 */         if (installPath == null) {
/* 539 */           container.addStatus((IStatus)new Status(4, "org.eclipse.jdt.launching", 
/* 540 */                 NLS.bind(LaunchingMessages.VMDefinitionsContainer_3, (Object[])new String[] { vmType.getName() })));
/*     */           return;
/*     */         } 
/* 543 */         container.addStatus((IStatus)new Status(4, "org.eclipse.jdt.launching", NLS.bind(LaunchingMessages.VMDefinitionsContainer_4, (Object[])new String[] { installPath })));
/*     */         return;
/*     */       } 
/* 546 */       if (installPath == null) {
/* 547 */         container.addStatus((IStatus)new Status(4, "org.eclipse.jdt.launching", 
/* 548 */               NLS.bind(LaunchingMessages.VMDefinitionsContainer_5, (Object[])new String[] { name })));
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 553 */       VMStandin vmStandin = new VMStandin(vmType, id);
/* 554 */       vmStandin.setName(name);
/* 555 */       File installLocation = new File(installPath);
/* 556 */       vmStandin.setInstallLocation(installLocation);
/* 557 */       String install = installLocation.getAbsolutePath();
/*     */       
/* 559 */       boolean changed = ("org.eclipse.jdt.internal.debug.ui.launcher.StandardVMType".equals(vmType.getId()) && 
/* 560 */         LaunchingPlugin.timeStampChanged(install));
/* 561 */       container.addVM((IVMInstall)vmStandin);
/*     */ 
/*     */ 
/*     */       
/* 565 */       if (!changed) {
/* 566 */         NodeList list = vmElement.getChildNodes();
/* 567 */         int length = list.getLength();
/* 568 */         for (int i = 0; i < length; i++) {
/* 569 */           Node node = list.item(i);
/* 570 */           short type = node.getNodeType();
/* 571 */           if (type == 1) {
/* 572 */             Element subElement = (Element)node;
/* 573 */             String subElementName = subElement.getNodeName();
/* 574 */             if (subElementName.equals("libraryLocation")) {
/* 575 */               LibraryLocation loc = getLibraryLocation(subElement);
/* 576 */               vmStandin.setLibraryLocations(new LibraryLocation[] { loc });
/* 577 */             } else if (subElementName.equals("libraryLocations")) {
/* 578 */               setLibraryLocations((IVMInstall)vmStandin, subElement);
/* 579 */             } else if (subElementName.equals("attributeMap")) {
/* 580 */               NodeList entries = subElement.getElementsByTagName("entry");
/* 581 */               for (int j = 0; j < entries.getLength(); j++) {
/* 582 */                 Node entryNode = entries.item(j);
/* 583 */                 if (entryNode instanceof Element) {
/* 584 */                   Element entryElement = (Element)entryNode;
/* 585 */                   String key = entryElement.getAttribute("key");
/* 586 */                   String value = entryElement.getAttribute("value");
/* 587 */                   if (key != null && value != null) {
/* 588 */                     vmStandin.setAttribute(key, value);
/*     */                   }
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 596 */           String externalForm = vmElement.getAttribute("javadocURL");
/* 597 */           if (externalForm != null && externalForm.length() > 0) {
/*     */             try {
/* 599 */               vmStandin.setJavadocLocation(new URL(externalForm));
/* 600 */             } catch (MalformedURLException e) {
/* 601 */               container.addStatus((IStatus)new Status(4, "org.eclipse.jdt.launching", 
/* 602 */                     NLS.bind(LaunchingMessages.VMDefinitionsContainer_6, (Object[])new String[] { name }), e));
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 608 */       String vmArgs = vmElement.getAttribute("vmargs");
/* 609 */       if (vmArgs != null && vmArgs.length() > 0) {
/* 610 */         vmStandin.setVMArgs(vmArgs);
/*     */       }
/*     */     } else {
/* 613 */       String installPath = vmElement.getAttribute("path");
/* 614 */       String name = vmElement.getAttribute("name");
/* 615 */       if (name != null) {
/* 616 */         container.addStatus((IStatus)new Status(4, "org.eclipse.jdt.launching", 
/* 617 */               NLS.bind(LaunchingMessages.VMDefinitionsContainer_7, (Object[])new String[] { name })));
/* 618 */       } else if (installPath != null) {
/* 619 */         container.addStatus((IStatus)new Status(4, "org.eclipse.jdt.launching", 
/* 620 */               NLS.bind(LaunchingMessages.VMDefinitionsContainer_7, (Object[])new String[] { installPath })));
/*     */       } else {
/* 622 */         container.addStatus((IStatus)new Status(4, "org.eclipse.jdt.launching", 
/* 623 */               NLS.bind(LaunchingMessages.VMDefinitionsContainer_9, (Object[])new String[] { vmType.getName() })));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static LibraryLocation getLibraryLocation(Element libLocationElement) {
/* 636 */     String jreJar = libLocationElement.getAttribute("jreJar");
/* 637 */     String jreSrc = libLocationElement.getAttribute("jreSrc");
/* 638 */     String pkgRoot = libLocationElement.getAttribute("pkgRoot");
/* 639 */     String jreJavadoc = libLocationElement.getAttribute("jreJavadoc");
/* 640 */     String jreIndex = libLocationElement.getAttribute("jreIndex");
/* 641 */     String externalAnns = libLocationElement.getAttribute("jreExternalAnns");
/*     */     
/* 643 */     URL javadocURL = null;
/* 644 */     if (jreJavadoc.length() == 0) {
/* 645 */       jreJavadoc = null;
/*     */     } else {
/*     */       try {
/* 648 */         javadocURL = new URL(jreJavadoc);
/* 649 */       } catch (MalformedURLException malformedURLException) {
/* 650 */         LaunchingPlugin.log("Library location javadoc element is specified incorrectly.");
/*     */       } 
/*     */     } 
/*     */     
/* 654 */     URL indexURL = null;
/* 655 */     if (jreIndex.length() == 0) {
/* 656 */       jreIndex = null;
/*     */     } else {
/*     */       try {
/* 659 */         indexURL = new URL(jreIndex);
/* 660 */       } catch (MalformedURLException malformedURLException) {
/* 661 */         LaunchingPlugin.log("Library location jre index element is specified incorrectly.");
/*     */       } 
/*     */     } 
/* 664 */     if (jreJar != null && jreSrc != null && pkgRoot != null) {
/* 665 */       return new LibraryLocation((IPath)new Path(jreJar), (IPath)new Path(jreSrc), (IPath)new Path(pkgRoot), javadocURL, indexURL, 
/* 666 */           (externalAnns == null) ? null : (IPath)new Path(externalAnns));
/*     */     }
/* 668 */     LaunchingPlugin.log("Library location element is specified incorrectly.");
/* 669 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setLibraryLocations(IVMInstall vm, Element libLocationsElement) {
/* 680 */     NodeList list = libLocationsElement.getChildNodes();
/* 681 */     int length = list.getLength();
/* 682 */     List<LibraryLocation> locations = new ArrayList<>(length);
/* 683 */     for (int i = 0; i < length; i++) {
/* 684 */       Node node = list.item(i);
/* 685 */       short type = node.getNodeType();
/* 686 */       if (type == 1) {
/* 687 */         Element libraryLocationElement = (Element)node;
/* 688 */         if (libraryLocationElement.getNodeName().equals("libraryLocation")) {
/* 689 */           locations.add(getLibraryLocation(libraryLocationElement));
/*     */         }
/*     */       } 
/*     */     } 
/* 693 */     vm.setLibraryLocations(locations.<LibraryLocation>toArray(new LibraryLocation[locations.size()]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeVM(IVMInstall vm) {
/* 702 */     this.fVMList.remove(vm);
/* 703 */     this.fInvalidVMList.remove(vm);
/* 704 */     List<IVMInstall> list = this.fVMTypeToVMMap.get(vm.getVMInstallType());
/* 705 */     if (list != null) {
/* 706 */       list.remove(vm);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addStatus(IStatus status) {
/* 711 */     if (this.fStatus == null) {
/* 712 */       this.fStatus = new MultiStatus("org.eclipse.jdt.launching", 0, LaunchingMessages.VMDefinitionsContainer_10, null);
/*     */     }
/* 714 */     this.fStatus.add(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus getStatus() {
/* 723 */     return (IStatus)this.fStatus;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\VMDefinitionsContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */