/*     */ package org.eclipse.jdt.launching;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.Launch;
/*     */ import org.eclipse.debug.core.model.IProcess;
/*     */ import org.eclipse.debug.core.model.IStreamsProxy;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingMessages;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractVMInstall
/*     */   implements IVMInstall, IVMInstall2, IVMInstall3
/*     */ {
/*     */   private IVMInstallType fType;
/*     */   private String fId;
/*     */   private String fName;
/*     */   private File fInstallLocation;
/*     */   private LibraryLocation[] fSystemLibraryDescriptions;
/*     */   private URL fJavadocLocation;
/*     */   private String fVMArgs;
/*  70 */   private Map<String, String> fAttributeMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String PREF_VM_INSTALL_SYSTEM_PROPERTY = "PREF_VM_INSTALL_SYSTEM_PROPERTY";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fNotify = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractVMInstall(IVMInstallType type, String id) {
/*  89 */     if (type == null) {
/*  90 */       throw new IllegalArgumentException(LaunchingMessages.vmInstall_assert_typeNotNull);
/*     */     }
/*  92 */     if (id == null) {
/*  93 */       throw new IllegalArgumentException(LaunchingMessages.vmInstall_assert_idNotNull);
/*     */     }
/*  95 */     this.fType = type;
/*  96 */     this.fId = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/* 105 */     return this.fId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 114 */     return this.fName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 123 */     if (!name.equals(this.fName)) {
/* 124 */       PropertyChangeEvent event = new PropertyChangeEvent(this, IVMInstallChangedListener.PROPERTY_NAME, this.fName, name);
/* 125 */       this.fName = name;
/* 126 */       if (this.fNotify) {
/* 127 */         JavaRuntime.fireVMChanged(event);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getInstallLocation() {
/* 138 */     return this.fInstallLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInstallLocation(File installLocation) {
/* 147 */     if (!installLocation.equals(this.fInstallLocation)) {
/* 148 */       PropertyChangeEvent event = new PropertyChangeEvent(this, IVMInstallChangedListener.PROPERTY_INSTALL_LOCATION, this.fInstallLocation, installLocation);
/* 149 */       this.fInstallLocation = installLocation;
/* 150 */       if (this.fNotify) {
/* 151 */         JavaRuntime.fireVMChanged(event);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IVMInstallType getVMInstallType() {
/* 162 */     return this.fType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IVMRunner getVMRunner(String mode) {
/* 170 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LibraryLocation[] getLibraryLocations() {
/* 178 */     return this.fSystemLibraryDescriptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLibraryLocations(LibraryLocation[] locations) {
/* 186 */     if (locations == this.fSystemLibraryDescriptions) {
/*     */       return;
/*     */     }
/* 189 */     LibraryLocation[] newLocations = locations;
/* 190 */     if (newLocations == null) {
/* 191 */       newLocations = getVMInstallType().getDefaultLibraryLocations(getInstallLocation());
/*     */     }
/* 193 */     LibraryLocation[] prevLocations = this.fSystemLibraryDescriptions;
/* 194 */     if (prevLocations == null) {
/* 195 */       prevLocations = getVMInstallType().getDefaultLibraryLocations(getInstallLocation());
/*     */     }
/*     */     
/* 198 */     if (newLocations.length == prevLocations.length) {
/* 199 */       int i = 0;
/* 200 */       boolean equal = true;
/* 201 */       while (i < newLocations.length && equal) {
/* 202 */         equal = newLocations[i].equals(prevLocations[i]);
/* 203 */         i++;
/*     */       } 
/* 205 */       if (equal) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 211 */     PropertyChangeEvent event = new PropertyChangeEvent(this, IVMInstallChangedListener.PROPERTY_LIBRARY_LOCATIONS, prevLocations, newLocations);
/* 212 */     this.fSystemLibraryDescriptions = locations;
/* 213 */     if (this.fNotify) {
/* 214 */       JavaRuntime.fireVMChanged(event);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getJavadocLocation() {
/* 223 */     return this.fJavadocLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJavadocLocation(URL url) {
/* 231 */     if (url == this.fJavadocLocation) {
/*     */       return;
/*     */     }
/* 234 */     if (url != null && this.fJavadocLocation != null && 
/* 235 */       url.toExternalForm().equals(this.fJavadocLocation.toExternalForm())) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 241 */     PropertyChangeEvent event = new PropertyChangeEvent(this, IVMInstallChangedListener.PROPERTY_JAVADOC_LOCATION, this.fJavadocLocation, url);
/* 242 */     this.fJavadocLocation = url;
/* 243 */     if (this.fNotify) {
/* 244 */       JavaRuntime.fireVMChanged(event);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setNotify(boolean notify) {
/* 255 */     this.fNotify = notify;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 264 */     if (object instanceof IVMInstall) {
/* 265 */       IVMInstall vm = (IVMInstall)object;
/* 266 */       return (getVMInstallType().equals(vm.getVMInstallType()) && 
/* 267 */         getId().equals(vm.getId()));
/*     */     } 
/* 269 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 278 */     return getVMInstallType().hashCode() + getId().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getVMArguments() {
/* 287 */     String args = getVMArgs();
/* 288 */     if (args == null) {
/* 289 */       return null;
/*     */     }
/* 291 */     ExecutionArguments ex = new ExecutionArguments(args, "");
/* 292 */     return ex.getVMArgumentsArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVMArguments(String[] vmArgs) {
/* 301 */     if (vmArgs == null) {
/* 302 */       setVMArgs(null);
/*     */     } else {
/* 304 */       StringBuilder buf = new StringBuilder();
/* 305 */       for (int i = 0; i < vmArgs.length; i++) {
/* 306 */         String string = vmArgs[i];
/* 307 */         buf.append(string);
/* 308 */         buf.append(" ");
/*     */       } 
/* 310 */       setVMArgs(buf.toString().trim());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getVMArgs() {
/* 319 */     return this.fVMArgs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVMArgs(String vmArgs) {
/* 327 */     if (this.fVMArgs == null) {
/* 328 */       if (vmArgs == null) {
/*     */         return;
/*     */       }
/*     */     }
/* 332 */     else if (this.fVMArgs.equals(vmArgs)) {
/*     */       return;
/*     */     } 
/*     */     
/* 336 */     PropertyChangeEvent event = new PropertyChangeEvent(this, IVMInstallChangedListener.PROPERTY_VM_ARGUMENTS, this.fVMArgs, vmArgs);
/* 337 */     this.fVMArgs = vmArgs;
/* 338 */     if (this.fNotify) {
/* 339 */       JavaRuntime.fireVMChanged(event);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJavaVersion() {
/* 349 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> evaluateSystemProperties(String[] properties, IProgressMonitor monitor) throws CoreException {
/*     */     NullProgressMonitor nullProgressMonitor;
/* 358 */     if (monitor == null) {
/* 359 */       nullProgressMonitor = new NullProgressMonitor();
/*     */     }
/* 361 */     Map<String, String> map = new HashMap<>();
/*     */ 
/*     */     
/* 364 */     boolean cached = true;
/* 365 */     IEclipsePreferences prefs = InstanceScope.INSTANCE.getNode("org.eclipse.jdt.launching");
/* 366 */     if (prefs != null) {
/* 367 */       for (int i = 0; i < properties.length; i++) {
/* 368 */         String property = properties[i];
/* 369 */         String key = getSystemPropertyKey(property);
/* 370 */         String value = prefs.get(key, null);
/* 371 */         if (value != null) {
/* 372 */           map.put(property, value);
/*     */         } else {
/* 374 */           map.clear();
/* 375 */           cached = false;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/* 380 */     if (!cached) {
/*     */       
/* 382 */       File file = LaunchingPlugin.getFileInPlugin((IPath)new Path("lib/launchingsupport.jar"));
/* 383 */       if (file != null && file.exists()) {
/* 384 */         VMRunnerConfiguration config = new VMRunnerConfiguration("org.eclipse.jdt.internal.launching.support.LegacySystemProperties", new String[] { file.getAbsolutePath() });
/* 385 */         IVMRunner runner = getVMRunner("run");
/* 386 */         if (runner == null) {
/* 387 */           abort(NLS.bind(LaunchingMessages.AbstractVMInstall_0, ""), null, 150);
/*     */         }
/* 389 */         if (!(this instanceof org.eclipse.jdt.internal.launching.Standard11xVM)) {
/* 390 */           config.setVMArguments(new String[] { "-Xmx16m" });
/*     */         }
/* 392 */         config.setProgramArguments(properties);
/* 393 */         Launch launch = new Launch(null, "run", null);
/* 394 */         if (nullProgressMonitor.isCanceled()) {
/* 395 */           return map;
/*     */         }
/* 397 */         nullProgressMonitor.beginTask(LaunchingMessages.AbstractVMInstall_1, 2);
/* 398 */         runner.run(config, (ILaunch)launch, (IProgressMonitor)nullProgressMonitor);
/* 399 */         IProcess[] processes = launch.getProcesses();
/* 400 */         if (processes.length != 1) {
/* 401 */           abort(NLS.bind(LaunchingMessages.AbstractVMInstall_0, runner), null, 150);
/*     */         }
/* 403 */         IProcess process = processes[0];
/*     */         try {
/* 405 */           int total = 0;
/* 406 */           int max = Platform.getPreferencesService().getInt(
/* 407 */               "org.eclipse.jdt.launching", 
/* 408 */               JavaRuntime.PREF_CONNECT_TIMEOUT, 
/* 409 */               20000, 
/* 410 */               null);
/* 411 */           while (!process.isTerminated()) {
/*     */             try {
/* 413 */               if (total > max) {
/*     */                 break;
/*     */               }
/* 416 */               Thread.sleep(50L);
/* 417 */               total += 50;
/* 418 */             } catch (InterruptedException interruptedException) {}
/*     */           } 
/*     */         } finally {
/*     */           
/* 422 */           if (!launch.isTerminated()) {
/* 423 */             launch.terminate();
/*     */           }
/*     */         } 
/* 426 */         nullProgressMonitor.worked(1);
/* 427 */         if (nullProgressMonitor.isCanceled()) {
/* 428 */           return map;
/*     */         }
/*     */         
/* 431 */         nullProgressMonitor.subTask(LaunchingMessages.AbstractVMInstall_3);
/* 432 */         IStreamsProxy streamsProxy = process.getStreamsProxy();
/* 433 */         String text = null;
/* 434 */         if (streamsProxy != null) {
/* 435 */           text = streamsProxy.getOutputStreamMonitor().getContents();
/*     */         }
/* 437 */         if (text != null && text.length() > 0) {
/*     */           try {
/* 439 */             DocumentBuilder parser = LaunchingPlugin.getParser();
/* 440 */             Document document = parser.parse(new ByteArrayInputStream(text.getBytes()));
/* 441 */             Element envs = document.getDocumentElement();
/* 442 */             NodeList list = envs.getChildNodes();
/* 443 */             int length = list.getLength();
/* 444 */             for (int i = 0; i < length; i++) {
/* 445 */               Node node = list.item(i);
/* 446 */               short type = node.getNodeType();
/* 447 */               if (type == 1) {
/* 448 */                 Element element = (Element)node;
/* 449 */                 if (element.getNodeName().equals("property")) {
/* 450 */                   String name = element.getAttribute("name");
/* 451 */                   String value = element.getAttribute("value");
/* 452 */                   map.put(name, value);
/*     */                 } 
/*     */               } 
/*     */             } 
/* 456 */           } catch (SAXException e) {
/* 457 */             String commandLine = process.getAttribute(IProcess.ATTR_CMDLINE);
/* 458 */             abort(NLS.bind(LaunchingMessages.AbstractVMInstall_4, commandLine), e, 150);
/* 459 */           } catch (IOException e) {
/* 460 */             String commandLine = process.getAttribute(IProcess.ATTR_CMDLINE);
/* 461 */             abort(NLS.bind(LaunchingMessages.AbstractVMInstall_4, commandLine), e, 150);
/*     */           } 
/*     */         } else {
/* 464 */           String commandLine = process.getAttribute(IProcess.ATTR_CMDLINE);
/* 465 */           abort(NLS.bind(LaunchingMessages.AbstractVMInstall_0, commandLine), null, 150);
/*     */         } 
/* 467 */         nullProgressMonitor.worked(1);
/*     */       } else {
/* 469 */         abort(NLS.bind(LaunchingMessages.AbstractVMInstall_0, file), null, 150);
/*     */       } 
/*     */       
/* 472 */       Iterator<String> keys = map.keySet().iterator();
/* 473 */       while (keys.hasNext()) {
/* 474 */         String property = keys.next();
/* 475 */         String value = map.get(property);
/* 476 */         String key = getSystemPropertyKey(property);
/* 477 */         prefs.put(key, value);
/*     */       } 
/*     */     } 
/* 480 */     nullProgressMonitor.done();
/* 481 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getSystemPropertyKey(String property) {
/* 492 */     StringBuilder buffer = new StringBuilder();
/* 493 */     buffer.append("PREF_VM_INSTALL_SYSTEM_PROPERTY");
/* 494 */     buffer.append(".");
/* 495 */     buffer.append(getVMInstallType().getId());
/* 496 */     buffer.append(".");
/* 497 */     buffer.append(getId());
/* 498 */     buffer.append(".");
/* 499 */     buffer.append(property);
/* 500 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void abort(String message, Throwable exception, int code) throws CoreException {
/* 515 */     throw new CoreException(new Status(4, 
/* 516 */           LaunchingPlugin.getUniqueIdentifier(), code, message, exception));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String key, String value) {
/* 529 */     String prevValue = this.fAttributeMap.remove(key);
/* 530 */     boolean notify = false;
/* 531 */     if (value == null) {
/* 532 */       if (prevValue != null && this.fNotify) {
/* 533 */         notify = true;
/*     */       }
/*     */     } else {
/* 536 */       this.fAttributeMap.put(key, value);
/* 537 */       if (this.fNotify && (prevValue == null || !prevValue.equals(value))) {
/* 538 */         notify = true;
/*     */       }
/*     */     } 
/* 541 */     if (notify) {
/* 542 */       PropertyChangeEvent event = new PropertyChangeEvent(this, key, prevValue, value);
/* 543 */       JavaRuntime.fireVMChanged(event);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAttribute(String key) {
/* 556 */     return this.fAttributeMap.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getAttributes() {
/* 568 */     return new HashMap<>(this.fAttributeMap);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\AbstractVMInstall.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */