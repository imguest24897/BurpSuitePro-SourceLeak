package org.eclipse.jdt.launching.sourcelookup.advanced;

import java.io.File;
import java.util.Map;
import java.util.function.Supplier;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.sourcelookup.ISourceContainer;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragmentRoot;

public interface IWorkspaceProjectDescriber {
  void describeProject(IJavaProject paramIJavaProject, IJavaProjectSourceDescription paramIJavaProjectSourceDescription) throws CoreException;
  
  public static interface IJavaProjectSourceDescription {
    void addLocation(File param1File);
    
    void addSourceContainerFactory(Supplier<ISourceContainer> param1Supplier);
    
    void addDependencies(Map<File, IPackageFragmentRoot> param1Map);
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\sourcelookup\advanced\IWorkspaceProjectDescriber.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */