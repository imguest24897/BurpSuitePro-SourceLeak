/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry;
/*     */ import org.eclipse.jdt.launching.IRuntimeClasspathEntryResolver;
/*     */ import org.eclipse.jdt.launching.IRuntimeClasspathEntryResolver2;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuntimeClasspathEntryResolver
/*     */   implements IRuntimeClasspathEntryResolver2
/*     */ {
/*     */   private IConfigurationElement fConfigurationElement;
/*     */   private IRuntimeClasspathEntryResolver fDelegate;
/*     */   
/*     */   public RuntimeClasspathEntryResolver(IConfigurationElement element) {
/*  41 */     this.fConfigurationElement = element;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IRuntimeClasspathEntry[] resolveRuntimeClasspathEntry(IRuntimeClasspathEntry entry, ILaunchConfiguration configuration) throws CoreException {
/*  49 */     return getResolver().resolveRuntimeClasspathEntry(entry, configuration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IRuntimeClasspathEntryResolver getResolver() throws CoreException {
/*  58 */     if (this.fDelegate == null) {
/*  59 */       this.fDelegate = (IRuntimeClasspathEntryResolver)this.fConfigurationElement.createExecutableExtension("class");
/*     */     }
/*  61 */     return this.fDelegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getVariableName() {
/*  69 */     return this.fConfigurationElement.getAttribute("variable");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContainerId() {
/*  77 */     return this.fConfigurationElement.getAttribute("container");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRuntimeClasspathEntryId() {
/*  86 */     return this.fConfigurationElement.getAttribute("runtimeClasspathEntryId");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IVMInstall resolveVMInstall(IClasspathEntry entry) throws CoreException {
/*  94 */     return getResolver().resolveVMInstall(entry);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IRuntimeClasspathEntry[] resolveRuntimeClasspathEntry(IRuntimeClasspathEntry entry, IJavaProject project) throws CoreException {
/* 102 */     return getResolver().resolveRuntimeClasspathEntry(entry, project);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IRuntimeClasspathEntry[] resolveRuntimeClasspathEntry(IRuntimeClasspathEntry entry, IJavaProject project, boolean excludeTestCode) throws CoreException {
/* 110 */     return getResolver().resolveRuntimeClasspathEntry(entry, project, excludeTestCode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVMInstallReference(IClasspathEntry entry) {
/*     */     try {
/* 119 */       IRuntimeClasspathEntryResolver resolver = getResolver();
/* 120 */       if (resolver instanceof IRuntimeClasspathEntryResolver2) {
/* 121 */         IRuntimeClasspathEntryResolver2 resolver2 = (IRuntimeClasspathEntryResolver2)resolver;
/* 122 */         return resolver2.isVMInstallReference(entry);
/*     */       } 
/* 124 */       return (resolver.resolveVMInstall(entry) != null);
/* 125 */     } catch (CoreException coreException) {
/* 126 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\RuntimeClasspathEntryResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */