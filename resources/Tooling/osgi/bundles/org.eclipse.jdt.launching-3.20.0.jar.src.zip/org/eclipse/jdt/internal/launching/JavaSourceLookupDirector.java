/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Objects;
/*    */ import java.util.Set;
/*    */ import org.eclipse.debug.core.sourcelookup.AbstractSourceLookupDirector;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceLookupParticipant;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.ProjectSourceContainer;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.WorkspaceSourceContainer;
/*    */ import org.eclipse.jdt.internal.core.AbstractClassFile;
/*    */ import org.eclipse.jdt.launching.sourcelookup.containers.JavaSourceLookupParticipant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaSourceLookupDirector
/*    */   extends AbstractSourceLookupDirector
/*    */ {
/* 38 */   private static Set<String> fFilteredTypes = new HashSet<>(); static {
/* 39 */     fFilteredTypes.add(ProjectSourceContainer.TYPE_ID);
/* 40 */     fFilteredTypes.add(WorkspaceSourceContainer.TYPE_ID);
/*    */     
/* 42 */     fFilteredTypes.add("org.eclipse.debug.ui.containerType.workingSet");
/*    */   }
/*    */ 
/*    */   
/*    */   public void initializeParticipants() {
/* 47 */     addParticipants(new ISourceLookupParticipant[] { (ISourceLookupParticipant)new JavaSourceLookupParticipant() });
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supportsSourceContainerType(ISourceContainerType type) {
/* 52 */     return !fFilteredTypes.contains(type.getId());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equalSourceElements(Object o1, Object o2) {
/* 57 */     if (o1 instanceof AbstractClassFile && o2 instanceof AbstractClassFile) {
/* 58 */       AbstractClassFile c1 = (AbstractClassFile)o1;
/* 59 */       AbstractClassFile c2 = (AbstractClassFile)o2;
/* 60 */       String pathIdentifier1 = c1.getPathIdentifier();
/* 61 */       String pathIdentifier2 = c2.getPathIdentifier();
/* 62 */       return Objects.equals(pathIdentifier1, pathIdentifier2);
/*    */     } 
/* 64 */     return super.equalSourceElements(o1, o2);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\JavaSourceLookupDirector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */