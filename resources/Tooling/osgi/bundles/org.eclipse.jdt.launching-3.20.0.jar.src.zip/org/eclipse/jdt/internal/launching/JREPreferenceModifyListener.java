/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.core.runtime.preferences.IPreferenceNodeVisitor;
/*     */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*     */ import org.eclipse.core.runtime.preferences.PreferenceModifyListener;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.jdt.launching.VMStandin;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JREPreferenceModifyListener
/*     */   extends PreferenceModifyListener
/*     */ {
/*     */   class Visitor
/*     */     implements IPreferenceNodeVisitor
/*     */   {
/*     */     public boolean visit(IEclipsePreferences node) throws BackingStoreException {
/*  46 */       if (node.name().equals(LaunchingPlugin.getUniqueIdentifier())) {
/*  47 */         String jresXML = node.get(JavaRuntime.PREF_VM_XML, null);
/*  48 */         if (jresXML != null) {
/*  49 */           VMDefinitionsContainer vms = new VMDefinitionsContainer();
/*  50 */           String pref = InstanceScope.INSTANCE.getNode("org.eclipse.jdt.launching").get(JavaRuntime.PREF_VM_XML, "");
/*     */           
/*  52 */           Map<String, IVMInstall> names = new HashMap<>();
/*  53 */           Set<String> ids = new HashSet<>();
/*  54 */           if (pref.length() > 0) {
/*     */             try {
/*  56 */               VMDefinitionsContainer container = VMDefinitionsContainer.parseXMLIntoContainer(new ByteArrayInputStream(pref.getBytes("UTF8")));
/*  57 */               List<IVMInstall> validVMList = container.getValidVMList();
/*  58 */               Iterator<IVMInstall> iterator = validVMList.iterator();
/*  59 */               while (iterator.hasNext()) {
/*  60 */                 IVMInstall vm = iterator.next();
/*  61 */                 names.put(vm.getName(), vm);
/*  62 */                 ids.add(vm.getId());
/*  63 */                 vms.addVM(vm);
/*     */               } 
/*  65 */               vms.setDefaultVMInstallCompositeID(container.getDefaultVMInstallCompositeID());
/*  66 */               vms.setDefaultVMInstallConnectorTypeID(container.getDefaultVMInstallConnectorTypeID());
/*  67 */             } catch (IOException e) {
/*  68 */               LaunchingPlugin.log(e);
/*  69 */               return false;
/*     */             } 
/*     */           }
/*     */           
/*     */           try {
/*  74 */             ByteArrayInputStream inputStream = new ByteArrayInputStream(jresXML.getBytes("UTF8"));
/*  75 */             VMDefinitionsContainer container = VMDefinitionsContainer.parseXMLIntoContainer(inputStream);
/*  76 */             List<IVMInstall> validVMList = container.getValidVMList();
/*  77 */             Iterator<IVMInstall> iterator = validVMList.iterator();
/*  78 */             while (iterator.hasNext()) {
/*  79 */               VMStandin vMStandin; IVMInstall vm = iterator.next();
/*  80 */               IVMInstall existing = names.get(vm.getName());
/*  81 */               if (existing != null) {
/*     */                 
/*  83 */                 vms.removeVM(existing);
/*  84 */                 ids.remove(existing.getId());
/*     */               } 
/*  86 */               boolean collision = ids.contains(vm.getId());
/*  87 */               if (collision) {
/*     */                 
/*  89 */                 long unique = System.currentTimeMillis();
/*  90 */                 while (ids.contains(String.valueOf(unique))) {
/*  91 */                   unique++;
/*     */                 }
/*  93 */                 vMStandin = new VMStandin(vm, String.valueOf(unique));
/*  94 */                 ids.add(vMStandin.getId());
/*     */               } 
/*  96 */               vms.addVM((IVMInstall)vMStandin);
/*     */             } 
/*     */             
/*  99 */             String defaultVMInstallCompositeID = container.getDefaultVMInstallCompositeID();
/* 100 */             validVMList = vms.getValidVMList();
/* 101 */             iterator = validVMList.iterator();
/* 102 */             while (iterator.hasNext()) {
/* 103 */               IVMInstall vm = iterator.next();
/* 104 */               if (JavaRuntime.getCompositeIdFromVM(vm).equals(defaultVMInstallCompositeID)) {
/* 105 */                 vms.setDefaultVMInstallCompositeID(defaultVMInstallCompositeID);
/*     */                 break;
/*     */               } 
/*     */             } 
/* 109 */           } catch (IOException e) {
/* 110 */             LaunchingPlugin.log(e);
/* 111 */             return false;
/*     */           } 
/*     */           try {
/* 114 */             String xml = vms.getAsXML();
/* 115 */             node.put(JavaRuntime.PREF_VM_XML, xml);
/* 116 */           } catch (CoreException e) {
/* 117 */             LaunchingPlugin.log((Throwable)e);
/* 118 */             return false;
/*     */           } 
/*     */         } 
/* 121 */         return false;
/*     */       } 
/* 123 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IEclipsePreferences preApply(IEclipsePreferences node) {
/*     */     try {
/* 132 */       JavaRuntime.getVMInstallTypes();
/* 133 */       node.accept(new Visitor());
/* 134 */     } catch (BackingStoreException e) {
/* 135 */       LaunchingPlugin.log((Throwable)e);
/*     */     } 
/* 137 */     return node;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\JREPreferenceModifyListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */