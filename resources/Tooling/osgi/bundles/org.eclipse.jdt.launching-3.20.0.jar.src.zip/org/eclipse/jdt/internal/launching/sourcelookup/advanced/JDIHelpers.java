/*     */ package org.eclipse.jdt.internal.launching.sourcelookup.advanced;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import org.eclipse.debug.core.DebugException;
/*     */ import org.eclipse.debug.core.model.IStackFrame;
/*     */ import org.eclipse.jdt.debug.core.IJavaObject;
/*     */ import org.eclipse.jdt.debug.core.IJavaReferenceType;
/*     */ import org.eclipse.jdt.debug.core.IJavaStackFrame;
/*     */ import org.eclipse.jdt.debug.core.IJavaType;
/*     */ import org.eclipse.jdt.debug.core.IJavaValue;
/*     */ import org.eclipse.jdt.debug.core.IJavaVariable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JDIHelpers
/*     */   implements IJDIHelpers
/*     */ {
/*     */   public static final String STRATA_ID = "jdt";
/*     */   
/*     */   public File getClassesLocation(Object element) throws DebugException {
/*  44 */     IJavaReferenceType declaringType = null;
/*  45 */     if (element instanceof IJavaStackFrame) {
/*  46 */       IJavaStackFrame stackFrame = (IJavaStackFrame)element;
/*  47 */       declaringType = stackFrame.getReferenceType();
/*  48 */     } else if (element instanceof IJavaObject) {
/*  49 */       IJavaType javaType = ((IJavaObject)element).getJavaType();
/*  50 */       if (javaType instanceof IJavaReferenceType) {
/*  51 */         declaringType = (IJavaReferenceType)javaType;
/*     */       }
/*  53 */     } else if (element instanceof IJavaReferenceType) {
/*  54 */       declaringType = (IJavaReferenceType)element;
/*  55 */     } else if (element instanceof IJavaVariable) {
/*  56 */       IJavaVariable javaVariable = (IJavaVariable)element;
/*  57 */       IJavaType javaType = ((IJavaValue)javaVariable.getValue()).getJavaType();
/*  58 */       if (javaType instanceof IJavaReferenceType) {
/*  59 */         declaringType = (IJavaReferenceType)javaType;
/*     */       }
/*     */     } 
/*     */     
/*  63 */     if (declaringType != null) {
/*  64 */       String[] locations = declaringType.getSourceNames("jdt");
/*     */       
/*  66 */       if (locations == null || locations.length < 2) {
/*  67 */         return null;
/*     */       }
/*     */       
/*     */       try {
/*  71 */         URL url = new URL(locations[1]);
/*  72 */         if ("file".equals(url.getProtocol())) {
/*  73 */           return (new File(url.getPath())).toPath().normalize().toFile();
/*     */         }
/*     */       }
/*  76 */       catch (MalformedURLException malformedURLException) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  81 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourcePath(Object element) throws DebugException {
/*  86 */     IJavaReferenceType declaringType = null;
/*  87 */     if (element instanceof IJavaStackFrame) {
/*  88 */       IJavaStackFrame stackFrame = (IJavaStackFrame)element;
/*     */       
/*  90 */       String sourcePath = stackFrame.getSourcePath("jdt");
/*  91 */       if (sourcePath != null) {
/*  92 */         return sourcePath;
/*     */       }
/*     */       
/*  95 */       declaringType = stackFrame.getReferenceType();
/*  96 */     } else if (element instanceof IJavaObject) {
/*  97 */       IJavaType javaType = ((IJavaObject)element).getJavaType();
/*  98 */       if (javaType instanceof IJavaReferenceType) {
/*  99 */         declaringType = (IJavaReferenceType)javaType;
/*     */       }
/* 101 */     } else if (element instanceof IJavaReferenceType) {
/* 102 */       declaringType = (IJavaReferenceType)element;
/* 103 */     } else if (element instanceof IJavaVariable) {
/* 104 */       IJavaType javaType = ((IJavaVariable)element).getJavaType();
/* 105 */       if (javaType instanceof IJavaReferenceType) {
/* 106 */         declaringType = (IJavaReferenceType)javaType;
/*     */       }
/*     */     } 
/*     */     
/* 110 */     if (declaringType != null) {
/* 111 */       String[] sourcePaths = declaringType.getSourcePaths("jdt");
/*     */       
/* 113 */       if (sourcePaths != null && sourcePaths.length > 0 && sourcePaths[0] != null) {
/* 114 */         return sourcePaths[0];
/*     */       }
/*     */       
/* 117 */       return generateSourceName(declaringType.getName());
/*     */     } 
/*     */     
/* 120 */     return null;
/*     */   }
/*     */   
/* 123 */   private static final IStackFrame[] EMPTY_STACK = new IStackFrame[0];
/*     */   
/*     */   private IStackFrame[] getStackFrames(Object element) throws DebugException {
/* 126 */     if (element instanceof IStackFrame) {
/* 127 */       IStackFrame[] frames = ((IStackFrame)element).getThread().getStackFrames();
/* 128 */       for (int i = 0; i < frames.length - 1; i++) {
/* 129 */         if (frames[i] == element) {
/* 130 */           return Arrays.<IStackFrame>copyOfRange(frames, i + 1, frames.length);
/*     */         }
/*     */       } 
/*     */     } 
/* 134 */     return EMPTY_STACK;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterable<File> getStackFramesClassesLocations(Object element) throws DebugException {
/* 139 */     final IStackFrame[] stack = getStackFrames(element);
/*     */     
/* 141 */     return new Iterable<File>()
/*     */       {
/*     */         public Iterator<File> iterator() {
/* 144 */           return Arrays.<IStackFrame>stream(stack)
/* 145 */             .map(frame -> getClassesLocation(frame))
/* 146 */             .filter(frameLocation -> (frameLocation != null))
/* 147 */             .iterator();
/*     */         }
/*     */ 
/*     */         
/*     */         File getClassesLocation(IStackFrame frame) {
/*     */           try {
/* 153 */             return JDIHelpers.this.getClassesLocation(frame);
/*     */           }
/* 155 */           catch (DebugException debugException) {
/* 156 */             return null;
/*     */           } 
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   private static String generateSourceName(String qualifiedTypeName) {
/* 164 */     int index = qualifiedTypeName.indexOf('$');
/* 165 */     if (index >= 0) {
/* 166 */       qualifiedTypeName = qualifiedTypeName.substring(0, index);
/*     */     }
/* 168 */     return String.valueOf(qualifiedTypeName.replace('.', File.separatorChar)) + ".java";
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\sourcelookup\advanced\JDIHelpers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */