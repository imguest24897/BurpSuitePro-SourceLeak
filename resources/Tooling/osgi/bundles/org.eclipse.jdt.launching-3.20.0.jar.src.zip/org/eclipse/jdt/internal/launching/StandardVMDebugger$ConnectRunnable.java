/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import com.sun.jdi.VirtualMachine;
/*     */ import com.sun.jdi.connect.Connector;
/*     */ import com.sun.jdi.connect.ListeningConnector;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConnectRunnable
/*     */   implements Runnable
/*     */ {
/*  93 */   private VirtualMachine fVirtualMachine = null;
/*  94 */   private ListeningConnector fConnector = null;
/*  95 */   private Map<String, Connector.Argument> fConnectionMap = null;
/*  96 */   private Exception fException = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectRunnable(ListeningConnector connector, Map<String, Connector.Argument> map) {
/* 106 */     this.fConnector = connector;
/* 107 */     this.fConnectionMap = map;
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/* 113 */       this.fVirtualMachine = this.fConnector.accept(this.fConnectionMap);
/* 114 */     } catch (IOException|com.sun.jdi.connect.IllegalConnectorArgumentsException e) {
/* 115 */       this.fException = e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VirtualMachine getVirtualMachine() {
/* 125 */     return this.fVirtualMachine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Exception getException() {
/* 134 */     return this.fException;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\StandardVMDebugger$ConnectRunnable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */