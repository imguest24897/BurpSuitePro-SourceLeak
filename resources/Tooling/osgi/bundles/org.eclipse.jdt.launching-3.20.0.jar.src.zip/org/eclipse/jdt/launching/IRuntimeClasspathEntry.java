package org.eclipse.jdt.launching;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.IJavaProject;

public interface IRuntimeClasspathEntry {
  public static final int PROJECT = 1;
  
  public static final int ARCHIVE = 2;
  
  public static final int VARIABLE = 3;
  
  public static final int CONTAINER = 4;
  
  public static final int OTHER = 5;
  
  public static final int STANDARD_CLASSES = 1;
  
  public static final int BOOTSTRAP_CLASSES = 2;
  
  public static final int USER_CLASSES = 3;
  
  public static final int MODULE_PATH = 4;
  
  public static final int CLASS_PATH = 5;
  
  public static final int PATCH_MODULE = 6;
  
  int getType();
  
  String getMemento() throws CoreException;
  
  IPath getPath();
  
  IResource getResource();
  
  IPath getSourceAttachmentPath();
  
  void setSourceAttachmentPath(IPath paramIPath);
  
  IPath getSourceAttachmentRootPath();
  
  void setSourceAttachmentRootPath(IPath paramIPath);
  
  IPath getExternalAnnotationsPath();
  
  void setExternalAnnotationsPath(IPath paramIPath);
  
  int getClasspathProperty();
  
  void setClasspathProperty(int paramInt);
  
  String getLocation();
  
  String getSourceAttachmentLocation();
  
  String getSourceAttachmentRootLocation();
  
  String getVariableName();
  
  IClasspathEntry getClasspathEntry();
  
  IJavaProject getJavaProject();
  
  boolean isAutomodule();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\IRuntimeClasspathEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */