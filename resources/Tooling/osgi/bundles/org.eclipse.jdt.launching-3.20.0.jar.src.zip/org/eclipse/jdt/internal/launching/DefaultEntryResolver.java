/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.ILaunchConfiguration;
/*    */ import org.eclipse.jdt.core.IClasspathEntry;
/*    */ import org.eclipse.jdt.core.IJavaProject;
/*    */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry;
/*    */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry2;
/*    */ import org.eclipse.jdt.launching.IRuntimeClasspathEntryResolver;
/*    */ import org.eclipse.jdt.launching.IVMInstall;
/*    */ import org.eclipse.jdt.launching.JavaRuntime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultEntryResolver
/*    */   implements IRuntimeClasspathEntryResolver
/*    */ {
/*    */   public IRuntimeClasspathEntry[] resolveRuntimeClasspathEntry(IRuntimeClasspathEntry entry, ILaunchConfiguration configuration) throws CoreException {
/* 38 */     IRuntimeClasspathEntry2 entry2 = (IRuntimeClasspathEntry2)entry;
/*    */     
/* 40 */     IRuntimeClasspathEntry[] entries = entry2.getRuntimeClasspathEntries(configuration);
/* 41 */     List<IRuntimeClasspathEntry> resolved = new ArrayList<>();
/* 42 */     for (int i = 0; i < entries.length; i++) {
/* 43 */       IRuntimeClasspathEntry[] temp = JavaRuntime.resolveRuntimeClasspathEntry(entries[i], configuration);
/* 44 */       for (int j = 0; j < temp.length; j++) {
/* 45 */         resolved.add(temp[j]);
/*    */       }
/*    */     } 
/* 48 */     return resolved.<IRuntimeClasspathEntry>toArray(new IRuntimeClasspathEntry[resolved.size()]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IRuntimeClasspathEntry[] resolveRuntimeClasspathEntry(IRuntimeClasspathEntry entry, IJavaProject project) throws CoreException {
/* 55 */     return resolveRuntimeClasspathEntry(entry, project, false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IRuntimeClasspathEntry[] resolveRuntimeClasspathEntry(IRuntimeClasspathEntry entry, IJavaProject project, boolean excludeTestCode) throws CoreException {
/* 66 */     IRuntimeClasspathEntry2 entry2 = (IRuntimeClasspathEntry2)entry;
/* 67 */     IRuntimeClasspathEntry[] entries = entry2.getRuntimeClasspathEntries(excludeTestCode);
/* 68 */     List<IRuntimeClasspathEntry> resolved = new ArrayList<>();
/* 69 */     for (int i = 0; i < entries.length; i++) {
/* 70 */       IRuntimeClasspathEntry[] temp = JavaRuntime.resolveRuntimeClasspathEntry(entries[i], project, excludeTestCode);
/* 71 */       for (int j = 0; j < temp.length; j++) {
/* 72 */         resolved.add(temp[j]);
/*    */       }
/*    */     } 
/* 75 */     return resolved.<IRuntimeClasspathEntry>toArray(new IRuntimeClasspathEntry[resolved.size()]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IVMInstall resolveVMInstall(IClasspathEntry entry) throws CoreException {
/* 83 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\DefaultEntryResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */