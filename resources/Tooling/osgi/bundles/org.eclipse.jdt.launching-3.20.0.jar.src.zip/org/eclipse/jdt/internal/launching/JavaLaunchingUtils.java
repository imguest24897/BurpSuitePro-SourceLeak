/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.eclipse.debug.core.ILaunch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaLaunchingUtils
/*    */ {
/*    */   public static final int MAX_LAUNCH_CONFIG_NAME_LENGTH = 10;
/*    */   
/*    */   public static File createFileForArgument(String timeStamp, File processTempFilesDir, String launchConfigName, String optionalString) {
/* 41 */     if (launchConfigName.length() > 10) {
/* 42 */       launchConfigName = launchConfigName.substring(0, 10);
/*    */     }
/* 44 */     String child = String.format(".temp-" + 
/* 45 */         optionalString, new Object[] { launchConfigName, timeStamp });
/* 46 */     File argumentsFile = new File(processTempFilesDir, child);
/* 47 */     return argumentsFile;
/*    */   }
/*    */   
/*    */   public static String getLaunchTimeStamp(ILaunch launch) {
/* 51 */     String timeStamp = launch.getAttribute("org.eclipse.debug.core.launch.timestamp");
/* 52 */     if (timeStamp == null) {
/* 53 */       timeStamp = Long.toString(System.currentTimeMillis());
/*    */     }
/* 55 */     return timeStamp;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\JavaLaunchingUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */