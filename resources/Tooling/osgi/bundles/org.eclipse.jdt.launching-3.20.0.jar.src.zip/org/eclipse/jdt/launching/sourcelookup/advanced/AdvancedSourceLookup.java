/*     */ package org.eclipse.jdt.launching.sourcelookup.advanced;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.debug.core.DebugException;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.model.IPersistableSourceLocator;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.internal.launching.sourcelookup.advanced.AdvancedSourceLookupSupport;
/*     */ import org.eclipse.jdt.internal.launching.sourcelookup.advanced.IJDIHelpers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdvancedSourceLookup
/*     */ {
/*  45 */   private static final IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
/*     */   
/*     */   public static boolean isSourceProject(IJavaProject project) throws JavaModelException {
/*     */     byte b;
/*     */     int i;
/*     */     IPackageFragmentRoot[] arrayOfIPackageFragmentRoot;
/*  51 */     for (i = (arrayOfIPackageFragmentRoot = project.getPackageFragmentRoots()).length, b = 0; b < i; ) { IPackageFragmentRoot fragment = arrayOfIPackageFragmentRoot[b];
/*  52 */       if (fragment.getKind() == 1)
/*  53 */         return true; 
/*     */       b++; }
/*     */     
/*  56 */     return false;
/*     */   }
/*     */   
/*     */   public static Map<File, IPackageFragmentRoot> getClasspath(IJavaProject project) throws JavaModelException {
/*  60 */     Map<File, IPackageFragmentRoot> classpath = new LinkedHashMap<>(); byte b; int i; IPackageFragmentRoot[] arrayOfIPackageFragmentRoot;
/*  61 */     for (i = (arrayOfIPackageFragmentRoot = project.getPackageFragmentRoots()).length, b = 0; b < i; ) { IPackageFragmentRoot fragment = arrayOfIPackageFragmentRoot[b];
/*  62 */       if (fragment.getKind() == 2) {
/*  63 */         File classpathLocation = null;
/*  64 */         if (fragment.isExternal()) {
/*  65 */           classpathLocation = fragment.getPath().toFile();
/*     */         } else {
/*  67 */           IResource resource = fragment.getResource();
/*  68 */           if (resource != null) {
/*  69 */             IPath location = resource.getLocation();
/*  70 */             if (location != null) {
/*  71 */               classpathLocation = location.toFile();
/*     */             }
/*     */           } 
/*     */         } 
/*  75 */         if (classpathLocation != null)
/*  76 */           classpath.put(classpathLocation, fragment); 
/*     */       } 
/*     */       b++; }
/*     */     
/*  80 */     return classpath;
/*     */   }
/*     */   
/*     */   public static Set<File> getOutputDirectories(IJavaProject project) throws JavaModelException {
/*  84 */     Set<File> locations = new LinkedHashSet<>();
/*  85 */     addWorkspaceLocation(locations, project.getOutputLocation()); byte b; int i; IClasspathEntry[] arrayOfIClasspathEntry;
/*  86 */     for (i = (arrayOfIClasspathEntry = project.getRawClasspath()).length, b = 0; b < i; ) { IClasspathEntry cpe = arrayOfIClasspathEntry[b];
/*  87 */       if (cpe.getEntryKind() == 3 && cpe.getOutputLocation() != null)
/*  88 */         addWorkspaceLocation(locations, cpe.getOutputLocation()); 
/*     */       b++; }
/*     */     
/*  91 */     return locations;
/*     */   }
/*     */   
/*     */   private static void addWorkspaceLocation(Collection<File> locations, IPath workspacePath) {
/*  95 */     IResource resource = root.findMember(workspacePath);
/*  96 */     if (resource == null) {
/*     */       return;
/*     */     }
/*  99 */     IPath location = resource.getLocation();
/* 100 */     if (location == null) {
/*     */       return;
/*     */     }
/* 103 */     locations.add(location.toFile());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getJavaagentString() {
/* 110 */     return AdvancedSourceLookupSupport.getJavaagentString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File getClassesLocation(Object fElement) throws DebugException {
/* 117 */     return IJDIHelpers.INSTANCE.getClassesLocation(fElement);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IPersistableSourceLocator createSourceLocator(String type, ILaunchConfiguration configuration) throws CoreException {
/* 124 */     return AdvancedSourceLookupSupport.createSourceLocator(type, configuration);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\sourcelookup\advanced\AdvancedSourceLookup.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */