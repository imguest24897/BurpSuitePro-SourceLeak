/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.ProjectScope;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.preferences.IPreferencesService;
/*     */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*     */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.compiler.CompilationParticipant;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstall2;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.jdt.launching.environments.IExecutionEnvironment;
/*     */ import org.eclipse.jdt.launching.environments.IExecutionEnvironmentsManager;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EECompilationParticipant
/*     */   extends CompilationParticipant
/*     */ {
/*  54 */   private Set<IJavaProject> fCleaned = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActive(IJavaProject project) {
/*  61 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanStarting(IJavaProject project) {
/*  69 */     super.cleanStarting(project);
/*  70 */     this.fCleaned.add(project);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void buildFinished(IJavaProject project) {
/*  78 */     super.buildFinished(project);
/*  79 */     if (this.fCleaned.remove(project)) {
/*  80 */       String eeId = null;
/*  81 */       IPath container = null;
/*     */       try {
/*  83 */         IClasspathEntry[] rawClasspath = project.getRawClasspath();
/*  84 */         for (int j = 0; j < rawClasspath.length; j++) {
/*  85 */           IClasspathEntry entry = rawClasspath[j];
/*  86 */           if (entry.getEntryKind() == 5) {
/*  87 */             IPath path = entry.getPath();
/*  88 */             if (JavaRuntime.JRE_CONTAINER.equals(path.segment(0))) {
/*  89 */               container = path;
/*  90 */               eeId = JREContainerInitializer.getExecutionEnvironmentId(path);
/*     */             } 
/*     */           } 
/*     */         } 
/*  94 */       } catch (CoreException e) {
/*  95 */         LaunchingPlugin.log((Throwable)e);
/*     */       } 
/*  97 */       if (container != null && eeId != null) {
/*  98 */         IVMInstall vm = JREContainerInitializer.resolveVM(container);
/*  99 */         validateEnvironment(eeId, project, vm);
/* 100 */         if (vm instanceof IVMInstall2) {
/* 101 */           eeId = getCompilerCompliance((IVMInstall2)vm);
/* 102 */           if (eeId != null) {
/* 103 */             validateCompliance(eeId, project, vm);
/*     */           }
/*     */         }
/*     */       
/* 107 */       } else if (container != null) {
/* 108 */         IVMInstall vm = JREContainerInitializer.resolveVM(container);
/* 109 */         if (vm instanceof IVMInstall2) {
/* 110 */           eeId = getCompilerCompliance((IVMInstall2)vm);
/* 111 */           if (eeId != null) {
/* 112 */             validateCompliance(eeId, project, vm);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isReleaseFlagEnabled(String eeId, String compId, IJavaProject project) {
/* 133 */     boolean releaseFlagEnabled = false;
/* 134 */     if (JavaCore.compareJavaVersions("9", eeId) <= 0 && 
/* 135 */       JavaCore.compareJavaVersions("1.6", compId) <= 0) {
/* 136 */       String releaseVal = project.getOption("org.eclipse.jdt.core.compiler.release", true);
/* 137 */       if ("enabled".equals(releaseVal)) {
/* 138 */         releaseFlagEnabled = true;
/*     */       }
/*     */     } 
/*     */     
/* 142 */     return releaseFlagEnabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateCompliance(String eeId, IJavaProject project, IVMInstall vm) {
/* 156 */     String id = project.getOption("org.eclipse.jdt.core.compiler.compliance", true);
/* 157 */     if (!eeId.equals(id))
/*     */     {
/* 159 */       if (!isReleaseFlagEnabled(eeId, id, project)) {
/* 160 */         IExecutionEnvironmentsManager manager = JavaRuntime.getExecutionEnvironmentsManager();
/* 161 */         IExecutionEnvironment[] environments = manager.getExecutionEnvironments();
/* 162 */         IExecutionEnvironment finalEnvironment = null; byte b; int i; IExecutionEnvironment[] arrayOfIExecutionEnvironment1;
/* 163 */         for (i = (arrayOfIExecutionEnvironment1 = environments).length, b = 0; b < i; ) { IExecutionEnvironment environment = arrayOfIExecutionEnvironment1[b];
/* 164 */           if (environment.getId().indexOf(id) != -1) {
/* 165 */             finalEnvironment = environment; break;
/*     */           } 
/*     */           b++; }
/*     */         
/* 169 */         if (finalEnvironment != null && 
/* 170 */           !finalEnvironment.isStrictlyCompatible(vm)) {
/* 171 */           String message = NLS.bind(LaunchingMessages.LaunchingPlugin_39, (Object[])new String[] { id, eeId });
/* 172 */           int sev = getSeverityLevel(JavaRuntime.PREF_COMPILER_COMPLIANCE_DOES_NOT_MATCH_JRE, project.getProject());
/* 173 */           if (sev != -1) {
/* 174 */             createProblemMarker(project, message, sev, JavaRuntime.JRE_COMPILER_COMPLIANCE_MARKER, LaunchingMessages.LaunchingPlugin_40);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateEnvironment(String id, IJavaProject project, IVMInstall vm) {
/* 190 */     IExecutionEnvironmentsManager manager = JavaRuntime.getExecutionEnvironmentsManager();
/* 191 */     IExecutionEnvironment environment = manager.getEnvironment(id);
/* 192 */     if (environment != null) {
/* 193 */       if (vm == null) {
/* 194 */         String message = NLS.bind(
/* 195 */             LaunchingMessages.LaunchingPlugin_38, 
/* 196 */             (Object[])new String[] { environment.getId() });
/* 197 */         createJREContainerProblem(project, message, 2);
/* 198 */       } else if (!environment.isStrictlyCompatible(vm)) {
/*     */ 
/*     */         
/* 201 */         IVMInstall[] compatibleVMs = environment.getCompatibleVMs();
/* 202 */         int exact = 0;
/* 203 */         for (int i = 0; i < compatibleVMs.length; i++) {
/* 204 */           if (environment.isStrictlyCompatible(compatibleVMs[i])) {
/* 205 */             exact++;
/*     */           }
/*     */         } 
/* 208 */         String message = null;
/* 209 */         if (exact == 0) {
/* 210 */           if (vm instanceof IVMInstall2) {
/* 211 */             String eeId = getCompilerCompliance((IVMInstall2)vm);
/* 212 */             String compId = project.getOption("org.eclipse.jdt.core.compiler.compliance", true);
/* 213 */             if (eeId != null && isReleaseFlagEnabled(eeId, compId, project)) {
/*     */               return;
/*     */             }
/*     */           } 
/* 217 */           message = NLS.bind(
/* 218 */               LaunchingMessages.LaunchingPlugin_35, 
/* 219 */               (Object[])new String[] { environment.getId() });
/*     */         } else {
/* 221 */           message = NLS.bind(
/* 222 */               LaunchingMessages.LaunchingPlugin_36, 
/* 223 */               (Object[])new String[] { environment.getId() });
/*     */         } 
/* 225 */         int sev = getSeverityLevel(JavaRuntime.PREF_STRICTLY_COMPATIBLE_JRE_NOT_AVAILABLE, project.getProject());
/* 226 */         if (sev != -1) {
/* 227 */           createJREContainerProblem(project, message, sev);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static String getCompilerCompliance(IVMInstall2 vMInstall) {
/* 234 */     String version = vMInstall.getJavaVersion();
/* 235 */     if (version == null)
/* 236 */       return null; 
/* 237 */     if (version.startsWith("20"))
/* 238 */       return "20"; 
/* 239 */     if (version.startsWith("19"))
/* 240 */       return "19"; 
/* 241 */     if (version.startsWith("18"))
/* 242 */       return "18"; 
/* 243 */     if (version.startsWith("17"))
/* 244 */       return "17"; 
/* 245 */     if (version.startsWith("16"))
/* 246 */       return "16"; 
/* 247 */     if (version.startsWith("15"))
/* 248 */       return "15"; 
/* 249 */     if (version.startsWith("14"))
/* 250 */       return "14"; 
/* 251 */     if (version.startsWith("13"))
/* 252 */       return "13"; 
/* 253 */     if (version.startsWith("12"))
/* 254 */       return "12"; 
/* 255 */     if (version.startsWith("11"))
/* 256 */       return "11"; 
/* 257 */     if (version.startsWith("10"))
/* 258 */       return "10"; 
/* 259 */     if (version.startsWith("9"))
/* 260 */       return "9"; 
/* 261 */     if (version.startsWith("1.8"))
/* 262 */       return "1.8"; 
/* 263 */     if (version.startsWith("1.7"))
/* 264 */       return "1.7"; 
/* 265 */     if (version.startsWith("1.6"))
/* 266 */       return "1.6"; 
/* 267 */     if (version.startsWith("1.5"))
/* 268 */       return "1.5"; 
/* 269 */     if (version.startsWith("1.4"))
/* 270 */       return "1.4"; 
/* 271 */     if (version.startsWith("1.3"))
/* 272 */       return "1.3"; 
/* 273 */     if (version.startsWith("1.2"))
/* 274 */       return "1.3"; 
/* 275 */     if (version.startsWith("1.1")) {
/* 276 */       return "1.3";
/*     */     }
/* 278 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getSeverityLevel(String prefkey, IProject project) {
/* 293 */     IPreferencesService service = Platform.getPreferencesService();
/* 294 */     List<IScopeContext> scopes = new ArrayList<>();
/* 295 */     scopes.add(InstanceScope.INSTANCE);
/* 296 */     if (project != null) {
/* 297 */       scopes.add(new ProjectScope(project));
/*     */     }
/* 299 */     String value = service.getString("org.eclipse.jdt.launching", prefkey, null, scopes.<IScopeContext>toArray(new IScopeContext[scopes.size()]));
/* 300 */     if (value == null) {
/* 301 */       value = InstanceScope.INSTANCE.getNode("org.eclipse.jdt.launching").get(prefkey, null);
/*     */     }
/* 303 */     if ("error".equals(value)) {
/* 304 */       return 2;
/*     */     }
/* 306 */     if ("warning".equals(value)) {
/* 307 */       return 1;
/*     */     }
/* 309 */     if ("info".equals(value)) {
/* 310 */       return 0;
/*     */     }
/* 312 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void createJREContainerProblem(IJavaProject javaProject, String message, int severity) {
/*     */     try {
/* 323 */       Map<String, Object> attributes = Map.of("message", message, 
/* 324 */           "severity", Integer.valueOf(severity), 
/* 325 */           "location", LaunchingMessages.LaunchingPlugin_37);
/*     */       
/* 327 */       javaProject.getProject().createMarker(JavaRuntime.JRE_CONTAINER_MARKER, attributes);
/* 328 */     } catch (CoreException coreException) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void createProblemMarker(IJavaProject javaProject, String message, int severity, String problemId, String location) {
/*     */     try {
/* 345 */       Map<String, Object> attributes = new HashMap<>();
/* 346 */       attributes.put("message", message);
/* 347 */       attributes.put("severity", Integer.valueOf(severity));
/* 348 */       attributes.put("location", location);
/*     */       
/* 350 */       javaProject.getProject().createMarker(problemId, attributes);
/* 351 */     } catch (CoreException coreException) {
/*     */       return;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\EECompilationParticipant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */