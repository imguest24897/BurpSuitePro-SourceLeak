/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.jdt.core.IAccessRule;
/*     */ import org.eclipse.jdt.core.IClasspathAttribute;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry;
/*     */ import org.eclipse.jdt.launching.IRuntimeClasspathEntryResolver2;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.jdt.launching.LibraryLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JRERuntimeClasspathEntryResolver
/*     */   implements IRuntimeClasspathEntryResolver2
/*     */ {
/*  45 */   private static IAccessRule[] EMPTY_RULES = new IAccessRule[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IRuntimeClasspathEntry[] resolveRuntimeClasspathEntry(IRuntimeClasspathEntry entry, ILaunchConfiguration configuration) throws CoreException {
/*  52 */     IVMInstall jre = null;
/*  53 */     if (entry.getType() == 4 && entry.getPath().segmentCount() > 1) {
/*     */       
/*  55 */       jre = JREContainerInitializer.resolveVM(entry.getPath());
/*     */     } else {
/*     */       
/*  58 */       jre = JavaRuntime.computeVMInstall(configuration);
/*     */     } 
/*  60 */     if (jre == null)
/*     */     {
/*  62 */       return new IRuntimeClasspathEntry[0];
/*     */     }
/*  64 */     return resolveLibraryLocations(jre, entry.getClasspathProperty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IRuntimeClasspathEntry[] resolveRuntimeClasspathEntry(IRuntimeClasspathEntry entry, IJavaProject project) throws CoreException {
/*  72 */     IVMInstall jre = null;
/*  73 */     if (entry.getType() == 4 && entry.getPath().segmentCount() > 1) {
/*     */       
/*  75 */       jre = JREContainerInitializer.resolveVM(entry.getPath());
/*     */     } else {
/*     */       
/*  78 */       jre = JavaRuntime.getVMInstall(project);
/*     */     } 
/*  80 */     if (jre == null)
/*     */     {
/*  82 */       return new IRuntimeClasspathEntry[0];
/*     */     }
/*  84 */     return resolveLibraryLocations(jre, entry.getClasspathProperty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IRuntimeClasspathEntry[] resolveLibraryLocations(IVMInstall vm, int kind) {
/*  94 */     LibraryLocation[] libs = vm.getLibraryLocations();
/*  95 */     LibraryLocation[] defaultLibs = vm.getVMInstallType().getDefaultLibraryLocations(vm.getInstallLocation());
/*  96 */     boolean overrideJavadoc = false;
/*  97 */     if (libs == null) {
/*     */       
/*  99 */       libs = defaultLibs;
/* 100 */       overrideJavadoc = true;
/* 101 */     } else if (!isSameArchives(libs, defaultLibs)) {
/*     */       
/* 103 */       kind = 2;
/*     */     } 
/* 105 */     if (kind == 2) {
/* 106 */       File vmInstallLocation = vm.getInstallLocation();
/* 107 */       if (vmInstallLocation != null) {
/* 108 */         LibraryInfo libraryInfo = LaunchingPlugin.getLibraryInfo(vmInstallLocation.getAbsolutePath());
/* 109 */         if (libraryInfo != null) {
/*     */ 
/*     */           
/* 112 */           String[] extensionDirsArray = libraryInfo.getExtensionDirs();
/* 113 */           Set<String> extensionDirsSet = new HashSet<>();
/* 114 */           for (int j = 0; j < extensionDirsArray.length; j++) {
/* 115 */             extensionDirsSet.add(extensionDirsArray[j]);
/*     */           }
/* 117 */           List<IRuntimeClasspathEntry> list = new ArrayList<>(libs.length);
/* 118 */           for (int k = 0; k < libs.length; k++) {
/* 119 */             LibraryLocation location = libs[k];
/* 120 */             IPath libraryPath = location.getSystemLibraryPath();
/* 121 */             String dir = libraryPath.toFile().getParent();
/*     */             
/* 123 */             if (!extensionDirsSet.contains(dir)) {
/* 124 */               list.add(resolveLibraryLocation(vm, location, kind, overrideJavadoc));
/*     */             }
/*     */           } 
/* 127 */           return list.<IRuntimeClasspathEntry>toArray(new IRuntimeClasspathEntry[list.size()]);
/*     */         } 
/*     */       } 
/*     */     } 
/* 131 */     List<IRuntimeClasspathEntry> resolvedEntries = new ArrayList<>(libs.length);
/* 132 */     for (int i = 0; i < libs.length; i++) {
/* 133 */       IPath systemLibraryPath = libs[i].getSystemLibraryPath();
/* 134 */       if (systemLibraryPath.toFile().exists()) {
/* 135 */         resolvedEntries.add(resolveLibraryLocation(vm, libs[i], kind, overrideJavadoc));
/*     */       }
/*     */     } 
/* 138 */     return resolvedEntries.<IRuntimeClasspathEntry>toArray(new IRuntimeClasspathEntry[resolvedEntries.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSameArchives(LibraryLocation[] libs, LibraryLocation[] defaultLibs) {
/* 151 */     if (libs.length != defaultLibs.length) {
/* 152 */       return false;
/*     */     }
/* 154 */     IPath dpath = null, lpath = null;
/* 155 */     for (int i = 0; i < defaultLibs.length; i++) {
/* 156 */       dpath = defaultLibs[i].getSystemLibraryPath();
/* 157 */       lpath = libs[i].getSystemLibraryPath();
/* 158 */       if (Platform.getOS().equals("win32")) {
/*     */         
/* 160 */         if (!dpath.removeTrailingSeparator().toOSString().equalsIgnoreCase(lpath.removeTrailingSeparator().toOSString())) {
/* 161 */           return false;
/*     */         }
/* 163 */       } else if (!dpath.equals(lpath)) {
/* 164 */         return false;
/*     */       } 
/*     */     } 
/* 167 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IVMInstall resolveVMInstall(IClasspathEntry entry) {
/* 175 */     switch (entry.getEntryKind()) {
/*     */       case 4:
/* 177 */         if (entry.getPath().segment(0).equals("JRE_LIB")) {
/* 178 */           return JavaRuntime.getDefaultVMInstall();
/*     */         }
/*     */         break;
/*     */       case 5:
/* 182 */         if (entry.getPath().segment(0).equals(JavaRuntime.JRE_CONTAINER)) {
/* 183 */           return JREContainerInitializer.resolveVM(entry.getPath());
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 189 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVMInstallReference(IClasspathEntry entry) {
/* 197 */     switch (entry.getEntryKind()) {
/*     */       case 4:
/* 199 */         if (entry.getPath().segment(0).equals("JRE_LIB")) {
/* 200 */           return true;
/*     */         }
/*     */         break;
/*     */       case 5:
/* 204 */         if (entry.getPath().segment(0).equals(JavaRuntime.JRE_CONTAINER)) {
/* 205 */           return true;
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 211 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IRuntimeClasspathEntry resolveLibraryLocation(IVMInstall vm, LibraryLocation location, int kind, boolean overrideJavaDoc) {
/* 225 */     IPath libraryPath = location.getSystemLibraryPath();
/* 226 */     URL javadocLocation = location.getJavadocLocation();
/* 227 */     if (overrideJavaDoc && javadocLocation == null) {
/* 228 */       javadocLocation = vm.getJavadocLocation();
/*     */     }
/* 230 */     IClasspathAttribute[] attributes = null;
/* 231 */     if (javadocLocation == null) {
/* 232 */       attributes = new IClasspathAttribute[0];
/*     */     } else {
/* 234 */       attributes = new IClasspathAttribute[] { JavaCore.newClasspathAttribute("javadoc_location", javadocLocation.toExternalForm()) };
/*     */     } 
/* 236 */     IClasspathEntry cpe = JavaCore.newLibraryEntry(libraryPath, location.getSystemLibraryPath(), location.getPackageRootPath(), EMPTY_RULES, attributes, false);
/* 237 */     IRuntimeClasspathEntry resolved = new RuntimeClasspathEntry(cpe);
/* 238 */     resolved.setClasspathProperty(kind);
/* 239 */     IPath sourcePath = location.getSystemLibrarySourcePath();
/* 240 */     if (sourcePath != null && !sourcePath.isEmpty()) {
/* 241 */       resolved.setSourceAttachmentPath(sourcePath);
/* 242 */       resolved.setSourceAttachmentRootPath(location.getPackageRootPath());
/*     */     } 
/* 244 */     return resolved;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\JRERuntimeClasspathEntryResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */