/*     */ package org.eclipse.jdt.internal.launching.sourcelookup.advanced;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileHashing
/*     */ {
/*  39 */   private static final HasherImpl HASHER = new HasherImpl(5000);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Hasher hasher() {
/*  45 */     return HASHER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Hasher newHasher() {
/*  52 */     return new HasherImpl(HASHER);
/*     */   }
/*     */ 
/*     */   
/*     */   private static class CacheKey
/*     */   {
/*     */     public final File file;
/*     */     private final long length;
/*     */     private final long lastModified;
/*     */     
/*     */     public CacheKey(File file) throws IOException {
/*  63 */       this.file = file.getCanonicalFile();
/*  64 */       this.length = file.length();
/*  65 */       this.lastModified = file.lastModified();
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  70 */       int hash = 17;
/*  71 */       hash = hash * 31 + this.file.hashCode();
/*  72 */       hash = hash * 31 + (int)this.length;
/*  73 */       hash = hash * 31 + (int)this.lastModified;
/*  74 */       return hash;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/*  79 */       if (obj == this) {
/*  80 */         return true;
/*     */       }
/*  82 */       if (!(obj instanceof CacheKey)) {
/*  83 */         return false;
/*     */       }
/*  85 */       CacheKey other = (CacheKey)obj;
/*  86 */       return (this.file.equals(other.file) && this.length == other.length && this.lastModified == other.lastModified);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class HashCode {
/*     */     private final byte[] bytes;
/*     */     
/*     */     public HashCode(byte[] bytes) {
/*  94 */       this.bytes = bytes;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  99 */       return Arrays.hashCode(this.bytes);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 104 */       if (obj == this) {
/* 105 */         return true;
/*     */       }
/* 107 */       if (!(obj instanceof HashCode)) {
/* 108 */         return false;
/*     */       }
/* 110 */       return Arrays.equals(this.bytes, ((HashCode)obj).bytes);
/*     */     }
/*     */ 
/*     */     
/*     */     public final String toString() {
/* 115 */       StringBuilder sb = new StringBuilder(2 * this.bytes.length); byte b; int i; byte[] arrayOfByte;
/* 116 */       for (i = (arrayOfByte = this.bytes).length, b = 0; b < i; ) { byte b1 = arrayOfByte[b];
/* 117 */         sb.append(hexDigits[b1 >> 4 & 0xF]).append(hexDigits[b1 & 0xF]); b++; }
/*     */       
/* 119 */       return sb.toString();
/*     */     }
/*     */     
/* 122 */     private static final char[] hexDigits = "0123456789abcdef".toCharArray();
/*     */   }
/*     */   
/*     */   public static interface Hasher { Object hash(File param1File); }
/*     */   
/*     */   private static class HasherImpl implements Hasher {
/*     */     private final Map<FileHashing.CacheKey, FileHashing.HashCode> cache;
/*     */     
/*     */     public HasherImpl(final int cacheSize) {
/* 131 */       this.cache = new LinkedHashMap<FileHashing.CacheKey, FileHashing.HashCode>()
/*     */         {
/*     */           protected boolean removeEldestEntry(Map.Entry<FileHashing.CacheKey, FileHashing.HashCode> eldest) {
/* 134 */             return (size() > cacheSize);
/*     */           }
/*     */         };
/*     */     }
/*     */     
/*     */     public HasherImpl(HasherImpl initial) {
/* 140 */       this.cache = new LinkedHashMap<>(initial.cache);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object hash(File file) {
/* 145 */       if (file == null || !file.isFile()) {
/* 146 */         return null;
/*     */       }
/*     */       try {
/* 149 */         FileHashing.CacheKey cacheKey = new FileHashing.CacheKey(file);
/* 150 */         synchronized (this.cache) {
/* 151 */           FileHashing.HashCode hashCode1 = this.cache.get(cacheKey);
/* 152 */           if (hashCode1 != null) {
/* 153 */             return hashCode1;
/*     */           }
/*     */         } 
/*     */         
/* 157 */         FileHashing.HashCode hashCode = FileHashing.sha1(file);
/* 158 */         synchronized (this.cache) {
/* 159 */           this.cache.put(cacheKey, hashCode);
/*     */         } 
/* 161 */         return hashCode;
/*     */       }
/* 163 */       catch (IOException iOException) {
/* 164 */         return null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static HashCode sha1(File file) throws IOException {
/*     */     MessageDigest digest;
/*     */     try {
/* 173 */       digest = MessageDigest.getInstance("SHA1");
/*     */     }
/* 175 */     catch (NoSuchAlgorithmException e) {
/* 176 */       throw new IllegalStateException("Unsupported JVM", e);
/*     */     } 
/* 178 */     byte[] buf = new byte[4096];
/* 179 */     Exception exception1 = null, exception2 = null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\sourcelookup\advanced\FileHashing.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */