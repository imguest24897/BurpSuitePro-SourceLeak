/*    */ package org.eclipse.jdt.launching;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.ILaunchConfiguration;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IRuntimeClasspathEntry2
/*    */   extends IRuntimeClasspathEntry
/*    */ {
/*    */   void initializeFrom(Element paramElement) throws CoreException;
/*    */   
/*    */   String getTypeId();
/*    */   
/*    */   boolean isComposite();
/*    */   
/*    */   IRuntimeClasspathEntry[] getRuntimeClasspathEntries(ILaunchConfiguration paramILaunchConfiguration) throws CoreException;
/*    */   
/*    */   default IRuntimeClasspathEntry[] getRuntimeClasspathEntries(boolean excludeTestCode) throws CoreException {
/* 86 */     return getRuntimeClasspathEntries((ILaunchConfiguration)null);
/*    */   }
/*    */   
/*    */   String getName();
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\IRuntimeClasspathEntry2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */