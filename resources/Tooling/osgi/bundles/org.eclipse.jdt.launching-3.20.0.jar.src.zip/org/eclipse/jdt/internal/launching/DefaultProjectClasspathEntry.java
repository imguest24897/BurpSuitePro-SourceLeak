/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.jdt.core.ClasspathContainerInitializer;
/*     */ import org.eclipse.jdt.core.IClasspathAttribute;
/*     */ import org.eclipse.jdt.core.IClasspathContainer;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
/*     */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry;
/*     */ import org.eclipse.jdt.launching.IRuntimeContainerComparator;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultProjectClasspathEntry
/*     */   extends AbstractRuntimeClasspathEntry
/*     */ {
/*     */   public static final String TYPE_ID = "org.eclipse.jdt.launching.classpathentry.defaultClasspath";
/*     */   private boolean fExportedEntriesOnly = false;
/*     */   
/*     */   public DefaultProjectClasspathEntry(IJavaProject project) {
/*  71 */     setJavaProject(project);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void buildMemento(Document document, Element memento) throws CoreException {
/*  79 */     memento.setAttribute("project", getJavaProject().getElementName());
/*  80 */     memento.setAttribute("exportedEntriesOnly", Boolean.toString(this.fExportedEntriesOnly));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeFrom(Element memento) throws CoreException {
/*  88 */     String name = memento.getAttribute("project");
/*  89 */     if (name == null) {
/*  90 */       abort(LaunchingMessages.DefaultProjectClasspathEntry_3, null);
/*     */     }
/*  92 */     IJavaProject project = JavaCore.create(ResourcesPlugin.getWorkspace().getRoot().getProject(name));
/*  93 */     setJavaProject(project);
/*  94 */     name = memento.getAttribute("exportedEntriesOnly");
/*  95 */     if (name != null) {
/*  96 */       this.fExportedEntriesOnly = Boolean.parseBoolean(name);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTypeId() {
/* 104 */     return "org.eclipse.jdt.launching.classpathentry.defaultClasspath";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getType() {
/* 111 */     return 5;
/*     */   }
/*     */   
/*     */   protected IProject getProject() {
/* 115 */     return getJavaProject().getProject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocation() {
/* 123 */     return getProject().getLocation().toOSString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getPath() {
/* 131 */     return getProject().getFullPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource getResource() {
/* 139 */     return (IResource)getProject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IRuntimeClasspathEntry[] getRuntimeClasspathEntries(ILaunchConfiguration configuration) throws CoreException {
/* 147 */     boolean excludeTestCode = (configuration != null && 
/* 148 */       configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_EXCLUDE_TEST_CODE, false));
/* 149 */     return getRuntimeClasspathEntries(excludeTestCode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IRuntimeClasspathEntry[] getRuntimeClasspathEntries(boolean excludeTestCode) throws CoreException {
/* 159 */     IClasspathEntry entry = JavaCore.newProjectEntry(getJavaProject().getProject().getFullPath());
/* 160 */     List<Object> classpathEntries = new ArrayList(5);
/* 161 */     List<IClasspathEntry> expanding = new ArrayList<>(5);
/* 162 */     expandProject(entry, classpathEntries, expanding, excludeTestCode, isExportedEntriesOnly(), getJavaProject(), false);
/* 163 */     IRuntimeClasspathEntry[] runtimeEntries = new IRuntimeClasspathEntry[classpathEntries.size()];
/* 164 */     for (int i = 0; i < runtimeEntries.length; i++) {
/* 165 */       Object e = classpathEntries.get(i);
/* 166 */       if (e instanceof IClasspathEntry) {
/* 167 */         IClasspathEntry cpe = (IClasspathEntry)e;
/* 168 */         runtimeEntries[i] = new RuntimeClasspathEntry(cpe);
/*     */       } else {
/* 170 */         runtimeEntries[i] = (IRuntimeClasspathEntry)e;
/*     */       } 
/*     */     } 
/*     */     
/* 174 */     List<IRuntimeClasspathEntry> ordered = new ArrayList<>(runtimeEntries.length);
/* 175 */     for (int j = 0; j < runtimeEntries.length; j++) {
/* 176 */       if (runtimeEntries[j].getClasspathProperty() == 3) {
/* 177 */         ordered.add(runtimeEntries[j]);
/*     */       }
/*     */     } 
/* 180 */     return ordered.<IRuntimeClasspathEntry>toArray(new IRuntimeClasspathEntry[ordered.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void expandProject(IClasspathEntry projectEntry, List<Object> expandedPath, List<IClasspathEntry> expanding, boolean excludeTestCode, boolean exportedEntriesOnly, IJavaProject rootProject, boolean isModularJVM) throws CoreException {
/* 204 */     Set<Object> visitedEntries = new HashSet();
/* 205 */     expandProjectInternal(projectEntry, expandedPath, visitedEntries, expanding, excludeTestCode, exportedEntriesOnly, rootProject, isModularJVM);
/*     */   }
/*     */   
/*     */   public static void expandProjectInternal(IClasspathEntry projectEntry, List<Object> expandedPath, Set<Object> visitedEntries, List<IClasspathEntry> expanding, boolean excludeTestCode, boolean exportedEntriesOnly, IJavaProject rootProject, boolean isModularJVM) throws CoreException {
/* 209 */     expanding.add(projectEntry);
/*     */ 
/*     */     
/* 212 */     IPath projectPath = projectEntry.getPath();
/* 213 */     IResource res = ResourcesPlugin.getWorkspace().getRoot().findMember(projectPath.lastSegment());
/* 214 */     if (res == null) {
/*     */       
/* 216 */       expandedPath.add(projectEntry);
/*     */       return;
/*     */     } 
/* 219 */     IJavaProject project = (IJavaProject)JavaCore.create(res);
/* 220 */     if (project == null || !project.getProject().isOpen() || !project.exists()) {
/*     */       
/* 222 */       expandedPath.add(projectEntry);
/*     */       
/*     */       return;
/*     */     } 
/* 226 */     IClasspathEntry[] buildPath = project.getRawClasspath();
/* 227 */     List<IClasspathEntry> unexpandedPath = new ArrayList<>(buildPath.length);
/* 228 */     boolean projectAdded = false;
/* 229 */     for (int i = 0; i < buildPath.length; i++) {
/* 230 */       IClasspathEntry classpathEntry = buildPath[i];
/* 231 */       if (!excludeTestCode || !classpathEntry.isTest())
/*     */       {
/*     */         
/* 234 */         if (classpathEntry.getEntryKind() == 3) {
/* 235 */           if (!projectAdded) {
/* 236 */             projectAdded = true;
/* 237 */             unexpandedPath.add(projectEntry);
/*     */           }
/*     */         
/*     */         }
/* 241 */         else if (classpathEntry.isExported()) {
/* 242 */           unexpandedPath.add(classpathEntry);
/* 243 */         } else if (!exportedEntriesOnly || project.equals(rootProject)) {
/*     */           
/* 245 */           unexpandedPath.add(classpathEntry);
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 251 */     Iterator<IClasspathEntry> iter = unexpandedPath.iterator();
/* 252 */     while (iter.hasNext()) {
/* 253 */       IClasspathContainer container; int property; IRuntimeClasspathEntry r; IClasspathEntry entry = iter.next();
/* 254 */       if (entry == projectEntry) {
/* 255 */         expandedPath.add(entry); continue;
/*     */       } 
/* 257 */       switch (entry.getEntryKind()) {
/*     */         case 2:
/* 259 */           if (!expanding.contains(entry)) {
/* 260 */             expandProjectInternal(entry, expandedPath, visitedEntries, expanding, excludeTestCode, exportedEntriesOnly, rootProject, isModularJVM);
/*     */           }
/*     */           continue;
/*     */         case 5:
/* 264 */           container = JavaCore.getClasspathContainer(entry.getPath(), project);
/* 265 */           property = -1;
/* 266 */           if (container != null) {
/* 267 */             switch (container.getKind()) {
/*     */               case 1:
/* 269 */                 if (isModularJVM) {
/* 270 */                   if (Arrays.<IClasspathAttribute>stream(entry.getExtraAttributes()).anyMatch(attribute -> ("module".equals(attribute.getName()) && Boolean.TRUE.toString().equals(attribute.getValue())))) {
/*     */                     
/* 272 */                     property = 4; break;
/*     */                   } 
/* 274 */                   property = 5;
/*     */                   break;
/*     */                 } 
/* 277 */                 property = 3;
/*     */                 break;
/*     */               
/*     */               case 3:
/* 281 */                 property = 1;
/*     */                 break;
/*     */               case 2:
/* 284 */                 property = 2;
/*     */                 break;
/*     */             } 
/* 287 */             IRuntimeClasspathEntry iRuntimeClasspathEntry = JavaRuntime.newRuntimeContainerClasspathEntry(entry.getPath(), property, project);
/*     */             
/* 289 */             boolean duplicate = false;
/* 290 */             ClasspathContainerInitializer initializer = JavaCore.getClasspathContainerInitializer(iRuntimeClasspathEntry.getPath().segment(0));
/* 291 */             for (int j = 0; j < expandedPath.size(); j++) {
/* 292 */               Object o = expandedPath.get(j);
/* 293 */               if (o instanceof IRuntimeClasspathEntry) {
/* 294 */                 IRuntimeClasspathEntry re = (IRuntimeClasspathEntry)o;
/* 295 */                 if (re.getType() == 4) {
/* 296 */                   if (container instanceof IRuntimeContainerComparator) {
/* 297 */                     duplicate = ((IRuntimeContainerComparator)container).isDuplicate(re.getPath());
/*     */                   } else {
/* 299 */                     ClasspathContainerInitializer initializer2 = JavaCore.getClasspathContainerInitializer(re.getPath().segment(0));
/* 300 */                     Object id1 = null;
/* 301 */                     Object id2 = null;
/* 302 */                     if (initializer == null) {
/* 303 */                       id1 = iRuntimeClasspathEntry.getPath().segment(0);
/*     */                     } else {
/* 305 */                       id1 = initializer.getComparisonID(iRuntimeClasspathEntry.getPath(), project);
/*     */                     } 
/* 307 */                     if (initializer2 == null) {
/* 308 */                       id2 = re.getPath().segment(0);
/*     */                     } else {
/* 310 */                       IJavaProject context = re.getJavaProject();
/* 311 */                       if (context == null) {
/* 312 */                         context = project;
/*     */                       }
/* 314 */                       id2 = initializer2.getComparisonID(re.getPath(), context);
/*     */                     } 
/* 316 */                     if (id1 == null) {
/* 317 */                       duplicate = (id2 == null);
/*     */                     } else {
/* 319 */                       duplicate = id1.equals(id2);
/*     */                     } 
/*     */                   } 
/* 322 */                   if (duplicate) {
/*     */                     break;
/*     */                   }
/*     */                 } 
/*     */               } 
/*     */             } 
/* 328 */             if (!duplicate) {
/* 329 */               expandedPath.add(iRuntimeClasspathEntry);
/*     */             }
/*     */           } 
/*     */           continue;
/*     */         case 4:
/* 334 */           r = JavaRuntime.newVariableRuntimeClasspathEntry(entry.getPath());
/* 335 */           if (isModularJVM) {
/* 336 */             adjustClasspathProperty(r, entry);
/*     */           }
/* 338 */           r.setSourceAttachmentPath(entry.getSourceAttachmentPath());
/* 339 */           r.setSourceAttachmentRootPath(entry.getSourceAttachmentRootPath());
/* 340 */           if (!expandedPath.contains(r)) {
/* 341 */             expandedPath.add(r);
/*     */           }
/*     */           continue;
/*     */       } 
/* 345 */       if (!expandedPath.contains(entry)) {
/*     */         
/* 347 */         if (entry.getEntryKind() != 3) {
/* 348 */           if (!visitedEntries.contains(entry)) {
/* 349 */             visitedEntries.add(entry);
/* 350 */             IPackageFragmentRoot[] roots = project.findPackageFragmentRoots(entry);
/* 351 */             for (int j = 0; j < roots.length; j++) {
/* 352 */               IPackageFragmentRoot root = roots[j];
/* 353 */               r = JavaRuntime.newArchiveRuntimeClasspathEntry(root.getPath(), entry.getSourceAttachmentPath(), entry.getSourceAttachmentRootPath(), entry.getAccessRules(), entry.getExtraAttributes(), entry.isExported());
/* 354 */               if (isModularJVM) {
/* 355 */                 adjustClasspathProperty(r, entry);
/*     */               }
/* 357 */               r.setSourceAttachmentPath(entry.getSourceAttachmentPath());
/* 358 */               r.setSourceAttachmentRootPath(entry.getSourceAttachmentRootPath());
/* 359 */               if (!expandedPath.contains(r))
/* 360 */                 expandedPath.add(r); 
/*     */             } 
/*     */           } 
/*     */           continue;
/*     */         } 
/* 365 */         expandedPath.add(entry);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void adjustClasspathProperty(IRuntimeClasspathEntry r, IClasspathEntry entry) {
/* 376 */     if (r.getClasspathProperty() == 3) {
/* 377 */       if (Arrays.<IClasspathAttribute>stream(entry.getExtraAttributes()).anyMatch(attribute -> ("module".equals(attribute.getName()) && Boolean.TRUE.toString().equals(attribute.getValue())))) {
/*     */         
/* 379 */         r.setClasspathProperty(4);
/*     */       } else {
/* 381 */         r.setClasspathProperty(5);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isComposite() {
/* 391 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 398 */     if (isExportedEntriesOnly()) {
/* 399 */       return NLS.bind(LaunchingMessages.DefaultProjectClasspathEntry_2, (Object[])new String[] { getJavaProject().getElementName() });
/*     */     }
/* 401 */     return NLS.bind(LaunchingMessages.DefaultProjectClasspathEntry_4, (Object[])new String[] { getJavaProject().getElementName() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 408 */     if (obj instanceof DefaultProjectClasspathEntry) {
/* 409 */       DefaultProjectClasspathEntry entry = (DefaultProjectClasspathEntry)obj;
/* 410 */       return (entry.getJavaProject().equals(getJavaProject()) && 
/* 411 */         entry.isExportedEntriesOnly() == isExportedEntriesOnly());
/*     */     } 
/* 413 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 420 */     return getJavaProject().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExportedEntriesOnly(boolean exportedOnly) {
/* 432 */     this.fExportedEntriesOnly = exportedOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExportedEntriesOnly() {
/* 444 */     return this.fExportedEntriesOnly | Platform.getPreferencesService().getBoolean(
/* 445 */         "org.eclipse.jdt.launching", 
/* 446 */         "org.eclipse.jdt.launching.only_include_exported_classpath_entries", 
/* 447 */         false, 
/* 448 */         null);
/*     */   }
/*     */   
/*     */   public DefaultProjectClasspathEntry() {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\DefaultProjectClasspathEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */