/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.resources.IResource;
/*    */ import org.eclipse.core.resources.ResourcesPlugin;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.core.variables.IDynamicVariable;
/*    */ import org.eclipse.core.variables.IDynamicVariableResolver;
/*    */ import org.eclipse.core.variables.IStringVariableManager;
/*    */ import org.eclipse.core.variables.VariablesPlugin;
/*    */ import org.eclipse.jdt.core.IJavaProject;
/*    */ import org.eclipse.jdt.core.JavaCore;
/*    */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry;
/*    */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry2;
/*    */ import org.eclipse.jdt.launching.JavaRuntime;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProjectClasspathVariableResolver
/*    */   implements IDynamicVariableResolver
/*    */ {
/*    */   public String resolveValue(IDynamicVariable variable, String argument) throws CoreException {
/* 46 */     IProject proj = null;
/* 47 */     if (argument == null) {
/* 48 */       IResource resource = getSelectedResource();
/* 49 */       if (resource != null && resource.exists()) {
/* 50 */         proj = resource.getProject();
/*    */       }
/* 52 */       if (proj == null) {
/* 53 */         throw new CoreException(new Status(4, "org.eclipse.jdt.launching", LaunchingMessages.ProjectClasspathVariableResolver_2));
/*    */       }
/*    */     } else {
/* 56 */       proj = ResourcesPlugin.getWorkspace().getRoot().getProject(argument);
/*    */     } 
/* 58 */     IJavaProject javaProject = JavaCore.create(proj);
/* 59 */     if (javaProject.exists()) {
/* 60 */       IRuntimeClasspathEntry2 defClassPath = (IRuntimeClasspathEntry2)JavaRuntime.newDefaultProjectClasspathEntry(javaProject);
/* 61 */       IRuntimeClasspathEntry[] entries = defClassPath.getRuntimeClasspathEntries(false);
/* 62 */       List<IRuntimeClasspathEntry> collect = new ArrayList<>();
/* 63 */       for (int i = 0; i < entries.length; i++) {
/* 64 */         IRuntimeClasspathEntry[] children = JavaRuntime.resolveRuntimeClasspathEntry(entries[i], javaProject, false);
/* 65 */         for (int k = 0; k < children.length; k++) {
/* 66 */           collect.add(children[k]);
/*    */         }
/*    */       } 
/* 69 */       entries = collect.<IRuntimeClasspathEntry>toArray(new IRuntimeClasspathEntry[collect.size()]);
/* 70 */       StringBuilder buffer = new StringBuilder();
/* 71 */       for (int j = 0; j < entries.length; j++) {
/* 72 */         if (j > 0) {
/* 73 */           buffer.append(File.pathSeparatorChar);
/*    */         }
/* 75 */         buffer.append(entries[j].getLocation());
/*    */       } 
/* 77 */       return buffer.toString();
/*    */     } 
/* 79 */     throw new CoreException(new Status(4, "org.eclipse.jdt.launching", NLS.bind(LaunchingMessages.ProjectClasspathVariableResolver_1, new String[] { argument })));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected IResource getSelectedResource() throws CoreException {
/* 92 */     IStringVariableManager manager = VariablesPlugin.getDefault().getStringVariableManager();
/*    */     try {
/* 94 */       String pathString = manager.performStringSubstitution("${selected_resource_path}");
/* 95 */       return ResourcesPlugin.getWorkspace().getRoot().findMember((IPath)new Path(pathString));
/* 96 */     } catch (CoreException coreException) {
/*    */ 
/*    */       
/* 99 */       throw new CoreException(new Status(4, "org.eclipse.jdt.launching", LaunchingMessages.ProjectClasspathVariableResolver_3));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\ProjectClasspathVariableResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */