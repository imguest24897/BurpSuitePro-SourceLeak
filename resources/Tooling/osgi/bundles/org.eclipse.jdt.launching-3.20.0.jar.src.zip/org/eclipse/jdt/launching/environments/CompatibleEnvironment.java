/*    */ package org.eclipse.jdt.launching.environments;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompatibleEnvironment
/*    */ {
/*    */   private IExecutionEnvironment fEnvironment;
/*    */   private boolean fIsStrictlyCompatible;
/*    */   
/*    */   public CompatibleEnvironment(IExecutionEnvironment environment, boolean strict) {
/* 48 */     this.fEnvironment = environment;
/* 49 */     this.fIsStrictlyCompatible = strict;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IExecutionEnvironment getCompatibleEnvironment() {
/* 58 */     return this.fEnvironment;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isStrictlyCompatbile() {
/* 71 */     return this.fIsStrictlyCompatible;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 76 */     return this.fEnvironment.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\environments\CompatibleEnvironment.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */