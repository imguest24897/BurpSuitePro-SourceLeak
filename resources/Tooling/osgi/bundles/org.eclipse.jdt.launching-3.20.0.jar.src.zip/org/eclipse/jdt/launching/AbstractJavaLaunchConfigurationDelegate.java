/*      */ package org.eclipse.jdt.launching;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.eclipse.core.resources.IMarker;
/*      */ import org.eclipse.core.resources.IProject;
/*      */ import org.eclipse.core.resources.IResource;
/*      */ import org.eclipse.core.resources.IWorkspaceRoot;
/*      */ import org.eclipse.core.resources.ResourcesPlugin;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.Path;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.core.variables.VariablesPlugin;
/*      */ import org.eclipse.debug.core.DebugEvent;
/*      */ import org.eclipse.debug.core.DebugPlugin;
/*      */ import org.eclipse.debug.core.IBreakpointManager;
/*      */ import org.eclipse.debug.core.IDebugEventSetListener;
/*      */ import org.eclipse.debug.core.ILaunch;
/*      */ import org.eclipse.debug.core.ILaunchConfiguration;
/*      */ import org.eclipse.debug.core.ILaunchManager;
/*      */ import org.eclipse.debug.core.model.IBreakpoint;
/*      */ import org.eclipse.debug.core.model.ISourceLocator;
/*      */ import org.eclipse.debug.core.model.LaunchConfigurationDelegate;
/*      */ import org.eclipse.jdt.core.IClasspathAttribute;
/*      */ import org.eclipse.jdt.core.IClasspathEntry;
/*      */ import org.eclipse.jdt.core.IJavaElement;
/*      */ import org.eclipse.jdt.core.IJavaProject;
/*      */ import org.eclipse.jdt.core.IModuleDescription;
/*      */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*      */ import org.eclipse.jdt.core.JavaCore;
/*      */ import org.eclipse.jdt.debug.core.IJavaDebugTarget;
/*      */ import org.eclipse.jdt.debug.core.IJavaMethodBreakpoint;
/*      */ import org.eclipse.jdt.debug.core.JDIDebugModel;
/*      */ import org.eclipse.jdt.internal.launching.JRERuntimeClasspathEntryResolver;
/*      */ import org.eclipse.jdt.internal.launching.JavaSourceLookupDirector;
/*      */ import org.eclipse.jdt.internal.launching.LaunchingMessages;
/*      */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*      */ import org.eclipse.jdt.internal.launching.sourcelookup.advanced.AdvancedSourceLookupSupport;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbstractJavaLaunchConfigurationDelegate
/*      */   extends LaunchConfigurationDelegate
/*      */   implements IDebugEventSetListener
/*      */ {
/*      */   private boolean allowAdvancedSourcelookup;
/*      */   private IProject[] fOrderedProjects;
/*      */   
/*      */   protected ILaunchManager getLaunchManager() {
/*   95 */     return DebugPlugin.getDefault().getLaunchManager();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void abort(String message, Throwable exception, int code) throws CoreException {
/*  113 */     throw new CoreException(new Status(4, 
/*  114 */           LaunchingPlugin.getUniqueIdentifier(), code, message, exception));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IVMInstall getVMInstall(ILaunchConfiguration configuration) throws CoreException {
/*  129 */     return JavaRuntime.computeVMInstall(configuration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getVMInstallName(ILaunchConfiguration configuration) throws CoreException {
/*  145 */     return configuration.getAttribute(
/*  146 */         IJavaLaunchConfigurationConstants.ATTR_VM_INSTALL_NAME, 
/*  147 */         null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IVMInstallType getVMInstallType(ILaunchConfiguration configuration) throws CoreException {
/*  162 */     String id = getVMInstallTypeId(configuration);
/*  163 */     if (id != null) {
/*  164 */       IVMInstallType type = JavaRuntime.getVMInstallType(id);
/*  165 */       if (type != null) {
/*  166 */         return type;
/*      */       }
/*      */     } 
/*  169 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getVMInstallTypeId(ILaunchConfiguration configuration) throws CoreException {
/*  185 */     return configuration.getAttribute(
/*  186 */         IJavaLaunchConfigurationConstants.ATTR_VM_INSTALL_TYPE, 
/*  187 */         null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IVMInstall verifyVMInstall(ILaunchConfiguration configuration) throws CoreException {
/*  203 */     IVMInstall vm = getVMInstall(configuration);
/*  204 */     if (vm == null) {
/*  205 */       abort(
/*  206 */           LaunchingMessages.AbstractJavaLaunchConfigurationDelegate_The_specified_JRE_installation_does_not_exist_4, 
/*  207 */           null, 
/*  208 */           105);
/*      */     }
/*  210 */     File location = vm.getInstallLocation();
/*  211 */     if (location == null) {
/*  212 */       abort(
/*  213 */           NLS.bind(LaunchingMessages.AbstractJavaLaunchConfigurationDelegate_JRE_home_directory_not_specified_for__0__5, (Object[])new String[] { vm.getName()
/*  214 */             }), null, 
/*  215 */           105);
/*      */     }
/*  217 */     if (!location.exists()) {
/*  218 */       abort(
/*  219 */           NLS.bind(LaunchingMessages.AbstractJavaLaunchConfigurationDelegate_JRE_home_directory_for__0__does_not_exist___1__6, 
/*  220 */             (Object[])new String[] { vm.getName(), 
/*  221 */               location.getAbsolutePath()
/*  222 */             }), null, 
/*  223 */           105);
/*      */     }
/*  225 */     return vm;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getVMConnectorId(ILaunchConfiguration configuration) throws CoreException {
/*  240 */     return configuration.getAttribute(
/*  241 */         IJavaLaunchConfigurationConstants.ATTR_VM_CONNECTOR, 
/*  242 */         null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getBootpath(ILaunchConfiguration configuration) throws CoreException {
/*  261 */     if (JavaRuntime.isModularConfiguration(configuration)) {
/*  262 */       return null;
/*      */     }
/*  264 */     String[][] paths = getBootpathExt(configuration);
/*  265 */     String[] pre = paths[0];
/*  266 */     String[] main = paths[1];
/*  267 */     String[] app = paths[2];
/*  268 */     if (pre == null && main == null && app == null)
/*      */     {
/*  270 */       return null;
/*      */     }
/*  272 */     IRuntimeClasspathEntry[] entries = 
/*  273 */       JavaRuntime.computeUnresolvedRuntimeClasspath(configuration);
/*  274 */     entries = JavaRuntime.resolveRuntimeClasspath(entries, configuration);
/*  275 */     List<String> bootEntries = new ArrayList<>(entries.length);
/*  276 */     boolean empty = true;
/*  277 */     boolean allStandard = true;
/*  278 */     for (int i = 0; i < entries.length; i++) {
/*  279 */       if (entries[i].getClasspathProperty() != 3) {
/*  280 */         String location = entries[i].getLocation();
/*  281 */         if (location != null) {
/*  282 */           empty = false;
/*  283 */           bootEntries.add(location);
/*  284 */           allStandard = (allStandard && 
/*  285 */             entries[i].getClasspathProperty() == 1);
/*      */         } 
/*      */       } 
/*      */     } 
/*  289 */     if (empty)
/*  290 */       return new String[0]; 
/*  291 */     if (allStandard) {
/*  292 */       return null;
/*      */     }
/*  294 */     return bootEntries
/*  295 */       .<String>toArray(new String[bootEntries.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[][] getBootpathExt(ILaunchConfiguration configuration) throws CoreException {
/*  317 */     String[][] bootpathInfo = new String[3][];
/*  318 */     IRuntimeClasspathEntry[] entries = 
/*  319 */       JavaRuntime.computeUnresolvedRuntimeClasspath(configuration);
/*  320 */     List<IRuntimeClasspathEntry> bootEntriesPrepend = new ArrayList<>();
/*  321 */     int index = 0;
/*  322 */     IRuntimeClasspathEntry jreEntry = null;
/*  323 */     while (jreEntry == null && index < entries.length) {
/*  324 */       IRuntimeClasspathEntry entry = entries[index++];
/*  325 */       if (JavaRuntime.isVMInstallReference(entry)) {
/*  326 */         jreEntry = entry; continue;
/*  327 */       }  if (entry.getClasspathProperty() == 2) {
/*  328 */         bootEntriesPrepend.add(entry);
/*      */       }
/*      */     } 
/*  331 */     IRuntimeClasspathEntry[] bootEntriesPrep = 
/*  332 */       JavaRuntime.resolveRuntimeClasspath(
/*  333 */         bootEntriesPrepend
/*  334 */         .<IRuntimeClasspathEntry>toArray(new IRuntimeClasspathEntry[bootEntriesPrepend
/*  335 */             .size()]), configuration);
/*  336 */     String[] entriesPrep = null;
/*  337 */     if (bootEntriesPrep.length > 0) {
/*  338 */       entriesPrep = new String[bootEntriesPrep.length];
/*  339 */       for (int i = 0; i < bootEntriesPrep.length; i++) {
/*  340 */         entriesPrep[i] = bootEntriesPrep[i].getLocation();
/*      */       }
/*      */     } 
/*  343 */     if (jreEntry != null) {
/*  344 */       List<IRuntimeClasspathEntry> bootEntriesAppend = new ArrayList<>();
/*  345 */       for (; index < entries.length; index++) {
/*  346 */         IRuntimeClasspathEntry entry = entries[index];
/*  347 */         if (entry.getClasspathProperty() == 2) {
/*  348 */           bootEntriesAppend.add(entry);
/*      */         }
/*      */       } 
/*  351 */       bootpathInfo[0] = entriesPrep;
/*  352 */       IRuntimeClasspathEntry[] bootEntriesApp = 
/*  353 */         JavaRuntime.resolveRuntimeClasspath(
/*  354 */           bootEntriesAppend
/*  355 */           .<IRuntimeClasspathEntry>toArray(new IRuntimeClasspathEntry[bootEntriesAppend
/*  356 */               .size()]), configuration);
/*  357 */       if (bootEntriesApp.length > 0) {
/*  358 */         bootpathInfo[2] = new String[bootEntriesApp.length];
/*  359 */         for (int i = 0; i < bootEntriesApp.length; i++) {
/*  360 */           bootpathInfo[2][i] = bootEntriesApp[i].getLocation();
/*      */         }
/*      */       } 
/*  363 */       IVMInstall install = getVMInstall(configuration);
/*  364 */       LibraryLocation[] libraryLocations = install.getLibraryLocations();
/*  365 */       if (libraryLocations != null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  372 */         if (!JRERuntimeClasspathEntryResolver.isSameArchives(libraryLocations, install.getVMInstallType().getDefaultLibraryLocations(install.getInstallLocation())))
/*      */         {
/*  374 */           IRuntimeClasspathEntry[] bootEntries = null;
/*  375 */           if (jreEntry.getType() == 4) {
/*  376 */             IRuntimeClasspathEntry bootEntry = JavaRuntime.newRuntimeContainerClasspathEntry(
/*  377 */                 jreEntry.getPath(), 
/*  378 */                 2, 
/*  379 */                 getJavaProject(configuration));
/*  380 */             bootEntries = JavaRuntime.resolveRuntimeClasspathEntry(bootEntry, configuration);
/*      */           } else {
/*  382 */             bootEntries = JavaRuntime.resolveRuntimeClasspathEntry(jreEntry, configuration);
/*      */           } 
/*      */ 
/*      */           
/*  386 */           String[] bootpath = new String[bootEntriesPrep.length + 
/*  387 */               bootEntries.length + bootEntriesApp.length];
/*  388 */           if (bootEntriesPrep.length > 0) {
/*  389 */             System.arraycopy(bootpathInfo[0], 0, bootpath, 0, 
/*  390 */                 bootEntriesPrep.length);
/*      */           }
/*  392 */           int dest = bootEntriesPrep.length;
/*  393 */           for (int i = 0; i < bootEntries.length; i++) {
/*  394 */             bootpath[dest] = bootEntries[i].getLocation();
/*  395 */             dest++;
/*      */           } 
/*  397 */           if (bootEntriesApp.length > 0) {
/*  398 */             System.arraycopy(bootpathInfo[2], 0, bootpath, dest, 
/*  399 */                 bootEntriesApp.length);
/*      */           }
/*  401 */           bootpathInfo[0] = null;
/*  402 */           bootpathInfo[1] = bootpath;
/*  403 */           bootpathInfo[2] = null;
/*      */         }
/*      */       
/*      */       }
/*  407 */     } else if (entriesPrep == null) {
/*  408 */       bootpathInfo[1] = new String[0];
/*      */     } else {
/*  410 */       bootpathInfo[1] = entriesPrep;
/*      */     } 
/*      */     
/*  413 */     return bootpathInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String[] getClasspath(ILaunchConfiguration configuration) throws CoreException {
/*  430 */     IRuntimeClasspathEntry[] entries = 
/*  431 */       JavaRuntime.computeUnresolvedRuntimeClasspath(configuration);
/*  432 */     entries = JavaRuntime.resolveRuntimeClasspath(entries, configuration);
/*      */     
/*  434 */     List<String> userEntries = new ArrayList<>(entries.length);
/*  435 */     Set<String> set = new HashSet<>(entries.length); byte b; int i; IRuntimeClasspathEntry[] arrayOfIRuntimeClasspathEntry1;
/*  436 */     for (i = (arrayOfIRuntimeClasspathEntry1 = entries).length, b = 0; b < i; ) { IRuntimeClasspathEntry entry = arrayOfIRuntimeClasspathEntry1[b];
/*  437 */       if (entry.getClasspathProperty() == 3 || 
/*  438 */         entry.getClasspathProperty() == 5) {
/*  439 */         String location = entry.getLocation();
/*  440 */         if (location != null && 
/*  441 */           !set.contains(location)) {
/*  442 */           userEntries.add(location);
/*  443 */           set.add(location);
/*      */         } 
/*      */       } 
/*      */       b++; }
/*      */     
/*  448 */     return userEntries.<String>toArray(new String[userEntries.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[][] getClasspathAndModulepath(ILaunchConfiguration config) throws CoreException {
/*  463 */     IRuntimeClasspathEntry[] entries = JavaRuntime.computeUnresolvedRuntimeClasspath(config);
/*  464 */     entries = JavaRuntime.resolveRuntimeClasspath(entries, config);
/*  465 */     String[][] path = new String[2][entries.length];
/*  466 */     List<String> classpathEntries = new ArrayList<>(entries.length);
/*  467 */     List<String> modulepathEntries = new ArrayList<>(entries.length);
/*  468 */     Set<String> classpathSet = new HashSet<>(entries.length);
/*  469 */     Set<String> modulepathSet = new HashSet<>(entries.length); byte b; int i; IRuntimeClasspathEntry[] arrayOfIRuntimeClasspathEntry1;
/*  470 */     for (i = (arrayOfIRuntimeClasspathEntry1 = entries).length, b = 0; b < i; ) { IRuntimeClasspathEntry entry = arrayOfIRuntimeClasspathEntry1[b];
/*  471 */       String location = entry.getLocation();
/*  472 */       if (location != null) {
/*  473 */         switch (entry.getClasspathProperty()) {
/*      */           case 3:
/*  475 */             if (!classpathSet.contains(location)) {
/*  476 */               classpathEntries.add(location);
/*  477 */               classpathSet.add(location);
/*      */             } 
/*      */             break;
/*      */           case 5:
/*  481 */             if (!classpathSet.contains(location)) {
/*  482 */               classpathEntries.add(location);
/*  483 */               classpathSet.add(location);
/*      */             } 
/*      */             break;
/*      */           case 4:
/*  487 */             if (!modulepathSet.contains(location)) {
/*  488 */               modulepathEntries.add(location);
/*  489 */               modulepathSet.add(location);
/*      */             } 
/*      */             break;
/*      */         } 
/*      */ 
/*      */       
/*      */       }
/*      */       b++; }
/*      */     
/*  498 */     path[0] = classpathEntries.<String>toArray(new String[classpathEntries.size()]);
/*  499 */     path[1] = modulepathEntries.<String>toArray(new String[modulepathEntries.size()]);
/*  500 */     return path;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IJavaProject getJavaProject(ILaunchConfiguration configuration) throws CoreException {
/*  516 */     String projectName = getJavaProjectName(configuration);
/*  517 */     if (projectName != null) {
/*  518 */       projectName = projectName.trim();
/*  519 */       if (projectName.length() > 0) {
/*  520 */         IProject project = ResourcesPlugin.getWorkspace().getRoot()
/*  521 */           .getProject(projectName);
/*  522 */         IJavaProject javaProject = JavaCore.create(project);
/*  523 */         if (javaProject != null && javaProject.exists()) {
/*  524 */           return javaProject;
/*      */         }
/*      */       } 
/*      */     } 
/*  528 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getJavaProjectName(ILaunchConfiguration configuration) throws CoreException {
/*  543 */     return configuration.getAttribute(
/*  544 */         IJavaLaunchConfigurationConstants.ATTR_PROJECT_NAME, 
/*  545 */         null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getMainTypeName(ILaunchConfiguration configuration) throws CoreException {
/*  560 */     String mainType = configuration.getAttribute(
/*  561 */         IJavaLaunchConfigurationConstants.ATTR_MAIN_TYPE_NAME, 
/*  562 */         null);
/*  563 */     if (mainType == null) {
/*  564 */       return null;
/*      */     }
/*  566 */     return VariablesPlugin.getDefault().getStringVariableManager()
/*  567 */       .performStringSubstitution(mainType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getProgramArguments(ILaunchConfiguration configuration) throws CoreException {
/*  583 */     String arguments = configuration.getAttribute(
/*  584 */         IJavaLaunchConfigurationConstants.ATTR_PROGRAM_ARGUMENTS, "");
/*  585 */     return VariablesPlugin.getDefault().getStringVariableManager()
/*  586 */       .performStringSubstitution(arguments);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getVMArguments(ILaunchConfiguration configuration) throws CoreException {
/*  600 */     String arguments = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_VM_ARGUMENTS, "");
/*  601 */     String args = VariablesPlugin.getDefault().getStringVariableManager().performStringSubstitution(arguments);
/*  602 */     int libraryPath = args.indexOf("-Djava.library.path");
/*  603 */     if (libraryPath < 0) {
/*      */       
/*  605 */       String[] javaLibraryPath = getJavaLibraryPath(configuration);
/*  606 */       if (javaLibraryPath != null && javaLibraryPath.length > 0) {
/*  607 */         StringBuilder path = new StringBuilder(args);
/*  608 */         path.append(" -Djava.library.path=");
/*  609 */         path.append("\"");
/*  610 */         for (int i = 0; i < javaLibraryPath.length; i++) {
/*  611 */           if (i > 0) {
/*  612 */             path.append(File.pathSeparatorChar);
/*      */           }
/*  614 */           path.append(javaLibraryPath[i]);
/*      */         } 
/*  616 */         path.append("\"");
/*  617 */         args = path.toString();
/*      */       } 
/*      */     } 
/*  620 */     return args;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getVMArguments(ILaunchConfiguration configuration, String mode) throws CoreException {
/*  638 */     if (!isAdvancedSourcelup(mode)) {
/*  639 */       return "";
/*      */     }
/*  641 */     if (!isJavaagentOptionSupported(configuration)) {
/*  642 */       return "";
/*      */     }
/*  644 */     return AdvancedSourceLookupSupport.getJavaagentString();
/*      */   }
/*      */   
/*      */   private boolean isJavaagentOptionSupported(ILaunchConfiguration configuration) {
/*      */     try {
/*  649 */       IVMInstall vm = JavaRuntime.computeVMInstall(configuration);
/*  650 */       if (JavaRuntime.compareJavaVersions(vm, "1.4") > 0) {
/*  651 */         return true;
/*      */       }
/*  653 */     } catch (CoreException e) {
/*  654 */       LaunchingPlugin.log((Throwable)e);
/*      */     } 
/*  656 */     return false;
/*      */   }
/*      */   
/*      */   private boolean isAdvancedSourcelup(String mode) {
/*  660 */     return (this.allowAdvancedSourcelookup && "debug".equals(mode) && AdvancedSourceLookupSupport.isAdvancedSourcelookupEnabled());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Object> getVMSpecificAttributesMap(ILaunchConfiguration configuration) throws CoreException {
/*  674 */     Map<String, String> map = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_VM_INSTALL_TYPE_SPECIFIC_ATTRS_MAP, null);
/*  675 */     Map<String, Object> attributes = new HashMap<>();
/*  676 */     if (map != null) {
/*  677 */       attributes.putAll(map);
/*      */     }
/*  679 */     String[][] paths = getBootpathExt(configuration);
/*  680 */     String[] pre = paths[0];
/*  681 */     String[] boot = paths[1];
/*  682 */     String[] app = paths[2];
/*  683 */     if (pre != null) {
/*  684 */       attributes.put(IJavaLaunchConfigurationConstants.ATTR_BOOTPATH_PREPEND, pre);
/*      */     }
/*  686 */     if (app != null) {
/*  687 */       attributes.put(IJavaLaunchConfigurationConstants.ATTR_BOOTPATH_APPEND, app);
/*      */     }
/*  689 */     if (boot != null) {
/*  690 */       attributes.put(IJavaLaunchConfigurationConstants.ATTR_BOOTPATH, boot);
/*      */     }
/*  692 */     return attributes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public File getWorkingDirectory(ILaunchConfiguration configuration) throws CoreException {
/*  707 */     return verifyWorkingDirectory(configuration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IPath getWorkingDirectoryPath(ILaunchConfiguration configuration) throws CoreException {
/*  722 */     String path = configuration.getAttribute(
/*  723 */         IJavaLaunchConfigurationConstants.ATTR_WORKING_DIRECTORY, 
/*  724 */         null);
/*  725 */     if (path != null) {
/*  726 */       path = VariablesPlugin.getDefault().getStringVariableManager()
/*  727 */         .performStringSubstitution(path);
/*  728 */       return (IPath)new Path(path);
/*      */     } 
/*  730 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IJavaProject verifyJavaProject(ILaunchConfiguration configuration) throws CoreException {
/*  745 */     String name = getJavaProjectName(configuration);
/*  746 */     if (name == null) {
/*  747 */       abort(
/*  748 */           LaunchingMessages.AbstractJavaLaunchConfigurationDelegate_Java_project_not_specified_9, 
/*  749 */           null, 
/*  750 */           100);
/*      */     }
/*  752 */     IJavaProject project = getJavaProject(configuration);
/*  753 */     if (project == null) {
/*  754 */       abort(
/*  755 */           LaunchingMessages.AbstractJavaLaunchConfigurationDelegate_Project_does_not_exist_or_is_not_a_Java_project_10, 
/*  756 */           null, 
/*  757 */           107);
/*      */     }
/*  759 */     return project;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String verifyMainTypeName(ILaunchConfiguration configuration) throws CoreException {
/*  774 */     String name = getMainTypeName(configuration);
/*  775 */     if (name == null) {
/*  776 */       abort(
/*  777 */           LaunchingMessages.AbstractJavaLaunchConfigurationDelegate_Main_type_not_specified_11, 
/*  778 */           null, 
/*  779 */           101);
/*      */     }
/*  781 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public File verifyWorkingDirectory(ILaunchConfiguration configuration) throws CoreException {
/*  797 */     IPath path = getWorkingDirectoryPath(configuration);
/*  798 */     if (path == null) {
/*  799 */       File dir = getDefaultWorkingDirectory(configuration);
/*  800 */       if (dir != null) {
/*  801 */         if (!dir.isDirectory()) {
/*  802 */           abort(
/*  803 */               NLS.bind(
/*  804 */                 LaunchingMessages.AbstractJavaLaunchConfigurationDelegate_Working_directory_does_not_exist___0__12, 
/*  805 */                 (Object[])new String[] { dir.toString()
/*  806 */                 }), null, 
/*  807 */               108);
/*      */         }
/*  809 */         return dir;
/*      */       }
/*      */     
/*  812 */     } else if (path.isAbsolute()) {
/*  813 */       File dir = new File(path.toOSString());
/*  814 */       if (dir.isDirectory()) {
/*  815 */         return dir;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  820 */       IResource res = ResourcesPlugin.getWorkspace().getRoot().findMember(path);
/*  821 */       if (res instanceof org.eclipse.core.resources.IContainer && res.exists()) {
/*  822 */         return res.getLocation().toFile();
/*      */       }
/*  824 */       abort(
/*  825 */           NLS.bind(
/*  826 */             LaunchingMessages.AbstractJavaLaunchConfigurationDelegate_Working_directory_does_not_exist___0__12, 
/*  827 */             (Object[])new String[] { path.toString()
/*  828 */             }), null, 
/*  829 */           108);
/*      */     } else {
/*  831 */       IResource res = ResourcesPlugin.getWorkspace().getRoot()
/*  832 */         .findMember(path);
/*  833 */       if (res instanceof org.eclipse.core.resources.IContainer && res.exists()) {
/*  834 */         return res.getLocation().toFile();
/*      */       }
/*  836 */       abort(
/*  837 */           NLS.bind(
/*  838 */             LaunchingMessages.AbstractJavaLaunchConfigurationDelegate_Working_directory_does_not_exist___0__12, 
/*  839 */             (Object[])new String[] { path.toString()
/*  840 */             }), null, 
/*  841 */           108);
/*      */     } 
/*      */     
/*  844 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAllowTerminate(ILaunchConfiguration configuration) throws CoreException {
/*  858 */     return configuration.getAttribute(
/*  859 */         IJavaLaunchConfigurationConstants.ATTR_ALLOW_TERMINATE, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isStopInMain(ILaunchConfiguration configuration) throws CoreException {
/*  874 */     return configuration.getAttribute(
/*  875 */         IJavaLaunchConfigurationConstants.ATTR_STOP_IN_MAIN, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setDefaultSourceLocator(ILaunch launch, ILaunchConfiguration configuration) throws CoreException {
/*  892 */     if (launch.getSourceLocator() == null) {
/*  893 */       JavaSourceLookupDirector javaSourceLookupDirector = new JavaSourceLookupDirector();
/*  894 */       javaSourceLookupDirector
/*  895 */         .setSourcePathComputer(getLaunchManager()
/*  896 */           .getSourcePathComputer(
/*  897 */             "org.eclipse.jdt.launching.sourceLookup.javaSourcePathComputer"));
/*  898 */       javaSourceLookupDirector.initializeDefaults(configuration);
/*  899 */       launch.setSourceLocator((ISourceLocator)javaSourceLookupDirector);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void prepareStopInMain(ILaunchConfiguration configuration) throws CoreException {
/*  915 */     if (isStopInMain(configuration))
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  920 */       DebugPlugin.getDefault().addDebugEventListener(this);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleDebugEvents(DebugEvent[] events) {
/*  932 */     for (int i = 0; i < events.length; i++) {
/*  933 */       DebugEvent event = events[i];
/*  934 */       if (event.getKind() == 4 && 
/*  935 */         event.getSource() instanceof IJavaDebugTarget) {
/*  936 */         IJavaDebugTarget target = (IJavaDebugTarget)event.getSource();
/*  937 */         ILaunch launch = target.getLaunch();
/*  938 */         if (launch != null) {
/*  939 */           ILaunchConfiguration configuration = launch
/*  940 */             .getLaunchConfiguration();
/*  941 */           if (configuration != null) {
/*      */             try {
/*  943 */               if (isStopInMain(configuration)) {
/*  944 */                 String mainType = getMainTypeName(configuration);
/*  945 */                 if (mainType != null) {
/*  946 */                   Map<String, Object> map = new HashMap<>();
/*  947 */                   map
/*  948 */                     .put(
/*  949 */                       IJavaLaunchConfigurationConstants.ATTR_STOP_IN_MAIN, 
/*  950 */                       IJavaLaunchConfigurationConstants.ATTR_STOP_IN_MAIN);
/*  951 */                   IJavaMethodBreakpoint bp = 
/*  952 */                     JDIDebugModel.createMethodBreakpoint(
/*      */                       
/*  954 */                       (IResource)ResourcesPlugin.getWorkspace()
/*  955 */                       .getRoot(), 
/*  956 */                       mainType, "main", 
/*  957 */                       "([Ljava/lang/String;)V", 
/*  958 */                       true, false, false, -1, -1, 
/*  959 */                       -1, 1, false, map);
/*  960 */                   bp.setPersisted(false);
/*  961 */                   target.breakpointAdded((IBreakpoint)bp);
/*  962 */                   DebugPlugin.getDefault()
/*  963 */                     .removeDebugEventListener(this);
/*      */                 } 
/*      */               } 
/*  966 */             } catch (CoreException e) {
/*  967 */               LaunchingPlugin.log((Throwable)e);
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IProject[] getBuildOrder(ILaunchConfiguration configuration, String mode) throws CoreException {
/*  984 */     return this.fOrderedProjects;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IProject[] getProjectsForProblemSearch(ILaunchConfiguration configuration, String mode) throws CoreException {
/*  996 */     return this.fOrderedProjects;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isLaunchProblem(IMarker problemMarker) throws CoreException {
/* 1004 */     return (super.isLaunchProblem(problemMarker) && problemMarker.getType().equals("org.eclipse.jdt.core.problem"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean preLaunchCheck(ILaunchConfiguration configuration, String mode, IProgressMonitor monitor) throws CoreException {
/* 1016 */     if (monitor != null) {
/* 1017 */       monitor.subTask(LaunchingMessages.AbstractJavaLaunchConfigurationDelegate_20);
/*      */     }
/* 1019 */     this.fOrderedProjects = null;
/* 1020 */     IJavaProject javaProject = JavaRuntime.getJavaProject(configuration);
/* 1021 */     if (javaProject != null) {
/* 1022 */       this.fOrderedProjects = computeReferencedBuildOrder(new IProject[] { javaProject
/* 1023 */             .getProject() });
/*      */     }
/*      */     
/* 1026 */     return super.preLaunchCheck(configuration, mode, monitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IBreakpoint[] getBreakpoints(ILaunchConfiguration configuration) {
/* 1034 */     IBreakpointManager breakpointManager = DebugPlugin.getDefault().getBreakpointManager();
/* 1035 */     if (!breakpointManager.isEnabled())
/*      */     {
/* 1037 */       return null;
/*      */     }
/* 1039 */     return breakpointManager.getBreakpoints(JDIDebugModel.getPluginIdentifier());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IVMRunner getVMRunner(ILaunchConfiguration configuration, String mode) throws CoreException {
/* 1053 */     IVMInstall vm = verifyVMInstall(configuration);
/* 1054 */     IVMRunner runner = vm.getVMRunner(mode);
/* 1055 */     if (runner == null) {
/* 1056 */       abort(NLS.bind(LaunchingMessages.JavaLocalApplicationLaunchConfigurationDelegate_0, (Object[])new String[] { vm.getName(), mode }), (Throwable)null, 106);
/*      */     }
/* 1058 */     return runner;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getEnvironment(ILaunchConfiguration configuration) throws CoreException {
/* 1072 */     return DebugPlugin.getDefault().getLaunchManager().getEnvironment(configuration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getJavaLibraryPath(ILaunchConfiguration configuration) throws CoreException {
/* 1086 */     IJavaProject project = getJavaProject(configuration);
/* 1087 */     if (project != null) {
/* 1088 */       String[] paths = JavaRuntime.computeJavaLibraryPath(project, true);
/* 1089 */       if (paths.length > 0) {
/* 1090 */         return paths;
/*      */       }
/*      */     } 
/* 1093 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected File getDefaultWorkingDirectory(ILaunchConfiguration configuration) throws CoreException {
/* 1108 */     IJavaProject jp = getJavaProject(configuration);
/* 1109 */     if (jp != null) {
/* 1110 */       IProject p = jp.getProject();
/*      */       
/* 1112 */       if (p.getLocation() != null) {
/* 1113 */         return p.getLocation().toFile();
/*      */       }
/*      */     } 
/* 1116 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public ILaunch getLaunch(ILaunchConfiguration configuration, String mode) throws CoreException {
/* 1121 */     if (!isAdvancedSourcelup(mode)) {
/* 1122 */       return null;
/*      */     }
/* 1124 */     return AdvancedSourceLookupSupport.createAdvancedLaunch(configuration, mode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void allowAdvancedSourcelookup() {
/* 1135 */     this.allowAdvancedSourcelookup = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getModuleCLIOptions(ILaunchConfiguration configuration) throws CoreException {
/* 1153 */     String moduleCLIOptions = JavaRuntime.getModuleCLIOptions(configuration);
/*      */     
/* 1155 */     IRuntimeClasspathEntry[] entries = JavaRuntime.computeUnresolvedRuntimeClasspath(configuration);
/* 1156 */     entries = JavaRuntime.resolveRuntimeClasspath(entries, configuration);
/* 1157 */     LinkedHashMap<String, String> moduleToLocations = new LinkedHashMap<>(); byte b; int i;
/*      */     IRuntimeClasspathEntry[] arrayOfIRuntimeClasspathEntry1;
/* 1159 */     for (i = (arrayOfIRuntimeClasspathEntry1 = entries).length, b = 0; b < i; ) { IRuntimeClasspathEntry entry = arrayOfIRuntimeClasspathEntry1[b];
/* 1160 */       String location = entry.getLocation();
/* 1161 */       if (location != null)
/* 1162 */         if (entry.getClasspathProperty() == 6) {
/* 1163 */           IJavaProject javaProject = entry.getJavaProject();
/* 1164 */           IModuleDescription moduleDescription = (javaProject == null) ? null : javaProject.getModuleDescription();
/* 1165 */           if (moduleDescription != null) {
/* 1166 */             String moduleName = moduleDescription.getElementName();
/* 1167 */             addPatchModuleLocations(moduleToLocations, moduleName, location);
/*      */           } 
/*      */         } else {
/*      */           byte b1; int j;
/*      */           IClasspathAttribute[] arrayOfIClasspathAttribute;
/* 1172 */           for (j = (arrayOfIClasspathAttribute = entry.getClasspathEntry().getExtraAttributes()).length, b1 = 0; b1 < j; ) { IClasspathAttribute attribute = arrayOfIClasspathAttribute[b1];
/* 1173 */             if ("patch-module".equals(attribute.getName())) {
/* 1174 */               String patchModules = attribute.getValue(); byte b2; int k; String[] arrayOfString;
/* 1175 */               for (k = (arrayOfString = patchModules.split("::")).length, b2 = 0; b2 < k; ) { String patchModule = arrayOfString[b2];
/* 1176 */                 int equalsIdx = patchModule.indexOf('=');
/* 1177 */                 if (equalsIdx != -1) {
/* 1178 */                   if (equalsIdx < patchModule.length() - 1) {
/* 1179 */                     String locations = toAbsolutePathsString(patchModule.substring(equalsIdx + 1));
/* 1180 */                     String moduleName = patchModule.substring(0, equalsIdx);
/* 1181 */                     addPatchModuleLocations(moduleToLocations, moduleName, locations);
/*      */                   } 
/*      */                 } else {
/*      */                   
/* 1185 */                   IJavaProject javaProject = JavaRuntime.getJavaProject(configuration);
/* 1186 */                   addPatchModuleLocations(moduleToLocations, patchModule, toAbsolutePathsString(javaProject.getOutputLocation().toString())); byte b3; int m; IClasspathEntry[] arrayOfIClasspathEntry;
/* 1187 */                   for (m = (arrayOfIClasspathEntry = javaProject.getRawClasspath()).length, b3 = 0; b3 < m; ) { IClasspathEntry cpEntry = arrayOfIClasspathEntry[b3];
/* 1188 */                     if (cpEntry.getOutputLocation() != null)
/* 1189 */                       addPatchModuleLocations(moduleToLocations, patchModule, toAbsolutePathsString(cpEntry.getOutputLocation().toString()));  b3++; }
/*      */                 
/*      */                 } 
/*      */                 b2++; }
/*      */               
/*      */               break;
/*      */             } 
/*      */             b1++; }
/*      */         
/*      */         }  
/*      */       b++; }
/*      */     
/* 1201 */     String addModules = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_SPECIAL_ADD_MODULES, "");
/* 1202 */     if (moduleToLocations.isEmpty() && addModules.isEmpty()) {
/* 1203 */       return moduleCLIOptions;
/*      */     }
/*      */     
/* 1206 */     ArrayList<String> list = new ArrayList<>();
/*      */     
/* 1208 */     Collections.addAll(list, DebugPlugin.parseArguments(moduleCLIOptions));
/*      */     
/* 1210 */     for (Map.Entry<String, String> entry : moduleToLocations.entrySet()) {
/* 1211 */       list.add("--patch-module");
/* 1212 */       list.add(String.valueOf(entry.getKey()) + '=' + (String)entry.getValue());
/*      */     } 
/*      */     
/* 1215 */     boolean excludeTestCode = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_EXCLUDE_TEST_CODE, false);
/* 1216 */     if (!excludeTestCode) {
/*      */       
/* 1218 */       IJavaProject project = getJavaProject(configuration);
/* 1219 */       if (project != null) {
/* 1220 */         for (String moduleName : project.determineModulesOfProjectsWithNonEmptyClasspath()) {
/* 1221 */           list.add("--add-reads");
/* 1222 */           list.add(String.valueOf(moduleName) + '=' + "ALL-UNNAMED");
/*      */         } 
/*      */       }
/*      */     } 
/* 1226 */     if (!addModules.isEmpty()) {
/* 1227 */       list.add("--add-modules");
/* 1228 */       list.add(addModules);
/*      */     } 
/* 1230 */     return DebugPlugin.renderArguments(list.<String>toArray(new String[list.size()]), null);
/*      */   }
/*      */   
/*      */   private void addPatchModuleLocations(Map<String, String> moduleToLocations, String moduleName, String locations) {
/* 1234 */     String existing = moduleToLocations.get(moduleName);
/* 1235 */     if (existing == null) {
/* 1236 */       moduleToLocations.put(moduleName, locations);
/*      */     } else {
/* 1238 */       moduleToLocations.put(moduleName, String.valueOf(existing) + File.pathSeparator + locations);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static String toAbsolutePathsString(String fPaths) {
/* 1243 */     String[] paths = fPaths.split(File.pathSeparator);
/* 1244 */     String[] absPaths = new String[paths.length];
/* 1245 */     IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
/* 1246 */     for (int i = 0; i < paths.length; i++) {
/* 1247 */       IResource resource = root.findMember((IPath)new Path(paths[i]));
/*      */       try {
/* 1249 */         absPaths[i] = toAbsolutePath(resource, root);
/* 1250 */       } catch (CoreException e) {
/* 1251 */         LaunchingPlugin.log((Throwable)e);
/*      */       } 
/* 1253 */       if (absPaths[i] == null) {
/* 1254 */         absPaths[i] = paths[i];
/*      */       }
/*      */     } 
/* 1257 */     String allPaths = String.join(File.pathSeparator, (CharSequence[])absPaths);
/* 1258 */     return allPaths;
/*      */   }
/*      */   
/*      */   private static String toAbsolutePath(IResource resource, IWorkspaceRoot root) throws CoreException {
/* 1262 */     IJavaElement element = JavaCore.create(resource);
/* 1263 */     if (element != null && element.exists()) {
/* 1264 */       if (element instanceof IJavaProject) {
/* 1265 */         Set<String> paths = new HashSet<>();
/* 1266 */         IJavaProject project = (IJavaProject)element;
/* 1267 */         paths.add(absPath(root, project.getOutputLocation())); byte b; int i; IClasspathEntry[] arrayOfIClasspathEntry;
/* 1268 */         for (i = (arrayOfIClasspathEntry = project.getResolvedClasspath(true)).length, b = 0; b < i; ) { IClasspathEntry entry = arrayOfIClasspathEntry[b];
/* 1269 */           if (entry.getEntryKind() == 3 && entry.getOutputLocation() != null)
/* 1270 */             paths.add(absPath(root, entry.getOutputLocation())); 
/*      */           b++; }
/*      */         
/* 1273 */         return String.join(File.pathSeparator, (Iterable)paths);
/* 1274 */       }  if (element instanceof IPackageFragmentRoot) {
/* 1275 */         IPackageFragmentRoot packageRoot = (IPackageFragmentRoot)element;
/* 1276 */         IClasspathEntry entry = packageRoot.getJavaProject().getClasspathEntryFor(resource.getFullPath());
/* 1277 */         return absPath(root, entry.getOutputLocation());
/*      */       } 
/*      */     } 
/* 1280 */     if (resource != null)
/*      */     {
/* 1282 */       return resource.getLocation().toString();
/*      */     }
/* 1284 */     return null;
/*      */   }
/*      */   
/*      */   private static String absPath(IWorkspaceRoot root, IPath path) {
/* 1288 */     return root.findMember(path).getLocation().toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean supportsModule() {
/* 1297 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean supportsPreviewFeatures(ILaunchConfiguration configuration) {
/*      */     try {
/* 1307 */       IJavaProject javaProject = getJavaProject(configuration);
/* 1308 */       if (javaProject != null) {
/* 1309 */         String id = javaProject.getOption("org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures", true);
/* 1310 */         if ("enabled".equals(id)) {
/* 1311 */           return true;
/*      */         }
/*      */       } 
/* 1314 */     } catch (CoreException coreException) {}
/*      */ 
/*      */     
/* 1317 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\AbstractJavaLaunchConfigurationDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */