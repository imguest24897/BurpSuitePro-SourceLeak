/*     */ package org.eclipse.jdt.launching.sourcelookup.advanced;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.debug.core.model.DebugElement;
/*     */ import org.eclipse.debug.core.model.IDebugElement;
/*     */ import org.eclipse.debug.core.model.ISourceLocator;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceLookupDirector;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceLookupParticipant;
/*     */ import org.eclipse.jdt.internal.launching.sourcelookup.advanced.AdvancedSourceLookupSupport;
/*     */ import org.eclipse.jdt.internal.launching.sourcelookup.advanced.CompositeSourceContainer;
/*     */ import org.eclipse.jdt.internal.launching.sourcelookup.advanced.IJDIHelpers;
/*     */ import org.eclipse.jdt.internal.launching.sourcelookup.advanced.WorkspaceProjectSourceContainers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdvancedSourceLookupParticipant
/*     */   implements ISourceLookupParticipant
/*     */ {
/*     */   private final IJDIHelpers jdi;
/*     */   private ISourceLookupDirector director;
/*  52 */   private final Map<File, ISourceContainer> containers = new HashMap<>();
/*     */   
/*     */   public AdvancedSourceLookupParticipant() {
/*  55 */     this(IJDIHelpers.INSTANCE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AdvancedSourceLookupParticipant(IJDIHelpers jdi) {
/*  62 */     this.jdi = jdi;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(ISourceLookupDirector director) {
/*  67 */     this.director = director;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] findSourceElements(Object element) throws CoreException {
/*  72 */     ISourceContainer container = getSourceContainer(element, false, null);
/*     */     
/*  74 */     if (container == null) {
/*  75 */       return null;
/*     */     }
/*     */     
/*  78 */     String sourcePath = this.jdi.getSourcePath(element);
/*  79 */     if (sourcePath == null)
/*     */     {
/*  81 */       return null;
/*     */     }
/*     */     
/*  84 */     return container.findSourceElements(sourcePath);
/*     */   }
/*     */   
/*     */   public ISourceContainer getSourceContainer(Object element, boolean refresh, IProgressMonitor monitor) throws CoreException {
/*  88 */     File location = this.jdi.getClassesLocation(element);
/*     */     
/*  90 */     if (location == null) {
/*  91 */       return null;
/*     */     }
/*     */     
/*  94 */     synchronized (this.containers) {
/*  95 */       if (!refresh && this.containers.containsKey(location)) {
/*  96 */         return this.containers.get(location);
/*     */       }
/*     */     } 
/*     */     
/* 100 */     monitor = AdvancedSourceLookupSupport.getContextMonitor(monitor);
/*     */     
/* 102 */     WorkspaceProjectSourceContainers projectLocator = AdvancedSourceLookupSupport.getWorkspaceJavaProjects(monitor);
/* 103 */     if (monitor == null && projectLocator == null) {
/*     */       
/* 105 */       AdvancedSourceLookupSupport.schedule(m -> { 
/* 106 */           }); return null;
/*     */     } 
/*     */     
/* 109 */     if (projectLocator == null)
/*     */     {
/* 111 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     ISourceContainer projectContainer = projectLocator.createProjectContainer(location);
/* 120 */     if (projectContainer != null) {
/* 121 */       return cacheContainer(element, location, projectContainer);
/*     */     }
/*     */ 
/*     */     
/* 125 */     for (File frameLocation : this.jdi.getStackFramesClassesLocations(element)) {
/* 126 */       ISourceContainer entryContainer = projectLocator.createClasspathEntryContainer(frameLocation, location);
/* 127 */       if (entryContainer != null) {
/* 128 */         return cacheContainer(element, location, entryContainer);
/*     */       }
/*     */     } 
/*     */     
/* 132 */     if (monitor == null) {
/*     */       
/* 134 */       AdvancedSourceLookupSupport.schedule(m -> { 
/* 135 */           }); return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     for (ISourceContainerResolver repository : getSourceContainerResolvers()) {
/* 144 */       Collection<ISourceContainer> members = repository.resolveSourceContainers(location, monitor);
/* 145 */       if (members != null && !members.isEmpty()) {
/* 146 */         return cacheContainer(element, location, CompositeSourceContainer.compose(members));
/*     */       }
/*     */     } 
/*     */     
/* 150 */     return null;
/*     */   }
/*     */   
/*     */   private ISourceContainer cacheContainer(Object element, File location, ISourceContainer container) {
/*     */     ISourceContainer oldContainer;
/* 155 */     synchronized (this.containers) {
/* 156 */       oldContainer = this.containers.put(location, container);
/* 157 */       if (oldContainer != null) {
/* 158 */         oldContainer.dispose();
/*     */       }
/*     */     } 
/* 161 */     if (oldContainer != null || container != null) {
/* 162 */       updateDebugElement(element);
/*     */     }
/* 164 */     return container;
/*     */   }
/*     */   
/*     */   protected Collection<ISourceContainerResolver> getSourceContainerResolvers() {
/* 168 */     List<ISourceContainerResolver> result = new ArrayList<>();
/*     */     
/* 170 */     IExtensionRegistry registry = Platform.getExtensionRegistry();
/*     */     
/* 172 */     IConfigurationElement[] elements = registry.getConfigurationElementsFor("org.eclipse.jdt.launching.sourceContainerResolvers"); byte b; int i;
/*     */     IConfigurationElement[] arrayOfIConfigurationElement1;
/* 174 */     for (i = (arrayOfIConfigurationElement1 = elements).length, b = 0; b < i; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b];
/* 175 */       if ("resolver".equals(element.getName())) {
/*     */         try {
/* 177 */           result.add((ISourceContainerResolver)element.createExecutableExtension("class"));
/*     */         }
/* 179 */         catch (CoreException coreException) {}
/*     */       }
/*     */       
/*     */       b++; }
/*     */     
/* 184 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSourceName(Object object) throws CoreException {
/* 189 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void dispose() {
/* 194 */     disposeContainers();
/*     */   }
/*     */ 
/*     */   
/*     */   public void sourceContainersChanged(ISourceLookupDirector director) {
/* 199 */     disposeContainers();
/*     */   }
/*     */   
/*     */   protected void disposeContainers() {
/* 203 */     synchronized (this.containers) {
/* 204 */       for (ISourceContainer container : this.containers.values()) {
/* 205 */         if (container != null)
/*     */         {
/* 207 */           container.dispose();
/*     */         }
/*     */       } 
/* 210 */       this.containers.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateDebugElement(Object element) {
/* 215 */     this.director.clearSourceElements(element);
/* 216 */     if (element instanceof DebugElement)
/*     */     {
/* 218 */       ((DebugElement)element).fireChangeEvent(512);
/*     */     }
/*     */   }
/*     */   
/*     */   public static AdvancedSourceLookupParticipant getSourceLookup(Object element) {
/* 223 */     ISourceLocator sourceLocator = null;
/* 224 */     if (element instanceof IDebugElement) {
/* 225 */       sourceLocator = ((IDebugElement)element).getLaunch().getSourceLocator();
/*     */     }
/*     */     
/* 228 */     AdvancedSourceLookupParticipant sourceLookup = null;
/* 229 */     if (sourceLocator instanceof ISourceLookupDirector) {
/* 230 */       byte b; int i; ISourceLookupParticipant[] arrayOfISourceLookupParticipant; for (i = (arrayOfISourceLookupParticipant = ((ISourceLookupDirector)sourceLocator).getParticipants()).length, b = 0; b < i; ) { ISourceLookupParticipant participant = arrayOfISourceLookupParticipant[b];
/* 231 */         if (participant instanceof AdvancedSourceLookupParticipant) {
/* 232 */           sourceLookup = (AdvancedSourceLookupParticipant)participant; break;
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } 
/* 237 */     return sourceLookup;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\sourcelookup\advanced\AdvancedSourceLookupParticipant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */