/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.model.IDebugTarget;
/*     */ import org.eclipse.jdt.launching.AbstractJavaLaunchConfigurationDelegate;
/*     */ import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
/*     */ import org.eclipse.jdt.launching.IVMConnector;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaRemoteApplicationLaunchConfigurationDelegate
/*     */   extends AbstractJavaLaunchConfigurationDelegate
/*     */ {
/*     */   public void launch(ILaunchConfiguration configuration, String mode, ILaunch launch, IProgressMonitor monitor) throws CoreException {
/*     */     NullProgressMonitor nullProgressMonitor;
/*  43 */     if (monitor == null) {
/*  44 */       nullProgressMonitor = new NullProgressMonitor();
/*     */     }
/*     */     
/*  47 */     nullProgressMonitor.beginTask(NLS.bind(LaunchingMessages.JavaRemoteApplicationLaunchConfigurationDelegate_Attaching_to__0_____1, (Object[])new String[] { configuration.getName() }), 3);
/*     */     
/*  49 */     if (nullProgressMonitor.isCanceled()) {
/*     */       return;
/*     */     }
/*     */     try {
/*  53 */       nullProgressMonitor.subTask(LaunchingMessages.JavaRemoteApplicationLaunchConfigurationDelegate_Verifying_launch_attributes____1);
/*     */       
/*  55 */       String connectorId = getVMConnectorId(configuration);
/*  56 */       IVMConnector connector = null;
/*  57 */       if (connectorId == null) {
/*  58 */         connector = JavaRuntime.getDefaultVMConnector();
/*     */       } else {
/*  60 */         connector = JavaRuntime.getVMConnector(connectorId);
/*     */       } 
/*  62 */       if (connector == null) {
/*  63 */         abort(LaunchingMessages.JavaRemoteApplicationLaunchConfigurationDelegate_Connector_not_specified_2, null, 119);
/*     */       }
/*     */       
/*  66 */       Map<String, String> argMap = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_CONNECT_MAP, null);
/*     */       
/*  68 */       int connectTimeout = Platform.getPreferencesService().getInt(
/*  69 */           "org.eclipse.jdt.launching", 
/*  70 */           JavaRuntime.PREF_CONNECT_TIMEOUT, 
/*  71 */           20000, 
/*  72 */           null);
/*  73 */       argMap.put("timeout", Integer.toString(connectTimeout));
/*     */ 
/*     */       
/*  76 */       if (nullProgressMonitor.isCanceled()) {
/*     */         return;
/*     */       }
/*     */       
/*  80 */       nullProgressMonitor.worked(1);
/*     */       
/*  82 */       nullProgressMonitor.subTask(LaunchingMessages.JavaRemoteApplicationLaunchConfigurationDelegate_Creating_source_locator____2);
/*     */       
/*  84 */       setDefaultSourceLocator(launch, configuration);
/*  85 */       nullProgressMonitor.worked(1);
/*     */ 
/*     */       
/*  88 */       connector.connect(argMap, (IProgressMonitor)nullProgressMonitor, launch);
/*     */ 
/*     */       
/*  91 */       if (nullProgressMonitor.isCanceled()) {
/*  92 */         IDebugTarget[] debugTargets = launch.getDebugTargets();
/*  93 */         for (int i = 0; i < debugTargets.length; i++) {
/*  94 */           IDebugTarget target = debugTargets[i];
/*  95 */           if (target.canDisconnect()) {
/*  96 */             target.disconnect();
/*     */           }
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } finally {
/* 103 */       nullProgressMonitor.done();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\JavaRemoteApplicationLaunchConfigurationDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */