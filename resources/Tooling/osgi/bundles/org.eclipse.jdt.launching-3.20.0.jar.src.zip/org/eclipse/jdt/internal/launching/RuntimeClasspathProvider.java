/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.debug.core.ILaunchConfiguration;
/*    */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry;
/*    */ import org.eclipse.jdt.launching.IRuntimeClasspathProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RuntimeClasspathProvider
/*    */   implements IRuntimeClasspathProvider
/*    */ {
/*    */   private IConfigurationElement fConfigurationElement;
/*    */   private IRuntimeClasspathProvider fDelegate;
/*    */   
/*    */   public RuntimeClasspathProvider(IConfigurationElement element) {
/* 37 */     this.fConfigurationElement = element;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected IRuntimeClasspathProvider getProvider() throws CoreException {
/* 46 */     if (this.fDelegate == null) {
/* 47 */       this.fDelegate = (IRuntimeClasspathProvider)this.fConfigurationElement.createExecutableExtension("class");
/*    */     }
/* 49 */     return this.fDelegate;
/*    */   }
/*    */   
/*    */   public String getIdentifier() {
/* 53 */     return this.fConfigurationElement.getAttribute("id");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IRuntimeClasspathEntry[] computeUnresolvedClasspath(ILaunchConfiguration configuration) throws CoreException {
/* 60 */     return getProvider().computeUnresolvedClasspath(configuration);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IRuntimeClasspathEntry[] resolveClasspath(IRuntimeClasspathEntry[] entries, ILaunchConfiguration configuration) throws CoreException {
/* 68 */     return getProvider().resolveClasspath(entries, configuration);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\RuntimeClasspathProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */