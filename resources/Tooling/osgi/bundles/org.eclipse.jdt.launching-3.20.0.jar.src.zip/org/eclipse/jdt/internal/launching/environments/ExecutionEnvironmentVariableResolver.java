/*    */ package org.eclipse.jdt.internal.launching.environments;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.core.variables.IDynamicVariable;
/*    */ import org.eclipse.core.variables.IDynamicVariableResolver;
/*    */ import org.eclipse.jdt.launching.IVMInstall;
/*    */ import org.eclipse.jdt.launching.JavaRuntime;
/*    */ import org.eclipse.jdt.launching.environments.IExecutionEnvironment;
/*    */ import org.eclipse.jdt.launching.environments.IExecutionEnvironmentsManager;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExecutionEnvironmentVariableResolver
/*    */   implements IDynamicVariableResolver
/*    */ {
/*    */   public String resolveValue(IDynamicVariable variable, String argument) throws CoreException {
/* 39 */     if (argument == null) {
/* 40 */       throw new CoreException(new Status(4, "org.eclipse.jdt.launching", EnvironmentMessages.ExecutionEnvironmentVariableResolver_0));
/*    */     }
/* 42 */     IExecutionEnvironmentsManager manager = JavaRuntime.getExecutionEnvironmentsManager();
/* 43 */     IExecutionEnvironment env = manager.getEnvironment(argument);
/* 44 */     if (env == null) {
/* 45 */       throw new CoreException(new Status(4, "org.eclipse.jdt.launching", NLS.bind(EnvironmentMessages.ExecutionEnvironmentVariableResolver_1, new String[] { argument })));
/*    */     }
/* 47 */     IPath path = JavaRuntime.newJREContainerPath(env);
/* 48 */     IVMInstall jre = JavaRuntime.getVMInstall(path);
/* 49 */     if (jre == null) {
/* 50 */       throw new CoreException(new Status(4, "org.eclipse.jdt.launching", NLS.bind(EnvironmentMessages.ExecutionEnvironmentVariableResolver_2, new String[] { argument })));
/*    */     }
/* 52 */     return jre.getInstallLocation().getAbsolutePath();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\environments\ExecutionEnvironmentVariableResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */