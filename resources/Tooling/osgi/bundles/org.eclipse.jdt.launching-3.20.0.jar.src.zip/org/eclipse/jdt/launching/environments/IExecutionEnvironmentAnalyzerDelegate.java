package org.eclipse.jdt.launching.environments;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.launching.IVMInstall;

public interface IExecutionEnvironmentAnalyzerDelegate {
  CompatibleEnvironment[] analyze(IVMInstall paramIVMInstall, IProgressMonitor paramIProgressMonitor) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\environments\IExecutionEnvironmentAnalyzerDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */