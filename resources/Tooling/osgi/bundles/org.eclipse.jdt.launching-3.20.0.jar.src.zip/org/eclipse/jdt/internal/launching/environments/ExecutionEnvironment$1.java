/*    */ package org.eclipse.jdt.internal.launching.environments;
/*    */ 
/*    */ import org.eclipse.jdt.launching.IVMInstall;
/*    */ import org.eclipse.jdt.launching.IVMInstallChangedListener;
/*    */ import org.eclipse.jdt.launching.PropertyChangeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements IVMInstallChangedListener
/*    */ {
/*    */   public void defaultVMInstallChanged(IVMInstall previous, IVMInstall current) {}
/*    */   
/*    */   public void vmAdded(IVMInstall newVm) {}
/*    */   
/*    */   public void vmChanged(PropertyChangeEvent event) {
/* 85 */     if (event.getSource() != null) {
/* 86 */       ExecutionEnvironment.this.fParticipantMap.remove(event.getSource());
/* 87 */       ExecutionEnvironment.this.fRuleCache.remove(event.getSource());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void vmRemoved(IVMInstall removedVm) {
/* 96 */     ExecutionEnvironment.this.fParticipantMap.remove(removedVm);
/* 97 */     ExecutionEnvironment.this.fRuleCache.remove(removedVm);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\environments\ExecutionEnvironment$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */