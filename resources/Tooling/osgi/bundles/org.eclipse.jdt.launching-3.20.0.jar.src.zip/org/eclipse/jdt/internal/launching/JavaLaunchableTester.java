/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.expressions.PropertyTester;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.jdt.core.Flags;
/*     */ import org.eclipse.jdt.core.IBuffer;
/*     */ import org.eclipse.jdt.core.IClassFile;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.ICompilationUnit;
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IMember;
/*     */ import org.eclipse.jdt.core.IMethod;
/*     */ import org.eclipse.jdt.core.IOpenable;
/*     */ import org.eclipse.jdt.core.IOrdinaryClassFile;
/*     */ import org.eclipse.jdt.core.ISourceRange;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.core.Signature;
/*     */ import org.eclipse.jdt.core.ToolFactory;
/*     */ import org.eclipse.jdt.core.compiler.IScanner;
/*     */ import org.eclipse.jdt.core.compiler.InvalidInputException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaLaunchableTester
/*     */   extends PropertyTester
/*     */ {
/*     */   private static final String PROPERTY_HAS_MAIN = "hasMain";
/*     */   private static final String PROPERTY_HAS_METHOD = "hasMethod";
/*     */   private static final String PROPERTY_HAS_METHOD_WITH_ANNOTATION = "hasMethodWithAnnotation";
/*     */   private static final String PROPERTY_HAS_TYPE_WITH_ANNOTATION = "hasTypeWithAnnotation";
/*     */   private static final String PROPERTY_EXTENDS_CLASS = "extendsClass";
/*     */   private static final String PROPERTY_IS_CONTAINER = "isContainer";
/*     */   private static final String PROPERTY_IS_PACKAGE_FRAGMENT = "isPackageFragment";
/*     */   private static final String PROPERTY_IS_PACKAGE_FRAGMENT_ROOT = "isPackageFragmentRoot";
/*     */   private static final String PROPERTY_PROJECT_NATURE = "hasProjectNature";
/*     */   private static final String PROPERTY_EXTENDS_INTERFACE = "extendsInterface";
/*     */   private static final String PROPERTY_BUILDPATH_REFERENCE = "buildpathReference";
/* 123 */   private static Map<String, Integer> fgModifiers = new HashMap<>();
/*     */ 
/*     */   
/*     */   private static final int FLAGS_MASK = 1343;
/*     */ 
/*     */   
/*     */   static {
/* 130 */     fgModifiers.put("public", Integer.valueOf(1));
/* 131 */     fgModifiers.put("protected", Integer.valueOf(4));
/* 132 */     fgModifiers.put("private", Integer.valueOf(2));
/* 133 */     fgModifiers.put("static", Integer.valueOf(8));
/* 134 */     fgModifiers.put("final", Integer.valueOf(16));
/* 135 */     fgModifiers.put("synchronized", Integer.valueOf(32));
/* 136 */     fgModifiers.put("abstract", Integer.valueOf(1024));
/* 137 */     fgModifiers.put("native", Integer.valueOf(256));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IType getType(IJavaElement element) {
/* 146 */     IType type = null;
/* 147 */     if (element instanceof ICompilationUnit) {
/* 148 */       type = ((ICompilationUnit)element).findPrimaryType();
/*     */     }
/* 150 */     else if (element instanceof IOrdinaryClassFile) {
/* 151 */       type = ((IOrdinaryClassFile)element).getType();
/*     */     }
/* 153 */     else if (element instanceof IType) {
/* 154 */       type = (IType)element;
/*     */     }
/* 156 */     else if (element instanceof IMember) {
/* 157 */       type = ((IMember)element).getDeclaringType();
/*     */     } 
/* 159 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasMain(IJavaElement element) {
/*     */     
/* 170 */     try { IType type = getType(element);
/* 171 */       if (type != null && type.exists()) {
/* 172 */         if (hasMainMethod(type)) {
/* 173 */           return true;
/*     */         }
/*     */         
/* 176 */         IJavaElement[] children = type.getChildren();
/* 177 */         for (int i = 0; i < children.length; i++) {
/* 178 */           if (hasMainInChildren(getType(children[i]))) {
/* 179 */             return true;
/*     */           }
/*     */         }
/*     */       
/*     */       }  }
/* 184 */     catch (JavaModelException javaModelException) {  }
/* 185 */     catch (CoreException coreException) {}
/* 186 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasMainMethod(IType type) throws JavaModelException {
/* 197 */     IMethod[] methods = type.getMethods();
/* 198 */     for (int i = 0; i < methods.length; i++) {
/* 199 */       if (methods[i].isMainMethod()) {
/* 200 */         return true;
/*     */       }
/*     */     } 
/* 203 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasMainInChildren(IType type) throws CoreException {
/* 215 */     if ((type.isClass() & Flags.isStatic(type.getFlags())) != 0) {
/* 216 */       if (hasMainMethod(type)) {
/* 217 */         return true;
/*     */       }
/* 219 */       IJavaElement[] children = type.getChildren();
/* 220 */       for (int i = 0; i < children.length; i++) {
/* 221 */         if (children[i].getElementType() == 7) {
/* 222 */           return hasMainInChildren((IType)children[i]);
/*     */         }
/*     */       } 
/*     */     } 
/* 226 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasMethod(IJavaElement element, Object[] args) {
/*     */     try {
/* 249 */       if (args.length > 1) {
/* 250 */         IType type = getType(element);
/* 251 */         if (type != null && type.exists()) {
/* 252 */           String name = (String)args[0];
/* 253 */           String signature = (String)args[1];
/* 254 */           String[] parms = Signature.getParameterTypes(signature);
/* 255 */           String returnType = Signature.getReturnType(signature);
/* 256 */           IMethod candidate = type.getMethod(name, parms);
/* 257 */           if (candidate.exists())
/*     */           {
/* 259 */             if (candidate.getReturnType().equals(returnType))
/*     */             {
/* 261 */               if (args.length > 2) {
/* 262 */                 String modifierText = (String)args[2];
/* 263 */                 String[] modifiers = modifierText.split(" ");
/* 264 */                 int flags = 0;
/* 265 */                 for (int j = 0; j < modifiers.length; j++) {
/* 266 */                   String modifier = modifiers[j];
/* 267 */                   Integer flag = fgModifiers.get(modifier);
/* 268 */                   if (flag != null) {
/* 269 */                     flags |= flag.intValue();
/*     */                   }
/*     */                 } 
/* 272 */                 if (candidate.getFlags() == flags) {
/* 273 */                   return true;
/*     */                 }
/*     */               }
/*     */             
/*     */             }
/*     */           }
/*     */         } 
/*     */       } 
/* 281 */     } catch (JavaModelException javaModelException) {}
/* 282 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasTypeWithAnnotation(IJavaElement element, String annotationType) {
/*     */     
/* 298 */     try { IType type = getType(element);
/* 299 */       if (type == null || !type.exists()) {
/* 300 */         return false;
/*     */       }
/*     */       
/* 303 */       IBuffer buffer = null;
/* 304 */       IOpenable openable = type.getOpenable();
/* 305 */       if (openable instanceof ICompilationUnit) {
/* 306 */         buffer = ((ICompilationUnit)openable).getBuffer();
/* 307 */       } else if (openable instanceof IClassFile) {
/* 308 */         buffer = ((IClassFile)openable).getBuffer();
/*     */       } 
/* 310 */       if (buffer == null) {
/* 311 */         return false;
/*     */       }
/*     */       
/* 314 */       ISourceRange sourceRange = type.getSourceRange();
/* 315 */       ISourceRange nameRange = type.getNameRange();
/* 316 */       if (sourceRange != null && nameRange != null) {
/* 317 */         IScanner scanner = ToolFactory.createScanner(false, false, true, false);
/* 318 */         scanner.setSource(buffer.getCharacters());
/* 319 */         scanner.resetTo(sourceRange.getOffset(), nameRange.getOffset());
/* 320 */         if (findAnnotation(scanner, annotationType)) {
/* 321 */           return true;
/*     */         }
/*     */       }
/*     */        }
/* 325 */     catch (JavaModelException javaModelException) {  }
/* 326 */     catch (InvalidInputException invalidInputException) {}
/* 327 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasMethodWithAnnotation(IJavaElement element, Object[] args) {
/*     */     
/* 346 */     try { String annotationType = (String)args[0];
/* 347 */       int flags = 0;
/* 348 */       if (args.length > 1) {
/* 349 */         String[] modifiers = ((String)args[1]).split(" ");
/* 350 */         for (int j = 0; j < modifiers.length; j++) {
/* 351 */           String modifier = modifiers[j];
/* 352 */           Integer flag = fgModifiers.get(modifier);
/* 353 */           if (flag != null) {
/* 354 */             flags |= flag.intValue();
/*     */           }
/*     */         } 
/*     */       } else {
/* 358 */         flags = -1;
/*     */       } 
/*     */       
/* 361 */       IType type = getType(element);
/* 362 */       if (type == null || !type.exists()) {
/* 363 */         return false;
/*     */       }
/* 365 */       IMethod[] methods = type.getMethods();
/* 366 */       if (methods.length == 0) {
/* 367 */         return false;
/*     */       }
/*     */       
/* 370 */       IBuffer buffer = null;
/* 371 */       IOpenable openable = type.getOpenable();
/* 372 */       if (openable instanceof ICompilationUnit) {
/* 373 */         buffer = ((ICompilationUnit)openable).getBuffer();
/* 374 */       } else if (openable instanceof IClassFile) {
/* 375 */         buffer = ((IClassFile)openable).getBuffer();
/*     */       } 
/* 377 */       if (buffer == null) {
/* 378 */         return false;
/*     */       }
/* 380 */       IScanner scanner = null;
/*     */       
/* 382 */       for (int i = 0; i < methods.length; i++) {
/* 383 */         IMethod curr = methods[i];
/* 384 */         if (!curr.isConstructor() && (flags == -1 || flags == (curr.getFlags() & 0x53F))) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 389 */           ISourceRange sourceRange = curr.getSourceRange();
/* 390 */           ISourceRange nameRange = curr.getNameRange();
/* 391 */           if (sourceRange != null && nameRange != null) {
/* 392 */             if (scanner == null) {
/* 393 */               scanner = ToolFactory.createScanner(false, false, true, false);
/* 394 */               scanner.setSource(buffer.getCharacters());
/*     */             } 
/* 396 */             scanner.resetTo(sourceRange.getOffset(), nameRange.getOffset());
/* 397 */             if (findAnnotation(scanner, annotationType))
/* 398 */               return true; 
/*     */           } 
/*     */         } 
/*     */       }  }
/* 402 */     catch (JavaModelException javaModelException) {  }
/* 403 */     catch (InvalidInputException invalidInputException) {}
/*     */     
/* 405 */     return false;
/*     */   }
/*     */   
/*     */   private boolean findAnnotation(IScanner scanner, String annotationName) throws InvalidInputException {
/* 409 */     String simpleName = Signature.getSimpleName(annotationName);
/* 410 */     StringBuilder buf = new StringBuilder();
/* 411 */     int tok = scanner.getNextToken();
/* 412 */     while (tok != 158) {
/* 413 */       if (tok == 401) {
/* 414 */         buf.setLength(0);
/* 415 */         tok = readName(scanner, buf);
/* 416 */         String name = buf.toString();
/* 417 */         if (name.equals(annotationName) || name.equals(simpleName) || name.endsWith(String.valueOf('.') + simpleName))
/* 418 */           return true; 
/*     */         continue;
/*     */       } 
/* 421 */       tok = scanner.getNextToken();
/*     */     } 
/*     */     
/* 424 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private int readName(IScanner scanner, StringBuilder buf) throws InvalidInputException {
/* 429 */     int tok = scanner.getNextToken();
/* 430 */     while (tok == 5) {
/* 431 */       buf.append(scanner.getCurrentTokenSource());
/* 432 */       tok = scanner.getNextToken();
/* 433 */       if (tok != 6) {
/* 434 */         return tok;
/*     */       }
/* 436 */       buf.append('.');
/* 437 */       tok = scanner.getNextToken();
/*     */     } 
/* 439 */     return tok;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasProjectNature(IJavaElement element, String ntype) {
/*     */     try {
/* 450 */       if (element != null) {
/* 451 */         IJavaProject jproj = element.getJavaProject();
/* 452 */         if (jproj != null) {
/* 453 */           IProject proj = jproj.getProject();
/* 454 */           return (proj.isAccessible() && proj.hasNature(ntype));
/*     */         } 
/*     */       } 
/* 457 */       return false;
/*     */     } catch (CoreException coreException) {
/* 459 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasSuperclass(IJavaElement element, String qname) {
/*     */     try {
/* 470 */       IType type = getType(element);
/* 471 */       if (type != null) {
/* 472 */         IType[] stypes = type.newSupertypeHierarchy((IProgressMonitor)new NullProgressMonitor()).getAllSuperclasses(type);
/* 473 */         for (int i = 0; i < stypes.length; i++) {
/* 474 */           if (stypes[i].getFullyQualifiedName().equals(qname) || stypes[i].getElementName().equals(qname)) {
/* 475 */             return true;
/*     */           }
/*     */         }
/*     */       
/*     */       } 
/* 480 */     } catch (JavaModelException javaModelException) {}
/* 481 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasItemOnBuildPath(IJavaElement element, Object[] args) {
/* 495 */     if (element != null && args != null) {
/* 496 */       IJavaProject project = element.getJavaProject();
/* 497 */       Set<IJavaProject> searched = new HashSet<>();
/* 498 */       searched.add(project);
/* 499 */       return hasItemsOnBuildPath(project, searched, args);
/*     */     } 
/* 501 */     return false;
/*     */   }
/*     */   
/*     */   private boolean hasItemsOnBuildPath(IJavaProject project, Set<IJavaProject> searched, Object[] args) {
/*     */     try {
/* 506 */       List<IJavaProject> projects = new ArrayList<>();
/* 507 */       if (project != null && project.exists()) {
/* 508 */         IClasspathEntry[] entries = project.getResolvedClasspath(true);
/* 509 */         for (int i = 0; i < entries.length; i++) {
/* 510 */           IClasspathEntry entry = entries[i];
/* 511 */           IPath path = entry.getPath();
/* 512 */           String spath = path.toPortableString();
/* 513 */           for (int j = 0; j < args.length; j++) {
/* 514 */             if (spath.lastIndexOf((String)args[j]) != -1) {
/* 515 */               return true;
/*     */             }
/*     */           } 
/* 518 */           if (entry.getEntryKind() == 2) {
/* 519 */             String name = entry.getPath().lastSegment();
/* 520 */             IProject dep = ResourcesPlugin.getWorkspace().getRoot().getProject(name);
/* 521 */             IJavaProject javaProject = JavaCore.create(dep);
/* 522 */             if (!searched.contains(javaProject)) {
/* 523 */               projects.add(javaProject);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 529 */       Iterator<IJavaProject> iterator = projects.iterator();
/* 530 */       while (iterator.hasNext()) {
/* 531 */         IJavaProject jp = iterator.next();
/* 532 */         searched.add(jp);
/* 533 */         if (hasItemsOnBuildPath(jp, searched, args)) {
/* 534 */           return true;
/*     */         }
/*     */       } 
/* 537 */     } catch (JavaModelException javaModelException) {}
/* 538 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean implementsInterface(IJavaElement element, String qname) {
/*     */     try {
/* 549 */       IType type = getType(element);
/* 550 */       if (type != null) {
/* 551 */         IType[] itypes = type.newSupertypeHierarchy((IProgressMonitor)new NullProgressMonitor()).getAllInterfaces();
/* 552 */         for (int i = 0; i < itypes.length; i++) {
/* 553 */           if (itypes[i].getFullyQualifiedName().equals(qname)) {
/* 554 */             return true;
/*     */           }
/*     */         }
/*     */       
/*     */       } 
/* 559 */     } catch (JavaModelException javaModelException) {}
/* 560 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean test(Object receiver, String property, Object[] args, Object expectedValue) {
/* 582 */     if ("isContainer".equals(property)) {
/* 583 */       if (receiver instanceof IAdaptable) {
/* 584 */         IResource resource = (IResource)((IAdaptable)receiver).getAdapter(IResource.class);
/* 585 */         if (resource != null) {
/* 586 */           return resource instanceof org.eclipse.core.resources.IContainer;
/*     */         }
/*     */       } 
/* 589 */       return false;
/*     */     } 
/* 591 */     IJavaElement element = null;
/* 592 */     if (receiver instanceof IAdaptable) {
/* 593 */       element = (IJavaElement)((IAdaptable)receiver).getAdapter(IJavaElement.class);
/* 594 */       if (element != null && 
/* 595 */         !element.exists()) {
/* 596 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 600 */     if ("hasMain".equals(property)) {
/* 601 */       return hasMain(element);
/*     */     }
/* 603 */     if ("hasMethod".equals(property)) {
/* 604 */       return hasMethod(element, args);
/*     */     }
/* 606 */     if ("hasMethodWithAnnotation".equals(property)) {
/* 607 */       return hasMethodWithAnnotation(element, args);
/*     */     }
/* 609 */     if ("hasTypeWithAnnotation".equals(property)) {
/* 610 */       return hasTypeWithAnnotation(element, (String)args[0]);
/*     */     }
/* 612 */     if ("buildpathReference".equals(property)) {
/* 613 */       return hasItemOnBuildPath(element, args);
/*     */     }
/* 615 */     if ("extendsClass".equals(property)) {
/* 616 */       return hasSuperclass(element, (String)args[0]);
/*     */     }
/* 618 */     if ("hasProjectNature".equals(property)) {
/* 619 */       return hasProjectNature(element, (String)args[0]);
/*     */     }
/* 621 */     if ("extendsInterface".equals(property)) {
/* 622 */       return implementsInterface(element, (String)args[0]);
/*     */     }
/* 624 */     if ("isPackageFragment".equals(property)) {
/* 625 */       return element instanceof org.eclipse.jdt.core.IPackageFragment;
/*     */     }
/* 627 */     if ("isPackageFragmentRoot".equals(property)) {
/* 628 */       return element instanceof org.eclipse.jdt.core.IPackageFragmentRoot;
/*     */     }
/* 630 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\JavaLaunchableTester.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */