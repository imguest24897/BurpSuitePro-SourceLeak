/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
/*    */ import org.eclipse.core.runtime.preferences.DefaultScope;
/*    */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*    */ import org.eclipse.jdt.launching.JavaRuntime;
/*    */ import org.osgi.service.prefs.BackingStoreException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LaunchingPreferenceInitializer
/*    */   extends AbstractPreferenceInitializer
/*    */ {
/*    */   public void initializeDefaultPreferences() {
/* 36 */     IEclipsePreferences dnode = DefaultScope.INSTANCE.getNode("org.eclipse.jdt.launching");
/* 37 */     if (dnode == null) {
/*    */       return;
/*    */     }
/* 40 */     dnode.putInt(JavaRuntime.PREF_CONNECT_TIMEOUT, 20000);
/* 41 */     dnode.put(JavaRuntime.PREF_STRICTLY_COMPATIBLE_JRE_NOT_AVAILABLE, "warning");
/* 42 */     dnode.put(JavaRuntime.PREF_COMPILER_COMPLIANCE_DOES_NOT_MATCH_JRE, "warning");
/* 43 */     dnode.putBoolean("org.eclipse.jdt.launching.only_include_exported_classpath_entries", false);
/*    */     try {
/* 45 */       dnode.flush();
/* 46 */     } catch (BackingStoreException e) {
/* 47 */       LaunchingPlugin.log((Throwable)e);
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 54 */     String launchFilter = "*.launch";
/* 55 */     dnode = DefaultScope.INSTANCE.getNode("org.eclipse.jdt.core");
/* 56 */     if (dnode == null) {
/*    */       return;
/*    */     }
/*    */ 
/*    */     
/* 61 */     String val = dnode.get("org.eclipse.jdt.core.builder.resourceCopyExclusionFilter", null);
/* 62 */     if (val != null && !"".equals(val)) {
/* 63 */       String[] filters = val.split(",");
/* 64 */       StringBuilder buff = new StringBuilder();
/* 65 */       boolean found = false;
/* 66 */       for (int i = 0; i < filters.length; i++) {
/* 67 */         if (launchFilter.equals(val)) {
/* 68 */           found = true;
/*    */           break;
/*    */         } 
/* 71 */         String filter = filters[i].trim();
/* 72 */         buff.append(filter);
/* 73 */         if (i < filters.length - 1) {
/* 74 */           buff.append(',');
/*    */         }
/*    */       } 
/* 77 */       if (!found) {
/* 78 */         launchFilter = buff.append(',').append(launchFilter).toString();
/* 79 */         dnode.put("org.eclipse.jdt.core.builder.resourceCopyExclusionFilter", launchFilter);
/*    */       } 
/*    */     } else {
/*    */       
/* 83 */       dnode.put("org.eclipse.jdt.core.builder.resourceCopyExclusionFilter", launchFilter);
/*    */     } 
/*    */     
/*    */     try {
/* 87 */       dnode.flush();
/* 88 */     } catch (BackingStoreException e) {
/* 89 */       LaunchingPlugin.log((Throwable)e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\LaunchingPreferenceInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */