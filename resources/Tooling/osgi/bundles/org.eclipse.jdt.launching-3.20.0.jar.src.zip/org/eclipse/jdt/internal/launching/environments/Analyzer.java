/*    */ package org.eclipse.jdt.internal.launching.environments;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.jdt.launching.IVMInstall;
/*    */ import org.eclipse.jdt.launching.environments.CompatibleEnvironment;
/*    */ import org.eclipse.jdt.launching.environments.IExecutionEnvironmentAnalyzerDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Analyzer
/*    */   implements IExecutionEnvironmentAnalyzerDelegate
/*    */ {
/*    */   private IConfigurationElement fElement;
/*    */   private IExecutionEnvironmentAnalyzerDelegate fDelegate;
/*    */   
/*    */   Analyzer(IConfigurationElement element) {
/* 36 */     this.fElement = element;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CompatibleEnvironment[] analyze(IVMInstall vm, IProgressMonitor monitor) throws CoreException {
/* 44 */     return getDelegate().analyze(vm, monitor);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private IExecutionEnvironmentAnalyzerDelegate getDelegate() throws CoreException {
/* 54 */     if (this.fDelegate == null) {
/* 55 */       this.fDelegate = (IExecutionEnvironmentAnalyzerDelegate)this.fElement.createExecutableExtension("class");
/*    */     }
/* 57 */     return this.fDelegate;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getId() {
/* 65 */     return this.fElement.getAttribute("id");
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\environments\Analyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */