package org.eclipse.jdt.launching;

public interface IVMInstall2 {
  String getVMArgs();
  
  void setVMArgs(String paramString);
  
  String getJavaVersion();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\IVMInstall2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */