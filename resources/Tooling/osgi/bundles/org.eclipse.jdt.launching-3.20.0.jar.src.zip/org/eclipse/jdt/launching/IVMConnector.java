package org.eclipse.jdt.launching;

import com.sun.jdi.connect.Connector;
import java.util.List;
import java.util.Map;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.debug.core.ILaunch;

public interface IVMConnector {
  void connect(Map<String, String> paramMap, IProgressMonitor paramIProgressMonitor, ILaunch paramILaunch) throws CoreException;
  
  String getName();
  
  String getIdentifier();
  
  Map<String, Connector.Argument> getDefaultArguments() throws CoreException;
  
  List<String> getArgumentOrder();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\IVMConnector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */