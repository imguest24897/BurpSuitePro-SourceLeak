package org.eclipse.jdt.internal.launching;

import java.io.File;
import java.util.List;

interface IProcessTempFileCreator {
  List<File> getProcessTempFiles();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\IProcessTempFileCreator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */