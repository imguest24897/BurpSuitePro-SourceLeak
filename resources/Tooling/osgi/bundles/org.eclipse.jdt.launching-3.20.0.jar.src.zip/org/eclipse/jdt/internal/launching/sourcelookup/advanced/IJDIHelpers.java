/*    */ package org.eclipse.jdt.internal.launching.sourcelookup.advanced;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.eclipse.debug.core.DebugException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IJDIHelpers
/*    */ {
/* 26 */   public static final IJDIHelpers INSTANCE = new JDIHelpers();
/*    */   
/*    */   File getClassesLocation(Object paramObject) throws DebugException;
/*    */   
/*    */   String getSourcePath(Object paramObject) throws DebugException;
/*    */   
/*    */   Iterable<File> getStackFramesClassesLocations(Object paramObject) throws DebugException;
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\sourcelookup\advanced\IJDIHelpers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */