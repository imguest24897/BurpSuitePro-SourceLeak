/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import org.eclipse.core.runtime.jobs.IJobChangeEvent;
/*     */ import org.eclipse.core.runtime.jobs.JobChangeAdapter;
/*     */ import org.eclipse.debug.core.DebugException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   extends JobChangeAdapter
/*     */ {
/*     */   public void running(IJobChangeEvent event) {
/* 127 */     SocketListenConnectorProcess.this.fireReadyToAcceptEvent();
/*     */   }
/*     */   
/*     */   public void done(IJobChangeEvent event) {
/* 131 */     if (event.getResult().isOK() && SocketListenConnectorProcess.this.continueListening()) {
/* 132 */       SocketListenConnectorProcess.this.fWaitForConnectionJob.schedule();
/*     */     } else {
/*     */       try {
/* 135 */         SocketListenConnectorProcess.this.terminate();
/* 136 */       } catch (DebugException debugException) {}
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\SocketListenConnectorProcess$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */