/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.jdt.core.IAccessRule;
/*     */ import org.eclipse.jdt.core.IClasspathAttribute;
/*     */ import org.eclipse.jdt.core.IClasspathContainer;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstallChangedListener;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.jdt.launching.LibraryLocation;
/*     */ import org.eclipse.jdt.launching.PropertyChangeEvent;
/*     */ import org.eclipse.jdt.launching.environments.IExecutionEnvironment;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JREContainer
/*     */   implements IClasspathContainer
/*     */ {
/*  50 */   private IVMInstall fVMInstall = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   private IPath fPath = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private IJavaProject fProject = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   private static Map<IVMInstall, IClasspathEntry[]> fgClasspathEntries = (Map)new HashMap<>(10);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private static IAccessRule[] EMPTY_RULES = new IAccessRule[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   private static Map<RuleKey, RuleEntry> fgClasspathEntriesWithRules = new HashMap<>(10);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class RuleKey
/*     */   {
/*  83 */     private String fEnvironmentId = null;
/*  84 */     private IVMInstall fInstall = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RuleKey(IVMInstall install, String environmentId) {
/*  92 */       this.fInstall = install;
/*  93 */       this.fEnvironmentId = environmentId;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 101 */       if (obj instanceof RuleKey) {
/* 102 */         RuleKey key = (RuleKey)obj;
/* 103 */         return (this.fEnvironmentId.equals(key.fEnvironmentId) && this.fInstall.equals(key.fInstall));
/*     */       } 
/* 105 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 113 */       return this.fEnvironmentId.hashCode() + this.fInstall.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class RuleEntry
/*     */   {
/* 123 */     private IAccessRule[][] fRules = null;
/* 124 */     private IClasspathEntry[] fEntries = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RuleEntry(IAccessRule[][] rules, IClasspathEntry[] entries) {
/* 132 */       this.fRules = rules;
/* 133 */       this.fEntries = entries;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IClasspathEntry[] getClasspathEntries() {
/* 141 */       return this.fEntries;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 149 */       IAccessRule[][] rules = null;
/* 150 */       if (obj instanceof RuleEntry) {
/* 151 */         rules = ((RuleEntry)obj).fRules;
/*     */       }
/* 153 */       if (obj instanceof IAccessRule[][]) {
/* 154 */         rules = (IAccessRule[][])obj;
/*     */       }
/* 156 */       if (this.fRules == rules) {
/* 157 */         return true;
/*     */       }
/* 159 */       if (rules != null && 
/* 160 */         this.fRules.length == rules.length) {
/* 161 */         for (int i = 0; i < this.fRules.length; i++) {
/* 162 */           if (!rulesEqual(this.fRules[i], rules[i])) {
/* 163 */             return false;
/*     */           }
/*     */         } 
/* 166 */         return true;
/*     */       } 
/*     */       
/* 169 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static boolean rulesEqual(IAccessRule[] a, IAccessRule[] b) {
/* 180 */       if (a == b) {
/* 181 */         return true;
/*     */       }
/* 183 */       if (a.length != b.length) {
/* 184 */         return false;
/*     */       }
/* 186 */       for (int j = 0; j < a.length; j++) {
/* 187 */         if (!a[j].equals(b[j])) {
/* 188 */           return false;
/*     */         }
/*     */       } 
/* 191 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 199 */     IVMInstallChangedListener listener = new IVMInstallChangedListener()
/*     */       {
/*     */         public void defaultVMInstallChanged(IVMInstall previous, IVMInstall current) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void vmAdded(IVMInstall newVm) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void vmChanged(PropertyChangeEvent event) {
/* 218 */           if (event.getSource() != null) {
/* 219 */             JREContainer.fgClasspathEntries.remove(event.getSource());
/* 220 */             removeRuleEntry(event.getSource());
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void vmRemoved(IVMInstall removedVm) {
/* 229 */           JREContainer.fgClasspathEntries.remove(removedVm);
/* 230 */           removeRuleEntry(removedVm);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private void removeRuleEntry(Object obj) {
/* 239 */           if (obj instanceof IVMInstall) {
/* 240 */             IVMInstall install = (IVMInstall)obj;
/* 241 */             JREContainer.RuleKey key = null;
/* 242 */             ArrayList<JREContainer.RuleKey> list = new ArrayList<>();
/* 243 */             for (Iterator<JREContainer.RuleKey> iter = JREContainer.fgClasspathEntriesWithRules.keySet().iterator(); iter.hasNext(); ) {
/* 244 */               key = iter.next();
/* 245 */               if (key.fInstall.equals(install)) {
/* 246 */                 list.add(key);
/*     */               }
/*     */             } 
/* 249 */             for (int i = 0; i < list.size(); i++) {
/* 250 */               JREContainer.fgClasspathEntriesWithRules.remove(list.get(i));
/*     */             }
/*     */           } 
/*     */         }
/*     */       };
/* 255 */     JavaRuntime.addVMInstallChangedListener(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IClasspathEntry[] getClasspathEntries(IVMInstall vm, IPath containerPath, IJavaProject project) {
/* 268 */     String id = JavaRuntime.getExecutionEnvironmentId(containerPath);
/* 269 */     IClasspathEntry[] entries = null;
/* 270 */     if (id == null) {
/*     */       
/* 272 */       entries = fgClasspathEntries.get(vm);
/* 273 */       if (entries == null) {
/* 274 */         entries = computeClasspathEntries(vm, project, id);
/* 275 */         fgClasspathEntries.put(vm, entries);
/*     */       } 
/*     */     } else {
/* 278 */       if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/* 279 */         LaunchingPlugin.trace("\tEE:\t" + id);
/*     */       }
/*     */       
/* 282 */       entries = computeClasspathEntries(vm, project, id);
/*     */     } 
/* 284 */     return entries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IClasspathEntry[] computeClasspathEntries(IVMInstall vm, IJavaProject project, String environmentId) {
/* 298 */     LibraryLocation[] libs = vm.getLibraryLocations();
/* 299 */     boolean overrideJavaDoc = false;
/* 300 */     if (libs == null) {
/* 301 */       libs = JavaRuntime.getLibraryLocations(vm);
/* 302 */       overrideJavaDoc = true;
/*     */     } 
/* 304 */     IAccessRule[][] rules = null;
/* 305 */     if (environmentId != null) {
/*     */       
/* 307 */       IExecutionEnvironment environment = JavaRuntime.getExecutionEnvironmentsManager().getEnvironment(environmentId);
/* 308 */       if (environment != null) {
/* 309 */         rules = environment.getAccessRules(vm, libs, project);
/*     */       }
/*     */     } 
/* 312 */     RuleKey key = null;
/* 313 */     if (vm != null && rules != null && environmentId != null) {
/* 314 */       key = new RuleKey(vm, environmentId);
/* 315 */       RuleEntry entry = fgClasspathEntriesWithRules.get(key);
/* 316 */       if (entry != null && entry.equals(rules)) {
/* 317 */         return entry.getClasspathEntries();
/*     */       }
/*     */     } 
/* 320 */     List<IClasspathEntry> entries = new ArrayList<>(libs.length);
/* 321 */     for (int i = 0; i < libs.length; i++) {
/* 322 */       if (!libs[i].getSystemLibraryPath().isEmpty()) {
/* 323 */         IPath sourcePath = libs[i].getSystemLibrarySourcePath();
/* 324 */         if (sourcePath.isEmpty()) {
/* 325 */           sourcePath = null;
/*     */         }
/* 327 */         IPath rootPath = libs[i].getPackageRootPath();
/* 328 */         if (rootPath.isEmpty()) {
/* 329 */           rootPath = null;
/*     */         }
/*     */         
/* 332 */         IClasspathAttribute[] attributes = buildClasspathAttributes(vm, libs[i], overrideJavaDoc);
/* 333 */         IAccessRule[] libRules = null;
/* 334 */         if (rules != null) {
/* 335 */           libRules = rules[i];
/*     */         } else {
/* 337 */           libRules = EMPTY_RULES;
/*     */         } 
/* 339 */         entries.add(JavaCore.newLibraryEntry(libs[i].getSystemLibraryPath(), sourcePath, rootPath, libRules, attributes, false));
/*     */       } 
/*     */     } 
/* 342 */     IClasspathEntry[] cpEntries = entries.<IClasspathEntry>toArray(new IClasspathEntry[entries.size()]);
/* 343 */     if (key != null && rules != null) {
/* 344 */       fgClasspathEntriesWithRules.put(key, new RuleEntry(rules, cpEntries));
/*     */     }
/* 346 */     return cpEntries;
/*     */   }
/*     */ 
/*     */   
/*     */   private static IClasspathAttribute[] buildClasspathAttributes(IVMInstall vm, LibraryLocation lib, boolean overrideJavaDoc) {
/* 351 */     List<IClasspathAttribute> classpathAttributes = new LinkedList<>();
/*     */     
/* 353 */     URL javadocLocation = lib.getJavadocLocation();
/* 354 */     if (overrideJavaDoc && javadocLocation == null) {
/* 355 */       javadocLocation = vm.getJavadocLocation();
/*     */     }
/* 357 */     if (javadocLocation != null) {
/* 358 */       IClasspathAttribute javadocCPAttribute = JavaCore.newClasspathAttribute("javadoc_location", javadocLocation.toExternalForm());
/* 359 */       classpathAttributes.add(javadocCPAttribute);
/*     */     } 
/*     */     
/* 362 */     URL indexLocation = lib.getIndexLocation();
/* 363 */     if (indexLocation != null) {
/* 364 */       IClasspathAttribute indexCPLocation = JavaCore.newClasspathAttribute("index_location", indexLocation.toExternalForm());
/* 365 */       classpathAttributes.add(indexCPLocation);
/*     */     } 
/* 367 */     IPath annotationsPath = lib.getExternalAnnotationsPath();
/* 368 */     if (annotationsPath != null && !annotationsPath.isEmpty()) {
/* 369 */       IClasspathAttribute xAnnLocation = JavaCore.newClasspathAttribute("annotationpath", annotationsPath.toPortableString());
/* 370 */       classpathAttributes.add(xAnnLocation);
/*     */     } 
/*     */     
/* 373 */     return classpathAttributes.<IClasspathAttribute>toArray(new IClasspathAttribute[classpathAttributes.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JREContainer(IVMInstall vm, IPath path, IJavaProject project) {
/* 384 */     this.fVMInstall = vm;
/* 385 */     this.fPath = path;
/* 386 */     this.fProject = project;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IClasspathEntry[] getClasspathEntries() {
/* 394 */     if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/* 395 */       LaunchingPlugin.trace("<JRE_CONTAINER> getClasspathEntries() " + toString());
/* 396 */       LaunchingPlugin.trace("\tJRE:\t" + this.fVMInstall.getName());
/* 397 */       LaunchingPlugin.trace("\tPath:\t" + getPath().toString());
/* 398 */       LaunchingPlugin.trace("\tProj:\t" + this.fProject.getProject().getName());
/*     */     } 
/* 400 */     IClasspathEntry[] entries = getClasspathEntries(this.fVMInstall, getPath(), this.fProject);
/* 401 */     if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/* 402 */       LaunchingPlugin.trace("\tResolved " + entries.length + " entries:");
/*     */     }
/* 404 */     return entries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 412 */     String environmentId = JavaRuntime.getExecutionEnvironmentId(getPath());
/* 413 */     String tag = null;
/* 414 */     if (environmentId == null) {
/* 415 */       tag = this.fVMInstall.getName();
/*     */     } else {
/* 417 */       tag = environmentId;
/*     */     } 
/* 419 */     return NLS.bind(LaunchingMessages.JREContainer_JRE_System_Library_1, (Object[])new String[] { tag });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getKind() {
/* 427 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getPath() {
/* 435 */     return this.fPath;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\JREContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */