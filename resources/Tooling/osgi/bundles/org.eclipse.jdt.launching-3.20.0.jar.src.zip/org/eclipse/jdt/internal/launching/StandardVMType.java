/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.IOException;
/*     */ import java.io.UncheckedIOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugException;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.Launch;
/*     */ import org.eclipse.debug.core.model.IProcess;
/*     */ import org.eclipse.debug.core.model.IStreamMonitor;
/*     */ import org.eclipse.debug.core.model.IStreamsProxy;
/*     */ import org.eclipse.debug.internal.core.OutputStreamMonitor;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.launching.AbstractVMInstallType;
/*     */ import org.eclipse.jdt.launching.ILibraryLocationResolver;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstallType;
/*     */ import org.eclipse.jdt.launching.LibraryLocation;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardVMType
/*     */   extends AbstractVMInstallType
/*     */ {
/*     */   private static final String RT_JAR = "rt.jar";
/*     */   private static final String SRC = "src";
/*     */   private static final String SRC_ZIP = "src.zip";
/*     */   private static final String SRC_JAR = "src.jar";
/*     */   private static final String JRE = "jre";
/*     */   private static final String LIB = "lib";
/*     */   private static final String BAR = "|";
/*     */   private static final String RELEASE_FILE = "release";
/*     */   private static final String JAVA_VERSION = "JAVA_VERSION";
/*     */   private static final String JRT_FS_JAR = "jrt-fs.jar";
/*     */   public static final String ID_STANDARD_VM_TYPE = "org.eclipse.jdt.internal.debug.ui.launcher.StandardVMType";
/*     */   public static final String MIN_VM_SIZE = "-Xmx16m";
/*     */   
/*     */   public StandardVMType() {
/* 113 */     this.fDefaultRootPath = "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   private static Map<String, LibraryInfo> fgFailedInstallPath = new HashMap<>();
/*     */   
/*     */   private static FilenameFilter fgArchiveFilter = new FilenameFilter() {
/*     */       public boolean accept(File arg0, String arg1) {
/*     */         return !(!arg1.endsWith(".zip") && !arg1.endsWith(".jar"));
/*     */       }
/*     */     };
/*     */   
/*     */   private String fDefaultRootPath;
/* 128 */   private static Map<String, List<LibraryLocation>> fgDefaultLibLocs = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   private static final String[] fgCandidateJavaFiles = new String[] { "javaw", "javaw.exe", "java", "java.exe", "j9w", "j9w.exe", "j9", "j9.exe" };
/* 135 */   private static final String[] fgCandidateJavaLocations = new String[] { File.separator, "bin" + File.separatorChar, 
/* 136 */       "jre" + File.separatorChar + "bin" + File.separatorChar };
/*     */   
/* 138 */   private static ILibraryLocationResolver[] fgLibraryLocationResolvers = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File findJavaExecutable(File vmInstallLocation) {
/* 151 */     boolean isBin = false;
/* 152 */     String filePath = vmInstallLocation.getPath();
/* 153 */     int index = filePath.lastIndexOf(File.separatorChar);
/* 154 */     if (index > 0 && filePath.substring(index + 1).equals("bin")) {
/* 155 */       isBin = true;
/*     */     }
/* 157 */     for (int i = 0; i < fgCandidateJavaFiles.length; i++) {
/* 158 */       for (int j = 0; j < fgCandidateJavaLocations.length; j++) {
/* 159 */         if (isBin || j != 0) {
/*     */ 
/*     */ 
/*     */           
/* 163 */           File javaFile = new File(vmInstallLocation, String.valueOf(fgCandidateJavaLocations[j]) + fgCandidateJavaFiles[i]);
/* 164 */           if (javaFile.isFile())
/* 165 */             return javaFile; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 169 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ILibraryLocationResolver[] getLibraryLocationResolvers() {
/* 179 */     if (fgLibraryLocationResolvers == null) {
/* 180 */       IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.jdt.launching", "libraryLocationResolvers");
/* 181 */       IConfigurationElement[] configs = extensionPoint.getConfigurationElements();
/*     */ 
/*     */       
/* 184 */       Arrays.sort(configs, new Comparator<IConfigurationElement>()
/*     */           {
/*     */             public int compare(IConfigurationElement e1, IConfigurationElement e2) {
/* 187 */               return e1.getNamespaceIdentifier().compareTo(e2.getNamespaceIdentifier());
/*     */             }
/*     */           });
/* 190 */       List<ILibraryLocationResolver> resolvers = new ArrayList<>(configs.length);
/* 191 */       for (int i = 0; i < configs.length; i++) {
/* 192 */         IConfigurationElement e = configs[i];
/*     */         try {
/* 194 */           resolvers.add((ILibraryLocationResolver)e.createExecutableExtension("class"));
/*     */         }
/* 196 */         catch (CoreException e1) {
/* 197 */           LaunchingPlugin.log(e1.getStatus());
/*     */         } 
/*     */       } 
/* 200 */       fgLibraryLocationResolvers = resolvers.<ILibraryLocationResolver>toArray(new ILibraryLocationResolver[0]);
/*     */     } 
/* 202 */     return fgLibraryLocationResolvers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 210 */     return LaunchingMessages.StandardVMType_Standard_VM_3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IVMInstall doCreateVMInstall(String id) {
/* 218 */     return (IVMInstall)new StandardVM((IVMInstallType)this, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized LibraryInfo getLibraryInfo(File javaHome, File javaExecutable) {
/* 230 */     String installPath = javaHome.getAbsolutePath();
/* 231 */     LibraryInfo info = LaunchingPlugin.getLibraryInfo(installPath);
/* 232 */     if (info == null || LaunchingPlugin.timeStampChanged(installPath)) {
/* 233 */       info = fgFailedInstallPath.get(installPath);
/* 234 */       if (info == null) {
/* 235 */         String version = readReleaseVersion(javaHome);
/* 236 */         if (JavaCore.compareJavaVersions(version, "1.8") > 0) {
/* 237 */           info = new LibraryInfo(version, new String[0], new String[0], new String[0]);
/* 238 */           LaunchingPlugin.setLibraryInfo(installPath, info);
/*     */         } else {
/* 240 */           info = generateLibraryInfo(javaHome, javaExecutable);
/* 241 */           if (info == null)
/*     */           {
/* 243 */             info = generateLibraryInfo(javaHome, javaExecutable);
/*     */           }
/* 245 */           if (info == null) {
/* 246 */             info = getDefaultLibraryInfo(javaHome);
/* 247 */             fgFailedInstallPath.put(installPath, info);
/*     */           } else {
/*     */             
/* 250 */             LaunchingPlugin.setLibraryInfo(installPath, info);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 255 */     return info;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean canDetectDefaultSystemLibraries(File javaHome, File javaExecutable) {
/* 267 */     LibraryLocation[] locations = getDefaultLibraryLocations(javaHome);
/* 268 */     String version = getVMVersion(javaHome, javaExecutable);
/* 269 */     return (locations.length > 0 && !version.startsWith("1.1"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getVMVersion(File javaHome, File javaExecutable) {
/* 281 */     LibraryInfo info = getLibraryInfo(javaHome, javaExecutable);
/* 282 */     return info.getVersion();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File detectInstallLocation() {
/* 291 */     if ("macosx".equals(Platform.getOS())) {
/* 292 */       return null;
/*     */     }
/* 294 */     return getJavaHomeLocation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected File getJavaHomeLocation() {
/*     */     File javaHome;
/*     */     try {
/* 311 */       javaHome = (new File(System.getProperty("java.home"))).getCanonicalFile();
/* 312 */     } catch (IOException e) {
/* 313 */       LaunchingPlugin.log(e);
/* 314 */       return null;
/*     */     } 
/* 316 */     if (!javaHome.exists()) {
/* 317 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 322 */     File javaExecutable = findJavaExecutable(javaHome);
/* 323 */     if (javaExecutable == null) {
/* 324 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 329 */     boolean foundLibraries = false;
/* 330 */     if (javaHome.getName().equalsIgnoreCase("jre")) {
/* 331 */       File parent = new File(javaHome.getParent());
/* 332 */       if (canDetectDefaultSystemLibraries(parent, javaExecutable)) {
/* 333 */         javaHome = parent;
/* 334 */         foundLibraries = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 339 */     if (!foundLibraries && 
/* 340 */       !canDetectDefaultSystemLibraries(javaHome, javaExecutable)) {
/* 341 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 345 */     return javaHome;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IPath getDefaultSystemLibrary(File javaHome) {
/* 356 */     IPath jreLibPath = (new Path(javaHome.getPath())).append("lib").append("rt.jar");
/* 357 */     if (jreLibPath.toFile().isFile()) {
/* 358 */       return jreLibPath;
/*     */     }
/* 360 */     return (new Path(javaHome.getPath())).append("jre").append("lib").append("rt.jar");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IPath getDefaultSystemLibrarySource(File libLocation) {
/* 372 */     File parent = libLocation.getParentFile();
/* 373 */     while (parent != null) {
/* 374 */       File parentsrc = new File(parent, "src.jar");
/* 375 */       if (parentsrc.isFile()) {
/* 376 */         setDefaultRootPath("src");
/* 377 */         return (IPath)new Path(parentsrc.getPath());
/*     */       } 
/* 379 */       parentsrc = new File(parent, "src.zip");
/* 380 */       if (parentsrc.isFile()) {
/* 381 */         setDefaultRootPath("");
/* 382 */         return (IPath)new Path(parentsrc.getPath());
/*     */       } 
/* 384 */       parent = parent.getParentFile();
/*     */     } 
/*     */     
/* 387 */     IPath result = checkForJ9LibrarySource(libLocation);
/* 388 */     if (result != null) {
/* 389 */       return result;
/*     */     }
/*     */     
/* 392 */     Path path = new Path(libLocation.getName());
/* 393 */     String extension = path.getFileExtension();
/* 394 */     String prefix = path.removeFileExtension().lastSegment();
/* 395 */     if (extension != null) {
/* 396 */       Path path1 = new Path(libLocation.getPath());
/* 397 */       IPath iPath = path1.removeLastSegments(1);
/* 398 */       StringBuilder buf = new StringBuilder();
/* 399 */       buf.append(prefix);
/* 400 */       buf.append("-src.");
/* 401 */       buf.append(extension);
/* 402 */       iPath = iPath.append(buf.toString());
/* 403 */       if (iPath.toFile().exists()) {
/* 404 */         return iPath;
/*     */       }
/*     */     } 
/* 407 */     setDefaultRootPath("");
/* 408 */     return (IPath)Path.EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private IPath checkForJ9LibrarySource(File libLocation) {
/* 414 */     File parent = libLocation.getParentFile();
/* 415 */     String name = libLocation.getName();
/* 416 */     if (name.equalsIgnoreCase("classes.zip")) {
/* 417 */       File source = new File(parent, "source/source.zip");
/* 418 */       return source.isFile() ? (IPath)new Path(source.getPath()) : (IPath)Path.EMPTY;
/*     */     } 
/* 420 */     if (name.equalsIgnoreCase("locale.zip")) {
/* 421 */       File source = new File(parent, "source/locale-src.zip");
/* 422 */       return source.isFile() ? (IPath)new Path(source.getPath()) : (IPath)Path.EMPTY;
/*     */     } 
/* 424 */     if (name.equalsIgnoreCase("charconv.zip")) {
/* 425 */       File source = new File(parent, "charconv-src.zip");
/* 426 */       return source.isFile() ? (IPath)new Path(source.getPath()) : (IPath)Path.EMPTY;
/*     */     } 
/* 428 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IPath getDefaultPackageRootPath() {
/* 437 */     return (IPath)new Path(getDefaultRootPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LibraryLocation[] getDefaultLibraryLocations(File installLocation) {
/* 450 */     List<LibraryLocation> allLibs = fgDefaultLibLocs.get(installLocation.getAbsolutePath());
/* 451 */     if (allLibs == null) {
/* 452 */       LibraryInfo libInfo; File javaExecutable = findJavaExecutable(installLocation);
/*     */       
/* 454 */       if (javaExecutable == null) {
/* 455 */         libInfo = getDefaultLibraryInfo(installLocation);
/*     */       } else {
/* 457 */         libInfo = getLibraryInfo(installLocation, javaExecutable);
/*     */       } 
/*     */ 
/*     */       
/* 461 */       allLibs = new ArrayList<>(gatherAllLibraries(libInfo.getEndorsedDirs()));
/* 462 */       URL url = getDefaultJavadocLocation(installLocation);
/* 463 */       if ((libInfo.getBootpath()).length == 0) {
/*     */         IPath iPath1;
/*     */ 
/*     */         
/* 467 */         Path path1 = Path.EMPTY;
/*     */         
/* 469 */         IPath path = (new Path(installLocation.getAbsolutePath())).append("lib").append("src.zip");
/* 470 */         File file1 = path.toFile();
/* 471 */         if (file1.exists() && file1.isFile()) {
/* 472 */           iPath1 = getDefaultSystemLibrarySource(file1);
/*     */         } else {
/* 474 */           path = (new Path(installLocation.getAbsolutePath())).append("src.zip");
/* 475 */           file1 = path.toFile();
/* 476 */           if (file1.exists() && file1.isFile()) {
/* 477 */             iPath1 = getDefaultSystemLibrarySource(file1);
/*     */           }
/*     */         } 
/* 480 */         IPath pathName = (new Path(installLocation.getAbsolutePath())).append("lib").append("jrt-fs.jar");
/*     */         
/* 482 */         File jrtfsJar = pathName.toFile();
/* 483 */         boolean exists = jrtfsJar.exists();
/* 484 */         if (!exists) {
/* 485 */           pathName = (new Path(installLocation.getAbsolutePath())).append("jrt-fs.jar");
/* 486 */           exists = pathName.toFile().exists();
/*     */         } 
/*     */         
/* 489 */         if (exists) {
/* 490 */           LibraryLocation libraryLocation = new LibraryLocation(pathName, iPath1, getDefaultPackageRootPath(), getDefaultJavadocLocation(installLocation));
/* 491 */           allLibs.add(libraryLocation);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 496 */       String[] bootpath = libInfo.getBootpath();
/* 497 */       List<LibraryLocation> boot = new ArrayList<>(bootpath.length);
/*     */       
/* 499 */       for (int i = 0; i < bootpath.length; i++) {
/* 500 */         Path path = new Path(bootpath[i]);
/* 501 */         File file = path.toFile();
/* 502 */         if (file.exists() && file.isFile()) {
/* 503 */           LibraryLocation libraryLocation = new LibraryLocation((IPath)path, 
/* 504 */               getDefaultSystemLibrarySource(file), 
/* 505 */               getDefaultPackageRootPath(), 
/* 506 */               url);
/* 507 */           boot.add(libraryLocation);
/*     */         } 
/*     */       } 
/* 510 */       allLibs.addAll(boot);
/*     */ 
/*     */       
/* 513 */       allLibs.addAll(gatherAllLibraries(libInfo.getExtensionDirs()));
/*     */ 
/*     */       
/* 516 */       HashSet<String> set = new HashSet<>();
/* 517 */       LibraryLocation lib = null;
/* 518 */       for (ListIterator<LibraryLocation> liter = allLibs.listIterator(); liter.hasNext(); ) {
/* 519 */         lib = liter.next();
/* 520 */         IPath systemLibraryPath = lib.getSystemLibraryPath();
/* 521 */         String device = systemLibraryPath.getDevice();
/* 522 */         if (device != null)
/*     */         {
/* 524 */           systemLibraryPath = systemLibraryPath.setDevice(device.toUpperCase());
/*     */         }
/* 526 */         if (!set.add(systemLibraryPath.toOSString()))
/*     */         {
/* 528 */           liter.remove();
/*     */         }
/*     */       } 
/* 531 */       fgDefaultLibLocs.put(installLocation.getAbsolutePath(), allLibs);
/*     */     } 
/* 533 */     return allLibs.<LibraryLocation>toArray(new LibraryLocation[allLibs.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LibraryInfo getDefaultLibraryInfo(File installLocation) {
/* 543 */     IPath rtjar = getDefaultSystemLibrary(installLocation);
/* 544 */     File extDir = getDefaultExtensionDirectory(installLocation);
/* 545 */     File endDir = getDefaultEndorsedDirectory(installLocation);
/* 546 */     String[] dirs = null;
/* 547 */     if (extDir == null) {
/* 548 */       dirs = new String[0];
/*     */     } else {
/* 550 */       dirs = new String[] { extDir.getAbsolutePath() };
/*     */     } 
/* 552 */     String[] endDirs = null;
/* 553 */     if (endDir == null) {
/* 554 */       endDirs = new String[0];
/*     */     } else {
/* 556 */       endDirs = new String[] { endDir.getAbsolutePath() };
/*     */     } 
/* 558 */     return new LibraryInfo("???", new String[] { rtjar.toOSString() }, dirs, endDirs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<LibraryLocation> gatherAllLibraries(String[] dirPaths) {
/* 568 */     List<LibraryLocation> libraries = new ArrayList<>();
/* 569 */     for (int i = 0; i < dirPaths.length; i++) {
/* 570 */       File extDir = new File(dirPaths[i]);
/* 571 */       if (extDir.isDirectory()) {
/* 572 */         String[] names = extDir.list(fgArchiveFilter);
/* 573 */         if (names != null) {
/* 574 */           for (int j = 0; j < names.length; j++) {
/* 575 */             File jar = new File(extDir, names[j]);
/* 576 */             if (jar.isFile()) {
/*     */               try {
/* 578 */                 IPath iPath1, iPath2; Path path1 = new Path(jar.getCanonicalPath());
/* 579 */                 Path path2 = Path.EMPTY;
/* 580 */                 Path path3 = Path.EMPTY;
/* 581 */                 URL javadocLocation = null;
/* 582 */                 URL indexLocation = null; byte b; int k; ILibraryLocationResolver[] arrayOfILibraryLocationResolver;
/* 583 */                 for (k = (arrayOfILibraryLocationResolver = getLibraryLocationResolvers()).length, b = 0; b < k; ) { ILibraryLocationResolver resolver = arrayOfILibraryLocationResolver[b];
/*     */                   try {
/* 585 */                     iPath1 = resolver.getSourcePath((IPath)path1);
/* 586 */                     iPath2 = resolver.getPackageRoot((IPath)path1);
/* 587 */                     javadocLocation = resolver.getJavadocLocation((IPath)path1);
/* 588 */                     indexLocation = resolver.getIndexLocation((IPath)path1);
/* 589 */                     if (iPath1 != Path.EMPTY || iPath2 != Path.EMPTY || javadocLocation != null || indexLocation != null) {
/*     */                       break;
/*     */                     }
/* 592 */                   } catch (Exception e) {
/* 593 */                     LaunchingPlugin.log(e);
/*     */                   }  b++; }
/*     */                 
/* 596 */                 LibraryLocation library = new LibraryLocation((IPath)path1, iPath1, iPath2, javadocLocation, indexLocation);
/* 597 */                 libraries.add(library);
/* 598 */               } catch (IOException e) {
/* 599 */                 LaunchingPlugin.log(e);
/*     */               } 
/*     */             }
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 606 */     return libraries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected File getDefaultExtensionDirectory(File installLocation) {
/* 618 */     File jre = null;
/* 619 */     if (installLocation.getName().equalsIgnoreCase("jre")) {
/* 620 */       jre = installLocation;
/*     */     } else {
/* 622 */       jre = new File(installLocation, "jre");
/*     */     } 
/* 624 */     File lib = new File(jre, "lib");
/* 625 */     File ext = new File(lib, "ext");
/* 626 */     return ext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected File getDefaultEndorsedDirectory(File installLocation) {
/* 638 */     File lib = new File(installLocation, "lib");
/* 639 */     File ext = new File(lib, "endorsed");
/* 640 */     return ext;
/*     */   }
/*     */   
/*     */   protected String getDefaultRootPath() {
/* 644 */     return this.fDefaultRootPath;
/*     */   }
/*     */   
/*     */   protected void setDefaultRootPath(String defaultRootPath) {
/* 648 */     this.fDefaultRootPath = defaultRootPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus validateInstallLocation(File javaHome) {
/*     */     Status status1;
/* 656 */     IStatus status = null;
/* 657 */     File javaExecutable = findJavaExecutable(javaHome);
/* 658 */     if (javaExecutable == null) {
/* 659 */       status1 = new Status(4, LaunchingPlugin.getUniqueIdentifier(), 0, LaunchingMessages.StandardVMType_Not_a_JDK_Root__Java_executable_was_not_found_1, null);
/*     */     } else {
/* 661 */       File javaHomeNew = javaHome;
/*     */       
/* 663 */       if (canDetectDefaultSystemLibraries(javaHomeNew, javaExecutable)) {
/* 664 */         status1 = new Status(0, LaunchingPlugin.getUniqueIdentifier(), 0, LaunchingMessages.StandardVMType_ok_2, null);
/*     */       } else {
/* 666 */         status1 = new Status(4, LaunchingPlugin.getUniqueIdentifier(), 0, LaunchingMessages.StandardVMType_Not_a_JDK_root__System_library_was_not_found__1, null);
/*     */       } 
/*     */     } 
/* 669 */     return (IStatus)status1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LibraryInfo generateLibraryInfo(File javaHome, File javaExecutable) {
/* 685 */     LibraryInfo info = null;
/*     */ 
/*     */     
/* 688 */     IPath classesZip = (new Path(javaHome.getAbsolutePath())).append("lib").append("classes.zip");
/* 689 */     if (classesZip.toFile().exists()) {
/* 690 */       return new LibraryInfo("1.1.x", new String[] { classesZip.toOSString() }, new String[0], new String[0]);
/*     */     }
/*     */     
/* 693 */     File file = LaunchingPlugin.getFileInPlugin((IPath)new Path("lib/launchingsupport.jar"));
/* 694 */     if (file != null && file.exists()) {
/* 695 */       String javaExecutablePath = javaExecutable.getAbsolutePath();
/* 696 */       String[] cmdLine = { javaExecutablePath, "-Xmx16m", 
/* 697 */           "-classpath", file.getAbsolutePath(), "org.eclipse.jdt.internal.launching.support.LibraryDetector" };
/* 698 */       Process p = null;
/*     */       try {
/* 700 */         String[] envp = null;
/* 701 */         if ("macosx".equals(Platform.getOS())) {
/* 702 */           Map<String, String> map = DebugPlugin.getDefault().getLaunchManager().getNativeEnvironmentCasePreserved();
/* 703 */           if (map.remove("JAVA_JVM_VERSION") != null) {
/* 704 */             envp = new String[map.size()];
/* 705 */             Iterator<Map.Entry<String, String>> iterator = map.entrySet().iterator();
/* 706 */             int j = 0;
/* 707 */             while (iterator.hasNext()) {
/* 708 */               Map.Entry<String, String> entry = iterator.next();
/* 709 */               envp[j] = String.valueOf(entry.getKey()) + "=" + (String)entry.getValue();
/* 710 */               j++;
/*     */             } 
/*     */           } 
/*     */         } 
/* 714 */         p = DebugPlugin.exec(cmdLine, null, envp);
/* 715 */         IProcess process = DebugPlugin.newProcess((ILaunch)new Launch(null, "run", null), p, "Library Detection");
/* 716 */         process.setAttribute(IProcess.ATTR_CMDLINE, String.join(" ", (CharSequence[])cmdLine));
/* 717 */         IStreamMonitor outputStreamMonitor = process.getStreamsProxy().getOutputStreamMonitor();
/* 718 */         for (int i = 0; i < 600; i++) {
/*     */ 
/*     */           
/* 721 */           if (process.isTerminated() && isReadingDone(outputStreamMonitor)) {
/*     */             break;
/*     */           }
/*     */           try {
/* 725 */             Thread.sleep(50L);
/* 726 */           } catch (InterruptedException e) {
/* 727 */             LaunchingPlugin.log(e);
/*     */           } 
/*     */         } 
/* 730 */         checkProcessResult(process);
/* 731 */         info = parseLibraryInfo(process);
/* 732 */       } catch (Throwable ioe) {
/* 733 */         LaunchingPlugin.log(ioe);
/*     */       } finally {
/* 735 */         if (p != null) {
/* 736 */           p.destroy();
/*     */         }
/*     */       } 
/*     */     } 
/* 740 */     if (info == null)
/*     */     {
/* 742 */       LaunchingPlugin.log(NLS.bind("Failed to retrieve default libraries for {0}", (Object[])new String[] { javaHome.getAbsolutePath() }));
/*     */     }
/* 744 */     return info;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isReadingDone(IStreamMonitor monitor) {
/* 749 */     if (monitor instanceof OutputStreamMonitor) {
/* 750 */       return ((OutputStreamMonitor)monitor).isReadingDone();
/*     */     }
/* 752 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LibraryInfo parseLibraryInfo(IProcess process) {
/* 762 */     IStreamsProxy streamsProxy = process.getStreamsProxy();
/* 763 */     String text = null;
/* 764 */     if (streamsProxy != null) {
/* 765 */       text = streamsProxy.getOutputStreamMonitor().getContents();
/*     */     }
/* 767 */     if (text != null && text.length() > 0) {
/* 768 */       int index = text.indexOf("|");
/* 769 */       if (index > 0) {
/* 770 */         String version = text.substring(0, index);
/* 771 */         text = text.substring(index + 1);
/* 772 */         index = text.indexOf("|");
/* 773 */         if (index > 0) {
/* 774 */           String bootPaths = text.substring(0, index);
/* 775 */           String[] bootPath = parsePaths(bootPaths);
/*     */           
/* 777 */           text = text.substring(index + 1);
/* 778 */           index = text.indexOf("|");
/*     */           
/* 780 */           if (index > 0) {
/* 781 */             String extDirPaths = text.substring(0, index);
/* 782 */             String endorsedDirsPath = text.substring(index + 1);
/* 783 */             String[] extDirs = parsePaths(extDirPaths);
/* 784 */             String[] endDirs = parsePaths(endorsedDirsPath);
/* 785 */             return new LibraryInfo(version, bootPath, extDirs, endDirs);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 790 */     return null;
/*     */   }
/*     */   
/*     */   protected String[] parsePaths(String paths) {
/* 794 */     List<String> list = new ArrayList<>();
/* 795 */     int pos = 0;
/* 796 */     int index = paths.indexOf(File.pathSeparatorChar, pos);
/* 797 */     while (index > 0) {
/* 798 */       String str = paths.substring(pos, index);
/* 799 */       list.add(str);
/* 800 */       pos = index + 1;
/* 801 */       index = paths.indexOf(File.pathSeparatorChar, pos);
/*     */     } 
/* 803 */     String path = paths.substring(pos);
/* 804 */     if (!path.equals("null")) {
/* 805 */       list.add(path);
/*     */     }
/* 807 */     return list.<String>toArray(new String[list.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disposeVMInstall(String id) {
/* 815 */     IVMInstall vm = findVMInstall(id);
/* 816 */     if (vm != null) {
/* 817 */       String path = vm.getInstallLocation().getAbsolutePath();
/* 818 */       LaunchingPlugin.setLibraryInfo(path, null);
/* 819 */       fgFailedInstallPath.remove(path);
/* 820 */       fgDefaultLibLocs.remove(path);
/*     */     } 
/* 822 */     super.disposeVMInstall(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getDefaultJavadocLocation(File installLocation) {
/* 830 */     File javaExecutable = findJavaExecutable(installLocation);
/* 831 */     if (javaExecutable != null) {
/* 832 */       LibraryInfo libInfo = getLibraryInfo(installLocation, javaExecutable);
/* 833 */       if (libInfo != null) {
/* 834 */         String version = libInfo.getVersion();
/* 835 */         return getDefaultJavadocLocation(version);
/*     */       } 
/*     */     } 
/* 838 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL getDefaultJavadocLocation(String version) {
/*     */     try {
/* 849 */       if (version.startsWith("20"))
/* 850 */         return new URL("https://docs.oracle.com/en/java/javase/20/docs/api/"); 
/* 851 */       if (version.startsWith("19"))
/* 852 */         return new URL("https://docs.oracle.com/en/java/javase/19/docs/api/"); 
/* 853 */       if (version.startsWith("18"))
/* 854 */         return new URL("https://docs.oracle.com/en/java/javase/18/docs/api/"); 
/* 855 */       if (version.startsWith("17"))
/* 856 */         return new URL("https://docs.oracle.com/en/java/javase/17/docs/api/"); 
/* 857 */       if (version.startsWith("16"))
/* 858 */         return new URL("https://docs.oracle.com/en/java/javase/16/docs/api/"); 
/* 859 */       if (version.startsWith("15"))
/* 860 */         return new URL("https://docs.oracle.com/en/java/javase/15/docs/api/"); 
/* 861 */       if (version.startsWith("14"))
/* 862 */         return new URL("https://docs.oracle.com/en/java/javase/14/docs/api/"); 
/* 863 */       if (version.startsWith("13"))
/* 864 */         return new URL("https://docs.oracle.com/en/java/javase/13/docs/api/"); 
/* 865 */       if (version.startsWith("12"))
/* 866 */         return new URL("https://docs.oracle.com/en/java/javase/12/docs/api/"); 
/* 867 */       if (version.startsWith("11"))
/* 868 */         return new URL("https://docs.oracle.com/en/java/javase/11/docs/api/"); 
/* 869 */       if (version.startsWith("10"))
/* 870 */         return new URL("https://docs.oracle.com/javase/10/docs/api/"); 
/* 871 */       if (version.startsWith("9"))
/* 872 */         return new URL("https://docs.oracle.com/javase/9/docs/api/"); 
/* 873 */       if (version.startsWith("1.8"))
/* 874 */         return new URL("https://docs.oracle.com/javase/8/docs/api/"); 
/* 875 */       if (version.startsWith("1.7"))
/* 876 */         return new URL("https://docs.oracle.com/javase/7/docs/api/"); 
/* 877 */       if (version.startsWith("1.6"))
/* 878 */         return new URL("https://docs.oracle.com/javase/6/docs/api/"); 
/* 879 */       if (version.startsWith("1.5"))
/* 880 */         return new URL("https://docs.oracle.com/javase/1.5.0/docs/api/"); 
/* 881 */       if (version.startsWith("1.4"))
/*     */       {
/* 883 */         return new URL("https://docs.oracle.com/javase/1.5.0/docs/api/"); } 
/* 884 */       if (version.startsWith("1.3"))
/*     */       {
/* 886 */         return new URL("https://docs.oracle.com/javase/1.5.0/docs/api/");
/*     */       }
/* 888 */     } catch (MalformedURLException malformedURLException) {}
/*     */     
/* 890 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized String readReleaseVersion(File javaHome) {
/* 895 */     String version = "";
/*     */     
/* 897 */     if (Files.notExists(Paths.get(javaHome.getAbsolutePath(), new String[] { "release" }), new java.nio.file.LinkOption[0]))
/* 898 */       return version; 
/*     */     try {
/* 900 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 907 */     catch (UncheckedIOException|IOException e) {
/* 908 */       LaunchingPlugin.log(e);
/*     */     } 
/*     */     
/* 911 */     return version;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkProcessResult(IProcess process) throws DebugException {
/* 919 */     boolean isTerminated = process.isTerminated();
/* 920 */     if (!isTerminated) {
/* 921 */       String output = getOutput(process);
/* 922 */       Object[] errorInfo = { process.getAttribute(IProcess.ATTR_CMDLINE), output };
/* 923 */       String errorMessage = NLS.bind("Process not finished.\n Command line arguments: {0}\nOutput: {1}", errorInfo);
/* 924 */       IllegalStateException exception = new IllegalStateException(errorMessage);
/* 925 */       LaunchingPlugin.log(exception);
/*     */     } else {
/* 927 */       int exitCode = process.getExitValue();
/* 928 */       if (exitCode != 0) {
/* 929 */         String output = getOutput(process);
/* 930 */         Object[] errorInfo = { Integer.valueOf(exitCode), process.getAttribute(IProcess.ATTR_CMDLINE), output };
/* 931 */         String errorMessage = NLS.bind("Process returned with error code \"{0}\".\nCommand line arguments: {1}\nOutput: {2}", errorInfo);
/* 932 */         IllegalStateException exception = new IllegalStateException(errorMessage);
/* 933 */         LaunchingPlugin.log(exception);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String getOutput(IProcess process) {
/* 939 */     IStreamsProxy streamsProxy = process.getStreamsProxy();
/* 940 */     String output = "IProcess.getStreamsProxy() returned null";
/* 941 */     if (streamsProxy != null) {
/* 942 */       String[] lines = { "Standard output:", 
/* 943 */           streamsProxy.getOutputStreamMonitor().getContents(), "Standard error:", 
/* 944 */           streamsProxy.getErrorStreamMonitor().getContents() };
/* 945 */       output = String.join(System.lineSeparator(), Arrays.asList((CharSequence[])lines));
/*     */     } 
/* 947 */     return output;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\StandardVMType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */