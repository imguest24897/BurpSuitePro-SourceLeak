/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.io.File;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstallType;
/*     */ import org.eclipse.jdt.launching.LibraryLocation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Standard11xVMType
/*     */   extends StandardVMType
/*     */ {
/*     */   protected IPath getDefaultSystemLibrary(File installLocation) {
/*  35 */     return (new Path(installLocation.getPath())).append("lib").append("classes.zip");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IVMInstall doCreateVMInstall(String id) {
/*  43 */     return (IVMInstall)new Standard11xVM((IVMInstallType)this, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IPath getDefaultSystemLibrarySource(File libLocation) {
/*  51 */     setDefaultRootPath("");
/*  52 */     return (IPath)Path.EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  60 */     return LaunchingMessages.Standard11xVMType_Standard_1_1_x_VM_1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected File getDefaultExtensionDirectory(File installLocation) {
/*  70 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected File getDefaultEndorsedDirectory(File installLocation) {
/*  78 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LibraryLocation[] getDefaultLibraryLocations(File installLocation) {
/*  86 */     IPath libPath = getDefaultSystemLibrary(installLocation);
/*  87 */     File lib = libPath.toFile();
/*  88 */     if (lib.exists()) {
/*  89 */       return new LibraryLocation[] { new LibraryLocation(libPath, getDefaultSystemLibrarySource(lib), getDefaultPackageRootPath()) };
/*     */     }
/*  91 */     return new LibraryLocation[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean canDetectDefaultSystemLibraries(File javaHome, File javaExecutable) {
/* 100 */     LibraryLocation[] locations = getDefaultLibraryLocations(javaHome);
/* 101 */     String version = getVMVersion(javaHome, javaExecutable);
/* 102 */     return (locations.length > 0 && version.startsWith("1.1"));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\Standard11xVMType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */