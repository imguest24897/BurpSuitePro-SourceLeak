/*     */ package org.eclipse.jdt.launching.sourcelookup.containers;
/*     */ 
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceLookupDirector;
/*     */ import org.eclipse.debug.core.sourcelookup.containers.CompositeSourceContainer;
/*     */ import org.eclipse.jdt.core.IClasspathContainer;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClasspathContainerSourceContainer
/*     */   extends CompositeSourceContainer
/*     */ {
/*     */   private IPath fContainerPath;
/*  50 */   public static final String TYPE_ID = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".sourceContainer.classpathContainer";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClasspathContainerSourceContainer(IPath containerPath) {
/*  58 */     this.fContainerPath = containerPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  66 */     IClasspathContainer container = null;
/*     */     try {
/*  68 */       container = getClasspathContainer();
/*  69 */     } catch (CoreException coreException) {}
/*     */     
/*  71 */     if (container == null) {
/*  72 */       return getPath().lastSegment();
/*     */     }
/*  74 */     return container.getDescription();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISourceContainerType getType() {
/*  81 */     return getSourceContainerType(TYPE_ID);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ISourceContainer[] createSourceContainers() throws CoreException {
/*  89 */     IRuntimeClasspathEntry entry = JavaRuntime.newRuntimeContainerClasspathEntry(getPath(), 3);
/*  90 */     IRuntimeClasspathEntry[] entries = JavaRuntime.resolveSourceLookupPath(new IRuntimeClasspathEntry[] { entry }, getDirector().getLaunchConfiguration());
/*  91 */     return JavaRuntime.getSourceContainers(entries);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getPath() {
/* 100 */     return this.fContainerPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 108 */     if (obj instanceof ClasspathContainerSourceContainer) {
/* 109 */       return getPath().equals(((ClasspathContainerSourceContainer)obj).getPath());
/*     */     }
/* 111 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 118 */     return getPath().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IClasspathContainer getClasspathContainer() throws CoreException {
/* 128 */     ISourceLookupDirector director = getDirector();
/* 129 */     if (director != null) {
/* 130 */       ILaunchConfiguration configuration = director.getLaunchConfiguration();
/* 131 */       if (configuration != null) {
/* 132 */         IJavaProject project = JavaRuntime.getJavaProject(configuration);
/* 133 */         if (project != null) {
/* 134 */           return JavaCore.getClasspathContainer(getPath(), project);
/*     */         }
/*     */       } 
/*     */     } 
/* 138 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\sourcelookup\containers\ClasspathContainerSourceContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */