/*     */ package org.eclipse.jdt.internal.launching.sourcelookup.advanced;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*     */ import org.eclipse.jdt.core.ElementChangedEvent;
/*     */ import org.eclipse.jdt.core.IElementChangedListener;
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.core.IJavaElementDelta;
/*     */ import org.eclipse.jdt.core.IJavaModel;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.launching.sourcelookup.advanced.IWorkspaceProjectDescriber;
/*     */ import org.eclipse.jdt.launching.sourcelookup.containers.PackageFragmentRootSourceContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WorkspaceProjectSourceContainers
/*     */ {
/*  68 */   private final IElementChangedListener changeListener = new IElementChangedListener()
/*     */     {
/*     */       public void elementChanged(ElementChangedEvent event) {
/*     */         try {
/*  72 */           Set<IJavaProject> remove = new HashSet<>();
/*  73 */           Set<IJavaProject> add = new HashSet<>();
/*     */           
/*  75 */           processDelta(event.getDelta(), remove, add);
/*     */           
/*  77 */           if (!remove.isEmpty() || !add.isEmpty()) {
/*  78 */             AdvancedSourceLookupSupport.schedule(m -> WorkspaceProjectSourceContainers.this.updateProjects(param1Set1, param1Set2, m));
/*     */           }
/*     */         }
/*  81 */         catch (CoreException coreException) {}
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private void processDelta(IJavaElementDelta delta, Set<IJavaProject> remove, Set<IJavaProject> add) throws CoreException {
/*  89 */         IJavaElement element = delta.getElement();
/*  90 */         int kind = delta.getKind();
/*  91 */         switch (element.getElementType()) {
/*     */           case 1:
/*  93 */             processChangedChildren(delta, remove, add);
/*     */             break;
/*     */           case 2:
/*  96 */             switch (kind) {
/*     */               case 2:
/*  98 */                 remove.add((IJavaProject)element);
/*     */                 break;
/*     */               case 1:
/* 101 */                 add.add((IJavaProject)element);
/*     */                 break;
/*     */               case 4:
/* 104 */                 if ((delta.getFlags() & 0x400) != 0) {
/* 105 */                   remove.add((IJavaProject)element); break;
/* 106 */                 }  if ((delta.getFlags() & 0x200) != 0) {
/* 107 */                   add.add((IJavaProject)element); break;
/* 108 */                 }  if ((delta.getFlags() & 0x220000) != 0) {
/* 109 */                   remove.add((IJavaProject)element);
/* 110 */                   add.add((IJavaProject)element);
/*     */                 } 
/*     */                 break;
/*     */             } 
/* 114 */             processChangedChildren(delta, remove, add);
/*     */             break;
/*     */           case 3:
/* 117 */             if ((delta.getFlags() & 0xC0) != 0) {
/* 118 */               remove.add(element.getJavaProject());
/* 119 */               add.add(element.getJavaProject());
/*     */             } 
/*     */             break;
/*     */         }  } private void processChangedChildren(IJavaElementDelta delta, Set<IJavaProject> remove, Set<IJavaProject> add) throws CoreException {
/*     */         byte b;
/*     */         int i;
/*     */         IJavaElementDelta[] arrayOfIJavaElementDelta;
/* 126 */         for (i = (arrayOfIJavaElementDelta = delta.getAffectedChildren()).length, b = 0; b < i; ) { IJavaElementDelta childDelta = arrayOfIJavaElementDelta[b];
/* 127 */           processDelta(childDelta, remove, add);
/*     */           b++; }
/*     */       
/*     */       }
/*     */     };
/*     */   
/* 133 */   private static class JavaProjectDescriptionBuilder implements IWorkspaceProjectDescriber.IJavaProjectSourceDescription { final Set<File> locations = new HashSet<>();
/* 134 */     final List<Supplier<ISourceContainer>> factories = new ArrayList<>();
/* 135 */     final Map<File, IPackageFragmentRoot> dependencyLocations = new HashMap<>();
/*     */ 
/*     */     
/*     */     public void addLocation(File location) {
/* 139 */       this.locations.add(location);
/*     */     }
/*     */ 
/*     */     
/*     */     public void addSourceContainerFactory(Supplier<ISourceContainer> factory) {
/* 144 */       this.factories.add(factory);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void addDependencies(Map<File, IPackageFragmentRoot> dependencies) {
/* 150 */       this.dependencyLocations.putAll(dependencies);
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class JavaProjectDescription
/*     */   {
/*     */     final Set<File> classesLocations;
/*     */     
/*     */     final Set<Object> classesLocationsHashes;
/*     */     
/*     */     final List<Supplier<ISourceContainer>> sourceContainerFactories;
/*     */     
/*     */     final Map<File, IPackageFragmentRoot> dependencies;
/*     */     final Map<Object, IPackageFragmentRoot> dependencyHashes;
/*     */     
/*     */     public JavaProjectDescription(Set<File> locations, Set<Object> hashes, List<Supplier<ISourceContainer>> factories, Map<File, IPackageFragmentRoot> dependencies, Map<Object, IPackageFragmentRoot> dependencyHashes) {
/* 167 */       this.classesLocations = Collections.unmodifiableSet(locations);
/* 168 */       this.classesLocationsHashes = Collections.unmodifiableSet(hashes);
/* 169 */       this.sourceContainerFactories = Collections.unmodifiableList(factories);
/* 170 */       this.dependencies = Collections.unmodifiableMap(dependencies);
/* 171 */       this.dependencyHashes = Collections.unmodifiableMap(dependencyHashes);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 176 */       if (this == obj) {
/* 177 */         return true;
/*     */       }
/* 179 */       if (!(obj instanceof JavaProjectDescription)) {
/* 180 */         return false;
/*     */       }
/* 182 */       JavaProjectDescription other = (JavaProjectDescription)obj;
/* 183 */       return this.classesLocations.equals(other.classesLocations);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 188 */       return this.classesLocations.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   private final Object lock = new Object()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */   
/* 204 */   private final Map<File, JavaProjectDescription> locations = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   private final Map<Object, Collection<JavaProjectDescription>> hashes = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   private final Map<IJavaProject, JavaProjectDescription> projects = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISourceContainer createProjectContainer(File projectLocation) {
/* 222 */     FileHashing.Hasher hasher = FileHashing.hasher();
/*     */     
/* 224 */     JavaProjectDescription description = getProjectByLocation(projectLocation);
/*     */     
/* 226 */     if (description == null) {
/* 227 */       Collection<JavaProjectDescription> desciptions = getProjectsByHash(projectLocation, hasher);
/* 228 */       if (!desciptions.isEmpty())
/*     */       {
/* 230 */         description = desciptions.iterator().next();
/*     */       }
/*     */     } 
/*     */     
/* 234 */     if (description == null) {
/* 235 */       return null;
/*     */     }
/*     */     
/* 238 */     List<ISourceContainer> containers = new ArrayList<>();
/* 239 */     for (Supplier<ISourceContainer> factory : description.sourceContainerFactories) {
/* 240 */       containers.add(factory.get());
/*     */     }
/*     */     
/* 243 */     return CompositeSourceContainer.compose(containers);
/*     */   }
/*     */   
/*     */   private JavaProjectDescription getProjectByLocation(File projectLocation) {
/* 247 */     synchronized (this.lock) {
/* 248 */       return this.locations.get(projectLocation);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Collection<JavaProjectDescription> getProjectsByHash(File projectLocation, FileHashing.Hasher hasher) {
/* 254 */     synchronized (this.lock) {
/* 255 */       Collection<JavaProjectDescription> projects = this.hashes.get(hasher.hash(projectLocation));
/* 256 */       return (projects != null) ? new HashSet<>(projects) : Collections.<JavaProjectDescription>emptySet();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISourceContainer createClasspathEntryContainer(File projectLocation, File entryLocation) {
/* 265 */     FileHashing.Hasher hasher = FileHashing.hasher();
/*     */     
/* 267 */     JavaProjectDescription projectByLocation = getProjectByLocation(projectLocation);
/*     */     
/* 269 */     IPackageFragmentRoot dependency = getProjectDependency(projectByLocation, entryLocation, hasher);
/*     */     
/* 271 */     if (dependency == null && projectByLocation == null) {
/* 272 */       for (JavaProjectDescription projectByHash : getProjectsByHash(projectLocation, hasher)) {
/* 273 */         dependency = getProjectDependency(projectByHash, entryLocation, hasher);
/* 274 */         if (dependency != null) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     try {
/* 281 */       if (dependency == null || (dependency.getKind() == 2 && dependency.getSourceAttachmentPath() == null)) {
/* 282 */         return null;
/*     */       }
/* 284 */     } catch (JavaModelException javaModelException) {
/* 285 */       return null;
/*     */     } 
/*     */     
/* 288 */     return (ISourceContainer)new PackageFragmentRootSourceContainer(dependency);
/*     */   }
/*     */   
/*     */   private IPackageFragmentRoot getProjectDependency(JavaProjectDescription project, File entryLocation, FileHashing.Hasher hasher) {
/* 292 */     if (project == null) {
/* 293 */       return null;
/*     */     }
/*     */     
/* 296 */     IPackageFragmentRoot dependency = project.dependencies.get(entryLocation);
/*     */     
/* 298 */     if (dependency == null) {
/* 299 */       dependency = project.dependencyHashes.get(hasher.hash(entryLocation));
/*     */     }
/* 301 */     return dependency;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(IProgressMonitor monitor) throws CoreException {
/* 307 */     JavaCore.addElementChangedListener(this.changeListener);
/*     */     
/* 309 */     IJavaModel javaModel = JavaCore.create(ResourcesPlugin.getWorkspace().getRoot());
/* 310 */     IJavaProject[] javaProjects = javaModel.getJavaProjects();
/*     */     
/* 312 */     SubMonitor progress = SubMonitor.convert(monitor, javaProjects.length);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 317 */     FileHashing.Hasher hasher = FileHashing.newHasher();
/*     */     
/* 319 */     List<IWorkspaceProjectDescriber> describers = getJavaProjectDescribers(); byte b; int i; IJavaProject[] arrayOfIJavaProject1;
/* 320 */     for (i = (arrayOfIJavaProject1 = javaProjects).length, b = 0; b < i; ) { IJavaProject project = arrayOfIJavaProject1[b];
/* 321 */       addJavaProject(project, describers, hasher, (IProgressMonitor)progress.split(1));
/*     */       b++; }
/*     */   
/*     */   }
/*     */   public void close() {
/* 326 */     JavaCore.removeElementChangedListener(this.changeListener);
/* 327 */     synchronized (this.lock) {
/* 328 */       this.locations.clear();
/* 329 */       this.hashes.clear();
/* 330 */       this.projects.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addJavaProject(IJavaProject project, List<IWorkspaceProjectDescriber> describers, FileHashing.Hasher hasher, IProgressMonitor monitor) throws CoreException {
/* 335 */     if (project == null) {
/* 336 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 339 */     JavaProjectDescriptionBuilder builder = new JavaProjectDescriptionBuilder();
/*     */     
/* 341 */     for (IWorkspaceProjectDescriber describer : describers) {
/* 342 */       describer.describeProject(project, builder);
/*     */     }
/*     */     
/* 345 */     Set<File> locations = builder.locations;
/* 346 */     List<Supplier<ISourceContainer>> factories = builder.factories;
/* 347 */     Map<File, IPackageFragmentRoot> dependencies = builder.dependencyLocations;
/*     */ 
/*     */     
/* 350 */     locations.forEach(location -> {
/*     */         
/* 352 */         }); Set<Object> hashes = new HashSet();
/* 353 */     locations.forEach(location -> {
/*     */           Object hash = paramHasher.hash(location);
/*     */           
/*     */           if (hash != null) {
/*     */             paramSet.add(hash);
/*     */           }
/*     */         });
/* 360 */     Map<Object, IPackageFragmentRoot> dependencyHashes = new HashMap<>();
/* 361 */     dependencies.forEach((location, packageFragmentRoot) -> {
/*     */         
/* 363 */         }); JavaProjectDescription info = new JavaProjectDescription(locations, hashes, factories, dependencies, dependencyHashes);
/*     */     
/* 365 */     synchronized (this.lock) {
/* 366 */       for (File location : locations) {
/* 367 */         this.locations.put(location, info);
/*     */       }
/* 369 */       for (Object hash : hashes) {
/* 370 */         Collection<JavaProjectDescription> hashProjects = this.hashes.get(hash);
/* 371 */         if (hashProjects == null) {
/* 372 */           hashProjects = new HashSet<>();
/* 373 */           this.hashes.put(hash, hashProjects);
/*     */         } 
/* 375 */         hashProjects.add(info);
/*     */       } 
/* 377 */       this.projects.put(project, info);
/*     */     } 
/*     */     
/* 380 */     SubMonitor.done(monitor);
/*     */   }
/*     */   
/*     */   protected List<IWorkspaceProjectDescriber> getJavaProjectDescribers() {
/* 384 */     List<IWorkspaceProjectDescriber> result = new ArrayList<>();
/*     */     
/* 386 */     IExtensionRegistry registry = Platform.getExtensionRegistry();
/*     */     
/* 388 */     IConfigurationElement[] elements = registry.getConfigurationElementsFor("org.eclipse.jdt.launching.workspaceProjectDescribers"); byte b; int i;
/*     */     IConfigurationElement[] arrayOfIConfigurationElement1;
/* 390 */     for (i = (arrayOfIConfigurationElement1 = elements).length, b = 0; b < i; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b];
/* 391 */       if ("describer".equals(element.getName())) {
/*     */         try {
/* 393 */           result.add((IWorkspaceProjectDescriber)element.createExecutableExtension("class"));
/*     */         }
/* 395 */         catch (CoreException coreException) {}
/*     */       }
/*     */       
/*     */       b++; }
/*     */     
/* 400 */     result.add(new DefaultProjectDescriber());
/*     */     
/* 402 */     return result;
/*     */   }
/*     */   
/*     */   private void removeJavaProject(IJavaProject project) {
/* 406 */     if (project == null) {
/* 407 */       throw new IllegalArgumentException();
/*     */     }
/* 409 */     synchronized (this.lock) {
/* 410 */       JavaProjectDescription description = this.projects.remove(project);
/* 411 */       if (description != null) {
/* 412 */         for (File location : description.classesLocations) {
/* 413 */           this.locations.remove(location);
/*     */         }
/* 415 */         for (Object hash : description.classesLocationsHashes) {
/* 416 */           Collection<JavaProjectDescription> hashProjects = this.hashes.get(hash);
/* 417 */           if (hashProjects != null) {
/* 418 */             hashProjects.remove(description);
/* 419 */             if (hashProjects.isEmpty()) {
/* 420 */               this.hashes.remove(hash);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void updateProjects(Set<IJavaProject> remove, Set<IJavaProject> add, IProgressMonitor monitor) throws CoreException {
/* 429 */     SubMonitor progress = SubMonitor.convert(monitor, 1 + add.size());
/*     */     
/* 431 */     progress.split(1);
/* 432 */     for (IJavaProject project : remove) {
/* 433 */       removeJavaProject(project);
/*     */     }
/* 435 */     List<IWorkspaceProjectDescriber> describers = getJavaProjectDescribers();
/* 436 */     FileHashing.Hasher hasher = FileHashing.newHasher();
/* 437 */     for (IJavaProject project : add)
/* 438 */       addJavaProject(project, describers, hasher, (IProgressMonitor)progress.split(1)); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\sourcelookup\advanced\WorkspaceProjectSourceContainers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */