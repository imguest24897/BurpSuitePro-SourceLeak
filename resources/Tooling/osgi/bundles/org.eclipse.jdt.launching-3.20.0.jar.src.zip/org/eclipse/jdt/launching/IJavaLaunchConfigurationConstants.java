/*     */ package org.eclipse.jdt.launching;
/*     */ 
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface IJavaLaunchConfigurationConstants
/*     */ {
/*  34 */   public static final String ID_JAVA_APPLICATION = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".localJavaApplication";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   public static final String ID_REMOTE_JAVA_APPLICATION = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".remoteJavaApplication";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final String ID_JAVA_APPLET = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".javaApplet";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public static final String ID_SOCKET_ATTACH_VM_CONNECTOR = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".socketAttachConnector";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   public static final String ID_SOCKET_LISTEN_VM_CONNECTOR = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".socketListenConnector";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String ID_JAVA_PROCESS_TYPE = "java";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   public static final String ATTR_PROJECT_NAME = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".PROJECT_ATTR";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public static final String ATTR_MAIN_TYPE_NAME = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".MAIN_TYPE";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public static final String ATTR_MODULE_NAME = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".MODULE_NAME";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public static final String ATTR_STOP_IN_MAIN = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".STOP_IN_MAIN";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public static final String ATTR_PROGRAM_ARGUMENTS = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".PROGRAM_ARGUMENTS";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public static final String ATTR_VM_ARGUMENTS = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".VM_ARGUMENTS";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   public static final String ATTR_WORKING_DIRECTORY = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".WORKING_DIRECTORY";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   public static final String ATTR_JRE_CONTAINER_PATH = JavaRuntime.JRE_CONTAINER;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/* 150 */   public static final String ATTR_VM_INSTALL_NAME = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".VM_INSTALL_NAME";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/* 162 */   public static final String ATTR_VM_INSTALL_TYPE = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".VM_INSTALL_TYPE_ID";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 171 */   public static final String ATTR_VM_INSTALL_TYPE_SPECIFIC_ATTRS_MAP = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + "VM_INSTALL_TYPE_SPECIFIC_ATTRS_MAP";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 178 */   public static final String ATTR_VM_CONNECTOR = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".VM_CONNECTOR_ID";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 186 */   public static final String ATTR_CLASSPATH = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".CLASSPATH";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 195 */   public static final String ATTR_MODULEPATH = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".MODULEPATH";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 209 */   public static final String ATTR_DEFAULT_CLASSPATH = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".DEFAULT_CLASSPATH";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 218 */   public static final String ATTR_DEFAULT_MODULE_CLI_OPTIONS = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".DEFAULT_MODULE_CLI_OPTIONS";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   public static final String ATTR_MODULE_CLI_OPTIONS = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".MODULE_CLI_OPTIONS";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 234 */   public static final String ATTR_CLASSPATH_PROVIDER = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".CLASSPATH_PROVIDER";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 244 */   public static final String ATTR_SOURCE_PATH = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".SOURCE_PATH";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 254 */   public static final String ATTR_DEFAULT_SOURCE_PATH = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".DEFAULT_SOURCE_PATH";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 262 */   public static final String ATTR_SOURCE_PATH_PROVIDER = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".SOURCE_PATH_PROVIDER";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 269 */   public static final String ATTR_ALLOW_TERMINATE = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".ALLOW_TERMINATE";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 276 */   public static final String ATTR_JAVA_COMMAND = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".JAVA_COMMAND";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 285 */   public static final String ATTR_CONNECT_MAP = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".CONNECT_MAP";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 293 */   public static final String ATTR_APPLET_WIDTH = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".APPLET_WIDTH";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 301 */   public static final String ATTR_APPLET_HEIGHT = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".APPLET_HEIGHT";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 309 */   public static final String ATTR_APPLET_NAME = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".APPLET_NAME";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 318 */   public static final String ATTR_APPLET_PARAMETERS = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".APPLET_PARAMETERS";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 326 */   public static final String ATTR_APPLET_APPLETVIEWER_CLASS = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".APPLET_APPLETVIEWER_CLASS";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 338 */   public static final String ATTR_BOOTPATH_PREPEND = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".-Xbootclasspath/p:";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 350 */   public static final String ATTR_BOOTPATH = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".-Xbootclasspath:";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 362 */   public static final String ATTR_BOOTPATH_APPEND = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".-Xbootclasspath/a:";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 371 */   public static final String ATTR_USE_START_ON_FIRST_THREAD = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".ATTR_USE_START_ON_FIRST_THREAD";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 380 */   public static final String ATTR_SHOW_CODEDETAILS_IN_EXCEPTION_MESSAGES = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + 
/* 381 */     ".ATTR_SHOW_CODEDETAILS_IN_EXCEPTION_MESSAGES";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 389 */   public static final String ATTR_USE_ARGFILE = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".ATTR_ATTR_USE_ARGFILE";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 397 */   public static final String ATTR_EXCLUDE_TEST_CODE = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".ATTR_EXCLUDE_TEST_CODE";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 406 */   public static final String ATTR_SPECIAL_ADD_MODULES = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".ATTR_SPECIAL_ADD_MODULES";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 411 */   public static final String ATTR_USE_CLASSPATH_ONLY_JAR = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".ATTR_USE_CLASSPATH_ONLY_JAR";
/*     */   public static final int ERR_UNSPECIFIED_PROJECT = 100;
/*     */   public static final int ERR_UNSPECIFIED_MAIN_TYPE = 101;
/*     */   public static final int ERR_UNSPECIFIED_VM_INSTALL_TYPE = 102;
/*     */   public static final int ERR_UNSPECIFIED_VM_INSTALL = 103;
/*     */   public static final int ERR_VM_INSTALL_TYPE_DOES_NOT_EXIST = 104;
/*     */   public static final int ERR_VM_INSTALL_DOES_NOT_EXIST = 105;
/*     */   public static final int ERR_VM_RUNNER_DOES_NOT_EXIST = 106;
/*     */   public static final int ERR_NOT_A_JAVA_PROJECT = 107;
/*     */   public static final int ERR_WORKING_DIRECTORY_DOES_NOT_EXIST = 108;
/*     */   public static final int ERR_UNSPECIFIED_HOSTNAME = 109;
/*     */   public static final int ERR_INVALID_HOSTNAME = 110;
/*     */   public static final int ERR_UNSPECIFIED_PORT = 111;
/*     */   public static final int ERR_INVALID_PORT = 112;
/*     */   public static final int ERR_REMOTE_VM_CONNECTION_FAILED = 113;
/*     */   public static final int ERR_SHARED_MEMORY_CONNECTOR_UNAVAILABLE = 114;
/*     */   public static final int ERR_WORKING_DIRECTORY_NOT_SUPPORTED = 115;
/*     */   public static final int ERR_VM_LAUNCH_ERROR = 116;
/*     */   public static final int ERR_VM_CONNECT_TIMEOUT = 117;
/*     */   public static final int ERR_NO_SOCKET_AVAILABLE = 118;
/*     */   public static final int ERR_CONNECTOR_NOT_AVAILABLE = 119;
/*     */   public static final int ERR_CONNECTION_FAILED = 120;
/*     */   public static final int ERR_NOT_AN_APPLET = 121;
/*     */   public static final int ERR_UNSPECIFIED_LAUNCH_CONFIG = 122;
/*     */   public static final int ERR_COULD_NOT_BUILD_HTML = 123;
/*     */   public static final int ERR_PROJECT_CLOSED = 124;
/*     */   public static final int ERR_CLASSPATH_TOO_LONG = 125;
/*     */   public static final int ERR_INTERNAL_ERROR = 150;
/*     */   public static final String DEFAULT_APPLETVIEWER_CLASS = "sun.applet.AppletViewer";
/*     */   public static final int DETAIL_CONFIG_READY_TO_ACCEPT_REMOTE_VM_CONNECTION = 1001;
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\IJavaLaunchConfigurationConstants.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */