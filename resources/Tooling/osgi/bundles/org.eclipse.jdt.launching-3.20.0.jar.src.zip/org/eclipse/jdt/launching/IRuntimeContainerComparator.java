package org.eclipse.jdt.launching;

import org.eclipse.core.runtime.IPath;

@Deprecated
public interface IRuntimeContainerComparator {
  boolean isDuplicate(IPath paramIPath);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\IRuntimeContainerComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */