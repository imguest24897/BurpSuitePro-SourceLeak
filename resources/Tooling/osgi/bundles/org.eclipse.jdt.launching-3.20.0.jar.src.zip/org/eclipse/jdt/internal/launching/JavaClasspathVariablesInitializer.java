/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.NullProgressMonitor;
/*    */ import org.eclipse.jdt.core.ClasspathVariableInitializer;
/*    */ import org.eclipse.jdt.core.JavaCore;
/*    */ import org.eclipse.jdt.launching.IVMInstall;
/*    */ import org.eclipse.jdt.launching.JavaRuntime;
/*    */ import org.eclipse.jdt.launching.LibraryLocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaClasspathVariablesInitializer
/*    */   extends ClasspathVariableInitializer
/*    */ {
/*    */   private IProgressMonitor fMonitor;
/*    */   
/*    */   public void initialize(String variable) {
/* 40 */     IVMInstall vmInstall = JavaRuntime.getDefaultVMInstall();
/* 41 */     if (vmInstall != null) {
/* 42 */       IPath newPath = null;
/* 43 */       LibraryLocation[] locations = JavaRuntime.getLibraryLocations(vmInstall);
/*    */       
/* 45 */       LibraryLocation rtjar = null;
/* 46 */       LibraryLocation classeszip = null;
/* 47 */       for (int i = 0; i < locations.length; i++) {
/* 48 */         LibraryLocation location = locations[i];
/* 49 */         String name = location.getSystemLibraryPath().lastSegment();
/* 50 */         if (name.equalsIgnoreCase("rt.jar")) {
/* 51 */           rtjar = location;
/* 52 */         } else if (name.equalsIgnoreCase("classes.zip")) {
/* 53 */           classeszip = location;
/*    */         } 
/*    */       } 
/*    */       
/* 57 */       LibraryLocation systemLib = rtjar;
/* 58 */       if (systemLib == null) {
/* 59 */         systemLib = classeszip;
/*    */       }
/* 61 */       if (systemLib == null && locations.length > 0) {
/* 62 */         systemLib = locations[0];
/*    */       }
/* 64 */       if (systemLib != null) {
/* 65 */         String str; switch ((str = variable).hashCode()) { case -2096319900: if (!str.equals("JRE_SRCROOT")) {
/*    */               break;
/*    */             }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */             
/* 73 */             newPath = systemLib.getPackageRootPath(); break;
/*    */           case -629985501: if (!str.equals("JRE_LIB"))
/*    */               break;  newPath = systemLib.getSystemLibraryPath(); break;
/*    */           case -629978494:
/*    */             if (!str.equals("JRE_SRC"))
/* 78 */               break;  newPath = systemLib.getSystemLibrarySourcePath(); break; }  if (newPath == null) {
/*    */           return;
/*    */         }
/*    */         try {
/* 82 */           setJREVariable(newPath, variable);
/*    */         }
/* 84 */         catch (CoreException e) {
/* 85 */           LaunchingPlugin.log((Throwable)e);
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private void setJREVariable(IPath newPath, String var) throws CoreException {
/* 92 */     JavaCore.setClasspathVariable(var, newPath, getMonitor());
/*    */   }
/*    */   
/*    */   protected IProgressMonitor getMonitor() {
/* 96 */     if (this.fMonitor == null) {
/* 97 */       return (IProgressMonitor)new NullProgressMonitor();
/*    */     }
/* 99 */     return this.fMonitor;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\JavaClasspathVariablesInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */