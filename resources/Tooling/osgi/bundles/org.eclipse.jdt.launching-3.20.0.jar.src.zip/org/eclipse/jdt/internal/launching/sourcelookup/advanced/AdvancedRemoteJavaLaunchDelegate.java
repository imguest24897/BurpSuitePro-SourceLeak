/*    */ package org.eclipse.jdt.internal.launching.sourcelookup.advanced;
/*    */ 
/*    */ import org.eclipse.jdt.internal.launching.JavaRemoteApplicationLaunchConfigurationDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AdvancedRemoteJavaLaunchDelegate
/*    */   extends JavaRemoteApplicationLaunchConfigurationDelegate
/*    */ {
/*    */   public AdvancedRemoteJavaLaunchDelegate() {
/* 21 */     allowAdvancedSourcelookup();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\sourcelookup\advanced\AdvancedRemoteJavaLaunchDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */