/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import org.eclipse.jdt.launching.IVMInstall;
/*    */ import org.eclipse.jdt.launching.IVMInstallType;
/*    */ import org.eclipse.jdt.launching.IVMRunner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Standard11xVM
/*    */   extends StandardVM
/*    */ {
/*    */   public Standard11xVM(IVMInstallType type, String id) {
/* 27 */     super(type, id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IVMRunner getVMRunner(String mode) {
/* 36 */     if ("run".equals(mode)) {
/* 37 */       return (IVMRunner)new Standard11xVMRunner((IVMInstall)this);
/*    */     }
/* 39 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\Standard11xVM.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */