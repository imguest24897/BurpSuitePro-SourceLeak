/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeId
/*    */ {
/*    */   private String[] fParts;
/*    */   
/*    */   public CompositeId(String[] parts) {
/* 25 */     this.fParts = parts;
/*    */   }
/*    */   
/*    */   public static CompositeId fromString(String idString) {
/* 29 */     ArrayList<String> parts = new ArrayList<>();
/* 30 */     int commaIndex = idString.indexOf(',');
/* 31 */     while (commaIndex > 0) {
/* 32 */       int length = Integer.parseInt(idString.substring(0, commaIndex));
/* 33 */       String part = idString.substring(commaIndex + 1, commaIndex + 1 + length);
/* 34 */       parts.add(part);
/* 35 */       idString = idString.substring(commaIndex + 1 + length);
/* 36 */       commaIndex = idString.indexOf(',');
/*    */     } 
/* 38 */     String[] result = parts.<String>toArray(new String[parts.size()]);
/* 39 */     return new CompositeId(result);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 44 */     StringBuilder buf = new StringBuilder();
/* 45 */     for (int i = 0; i < this.fParts.length; i++) {
/* 46 */       buf.append(this.fParts[i].length());
/* 47 */       buf.append(',');
/* 48 */       buf.append(this.fParts[i]);
/*    */     } 
/* 50 */     return buf.toString();
/*    */   }
/*    */   
/*    */   public String get(int index) {
/* 54 */     return this.fParts[index];
/*    */   }
/*    */   
/*    */   public int getPartCount() {
/* 58 */     return this.fParts.length;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\CompositeId.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */