/*     */ package org.eclipse.jdt.launching.sourcelookup.containers;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*     */ import org.eclipse.debug.core.sourcelookup.containers.CompositeSourceContainer;
/*     */ import org.eclipse.debug.core.sourcelookup.containers.FolderSourceContainer;
/*     */ import org.eclipse.debug.core.sourcelookup.containers.ProjectSourceContainer;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaProjectSourceContainer
/*     */   extends CompositeSourceContainer
/*     */ {
/*     */   private IJavaProject fProject;
/*     */   private ISourceContainer[] fSourceFolders;
/*     */   private ISourceContainer[] fOthers;
/*  54 */   private static String[] fgJavaExtensions = null;
/*     */   
/*     */   public static final String TYPE_ID;
/*     */ 
/*     */   
/*     */   static {
/*  60 */     String[] extensions = JavaCore.getJavaLikeExtensions();
/*  61 */     fgJavaExtensions = new String[extensions.length];
/*  62 */     for (int i = 0; i < extensions.length; i++) {
/*  63 */       String ext = extensions[i];
/*  64 */       fgJavaExtensions[i] = String.valueOf('.') + ext;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     TYPE_ID = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".sourceContainer.javaProject";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaProjectSourceContainer(IJavaProject project) {
/*  80 */     this.fProject = project;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  87 */     return this.fProject.getElementName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISourceContainerType getType() {
/*  95 */     return getSourceContainerType(TYPE_ID);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IJavaProject getJavaProject() {
/* 104 */     return this.fProject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ISourceContainer[] createSourceContainers() throws CoreException {
/* 111 */     List<ISourceContainer> containers = new ArrayList<>();
/* 112 */     IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
/* 113 */     if (this.fProject.getProject().isOpen()) {
/* 114 */       IClasspathEntry[] entries = this.fProject.getRawClasspath();
/* 115 */       for (int i = 0; i < entries.length; i++) {
/* 116 */         IPath path; IResource resource; IClasspathEntry entry = entries[i];
/* 117 */         switch (entry.getEntryKind()) {
/*     */           case 3:
/* 119 */             path = entry.getPath();
/* 120 */             resource = root.findMember(path);
/* 121 */             if (resource instanceof IContainer) {
/* 122 */               containers.add(new FolderSourceContainer((IContainer)resource, false));
/*     */             }
/*     */             break;
/*     */         } 
/*     */       
/*     */       } 
/*     */     } 
/* 129 */     this.fSourceFolders = containers.<ISourceContainer>toArray(new ISourceContainer[containers.size()]);
/* 130 */     ProjectSourceContainer projectSourceContainer = new ProjectSourceContainer(this.fProject.getProject(), false);
/* 131 */     this.fOthers = new ISourceContainer[] { (ISourceContainer)projectSourceContainer };
/* 132 */     containers.add(projectSourceContainer);
/* 133 */     return containers.<ISourceContainer>toArray(new ISourceContainer[containers.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 140 */     if (obj instanceof JavaProjectSourceContainer) {
/* 141 */       return getJavaProject().equals(((JavaProjectSourceContainer)obj).getJavaProject());
/*     */     }
/* 143 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 150 */     return getJavaProject().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] findSourceElements(String name) throws CoreException {
/* 158 */     getSourceContainers();
/*     */     
/* 160 */     if (isJavaLikeFileName(name)) {
/*     */       
/* 162 */       Object[] objects = findSourceElements(name, this.fSourceFolders);
/* 163 */       List<Object> filtered = null;
/* 164 */       for (int i = 0; i < objects.length; i++) {
/* 165 */         Object object = objects[i];
/* 166 */         if (object instanceof IResource && 
/* 167 */           !getJavaProject().isOnClasspath((IResource)object)) {
/* 168 */           if (filtered == null) {
/* 169 */             filtered = new ArrayList(objects.length);
/* 170 */             for (int j = 0; j < objects.length; j++) {
/* 171 */               filtered.add(objects[j]);
/*     */             }
/*     */           } 
/* 174 */           filtered.remove(object);
/*     */         } 
/*     */       } 
/*     */       
/* 178 */       if (filtered == null) {
/* 179 */         return objects;
/*     */       }
/* 181 */       return filtered.toArray();
/*     */     } 
/*     */     
/* 184 */     return findSourceElements(name, this.fOthers);
/*     */   }
/*     */   
/*     */   public void dispose() {
/* 188 */     this.fSourceFolders = null;
/* 189 */     this.fOthers = null;
/* 190 */     super.dispose();
/*     */   }
/*     */   
/*     */   private boolean isJavaLikeFileName(String name) {
/* 194 */     for (int i = 0; i < fgJavaExtensions.length; i++) {
/* 195 */       String ext = fgJavaExtensions[i];
/* 196 */       if (name.endsWith(ext)) {
/* 197 */         return true;
/*     */       }
/*     */     } 
/* 200 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\sourcelookup\containers\JavaProjectSourceContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */