/*     */ package org.eclipse.jdt.launching;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExecutableExtension;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingMessages;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractVMInstallType
/*     */   implements IVMInstallType, IExecutableExtension
/*     */ {
/*  49 */   private List<IVMInstall> fVMs = new ArrayList<>(10);
/*     */ 
/*     */ 
/*     */   
/*     */   private String fId;
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized IVMInstall[] getVMInstalls() {
/*  58 */     IVMInstall[] vms = new IVMInstall[this.fVMs.size()];
/*  59 */     return this.fVMs.<IVMInstall>toArray(vms);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disposeVMInstall(String id) {
/*  68 */     IVMInstall removedVM = null;
/*  69 */     synchronized (this) {
/*  70 */       for (int i = 0; i < this.fVMs.size(); i++) {
/*  71 */         if (((IVMInstall)this.fVMs.get(i)).getId().equals(id)) {
/*  72 */           removedVM = this.fVMs.remove(i);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*  77 */     if (removedVM != null) {
/*  78 */       JavaRuntime.fireVMRemoved(removedVM);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IVMInstall findVMInstall(String id) {
/*  88 */     synchronized (this) {
/*  89 */       for (int i = 0; i < this.fVMs.size(); i++) {
/*  90 */         IVMInstall vm = this.fVMs.get(i);
/*  91 */         if (vm.getId().equals(id)) {
/*  92 */           return vm;
/*     */         }
/*     */       } 
/*     */     } 
/*  96 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized IVMInstall createVMInstall(String id) throws IllegalArgumentException {
/* 105 */     if (findVMInstall(id) != null) {
/* 106 */       String format = LaunchingMessages.vmInstallType_duplicateVM;
/* 107 */       throw new IllegalArgumentException(NLS.bind(format, new String[] { id }));
/*     */     } 
/* 109 */     IVMInstall vm = doCreateVMInstall(id);
/* 110 */     this.fVMs.add(vm);
/* 111 */     return vm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract IVMInstall doCreateVMInstall(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInitializationData(IConfigurationElement config, String propertyName, Object data) {
/* 141 */     this.fId = config.getAttribute("id");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/* 150 */     return this.fId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IVMInstall findVMInstallByName(String name) {
/* 158 */     synchronized (this) {
/* 159 */       for (int i = 0; i < this.fVMs.size(); i++) {
/* 160 */         IVMInstall vm = this.fVMs.get(i);
/* 161 */         if (Objects.equals(vm.getName(), name)) {
/* 162 */           return vm;
/*     */         }
/*     */       } 
/*     */     } 
/* 166 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getDefaultJavadocLocation(File installLocation) {
/* 186 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDefaultVMArguments(File installLocation) {
/* 205 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\AbstractVMInstallType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */