/*     */ package org.eclipse.jdt.internal.launching.environments;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.jdt.internal.launching.EEVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstall2;
/*     */ import org.eclipse.jdt.launching.IVMInstall3;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.jdt.launching.environments.CompatibleEnvironment;
/*     */ import org.eclipse.jdt.launching.environments.IExecutionEnvironment;
/*     */ import org.eclipse.jdt.launching.environments.IExecutionEnvironmentAnalyzerDelegate;
/*     */ import org.eclipse.jdt.launching.environments.IExecutionEnvironmentsManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExecutionEnvironmentAnalyzer
/*     */   implements IExecutionEnvironmentAnalyzerDelegate
/*     */ {
/*     */   private static final String JavaSE_20 = "JavaSE-20";
/*     */   private static final String JavaSE_19 = "JavaSE-19";
/*     */   private static final String JavaSE_18 = "JavaSE-18";
/*     */   private static final String JavaSE_17 = "JavaSE-17";
/*     */   private static final String JavaSE_16 = "JavaSE-16";
/*     */   private static final String JavaSE_15 = "JavaSE-15";
/*     */   private static final String JavaSE_14 = "JavaSE-14";
/*     */   private static final String JavaSE_13 = "JavaSE-13";
/*     */   private static final String JavaSE_12 = "JavaSE-12";
/*     */   private static final String JavaSE_11 = "JavaSE-11";
/*     */   private static final String JavaSE_10_Plus = "JavaSE-10+";
/*     */   private static final String JavaSE_10 = "JavaSE-10";
/*     */   static final String JavaSE_9 = "JavaSE-9";
/*     */   private static final String JavaSE_1_8 = "JavaSE-1.8";
/*     */   private static final String JavaSE_1_7 = "JavaSE-1.7";
/*     */   private static final String JavaSE_1_6 = "JavaSE-1.6";
/*     */   private static final String J2SE_1_5 = "J2SE-1.5";
/*     */   private static final String J2SE_1_4 = "J2SE-1.4";
/*     */   private static final String J2SE_1_3 = "J2SE-1.3";
/*     */   private static final String J2SE_1_2 = "J2SE-1.2";
/*     */   private static final String JRE_1_1 = "JRE-1.1";
/*     */   private static final String CDC_FOUNDATION_1_1 = "CDC-1.1/Foundation-1.1";
/*     */   private static final String CDC_FOUNDATION_1_0 = "CDC-1.0/Foundation-1.0";
/*     */   private static final String OSGI_MINIMUM_1_0 = "OSGi/Minimum-1.0";
/*     */   private static final String OSGI_MINIMUM_1_1 = "OSGi/Minimum-1.1";
/*     */   private static final String OSGI_MINIMUM_1_2 = "OSGi/Minimum-1.2";
/*     */   private static final String JAVA_SPEC_VERSION = "java.specification.version";
/*     */   private static final String JAVA_SPEC_NAME = "java.specification.name";
/*     */   private static final String JAVA_VERSION = "java.version";
/*  77 */   private static final String[] VM_PROPERTIES = new String[] { "java.specification.name", "java.specification.version", "java.version" };
/*     */   private static final String FOUNDATION = "foundation";
/*  79 */   private static final Map<String, String[]> mappings = (Map)new HashMap<>();
/*     */ 
/*     */   
/*     */   static {
/*  83 */     mappings.put("CDC-1.0/Foundation-1.0", new String[] { "OSGi/Minimum-1.0" });
/*  84 */     mappings.put("CDC-1.1/Foundation-1.1", new String[] { "CDC-1.0/Foundation-1.0", "OSGi/Minimum-1.2" });
/*  85 */     mappings.put("OSGi/Minimum-1.1", new String[] { "OSGi/Minimum-1.0" });
/*  86 */     mappings.put("OSGi/Minimum-1.2", new String[] { "OSGi/Minimum-1.1" });
/*  87 */     mappings.put("J2SE-1.2", new String[] { "JRE-1.1" });
/*  88 */     mappings.put("J2SE-1.3", new String[] { "J2SE-1.2", "CDC-1.0/Foundation-1.0", "OSGi/Minimum-1.0" });
/*  89 */     mappings.put("J2SE-1.4", new String[] { "J2SE-1.3", "CDC-1.1/Foundation-1.1", "OSGi/Minimum-1.2" });
/*  90 */     mappings.put("J2SE-1.5", new String[] { "J2SE-1.4" });
/*  91 */     mappings.put("JavaSE-1.6", new String[] { "J2SE-1.5" });
/*  92 */     mappings.put("JavaSE-1.7", new String[] { "JavaSE-1.6" });
/*  93 */     mappings.put("JavaSE-1.8", new String[] { "JavaSE-1.7" });
/*  94 */     mappings.put("JavaSE-9", new String[] { "JavaSE-1.8" });
/*  95 */     mappings.put("JavaSE-10", new String[] { "JavaSE-9" });
/*  96 */     mappings.put("JavaSE-10+", new String[] { "JavaSE-20" });
/*  97 */     mappings.put("JavaSE-11", new String[] { "JavaSE-10" });
/*  98 */     mappings.put("JavaSE-12", new String[] { "JavaSE-11" });
/*  99 */     mappings.put("JavaSE-13", new String[] { "JavaSE-12" });
/* 100 */     mappings.put("JavaSE-14", new String[] { "JavaSE-13" });
/* 101 */     mappings.put("JavaSE-15", new String[] { "JavaSE-14" });
/* 102 */     mappings.put("JavaSE-16", new String[] { "JavaSE-15" });
/* 103 */     mappings.put("JavaSE-17", new String[] { "JavaSE-16" });
/* 104 */     mappings.put("JavaSE-18", new String[] { "JavaSE-17" });
/* 105 */     mappings.put("JavaSE-19", new String[] { "JavaSE-18" });
/* 106 */     mappings.put("JavaSE-20", new String[] { "JavaSE-19" });
/*     */   }
/*     */   
/*     */   public CompatibleEnvironment[] analyze(IVMInstall vm, IProgressMonitor monitor) throws CoreException {
/* 110 */     ArrayList<CompatibleEnvironment> result = new ArrayList<>();
/* 111 */     if (!(vm instanceof IVMInstall2)) {
/* 112 */       return new CompatibleEnvironment[0];
/*     */     }
/* 114 */     IVMInstall2 vm2 = (IVMInstall2)vm;
/* 115 */     List<String> types = null;
/* 116 */     if ("org.eclipse.jdt.launching.EEVMType".equals(vm.getVMInstallType().getId())) {
/* 117 */       String eeId = ((EEVMInstall)vm).getAttribute("ATTR_EXECUTION_ENVIRONMENT_ID");
/* 118 */       if (eeId != null) {
/* 119 */         types = getTypes(eeId);
/*     */       }
/*     */     } 
/* 122 */     if (types == null) {
/* 123 */       String javaVersion = vm2.getJavaVersion();
/* 124 */       if (javaVersion == null) {
/*     */         
/* 126 */         if (vm instanceof IVMInstall3 && isFoundation1_0((IVMInstall3)vm)) {
/* 127 */           types = getTypes("CDC-1.0/Foundation-1.0");
/* 128 */         } else if (vm instanceof IVMInstall3 && isFoundation1_1((IVMInstall3)vm)) {
/* 129 */           types = getTypes("CDC-1.1/Foundation-1.1");
/*     */         }
/*     */       
/* 132 */       } else if (javaVersion.startsWith("20")) {
/* 133 */         types = getTypes("JavaSE-20");
/* 134 */       } else if (javaVersion.startsWith("19")) {
/* 135 */         types = getTypes("JavaSE-19");
/* 136 */       } else if (javaVersion.startsWith("18")) {
/* 137 */         types = getTypes("JavaSE-18");
/* 138 */       } else if (javaVersion.startsWith("17")) {
/* 139 */         types = getTypes("JavaSE-17");
/* 140 */       } else if (javaVersion.startsWith("16")) {
/* 141 */         types = getTypes("JavaSE-16");
/* 142 */       } else if (javaVersion.startsWith("15")) {
/* 143 */         types = getTypes("JavaSE-15");
/* 144 */       } else if (javaVersion.startsWith("14")) {
/* 145 */         types = getTypes("JavaSE-14");
/* 146 */       } else if (javaVersion.startsWith("13")) {
/* 147 */         types = getTypes("JavaSE-13");
/* 148 */       } else if (javaVersion.startsWith("12")) {
/* 149 */         types = getTypes("JavaSE-12");
/* 150 */       } else if (javaVersion.startsWith("11")) {
/* 151 */         types = getTypes("JavaSE-11");
/* 152 */       } else if (javaVersion.startsWith("10")) {
/* 153 */         types = getTypes("JavaSE-10");
/* 154 */       } else if (javaVersion.startsWith("9")) {
/* 155 */         types = getTypes("JavaSE-9");
/* 156 */       } else if (javaVersion.startsWith("1.8")) {
/* 157 */         types = getTypes("JavaSE-1.8");
/* 158 */       } else if (javaVersion.startsWith("1.7")) {
/* 159 */         types = getTypes("JavaSE-1.7");
/* 160 */       } else if (javaVersion.startsWith("1.6")) {
/* 161 */         types = getTypes("JavaSE-1.6");
/* 162 */       } else if (javaVersion.startsWith("1.5")) {
/* 163 */         types = getTypes("J2SE-1.5");
/* 164 */       } else if (javaVersion.startsWith("1.4")) {
/* 165 */         types = getTypes("J2SE-1.4");
/* 166 */       } else if (javaVersion.startsWith("1.3")) {
/* 167 */         types = getTypes("J2SE-1.3");
/* 168 */       } else if (javaVersion.startsWith("1.2")) {
/* 169 */         types = getTypes("J2SE-1.2");
/* 170 */       } else if (javaVersion.startsWith("1.1")) {
/* 171 */         if (vm instanceof IVMInstall3 && isFoundation1_1((IVMInstall3)vm)) {
/* 172 */           types = getTypes("CDC-1.1/Foundation-1.1");
/*     */         } else {
/* 174 */           types = getTypes("JRE-1.1");
/*     */         } 
/* 176 */       } else if (javaVersion.startsWith("1.0")) {
/* 177 */         if (vm instanceof IVMInstall3 && isFoundation1_0((IVMInstall3)vm)) {
/* 178 */           types = getTypes("CDC-1.0/Foundation-1.0");
/*     */         }
/* 180 */       } else if (javaVersion.startsWith("1") && javaVersion.length() >= 2 && javaVersion.charAt(1) != '.') {
/*     */         
/* 182 */         types = getTypes("JavaSE-10+");
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 187 */     if (types != null) {
/* 188 */       for (int i = 0; i < types.size(); i++) {
/* 189 */         addEnvironment(result, types.get(i), (i == 0));
/*     */       }
/*     */     }
/* 192 */     return result.<CompatibleEnvironment>toArray(new CompatibleEnvironment[result.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isFoundation(Map<String, String> properties) {
/* 199 */     for (int i = 0; i < VM_PROPERTIES.length; i++) {
/* 200 */       String value = properties.get(VM_PROPERTIES[i]);
/* 201 */       if (value != null)
/*     */       {
/*     */         
/* 204 */         for (StringTokenizer tokenizer = new StringTokenizer(value); tokenizer.hasMoreTokens();) {
/* 205 */           if ("foundation".equalsIgnoreCase(tokenizer.nextToken()))
/* 206 */             return true; 
/*     */         } 
/*     */       }
/*     */     } 
/* 210 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isFoundation1_0(IVMInstall3 vm) throws CoreException {
/* 214 */     Map<String, String> map = vm.evaluateSystemProperties(VM_PROPERTIES, null);
/* 215 */     return isFoundation(map) ? "1.0".equals(map.get("java.specification.version")) : false;
/*     */   }
/*     */   
/*     */   private boolean isFoundation1_1(IVMInstall3 vm) throws CoreException {
/* 219 */     Map<String, String> map = vm.evaluateSystemProperties(VM_PROPERTIES, null);
/* 220 */     return isFoundation(map) ? "1.1".equals(map.get("java.specification.version")) : false;
/*     */   }
/*     */   
/*     */   private void addEnvironment(ArrayList<CompatibleEnvironment> result, String id, boolean strict) {
/* 224 */     IExecutionEnvironmentsManager manager = JavaRuntime.getExecutionEnvironmentsManager();
/* 225 */     IExecutionEnvironment env = manager.getEnvironment(id);
/* 226 */     if (env != null) {
/* 227 */       result.add(new CompatibleEnvironment(env, strict));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private List<String> getTypes(String type) {
/* 233 */     List<String> result = new ArrayList<>();
/* 234 */     result.add(type);
/* 235 */     String[] values = mappings.get(type);
/* 236 */     if (values != null) {
/* 237 */       for (int i = 0; i < values.length; i++) {
/* 238 */         result.addAll(getTypes(values[i]));
/*     */       }
/*     */     }
/* 241 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\environments\ExecutionEnvironmentAnalyzer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */