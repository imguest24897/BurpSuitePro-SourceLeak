/*     */ package org.eclipse.jdt.launching;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.variables.IStringVariableManager;
/*     */ import org.eclipse.core.variables.VariablesPlugin;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.model.IProcess;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.internal.launching.CommandLineQuoting;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingMessages;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractVMRunner
/*     */   implements IVMRunner
/*     */ {
/*     */   protected void abort(String message, Throwable exception, int code) throws CoreException {
/*  56 */     throw new CoreException(new Status(4, getPluginIdentifier(), code, message, exception));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String getPluginIdentifier();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Process exec(String[] cmdLine, File workingDirectory) throws CoreException {
/*  77 */     cmdLine = quoteWindowsArgs(cmdLine);
/*  78 */     return DebugPlugin.exec(cmdLine, workingDirectory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Process exec(String[] cmdLine, File workingDirectory, String[] envp) throws CoreException {
/*  93 */     cmdLine = quoteWindowsArgs(cmdLine);
/*  94 */     return DebugPlugin.exec(cmdLine, workingDirectory, envp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Process exec(String[] cmdLine, File workingDirectory, String[] envp, boolean mergeOutput) throws CoreException {
/* 115 */     cmdLine = quoteWindowsArgs(cmdLine);
/* 116 */     return DebugPlugin.exec(cmdLine, workingDirectory, envp, mergeOutput);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String[] quoteWindowsArgs(String[] cmdLine) {
/* 123 */     return CommandLineQuoting.quoteWindowsArgs(cmdLine);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getCmdLineAsString(String[] cmdLine) {
/* 133 */     StringBuilder buff = new StringBuilder();
/* 134 */     for (int i = 0; i < cmdLine.length; i++) {
/* 135 */       buff.append(cmdLine[i]);
/* 136 */       if (i != cmdLine.length - 1) {
/* 137 */         if (cmdLine[i + 1].startsWith("-")) {
/* 138 */           buff.append("\n");
/*     */         } else {
/* 140 */           buff.append(' ');
/*     */         } 
/*     */       }
/*     */     } 
/* 144 */     return buff.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<String, String> getDefaultProcessMap() {
/* 153 */     Map<String, String> map = new HashMap<>();
/* 154 */     map.put(IProcess.ATTR_PROCESS_TYPE, "java");
/* 155 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IProcess newProcess(ILaunch launch, Process p, String label, Map<String, String> attributes) throws CoreException {
/* 169 */     IProcess process = DebugPlugin.newProcess(launch, p, label, attributes);
/* 170 */     if (process == null) {
/* 171 */       p.destroy();
/* 172 */       abort(LaunchingMessages.AbstractVMRunner_0, null, 150);
/*     */     } 
/* 174 */     return process;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] combineVmArgs(VMRunnerConfiguration configuration, IVMInstall vmInstall) {
/* 188 */     String[] launchVMArgs = configuration.getVMArguments();
/* 189 */     String[] vmVMArgs = vmInstall.getVMArguments();
/* 190 */     if (vmVMArgs == null || vmVMArgs.length == 0) {
/* 191 */       return launchVMArgs;
/*     */     }
/*     */     
/* 194 */     IStringVariableManager manager = VariablesPlugin.getDefault().getStringVariableManager();
/* 195 */     for (int i = 0; i < vmVMArgs.length; i++) {
/*     */       try {
/* 197 */         vmVMArgs[i] = manager.performStringSubstitution(vmVMArgs[i], false);
/* 198 */       } catch (CoreException e) {
/* 199 */         LaunchingPlugin.log(e.getStatus());
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 205 */     String[] allVMArgs = new String[launchVMArgs.length + vmVMArgs.length];
/* 206 */     System.arraycopy(vmVMArgs, 0, allVMArgs, 0, vmVMArgs.length);
/* 207 */     System.arraycopy(launchVMArgs, 0, allVMArgs, vmVMArgs.length, launchVMArgs.length);
/* 208 */     return allVMArgs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isModular(VMRunnerConfiguration config, IVMInstall vmInstall) {
/* 222 */     if (config.getModuleDescription() != null && config.getModuleDescription().length() > 0 && vmInstall instanceof AbstractVMInstall) {
/* 223 */       AbstractVMInstall install = (AbstractVMInstall)vmInstall;
/* 224 */       String vmver = install.getJavaVersion();
/*     */       
/* 226 */       if (vmver.length() > 3) {
/* 227 */         vmver = vmver.substring(0, 3);
/*     */       }
/* 229 */       if (JavaCore.compareJavaVersions(vmver, "9") >= 0) {
/* 230 */         return true;
/*     */       }
/*     */     } 
/* 233 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\AbstractVMRunner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */