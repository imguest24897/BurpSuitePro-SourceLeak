/*      */ package org.eclipse.jdt.launching;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.StringReader;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Set;
/*      */ import java.util.stream.Collectors;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import org.eclipse.core.resources.IProject;
/*      */ import org.eclipse.core.resources.IResource;
/*      */ import org.eclipse.core.resources.IWorkspaceRoot;
/*      */ import org.eclipse.core.resources.ResourcesPlugin;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.IConfigurationElement;
/*      */ import org.eclipse.core.runtime.IExtensionPoint;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.ListenerList;
/*      */ import org.eclipse.core.runtime.MultiStatus;
/*      */ import org.eclipse.core.runtime.Path;
/*      */ import org.eclipse.core.runtime.Platform;
/*      */ import org.eclipse.core.runtime.Preferences;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.core.runtime.preferences.BundleDefaultsScope;
/*      */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*      */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*      */ import org.eclipse.core.variables.IStringVariableManager;
/*      */ import org.eclipse.core.variables.VariablesPlugin;
/*      */ import org.eclipse.debug.core.ILaunchConfiguration;
/*      */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*      */ import org.eclipse.jdt.core.IAccessRule;
/*      */ import org.eclipse.jdt.core.IClasspathAttribute;
/*      */ import org.eclipse.jdt.core.IClasspathContainer;
/*      */ import org.eclipse.jdt.core.IClasspathEntry;
/*      */ import org.eclipse.jdt.core.IJavaElement;
/*      */ import org.eclipse.jdt.core.IJavaModel;
/*      */ import org.eclipse.jdt.core.IJavaProject;
/*      */ import org.eclipse.jdt.core.IModuleDescription;
/*      */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*      */ import org.eclipse.jdt.core.JavaCore;
/*      */ import org.eclipse.jdt.core.JavaModelException;
/*      */ import org.eclipse.jdt.internal.core.ClasspathEntry;
/*      */ import org.eclipse.jdt.internal.core.JavaProject;
/*      */ import org.eclipse.jdt.internal.launching.CompositeId;
/*      */ import org.eclipse.jdt.internal.launching.DefaultEntryResolver;
/*      */ import org.eclipse.jdt.internal.launching.DefaultProjectClasspathEntry;
/*      */ import org.eclipse.jdt.internal.launching.EEVMType;
/*      */ import org.eclipse.jdt.internal.launching.JREContainerInitializer;
/*      */ import org.eclipse.jdt.internal.launching.JavaSourceLookupUtil;
/*      */ import org.eclipse.jdt.internal.launching.LaunchingMessages;
/*      */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*      */ import org.eclipse.jdt.internal.launching.RuntimeClasspathEntry;
/*      */ import org.eclipse.jdt.internal.launching.RuntimeClasspathEntryResolver;
/*      */ import org.eclipse.jdt.internal.launching.RuntimeClasspathProvider;
/*      */ import org.eclipse.jdt.internal.launching.SocketAttachConnector;
/*      */ import org.eclipse.jdt.internal.launching.VMDefinitionsContainer;
/*      */ import org.eclipse.jdt.internal.launching.VMListener;
/*      */ import org.eclipse.jdt.internal.launching.VariableClasspathEntry;
/*      */ import org.eclipse.jdt.internal.launching.environments.EnvironmentsManager;
/*      */ import org.eclipse.jdt.launching.environments.ExecutionEnvironmentDescription;
/*      */ import org.eclipse.jdt.launching.environments.IExecutionEnvironment;
/*      */ import org.eclipse.jdt.launching.environments.IExecutionEnvironmentsManager;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ import org.osgi.service.prefs.BackingStoreException;
/*      */ import org.osgi.service.prefs.Preferences;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class JavaRuntime
/*      */ {
/*      */   public static final String JRELIB_VARIABLE = "JRE_LIB";
/*      */   public static final String JRESRC_VARIABLE = "JRE_SRC";
/*      */   public static final String JRESRCROOT_VARIABLE = "JRE_SRCROOT";
/*      */   public static final String EXTENSION_POINT_RUNTIME_CLASSPATH_ENTRY_RESOLVERS = "runtimeClasspathEntryResolvers";
/*      */   public static final String EXTENSION_POINT_RUNTIME_CLASSPATH_PROVIDERS = "classpathProviders";
/*      */   public static final String EXTENSION_POINT_EXECUTION_ENVIRONMENTS = "executionEnvironments";
/*      */   public static final String EXTENSION_POINT_VM_INSTALLS = "vmInstalls";
/*      */   public static final String EXTENSION_POINT_LIBRARY_LOCATION_RESOLVERS = "libraryLocationResolvers";
/*  207 */   public static final String JRE_CONTAINER = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".JRE_CONTAINER";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  214 */   public static final String JRE_CONTAINER_MARKER = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".jreContainerMarker";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  221 */   public static final String JRE_COMPILER_COMPLIANCE_MARKER = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".jreCompilerComplianceMarker";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int ERR_UNABLE_TO_RESOLVE_JRE = 160;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  243 */   public static final String PREF_CONNECT_TIMEOUT = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".PREF_CONNECT_TIMEOUT";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  250 */   public static final String PREF_VM_XML = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".PREF_VM_XML";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  259 */   public static final String PREF_STRICTLY_COMPATIBLE_JRE_NOT_AVAILABLE = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".PREF_STRICTLY_COMPATIBLE_JRE_NOT_AVAILABLE";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  270 */   public static final String PREF_COMPILER_COMPLIANCE_DOES_NOT_MATCH_JRE = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".PREF_COMPILER_COMPLIANCE_DOES_NOT_MATCH_JRE";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String ID_PLUGIN = "org.eclipse.jdt.launching";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int DEF_CONNECT_TIMEOUT = 20000;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*  299 */   public static final String ATTR_CMDLINE = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".launcher.cmdLine";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String PREF_ONLY_INCLUDE_EXPORTED_CLASSPATH_ENTRIES = "org.eclipse.jdt.launching.only_include_exported_classpath_entries";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  328 */   public static final String CLASSPATH_ATTR_LIBRARY_PATH_ENTRY = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".CLASSPATH_ATTR_LIBRARY_PATH_ENTRY";
/*      */ 
/*      */   
/*  331 */   private static Object fgVMLock = new Object();
/*      */   
/*      */   private static boolean fgInitializingVMs = false;
/*  334 */   private static HashSet<Object> fgVMTypes = null;
/*  335 */   private static String fgDefaultVMId = null;
/*  336 */   private static String fgDefaultVMConnectorId = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  342 */   private static Map<String, IRuntimeClasspathEntryResolver> fgVariableResolvers = null;
/*  343 */   private static Map<String, IRuntimeClasspathEntryResolver> fgContainerResolvers = null;
/*  344 */   private static Map<String, RuntimeClasspathEntryResolver> fgRuntimeClasspathEntryResolvers = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  349 */   private static Map<String, RuntimeClasspathProvider> fgPathProviders = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  354 */   private static IRuntimeClasspathProvider fgDefaultClasspathProvider = new StandardClasspathProvider();
/*  355 */   private static IRuntimeClasspathProvider fgDefaultSourcePathProvider = new StandardSourcePathProvider();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  360 */   private static ListenerList<IVMInstallChangedListener> fgVMListeners = new ListenerList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  367 */   private static ThreadLocal<List<IJavaProject>> fgProjects = new ThreadLocal<>();
/*  368 */   private static ThreadLocal<Integer> fgEntryCount = new ThreadLocal<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  373 */   private static Set<String> fgContributedVMs = new HashSet<>();
/*      */   
/*      */   private static final String BLANK = " ";
/*      */   
/*      */   private static final String COMMA = ",";
/*      */   
/*      */   private static final String OPTION_START = "--";
/*      */   
/*      */   private static final String ADD_MODULES = "--add-modules ";
/*      */   
/*      */   private static final String LIMIT_MODULES = "--limit-modules ";
/*      */   
/*      */   private static void initializeVMTypeExtensions() {
/*  386 */     IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.jdt.launching", "vmInstallTypes");
/*  387 */     if (extensionPoint != null) {
/*  388 */       IConfigurationElement[] configs = extensionPoint.getConfigurationElements();
/*  389 */       MultiStatus status = new MultiStatus(LaunchingPlugin.getUniqueIdentifier(), 0, "Exceptions occurred", null);
/*  390 */       fgVMTypes = new HashSet();
/*  391 */       for (int i = 0; i < configs.length; i++) {
/*      */         try {
/*  393 */           fgVMTypes.add(configs[i].createExecutableExtension("class"));
/*      */         } catch (CoreException e) {
/*  395 */           status.add(e.getStatus());
/*      */         } 
/*  397 */       }  if (!status.isOK())
/*      */       {
/*  399 */         LaunchingPlugin.log((IStatus)status);
/*      */       }
/*      */     } else {
/*      */       
/*  403 */       LaunchingPlugin.log((IStatus)new Status(4, LaunchingPlugin.getUniqueIdentifier(), "VM Install extension point not found", null));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IVMInstall getVMInstall(IJavaProject project) throws CoreException {
/*  419 */     IVMInstall vm = null;
/*  420 */     IClasspathEntry[] classpath = project.getRawClasspath();
/*  421 */     IRuntimeClasspathEntryResolver resolver = null;
/*  422 */     IClasspathEntry entry = null;
/*  423 */     for (int i = 0; i < classpath.length; i++) {
/*  424 */       entry = classpath[i];
/*  425 */       switch (entry.getEntryKind()) {
/*      */         case 4:
/*  427 */           resolver = getVariableResolver(entry.getPath().segment(0));
/*  428 */           if (resolver != null) {
/*  429 */             vm = resolver.resolveVMInstall(entry);
/*      */           }
/*      */           break;
/*      */         case 5:
/*  433 */           resolver = getContainerResolver(entry.getPath().segment(0));
/*  434 */           if (resolver != null) {
/*  435 */             vm = resolver.resolveVMInstall(entry);
/*      */           }
/*      */           break;
/*      */       } 
/*  439 */       if (vm != null) {
/*  440 */         return vm;
/*      */       }
/*      */     } 
/*  443 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IVMInstallType getVMInstallType(String id) {
/*  453 */     IVMInstallType[] vmTypes = getVMInstallTypes();
/*  454 */     for (int i = 0; i < vmTypes.length; i++) {
/*  455 */       if (vmTypes[i].getId().equals(id)) {
/*  456 */         return vmTypes[i];
/*      */       }
/*      */     } 
/*  459 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setDefaultVMInstall(IVMInstall vm, IProgressMonitor monitor) throws CoreException {
/*  472 */     setDefaultVMInstall(vm, monitor, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setDefaultVMInstall(IVMInstall vm, IProgressMonitor monitor, boolean savePreference) throws CoreException {
/*  488 */     IVMInstall previous = null;
/*  489 */     if (fgDefaultVMId != null) {
/*  490 */       previous = getVMFromCompositeId(fgDefaultVMId);
/*      */     }
/*  492 */     fgDefaultVMId = getCompositeIdFromVM(vm);
/*  493 */     if (savePreference) {
/*  494 */       saveVMConfiguration();
/*      */     }
/*  496 */     IVMInstall current = null;
/*  497 */     if (fgDefaultVMId != null) {
/*  498 */       current = getVMFromCompositeId(fgDefaultVMId);
/*      */     }
/*  500 */     if (previous != current) {
/*  501 */       notifyDefaultVMChanged(previous, current);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setDefaultVMConnector(IVMConnector connector, IProgressMonitor monitor) throws CoreException {
/*  515 */     fgDefaultVMConnectorId = connector.getIdentifier();
/*  516 */     saveVMConfiguration();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IVMInstall getDefaultVMInstall() {
/*  526 */     IVMInstall install = getVMFromCompositeId(getDefaultVMId());
/*  527 */     if (install != null) {
/*  528 */       File location = install.getInstallLocation();
/*  529 */       if (location != null && 
/*  530 */         location.exists()) {
/*  531 */         return install;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  536 */     if (install != null) {
/*  537 */       install.getVMInstallType().disposeVMInstall(install.getId());
/*      */     }
/*  539 */     synchronized (fgVMLock) {
/*  540 */       fgDefaultVMId = null;
/*  541 */       fgVMTypes = null;
/*  542 */       initializeVMs();
/*      */     } 
/*  544 */     return getVMFromCompositeId(getDefaultVMId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IVMConnector getDefaultVMConnector() {
/*      */     SocketAttachConnector socketAttachConnector;
/*  553 */     String id = getDefaultVMConnectorId();
/*  554 */     IVMConnector connector = null;
/*  555 */     if (id != null) {
/*  556 */       connector = getVMConnector(id);
/*      */     }
/*  558 */     if (connector == null) {
/*  559 */       socketAttachConnector = new SocketAttachConnector();
/*      */     }
/*  561 */     return (IVMConnector)socketAttachConnector;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IVMInstallType[] getVMInstallTypes() {
/*  572 */     initializeVMs();
/*  573 */     return fgVMTypes.<IVMInstallType>toArray(new IVMInstallType[fgVMTypes.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getDefaultVMId() {
/*  581 */     initializeVMs();
/*  582 */     return fgDefaultVMId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getDefaultVMConnectorId() {
/*  590 */     initializeVMs();
/*  591 */     return fgDefaultVMConnectorId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getCompositeIdFromVM(IVMInstall vm) {
/*  603 */     if (vm == null) {
/*  604 */       return null;
/*      */     }
/*  606 */     IVMInstallType vmType = vm.getVMInstallType();
/*  607 */     String typeID = vmType.getId();
/*  608 */     CompositeId id = new CompositeId(new String[] { typeID, vm.getId() });
/*  609 */     return id.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IVMInstall getVMFromCompositeId(String idString) {
/*  622 */     if (idString == null || idString.length() == 0) {
/*  623 */       return null;
/*      */     }
/*  625 */     CompositeId id = CompositeId.fromString(idString);
/*  626 */     if (id.getPartCount() == 2) {
/*  627 */       IVMInstallType vmType = getVMInstallType(id.get(0));
/*  628 */       if (vmType != null) {
/*  629 */         return vmType.findVMInstall(id.get(1));
/*      */       }
/*      */     } 
/*  632 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry newStringVariableClasspathEntry(String expression) {
/*  645 */     return (IRuntimeClasspathEntry)new VariableClasspathEntry(expression);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry newDefaultProjectClasspathEntry(IJavaProject project) {
/*  657 */     return (IRuntimeClasspathEntry)new DefaultProjectClasspathEntry(project);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry newProjectRuntimeClasspathEntry(IJavaProject project) {
/*  668 */     return newRuntimeClasspathEntry(JavaCore.newProjectEntry(project.getProject().getFullPath()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry newProjectRuntimeClasspathEntry(IJavaProject project, int classpathProperty) {
/*  683 */     return newRuntimeClasspathEntry(JavaCore.newProjectEntry(project.getProject().getFullPath()), classpathProperty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry newArchiveRuntimeClasspathEntry(IResource resource) {
/*  695 */     return newRuntimeClasspathEntry(JavaCore.newLibraryEntry(resource.getFullPath(), null, null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry newArchiveRuntimeClasspathEntry(IPath path, int classpathProperty) {
/*  710 */     return newRuntimeClasspathEntry(JavaCore.newLibraryEntry(path, null, null), classpathProperty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry newArchiveRuntimeClasspathEntry(IPath path, int classpathProperty, IJavaProject javaProject) {
/*  727 */     RuntimeClasspathEntry entry = new RuntimeClasspathEntry(JavaCore.newLibraryEntry(path, null, null), classpathProperty);
/*  728 */     entry.setJavaProject(javaProject);
/*  729 */     return (IRuntimeClasspathEntry)entry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry newArchiveRuntimeClasspathEntry(IPath path) {
/*  741 */     return newRuntimeClasspathEntry(JavaCore.newLibraryEntry(path, null, null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry newArchiveRuntimeClasspathEntry(IPath path, IPath sourceAttachmentPath, IPath sourceAttachmentRootPath, IAccessRule[] accessRules, IClasspathAttribute[] extraAttributes, boolean isExported) {
/*  766 */     return newRuntimeClasspathEntry(JavaCore.newLibraryEntry(path, sourceAttachmentPath, sourceAttachmentRootPath, accessRules, extraAttributes, isExported));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry newVariableRuntimeClasspathEntry(IPath path) {
/*  779 */     return newRuntimeClasspathEntry(JavaCore.newVariableEntry(path, null, null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry newRuntimeContainerClasspathEntry(IPath path, int classpathProperty) throws CoreException {
/*  795 */     return newRuntimeContainerClasspathEntry(path, classpathProperty, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry newRuntimeContainerClasspathEntry(IPath path, int classpathProperty, IJavaProject project) throws CoreException {
/*  813 */     RuntimeClasspathEntry entry = new RuntimeClasspathEntry(JavaCore.newContainerEntry(path), classpathProperty);
/*  814 */     entry.setJavaProject(project);
/*  815 */     return (IRuntimeClasspathEntry)entry;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry newRuntimeClasspathEntry(String memento) throws CoreException {
/*      */     try {
/*  828 */       Element root = null;
/*  829 */       DocumentBuilder parser = LaunchingPlugin.getParser();
/*  830 */       StringReader reader = new StringReader(memento);
/*  831 */       InputSource source = new InputSource(reader);
/*  832 */       root = parser.parse(source).getDocumentElement();
/*      */       
/*  834 */       String id = root.getAttribute("id");
/*  835 */       if (id == null || id.length() == 0)
/*      */       {
/*  837 */         return (IRuntimeClasspathEntry)new RuntimeClasspathEntry(root);
/*      */       }
/*      */       
/*  840 */       IRuntimeClasspathEntry2 entry = LaunchingPlugin.getDefault().newRuntimeClasspathEntry(id);
/*  841 */       NodeList list = root.getChildNodes();
/*  842 */       Node node = null;
/*  843 */       Element element = null;
/*  844 */       for (int i = 0; i < list.getLength(); i++) {
/*  845 */         node = list.item(i);
/*  846 */         if (node.getNodeType() == 1) {
/*  847 */           element = (Element)node;
/*  848 */           if ("memento".equals(element.getNodeName())) {
/*  849 */             entry.initializeFrom(element);
/*      */           }
/*      */         } 
/*      */       } 
/*  853 */       return entry;
/*  854 */     } catch (SAXException e) {
/*  855 */       abort(LaunchingMessages.JavaRuntime_32, e);
/*  856 */     } catch (IOException e) {
/*  857 */       abort(LaunchingMessages.JavaRuntime_32, e);
/*      */     } 
/*  859 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IRuntimeClasspathEntry newRuntimeClasspathEntry(IClasspathEntry entry) {
/*  872 */     return (IRuntimeClasspathEntry)new RuntimeClasspathEntry(entry);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IRuntimeClasspathEntry newRuntimeClasspathEntry(IClasspathEntry entry, int classPathProperty) {
/*  885 */     return (IRuntimeClasspathEntry)new RuntimeClasspathEntry(entry, classPathProperty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry[] computeUnresolvedRuntimeClasspath(IJavaProject project) throws CoreException {
/*  900 */     return computeUnresolvedRuntimeClasspath(project, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry[] computeUnresolvedRuntimeClasspath(IJavaProject project, boolean excludeTestCode) throws CoreException {
/*  917 */     IClasspathEntry[] entries = project.getRawClasspath();
/*  918 */     List<IRuntimeClasspathEntry> classpathEntries = new ArrayList<>(3);
/*  919 */     for (int i = 0; i < entries.length; i++) {
/*  920 */       IClasspathContainer container; IClasspathEntry entry = entries[i];
/*  921 */       switch (entry.getEntryKind()) {
/*      */         case 5:
/*  923 */           container = JavaCore.getClasspathContainer(entry.getPath(), project);
/*  924 */           if (container != null) {
/*  925 */             switch (container.getKind()) {
/*      */ 
/*      */ 
/*      */               
/*      */               case 3:
/*  930 */                 classpathEntries.add(newRuntimeContainerClasspathEntry(container.getPath(), 1, project));
/*      */                 break;
/*      */               case 2:
/*  933 */                 classpathEntries.add(newRuntimeContainerClasspathEntry(container.getPath(), 2, project));
/*      */                 break;
/*      */             } 
/*      */           }
/*      */           break;
/*      */         case 4:
/*  939 */           if ("JRE_LIB".equals(entry.getPath().segment(0))) {
/*  940 */             IRuntimeClasspathEntry jre = newVariableRuntimeClasspathEntry(entry.getPath());
/*  941 */             jre.setClasspathProperty(1);
/*  942 */             classpathEntries.add(jre);
/*      */           } 
/*      */           break;
/*      */       } 
/*      */ 
/*      */     
/*      */     } 
/*  949 */     classpathEntries.add(newDefaultProjectClasspathEntry(project));
/*  950 */     return classpathEntries.<IRuntimeClasspathEntry>toArray(new IRuntimeClasspathEntry[classpathEntries.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry[] computeUnresolvedRuntimeDependencies(IJavaProject project) throws CoreException {
/*  965 */     return computeUnresolvedRuntimeDependencies(project, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry[] computeUnresolvedRuntimeDependencies(IJavaProject project, boolean excludeTestCode) throws CoreException {
/*  982 */     IClasspathEntry entry1 = JavaCore.newProjectEntry(project.getProject().getFullPath());
/*  983 */     List<Object> classpathEntries = new ArrayList(5);
/*  984 */     List<IClasspathEntry> expanding = new ArrayList<>(5);
/*  985 */     boolean exportedEntriesOnly = Platform.getPreferencesService().getBoolean("org.eclipse.jdt.launching", "org.eclipse.jdt.launching.only_include_exported_classpath_entries", false, null);
/*  986 */     DefaultProjectClasspathEntry.expandProject(entry1, classpathEntries, expanding, excludeTestCode, exportedEntriesOnly, project, true);
/*  987 */     IRuntimeClasspathEntry[] runtimeEntries = new IRuntimeClasspathEntry[classpathEntries.size()];
/*  988 */     for (int i = 0; i < runtimeEntries.length; i++) {
/*  989 */       Object e = classpathEntries.get(i);
/*  990 */       if (e instanceof IClasspathEntry) {
/*  991 */         IClasspathEntry cpe = (IClasspathEntry)e;
/*  992 */         if (cpe == entry1) {
/*  993 */           if (isModularProject(project)) {
/*  994 */             runtimeEntries[i] = (IRuntimeClasspathEntry)new RuntimeClasspathEntry(entry1, 4);
/*      */           } else {
/*  996 */             runtimeEntries[i] = (IRuntimeClasspathEntry)new RuntimeClasspathEntry(entry1, 5);
/*      */           } 
/*      */         } else {
/*  999 */           runtimeEntries[i] = (IRuntimeClasspathEntry)new RuntimeClasspathEntry(cpe);
/* 1000 */           DefaultProjectClasspathEntry.adjustClasspathProperty(runtimeEntries[i], cpe);
/*      */         } 
/*      */       } else {
/* 1003 */         runtimeEntries[i] = (IRuntimeClasspathEntry)e;
/*      */       } 
/*      */     } 
/* 1006 */     List<IRuntimeClasspathEntry> ordered = new ArrayList<>(runtimeEntries.length);
/* 1007 */     for (int j = 0; j < runtimeEntries.length; j++) {
/* 1008 */       if (runtimeEntries[j].getClasspathProperty() != 1 && 
/* 1009 */         runtimeEntries[j].getClasspathProperty() != 2) {
/* 1010 */         ordered.add(runtimeEntries[j]);
/*      */       }
/*      */     } 
/* 1013 */     IRuntimeClasspathEntry jreEntry = computeModularJREEntry(project);
/* 1014 */     if (jreEntry != null) {
/* 1015 */       ordered.add(jreEntry);
/*      */     }
/* 1017 */     return ordered.<IRuntimeClasspathEntry>toArray(new IRuntimeClasspathEntry[ordered.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isModule(IClasspathEntry entry, IJavaProject proj) {
/* 1029 */     if (entry == null) {
/* 1030 */       return false;
/*      */     }
/* 1032 */     if (!isModularProject(proj)) {
/* 1033 */       return false;
/*      */     }
/*      */     
/* 1036 */     return ClasspathEntry.isModular(entry);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isModularConfiguration(ILaunchConfiguration configuration) {
/*      */     try {
/* 1051 */       IVMInstall vm = computeVMInstall(configuration);
/* 1052 */       return isModularJava(vm);
/*      */     }
/* 1054 */     catch (CoreException e) {
/* 1055 */       e.printStackTrace();
/*      */       
/* 1057 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isModularJava(IVMInstall vm) {
/* 1070 */     if (compareJavaVersions(vm, "1.8") > 0) {
/* 1071 */       return true;
/*      */     }
/* 1073 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compareJavaVersions(IVMInstall vm, String ver) {
/* 1089 */     if (vm instanceof AbstractVMInstall) {
/* 1090 */       AbstractVMInstall install = (AbstractVMInstall)vm;
/* 1091 */       String vmver = install.getJavaVersion();
/* 1092 */       if (vmver == null) {
/* 1093 */         return -1;
/*      */       }
/*      */       
/* 1096 */       if (vmver.length() > 3) {
/* 1097 */         vmver = vmver.substring(0, 3);
/*      */       }
/* 1099 */       return JavaCore.compareJavaVersions(vmver, ver);
/*      */     } 
/* 1101 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isModularProject(IJavaProject proj) {
/*      */     try {
/* 1116 */       IModuleDescription module = (proj == null) ? null : proj.getModuleDescription();
/* 1117 */       String modName = (module == null) ? null : module.getElementName();
/* 1118 */       if (modName != null && modName.length() > 0) {
/* 1119 */         return true;
/*      */       }
/*      */     }
/* 1122 */     catch (JavaModelException javaModelException) {}
/*      */     
/* 1124 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry[] computeUnresolvedSourceLookupPath(ILaunchConfiguration configuration) throws CoreException {
/* 1137 */     return getSourceLookupPathProvider(configuration).computeUnresolvedClasspath(configuration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry[] resolveSourceLookupPath(IRuntimeClasspathEntry[] entries, ILaunchConfiguration configuration) throws CoreException {
/* 1151 */     return getSourceLookupPathProvider(configuration).resolveClasspath(entries, configuration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathProvider getClasspathProvider(ILaunchConfiguration configuration) throws CoreException {
/* 1163 */     String providerId = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_CLASSPATH_PROVIDER, null);
/* 1164 */     IRuntimeClasspathProvider provider = null;
/* 1165 */     if (providerId == null) {
/* 1166 */       provider = fgDefaultClasspathProvider;
/*      */     } else {
/* 1168 */       provider = (IRuntimeClasspathProvider)getClasspathProviders().get(providerId);
/* 1169 */       if (provider == null) {
/* 1170 */         abort(NLS.bind(LaunchingMessages.JavaRuntime_26, (Object[])new String[] { providerId }), null);
/*      */       }
/*      */     } 
/* 1173 */     return provider;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathProvider getSourceLookupPathProvider(ILaunchConfiguration configuration) throws CoreException {
/* 1185 */     String providerId = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_SOURCE_PATH_PROVIDER, null);
/* 1186 */     IRuntimeClasspathProvider provider = null;
/* 1187 */     if (providerId == null) {
/* 1188 */       provider = fgDefaultSourcePathProvider;
/*      */     } else {
/* 1190 */       provider = (IRuntimeClasspathProvider)getClasspathProviders().get(providerId);
/* 1191 */       if (provider == null) {
/* 1192 */         abort(NLS.bind(LaunchingMessages.JavaRuntime_27, (Object[])new String[] { providerId }), null);
/*      */       }
/*      */     } 
/* 1195 */     return provider;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry[] resolveRuntimeClasspathEntry(IRuntimeClasspathEntry entry, ILaunchConfiguration configuration) throws CoreException {
/*      */     IResource resource;
/*      */     IRuntimeClasspathEntryResolver resolver;
/*      */     String location;
/* 1221 */     boolean excludeTestCode = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_EXCLUDE_TEST_CODE, false);
/* 1222 */     switch (entry.getType()) {
/*      */       
/*      */       case 1:
/* 1225 */         resource = entry.getResource();
/* 1226 */         if (resource instanceof IProject) {
/* 1227 */           IProject p = (IProject)resource;
/* 1228 */           IJavaProject project = JavaCore.create(p);
/* 1229 */           if (project == null || !p.isOpen() || !project.exists()) {
/* 1230 */             return new IRuntimeClasspathEntry[0];
/*      */           }
/* 1232 */           IClasspathAttribute[] attributes = entry.getClasspathEntry().getExtraAttributes();
/* 1233 */           IRuntimeClasspathEntry[] entries = resolveOutputLocations(project, entry.getClasspathProperty(), attributes, excludeTestCode);
/* 1234 */           if (entries != null)
/* 1235 */             return entries; 
/*      */           break;
/*      */         } 
/* 1238 */         if (isOptional(entry.getClasspathEntry())) {
/* 1239 */           return new IRuntimeClasspathEntry[0];
/*      */         }
/* 1241 */         abort(NLS.bind(LaunchingMessages.JavaRuntime_Classpath_references_non_existant_project___0__3, (Object[])new String[] { entry.getPath().lastSegment() }), null);
/*      */         break;
/*      */       
/*      */       case 3:
/* 1245 */         resolver = getVariableResolver(entry.getVariableName());
/* 1246 */         if (resolver == null) {
/* 1247 */           IRuntimeClasspathEntry[] resolved = resolveVariableEntry(entry, null, false, configuration);
/* 1248 */           if (resolved != null) {
/* 1249 */             return resolved;
/*      */           }
/*      */           break;
/*      */         } 
/* 1253 */         return resolver.resolveRuntimeClasspathEntry(entry, configuration);
/*      */       case 4:
/* 1255 */         resolver = getContainerResolver(entry.getVariableName());
/* 1256 */         if (resolver == null) {
/* 1257 */           return computeDefaultContainerEntries(entry, configuration, excludeTestCode);
/*      */         }
/* 1259 */         return resolver.resolveRuntimeClasspathEntry(entry, configuration);
/*      */       
/*      */       case 2:
/* 1262 */         location = entry.getLocation();
/* 1263 */         if (location != null) {
/* 1264 */           File file = new File(location);
/* 1265 */           if (file.exists()) {
/*      */             break;
/*      */           }
/*      */         } 
/* 1269 */         if (isOptional(entry.getClasspathEntry())) {
/* 1270 */           return new IRuntimeClasspathEntry[0];
/*      */         }
/* 1272 */         abort(NLS.bind(LaunchingMessages.JavaRuntime_Classpath_references_non_existant_archive___0__4, (Object[])new String[] { entry.getPath().toString() }), null);
/*      */       case 5:
/* 1274 */         resolver = getContributedResolver(((IRuntimeClasspathEntry2)entry).getTypeId());
/* 1275 */         return resolver.resolveRuntimeClasspathEntry(entry, configuration);
/*      */     } 
/* 1277 */     return new IRuntimeClasspathEntry[] {
/*      */         
/* 1279 */         entry };
/*      */   }
/*      */   
/*      */   private static boolean isOptional(IClasspathEntry entry) {
/* 1283 */     IClasspathAttribute[] extraAttributes = entry.getExtraAttributes();
/* 1284 */     for (int i = 0, length = extraAttributes.length; i < length; i++) {
/* 1285 */       IClasspathAttribute attribute = extraAttributes[i];
/* 1286 */       if ("optional".equals(attribute.getName()) && Boolean.parseBoolean(attribute.getValue())) {
/* 1287 */         return true;
/*      */       }
/*      */     } 
/* 1290 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IRuntimeClasspathEntry[] resolveVariableEntry(IRuntimeClasspathEntry entry, IJavaProject project, boolean excludeTestCode, ILaunchConfiguration configuration) throws CoreException {
/* 1310 */     IPath archPath = JavaCore.getClasspathVariable(entry.getVariableName());
/* 1311 */     if (archPath != null) {
/* 1312 */       if (entry.getPath().segmentCount() > 1) {
/* 1313 */         archPath = archPath.append(entry.getPath().removeFirstSegments(1));
/*      */       }
/* 1315 */       IPath srcPath = null;
/* 1316 */       IPath srcVar = entry.getSourceAttachmentPath();
/* 1317 */       IPath srcRootPath = null;
/* 1318 */       IPath srcRootVar = entry.getSourceAttachmentRootPath();
/* 1319 */       if (archPath != null && !archPath.isEmpty()) {
/* 1320 */         if (srcVar != null && !srcVar.isEmpty()) {
/* 1321 */           srcPath = JavaCore.getClasspathVariable(srcVar.segment(0));
/* 1322 */           if (srcPath != null) {
/* 1323 */             if (srcVar.segmentCount() > 1) {
/* 1324 */               srcPath = srcPath.append(srcVar.removeFirstSegments(1));
/*      */             }
/* 1326 */             if (srcRootVar != null && !srcRootVar.isEmpty()) {
/* 1327 */               srcRootPath = JavaCore.getClasspathVariable(srcRootVar.segment(0));
/* 1328 */               if (srcRootPath != null && 
/* 1329 */                 srcRootVar.segmentCount() > 1) {
/* 1330 */                 srcRootPath = srcRootPath.append(srcRootVar.removeFirstSegments(1));
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 1337 */         IClasspathEntry cpEntry = entry.getClasspathEntry();
/* 1338 */         IClasspathEntry archEntry = JavaCore.newLibraryEntry(archPath, srcPath, srcRootPath, null, cpEntry.getExtraAttributes(), cpEntry.isExported());
/* 1339 */         IRuntimeClasspathEntry runtimeArchEntry = newRuntimeClasspathEntry(archEntry);
/* 1340 */         runtimeArchEntry.setClasspathProperty(entry.getClasspathProperty());
/* 1341 */         if (configuration == null) {
/* 1342 */           return resolveRuntimeClasspathEntry(runtimeArchEntry, project, excludeTestCode);
/*      */         }
/* 1344 */         return resolveRuntimeClasspathEntry(runtimeArchEntry, configuration);
/*      */       } 
/*      */     } 
/* 1347 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IRuntimeClasspathEntry[] resolveOutputLocations(IJavaProject project, int classpathProperty, IClasspathAttribute[] attributes, boolean excludeTestCode) throws CoreException {
/* 1368 */     List<IPath> nonDefault = new ArrayList<>();
/* 1369 */     boolean defaultUsedByNonTest = false;
/* 1370 */     if (project.exists() && project.getProject().isOpen()) {
/* 1371 */       IClasspathEntry[] entries = project.getRawClasspath();
/* 1372 */       for (int j = 0; j < entries.length; j++) {
/* 1373 */         IClasspathEntry classpathEntry = entries[j];
/* 1374 */         if (classpathEntry.getEntryKind() == 3) {
/* 1375 */           IPath path = classpathEntry.getOutputLocation();
/* 1376 */           if (path != null) {
/* 1377 */             if (!excludeTestCode || !classpathEntry.isTest()) {
/* 1378 */               nonDefault.add(path);
/*      */             }
/*      */           }
/* 1381 */           else if (!classpathEntry.isTest()) {
/* 1382 */             defaultUsedByNonTest = true;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1388 */     boolean isModular = (project.getOwnModuleDescription() != null);
/* 1389 */     if (nonDefault.isEmpty() && !isModular && !excludeTestCode)
/*      */     {
/* 1391 */       return null;
/*      */     }
/*      */     
/* 1394 */     IPath def = project.getOutputLocation();
/* 1395 */     if ((!excludeTestCode || defaultUsedByNonTest) && 
/* 1396 */       !nonDefault.contains(def)) {
/* 1397 */       nonDefault.add(def);
/*      */     }
/*      */     
/* 1400 */     IRuntimeClasspathEntry[] locations = new IRuntimeClasspathEntry[nonDefault.size()];
/* 1401 */     for (int i = 0; i < locations.length; i++) {
/* 1402 */       IClasspathEntry newEntry = JavaCore.newLibraryEntry(nonDefault.get(i), null, null, null, attributes, false);
/* 1403 */       locations[i] = (IRuntimeClasspathEntry)new RuntimeClasspathEntry(newEntry);
/* 1404 */       if (isModular && !containsModuleInfo(locations[i])) {
/* 1405 */         locations[i].setClasspathProperty(6);
/* 1406 */         ((RuntimeClasspathEntry)locations[i]).setJavaProject(project);
/*      */       } else {
/* 1408 */         locations[i].setClasspathProperty(classpathProperty);
/*      */       } 
/*      */     } 
/* 1411 */     return locations;
/*      */   }
/*      */   
/*      */   private static boolean containsModuleInfo(IRuntimeClasspathEntry entry) {
/* 1415 */     return (new File(String.valueOf(entry.getLocation()) + File.separator + "module-info.class")).exists();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry[] resolveRuntimeClasspathEntry(IRuntimeClasspathEntry entry, IJavaProject project) throws CoreException {
/* 1441 */     return resolveRuntimeClasspathEntry(entry, project, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry[] resolveRuntimeClasspathEntry(IRuntimeClasspathEntry entry, IJavaProject project, boolean excludeTestCode) throws CoreException {
/*      */     IResource resource;
/*      */     IRuntimeClasspathEntryResolver resolver;
/* 1469 */     switch (entry.getType()) {
/*      */       
/*      */       case 1:
/* 1472 */         resource = entry.getResource();
/* 1473 */         if (resource instanceof IProject) {
/* 1474 */           IProject p = (IProject)resource;
/* 1475 */           IJavaProject jp = JavaCore.create(p);
/* 1476 */           if (jp != null && p.isOpen() && jp.exists()) {
/* 1477 */             IClasspathAttribute[] attributes = entry.getClasspathEntry().getExtraAttributes();
/* 1478 */             IRuntimeClasspathEntry[] entries = resolveOutputLocations(jp, entry.getClasspathProperty(), attributes, excludeTestCode);
/* 1479 */             if (entries != null)
/* 1480 */               return entries; 
/*      */             break;
/*      */           } 
/* 1483 */           return new IRuntimeClasspathEntry[0];
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 3:
/* 1488 */         resolver = getVariableResolver(entry.getVariableName());
/* 1489 */         if (resolver == null) {
/* 1490 */           IRuntimeClasspathEntry[] resolved = resolveVariableEntry(entry, project, excludeTestCode, null);
/* 1491 */           if (resolved != null) {
/* 1492 */             return resolved;
/*      */           }
/*      */           break;
/*      */         } 
/* 1496 */         return resolver.resolveRuntimeClasspathEntry(entry, project, excludeTestCode);
/*      */       case 4:
/* 1498 */         resolver = getContainerResolver(entry.getVariableName());
/* 1499 */         if (resolver == null) {
/* 1500 */           return computeDefaultContainerEntries(entry, project, excludeTestCode);
/*      */         }
/* 1502 */         return resolver.resolveRuntimeClasspathEntry(entry, project, excludeTestCode);
/*      */       case 5:
/* 1504 */         resolver = getContributedResolver(((IRuntimeClasspathEntry2)entry).getTypeId());
/* 1505 */         return resolver.resolveRuntimeClasspathEntry(entry, project, excludeTestCode);
/*      */     } 
/* 1507 */     return new IRuntimeClasspathEntry[] {
/*      */         
/* 1509 */         entry
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IRuntimeClasspathEntry[] computeDefaultContainerEntries(IRuntimeClasspathEntry entry, ILaunchConfiguration config, boolean excludeTestCode) throws CoreException {
/* 1526 */     IJavaProject project = entry.getJavaProject();
/* 1527 */     if (project == null) {
/* 1528 */       project = getJavaProject(config);
/*      */     }
/* 1530 */     return computeDefaultContainerEntries(entry, project, excludeTestCode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IRuntimeClasspathEntry[] computeDefaultContainerEntries(IRuntimeClasspathEntry entry, IJavaProject project, boolean excludeTestCode) throws CoreException {
/* 1547 */     if (project == null || entry == null)
/*      */     {
/* 1549 */       return new IRuntimeClasspathEntry[0];
/*      */     }
/* 1551 */     IClasspathContainer container = JavaCore.getClasspathContainer(entry.getPath(), project);
/* 1552 */     if (container == null) {
/* 1553 */       abort(NLS.bind(LaunchingMessages.JavaRuntime_Could_not_resolve_classpath_container___0__1, (Object[])new String[] { entry.getPath().toString() }), null);
/*      */       
/* 1555 */       return null;
/*      */     } 
/* 1557 */     IClasspathEntry[] cpes = container.getClasspathEntries();
/* 1558 */     int property = -1;
/* 1559 */     switch (container.getKind()) {
/*      */       case 1:
/* 1561 */         switch (entry.getClasspathProperty()) {
/*      */           case 4:
/* 1563 */             property = 4;
/*      */             break;
/*      */           case 5:
/* 1566 */             property = 5;
/*      */             break;
/*      */         } 
/* 1569 */         property = 3;
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/* 1575 */         property = 1;
/*      */         break;
/*      */       case 2:
/* 1578 */         property = 2;
/*      */         break;
/*      */     } 
/* 1581 */     List<IRuntimeClasspathEntry> resolved = new ArrayList<>(cpes.length);
/* 1582 */     List<IJavaProject> projects = fgProjects.get();
/* 1583 */     Integer count = fgEntryCount.get();
/* 1584 */     if (projects == null) {
/* 1585 */       projects = new ArrayList<>();
/* 1586 */       fgProjects.set(projects);
/* 1587 */       count = Integer.valueOf(0);
/*      */     } 
/* 1589 */     int intCount = count.intValue();
/* 1590 */     intCount++;
/* 1591 */     fgEntryCount.set(Integer.valueOf(intCount));
/*      */     try {
/* 1593 */       for (int j = 0; j < cpes.length; j++) {
/* 1594 */         IClasspathEntry cpe = cpes[j];
/* 1595 */         if (cpe.getEntryKind() == 2) {
/* 1596 */           IProject p = ResourcesPlugin.getWorkspace().getRoot().getProject(cpe.getPath().segment(0));
/* 1597 */           IJavaProject jp = JavaCore.create(p);
/* 1598 */           if (!projects.contains(jp)) {
/* 1599 */             projects.add(jp);
/* 1600 */             IRuntimeClasspathEntry classpath = newDefaultProjectClasspathEntry(jp);
/* 1601 */             IRuntimeClasspathEntry[] entries = resolveRuntimeClasspathEntry(classpath, jp, excludeTestCode);
/* 1602 */             for (int k = 0; k < entries.length; k++) {
/* 1603 */               IRuntimeClasspathEntry e = entries[k];
/* 1604 */               if (!resolved.contains(e)) {
/* 1605 */                 resolved.add(entries[k]);
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } else {
/* 1610 */           IRuntimeClasspathEntry e = newRuntimeClasspathEntry(cpe);
/* 1611 */           if (!resolved.contains(e)) {
/* 1612 */             resolved.add(e);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } finally {
/* 1617 */       intCount--;
/* 1618 */       if (intCount == 0) {
/* 1619 */         fgProjects.set(null);
/* 1620 */         fgEntryCount.set(null);
/*      */       } else {
/* 1622 */         fgEntryCount.set(Integer.valueOf(intCount));
/*      */       } 
/*      */     } 
/*      */     
/* 1626 */     IRuntimeClasspathEntry[] result = new IRuntimeClasspathEntry[resolved.size()];
/* 1627 */     for (int i = 0; i < result.length; i++) {
/* 1628 */       result[i] = resolved.get(i);
/* 1629 */       result[i].setClasspathProperty(property);
/*      */     } 
/* 1631 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry[] computeUnresolvedRuntimeClasspath(ILaunchConfiguration configuration) throws CoreException {
/* 1644 */     return getClasspathProvider(configuration).computeUnresolvedClasspath(configuration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry[] resolveRuntimeClasspath(IRuntimeClasspathEntry[] entries, ILaunchConfiguration configuration) throws CoreException {
/*      */     IJavaProject project;
/* 1658 */     if (!isModularConfiguration(configuration)) {
/* 1659 */       return getClasspathProvider(configuration).resolveClasspath(entries, configuration);
/*      */     }
/* 1661 */     IRuntimeClasspathEntry[] entries1 = getClasspathProvider(configuration).resolveClasspath(entries, configuration);
/* 1662 */     List<IRuntimeClasspathEntry> entries2 = new ArrayList<>(entries1.length);
/*      */     
/*      */     try {
/* 1665 */       project = getJavaProject(configuration);
/* 1666 */     } catch (CoreException coreException) {
/* 1667 */       project = null;
/*      */     } 
/* 1669 */     if (project == null) {
/* 1670 */       entries2.addAll(Arrays.asList(entries1));
/*      */     } else {
/*      */       
/* 1673 */       IPackageFragmentRoot jreContainer = findJreContainer(project);
/* 1674 */       IPath jrePath = (jreContainer != null) ? jreContainer.getPath() : null; byte b; int i;
/*      */       IRuntimeClasspathEntry[] arrayOfIRuntimeClasspathEntry;
/* 1676 */       for (i = (arrayOfIRuntimeClasspathEntry = entries1).length, b = 0; b < i; ) { IRuntimeClasspathEntry entry = arrayOfIRuntimeClasspathEntry[b];
/* 1677 */         switch (entry.getClasspathEntry().getEntryKind()) {
/*      */           case 1:
/* 1679 */             if (!entry.getPath().lastSegment().contains("jrt-fs.jar") && (
/* 1680 */               jrePath == null || !jrePath.equals(entry.getPath()))) {
/* 1681 */               entries2.add(entry);
/*      */             }
/*      */             break;
/*      */           default:
/* 1685 */             entries2.add(entry); break;
/*      */         }  b++; }
/*      */     
/*      */     } 
/* 1689 */     return entries2.<IRuntimeClasspathEntry>toArray(new IRuntimeClasspathEntry[entries2.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IPackageFragmentRoot findJreContainer(IJavaProject project) throws JavaModelException {
/* 1701 */     IPackageFragmentRoot jreContainer = null;
/*      */     
/* 1703 */     IPackageFragmentRoot[] allPackageFragmentRoots = project.getAllPackageFragmentRoots(); byte b; int i; IPackageFragmentRoot[] arrayOfIPackageFragmentRoot1;
/* 1704 */     for (i = (arrayOfIPackageFragmentRoot1 = allPackageFragmentRoots).length, b = 0; b < i; ) { IPackageFragmentRoot packageFragmentRoot = arrayOfIPackageFragmentRoot1[b];
/* 1705 */       if (packageFragmentRoot.getRawClasspathEntry().getPath().segment(0).contains("JRE_CONTAINER")) {
/* 1706 */         jreContainer = packageFragmentRoot; break;
/*      */       } 
/*      */       b++; }
/*      */     
/* 1710 */     return jreContainer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IJavaProject getJavaProject(ILaunchConfiguration configuration) throws CoreException {
/* 1724 */     String projectName = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_PROJECT_NAME, null);
/* 1725 */     if (projectName == null || projectName.trim().length() < 1) {
/* 1726 */       return null;
/*      */     }
/* 1728 */     IJavaProject javaProject = getJavaModel().getJavaProject(projectName);
/* 1729 */     if (javaProject != null && javaProject.getProject().exists() && !javaProject.getProject().isOpen()) {
/* 1730 */       abort(NLS.bind(LaunchingMessages.JavaRuntime_28, (Object[])new String[] { configuration.getName(), projectName }), 124, null);
/*      */     }
/* 1732 */     if (javaProject == null || !javaProject.exists()) {
/* 1733 */       abort(NLS.bind(LaunchingMessages.JavaRuntime_Launch_configuration__0__references_non_existing_project__1___1, (Object[])new String[] { configuration.getName(), projectName }), 107, null);
/*      */     }
/* 1735 */     return javaProject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IJavaModel getJavaModel() {
/* 1743 */     return JavaCore.create(ResourcesPlugin.getWorkspace().getRoot());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IVMInstall computeVMInstall(ILaunchConfiguration configuration) throws CoreException {
/* 1767 */     String jreAttr = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_JRE_CONTAINER_PATH, null);
/* 1768 */     if (jreAttr == null) {
/* 1769 */       String type = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_VM_INSTALL_TYPE, null);
/* 1770 */       if (type == null) {
/* 1771 */         IJavaProject proj = getJavaProject(configuration);
/* 1772 */         if (proj != null) {
/* 1773 */           IVMInstall vm = getVMInstall(proj);
/* 1774 */           if (vm != null) {
/* 1775 */             return vm;
/*      */           }
/*      */         } 
/*      */       } else {
/* 1779 */         String name = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_VM_INSTALL_NAME, null);
/* 1780 */         return resolveVM(type, name, configuration);
/*      */       } 
/*      */     } else {
/* 1783 */       IPath jrePath = Path.fromPortableString(jreAttr);
/* 1784 */       IClasspathEntry entry = JavaCore.newContainerEntry(jrePath);
/* 1785 */       IRuntimeClasspathEntryResolver2 resolver = getVariableResolver(jrePath.segment(0));
/* 1786 */       if (resolver != null) {
/* 1787 */         return resolver.resolveVMInstall(entry);
/*      */       }
/* 1789 */       resolver = getContainerResolver(jrePath.segment(0));
/* 1790 */       if (resolver != null) {
/* 1791 */         return resolver.resolveVMInstall(entry);
/*      */       }
/*      */     } 
/*      */     
/* 1795 */     return getDefaultVMInstall();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IVMInstall resolveVM(String type, String name, ILaunchConfiguration configuration) throws CoreException {
/* 1808 */     IVMInstallType vt = getVMInstallType(type);
/* 1809 */     if (vt == null)
/*      */     {
/* 1811 */       abort(NLS.bind(LaunchingMessages.JavaRuntime_Specified_VM_install_type_does_not_exist___0__2, (Object[])new String[] { type }), null);
/*      */     }
/* 1813 */     IVMInstall vm = null;
/*      */     
/* 1815 */     if (name == null) {
/*      */ 
/*      */       
/* 1818 */       LaunchingPlugin.log((IStatus)new Status(2, LaunchingPlugin.getUniqueIdentifier(), 103, NLS.bind("VM not fully specified in launch configuration {0} - missing VM name. Reverting to default VM.", (Object[])new String[] { configuration.getName() }), null));
/* 1819 */       return getDefaultVMInstall();
/*      */     } 
/* 1821 */     vm = vt.findVMInstallByName(name);
/* 1822 */     if (vm == null) {
/*      */       
/* 1824 */       abort(NLS.bind(LaunchingMessages.JavaRuntime_Specified_VM_install_not_found__type__0___name__1__2, (Object[])new String[] { vt.getName(), name }), null);
/*      */     } else {
/* 1826 */       return vm;
/*      */     } 
/*      */     
/* 1829 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void abort(String message, Throwable exception) throws CoreException {
/* 1841 */     abort(message, 150, exception);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void abort(String message, int code, Throwable exception) throws CoreException {
/* 1856 */     throw new CoreException(new Status(4, LaunchingPlugin.getUniqueIdentifier(), code, message, exception));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] computeDefaultRuntimeClassPath(IJavaProject jproject) throws CoreException {
/* 1868 */     IRuntimeClasspathEntry[] unresolved = computeUnresolvedRuntimeClasspath(jproject);
/*      */ 
/*      */     
/* 1871 */     List<String> resolved = new ArrayList<>(unresolved.length);
/* 1872 */     for (int i = 0; i < unresolved.length; i++) {
/* 1873 */       IRuntimeClasspathEntry entry = unresolved[i];
/* 1874 */       if (entry.getClasspathProperty() == 3) {
/* 1875 */         IRuntimeClasspathEntry[] entries = resolveRuntimeClasspathEntry(entry, jproject);
/* 1876 */         for (int j = 0; j < entries.length; j++) {
/* 1877 */           String location = entries[j].getLocation();
/* 1878 */           if (location != null) {
/* 1879 */             resolved.add(location);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 1884 */     return resolved.<String>toArray(new String[resolved.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void saveVMConfiguration() throws CoreException {
/* 1899 */     if (fgVMTypes == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1903 */     String xml = getVMsAsXML();
/* 1904 */     InstanceScope.INSTANCE.getNode("org.eclipse.jdt.launching").put(PREF_VM_XML, xml);
/* 1905 */     savePreferences();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getVMsAsXML() throws CoreException {
/* 1914 */     VMDefinitionsContainer container = new VMDefinitionsContainer();
/* 1915 */     container.setDefaultVMInstallCompositeID(getDefaultVMId());
/* 1916 */     container.setDefaultVMInstallConnectorTypeID(getDefaultVMConnectorId());
/* 1917 */     IVMInstallType[] vmTypes = getVMInstallTypes();
/* 1918 */     IVMInstall[] vms = null;
/* 1919 */     for (int i = 0; i < vmTypes.length; i++) {
/* 1920 */       vms = vmTypes[i].getVMInstalls();
/* 1921 */       for (int j = 0; j < vms.length; j++) {
/* 1922 */         container.addVM(vms[j]);
/*      */       }
/*      */     } 
/* 1925 */     return container.getAsXML();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean addPersistedVMs(VMDefinitionsContainer vmDefs) throws IOException {
/* 1941 */     String vmXMLString = InstanceScope.INSTANCE.getNode("org.eclipse.jdt.launching").get(PREF_VM_XML, "");
/*      */ 
/*      */     
/* 1944 */     if (vmXMLString.length() > 0) {
/*      */       try {
/* 1946 */         ByteArrayInputStream inputStream = new ByteArrayInputStream(vmXMLString.getBytes("UTF8"));
/* 1947 */         VMDefinitionsContainer.parseXMLIntoContainer(inputStream, vmDefs);
/* 1948 */         return false;
/* 1949 */       } catch (IOException ioe) {
/* 1950 */         LaunchingPlugin.log(ioe);
/*      */       } 
/*      */     } else {
/*      */       
/* 1954 */       IPath stateLocation = LaunchingPlugin.getDefault().getStateLocation();
/* 1955 */       IPath stateFile = stateLocation.append("vmConfiguration.xml");
/* 1956 */       File file = new File(stateFile.toOSString());
/*      */       
/* 1958 */       if (file.exists()) {
/*      */ 
/*      */         
/* 1961 */         InputStream fileInputStream = new BufferedInputStream(new FileInputStream(file));
/* 1962 */         VMDefinitionsContainer.parseXMLIntoContainer(fileInputStream, vmDefs);
/*      */       } 
/*      */     } 
/* 1965 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void addVMExtensions(VMDefinitionsContainer vmDefs) {
/* 1974 */     IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.jdt.launching", "vmInstalls");
/* 1975 */     IConfigurationElement[] configs = extensionPoint.getConfigurationElements();
/* 1976 */     for (int i = 0; i < configs.length; i++) {
/* 1977 */       IConfigurationElement element = configs[i];
/*      */       try {
/* 1979 */         if ("vmInstall".equals(element.getName())) {
/* 1980 */           String vmType = element.getAttribute("vmInstallType");
/* 1981 */           if (vmType == null) {
/* 1982 */             abort(NLS.bind("Missing required vmInstallType attribute for vmInstall contributed by {0}", 
/* 1983 */                   (Object[])new String[] { element.getContributor().getName() }), null);
/*      */           }
/* 1985 */           String id = element.getAttribute("id");
/* 1986 */           if (id == null) {
/* 1987 */             abort(NLS.bind("Missing required id attribute for vmInstall contributed by {0}", 
/* 1988 */                   (Object[])new String[] { element.getContributor().getName() }), null);
/*      */           }
/* 1990 */           IVMInstallType installType = getVMInstallType(vmType);
/* 1991 */           if (installType == null) {
/* 1992 */             abort(NLS.bind("vmInstall {0} contributed by {1} references undefined VM install type {2}", 
/* 1993 */                   (Object[])new String[] { id, element.getContributor().getName(), vmType }), null);
/*      */           }
/* 1995 */           IVMInstall install = installType.findVMInstall(id);
/* 1996 */           if (install == null) {
/*      */             
/* 1998 */             String name = element.getAttribute("name");
/* 1999 */             if (name == null) {
/* 2000 */               abort(NLS.bind("vmInstall {0} contributed by {1} missing required attribute name", 
/* 2001 */                     (Object[])new String[] { id, element.getContributor().getName() }), null);
/*      */             }
/* 2003 */             String home = element.getAttribute("home");
/* 2004 */             if (home == null) {
/* 2005 */               abort(NLS.bind("vmInstall {0} contributed by {1} missing required attribute home", 
/* 2006 */                     (Object[])new String[] { id, element.getContributor().getName() }), null);
/*      */             }
/* 2008 */             String javadoc = element.getAttribute("javadocURL");
/* 2009 */             String vmArgs = element.getAttribute("vmArgs");
/* 2010 */             VMStandin standin = null;
/* 2011 */             home = substitute(home);
/* 2012 */             File homeDir = new File(home);
/* 2013 */             if (homeDir.exists()) {
/*      */               
/*      */               try {
/* 2016 */                 home = homeDir.getCanonicalPath();
/* 2017 */                 homeDir = new File(home);
/* 2018 */               } catch (IOException iOException) {}
/*      */             }
/*      */             
/* 2021 */             if ("org.eclipse.jdt.launching.EEVMType".equals(installType.getId())) {
/* 2022 */               standin = createVMFromDefinitionFile(homeDir, name, id);
/*      */             } else {
/* 2024 */               standin = new VMStandin(installType, id);
/* 2025 */               standin.setName(name);
/* 2026 */               IStatus status = installType.validateInstallLocation(homeDir);
/* 2027 */               if (!status.isOK()) {
/* 2028 */                 abort(NLS.bind("Illegal install location {0} for vmInstall {1} contributed by {2}: {3}", 
/* 2029 */                       (Object[])new String[] { home, id, element.getContributor().getName(), status.getMessage() }), null);
/*      */               }
/* 2031 */               standin.setInstallLocation(homeDir);
/* 2032 */               if (javadoc != null) {
/*      */                 try {
/* 2034 */                   standin.setJavadocLocation(new URL(javadoc));
/* 2035 */                 } catch (MalformedURLException e) {
/* 2036 */                   abort(NLS.bind("Illegal javadocURL attribute for vmInstall {0} contributed by {1}", 
/* 2037 */                         (Object[])new String[] { id, element.getContributor().getName() }), e);
/*      */                 } 
/*      */               }
/*      */               
/* 2041 */               if (vmArgs == null && 
/* 2042 */                 installType instanceof AbstractVMInstallType) {
/* 2043 */                 AbstractVMInstallType type = (AbstractVMInstallType)installType;
/* 2044 */                 vmArgs = type.getDefaultVMArguments(homeDir);
/*      */               } 
/*      */               
/* 2047 */               if (vmArgs != null) {
/* 2048 */                 standin.setVMArgs(vmArgs);
/*      */               }
/* 2050 */               IConfigurationElement[] libraries = element.getChildren("library");
/* 2051 */               LibraryLocation[] locations = null;
/* 2052 */               if (libraries.length > 0) {
/* 2053 */                 locations = new LibraryLocation[libraries.length];
/* 2054 */                 for (int j = 0; j < libraries.length; j++) {
/* 2055 */                   IPath iPath1; IConfigurationElement library = libraries[j];
/* 2056 */                   String libPathStr = library.getAttribute("path");
/* 2057 */                   if (libPathStr == null) {
/* 2058 */                     abort(NLS.bind("library for vmInstall {0} contributed by {1} missing required attribute libPath", 
/* 2059 */                           (Object[])new String[] { id, element.getContributor().getName() }), null);
/*      */                   }
/* 2061 */                   String sourcePathStr = library.getAttribute("sourcePath");
/* 2062 */                   String packageRootStr = library.getAttribute("packageRootPath");
/* 2063 */                   String javadocOverride = library.getAttribute("javadocURL");
/* 2064 */                   URL url = null;
/* 2065 */                   if (javadocOverride != null) {
/*      */                     try {
/* 2067 */                       url = new URL(javadocOverride);
/* 2068 */                     } catch (MalformedURLException e) {
/* 2069 */                       abort(NLS.bind("Illegal javadocURL attribute specified for library {0} for vmInstall {1} contributed by {2}", 
/* 2070 */                             (Object[])new String[] { libPathStr, id, element.getContributor().getName() }), e);
/*      */                     } 
/*      */                   }
/* 2073 */                   Path path1 = new Path(home);
/* 2074 */                   IPath libPath = path1.append(substitute(libPathStr));
/* 2075 */                   Path path2 = Path.EMPTY;
/* 2076 */                   if (sourcePathStr != null) {
/* 2077 */                     iPath1 = path1.append(substitute(sourcePathStr));
/*      */                   }
/* 2079 */                   Path path3 = Path.EMPTY;
/* 2080 */                   if (packageRootStr != null) {
/* 2081 */                     path3 = new Path(substitute(packageRootStr));
/*      */                   }
/* 2083 */                   locations[j] = new LibraryLocation(libPath, iPath1, (IPath)path3, url);
/*      */                 } 
/*      */               } 
/* 2086 */               standin.setLibraryLocations(locations);
/*      */             } 
/*      */             
/* 2089 */             vmDefs.removeVM(standin);
/* 2090 */             vmDefs.addVM(standin);
/*      */           } 
/* 2092 */           fgContributedVMs.add(id);
/*      */         } else {
/* 2094 */           abort(NLS.bind("Illegal element {0} in vmInstalls extension contributed by {1}", 
/* 2095 */                 (Object[])new String[] { element.getName(), element.getContributor().getName() }), null);
/*      */         } 
/* 2097 */       } catch (CoreException e) {
/* 2098 */         LaunchingPlugin.log((Throwable)e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String substitute(String expression) throws CoreException {
/* 2112 */     return VariablesPlugin.getDefault().getStringVariableManager().performStringSubstitution(expression);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isContributedVMInstall(String id) {
/* 2124 */     getVMInstallTypes();
/* 2125 */     return fgContributedVMs.contains(id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LibraryLocation[] getLibraryLocations(IVMInstall vm) {
/*      */     IPath[] libraryPaths, sourcePaths, sourceRootPaths, annotationPaths;
/*      */     URL[] javadocLocations, indexes;
/* 2142 */     LibraryLocation[] locations = vm.getLibraryLocations();
/* 2143 */     if (locations == null) {
/* 2144 */       URL defJavaDocLocation = vm.getJavadocLocation();
/* 2145 */       File installLocation = vm.getInstallLocation();
/* 2146 */       if (installLocation == null) {
/* 2147 */         return new LibraryLocation[0];
/*      */       }
/* 2149 */       LibraryLocation[] dflts = vm.getVMInstallType().getDefaultLibraryLocations(installLocation);
/* 2150 */       libraryPaths = new IPath[dflts.length];
/* 2151 */       sourcePaths = new IPath[dflts.length];
/* 2152 */       sourceRootPaths = new IPath[dflts.length];
/* 2153 */       javadocLocations = new URL[dflts.length];
/* 2154 */       indexes = new URL[dflts.length];
/* 2155 */       annotationPaths = new IPath[dflts.length];
/* 2156 */       for (int j = 0; j < dflts.length; j++) {
/* 2157 */         libraryPaths[j] = dflts[j].getSystemLibraryPath();
/* 2158 */         if (defJavaDocLocation == null) {
/* 2159 */           javadocLocations[j] = dflts[j].getJavadocLocation();
/*      */         } else {
/* 2161 */           javadocLocations[j] = defJavaDocLocation;
/*      */         } 
/* 2163 */         indexes[j] = dflts[j].getIndexLocation();
/* 2164 */         if (!libraryPaths[j].toFile().isFile()) {
/* 2165 */           libraryPaths[j] = (IPath)Path.EMPTY;
/*      */         }
/*      */         
/* 2168 */         annotationPaths[j] = (IPath)Path.EMPTY;
/*      */         
/* 2170 */         sourcePaths[j] = dflts[j].getSystemLibrarySourcePath();
/* 2171 */         if (sourcePaths[j].toFile().isFile()) {
/* 2172 */           sourceRootPaths[j] = dflts[j].getPackageRootPath();
/*      */         } else {
/* 2174 */           sourcePaths[j] = (IPath)Path.EMPTY;
/* 2175 */           sourceRootPaths[j] = (IPath)Path.EMPTY;
/*      */         } 
/*      */       } 
/*      */     } else {
/* 2179 */       libraryPaths = new IPath[locations.length];
/* 2180 */       sourcePaths = new IPath[locations.length];
/* 2181 */       sourceRootPaths = new IPath[locations.length];
/* 2182 */       javadocLocations = new URL[locations.length];
/* 2183 */       indexes = new URL[locations.length];
/* 2184 */       annotationPaths = new IPath[locations.length];
/* 2185 */       for (int j = 0; j < locations.length; j++) {
/* 2186 */         libraryPaths[j] = locations[j].getSystemLibraryPath();
/* 2187 */         sourcePaths[j] = locations[j].getSystemLibrarySourcePath();
/* 2188 */         sourceRootPaths[j] = locations[j].getPackageRootPath();
/* 2189 */         javadocLocations[j] = locations[j].getJavadocLocation();
/* 2190 */         annotationPaths[j] = locations[j].getExternalAnnotationsPath();
/* 2191 */         indexes[j] = locations[j].getIndexLocation();
/*      */       } 
/*      */     } 
/* 2194 */     locations = new LibraryLocation[sourcePaths.length];
/* 2195 */     for (int i = 0; i < sourcePaths.length; i++) {
/* 2196 */       locations[i] = new LibraryLocation(libraryPaths[i], sourcePaths[i], sourceRootPaths[i], javadocLocations[i], indexes[i], annotationPaths[i]);
/*      */     }
/* 2198 */     return locations;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static VMStandin detectEclipseRuntime() {
/* 2209 */     IVMInstallType[] vmTypes = getVMInstallTypes();
/*      */     int i;
/* 2211 */     for (i = 0; i < vmTypes.length; i++) {
/* 2212 */       if (vmTypes[i] instanceof EEVMType) {
/* 2213 */         String eeFileName = System.getProperty("ee.filename");
/* 2214 */         if (eeFileName != null) {
/* 2215 */           File vmFile = new File(eeFileName);
/* 2216 */           if (vmFile.isDirectory()) {
/* 2217 */             vmFile = new File(vmFile, "default.ee");
/*      */           }
/* 2219 */           if (vmFile.isFile()) {
/*      */             
/* 2221 */             long unique = System.currentTimeMillis();
/* 2222 */             while (vmTypes[i].findVMInstall(String.valueOf(unique)) != null) {
/* 2223 */               unique++;
/*      */             }
/*      */ 
/*      */             
/* 2227 */             String vmID = String.valueOf(unique);
/*      */             try {
/* 2229 */               return createVMFromDefinitionFile(vmFile, "", vmID);
/* 2230 */             } catch (CoreException coreException) {}
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2239 */     for (i = 0; i < vmTypes.length; i++) {
/* 2240 */       File detectedLocation = vmTypes[i].detectInstallLocation();
/* 2241 */       if (detectedLocation != null) {
/*      */ 
/*      */         
/* 2244 */         long unique = System.currentTimeMillis();
/* 2245 */         IVMInstallType vmType = vmTypes[i];
/* 2246 */         while (vmType.findVMInstall(String.valueOf(unique)) != null) {
/* 2247 */           unique++;
/*      */         }
/*      */ 
/*      */         
/* 2251 */         String vmID = String.valueOf(unique);
/* 2252 */         VMStandin detectedVMStandin = new VMStandin(vmType, vmID);
/*      */ 
/*      */         
/* 2255 */         File pluginDir = new File(detectedLocation, "plugins");
/* 2256 */         File featuresDir = new File(detectedLocation, "features");
/* 2257 */         if (pluginDir.exists() && featuresDir.exists() && 
/* 2258 */           isJREVersionAbove8(vmType, detectedLocation)) {
/* 2259 */           detectedLocation = new File(detectedLocation, "jre");
/*      */         }
/*      */         
/* 2262 */         detectedVMStandin.setInstallLocation(detectedLocation);
/* 2263 */         detectedVMStandin.setName(generateDetectedVMName(detectedVMStandin));
/* 2264 */         if (vmType instanceof AbstractVMInstallType) {
/* 2265 */           AbstractVMInstallType abs = (AbstractVMInstallType)vmType;
/* 2266 */           URL url = abs.getDefaultJavadocLocation(detectedLocation);
/* 2267 */           detectedVMStandin.setJavadocLocation(url);
/* 2268 */           String arguments = abs.getDefaultVMArguments(detectedLocation);
/* 2269 */           if (arguments != null) {
/* 2270 */             detectedVMStandin.setVMArgs(arguments);
/*      */           }
/*      */         } 
/* 2273 */         return detectedVMStandin;
/*      */       } 
/*      */     } 
/* 2276 */     return null;
/*      */   }
/*      */   
/*      */   private static boolean isJREVersionAbove8(IVMInstallType vmType, File installLocation) {
/* 2280 */     LibraryLocation[] locations = vmType.getDefaultLibraryLocations(installLocation);
/* 2281 */     boolean exist = true;
/* 2282 */     for (int i = 0; i < locations.length; i++) {
/* 2283 */       exist = (exist && (new File(locations[i].getSystemLibraryPath().toOSString())).exists());
/*      */     }
/* 2285 */     if (exist) {
/* 2286 */       return false;
/*      */     }
/* 2288 */     exist = true;
/* 2289 */     LibraryLocation[] newLocations = vmType.getDefaultLibraryLocations(new File(installLocation, "jre"));
/* 2290 */     for (int j = 0; j < newLocations.length; j++) {
/* 2291 */       exist = (exist && (new File(newLocations[j].getSystemLibraryPath().toOSString())).exists());
/*      */     }
/* 2293 */     return exist;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean equals(String optionName, Map<?, ?> options, Preferences prefStore) {
/* 2314 */     String dummy = new String();
/* 2315 */     String prefValue = prefStore.get(optionName, dummy);
/* 2316 */     if (prefValue != null && prefValue != dummy) {
/* 2317 */       return (options.containsKey(optionName) && 
/* 2318 */         equals(prefValue, options.get(optionName)));
/*      */     }
/* 2320 */     return !options.containsKey(optionName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean equals(Object o1, Object o2) {
/* 2331 */     if (o1 == null) {
/* 2332 */       return (o2 == null);
/*      */     }
/* 2334 */     return o1.equals(o2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String generateDetectedVMName(IVMInstall vm) {
/* 2343 */     String name = vm.getInstallLocation().getName();
/* 2344 */     name = name.trim();
/* 2345 */     if (name.length() == 0) {
/* 2346 */       name = LaunchingMessages.JavaRuntime_25;
/*      */     }
/* 2348 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry getJREVariableEntry() {
/* 2358 */     return JavaCore.newVariableEntry(
/* 2359 */         (IPath)new Path("JRE_LIB"), 
/* 2360 */         (IPath)new Path("JRE_SRC"), 
/* 2361 */         (IPath)new Path("JRE_SRCROOT"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathEntry getDefaultJREContainerEntry() {
/* 2373 */     return JavaCore.newContainerEntry(newDefaultJREContainerPath());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IPath newDefaultJREContainerPath() {
/* 2384 */     return (IPath)new Path(JRE_CONTAINER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IPath newJREContainerPath(IVMInstall vm) {
/* 2396 */     return newJREContainerPath(vm.getVMInstallType().getId(), vm.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IPath newJREContainerPath(String typeId, String name) {
/* 2409 */     IPath path = newDefaultJREContainerPath();
/* 2410 */     path = path.append(typeId);
/* 2411 */     path = path.append(name);
/* 2412 */     return path;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IPath newJREContainerPath(IExecutionEnvironment environment) {
/* 2424 */     IPath path = newDefaultJREContainerPath();
/* 2425 */     path = path.append("org.eclipse.jdt.internal.debug.ui.launcher.StandardVMType");
/* 2426 */     path = path.append(JREContainerInitializer.encodeEnvironmentId(environment.getId()));
/* 2427 */     return path;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IVMInstall getVMInstall(IPath jreContainerPath) {
/* 2440 */     return JREContainerInitializer.resolveVM(jreContainerPath);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getVMInstallTypeId(IPath jreContainerPath) {
/* 2452 */     if (JREContainerInitializer.isExecutionEnvironment(jreContainerPath)) {
/* 2453 */       return null;
/*      */     }
/* 2455 */     return JREContainerInitializer.getVMTypeId(jreContainerPath);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getVMInstallName(IPath jreContainerPath) {
/* 2467 */     if (JREContainerInitializer.isExecutionEnvironment(jreContainerPath)) {
/* 2468 */       return null;
/*      */     }
/* 2470 */     return JREContainerInitializer.getVMName(jreContainerPath);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getExecutionEnvironmentId(IPath jreContainerPath) {
/* 2482 */     return JREContainerInitializer.getExecutionEnvironmentId(jreContainerPath);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry computeJREEntry(ILaunchConfiguration configuration) throws CoreException {
/* 2509 */     String jreAttr = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_JRE_CONTAINER_PATH, null);
/* 2510 */     IPath containerPath = null;
/* 2511 */     if (jreAttr == null) {
/* 2512 */       String type = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_VM_INSTALL_TYPE, null);
/* 2513 */       if (type == null) {
/*      */         
/* 2515 */         IJavaProject proj = getJavaProject(configuration);
/* 2516 */         if (proj == null) {
/* 2517 */           containerPath = newDefaultJREContainerPath();
/*      */         } else {
/* 2519 */           if (isModularConfiguration(configuration)) {
/* 2520 */             return computeModularJREEntry(proj);
/*      */           }
/* 2522 */           return computeJREEntry(proj);
/*      */         } 
/*      */       } else {
/* 2525 */         String name = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_VM_INSTALL_NAME, null);
/* 2526 */         if (name != null) {
/* 2527 */           containerPath = newDefaultJREContainerPath().append(type).append(name);
/*      */         }
/*      */       } 
/*      */     } else {
/* 2531 */       containerPath = Path.fromPortableString(jreAttr);
/*      */     } 
/* 2533 */     if (containerPath != null) {
/* 2534 */       if (isModularConfiguration(configuration)) {
/* 2535 */         return newRuntimeContainerClasspathEntry(containerPath, 4);
/*      */       }
/* 2537 */       return newRuntimeContainerClasspathEntry(containerPath, 1);
/*      */     } 
/* 2539 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry computeJREEntry(IJavaProject project) throws CoreException {
/* 2554 */     IClasspathEntry[] rawClasspath = project.getRawClasspath();
/* 2555 */     IRuntimeClasspathEntryResolver2 resolver = null;
/* 2556 */     for (int i = 0; i < rawClasspath.length; i++) {
/* 2557 */       IClasspathEntry entry = rawClasspath[i];
/* 2558 */       switch (entry.getEntryKind()) {
/*      */         case 4:
/* 2560 */           resolver = getVariableResolver(entry.getPath().segment(0));
/* 2561 */           if (resolver != null && 
/* 2562 */             resolver.isVMInstallReference(entry)) {
/* 2563 */             return newRuntimeClasspathEntry(entry);
/*      */           }
/*      */           break;
/*      */         
/*      */         case 5:
/* 2568 */           resolver = getContainerResolver(entry.getPath().segment(0));
/* 2569 */           if (resolver != null && 
/* 2570 */             resolver.isVMInstallReference(entry)) {
/* 2571 */             IClasspathContainer container = JavaCore.getClasspathContainer(entry.getPath(), project);
/* 2572 */             if (container != null) {
/* 2573 */               switch (container.getKind()) {
/*      */ 
/*      */                 
/*      */                 case 3:
/* 2577 */                   return newRuntimeContainerClasspathEntry(entry.getPath(), 1);
/*      */                 case 2:
/* 2579 */                   return newRuntimeContainerClasspathEntry(entry.getPath(), 2);
/*      */               } 
/*      */             
/*      */             }
/*      */           } 
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/* 2588 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IRuntimeClasspathEntry computeModularJREEntry(IJavaProject project) throws CoreException {
/* 2603 */     IClasspathEntry[] rawClasspath = project.getRawClasspath();
/* 2604 */     IRuntimeClasspathEntryResolver2 resolver = null;
/* 2605 */     for (int i = 0; i < rawClasspath.length; i++) {
/* 2606 */       IClasspathEntry entry = rawClasspath[i];
/* 2607 */       switch (entry.getEntryKind()) {
/*      */         case 4:
/* 2609 */           resolver = getVariableResolver(entry.getPath().segment(0));
/* 2610 */           if (resolver != null && 
/* 2611 */             resolver.isVMInstallReference(entry)) {
/* 2612 */             if (isModularProject(project)) {
/* 2613 */               return newRuntimeClasspathEntry(entry, 4);
/*      */             }
/* 2615 */             return newRuntimeClasspathEntry(entry, 5);
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 5:
/* 2620 */           resolver = getContainerResolver(entry.getPath().segment(0));
/* 2621 */           if (resolver != null && 
/* 2622 */             resolver.isVMInstallReference(entry)) {
/* 2623 */             IClasspathContainer container = JavaCore.getClasspathContainer(entry.getPath(), project);
/* 2624 */             if (container != null) {
/* 2625 */               switch (container.getKind()) {
/*      */ 
/*      */                 
/*      */                 case 3:
/* 2629 */                   if (isModularProject(project)) {
/* 2630 */                     return newRuntimeContainerClasspathEntry(entry.getPath(), 4);
/*      */                   }
/* 2632 */                   return newRuntimeContainerClasspathEntry(entry.getPath(), 5);
/*      */                 case 2:
/* 2634 */                   if (isModularProject(project)) {
/* 2635 */                     return newRuntimeContainerClasspathEntry(entry.getPath(), 4);
/*      */                   }
/* 2637 */                   return newRuntimeContainerClasspathEntry(entry.getPath(), 5);
/*      */               } 
/*      */             
/*      */             }
/*      */           } 
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/* 2646 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isVMInstallReference(IRuntimeClasspathEntry entry) {
/* 2657 */     IClasspathEntry classpathEntry = entry.getClasspathEntry();
/* 2658 */     if (classpathEntry != null) {
/* 2659 */       IRuntimeClasspathEntryResolver2 resolver; switch (classpathEntry.getEntryKind()) {
/*      */         case 4:
/* 2661 */           resolver = getVariableResolver(classpathEntry.getPath().segment(0));
/* 2662 */           if (resolver != null) {
/* 2663 */             return resolver.isVMInstallReference(classpathEntry);
/*      */           }
/*      */           break;
/*      */         case 5:
/* 2667 */           resolver = getContainerResolver(classpathEntry.getPath().segment(0));
/* 2668 */           if (resolver != null) {
/* 2669 */             return resolver.isVMInstallReference(classpathEntry);
/*      */           }
/*      */           break;
/*      */       } 
/*      */     } 
/* 2674 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IVMConnector getVMConnector(String id) {
/* 2686 */     return LaunchingPlugin.getDefault().getVMConnector(id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IVMConnector[] getVMConnectors() {
/* 2696 */     return LaunchingPlugin.getDefault().getVMConnectors();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Preferences getPreferences() {
/* 2706 */     return LaunchingPlugin.getDefault().getPluginPreferences();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void savePreferences() {
/* 2715 */     IEclipsePreferences prefs = InstanceScope.INSTANCE.getNode("org.eclipse.jdt.launching");
/*      */     try {
/* 2717 */       prefs.flush();
/* 2718 */     } catch (BackingStoreException e) {
/* 2719 */       LaunchingPlugin.log((Throwable)e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addVariableResolver(IRuntimeClasspathEntryResolver resolver, String variableName) {
/* 2731 */     Map<String, IRuntimeClasspathEntryResolver> map = getVariableResolvers();
/* 2732 */     map.put(variableName, resolver);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addContainerResolver(IRuntimeClasspathEntryResolver resolver, String containerIdentifier) {
/* 2743 */     Map<String, IRuntimeClasspathEntryResolver> map = getContainerResolvers();
/* 2744 */     map.put(containerIdentifier, resolver);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Map<String, IRuntimeClasspathEntryResolver> getVariableResolvers() {
/* 2752 */     if (fgVariableResolvers == null) {
/* 2753 */       initializeResolvers();
/*      */     }
/* 2755 */     return fgVariableResolvers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Map<String, IRuntimeClasspathEntryResolver> getContainerResolvers() {
/* 2763 */     if (fgContainerResolvers == null) {
/* 2764 */       initializeResolvers();
/*      */     }
/* 2766 */     return fgContainerResolvers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Map<String, RuntimeClasspathEntryResolver> getEntryResolvers() {
/* 2774 */     if (fgRuntimeClasspathEntryResolvers == null) {
/* 2775 */       initializeResolvers();
/*      */     }
/* 2777 */     return fgRuntimeClasspathEntryResolvers;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void initializeResolvers() {
/* 2784 */     IExtensionPoint point = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.jdt.launching", "runtimeClasspathEntryResolvers");
/* 2785 */     IConfigurationElement[] extensions = point.getConfigurationElements();
/* 2786 */     fgVariableResolvers = new HashMap<>(extensions.length);
/* 2787 */     fgContainerResolvers = new HashMap<>(extensions.length);
/* 2788 */     fgRuntimeClasspathEntryResolvers = new HashMap<>(extensions.length);
/* 2789 */     for (int i = 0; i < extensions.length; i++) {
/* 2790 */       RuntimeClasspathEntryResolver res = new RuntimeClasspathEntryResolver(extensions[i]);
/* 2791 */       String variable = res.getVariableName();
/* 2792 */       String container = res.getContainerId();
/* 2793 */       String entryId = res.getRuntimeClasspathEntryId();
/* 2794 */       if (variable != null) {
/* 2795 */         fgVariableResolvers.put(variable, res);
/*      */       }
/* 2797 */       if (container != null) {
/* 2798 */         fgContainerResolvers.put(container, res);
/*      */       }
/* 2800 */       if (entryId != null) {
/* 2801 */         fgRuntimeClasspathEntryResolvers.put(entryId, res);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Map<String, RuntimeClasspathProvider> getClasspathProviders() {
/* 2811 */     if (fgPathProviders == null) {
/* 2812 */       initializeProviders();
/*      */     }
/* 2814 */     return fgPathProviders;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void initializeProviders() {
/* 2821 */     IExtensionPoint point = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.jdt.launching", "classpathProviders");
/* 2822 */     IConfigurationElement[] extensions = point.getConfigurationElements();
/* 2823 */     fgPathProviders = new HashMap<>(extensions.length);
/* 2824 */     for (int i = 0; i < extensions.length; i++) {
/* 2825 */       RuntimeClasspathProvider res = new RuntimeClasspathProvider(extensions[i]);
/* 2826 */       fgPathProviders.put(res.getIdentifier(), res);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IRuntimeClasspathEntryResolver2 getVariableResolver(String variableName) {
/* 2839 */     return (IRuntimeClasspathEntryResolver2)getVariableResolvers().get(variableName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IRuntimeClasspathEntryResolver2 getContainerResolver(String containerId) {
/* 2851 */     return (IRuntimeClasspathEntryResolver2)getContainerResolvers().get(containerId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IRuntimeClasspathEntryResolver getContributedResolver(String typeId) {
/* 2862 */     IRuntimeClasspathEntryResolver resolver = (IRuntimeClasspathEntryResolver)getEntryResolvers().get(typeId);
/* 2863 */     if (resolver == null) {
/* 2864 */       return (IRuntimeClasspathEntryResolver)new DefaultEntryResolver();
/*      */     }
/* 2866 */     return resolver;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addVMInstallChangedListener(IVMInstallChangedListener listener) {
/* 2877 */     fgVMListeners.add(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void removeVMInstallChangedListener(IVMInstallChangedListener listener) {
/* 2888 */     fgVMListeners.remove(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void notifyDefaultVMChanged(IVMInstall previous, IVMInstall current) {
/* 2897 */     for (IVMInstallChangedListener listener : fgVMListeners) {
/* 2898 */       listener.defaultVMInstallChanged(previous, current);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void fireVMChanged(PropertyChangeEvent event) {
/* 2909 */     for (IVMInstallChangedListener listener : fgVMListeners) {
/* 2910 */       listener.vmChanged(event);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void fireVMAdded(IVMInstall vm) {
/* 2921 */     if (!fgInitializingVMs) {
/* 2922 */       for (IVMInstallChangedListener listener : fgVMListeners) {
/* 2923 */         listener.vmAdded(vm);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void fireVMRemoved(IVMInstall vm) {
/* 2935 */     for (IVMInstallChangedListener listener : fgVMListeners) {
/* 2936 */       listener.vmRemoved(vm);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getProjectOutputDirectory(ILaunchConfiguration config) {
/*      */     try {
/* 2952 */       if (config != null) {
/* 2953 */         IJavaProject javaProject = getJavaProject(config);
/* 2954 */         if (javaProject != null) {
/* 2955 */           IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
/* 2956 */           IPath outputLocation = javaProject.getOutputLocation();
/* 2957 */           IResource resource = root.findMember(outputLocation);
/* 2958 */           if (resource != null) {
/* 2959 */             IPath path = resource.getFullPath();
/* 2960 */             if (path != null) {
/* 2961 */               return path.makeRelative().toString();
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/* 2966 */     } catch (CoreException coreException) {}
/*      */     
/* 2968 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ISourceContainer[] getSourceContainers(IRuntimeClasspathEntry[] entries) {
/* 2983 */     return JavaSourceLookupUtil.translate(entries);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] computeJavaLibraryPath(IJavaProject project, boolean requiredProjects) throws CoreException {
/* 3002 */     Set<IJavaProject> visited = new HashSet<>();
/* 3003 */     List<String> entries = new ArrayList<>();
/* 3004 */     gatherJavaLibraryPathEntries(project, requiredProjects, visited, entries);
/* 3005 */     List<String> resolved = new ArrayList<>(entries.size());
/* 3006 */     Iterator<String> iterator = entries.iterator();
/* 3007 */     IStringVariableManager manager = VariablesPlugin.getDefault().getStringVariableManager();
/* 3008 */     IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
/* 3009 */     while (iterator.hasNext()) {
/* 3010 */       String entry = iterator.next();
/* 3011 */       String resolvedEntry = manager.performStringSubstitution(entry);
/* 3012 */       Path path = new Path(resolvedEntry);
/* 3013 */       if (path.isAbsolute()) {
/* 3014 */         File file = path.toFile();
/* 3015 */         resolved.add(file.getAbsolutePath()); continue;
/*      */       } 
/* 3017 */       IResource resource = root.findMember((IPath)path);
/* 3018 */       if (resource != null) {
/* 3019 */         IPath location = resource.getLocation();
/* 3020 */         if (location != null) {
/* 3021 */           resolved.add(location.toFile().getAbsolutePath());
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 3026 */     return resolved.<String>toArray(new String[resolved.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void gatherJavaLibraryPathEntries(IJavaProject project, boolean requiredProjects, Set<IJavaProject> visited, List<String> entries) throws CoreException {
/* 3041 */     if (visited.contains(project)) {
/*      */       return;
/*      */     }
/* 3044 */     visited.add(project);
/* 3045 */     IClasspathEntry[] rawClasspath = project.getRawClasspath();
/* 3046 */     IClasspathEntry[] required = processJavaLibraryPathEntries(project, requiredProjects, rawClasspath, entries);
/* 3047 */     if (required != null) {
/* 3048 */       IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
/* 3049 */       for (int i = 0; i < required.length; i++) {
/* 3050 */         IClasspathEntry entry = required[i];
/* 3051 */         String projectName = entry.getPath().segment(0);
/* 3052 */         IProject p = root.getProject(projectName);
/* 3053 */         if (p.exists()) {
/* 3054 */           IJavaProject requiredProject = JavaCore.create(p);
/* 3055 */           if (requiredProject.isOpen()) {
/* 3056 */             gatherJavaLibraryPathEntries(requiredProject, requiredProjects, visited, entries);
/*      */           }
/* 3058 */           else if (!isOptional(entry)) {
/* 3059 */             gatherJavaLibraryPathEntries(requiredProject, requiredProjects, visited, entries);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static IClasspathEntry[] processJavaLibraryPathEntries(IJavaProject project, boolean collectRequired, IClasspathEntry[] classpathEntries, List<String> entries) throws CoreException {
/* 3080 */     List<IClasspathEntry> req = null;
/* 3081 */     for (int i = 0; i < classpathEntries.length; i++) {
/* 3082 */       IClasspathEntry entry = classpathEntries[i];
/* 3083 */       IClasspathAttribute[] extraAttributes = entry.getExtraAttributes();
/* 3084 */       for (int j = 0; j < extraAttributes.length; j++) {
/* 3085 */         String[] paths = getLibraryPaths(extraAttributes[j]);
/* 3086 */         if (paths != null) {
/* 3087 */           for (int k = 0; k < paths.length; k++) {
/* 3088 */             entries.add(paths[k]);
/*      */           }
/*      */         }
/*      */       } 
/* 3092 */       if (entry.getEntryKind() == 5) {
/* 3093 */         IClasspathContainer container = JavaCore.getClasspathContainer(entry.getPath(), project);
/* 3094 */         if (container != null) {
/* 3095 */           IClasspathEntry[] requiredProjects = processJavaLibraryPathEntries(project, collectRequired, container.getClasspathEntries(), entries);
/* 3096 */           if (requiredProjects != null) {
/* 3097 */             if (req == null) {
/* 3098 */               req = new ArrayList<>();
/*      */             }
/* 3100 */             for (int k = 0; k < requiredProjects.length; k++) {
/* 3101 */               req.add(requiredProjects[k]);
/*      */             }
/*      */           } 
/*      */         } 
/* 3105 */       } else if (collectRequired && entry.getEntryKind() == 2) {
/* 3106 */         if (req == null) {
/* 3107 */           req = new ArrayList<>();
/*      */         }
/* 3109 */         req.add(entry);
/*      */       } 
/*      */     } 
/* 3112 */     if (req != null) {
/* 3113 */       return req.<IClasspathEntry>toArray(new IClasspathEntry[req.size()]);
/*      */     }
/* 3115 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IClasspathAttribute newLibraryPathsAttribute(String[] paths) {
/* 3137 */     return JavaCore.newClasspathAttribute(CLASSPATH_ATTR_LIBRARY_PATH_ENTRY, String.join("|", (CharSequence[])paths));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] getLibraryPaths(IClasspathAttribute attribute) {
/* 3162 */     if (CLASSPATH_ATTR_LIBRARY_PATH_ENTRY.equals(attribute.getName())) {
/* 3163 */       String value = attribute.getValue();
/* 3164 */       return value.split("\\|");
/*      */     } 
/* 3166 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static IExecutionEnvironmentsManager getExecutionEnvironmentsManager() {
/* 3176 */     return (IExecutionEnvironmentsManager)EnvironmentsManager.getDefault();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void initializeVMs() {
/* 3186 */     VMDefinitionsContainer vmDefs = null;
/* 3187 */     boolean setPref = false;
/* 3188 */     boolean updateCompliance = false;
/* 3189 */     synchronized (fgVMLock) {
/* 3190 */       if (fgVMTypes == null) {
/*      */         try {
/* 3192 */           fgInitializingVMs = true;
/*      */           
/* 3194 */           initializeVMTypeExtensions();
/*      */           try {
/* 3196 */             vmDefs = new VMDefinitionsContainer();
/*      */             
/* 3198 */             setPref = addPersistedVMs(vmDefs);
/* 3199 */             IStatus status = vmDefs.getStatus();
/* 3200 */             if (status != null) {
/* 3201 */               if (status.isMultiStatus()) {
/* 3202 */                 MultiStatus multi = (MultiStatus)status;
/* 3203 */                 IStatus[] children = multi.getChildren();
/* 3204 */                 for (int i = 0; i < children.length; i++) {
/* 3205 */                   IStatus child = children[i];
/* 3206 */                   if (!child.isOK()) {
/* 3207 */                     LaunchingPlugin.log(child);
/*      */                   }
/*      */                 } 
/* 3210 */               } else if (!status.isOK()) {
/* 3211 */                 LaunchingPlugin.log(status);
/*      */               } 
/*      */             }
/*      */ 
/*      */             
/* 3216 */             if (vmDefs.getValidVMList().isEmpty()) {
/*      */ 
/*      */               
/* 3219 */               VMListener listener = new VMListener();
/* 3220 */               addVMInstallChangedListener((IVMInstallChangedListener)listener);
/* 3221 */               setPref = true;
/* 3222 */               VMStandin runtime = detectEclipseRuntime();
/* 3223 */               removeVMInstallChangedListener((IVMInstallChangedListener)listener);
/* 3224 */               if (!listener.isChanged()) {
/* 3225 */                 if (runtime != null) {
/* 3226 */                   updateCompliance = true;
/* 3227 */                   vmDefs.addVM(runtime);
/* 3228 */                   vmDefs.setDefaultVMInstallCompositeID(getCompositeIdFromVM(runtime));
/*      */                 } 
/*      */               } else {
/*      */                 
/* 3232 */                 addPersistedVMs(vmDefs);
/* 3233 */                 vmDefs.setDefaultVMInstallCompositeID(fgDefaultVMId);
/* 3234 */                 updateCompliance = (fgDefaultVMId != null);
/*      */               } 
/*      */             } 
/*      */             
/* 3238 */             addVMExtensions(vmDefs);
/*      */             
/* 3240 */             String defId = vmDefs.getDefaultVMInstallCompositeID();
/* 3241 */             boolean validDef = false;
/* 3242 */             if (defId != null) {
/* 3243 */               Iterator<IVMInstall> iterator = vmDefs.getValidVMList().iterator();
/* 3244 */               while (iterator.hasNext()) {
/* 3245 */                 IVMInstall vm = iterator.next();
/* 3246 */                 if (getCompositeIdFromVM(vm).equals(defId)) {
/* 3247 */                   validDef = true;
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */             } 
/* 3252 */             if (!validDef) {
/*      */               
/* 3254 */               setPref = true;
/* 3255 */               List<IVMInstall> list = vmDefs.getValidVMList();
/* 3256 */               if (!list.isEmpty()) {
/* 3257 */                 IVMInstall vm = list.get(0);
/* 3258 */                 vmDefs.setDefaultVMInstallCompositeID(getCompositeIdFromVM(vm));
/*      */               } 
/*      */             } 
/* 3261 */             fgDefaultVMId = vmDefs.getDefaultVMInstallCompositeID();
/* 3262 */             fgDefaultVMConnectorId = vmDefs.getDefaultVMInstallConnectorTypeID();
/*      */ 
/*      */             
/* 3265 */             List<IVMInstall> vmList = vmDefs.getValidVMList();
/* 3266 */             Iterator<IVMInstall> vmListIterator = vmList.iterator();
/* 3267 */             while (vmListIterator.hasNext()) {
/* 3268 */               VMStandin vmStandin = (VMStandin)vmListIterator.next();
/* 3269 */               vmStandin.convertToRealVM();
/*      */             }
/*      */           
/*      */           }
/* 3273 */           catch (IOException e) {
/* 3274 */             LaunchingPlugin.log(e);
/*      */           } 
/*      */         } finally {
/* 3277 */           fgInitializingVMs = false;
/*      */         } 
/*      */       }
/*      */     } 
/* 3281 */     if (vmDefs != null) {
/*      */       
/* 3283 */       IVMInstallType[] installTypes = getVMInstallTypes();
/* 3284 */       for (int i = 0; i < installTypes.length; i++) {
/* 3285 */         IVMInstallType type = installTypes[i];
/* 3286 */         IVMInstall[] installs = type.getVMInstalls();
/* 3287 */         for (int j = 0; j < installs.length; j++) {
/* 3288 */           fireVMAdded(installs[j]);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 3293 */       if (setPref) {
/*      */         try {
/* 3295 */           String xml = vmDefs.getAsXML();
/* 3296 */           InstanceScope.INSTANCE.getNode("org.eclipse.jdt.launching").put(PREF_VM_XML, xml);
/* 3297 */         } catch (CoreException e) {
/* 3298 */           LaunchingPlugin.log((Throwable)e);
/*      */         } 
/*      */       }
/*      */       
/* 3302 */       if (updateCompliance) {
/* 3303 */         updateCompliance(getDefaultVMInstall());
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void updateCompliance(IVMInstall vm) {
/* 3314 */     if (LaunchingPlugin.isVMLogging()) {
/* 3315 */       LaunchingPlugin.log("Compliance needs an update.");
/*      */     }
/* 3317 */     if (vm instanceof IVMInstall2) {
/* 3318 */       String javaVersion = ((IVMInstall2)vm).getJavaVersion();
/* 3319 */       if (javaVersion != null) {
/* 3320 */         String compliance = null;
/* 3321 */         if (javaVersion.startsWith("1.5")) {
/* 3322 */           compliance = "1.5";
/* 3323 */         } else if (javaVersion.startsWith("1.6")) {
/* 3324 */           compliance = "1.6";
/* 3325 */         } else if (javaVersion.startsWith("1.7")) {
/* 3326 */           compliance = "1.7";
/* 3327 */         } else if (javaVersion.startsWith("1.8")) {
/* 3328 */           compliance = "1.8";
/* 3329 */         } else if (javaVersion.startsWith("9") && (
/* 3330 */           javaVersion.length() == "9".length() || javaVersion.charAt("9".length()) == '.')) {
/* 3331 */           compliance = "9";
/* 3332 */         } else if (javaVersion.startsWith("10") && (
/* 3333 */           javaVersion.length() == "10".length() || javaVersion.charAt("10".length()) == '.')) {
/* 3334 */           compliance = "10";
/* 3335 */         } else if (javaVersion.startsWith("11") && (
/* 3336 */           javaVersion.length() == "11".length() || javaVersion.charAt("11".length()) == '.')) {
/* 3337 */           compliance = "11";
/* 3338 */         } else if (javaVersion.startsWith("12") && (
/* 3339 */           javaVersion.length() == "12".length() || javaVersion.charAt("12".length()) == '.')) {
/* 3340 */           compliance = "12";
/* 3341 */         } else if (javaVersion.startsWith("13") && (
/* 3342 */           javaVersion.length() == "13".length() || javaVersion.charAt("13".length()) == '.')) {
/* 3343 */           compliance = "13";
/* 3344 */         } else if (javaVersion.startsWith("14") && (
/* 3345 */           javaVersion.length() == "14".length() || javaVersion.charAt("14".length()) == '.')) {
/* 3346 */           compliance = "14";
/* 3347 */         } else if (javaVersion.startsWith("15") && (
/* 3348 */           javaVersion.length() == "15".length() || javaVersion.charAt("15".length()) == '.')) {
/* 3349 */           compliance = "15";
/* 3350 */         } else if (javaVersion.startsWith("16") && (
/* 3351 */           javaVersion.length() == "16".length() || javaVersion.charAt("16".length()) == '.')) {
/* 3352 */           compliance = "16";
/* 3353 */         } else if (javaVersion.startsWith("17") && (
/* 3354 */           javaVersion.length() == "17".length() || javaVersion.charAt("17".length()) == '.')) {
/* 3355 */           compliance = "17";
/* 3356 */         } else if (javaVersion.startsWith("18") && (
/* 3357 */           javaVersion.length() == "18".length() || javaVersion.charAt("18".length()) == '.')) {
/* 3358 */           compliance = "18";
/* 3359 */         } else if (javaVersion.startsWith("19") && (
/* 3360 */           javaVersion.length() == "19".length() || javaVersion.charAt("19".length()) == '.')) {
/* 3361 */           compliance = "19";
/* 3362 */         } else if (javaVersion.startsWith("20") && (
/* 3363 */           javaVersion.length() == "20".length() || javaVersion.charAt("20".length()) == '.')) {
/* 3364 */           compliance = "20";
/*      */         } else {
/* 3366 */           compliance = "20";
/*      */         } 
/*      */         
/* 3369 */         Hashtable<String, String> options = JavaCore.getOptions();
/*      */         
/* 3371 */         IEclipsePreferences iEclipsePreferences = BundleDefaultsScope.INSTANCE.getNode("org.eclipse.jdt.core");
/*      */         
/* 3373 */         boolean isDefault = 
/* 3374 */           (equals("org.eclipse.jdt.core.compiler.compliance", options, (Preferences)iEclipsePreferences) && 
/* 3375 */           equals("org.eclipse.jdt.core.compiler.source", options, (Preferences)iEclipsePreferences) && 
/* 3376 */           equals("org.eclipse.jdt.core.compiler.codegen.targetPlatform", options, (Preferences)iEclipsePreferences) && 
/* 3377 */           equals("org.eclipse.jdt.core.compiler.problem.assertIdentifier", options, (Preferences)iEclipsePreferences) && 
/* 3378 */           equals("org.eclipse.jdt.core.compiler.problem.enumIdentifier", options, (Preferences)iEclipsePreferences));
/* 3379 */         if (JavaCore.compareJavaVersions(compliance, "10") > 0) {
/* 3380 */           isDefault = (isDefault && equals("org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures", options, (Preferences)iEclipsePreferences) && 
/* 3381 */             equals("org.eclipse.jdt.core.compiler.problem.reportPreviewFeatures", options, (Preferences)iEclipsePreferences));
/*      */         }
/*      */ 
/*      */         
/* 3385 */         if (LaunchingPlugin.isVMLogging()) {
/* 3386 */           LaunchingPlugin.log("Compliance to be updated is: " + compliance);
/*      */         }
/* 3388 */         if (isDefault) {
/* 3389 */           JavaCore.setComplianceOptions(compliance, options);
/* 3390 */           JavaCore.setOptions(options);
/* 3391 */           if (LaunchingPlugin.isVMLogging()) {
/* 3392 */             LaunchingPlugin.log("Compliance Options are updated.");
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static VMStandin createVMFromDefinitionFile(File eeFile, String name, String id) throws CoreException {
/* 3413 */     ExecutionEnvironmentDescription description = new ExecutionEnvironmentDescription(eeFile);
/* 3414 */     IStatus status = EEVMType.validateDefinitionFile(description);
/* 3415 */     if (status.isOK()) {
/* 3416 */       VMStandin standin = new VMStandin(getVMInstallType("org.eclipse.jdt.launching.EEVMType"), id);
/* 3417 */       if (name != null && name.length() > 0) {
/* 3418 */         standin.setName(name);
/*      */       } else {
/* 3420 */         name = description.getProperty("-Dee.name");
/* 3421 */         if (name == null) {
/* 3422 */           name = eeFile.getName();
/*      */         }
/* 3424 */         standin.setName(name);
/*      */       } 
/* 3426 */       String home = description.getProperty("-Djava.home");
/* 3427 */       standin.setInstallLocation(new File(home));
/* 3428 */       standin.setLibraryLocations(description.getLibraryLocations());
/* 3429 */       standin.setVMArgs(description.getVMArguments());
/* 3430 */       standin.setJavadocLocation(EEVMType.getJavadocLocation(description.getProperties()));
/* 3431 */       standin.setAttribute("ATTR_EXECUTION_ENVIRONMENT_ID", description.getProperty("-Dee.class.library.level"));
/* 3432 */       File exe = description.getExecutable();
/* 3433 */       if (exe == null) {
/* 3434 */         exe = description.getConsoleExecutable();
/*      */       }
/* 3436 */       if (exe != null) {
/*      */         try {
/* 3438 */           standin.setAttribute("ATTR_JAVA_EXE", exe.getCanonicalPath());
/* 3439 */         } catch (IOException e) {
/* 3440 */           throw new CoreException(new Status(4, LaunchingPlugin.getUniqueIdentifier(), 
/* 3441 */                 LaunchingMessages.JavaRuntime_24, e));
/*      */         } 
/*      */       }
/* 3444 */       standin.setAttribute("ATTR_JAVA_VERSION", description.getProperty("-Dee.language.level"));
/* 3445 */       standin.setAttribute("ATTR_DEFINITION_FILE", eeFile.getPath());
/* 3446 */       standin.setAttribute("ATTR_DEBUG_ARGS", description.getProperty("-Dee.debug.args"));
/* 3447 */       return standin;
/*      */     } 
/* 3449 */     throw new CoreException(status);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getModuleCLIOptions(ILaunchConfiguration configuration) {
/* 3473 */     StringBuilder cliOptionString = new StringBuilder();
/*      */     
/*      */     try {
/* 3476 */       IRuntimeClasspathEntry[] entries = computeUnresolvedRuntimeClasspath(configuration);
/*      */       
/* 3478 */       IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot(); byte b; int i; IRuntimeClasspathEntry[] arrayOfIRuntimeClasspathEntry1;
/* 3479 */       for (i = (arrayOfIRuntimeClasspathEntry1 = entries).length, b = 0; b < i; ) { IRuntimeClasspathEntry iRuntimeClasspathEntry = arrayOfIRuntimeClasspathEntry1[b];
/* 3480 */         IClasspathEntry classpathEntry = iRuntimeClasspathEntry.getClasspathEntry();
/* 3481 */         if (classpathEntry != null && classpathEntry.getEntryKind() == 2) {
/* 3482 */           IResource res = root.findMember(classpathEntry.getPath());
/* 3483 */           IJavaProject jp = (IJavaProject)JavaCore.create(res);
/* 3484 */           if (jp.isOpen()) {
/* 3485 */             IClasspathEntry[] rawClasspath = jp.getRawClasspath(); byte b1; int j; IClasspathEntry[] arrayOfIClasspathEntry1;
/* 3486 */             for (j = (arrayOfIClasspathEntry1 = rawClasspath).length, b1 = 0; b1 < j; ) { IClasspathEntry iClasspathEntry = arrayOfIClasspathEntry1[b1];
/* 3487 */               if (iClasspathEntry.getEntryKind() == 5 && 
/* 3488 */                 JRE_CONTAINER.equals(iClasspathEntry.getPath().segment(0))) {
/* 3489 */                 String cliOptions = getModuleCLIOptions(jp, iClasspathEntry);
/* 3490 */                 if (cliOptionString.length() > 0 && cliOptions.length() > 0) {
/* 3491 */                   cliOptionString.append(" ");
/*      */                 }
/* 3493 */                 cliOptionString.append(cliOptions);
/*      */               } 
/*      */               
/*      */               b1++; }
/*      */           
/*      */           } 
/*      */         } 
/*      */         b++; }
/*      */     
/* 3502 */     } catch (CoreException e) {
/* 3503 */       LaunchingPlugin.log((Throwable)e);
/*      */     } 
/* 3505 */     return cliOptionString.toString().trim();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getModuleCLIOptions(IJavaProject project, IClasspathEntry systemLibrary) throws JavaModelException {
/*      */     // Byte code:
/*      */     //   0: new java/lang/StringBuilder
/*      */     //   3: dup
/*      */     //   4: invokespecial <init> : ()V
/*      */     //   7: astore_2
/*      */     //   8: aload_0
/*      */     //   9: invokeinterface getRawClasspath : ()[Lorg/eclipse/jdt/core/IClasspathEntry;
/*      */     //   14: dup
/*      */     //   15: astore #6
/*      */     //   17: arraylength
/*      */     //   18: istore #5
/*      */     //   20: iconst_0
/*      */     //   21: istore #4
/*      */     //   23: goto -> 319
/*      */     //   26: aload #6
/*      */     //   28: iload #4
/*      */     //   30: aaload
/*      */     //   31: astore_3
/*      */     //   32: aload_3
/*      */     //   33: invokeinterface getExtraAttributes : ()[Lorg/eclipse/jdt/core/IClasspathAttribute;
/*      */     //   38: dup
/*      */     //   39: astore #10
/*      */     //   41: arraylength
/*      */     //   42: istore #9
/*      */     //   44: iconst_0
/*      */     //   45: istore #8
/*      */     //   47: goto -> 309
/*      */     //   50: aload #10
/*      */     //   52: iload #8
/*      */     //   54: aaload
/*      */     //   55: astore #7
/*      */     //   57: aload #7
/*      */     //   59: invokeinterface getName : ()Ljava/lang/String;
/*      */     //   64: astore #11
/*      */     //   66: aload #11
/*      */     //   68: dup
/*      */     //   69: astore #12
/*      */     //   71: invokevirtual hashCode : ()I
/*      */     //   74: lookupswitch default -> 306, -1230926317 -> 116, -1091734723 -> 130, -1089296015 -> 144, 425945973 -> 158
/*      */     //   116: aload #12
/*      */     //   118: ldc_w 'add-exports'
/*      */     //   121: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   124: ifne -> 172
/*      */     //   127: goto -> 306
/*      */     //   130: aload #12
/*      */     //   132: ldc_w 'add-opens'
/*      */     //   135: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   138: ifne -> 172
/*      */     //   141: goto -> 306
/*      */     //   144: aload #12
/*      */     //   146: ldc_w 'add-reads'
/*      */     //   149: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   152: ifne -> 172
/*      */     //   155: goto -> 306
/*      */     //   158: aload #12
/*      */     //   160: ldc_w 'limit-modules'
/*      */     //   163: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */     //   166: ifne -> 293
/*      */     //   169: goto -> 306
/*      */     //   172: aload #7
/*      */     //   174: invokeinterface getValue : ()Ljava/lang/String;
/*      */     //   179: astore #13
/*      */     //   181: aload #13
/*      */     //   183: bipush #61
/*      */     //   185: invokevirtual indexOf : (I)I
/*      */     //   188: istore #14
/*      */     //   190: iload #14
/*      */     //   192: iconst_m1
/*      */     //   193: if_icmpeq -> 263
/*      */     //   196: aload #13
/*      */     //   198: ldc_w ':'
/*      */     //   201: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
/*      */     //   204: dup
/*      */     //   205: astore #18
/*      */     //   207: arraylength
/*      */     //   208: istore #17
/*      */     //   210: iconst_0
/*      */     //   211: istore #16
/*      */     //   213: goto -> 253
/*      */     //   216: aload #18
/*      */     //   218: iload #16
/*      */     //   220: aaload
/*      */     //   221: astore #15
/*      */     //   223: aload_2
/*      */     //   224: ldc '--'
/*      */     //   226: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   229: aload #11
/*      */     //   231: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   234: ldc ' '
/*      */     //   236: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   239: aload #15
/*      */     //   241: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   244: ldc ' '
/*      */     //   246: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   249: pop
/*      */     //   250: iinc #16, 1
/*      */     //   253: iload #16
/*      */     //   255: iload #17
/*      */     //   257: if_icmplt -> 216
/*      */     //   260: goto -> 306
/*      */     //   263: aload_2
/*      */     //   264: ldc '--'
/*      */     //   266: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   269: aload #11
/*      */     //   271: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   274: ldc ' '
/*      */     //   276: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   279: aload #13
/*      */     //   281: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   284: ldc ' '
/*      */     //   286: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   289: pop
/*      */     //   290: goto -> 306
/*      */     //   293: aload_2
/*      */     //   294: aload_0
/*      */     //   295: aload_1
/*      */     //   296: aload #7
/*      */     //   298: invokeinterface getValue : ()Ljava/lang/String;
/*      */     //   303: invokestatic addLimitModules : (Ljava/lang/StringBuilder;Lorg/eclipse/jdt/core/IJavaProject;Lorg/eclipse/jdt/core/IClasspathEntry;Ljava/lang/String;)V
/*      */     //   306: iinc #8, 1
/*      */     //   309: iload #8
/*      */     //   311: iload #9
/*      */     //   313: if_icmplt -> 50
/*      */     //   316: iinc #4, 1
/*      */     //   319: iload #4
/*      */     //   321: iload #5
/*      */     //   323: if_icmplt -> 26
/*      */     //   326: aload_2
/*      */     //   327: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   330: invokevirtual trim : ()Ljava/lang/String;
/*      */     //   333: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #3531	-> 0
/*      */     //   #3532	-> 8
/*      */     //   #3533	-> 32
/*      */     //   #3534	-> 57
/*      */     //   #3535	-> 66
/*      */     //   #3539	-> 172
/*      */     //   #3540	-> 181
/*      */     //   #3541	-> 190
/*      */     //   #3542	-> 196
/*      */     //   #3543	-> 223
/*      */     //   #3542	-> 250
/*      */     //   #3545	-> 260
/*      */     //   #3546	-> 263
/*      */     //   #3548	-> 290
/*      */     //   #3553	-> 293
/*      */     //   #3533	-> 306
/*      */     //   #3532	-> 316
/*      */     //   #3558	-> 326
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   0	334	0	project	Lorg/eclipse/jdt/core/IJavaProject;
/*      */     //   0	334	1	systemLibrary	Lorg/eclipse/jdt/core/IClasspathEntry;
/*      */     //   8	326	2	buf	Ljava/lang/StringBuilder;
/*      */     //   32	284	3	classpathEntry	Lorg/eclipse/jdt/core/IClasspathEntry;
/*      */     //   57	249	7	classpathAttribute	Lorg/eclipse/jdt/core/IClasspathAttribute;
/*      */     //   66	240	11	optName	Ljava/lang/String;
/*      */     //   181	112	13	readModules	Ljava/lang/String;
/*      */     //   190	103	14	equalsIdx	I
/*      */     //   223	27	15	readModule	Ljava/lang/String;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void addLimitModules(StringBuilder buf, IJavaProject prj, IClasspathEntry systemLibrary, String value) throws JavaModelException {
/* 3561 */     String[] modules = value.split(",");
/* 3562 */     boolean isUnnamed = (prj.getModuleDescription() == null);
/* 3563 */     if (isUnnamed) {
/* 3564 */       Set<String> selected = new HashSet<>(Arrays.asList(modules));
/* 3565 */       List<IPackageFragmentRoot> allSystemRoots = Arrays.asList(prj.findUnfilteredPackageFragmentRoots(systemLibrary));
/* 3566 */       Set<String> defaultModules = getDefaultModules(allSystemRoots);
/* 3567 */       Set<String> limit = new HashSet<>(defaultModules);
/*      */ 
/*      */       
/* 3570 */       Map<String, IModuleDescription> allModules = (Map<String, IModuleDescription>)allSystemRoots.stream()
/* 3571 */         .map(r -> r.getModuleDescription())
/* 3572 */         .filter(Objects::nonNull)
/* 3573 */         .collect(Collectors.toMap(IJavaElement::getElementName, module -> module));
/* 3574 */       Set<String> selectedClosure = closure(selected, new HashSet<>(), allModules);
/*      */       
/* 3576 */       if (limit.retainAll(selectedClosure)) {
/* 3577 */         if (limit.isEmpty()) {
/* 3578 */           throw new IllegalArgumentException("Cannot hide all modules, at least java.base is required");
/*      */         }
/* 3580 */         buf.append("--limit-modules ").append(joinedSortedList(reduceNames(limit, allModules.values()))).append(" ");
/*      */       } 
/*      */       
/* 3583 */       selectedClosure.removeAll(defaultModules);
/* 3584 */       if (!selectedClosure.isEmpty()) {
/* 3585 */         buf.append("--add-modules ").append(joinedSortedList(selectedClosure)).append(" ");
/*      */       }
/*      */     } else {
/* 3588 */       Arrays.sort((Object[])modules);
/* 3589 */       buf.append("--limit-modules ").append(String.join(",", (CharSequence[])modules)).append(" ");
/*      */     } 
/*      */   }
/*      */   
/*      */   private static Set<String> closure(Collection<String> moduleNames, Set<String> collected, Map<String, IModuleDescription> allModules) {
/* 3594 */     for (String name : moduleNames) {
/* 3595 */       if (collected.add(name)) {
/* 3596 */         IModuleDescription module = allModules.get(name);
/* 3597 */         if (module != null) {
/*      */           try {
/* 3599 */             closure(Arrays.asList(module.getRequiredModuleNames()), collected, allModules);
/* 3600 */           } catch (JavaModelException e) {
/* 3601 */             LaunchingPlugin.log((Throwable)e);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/* 3606 */     return collected;
/*      */   }
/*      */ 
/*      */   
/*      */   private static Collection<String> reduceNames(Collection<String> names, Collection<IModuleDescription> allModules) {
/* 3611 */     Map<String, List<String>> moduleRequiredByModules = new HashMap<>();
/* 3612 */     for (IModuleDescription module : allModules) {
/* 3613 */       if (!names.contains(module.getElementName()))
/*      */         continue;  try {
/*      */         byte b; int i;
/*      */         String[] arrayOfString;
/* 3617 */         for (i = (arrayOfString = module.getRequiredModuleNames()).length, b = 0; b < i; ) { String required = arrayOfString[b];
/* 3618 */           List<String> dominators = moduleRequiredByModules.get(required);
/* 3619 */           if (dominators == null) {
/* 3620 */             moduleRequiredByModules.put(required, dominators = new ArrayList<>());
/*      */           }
/* 3622 */           dominators.add(module.getElementName()); b++; }
/*      */       
/* 3624 */       } catch (CoreException e) {
/* 3625 */         LaunchingPlugin.log((Throwable)e);
/* 3626 */         return names;
/*      */       } 
/*      */     } 
/*      */     
/* 3630 */     List<String> reduced = new ArrayList<>();
/* 3631 */     label34: for (String name : names) {
/* 3632 */       List<String> dominators = moduleRequiredByModules.get(name);
/* 3633 */       if (dominators != null) {
/* 3634 */         for (String dominator : dominators) {
/* 3635 */           if (names.contains(dominator)) {
/*      */             continue label34;
/*      */           }
/*      */         } 
/*      */       }
/* 3640 */       reduced.add(name);
/*      */     } 
/* 3642 */     return reduced;
/*      */   }
/*      */   
/*      */   private static Set<String> getDefaultModules(List<IPackageFragmentRoot> allSystemRoots) throws JavaModelException {
/* 3646 */     HashMap<String, String[]> moduleDescriptions = (HashMap)new HashMap<>();
/* 3647 */     for (IPackageFragmentRoot packageFragmentRoot : allSystemRoots) {
/* 3648 */       IModuleDescription module = packageFragmentRoot.getModuleDescription();
/* 3649 */       if (module != null) {
/* 3650 */         moduleDescriptions.put(module.getElementName(), module.getRequiredModuleNames());
/*      */       }
/*      */     } 
/* 3653 */     HashSet<String> result = new HashSet<>();
/* 3654 */     HashSet<String> todo = new HashSet<>(JavaProject.defaultRootModules(allSystemRoots));
/* 3655 */     while (!todo.isEmpty()) {
/* 3656 */       HashSet<String> more = new HashSet<>();
/* 3657 */       for (String s : todo) {
/* 3658 */         if (result.add(s)) {
/* 3659 */           String[] requiredModules = moduleDescriptions.get(s);
/* 3660 */           if (requiredModules != null) {
/* 3661 */             Collections.addAll(more, requiredModules);
/*      */           }
/*      */         } 
/*      */       } 
/* 3665 */       todo = more;
/*      */     } 
/* 3667 */     return result;
/*      */   }
/*      */   
/*      */   private static String joinedSortedList(Collection<String> list) {
/* 3671 */     String[] limitArray = list.<String>toArray(new String[list.size()]);
/* 3672 */     Arrays.sort((Object[])limitArray);
/* 3673 */     return String.join(",", (CharSequence[])limitArray);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\JavaRuntime.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */