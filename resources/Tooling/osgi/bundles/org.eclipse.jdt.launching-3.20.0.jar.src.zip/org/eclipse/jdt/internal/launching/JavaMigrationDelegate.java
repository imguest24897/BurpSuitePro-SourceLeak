/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.ILaunchConfigurationMigrationDelegate;
/*     */ import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaMigrationDelegate
/*     */   implements ILaunchConfigurationMigrationDelegate
/*     */ {
/*     */   protected static final String EMPTY_STRING = "";
/*     */   
/*     */   public boolean isCandidate(ILaunchConfiguration candidate) throws CoreException {
/*  54 */     String pName = candidate.getAttribute(IJavaLaunchConfigurationConstants.ATTR_PROJECT_NAME, "");
/*  55 */     if (pName.equals("")) {
/*  56 */       return false;
/*     */     }
/*  58 */     if (!isAvailable(pName)) {
/*  59 */       return false;
/*     */     }
/*  61 */     IResource[] mapped = candidate.getMappedResources();
/*  62 */     IResource target = getResource(candidate);
/*  63 */     if (target == null) {
/*  64 */       return (mapped != null);
/*     */     }
/*  66 */     if (mapped == null) {
/*  67 */       return true;
/*     */     }
/*  69 */     if (mapped.length != 1) {
/*  70 */       return true;
/*     */     }
/*  72 */     return !target.equals(mapped[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isAvailable(String projectName) {
/*  82 */     IProject project = ResourcesPlugin.getWorkspace().getRoot().getProject(projectName);
/*  83 */     return (project.exists() && project.isOpen());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static IResource getResource(ILaunchConfiguration candidate) throws CoreException {
/*     */     IProject iProject;
/*  98 */     IResource resource = null;
/*  99 */     String pname = candidate.getAttribute(IJavaLaunchConfigurationConstants.ATTR_PROJECT_NAME, "");
/* 100 */     if (Path.ROOT.isValidSegment(pname)) {
/* 101 */       IProject project = ResourcesPlugin.getWorkspace().getRoot().getProject(pname);
/* 102 */       String tname = candidate.getAttribute(IJavaLaunchConfigurationConstants.ATTR_MAIN_TYPE_NAME, "");
/* 103 */       if (!"".equals(tname)) {
/* 104 */         if (project != null && project.isAccessible()) {
/* 105 */           IJavaProject jproject = JavaCore.create(project);
/* 106 */           if (jproject != null && jproject.exists()) {
/* 107 */             tname = tname.replace('$', '.');
/* 108 */             IType type = jproject.findType(tname);
/* 109 */             if (type != null) {
/*     */               try {
/* 111 */                 resource = type.getUnderlyingResource();
/* 112 */                 if (resource == null) {
/* 113 */                   resource = (IResource)type.getAdapter(IResource.class);
/*     */                 }
/*     */               }
/* 116 */               catch (JavaModelException jme) {
/* 117 */                 LaunchingPlugin.log((Throwable)jme);
/* 118 */                 return null;
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } else {
/* 124 */         return (IResource)project;
/*     */       } 
/* 126 */       if (resource == null) {
/* 127 */         iProject = project;
/*     */       }
/*     */     } 
/* 130 */     return (IResource)iProject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void migrate(ILaunchConfiguration candidate) throws CoreException {
/* 138 */     ILaunchConfigurationWorkingCopy wc = candidate.getWorkingCopy();
/* 139 */     updateResourceMapping(wc);
/* 140 */     wc.doSave();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void updateResourceMapping(ILaunchConfigurationWorkingCopy wc) throws CoreException {
/* 150 */     IResource resource = getResource((ILaunchConfiguration)wc);
/* 151 */     IResource[] resources = null;
/* 152 */     if (resource != null) {
/* 153 */       resources = new IResource[] { resource };
/*     */     }
/* 155 */     wc.setMappedResources(resources);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\JavaMigrationDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */