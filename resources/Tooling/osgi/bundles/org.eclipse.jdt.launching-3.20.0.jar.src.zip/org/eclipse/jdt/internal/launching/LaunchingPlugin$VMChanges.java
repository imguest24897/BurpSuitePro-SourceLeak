/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstallChangedListener;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.jdt.launching.PropertyChangeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class VMChanges
/*     */   implements IVMInstallChangedListener
/*     */ {
/*     */   private boolean fDefaultChanged = false;
/* 203 */   private HashMap<IPath, IPath> fRenamedContainerIds = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IPath getContainerId(IVMInstall vm) {
/* 213 */     if (vm != null) {
/* 214 */       String name = vm.getName();
/* 215 */       if (name != null) {
/* 216 */         Path path = new Path(JavaRuntime.JRE_CONTAINER);
/* 217 */         IPath iPath = path.append((IPath)new Path(vm.getVMInstallType().getId()));
/* 218 */         iPath = iPath.append((IPath)new Path(name));
/* 219 */         return iPath;
/*     */       } 
/*     */     } 
/* 222 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void defaultVMInstallChanged(IVMInstall previous, IVMInstall current) {
/* 230 */     this.fDefaultChanged = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void vmAdded(IVMInstall vm) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void vmChanged(PropertyChangeEvent event) {
/* 245 */     String property = event.getProperty();
/* 246 */     IVMInstall vm = (IVMInstall)event.getSource();
/* 247 */     if (property.equals(IVMInstallChangedListener.PROPERTY_NAME)) {
/* 248 */       IPath newId = getContainerId(vm);
/* 249 */       Path path = new Path(JavaRuntime.JRE_CONTAINER);
/* 250 */       IPath iPath1 = path.append(vm.getVMInstallType().getId());
/* 251 */       String oldName = (String)event.getOldValue();
/*     */       
/* 253 */       if (oldName != null) {
/* 254 */         iPath1 = iPath1.append(oldName);
/* 255 */         this.fRenamedContainerIds.put(iPath1, newId);
/*     */         
/*     */         try {
/* 258 */           ILaunchConfiguration[] configs = DebugPlugin.getDefault().getLaunchManager().getLaunchConfigurations();
/* 259 */           String container = null;
/* 260 */           ILaunchConfigurationWorkingCopy wc = null;
/* 261 */           IPath cpath = null;
/* 262 */           for (int i = 0; i < configs.length; i++) {
/* 263 */             container = configs[i].getAttribute(JavaRuntime.JRE_CONTAINER, null);
/* 264 */             if (container != null) {
/* 265 */               Path path1 = new Path(container);
/* 266 */               if (path1.lastSegment().equals(oldName)) {
/* 267 */                 IPath iPath = path1.removeLastSegments(1).append(newId.lastSegment()).addTrailingSeparator();
/* 268 */                 wc = configs[i].getWorkingCopy();
/* 269 */                 wc.setAttribute(JavaRuntime.JRE_CONTAINER, iPath.toString());
/* 270 */                 wc.doSave();
/*     */               } 
/*     */             } 
/*     */           } 
/* 274 */         } catch (CoreException coreException) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void vmRemoved(IVMInstall vm) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void process() {
/* 291 */     LaunchingPlugin.JREUpdateJob job = new LaunchingPlugin.JREUpdateJob(LaunchingPlugin.this, this);
/* 292 */     job.schedule();
/*     */   }
/*     */   
/*     */   protected void doit(IProgressMonitor monitor) throws CoreException {
/* 296 */     IWorkspaceRunnable runnable = new IWorkspaceRunnable()
/*     */       {
/*     */         public void run(IProgressMonitor monitor1) throws CoreException {
/* 299 */           IJavaProject[] projects = JavaCore.create(ResourcesPlugin.getWorkspace().getRoot()).getJavaProjects();
/* 300 */           monitor1.beginTask(LaunchingMessages.LaunchingPlugin_0, projects.length + 1);
/* 301 */           LaunchingPlugin.VMChanges.this.rebind(monitor1, projects);
/* 302 */           monitor1.done();
/*     */         }
/*     */       };
/* 305 */     JavaCore.run(runnable, null, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void rebind(IProgressMonitor monitor, IJavaProject[] projects) throws CoreException {
/* 316 */     if (this.fDefaultChanged) {
/*     */       
/* 318 */       JavaClasspathVariablesInitializer initializer = new JavaClasspathVariablesInitializer();
/* 319 */       initializer.initialize("JRE_LIB");
/* 320 */       initializer.initialize("JRE_SRC");
/* 321 */       initializer.initialize("JRE_SRCROOT");
/*     */     } 
/* 323 */     monitor.worked(1);
/*     */ 
/*     */     
/* 326 */     int length = projects.length;
/* 327 */     Map<IPath, List<IJavaProject>> projectsMap = new HashMap<>();
/* 328 */     for (int i = 0; i < length; i++) {
/* 329 */       IJavaProject project = projects[i];
/* 330 */       IClasspathEntry[] entries = project.getRawClasspath();
/* 331 */       boolean replace = false;
/* 332 */       for (int j = 0; j < entries.length; j++) {
/* 333 */         IPath reference, newBinding; String firstSegment; IClasspathEntry entry = entries[j];
/* 334 */         switch (entry.getEntryKind()) {
/*     */           case 5:
/* 336 */             reference = entry.getPath();
/* 337 */             newBinding = null;
/* 338 */             firstSegment = reference.segment(0);
/* 339 */             if (JavaRuntime.JRE_CONTAINER.equals(firstSegment)) {
/* 340 */               if (reference.segmentCount() > 1) {
/* 341 */                 IPath renamed = this.fRenamedContainerIds.get(reference);
/* 342 */                 if (renamed != null)
/*     */                 {
/*     */                   
/* 345 */                   newBinding = renamed;
/*     */                 }
/*     */               } 
/* 348 */               if (newBinding == null) {
/*     */ 
/*     */                 
/* 351 */                 List<IJavaProject> projectsList = projectsMap.get(reference);
/* 352 */                 if (projectsList == null) {
/* 353 */                   projectsMap.put(reference, projectsList = new ArrayList<>(length));
/*     */                 }
/* 355 */                 projectsList.add(project);
/*     */                 break;
/*     */               } 
/* 358 */               IClasspathEntry newEntry = JavaCore.newContainerEntry(newBinding, entry.isExported());
/* 359 */               entries[j] = newEntry;
/* 360 */               replace = true;
/*     */             } 
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/* 368 */       if (replace) {
/* 369 */         project.setRawClasspath(entries, null);
/*     */       }
/* 371 */       monitor.worked(1);
/*     */     } 
/* 373 */     Iterator<IPath> references = projectsMap.keySet().iterator();
/* 374 */     while (references.hasNext()) {
/* 375 */       IPath reference = references.next();
/* 376 */       List<IJavaProject> projectsList = projectsMap.get(reference);
/* 377 */       IJavaProject[] referenceProjects = new IJavaProject[projectsList.size()];
/* 378 */       projectsList.toArray(referenceProjects);
/*     */       
/* 380 */       JREContainerInitializer initializer = new JREContainerInitializer();
/* 381 */       initializer.initialize(reference, referenceProjects);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\LaunchingPlugin$VMChanges.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */