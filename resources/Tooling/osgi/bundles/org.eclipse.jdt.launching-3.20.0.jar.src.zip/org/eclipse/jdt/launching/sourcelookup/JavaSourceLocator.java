/*     */ package org.eclipse.jdt.launching.sourcelookup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.ILaunchConfigurationType;
/*     */ import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
/*     */ import org.eclipse.debug.core.model.IPersistableSourceLocator;
/*     */ import org.eclipse.debug.core.model.IStackFrame;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.IJavaModel;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.debug.core.IJavaStackFrame;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingMessages;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
/*     */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class JavaSourceLocator
/*     */   implements IPersistableSourceLocator
/*     */ {
/* 108 */   public static final String ID_JAVA_SOURCE_LOCATOR = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".javaSourceLocator";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IJavaSourceLocation[] fLocations;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaSourceLocator() {
/* 119 */     setSourceLocations(new IJavaSourceLocation[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaSourceLocator(IJavaProject[] projects, boolean includeRequired) throws CoreException {
/* 133 */     ArrayList<IJavaProject> requiredProjects = new ArrayList<>();
/* 134 */     for (int i = 0; i < projects.length; i++) {
/* 135 */       if (includeRequired) {
/* 136 */         collectRequiredProjects(projects[i], requiredProjects);
/*     */       }
/* 138 */       else if (!requiredProjects.contains(projects[i])) {
/* 139 */         requiredProjects.add(projects[i]);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 145 */     HashMap<IPath, IPath> external = new HashMap<>();
/* 146 */     ArrayList<PackageFragmentRootSourceLocation> list = new ArrayList<>();
/*     */     
/* 148 */     Iterator<IJavaProject> iter = requiredProjects.iterator();
/* 149 */     while (iter.hasNext()) {
/* 150 */       IJavaProject p = iter.next();
/* 151 */       IPackageFragmentRoot[] roots = p.getPackageFragmentRoots();
/* 152 */       for (int j = 0; j < roots.length; j++) {
/* 153 */         if (roots[j].isExternal()) {
/* 154 */           IPath location = roots[j].getPath();
/* 155 */           if (external.get(location) == null) {
/* 156 */             external.put(location, location);
/* 157 */             list.add(new PackageFragmentRootSourceLocation(roots[j]));
/*     */           } 
/*     */         } else {
/* 160 */           list.add(new PackageFragmentRootSourceLocation(roots[j]));
/*     */         } 
/*     */       } 
/*     */     } 
/* 164 */     IJavaSourceLocation[] locations = list.<IJavaSourceLocation>toArray(new IJavaSourceLocation[list.size()]);
/* 165 */     setSourceLocations(locations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaSourceLocator(IJavaSourceLocation[] locations) {
/* 176 */     setSourceLocations(locations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaSourceLocator(IJavaProject project) throws CoreException {
/* 188 */     setSourceLocations(getDefaultSourceLocations(project));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceLocations(IJavaSourceLocation[] locations) {
/* 199 */     this.fLocations = locations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IJavaSourceLocation[] getSourceLocations() {
/* 210 */     return this.fLocations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getSourceElements(IStackFrame stackFrame) {
/* 223 */     if (stackFrame instanceof IJavaStackFrame) {
/* 224 */       IJavaStackFrame frame = (IJavaStackFrame)stackFrame;
/* 225 */       String name = null;
/*     */       try {
/* 227 */         name = getFullyQualfiedName(frame);
/* 228 */         if (name == null) {
/* 229 */           return null;
/*     */         }
/* 231 */       } catch (CoreException e) {
/*     */         
/* 233 */         if (e.getStatus().getCode() != 100) {
/* 234 */           LaunchingPlugin.log((Throwable)e);
/*     */         }
/* 236 */         return null;
/*     */       } 
/* 238 */       List<Object> list = new ArrayList();
/* 239 */       IJavaSourceLocation[] locations = getSourceLocations();
/* 240 */       for (int i = 0; i < locations.length; i++) {
/*     */         try {
/* 242 */           Object sourceElement = locations[i].findSourceElement(name);
/* 243 */           if (sourceElement != null) {
/* 244 */             list.add(sourceElement);
/*     */           }
/* 246 */         } catch (CoreException e) {
/*     */           
/* 248 */           LaunchingPlugin.log((Throwable)e);
/*     */         } 
/*     */       } 
/* 251 */       return list.toArray();
/*     */     } 
/* 253 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getSourceElement(IStackFrame stackFrame) {
/* 261 */     if (stackFrame instanceof IJavaStackFrame) {
/* 262 */       IJavaStackFrame frame = (IJavaStackFrame)stackFrame;
/* 263 */       String name = null;
/*     */       try {
/* 265 */         name = getFullyQualfiedName(frame);
/* 266 */         if (name == null) {
/* 267 */           return null;
/*     */         }
/* 269 */       } catch (CoreException e) {
/*     */         
/* 271 */         if (e.getStatus().getCode() != 100) {
/* 272 */           LaunchingPlugin.log((Throwable)e);
/*     */         }
/* 274 */         return null;
/*     */       } 
/* 276 */       IJavaSourceLocation[] locations = getSourceLocations();
/* 277 */       for (int i = 0; i < locations.length; i++) {
/*     */         try {
/* 279 */           Object sourceElement = locations[i].findSourceElement(name);
/* 280 */           if (sourceElement != null) {
/* 281 */             return sourceElement;
/*     */           }
/* 283 */         } catch (CoreException e) {
/*     */           
/* 285 */           LaunchingPlugin.log((Throwable)e);
/*     */         } 
/*     */       } 
/*     */     } 
/* 289 */     return null;
/*     */   }
/*     */   
/*     */   private String getFullyQualfiedName(IJavaStackFrame frame) throws CoreException {
/* 293 */     String name = null;
/* 294 */     if (frame.isObsolete()) {
/* 295 */       return null;
/*     */     }
/* 297 */     String sourceName = frame.getSourceName();
/* 298 */     if (sourceName == null) {
/*     */       
/* 300 */       name = frame.getDeclaringTypeName();
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 307 */       int index = sourceName.lastIndexOf('\\');
/* 308 */       if (index == -1) {
/* 309 */         index = sourceName.lastIndexOf('/');
/*     */       }
/* 311 */       if (index >= 0) {
/* 312 */         sourceName = sourceName.substring(index + 1);
/*     */       }
/*     */       
/* 315 */       String declName = frame.getDeclaringTypeName();
/* 316 */       index = declName.lastIndexOf('.');
/* 317 */       if (index >= 0) {
/* 318 */         name = declName.substring(0, index + 1);
/*     */       } else {
/* 320 */         name = "";
/*     */       } 
/* 322 */       index = sourceName.lastIndexOf('.');
/* 323 */       if (index >= 0) {
/* 324 */         name = String.valueOf(name) + sourceName.substring(0, index);
/*     */       }
/*     */     } 
/* 327 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void collectRequiredProjects(IJavaProject proj, ArrayList<IJavaProject> res) throws JavaModelException {
/* 340 */     if (!res.contains(proj)) {
/* 341 */       res.add(proj);
/*     */       
/* 343 */       IJavaModel model = proj.getJavaModel();
/*     */       
/* 345 */       IClasspathEntry[] entries = proj.getRawClasspath();
/* 346 */       for (int i = 0; i < entries.length; i++) {
/* 347 */         IClasspathEntry curr = entries[i];
/* 348 */         if (curr.getEntryKind() == 2) {
/* 349 */           IJavaProject ref = model.getJavaProject(curr.getPath().segment(0));
/* 350 */           if (ref.exists()) {
/* 351 */             collectRequiredProjects(ref, res);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IJavaSourceLocation[] getDefaultSourceLocations(IJavaProject project) throws CoreException {
/* 371 */     ILaunchConfigurationType type = DebugPlugin.getDefault().getLaunchManager().getLaunchConfigurationType(IJavaLaunchConfigurationConstants.ID_JAVA_APPLICATION);
/* 372 */     ILaunchConfigurationWorkingCopy config = type.newInstance(null, project.getElementName());
/* 373 */     config.setAttribute(IJavaLaunchConfigurationConstants.ATTR_PROJECT_NAME, project.getElementName());
/* 374 */     JavaSourceLocator locator = new JavaSourceLocator();
/* 375 */     locator.initializeDefaults((ILaunchConfiguration)config);
/* 376 */     return locator.getSourceLocations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMemento() throws CoreException {
/* 384 */     Document doc = DebugPlugin.newDocument();
/* 385 */     Element node = doc.createElement("javaSourceLocator");
/* 386 */     doc.appendChild(node);
/*     */     
/* 388 */     IJavaSourceLocation[] locations = getSourceLocations();
/* 389 */     for (int i = 0; i < locations.length; i++) {
/* 390 */       Element child = doc.createElement("javaSourceLocation");
/* 391 */       child.setAttribute("class", locations[i].getClass().getName());
/* 392 */       child.setAttribute("memento", locations[i].getMemento());
/* 393 */       node.appendChild(child);
/*     */     } 
/* 395 */     return DebugPlugin.serializeDocument(doc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeDefaults(ILaunchConfiguration configuration) throws CoreException {
/* 403 */     IRuntimeClasspathEntry[] entries = JavaRuntime.computeUnresolvedSourceLookupPath(configuration);
/* 404 */     IRuntimeClasspathEntry[] resolved = JavaRuntime.resolveSourceLookupPath(entries, configuration);
/* 405 */     setSourceLocations(getSourceLocations(resolved));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeFromMemento(String memento) throws CoreException {
/* 413 */     Exception ex = null;
/*     */     try {
/* 415 */       Element root = null;
/* 416 */       DocumentBuilder parser = 
/* 417 */         DocumentBuilderFactory.newInstance().newDocumentBuilder();
/* 418 */       parser.setErrorHandler(new DefaultHandler());
/* 419 */       StringReader reader = new StringReader(memento);
/* 420 */       InputSource source = new InputSource(reader);
/* 421 */       root = parser.parse(source).getDocumentElement();
/*     */       
/* 423 */       if (!root.getNodeName().equalsIgnoreCase("javaSourceLocator")) {
/* 424 */         abort(LaunchingMessages.JavaSourceLocator_Unable_to_restore_Java_source_locator___invalid_format__6, null);
/*     */       }
/*     */       
/* 427 */       List<IJavaSourceLocation> sourceLocations = new ArrayList<>();
/* 428 */       Bundle bundle = LaunchingPlugin.getDefault().getBundle();
/*     */       
/* 430 */       NodeList list = root.getChildNodes();
/* 431 */       int length = list.getLength();
/* 432 */       for (int i = 0; i < length; i++) {
/* 433 */         Node node = list.item(i);
/* 434 */         short type = node.getNodeType();
/* 435 */         if (type == 1) {
/* 436 */           Element entry = (Element)node;
/* 437 */           if (entry.getNodeName().equalsIgnoreCase("javaSourceLocation")) {
/* 438 */             String className = entry.getAttribute("class");
/* 439 */             String data = entry.getAttribute("memento");
/* 440 */             if (isEmpty(className)) {
/* 441 */               abort(LaunchingMessages.JavaSourceLocator_Unable_to_restore_Java_source_locator___invalid_format__10, null);
/*     */             }
/* 443 */             Class<?> clazz = null;
/*     */             try {
/* 445 */               clazz = bundle.loadClass(className);
/* 446 */             } catch (ClassNotFoundException e) {
/* 447 */               abort(NLS.bind(LaunchingMessages.JavaSourceLocator_Unable_to_restore_source_location___class_not_found___0__11, (Object[])new String[] { className }), e);
/*     */             } 
/*     */             
/* 450 */             IJavaSourceLocation location = null;
/*     */             try {
/* 452 */               location = (IJavaSourceLocation)clazz.newInstance();
/* 453 */             } catch (IllegalAccessException e) {
/* 454 */               abort(LaunchingMessages.JavaSourceLocator_Unable_to_restore_source_location__12, e);
/* 455 */             } catch (InstantiationException e) {
/* 456 */               abort(LaunchingMessages.JavaSourceLocator_Unable_to_restore_source_location__12, e);
/*     */             } 
/* 458 */             location.initializeFrom(data);
/* 459 */             sourceLocations.add(location);
/*     */           } else {
/* 461 */             abort(LaunchingMessages.JavaSourceLocator_Unable_to_restore_Java_source_locator___invalid_format__14, null);
/*     */           } 
/*     */         } 
/*     */       } 
/* 465 */       setSourceLocations(sourceLocations.<IJavaSourceLocation>toArray(new IJavaSourceLocation[sourceLocations.size()]));
/*     */       return;
/* 467 */     } catch (ParserConfigurationException e) {
/* 468 */       ex = e;
/* 469 */     } catch (SAXException e) {
/* 470 */       ex = e;
/* 471 */     } catch (IOException e) {
/* 472 */       ex = e;
/*     */     } 
/* 474 */     abort(LaunchingMessages.JavaSourceLocator_Exception_occurred_initializing_source_locator__15, ex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IJavaSourceLocation[] getSourceLocations(IRuntimeClasspathEntry[] entries) {
/* 484 */     List<IJavaSourceLocation> locations = new ArrayList<>(entries.length);
/* 485 */     for (int i = 0; i < entries.length; i++) {
/* 486 */       IProject project; String source; IRuntimeClasspathEntry entry = entries[i];
/* 487 */       IJavaSourceLocation location = null;
/* 488 */       switch (entry.getType()) {
/*     */         case 1:
/* 490 */           project = (IProject)entry.getResource();
/* 491 */           if (project != null && project.exists() && project.isOpen()) {
/* 492 */             location = new JavaProjectSourceLocation(JavaCore.create(project));
/*     */           }
/*     */           break;
/*     */         
/*     */         case 2:
/* 497 */           location = getArchiveSourceLocation(entry);
/* 498 */           if (location == null) {
/* 499 */             String path = entry.getSourceAttachmentLocation();
/* 500 */             if (path == null)
/*     */             {
/* 502 */               path = entry.getLocation();
/*     */             }
/* 504 */             if (path != null) {
/* 505 */               File file = new File(path);
/* 506 */               if (file.exists()) {
/* 507 */                 if (file.isDirectory()) {
/* 508 */                   location = new DirectorySourceLocation(file); break;
/*     */                 } 
/* 510 */                 location = new ArchiveSourceLocation(path, entry.getSourceAttachmentRootLocation());
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 3:
/* 517 */           source = entry.getSourceAttachmentLocation();
/* 518 */           if (source != null) {
/* 519 */             location = new ArchiveSourceLocation(source, entry.getSourceAttachmentRootLocation());
/*     */           }
/*     */           break;
/*     */         case 4:
/* 523 */           throw new IllegalArgumentException(LaunchingMessages.JavaSourceLocator_Illegal_to_have_a_container_resolved_to_a_container_1);
/*     */       } 
/* 525 */       if (location != null) {
/* 526 */         locations.add(location);
/*     */       }
/*     */     } 
/* 529 */     return locations.<IJavaSourceLocation>toArray(new IJavaSourceLocation[locations.size()]);
/*     */   }
/*     */   
/*     */   private boolean isEmpty(String string) {
/* 533 */     return !(string != null && string.length() != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void abort(String message, Throwable e) throws CoreException {
/* 543 */     Status status = new Status(4, LaunchingPlugin.getUniqueIdentifier(), 150, message, e);
/* 544 */     throw new CoreException(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean equalOrNull(Object a, Object b) {
/* 557 */     if (a == null) {
/* 558 */       return (b == null);
/*     */     }
/* 560 */     if (b == null) {
/* 561 */       return false;
/*     */     }
/* 563 */     return a.equals(b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isSourceAttachmentEqual(IPackageFragmentRoot root, IRuntimeClasspathEntry entry) throws JavaModelException {
/* 577 */     return equalOrNull(root.getSourceAttachmentPath(), entry.getSourceAttachmentPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IJavaSourceLocation getArchiveSourceLocation(IRuntimeClasspathEntry entry) {
/* 590 */     IResource resource = entry.getResource();
/* 591 */     if (resource == null) {
/*     */ 
/*     */ 
/*     */       
/* 595 */       IJavaModel model = JavaCore.create(ResourcesPlugin.getWorkspace().getRoot());
/*     */       try {
/* 597 */         IJavaProject[] jps = model.getJavaProjects();
/* 598 */         for (int i = 0; i < jps.length; i++) {
/* 599 */           IPackageFragmentRoot[] allRoots = jps[i].getPackageFragmentRoots();
/* 600 */           for (int j = 0; j < allRoots.length; j++) {
/* 601 */             IPackageFragmentRoot root = allRoots[j];
/* 602 */             if (root.isExternal() && root.getPath().equals(new Path(entry.getLocation())) && 
/* 603 */               isSourceAttachmentEqual(root, entry))
/*     */             {
/* 605 */               return new PackageFragmentRootSourceLocation(root);
/*     */             }
/*     */           }
/*     */         
/*     */         } 
/* 610 */       } catch (JavaModelException e) {
/* 611 */         LaunchingPlugin.log((Throwable)e);
/*     */       } 
/*     */     } else {
/*     */       
/* 615 */       IProject project = resource.getProject();
/* 616 */       IJavaProject jp = JavaCore.create(project);
/*     */       try {
/* 618 */         if (jp != null && jp.exists()) {
/* 619 */           IPackageFragmentRoot root = jp.getPackageFragmentRoot(resource);
/* 620 */           IPackageFragmentRoot[] allRoots = jp.getPackageFragmentRoots();
/* 621 */           for (int j = 0; j < allRoots.length; j++) {
/* 622 */             if (allRoots[j].equals(root))
/*     */             {
/* 624 */               if (isSourceAttachmentEqual(root, entry))
/*     */               {
/* 626 */                 return new PackageFragmentRootSourceLocation(root);
/*     */               }
/*     */             }
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 634 */         IJavaModel model = JavaCore.create(ResourcesPlugin.getWorkspace().getRoot());
/* 635 */         IJavaProject[] jps = model.getJavaProjects();
/* 636 */         for (int i = 0; i < jps.length; i++) {
/* 637 */           IPackageFragmentRoot[] allRoots = jps[i].getPackageFragmentRoots();
/* 638 */           for (int j = 0; j < allRoots.length; j++) {
/* 639 */             IPackageFragmentRoot root = allRoots[j];
/* 640 */             if (!root.isExternal() && root.getPath().equals(entry.getPath()) && 
/* 641 */               isSourceAttachmentEqual(root, entry))
/*     */             {
/* 643 */               return new PackageFragmentRootSourceLocation(root);
/*     */             }
/*     */           }
/*     */         
/*     */         } 
/* 648 */       } catch (JavaModelException e) {
/* 649 */         LaunchingPlugin.log((Throwable)e);
/*     */       } 
/*     */     } 
/* 652 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\sourcelookup\JavaSourceLocator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */