/*     */ package org.eclipse.jdt.launching.sourcelookup;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingMessages;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class ArchiveSourceLocation
/*     */   extends PlatformObject
/*     */   implements IJavaSourceLocation
/*     */ {
/*  72 */   private static HashMap<String, ZipFile> fZipFileCache = new HashMap<>(5);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IPath fRootPath;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ZipFile getZipFile(String name) throws IOException {
/*  83 */     synchronized (fZipFileCache) {
/*  84 */       ZipFile zip = fZipFileCache.get(name);
/*  85 */       if (zip == null) {
/*  86 */         zip = new ZipFile(name);
/*  87 */         fZipFileCache.put(name, zip);
/*     */       } 
/*  89 */       return zip;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void closeArchives() {
/* 100 */     synchronized (fZipFileCache) {
/* 101 */       Iterator<ZipFile> iter = fZipFileCache.values().iterator();
/* 102 */       while (iter.hasNext()) { try {
/* 103 */           Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 108 */         catch (IOException e) {
/* 109 */           LaunchingPlugin.log(e);
/*     */         }  }
/*     */       
/* 112 */       fZipFileCache.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fRootDetected = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String fName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArchiveSourceLocation() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArchiveSourceLocation(String archiveName, String sourceRoot) {
/* 149 */     setName(archiveName);
/* 150 */     setRootPath(sourceRoot);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findSourceElement(String name) throws CoreException {
/*     */     try {
/* 159 */       ZipFile zip = getArchive();
/* 160 */       if (zip == null) {
/* 161 */         return null;
/*     */       }
/*     */       
/* 164 */       boolean possibleInnerType = false;
/* 165 */       String pathStr = name.replace('.', '/');
/* 166 */       int lastSlash = pathStr.lastIndexOf('/');
/* 167 */       String typeName = pathStr; while (true)
/*     */       { IPath iPath;
/* 169 */         Path path = new Path(String.valueOf(typeName) + ".java");
/* 170 */         autoDetectRoot((IPath)path);
/* 171 */         if (getRootPath() != null) {
/* 172 */           iPath = getRootPath().append((IPath)path);
/*     */         }
/* 174 */         ZipEntry entry = getArchive().getEntry(iPath.toString());
/* 175 */         if (entry != null) {
/* 176 */           return new ZipEntryStorage(zip, entry);
/*     */         }
/* 178 */         int index = typeName.lastIndexOf('$');
/* 179 */         if (index > lastSlash) {
/* 180 */           typeName = typeName.substring(0, index);
/* 181 */           possibleInnerType = true;
/*     */         } else {
/* 183 */           possibleInnerType = false;
/*     */         } 
/* 185 */         if (!possibleInnerType)
/* 186 */           return null;  } 
/* 187 */     } catch (IOException e) {
/* 188 */       throw new CoreException(new Status(4, LaunchingPlugin.getUniqueIdentifier(), 150, 
/* 189 */             NLS.bind(LaunchingMessages.ArchiveSourceLocation_Unable_to_locate_source_element_in_archive__0__1, new String[] { getName() }), e));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void autoDetectRoot(IPath path) throws CoreException {
/* 200 */     if (!this.fRootDetected) {
/* 201 */       ZipFile zip = null;
/*     */       try {
/* 203 */         zip = getArchive();
/* 204 */       } catch (IOException e) {
/* 205 */         throw new CoreException(new Status(4, LaunchingPlugin.getUniqueIdentifier(), 150, 
/* 206 */               NLS.bind(LaunchingMessages.ArchiveSourceLocation_Exception_occurred_while_detecting_root_source_directory_in_archive__0__1, new String[] { getName() }), e));
/*     */       } 
/* 208 */       synchronized (zip) {
/* 209 */         Enumeration<? extends ZipEntry> entries = zip.entries();
/* 210 */         String fileName = path.toString();
/*     */         try {
/* 212 */           while (entries.hasMoreElements()) {
/* 213 */             ZipEntry entry = entries.nextElement();
/* 214 */             String entryName = entry.getName();
/* 215 */             if (entryName.endsWith(fileName)) {
/* 216 */               int rootLength = entryName.length() - fileName.length();
/* 217 */               if (rootLength > 0) {
/* 218 */                 String root = entryName.substring(0, rootLength);
/* 219 */                 setRootPath(root);
/*     */               } 
/* 221 */               this.fRootDetected = true;
/*     */               return;
/*     */             } 
/*     */           } 
/* 225 */         } catch (IllegalStateException e) {
/* 226 */           throw new CoreException(new Status(4, LaunchingPlugin.getUniqueIdentifier(), 150, 
/* 227 */                 NLS.bind(LaunchingMessages.ArchiveSourceLocation_Exception_occurred_while_detecting_root_source_directory_in_archive__0__2, new String[] { getName() }), e));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ZipFile getArchive() throws IOException {
/* 242 */     return getZipFile(getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setRootPath(String path) {
/* 255 */     if (path == null || path.trim().length() == 0) {
/* 256 */       this.fRootPath = null;
/*     */     } else {
/* 258 */       this.fRootPath = (IPath)new Path(path);
/* 259 */       this.fRootDetected = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getRootPath() {
/* 273 */     return this.fRootPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 284 */     return this.fName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setName(String name) {
/* 295 */     this.fName = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 303 */     return (object instanceof ArchiveSourceLocation && 
/* 304 */       getName().equals(((ArchiveSourceLocation)object).getName()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 312 */     return getName().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMemento() throws CoreException {
/* 320 */     Document doc = DebugPlugin.newDocument();
/* 321 */     Element node = doc.createElement("archiveSourceLocation");
/* 322 */     doc.appendChild(node);
/* 323 */     node.setAttribute("archivePath", getName());
/* 324 */     if (getRootPath() != null) {
/* 325 */       node.setAttribute("rootPath", getRootPath().toString());
/*     */     }
/*     */     
/* 328 */     return DebugPlugin.serializeDocument(doc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeFrom(String memento) throws CoreException {
/* 336 */     Exception ex = null;
/*     */     try {
/* 338 */       Element root = null;
/* 339 */       DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/* 340 */       parser.setErrorHandler(new DefaultHandler());
/* 341 */       StringReader reader = new StringReader(memento);
/* 342 */       InputSource source = new InputSource(reader);
/* 343 */       root = parser.parse(source).getDocumentElement();
/*     */       
/* 345 */       String path = root.getAttribute("archivePath");
/* 346 */       if (isEmpty(path)) {
/* 347 */         abort(LaunchingMessages.ArchiveSourceLocation_Unable_to_initialize_source_location___missing_archive_path__3, null);
/*     */       }
/* 349 */       String rootPath = root.getAttribute("rootPath");
/*     */       
/* 351 */       setName(path);
/* 352 */       setRootPath(rootPath);
/*     */       return;
/* 354 */     } catch (ParserConfigurationException e) {
/* 355 */       ex = e;
/* 356 */     } catch (SAXException e) {
/* 357 */       ex = e;
/* 358 */     } catch (IOException e) {
/* 359 */       ex = e;
/*     */     } 
/* 361 */     abort(LaunchingMessages.ArchiveSourceLocation_Exception_occurred_initializing_source_location__5, ex);
/*     */   }
/*     */   
/*     */   private boolean isEmpty(String string) {
/* 365 */     return !(string != null && string.length() != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void abort(String message, Throwable e) throws CoreException {
/* 372 */     Status status = new Status(4, LaunchingPlugin.getUniqueIdentifier(), 150, message, e);
/* 373 */     throw new CoreException(status);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\sourcelookup\ArchiveSourceLocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */