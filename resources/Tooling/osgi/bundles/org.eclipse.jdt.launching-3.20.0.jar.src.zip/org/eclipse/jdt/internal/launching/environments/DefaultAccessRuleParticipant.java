/*    */ package org.eclipse.jdt.internal.launching.environments;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Properties;
/*    */ import java.util.StringTokenizer;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ import org.eclipse.jdt.core.IAccessRule;
/*    */ import org.eclipse.jdt.core.IJavaProject;
/*    */ import org.eclipse.jdt.core.JavaCore;
/*    */ import org.eclipse.jdt.launching.IVMInstall;
/*    */ import org.eclipse.jdt.launching.LibraryLocation;
/*    */ import org.eclipse.jdt.launching.environments.IAccessRuleParticipant;
/*    */ import org.eclipse.jdt.launching.environments.IExecutionEnvironment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultAccessRuleParticipant
/*    */   implements IAccessRuleParticipant
/*    */ {
/* 43 */   private static Map<String, IAccessRule[][]> fgRules = (Map)new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IAccessRule[][] getAccessRules(IExecutionEnvironment environment, IVMInstall vm, LibraryLocation[] libraries, IJavaProject project) {
/* 50 */     Map<String, String> complianceOptions = environment.getComplianceOptions();
/* 51 */     if (complianceOptions != null) {
/* 52 */       String compliance = complianceOptions.get("org.eclipse.jdt.core.compiler.compliance");
/* 53 */       if (JavaCore.compareJavaVersions(compliance, "9") >= 0) {
/* 54 */         return new IAccessRule[0][];
/*    */       }
/*    */     } 
/* 57 */     IAccessRule[][] allRules = null;
/* 58 */     allRules = fgRules.get(environment.getId());
/* 59 */     if (allRules == null || allRules.length != libraries.length) {
/*    */       
/* 61 */       String[] packages = retrieveSystemPackages(environment);
/* 62 */       IAccessRule[] packageRules = null;
/* 63 */       if (packages.length > 0) {
/* 64 */         packageRules = new IAccessRule[packages.length + 1];
/* 65 */         for (int j = 0; j < packages.length; j++) {
/* 66 */           packageRules[j] = JavaCore.newAccessRule((IPath)new Path(packages[j].replace('.', '/')), 0);
/*    */         }
/*    */         
/* 69 */         packageRules[packages.length] = JavaCore.newAccessRule((IPath)new Path("**/*"), 257);
/*    */       } else {
/* 71 */         packageRules = new IAccessRule[0];
/*    */       } 
/* 73 */       allRules = new IAccessRule[libraries.length][];
/* 74 */       for (int i = 0; i < allRules.length; i++) {
/* 75 */         allRules[i] = packageRules;
/*    */       }
/* 77 */       fgRules.put(environment.getId(), allRules);
/*    */     } 
/* 79 */     return allRules;
/*    */   }
/*    */   
/*    */   private String[] retrieveSystemPackages(IExecutionEnvironment environment) {
/* 83 */     Properties profile = environment.getProfileProperties();
/* 84 */     if (profile != null) {
/* 85 */       String packages = profile.getProperty("org.osgi.framework.system.packages");
/* 86 */       if (packages != null) {
/* 87 */         StringTokenizer tokenizer = new StringTokenizer(packages, ",");
/* 88 */         String[] result = new String[tokenizer.countTokens() + 1];
/* 89 */         result[0] = "java.**";
/* 90 */         for (int i = 1; i < result.length; i++) {
/* 91 */           result[i] = String.valueOf(tokenizer.nextToken().trim()) + ".*";
/*    */         }
/* 93 */         return result;
/*    */       } 
/*    */     } 
/* 96 */     return new String[0];
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\environments\DefaultAccessRuleParticipant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */