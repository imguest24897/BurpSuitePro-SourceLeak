/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ import org.eclipse.core.variables.VariablesPlugin;
/*    */ import org.eclipse.debug.core.ILaunchConfiguration;
/*    */ import org.eclipse.jdt.core.IClasspathEntry;
/*    */ import org.eclipse.jdt.core.IJavaProject;
/*    */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry;
/*    */ import org.eclipse.jdt.launching.IRuntimeClasspathEntryResolver;
/*    */ import org.eclipse.jdt.launching.IVMInstall;
/*    */ import org.eclipse.jdt.launching.JavaRuntime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VariableClasspathResolver
/*    */   implements IRuntimeClasspathEntryResolver
/*    */ {
/*    */   public IRuntimeClasspathEntry[] resolveRuntimeClasspathEntry(IRuntimeClasspathEntry entry, ILaunchConfiguration configuration) throws CoreException {
/* 37 */     return resolveRuntimeClasspathEntry(entry);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IRuntimeClasspathEntry[] resolveRuntimeClasspathEntry(IRuntimeClasspathEntry entry, IJavaProject project) throws CoreException {
/* 45 */     return resolveRuntimeClasspathEntry(entry);
/*    */   }
/*    */   
/*    */   private IRuntimeClasspathEntry[] resolveRuntimeClasspathEntry(IRuntimeClasspathEntry entry) throws CoreException {
/* 49 */     String variableString = ((VariableClasspathEntry)entry).getVariableString();
/* 50 */     String strpath = VariablesPlugin.getDefault().getStringVariableManager().performStringSubstitution(variableString);
/* 51 */     IPath path = (new Path(strpath)).makeAbsolute();
/* 52 */     IRuntimeClasspathEntry archiveEntry = JavaRuntime.newArchiveRuntimeClasspathEntry(path);
/* 53 */     return new IRuntimeClasspathEntry[] { archiveEntry };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IVMInstall resolveVMInstall(IClasspathEntry entry) throws CoreException {
/* 61 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\VariableClasspathResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */