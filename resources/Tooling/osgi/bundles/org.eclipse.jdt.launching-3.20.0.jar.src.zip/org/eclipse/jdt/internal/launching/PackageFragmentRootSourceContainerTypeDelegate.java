/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.AbstractSourceContainerTypeDelegate;
/*    */ import org.eclipse.jdt.core.IJavaElement;
/*    */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*    */ import org.eclipse.jdt.core.JavaCore;
/*    */ import org.eclipse.jdt.launching.sourcelookup.containers.PackageFragmentRootSourceContainer;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PackageFragmentRootSourceContainerTypeDelegate
/*    */   extends AbstractSourceContainerTypeDelegate
/*    */ {
/*    */   public ISourceContainer createSourceContainer(String memento) throws CoreException {
/* 39 */     Node node = parseDocument(memento);
/* 40 */     if (node.getNodeType() == 1) {
/* 41 */       Element element = (Element)node;
/* 42 */       if ("packageFragmentRoot".equals(element.getNodeName())) {
/* 43 */         String string = element.getAttribute("handle");
/* 44 */         if (string == null || string.length() == 0) {
/* 45 */           abort(LaunchingMessages.PackageFragmentRootSourceContainerTypeDelegate_6, null);
/*    */         }
/* 47 */         IJavaElement root = JavaCore.create(string);
/* 48 */         if (root instanceof IPackageFragmentRoot) {
/* 49 */           return (ISourceContainer)new PackageFragmentRootSourceContainer((IPackageFragmentRoot)root);
/*    */         }
/* 51 */         abort(LaunchingMessages.PackageFragmentRootSourceContainerTypeDelegate_7, null);
/*    */       } else {
/* 53 */         abort(LaunchingMessages.PackageFragmentRootSourceContainerTypeDelegate_8, null);
/*    */       } 
/*    */     } 
/* 56 */     abort(LaunchingMessages.JavaProjectSourceContainerTypeDelegate_7, null);
/* 57 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getMemento(ISourceContainer container) throws CoreException {
/* 64 */     PackageFragmentRootSourceContainer root = (PackageFragmentRootSourceContainer)container;
/* 65 */     Document document = newDocument();
/* 66 */     Element element = document.createElement("packageFragmentRoot");
/* 67 */     element.setAttribute("handle", root.getPackageFragmentRoot().getHandleIdentifier());
/* 68 */     document.appendChild(element);
/* 69 */     return serializeDocument(document);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\PackageFragmentRootSourceContainerTypeDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */