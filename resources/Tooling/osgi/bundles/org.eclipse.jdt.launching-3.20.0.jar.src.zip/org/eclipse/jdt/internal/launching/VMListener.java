/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import org.eclipse.jdt.launching.IVMInstall;
/*    */ import org.eclipse.jdt.launching.IVMInstallChangedListener;
/*    */ import org.eclipse.jdt.launching.PropertyChangeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VMListener
/*    */   implements IVMInstallChangedListener
/*    */ {
/*    */   private boolean fChanged = false;
/*    */   
/*    */   public void defaultVMInstallChanged(IVMInstall previous, IVMInstall current) {
/* 35 */     this.fChanged = true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void vmAdded(IVMInstall vm) {
/* 43 */     this.fChanged = true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void vmChanged(PropertyChangeEvent event) {
/* 51 */     this.fChanged = true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void vmRemoved(IVMInstall vm) {
/* 59 */     this.fChanged = true;
/*    */   }
/*    */   
/*    */   public boolean isChanged() {
/* 63 */     return this.fChanged;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\VMListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */