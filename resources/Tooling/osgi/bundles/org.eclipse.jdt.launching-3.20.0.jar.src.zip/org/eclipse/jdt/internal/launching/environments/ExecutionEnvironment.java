/*     */ package org.eclipse.jdt.internal.launching.environments;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.jdt.core.IAccessRule;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.IJavaModel;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstallChangedListener;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.jdt.launching.LibraryLocation;
/*     */ import org.eclipse.jdt.launching.PropertyChangeEvent;
/*     */ import org.eclipse.jdt.launching.environments.IAccessRuleParticipant;
/*     */ import org.eclipse.jdt.launching.environments.IExecutionEnvironment;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.framework.Bundle;
/*     */ import org.osgi.framework.Version;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ExecutionEnvironment
/*     */   implements IExecutionEnvironment
/*     */ {
/*  66 */   private IVMInstallChangedListener fListener = new IVMInstallChangedListener()
/*     */     {
/*     */       public void defaultVMInstallChanged(IVMInstall previous, IVMInstall current) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void vmAdded(IVMInstall newVm) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void vmChanged(PropertyChangeEvent event) {
/*  85 */         if (event.getSource() != null) {
/*  86 */           ExecutionEnvironment.this.fParticipantMap.remove(event.getSource());
/*  87 */           ExecutionEnvironment.this.fRuleCache.remove(event.getSource());
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void vmRemoved(IVMInstall removedVm) {
/*  96 */         ExecutionEnvironment.this.fParticipantMap.remove(removedVm);
/*  97 */         ExecutionEnvironment.this.fRuleCache.remove(removedVm);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IConfigurationElement fElement;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IAccessRuleParticipant fRuleParticipant;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Properties fProfileProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fPropertiesInitialized;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   private Set<IVMInstall> fStrictlyCompatible = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   private List<IVMInstall> fCompatibleVMs = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   private IVMInstall fDefault = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   private IAccessRuleParticipant[] fParticipants = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   private Map<IVMInstall, Map<IAccessRuleParticipant, IAccessRule[][]>> fParticipantMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   private Map<IVMInstall, IAccessRule[][]> fRuleCache = (Map)new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   private static final IPath ALL_PATTERN = (IPath)new Path("**/*");
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String COMPILER_SETTING_PREFIX = "org.eclipse.jdt.core.compiler";
/*     */ 
/*     */   
/*     */   private static final String JAVASE = "JavaSE";
/*     */ 
/*     */ 
/*     */   
/*     */   ExecutionEnvironment(IConfigurationElement element) {
/* 172 */     this.fElement = element;
/* 173 */     this.fPropertiesInitialized = false;
/* 174 */     String attribute = this.fElement.getAttribute("ruleParticipant");
/* 175 */     if (attribute != null) {
/* 176 */       this.fRuleParticipant = new AccessRuleParticipant(this.fElement);
/*     */     }
/* 178 */     JavaRuntime.addVMInstallChangedListener(this.fListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 185 */     EnvironmentsManager.getDefault().initializeCompatibilities();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getId() {
/* 193 */     return this.fElement.getAttribute("id");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 201 */     return this.fElement.getAttribute("description");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IVMInstall[] getCompatibleVMs() {
/* 209 */     init();
/* 210 */     return this.fCompatibleVMs.<IVMInstall>toArray(new IVMInstall[this.fCompatibleVMs.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStrictlyCompatible(IVMInstall vm) {
/* 218 */     init();
/* 219 */     return this.fStrictlyCompatible.contains(vm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IVMInstall getDefaultVM() {
/* 227 */     init();
/* 228 */     return this.fDefault;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultVM(IVMInstall vm) {
/* 236 */     init();
/* 237 */     if (vm != null && !this.fCompatibleVMs.contains(vm)) {
/* 238 */       throw new IllegalArgumentException(NLS.bind(EnvironmentMessages.EnvironmentsManager_0, new String[] { getId() }));
/*     */     }
/* 240 */     if (vm != null && vm.equals(this.fDefault)) {
/*     */       return;
/*     */     }
/* 243 */     this.fDefault = vm;
/* 244 */     EnvironmentsManager.getDefault().updateDefaultVMs();
/*     */     
/* 246 */     rebindClasspathContainers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void rebindClasspathContainers() {
/* 253 */     IJavaModel model = JavaCore.create(ResourcesPlugin.getWorkspace().getRoot());
/* 254 */     if (model != null) {
/*     */       try {
/* 256 */         List<IJavaProject> updates = new ArrayList<>();
/* 257 */         IJavaProject[] javaProjects = model.getJavaProjects();
/* 258 */         IPath path = JavaRuntime.newJREContainerPath(this);
/* 259 */         for (int i = 0; i < javaProjects.length; i++) {
/* 260 */           IJavaProject project = javaProjects[i];
/* 261 */           IClasspathEntry[] rawClasspath = project.getRawClasspath();
/* 262 */           for (int j = 0; j < rawClasspath.length; j++) {
/* 263 */             IClasspathEntry entry = rawClasspath[j];
/* 264 */             if (entry.getEntryKind() == 5 && 
/* 265 */               entry.getPath().equals(path)) {
/* 266 */               updates.add(project);
/*     */             }
/*     */           } 
/*     */         } 
/*     */         
/* 271 */         if (!updates.isEmpty()) {
/* 272 */           JavaCore.setClasspathContainer(path, 
/* 273 */               updates.<IJavaProject>toArray(new IJavaProject[updates.size()]), 
/* 274 */               new org.eclipse.jdt.core.IClasspathContainer[updates.size()], 
/* 275 */               (IProgressMonitor)new NullProgressMonitor());
/*     */         }
/* 277 */       } catch (JavaModelException e) {
/* 278 */         LaunchingPlugin.log((Throwable)e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void add(IVMInstall vm, boolean strictlyCompatible) {
/* 291 */     if (this.fCompatibleVMs.contains(vm)) {
/*     */       return;
/*     */     }
/* 294 */     this.fCompatibleVMs.add(vm);
/* 295 */     if (strictlyCompatible) {
/* 296 */       this.fStrictlyCompatible.add(vm);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void remove(IVMInstall vm) {
/* 305 */     this.fCompatibleVMs.remove(vm);
/* 306 */     this.fStrictlyCompatible.remove(vm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initDefaultVM(IVMInstall vm) {
/* 314 */     this.fDefault = vm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IAccessRule[][] getAccessRules(IVMInstall vm, LibraryLocation[] libraries, IJavaProject project) {
/* 322 */     IAccessRuleParticipant[] participants = getParticipants();
/* 323 */     Map<IAccessRuleParticipant, IAccessRule[][]> rulesByParticipant = collectRulesByParticipant(participants, vm, libraries, project);
/* 324 */     synchronized (this) {
/* 325 */       Map<IAccessRuleParticipant, IAccessRule[][]> cachedRules = this.fParticipantMap.get(vm);
/* 326 */       if (cachedRules == null || !cachedRules.equals(rulesByParticipant)) {
/* 327 */         ArrayList<List<IAccessRule>> libLists = new ArrayList<>(); int i;
/* 328 */         for (i = 0; i < libraries.length; i++) {
/* 329 */           libLists.add(new ArrayList<>());
/*     */         }
/* 331 */         for (i = 0; i < participants.length; i++) {
/* 332 */           IAccessRuleParticipant participant = participants[i];
/* 333 */           addRules(rulesByParticipant.get(participant), libLists);
/*     */         } 
/* 335 */         IAccessRule[][] allRules = new IAccessRule[libraries.length][];
/* 336 */         for (int j = 0; j < libLists.size(); j++) {
/* 337 */           List<IAccessRule> l = libLists.get(j);
/* 338 */           allRules[j] = l.<IAccessRule>toArray(new IAccessRule[l.size()]);
/*     */         } 
/* 340 */         this.fParticipantMap.put(vm, rulesByParticipant);
/* 341 */         this.fRuleCache.put(vm, allRules);
/* 342 */         return allRules;
/*     */       } 
/* 344 */       return this.fRuleCache.get(vm);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized IAccessRuleParticipant[] getParticipants() {
/* 356 */     if (this.fParticipants == null) {
/*     */       
/* 358 */       IAccessRuleParticipant[] participants = EnvironmentsManager.getDefault().getAccessRuleParticipants();
/* 359 */       if (this.fRuleParticipant != null) {
/*     */         
/* 361 */         LinkedHashSet<IAccessRuleParticipant> set = new LinkedHashSet<>();
/* 362 */         for (int i = 0; i < participants.length; i++) {
/* 363 */           set.add(participants[i]);
/*     */         }
/*     */         
/* 366 */         set.remove(this.fRuleParticipant);
/* 367 */         set.add(this.fRuleParticipant);
/* 368 */         participants = (IAccessRuleParticipant[])set.toArray((Object[])new IAccessRuleParticipant[set.size()]);
/*     */       } 
/* 370 */       this.fParticipants = participants;
/*     */     } 
/* 372 */     return this.fParticipants;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<IAccessRuleParticipant, IAccessRule[][]> collectRulesByParticipant(IAccessRuleParticipant[] participants, IVMInstall vm, LibraryLocation[] libraries, IJavaProject project) {
/* 386 */     Map<IAccessRuleParticipant, IAccessRule[][]> map = (Map)new HashMap<>();
/* 387 */     for (int i = 0; i < participants.length; i++)
/*     */     {
/* 389 */       map.put(participants[i], participants[i].getAccessRules(this, vm, libraries, project));
/*     */     }
/* 391 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addRules(IAccessRule[][] accessRules, ArrayList<List<IAccessRule>> collect) {
/* 402 */     for (int i = 0; i < accessRules.length; i++) {
/* 403 */       IAccessRule[] libRules = accessRules[i];
/* 404 */       List<IAccessRule> list = collect.get(i);
/*     */       
/* 406 */       if (!list.isEmpty()) {
/* 407 */         IAccessRule lastRule = list.get(list.size() - 1);
/* 408 */         if (lastRule.getPattern().equals(ALL_PATTERN)) {
/*     */           continue;
/*     */         }
/*     */       } 
/* 412 */       for (int j = 0; j < libRules.length; j++) {
/* 413 */         list.add(libRules[j]);
/*     */       }
/*     */       continue;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Properties getProfileProperties() {
/* 423 */     if (!this.fPropertiesInitialized) {
/* 424 */       this.fPropertiesInitialized = true;
/* 425 */       String path = this.fElement.getAttribute("profileProperties");
/* 426 */       Bundle bundle = null;
/* 427 */       if (path == null) {
/*     */         
/* 429 */         bundle = Platform.getBundle("org.eclipse.osgi");
/* 430 */         path = String.valueOf(getId().replace('/', '_')) + ".profile";
/*     */       } else {
/*     */         
/* 433 */         bundle = Platform.getBundle(this.fElement.getContributor().getName());
/*     */       } 
/* 435 */       if (bundle != null && path != null) {
/* 436 */         this.fProfileProperties = getJavaProfileProperties(bundle, path);
/*     */       }
/*     */     } 
/* 439 */     return this.fProfileProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Properties getJavaProfileProperties(Bundle bundle, String path) {
/* 452 */     Properties profile = new Properties();
/* 453 */     URL profileURL = bundle.getEntry(path);
/* 454 */     if (profileURL != null) { try {
/* 455 */         Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 461 */       catch (IOException iOException) {
/* 462 */         return null;
/*     */       }  }
/*     */     else
/* 465 */     { String compliance = getCompliance();
/* 466 */       if (compliance == null) {
/* 467 */         return null;
/*     */       }
/* 469 */       profile.setProperty("org.eclipse.jdt.core.compiler.compliance", compliance);
/* 470 */       profile.setProperty("org.eclipse.jdt.core.compiler.source", compliance);
/* 471 */       profile.setProperty("org.eclipse.jdt.core.compiler.codegen.targetPlatform", compliance);
/* 472 */       profile.setProperty("org.eclipse.jdt.core.compiler.problem.assertIdentifier", "error");
/* 473 */       profile.setProperty("org.eclipse.jdt.core.compiler.problem.enumIdentifier", "error");
/* 474 */       profile.setProperty("org.osgi.framework.executionenvironment", calculateVMExecutionEnvs(new Version(compliance)));
/* 475 */       profile.setProperty("org.eclipse.jdt.core.compiler.release", "enabled");
/* 476 */       if (JavaCore.compareJavaVersions(compliance, "10") > 0) {
/* 477 */         profile.setProperty("org.eclipse.jdt.core.compiler.problem.enablePreviewFeatures", "disabled");
/* 478 */         profile.setProperty("org.eclipse.jdt.core.compiler.problem.reportPreviewFeatures", "warning");
/*     */       }  }
/*     */ 
/*     */ 
/*     */     
/* 483 */     String property = profile.getProperty("org.eclipse.jdt.core.compiler.compliance");
/* 484 */     if (property != null && 
/* 485 */       JavaCore.compareJavaVersions(property, "9") < 0) {
/* 486 */       profile.setProperty("org.eclipse.jdt.core.compiler.release", "disabled");
/*     */     }
/*     */     
/* 489 */     return profile;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String calculateVMExecutionEnvs(Version javaVersion) {
/* 495 */     StringBuilder result = new StringBuilder("OSGi/Minimum-1.0, OSGi/Minimum-1.1, OSGi/Minimum-1.2, JavaSE/compact1-1.8, JavaSE/compact2-1.8, JavaSE/compact3-1.8, JRE-1.1, J2SE-1.2, J2SE-1.3, J2SE-1.4, J2SE-1.5, JavaSE-1.6, JavaSE-1.7, JavaSE-1.8");
/* 496 */     Version v = new Version(9, 0, 0);
/* 497 */     while (v.compareTo(javaVersion) <= 0) {
/* 498 */       result.append(',').append(' ').append("JavaSE").append('-').append(v.getMajor());
/* 499 */       if (v.getMinor() > 0) {
/* 500 */         result.append('.').append(v.getMinor());
/*     */       }
/* 502 */       if (v.getMajor() == javaVersion.getMajor()) {
/* 503 */         v = new Version(v.getMajor(), v.getMinor() + 1, 0); continue;
/*     */       } 
/* 505 */       v = new Version(v.getMajor() + 1, 0, 0);
/*     */     } 
/*     */     
/* 508 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fixJavaSE9ComplianceSourceTargetLevels(Properties profile) {
/* 518 */     if ("JavaSE-9".equals(getId())) {
/* 519 */       profile.setProperty("org.eclipse.jdt.core.compiler.compliance", "9");
/* 520 */       profile.setProperty("org.eclipse.jdt.core.compiler.source", "9");
/* 521 */       profile.setProperty("org.eclipse.jdt.core.compiler.codegen.targetPlatform", "9");
/* 522 */       profile.setProperty("org.eclipse.jdt.core.compiler.release", "enabled");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IExecutionEnvironment[] getSubEnvironments() {
/* 531 */     Properties properties = getProfileProperties();
/* 532 */     Set<IExecutionEnvironment> subenv = new LinkedHashSet<>();
/* 533 */     if (properties != null) {
/*     */       
/* 535 */       String subsets = properties.getProperty("org.osgi.framework.executionenvironment");
/* 536 */       if (subsets != null) {
/* 537 */         String[] ids = subsets.split(",");
/* 538 */         for (int i = 0; i < ids.length; i++) {
/* 539 */           IExecutionEnvironment sub = JavaRuntime.getExecutionEnvironmentsManager().getEnvironment(ids[i].trim());
/* 540 */           if (sub != null && !sub.getId().equals(getId())) {
/* 541 */             subenv.add(sub);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 546 */     return subenv.<IExecutionEnvironment>toArray(new IExecutionEnvironment[subenv.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getComplianceOptions() {
/* 554 */     Properties properties = getProfileProperties();
/* 555 */     if (properties != null) {
/* 556 */       Map<String, String> map = new HashMap<>();
/* 557 */       Iterator<?> iterator = properties.keySet().iterator();
/* 558 */       while (iterator.hasNext()) {
/* 559 */         String key = (String)iterator.next();
/* 560 */         if (key.startsWith("org.eclipse.jdt.core.compiler")) {
/* 561 */           map.put(key, properties.getProperty(key));
/*     */         }
/*     */       } 
/* 564 */       if (!map.isEmpty()) {
/* 565 */         return map;
/*     */       }
/*     */     } 
/* 568 */     return null;
/*     */   }
/*     */   
/*     */   private String getCompliance() {
/* 572 */     return this.fElement.getAttribute("compliance");
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 577 */     return this.fElement.getAttribute("id");
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\environments\ExecutionEnvironment.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */