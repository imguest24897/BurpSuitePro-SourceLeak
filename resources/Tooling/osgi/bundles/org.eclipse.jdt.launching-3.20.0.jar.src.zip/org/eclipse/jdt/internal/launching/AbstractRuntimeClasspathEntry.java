/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry;
/*     */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry2;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractRuntimeClasspathEntry
/*     */   extends PlatformObject
/*     */   implements IRuntimeClasspathEntry2
/*     */ {
/*  43 */   private IPath sourceAttachmentPath = null;
/*  44 */   private IPath rootSourcePath = null;
/*  45 */   private IPath externalAnnotationsPath = null;
/*     */   
/*  47 */   private int classpathProperty = 3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IJavaProject fJavaProject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isComposite() {
/*  62 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IRuntimeClasspathEntry[] getRuntimeClasspathEntries() throws CoreException {
/*  73 */     return new IRuntimeClasspathEntry[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void abort(String message, Throwable exception) throws CoreException {
/*  84 */     Status status = new Status(4, LaunchingPlugin.getUniqueIdentifier(), 150, message, exception);
/*  85 */     throw new CoreException(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMemento() throws CoreException {
/*  99 */     Document doc = DebugPlugin.newDocument();
/* 100 */     Element root = doc.createElement("runtimeClasspathEntry");
/* 101 */     doc.appendChild(root);
/* 102 */     root.setAttribute("id", getTypeId());
/* 103 */     Element memento = doc.createElement("memento");
/* 104 */     root.appendChild(memento);
/* 105 */     buildMemento(doc, memento);
/* 106 */     return DebugPlugin.serializeDocument(doc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void buildMemento(Document paramDocument, Element paramElement) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getPath() {
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource getResource() {
/* 141 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getSourceAttachmentPath() {
/* 149 */     return this.sourceAttachmentPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceAttachmentPath(IPath path) {
/* 156 */     this.sourceAttachmentPath = path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getSourceAttachmentRootPath() {
/* 163 */     return this.rootSourcePath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceAttachmentRootPath(IPath path) {
/* 170 */     this.rootSourcePath = path;
/*     */   }
/*     */   
/*     */   public IPath getExternalAnnotationsPath() {
/* 174 */     return this.externalAnnotationsPath;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExternalAnnotationsPath(IPath path) {
/* 179 */     this.externalAnnotationsPath = path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getClasspathProperty() {
/* 187 */     return this.classpathProperty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClasspathProperty(int property) {
/* 194 */     this.classpathProperty = property;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocation() {
/* 205 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceAttachmentLocation() {
/* 216 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceAttachmentRootLocation() {
/* 226 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getVariableName() {
/* 237 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IClasspathEntry getClasspathEntry() {
/* 248 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IJavaProject getJavaProject() {
/* 255 */     return this.fJavaProject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setJavaProject(IJavaProject javaProject) {
/* 264 */     this.fJavaProject = javaProject;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAutomodule() {
/* 269 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\AbstractRuntimeClasspathEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */