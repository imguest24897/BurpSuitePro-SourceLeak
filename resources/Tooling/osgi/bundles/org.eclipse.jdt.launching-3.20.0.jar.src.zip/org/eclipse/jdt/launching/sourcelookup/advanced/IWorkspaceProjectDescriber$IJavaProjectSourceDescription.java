package org.eclipse.jdt.launching.sourcelookup.advanced;

import java.io.File;
import java.util.Map;
import java.util.function.Supplier;
import org.eclipse.debug.core.sourcelookup.ISourceContainer;
import org.eclipse.jdt.core.IPackageFragmentRoot;

public interface IJavaProjectSourceDescription {
  void addLocation(File paramFile);
  
  void addSourceContainerFactory(Supplier<ISourceContainer> paramSupplier);
  
  void addDependencies(Map<File, IPackageFragmentRoot> paramMap);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\sourcelookup\advanced\IWorkspaceProjectDescriber$IJavaProjectSourceDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */