/*    */ package org.eclipse.jdt.internal.launching.sourcelookup.advanced;
/*    */ 
/*    */ import org.eclipse.core.expressions.PropertyTester;
/*    */ import org.eclipse.debug.core.DebugException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JDIStratumPropertyTester
/*    */   extends PropertyTester
/*    */ {
/*    */   public boolean test(Object receiver, String property, Object[] args, Object expectedValue) {
/*    */     boolean result;
/*    */     try {
/* 28 */       result = (IJDIHelpers.INSTANCE.getClassesLocation(receiver) != null);
/*    */     }
/* 30 */     catch (DebugException debugException) {
/* 31 */       result = false;
/*    */     } 
/* 33 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\sourcelookup\advanced\JDIStratumPropertyTester.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */