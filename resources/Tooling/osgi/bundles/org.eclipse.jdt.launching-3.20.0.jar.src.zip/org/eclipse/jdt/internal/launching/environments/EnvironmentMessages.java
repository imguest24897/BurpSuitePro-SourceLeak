/*    */ package org.eclipse.jdt.internal.launching.environments;
/*    */ 
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnvironmentMessages
/*    */   extends NLS
/*    */ {
/*    */   private static final String BUNDLE_NAME = "org.eclipse.jdt.internal.launching.environments.EnvironmentMessages";
/*    */   public static String EnvironmentsManager_0;
/*    */   public static String ExecutionEnvironmentVariableResolver_0;
/*    */   public static String ExecutionEnvironmentVariableResolver_1;
/*    */   public static String ExecutionEnvironmentVariableResolver_2;
/*    */   
/*    */   static {
/* 30 */     NLS.initializeMessages("org.eclipse.jdt.internal.launching.environments.EnvironmentMessages", EnvironmentMessages.class);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\environments\EnvironmentMessages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */