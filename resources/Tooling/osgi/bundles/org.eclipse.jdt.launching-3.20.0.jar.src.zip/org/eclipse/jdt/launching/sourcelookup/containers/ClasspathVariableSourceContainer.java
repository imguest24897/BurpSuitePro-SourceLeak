/*    */ package org.eclipse.jdt.launching.sourcelookup.containers;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.CompositeSourceContainer;
/*    */ import org.eclipse.jdt.core.JavaCore;
/*    */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*    */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry;
/*    */ import org.eclipse.jdt.launching.JavaRuntime;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClasspathVariableSourceContainer
/*    */   extends CompositeSourceContainer
/*    */ {
/*    */   private IPath fVariable;
/* 42 */   public static final String TYPE_ID = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".sourceContainer.classpathVariable";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ClasspathVariableSourceContainer(IPath variablePath) {
/* 52 */     this.fVariable = variablePath;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ISourceContainer[] createSourceContainers() throws CoreException {
/* 60 */     IPath path = JavaCore.getClasspathVariable(this.fVariable.segment(0));
/* 61 */     if (path == null) {
/* 62 */       return new ISourceContainer[0];
/*    */     }
/* 64 */     if (this.fVariable.segmentCount() > 1) {
/* 65 */       path = path.append(this.fVariable.removeFirstSegments(1));
/*    */     }
/* 67 */     IRuntimeClasspathEntry entry = JavaRuntime.newArchiveRuntimeClasspathEntry(path);
/* 68 */     return JavaRuntime.getSourceContainers(new IRuntimeClasspathEntry[] { entry });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getName() {
/* 75 */     return this.fVariable.toOSString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IPath getPath() {
/* 86 */     return this.fVariable;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ISourceContainerType getType() {
/* 94 */     return getSourceContainerType(TYPE_ID);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\sourcelookup\containers\ClasspathVariableSourceContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */