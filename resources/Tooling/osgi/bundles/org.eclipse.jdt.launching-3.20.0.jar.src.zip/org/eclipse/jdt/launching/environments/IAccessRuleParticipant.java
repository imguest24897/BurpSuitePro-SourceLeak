package org.eclipse.jdt.launching.environments;

import org.eclipse.jdt.core.IAccessRule;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.launching.IVMInstall;
import org.eclipse.jdt.launching.LibraryLocation;

public interface IAccessRuleParticipant {
  IAccessRule[][] getAccessRules(IExecutionEnvironment paramIExecutionEnvironment, IVMInstall paramIVMInstall, LibraryLocation[] paramArrayOfLibraryLocation, IJavaProject paramIJavaProject);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\environments\IAccessRuleParticipant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */