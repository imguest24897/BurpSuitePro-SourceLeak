/*     */ package org.eclipse.jdt.launching.sourcelookup;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingMessages;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class DirectorySourceLocation
/*     */   extends PlatformObject
/*     */   implements IJavaSourceLocation
/*     */ {
/*     */   private File fDirectory;
/*     */   
/*     */   public DirectorySourceLocation() {}
/*     */   
/*     */   public DirectorySourceLocation(File directory) {
/*  81 */     setDirectory(directory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findSourceElement(String name) throws CoreException {
/*  89 */     if (getDirectory() == null) {
/*  90 */       return null;
/*     */     }
/*     */     
/*  93 */     String pathStr = name.replace('.', '/');
/*  94 */     int lastSlash = pathStr.lastIndexOf('/');
/*     */     try {
/*  96 */       Path path = new Path(getDirectory().getCanonicalPath());
/*  97 */       boolean possibleInnerType = false;
/*  98 */       String typeName = pathStr;
/*     */       do {
/* 100 */         IPath filePath = path.append((IPath)new Path(String.valueOf(typeName) + ".java"));
/* 101 */         File file = filePath.toFile();
/* 102 */         if (file.exists()) {
/* 103 */           return new LocalFileStorage(file);
/*     */         }
/* 105 */         int index = typeName.lastIndexOf('$');
/* 106 */         if (index > lastSlash) {
/* 107 */           typeName = typeName.substring(0, index);
/* 108 */           possibleInnerType = true;
/*     */         } else {
/* 110 */           possibleInnerType = false;
/*     */         } 
/* 112 */       } while (possibleInnerType);
/* 113 */     } catch (IOException e) {
/* 114 */       throw new CoreException(new Status(4, LaunchingPlugin.getUniqueIdentifier(), e.getMessage(), e));
/*     */     } 
/* 116 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setDirectory(File directory) {
/* 126 */     this.fDirectory = directory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getDirectory() {
/* 136 */     return this.fDirectory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 144 */     return (object instanceof DirectorySourceLocation && 
/* 145 */       getDirectory().equals(((DirectorySourceLocation)object).getDirectory()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 153 */     return getDirectory().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMemento() throws CoreException {
/* 161 */     Document doc = DebugPlugin.newDocument();
/* 162 */     Element node = doc.createElement("directorySourceLocation");
/* 163 */     doc.appendChild(node);
/* 164 */     node.setAttribute("path", getDirectory().getAbsolutePath());
/* 165 */     return DebugPlugin.serializeDocument(doc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeFrom(String memento) throws CoreException {
/* 173 */     Exception ex = null;
/*     */     try {
/* 175 */       Element root = null;
/* 176 */       DocumentBuilder parser = 
/* 177 */         DocumentBuilderFactory.newInstance().newDocumentBuilder();
/* 178 */       parser.setErrorHandler(new DefaultHandler());
/* 179 */       StringReader reader = new StringReader(memento);
/* 180 */       InputSource source = new InputSource(reader);
/* 181 */       root = parser.parse(source).getDocumentElement();
/*     */       
/* 183 */       String path = root.getAttribute("path");
/* 184 */       if (isEmpty(path)) {
/* 185 */         abort(LaunchingMessages.DirectorySourceLocation_Unable_to_initialize_source_location___missing_directory_path_3, null);
/*     */       } else {
/* 187 */         File dir = new File(path);
/* 188 */         if (dir.exists() && dir.isDirectory()) {
/* 189 */           setDirectory(dir);
/*     */         } else {
/* 191 */           abort(NLS.bind(LaunchingMessages.DirectorySourceLocation_Unable_to_initialize_source_location___directory_does_not_exist___0__4, (Object[])new String[] { path }), null);
/*     */         } 
/*     */       } 
/*     */       return;
/* 195 */     } catch (ParserConfigurationException e) {
/* 196 */       ex = e;
/* 197 */     } catch (SAXException e) {
/* 198 */       ex = e;
/* 199 */     } catch (IOException e) {
/* 200 */       ex = e;
/*     */     } 
/* 202 */     abort(LaunchingMessages.DirectorySourceLocation_Exception_occurred_initializing_source_location__5, ex);
/*     */   }
/*     */   
/*     */   private boolean isEmpty(String string) {
/* 206 */     return !(string != null && string.length() != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void abort(String message, Throwable e) throws CoreException {
/* 213 */     Status status = new Status(4, LaunchingPlugin.getUniqueIdentifier(), 150, message, e);
/* 214 */     throw new CoreException(status);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\sourcelookup\DirectorySourceLocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */