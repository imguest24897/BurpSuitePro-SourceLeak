package org.eclipse.jdt.launching;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.debug.core.ILaunchConfiguration;

public interface IRuntimeClasspathProvider {
  IRuntimeClasspathEntry[] computeUnresolvedClasspath(ILaunchConfiguration paramILaunchConfiguration) throws CoreException;
  
  IRuntimeClasspathEntry[] resolveClasspath(IRuntimeClasspathEntry[] paramArrayOfIRuntimeClasspathEntry, ILaunchConfiguration paramILaunchConfiguration) throws CoreException;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\IRuntimeClasspathProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */