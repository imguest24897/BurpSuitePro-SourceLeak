/*     */ package org.eclipse.jdt.internal.launching.environments;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstallChangedListener;
/*     */ import org.eclipse.jdt.launching.IVMInstallType;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.jdt.launching.PropertyChangeEvent;
/*     */ import org.eclipse.jdt.launching.environments.CompatibleEnvironment;
/*     */ import org.eclipse.jdt.launching.environments.IAccessRuleParticipant;
/*     */ import org.eclipse.jdt.launching.environments.IExecutionEnvironment;
/*     */ import org.eclipse.jdt.launching.environments.IExecutionEnvironmentsManager;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnvironmentsManager
/*     */   implements IExecutionEnvironmentsManager, IVMInstallChangedListener, IEclipsePreferences.IPreferenceChangeListener
/*     */ {
/*     */   private static final String ANALYZER_ELEMENT = "analyzer";
/*     */   static final String ENVIRONMENT_ELEMENT = "environment";
/*     */   static final String RULE_PARTICIPANT_ELEMENT = "ruleParticipant";
/*  80 */   private static EnvironmentsManager fgManager = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String PREF_DEFAULT_ENVIRONMENTS_XML = "org.eclipse.jdt.launching.PREF_DEFAULT_ENVIRONMENTS_XML";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   private TreeSet<IExecutionEnvironment> fEnvironments = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   private Set<AccessRuleParticipant> fRuleParticipants = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private Map<String, IExecutionEnvironment> fEnvironmentsMap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   private Map<String, Analyzer> fAnalyzers = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fIsUpdatingDefaults = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean fInitializedCompatibilities = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String VM_ID = "vmId";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String ENVIRONMENT_ID = "environmentId";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_ENVIRONMENT = "defaultEnvironment";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_ENVIRONMENTS = "defaultEnvironments";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnvironmentsManager getDefault() {
/* 143 */     if (fgManager == null) {
/* 144 */       fgManager = new EnvironmentsManager();
/*     */     }
/* 146 */     return fgManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EnvironmentsManager() {
/* 153 */     JavaRuntime.addVMInstallChangedListener(this);
/* 154 */     InstanceScope.INSTANCE.getNode("org.eclipse.jdt.launching").addPreferenceChangeListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized IExecutionEnvironment[] getExecutionEnvironments() {
/* 162 */     initializeExtensions();
/* 163 */     return (IExecutionEnvironment[])this.fEnvironments.toArray((Object[])new IExecutionEnvironment[this.fEnvironments.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized IAccessRuleParticipant[] getAccessRuleParticipants() {
/* 173 */     initializeExtensions();
/* 174 */     return this.fRuleParticipants.<IAccessRuleParticipant>toArray(new IAccessRuleParticipant[this.fRuleParticipants.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized IExecutionEnvironment getEnvironment(String id) {
/* 182 */     initializeExtensions();
/* 183 */     return this.fEnvironmentsMap.get(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Analyzer[] getAnalyzers() {
/* 192 */     initializeExtensions();
/* 193 */     Collection<Analyzer> collection = this.fAnalyzers.values();
/* 194 */     return collection.<Analyzer>toArray(new Analyzer[collection.size()]);
/*     */   }
/*     */   
/*     */   private String getExecutionEnvironmentCompliance(IExecutionEnvironment executionEnvironment) {
/* 198 */     String desc = executionEnvironment.getId();
/* 199 */     if (desc.indexOf("20") != -1)
/* 200 */       return "20"; 
/* 201 */     if (desc.indexOf("19") != -1)
/* 202 */       return "19"; 
/* 203 */     if (desc.indexOf("18") != -1)
/* 204 */       return "18"; 
/* 205 */     if (desc.indexOf("17") != -1)
/* 206 */       return "17"; 
/* 207 */     if (desc.indexOf("16") != -1)
/* 208 */       return "16"; 
/* 209 */     if (desc.indexOf("15") != -1)
/* 210 */       return "15"; 
/* 211 */     if (desc.indexOf("14") != -1)
/* 212 */       return "14"; 
/* 213 */     if (desc.indexOf("13") != -1)
/* 214 */       return "13"; 
/* 215 */     if (desc.indexOf("12") != -1)
/* 216 */       return "12"; 
/* 217 */     if (desc.indexOf("11") != -1)
/* 218 */       return "11"; 
/* 219 */     if (desc.indexOf("10") != -1)
/* 220 */       return "10"; 
/* 221 */     if (desc.indexOf("9") != -1)
/* 222 */       return "9"; 
/* 223 */     if (desc.indexOf("1.8") != -1)
/* 224 */       return "1.8"; 
/* 225 */     if (desc.indexOf("1.7") != -1)
/* 226 */       return "1.7"; 
/* 227 */     if (desc.indexOf("1.6") != -1)
/* 228 */       return "1.6"; 
/* 229 */     if (desc.indexOf("1.5") != -1)
/* 230 */       return "1.5"; 
/* 231 */     if (desc.indexOf("1.4") != -1)
/* 232 */       return "1.4"; 
/* 233 */     if (desc.indexOf("1.3") != -1)
/* 234 */       return "1.3"; 
/* 235 */     if (desc.indexOf("1.2") != -1)
/* 236 */       return "1.2"; 
/* 237 */     if (desc.indexOf("1.1") != -1)
/* 238 */       return "1.1"; 
/* 239 */     if (desc.indexOf("1.0") != -1) {
/* 240 */       return "1.0";
/*     */     }
/* 242 */     return "1.3";
/*     */   }
/*     */   
/*     */   private synchronized void initializeExtensions() {
/* 246 */     if (this.fEnvironments == null) {
/* 247 */       IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.jdt.launching", "executionEnvironments");
/* 248 */       IConfigurationElement[] configs = extensionPoint.getConfigurationElements();
/* 249 */       this.fEnvironments = new TreeSet<>(new Comparator<IExecutionEnvironment>()
/*     */           {
/*     */             public int compare(IExecutionEnvironment o1, IExecutionEnvironment o2) {
/* 252 */               String compliance1 = EnvironmentsManager.this.getExecutionEnvironmentCompliance(o1);
/* 253 */               String compliance2 = EnvironmentsManager.this.getExecutionEnvironmentCompliance(o2);
/* 254 */               int result = JavaCore.compareJavaVersions(compliance1, compliance2);
/* 255 */               if (result == 0) {
/* 256 */                 return o1.getId().compareTo(o2.getId());
/*     */               }
/* 258 */               return result;
/*     */             }
/*     */           });
/* 261 */       this.fRuleParticipants = new LinkedHashSet<>();
/* 262 */       this.fEnvironmentsMap = new HashMap<>(configs.length);
/* 263 */       this.fAnalyzers = new HashMap<>(configs.length);
/* 264 */       for (int i = 0; i < configs.length; i++) {
/* 265 */         String id; IExecutionEnvironment env; IConfigurationElement element = configs[i];
/* 266 */         String name = element.getName(); String str1;
/* 267 */         switch ((str1 = name).hashCode()) { case -1024439130: if (!str1.equals("analyzer")) {
/*     */               break;
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 280 */             id = element.getAttribute("id");
/* 281 */             if (id == null) {
/* 282 */               LaunchingPlugin.log(NLS.bind("Execution environment analyzer must specify \"id\" attribute. Contributed by {0}", (Object[])new String[] {
/* 283 */                       element.getContributor().getName() })); break;
/*     */             } 
/* 285 */             this.fAnalyzers.put(id, new Analyzer(element)); break;
/*     */           case -85904877: if (!str1.equals("environment"))
/*     */               break;  id = element.getAttribute("id"); if (id == null) { LaunchingPlugin.log(NLS.bind("Execution environment must specify \"id\" attribute. Contributed by {0}.", (Object[])new String[] { element.getContributor().getName() })); break; }  env = new ExecutionEnvironment(element); this.fEnvironments.add(env); this.fEnvironmentsMap.put(id, env); break;
/*     */           case 2006387351: if (!str1.equals("ruleParticipant"))
/* 289 */               break;  id = element.getAttribute("id");
/* 290 */             if (id == null) {
/* 291 */               LaunchingPlugin.log(NLS.bind("Execution environment rule participant must specify \"id\" attribute. Contributed by {0}", (Object[])new String[] {
/* 292 */                       element.getContributor().getName() }));
/*     */               break;
/*     */             } 
/* 295 */             this.fRuleParticipants.add(new AccessRuleParticipant(element));
/*     */             break; }
/*     */       
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initializeCompatibilities() {
/* 309 */     IVMInstallType[] installTypes = JavaRuntime.getVMInstallTypes();
/* 310 */     synchronized (this) {
/* 311 */       if (!this.fInitializedCompatibilities) {
/* 312 */         this.fInitializedCompatibilities = true;
/* 313 */         for (int i = 0; i < installTypes.length; i++) {
/* 314 */           IVMInstallType type = installTypes[i];
/* 315 */           IVMInstall[] installs = type.getVMInstalls();
/* 316 */           for (int j = 0; j < installs.length; j++) {
/* 317 */             IVMInstall install = installs[j];
/*     */             
/* 319 */             analyze(install, (IProgressMonitor)new NullProgressMonitor());
/*     */           } 
/*     */         } 
/* 322 */         initializeDefaultVMs();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void initializeDefaultVMs() {
/* 331 */     String xml = InstanceScope.INSTANCE.getNode("org.eclipse.jdt.launching").get("org.eclipse.jdt.launching.PREF_DEFAULT_ENVIRONMENTS_XML", "");
/*     */     try {
/* 333 */       if (xml.length() > 0) {
/* 334 */         DocumentBuilder parser = LaunchingPlugin.getParser();
/*     */         
/* 336 */         Document document = parser.parse(new ByteArrayInputStream(xml.getBytes()));
/* 337 */         Element envs = document.getDocumentElement();
/* 338 */         NodeList list = envs.getChildNodes();
/* 339 */         int length = list.getLength();
/* 340 */         for (int i = 0; i < length; i++) {
/* 341 */           Node node = list.item(i);
/* 342 */           short type = node.getNodeType();
/* 343 */           if (type == 1) {
/* 344 */             Element element = (Element)node;
/* 345 */             if (element.getNodeName().equals("defaultEnvironment")) {
/* 346 */               String envId = element.getAttribute("environmentId");
/* 347 */               String vmId = element.getAttribute("vmId");
/* 348 */               ExecutionEnvironment environment = (ExecutionEnvironment)getEnvironment(envId);
/* 349 */               if (environment != null) {
/* 350 */                 IVMInstall vm = JavaRuntime.getVMFromCompositeId(vmId);
/* 351 */                 if (vm != null) {
/* 352 */                   environment.initDefaultVM(vm);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 359 */     } catch (CoreException e) {
/* 360 */       LaunchingPlugin.log((Throwable)e);
/* 361 */     } catch (SAXException e) {
/* 362 */       LaunchingPlugin.log(e);
/* 363 */     } catch (IOException e) {
/* 364 */       LaunchingPlugin.log(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getDefatulVMsAsXML() {
/* 375 */     int count = 0;
/*     */     try {
/* 377 */       Document doc = DebugPlugin.newDocument();
/* 378 */       Element envs = doc.createElement("defaultEnvironments");
/* 379 */       doc.appendChild(envs);
/* 380 */       IExecutionEnvironment[] environments = getExecutionEnvironments();
/* 381 */       for (int i = 0; i < environments.length; i++) {
/* 382 */         IExecutionEnvironment env = environments[i];
/* 383 */         IVMInstall vm = env.getDefaultVM();
/* 384 */         if (vm != null) {
/* 385 */           count++;
/* 386 */           Element element = doc.createElement("defaultEnvironment");
/* 387 */           element.setAttribute("environmentId", env.getId());
/* 388 */           element.setAttribute("vmId", JavaRuntime.getCompositeIdFromVM(vm));
/* 389 */           envs.appendChild(element);
/*     */         } 
/*     */       } 
/* 392 */       if (count > 0) {
/* 393 */         return DebugPlugin.serializeDocument(doc);
/*     */       }
/* 395 */     } catch (CoreException e) {
/* 396 */       LaunchingPlugin.log((Throwable)e);
/*     */     } 
/* 398 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void analyze(IVMInstall vm, IProgressMonitor monitor) {
/* 408 */     Analyzer[] analyzers = getAnalyzers();
/* 409 */     for (int i = 0; i < analyzers.length; i++) {
/* 410 */       Analyzer analyzer = analyzers[i];
/*     */       try {
/* 412 */         CompatibleEnvironment[] environments = analyzer.analyze(vm, monitor);
/* 413 */         for (int j = 0; j < environments.length; j++) {
/* 414 */           CompatibleEnvironment compatibleEnvironment = environments[j];
/* 415 */           ExecutionEnvironment environment = (ExecutionEnvironment)compatibleEnvironment.getCompatibleEnvironment();
/* 416 */           environment.add(vm, compatibleEnvironment.isStrictlyCompatbile());
/*     */         } 
/* 418 */       } catch (CoreException e) {
/* 419 */         LaunchingPlugin.log((Throwable)e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void defaultVMInstallChanged(IVMInstall previous, IVMInstall current) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void vmChanged(PropertyChangeEvent event) {
/* 437 */     IVMInstall vm = (IVMInstall)event.getSource();
/* 438 */     if (vm instanceof org.eclipse.jdt.launching.VMStandin) {
/*     */       return;
/*     */     }
/* 441 */     vmRemoved(vm);
/* 442 */     vmAdded(vm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void vmAdded(IVMInstall vm) {
/* 451 */     if (vm instanceof org.eclipse.jdt.launching.VMStandin) {
/*     */       return;
/*     */     }
/* 454 */     analyze(vm, (IProgressMonitor)new NullProgressMonitor());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void vmRemoved(IVMInstall vm) {
/* 462 */     if (vm instanceof org.eclipse.jdt.launching.VMStandin) {
/*     */       return;
/*     */     }
/* 465 */     IExecutionEnvironment[] environments = getExecutionEnvironments();
/* 466 */     for (int i = 0; i < environments.length; i++) {
/* 467 */       ExecutionEnvironment environment = (ExecutionEnvironment)environments[i];
/* 468 */       environment.remove(vm);
/*     */     } 
/*     */   }
/*     */   
/*     */   synchronized void updateDefaultVMs() {
/*     */     try {
/* 474 */       this.fIsUpdatingDefaults = true;
/* 475 */       InstanceScope.INSTANCE.getNode("org.eclipse.jdt.launching").put("org.eclipse.jdt.launching.PREF_DEFAULT_ENVIRONMENTS_XML", getDefatulVMsAsXML());
/*     */     } finally {
/* 477 */       this.fIsUpdatingDefaults = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void preferenceChange(IEclipsePreferences.PreferenceChangeEvent event) {
/* 487 */     if (this.fIsUpdatingDefaults) {
/*     */       return;
/*     */     }
/* 490 */     if (event.getKey().equals("org.eclipse.jdt.launching.PREF_DEFAULT_ENVIRONMENTS_XML"))
/* 491 */       initializeDefaultVMs(); 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\environments\EnvironmentsManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */