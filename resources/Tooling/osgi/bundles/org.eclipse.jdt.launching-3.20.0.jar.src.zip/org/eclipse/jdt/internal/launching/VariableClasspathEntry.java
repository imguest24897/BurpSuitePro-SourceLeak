/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VariableClasspathEntry
/*     */   extends AbstractRuntimeClasspathEntry
/*     */ {
/*     */   public static final String TYPE_ID = "org.eclipse.jdt.launching.classpathentry.variableClasspathEntry";
/*     */   private String variableString;
/*     */   
/*     */   public VariableClasspathEntry() {}
/*     */   
/*     */   public VariableClasspathEntry(String variableString) {
/*  41 */     this.variableString = variableString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void buildMemento(Document document, Element memento) throws CoreException {
/*  49 */     memento.setAttribute("variableString", this.variableString);
/*  50 */     memento.setAttribute("path", Integer.toString(getClasspathProperty()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeFrom(Element memento) throws CoreException {
/*  58 */     this.variableString = memento.getAttribute("variableString");
/*  59 */     String property = memento.getAttribute("path");
/*  60 */     if (property != null && !"".equals(property)) {
/*     */       try {
/*  62 */         setClasspathProperty(Integer.parseInt(property));
/*     */       }
/*  64 */       catch (NumberFormatException numberFormatException) {}
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTypeId() {
/*  74 */     return "org.eclipse.jdt.launching.classpathentry.variableClasspathEntry";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IRuntimeClasspathEntry[] getRuntimeClasspathEntries(ILaunchConfiguration configuration) throws CoreException {
/*  82 */     return new IRuntimeClasspathEntry[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  90 */     return this.variableString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getType() {
/*  98 */     return 5;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getVariableString() {
/* 104 */     return this.variableString;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVariableString(String variableString) {
/* 110 */     this.variableString = variableString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 118 */     if (this.variableString != null) {
/* 119 */       return this.variableString.hashCode();
/*     */     }
/* 121 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 129 */     if (obj instanceof VariableClasspathEntry) {
/* 130 */       VariableClasspathEntry other = (VariableClasspathEntry)obj;
/* 131 */       if (this.variableString != null) {
/* 132 */         return this.variableString.equals(other.variableString);
/*     */       }
/*     */     } 
/* 135 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\VariableClasspathEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */