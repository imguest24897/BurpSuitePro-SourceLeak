/*     */ package org.eclipse.jdt.launching;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardSourcePathProvider
/*     */   extends StandardClasspathProvider
/*     */ {
/*     */   public IRuntimeClasspathEntry[] computeUnresolvedClasspath(ILaunchConfiguration configuration) throws CoreException {
/*  47 */     boolean useDefault = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_DEFAULT_SOURCE_PATH, true);
/*  48 */     IRuntimeClasspathEntry[] entries = null;
/*  49 */     if (useDefault) {
/*     */       
/*  51 */       entries = super.computeUnresolvedClasspath(configuration);
/*     */     } else {
/*     */       
/*  54 */       entries = recoverRuntimePath(configuration, IJavaLaunchConfigurationConstants.ATTR_SOURCE_PATH);
/*     */     } 
/*  56 */     return entries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IRuntimeClasspathEntry[] resolveClasspath(IRuntimeClasspathEntry[] entries, ILaunchConfiguration configuration) throws CoreException {
/*  65 */     List<IRuntimeClasspathEntry> all = new UniqueList(entries.length);
/*  66 */     for (int i = 0; i < entries.length; i++) {
/*  67 */       IRuntimeClasspathEntry2 entry; String typeId; IRuntimeClasspathEntry[] res; String str1; IRuntimeClasspathEntry[] resolved; int j; switch (entries[i].getType()) {
/*     */         
/*     */         case 1:
/*  70 */           all.add(entries[i]);
/*     */           break;
/*     */         case 5:
/*  73 */           entry = (IRuntimeClasspathEntry2)entries[i];
/*  74 */           typeId = entry.getTypeId();
/*  75 */           res = null;
/*  76 */           switch ((str1 = typeId).hashCode()) { case 1232062086: if (str1.equals("org.eclipse.jdt.launching.classpathentry.variableClasspathEntry"))
/*     */               
/*     */               { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*  84 */                 res = JavaRuntime.resolveRuntimeClasspathEntry(entry, configuration); break; } 
/*     */             case 1960146993: if (str1.equals("org.eclipse.jdt.launching.classpathentry.defaultClasspath")) { IRuntimeClasspathEntry[] children = entry.getRuntimeClasspathEntries(configuration); res = JavaRuntime.resolveSourceLookupPath(children, configuration); break; } 
/*     */             default:
/*  87 */               res = JavaRuntime.resolveRuntimeClasspathEntry(entry, configuration);
/*     */               break; }
/*     */           
/*  90 */           if (res != null) {
/*  91 */             for (int k = 0; k < res.length; k++) {
/*  92 */               all.add(res[k]);
/*  93 */               addManifestReferences(res[k], all);
/*     */             } 
/*     */           }
/*     */           break;
/*     */         
/*     */         default:
/*  99 */           resolved = JavaRuntime.resolveRuntimeClasspathEntry(entries[i], configuration);
/* 100 */           for (j = 0; j < resolved.length; j++) {
/* 101 */             all.add(resolved[j]);
/* 102 */             addManifestReferences(resolved[j], all);
/*     */           } 
/*     */           break;
/*     */       } 
/*     */     } 
/* 107 */     return all.<IRuntimeClasspathEntry>toArray(new IRuntimeClasspathEntry[all.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addManifestReferences(IRuntimeClasspathEntry entry, List<IRuntimeClasspathEntry> all) {
/* 117 */     if (entry.getType() == 2) {
/* 118 */       String location = entry.getLocation();
/* 119 */       if (location != null) {
/* 120 */         try { Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */            }
/*     */         
/* 142 */         catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   class UniqueList
/*     */     extends ArrayList<IRuntimeClasspathEntry>
/*     */   {
/*     */     private static final long serialVersionUID = -7402160651027036270L;
/*     */     
/*     */     HashSet<IRuntimeClasspathEntry> set;
/*     */ 
/*     */     
/*     */     public UniqueList(int length) {
/* 157 */       super(length);
/* 158 */       this.set = new HashSet<>(length);
/*     */     }
/*     */ 
/*     */     
/*     */     public void add(int index, IRuntimeClasspathEntry element) {
/* 163 */       if (this.set.add(element)) {
/* 164 */         super.add(index, element);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean add(IRuntimeClasspathEntry o) {
/* 170 */       if (this.set.add(o)) {
/* 171 */         return super.add(o);
/*     */       }
/* 173 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(Collection<? extends IRuntimeClasspathEntry> c) {
/* 178 */       if (this.set.addAll(c)) {
/* 179 */         return super.addAll(c);
/*     */       }
/* 181 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean addAll(int index, Collection<? extends IRuntimeClasspathEntry> c) {
/* 186 */       if (this.set.addAll(c)) {
/* 187 */         return super.addAll(index, c);
/*     */       }
/* 189 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 194 */       this.set.clear();
/* 195 */       super.clear();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean contains(Object elem) {
/* 200 */       return this.set.contains(elem);
/*     */     }
/*     */ 
/*     */     
/*     */     public void ensureCapacity(int minCapacity) {
/* 205 */       super.ensureCapacity(minCapacity);
/*     */     }
/*     */ 
/*     */     
/*     */     public IRuntimeClasspathEntry remove(int index) {
/* 210 */       IRuntimeClasspathEntry object = super.remove(index);
/* 211 */       this.set.remove(object);
/* 212 */       return object;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void removeRange(int fromIndex, int toIndex) {
/* 217 */       for (int index = fromIndex; index <= toIndex; index++) {
/* 218 */         remove(index);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public IRuntimeClasspathEntry set(int index, IRuntimeClasspathEntry element) {
/* 224 */       this.set.remove(element);
/* 225 */       if (this.set.add(element)) {
/* 226 */         return super.set(index, element);
/*     */       }
/* 228 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\StandardSourcePathProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */