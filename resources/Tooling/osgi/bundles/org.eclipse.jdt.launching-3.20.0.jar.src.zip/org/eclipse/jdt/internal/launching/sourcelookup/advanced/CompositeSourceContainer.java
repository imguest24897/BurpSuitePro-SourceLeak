/*    */ package org.eclipse.jdt.internal.launching.sourcelookup.advanced;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.CompositeSourceContainer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompositeSourceContainer
/*    */   extends CompositeSourceContainer
/*    */ {
/*    */   private final ISourceContainer[] members;
/*    */   
/*    */   private CompositeSourceContainer(Collection<ISourceContainer> members) {
/* 28 */     this.members = members.<ISourceContainer>toArray(new ISourceContainer[members.size()]);
/*    */   }
/*    */ 
/*    */   
/*    */   public ISourceContainer[] getSourceContainers() throws CoreException {
/* 33 */     return this.members;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 38 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public ISourceContainerType getType() {
/* 43 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   protected ISourceContainer[] createSourceContainers() throws CoreException {
/* 48 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void dispose() {
/* 53 */     super.dispose(); byte b; int i; ISourceContainer[] arrayOfISourceContainer;
/* 54 */     for (i = (arrayOfISourceContainer = this.members).length, b = 0; b < i; ) { ISourceContainer member = arrayOfISourceContainer[b];
/* 55 */       member.dispose(); b++; }
/*    */     
/* 57 */     Arrays.fill((Object[])this.members, (Object)null);
/*    */   }
/*    */   
/*    */   public static ISourceContainer compose(Collection<ISourceContainer> containers) {
/* 61 */     if (containers.isEmpty()) {
/* 62 */       throw new IllegalArgumentException();
/*    */     }
/* 64 */     if (containers.size() == 1) {
/* 65 */       return containers.iterator().next();
/*    */     }
/* 67 */     return (ISourceContainer)new CompositeSourceContainer(containers);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\sourcelookup\advanced\CompositeSourceContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */