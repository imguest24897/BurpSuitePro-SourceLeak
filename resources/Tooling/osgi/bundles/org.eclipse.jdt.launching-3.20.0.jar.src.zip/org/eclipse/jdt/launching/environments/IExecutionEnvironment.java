package org.eclipse.jdt.launching.environments;

import java.util.Map;
import java.util.Properties;
import org.eclipse.jdt.core.IAccessRule;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.launching.IVMInstall;
import org.eclipse.jdt.launching.LibraryLocation;

public interface IExecutionEnvironment {
  String getId();
  
  String getDescription();
  
  IVMInstall[] getCompatibleVMs();
  
  boolean isStrictlyCompatible(IVMInstall paramIVMInstall);
  
  IVMInstall getDefaultVM();
  
  void setDefaultVM(IVMInstall paramIVMInstall);
  
  IAccessRule[][] getAccessRules(IVMInstall paramIVMInstall, LibraryLocation[] paramArrayOfLibraryLocation, IJavaProject paramIJavaProject);
  
  Properties getProfileProperties();
  
  IExecutionEnvironment[] getSubEnvironments();
  
  Map<String, String> getComplianceOptions();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\environments\IExecutionEnvironment.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */