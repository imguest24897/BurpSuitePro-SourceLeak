/*     */ package org.eclipse.jdt.launching;
/*     */ 
/*     */ import java.net.URL;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingMessages;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LibraryLocation
/*     */ {
/*     */   private IPath fSystemLibrary;
/*     */   private IPath fSystemLibrarySource;
/*     */   private IPath fExternalAnnotations;
/*     */   private IPath fPackageRootPath;
/*     */   private URL fJavadocLocation;
/*     */   private URL fIndexLocation;
/*     */   
/*     */   public LibraryLocation(IPath libraryPath, IPath sourcePath, IPath packageRoot) {
/*  55 */     this(libraryPath, sourcePath, packageRoot, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LibraryLocation(IPath libraryPath, IPath sourcePath, IPath packageRoot, URL javadocLocation) {
/*  75 */     this(libraryPath, sourcePath, packageRoot, javadocLocation, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LibraryLocation(IPath libraryPath, IPath sourcePath, IPath packageRoot, URL javadocLocation, URL indexLocation) {
/*  96 */     this(libraryPath, sourcePath, packageRoot, javadocLocation, indexLocation, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LibraryLocation(IPath libraryPath, IPath sourcePath, IPath packageRoot, URL javadocLocation, URL indexLocation, IPath externalAnnotations) {
/* 118 */     if (libraryPath == null) {
/* 119 */       throw new IllegalArgumentException(LaunchingMessages.libraryLocation_assert_libraryNotNull);
/*     */     }
/* 121 */     this.fSystemLibrary = libraryPath;
/* 122 */     this.fSystemLibrarySource = sourcePath;
/* 123 */     this.fPackageRootPath = packageRoot;
/* 124 */     this.fJavadocLocation = javadocLocation;
/* 125 */     this.fIndexLocation = indexLocation;
/* 126 */     this.fExternalAnnotations = (externalAnnotations == null) ? (IPath)Path.EMPTY : externalAnnotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getSystemLibraryPath() {
/* 135 */     return this.fSystemLibrary;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getSystemLibrarySourcePath() {
/* 144 */     return this.fSystemLibrarySource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getExternalAnnotationsPath() {
/* 154 */     return this.fExternalAnnotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getPackageRootPath() {
/* 163 */     return this.fPackageRootPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getJavadocLocation() {
/* 174 */     return this.fJavadocLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getIndexLocation() {
/* 185 */     return this.fIndexLocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 193 */     if (obj instanceof LibraryLocation) {
/* 194 */       LibraryLocation lib = (LibraryLocation)obj;
/* 195 */       return (getSystemLibraryPath().equals(lib.getSystemLibraryPath()) && 
/* 196 */         equals(getSystemLibrarySourcePath(), lib.getSystemLibrarySourcePath()) && 
/* 197 */         equals(getExternalAnnotationsPath(), lib.getExternalAnnotationsPath()) && 
/* 198 */         equals(getPackageRootPath(), lib.getPackageRootPath()) && 
/* 199 */         LaunchingPlugin.sameURL(getJavadocLocation(), lib.getJavadocLocation()));
/*     */     } 
/* 201 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 209 */     return getSystemLibraryPath().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean equals(IPath path1, IPath path2) {
/* 219 */     return equalsOrNull(path1, path2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean equalsOrNull(Object o1, Object o2) {
/* 230 */     if (o1 == null) {
/* 231 */       return (o2 == null);
/*     */     }
/* 233 */     if (o2 == null) {
/* 234 */       return false;
/*     */     }
/* 236 */     return o1.equals(o2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSystemLibrarySource(IPath source) {
/* 246 */     this.fSystemLibrarySource = source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIndexLocation(URL indexLoc) {
/* 256 */     this.fIndexLocation = indexLoc;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\LibraryLocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */