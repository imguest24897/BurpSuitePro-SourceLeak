package org.eclipse.jdt.launching;

import java.io.File;
import org.eclipse.core.runtime.IStatus;

public interface IVMInstallType {
  IVMInstall createVMInstall(String paramString);
  
  IVMInstall findVMInstall(String paramString);
  
  IVMInstall findVMInstallByName(String paramString);
  
  void disposeVMInstall(String paramString);
  
  IVMInstall[] getVMInstalls();
  
  String getName();
  
  String getId();
  
  IStatus validateInstallLocation(File paramFile);
  
  File detectInstallLocation();
  
  LibraryLocation[] getDefaultLibraryLocations(File paramFile);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\IVMInstallType.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */