/*     */ package org.eclipse.jdt.launching.sourcelookup;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingMessages;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class JavaProjectSourceLocation
/*     */   extends PlatformObject
/*     */   implements IJavaSourceLocation
/*     */ {
/*     */   private IJavaProject fProject;
/*  72 */   private IJavaSourceLocation[] fRootLocations = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaProjectSourceLocation() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaProjectSourceLocation(IJavaProject project) {
/*  88 */     setJavaProject(project);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findSourceElement(String name) throws CoreException {
/*  96 */     if (this.fRootLocations != null) {
/*  97 */       for (int i = 0; i < this.fRootLocations.length; i++) {
/*  98 */         Object element = this.fRootLocations[i].findSourceElement(name);
/*  99 */         if (element != null) {
/* 100 */           return element;
/*     */         }
/*     */       } 
/*     */     }
/* 104 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setJavaProject(IJavaProject project) {
/* 114 */     this.fProject = project;
/* 115 */     this.fRootLocations = null;
/* 116 */     if (this.fProject != null) {
/*     */       try {
/* 118 */         IPackageFragmentRoot[] roots = project.getPackageFragmentRoots();
/* 119 */         ArrayList<PackageFragmentRootSourceLocation> list = new ArrayList<>(roots.length);
/*     */         
/* 121 */         for (int i = 0; i < roots.length; i++) {
/* 122 */           if (roots[i].getKind() == 1) {
/* 123 */             list.add(new PackageFragmentRootSourceLocation(roots[i]));
/*     */           }
/*     */         } 
/* 126 */         this.fRootLocations = list.<IJavaSourceLocation>toArray(new IJavaSourceLocation[list.size()]);
/* 127 */       } catch (JavaModelException e) {
/* 128 */         LaunchingPlugin.log((Throwable)e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IJavaProject getJavaProject() {
/* 140 */     return this.fProject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 148 */     return (object instanceof JavaProjectSourceLocation && 
/* 149 */       getJavaProject().equals(((JavaProjectSourceLocation)object).getJavaProject()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 157 */     return getJavaProject().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMemento() throws CoreException {
/* 165 */     Document doc = DebugPlugin.newDocument();
/* 166 */     Element node = doc.createElement("javaProjectSourceLocation");
/* 167 */     doc.appendChild(node);
/* 168 */     node.setAttribute("name", getJavaProject().getElementName());
/* 169 */     return DebugPlugin.serializeDocument(doc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeFrom(String memento) throws CoreException {
/* 177 */     Exception ex = null;
/*     */     try {
/* 179 */       Element root = null;
/* 180 */       DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/* 181 */       parser.setErrorHandler(new DefaultHandler());
/* 182 */       StringReader reader = new StringReader(memento);
/* 183 */       InputSource source = new InputSource(reader);
/* 184 */       root = parser.parse(source).getDocumentElement();
/*     */       
/* 186 */       String name = root.getAttribute("name");
/* 187 */       if (isEmpty(name)) {
/* 188 */         abort(LaunchingMessages.JavaProjectSourceLocation_Unable_to_initialize_source_location___missing_project_name_3, null);
/*     */       } else {
/* 190 */         IProject proj = ResourcesPlugin.getWorkspace().getRoot().getProject(name);
/* 191 */         setJavaProject(JavaCore.create(proj));
/*     */       } 
/*     */       return;
/* 194 */     } catch (ParserConfigurationException e) {
/* 195 */       ex = e;
/* 196 */     } catch (SAXException e) {
/* 197 */       ex = e;
/* 198 */     } catch (IOException e) {
/* 199 */       ex = e;
/*     */     } 
/* 201 */     abort(LaunchingMessages.JavaProjectSourceLocation_Exception_occurred_initializing_source_location__4, ex);
/*     */   }
/*     */   
/*     */   private boolean isEmpty(String string) {
/* 205 */     return !(string != null && string.length() != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void abort(String message, Throwable e) throws CoreException {
/* 212 */     Status status = new Status(4, LaunchingPlugin.getUniqueIdentifier(), 150, message, e);
/* 213 */     throw new CoreException(status);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\sourcelookup\JavaProjectSourceLocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */