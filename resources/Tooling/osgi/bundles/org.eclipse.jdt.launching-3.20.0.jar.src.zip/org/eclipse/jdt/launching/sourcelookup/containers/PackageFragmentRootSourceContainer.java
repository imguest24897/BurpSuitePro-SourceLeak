/*     */ package org.eclipse.jdt.launching.sourcelookup.containers;
/*     */ 
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainerType;
/*     */ import org.eclipse.debug.core.sourcelookup.containers.AbstractSourceContainer;
/*     */ import org.eclipse.jdt.core.IClassFile;
/*     */ import org.eclipse.jdt.core.ICompilationUnit;
/*     */ import org.eclipse.jdt.core.IPackageFragment;
/*     */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PackageFragmentRootSourceContainer
/*     */   extends AbstractSourceContainer
/*     */ {
/*     */   private IPackageFragmentRoot fRoot;
/*  45 */   public static final String TYPE_ID = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".sourceContainer.packageFragmentRoot";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PackageFragmentRootSourceContainer(IPackageFragmentRoot root) {
/*  54 */     this.fRoot = root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] findSourceElements(String name) throws CoreException {
/*  63 */     int index = name.lastIndexOf('.');
/*  64 */     String typeName = name;
/*  65 */     if (index >= 0)
/*     */     {
/*  67 */       typeName = typeName.substring(0, index);
/*     */     }
/*  69 */     typeName = typeName.replace('/', '.');
/*  70 */     typeName = typeName.replace('\\', '.');
/*  71 */     index = typeName.lastIndexOf('.');
/*  72 */     String packageName = "";
/*  73 */     if (index >= 0) {
/*  74 */       packageName = typeName.substring(0, index);
/*  75 */       typeName = typeName.substring(index + 1);
/*     */     } 
/*  77 */     IPackageFragment fragment = this.fRoot.getPackageFragment(packageName);
/*  78 */     if (fragment.exists()) {
/*  79 */       IClassFile file; String[] extensions; int i; switch (fragment.getKind()) {
/*     */         case 2:
/*  81 */           file = fragment.getClassFile(String.valueOf(typeName) + ".class");
/*  82 */           if (file.exists()) {
/*  83 */             return new Object[] { file };
/*     */           }
/*     */           break;
/*     */         case 1:
/*  87 */           extensions = JavaCore.getJavaLikeExtensions();
/*  88 */           for (i = 0; i < extensions.length; i++) {
/*  89 */             String ext = extensions[i];
/*  90 */             ICompilationUnit unit = fragment.getCompilationUnit(String.valueOf(typeName) + '.' + ext);
/*  91 */             if (unit.exists()) {
/*  92 */               return new Object[] { unit };
/*     */             }
/*     */           } 
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/*  99 */     return EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 106 */     return this.fRoot.getElementName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISourceContainerType getType() {
/* 113 */     return getSourceContainerType(TYPE_ID);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 121 */     return (obj instanceof PackageFragmentRootSourceContainer && (
/* 122 */       (PackageFragmentRootSourceContainer)obj).getPackageFragmentRoot().equals(getPackageFragmentRoot()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPackageFragmentRoot getPackageFragmentRoot() {
/* 131 */     return this.fRoot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 139 */     return this.fRoot.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getPath() {
/* 145 */     return getPackageFragmentRoot().getPath();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 150 */     StringBuilder builder = new StringBuilder();
/* 151 */     builder.append("[");
/* 152 */     if (this.fRoot != null) {
/* 153 */       builder.append(this.fRoot.getElementName());
/* 154 */       builder.append(", parent=");
/* 155 */       builder.append(this.fRoot.getParent().getElementName());
/* 156 */       builder.append(", path=");
/* 157 */       builder.append(getPath());
/*     */     } 
/* 159 */     builder.append("]");
/* 160 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\sourcelookup\containers\PackageFragmentRootSourceContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */