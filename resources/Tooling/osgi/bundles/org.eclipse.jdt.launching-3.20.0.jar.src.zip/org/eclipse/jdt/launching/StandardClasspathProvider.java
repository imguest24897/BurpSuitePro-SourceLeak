/*     */ package org.eclipse.jdt.launching;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardClasspathProvider
/*     */   implements IRuntimeClasspathProvider
/*     */ {
/*     */   public IRuntimeClasspathEntry[] computeUnresolvedClasspath(ILaunchConfiguration configuration) throws CoreException {
/*  42 */     boolean useDefault = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_DEFAULT_CLASSPATH, true);
/*  43 */     boolean isModular = JavaRuntime.isModularConfiguration(configuration);
/*  44 */     boolean excludeTestCode = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_EXCLUDE_TEST_CODE, false);
/*  45 */     if (useDefault) {
/*  46 */       IJavaProject proj = JavaRuntime.getJavaProject(configuration);
/*  47 */       IRuntimeClasspathEntry jreEntry = JavaRuntime.computeJREEntry(configuration);
/*  48 */       if (proj == null) {
/*     */         
/*  50 */         if (jreEntry == null) {
/*  51 */           return new IRuntimeClasspathEntry[0];
/*     */         }
/*  53 */         return new IRuntimeClasspathEntry[] { jreEntry };
/*     */       } 
/*  55 */       IRuntimeClasspathEntry[] entries = null;
/*  56 */       if (isModular) {
/*  57 */         entries = JavaRuntime.computeUnresolvedRuntimeDependencies(proj, excludeTestCode);
/*     */       } else {
/*  59 */         entries = JavaRuntime.computeUnresolvedRuntimeClasspath(proj, excludeTestCode);
/*     */       } 
/*     */       
/*  62 */       IRuntimeClasspathEntry projEntry = isModular ? JavaRuntime.computeModularJREEntry(proj) : JavaRuntime.computeJREEntry(proj);
/*  63 */       if (jreEntry != null && projEntry != null && 
/*  64 */         !jreEntry.equals(projEntry)) {
/*  65 */         for (int i = 0; i < entries.length; i++) {
/*  66 */           IRuntimeClasspathEntry entry = entries[i];
/*  67 */           if (entry.equals(projEntry)) {
/*  68 */             entries[i] = jreEntry;
/*  69 */             return entries;
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/*  74 */       return entries;
/*     */     } 
/*     */     
/*  77 */     if (isModular) {
/*  78 */       IRuntimeClasspathEntry[] runtimeModulePaths = recoverRuntimePath(configuration, IJavaLaunchConfigurationConstants.ATTR_MODULEPATH);
/*  79 */       IRuntimeClasspathEntry[] runtimeClasspaths = recoverRuntimePath(configuration, IJavaLaunchConfigurationConstants.ATTR_CLASSPATH);
/*  80 */       IRuntimeClasspathEntry[] result = Arrays.<IRuntimeClasspathEntry>copyOf(runtimeModulePaths, runtimeModulePaths.length + runtimeClasspaths.length);
/*  81 */       System.arraycopy(runtimeClasspaths, 0, result, runtimeModulePaths.length, runtimeClasspaths.length);
/*  82 */       return result;
/*     */     } 
/*  84 */     return recoverRuntimePath(configuration, IJavaLaunchConfigurationConstants.ATTR_CLASSPATH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IRuntimeClasspathEntry[] resolveClasspath(IRuntimeClasspathEntry[] entries, ILaunchConfiguration configuration) throws CoreException {
/*  93 */     Set<IRuntimeClasspathEntry> all = new LinkedHashSet<>(entries.length);
/*  94 */     for (int i = 0; i < entries.length; i++) {
/*  95 */       IRuntimeClasspathEntry[] resolved = JavaRuntime.resolveRuntimeClasspathEntry(entries[i], configuration);
/*  96 */       for (int j = 0; j < resolved.length; j++) {
/*  97 */         all.add(resolved[j]);
/*     */       }
/*     */     } 
/* 100 */     return all.<IRuntimeClasspathEntry>toArray(new IRuntimeClasspathEntry[all.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IRuntimeClasspathEntry[] recoverRuntimePath(ILaunchConfiguration configuration, String attribute) throws CoreException {
/* 115 */     List<String> entries = configuration.getAttribute(attribute, Collections.EMPTY_LIST);
/* 116 */     IRuntimeClasspathEntry[] rtes = new IRuntimeClasspathEntry[entries.size()];
/* 117 */     Iterator<String> iter = entries.iterator();
/* 118 */     int i = 0;
/* 119 */     while (iter.hasNext()) {
/* 120 */       rtes[i] = JavaRuntime.newRuntimeClasspathEntry(iter.next());
/* 121 */       i++;
/*     */     } 
/* 123 */     return rtes;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\StandardClasspathProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */