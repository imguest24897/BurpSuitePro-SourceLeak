/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.resources.IWorkspace;
/*    */ import org.eclipse.core.resources.ResourcesPlugin;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.AbstractSourceContainerTypeDelegate;
/*    */ import org.eclipse.jdt.core.IJavaProject;
/*    */ import org.eclipse.jdt.core.JavaCore;
/*    */ import org.eclipse.jdt.launching.sourcelookup.containers.JavaProjectSourceContainer;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaProjectSourceContainerTypeDelegate
/*    */   extends AbstractSourceContainerTypeDelegate
/*    */ {
/*    */   public ISourceContainer createSourceContainer(String memento) throws CoreException {
/* 39 */     Node node = parseDocument(memento);
/* 40 */     if (node.getNodeType() == 1) {
/* 41 */       Element element = (Element)node;
/* 42 */       if ("javaProject".equals(element.getNodeName())) {
/* 43 */         String string = element.getAttribute("name");
/* 44 */         if (string == null || string.length() == 0) {
/* 45 */           abort(LaunchingMessages.JavaProjectSourceContainerTypeDelegate_5, null);
/*    */         }
/* 47 */         IWorkspace workspace = ResourcesPlugin.getWorkspace();
/* 48 */         IProject project = workspace.getRoot().getProject(string);
/* 49 */         IJavaProject javaProject = JavaCore.create(project);
/* 50 */         return (ISourceContainer)new JavaProjectSourceContainer(javaProject);
/*    */       } 
/* 52 */       abort(LaunchingMessages.JavaProjectSourceContainerTypeDelegate_6, null);
/*    */     } 
/* 54 */     abort(LaunchingMessages.JavaProjectSourceContainerTypeDelegate_7, null);
/* 55 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getMemento(ISourceContainer container) throws CoreException {
/* 62 */     JavaProjectSourceContainer project = (JavaProjectSourceContainer)container;
/* 63 */     Document document = newDocument();
/* 64 */     Element element = document.createElement("javaProject");
/* 65 */     element.setAttribute("name", project.getName());
/* 66 */     document.appendChild(element);
/* 67 */     return serializeDocument(document);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\JavaProjectSourceContainerTypeDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */