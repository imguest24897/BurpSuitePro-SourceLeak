/*      */ package org.eclipse.jdt.internal.launching;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.xml.parsers.DocumentBuilder;
/*      */ import javax.xml.parsers.DocumentBuilderFactory;
/*      */ import javax.xml.parsers.FactoryConfigurationError;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import org.eclipse.core.resources.IResourceChangeEvent;
/*      */ import org.eclipse.core.resources.IResourceChangeListener;
/*      */ import org.eclipse.core.resources.ISaveContext;
/*      */ import org.eclipse.core.resources.ISaveParticipant;
/*      */ import org.eclipse.core.resources.IWorkspaceRunnable;
/*      */ import org.eclipse.core.resources.ResourcesPlugin;
/*      */ import org.eclipse.core.runtime.CoreException;
/*      */ import org.eclipse.core.runtime.FileLocator;
/*      */ import org.eclipse.core.runtime.IConfigurationElement;
/*      */ import org.eclipse.core.runtime.IExtensionPoint;
/*      */ import org.eclipse.core.runtime.IPath;
/*      */ import org.eclipse.core.runtime.IProgressMonitor;
/*      */ import org.eclipse.core.runtime.IStatus;
/*      */ import org.eclipse.core.runtime.MultiStatus;
/*      */ import org.eclipse.core.runtime.Path;
/*      */ import org.eclipse.core.runtime.Platform;
/*      */ import org.eclipse.core.runtime.Plugin;
/*      */ import org.eclipse.core.runtime.Status;
/*      */ import org.eclipse.core.runtime.jobs.Job;
/*      */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*      */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*      */ import org.eclipse.debug.core.DebugEvent;
/*      */ import org.eclipse.debug.core.DebugPlugin;
/*      */ import org.eclipse.debug.core.IDebugEventSetListener;
/*      */ import org.eclipse.debug.core.ILaunch;
/*      */ import org.eclipse.debug.core.ILaunchConfiguration;
/*      */ import org.eclipse.debug.core.ILaunchConfigurationWorkingCopy;
/*      */ import org.eclipse.debug.core.ILaunchesListener;
/*      */ import org.eclipse.debug.core.model.IDebugTarget;
/*      */ import org.eclipse.debug.core.model.IProcess;
/*      */ import org.eclipse.jdt.core.IClasspathEntry;
/*      */ import org.eclipse.jdt.core.IJavaProject;
/*      */ import org.eclipse.jdt.core.JavaCore;
/*      */ import org.eclipse.jdt.internal.launching.sourcelookup.advanced.AdvancedSourceLookupSupport;
/*      */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry2;
/*      */ import org.eclipse.jdt.launching.IVMConnector;
/*      */ import org.eclipse.jdt.launching.IVMInstall;
/*      */ import org.eclipse.jdt.launching.IVMInstallChangedListener;
/*      */ import org.eclipse.jdt.launching.JavaRuntime;
/*      */ import org.eclipse.jdt.launching.PropertyChangeEvent;
/*      */ import org.eclipse.jdt.launching.VMStandin;
/*      */ import org.eclipse.jdt.launching.sourcelookup.ArchiveSourceLocation;
/*      */ import org.eclipse.osgi.service.debug.DebugOptions;
/*      */ import org.eclipse.osgi.service.debug.DebugOptionsListener;
/*      */ import org.eclipse.osgi.service.debug.DebugTrace;
/*      */ import org.eclipse.osgi.util.NLS;
/*      */ import org.osgi.framework.BundleContext;
/*      */ import org.osgi.service.prefs.BackingStoreException;
/*      */ import org.w3c.dom.Document;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.SAXException;
/*      */ import org.xml.sax.helpers.DefaultHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LaunchingPlugin
/*      */   extends Plugin
/*      */   implements DebugOptionsListener, IEclipsePreferences.IPreferenceChangeListener, IVMInstallChangedListener, IResourceChangeListener, ILaunchesListener, IDebugEventSetListener
/*      */ {
/*      */   public static boolean DEBUG = false;
/*      */   public static boolean DEBUG_JRE_CONTAINER = false;
/*      */   public static final String DEBUG_JRE_CONTAINER_FLAG = "org.eclipse.jdt.launching/debug/classpath/jreContainer";
/*      */   public static final String DEBUG_FLAG = "org.eclipse.jdt.launching/debug";
/*      */   public static final String ATTR_LAUNCH_TEMP_FILES = "tempFiles";
/*      */   public static final String LAUNCH_TEMP_FILE_PREFIX = ".temp-";
/*      */   private static DebugTrace fgDebugTrace;
/*      */   public static final String ID_PLUGIN = "org.eclipse.jdt.launching";
/*      */   public static final String ID_EXTENSION_POINT_VM_CONNECTORS = "vmConnectors";
/*      */   public static final String ID_EXTENSION_POINT_RUNTIME_CLASSPATH_ENTRIES = "runtimeClasspathEntries";
/*      */   private static LaunchingPlugin fgLaunchingPlugin;
/*  144 */   private HashMap<String, IVMConnector> fVMConnectors = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  149 */   private HashMap<String, IConfigurationElement> fClasspathEntryExtensions = null;
/*      */   
/*  151 */   private String fOldVMPrefString = "";
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean fIgnoreVMDefPropertyChangeEvents = false;
/*      */ 
/*      */   
/*      */   private static final String EMPTY_STRING = "";
/*      */ 
/*      */   
/*  161 */   private static Map<String, LibraryInfo> fgLibraryInfoMap = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  169 */   private static Map<String, Long> fgInstallTimeMap = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  175 */   private static HashSet<String> fgHasChanged = new HashSet<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  181 */   private static Object installLock = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean fBatchingChanges = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  192 */   private static DocumentBuilder fgXMLParser = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class VMChanges
/*      */     implements IVMInstallChangedListener
/*      */   {
/*      */     private boolean fDefaultChanged = false;
/*      */ 
/*      */     
/*  203 */     private HashMap<IPath, IPath> fRenamedContainerIds = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private IPath getContainerId(IVMInstall vm) {
/*  213 */       if (vm != null) {
/*  214 */         String name = vm.getName();
/*  215 */         if (name != null) {
/*  216 */           Path path = new Path(JavaRuntime.JRE_CONTAINER);
/*  217 */           IPath iPath = path.append((IPath)new Path(vm.getVMInstallType().getId()));
/*  218 */           iPath = iPath.append((IPath)new Path(name));
/*  219 */           return iPath;
/*      */         } 
/*      */       } 
/*  222 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void defaultVMInstallChanged(IVMInstall previous, IVMInstall current) {
/*  230 */       this.fDefaultChanged = true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void vmAdded(IVMInstall vm) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void vmChanged(PropertyChangeEvent event) {
/*  245 */       String property = event.getProperty();
/*  246 */       IVMInstall vm = (IVMInstall)event.getSource();
/*  247 */       if (property.equals(IVMInstallChangedListener.PROPERTY_NAME)) {
/*  248 */         IPath newId = getContainerId(vm);
/*  249 */         Path path = new Path(JavaRuntime.JRE_CONTAINER);
/*  250 */         IPath iPath1 = path.append(vm.getVMInstallType().getId());
/*  251 */         String oldName = (String)event.getOldValue();
/*      */         
/*  253 */         if (oldName != null) {
/*  254 */           iPath1 = iPath1.append(oldName);
/*  255 */           this.fRenamedContainerIds.put(iPath1, newId);
/*      */           
/*      */           try {
/*  258 */             ILaunchConfiguration[] configs = DebugPlugin.getDefault().getLaunchManager().getLaunchConfigurations();
/*  259 */             String container = null;
/*  260 */             ILaunchConfigurationWorkingCopy wc = null;
/*  261 */             IPath cpath = null;
/*  262 */             for (int i = 0; i < configs.length; i++) {
/*  263 */               container = configs[i].getAttribute(JavaRuntime.JRE_CONTAINER, null);
/*  264 */               if (container != null) {
/*  265 */                 Path path1 = new Path(container);
/*  266 */                 if (path1.lastSegment().equals(oldName)) {
/*  267 */                   IPath iPath = path1.removeLastSegments(1).append(newId.lastSegment()).addTrailingSeparator();
/*  268 */                   wc = configs[i].getWorkingCopy();
/*  269 */                   wc.setAttribute(JavaRuntime.JRE_CONTAINER, iPath.toString());
/*  270 */                   wc.doSave();
/*      */                 } 
/*      */               } 
/*      */             } 
/*  274 */           } catch (CoreException coreException) {}
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void vmRemoved(IVMInstall vm) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void process() {
/*  291 */       LaunchingPlugin.JREUpdateJob job = new LaunchingPlugin.JREUpdateJob(this);
/*  292 */       job.schedule();
/*      */     }
/*      */     
/*      */     protected void doit(IProgressMonitor monitor) throws CoreException {
/*  296 */       IWorkspaceRunnable runnable = new IWorkspaceRunnable()
/*      */         {
/*      */           public void run(IProgressMonitor monitor1) throws CoreException {
/*  299 */             IJavaProject[] projects = JavaCore.create(ResourcesPlugin.getWorkspace().getRoot()).getJavaProjects();
/*  300 */             monitor1.beginTask(LaunchingMessages.LaunchingPlugin_0, projects.length + 1);
/*  301 */             LaunchingPlugin.VMChanges.this.rebind(monitor1, projects);
/*  302 */             monitor1.done();
/*      */           }
/*      */         };
/*  305 */       JavaCore.run(runnable, null, monitor);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void rebind(IProgressMonitor monitor, IJavaProject[] projects) throws CoreException {
/*  316 */       if (this.fDefaultChanged) {
/*      */         
/*  318 */         JavaClasspathVariablesInitializer initializer = new JavaClasspathVariablesInitializer();
/*  319 */         initializer.initialize("JRE_LIB");
/*  320 */         initializer.initialize("JRE_SRC");
/*  321 */         initializer.initialize("JRE_SRCROOT");
/*      */       } 
/*  323 */       monitor.worked(1);
/*      */ 
/*      */       
/*  326 */       int length = projects.length;
/*  327 */       Map<IPath, List<IJavaProject>> projectsMap = new HashMap<>();
/*  328 */       for (int i = 0; i < length; i++) {
/*  329 */         IJavaProject project = projects[i];
/*  330 */         IClasspathEntry[] entries = project.getRawClasspath();
/*  331 */         boolean replace = false;
/*  332 */         for (int j = 0; j < entries.length; j++) {
/*  333 */           IPath reference, newBinding; String firstSegment; IClasspathEntry entry = entries[j];
/*  334 */           switch (entry.getEntryKind()) {
/*      */             case 5:
/*  336 */               reference = entry.getPath();
/*  337 */               newBinding = null;
/*  338 */               firstSegment = reference.segment(0);
/*  339 */               if (JavaRuntime.JRE_CONTAINER.equals(firstSegment)) {
/*  340 */                 if (reference.segmentCount() > 1) {
/*  341 */                   IPath renamed = this.fRenamedContainerIds.get(reference);
/*  342 */                   if (renamed != null)
/*      */                   {
/*      */                     
/*  345 */                     newBinding = renamed;
/*      */                   }
/*      */                 } 
/*  348 */                 if (newBinding == null) {
/*      */ 
/*      */                   
/*  351 */                   List<IJavaProject> projectsList = projectsMap.get(reference);
/*  352 */                   if (projectsList == null) {
/*  353 */                     projectsMap.put(reference, projectsList = new ArrayList<>(length));
/*      */                   }
/*  355 */                   projectsList.add(project);
/*      */                   break;
/*      */                 } 
/*  358 */                 IClasspathEntry newEntry = JavaCore.newContainerEntry(newBinding, entry.isExported());
/*  359 */                 entries[j] = newEntry;
/*  360 */                 replace = true;
/*      */               } 
/*      */               break;
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/*      */         } 
/*  368 */         if (replace) {
/*  369 */           project.setRawClasspath(entries, null);
/*      */         }
/*  371 */         monitor.worked(1);
/*      */       } 
/*  373 */       Iterator<IPath> references = projectsMap.keySet().iterator();
/*  374 */       while (references.hasNext()) {
/*  375 */         IPath reference = references.next();
/*  376 */         List<IJavaProject> projectsList = projectsMap.get(reference);
/*  377 */         IJavaProject[] referenceProjects = new IJavaProject[projectsList.size()];
/*  378 */         projectsList.toArray(referenceProjects);
/*      */         
/*  380 */         JREContainerInitializer initializer = new JREContainerInitializer();
/*  381 */         initializer.initialize(reference, referenceProjects);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   class JREUpdateJob
/*      */     extends Job {
/*      */     private LaunchingPlugin.VMChanges fChanges;
/*      */     
/*      */     public JREUpdateJob(LaunchingPlugin.VMChanges changes) {
/*  391 */       super(LaunchingMessages.LaunchingPlugin_1);
/*  392 */       this.fChanges = changes;
/*  393 */       setSystem(true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected IStatus run(IProgressMonitor monitor) {
/*      */       try {
/*  402 */         this.fChanges.doit(monitor);
/*  403 */       } catch (CoreException e) {
/*  404 */         return e.getStatus();
/*      */       } 
/*  406 */       return Status.OK_STATUS;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LaunchingPlugin() {
/*  416 */     fgLaunchingPlugin = this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LibraryInfo getLibraryInfo(String javaInstallPath) {
/*  428 */     if (fgLibraryInfoMap == null) {
/*  429 */       restoreLibraryInfo();
/*      */     }
/*  431 */     return fgLibraryInfoMap.get(javaInstallPath);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setLibraryInfo(String javaInstallPath, LibraryInfo info) {
/*  442 */     if (isVMLogging()) {
/*  443 */       log(String.valueOf(LaunchingMessages.VMLogging_2) + javaInstallPath);
/*      */     }
/*  445 */     if (fgLibraryInfoMap == null) {
/*  446 */       restoreLibraryInfo();
/*      */     }
/*  448 */     if (info == null) {
/*  449 */       fgLibraryInfoMap.remove(javaInstallPath);
/*  450 */       if (fgInstallTimeMap != null) {
/*  451 */         fgInstallTimeMap.remove(javaInstallPath);
/*  452 */         writeInstallInfo();
/*      */       } 
/*      */     } else {
/*      */       
/*  456 */       fgLibraryInfoMap.put(javaInstallPath, info);
/*      */     } 
/*      */     
/*  459 */     fgHasChanged.remove(javaInstallPath);
/*  460 */     saveLibraryInfo();
/*      */   }
/*      */   
/*      */   public static boolean isVMLogging() {
/*  464 */     String vmLogging = System.getProperty("jdt.debug.launching.vmLogging");
/*  465 */     return "true".equalsIgnoreCase(vmLogging);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File getFileInPlugin(IPath path) {
/*      */     try {
/*  477 */       URL installURL = 
/*  478 */         new URL(getDefault().getBundle().getEntry("/"), path.toString());
/*  479 */       URL localURL = FileLocator.toFileURL(installURL);
/*  480 */       return new File(localURL.getFile());
/*  481 */     } catch (IOException iOException) {
/*  482 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getUniqueIdentifier() {
/*  492 */     return "org.eclipse.jdt.launching";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static LaunchingPlugin getDefault() {
/*  500 */     return fgLaunchingPlugin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void log(IStatus status) {
/*  508 */     getDefault().getLog().log(status);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void log(String message) {
/*  516 */     log((IStatus)new Status(4, getUniqueIdentifier(), 4, message, null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void log(Throwable e) {
/*  524 */     log((IStatus)new Status(4, getUniqueIdentifier(), 4, e.getMessage(), e));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void stop(BundleContext context) throws Exception {
/*      */     try {
/*  536 */       AdvancedSourceLookupSupport.stop();
/*      */       
/*  538 */       DebugPlugin.getDefault().getLaunchManager().removeLaunchListener(this);
/*  539 */       DebugPlugin.getDefault().removeDebugEventListener(this);
/*  540 */       ResourcesPlugin.getWorkspace().removeResourceChangeListener(this);
/*  541 */       ArchiveSourceLocation.closeArchives();
/*  542 */       InstanceScope.INSTANCE.getNode("org.eclipse.jdt.launching").removePreferenceChangeListener(this);
/*  543 */       JavaRuntime.removeVMInstallChangedListener(this);
/*  544 */       JavaRuntime.saveVMConfiguration();
/*  545 */       fgXMLParser = null;
/*  546 */       ResourcesPlugin.getWorkspace().removeSaveParticipant("org.eclipse.jdt.launching");
/*      */     } finally {
/*  548 */       super.stop(context);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void start(BundleContext context) throws Exception {
/*  557 */     super.start(context);
/*  558 */     Hashtable<String, String> props = new Hashtable<>(2);
/*  559 */     props.put("listener.symbolic.name", getUniqueIdentifier());
/*  560 */     context.registerService(DebugOptionsListener.class.getName(), this, props);
/*  561 */     ResourcesPlugin.getWorkspace().addSaveParticipant("org.eclipse.jdt.launching", new ISaveParticipant()
/*      */         {
/*      */           public void doneSaving(ISaveContext context1) {}
/*      */           
/*      */           public void prepareToSave(ISaveContext context1) throws CoreException {}
/*      */           
/*      */           public void rollback(ISaveContext context1) {}
/*      */           
/*      */           public void saving(ISaveContext context1) throws CoreException {
/*      */             try {
/*  571 */               InstanceScope.INSTANCE.getNode("org.eclipse.jdt.launching").flush();
/*  572 */             } catch (BackingStoreException e) {
/*  573 */               LaunchingPlugin.log((Throwable)e);
/*      */             } 
/*      */             
/*  576 */             LaunchingPlugin.writeInstallInfo();
/*      */           }
/*      */         });
/*      */     
/*  580 */     InstanceScope.INSTANCE.getNode("org.eclipse.jdt.launching").addPreferenceChangeListener(this);
/*  581 */     JavaRuntime.addVMInstallChangedListener(this);
/*  582 */     ResourcesPlugin.getWorkspace().addResourceChangeListener(this, 6);
/*  583 */     DebugPlugin.getDefault().getLaunchManager().addLaunchListener(this);
/*  584 */     DebugPlugin.getDefault().addDebugEventListener(this);
/*      */     
/*  586 */     AdvancedSourceLookupSupport.start();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IVMConnector getVMConnector(String id) {
/*  597 */     if (this.fVMConnectors == null) {
/*  598 */       initializeVMConnectors();
/*      */     }
/*  600 */     return this.fVMConnectors.get(id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IVMConnector[] getVMConnectors() {
/*  609 */     if (this.fVMConnectors == null) {
/*  610 */       initializeVMConnectors();
/*      */     }
/*  612 */     return (IVMConnector[])this.fVMConnectors.values().toArray((Object[])new IVMConnector[this.fVMConnectors.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeVMConnectors() {
/*  619 */     IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.jdt.launching", "vmConnectors");
/*  620 */     IConfigurationElement[] configs = extensionPoint.getConfigurationElements();
/*  621 */     MultiStatus status = new MultiStatus(getUniqueIdentifier(), 0, "Exception occurred reading vmConnectors extensions.", null);
/*  622 */     this.fVMConnectors = new HashMap<>(configs.length);
/*  623 */     for (int i = 0; i < configs.length; i++) {
/*      */       try {
/*  625 */         IVMConnector vmConnector = (IVMConnector)configs[i].createExecutableExtension("class");
/*  626 */         this.fVMConnectors.put(vmConnector.getIdentifier(), vmConnector);
/*  627 */       } catch (CoreException e) {
/*  628 */         status.add(e.getStatus());
/*      */       } 
/*      */     } 
/*  631 */     if (!status.isOK()) {
/*  632 */       log((IStatus)status);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public IRuntimeClasspathEntry2 newRuntimeClasspathEntry(String id) throws CoreException {
/*  644 */     if (this.fClasspathEntryExtensions == null) {
/*  645 */       initializeRuntimeClasspathExtensions();
/*      */     }
/*  647 */     IConfigurationElement config = this.fClasspathEntryExtensions.get(id);
/*  648 */     if (config != null) {
/*  649 */       return (IRuntimeClasspathEntry2)config.createExecutableExtension("class");
/*      */     }
/*  651 */     abort(NLS.bind(LaunchingMessages.LaunchingPlugin_32, (Object[])new String[] { id }), (Throwable)null);
/*  652 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeRuntimeClasspathExtensions() {
/*  659 */     IExtensionPoint extensionPoint = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.jdt.launching", "runtimeClasspathEntries");
/*  660 */     IConfigurationElement[] configs = extensionPoint.getConfigurationElements();
/*  661 */     this.fClasspathEntryExtensions = new HashMap<>(configs.length);
/*  662 */     for (int i = 0; i < configs.length; i++) {
/*  663 */       this.fClasspathEntryExtensions.put(configs[i].getAttribute("id"), configs[i]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void processVMPrefsChanged(String oldValue, String newValue) {
/*  684 */     this.fBatchingChanges = true;
/*  685 */     VMChanges vmChanges = null;
/*      */ 
/*      */ 
/*      */     
/*      */     try { String oldPrefString, newPrefString;
/*      */ 
/*      */       
/*  692 */       if (newValue == null || newValue.equals("")) {
/*  693 */         this.fOldVMPrefString = oldValue;
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  698 */       if (oldValue == null || oldValue.equals("")) {
/*  699 */         oldPrefString = this.fOldVMPrefString;
/*  700 */         newPrefString = newValue;
/*      */       }
/*      */       else {
/*      */         
/*  704 */         oldPrefString = oldValue;
/*  705 */         newPrefString = newValue;
/*      */       } 
/*      */       
/*  708 */       vmChanges = new VMChanges();
/*  709 */       JavaRuntime.addVMInstallChangedListener(vmChanges);
/*      */ 
/*      */       
/*  712 */       VMDefinitionsContainer oldResults = getVMDefinitions(oldPrefString);
/*      */ 
/*      */       
/*  715 */       VMDefinitionsContainer newResults = getVMDefinitions(newPrefString);
/*      */ 
/*      */       
/*  718 */       List<IVMInstall> deleted = oldResults.getVMList();
/*  719 */       List<IVMInstall> current = newResults.getValidVMList();
/*  720 */       deleted.removeAll(current);
/*      */ 
/*      */ 
/*      */       
/*  724 */       Iterator<IVMInstall> deletedIterator = deleted.iterator();
/*  725 */       while (deletedIterator.hasNext()) {
/*  726 */         VMStandin deletedVMStandin = (VMStandin)deletedIterator.next();
/*  727 */         deletedVMStandin.getVMInstallType().disposeVMInstall(deletedVMStandin.getId());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  732 */       Iterator<IVMInstall> iter = current.iterator();
/*  733 */       while (iter.hasNext()) {
/*  734 */         VMStandin standin = (VMStandin)iter.next();
/*  735 */         standin.convertToRealVM();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */        }
/*      */     
/*      */     finally
/*      */     
/*      */     { 
/*      */ 
/*      */ 
/*      */       
/*  754 */       this.fBatchingChanges = false;
/*  755 */       if (vmChanges != null)
/*  756 */       { JavaRuntime.removeVMInstallChangedListener(vmChanges);
/*  757 */         vmChanges.process(); }  }  this.fBatchingChanges = false; if (vmChanges != null) { JavaRuntime.removeVMInstallChangedListener(vmChanges); vmChanges.process(); }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private VMDefinitionsContainer getVMDefinitions(String xml) {
/*  771 */     if (xml.length() > 0) {
/*      */       try {
/*  773 */         ByteArrayInputStream stream = new ByteArrayInputStream(xml.getBytes("UTF8"));
/*  774 */         return VMDefinitionsContainer.parseXMLIntoContainer(stream);
/*  775 */       } catch (IOException e) {
/*  776 */         log(e);
/*      */       } 
/*      */     }
/*  779 */     return new VMDefinitionsContainer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defaultVMInstallChanged(IVMInstall previous, IVMInstall current) {
/*  787 */     if (!this.fBatchingChanges) {
/*  788 */       VMChanges changes = new VMChanges();
/*  789 */       changes.defaultVMInstallChanged(previous, current);
/*  790 */       changes.process();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void vmAdded(IVMInstall vm) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void vmChanged(PropertyChangeEvent event) {
/*  806 */     if (!this.fBatchingChanges) {
/*  807 */       VMChanges changes = new VMChanges();
/*  808 */       changes.vmChanged(event);
/*  809 */       changes.process();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void vmRemoved(IVMInstall vm) {
/*  818 */     if (!this.fBatchingChanges) {
/*  819 */       VMChanges changes = new VMChanges();
/*  820 */       changes.vmRemoved(vm);
/*  821 */       changes.process();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resourceChanged(IResourceChangeEvent event) {
/*  830 */     ArchiveSourceLocation.closeArchives();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIgnoreVMDefPropertyChangeEvents(boolean ignore) {
/*  838 */     this.fIgnoreVMDefPropertyChangeEvents = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isIgnoreVMDefPropertyChangeEvents() {
/*  846 */     return this.fIgnoreVMDefPropertyChangeEvents;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getLibraryInfoAsXML() throws CoreException {
/*  862 */     Document doc = DebugPlugin.newDocument();
/*  863 */     Element config = doc.createElement("libraryInfos");
/*  864 */     doc.appendChild(config);
/*      */ 
/*      */     
/*  867 */     Iterator<String> locations = fgLibraryInfoMap.keySet().iterator();
/*  868 */     while (locations.hasNext()) {
/*  869 */       String home = locations.next();
/*  870 */       LibraryInfo info = fgLibraryInfoMap.get(home);
/*  871 */       Element locationElemnet = infoAsElement(doc, info);
/*  872 */       locationElemnet.setAttribute("home", home);
/*  873 */       config.appendChild(locationElemnet);
/*      */     } 
/*      */ 
/*      */     
/*  877 */     return DebugPlugin.serializeDocument(doc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Element infoAsElement(Document doc, LibraryInfo info) {
/*  888 */     Element libraryElement = doc.createElement("libraryInfo");
/*  889 */     libraryElement.setAttribute("version", info.getVersion());
/*  890 */     appendPathElements(doc, "bootpath", libraryElement, info.getBootpath());
/*  891 */     appendPathElements(doc, "extensionDirs", libraryElement, info.getExtensionDirs());
/*  892 */     appendPathElements(doc, "endorsedDirs", libraryElement, info.getEndorsedDirs());
/*  893 */     return libraryElement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void appendPathElements(Document doc, String elementType, Element libraryElement, String[] paths) {
/*  906 */     if (paths.length > 0) {
/*  907 */       Element child = doc.createElement(elementType);
/*  908 */       libraryElement.appendChild(child);
/*  909 */       for (int i = 0; i < paths.length; i++) {
/*  910 */         String path = paths[i];
/*  911 */         Element entry = doc.createElement("entry");
/*  912 */         child.appendChild(entry);
/*  913 */         entry.setAttribute("path", path);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void saveLibraryInfo() {
/*      */     try {
/*      */       Exception exception2;
/*  923 */       String xml = getLibraryInfoAsXML();
/*  924 */       IPath libPath = getDefault().getStateLocation();
/*  925 */       libPath = libPath.append("libraryInfos.xml");
/*  926 */       File file = libPath.toFile();
/*  927 */       if (!file.exists()) {
/*  928 */         file.createNewFile();
/*      */       }
/*  930 */       Exception exception1 = null;
/*      */     
/*      */     }
/*  933 */     catch (IOException e) {
/*  934 */       log(e);
/*  935 */     } catch (CoreException e) {
/*  936 */       log((Throwable)e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void restoreLibraryInfo() {
/*  944 */     fgLibraryInfoMap = new HashMap<>(10);
/*  945 */     IPath libPath = getDefault().getStateLocation();
/*  946 */     libPath = libPath.append("libraryInfos.xml");
/*  947 */     File file = libPath.toFile();
/*  948 */     if (file.exists()) {
/*      */       try {
/*  950 */         InputStream stream = new BufferedInputStream(new FileInputStream(file));
/*  951 */         DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/*  952 */         parser.setErrorHandler(new DefaultHandler());
/*  953 */         Element root = parser.parse(new InputSource(stream)).getDocumentElement();
/*  954 */         if (!root.getNodeName().equals("libraryInfos")) {
/*      */           return;
/*      */         }
/*      */         
/*  958 */         NodeList list = root.getChildNodes();
/*  959 */         int length = list.getLength();
/*  960 */         for (int i = 0; i < length; i++) {
/*  961 */           Node node = list.item(i);
/*  962 */           short type = node.getNodeType();
/*  963 */           if (type == 1) {
/*  964 */             Element element = (Element)node;
/*  965 */             String nodeName = element.getNodeName();
/*  966 */             if (nodeName.equalsIgnoreCase("libraryInfo")) {
/*  967 */               String version = element.getAttribute("version");
/*  968 */               String location = element.getAttribute("home");
/*  969 */               String[] bootpath = getPathsFromXML(element, "bootpath");
/*  970 */               String[] extDirs = getPathsFromXML(element, "extensionDirs");
/*  971 */               String[] endDirs = getPathsFromXML(element, "endorsedDirs");
/*  972 */               if (location != null) {
/*  973 */                 if (isVMLogging()) {
/*  974 */                   log(String.valueOf(LaunchingMessages.VMLogging_1) + location);
/*      */                 }
/*  976 */                 LibraryInfo info = new LibraryInfo(version, bootpath, extDirs, endDirs);
/*  977 */                 fgLibraryInfoMap.put(location, info);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*  982 */       } catch (IOException e) {
/*  983 */         log(e);
/*  984 */       } catch (ParserConfigurationException e) {
/*  985 */         log(e);
/*  986 */       } catch (SAXException e) {
/*  987 */         log(e);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean timeStampChanged(String location) {
/* 1004 */     synchronized (installLock) {
/* 1005 */       if (fgHasChanged.contains(location)) {
/* 1006 */         return true;
/*      */       }
/* 1008 */       File file = new File(location);
/* 1009 */       if (file.exists()) {
/* 1010 */         if (fgInstallTimeMap == null) {
/* 1011 */           readInstallInfo();
/*      */         }
/* 1013 */         Long stamp = fgInstallTimeMap.get(location);
/* 1014 */         long fstamp = file.lastModified();
/* 1015 */         if (stamp != null && 
/* 1016 */           stamp.longValue() == fstamp) {
/* 1017 */           return false;
/*      */         }
/*      */ 
/*      */         
/* 1021 */         stamp = Long.valueOf(fstamp);
/* 1022 */         fgInstallTimeMap.put(location, stamp);
/* 1023 */         writeInstallInfo();
/* 1024 */         fgHasChanged.add(location);
/* 1025 */         return true;
/*      */       } 
/*      */     } 
/* 1028 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void readInstallInfo() {
/* 1038 */     fgInstallTimeMap = new HashMap<>();
/* 1039 */     IPath libPath = getDefault().getStateLocation();
/* 1040 */     libPath = libPath.append(".install.xml");
/* 1041 */     File file = libPath.toFile();
/* 1042 */     if (file.exists()) {
/*      */       try {
/* 1044 */         InputStream stream = new BufferedInputStream(new FileInputStream(file));
/* 1045 */         DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/* 1046 */         parser.setErrorHandler(new DefaultHandler());
/* 1047 */         Element root = parser.parse(new InputSource(stream)).getDocumentElement();
/* 1048 */         if (root.getNodeName().equalsIgnoreCase("dirs")) {
/* 1049 */           NodeList nodes = root.getChildNodes();
/* 1050 */           Node node = null;
/* 1051 */           Element element = null;
/* 1052 */           for (int i = 0; i < nodes.getLength(); i++) {
/* 1053 */             node = nodes.item(i);
/* 1054 */             if (node.getNodeType() == 1) {
/* 1055 */               element = (Element)node;
/* 1056 */               if (element.getNodeName().equalsIgnoreCase("entry")) {
/* 1057 */                 String loc = element.getAttribute("loc");
/* 1058 */                 String stamp = element.getAttribute("stamp");
/*      */                 try {
/* 1060 */                   Long l = Long.valueOf(stamp);
/* 1061 */                   fgInstallTimeMap.put(loc, l);
/*      */                 }
/* 1063 */                 catch (NumberFormatException numberFormatException) {}
/*      */               }
/*      */             
/*      */             }
/*      */           
/*      */           } 
/*      */         } 
/* 1070 */       } catch (IOException e) {
/* 1071 */         log(e);
/* 1072 */       } catch (ParserConfigurationException e) {
/* 1073 */         log(e);
/* 1074 */       } catch (SAXException e) {
/* 1075 */         log(e);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void writeInstallInfo() {
/* 1087 */     if (fgInstallTimeMap != null) {
/*      */       try {
/* 1089 */         Exception exception2; Document doc = DebugPlugin.newDocument();
/* 1090 */         Element root = doc.createElement("dirs");
/* 1091 */         doc.appendChild(root);
/* 1092 */         Map.Entry<String, Long> entry = null;
/* 1093 */         Element e = null;
/* 1094 */         String key = null;
/* 1095 */         for (Iterator<Map.Entry<String, Long>> i = fgInstallTimeMap.entrySet().iterator(); i.hasNext(); ) {
/* 1096 */           entry = i.next();
/* 1097 */           key = entry.getKey();
/* 1098 */           if (fgLibraryInfoMap == null || fgLibraryInfoMap.containsKey(key)) {
/*      */             
/* 1100 */             e = doc.createElement("entry");
/* 1101 */             root.appendChild(e);
/* 1102 */             e.setAttribute("loc", key);
/* 1103 */             e.setAttribute("stamp", ((Long)entry.getValue()).toString());
/*      */           } 
/*      */         } 
/* 1106 */         String xml = DebugPlugin.serializeDocument(doc);
/* 1107 */         IPath libPath = getDefault().getStateLocation();
/* 1108 */         libPath = libPath.append(".install.xml");
/* 1109 */         File file = libPath.toFile();
/* 1110 */         if (!file.exists()) {
/* 1111 */           file.createNewFile();
/*      */         }
/* 1113 */         Exception exception1 = null;
/*      */       
/*      */       }
/* 1116 */       catch (IOException e) {
/* 1117 */         log(e);
/* 1118 */       } catch (CoreException e) {
/* 1119 */         log((Throwable)e);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] getPathsFromXML(Element lib, String pathType) {
/* 1131 */     List<String> paths = new ArrayList<>();
/* 1132 */     NodeList list = lib.getChildNodes();
/* 1133 */     int length = list.getLength();
/* 1134 */     for (int i = 0; i < length; i++) {
/* 1135 */       Node node = list.item(i);
/* 1136 */       short type = node.getNodeType();
/* 1137 */       if (type == 1) {
/* 1138 */         Element element = (Element)node;
/* 1139 */         String nodeName = element.getNodeName();
/* 1140 */         if (nodeName.equalsIgnoreCase(pathType)) {
/* 1141 */           NodeList entries = element.getChildNodes();
/* 1142 */           int numEntries = entries.getLength();
/* 1143 */           for (int j = 0; j < numEntries; j++) {
/* 1144 */             Node n = entries.item(j);
/* 1145 */             short t = n.getNodeType();
/* 1146 */             if (t == 1) {
/* 1147 */               Element entryElement = (Element)n;
/* 1148 */               String name = entryElement.getNodeName();
/* 1149 */               if (name.equals("entry")) {
/* 1150 */                 String path = entryElement.getAttribute("path");
/* 1151 */                 if (path != null && path.length() > 0) {
/* 1152 */                   paths.add(path);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1160 */     return paths.<String>toArray(new String[paths.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void launchesRemoved(ILaunch[] launches) {
/* 1168 */     ArchiveSourceLocation.closeArchives();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void launchesAdded(ILaunch[] launches) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void launchesChanged(ILaunch[] launches) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleDebugEvents(DebugEvent[] events) {
/* 1190 */     for (int i = 0; i < events.length; i++) {
/* 1191 */       DebugEvent event = events[i];
/* 1192 */       if (event.getKind() == 8) {
/* 1193 */         Object source = event.getSource();
/* 1194 */         if (source instanceof IDebugTarget || source instanceof IProcess) {
/* 1195 */           IProcess process; ArchiveSourceLocation.closeArchives();
/*      */           
/* 1197 */           if (source instanceof IProcess) {
/* 1198 */             process = (IProcess)source;
/*      */           } else {
/* 1200 */             process = ((IDebugTarget)source).getProcess();
/*      */           } 
/* 1202 */           if (process != null) {
/* 1203 */             deleteProcessTempFiles(process);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void deleteProcessTempFiles(IProcess process) {
/* 1211 */     String tempFiles = process.getAttribute("tempFiles");
/* 1212 */     if (tempFiles == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1216 */     Arrays.<String>stream(tempFiles.split(File.pathSeparator)).map(path -> new File(path)).filter(file -> isValidProcessTempFile(file)).forEach(file -> {
/*      */         
/*      */         });
/*      */   } private boolean isValidProcessTempFile(File file) {
/* 1220 */     return file.getName().startsWith(".temp-");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static DocumentBuilder getParser() throws CoreException {
/* 1231 */     if (fgXMLParser == null) {
/*      */       try {
/* 1233 */         fgXMLParser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/* 1234 */         fgXMLParser.setErrorHandler(new DefaultHandler());
/* 1235 */       } catch (ParserConfigurationException e) {
/* 1236 */         abort(LaunchingMessages.LaunchingPlugin_34, e);
/* 1237 */       } catch (FactoryConfigurationError e) {
/* 1238 */         abort(LaunchingMessages.LaunchingPlugin_34, e);
/*      */       } 
/*      */     }
/* 1241 */     return fgXMLParser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static void abort(String message, Throwable exception) throws CoreException {
/* 1252 */     Status status = new Status(4, getUniqueIdentifier(), 0, message, exception);
/* 1253 */     throw new CoreException(status);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean sameURL(URL url1, URL url2) {
/* 1266 */     if (url1 == url2) {
/* 1267 */       return true;
/*      */     }
/* 1269 */     if ((((url1 == null) ? 1 : 0) ^ ((url2 == null) ? 1 : 0)) != 0) {
/* 1270 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1274 */     boolean isFile1 = "file".equalsIgnoreCase(url1.getProtocol());
/* 1275 */     boolean isFile2 = "file".equalsIgnoreCase(url2.getProtocol());
/* 1276 */     if (isFile1 && isFile2) {
/* 1277 */       File file1 = new File(url1.getFile());
/* 1278 */       File file2 = new File(url2.getFile());
/* 1279 */       return file1.equals(file2);
/*      */     } 
/*      */     
/* 1282 */     if (isFile1 ^ isFile2) {
/* 1283 */       return false;
/*      */     }
/* 1285 */     return getExternalForm(url1).equals(getExternalForm(url2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getExternalForm(URL url) {
/* 1295 */     String externalForm = url.toExternalForm();
/* 1296 */     if (externalForm == null)
/*      */     {
/* 1298 */       return "";
/*      */     }
/* 1300 */     externalForm = externalForm.trim();
/* 1301 */     if (externalForm.endsWith("/"))
/*      */     {
/* 1303 */       externalForm = externalForm.substring(0, externalForm.length() - 1);
/*      */     }
/* 1305 */     return externalForm.toLowerCase();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void preferenceChange(IEclipsePreferences.PreferenceChangeEvent event) {
/* 1314 */     String property = event.getKey();
/* 1315 */     if (property.equals(JavaRuntime.PREF_VM_XML) && 
/* 1316 */       !isIgnoreVMDefPropertyChangeEvents()) {
/* 1317 */       processVMPrefsChanged((String)event.getOldValue(), (String)event.getNewValue());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void optionsChanged(DebugOptions options) {
/* 1327 */     DEBUG = options.getBooleanOption("org.eclipse.jdt.launching/debug", false);
/* 1328 */     DEBUG_JRE_CONTAINER = (DEBUG && options.getBooleanOption("org.eclipse.jdt.launching/debug/classpath/jreContainer", false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void trace(String option, String message, Throwable throwable) {
/* 1339 */     System.out.println(message);
/* 1340 */     if (fgDebugTrace != null) {
/* 1341 */       fgDebugTrace.trace(option, message, throwable);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void trace(String message) {
/* 1352 */     trace((String)null, message, (Throwable)null);
/*      */   }
/*      */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\LaunchingPlugin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */