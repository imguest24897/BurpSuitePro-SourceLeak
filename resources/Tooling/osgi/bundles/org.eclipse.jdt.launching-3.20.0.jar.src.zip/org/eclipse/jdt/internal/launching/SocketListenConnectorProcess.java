/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import com.sun.jdi.VMDisconnectedException;
/*     */ import com.sun.jdi.VirtualMachine;
/*     */ import com.sun.jdi.connect.Connector;
/*     */ import com.sun.jdi.connect.IllegalConnectorArgumentsException;
/*     */ import com.sun.jdi.connect.ListeningConnector;
/*     */ import com.sun.jdi.connect.TransportTimeoutException;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.IJobChangeEvent;
/*     */ import org.eclipse.core.runtime.jobs.IJobChangeListener;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.core.runtime.jobs.JobChangeAdapter;
/*     */ import org.eclipse.debug.core.DebugEvent;
/*     */ import org.eclipse.debug.core.DebugException;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.model.IDebugTarget;
/*     */ import org.eclipse.debug.core.model.IProcess;
/*     */ import org.eclipse.debug.core.model.IStreamsProxy;
/*     */ import org.eclipse.jdi.TimeoutException;
/*     */ import org.eclipse.jdt.debug.core.JDIDebugModel;
/*     */ import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SocketListenConnectorProcess
/*     */   implements IProcess
/*     */ {
/*     */   private boolean fTerminated = false;
/*     */   private ILaunch fLaunch;
/*     */   private String fPort;
/*     */   private int fConnectionLimit;
/*  75 */   private int fAccepted = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WaitForConnectionJob fWaitForConnectionJob;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long fStartTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SocketListenConnectorProcess(ILaunch launch, String port, int connectionLimit) {
/*  92 */     this.fLaunch = launch;
/*  93 */     this.fPort = port;
/*  94 */     this.fConnectionLimit = connectionLimit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void waitForConnection(ListeningConnector connector, Map<String, Connector.Argument> arguments) throws CoreException {
/* 110 */     if (isTerminated()) {
/* 111 */       throw new CoreException(getStatus(LaunchingMessages.SocketListenConnectorProcess_0, null, 113));
/*     */     }
/* 113 */     this.fStartTime = System.currentTimeMillis();
/* 114 */     this.fAccepted = 0;
/*     */     
/* 116 */     if (!connector.supportsMultipleConnections()) {
/* 117 */       this.fConnectionLimit = 1;
/*     */     }
/*     */     
/* 120 */     this.fLaunch.addProcess(this);
/* 121 */     this.fWaitForConnectionJob = new WaitForConnectionJob(connector, arguments);
/* 122 */     this.fWaitForConnectionJob.setPriority(20);
/* 123 */     this.fWaitForConnectionJob.setSystem(true);
/* 124 */     this.fWaitForConnectionJob.addJobChangeListener((IJobChangeListener)new JobChangeAdapter()
/*     */         {
/*     */           public void running(IJobChangeEvent event) {
/* 127 */             SocketListenConnectorProcess.this.fireReadyToAcceptEvent();
/*     */           }
/*     */           
/*     */           public void done(IJobChangeEvent event) {
/* 131 */             if (event.getResult().isOK() && SocketListenConnectorProcess.this.continueListening()) {
/* 132 */               SocketListenConnectorProcess.this.fWaitForConnectionJob.schedule();
/*     */             } else {
/*     */               try {
/* 135 */                 SocketListenConnectorProcess.this.terminate();
/* 136 */               } catch (DebugException debugException) {}
/*     */             } 
/*     */           }
/*     */         });
/* 140 */     this.fWaitForConnectionJob.schedule();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean continueListening() {
/* 147 */     return (!isTerminated() && this.fWaitForConnectionJob != null && !this.fWaitForConnectionJob.fListeningStopped && (
/* 148 */       this.fConnectionLimit <= 0 || this.fConnectionLimit - this.fAccepted > 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static IStatus getStatus(String message, Throwable exception, int code) {
/* 161 */     return (IStatus)new Status(4, LaunchingPlugin.getUniqueIdentifier(), code, message, exception);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getExitValue() throws DebugException {
/* 169 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLabel() {
/* 177 */     return NLS.bind(LaunchingMessages.SocketListenConnectorProcess_1, (Object[])new String[] { this.fPort });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ILaunch getLaunch() {
/* 185 */     return this.fLaunch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canTerminate() {
/* 193 */     return !this.fTerminated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTerminated() {
/* 201 */     return this.fTerminated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void terminate() throws DebugException {
/* 209 */     if (!this.fTerminated) {
/* 210 */       this.fTerminated = true;
/* 211 */       this.fLaunch.removeProcess(this);
/* 212 */       if (this.fWaitForConnectionJob != null) {
/* 213 */         this.fWaitForConnectionJob.cancel();
/* 214 */         this.fWaitForConnectionJob.stopListening();
/* 215 */         this.fWaitForConnectionJob = null;
/*     */       } 
/* 217 */       fireTerminateEvent();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireTerminateEvent() {
/* 225 */     DebugPlugin manager = DebugPlugin.getDefault();
/* 226 */     if (manager != null) {
/* 227 */       manager.fireDebugEventSet(new DebugEvent[] { new DebugEvent(this, 8) });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireReadyToAcceptEvent() {
/* 236 */     DebugPlugin manager = DebugPlugin.getDefault();
/* 237 */     if (manager != null) {
/* 238 */       manager.fireDebugEventSet(new DebugEvent[] { new DebugEvent(this, 32, 1001) });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStreamsProxy getStreamsProxy() {
/* 247 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAttribute(String key) {
/* 255 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String key, String value) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T getAdapter(Class<T> adapter) {
/* 270 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getRunningTime() {
/* 277 */     long total = System.currentTimeMillis() - this.fStartTime;
/* 278 */     StringWriter result = new StringWriter();
/* 279 */     PrintWriter writer = new PrintWriter(result);
/* 280 */     int minutes = (int)(total / 60L / 1000L);
/* 281 */     int seconds = (int)(total / 1000L) % 60;
/* 282 */     int milliseconds = (int)(total / 1000L) % 1000;
/* 283 */     writer.printf("%02d:%02d.%03d", new Object[] { Integer.valueOf(minutes), Integer.valueOf(seconds), Integer.valueOf(milliseconds) }).close();
/* 284 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   class WaitForConnectionJob
/*     */     extends Job
/*     */   {
/*     */     private ListeningConnector fConnector;
/*     */ 
/*     */     
/*     */     private Map<String, Connector.Argument> fArguments;
/*     */ 
/*     */     
/*     */     private boolean fListeningStopped = false;
/*     */ 
/*     */ 
/*     */     
/*     */     public WaitForConnectionJob(ListeningConnector connector, Map<String, Connector.Argument> arguments) {
/* 303 */       super(SocketListenConnectorProcess.this.getLabel());
/* 304 */       this.fConnector = connector;
/* 305 */       this.fArguments = arguments;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected IStatus run(IProgressMonitor monitor) {
/*     */       try {
/* 314 */         Connector.Argument timeout = this.fArguments.get("timeout");
/* 315 */         if (timeout != null) {
/* 316 */           timeout.setValue("3000");
/*     */         }
/*     */         
/* 319 */         VirtualMachine vm = null;
/* 320 */         while (vm == null && !monitor.isCanceled()) {
/*     */           try {
/* 322 */             vm = this.fConnector.accept(this.fArguments);
/* 323 */           } catch (TransportTimeoutException transportTimeoutException) {}
/*     */         } 
/*     */ 
/*     */         
/* 327 */         if (monitor.isCanceled()) {
/* 328 */           this.fConnector.stopListening(this.fArguments);
/* 329 */           return Status.CANCEL_STATUS;
/*     */         } 
/*     */         
/* 332 */         ILaunchConfiguration configuration = SocketListenConnectorProcess.this.fLaunch.getLaunchConfiguration();
/* 333 */         boolean allowTerminate = false;
/* 334 */         if (configuration != null) {
/*     */           try {
/* 336 */             allowTerminate = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_ALLOW_TERMINATE, false);
/* 337 */           } catch (CoreException e) {
/* 338 */             LaunchingPlugin.log((Throwable)e);
/*     */           } 
/*     */         }
/* 341 */         Connector.Argument portArg = this.fArguments.get("port");
/* 342 */         String vmLabel = constructVMLabel(vm, portArg.value(), SocketListenConnectorProcess.this.fLaunch.getLaunchConfiguration());
/* 343 */         IDebugTarget debugTarget = JDIDebugModel.newDebugTarget(SocketListenConnectorProcess.this.fLaunch, vm, vmLabel, null, allowTerminate, true);
/* 344 */         SocketListenConnectorProcess.this.fLaunch.addDebugTarget(debugTarget);
/* 345 */         SocketListenConnectorProcess.this.fAccepted++;
/* 346 */         return Status.OK_STATUS;
/* 347 */       } catch (IOException e) {
/* 348 */         if (this.fListeningStopped) {
/* 349 */           return Status.CANCEL_STATUS;
/*     */         }
/* 351 */         return SocketListenConnectorProcess.getStatus(LaunchingMessages.SocketListenConnectorProcess_4, e, 113);
/* 352 */       } catch (IllegalConnectorArgumentsException e) {
/* 353 */         return SocketListenConnectorProcess.getStatus(LaunchingMessages.SocketListenConnectorProcess_4, e, 113);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void canceling() {
/* 362 */       stopListening();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void stopListening() {
/* 372 */       if (!this.fListeningStopped) {
/*     */         try {
/* 374 */           this.fListeningStopped = true;
/* 375 */           this.fConnector.stopListening(this.fArguments);
/* 376 */         } catch (IOException e) {
/* 377 */           done(SocketListenConnectorProcess.getStatus(LaunchingMessages.SocketListenConnectorProcess_5, e, 113));
/* 378 */         } catch (IllegalConnectorArgumentsException e) {
/* 379 */           done(SocketListenConnectorProcess.getStatus(LaunchingMessages.SocketListenConnectorProcess_5, e, 113));
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected String constructVMLabel(VirtualMachine vm, String port, ILaunchConfiguration configuration) {
/* 392 */       String name = null;
/*     */       try {
/* 394 */         name = vm.name();
/* 395 */       } catch (TimeoutException timeoutException) {
/*     */       
/* 397 */       } catch (VMDisconnectedException vMDisconnectedException) {}
/*     */ 
/*     */       
/* 400 */       if (name == null) {
/* 401 */         if (configuration == null) {
/* 402 */           name = "";
/*     */         } else {
/* 404 */           name = configuration.getName();
/*     */         } 
/*     */       }
/* 407 */       StringBuilder buffer = new StringBuilder(name);
/* 408 */       if (SocketListenConnectorProcess.this.fConnectionLimit != 1)
/*     */       {
/*     */         
/* 411 */         buffer.append('<').append(SocketListenConnectorProcess.this.getRunningTime()).append('>');
/*     */       }
/* 413 */       buffer.append('[');
/* 414 */       buffer.append(port);
/* 415 */       buffer.append(']');
/* 416 */       return buffer.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\SocketListenConnectorProcess.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */