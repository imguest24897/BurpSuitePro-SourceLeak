/*    */ package org.eclipse.jdt.internal.launching.sourcelookup.advanced;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.IStatus;
/*    */ import org.eclipse.core.runtime.MultiStatus;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.core.runtime.SubMonitor;
/*    */ import org.eclipse.core.runtime.jobs.Job;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BackgroundProcessingJob
/*    */   extends Job
/*    */ {
/*    */   private static final long EXECUTION_DELAY = 1000L;
/* 35 */   private final ArrayList<IRunnableWithProgress> queue = new ArrayList<>();
/*    */   
/*    */   public BackgroundProcessingJob() {
/* 38 */     super(Messages.BackgroundProcessingJob_name);
/*    */   }
/*    */ 
/*    */   
/*    */   protected IStatus run(IProgressMonitor monitor) {
/*    */     ArrayList<IRunnableWithProgress> tasks;
/* 44 */     synchronized (this.queue) {
/* 45 */       tasks = new ArrayList<>(this.queue);
/* 46 */       this.queue.clear();
/*    */     } 
/*    */     
/* 49 */     SubMonitor progress = SubMonitor.convert(monitor, tasks.size());
/*    */     
/* 51 */     List<IStatus> errors = new ArrayList<>();
/*    */     
/* 53 */     for (IRunnableWithProgress task : tasks) {
/*    */       try {
/* 55 */         task.run((IProgressMonitor)progress.split(1));
/*    */       }
/* 57 */       catch (CoreException e) {
/* 58 */         errors.add(e.getStatus());
/*    */       } 
/*    */     } 
/*    */     
/* 62 */     if (errors.isEmpty()) {
/* 63 */       return Status.OK_STATUS;
/*    */     }
/*    */     
/* 66 */     if (errors.size() == 1) {
/* 67 */       return errors.get(0);
/*    */     }
/*    */     
/* 70 */     return (IStatus)new MultiStatus("org.eclipse.jdt.launching", 4, errors.<IStatus>toArray(new IStatus[errors.size()]), Messages.BackgroundProcessingJob_failed, null);
/*    */   }
/*    */   
/*    */   public void schedule(IRunnableWithProgress task) {
/* 74 */     synchronized (this.queue) {
/* 75 */       this.queue.add(task);
/* 76 */       schedule(1000L);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\sourcelookup\advanced\BackgroundProcessingJob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */