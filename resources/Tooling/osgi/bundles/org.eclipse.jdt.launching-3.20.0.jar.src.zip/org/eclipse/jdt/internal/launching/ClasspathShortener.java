/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.jar.Attributes;
/*     */ import java.util.jar.Manifest;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.URIUtil;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.IStatusHandler;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstall2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClasspathShortener
/*     */   implements IProcessTempFileCreator
/*     */ {
/*     */   private static final String CLASSPATH_ENV_VAR_PREFIX = "CLASSPATH=";
/*     */   public static final int ARG_MAX_LINUX = 2097152;
/*     */   public static final int ARG_MAX_WINDOWS = 32767;
/*     */   public static final int ARG_MAX_MACOS = 262144;
/*     */   public static final int MAX_ARG_STRLEN_LINUX = 131072;
/*     */   private final String os;
/*     */   private final String javaVersion;
/*     */   private final ILaunch launch;
/*     */   private final List<String> cmdLine;
/*     */   private int lastJavaArgumentIndex;
/*     */   private String[] envp;
/*     */   private File processTempFilesDir;
/*  68 */   private final List<File> processTempFiles = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClasspathShortener(IVMInstall vmInstall, ILaunch launch, String[] cmdLine, int lastJavaArgumentIndex, File workingDir, String[] envp) {
/*  87 */     this(Platform.getOS(), getJavaVersion(vmInstall), launch, cmdLine, lastJavaArgumentIndex, workingDir, envp);
/*     */   }
/*     */   
/*     */   protected ClasspathShortener(String os, String javaVersion, ILaunch launch, String[] cmdLine, int lastJavaArgumentIndex, File workingDir, String[] envp) {
/*  91 */     Assert.isNotNull(os);
/*  92 */     Assert.isNotNull(javaVersion);
/*  93 */     Assert.isNotNull(launch);
/*  94 */     Assert.isNotNull(cmdLine);
/*  95 */     this.os = os;
/*  96 */     this.javaVersion = javaVersion;
/*  97 */     this.launch = launch;
/*  98 */     this.cmdLine = new ArrayList<>(Arrays.asList(cmdLine));
/*  99 */     this.lastJavaArgumentIndex = lastJavaArgumentIndex;
/* 100 */     this.envp = (envp == null) ? null : Arrays.<String>copyOf(envp, envp.length);
/* 101 */     this.processTempFilesDir = (workingDir != null) ? workingDir : Paths.get(".", new String[0]).toAbsolutePath().normalize().toFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProcessTempFilesDir(File processTempFilesDir) {
/* 112 */     this.processTempFilesDir = processTempFilesDir;
/*     */   }
/*     */   
/*     */   public File getProcessTempFilesDir() {
/* 116 */     return this.processTempFilesDir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getEnvp() {
/* 125 */     return this.envp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getCmdLine() {
/* 134 */     return this.cmdLine.<String>toArray(new String[this.cmdLine.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<File> getProcessTempFiles() {
/* 139 */     return new ArrayList<>(this.processTempFiles);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shortenCommandLineIfNecessary() {
/* 155 */     return shortenClasspathIfNecessary() | shortenModulePathIfNecessary();
/*     */   }
/*     */   
/*     */   private int getClasspathArgumentIndex() {
/* 159 */     for (int i = 0; i <= this.lastJavaArgumentIndex; i++) {
/* 160 */       String element = this.cmdLine.get(i);
/* 161 */       if ("-cp".equals(element) || "-classpath".equals(element) || "--class-path".equals(element)) {
/* 162 */         return i + 1;
/*     */       }
/*     */     } 
/* 165 */     return -1;
/*     */   }
/*     */   
/*     */   private int getModulepathArgumentIndex() {
/* 169 */     for (int i = 0; i <= this.lastJavaArgumentIndex; i++) {
/* 170 */       String element = this.cmdLine.get(i);
/* 171 */       if ("-p".equals(element) || "--module-path".equals(element)) {
/* 172 */         return i + 1;
/*     */       }
/*     */     } 
/* 175 */     return -1;
/*     */   }
/*     */   
/*     */   private boolean shortenModulePathIfNecessary() {
/* 179 */     int modulePathArgumentIndex = getModulepathArgumentIndex();
/* 180 */     if (modulePathArgumentIndex == -1) {
/* 181 */       return false;
/*     */     }
/*     */     try {
/* 184 */       String modulePath = this.cmdLine.get(modulePathArgumentIndex);
/* 185 */       if (getCommandLineLength() <= getMaxCommandLineLength() && modulePath.length() <= getMaxArgLength()) {
/* 186 */         return false;
/*     */       }
/* 188 */       if (isArgumentFileSupported()) {
/* 189 */         shortenPathUsingClasspathArgumentFile(modulePathArgumentIndex, "--module-path");
/* 190 */         return true;
/*     */       } 
/* 192 */     } catch (CoreException e) {
/* 193 */       LaunchingPlugin.log(e.getStatus());
/*     */     } 
/* 195 */     return false;
/*     */   }
/*     */   
/*     */   private boolean shortenClasspathIfNecessary() {
/* 199 */     int classpathArgumentIndex = getClasspathArgumentIndex();
/* 200 */     if (classpathArgumentIndex == -1) {
/* 201 */       return false;
/*     */     }
/*     */     try {
/* 204 */       boolean forceUseClasspathOnlyJar = getLaunchConfigurationUseClasspathOnlyJarAttribute();
/* 205 */       if (forceUseClasspathOnlyJar) {
/* 206 */         shortenClasspathUsingClasspathOnlyJar(classpathArgumentIndex);
/* 207 */         return true;
/*     */       } 
/* 209 */       String classpath = this.cmdLine.get(classpathArgumentIndex);
/* 210 */       if (getCommandLineLength() <= getMaxCommandLineLength() && classpath.length() <= getMaxArgLength()) {
/* 211 */         return false;
/*     */       }
/* 213 */       if (isArgumentFileSupported()) {
/* 214 */         shortenPathUsingClasspathArgumentFile(classpathArgumentIndex, "-classpath");
/* 215 */         return true;
/*     */       } 
/* 217 */       if (this.os.equals("win32")) {
/* 218 */         shortenClasspathUsingClasspathEnvVariable(classpathArgumentIndex);
/* 219 */         return true;
/* 220 */       }  if (handleClasspathTooLongStatus()) {
/* 221 */         shortenClasspathUsingClasspathOnlyJar(classpathArgumentIndex);
/* 222 */         return true;
/*     */       } 
/* 224 */     } catch (CoreException e) {
/* 225 */       LaunchingPlugin.log(e.getStatus());
/*     */     } 
/* 227 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean getLaunchConfigurationUseClasspathOnlyJarAttribute() throws CoreException {
/* 231 */     ILaunchConfiguration launchConfiguration = this.launch.getLaunchConfiguration();
/* 232 */     if (launchConfiguration == null) {
/* 233 */       return false;
/*     */     }
/* 235 */     return launchConfiguration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_USE_CLASSPATH_ONLY_JAR, false);
/*     */   }
/*     */   
/*     */   public static String getJavaVersion(IVMInstall vmInstall) {
/* 239 */     if (vmInstall instanceof IVMInstall2) {
/* 240 */       IVMInstall2 install = (IVMInstall2)vmInstall;
/* 241 */       return install.getJavaVersion();
/*     */     } 
/* 243 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isArgumentFileSupported() {
/* 247 */     return (JavaCore.compareJavaVersions(this.javaVersion, "9") >= 0);
/*     */   }
/*     */   
/*     */   private int getCommandLineLength() {
/* 251 */     return ((Integer)this.cmdLine.stream().map(argument -> Integer.valueOf(argument.length() + 1)).reduce((a, b) -> Integer.valueOf(a.intValue() + b.intValue())).get()).intValue();
/*     */   }
/*     */   
/*     */   private int getEnvironmentLength() {
/* 255 */     if (this.envp == null) {
/* 256 */       return 0;
/*     */     }
/* 258 */     return ((Integer)Arrays.<String>stream(this.envp).map(element -> Integer.valueOf(element.length() + 1)).reduce((a, b) -> Integer.valueOf(a.intValue() + b.intValue())).orElse(Integer.valueOf(0))).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getMaxCommandLineLength() {
/*     */     String str;
/* 265 */     switch ((str = this.os).hashCode()) { case -1081748635: if (!str.equals("macosx")) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 271 */         return 262144 - getEnvironmentLength() - 2048;
/*     */       case 102977780: if (!str.equals("linux"))
/*     */           break;  return 2097152 - getEnvironmentLength() - 2048;
/*     */       case 113134395: if (!str.equals("win32"))
/* 275 */           break;  return 30719; }
/*     */     
/* 277 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getMaxArgLength() {
/* 282 */     if (this.os.equals("linux"))
/*     */     {
/*     */       
/* 285 */       return 129024;
/*     */     }
/* 287 */     return Integer.MAX_VALUE;
/*     */   }
/*     */   private void shortenPathUsingClasspathArgumentFile(int modulePathArgumentIndex, String option) throws CoreException {
/*     */     File file;
/* 291 */     String path = this.cmdLine.get(modulePathArgumentIndex);
/*     */     
/*     */     try {
/* 294 */       File argFile = JavaLaunchingUtils.createFileForArgument(getLaunchTimeStamp(), this.processTempFilesDir, getLaunchConfigurationName(), "%s" + 
/* 295 */           option + "-arg-%s.txt");
/*     */       
/* 297 */       String arg = String.valueOf(option) + " " + quoteWindowsPath(path);
/* 298 */       Charset systemCharset = Platform.getSystemCharset();
/* 299 */       if (!systemCharset.newEncoder().canEncode(arg)) {
/* 300 */         throw new CoreException(new Status(4, LaunchingPlugin.getUniqueIdentifier(), 4, "Cannot encode " + option + 
/* 301 */               " as argument file with system charset " + 
/* 302 */               systemCharset.displayName() + ".", null));
/*     */       }
/* 304 */       Files.writeString(argFile.toPath(), arg, systemCharset, new java.nio.file.OpenOption[0]);
/* 305 */       file = argFile;
/* 306 */     } catch (IOException e) {
/* 307 */       throw new CoreException(new Status(4, LaunchingPlugin.getUniqueIdentifier(), 4, "Cannot create " + option + 
/* 308 */             " argument file", e));
/*     */     } 
/*     */     
/* 311 */     removeCmdLineArgs(modulePathArgumentIndex - 1, 2);
/* 312 */     addCmdLineArgs(modulePathArgumentIndex - 1, new String[] { String.valueOf('@') + file.getAbsolutePath() });
/* 313 */     addProcessTempFile(file);
/*     */   }
/*     */   
/*     */   private void shortenClasspathUsingClasspathOnlyJar(int classpathArgumentIndex) throws CoreException {
/* 317 */     String classpath = this.cmdLine.get(classpathArgumentIndex);
/* 318 */     File classpathOnlyJar = createClasspathOnlyJar(classpath);
/* 319 */     removeCmdLineArgs(classpathArgumentIndex, 1);
/* 320 */     addCmdLineArgs(classpathArgumentIndex, new String[] { classpathOnlyJar.getAbsolutePath() });
/* 321 */     addProcessTempFile(classpathOnlyJar);
/*     */   }
/*     */   
/*     */   protected void addProcessTempFile(File file) {
/* 325 */     this.processTempFiles.add(file);
/*     */   }
/*     */   
/*     */   protected boolean handleClasspathTooLongStatus() throws CoreException {
/* 329 */     Status status = new Status(4, LaunchingPlugin.getUniqueIdentifier(), 125, "", null);
/* 330 */     IStatusHandler handler = DebugPlugin.getDefault().getStatusHandler((IStatus)status);
/* 331 */     if (handler == null) {
/* 332 */       return false;
/*     */     }
/* 334 */     Object result = handler.handleStatus((IStatus)status, this.launch);
/* 335 */     if (!(result instanceof Boolean)) {
/* 336 */       return false;
/*     */     }
/* 338 */     return ((Boolean)result).booleanValue();
/*     */   }
/*     */   
/*     */   private File createClasspathOnlyJar(String classpath) throws CoreException {
/*     */     try {
/* 343 */       File jarFile = JavaLaunchingUtils.createFileForArgument(getLaunchTimeStamp(), this.processTempFilesDir, getLaunchConfigurationName(), "%s-classpathOnly-%s.jar");
/* 344 */       URI workingDirUri = this.processTempFilesDir.toURI();
/* 345 */       StringBuilder manifestClasspath = new StringBuilder();
/* 346 */       String[] classpathArray = getClasspathAsArray(classpath);
/* 347 */       for (int i = 0; i < classpathArray.length; i++) {
/* 348 */         if (i != 0) {
/* 349 */           manifestClasspath.append(' ');
/*     */         }
/* 351 */         File file = new File(classpathArray[i]);
/* 352 */         String relativePath = URIUtil.makeRelative(file.toURI(), workingDirUri).toString();
/* 353 */         manifestClasspath.append(relativePath);
/*     */       } 
/* 355 */       Manifest manifest = new Manifest();
/* 356 */       manifest.getMainAttributes().put(Attributes.Name.MANIFEST_VERSION, "1.0");
/* 357 */       manifest.getMainAttributes().put(Attributes.Name.CLASS_PATH, manifestClasspath.toString());
/* 358 */       Exception exception1 = null, exception2 = null;
/*     */ 
/*     */     
/*     */     }
/* 362 */     catch (IOException e) {
/* 363 */       throw new CoreException(new Status(4, LaunchingPlugin.getUniqueIdentifier(), 4, "Cannot create classpath only jar", e));
/*     */     } 
/*     */   }
/*     */   
/*     */   private String[] getClasspathAsArray(String classpath) {
/* 368 */     return classpath.split(getPathSeparatorChar());
/*     */   }
/*     */   
/*     */   protected char getPathSeparatorChar() {
/* 372 */     char separator = ':';
/* 373 */     if (this.os.equals("win32")) {
/* 374 */       separator = ';';
/*     */     }
/* 376 */     return separator;
/*     */   }
/*     */   
/*     */   protected String getLaunchConfigurationName() {
/* 380 */     return this.launch.getLaunchConfiguration().getName();
/*     */   }
/*     */   
/*     */   protected String getLaunchTimeStamp() {
/* 384 */     return JavaLaunchingUtils.getLaunchTimeStamp(this.launch);
/*     */   }
/*     */   
/*     */   private String[] getEnvpFromNativeEnvironment() {
/* 388 */     Map<String, String> nativeEnvironment = getNativeEnvironment();
/* 389 */     String[] envp = new String[nativeEnvironment.size()];
/* 390 */     int idx = 0;
/* 391 */     for (Map.Entry<String, String> entry : nativeEnvironment.entrySet()) {
/* 392 */       String value = entry.getValue();
/* 393 */       if (value == null) {
/* 394 */         value = "";
/*     */       }
/* 396 */       String key = entry.getKey();
/* 397 */       envp[idx] = String.valueOf(key) + '=' + value;
/* 398 */       idx++;
/*     */     } 
/* 400 */     return envp;
/*     */   }
/*     */   
/*     */   protected Map<String, String> getNativeEnvironment() {
/* 404 */     return DebugPlugin.getDefault().getLaunchManager().getNativeEnvironment();
/*     */   }
/*     */   
/*     */   private void shortenClasspathUsingClasspathEnvVariable(int classpathArgumentIndex) {
/* 408 */     String classpath = this.cmdLine.get(classpathArgumentIndex);
/* 409 */     if (this.envp == null) {
/* 410 */       this.envp = getEnvpFromNativeEnvironment();
/*     */     }
/* 412 */     String classpathEnvVar = "CLASSPATH=" + classpath;
/* 413 */     int index = getEnvClasspathIndex(this.envp);
/* 414 */     if (index < 0) {
/* 415 */       this.envp = Arrays.<String>copyOf(this.envp, this.envp.length + 1);
/* 416 */       this.envp[this.envp.length - 1] = classpathEnvVar;
/*     */     } else {
/* 418 */       this.envp[index] = classpathEnvVar;
/*     */     } 
/* 420 */     removeCmdLineArgs(classpathArgumentIndex - 1, 2);
/*     */   }
/*     */   
/*     */   private void removeCmdLineArgs(int index, int length) {
/* 424 */     for (int i = 0; i < length; i++) {
/* 425 */       this.cmdLine.remove(index);
/* 426 */       this.lastJavaArgumentIndex--;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addCmdLineArgs(int index, String... newArgs) {
/* 431 */     this.cmdLine.addAll(index, Arrays.asList(newArgs));
/* 432 */     this.lastJavaArgumentIndex += newArgs.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getEnvClasspathIndex(String[] env) {
/* 443 */     if (env != null) {
/* 444 */       for (int i = 0; i < env.length; i++) {
/* 445 */         if (env[i].regionMatches(true, 0, "CLASSPATH=", 0, 10)) {
/* 446 */           return i;
/*     */         }
/*     */       } 
/*     */     }
/* 450 */     return -1;
/*     */   }
/*     */   
/*     */   public String quoteWindowsPath(String path) {
/* 454 */     if (this.os.equals("win32")) {
/* 455 */       int length = path.length();
/* 456 */       StringBuilder newPath = new StringBuilder(length);
/* 457 */       boolean insideQuote = false;
/* 458 */       for (int i = 0; i < length; i++) {
/* 459 */         char c = path.charAt(i);
/* 460 */         if (c == ' ' && !insideQuote) {
/* 461 */           newPath.append('"');
/* 462 */           insideQuote = true;
/* 463 */         } else if (insideQuote) {
/* 464 */           newPath.append('"');
/* 465 */           insideQuote = false;
/*     */         } 
/* 467 */         newPath.append(c);
/*     */       } 
/* 469 */       return newPath.toString();
/*     */     } 
/* 471 */     return path;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\ClasspathShortener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */