/*     */ package org.eclipse.jdt.internal.launching.sourcelookup.advanced;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HasherImpl
/*     */   implements FileHashing.Hasher
/*     */ {
/*     */   private final Map<FileHashing.CacheKey, FileHashing.HashCode> cache;
/*     */   
/*     */   public HasherImpl(final int cacheSize) {
/* 131 */     this.cache = new LinkedHashMap<FileHashing.CacheKey, FileHashing.HashCode>()
/*     */       {
/*     */         protected boolean removeEldestEntry(Map.Entry<FileHashing.CacheKey, FileHashing.HashCode> eldest) {
/* 134 */           return (size() > cacheSize);
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   public HasherImpl(HasherImpl initial) {
/* 140 */     this.cache = new LinkedHashMap<>(initial.cache);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object hash(File file) {
/* 145 */     if (file == null || !file.isFile()) {
/* 146 */       return null;
/*     */     }
/*     */     try {
/* 149 */       FileHashing.CacheKey cacheKey = new FileHashing.CacheKey(file);
/* 150 */       synchronized (this.cache) {
/* 151 */         FileHashing.HashCode hashCode1 = this.cache.get(cacheKey);
/* 152 */         if (hashCode1 != null) {
/* 153 */           return hashCode1;
/*     */         }
/*     */       } 
/*     */       
/* 157 */       FileHashing.HashCode hashCode = FileHashing.sha1(file);
/* 158 */       synchronized (this.cache) {
/* 159 */         this.cache.put(cacheKey, hashCode);
/*     */       } 
/* 161 */       return hashCode;
/*     */     }
/* 163 */     catch (IOException iOException) {
/* 164 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\sourcelookup\advanced\FileHashing$HasherImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */