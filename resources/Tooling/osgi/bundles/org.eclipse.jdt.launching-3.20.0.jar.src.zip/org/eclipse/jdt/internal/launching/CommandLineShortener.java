/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.CharacterCodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstall2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommandLineShortener
/*     */   implements IProcessTempFileCreator
/*     */ {
/*     */   private final String javaVersion;
/*     */   private final ILaunch launch;
/*     */   private final String[] cmdLine;
/*     */   private File processTempFilesDir;
/*     */   
/*     */   public static String getJavaVersion(IVMInstall vmInstall) {
/*  43 */     if (vmInstall instanceof IVMInstall2) {
/*  44 */       IVMInstall2 install = (IVMInstall2)vmInstall;
/*  45 */       return install.getJavaVersion();
/*     */     } 
/*  47 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   private final List<File> processTempFiles = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandLineShortener(IVMInstall vmInstall, ILaunch launch, String[] cmdLine, File workingDir) {
/*  74 */     this(getJavaVersion(vmInstall), launch, cmdLine, workingDir);
/*     */   }
/*     */   
/*     */   protected CommandLineShortener(String javaVersion, ILaunch launch, String[] cmdLine, File workingDir) {
/*  78 */     Assert.isNotNull(javaVersion);
/*  79 */     Assert.isNotNull(launch);
/*  80 */     Assert.isNotNull(cmdLine);
/*  81 */     this.javaVersion = javaVersion;
/*  82 */     this.launch = launch;
/*  83 */     this.cmdLine = cmdLine;
/*  84 */     this.processTempFilesDir = (workingDir != null) ? workingDir : Paths.get(".", new String[0]).toAbsolutePath().normalize().toFile();
/*     */   }
/*     */   
/*     */   protected void addProcessTempFile(File file) {
/*  88 */     this.processTempFiles.add(file);
/*     */   }
/*     */   
/*     */   protected File createArgumentFile(String[] cmdLine) throws CoreException {
/*  92 */     Charset systemCharset = Platform.getSystemCharset();
/*     */     try {
/*  94 */       File argumentsFile = JavaLaunchingUtils.createFileForArgument(getLaunchTimeStamp(), this.processTempFilesDir, getLaunchConfigurationName(), "%s-args-%s.txt");
/*  95 */       cmdLine = quoteForArgfile(cmdLine);
/*     */       
/*  97 */       Files.write(argumentsFile.toPath(), Arrays.asList((CharSequence[])cmdLine), systemCharset, new java.nio.file.OpenOption[0]);
/*  98 */       return argumentsFile;
/*  99 */     } catch (CharacterCodingException e) {
/* 100 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = cmdLine).length, b = 0; b < i; ) { String s = arrayOfString[b]; byte b1; int j; char[] arrayOfChar;
/* 101 */         for (j = (arrayOfChar = s.toCharArray()).length, b1 = 0; b1 < j; ) { char c = arrayOfChar[b1];
/* 102 */           if (!systemCharset.newEncoder().canEncode(c))
/* 103 */             throw new CoreException(new Status(4, LaunchingPlugin.getUniqueIdentifier(), 4, "Cannot encode argument as file: Illegal character " + 
/* 104 */                   String.format("\\u%04x", new Object[] { Integer.valueOf(c)
/* 105 */                     }) + " for system charset " + systemCharset.displayName() + ".", e)); 
/*     */           b1++; }
/*     */         
/*     */         b++; }
/*     */       
/* 110 */       throw new CoreException(new Status(4, LaunchingPlugin.getUniqueIdentifier(), 4, "Cannot encode argument as file", e));
/* 111 */     } catch (IOException e) {
/* 112 */       throw new CoreException(new Status(4, LaunchingPlugin.getUniqueIdentifier(), 4, "Cannot create argument file", e));
/*     */     } 
/*     */   }
/*     */   
/*     */   String[] quoteForArgfile(String[] cmdLine) {
/* 117 */     String[] quotedCmdLine = new String[cmdLine.length];
/* 118 */     for (int i = 0; i < cmdLine.length; i++) {
/* 119 */       String arg = cmdLine[i];
/* 120 */       if (CommandLineQuoting.needsQuoting(arg)) {
/* 121 */         StringBuilder escapedArg = new StringBuilder();
/* 122 */         for (int j = 0; j < arg.length(); j++) {
/* 123 */           char c = arg.charAt(j);
/* 124 */           if (c == '\\') {
/* 125 */             escapedArg.append('\\');
/* 126 */           } else if (c == '"') {
/* 127 */             escapedArg.append('\\');
/*     */           } 
/* 129 */           escapedArg.append(c);
/*     */         } 
/* 131 */         arg = "\"" + escapedArg.toString() + "\"";
/*     */       } 
/* 133 */       quotedCmdLine[i] = arg;
/*     */     } 
/* 135 */     return quotedCmdLine;
/*     */   }
/*     */   
/*     */   protected String getLaunchConfigurationName() {
/* 139 */     return this.launch.getLaunchConfiguration().getName();
/*     */   }
/*     */   
/*     */   protected String getLaunchTimeStamp() {
/* 143 */     return JavaLaunchingUtils.getLaunchTimeStamp(this.launch);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<File> getProcessTempFiles() {
/* 148 */     return new ArrayList<>(this.processTempFiles);
/*     */   }
/*     */   
/*     */   public File getProcessTempFilesDir() {
/* 152 */     return this.processTempFilesDir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getOriginalCmdLine() {
/* 159 */     return this.cmdLine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isArgumentFileSupported() {
/* 166 */     return (JavaCore.compareJavaVersions(this.javaVersion, "9") >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProcessTempFilesDir(File processTempFilesDir) {
/* 177 */     this.processTempFilesDir = processTempFilesDir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] shortenCommandLine() throws CoreException {
/* 187 */     List<String> fullCommandLine = new ArrayList<>(Arrays.asList(this.cmdLine));
/* 188 */     List<String> shortCommandLine = new ArrayList<>();
/*     */     
/* 190 */     shortCommandLine.add(fullCommandLine.remove(0));
/*     */     
/* 192 */     File argumentFile = createArgumentFile(fullCommandLine.<String>toArray(new String[fullCommandLine.size()]));
/* 193 */     addProcessTempFile(argumentFile);
/* 194 */     shortCommandLine.add("@" + argumentFile.getAbsolutePath());
/*     */     
/* 196 */     return shortCommandLine.<String>toArray(new String[shortCommandLine.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean shouldShortenCommandLine() throws CoreException {
/* 210 */     if (!isArgumentFileSupported()) {
/* 211 */       return false;
/*     */     }
/*     */     
/* 214 */     if (this.cmdLine.length < 2)
/*     */     {
/* 216 */       return false;
/*     */     }
/*     */     
/* 219 */     ILaunchConfiguration configuration = this.launch.getLaunchConfiguration();
/* 220 */     if (configuration != null) {
/* 221 */       return configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_USE_ARGFILE, false);
/*     */     }
/*     */     
/* 224 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\CommandLineShortener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */