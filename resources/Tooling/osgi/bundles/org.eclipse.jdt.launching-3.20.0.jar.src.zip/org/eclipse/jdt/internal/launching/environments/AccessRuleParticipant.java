/*     */ package org.eclipse.jdt.internal.launching.environments;
/*     */ 
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.jdt.core.IAccessRule;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.LibraryLocation;
/*     */ import org.eclipse.jdt.launching.environments.IAccessRuleParticipant;
/*     */ import org.eclipse.jdt.launching.environments.IExecutionEnvironment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AccessRuleParticipant
/*     */   implements IAccessRuleParticipant
/*     */ {
/*     */   private IConfigurationElement fElement;
/*     */   private IAccessRuleParticipant fDelegate;
/*     */   
/*     */   AccessRuleParticipant(IConfigurationElement element) {
/*  46 */     this.fElement = element;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IAccessRule[][] getAccessRules(IExecutionEnvironment environment, IVMInstall vm, LibraryLocation[] libraries, IJavaProject project) {
/*     */     try {
/*  55 */       return getDelegate().getAccessRules(environment, vm, libraries, project);
/*  56 */     } catch (CoreException e) {
/*  57 */       LaunchingPlugin.log(e.getStatus());
/*     */       
/*  59 */       IAccessRule[][] rules = new IAccessRule[libraries.length][];
/*  60 */       for (int i = 0; i < rules.length; i++) {
/*  61 */         rules[i] = new IAccessRule[0];
/*     */       }
/*  63 */       return rules;
/*     */     } 
/*     */   }
/*     */   private IAccessRuleParticipant getDelegate() throws CoreException {
/*  67 */     if (this.fDelegate == null) {
/*  68 */       if (this.fElement.getName().equals("environment")) {
/*  69 */         this.fDelegate = (IAccessRuleParticipant)this.fElement.createExecutableExtension("ruleParticipant");
/*     */       } else {
/*  71 */         this.fDelegate = (IAccessRuleParticipant)this.fElement.createExecutableExtension("class");
/*     */       } 
/*     */     }
/*  74 */     return this.fDelegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getId() {
/*  83 */     if (this.fElement.getName().equals("environment")) {
/*  84 */       return this.fElement.getAttribute("ruleParticipant");
/*     */     }
/*  86 */     return this.fElement.getAttribute("id");
/*     */   }
/*     */   
/*     */   private String getDelegateClassName() {
/*  90 */     if (this.fElement.getName().equals("environment")) {
/*  91 */       return this.fElement.getAttribute("ruleParticipant");
/*     */     }
/*  93 */     return this.fElement.getAttribute("class");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 101 */     if (obj instanceof AccessRuleParticipant) {
/* 102 */       AccessRuleParticipant participant = (AccessRuleParticipant)obj;
/* 103 */       return participant.getDelegateClassName().equals(getDelegateClassName());
/*     */     } 
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 113 */     return getDelegateClassName().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 121 */     return getDelegateClassName();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\environments\AccessRuleParticipant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */