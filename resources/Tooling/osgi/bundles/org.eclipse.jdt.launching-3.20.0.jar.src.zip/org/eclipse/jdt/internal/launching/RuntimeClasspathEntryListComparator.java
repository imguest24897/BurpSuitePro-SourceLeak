/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RuntimeClasspathEntryListComparator
/*    */   implements Comparator<Object>
/*    */ {
/*    */   public int compare(Object o1, Object o2) {
/* 30 */     List<?> list1 = (List)o1;
/* 31 */     List<?> list2 = (List)o2;
/*    */     
/* 33 */     if (list1.size() == list2.size()) {
/* 34 */       for (int i = 0; i < list1.size(); i++) {
/* 35 */         String memento1 = (String)list1.get(i);
/* 36 */         String memento2 = (String)list2.get(i);
/* 37 */         if (!equalsIgnoreWhitespace(memento1, memento2)) {
/* 38 */           return -1;
/*    */         }
/*    */       } 
/* 41 */       return 0;
/*    */     } 
/* 43 */     return -1;
/*    */   }
/*    */   
/*    */   protected boolean equalsIgnoreWhitespace(String one, String two) {
/* 47 */     int i1 = 0;
/* 48 */     int i2 = 0;
/* 49 */     int l1 = one.length();
/* 50 */     int l2 = two.length();
/* 51 */     char ch1 = ' ';
/* 52 */     char ch2 = ' ';
/* 53 */     while (i1 < l1 && i2 < l2) {
/* 54 */       while (i1 < l1 && Character.isWhitespace(ch1 = one.charAt(i1))) {
/* 55 */         i1++;
/*    */       }
/* 57 */       while (i2 < l2 && Character.isWhitespace(ch2 = two.charAt(i2))) {
/* 58 */         i2++;
/*    */       }
/* 60 */       if (i1 == l1 && i2 == l2) {
/* 61 */         return true;
/*    */       }
/* 63 */       if (ch1 != ch2) {
/* 64 */         return false;
/*    */       }
/* 66 */       i1++;
/* 67 */       i2++;
/*    */     } 
/* 69 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\RuntimeClasspathEntryListComparator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */