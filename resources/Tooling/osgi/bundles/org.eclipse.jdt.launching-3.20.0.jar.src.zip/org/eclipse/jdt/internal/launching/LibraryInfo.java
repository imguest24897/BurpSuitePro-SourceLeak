/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LibraryInfo
/*    */ {
/*    */   private String fVersion;
/*    */   private String[] fBootpath;
/*    */   private String[] fExtensionDirs;
/*    */   private String[] fEndorsedDirs;
/*    */   
/*    */   public LibraryInfo(String version, String[] bootpath, String[] extDirs, String[] endDirs) {
/* 28 */     this.fVersion = version;
/* 29 */     this.fBootpath = bootpath;
/* 30 */     this.fExtensionDirs = extDirs;
/* 31 */     this.fEndorsedDirs = endDirs;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getVersion() {
/* 40 */     return this.fVersion;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getExtensionDirs() {
/* 49 */     return this.fExtensionDirs;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getBootpath() {
/* 58 */     return this.fBootpath;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getEndorsedDirs() {
/* 67 */     return this.fEndorsedDirs;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\LibraryInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */