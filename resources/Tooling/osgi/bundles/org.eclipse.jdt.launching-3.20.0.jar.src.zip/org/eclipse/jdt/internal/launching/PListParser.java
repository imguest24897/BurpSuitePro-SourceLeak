/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.Text;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PListParser
/*     */ {
/*     */   private static final String PLIST_ELEMENT = "plist";
/*     */   private static final String KEY_ELEMENT = "key";
/*     */   private static final String DICT_ELEMENT = "dict";
/*     */   private static final String ARRAY_ELEMENT = "array";
/*     */   private static final String TRUE_ELEMENT = "true";
/*     */   private static final String FALSE_ELEMENT = "false";
/*     */   private static final String INT_ELEMENT = "integer";
/*     */   private static final String STRING_ELEMENT = "string";
/*     */   
/*     */   public Object parse(InputStream stream) throws CoreException {
/*     */     try {
/*  67 */       stream = new BufferedInputStream(stream);
/*  68 */       return parseXML(stream);
/*  69 */     } catch (FileNotFoundException e) {
/*  70 */       abort(e);
/*  71 */     } catch (SAXException e) {
/*  72 */       abort(e);
/*  73 */     } catch (ParserConfigurationException e) {
/*  74 */       abort(e);
/*  75 */     } catch (IOException e) {
/*  76 */       abort(e);
/*     */     } finally {
/*  78 */       if (stream != null) {
/*     */         try {
/*  80 */           stream.close();
/*  81 */         } catch (IOException e) {
/*  82 */           abort(e);
/*     */         } 
/*     */       }
/*     */     } 
/*  86 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object parseXML(InputStream stream) throws CoreException, ParserConfigurationException, IOException, SAXException {
/* 102 */     Element root = null;
/* 103 */     DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
/*     */     try {
/* 105 */       documentBuilderFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
/*     */     }
/* 107 */     catch (ParserConfigurationException parserConfigurationException) {}
/*     */ 
/*     */ 
/*     */     
/* 111 */     DocumentBuilder parser = documentBuilderFactory.newDocumentBuilder();
/* 112 */     parser.setErrorHandler(new DefaultHandler());
/* 113 */     root = parser.parse(new InputSource(stream)).getDocumentElement();
/* 114 */     if (!root.getNodeName().equalsIgnoreCase("plist")) {
/* 115 */       throw getInvalidFormatException();
/*     */     }
/* 117 */     NodeList list = root.getChildNodes();
/* 118 */     Node node = null;
/* 119 */     Element element = null;
/* 120 */     for (int i = 0; i < list.getLength(); i++) {
/* 121 */       node = list.item(i);
/* 122 */       short nodeType = node.getNodeType();
/* 123 */       if (nodeType == 1) {
/* 124 */         element = (Element)node;
/* 125 */         return parseObject(element);
/*     */       } 
/*     */     } 
/* 128 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CoreException getInvalidFormatException() {
/* 137 */     return new CoreException((IStatus)new Status(4, "org.eclipse.jdt.launching", "Invalid plist XML", null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object parseObject(Element element) throws CoreException {
/* 148 */     String nodeName = element.getNodeName();
/* 149 */     if (nodeName.equalsIgnoreCase("array"))
/* 150 */       return parseArray(element); 
/* 151 */     if (nodeName.equalsIgnoreCase("dict"))
/* 152 */       return parseDictionary(element); 
/* 153 */     if (nodeName.equalsIgnoreCase("key"))
/* 154 */       return getText(element); 
/* 155 */     if (nodeName.equalsIgnoreCase("true"))
/* 156 */       return Boolean.TRUE; 
/* 157 */     if (nodeName.equalsIgnoreCase("false"))
/* 158 */       return Boolean.FALSE; 
/* 159 */     if (nodeName.equalsIgnoreCase("integer")) {
/*     */       try {
/* 161 */         return Integer.valueOf(Integer.parseInt(getText(element)));
/* 162 */       } catch (NumberFormatException e) {
/* 163 */         abort(e);
/*     */       } 
/* 165 */     } else if (nodeName.equalsIgnoreCase("string")) {
/* 166 */       return getText(element);
/*     */     } 
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object[] parseArray(Element root) throws CoreException {
/* 179 */     List<Object> collection = new ArrayList();
/* 180 */     NodeList list = root.getChildNodes();
/* 181 */     Node node = null;
/* 182 */     Element element = null;
/* 183 */     for (int i = 0; i < list.getLength(); i++) {
/* 184 */       node = list.item(i);
/* 185 */       short nodeType = node.getNodeType();
/* 186 */       if (nodeType == 1) {
/* 187 */         element = (Element)node;
/* 188 */         Object obj = parseObject(element);
/* 189 */         if (obj != null) {
/* 190 */           collection.add(obj);
/*     */         }
/*     */       } 
/*     */     } 
/* 194 */     return collection.toArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Object> parseDictionary(Element root) throws CoreException {
/* 205 */     Map<String, Object> dict = new HashMap<>();
/* 206 */     NodeList list = root.getChildNodes();
/* 207 */     Node node = null;
/* 208 */     Element element = null;
/* 209 */     String nodeName = null;
/* 210 */     String key = null;
/* 211 */     for (int i = 0; i < list.getLength(); i++) {
/* 212 */       node = list.item(i);
/* 213 */       short nodeType = node.getNodeType();
/* 214 */       if (nodeType == 1) {
/* 215 */         element = (Element)node;
/* 216 */         nodeName = element.getNodeName();
/* 217 */         if (nodeName.equalsIgnoreCase("key")) {
/* 218 */           key = getText(element);
/*     */         } else {
/* 220 */           dict.put(key, parseObject(element));
/*     */         } 
/*     */       } 
/*     */     } 
/* 224 */     return dict;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getText(Element root) {
/* 235 */     NodeList list = root.getChildNodes();
/* 236 */     Node node = null;
/* 237 */     for (int i = 0; i < list.getLength(); i++) {
/* 238 */       node = list.item(i);
/* 239 */       short nodeType = node.getNodeType();
/* 240 */       if (nodeType == 3) {
/* 241 */         return ((Text)node).getNodeValue();
/*     */       }
/*     */     } 
/* 244 */     return null;
/*     */   }
/*     */   
/*     */   private void abort(Throwable t) throws CoreException {
/* 248 */     throw new CoreException(new Status(4, "org.eclipse.jdt.launching", "Exception occurred parsing property list", t));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\PListParser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */