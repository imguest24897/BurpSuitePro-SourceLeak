/*     */ package org.eclipse.jdt.launching;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IModuleDescription;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingMessages;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaLaunchDelegate
/*     */   extends AbstractJavaLaunchConfigurationDelegate
/*     */ {
/*     */   public String showCommandLine(ILaunchConfiguration configuration, String mode, ILaunch launch, IProgressMonitor monitor) throws CoreException {
/*     */     NullProgressMonitor nullProgressMonitor;
/*  44 */     if (monitor == null) {
/*  45 */       nullProgressMonitor = new NullProgressMonitor();
/*     */     }
/*     */     try {
/*  48 */       VMRunnerConfiguration runConfig = getVMRunnerConfiguration(configuration, mode, (IProgressMonitor)nullProgressMonitor);
/*  49 */       if (runConfig == null) {
/*  50 */         return "";
/*     */       }
/*  52 */       IVMRunner runner = getVMRunner(configuration, mode);
/*  53 */       String cmdLine = runner.showCommandLine(runConfig, launch, (IProgressMonitor)nullProgressMonitor);
/*     */ 
/*     */       
/*  56 */       if (nullProgressMonitor.isCanceled()) {
/*  57 */         return "";
/*     */       }
/*  59 */       return cmdLine;
/*     */     } finally {
/*  61 */       nullProgressMonitor.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private VMRunnerConfiguration getVMRunnerConfiguration(ILaunchConfiguration configuration, String mode, IProgressMonitor monitor) throws CoreException {
/*  68 */     monitor.beginTask(NLS.bind("{0}...", (Object[])new String[] { configuration.getName() }), 3);
/*     */     
/*  70 */     if (monitor.isCanceled()) {
/*  71 */       return null;
/*     */     }
/*  73 */     monitor.subTask(LaunchingMessages.JavaLocalApplicationLaunchConfigurationDelegate_Verifying_launch_attributes____1);
/*     */     
/*  75 */     String mainTypeName = verifyMainTypeName(configuration);
/*     */     
/*  77 */     File workingDir = verifyWorkingDirectory(configuration);
/*  78 */     String workingDirName = null;
/*  79 */     if (workingDir != null) {
/*  80 */       workingDirName = workingDir.getAbsolutePath();
/*     */     }
/*     */ 
/*     */     
/*  84 */     String[] envp = getEnvironment(configuration);
/*     */ 
/*     */     
/*  87 */     String pgmArgs = getProgramArguments(configuration);
/*  88 */     String vmArgs = concat(getVMArguments(configuration), getVMArguments(configuration, mode));
/*  89 */     ExecutionArguments execArgs = new ExecutionArguments(vmArgs, pgmArgs);
/*     */ 
/*     */     
/*  92 */     Map<String, Object> vmAttributesMap = getVMSpecificAttributesMap(configuration);
/*     */ 
/*     */ 
/*     */     
/*  96 */     VMRunnerConfiguration runConfig = new VMRunnerConfiguration(mainTypeName, getClasspath(configuration));
/*  97 */     runConfig.setProgramArguments(execArgs.getProgramArgumentsArray());
/*  98 */     runConfig.setEnvironment(envp);
/*  99 */     runConfig.setVMArguments(execArgs.getVMArgumentsArray());
/* 100 */     runConfig.setWorkingDirectory(workingDirName);
/* 101 */     runConfig.setVMSpecificAttributesMap(vmAttributesMap);
/* 102 */     runConfig.setPreviewEnabled(supportsPreviewFeatures(configuration));
/*     */     
/* 104 */     if (supportsModule() && !mainTypeName.equals("org.eclipse.jdt.internal.debug.ui.snippeteditor.ScrapbookMain")) {
/*     */       
/*     */       try {
/* 107 */         IJavaProject proj = JavaRuntime.getJavaProject(configuration);
/* 108 */         if (proj != null) {
/* 109 */           IModuleDescription module = (proj == null) ? null : proj.getModuleDescription();
/* 110 */           String modName = (module == null) ? null : module.getElementName();
/* 111 */           if (modName != null && modName.length() > 0) {
/* 112 */             String defaultModuleName = null;
/* 113 */             String moduleName = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_MODULE_NAME, defaultModuleName);
/* 114 */             if (moduleName != null && !moduleName.isEmpty()) {
/* 115 */               runConfig.setModuleDescription(moduleName);
/*     */             } else {
/* 117 */               runConfig.setModuleDescription(modName);
/*     */             } 
/*     */           } 
/*     */         } 
/* 121 */       } catch (CoreException coreException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     if (!JavaRuntime.isModularConfiguration(configuration)) {
/*     */       
/* 129 */       runConfig.setBootClassPath(getBootpath(configuration));
/* 130 */     } else if (supportsModule()) {
/*     */       
/* 132 */       String[][] paths = getClasspathAndModulepath(configuration);
/* 133 */       if (paths != null && paths.length > 1) {
/* 134 */         runConfig.setModulepath(paths[1]);
/*     */       }
/* 136 */       if (!configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_DEFAULT_MODULE_CLI_OPTIONS, true)) {
/* 137 */         runConfig.setOverrideDependencies(configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_MODULE_CLI_OPTIONS, ""));
/*     */       } else {
/* 139 */         runConfig.setOverrideDependencies(getModuleCLIOptions(configuration));
/*     */       } 
/*     */     } 
/* 142 */     runConfig.setMergeOutput(configuration.getAttribute("org.eclipse.debug.core.ATTR_MERGE_OUTPUT", false));
/*     */ 
/*     */     
/* 145 */     if (monitor.isCanceled()) {
/* 146 */       return null;
/*     */     }
/* 148 */     monitor.worked(1);
/*     */     
/* 150 */     return runConfig;
/*     */   }
/*     */   
/*     */   public void launch(ILaunchConfiguration configuration, String mode, ILaunch launch, IProgressMonitor monitor) throws CoreException {
/*     */     NullProgressMonitor nullProgressMonitor;
/* 155 */     if (monitor == null) {
/* 156 */       nullProgressMonitor = new NullProgressMonitor();
/*     */     }
/*     */     
/*     */     try {
/* 160 */       VMRunnerConfiguration runConfig = getVMRunnerConfiguration(configuration, mode, (IProgressMonitor)nullProgressMonitor);
/* 161 */       if (runConfig == null) {
/*     */         return;
/*     */       }
/*     */       
/* 165 */       prepareStopInMain(configuration);
/*     */ 
/*     */       
/* 168 */       nullProgressMonitor.worked(1);
/*     */       
/* 170 */       nullProgressMonitor.subTask(LaunchingMessages.JavaLocalApplicationLaunchConfigurationDelegate_Creating_source_locator____2);
/*     */       
/* 172 */       setDefaultSourceLocator(launch, configuration);
/* 173 */       nullProgressMonitor.worked(1);
/*     */       
/* 175 */       IVMRunner runner = getVMRunner(configuration, mode);
/* 176 */       runner.run(runConfig, launch, (IProgressMonitor)nullProgressMonitor);
/*     */ 
/*     */       
/* 179 */       if (nullProgressMonitor.isCanceled()) {
/*     */         return;
/*     */       }
/*     */     } finally {
/*     */       
/* 184 */       nullProgressMonitor.done();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String concat(String args1, String args2) {
/* 189 */     StringBuilder args = new StringBuilder();
/* 190 */     if (args1 != null && !args1.isEmpty()) {
/* 191 */       args.append(args1);
/*     */     }
/* 193 */     if (args2 != null && !args2.isEmpty()) {
/* 194 */       args.append(" ");
/* 195 */       args.append(args2);
/*     */     } 
/* 197 */     return args.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\JavaLaunchDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */