/*     */ package org.eclipse.jdt.internal.launching.sourcelookup.advanced;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*     */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JavaProjectDescription
/*     */ {
/*     */   final Set<File> classesLocations;
/*     */   final Set<Object> classesLocationsHashes;
/*     */   final List<Supplier<ISourceContainer>> sourceContainerFactories;
/*     */   final Map<File, IPackageFragmentRoot> dependencies;
/*     */   final Map<Object, IPackageFragmentRoot> dependencyHashes;
/*     */   
/*     */   public JavaProjectDescription(Set<File> locations, Set<Object> hashes, List<Supplier<ISourceContainer>> factories, Map<File, IPackageFragmentRoot> dependencies, Map<Object, IPackageFragmentRoot> dependencyHashes) {
/* 167 */     this.classesLocations = Collections.unmodifiableSet(locations);
/* 168 */     this.classesLocationsHashes = Collections.unmodifiableSet(hashes);
/* 169 */     this.sourceContainerFactories = Collections.unmodifiableList(factories);
/* 170 */     this.dependencies = Collections.unmodifiableMap(dependencies);
/* 171 */     this.dependencyHashes = Collections.unmodifiableMap(dependencyHashes);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 176 */     if (this == obj) {
/* 177 */       return true;
/*     */     }
/* 179 */     if (!(obj instanceof JavaProjectDescription)) {
/* 180 */       return false;
/*     */     }
/* 182 */     JavaProjectDescription other = (JavaProjectDescription)obj;
/* 183 */     return this.classesLocations.equals(other.classesLocations);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 188 */     return this.classesLocations.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\sourcelookup\advanced\WorkspaceProjectSourceContainers$JavaProjectDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */