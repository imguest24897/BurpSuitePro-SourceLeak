package org.eclipse.jdt.launching.environments;

public interface IExecutionEnvironmentsManager {
  IExecutionEnvironment[] getExecutionEnvironments();
  
  IExecutionEnvironment getEnvironment(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\environments\IExecutionEnvironmentsManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */