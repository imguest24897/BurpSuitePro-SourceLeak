/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import com.sun.jdi.VirtualMachine;
/*     */ import com.sun.jdi.connect.Connector;
/*     */ import com.sun.jdi.connect.IllegalConnectorArgumentsException;
/*     */ import com.sun.jdi.connect.ListeningConnector;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.text.DateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.IStatusHandler;
/*     */ import org.eclipse.debug.core.model.IDebugTarget;
/*     */ import org.eclipse.debug.core.model.IProcess;
/*     */ import org.eclipse.debug.core.model.IStreamsProxy;
/*     */ import org.eclipse.jdi.Bootstrap;
/*     */ import org.eclipse.jdt.debug.core.JDIDebugModel;
/*     */ import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.jdt.launching.SocketUtil;
/*     */ import org.eclipse.jdt.launching.VMRunnerConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardVMDebugger
/*     */   extends StandardVMRunner
/*     */ {
/*     */   protected static final String JAVA_JVM_VERSION = "JAVA_JVM_VERSION";
/*     */   protected static final String JRE = "jre";
/*     */   protected static final String BIN = "bin";
/*     */   
/*     */   class ConnectRunnable
/*     */     implements Runnable
/*     */   {
/*  93 */     private VirtualMachine fVirtualMachine = null;
/*  94 */     private ListeningConnector fConnector = null;
/*  95 */     private Map<String, Connector.Argument> fConnectionMap = null;
/*  96 */     private Exception fException = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConnectRunnable(ListeningConnector connector, Map<String, Connector.Argument> map) {
/* 106 */       this.fConnector = connector;
/* 107 */       this.fConnectionMap = map;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       try {
/* 113 */         this.fVirtualMachine = this.fConnector.accept(this.fConnectionMap);
/* 114 */       } catch (IOException|IllegalConnectorArgumentsException e) {
/* 115 */         this.fException = e;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public VirtualMachine getVirtualMachine() {
/* 125 */       return this.fVirtualMachine;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Exception getException() {
/* 134 */       return this.fException;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardVMDebugger(IVMInstall vmInstance) {
/* 143 */     super(vmInstance);
/*     */   }
/*     */ 
/*     */   
/*     */   public String showCommandLine(VMRunnerConfiguration configuration, ILaunch launch, IProgressMonitor monitor) throws CoreException {
/* 148 */     SubMonitor subMonitor = SubMonitor.convert(monitor);
/*     */     
/* 150 */     StandardVMRunner.CommandDetails cmd = getCommandLine(configuration, launch, (IProgressMonitor)subMonitor);
/* 151 */     if (subMonitor.isCanceled()) {
/* 152 */       return "";
/*     */     }
/* 154 */     String[] cmdLine = cmd.getCommandLine();
/* 155 */     cmdLine = quoteWindowsArgs(cmdLine);
/* 156 */     return getCmdLineAsString(cmdLine);
/*     */   }
/*     */   
/*     */   private StandardVMRunner.CommandDetails getCommandLine(VMRunnerConfiguration config, ILaunch launch, IProgressMonitor monitor) throws CoreException {
/* 160 */     SubMonitor subMonitor = SubMonitor.convert(monitor, 1);
/*     */ 
/*     */     
/* 163 */     if (subMonitor.isCanceled()) {
/* 164 */       return null;
/*     */     }
/*     */     
/* 167 */     subMonitor.subTask(LaunchingMessages.StandardVMDebugger_Finding_free_socket____2);
/*     */     
/* 169 */     int port = SocketUtil.findFreePort();
/* 170 */     if (port == -1) {
/* 171 */       abort(LaunchingMessages.StandardVMDebugger_Could_not_find_a_free_socket_for_the_debugger_1, null, 118);
/*     */     }
/*     */     
/* 174 */     subMonitor.worked(1);
/*     */ 
/*     */     
/* 177 */     if (subMonitor.isCanceled()) {
/* 178 */       return null;
/*     */     }
/*     */     
/* 181 */     subMonitor.subTask(LaunchingMessages.StandardVMDebugger_Constructing_command_line____3);
/*     */     
/* 183 */     String program = constructProgramString(config);
/*     */     
/* 185 */     List<String> arguments = new ArrayList<>(12);
/*     */     
/* 187 */     arguments.add(program);
/*     */     
/* 189 */     if (this.fVMInstance instanceof StandardVM && ((StandardVM)this.fVMInstance).getDebugArgs() != null) {
/* 190 */       String debugArgString = ((StandardVM)this.fVMInstance).getDebugArgs().replaceAll("\\Q${port}\\E", Integer.toString(port));
/* 191 */       arguments.addAll(Arrays.asList(DebugPlugin.parseArguments(debugArgString)));
/*     */     }
/*     */     else {
/*     */       
/* 195 */       double version = getJavaVersion(this.fVMInstance);
/* 196 */       if (version < 1.5D) {
/* 197 */         arguments.add("-Xdebug");
/* 198 */         arguments.add("-Xnoagent");
/*     */       } 
/*     */ 
/*     */       
/* 202 */       if (version < 1.4D) {
/* 203 */         arguments.add("-Djava.compiler=NONE");
/*     */       }
/*     */       
/* 206 */       if (version >= 14.0D && 
/* 207 */         launch.getLaunchConfiguration().getAttribute(IJavaLaunchConfigurationConstants.ATTR_SHOW_CODEDETAILS_IN_EXCEPTION_MESSAGES, true)) {
/* 208 */         arguments.add("-XX:+ShowCodeDetailsInExceptionMessages");
/*     */       }
/*     */       
/* 211 */       if (version < 1.5D) {
/* 212 */         arguments.add("-Xrunjdwp:transport=dt_socket,suspend=y,address=localhost:" + port);
/*     */       } else {
/* 214 */         arguments.add("-agentlib:jdwp=transport=dt_socket,suspend=y,address=localhost:" + port);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 219 */     String[] allVMArgs = combineVmArgs(config, this.fVMInstance);
/* 220 */     addArguments(ensureEncoding(launch, allVMArgs), arguments);
/* 221 */     addBootClassPathArguments(arguments, config);
/*     */     
/* 223 */     String[] mp = config.getModulepath();
/* 224 */     if (mp != null && mp.length > 0) {
/*     */       
/* 226 */       arguments.add("-p");
/* 227 */       arguments.add(convertClassPath(mp));
/*     */     } 
/*     */     
/* 230 */     String[] cp = config.getClassPath();
/* 231 */     if (cp.length > 0) {
/* 232 */       arguments.add("-classpath");
/* 233 */       arguments.add(convertClassPath(cp));
/*     */     } 
/*     */ 
/*     */     
/* 237 */     if (config.isPreviewEnabled()) {
/* 238 */       arguments.add("--enable-preview");
/*     */     }
/*     */     
/* 241 */     String dependencies = config.getOverrideDependencies();
/* 242 */     if (dependencies != null && dependencies.length() > 0) {
/* 243 */       arguments.addAll(Arrays.asList(DebugPlugin.parseArguments(dependencies)));
/*     */     }
/*     */     
/* 246 */     if (isModular(config, this.fVMInstance)) {
/* 247 */       arguments.add("-m");
/* 248 */       arguments.add(String.valueOf(config.getModuleDescription()) + "/" + config.getClassToLaunch());
/*     */     } else {
/* 250 */       arguments.add(config.getClassToLaunch());
/*     */     } 
/* 252 */     int lastVMArgumentIndex = arguments.size() - 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 259 */     addArguments(config.getProgramArguments(), arguments);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 264 */     String[] envp = prependJREPath(config.getEnvironment(), (IPath)new Path(program));
/*     */     
/* 266 */     String[] cmdLine = new String[arguments.size()];
/* 267 */     arguments.toArray(cmdLine);
/*     */ 
/*     */     
/* 270 */     if (subMonitor.isCanceled()) {
/* 271 */       return null;
/*     */     }
/* 273 */     File workingDir = getWorkingDir(config);
/* 274 */     StandardVMRunner.CommandDetails cmd = new StandardVMRunner.CommandDetails();
/* 275 */     CommandLineShortener commandLineShortener = new CommandLineShortener(this.fVMInstance, launch, cmdLine, workingDir);
/* 276 */     if (commandLineShortener.shouldShortenCommandLine()) {
/* 277 */       cmdLine = commandLineShortener.shortenCommandLine();
/* 278 */       cmd.setCommandLineShortener(commandLineShortener);
/*     */     } else {
/* 280 */       ClasspathShortener classpathShortener = new ClasspathShortener(this.fVMInstance, launch, cmdLine, lastVMArgumentIndex, workingDir, envp);
/* 281 */       if (classpathShortener.shortenCommandLineIfNecessary()) {
/* 282 */         cmdLine = classpathShortener.getCmdLine();
/* 283 */         envp = classpathShortener.getEnvp();
/*     */       } 
/* 285 */       cmd.setCommandLineShortener(classpathShortener);
/*     */     } 
/* 287 */     String[] newCmdLine = validateCommandLine(launch.getLaunchConfiguration(), cmdLine);
/* 288 */     if (newCmdLine != null) {
/* 289 */       cmdLine = newCmdLine;
/*     */     }
/* 291 */     subMonitor.worked(1);
/*     */     
/* 293 */     cmd.setCommandLine(cmdLine);
/* 294 */     cmd.setEnvp(envp);
/* 295 */     cmd.setWorkingDir(workingDir);
/* 296 */     cmd.setPort(port);
/* 297 */     return cmd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(VMRunnerConfiguration config, ILaunch launch, IProgressMonitor monitor) throws CoreException {
/* 309 */     SubMonitor subMonitor = SubMonitor.convert(monitor, 1);
/* 310 */     StandardVMRunner.CommandDetails cmdDetails = getCommandLine(config, launch, (IProgressMonitor)subMonitor);
/*     */ 
/*     */     
/* 313 */     if (subMonitor.isCanceled() || cmdDetails == null) {
/*     */       return;
/*     */     }
/* 316 */     String[] cmdLine = cmdDetails.getCommandLine();
/*     */     
/* 318 */     subMonitor.beginTask(LaunchingMessages.StandardVMDebugger_Launching_VM____1, 4);
/* 319 */     subMonitor.subTask(LaunchingMessages.StandardVMDebugger_Starting_virtual_machine____4);
/* 320 */     ListeningConnector connector = getConnector();
/* 321 */     if (connector == null) {
/* 322 */       abort(LaunchingMessages.StandardVMDebugger_Couldn__t_find_an_appropriate_debug_connector_2, null, 119);
/*     */     }
/* 324 */     Map<String, Connector.Argument> map = connector.defaultArguments();
/*     */     
/* 326 */     specifyArguments(map, cmdDetails.getPort());
/* 327 */     Process p = null;
/*     */     
/*     */     try {
/*     */       
/* 331 */       try { if (subMonitor.isCanceled()) {
/*     */           return;
/*     */         }
/*     */         
/* 335 */         connector.startListening(map);
/*     */         
/* 337 */         p = exec(cmdLine, cmdDetails.getWorkingDir(), cmdDetails.getEnvp(), config.isMergeOutput());
/* 338 */         if (p == null) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 343 */         if (subMonitor.isCanceled()) {
/* 344 */           p.destroy();
/*     */           return;
/*     */         } 
/* 347 */         String timestamp = DateFormat.getDateTimeInstance(2, 2).format(new Date(System.currentTimeMillis()));
/* 348 */         IProcess process = newProcess(launch, p, renderProcessLabel(p, cmdLine, timestamp), getDefaultProcessMap());
/* 349 */         process.setAttribute("org.eclipse.debug.core.ATTR_PATH", cmdLine[0]);
/* 350 */         process.setAttribute(IProcess.ATTR_CMDLINE, renderCommandLine(cmdLine));
/* 351 */         String ltime = launch.getAttribute("org.eclipse.debug.core.launch.timestamp");
/* 352 */         process.setAttribute("org.eclipse.debug.core.launch.timestamp", (ltime != null) ? ltime : timestamp);
/* 353 */         if (cmdDetails.getWorkingDir() != null) {
/* 354 */           process.setAttribute("org.eclipse.debug.core.ATTR_WORKING_DIRECTORY", cmdDetails.getWorkingDir().getAbsolutePath());
/*     */         }
/* 356 */         if (cmdDetails.getEnvp() != null) {
/* 357 */           Arrays.sort((Object[])cmdDetails.getEnvp());
/* 358 */           StringBuilder buff = new StringBuilder();
/* 359 */           for (int i = 0; i < (cmdDetails.getEnvp()).length; i++) {
/* 360 */             buff.append(cmdDetails.getEnvp()[i]);
/* 361 */             if (i < (cmdDetails.getEnvp()).length - 1) {
/* 362 */               buff.append('\n');
/*     */             }
/*     */           } 
/* 365 */           process.setAttribute("org.eclipse.debug.core.ATTR_ENVIRONMENT", buff.toString());
/*     */         } 
/* 367 */         List<File> processTempFiles = cmdDetails.getCommandLineShortener().getProcessTempFiles();
/* 368 */         if (!processTempFiles.isEmpty()) {
/* 369 */           String tempFiles = processTempFiles.stream().map(File::getAbsolutePath).collect(Collectors.joining(File.pathSeparator));
/* 370 */           process.setAttribute("tempFiles", tempFiles);
/*     */         } 
/* 372 */         subMonitor.worked(1);
/* 373 */         subMonitor.subTask(LaunchingMessages.StandardVMDebugger_Establishing_debug_connection____5);
/* 374 */         int retryCount = 0;
/* 375 */         boolean retry = false;
/*     */         
/*     */         while (true)
/*     */         { 
/* 379 */           try { ConnectRunnable runnable = new ConnectRunnable(connector, map);
/* 380 */             Thread connectThread = new Thread(runnable, "Listening Connector");
/* 381 */             connectThread.setDaemon(true);
/* 382 */             connectThread.start();
/* 383 */             while (connectThread.isAlive()) {
/* 384 */               if (subMonitor.isCanceled()) {
/*     */                 try {
/* 386 */                   connector.stopListening(map);
/* 387 */                 } catch (IOException iOException) {}
/*     */ 
/*     */                 
/* 390 */                 p.destroy();
/*     */                 return;
/*     */               } 
/*     */               try {
/* 394 */                 p.exitValue();
/*     */                 
/*     */                 try {
/* 397 */                   connector.stopListening(map);
/* 398 */                 } catch (IOException iOException) {}
/*     */ 
/*     */                 
/* 401 */                 checkErrorMessage(process);
/* 402 */               } catch (IllegalThreadStateException illegalThreadStateException) {}
/*     */ 
/*     */               
/*     */               try {
/* 406 */                 Thread.sleep(100L);
/* 407 */               } catch (InterruptedException interruptedException) {}
/*     */             } 
/*     */ 
/*     */             
/* 411 */             Exception ex = runnable.getException();
/* 412 */             if (ex instanceof IllegalConnectorArgumentsException) {
/* 413 */               throw (IllegalConnectorArgumentsException)ex;
/*     */             }
/* 415 */             if (ex instanceof InterruptedIOException) {
/* 416 */               throw (InterruptedIOException)ex;
/*     */             }
/* 418 */             if (ex instanceof IOException) {
/* 419 */               throw (IOException)ex;
/*     */             }
/*     */             
/* 422 */             VirtualMachine vm = runnable.getVirtualMachine();
/* 423 */             if (vm != null) {
/* 424 */               createDebugTarget(config, launch, cmdDetails.getPort(), process, vm);
/* 425 */               subMonitor.worked(1);
/* 426 */               subMonitor.done();
/*     */             } 
/*     */             return; }
/* 429 */           catch (InterruptedIOException e)
/* 430 */           { checkErrorMessage(process);
/*     */ 
/*     */             
/* 433 */             Status status = new Status(4, LaunchingPlugin.getUniqueIdentifier(), 117, "", e);
/* 434 */             IStatusHandler handler = DebugPlugin.getDefault().getStatusHandler((IStatus)status);
/*     */             
/* 436 */             retry = false;
/* 437 */             if (handler == null)
/*     */             {
/* 439 */               throw new CoreException(status);
/*     */             }
/* 441 */             Object result = handler.handleStatus((IStatus)status, this);
/* 442 */             if (result instanceof Boolean) {
/* 443 */               retry = ((Boolean)result).booleanValue();
/*     */             }
/* 445 */             if (!retry && retryCount < 5) {
/* 446 */               retry = true;
/* 447 */               retryCount++;
/* 448 */               LaunchingPlugin.log("Retrying count: " + retryCount);
/*     */             } 
/*     */ 
/*     */             
/* 452 */             if (!retry)
/*     */               break;  }  }  }
/* 454 */       finally { connector.stopListening(map); }
/*     */     
/* 456 */     } catch (IOException e) {
/* 457 */       abort(LaunchingMessages.StandardVMDebugger_Couldn__t_connect_to_VM_4, e, 120);
/* 458 */     } catch (IllegalConnectorArgumentsException e) {
/* 459 */       abort(LaunchingMessages.StandardVMDebugger_Couldn__t_connect_to_VM_5, e, 120);
/*     */     } 
/* 461 */     if (p != null) {
/* 462 */       p.destroy();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] prependJREPath(String[] env, IPath jdkpath) {
/* 489 */     if ("win32".equals(Platform.getOS())) {
/* 490 */       IPath jrepath = jdkpath.removeLastSegments(1);
/* 491 */       if (jrepath.lastSegment().equals("bin")) {
/* 492 */         int count = jrepath.segmentCount();
/* 493 */         if (count > 1 && !jrepath.segment(count - 2).equalsIgnoreCase("jre")) {
/* 494 */           jrepath = jrepath.removeLastSegments(1).append("jre").append("bin");
/*     */         }
/*     */       } else {
/*     */         
/* 498 */         jrepath = jrepath.append("jre").append("bin");
/*     */       } 
/* 500 */       if (jrepath.toFile().exists()) {
/* 501 */         String jrestr = jrepath.toOSString();
/* 502 */         if (env == null) {
/* 503 */           Map<String, String> map = DebugPlugin.getDefault().getLaunchManager().getNativeEnvironment();
/* 504 */           env = new String[map.size()];
/* 505 */           int index = 0;
/* 506 */           for (String var : map.keySet()) {
/* 507 */             String value = map.get(var);
/* 508 */             if (value == null) {
/* 509 */               value = "";
/*     */             }
/* 511 */             if (var.equalsIgnoreCase("path") && 
/* 512 */               !value.contains(jrestr)) {
/* 513 */               value = String.valueOf(jrestr) + ';' + value;
/*     */             }
/*     */             
/* 516 */             env[index] = String.valueOf(var) + "=" + value;
/* 517 */             index++;
/*     */           } 
/*     */         } else {
/* 520 */           String var = null;
/* 521 */           int esign = -1;
/* 522 */           for (int i = 0; i < env.length; i++) {
/* 523 */             esign = env[i].indexOf('=');
/* 524 */             if (esign > -1) {
/* 525 */               var = env[i].substring(0, esign);
/* 526 */               if (var != null && var.equalsIgnoreCase("path") && 
/* 527 */                 env[i].indexOf(jrestr) == -1) {
/* 528 */                 env[i] = String.valueOf(var) + "=" + jrestr + ';' + ((esign == env[i].length()) ? "" : env[i].substring(esign + 1));
/*     */                 
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 537 */     return prependJREPath(env);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IDebugTarget createDebugTarget(VMRunnerConfiguration config, ILaunch launch, int port, IProcess process, VirtualMachine vm) {
/* 552 */     return JDIDebugModel.newDebugTarget(launch, vm, renderDebugTarget(config.getClassToLaunch(), port), process, true, false, config.isResumeOnStartup());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkErrorMessage(IProcess process) throws CoreException {
/* 561 */     IStreamsProxy streamsProxy = process.getStreamsProxy();
/* 562 */     if (streamsProxy != null) {
/* 563 */       String errorMessage = streamsProxy.getErrorStreamMonitor().getContents();
/* 564 */       if (errorMessage.length() == 0) {
/* 565 */         errorMessage = streamsProxy.getOutputStreamMonitor().getContents();
/*     */       }
/* 567 */       if (errorMessage.length() != 0) {
/* 568 */         abort(errorMessage, null, 116);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void specifyArguments(Map<String, Connector.Argument> map, int portNumber) {
/* 580 */     Connector.IntegerArgument port = (Connector.IntegerArgument)map.get("port");
/* 581 */     port.setValue(portNumber);
/*     */     
/* 583 */     Connector.IntegerArgument timeoutArg = (Connector.IntegerArgument)map.get("timeout");
/* 584 */     if (timeoutArg != null) {
/* 585 */       int timeout = Platform.getPreferencesService().getInt(
/* 586 */           "org.eclipse.jdt.launching", 
/* 587 */           JavaRuntime.PREF_CONNECT_TIMEOUT, 
/* 588 */           20000, 
/* 589 */           null);
/* 590 */       timeoutArg.setValue(timeout);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ListeningConnector getConnector() {
/* 600 */     for (ListeningConnector c : Bootstrap.virtualMachineManager().listeningConnectors()) {
/* 601 */       if ("com.sun.jdi.SocketListen".equals(c.name())) {
/* 602 */         return c;
/*     */       }
/*     */     } 
/* 605 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\StandardVMDebugger.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */