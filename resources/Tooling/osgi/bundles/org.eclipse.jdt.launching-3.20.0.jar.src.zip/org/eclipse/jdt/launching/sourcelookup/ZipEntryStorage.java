/*    */ package org.eclipse.jdt.launching.sourcelookup;
/*    */ 
/*    */ import java.util.zip.ZipEntry;
/*    */ import java.util.zip.ZipFile;
/*    */ import org.eclipse.debug.core.sourcelookup.containers.ZipEntryStorage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ZipEntryStorage
/*    */   extends ZipEntryStorage
/*    */ {
/*    */   public ZipEntryStorage(ZipFile archive, ZipEntry entry) {
/* 44 */     super(archive, entry);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\sourcelookup\ZipEntryStorage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */