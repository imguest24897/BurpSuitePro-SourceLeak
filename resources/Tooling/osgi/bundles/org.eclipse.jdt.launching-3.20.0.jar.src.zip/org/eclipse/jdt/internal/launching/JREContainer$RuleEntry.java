/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import org.eclipse.jdt.core.IAccessRule;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RuleEntry
/*     */ {
/* 123 */   private IAccessRule[][] fRules = null;
/* 124 */   private IClasspathEntry[] fEntries = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RuleEntry(IAccessRule[][] rules, IClasspathEntry[] entries) {
/* 132 */     this.fRules = rules;
/* 133 */     this.fEntries = entries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IClasspathEntry[] getClasspathEntries() {
/* 141 */     return this.fEntries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 149 */     IAccessRule[][] rules = null;
/* 150 */     if (obj instanceof RuleEntry) {
/* 151 */       rules = ((RuleEntry)obj).fRules;
/*     */     }
/* 153 */     if (obj instanceof IAccessRule[][]) {
/* 154 */       rules = (IAccessRule[][])obj;
/*     */     }
/* 156 */     if (this.fRules == rules) {
/* 157 */       return true;
/*     */     }
/* 159 */     if (rules != null && 
/* 160 */       this.fRules.length == rules.length) {
/* 161 */       for (int i = 0; i < this.fRules.length; i++) {
/* 162 */         if (!rulesEqual(this.fRules[i], rules[i])) {
/* 163 */           return false;
/*     */         }
/*     */       } 
/* 166 */       return true;
/*     */     } 
/*     */     
/* 169 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean rulesEqual(IAccessRule[] a, IAccessRule[] b) {
/* 180 */     if (a == b) {
/* 181 */       return true;
/*     */     }
/* 183 */     if (a.length != b.length) {
/* 184 */       return false;
/*     */     }
/* 186 */     for (int j = 0; j < a.length; j++) {
/* 187 */       if (!a[j].equals(b[j])) {
/* 188 */         return false;
/*     */       }
/*     */     } 
/* 191 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\JREContainer$RuleEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */