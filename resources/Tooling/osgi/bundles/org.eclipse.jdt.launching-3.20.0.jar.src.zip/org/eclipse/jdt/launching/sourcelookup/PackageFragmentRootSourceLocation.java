/*     */ package org.eclipse.jdt.launching.sourcelookup;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.jdt.core.IClassFile;
/*     */ import org.eclipse.jdt.core.ICompilationUnit;
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.core.IPackageFragment;
/*     */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingMessages;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class PackageFragmentRootSourceLocation
/*     */   extends PlatformObject
/*     */   implements IJavaSourceLocation
/*     */ {
/*  65 */   private IPackageFragmentRoot fRoot = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PackageFragmentRootSourceLocation() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PackageFragmentRootSourceLocation(IPackageFragmentRoot root) {
/*  79 */     setPackageFragmentRoot(root);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findSourceElement(String name) throws CoreException {
/*  87 */     if (name != null && getPackageFragmentRoot() != null) {
/*  88 */       IPackageFragment pkg = null;
/*  89 */       int index = name.lastIndexOf('.');
/*  90 */       if (index >= 0) {
/*  91 */         String fragment = name.substring(0, index);
/*  92 */         pkg = getPackageFragmentRoot().getPackageFragment(fragment);
/*  93 */         name = name.substring(index + 1);
/*     */       } else {
/*  95 */         pkg = getPackageFragmentRoot().getPackageFragment("");
/*     */       } 
/*  97 */       if (pkg.exists()) {
/*  98 */         boolean possibleInnerType = false;
/*  99 */         String typeName = name;
/*     */         do {
/* 101 */           ICompilationUnit cu = pkg.getCompilationUnit(String.valueOf(typeName) + ".java");
/* 102 */           if (cu.exists()) {
/* 103 */             return cu;
/*     */           }
/* 105 */           IClassFile cf = pkg.getClassFile(String.valueOf(typeName) + ".class");
/* 106 */           if (cf.exists()) {
/* 107 */             return cf;
/*     */           }
/* 109 */           index = typeName.lastIndexOf('$');
/* 110 */           if (index >= 0) {
/* 111 */             typeName = typeName.substring(0, index);
/* 112 */             possibleInnerType = true;
/*     */           } else {
/* 114 */             possibleInnerType = false;
/*     */           } 
/* 116 */         } while (possibleInnerType);
/*     */       } 
/*     */     } 
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMemento() throws CoreException {
/* 127 */     Document doc = DebugPlugin.newDocument();
/* 128 */     Element node = doc.createElement("javaPackageFragmentRootSourceLocation");
/* 129 */     doc.appendChild(node);
/* 130 */     String handle = "";
/* 131 */     if (getPackageFragmentRoot() != null) {
/* 132 */       handle = getPackageFragmentRoot().getHandleIdentifier();
/*     */     }
/* 134 */     node.setAttribute("handleId", handle);
/* 135 */     return DebugPlugin.serializeDocument(doc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initializeFrom(String memento) throws CoreException {
/* 143 */     Exception ex = null;
/*     */     try {
/* 145 */       Element root = null;
/* 146 */       DocumentBuilder parser = 
/* 147 */         DocumentBuilderFactory.newInstance().newDocumentBuilder();
/* 148 */       parser.setErrorHandler(new DefaultHandler());
/* 149 */       StringReader reader = new StringReader(memento);
/* 150 */       InputSource source = new InputSource(reader);
/* 151 */       root = parser.parse(source).getDocumentElement();
/*     */       
/* 153 */       String handle = root.getAttribute("handleId");
/* 154 */       if (handle == null) {
/* 155 */         abort(LaunchingMessages.PackageFragmentRootSourceLocation_Unable_to_initialize_source_location___missing_handle_identifier_for_package_fragment_root__6, null);
/*     */       }
/* 157 */       else if (handle.length() == 0) {
/*     */         
/* 159 */         setPackageFragmentRoot(null);
/*     */       } else {
/* 161 */         IJavaElement element = JavaCore.create(handle);
/* 162 */         if (element instanceof IPackageFragmentRoot) {
/* 163 */           setPackageFragmentRoot((IPackageFragmentRoot)element);
/*     */         } else {
/* 165 */           abort(LaunchingMessages.PackageFragmentRootSourceLocation_Unable_to_initialize_source_location___package_fragment_root_does_not_exist__7, null);
/*     */         } 
/*     */       } 
/*     */       
/*     */       return;
/* 170 */     } catch (ParserConfigurationException e) {
/* 171 */       ex = e;
/* 172 */     } catch (SAXException e) {
/* 173 */       ex = e;
/* 174 */     } catch (IOException e) {
/* 175 */       ex = e;
/*     */     } 
/* 177 */     abort(LaunchingMessages.PackageFragmentRootSourceLocation_Exception_occurred_initializing_source_location__8, ex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPackageFragmentRoot getPackageFragmentRoot() {
/* 188 */     return this.fRoot;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setPackageFragmentRoot(IPackageFragmentRoot root) {
/* 198 */     this.fRoot = root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void abort(String message, Throwable e) throws CoreException {
/* 205 */     Status status = new Status(4, LaunchingPlugin.getUniqueIdentifier(), 150, message, e);
/* 206 */     throw new CoreException(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 214 */     if (object instanceof PackageFragmentRootSourceLocation) {
/* 215 */       PackageFragmentRootSourceLocation root = (PackageFragmentRootSourceLocation)object;
/* 216 */       if (getPackageFragmentRoot() == null) {
/* 217 */         return (root.getPackageFragmentRoot() == null);
/*     */       }
/* 219 */       return getPackageFragmentRoot().equals(root.getPackageFragmentRoot());
/*     */     } 
/* 221 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 229 */     if (getPackageFragmentRoot() == null) {
/* 230 */       return getClass().hashCode();
/*     */     }
/* 232 */     return getPackageFragmentRoot().hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\sourcelookup\PackageFragmentRootSourceLocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */