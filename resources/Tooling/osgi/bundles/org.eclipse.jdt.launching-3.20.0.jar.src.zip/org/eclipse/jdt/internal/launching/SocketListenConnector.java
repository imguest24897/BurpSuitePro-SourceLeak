/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import com.sun.jdi.connect.Connector;
/*     */ import com.sun.jdi.connect.IllegalConnectorArgumentsException;
/*     */ import com.sun.jdi.connect.ListeningConnector;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.jdi.Bootstrap;
/*     */ import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
/*     */ import org.eclipse.jdt.launching.IVMConnector;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SocketListenConnector
/*     */   implements IVMConnector
/*     */ {
/*     */   protected static ListeningConnector getListeningConnector() throws CoreException {
/*  53 */     ListeningConnector connector = null;
/*  54 */     Iterator<ListeningConnector> iter = Bootstrap.virtualMachineManager().listeningConnectors().iterator();
/*  55 */     while (iter.hasNext()) {
/*  56 */       ListeningConnector lc = iter.next();
/*  57 */       if (lc.name().equals("com.sun.jdi.SocketListen")) {
/*  58 */         connector = lc;
/*     */         break;
/*     */       } 
/*     */     } 
/*  62 */     if (connector == null) {
/*  63 */       abort(LaunchingMessages.SocketListenConnector_0, null, 114);
/*     */     }
/*  65 */     return connector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIdentifier() {
/*  73 */     return IJavaLaunchConfigurationConstants.ID_SOCKET_LISTEN_VM_CONNECTOR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  81 */     return LaunchingMessages.SocketListenConnector_1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect(Map<String, String> arguments, IProgressMonitor monitor, ILaunch launch) throws CoreException {
/*     */     NullProgressMonitor nullProgressMonitor;
/*  89 */     if (monitor == null) {
/*  90 */       nullProgressMonitor = new NullProgressMonitor();
/*     */     }
/*     */     
/*  93 */     nullProgressMonitor.subTask(LaunchingMessages.SocketListenConnector_2);
/*     */     
/*  95 */     ListeningConnector connector = getListeningConnector();
/*     */     
/*  97 */     String portNumberString = arguments.get("port");
/*  98 */     if (portNumberString == null) {
/*  99 */       abort(LaunchingMessages.SocketAttachConnector_Port_unspecified_for_remote_connection__2, null, 111);
/*     */     }
/*     */     
/* 102 */     Map<String, Connector.Argument> acceptArguments = connector.defaultArguments();
/*     */     
/* 104 */     Connector.Argument param = acceptArguments.get("port");
/* 105 */     param.setValue(portNumberString);
/*     */ 
/*     */     
/* 108 */     int connectionLimit = 1;
/* 109 */     if (arguments.containsKey("connectionLimit")) {
/* 110 */       connectionLimit = Integer.parseInt(arguments.get("connectionLimit"));
/*     */     }
/*     */     
/*     */     try {
/* 114 */       nullProgressMonitor.subTask(NLS.bind(LaunchingMessages.SocketListenConnector_3, (Object[])new String[] { portNumberString }));
/* 115 */       connector.startListening(acceptArguments);
/* 116 */       SocketListenConnectorProcess process = new SocketListenConnectorProcess(launch, portNumberString, connectionLimit);
/* 117 */       process.waitForConnection(connector, acceptArguments);
/* 118 */     } catch (IOException e) {
/* 119 */       abort(LaunchingMessages.SocketListenConnector_4, e, 113);
/* 120 */     } catch (IllegalConnectorArgumentsException e) {
/* 121 */       abort(LaunchingMessages.SocketListenConnector_4, e, 113);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Connector.Argument> getDefaultArguments() throws CoreException {
/* 130 */     Map<String, Connector.Argument> def = getListeningConnector().defaultArguments();
/*     */     
/* 132 */     Connector.IntegerArgument arg = (Connector.IntegerArgument)def.get("port");
/* 133 */     arg.setValue(8000);
/*     */     
/* 135 */     return def;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getArgumentOrder() {
/* 143 */     List<String> list = new ArrayList<>(1);
/* 144 */     list.add("port");
/* 145 */     list.add("connectionLimit");
/* 146 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void abort(String message, Throwable exception, int code) throws CoreException {
/* 160 */     throw new CoreException(new Status(4, LaunchingPlugin.getUniqueIdentifier(), code, message, exception));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\SocketListenConnector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */