/*     */ package org.eclipse.jdt.launching;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VMStandin
/*     */   extends AbstractVMInstall
/*     */ {
/*  46 */   private String fJavaVersion = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VMStandin(IVMInstallType type, String id) {
/*  52 */     super(type, id);
/*  53 */     setNotify(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VMStandin(IVMInstall sourceVM, String id) {
/*  64 */     super(sourceVM.getVMInstallType(), id);
/*  65 */     setNotify(false);
/*  66 */     init(sourceVM);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VMStandin(IVMInstall realVM) {
/*  77 */     this(realVM.getVMInstallType(), realVM.getId());
/*  78 */     init(realVM);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init(IVMInstall realVM) {
/*  88 */     setName(realVM.getName());
/*  89 */     setInstallLocation(realVM.getInstallLocation());
/*  90 */     setLibraryLocations(realVM.getLibraryLocations());
/*  91 */     setJavadocLocation(realVM.getJavadocLocation());
/*  92 */     if (realVM instanceof IVMInstall2) {
/*  93 */       IVMInstall2 vm2 = (IVMInstall2)realVM;
/*  94 */       setVMArgs(vm2.getVMArgs());
/*  95 */       this.fJavaVersion = vm2.getJavaVersion();
/*     */     } else {
/*  97 */       setVMArguments(realVM.getVMArguments());
/*  98 */       this.fJavaVersion = null;
/*     */     } 
/* 100 */     if (realVM instanceof AbstractVMInstall) {
/* 101 */       AbstractVMInstall vm2 = (AbstractVMInstall)realVM;
/* 102 */       Map<String, String> attributes = vm2.getAttributes();
/* 103 */       Iterator<Map.Entry<String, String>> iterator = attributes.entrySet().iterator();
/* 104 */       while (iterator.hasNext()) {
/* 105 */         Map.Entry<String, String> entry = iterator.next();
/* 106 */         setAttribute(entry.getKey(), entry.getValue());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IVMInstall convertToRealVM() {
/* 119 */     IVMInstallType vmType = getVMInstallType();
/* 120 */     IVMInstall realVM = vmType.findVMInstall(getId());
/* 121 */     boolean notify = true;
/*     */     
/* 123 */     if (realVM == null) {
/* 124 */       realVM = vmType.createVMInstall(getId());
/* 125 */       notify = false;
/*     */     } 
/*     */     
/* 128 */     if (realVM instanceof AbstractVMInstall) {
/* 129 */       ((AbstractVMInstall)realVM).setNotify(notify);
/*     */     }
/* 131 */     realVM.setName(getName());
/* 132 */     realVM.setInstallLocation(getInstallLocation());
/* 133 */     realVM.setLibraryLocations(getLibraryLocations());
/* 134 */     realVM.setJavadocLocation(getJavadocLocation());
/* 135 */     if (realVM instanceof IVMInstall2) {
/* 136 */       IVMInstall2 vm2 = (IVMInstall2)realVM;
/* 137 */       vm2.setVMArgs(getVMArgs());
/*     */     } else {
/* 139 */       realVM.setVMArguments(getVMArguments());
/*     */     } 
/*     */     
/* 142 */     if (realVM instanceof AbstractVMInstall) {
/* 143 */       AbstractVMInstall avm = (AbstractVMInstall)realVM;
/* 144 */       Iterator<Map.Entry<String, String>> iterator = getAttributes().entrySet().iterator();
/* 145 */       while (iterator.hasNext()) {
/* 146 */         Map.Entry<String, String> entry = iterator.next();
/* 147 */         avm.setAttribute(entry.getKey(), entry.getValue());
/*     */       } 
/* 149 */       avm.setNotify(true);
/*     */     } 
/* 151 */     if (!notify) {
/* 152 */       JavaRuntime.fireVMAdded(realVM);
/*     */     }
/* 154 */     return realVM;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJavaVersion() {
/* 162 */     return this.fJavaVersion;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\VMStandin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */