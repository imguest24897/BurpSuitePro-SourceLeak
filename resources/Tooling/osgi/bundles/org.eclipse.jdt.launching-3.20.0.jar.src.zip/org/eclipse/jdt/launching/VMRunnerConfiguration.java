/*     */ package org.eclipse.jdt.launching;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingMessages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VMRunnerConfiguration
/*     */ {
/*     */   private String fClassToLaunch;
/*     */   private String[] fVMArgs;
/*     */   private String[] fProgramArgs;
/*     */   private String[] fEnvironment;
/*     */   private String[] fClassPath;
/*     */   private String[] fBootClassPath;
/*     */   private String[] fModulepath;
/*     */   private String fModuleDescription;
/*     */   private String fWorkingDirectory;
/*     */   private String fOverrideDependencies;
/*  41 */   private Boolean fPreviewEnabled = Boolean.valueOf(false);
/*     */   
/*     */   private Map<String, Object> fVMSpecificAttributesMap;
/*     */   private boolean fResume = true;
/*     */   private boolean fMergeOutput = false;
/*  46 */   private static final String[] fgEmpty = new String[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VMRunnerConfiguration(String classToLaunch, String[] classPath) {
/*  56 */     if (classToLaunch == null) {
/*  57 */       throw new IllegalArgumentException(LaunchingMessages.vmRunnerConfig_assert_classNotNull);
/*     */     }
/*  59 */     if (classPath == null) {
/*  60 */       throw new IllegalArgumentException(LaunchingMessages.vmRunnerConfig_assert_classPathNotNull);
/*     */     }
/*  62 */     this.fClassToLaunch = classToLaunch;
/*  63 */     this.fClassPath = classPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVMSpecificAttributesMap(Map<String, Object> map) {
/*  74 */     this.fVMSpecificAttributesMap = map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVMArguments(String[] args) {
/*  87 */     if (args == null) {
/*  88 */       throw new IllegalArgumentException(LaunchingMessages.vmRunnerConfig_assert_vmArgsNotNull);
/*     */     }
/*  90 */     this.fVMArgs = args;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProgramArguments(String[] args) {
/* 103 */     if (args == null) {
/* 104 */       throw new IllegalArgumentException(LaunchingMessages.vmRunnerConfig_assert_programArgsNotNull);
/*     */     }
/* 106 */     this.fProgramArgs = args;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnvironment(String[] environment) {
/* 119 */     this.fEnvironment = environment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBootClassPath(String[] bootClassPath) {
/* 137 */     this.fBootClassPath = bootClassPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getVMSpecificAttributesMap() {
/* 148 */     return this.fVMSpecificAttributesMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassToLaunch() {
/* 157 */     return this.fClassToLaunch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getClassPath() {
/* 166 */     return this.fClassPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getBootClassPath() {
/* 188 */     return this.fBootClassPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getVMArguments() {
/* 198 */     if (this.fVMArgs == null) {
/* 199 */       return fgEmpty;
/*     */     }
/* 201 */     return this.fVMArgs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getProgramArguments() {
/* 211 */     if (this.fProgramArgs == null) {
/* 212 */       return fgEmpty;
/*     */     }
/* 214 */     return this.fProgramArgs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getEnvironment() {
/* 224 */     return this.fEnvironment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWorkingDirectory(String path) {
/* 237 */     this.fWorkingDirectory = path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getWorkingDirectory() {
/* 249 */     return this.fWorkingDirectory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResumeOnStartup(boolean resume) {
/* 260 */     this.fResume = resume;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isResumeOnStartup() {
/* 272 */     return this.fResume;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModulepath(String[] modulepath) {
/* 283 */     this.fModulepath = modulepath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getModulepath() {
/* 293 */     return this.fModulepath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModuleDescription(String fModuleDescription) {
/* 304 */     this.fModuleDescription = fModuleDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getModuleDescription() {
/* 314 */     return this.fModuleDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOverrideDependencies() {
/* 324 */     return this.fOverrideDependencies;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOverrideDependencies(String fOverrideDependencies) {
/* 335 */     this.fOverrideDependencies = fOverrideDependencies;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPreviewEnabled() {
/* 345 */     return this.fPreviewEnabled.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPreviewEnabled(boolean fPreviewEnabled) {
/* 356 */     this.fPreviewEnabled = Boolean.valueOf(fPreviewEnabled);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMergeOutput() {
/* 366 */     return this.fMergeOutput;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMergeOutput(boolean fMergeOutput) {
/* 377 */     this.fMergeOutput = fMergeOutput;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\VMRunnerConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */