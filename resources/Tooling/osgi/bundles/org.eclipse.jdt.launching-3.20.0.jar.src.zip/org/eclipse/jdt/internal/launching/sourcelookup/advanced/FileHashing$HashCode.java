/*     */ package org.eclipse.jdt.internal.launching.sourcelookup.advanced;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HashCode
/*     */ {
/*     */   private final byte[] bytes;
/*     */   
/*     */   public HashCode(byte[] bytes) {
/*  94 */     this.bytes = bytes;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  99 */     return Arrays.hashCode(this.bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 104 */     if (obj == this) {
/* 105 */       return true;
/*     */     }
/* 107 */     if (!(obj instanceof HashCode)) {
/* 108 */       return false;
/*     */     }
/* 110 */     return Arrays.equals(this.bytes, ((HashCode)obj).bytes);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 115 */     StringBuilder sb = new StringBuilder(2 * this.bytes.length); byte b; int i; byte[] arrayOfByte;
/* 116 */     for (i = (arrayOfByte = this.bytes).length, b = 0; b < i; ) { byte b1 = arrayOfByte[b];
/* 117 */       sb.append(hexDigits[b1 >> 4 & 0xF]).append(hexDigits[b1 & 0xF]); b++; }
/*     */     
/* 119 */     return sb.toString();
/*     */   }
/*     */   
/* 122 */   private static final char[] hexDigits = "0123456789abcdef".toCharArray();
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\sourcelookup\advanced\FileHashing$HashCode.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */