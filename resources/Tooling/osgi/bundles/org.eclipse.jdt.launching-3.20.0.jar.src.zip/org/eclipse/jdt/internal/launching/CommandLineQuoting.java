/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import org.eclipse.core.runtime.Platform;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommandLineQuoting
/*    */ {
/*    */   public static String[] quoteWindowsArgs(String[] cmdLine) {
/* 17 */     if (Platform.getOS().equals("win32")) {
/* 18 */       String[] winCmdLine = new String[cmdLine.length];
/* 19 */       if (cmdLine.length > 0) {
/* 20 */         winCmdLine[0] = cmdLine[0];
/*    */       }
/* 22 */       for (int i = 1; i < cmdLine.length; i++) {
/* 23 */         winCmdLine[i] = winQuote(cmdLine[i]);
/*    */       }
/* 25 */       cmdLine = winCmdLine;
/*    */     } 
/* 27 */     return cmdLine;
/*    */   }
/*    */   
/*    */   static boolean needsQuoting(String s) {
/* 31 */     int len = s.length();
/* 32 */     if (len == 0) {
/* 33 */       return true;
/*    */     }
/* 35 */     if ("\"\"".equals(s))
/*    */     {
/* 37 */       return false;
/*    */     }
/* 39 */     for (int i = 0; i < len; i++) {
/* 40 */       switch (s.charAt(i)) {
/*    */         case '\t':
/*    */         case ' ':
/*    */         case '"':
/*    */         case '\\':
/* 45 */           return true;
/*    */       } 
/*    */     } 
/* 48 */     return false;
/*    */   }
/*    */   
/*    */   private static String winQuote(String s) {
/* 52 */     if (!needsQuoting(s)) {
/* 53 */       return s;
/*    */     }
/* 55 */     s = s.replaceAll("([\\\\]*)\"", "$1$1\\\\\"");
/* 56 */     s = s.replaceAll("([\\\\]*)\\z", "$1$1");
/* 57 */     return "\"" + s + "\"";
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\CommandLineQuoting.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */