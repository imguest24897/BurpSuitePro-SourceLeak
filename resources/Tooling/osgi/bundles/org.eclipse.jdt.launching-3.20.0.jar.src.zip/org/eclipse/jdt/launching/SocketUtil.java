/*    */ package org.eclipse.jdt.launching;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.ConnectException;
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SocketUtil
/*    */ {
/* 29 */   private static final Random fgRandom = new Random(System.currentTimeMillis());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public static int findUnusedLocalPort(String host, int searchFrom, int searchTo) {
/* 46 */     for (int i = 0; i < 10; i++) {
/* 47 */       int port = getRandomPort(searchFrom, searchTo); try {
/* 48 */         Exception exception2, exception1 = null;
/*    */       }
/* 50 */       catch (ConnectException connectException) {
/* 51 */         return port;
/* 52 */       } catch (IOException iOException) {}
/*    */     } 
/*    */     
/* 55 */     return -1;
/*    */   }
/*    */   
/*    */   private static int getRandomPort(int low, int high) {
/* 59 */     return (int)(fgRandom.nextFloat() * (high - low)) + low;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int findFreePort() {
/*    */     
/* 69 */     try { Exception exception1 = null, exception2 = null; try {  }
/*    */       finally
/* 71 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  }  } catch (IOException iOException)
/*    */     
/* 73 */     { return -1; }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\SocketUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */