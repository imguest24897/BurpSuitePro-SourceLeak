/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.debug.core.model.IProcess;
/*     */ import org.eclipse.debug.core.model.IStreamsProxy;
/*     */ import org.eclipse.jdt.launching.AbstractVMInstallType;
/*     */ import org.eclipse.jdt.launching.IVMInstallType;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.jdt.launching.VMStandin;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MacInstalledJREs
/*     */ {
/*     */   private static final String JAVA_HOME_PLIST = "/usr/libexec/java_home";
/*     */   private static final String PLIST_JVM_HOME_PATH = "JVMHomePath";
/*     */   private static final String PLIST_JVM_NAME = "JVMName";
/*     */   private static final String PLIST_JVM_VERSION = "JVMVersion";
/*     */   private static final String PLIST_JVM_BUNDLE_ID = "JVMBundleID";
/*  58 */   public static final VMStandin[] NO_VMS = new VMStandin[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class MacVMStandin
/*     */     extends VMStandin
/*     */   {
/*  66 */     String version = null;
/*     */     
/*     */     public MacVMStandin(IVMInstallType type, File location, String name, String version, String id) {
/*  69 */       super(type, id);
/*  70 */       setInstallLocation(location);
/*  71 */       setName(name);
/*  72 */       this.version = version;
/*     */     }
/*     */ 
/*     */     
/*     */     public String getJavaVersion() {
/*  77 */       return this.version;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VMStandin[] getInstalledJREs(IProgressMonitor monitor) throws CoreException {
/*  90 */     SubMonitor smonitor = SubMonitor.convert(monitor);
/*     */     
/*     */     try {
/*  93 */       File java_home = new File("/usr/libexec/java_home");
/*  94 */       if (!java_home.exists()) {
/*  95 */         throw new CoreException(new Status(2, LaunchingPlugin.getUniqueIdentifier(), "The java_home executable does not exist"));
/*     */       }
/*  97 */       String[] cmdLine = { "/usr/libexec/java_home", "-X" };
/*  98 */       Process p = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 121 */       if (!smonitor.isCanceled()) {
/* 122 */         smonitor.done();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static VMStandin[] parseJREInfo(IProcess process, IProgressMonitor monitor) throws CoreException {
/* 136 */     IStreamsProxy streamsProxy = process.getStreamsProxy();
/* 137 */     String text = null;
/* 138 */     if (streamsProxy != null) {
/* 139 */       text = streamsProxy.getOutputStreamMonitor().getContents();
/*     */     }
/* 141 */     if (text != null && text.length() > 0) {
/* 142 */       ByteArrayInputStream stream = new ByteArrayInputStream(text.getBytes());
/* 143 */       return parseJREInfo(stream, monitor);
/*     */     } 
/* 145 */     return NO_VMS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VMStandin[] parseJREInfo(InputStream stream, IProgressMonitor monitor) {
/* 158 */     SubMonitor smonitor = SubMonitor.convert(monitor, LaunchingMessages.MacInstalledJREs_0, 10);
/*     */     try {
/* 160 */       Object result = (new PListParser()).parse(stream);
/* 161 */       if (result instanceof Object[]) {
/* 162 */         Object[] maps = (Object[])result;
/* 163 */         smonitor.setWorkRemaining(maps.length);
/* 164 */         List<VMStandin> jres = new ArrayList<>();
/* 165 */         AbstractVMInstallType mactype = (AbstractVMInstallType)JavaRuntime.getVMInstallType("org.eclipse.jdt.internal.launching.macosx.MacOSXType");
/* 166 */         if (mactype != null) {
/* 167 */           for (int i = 0; i < maps.length; i++) {
/* 168 */             if (smonitor.isCanceled())
/*     */             {
/* 170 */               return jres.<VMStandin>toArray(new VMStandin[jres.size()]);
/*     */             }
/* 172 */             Object object = maps[i];
/* 173 */             if (object instanceof Map) {
/* 174 */               Map<?, ?> map = (Map<?, ?>)object;
/* 175 */               Object home = map.get("JVMHomePath");
/* 176 */               Object name = map.get("JVMName");
/* 177 */               Object version = map.get("JVMVersion");
/* 178 */               if (home instanceof String && name instanceof String && version instanceof String) {
/* 179 */                 smonitor.setTaskName(NLS.bind(LaunchingMessages.MacInstalledJREs_1, (Object[])new String[] { (String)name, (String)version }));
/* 180 */                 String ver = (String)version;
/* 181 */                 File loc = new File((String)home);
/*     */ 
/*     */                 
/* 184 */                 StringBuilder namebuff = new StringBuilder(name.toString());
/* 185 */                 namebuff.append(" [").append(ver).append("]");
/* 186 */                 MacVMStandin vm = new MacVMStandin((IVMInstallType)mactype, loc, namebuff.toString(), ver, computeId(map, ver));
/* 187 */                 vm.setJavadocLocation(mactype.getDefaultJavadocLocation(loc));
/* 188 */                 vm.setLibraryLocations(mactype.getDefaultLibraryLocations(loc));
/* 189 */                 vm.setVMArgs(mactype.getDefaultVMArguments(loc));
/* 190 */                 if (!jres.contains(vm)) {
/* 191 */                   jres.add(vm);
/*     */                 }
/*     */               } 
/*     */             } 
/* 195 */             smonitor.worked(1);
/*     */           } 
/*     */         }
/* 198 */         return jres.<VMStandin>toArray(new VMStandin[jres.size()]);
/*     */       } 
/* 200 */     } catch (CoreException ce) {
/* 201 */       LaunchingPlugin.log((Throwable)ce);
/*     */     } finally {
/*     */       
/* 204 */       smonitor.done();
/*     */     } 
/* 206 */     return NO_VMS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String computeId(Map<?, ?> map, String version) {
/* 218 */     Object o = map.get("JVMBundleID");
/* 219 */     if (o instanceof String) {
/* 220 */       return (String)o;
/*     */     }
/* 222 */     return version;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\MacInstalledJREs.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */