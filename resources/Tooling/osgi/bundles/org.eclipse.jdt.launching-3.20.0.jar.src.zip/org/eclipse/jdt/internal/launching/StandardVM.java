/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.io.File;
/*     */ import org.eclipse.jdt.launching.AbstractVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstallType;
/*     */ import org.eclipse.jdt.launching.IVMRunner;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardVM
/*     */   extends AbstractVMInstall
/*     */ {
/*     */   public static final String VAR_PORT = "${port}";
/*     */   
/*     */   StandardVM(IVMInstallType type, String id) {
/*  35 */     super(type, id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IVMRunner getVMRunner(String mode) {
/*  42 */     if ("run".equals(mode))
/*  43 */       return (IVMRunner)new StandardVMRunner((IVMInstall)this); 
/*  44 */     if ("debug".equals(mode)) {
/*  45 */       return (IVMRunner)new StandardVMDebugger((IVMInstall)this);
/*     */     }
/*  47 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJavaVersion() {
/*  55 */     StandardVMType installType = (StandardVMType)getVMInstallType();
/*  56 */     File installLocation = getInstallLocation();
/*  57 */     if (installLocation != null) {
/*  58 */       File executable = getJavaExecutable();
/*  59 */       if (executable != null) {
/*  60 */         String vmVersion = installType.getVMVersion(installLocation, executable);
/*     */         
/*  62 */         StringBuilder version = new StringBuilder();
/*  63 */         for (int i = 0; i < vmVersion.length(); ) {
/*  64 */           char ch = vmVersion.charAt(i);
/*  65 */           if (Character.isDigit(ch) || ch == '.') {
/*  66 */             version.append(ch);
/*     */             i++;
/*     */           } 
/*     */           break;
/*     */         } 
/*  71 */         if (version.length() > 0) {
/*  72 */           return version.toString();
/*     */         }
/*     */       } 
/*  75 */       LaunchingPlugin.log(NLS.bind(LaunchingMessages.vmInstall_could_not_determine_java_Version, installLocation.getAbsolutePath()));
/*     */     } 
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   File getJavaExecutable() {
/*  86 */     File installLocation = getInstallLocation();
/*  87 */     if (installLocation != null) {
/*  88 */       return StandardVMType.findJavaExecutable(installLocation);
/*     */     }
/*  90 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDebugArgs() {
/* 101 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\StandardVM.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */