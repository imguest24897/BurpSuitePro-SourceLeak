/*    */ package org.eclipse.jdt.launching;
/*    */ 
/*    */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IVMInstallChangedListener
/*    */ {
/* 35 */   public static final String PROPERTY_LIBRARY_LOCATIONS = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".PROPERTY_LIBRARY_LOCATIONS";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public static final String PROPERTY_NAME = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".PROPERTY_NAME";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   public static final String PROPERTY_INSTALL_LOCATION = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".PROPERTY_INSTALL_LOCATION";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   public static final String PROPERTY_JAVADOC_LOCATION = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".PROPERTY_JAVADOC_LOCATION";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 61 */   public static final String PROPERTY_VM_ARGUMENTS = String.valueOf(LaunchingPlugin.getUniqueIdentifier()) + ".PROPERTY_VM_ARGUMENTS";
/*    */   
/*    */   void defaultVMInstallChanged(IVMInstall paramIVMInstall1, IVMInstall paramIVMInstall2);
/*    */   
/*    */   void vmChanged(PropertyChangeEvent paramPropertyChangeEvent);
/*    */   
/*    */   void vmAdded(IVMInstall paramIVMInstall);
/*    */   
/*    */   void vmRemoved(IVMInstall paramIVMInstall);
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\IVMInstallChangedListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */