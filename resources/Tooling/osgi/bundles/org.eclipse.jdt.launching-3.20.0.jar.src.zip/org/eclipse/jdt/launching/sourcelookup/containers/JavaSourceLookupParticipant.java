/*     */ package org.eclipse.jdt.launching.sourcelookup.containers;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.debug.core.sourcelookup.AbstractSourceLookupParticipant;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceContainer;
/*     */ import org.eclipse.debug.core.sourcelookup.ISourceLookupDirector;
/*     */ import org.eclipse.debug.core.sourcelookup.containers.ArchiveSourceContainer;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.internal.debug.core.JavaDebugUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaSourceLookupParticipant
/*     */   extends AbstractSourceLookupParticipant
/*     */ {
/*     */   private Map<ISourceContainer, PackageFragmentRootSourceContainer> fDelegateContainers;
/*     */   
/*     */   public String getSourceName(Object object) throws CoreException {
/*  64 */     return JavaDebugUtils.getSourceName(object);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispose() {
/*  72 */     Iterator<PackageFragmentRootSourceContainer> iterator = this.fDelegateContainers.values().iterator();
/*  73 */     while (iterator.hasNext()) {
/*  74 */       ISourceContainer container = (ISourceContainer)iterator.next();
/*  75 */       container.dispose();
/*     */     } 
/*  77 */     this.fDelegateContainers = null;
/*  78 */     super.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ISourceContainer getDelegateContainer(ISourceContainer container) {
/*  87 */     ISourceContainer delegate = (ISourceContainer)this.fDelegateContainers.get(container);
/*  88 */     if (delegate == null) {
/*  89 */       return container;
/*     */     }
/*  91 */     return delegate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(ISourceLookupDirector director) {
/*  98 */     super.init(director);
/*  99 */     this.fDelegateContainers = new HashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sourceContainersChanged(ISourceLookupDirector director) {
/* 107 */     this.fDelegateContainers.clear();
/* 108 */     ISourceContainer[] containers = director.getSourceContainers();
/* 109 */     for (int i = 0; i < containers.length; i++) {
/* 110 */       ISourceContainer container = containers[i];
/* 111 */       if (container.getType().getId().equals(ArchiveSourceContainer.TYPE_ID)) {
/* 112 */         IFile file = ((ArchiveSourceContainer)container).getFile();
/* 113 */         IProject project = file.getProject();
/* 114 */         IJavaProject javaProject = JavaCore.create(project);
/* 115 */         if (javaProject.exists())
/*     */           try {
/* 117 */             IPackageFragmentRoot[] roots = javaProject.getPackageFragmentRoots();
/* 118 */             for (int j = 0; j < roots.length; j++) {
/* 119 */               IPackageFragmentRoot root = roots[j];
/* 120 */               if (file.equals(root.getUnderlyingResource())) {
/*     */                 
/* 122 */                 this.fDelegateContainers.put(container, new PackageFragmentRootSourceContainer(root));
/*     */               } else {
/* 124 */                 IPath path = root.getSourceAttachmentPath();
/* 125 */                 if (path != null && 
/* 126 */                   file.getFullPath().equals(path))
/*     */                 {
/* 128 */                   this.fDelegateContainers.put(container, new PackageFragmentRootSourceContainer(root));
/*     */                 }
/*     */               }
/*     */             
/*     */             } 
/* 133 */           } catch (JavaModelException javaModelException) {} 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\sourcelookup\containers\JavaSourceLookupParticipant.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */