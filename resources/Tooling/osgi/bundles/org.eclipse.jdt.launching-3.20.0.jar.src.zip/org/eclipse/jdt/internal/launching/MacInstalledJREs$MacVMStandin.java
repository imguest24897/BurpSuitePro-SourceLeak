/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.eclipse.jdt.launching.IVMInstallType;
/*    */ import org.eclipse.jdt.launching.VMStandin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MacVMStandin
/*    */   extends VMStandin
/*    */ {
/* 66 */   String version = null;
/*    */   
/*    */   public MacVMStandin(IVMInstallType type, File location, String name, String version, String id) {
/* 69 */     super(type, id);
/* 70 */     setInstallLocation(location);
/* 71 */     setName(name);
/* 72 */     this.version = version;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getJavaVersion() {
/* 77 */     return this.version;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\MacInstalledJREs$MacVMStandin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */