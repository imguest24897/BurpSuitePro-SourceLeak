/*     */ package org.eclipse.jdt.launching.environments;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.jdt.internal.launching.EEVMType;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingMessages;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ import org.eclipse.jdt.internal.launching.StandardVMType;
/*     */ import org.eclipse.jdt.launching.LibraryLocation;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExecutionEnvironmentDescription
/*     */ {
/*     */   public static final String ENDORSED_DIRS = "-Dee.endorsed.dirs";
/*     */   public static final String BOOT_CLASS_PATH = "-Dee.bootclasspath";
/*     */   public static final String SOURCE_DEFAULT = "-Dee.src";
/*     */   public static final String SOURCE_MAP = "-Dee.src.map";
/*     */   public static final String JAVADOC_LOC = "-Dee.javadoc";
/*     */   public static final String INDEX_LOC = "-Dee.index";
/*     */   public static final String ADDITIONAL_DIRS = "-Dee.additional.dirs";
/*     */   public static final String EXTENSION_DIRS = "-Dee.ext.dirs";
/*     */   public static final String LANGUAGE_LEVEL = "-Dee.language.level";
/*     */   public static final String CLASS_LIB_LEVEL = "-Dee.class.library.level";
/*     */   public static final String EXECUTABLE = "-Dee.executable";
/*     */   public static final String EXECUTABLE_CONSOLE = "-Dee.executable.console";
/*     */   public static final String JAVA_HOME = "-Djava.home";
/*     */   public static final String DEBUG_ARGS = "-Dee.debug.args";
/*     */   public static final String EE_NAME = "-Dee.name";
/*     */   public static final String EE_HOME = "-Dee.home";
/*     */   private static final String VAR_EE_HOME = "${ee.home}";
/*     */   private static final String EE_ARG_FILTER = "-Dee.";
/* 183 */   private static final Character WILDCARD_SINGLE_CHAR = Character.valueOf('?');
/* 184 */   private static final Character WILDCARD_MULTI_CHAR = Character.valueOf('*');
/*     */ 
/*     */   
/*     */   private static final String REGEX_SPECIAL_CHARS = "+()^$.{}[]|\\";
/*     */ 
/*     */   
/* 190 */   private Map<String, String> fProperties = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExecutionEnvironmentDescription(File eeFile) throws CoreException {
/* 201 */     initProperties(eeFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getProperties() {
/* 213 */     return this.fProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProperty(String property) {
/* 224 */     return this.fProperties.get(property);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LibraryLocation[] getLibraryLocations() {
/* 237 */     List<LibraryLocation> allLibs = new ArrayList<>();
/*     */     
/* 239 */     String dirs = getProperty("-Dee.endorsed.dirs");
/* 240 */     if (dirs != null)
/*     */     {
/* 242 */       allLibs.addAll(StandardVMType.gatherAllLibraries(resolvePaths(dirs)));
/*     */     }
/*     */ 
/*     */     
/* 246 */     dirs = getProperty("-Dee.bootclasspath");
/* 247 */     if (dirs != null) {
/* 248 */       String[] bootpath = resolvePaths(dirs);
/* 249 */       List<LibraryLocation> boot = new ArrayList<>(bootpath.length);
/* 250 */       IPath src = getSourceLocation();
/* 251 */       URL url = getJavadocLocation();
/* 252 */       URL indexurl = getIndexLocation();
/* 253 */       for (int i = 0; i < bootpath.length; i++) {
/* 254 */         Path path = new Path(bootpath[i]);
/* 255 */         File file = path.toFile();
/* 256 */         if (file.exists() && file.isFile()) {
/* 257 */           LibraryLocation libraryLocation = new LibraryLocation((IPath)path, src, (IPath)Path.EMPTY, url, indexurl);
/* 258 */           boot.add(libraryLocation);
/*     */         } 
/*     */       } 
/* 261 */       allLibs.addAll(boot);
/*     */     } 
/*     */ 
/*     */     
/* 265 */     dirs = getProperty("-Dee.additional.dirs");
/* 266 */     if (dirs != null) {
/* 267 */       allLibs.addAll(StandardVMType.gatherAllLibraries(resolvePaths(dirs)));
/*     */     }
/*     */ 
/*     */     
/* 271 */     dirs = getProperty("-Dee.ext.dirs");
/* 272 */     if (dirs != null) {
/* 273 */       allLibs.addAll(StandardVMType.gatherAllLibraries(resolvePaths(dirs)));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 278 */     HashSet<String> set = new HashSet<>();
/* 279 */     LibraryLocation lib = null;
/* 280 */     for (ListIterator<LibraryLocation> liter = allLibs.listIterator(); liter.hasNext(); ) {
/* 281 */       lib = liter.next();
/* 282 */       if (!set.add(lib.getSystemLibraryPath().toOSString()))
/*     */       {
/* 284 */         liter.remove();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 289 */     addSourceLocationsToLibraries(getSourceMap(), allLibs);
/*     */     
/* 291 */     return allLibs.<LibraryLocation>toArray(new LibraryLocation[allLibs.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getVMArguments() {
/* 303 */     StringBuilder arguments = new StringBuilder();
/* 304 */     Iterator<Map.Entry<String, String>> entries = this.fProperties.entrySet().iterator();
/* 305 */     while (entries.hasNext()) {
/* 306 */       Map.Entry<String, String> entry = entries.next();
/* 307 */       String key = entry.getKey();
/* 308 */       String value = entry.getValue();
/* 309 */       boolean appendArgument = !key.startsWith("-Dee.");
/* 310 */       if (appendArgument) {
/* 311 */         arguments.append(key);
/* 312 */         if (!value.isEmpty()) {
/* 313 */           arguments.append('=');
/* 314 */           value = resolveHome(value);
/* 315 */           if (value.indexOf(' ') > -1) {
/* 316 */             arguments.append('"').append(value).append('"');
/*     */           } else {
/* 318 */             arguments.append(value);
/*     */           } 
/*     */         } 
/* 321 */         arguments.append(' ');
/*     */       } 
/*     */     } 
/* 324 */     if (arguments.charAt(arguments.length() - 1) == ' ') {
/* 325 */       arguments.deleteCharAt(arguments.length() - 1);
/*     */     }
/* 327 */     return arguments.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getExecutable() {
/* 337 */     String property = getProperty("-Dee.executable");
/* 338 */     if (property != null) {
/* 339 */       String[] paths = resolvePaths(property);
/* 340 */       if (paths.length == 1) {
/* 341 */         return new File(paths[0]);
/*     */       }
/*     */     } 
/* 344 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getConsoleExecutable() {
/* 354 */     String property = getProperty("-Dee.executable.console");
/* 355 */     if (property != null) {
/* 356 */       String[] paths = resolvePaths(property);
/* 357 */       if (paths.length == 1) {
/* 358 */         return new File(paths[0]);
/*     */       }
/*     */     } 
/* 361 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initProperties(File eeFile) throws CoreException {
/* 372 */     Map<String, String> properties = new LinkedHashMap<>();
/* 373 */     String eeHome = eeFile.getParentFile().getAbsolutePath(); try {
/* 374 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 394 */     catch (FileNotFoundException e) {
/* 395 */       throw new CoreException(new Status(4, "org.eclipse.jdt.launching", 
/* 396 */             NLS.bind(LaunchingMessages.ExecutionEnvironmentDescription_0, new String[] { eeFile.getPath() }), e));
/* 397 */     } catch (IOException e) {
/* 398 */       throw new CoreException(new Status(4, "org.eclipse.jdt.launching", 
/* 399 */             NLS.bind(LaunchingMessages.ExecutionEnvironmentDescription_1, new String[] { eeFile.getPath() }), e));
/*     */     } 
/* 401 */     if (!properties.containsKey("-Dee.home")) {
/* 402 */       properties.put("-Dee.home", eeHome);
/*     */     }
/*     */     
/* 405 */     this.fProperties = properties;
/* 406 */     Iterator<Map.Entry<String, String>> entries = properties.entrySet().iterator();
/* 407 */     Map<String, String> resolved = new LinkedHashMap<>(properties.size());
/* 408 */     while (entries.hasNext()) {
/* 409 */       Map.Entry<String, String> entry = entries.next();
/* 410 */       String key = entry.getKey();
/* 411 */       String value = entry.getValue();
/* 412 */       if (value != null) {
/* 413 */         value = resolveHome(value);
/* 414 */         resolved.put(key, value); continue;
/*     */       } 
/* 416 */       resolved.put(key, "");
/*     */     } 
/*     */     
/* 419 */     this.fProperties = resolved;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String resolveHome(String value) {
/* 430 */     int start = 0;
/* 431 */     int index = value.indexOf("${ee.home}", start);
/* 432 */     StringBuilder replaced = null;
/* 433 */     String eeHome = getProperty("-Dee.home");
/* 434 */     while (index >= 0) {
/* 435 */       if (replaced == null) {
/* 436 */         replaced = new StringBuilder();
/*     */       }
/* 438 */       replaced.append(value.substring(start, index));
/* 439 */       replaced.append(eeHome);
/* 440 */       start = index + "${ee.home}".length();
/* 441 */       index = value.indexOf("${ee.home}", start);
/*     */     } 
/* 443 */     if (replaced != null) {
/* 444 */       replaced.append(value.substring(start));
/* 445 */       return replaced.toString();
/*     */     } 
/* 447 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] resolvePaths(String paths) {
/* 458 */     String[] strings = paths.split(File.pathSeparator, -1);
/* 459 */     String eeHome = getProperty("-Dee.home");
/* 460 */     Path path = new Path(eeHome);
/* 461 */     for (int i = 0; i < strings.length; i++) {
/* 462 */       strings[i] = makePathAbsolute(strings[i], (IPath)path);
/*     */     }
/* 464 */     return strings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String makePathAbsolute(String pathString, IPath root) {
/* 477 */     Path path = new Path(pathString.trim());
/* 478 */     if (!path.isEmpty() && !path.isAbsolute()) {
/* 479 */       IPath filePath = root.append((IPath)path);
/* 480 */       return filePath.toOSString();
/*     */     } 
/* 482 */     return path.toOSString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, String> getSourceMap() {
/* 503 */     String srcMapString = getProperty("-Dee.src.map");
/* 504 */     Map<String, String> srcMap = new HashMap<>();
/* 505 */     if (srcMapString != null) {
/*     */       
/* 507 */       String[] entries = srcMapString.split(File.pathSeparator);
/* 508 */       for (int i = 0; i < entries.length; i++) {
/* 509 */         int index = entries[i].indexOf('=');
/* 510 */         if (index > 0 && index < entries[i].length() - 1) {
/* 511 */           Path path = new Path(getProperty("-Dee.home"));
/* 512 */           String key = entries[i].substring(0, index);
/* 513 */           String value = entries[i].substring(index + 1);
/* 514 */           key = makePathAbsolute(key, (IPath)path);
/* 515 */           value = makePathAbsolute(value, (IPath)path);
/*     */           
/* 517 */           List<Character> wildcards = new ArrayList<>();
/* 518 */           StringBuilder keyBuffer = new StringBuilder();
/* 519 */           char[] chars = key.toCharArray();
/*     */           
/* 521 */           for (int j = 0; j < chars.length; j++) {
/* 522 */             if (chars[j] == WILDCARD_MULTI_CHAR.charValue()) {
/* 523 */               wildcards.add(WILDCARD_MULTI_CHAR);
/* 524 */               keyBuffer.append("(.*)");
/* 525 */             } else if (chars[j] == WILDCARD_SINGLE_CHAR.charValue()) {
/* 526 */               wildcards.add(WILDCARD_SINGLE_CHAR);
/* 527 */               keyBuffer.append("(.)");
/* 528 */             } else if ("+()^$.{}[]|\\".indexOf(chars[j]) != -1) {
/* 529 */               keyBuffer.append('\\').append(chars[j]);
/*     */             } else {
/* 531 */               keyBuffer.append(chars[j]);
/*     */             } 
/*     */           } 
/*     */           
/* 535 */           int currentWild = 0;
/* 536 */           StringBuilder valueBuffer = new StringBuilder();
/* 537 */           chars = value.toCharArray();
/*     */           
/* 539 */           for (int k = 0; k < chars.length; k++) {
/* 540 */             if (chars[k] == WILDCARD_MULTI_CHAR.charValue() || chars[k] == WILDCARD_SINGLE_CHAR.charValue()) {
/* 541 */               if (currentWild < wildcards.size()) {
/* 542 */                 Character wild = wildcards.get(currentWild);
/* 543 */                 if (chars[k] == wild.charValue()) {
/* 544 */                   valueBuffer.append('$').append(currentWild + 1);
/* 545 */                   currentWild++;
/*     */                 } else {
/* 547 */                   LaunchingPlugin.log(NLS.bind(LaunchingMessages.EEVMType_5, (Object[])new String[] { entries[i] }));
/*     */                   break;
/*     */                 } 
/*     */               } else {
/* 551 */                 LaunchingPlugin.log(NLS.bind(LaunchingMessages.EEVMType_5, (Object[])new String[] { entries[i] }));
/*     */                 break;
/*     */               } 
/* 554 */             } else if ("+()^$.{}[]|\\".indexOf(chars[k]) != -1) {
/* 555 */               valueBuffer.append('\\').append(chars[k]);
/*     */             } else {
/* 557 */               valueBuffer.append(chars[k]);
/*     */             } 
/*     */           } 
/*     */           
/* 561 */           srcMap.put(keyBuffer.toString(), valueBuffer.toString());
/*     */         } else {
/*     */           
/* 564 */           LaunchingPlugin.log(NLS.bind(LaunchingMessages.EEVMType_6, (Object[])new String[] { entries[i] }));
/*     */         } 
/*     */       } 
/*     */     } 
/* 568 */     return srcMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addSourceLocationsToLibraries(Map<String, String> srcMap, List<LibraryLocation> libraries) {
/* 581 */     for (Iterator<String> patternIterator = srcMap.keySet().iterator(); patternIterator.hasNext(); ) {
/*     */       
/* 583 */       String currentKey = patternIterator.next();
/* 584 */       Pattern currentPattern = Pattern.compile(currentKey);
/* 585 */       Matcher matcher = currentPattern.matcher("");
/* 586 */       for (Iterator<LibraryLocation> locationIterator = libraries.iterator(); locationIterator.hasNext(); ) {
/* 587 */         LibraryLocation currentLibrary = locationIterator.next();
/* 588 */         matcher.reset(currentLibrary.getSystemLibraryPath().toOSString());
/* 589 */         if (matcher.find()) {
/*     */           
/* 591 */           String sourceLocation = matcher.replaceAll(srcMap.get(currentKey));
/* 592 */           Path path = new Path(sourceLocation);
/*     */           
/* 594 */           if (path.toFile().exists()) {
/* 595 */             currentLibrary.setSystemLibrarySource((IPath)path);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IPath getSourceLocation() {
/* 610 */     String src = getProperty("-Dee.src");
/* 611 */     if (src != null) {
/* 612 */       String eeHome = getProperty("-Dee.home");
/* 613 */       src = makePathAbsolute(src, (IPath)new Path(eeHome));
/* 614 */       return (IPath)new Path(src);
/*     */     } 
/* 616 */     return (IPath)Path.EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private URL getJavadocLocation() {
/* 626 */     return EEVMType.getJavadocLocation(this.fProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private URL getIndexLocation() {
/* 636 */     return EEVMType.getIndexLocation(this.fProperties);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\environments\ExecutionEnvironmentDescription.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */