/*    */ package org.eclipse.jdt.internal.launching.sourcelookup.advanced;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CacheKey
/*    */ {
/*    */   public final File file;
/*    */   private final long length;
/*    */   private final long lastModified;
/*    */   
/*    */   public CacheKey(File file) throws IOException {
/* 63 */     this.file = file.getCanonicalFile();
/* 64 */     this.length = file.length();
/* 65 */     this.lastModified = file.lastModified();
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 70 */     int hash = 17;
/* 71 */     hash = hash * 31 + this.file.hashCode();
/* 72 */     hash = hash * 31 + (int)this.length;
/* 73 */     hash = hash * 31 + (int)this.lastModified;
/* 74 */     return hash;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 79 */     if (obj == this) {
/* 80 */       return true;
/*    */     }
/* 82 */     if (!(obj instanceof CacheKey)) {
/* 83 */       return false;
/*    */     }
/* 85 */     CacheKey other = (CacheKey)obj;
/* 86 */     return (this.file.equals(other.file) && this.length == other.length && this.lastModified == other.lastModified);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\sourcelookup\advanced\FileHashing$CacheKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */