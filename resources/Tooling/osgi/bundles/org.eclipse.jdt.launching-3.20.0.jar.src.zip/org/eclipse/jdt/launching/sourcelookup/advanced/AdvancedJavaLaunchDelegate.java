/*    */ package org.eclipse.jdt.launching.sourcelookup.advanced;
/*    */ 
/*    */ import org.eclipse.jdt.launching.JavaLaunchDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AdvancedJavaLaunchDelegate
/*    */   extends JavaLaunchDelegate
/*    */ {
/*    */   public AdvancedJavaLaunchDelegate() {
/* 27 */     allowAdvancedSourcelookup();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\sourcelookup\advanced\AdvancedJavaLaunchDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */