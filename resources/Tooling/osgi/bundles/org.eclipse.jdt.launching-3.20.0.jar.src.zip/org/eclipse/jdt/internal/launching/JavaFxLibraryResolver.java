/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ import org.eclipse.jdt.launching.ILibraryLocationResolver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaFxLibraryResolver
/*    */   implements ILibraryLocationResolver
/*    */ {
/*    */   public static final String JFXRT_JAR = "jfxrt.jar";
/*    */   private static final String JAVAFX_SRC_ZIP = "javafx-src.zip";
/*    */   private static final String JAVAFX_8_JAVADOC = "http://docs.oracle.com/javase/8/javafx/api/";
/*    */   
/*    */   private static boolean isJavaFx(IPath libraryPath) {
/* 31 */     return "jfxrt.jar".equals(libraryPath.lastSegment());
/*    */   }
/*    */ 
/*    */   
/*    */   public IPath getPackageRoot(IPath libraryPath) {
/* 36 */     return (IPath)Path.EMPTY;
/*    */   }
/*    */ 
/*    */   
/*    */   public IPath getSourcePath(IPath libraryPath) {
/* 41 */     if (isJavaFx(libraryPath)) {
/* 42 */       File parent = libraryPath.toFile().getParentFile();
/* 43 */       while (parent != null) {
/* 44 */         File parentsrc = new File(parent, "javafx-src.zip");
/* 45 */         if (parentsrc.isFile()) {
/* 46 */           return (IPath)new Path(parentsrc.getPath());
/*    */         }
/* 48 */         parent = parent.getParentFile();
/*    */       } 
/*    */     } 
/* 51 */     return (IPath)Path.EMPTY;
/*    */   }
/*    */ 
/*    */   
/*    */   public URL getJavadocLocation(IPath libraryPath) {
/* 56 */     if (isJavaFx(libraryPath)) {
/*    */       
/*    */       try {
/*    */ 
/*    */ 
/*    */         
/* 62 */         return new URL("http://docs.oracle.com/javase/8/javafx/api/");
/*    */       }
/* 64 */       catch (MalformedURLException e) {
/* 65 */         LaunchingPlugin.log(e);
/*    */       } 
/*    */     }
/* 68 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public URL getIndexLocation(IPath libraryPath) {
/* 73 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\JavaFxLibraryResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */