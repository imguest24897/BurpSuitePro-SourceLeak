/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.text.DateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.SubProgressMonitor;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.model.IProcess;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.jdt.launching.LibraryLocation;
/*     */ import org.eclipse.jdt.launching.VMRunnerConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Standard11xVMRunner
/*     */   extends StandardVMRunner
/*     */ {
/*     */   public Standard11xVMRunner(IVMInstall vmInstance) {
/*  44 */     super(vmInstance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run(VMRunnerConfiguration config, ILaunch launch, IProgressMonitor monitor) throws CoreException {
/*     */     NullProgressMonitor nullProgressMonitor;
/*  52 */     if (monitor == null) {
/*  53 */       nullProgressMonitor = new NullProgressMonitor();
/*     */     }
/*  55 */     SubProgressMonitor subProgressMonitor = new SubProgressMonitor((IProgressMonitor)nullProgressMonitor, 1);
/*  56 */     subProgressMonitor.beginTask(LaunchingMessages.StandardVMRunner_Launching_VM____1, 2);
/*  57 */     subProgressMonitor.subTask(LaunchingMessages.StandardVMRunner_Constructing_command_line____2);
/*     */     
/*  59 */     String program = constructProgramString(config);
/*     */     
/*  61 */     List<String> arguments = new ArrayList<>();
/*  62 */     arguments.add(program);
/*     */ 
/*     */ 
/*     */     
/*  66 */     String[] vmArgs = combineVmArgs(config, this.fVMInstance);
/*  67 */     addArguments(vmArgs, arguments);
/*     */     
/*  69 */     String[] bootCP = config.getBootClassPath();
/*  70 */     String[] classPath = config.getClassPath();
/*     */     
/*  72 */     String[] combinedPath = null;
/*  73 */     if (bootCP == null) {
/*  74 */       LibraryLocation[] locs = JavaRuntime.getLibraryLocations(this.fVMInstance);
/*  75 */       bootCP = new String[locs.length];
/*  76 */       for (int j = 0; j < locs.length; j++) {
/*  77 */         bootCP[j] = locs[j].getSystemLibraryPath().toOSString();
/*     */       }
/*     */     } 
/*     */     
/*  81 */     combinedPath = new String[bootCP.length + classPath.length];
/*  82 */     int offset = 0; int i;
/*  83 */     for (i = 0; i < bootCP.length; i++) {
/*  84 */       combinedPath[offset] = bootCP[i];
/*  85 */       offset++;
/*     */     } 
/*  87 */     for (i = 0; i < classPath.length; i++) {
/*  88 */       combinedPath[offset] = classPath[i];
/*  89 */       offset++;
/*     */     } 
/*  91 */     if (combinedPath.length > 0) {
/*  92 */       arguments.add("-classpath");
/*  93 */       arguments.add(convertClassPath(combinedPath));
/*     */     } 
/*  95 */     arguments.add(config.getClassToLaunch());
/*     */     
/*  97 */     String[] programArgs = config.getProgramArguments();
/*     */     
/*  99 */     String[] envp = prependJREPath(config.getEnvironment());
/* 100 */     int lastVMArgumentIndex = arguments.size() - 1;
/* 101 */     addArguments(programArgs, arguments);
/*     */     
/* 103 */     String[] cmdLine = new String[arguments.size()];
/* 104 */     arguments.toArray(cmdLine);
/*     */ 
/*     */     
/* 107 */     if (nullProgressMonitor.isCanceled()) {
/*     */       return;
/*     */     }
/* 110 */     File workingDir = getWorkingDir(config);
/* 111 */     ClasspathShortener classpathShortener = new ClasspathShortener(this.fVMInstance, launch, cmdLine, lastVMArgumentIndex, workingDir, envp);
/* 112 */     if (classpathShortener.shortenCommandLineIfNecessary()) {
/* 113 */       cmdLine = classpathShortener.getCmdLine();
/* 114 */       envp = classpathShortener.getEnvp();
/*     */     } 
/*     */     
/* 117 */     subProgressMonitor.worked(1);
/* 118 */     subProgressMonitor.subTask(LaunchingMessages.StandardVMRunner_Starting_virtual_machine____3);
/*     */     
/* 120 */     Process p = null;
/* 121 */     String[] newCmdLine = validateCommandLine(launch.getLaunchConfiguration(), cmdLine);
/* 122 */     if (newCmdLine != null) {
/* 123 */       cmdLine = newCmdLine;
/*     */     }
/* 125 */     p = exec(cmdLine, workingDir, envp);
/* 126 */     if (p == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 131 */     if (nullProgressMonitor.isCanceled()) {
/* 132 */       p.destroy();
/*     */       return;
/*     */     } 
/* 135 */     String timestamp = DateFormat.getDateTimeInstance(2, 2).format(new Date(System.currentTimeMillis()));
/* 136 */     IProcess process = DebugPlugin.newProcess(launch, p, renderProcessLabel(p, cmdLine, timestamp));
/* 137 */     process.setAttribute("org.eclipse.debug.core.ATTR_PATH", cmdLine[0]);
/* 138 */     process.setAttribute(IProcess.ATTR_CMDLINE, renderCommandLine(cmdLine));
/* 139 */     String ltime = launch.getAttribute("org.eclipse.debug.core.launch.timestamp");
/* 140 */     process.setAttribute("org.eclipse.debug.core.launch.timestamp", (ltime != null) ? ltime : timestamp);
/* 141 */     if (workingDir != null) {
/* 142 */       process.setAttribute("org.eclipse.debug.core.ATTR_WORKING_DIRECTORY", workingDir.getAbsolutePath());
/*     */     }
/* 144 */     if (!classpathShortener.getProcessTempFiles().isEmpty()) {
/* 145 */       String tempFiles = classpathShortener.getProcessTempFiles().stream().map(file -> file.getAbsolutePath()).collect(Collectors.joining(File.pathSeparator));
/* 146 */       process.setAttribute("tempFiles", tempFiles);
/*     */     } 
/* 148 */     subProgressMonitor.worked(1);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\Standard11xVMRunner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */