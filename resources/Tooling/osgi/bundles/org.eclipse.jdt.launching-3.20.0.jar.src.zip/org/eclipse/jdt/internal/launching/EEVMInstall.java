/*    */ package org.eclipse.jdt.internal.launching;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.eclipse.jdt.launching.IVMInstallType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EEVMInstall
/*    */   extends StandardVM
/*    */ {
/*    */   public static final String ATTR_JAVA_VERSION = "ATTR_JAVA_VERSION";
/*    */   public static final String ATTR_EXECUTION_ENVIRONMENT_ID = "ATTR_EXECUTION_ENVIRONMENT_ID";
/*    */   public static final String ATTR_JAVA_EXE = "ATTR_JAVA_EXE";
/*    */   public static final String ATTR_DEBUG_ARGS = "ATTR_DEBUG_ARGS";
/*    */   public static final String ATTR_DEFINITION_FILE = "ATTR_DEFINITION_FILE";
/*    */   
/*    */   EEVMInstall(IVMInstallType type, String id) {
/* 59 */     super(type, id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getJavaVersion() {
/* 67 */     return getAttribute("ATTR_JAVA_VERSION");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   File getJavaExecutable() {
/* 75 */     String exe = getAttribute("ATTR_JAVA_EXE");
/* 76 */     if (exe != null) {
/* 77 */       return new File(exe);
/*    */     }
/* 79 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDebugArgs() {
/* 87 */     return getAttribute("ATTR_DEBUG_ARGS");
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\EEVMInstall.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */