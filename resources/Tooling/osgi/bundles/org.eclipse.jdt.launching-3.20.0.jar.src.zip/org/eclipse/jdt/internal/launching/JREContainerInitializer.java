/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.jdt.core.ClasspathContainerInitializer;
/*     */ import org.eclipse.jdt.core.IClasspathAttribute;
/*     */ import org.eclipse.jdt.core.IClasspathContainer;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstallType;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.jdt.launching.LibraryLocation;
/*     */ import org.eclipse.jdt.launching.VMStandin;
/*     */ import org.eclipse.jdt.launching.environments.IExecutionEnvironment;
/*     */ import org.eclipse.jdt.launching.environments.IExecutionEnvironmentsManager;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JREContainerInitializer
/*     */   extends ClasspathContainerInitializer
/*     */ {
/*     */   public void initialize(IPath containerPath, IJavaProject project) throws CoreException {
/*  55 */     if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/*  56 */       LaunchingPlugin.trace("<JRE_CONTAINER> initialize()");
/*  57 */       LaunchingPlugin.trace("\tPath: " + containerPath.toString());
/*  58 */       LaunchingPlugin.trace("\tProj: " + project.getProject().getName());
/*     */     } 
/*  60 */     int size = containerPath.segmentCount();
/*  61 */     if (size > 0) {
/*  62 */       if (containerPath.segment(0).equals(JavaRuntime.JRE_CONTAINER)) {
/*  63 */         IVMInstall vm = resolveVM(containerPath);
/*  64 */         JREContainer container = null;
/*  65 */         if (vm != null) {
/*  66 */           if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/*  67 */             LaunchingPlugin.trace("\tResolved VM: " + vm.getName());
/*     */           }
/*  69 */           container = new JREContainer(vm, containerPath, project);
/*     */         }
/*  71 */         else if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/*  72 */           LaunchingPlugin.trace("\t*** FAILED RESOLVE VM ***");
/*     */         } 
/*     */         
/*  75 */         JavaCore.setClasspathContainer(containerPath, new IJavaProject[] { project }, new IClasspathContainer[] { container }, null);
/*     */       }
/*  77 */       else if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/*  78 */         LaunchingPlugin.trace("\t*** INVALID JRE CONTAINER PATH ***");
/*     */       }
/*     */     
/*     */     }
/*  82 */     else if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/*  83 */       LaunchingPlugin.trace("\t*** NO SEGMENTS IN CONTAINER PATH ***");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(IPath containerPath, IJavaProject[] projects) throws CoreException {
/*  96 */     int size = containerPath.segmentCount();
/*  97 */     if (size > 0) {
/*  98 */       if (containerPath.segment(0).equals(JavaRuntime.JRE_CONTAINER)) {
/*  99 */         int length = projects.length;
/* 100 */         IVMInstall vm = resolveVM(containerPath);
/* 101 */         JREContainer[] arrayOfJREContainer = new JREContainer[length];
/* 102 */         if (vm != null) {
/* 103 */           if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/* 104 */             LaunchingPlugin.trace("\tResolved VM: " + vm.getName());
/*     */           }
/* 106 */           for (int i = 0; i < length; i++) {
/* 107 */             arrayOfJREContainer[i] = new JREContainer(vm, containerPath, projects[i]);
/*     */           }
/*     */         }
/* 110 */         else if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/* 111 */           LaunchingPlugin.trace("\t*** FAILED RESOLVE VM ***");
/*     */         } 
/*     */         
/* 114 */         JavaCore.setClasspathContainer(containerPath, projects, (IClasspathContainer[])arrayOfJREContainer, null);
/*     */       }
/* 116 */       else if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/* 117 */         LaunchingPlugin.trace("\t*** INVALID JRE CONTAINER PATH ***");
/*     */       }
/*     */     
/*     */     }
/* 121 */     else if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/* 122 */       LaunchingPlugin.trace("\t*** NO SEGMENTS IN CONTAINER PATH ***");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IVMInstall resolveVM(IPath containerPath) {
/* 134 */     IVMInstall vm = null;
/* 135 */     if (containerPath.segmentCount() > 1) {
/*     */       
/* 137 */       String id = getExecutionEnvironmentId(containerPath);
/* 138 */       if (id != null) {
/* 139 */         if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/* 140 */           LaunchingPlugin.trace("<JRE_CONTAINER> resolveVM(IPath)");
/* 141 */           LaunchingPlugin.trace("\tEE: " + id);
/*     */         } 
/* 143 */         IExecutionEnvironmentsManager manager = JavaRuntime.getExecutionEnvironmentsManager();
/* 144 */         IExecutionEnvironment environment = manager.getEnvironment(id);
/* 145 */         if (environment != null) {
/* 146 */           vm = resolveVM(environment);
/*     */         }
/* 148 */         else if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/* 149 */           LaunchingPlugin.trace("\t*** NO ENVIRONMENT ***");
/*     */         } 
/*     */       } else {
/*     */         
/* 153 */         String vmTypeId = getVMTypeId(containerPath);
/* 154 */         String vmName = getVMName(containerPath);
/* 155 */         IVMInstallType vmType = JavaRuntime.getVMInstallType(vmTypeId);
/* 156 */         if (vmType != null) {
/* 157 */           vm = vmType.findVMInstallByName(vmName);
/*     */         }
/*     */       } 
/*     */     } else {
/*     */       
/* 162 */       vm = JavaRuntime.getDefaultVMInstall();
/*     */     } 
/* 164 */     return vm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IVMInstall resolveVM(IExecutionEnvironment environment) {
/* 176 */     if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/* 177 */       LaunchingPlugin.trace("<JRE_CONTAINER> resolveVM(IExecutionEnvironment)");
/*     */     }
/* 179 */     IVMInstall vm = environment.getDefaultVM();
/* 180 */     if (vm == null) {
/* 181 */       IVMInstall[] installs = environment.getCompatibleVMs();
/*     */       
/* 183 */       if (installs.length == 0 && LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/* 184 */         LaunchingPlugin.trace("\t*** NO COMPATIBLE VMS ***");
/*     */       }
/* 186 */       for (int i = 0; i < installs.length; i++) {
/* 187 */         IVMInstall install = installs[i];
/* 188 */         if (environment.isStrictlyCompatible(install)) {
/* 189 */           vm = install;
/* 190 */           if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/* 191 */             LaunchingPlugin.trace("\tPerfect Match: " + vm.getName());
/*     */           }
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 198 */       if (vm == null && installs.length > 0 && Arrays.<IVMInstall>asList(installs).contains(JavaRuntime.getDefaultVMInstall())) {
/* 199 */         vm = JavaRuntime.getDefaultVMInstall();
/*     */       }
/*     */       
/* 202 */       if (vm == null && installs.length > 0) {
/* 203 */         vm = installs[0];
/* 204 */         if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/* 205 */           LaunchingPlugin.trace("\tFirst Match: " + vm.getName());
/*     */         }
/*     */       }
/*     */     
/* 209 */     } else if (LaunchingPlugin.DEBUG_JRE_CONTAINER) {
/* 210 */       LaunchingPlugin.trace("\tUser Default VM: " + vm.getName());
/*     */     } 
/*     */     
/* 213 */     return vm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getExecutionEnvironmentId(IPath path) {
/* 224 */     String name = getVMName(path);
/* 225 */     if (name != null) {
/* 226 */       name = decodeEnvironmentId(name);
/* 227 */       IExecutionEnvironmentsManager manager = JavaRuntime.getExecutionEnvironmentsManager();
/* 228 */       IExecutionEnvironment environment = manager.getEnvironment(name);
/* 229 */       if (environment != null) {
/* 230 */         return environment.getId();
/*     */       }
/*     */     } 
/* 233 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isExecutionEnvironment(IPath path) {
/* 243 */     return (getExecutionEnvironmentId(path) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encodeEnvironmentId(String id) {
/* 253 */     return id.replace('/', '%');
/*     */   }
/*     */   
/*     */   public static String decodeEnvironmentId(String id) {
/* 257 */     return id.replace('%', '/');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getVMTypeId(IPath path) {
/* 267 */     return path.segment(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getVMName(IPath path) {
/* 277 */     return path.segment(2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canUpdateClasspathContainer(IPath containerPath, IJavaProject project) {
/* 287 */     if (containerPath != null && containerPath.segmentCount() > 0 && 
/* 288 */       JavaRuntime.JRE_CONTAINER.equals(containerPath.segment(0))) {
/* 289 */       return (resolveVM(containerPath) != null);
/*     */     }
/*     */     
/* 292 */     return false;
/*     */   }
/*     */   
/* 295 */   private static final IStatus READ_ONLY = (IStatus)new Status(4, "org.eclipse.jdt.launching", 2, new String(), null);
/* 296 */   private static final IStatus NOT_SUPPORTED = (IStatus)new Status(4, "org.eclipse.jdt.launching", 1, new String(), null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus getAccessRulesStatus(IPath containerPath, IJavaProject project) {
/* 303 */     return READ_ONLY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus getSourceAttachmentStatus(IPath containerPath, IJavaProject project) {
/* 311 */     return Status.OK_STATUS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStatus getAttributeStatus(IPath containerPath, IJavaProject project, String attributeKey) {
/* 319 */     if (attributeKey.equals("javadoc_location")) {
/* 320 */       return Status.OK_STATUS;
/*     */     }
/* 322 */     if (attributeKey.equals("annotationpath")) {
/* 323 */       return Status.OK_STATUS;
/*     */     }
/* 325 */     if (attributeKey.equals(JavaRuntime.CLASSPATH_ATTR_LIBRARY_PATH_ENTRY)) {
/* 326 */       return Status.OK_STATUS;
/*     */     }
/* 328 */     return NOT_SUPPORTED;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void requestClasspathContainerUpdate(IPath containerPath, IJavaProject project, IClasspathContainer containerSuggestion) throws CoreException {
/* 336 */     IVMInstall vm = resolveVM(containerPath);
/* 337 */     if (vm == null) {
/* 338 */       Status status = new Status(4, LaunchingPlugin.getUniqueIdentifier(), 105, NLS.bind(LaunchingMessages.JREContainerInitializer_JRE_referenced_by_classpath_container__0__does_not_exist__1, (Object[])new String[] { containerPath.toString() }), null);
/* 339 */       throw new CoreException(status);
/*     */     } 
/*     */ 
/*     */     
/* 343 */     IClasspathEntry[] entries = containerSuggestion.getClasspathEntries();
/* 344 */     LibraryLocation[] libs = new LibraryLocation[entries.length];
/* 345 */     for (int i = 0; i < entries.length; i++) {
/* 346 */       IClasspathEntry entry = entries[i];
/* 347 */       if (entry.getEntryKind() == 1) {
/* 348 */         IPath path = entry.getPath();
/* 349 */         File lib = path.toFile();
/* 350 */         if (lib.exists() && lib.isFile()) {
/* 351 */           Path path1, path2; IPath srcPath = entry.getSourceAttachmentPath();
/* 352 */           if (srcPath == null) {
/* 353 */             path1 = Path.EMPTY;
/*     */           }
/* 355 */           IPath rootPath = entry.getSourceAttachmentRootPath();
/* 356 */           if (rootPath == null) {
/* 357 */             path2 = Path.EMPTY;
/*     */           }
/* 359 */           URL javadocLocation = null;
/* 360 */           IPath externalAnnotations = null;
/* 361 */           IClasspathAttribute[] extraAttributes = entry.getExtraAttributes();
/* 362 */           for (int j = 0; j < extraAttributes.length; j++) {
/* 363 */             IClasspathAttribute attribute = extraAttributes[j];
/* 364 */             if (attribute.getName().equals("javadoc_location")) {
/* 365 */               String url = attribute.getValue();
/* 366 */               if (url != null && url.trim().length() > 0) {
/*     */                 try {
/* 368 */                   javadocLocation = new URL(url);
/* 369 */                 } catch (MalformedURLException e) {
/* 370 */                   LaunchingPlugin.log(e);
/*     */                 } 
/*     */               }
/* 373 */             } else if (attribute.getName().equals("annotationpath")) {
/* 374 */               String xpath = attribute.getValue();
/* 375 */               if (xpath != null && xpath.trim().length() > 0) {
/*     */                 try {
/* 377 */                   externalAnnotations = Path.fromPortableString(xpath);
/* 378 */                 } catch (Exception x) {
/* 379 */                   LaunchingPlugin.log(x);
/*     */                 } 
/*     */               }
/*     */             } 
/*     */           } 
/* 384 */           libs[i] = new LibraryLocation(path, (IPath)path1, (IPath)path2, javadocLocation, null, externalAnnotations);
/*     */         } else {
/* 386 */           Status status = new Status(4, LaunchingPlugin.getUniqueIdentifier(), 150, NLS.bind(LaunchingMessages.JREContainerInitializer_Classpath_entry__0__does_not_refer_to_an_existing_library__2, (Object[])new String[] { entry.getPath().toString() }), null);
/* 387 */           throw new CoreException(status);
/*     */         } 
/*     */       } else {
/* 390 */         Status status = new Status(4, LaunchingPlugin.getUniqueIdentifier(), 150, NLS.bind(LaunchingMessages.JREContainerInitializer_Classpath_entry__0__does_not_refer_to_a_library__3, (Object[])new String[] { entry.getPath().toString() }), null);
/* 391 */         throw new CoreException(status);
/*     */       } 
/*     */     } 
/* 394 */     VMStandin standin = new VMStandin(vm);
/* 395 */     standin.setLibraryLocations(libs);
/* 396 */     standin.convertToRealVM();
/* 397 */     JavaRuntime.saveVMConfiguration();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription(IPath containerPath, IJavaProject project) {
/* 405 */     String tag = getExecutionEnvironmentId(containerPath);
/* 406 */     if (tag == null && containerPath.segmentCount() > 2) {
/* 407 */       tag = getVMName(containerPath);
/*     */     }
/* 409 */     if (tag != null) {
/* 410 */       return NLS.bind(LaunchingMessages.JREContainer_JRE_System_Library_1, (Object[])new String[] { tag });
/*     */     }
/* 412 */     return LaunchingMessages.JREContainerInitializer_Default_System_Library_1;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\JREContainerInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */