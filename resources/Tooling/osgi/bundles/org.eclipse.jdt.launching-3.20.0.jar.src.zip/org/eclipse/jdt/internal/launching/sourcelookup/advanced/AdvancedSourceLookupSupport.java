/*     */ package org.eclipse.jdt.internal.launching.sourcelookup.advanced;
/*     */ 
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.locks.Lock;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.ILaunchManager;
/*     */ import org.eclipse.debug.core.Launch;
/*     */ import org.eclipse.debug.core.model.IPersistableSourceLocator;
/*     */ import org.eclipse.debug.core.model.ISourceLocator;
/*     */ import org.eclipse.debug.core.sourcelookup.IPersistableSourceLocator2;
/*     */ import org.eclipse.jdt.internal.debug.core.JDIDebugPlugin;
/*     */ import org.eclipse.jdt.internal.launching.LaunchingPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdvancedSourceLookupSupport
/*     */ {
/*     */   public static final String ID_sourceContainerResolvers = "org.eclipse.jdt.launching.sourceContainerResolvers";
/*     */   public static final String ID_workspaceProjectDescribers = "org.eclipse.jdt.launching.workspaceProjectDescribers";
/*     */   private static BackgroundProcessingJob backgroundJob;
/*     */   private static volatile WorkspaceProjectSourceContainers workspaceProjects;
/*  47 */   private static final Lock workspaceProjectsLock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void start() {
/*  53 */     backgroundJob = new BackgroundProcessingJob();
/*     */   }
/*     */   
/*     */   public static void stop() {
/*  57 */     backgroundJob.cancel();
/*  58 */     backgroundJob = null;
/*     */     
/*  60 */     workspaceProjectsLock.lock();
/*     */     try {
/*  62 */       if (workspaceProjects != null) {
/*  63 */         workspaceProjects.close();
/*  64 */         workspaceProjects = null;
/*     */       } 
/*     */     } finally {
/*     */       
/*  68 */       workspaceProjectsLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void schedule(IRunnableWithProgress task) {
/*  73 */     backgroundJob.schedule(task);
/*     */   }
/*     */   
/*     */   public static WorkspaceProjectSourceContainers getWorkspaceJavaProjects(IProgressMonitor monitor) throws CoreException {
/*  77 */     return getWorkspaceJavaProjects0(monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static WorkspaceProjectSourceContainers getWorkspaceJavaProjects0(IProgressMonitor monitor) throws CoreException {
/*  84 */     if (monitor == null || workspaceProjects != null) {
/*  85 */       return workspaceProjects;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  90 */     while (!workspaceProjectsLock.tryLock(500L, TimeUnit.MILLISECONDS)) {
/*  91 */       if (monitor.isCanceled()) {
/*  92 */         return workspaceProjects;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 104 */       if (workspaceProjects == null) {
/* 105 */         WorkspaceProjectSourceContainers _workspaceProjects = new WorkspaceProjectSourceContainers();
/* 106 */         _workspaceProjects.initialize(monitor);
/*     */ 
/*     */         
/* 109 */         workspaceProjects = _workspaceProjects;
/*     */       }
/*     */     
/*     */     } finally {
/*     */       
/* 114 */       workspaceProjectsLock.unlock();
/*     */     } 
/*     */     
/* 117 */     return workspaceProjects;
/*     */   }
/*     */   
/*     */   public static String getJavaagentString() {
/* 121 */     return "-javaagent:\"" + getJavaagentLocation() + "\"";
/*     */   }
/*     */   
/*     */   public static String getJavaagentLocation() {
/* 125 */     return LaunchingPlugin.getFileInPlugin((IPath)new Path("lib/javaagent-shaded.jar")).getAbsolutePath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IProgressMonitor getContextMonitor(IProgressMonitor monitor) {
/*     */     NullProgressMonitor nullProgressMonitor;
/* 141 */     if (monitor == null) {
/* 142 */       Job job = Job.getJobManager().currentJob();
/* 143 */       if (job != null)
/*     */       {
/*     */ 
/*     */         
/* 147 */         nullProgressMonitor = new NullProgressMonitor();
/*     */       }
/*     */     } 
/* 150 */     return (IProgressMonitor)nullProgressMonitor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ILaunch createAdvancedLaunch(ILaunchConfiguration configuration, String mode) throws CoreException {
/* 158 */     return (ILaunch)new Launch(configuration, mode, (ISourceLocator)createSourceLocator("org.eclipse.jdt.launching.sourceLocator.JavaAdvancedSourceLookupDirector", configuration));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IPersistableSourceLocator createSourceLocator(String type, ILaunchConfiguration configuration) throws CoreException {
/* 165 */     ILaunchManager launchManager = DebugPlugin.getDefault().getLaunchManager();
/*     */     
/* 167 */     IPersistableSourceLocator locator = launchManager.newSourceLocator(type);
/* 168 */     String memento = configuration.getAttribute(ILaunchConfiguration.ATTR_SOURCE_LOCATOR_MEMENTO, null);
/* 169 */     if (memento == null) {
/* 170 */       locator.initializeDefaults(configuration);
/*     */     }
/* 172 */     else if (locator instanceof IPersistableSourceLocator2) {
/* 173 */       ((IPersistableSourceLocator2)locator).initializeFromMemento(memento, configuration);
/*     */     } else {
/* 175 */       locator.initializeFromMemento(memento);
/*     */     } 
/*     */ 
/*     */     
/* 179 */     return locator;
/*     */   }
/*     */   
/*     */   public static boolean isAdvancedSourcelookupEnabled() {
/* 183 */     return Platform.getPreferencesService().getBoolean(JDIDebugPlugin.getUniqueIdentifier(), JDIDebugPlugin.PREF_ENABLE_ADVANCED_SOURCELOOKUP, true, null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\sourcelookup\advanced\AdvancedSourceLookupSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */