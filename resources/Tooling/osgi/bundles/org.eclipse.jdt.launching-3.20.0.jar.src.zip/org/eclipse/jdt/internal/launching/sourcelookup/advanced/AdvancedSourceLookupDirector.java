/*    */ package org.eclipse.jdt.internal.launching.sourcelookup.advanced;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import org.eclipse.debug.core.sourcelookup.ISourceLookupParticipant;
/*    */ import org.eclipse.jdt.internal.launching.JavaSourceLookupDirector;
/*    */ import org.eclipse.jdt.launching.sourcelookup.advanced.AdvancedSourceLookupParticipant;
/*    */ import org.eclipse.jdt.launching.sourcelookup.containers.JavaSourceLookupParticipant;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AdvancedSourceLookupDirector
/*    */   extends JavaSourceLookupDirector
/*    */ {
/*    */   public static final String ID = "org.eclipse.jdt.launching.sourceLocator.JavaAdvancedSourceLookupDirector";
/*    */   private final String mode;
/*    */   
/*    */   public AdvancedSourceLookupDirector() {
/* 35 */     this(null);
/*    */   }
/*    */   
/*    */   public AdvancedSourceLookupDirector(String mode) {
/* 39 */     this.mode = mode;
/*    */   }
/*    */ 
/*    */   
/*    */   public void initializeParticipants() {
/* 44 */     List<ISourceLookupParticipant> participants = new ArrayList<>();
/* 45 */     if (this.mode == null || "debug".equals(this.mode)) {
/* 46 */       participants.addAll(getSourceLookupParticipants());
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 51 */     participants.add(new JavaSourceLookupParticipant());
/*    */     
/* 53 */     addParticipants(participants.<ISourceLookupParticipant>toArray(new ISourceLookupParticipant[participants.size()]));
/*    */   }
/*    */   
/*    */   protected Collection<ISourceLookupParticipant> getSourceLookupParticipants() {
/* 57 */     return (Collection)Collections.singleton(new AdvancedSourceLookupParticipant());
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\sourcelookup\advanced\AdvancedSourceLookupDirector.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */