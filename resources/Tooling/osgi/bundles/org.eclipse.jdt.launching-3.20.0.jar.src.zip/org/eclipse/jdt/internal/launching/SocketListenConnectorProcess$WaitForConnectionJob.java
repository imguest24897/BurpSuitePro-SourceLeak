/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import com.sun.jdi.VMDisconnectedException;
/*     */ import com.sun.jdi.VirtualMachine;
/*     */ import com.sun.jdi.connect.Connector;
/*     */ import com.sun.jdi.connect.IllegalConnectorArgumentsException;
/*     */ import com.sun.jdi.connect.ListeningConnector;
/*     */ import com.sun.jdi.connect.TransportTimeoutException;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.jobs.Job;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.model.IDebugTarget;
/*     */ import org.eclipse.jdi.TimeoutException;
/*     */ import org.eclipse.jdt.debug.core.JDIDebugModel;
/*     */ import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WaitForConnectionJob
/*     */   extends Job
/*     */ {
/*     */   private ListeningConnector fConnector;
/*     */   private Map<String, Connector.Argument> fArguments;
/*     */   private boolean fListeningStopped = false;
/*     */   
/*     */   public WaitForConnectionJob(ListeningConnector connector, Map<String, Connector.Argument> arguments) {
/* 303 */     super(paramSocketListenConnectorProcess.getLabel());
/* 304 */     this.fConnector = connector;
/* 305 */     this.fArguments = arguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IStatus run(IProgressMonitor monitor) {
/*     */     try {
/* 314 */       Connector.Argument timeout = this.fArguments.get("timeout");
/* 315 */       if (timeout != null) {
/* 316 */         timeout.setValue("3000");
/*     */       }
/*     */       
/* 319 */       VirtualMachine vm = null;
/* 320 */       while (vm == null && !monitor.isCanceled()) {
/*     */         try {
/* 322 */           vm = this.fConnector.accept(this.fArguments);
/* 323 */         } catch (TransportTimeoutException transportTimeoutException) {}
/*     */       } 
/*     */ 
/*     */       
/* 327 */       if (monitor.isCanceled()) {
/* 328 */         this.fConnector.stopListening(this.fArguments);
/* 329 */         return Status.CANCEL_STATUS;
/*     */       } 
/*     */       
/* 332 */       ILaunchConfiguration configuration = SocketListenConnectorProcess.this.fLaunch.getLaunchConfiguration();
/* 333 */       boolean allowTerminate = false;
/* 334 */       if (configuration != null) {
/*     */         try {
/* 336 */           allowTerminate = configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_ALLOW_TERMINATE, false);
/* 337 */         } catch (CoreException e) {
/* 338 */           LaunchingPlugin.log((Throwable)e);
/*     */         } 
/*     */       }
/* 341 */       Connector.Argument portArg = this.fArguments.get("port");
/* 342 */       String vmLabel = constructVMLabel(vm, portArg.value(), SocketListenConnectorProcess.this.fLaunch.getLaunchConfiguration());
/* 343 */       IDebugTarget debugTarget = JDIDebugModel.newDebugTarget(SocketListenConnectorProcess.this.fLaunch, vm, vmLabel, null, allowTerminate, true);
/* 344 */       SocketListenConnectorProcess.this.fLaunch.addDebugTarget(debugTarget);
/* 345 */       SocketListenConnectorProcess.this.fAccepted++;
/* 346 */       return Status.OK_STATUS;
/* 347 */     } catch (IOException e) {
/* 348 */       if (this.fListeningStopped) {
/* 349 */         return Status.CANCEL_STATUS;
/*     */       }
/* 351 */       return SocketListenConnectorProcess.getStatus(LaunchingMessages.SocketListenConnectorProcess_4, e, 113);
/* 352 */     } catch (IllegalConnectorArgumentsException e) {
/* 353 */       return SocketListenConnectorProcess.getStatus(LaunchingMessages.SocketListenConnectorProcess_4, e, 113);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void canceling() {
/* 362 */     stopListening();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopListening() {
/* 372 */     if (!this.fListeningStopped) {
/*     */       try {
/* 374 */         this.fListeningStopped = true;
/* 375 */         this.fConnector.stopListening(this.fArguments);
/* 376 */       } catch (IOException e) {
/* 377 */         done(SocketListenConnectorProcess.getStatus(LaunchingMessages.SocketListenConnectorProcess_5, e, 113));
/* 378 */       } catch (IllegalConnectorArgumentsException e) {
/* 379 */         done(SocketListenConnectorProcess.getStatus(LaunchingMessages.SocketListenConnectorProcess_5, e, 113));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String constructVMLabel(VirtualMachine vm, String port, ILaunchConfiguration configuration) {
/* 392 */     String name = null;
/*     */     try {
/* 394 */       name = vm.name();
/* 395 */     } catch (TimeoutException timeoutException) {
/*     */     
/* 397 */     } catch (VMDisconnectedException vMDisconnectedException) {}
/*     */ 
/*     */     
/* 400 */     if (name == null) {
/* 401 */       if (configuration == null) {
/* 402 */         name = "";
/*     */       } else {
/* 404 */         name = configuration.getName();
/*     */       } 
/*     */     }
/* 407 */     StringBuilder buffer = new StringBuilder(name);
/* 408 */     if (SocketListenConnectorProcess.this.fConnectionLimit != 1)
/*     */     {
/*     */       
/* 411 */       buffer.append('<').append(SocketListenConnectorProcess.this.getRunningTime()).append('>');
/*     */     }
/* 413 */     buffer.append('[');
/* 414 */     buffer.append(port);
/* 415 */     buffer.append(']');
/* 416 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\SocketListenConnectorProcess$WaitForConnectionJob.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */