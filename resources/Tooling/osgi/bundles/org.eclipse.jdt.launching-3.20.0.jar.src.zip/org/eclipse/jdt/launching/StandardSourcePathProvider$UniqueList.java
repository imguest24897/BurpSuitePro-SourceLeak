/*     */ package org.eclipse.jdt.launching;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UniqueList
/*     */   extends ArrayList<IRuntimeClasspathEntry>
/*     */ {
/*     */   private static final long serialVersionUID = -7402160651027036270L;
/*     */   HashSet<IRuntimeClasspathEntry> set;
/*     */   
/*     */   public UniqueList(int length) {
/* 157 */     super(length);
/* 158 */     this.set = new HashSet<>(length);
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(int index, IRuntimeClasspathEntry element) {
/* 163 */     if (this.set.add(element)) {
/* 164 */       super.add(index, element);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean add(IRuntimeClasspathEntry o) {
/* 170 */     if (this.set.add(o)) {
/* 171 */       return super.add(o);
/*     */     }
/* 173 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends IRuntimeClasspathEntry> c) {
/* 178 */     if (this.set.addAll(c)) {
/* 179 */       return super.addAll(c);
/*     */     }
/* 181 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean addAll(int index, Collection<? extends IRuntimeClasspathEntry> c) {
/* 186 */     if (this.set.addAll(c)) {
/* 187 */       return super.addAll(index, c);
/*     */     }
/* 189 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void clear() {
/* 194 */     this.set.clear();
/* 195 */     super.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(Object elem) {
/* 200 */     return this.set.contains(elem);
/*     */   }
/*     */ 
/*     */   
/*     */   public void ensureCapacity(int minCapacity) {
/* 205 */     super.ensureCapacity(minCapacity);
/*     */   }
/*     */ 
/*     */   
/*     */   public IRuntimeClasspathEntry remove(int index) {
/* 210 */     IRuntimeClasspathEntry object = super.remove(index);
/* 211 */     this.set.remove(object);
/* 212 */     return object;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void removeRange(int fromIndex, int toIndex) {
/* 217 */     for (int index = fromIndex; index <= toIndex; index++) {
/* 218 */       remove(index);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public IRuntimeClasspathEntry set(int index, IRuntimeClasspathEntry element) {
/* 224 */     this.set.remove(element);
/* 225 */     if (this.set.add(element)) {
/* 226 */       return super.set(index, element);
/*     */     }
/* 228 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\StandardSourcePathProvider$UniqueList.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */