/*    */ package org.eclipse.jdt.launching;
/*    */ 
/*    */ import org.eclipse.debug.core.DebugPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExecutionArguments
/*    */ {
/*    */   private String fVMArgs;
/*    */   private String fProgramArgs;
/*    */   
/*    */   public ExecutionArguments(String vmArgs, String programArgs) {
/* 40 */     if (vmArgs == null || programArgs == null)
/* 41 */       throw new IllegalArgumentException(); 
/* 42 */     this.fVMArgs = vmArgs;
/* 43 */     this.fProgramArgs = programArgs;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getVMArguments() {
/* 52 */     return this.fVMArgs;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getProgramArguments() {
/* 61 */     return this.fProgramArgs;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getVMArgumentsArray() {
/* 70 */     return DebugPlugin.parseArguments(this.fVMArgs);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String[] getProgramArgumentsArray() {
/* 79 */     return DebugPlugin.parseArguments(this.fProgramArgs);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\launching\ExecutionArguments.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */