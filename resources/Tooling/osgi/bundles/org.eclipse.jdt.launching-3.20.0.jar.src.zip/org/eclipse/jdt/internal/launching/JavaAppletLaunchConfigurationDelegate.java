/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.debug.core.DebugEvent;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.IDebugEventSetListener;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.model.IDebugTarget;
/*     */ import org.eclipse.debug.core.model.IProcess;
/*     */ import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
/*     */ import org.eclipse.jdt.launching.JavaLaunchDelegate;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaAppletLaunchConfigurationDelegate
/*     */   extends JavaLaunchDelegate
/*     */   implements IDebugEventSetListener
/*     */ {
/*  50 */   private static Map<ILaunch, File> fgLaunchToFileMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ILaunch fLaunch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void launch(ILaunchConfiguration configuration, String mode, ILaunch launch, IProgressMonitor monitor) throws CoreException {
/*     */     try {
/*  63 */       this.fLaunch = launch;
/*  64 */       super.launch(configuration, mode, launch, monitor);
/*  65 */     } catch (CoreException e) {
/*  66 */       cleanup(launch);
/*  67 */       throw e;
/*     */     } 
/*  69 */     this.fLaunch = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getJavaPolicyFile(File workingDir) {
/*  79 */     File file = new File(workingDir, "java.policy.applet");
/*  80 */     if (!file.exists()) {
/*     */       
/*  82 */       File test = LaunchingPlugin.getFileInPlugin((IPath)new Path("java.policy.applet")); try {
/*  83 */         Exception exception2, exception1 = null;
/*     */       }
/*  85 */       catch (IOException iOException) {
/*  86 */         return "";
/*     */       } 
/*     */     } 
/*  89 */     return "-Djava.security.policy=java.policy.applet";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File buildHTMLFile(ILaunchConfiguration configuration, File dir) throws CoreException {
/* 104 */     String name = getAppletMainTypeName(configuration);
/* 105 */     File tempFile = new File(dir, String.valueOf(name) + System.currentTimeMillis() + ".html"); try {
/* 106 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 141 */     catch (IOException e) {
/* 142 */       LaunchingPlugin.log(e);
/*     */     } 
/*     */     
/* 145 */     return tempFile;
/*     */   }
/*     */   
/*     */   private String getQuotedString(String string) {
/* 149 */     int singleQuotes = count(string, '\'');
/* 150 */     int doubleQuotes = count(string, '"');
/* 151 */     if (doubleQuotes == 0)
/* 152 */       return String.valueOf('"') + string + '"'; 
/* 153 */     if (singleQuotes == 0) {
/* 154 */       return String.valueOf('\'') + string + '\'';
/*     */     }
/* 156 */     return String.valueOf('"') + convertToHTMLContent(string) + '"';
/*     */   }
/*     */ 
/*     */   
/*     */   private static int count(String string, char character) {
/* 161 */     int count = 0;
/* 162 */     for (int i = 0; i < string.length(); i++) {
/* 163 */       if (string.charAt(i) == character) {
/* 164 */         count++;
/*     */       }
/*     */     } 
/* 167 */     return count;
/*     */   }
/*     */   
/*     */   private static String convertToHTMLContent(String content) {
/* 171 */     content = replace(content, '"', "&quot;");
/* 172 */     content = replace(content, '\'', "&#39;");
/* 173 */     return content;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String replace(String text, char c, String s) {
/* 178 */     int previous = 0;
/* 179 */     int current = text.indexOf(c, previous);
/*     */     
/* 181 */     if (current == -1) {
/* 182 */       return text;
/*     */     }
/*     */     
/* 185 */     StringBuilder buffer = new StringBuilder();
/* 186 */     while (current > -1) {
/* 187 */       buffer.append(text.substring(previous, current));
/* 188 */       buffer.append(s);
/* 189 */       previous = current + 1;
/* 190 */       current = text.indexOf(c, previous);
/*     */     } 
/* 192 */     buffer.append(text.substring(previous));
/*     */     
/* 194 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleDebugEvents(DebugEvent[] events) {
/* 202 */     for (int i = 0; i < events.length; i++) {
/* 203 */       DebugEvent event = events[i];
/* 204 */       Object eventSource = event.getSource();
/* 205 */       switch (event.getKind()) {
/*     */ 
/*     */         
/*     */         case 8:
/* 209 */           if (eventSource != null) {
/* 210 */             ILaunch launch = null;
/* 211 */             if (eventSource instanceof IProcess) {
/* 212 */               IProcess process = (IProcess)eventSource;
/* 213 */               launch = process.getLaunch();
/* 214 */             } else if (eventSource instanceof IDebugTarget) {
/* 215 */               IDebugTarget debugTarget = (IDebugTarget)eventSource;
/* 216 */               launch = debugTarget.getLaunch();
/*     */             } 
/* 218 */             if (launch != null) {
/* 219 */               cleanup(launch);
/*     */             }
/*     */           } 
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void cleanup(ILaunch launch) {
/* 233 */     File temp = fgLaunchToFileMap.get(launch);
/* 234 */     if (temp != null) {
/*     */       try {
/* 236 */         fgLaunchToFileMap.remove(launch);
/* 237 */         temp.delete();
/*     */       } finally {
/* 239 */         if (fgLaunchToFileMap.isEmpty()) {
/* 240 */           DebugPlugin.getDefault().removeDebugEventListener(this);
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProgramArguments(ILaunchConfiguration configuration) throws CoreException {
/* 251 */     File workingDir = verifyWorkingDirectory(configuration);
/*     */     
/* 253 */     File htmlFile = buildHTMLFile(configuration, workingDir);
/* 254 */     if (htmlFile == null) {
/* 255 */       abort(LaunchingMessages.JavaAppletLaunchConfigurationDelegate_Could_not_build_HTML_file_for_applet_launch_1, null, 123);
/*     */     }
/*     */     
/* 258 */     if (fgLaunchToFileMap.isEmpty()) {
/* 259 */       DebugPlugin.getDefault().addDebugEventListener(this);
/*     */     }
/*     */     
/* 262 */     fgLaunchToFileMap.put(this.fLaunch, htmlFile);
/* 263 */     return htmlFile.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getVMArguments(ILaunchConfiguration configuration) throws CoreException {
/* 271 */     StringBuilder arguments = new StringBuilder(super.getVMArguments(configuration));
/* 272 */     File workingDir = verifyWorkingDirectory(configuration);
/* 273 */     String javaPolicyFile = getJavaPolicyFile(workingDir);
/* 274 */     arguments.append(" ");
/* 275 */     arguments.append(javaPolicyFile);
/* 276 */     return arguments.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMainTypeName(ILaunchConfiguration configuration) throws CoreException {
/* 284 */     return configuration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_APPLET_APPLETVIEWER_CLASS, "sun.applet.AppletViewer");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getAppletMainTypeName(ILaunchConfiguration configuration) throws CoreException {
/* 295 */     return super.getMainTypeName(configuration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected File getDefaultWorkingDirectory(ILaunchConfiguration configuration) throws CoreException {
/* 304 */     String outputDir = JavaRuntime.getProjectOutputDirectory(configuration);
/* 305 */     if (outputDir == null)
/*     */     {
/* 307 */       return new File(System.getProperty("user.dir"));
/*     */     }
/* 309 */     IResource resource = ResourcesPlugin.getWorkspace().getRoot().findMember(outputDir);
/* 310 */     if (resource == null || !resource.exists())
/*     */     {
/* 312 */       return new File(System.getProperty("user.dir"));
/*     */     }
/* 314 */     return resource.getLocation().toFile();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\JavaAppletLaunchConfigurationDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */