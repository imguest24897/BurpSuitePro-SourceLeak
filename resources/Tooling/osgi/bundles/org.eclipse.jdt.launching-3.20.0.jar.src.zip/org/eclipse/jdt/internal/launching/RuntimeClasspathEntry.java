/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.core.resources.IContainer;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.jdt.core.ClasspathContainerInitializer;
/*     */ import org.eclipse.jdt.core.IClasspathAttribute;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.launching.IRuntimeClasspathEntry;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RuntimeClasspathEntry
/*     */   implements IRuntimeClasspathEntry
/*     */ {
/*     */   private int fType;
/*     */   private int fClasspathProperty;
/*     */   private IClasspathEntry fClasspathEntry;
/*     */   private IClasspathEntry fResolvedEntry;
/*     */   private IJavaProject fJavaProject;
/*     */   private IPath fInvalidPath;
/*     */   
/*     */   public RuntimeClasspathEntry(IClasspathEntry entry) {
/*  59 */     this.fType = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     this.fClasspathProperty = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  69 */     this.fClasspathEntry = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     this.fResolvedEntry = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     this.fJavaProject = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     switch (entry.getEntryKind()) {
/*     */       case 2:
/*  95 */         setType(1);
/*     */         break;
/*     */       case 1:
/*  98 */         setType(2);
/*     */         break;
/*     */       case 4:
/* 101 */         setType(3);
/*     */         break;
/*     */       default:
/* 104 */         throw new IllegalArgumentException(NLS.bind(LaunchingMessages.RuntimeClasspathEntry_Illegal_classpath_entry__0__1, new String[] { entry.toString() }));
/*     */     } 
/* 106 */     setClasspathEntry(entry);
/* 107 */     initializeClasspathProperty();
/*     */   }
/*     */ 
/*     */   
/*     */   public RuntimeClasspathEntry(IClasspathEntry entry, int classpathProperty) {
/*     */     this.fType = -1;
/*     */     this.fClasspathProperty = -1;
/*     */     this.fClasspathEntry = null;
/*     */     this.fResolvedEntry = null;
/*     */     this.fJavaProject = null;
/* 117 */     switch (entry.getEntryKind()) {
/*     */       case 5:
/* 119 */         setType(4);
/*     */         break;
/*     */       case 2:
/* 122 */         setType(1);
/*     */         break;
/*     */       case 1:
/* 125 */         setType(2);
/*     */         break;
/*     */       case 4:
/* 128 */         setType(3);
/*     */         break;
/*     */       default:
/* 131 */         throw new IllegalArgumentException(NLS.bind(LaunchingMessages.RuntimeClasspathEntry_Illegal_classpath_entry__0__1, new String[] {
/* 132 */                 entry.toString() }));
/*     */     } 
/* 134 */     setClasspathEntry(entry);
/* 135 */     setClasspathProperty(classpathProperty);
/*     */   }
/*     */   public RuntimeClasspathEntry(Element root) throws CoreException {
/*     */     Path path1, path2;
/*     */     IProject proj;
/*     */     String var;
/*     */     this.fType = -1;
/*     */     this.fClasspathProperty = -1;
/*     */     this.fClasspathEntry = null;
/*     */     this.fResolvedEntry = null;
/*     */     this.fJavaProject = null;
/*     */     try {
/* 147 */       setType(Integer.parseInt(root.getAttribute("type")));
/* 148 */     } catch (NumberFormatException e) {
/* 149 */       abort(LaunchingMessages.RuntimeClasspathEntry_Unable_to_recover_runtime_class_path_entry_type_2, e);
/*     */     } 
/*     */     try {
/* 152 */       setClasspathProperty(Integer.parseInt(root.getAttribute("path")));
/* 153 */     } catch (NumberFormatException e) {
/* 154 */       abort(LaunchingMessages.RuntimeClasspathEntry_Unable_to_recover_runtime_class_path_entry_location_3, e);
/*     */     } 
/*     */ 
/*     */     
/* 158 */     IPath sourcePath = null;
/* 159 */     IPath rootPath = null;
/* 160 */     String path = root.getAttribute("sourceAttachmentPath");
/* 161 */     if (path != null && path.length() > 0) {
/* 162 */       path1 = new Path(path);
/*     */     }
/* 164 */     path = root.getAttribute("sourceRootPath");
/* 165 */     if (path != null && path.length() > 0) {
/* 166 */       path2 = new Path(path);
/*     */     }
/*     */     
/* 169 */     switch (getType()) {
/*     */       case 1:
/* 171 */         name = root.getAttribute("projectName");
/* 172 */         if (isEmpty(name)) {
/* 173 */           abort(LaunchingMessages.RuntimeClasspathEntry_Unable_to_recover_runtime_class_path_entry___missing_project_name_4, null); break;
/*     */         } 
/* 175 */         proj = ResourcesPlugin.getWorkspace().getRoot().getProject(name);
/* 176 */         setClasspathEntry(JavaCore.newProjectEntry(proj.getFullPath()));
/*     */         break;
/*     */       
/*     */       case 2:
/* 180 */         path = root.getAttribute("externalArchive");
/* 181 */         if (isEmpty(path)) {
/*     */           
/* 183 */           path = root.getAttribute("internalArchive");
/* 184 */           if (isEmpty(path)) {
/* 185 */             abort(LaunchingMessages.RuntimeClasspathEntry_Unable_to_recover_runtime_class_path_entry___missing_archive_path_5, null); break;
/*     */           } 
/* 187 */           setClasspathEntry(createLibraryEntry((IPath)path1, (IPath)path2, path));
/*     */           
/*     */           break;
/*     */         } 
/* 191 */         setClasspathEntry(createLibraryEntry((IPath)path1, (IPath)path2, path));
/*     */         break;
/*     */       
/*     */       case 3:
/* 195 */         var = root.getAttribute("containerPath");
/* 196 */         if (isEmpty(var)) {
/* 197 */           abort(LaunchingMessages.RuntimeClasspathEntry_Unable_to_recover_runtime_class_path_entry___missing_variable_name_6, null); break;
/*     */         } 
/* 199 */         setClasspathEntry(JavaCore.newVariableEntry((IPath)new Path(var), (IPath)path1, (IPath)path2));
/*     */         break;
/*     */       
/*     */       case 4:
/* 203 */         var = root.getAttribute("containerPath");
/* 204 */         if (isEmpty(var)) {
/* 205 */           abort(LaunchingMessages.RuntimeClasspathEntry_Unable_to_recover_runtime_class_path_entry___missing_variable_name_6, null); break;
/*     */         } 
/* 207 */         setClasspathEntry(JavaCore.newContainerEntry((IPath)new Path(var)));
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 212 */     String name = root.getAttribute("javaProject");
/* 213 */     if (isEmpty(name)) {
/* 214 */       this.fJavaProject = null;
/*     */     } else {
/* 216 */       IProject project2 = ResourcesPlugin.getWorkspace().getRoot().getProject(name);
/* 217 */       this.fJavaProject = JavaCore.create(project2);
/*     */     } 
/*     */   }
/*     */   
/*     */   private IClasspathEntry createLibraryEntry(IPath sourcePath, IPath rootPath, String path) {
/* 222 */     Path p = new Path(path);
/* 223 */     if (!p.isAbsolute()) {
/*     */       
/* 225 */       this.fInvalidPath = (IPath)p;
/* 226 */       return null;
/*     */     } 
/*     */     
/* 229 */     return JavaCore.newLibraryEntry((IPath)p, sourcePath, rootPath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void abort(String message, Throwable e) throws CoreException {
/* 239 */     Status status = new Status(4, LaunchingPlugin.getUniqueIdentifier(), 150, message, e);
/* 240 */     throw new CoreException(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getType() {
/* 248 */     return this.fType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setType(int type) {
/* 257 */     this.fType = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setClasspathEntry(IClasspathEntry entry) {
/* 267 */     this.fClasspathEntry = entry;
/* 268 */     this.fResolvedEntry = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IClasspathEntry getClasspathEntry() {
/* 276 */     return this.fClasspathEntry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMemento() throws CoreException {
/*     */     IResource res;
/* 284 */     Document doc = DebugPlugin.newDocument();
/* 285 */     Element node = doc.createElement("runtimeClasspathEntry");
/* 286 */     doc.appendChild(node);
/* 287 */     node.setAttribute("type", Integer.toString(getType()));
/* 288 */     node.setAttribute("path", Integer.toString(getClasspathProperty()));
/* 289 */     switch (getType()) {
/*     */       case 1:
/* 291 */         node.setAttribute("projectName", getPath().lastSegment());
/*     */         break;
/*     */       case 2:
/* 294 */         res = getResource();
/* 295 */         if (res == null) {
/* 296 */           node.setAttribute("externalArchive", getPath().toString()); break;
/*     */         } 
/* 298 */         node.setAttribute("internalArchive", res.getFullPath().toString());
/*     */         break;
/*     */       
/*     */       case 3:
/*     */       case 4:
/* 303 */         node.setAttribute("containerPath", getPath().toString());
/*     */         break;
/*     */     } 
/* 306 */     if (getSourceAttachmentPath() != null) {
/* 307 */       node.setAttribute("sourceAttachmentPath", getSourceAttachmentPath().toString());
/*     */     }
/* 309 */     if (getSourceAttachmentRootPath() != null) {
/* 310 */       node.setAttribute("sourceRootPath", getSourceAttachmentRootPath().toString());
/*     */     }
/* 312 */     if (getExternalAnnotationsPath() != null) {
/* 313 */       node.setAttribute("externalAnnotationsPath", getExternalAnnotationsPath().toString());
/*     */     }
/* 315 */     if (getJavaProject() != null) {
/* 316 */       node.setAttribute("javaProject", getJavaProject().getElementName());
/*     */     }
/* 318 */     return DebugPlugin.serializeDocument(doc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getPath() {
/* 326 */     IClasspathEntry entry = getClasspathEntry();
/* 327 */     return (entry != null) ? entry.getPath() : this.fInvalidPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IResource getResource() {
/* 335 */     switch (getType()) {
/*     */       case 3:
/*     */       case 4:
/* 338 */         return null;
/*     */     } 
/* 340 */     return getResource(getPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IResource getResource(IPath path) {
/* 353 */     if (path != null) {
/* 354 */       IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
/* 355 */       if (getType() == 1 || getType() == 2) {
/*     */         
/* 357 */         IResource member = root.findMember(path);
/* 358 */         if (member != null) {
/* 359 */           return member;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 364 */       IFile file = root.getFileForLocation(path);
/* 365 */       if (file != null) {
/* 366 */         return (IResource)file;
/*     */       }
/* 368 */       if (getType() != 2) {
/* 369 */         IContainer container = root.getContainerForLocation(path);
/* 370 */         if (container != null) {
/* 371 */           return (IResource)container;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 376 */       IFile[] files = root.findFilesForLocation(path);
/* 377 */       if (files.length > 0) {
/* 378 */         return (IResource)files[0];
/*     */       }
/*     */       
/* 381 */       if (getType() != 2) {
/*     */         
/* 383 */         IContainer[] containers = root.findContainersForLocation(path);
/* 384 */         if (containers.length > 0) {
/* 385 */           return (IResource)containers[0];
/*     */         }
/*     */       } 
/*     */       
/* 389 */       return root.findMember(path);
/*     */     } 
/* 391 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getSourceAttachmentPath() {
/* 399 */     IClasspathEntry entry = getClasspathEntry();
/* 400 */     return (entry != null) ? entry.getSourceAttachmentPath() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceAttachmentPath(IPath path) {
/* 408 */     if (path != null && path.isEmpty()) {
/* 409 */       path = null;
/*     */     }
/* 411 */     updateClasspathEntry(getPath(), path, getSourceAttachmentRootPath(), getExternalAnnotationsPath());
/*     */   }
/*     */ 
/*     */   
/*     */   public IPath getExternalAnnotationsPath() {
/* 416 */     IClasspathEntry entry = getClasspathEntry();
/* 417 */     if (entry != null) {
/* 418 */       String s = findClasspathAttribute(entry.getExtraAttributes(), "annotationpath");
/* 419 */       if (s != null) {
/* 420 */         return (IPath)new Path(s);
/*     */       }
/*     */     } 
/* 423 */     return null;
/*     */   }
/*     */   
/*     */   private static String findClasspathAttribute(IClasspathAttribute[] attributes, String name) {
/* 427 */     for (int i = attributes.length; --i >= 0;) {
/* 428 */       if (name.equals(attributes[i].getName())) {
/* 429 */         return attributes[i].getValue();
/*     */       }
/*     */     } 
/* 432 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExternalAnnotationsPath(IPath path) {
/* 437 */     if (path != null && path.isEmpty()) {
/* 438 */       path = null;
/*     */     }
/* 440 */     updateClasspathEntry(getPath(), getSourceAttachmentPath(), getSourceAttachmentRootPath(), path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IPath getSourceAttachmentRootPath() {
/* 448 */     IClasspathEntry entry = getClasspathEntry();
/* 449 */     IPath path = (entry != null) ? getClasspathEntry().getSourceAttachmentRootPath() : null;
/* 450 */     if (path == null && getSourceAttachmentPath() != null) {
/* 451 */       return (IPath)Path.EMPTY;
/*     */     }
/* 453 */     return path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSourceAttachmentRootPath(IPath path) {
/* 461 */     if (path != null && path.isEmpty()) {
/* 462 */       path = null;
/*     */     }
/* 464 */     updateClasspathEntry(getPath(), getSourceAttachmentPath(), path, getExternalAnnotationsPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeClasspathProperty() {
/* 471 */     switch (getType()) {
/*     */       case 3:
/* 473 */         if (getVariableName().equals("JRE_LIB")) {
/* 474 */           setClasspathProperty(1); break;
/*     */         } 
/* 476 */         setClasspathProperty(3);
/*     */         break;
/*     */       
/*     */       case 1:
/*     */       case 2:
/* 481 */         setClasspathProperty(3);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClasspathProperty(int location) {
/* 494 */     this.fClasspathProperty = location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getClasspathProperty() {
/* 502 */     return this.fClasspathProperty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocation() {
/*     */     IJavaProject pro;
/*     */     IClasspathEntry resolved;
/* 511 */     IPath path = null;
/* 512 */     switch (getType()) {
/*     */       case 1:
/* 514 */         pro = (IJavaProject)JavaCore.create(getResource());
/* 515 */         if (pro != null) {
/*     */           try {
/* 517 */             path = pro.getOutputLocation();
/* 518 */           } catch (JavaModelException e) {
/* 519 */             LaunchingPlugin.log((Throwable)e);
/*     */           } 
/*     */         }
/*     */         break;
/*     */       case 2:
/* 524 */         path = getPath();
/*     */         break;
/*     */       case 3:
/* 527 */         resolved = getResolvedClasspathEntry();
/* 528 */         if (resolved != null) {
/* 529 */           path = resolved.getPath();
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 535 */     return resolveToOSPath(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String resolveToOSPath(IPath path) {
/* 544 */     if (path != null) {
/* 545 */       IResource res = null;
/* 546 */       if (path.getDevice() == null)
/*     */       {
/* 548 */         res = getResource(path);
/*     */       }
/* 550 */       if (res == null) {
/* 551 */         return path.toOSString();
/*     */       }
/* 553 */       IPath location = res.getLocation();
/* 554 */       if (location != null) {
/* 555 */         return location.toOSString();
/*     */       }
/*     */     } 
/* 558 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getVariableName() {
/* 566 */     if (getType() == 3 || getType() == 4) {
/* 567 */       return getPath().segment(0);
/*     */     }
/* 569 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 577 */     if (obj instanceof IRuntimeClasspathEntry) {
/* 578 */       IRuntimeClasspathEntry r = (IRuntimeClasspathEntry)obj;
/* 579 */       if (getType() == r.getType() && getClasspathProperty() == r.getClasspathProperty()) {
/* 580 */         if (getType() == 4) {
/* 581 */           String id = getPath().segment(0);
/* 582 */           ClasspathContainerInitializer initializer = JavaCore.getClasspathContainerInitializer(id);
/* 583 */           IJavaProject javaProject1 = getJavaProject();
/* 584 */           IJavaProject javaProject2 = r.getJavaProject();
/* 585 */           if (initializer == null || javaProject1 == null || javaProject2 == null)
/*     */           {
/* 587 */             return getPath().equals(r.getPath());
/*     */           }
/* 589 */           Object comparisonID1 = initializer.getComparisonID(getPath(), javaProject1);
/* 590 */           Object comparisonID2 = initializer.getComparisonID(r.getPath(), javaProject2);
/* 591 */           return comparisonID1.equals(comparisonID2);
/* 592 */         }  if (getPath() != null && getPath().equals(r.getPath())) {
/* 593 */           IPath sa1 = getSourceAttachmentPath();
/* 594 */           IPath root1 = getSourceAttachmentRootPath();
/* 595 */           IPath sa2 = r.getSourceAttachmentPath();
/* 596 */           IPath root2 = r.getSourceAttachmentRootPath();
/* 597 */           return (equal(sa1, sa2) && equal(root1, root2));
/*     */         } 
/*     */       } 
/*     */     } 
/* 601 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean equal(Object one, Object two) {
/* 611 */     if (one == null) {
/* 612 */       return (two == null);
/*     */     }
/* 614 */     return one.equals(two);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 622 */     if (getType() == 4) {
/* 623 */       return getPath().segment(0).hashCode() + getType();
/*     */     }
/* 625 */     return getPath().hashCode() + getType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceAttachmentLocation() {
/*     */     IClasspathEntry resolved;
/* 633 */     IPath path = null;
/* 634 */     switch (getType()) {
/*     */       case 2:
/*     */       case 3:
/* 637 */         resolved = getResolvedClasspathEntry();
/* 638 */         if (resolved != null) {
/* 639 */           path = resolved.getSourceAttachmentPath();
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 645 */     return resolveToOSPath(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceAttachmentRootLocation() {
/*     */     IClasspathEntry resolved;
/* 653 */     IPath path = null;
/* 654 */     switch (getType()) {
/*     */       case 2:
/*     */       case 3:
/* 657 */         resolved = getResolvedClasspathEntry();
/* 658 */         if (resolved != null) {
/* 659 */           path = resolved.getSourceAttachmentRootPath();
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 665 */     if (path != null) {
/* 666 */       return path.toOSString();
/*     */     }
/* 668 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateClasspathEntry(IPath path, IPath sourcePath, IPath rootPath, IPath annotationsPath) {
/*     */     IClasspathAttribute[] extraAttributes;
/* 679 */     IClasspathEntry entry = null;
/* 680 */     IClasspathEntry original = getClasspathEntry();
/* 681 */     switch (getType()) {
/*     */       case 2:
/* 683 */         extraAttributes = original.getExtraAttributes();
/* 684 */         if (annotationsPath != null) {
/* 685 */           extraAttributes = setClasspathAttribute(extraAttributes, "annotationpath", annotationsPath.toPortableString());
/*     */         }
/*     */         
/* 688 */         entry = JavaCore.newLibraryEntry(path, sourcePath, rootPath, original.getAccessRules(), extraAttributes, original.isExported());
/*     */         break;
/*     */       case 3:
/* 691 */         entry = JavaCore.newVariableEntry(path, sourcePath, rootPath);
/*     */         break;
/*     */       default:
/*     */         return;
/*     */     } 
/* 696 */     setClasspathEntry(entry);
/*     */   }
/*     */   
/*     */   private static IClasspathAttribute[] setClasspathAttribute(IClasspathAttribute[] attributes, String name, String value) {
/* 700 */     for (int i = attributes.length; --i >= 0;) {
/* 701 */       if (name.equals(attributes[i].getName())) {
/* 702 */         IClasspathAttribute[] arrayOfIClasspathAttribute = Arrays.<IClasspathAttribute>copyOf(attributes, attributes.length);
/* 703 */         arrayOfIClasspathAttribute[i] = JavaCore.newClasspathAttribute(name, value);
/* 704 */         return arrayOfIClasspathAttribute;
/*     */       } 
/*     */     } 
/* 707 */     IClasspathAttribute[] nw = Arrays.<IClasspathAttribute>copyOf(attributes, attributes.length + 1);
/* 708 */     nw[attributes.length] = JavaCore.newClasspathAttribute(name, value);
/* 709 */     return nw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IClasspathEntry getResolvedClasspathEntry() {
/* 718 */     if (this.fResolvedEntry == null) {
/* 719 */       this.fResolvedEntry = JavaCore.getResolvedClasspathEntry(getClasspathEntry());
/*     */     }
/* 721 */     return this.fResolvedEntry;
/*     */   }
/*     */   
/*     */   protected boolean isEmpty(String string) {
/* 725 */     return !(string != null && string.length() != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 730 */     if (this.fClasspathEntry != null) {
/* 731 */       return this.fClasspathEntry.toString();
/*     */     }
/* 733 */     return super.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IJavaProject getJavaProject() {
/* 741 */     return this.fJavaProject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJavaProject(IJavaProject project) {
/* 750 */     this.fJavaProject = project;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAutomodule() {
/* 755 */     IClasspathAttribute[] extraAttributes = getClasspathEntry().getExtraAttributes(); byte b; int i; IClasspathAttribute[] arrayOfIClasspathAttribute1;
/* 756 */     for (i = (arrayOfIClasspathAttribute1 = extraAttributes).length, b = 0; b < i; ) { IClasspathAttribute attribute = arrayOfIClasspathAttribute1[b];
/* 757 */       if ("module".equals(attribute.getName()) && Boolean.TRUE.toString().equals(attribute.getValue()))
/* 758 */         return true; 
/*     */       b++; }
/*     */     
/* 761 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\RuntimeClasspathEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */