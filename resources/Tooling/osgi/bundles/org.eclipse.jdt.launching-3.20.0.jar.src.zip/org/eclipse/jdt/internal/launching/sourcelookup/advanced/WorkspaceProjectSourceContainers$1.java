/*     */ package org.eclipse.jdt.internal.launching.sourcelookup.advanced;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.jdt.core.ElementChangedEvent;
/*     */ import org.eclipse.jdt.core.IElementChangedListener;
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.core.IJavaElementDelta;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements IElementChangedListener
/*     */ {
/*     */   public void elementChanged(ElementChangedEvent event) {
/*     */     try {
/*  72 */       Set<IJavaProject> remove = new HashSet<>();
/*  73 */       Set<IJavaProject> add = new HashSet<>();
/*     */       
/*  75 */       processDelta(event.getDelta(), remove, add);
/*     */       
/*  77 */       if (!remove.isEmpty() || !add.isEmpty()) {
/*  78 */         AdvancedSourceLookupSupport.schedule(m -> WorkspaceProjectSourceContainers.this.updateProjects(paramSet1, paramSet2, m));
/*     */       }
/*     */     }
/*  81 */     catch (CoreException coreException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void processDelta(IJavaElementDelta delta, Set<IJavaProject> remove, Set<IJavaProject> add) throws CoreException {
/*  89 */     IJavaElement element = delta.getElement();
/*  90 */     int kind = delta.getKind();
/*  91 */     switch (element.getElementType()) {
/*     */       case 1:
/*  93 */         processChangedChildren(delta, remove, add);
/*     */         break;
/*     */       case 2:
/*  96 */         switch (kind) {
/*     */           case 2:
/*  98 */             remove.add((IJavaProject)element);
/*     */             break;
/*     */           case 1:
/* 101 */             add.add((IJavaProject)element);
/*     */             break;
/*     */           case 4:
/* 104 */             if ((delta.getFlags() & 0x400) != 0) {
/* 105 */               remove.add((IJavaProject)element); break;
/* 106 */             }  if ((delta.getFlags() & 0x200) != 0) {
/* 107 */               add.add((IJavaProject)element); break;
/* 108 */             }  if ((delta.getFlags() & 0x220000) != 0) {
/* 109 */               remove.add((IJavaProject)element);
/* 110 */               add.add((IJavaProject)element);
/*     */             } 
/*     */             break;
/*     */         } 
/* 114 */         processChangedChildren(delta, remove, add);
/*     */         break;
/*     */       case 3:
/* 117 */         if ((delta.getFlags() & 0xC0) != 0) {
/* 118 */           remove.add(element.getJavaProject());
/* 119 */           add.add(element.getJavaProject());
/*     */         } 
/*     */         break;
/*     */     }  } private void processChangedChildren(IJavaElementDelta delta, Set<IJavaProject> remove, Set<IJavaProject> add) throws CoreException {
/*     */     byte b;
/*     */     int i;
/*     */     IJavaElementDelta[] arrayOfIJavaElementDelta;
/* 126 */     for (i = (arrayOfIJavaElementDelta = delta.getAffectedChildren()).length, b = 0; b < i; ) { IJavaElementDelta childDelta = arrayOfIJavaElementDelta[b];
/* 127 */       processDelta(childDelta, remove, add);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\sourcelookup\advanced\WorkspaceProjectSourceContainers$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */