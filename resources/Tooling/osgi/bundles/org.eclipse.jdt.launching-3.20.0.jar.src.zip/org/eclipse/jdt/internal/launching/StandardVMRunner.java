/*     */ package org.eclipse.jdt.internal.launching;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.text.DateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.debug.core.DebugPlugin;
/*     */ import org.eclipse.debug.core.ILaunch;
/*     */ import org.eclipse.debug.core.ILaunchConfiguration;
/*     */ import org.eclipse.debug.core.model.IProcess;
/*     */ import org.eclipse.jdt.launching.AbstractVMRunner;
/*     */ import org.eclipse.jdt.launching.IJavaLaunchConfigurationConstants;
/*     */ import org.eclipse.jdt.launching.IVMInstall;
/*     */ import org.eclipse.jdt.launching.IVMInstall2;
/*     */ import org.eclipse.jdt.launching.JavaRuntime;
/*     */ import org.eclipse.jdt.launching.VMRunnerConfiguration;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardVMRunner
/*     */   extends AbstractVMRunner
/*     */ {
/*     */   public static final String XSTART_ON_FIRST_THREAD = "-XstartOnFirstThread";
/*     */   protected IVMInstall fVMInstance;
/*     */   
/*     */   public StandardVMRunner(IVMInstall vmInstance) {
/*  67 */     this.fVMInstance = vmInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String renderDebugTarget(String classToRun, int host) {
/*  77 */     String format = LaunchingMessages.StandardVMRunner__0__at_localhost__1__1;
/*  78 */     return NLS.bind(format, (Object[])new String[] { classToRun, String.valueOf(host) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String renderProcessLabel(Process p, String[] commandLine, String timestamp) {
/*  92 */     String processId = getProcessId(p);
/*  93 */     if (processId == null) {
/*  94 */       String str = LaunchingMessages.StandardVMRunner__0____1___2;
/*  95 */       return NLS.bind(str, (Object[])new String[] { commandLine[0], timestamp });
/*     */     } 
/*  97 */     String format = LaunchingMessages.StandardVMRunner__0____1___2_3;
/*  98 */     return NLS.bind(format, (Object[])new String[] { commandLine[0], timestamp, processId });
/*     */   }
/*     */   
/*     */   private static String getProcessId(Process p) {
/*     */     try {
/* 103 */       return (p != null) ? Long.toString(p.pid()) : null;
/* 104 */     } catch (UnsupportedOperationException unsupportedOperationException) {
/*     */ 
/*     */       
/* 107 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String renderCommandLine(String[] commandLine) {
/* 116 */     return DebugPlugin.renderArguments(commandLine, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addArguments(String[] args, List<String> v) {
/* 125 */     if (args == null) {
/*     */       return;
/*     */     }
/* 128 */     v.addAll(Arrays.asList(args));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] validateCommandLine(ILaunchConfiguration configuration, String[] cmdLine) {
/*     */     try {
/* 145 */       return wrap(configuration, cmdLine);
/*     */     }
/* 147 */     catch (CoreException ce) {
/* 148 */       LaunchingPlugin.log((Throwable)ce);
/*     */       
/* 150 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] wrap(ILaunchConfiguration config, String[] cmdLine) throws CoreException {
/* 163 */     if (config != null && "macosx".equals(Platform.getOS())) {
/* 164 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = cmdLine).length, b = 0; b < i; ) { String element = arrayOfString[b];
/* 165 */         if ("-ws".equals(element) || element.contains("swt.jar") || element.contains("org.eclipse.swt"))
/* 166 */           return createSWTlauncher(cmdLine, 
/* 167 */               cmdLine[0], 
/* 168 */               config.getAttribute(IJavaLaunchConfigurationConstants.ATTR_USE_START_ON_FIRST_THREAD, true)); 
/*     */         b++; }
/*     */     
/*     */     } 
/* 172 */     return cmdLine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] createSWTlauncher(String[] cmdLine, String vmVersion, boolean startonfirstthread) {
/* 184 */     String java_swt = System.getProperty("org.eclipse.swtlauncher");
/* 185 */     if (java_swt == null) {
/*     */       
/* 187 */       boolean found = false;
/* 188 */       ArrayList<String> args = new ArrayList<>(); byte b; int j; String[] arrayOfString;
/* 189 */       for (j = (arrayOfString = cmdLine).length, b = 0; b < j; ) { String element = arrayOfString[b];
/* 190 */         if ("-XstartOnFirstThread".equals(element)) {
/* 191 */           found = true;
/*     */         }
/* 193 */         args.add(element);
/*     */         
/*     */         b++; }
/*     */       
/* 197 */       if (!found && startonfirstthread)
/*     */       {
/* 199 */         args.add(1, "-XstartOnFirstThread");
/*     */       }
/* 201 */       return args.<String>toArray(new String[args.size()]);
/*     */     } 
/*     */     
/*     */     try {
/* 205 */       Process process = Runtime.getRuntime().exec(new String[] { "/bin/cp", java_swt, "/tmp" });
/* 206 */       process.waitFor();
/* 207 */       java_swt = "/tmp/java_swt";
/* 208 */     } catch (IOException|InterruptedException iOException) {}
/*     */ 
/*     */     
/* 211 */     String[] newCmdLine = new String[cmdLine.length + 1];
/* 212 */     int argCount = 0;
/* 213 */     newCmdLine[argCount++] = java_swt;
/* 214 */     newCmdLine[argCount++] = "-XXvm=" + vmVersion;
/* 215 */     for (int i = 1; i < cmdLine.length; i++) {
/* 216 */       newCmdLine[argCount++] = cmdLine[i];
/*     */     }
/* 218 */     return newCmdLine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected File getWorkingDir(VMRunnerConfiguration config) throws CoreException {
/* 232 */     String path = config.getWorkingDirectory();
/* 233 */     if (path == null) {
/* 234 */       return null;
/*     */     }
/* 236 */     File dir = new File(path);
/* 237 */     if (!dir.isDirectory()) {
/* 238 */       abort(NLS.bind(LaunchingMessages.StandardVMRunner_Specified_working_directory_does_not_exist_or_is_not_a_directory___0__3, (Object[])new String[] { path }), null, 108);
/*     */     }
/* 240 */     return dir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getPluginIdentifier() {
/* 248 */     return LaunchingPlugin.getUniqueIdentifier();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String constructProgramString(VMRunnerConfiguration config) throws CoreException {
/* 263 */     String command = null;
/* 264 */     Map<String, Object> map = config.getVMSpecificAttributesMap();
/* 265 */     if (map != null) {
/* 266 */       command = (String)map.get(IJavaLaunchConfigurationConstants.ATTR_JAVA_COMMAND);
/*     */     }
/*     */ 
/*     */     
/* 270 */     if (command == null) {
/* 271 */       File file = null;
/* 272 */       if (this.fVMInstance instanceof StandardVM) {
/* 273 */         file = ((StandardVM)this.fVMInstance).getJavaExecutable();
/*     */       } else {
/* 275 */         file = StandardVMType.findJavaExecutable(this.fVMInstance.getInstallLocation());
/*     */       } 
/* 277 */       if (file == null) {
/* 278 */         abort(NLS.bind(LaunchingMessages.StandardVMRunner_Unable_to_locate_executable_for__0__1, (Object[])new String[] { this.fVMInstance.getName() }), null, 150);
/*     */       } else {
/* 280 */         return file.getAbsolutePath();
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 286 */     String installLocation = String.valueOf(this.fVMInstance.getInstallLocation().getAbsolutePath()) + File.separatorChar;
/* 287 */     File exe = new File(String.valueOf(installLocation) + "bin" + File.separatorChar + command);
/* 288 */     if (fileExists(exe)) {
/* 289 */       return exe.getAbsolutePath();
/*     */     }
/* 291 */     exe = new File(String.valueOf(exe.getAbsolutePath()) + ".exe");
/* 292 */     if (fileExists(exe)) {
/* 293 */       return exe.getAbsolutePath();
/*     */     }
/* 295 */     exe = new File(String.valueOf(installLocation) + "jre" + File.separatorChar + "bin" + File.separatorChar + command);
/* 296 */     if (fileExists(exe)) {
/* 297 */       return exe.getAbsolutePath();
/*     */     }
/* 299 */     exe = new File(String.valueOf(exe.getAbsolutePath()) + ".exe");
/* 300 */     if (fileExists(exe)) {
/* 301 */       return exe.getAbsolutePath();
/*     */     }
/*     */ 
/*     */     
/* 305 */     abort(NLS.bind(LaunchingMessages.StandardVMRunner_Specified_executable__0__does_not_exist_for__1__4, (Object[])new String[] { command, this.fVMInstance.getName() }), null, 150);
/*     */     
/* 307 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean fileExists(File file) {
/* 316 */     return (file.exists() && file.isFile());
/*     */   }
/*     */   
/*     */   protected String convertClassPath(String[] cp) {
/* 320 */     int pathCount = 0;
/* 321 */     StringBuilder buf = new StringBuilder();
/* 322 */     if (cp.length == 0)
/* 323 */       return "";  byte b; int i;
/*     */     String[] arrayOfString;
/* 325 */     for (i = (arrayOfString = cp).length, b = 0; b < i; ) { String element = arrayOfString[b];
/* 326 */       if (pathCount > 0) {
/* 327 */         buf.append(File.pathSeparator);
/*     */       }
/* 329 */       buf.append(element);
/* 330 */       pathCount++; b++; }
/*     */     
/* 332 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] ensureEncoding(ILaunch launch, String[] vmargs) {
/* 346 */     boolean foundencoding = false; byte b; int i; String[] arrayOfString;
/* 347 */     for (i = (arrayOfString = vmargs).length, b = 0; b < i; ) { String vmarg = arrayOfString[b];
/* 348 */       if (vmarg.startsWith("-Dfile.encoding="))
/* 349 */         foundencoding = true; 
/*     */       b++; }
/*     */     
/* 352 */     if (!foundencoding) {
/* 353 */       String encoding = launch.getAttribute("org.eclipse.debug.ui.ATTR_CONSOLE_ENCODING");
/* 354 */       if (encoding == null) {
/* 355 */         return vmargs;
/*     */       }
/* 357 */       String[] newargs = new String[vmargs.length + 1];
/* 358 */       System.arraycopy(vmargs, 0, newargs, 0, vmargs.length);
/* 359 */       newargs[newargs.length - 1] = "-Dfile.encoding=" + encoding;
/* 360 */       return newargs;
/*     */     } 
/* 362 */     return vmargs;
/*     */   }
/*     */   
/*     */   protected static class CommandDetails {
/*     */     private String[] commandLine;
/*     */     private String[] envp;
/*     */     private File workingDir;
/*     */     private IProcessTempFileCreator commandLineShortener;
/*     */     private int port;
/*     */     
/*     */     public String[] getEnvp() {
/* 373 */       return this.envp;
/*     */     }
/*     */     
/*     */     public void setEnvp(String[] envp) {
/* 377 */       this.envp = envp;
/*     */     }
/*     */     
/*     */     public String[] getCommandLine() {
/* 381 */       return this.commandLine;
/*     */     }
/*     */     
/*     */     public void setCommandLine(String[] commandLine) {
/* 385 */       this.commandLine = commandLine;
/*     */     }
/*     */     
/*     */     public File getWorkingDir() {
/* 389 */       return this.workingDir;
/*     */     }
/*     */     
/*     */     public void setWorkingDir(File workingDir) {
/* 393 */       this.workingDir = workingDir;
/*     */     }
/*     */     
/*     */     public IProcessTempFileCreator getCommandLineShortener() {
/* 397 */       return this.commandLineShortener;
/*     */     }
/*     */     
/*     */     public void setCommandLineShortener(IProcessTempFileCreator commandLineShortener) {
/* 401 */       this.commandLineShortener = commandLineShortener;
/*     */     }
/*     */     
/*     */     public int getPort() {
/* 405 */       return this.port;
/*     */     }
/*     */     
/*     */     public void setPort(int port) {
/* 409 */       this.port = port;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String showCommandLine(VMRunnerConfiguration configuration, ILaunch launch, IProgressMonitor monitor) throws CoreException {
/* 416 */     SubMonitor subMonitor = SubMonitor.convert(monitor, 1);
/*     */     
/* 418 */     CommandDetails cmd = getCommandLine(configuration, launch, (IProgressMonitor)subMonitor);
/* 419 */     if (subMonitor.isCanceled() || cmd == null) {
/* 420 */       return "";
/*     */     }
/* 422 */     String[] cmdLine = cmd.getCommandLine();
/* 423 */     cmdLine = quoteWindowsArgs(cmdLine);
/* 424 */     return getCmdLineAsString(cmdLine);
/*     */   }
/*     */   
/*     */   private CommandDetails getCommandLine(VMRunnerConfiguration config, ILaunch launch, IProgressMonitor monitor) throws CoreException {
/* 428 */     SubMonitor subMonitor = SubMonitor.convert(monitor, 1);
/* 429 */     subMonitor.subTask(LaunchingMessages.StandardVMRunner_Constructing_command_line____2);
/* 430 */     String program = constructProgramString(config);
/*     */     
/* 432 */     List<String> arguments = new ArrayList<>();
/* 433 */     arguments.add(program);
/*     */ 
/*     */ 
/*     */     
/* 437 */     String[] allVMArgs = combineVmArgs(config, this.fVMInstance);
/* 438 */     addArguments(ensureEncoding(launch, allVMArgs), arguments);
/*     */     
/* 440 */     addBootClassPathArguments(arguments, config);
/*     */     
/* 442 */     String[] mp = config.getModulepath();
/* 443 */     if (mp != null && mp.length > 0) {
/*     */       
/* 445 */       arguments.add("-p");
/* 446 */       arguments.add(convertClassPath(mp));
/*     */     } 
/* 448 */     String[] cp = config.getClassPath();
/* 449 */     if (cp.length > 0) {
/* 450 */       arguments.add("-classpath");
/* 451 */       arguments.add(convertClassPath(cp));
/*     */     } 
/*     */ 
/*     */     
/* 455 */     if (config.isPreviewEnabled()) {
/* 456 */       arguments.add("--enable-preview");
/*     */     }
/*     */     
/* 459 */     ILaunchConfiguration launchConfiguration = launch.getLaunchConfiguration();
/*     */     
/* 461 */     if (getJavaVersion(this.fVMInstance) >= 14.0D && 
/* 462 */       launchConfiguration != null && 
/* 463 */       launchConfiguration.getAttribute(IJavaLaunchConfigurationConstants.ATTR_SHOW_CODEDETAILS_IN_EXCEPTION_MESSAGES, true)) {
/* 464 */       arguments.add("-XX:+ShowCodeDetailsInExceptionMessages");
/*     */     }
/*     */ 
/*     */     
/* 468 */     String dependencies = config.getOverrideDependencies();
/* 469 */     if (dependencies != null && dependencies.length() > 0) {
/* 470 */       arguments.addAll(Arrays.asList(DebugPlugin.parseArguments(dependencies)));
/*     */     }
/* 472 */     if (isModular(config, this.fVMInstance)) {
/* 473 */       arguments.add("-m");
/* 474 */       arguments.add(String.valueOf(config.getModuleDescription()) + "/" + config.getClassToLaunch());
/*     */     } else {
/* 476 */       arguments.add(config.getClassToLaunch());
/*     */     } 
/* 478 */     int lastVMArgumentIndex = arguments.size() - 1;
/* 479 */     String[] programArgs = config.getProgramArguments();
/* 480 */     addArguments(programArgs, arguments);
/*     */     
/* 482 */     String[] envp = prependJREPath(config.getEnvironment());
/*     */     
/* 484 */     String[] cmdLine = new String[arguments.size()];
/* 485 */     arguments.toArray(cmdLine);
/* 486 */     File workingDir = getWorkingDir(config);
/* 487 */     CommandDetails cmd = new CommandDetails();
/* 488 */     CommandLineShortener commandLineShortener = new CommandLineShortener(this.fVMInstance, launch, cmdLine, workingDir);
/* 489 */     if (commandLineShortener.shouldShortenCommandLine()) {
/* 490 */       cmdLine = commandLineShortener.shortenCommandLine();
/* 491 */       cmd.setCommandLineShortener(commandLineShortener);
/*     */     } else {
/* 493 */       ClasspathShortener classpathShortener = new ClasspathShortener(this.fVMInstance, launch, cmdLine, lastVMArgumentIndex, workingDir, envp);
/* 494 */       if (classpathShortener.shortenCommandLineIfNecessary()) {
/* 495 */         cmdLine = classpathShortener.getCmdLine();
/* 496 */         envp = classpathShortener.getEnvp();
/*     */       } 
/* 498 */       cmd.setCommandLineShortener(classpathShortener);
/*     */     } 
/* 500 */     String[] newCmdLine = validateCommandLine(launchConfiguration, cmdLine);
/* 501 */     if (newCmdLine != null) {
/* 502 */       cmdLine = newCmdLine;
/*     */     }
/*     */     
/* 505 */     cmd.setCommandLine(cmdLine);
/* 506 */     cmd.setEnvp(envp);
/* 507 */     cmd.setWorkingDir(workingDir);
/* 508 */     subMonitor.worked(1);
/* 509 */     return cmd;
/*     */   }
/*     */ 
/*     */   
/*     */   public void run(VMRunnerConfiguration config, ILaunch launch, IProgressMonitor monitor) throws CoreException {
/* 514 */     SubMonitor subMonitor = SubMonitor.convert(monitor, 1);
/*     */     
/* 516 */     CommandDetails cmdDetails = getCommandLine(config, launch, (IProgressMonitor)subMonitor);
/*     */     
/* 518 */     if (subMonitor.isCanceled() || cmdDetails == null) {
/*     */       return;
/*     */     }
/* 521 */     String[] cmdLine = cmdDetails.getCommandLine();
/*     */     
/* 523 */     subMonitor.beginTask(LaunchingMessages.StandardVMRunner_Launching_VM____1, 2);
/* 524 */     subMonitor.subTask(LaunchingMessages.StandardVMRunner_Starting_virtual_machine____3);
/* 525 */     Process p = null;
/* 526 */     p = exec(cmdLine, cmdDetails.getWorkingDir(), cmdDetails.getEnvp(), config.isMergeOutput());
/* 527 */     if (p == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 532 */     if (subMonitor.isCanceled()) {
/* 533 */       p.destroy();
/*     */       return;
/*     */     } 
/* 536 */     String timestamp = DateFormat.getDateTimeInstance(2, 2).format(new Date(System.currentTimeMillis()));
/* 537 */     IProcess process = newProcess(launch, p, renderProcessLabel(p, cmdLine, timestamp), getDefaultProcessMap());
/* 538 */     process.setAttribute("org.eclipse.debug.core.ATTR_PATH", cmdLine[0]);
/* 539 */     process.setAttribute(IProcess.ATTR_CMDLINE, renderCommandLine(cmdLine));
/* 540 */     String ltime = launch.getAttribute("org.eclipse.debug.core.launch.timestamp");
/* 541 */     process.setAttribute("org.eclipse.debug.core.launch.timestamp", (ltime != null) ? ltime : timestamp);
/* 542 */     if (cmdDetails.getWorkingDir() != null) {
/* 543 */       process.setAttribute("org.eclipse.debug.core.ATTR_WORKING_DIRECTORY", cmdDetails.getWorkingDir().getAbsolutePath());
/*     */     }
/* 545 */     if (cmdDetails.getEnvp() != null) {
/* 546 */       String[] envp = cmdDetails.getEnvp();
/* 547 */       Arrays.sort((Object[])envp);
/* 548 */       process.setAttribute("org.eclipse.debug.core.ATTR_ENVIRONMENT", String.join(String.valueOf('\n'), (CharSequence[])envp));
/*     */     } 
/* 550 */     List<File> processTempFiles = cmdDetails.getCommandLineShortener().getProcessTempFiles();
/* 551 */     if (!processTempFiles.isEmpty()) {
/* 552 */       String tempFiles = processTempFiles.stream().map(File::getAbsolutePath).collect(Collectors.joining(File.pathSeparator));
/* 553 */       process.setAttribute("tempFiles", tempFiles);
/*     */     } 
/* 555 */     subMonitor.worked(1);
/* 556 */     subMonitor.done();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getCPIndex(String[] env) {
/* 566 */     if (env != null) {
/* 567 */       for (int i = 0; i < env.length; i++) {
/* 568 */         if (env[i].regionMatches(true, 0, "CLASSPATH=", 0, 10)) {
/* 569 */           return i;
/*     */         }
/*     */       } 
/*     */     }
/* 573 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] prependJREPath(String[] env) {
/* 584 */     if ("macosx".equals(Platform.getOS()) && 
/* 585 */       this.fVMInstance instanceof IVMInstall2) {
/* 586 */       IVMInstall2 vm = (IVMInstall2)this.fVMInstance;
/* 587 */       String javaVersion = vm.getJavaVersion();
/* 588 */       if (javaVersion != null) {
/* 589 */         if (env == null) {
/* 590 */           Map<String, String> map = DebugPlugin.getDefault().getLaunchManager().getNativeEnvironmentCasePreserved();
/* 591 */           if (map.containsKey("JAVA_JVM_VERSION")) {
/* 592 */             String[] env2 = new String[map.size()];
/* 593 */             Iterator<Map.Entry<String, String>> iterator = map.entrySet().iterator();
/* 594 */             int i = 0;
/* 595 */             while (iterator.hasNext()) {
/* 596 */               Map.Entry<String, String> entry = iterator.next();
/* 597 */               String key = entry.getKey();
/* 598 */               if ("JAVA_JVM_VERSION".equals(key)) {
/* 599 */                 env2[i] = String.valueOf(key) + "=" + javaVersion;
/*     */               } else {
/* 601 */                 env2[i] = String.valueOf(key) + "=" + (String)entry.getValue();
/*     */               } 
/* 603 */               i++;
/*     */             } 
/* 605 */             env = env2;
/*     */           } 
/*     */         } else {
/* 608 */           for (int i = 0; i < env.length; i++) {
/* 609 */             String string = env[i];
/* 610 */             if (string.startsWith("JAVA_JVM_VERSION")) {
/* 611 */               env[i] = "JAVA_JVM_VERSION=" + javaVersion;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/* 619 */     return env;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addBootClassPathArguments(List<String> arguments, VMRunnerConfiguration config) {
/* 628 */     String[] prependBootCP = null;
/* 629 */     String[] bootCP = null;
/* 630 */     String[] appendBootCP = null;
/* 631 */     Map<String, Object> map = config.getVMSpecificAttributesMap();
/* 632 */     if (map != null) {
/* 633 */       prependBootCP = (String[])map.get(IJavaLaunchConfigurationConstants.ATTR_BOOTPATH_PREPEND);
/* 634 */       bootCP = (String[])map.get(IJavaLaunchConfigurationConstants.ATTR_BOOTPATH);
/* 635 */       if (JavaRuntime.isModularJava(this.fVMInstance)) {
/* 636 */         if (prependBootCP != null && prependBootCP.length > 0) {
/* 637 */           prependBootCP = null;
/* 638 */           LaunchingPlugin.log(LaunchingMessages.RunnerBootpathPError);
/*     */         } 
/* 640 */         if (bootCP != null && bootCP.length > 0) {
/* 641 */           bootCP = null;
/* 642 */           LaunchingPlugin.log(LaunchingMessages.RunnerBootpathError);
/*     */         } 
/*     */       } 
/* 645 */       appendBootCP = (String[])map.get(IJavaLaunchConfigurationConstants.ATTR_BOOTPATH_APPEND);
/*     */     } 
/* 647 */     if (!JavaRuntime.isModularJava(this.fVMInstance) && 
/* 648 */       prependBootCP == null && bootCP == null && appendBootCP == null)
/*     */     {
/* 650 */       bootCP = config.getBootClassPath();
/*     */     }
/*     */     
/* 653 */     if (prependBootCP != null) {
/* 654 */       arguments.add("-Xbootclasspath/p:" + convertClassPath(prependBootCP));
/*     */     }
/*     */     
/* 657 */     if (bootCP != null && 
/* 658 */       bootCP.length > 0) {
/* 659 */       arguments.add("-Xbootclasspath:" + convertClassPath(bootCP));
/*     */     }
/*     */     
/* 662 */     if (appendBootCP != null) {
/* 663 */       arguments.add("-Xbootclasspath/a:" + convertClassPath(appendBootCP));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected double getJavaVersion(IVMInstall fVMInstance) {
/* 672 */     String version = null;
/* 673 */     if (fVMInstance instanceof IVMInstall2) {
/* 674 */       version = ((IVMInstall2)fVMInstance).getJavaVersion();
/*     */     } else {
/* 676 */       LibraryInfo libInfo = LaunchingPlugin.getLibraryInfo(fVMInstance.getInstallLocation().getAbsolutePath());
/* 677 */       if (libInfo == null) {
/* 678 */         return 0.0D;
/*     */       }
/* 680 */       version = libInfo.getVersion();
/*     */     } 
/* 682 */     if (version == null)
/*     */     {
/* 684 */       return 0.0D;
/*     */     }
/* 686 */     int index = version.indexOf(".");
/* 687 */     int nextIndex = version.indexOf(".", index + 1);
/*     */     try {
/* 689 */       if (index > 0 && nextIndex > index) {
/* 690 */         return Double.parseDouble(version.substring(0, nextIndex));
/*     */       }
/* 692 */       return Double.parseDouble(version);
/* 693 */     } catch (NumberFormatException numberFormatException) {
/* 694 */       return 0.0D;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.jdt.launching-3.20.0.jar!\org\eclipse\jdt\internal\launching\StandardVMRunner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */