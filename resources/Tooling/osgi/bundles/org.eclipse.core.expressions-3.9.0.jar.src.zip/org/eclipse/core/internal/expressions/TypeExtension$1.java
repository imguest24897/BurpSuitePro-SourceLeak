/*    */ package org.eclipse.core.internal.expressions;
/*    */ 
/*    */ import org.eclipse.core.expressions.IPropertyTester;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements IPropertyTester
/*    */ {
/*    */   public boolean handles(String namespace, String method) {
/* 30 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isInstantiated() {
/* 34 */     return true;
/*    */   }
/*    */   
/*    */   public boolean isDeclaringPluginActive() {
/* 38 */     return true;
/*    */   }
/*    */   
/*    */   public IPropertyTester instantiate() {
/* 42 */     return this;
/*    */   }
/*    */   
/*    */   public boolean test(Object receiver, String method, Object[] args, Object expectedValue) {
/* 46 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\TypeExtension$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */