/*     */ package org.eclipse.core.internal.expressions;
/*     */ 
/*     */ import org.eclipse.core.expressions.AndExpression;
/*     */ import org.eclipse.core.expressions.CompositeExpression;
/*     */ import org.eclipse.core.expressions.CountExpression;
/*     */ import org.eclipse.core.expressions.ElementHandler;
/*     */ import org.eclipse.core.expressions.EqualsExpression;
/*     */ import org.eclipse.core.expressions.Expression;
/*     */ import org.eclipse.core.expressions.ExpressionConverter;
/*     */ import org.eclipse.core.expressions.OrExpression;
/*     */ import org.eclipse.core.expressions.ReferenceExpression;
/*     */ import org.eclipse.core.expressions.TestExpression;
/*     */ import org.eclipse.core.expressions.WithExpression;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardElementHandler
/*     */   extends ElementHandler
/*     */ {
/*     */   public Expression create(ExpressionConverter converter, IConfigurationElement element) throws CoreException {
/*     */     OrExpression orExpression;
/*     */     AndExpression andExpression;
/*     */     WithExpression withExpression;
/*     */     AdaptExpression adaptExpression;
/*     */     ResolveExpression resolveExpression;
/*     */     EnablementExpression enablementExpression;
/*     */     IterateExpression result;
/*  38 */     String name = element.getName();
/*  39 */     if (name == null) {
/*  40 */       return null;
/*     */     }
/*     */     String str1;
/*  43 */     switch ((str1 = name).hashCode()) { case -1295482945: if (!str1.equals("equals")) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  97 */         return (Expression)new EqualsExpression(element);
/*     */       case -925155509: if (!str1.equals("reference"))
/*  99 */           break;  return (Expression)new ReferenceExpression(element);case 3555: if (!str1.equals("or")) break;  orExpression = new OrExpression(); processChildren(converter, element, (CompositeExpression)orExpression); return (Expression)orExpression;case 96727: if (!str1.equals("and")) break;  andExpression = new AndExpression(); processChildren(converter, element, (CompositeExpression)andExpression); return (Expression)andExpression;case 109267: if (!str1.equals("not")) break;  return new NotExpression(converter.perform(element.getChildren()[0]));case 3556498: if (!str1.equals("test")) break;  return (Expression)new TestExpression(element);case 3649734: if (!str1.equals("with")) break;  withExpression = new WithExpression(element); processChildren(converter, element, (CompositeExpression)withExpression); return (Expression)withExpression;case 92657442: if (!str1.equals("adapt")) break;  adaptExpression = new AdaptExpression(element); processChildren(converter, element, adaptExpression); return (Expression)adaptExpression;case 94851343: if (!str1.equals("count")) break;  return (Expression)new CountExpression(element);case 642874209: if (!str1.equals("systemTest")) break;  return new SystemTestExpression(element);case 902025516: if (!str1.equals("instanceof"))
/*     */           break;  return new InstanceofExpression(element);case 1097368044: if (!str1.equals("resolve"))
/*     */           break;  resolveExpression = new ResolveExpression(element); processChildren(converter, element, resolveExpression); return (Expression)resolveExpression;case 1893974369: if (!str1.equals("enablement"))
/*     */           break;  enablementExpression = new EnablementExpression(element); processChildren(converter, element, enablementExpression); return (Expression)enablementExpression;case 2116356218: if (!str1.equals("iterate"))
/* 103 */           break;  result = new IterateExpression(element); processChildren(converter, element, result); return (Expression)result; }  return null; } public Expression create(ExpressionConverter converter, Element element) throws CoreException { OrExpression orExpression; AndExpression result; Node child; WithExpression withExpression;
/*     */     AdaptExpression adaptExpression;
/*     */     ResolveExpression resolveExpression;
/*     */     EnablementExpression enablementExpression;
/*     */     IterateExpression iterateExpression;
/* 108 */     String name = element.getNodeName();
/* 109 */     if (name == null) {
/* 110 */       return null;
/*     */     }
/*     */     String str1;
/* 113 */     switch ((str1 = name).hashCode()) { case -1295482945: if (!str1.equals("equals")) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 174 */         return (Expression)new EqualsExpression(element);
/*     */       case -925155509: if (!str1.equals("reference"))
/* 176 */           break;  return (Expression)new ReferenceExpression(element);case 3555: if (!str1.equals("or")) break;  orExpression = new OrExpression(); processChildren(converter, element, (CompositeExpression)orExpression); return (Expression)orExpression;case 96727: if (!str1.equals("and")) break;  result = new AndExpression(); processChildren(converter, element, (CompositeExpression)result); return (Expression)result;case 109267: if (!str1.equals("not")) break;  child = element.getFirstChild(); while (child != null) { if (child.getNodeType() == 1) return new NotExpression(converter.perform((Element)child));  child = child.getNextSibling(); }  break;case 3556498: if (!str1.equals("test")) break;  return (Expression)new TestExpression(element);case 3649734: if (!str1.equals("with")) break;  withExpression = new WithExpression(element); processChildren(converter, element, (CompositeExpression)withExpression); return (Expression)withExpression;case 92657442: if (!str1.equals("adapt")) break;  adaptExpression = new AdaptExpression(element); processChildren(converter, element, adaptExpression); return (Expression)adaptExpression;case 94851343: if (!str1.equals("count")) break;  return (Expression)new CountExpression(element);case 642874209: if (!str1.equals("systemTest")) break;  return new SystemTestExpression(element);case 902025516: if (!str1.equals("instanceof"))
/*     */           break;  return new InstanceofExpression(element);case 1097368044: if (!str1.equals("resolve"))
/*     */           break;  resolveExpression = new ResolveExpression(element); processChildren(converter, element, resolveExpression); return (Expression)resolveExpression;case 1893974369: if (!str1.equals("enablement"))
/*     */           break;  enablementExpression = new EnablementExpression(element); processChildren(converter, element, enablementExpression); return (Expression)enablementExpression;case 2116356218: if (!str1.equals("iterate"))
/* 180 */           break;  iterateExpression = new IterateExpression(element); processChildren(converter, element, iterateExpression); return (Expression)iterateExpression; }  return null; }
/*     */ 
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\StandardElementHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */