/*    */ package org.eclipse.core.expressions;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CompositeExpression
/*    */   extends Expression
/*    */ {
/* 28 */   private static final Expression[] EMPTY_ARRAY = new Expression[0];
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 33 */   private static final int HASH_INITIAL = CompositeExpression.class.getName().hashCode();
/*    */   
/*    */   protected List<Expression> fExpressions;
/*    */   
/*    */   public void add(Expression expression) {
/* 38 */     if (this.fExpressions == null)
/* 39 */       this.fExpressions = new ArrayList<>(2); 
/* 40 */     this.fExpressions.add(expression);
/*    */   }
/*    */   
/*    */   public Expression[] getChildren() {
/* 44 */     if (this.fExpressions == null)
/* 45 */       return EMPTY_ARRAY; 
/* 46 */     return this.fExpressions.<Expression>toArray(new Expression[this.fExpressions.size()]);
/*    */   }
/*    */   
/*    */   protected EvaluationResult evaluateAnd(IEvaluationContext scope) throws CoreException {
/* 50 */     if (this.fExpressions == null)
/* 51 */       return EvaluationResult.TRUE; 
/* 52 */     EvaluationResult result = EvaluationResult.TRUE;
/* 53 */     for (Expression expression : this.fExpressions) {
/* 54 */       result = result.and(expression.evaluate(scope));
/*    */ 
/*    */       
/* 57 */       if (result == EvaluationResult.FALSE)
/* 58 */         return result; 
/*    */     } 
/* 60 */     return result;
/*    */   }
/*    */   
/*    */   protected EvaluationResult evaluateOr(IEvaluationContext scope) throws CoreException {
/* 64 */     if (this.fExpressions == null)
/* 65 */       return EvaluationResult.TRUE; 
/* 66 */     EvaluationResult result = EvaluationResult.FALSE;
/* 67 */     for (Expression expression : this.fExpressions) {
/* 68 */       result = result.or(expression.evaluate(scope));
/* 69 */       if (result == EvaluationResult.TRUE)
/* 70 */         return result; 
/*    */     } 
/* 72 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public void collectExpressionInfo(ExpressionInfo info) {
/* 77 */     if (this.fExpressions == null)
/*    */       return; 
/* 79 */     for (Expression expression : this.fExpressions) {
/* 80 */       expression.collectExpressionInfo(info);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   protected int computeHashCode() {
/* 86 */     return HASH_INITIAL * 89 + hashCode(this.fExpressions);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 91 */     StringBuilder builder = new StringBuilder(getClass().getSimpleName());
/* 92 */     Expression[] children = getChildren();
/* 93 */     if (children.length > 0) {
/* 94 */       builder.append(" [children=");
/* 95 */       builder.append(Arrays.toString((Object[])children));
/* 96 */       builder.append("]");
/*    */     } 
/* 98 */     return builder.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\CompositeExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */