/*    */ package org.eclipse.core.internal.expressions;
/*    */ 
/*    */ import org.eclipse.core.internal.expressions.util.LRUCache;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PropertyCache
/*    */ {
/*    */   private LRUCache fCache;
/*    */   
/*    */   public PropertyCache(int cacheSize) {
/* 23 */     this.fCache = new LRUCache(100);
/* 24 */     this.fCache.setSpaceLimit(cacheSize);
/*    */   }
/*    */   
/*    */   public Property get(Property key) {
/* 28 */     return (Property)this.fCache.get(key);
/*    */   }
/*    */   
/*    */   public void put(Property method) {
/* 32 */     this.fCache.put(method, method);
/*    */   }
/*    */   
/*    */   public void remove(Property method) {
/* 36 */     this.fCache.removeKey(method);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\PropertyCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */