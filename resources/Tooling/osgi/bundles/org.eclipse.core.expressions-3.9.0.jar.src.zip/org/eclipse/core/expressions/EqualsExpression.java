/*    */ package org.eclipse.core.expressions;
/*    */ 
/*    */ import org.eclipse.core.internal.expressions.Expressions;
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EqualsExpression
/*    */   extends Expression
/*    */ {
/* 31 */   private static final int HASH_INITIAL = EqualsExpression.class.getName().hashCode();
/*    */   
/*    */   private Object fExpectedValue;
/*    */   
/*    */   public EqualsExpression(Object expectedValue) {
/* 36 */     Assert.isNotNull(expectedValue);
/* 37 */     this.fExpectedValue = expectedValue;
/*    */   }
/*    */   
/*    */   public EqualsExpression(IConfigurationElement element) throws CoreException {
/* 41 */     String value = element.getAttribute("value");
/* 42 */     Expressions.checkAttribute("value", value);
/* 43 */     this.fExpectedValue = Expressions.convertArgument(value);
/*    */   }
/*    */   
/*    */   public EqualsExpression(Element element) throws CoreException {
/* 47 */     String value = element.getAttribute("value");
/* 48 */     Expressions.checkAttribute("value", value.isEmpty() ? null : value);
/* 49 */     this.fExpectedValue = Expressions.convertArgument(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public EvaluationResult evaluate(IEvaluationContext context) throws CoreException {
/* 54 */     Object element = context.getDefaultVariable();
/* 55 */     return EvaluationResult.valueOf(element.equals(this.fExpectedValue));
/*    */   }
/*    */ 
/*    */   
/*    */   public void collectExpressionInfo(ExpressionInfo info) {
/* 60 */     info.markDefaultVariableAccessed();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object object) {
/* 65 */     if (!(object instanceof EqualsExpression)) {
/* 66 */       return false;
/*    */     }
/* 68 */     EqualsExpression that = (EqualsExpression)object;
/* 69 */     return this.fExpectedValue.equals(that.fExpectedValue);
/*    */   }
/*    */ 
/*    */   
/*    */   protected int computeHashCode() {
/* 74 */     return HASH_INITIAL * 89 + this.fExpectedValue.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 79 */     StringBuilder builder = new StringBuilder(getClass().getSimpleName());
/* 80 */     builder.append(" [expected=");
/* 81 */     builder.append(this.fExpectedValue);
/* 82 */     builder.append("]");
/* 83 */     return builder.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\EqualsExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */