/*    */ package org.eclipse.core.internal.expressions;
/*    */ 
/*    */ import org.eclipse.core.expressions.CompositeExpression;
/*    */ import org.eclipse.core.expressions.EvaluationResult;
/*    */ import org.eclipse.core.expressions.IEvaluationContext;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnablementExpression
/*    */   extends CompositeExpression
/*    */ {
/*    */   public EnablementExpression(IConfigurationElement configElement) {}
/*    */   
/*    */   public EnablementExpression(Element element) {}
/*    */   
/*    */   public boolean equals(Object object) {
/* 47 */     if (!(object instanceof EnablementExpression)) {
/* 48 */       return false;
/*    */     }
/* 50 */     EnablementExpression that = (EnablementExpression)object;
/* 51 */     return equals(this.fExpressions, that.fExpressions);
/*    */   }
/*    */ 
/*    */   
/*    */   public EvaluationResult evaluate(IEvaluationContext context) throws CoreException {
/* 56 */     long start = 0L;
/* 57 */     if (Expressions.TRACING)
/* 58 */       start = System.currentTimeMillis(); 
/* 59 */     EvaluationResult result = evaluateAnd(context);
/* 60 */     if (Expressions.TRACING) {
/* 61 */       System.out.println("[Enablement Expression] - evaluation time: " + (
/* 62 */           System.currentTimeMillis() - start) + " ms.");
/*    */     }
/* 64 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\EnablementExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */