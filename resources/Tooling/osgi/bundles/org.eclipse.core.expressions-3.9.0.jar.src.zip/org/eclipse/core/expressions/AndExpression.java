/*    */ package org.eclipse.core.expressions;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AndExpression
/*    */   extends CompositeExpression
/*    */ {
/*    */   public boolean equals(Object object) {
/* 27 */     if (!(object instanceof AndExpression)) {
/* 28 */       return false;
/*    */     }
/* 30 */     AndExpression that = (AndExpression)object;
/* 31 */     return equals(this.fExpressions, that.fExpressions);
/*    */   }
/*    */ 
/*    */   
/*    */   public EvaluationResult evaluate(IEvaluationContext context) throws CoreException {
/* 36 */     return evaluateAnd(context);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\AndExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */