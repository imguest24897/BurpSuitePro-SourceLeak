/*    */ package org.eclipse.core.internal.expressions;
/*    */ 
/*    */ import org.eclipse.core.expressions.IEvaluationContext;
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DefaultVariable
/*    */   implements IEvaluationContext
/*    */ {
/*    */   private Object fDefaultVariable;
/*    */   private IEvaluationContext fParent;
/*    */   private IEvaluationContext fManagedPool;
/*    */   
/*    */   public DefaultVariable(IEvaluationContext parent, Object defaultVariable) {
/* 41 */     Assert.isNotNull(parent);
/* 42 */     Assert.isNotNull(defaultVariable);
/* 43 */     this.fParent = parent;
/* 44 */     while (parent instanceof DefaultVariable) {
/* 45 */       parent = parent.getParent();
/*    */     }
/* 47 */     this.fManagedPool = parent;
/* 48 */     this.fDefaultVariable = defaultVariable;
/*    */   }
/*    */ 
/*    */   
/*    */   public IEvaluationContext getParent() {
/* 53 */     return this.fParent;
/*    */   }
/*    */ 
/*    */   
/*    */   public IEvaluationContext getRoot() {
/* 58 */     return this.fParent.getRoot();
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getDefaultVariable() {
/* 63 */     return this.fDefaultVariable;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setAllowPluginActivation(boolean value) {
/* 68 */     this.fParent.setAllowPluginActivation(value);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean getAllowPluginActivation() {
/* 73 */     return this.fParent.getAllowPluginActivation();
/*    */   }
/*    */ 
/*    */   
/*    */   public void addVariable(String name, Object value) {
/* 78 */     this.fManagedPool.addVariable(name, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object removeVariable(String name) {
/* 83 */     return this.fManagedPool.removeVariable(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getVariable(String name) {
/* 88 */     return this.fManagedPool.getVariable(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object resolveVariable(String name, Object[] args) throws CoreException {
/* 93 */     return this.fManagedPool.resolveVariable(name, args);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\DefaultVariable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */