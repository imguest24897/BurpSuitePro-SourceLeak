/*     */ package org.eclipse.core.expressions;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.core.internal.expressions.ExpressionMessages;
/*     */ import org.eclipse.core.internal.expressions.ExpressionStatus;
/*     */ import org.eclipse.core.internal.expressions.Expressions;
/*     */ import org.eclipse.core.internal.expressions.Messages;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WithExpression
/*     */   extends CompositeExpression
/*     */ {
/*     */   private String fVariable;
/*     */   private static final String ATT_VARIABLE = "variable";
/*  41 */   private static final int HASH_INITIAL = WithExpression.class.getName().hashCode();
/*     */   
/*     */   public WithExpression(IConfigurationElement configElement) throws CoreException {
/*  44 */     this.fVariable = configElement.getAttribute("variable");
/*  45 */     Expressions.checkAttribute("variable", this.fVariable);
/*     */   }
/*     */   
/*     */   public WithExpression(Element element) throws CoreException {
/*  49 */     this.fVariable = element.getAttribute("variable");
/*  50 */     Expressions.checkAttribute("variable", this.fVariable.isEmpty() ? null : this.fVariable);
/*     */   }
/*     */   
/*     */   public WithExpression(String variable) {
/*  54 */     Assert.isNotNull(variable);
/*  55 */     this.fVariable = variable;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/*  60 */     if (!(object instanceof WithExpression)) {
/*  61 */       return false;
/*     */     }
/*  63 */     WithExpression that = (WithExpression)object;
/*  64 */     return (this.fVariable.equals(that.fVariable) && equals(this.fExpressions, that.fExpressions));
/*     */   }
/*     */ 
/*     */   
/*     */   protected int computeHashCode() {
/*  69 */     return HASH_INITIAL * 89 + hashCode(this.fExpressions) * 
/*  70 */       89 + this.fVariable.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public EvaluationResult evaluate(IEvaluationContext context) throws CoreException {
/*  75 */     Object variable = context.getVariable(this.fVariable);
/*  76 */     if (variable == null) {
/*  77 */       throw new CoreException(new ExpressionStatus(
/*  78 */             301, 
/*  79 */             Messages.format(ExpressionMessages.WithExpression_variable_not_defined, this.fVariable)));
/*     */     }
/*  81 */     if (variable == IEvaluationContext.UNDEFINED_VARIABLE) {
/*  82 */       return EvaluationResult.FALSE;
/*     */     }
/*  84 */     return evaluateAnd(new EvaluationContext(context, variable));
/*     */   }
/*     */ 
/*     */   
/*     */   public void collectExpressionInfo(ExpressionInfo info) {
/*  89 */     ExpressionInfo other = new ExpressionInfo();
/*  90 */     super.collectExpressionInfo(other);
/*  91 */     if (other.hasDefaultVariableAccess()) {
/*  92 */       info.addVariableNameAccess(this.fVariable);
/*     */     }
/*  94 */     info.mergeExceptDefaultVariable(other);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  99 */     StringBuilder builder = new StringBuilder(getClass().getSimpleName());
/* 100 */     builder.append(" [variable=").append(this.fVariable);
/* 101 */     Expression[] children = getChildren();
/* 102 */     if (children.length > 0) {
/* 103 */       builder.append(", children=");
/* 104 */       builder.append(Arrays.toString((Object[])children));
/*     */     } 
/* 106 */     builder.append("]");
/* 107 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\WithExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */