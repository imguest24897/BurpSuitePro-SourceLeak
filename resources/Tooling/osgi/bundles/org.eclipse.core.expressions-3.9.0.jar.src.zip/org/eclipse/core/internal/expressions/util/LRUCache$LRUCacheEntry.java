/*    */ package org.eclipse.core.internal.expressions.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LRUCacheEntry
/*    */ {
/*    */   public Object _fKey;
/*    */   public Object _fValue;
/*    */   public int _fTimestamp;
/*    */   public int _fSpace;
/*    */   public LRUCacheEntry _fPrevious;
/*    */   public LRUCacheEntry _fNext;
/*    */   
/*    */   public LRUCacheEntry(Object key, Object value, int space) {
/* 73 */     this._fKey = key;
/* 74 */     this._fValue = value;
/* 75 */     this._fSpace = space;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 85 */     return "LRUCacheEntry [" + this._fKey + "-->" + this._fValue + "]";
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expression\\util\LRUCache$LRUCacheEntry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */