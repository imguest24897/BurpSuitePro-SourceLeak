/*     */ package org.eclipse.core.expressions;
/*     */ 
/*     */ import org.eclipse.core.internal.expressions.ExpressionMessages;
/*     */ import org.eclipse.core.internal.expressions.ExpressionStatus;
/*     */ import org.eclipse.core.internal.expressions.Expressions;
/*     */ import org.eclipse.core.internal.expressions.Property;
/*     */ import org.eclipse.core.internal.expressions.TypeExtensionManager;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestExpression
/*     */   extends Expression
/*     */ {
/*     */   private String fNamespace;
/*     */   private String fProperty;
/*     */   private Object[] fArgs;
/*     */   private Object fExpectedValue;
/*     */   private boolean fForcePluginActivation;
/*     */   private static final char PROP_SEP = '.';
/*     */   private static final String ATT_PROPERTY = "property";
/*     */   private static final String ATT_ARGS = "args";
/*     */   private static final String ATT_FORCE_PLUGIN_ACTIVATION = "forcePluginActivation";
/*  46 */   private static final int HASH_INITIAL = TestExpression.class.getName().hashCode();
/*     */   
/*  48 */   private static final TypeExtensionManager fgTypeExtensionManager = new TypeExtensionManager("propertyTesters");
/*     */   
/*     */   public TestExpression(IConfigurationElement element) throws CoreException {
/*  51 */     String property = element.getAttribute("property");
/*  52 */     int pos = property.lastIndexOf('.');
/*  53 */     if (pos == -1) {
/*  54 */       throw new CoreException(new ExpressionStatus(
/*  55 */             300, 
/*  56 */             ExpressionMessages.TestExpression_no_name_space));
/*     */     }
/*  58 */     this.fNamespace = property.substring(0, pos);
/*  59 */     this.fProperty = property.substring(pos + 1);
/*  60 */     this.fArgs = Expressions.getArguments(element, "args");
/*  61 */     this.fExpectedValue = Expressions.convertArgument(element.getAttribute("value"));
/*  62 */     this.fForcePluginActivation = Expressions.getOptionalBooleanAttribute(element, "forcePluginActivation");
/*     */   }
/*     */   
/*     */   public TestExpression(Element element) throws CoreException {
/*  66 */     String property = element.getAttribute("property");
/*  67 */     int pos = property.lastIndexOf('.');
/*  68 */     if (pos == -1) {
/*  69 */       throw new CoreException(new ExpressionStatus(
/*  70 */             300, 
/*  71 */             ExpressionMessages.TestExpression_no_name_space));
/*     */     }
/*  73 */     this.fNamespace = property.substring(0, pos);
/*  74 */     this.fProperty = property.substring(pos + 1);
/*  75 */     this.fArgs = Expressions.getArguments(element, "args");
/*  76 */     String value = element.getAttribute("value");
/*  77 */     this.fExpectedValue = Expressions.convertArgument(value.isEmpty() ? null : value);
/*  78 */     this.fForcePluginActivation = Expressions.getOptionalBooleanAttribute(element, "forcePluginActivation");
/*     */   }
/*     */   
/*     */   public TestExpression(String namespace, String property, Object[] args, Object expectedValue) {
/*  82 */     this(namespace, property, args, expectedValue, false);
/*     */   }
/*     */   
/*     */   public TestExpression(String namespace, String property, Object[] args, Object expectedValue, boolean forcePluginActivation) {
/*  86 */     Assert.isNotNull(namespace);
/*  87 */     Assert.isNotNull(property);
/*  88 */     this.fNamespace = namespace;
/*  89 */     this.fProperty = property;
/*  90 */     this.fArgs = (args != null) ? args : Expressions.EMPTY_ARGS;
/*  91 */     this.fExpectedValue = expectedValue;
/*  92 */     this.fForcePluginActivation = forcePluginActivation;
/*     */   }
/*     */ 
/*     */   
/*     */   public EvaluationResult evaluate(IEvaluationContext context) throws CoreException {
/*  97 */     Object element = context.getDefaultVariable();
/*  98 */     if (System.class.equals(element)) {
/*  99 */       String str = System.getProperty(this.fProperty);
/* 100 */       if (str == null)
/* 101 */         return EvaluationResult.FALSE; 
/* 102 */       return EvaluationResult.valueOf(str.equals(this.fArgs[0]));
/*     */     } 
/* 104 */     Property property = fgTypeExtensionManager.getProperty(element, this.fNamespace, this.fProperty, (context.getAllowPluginActivation() && this.fForcePluginActivation));
/* 105 */     if (!property.isInstantiated())
/* 106 */       return EvaluationResult.NOT_LOADED; 
/* 107 */     return EvaluationResult.valueOf(property.test(element, this.fArgs, this.fExpectedValue));
/*     */   }
/*     */ 
/*     */   
/*     */   public void collectExpressionInfo(ExpressionInfo info) {
/* 112 */     info.markDefaultVariableAccessed();
/* 113 */     info.addAccessedPropertyName(String.valueOf(this.fNamespace) + '.' + this.fProperty);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 118 */     if (!(object instanceof TestExpression)) {
/* 119 */       return false;
/*     */     }
/* 121 */     TestExpression that = (TestExpression)object;
/* 122 */     return (this.fNamespace.equals(that.fNamespace) && this.fProperty.equals(that.fProperty) && 
/* 123 */       this.fForcePluginActivation == that.fForcePluginActivation && 
/* 124 */       equals(this.fArgs, that.fArgs) && equals(this.fExpectedValue, that.fExpectedValue));
/*     */   }
/*     */ 
/*     */   
/*     */   protected int computeHashCode() {
/* 129 */     return HASH_INITIAL * 89 + hashCode(this.fArgs) * 
/* 130 */       89 + hashCode(this.fExpectedValue) * 
/* 131 */       89 + this.fNamespace.hashCode() * 
/* 132 */       89 + this.fProperty.hashCode() * 
/* 133 */       89 + (this.fForcePluginActivation ? 1 : 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 140 */     StringBuilder args = new StringBuilder();
/* 141 */     for (int i = 0; i < this.fArgs.length; i++) {
/* 142 */       Object arg = this.fArgs[i];
/* 143 */       if (arg instanceof String) {
/* 144 */         args.append('\'');
/* 145 */         args.append(arg);
/* 146 */         args.append('\'');
/*     */       } else {
/* 148 */         args.append(arg.toString());
/*     */       } 
/* 150 */       if (i < this.fArgs.length - 1)
/* 151 */         args.append(", "); 
/*     */     } 
/* 153 */     return "<test property=\"" + this.fProperty + "\"" + (
/* 154 */       (this.fArgs.length != 0) ? (" args=\"" + args + "\"") : "") + (
/* 155 */       (this.fExpectedValue != null) ? (" value=\"" + this.fExpectedValue + "\"") : "") + 
/* 156 */       " plug-in activation: " + (this.fForcePluginActivation ? "eager" : "lazy") + 
/* 157 */       "/>";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean testGetForcePluginActivation() {
/* 163 */     return this.fForcePluginActivation;
/*     */   }
/*     */   
/*     */   public static TypeExtensionManager testGetTypeExtensionManager() {
/* 167 */     return fgTypeExtensionManager;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\TestExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */