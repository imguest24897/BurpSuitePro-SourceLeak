/*     */ package org.eclipse.core.internal.expressions;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ import org.eclipse.core.expressions.Expression;
/*     */ import org.eclipse.core.expressions.ICountable;
/*     */ import org.eclipse.core.expressions.IIterable;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IAdapterManager;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.osgi.framework.BundleContext;
/*     */ import org.osgi.framework.BundleEvent;
/*     */ import org.osgi.framework.BundleListener;
/*     */ import org.osgi.framework.FrameworkUtil;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Expressions
/*     */ {
/*     */   private static WeakHashMap<Class<?>, Map<String, Boolean>> fgKnownClasses;
/*     */   private static WeakHashMap<ClassLoader, Set<String>> fgNotFoundClasses;
/*  59 */   public static final boolean TRACING = "true".equalsIgnoreCase(Platform.getDebugOption("org.eclipse.core.expressions/tracePropertyResolving"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInstanceOf(Object element, String type) {
/*  68 */     if (element == null)
/*  69 */       return false; 
/*  70 */     return isSubtype(element.getClass(), type);
/*     */   }
/*     */   
/*     */   private static synchronized boolean isSubtype(Class<?> clazz, String type) {
/*  74 */     WeakHashMap<Class<?>, Map<String, Boolean>> knownClassesMap = getKnownClasses();
/*  75 */     Map<String, Boolean> nameMap = knownClassesMap.get(clazz);
/*  76 */     if (nameMap != null) {
/*  77 */       Object obj = nameMap.get(type);
/*  78 */       if (obj != null)
/*  79 */         return ((Boolean)obj).booleanValue(); 
/*     */     } 
/*  81 */     if (nameMap == null) {
/*  82 */       nameMap = new HashMap<>();
/*  83 */       knownClassesMap.put(clazz, nameMap);
/*     */     } 
/*  85 */     boolean isSubtype = uncachedIsSubtype(clazz, type);
/*  86 */     nameMap.put(type, isSubtype ? Boolean.TRUE : Boolean.FALSE);
/*  87 */     return isSubtype;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Class<?> loadClass(ClassLoader classLoader, String className) {
/*     */     WeakHashMap<ClassLoader, Set<String>> cache;
/* 104 */     synchronized (Expressions.class) {
/* 105 */       cache = getNotFoundClasses();
/* 106 */       Set<String> classNames = cache.get(classLoader);
/* 107 */       if (classNames != null && classNames.contains(className)) {
/* 108 */         return null;
/*     */       }
/*     */     } 
/*     */     
/*     */     try {
/* 113 */       return Class.forName(className, false, classLoader);
/* 114 */     } catch (ClassNotFoundException classNotFoundException) {
/* 115 */       synchronized (Expressions.class) {
/* 116 */         Set<String> classNames = cache.get(classLoader);
/* 117 */         if (classNames == null) {
/* 118 */           classNames = new HashSet<>();
/* 119 */           cache.put(classLoader, classNames);
/*     */         } 
/* 121 */         classNames.add(className);
/*     */       } 
/*     */       
/* 124 */       return null;
/*     */     } 
/*     */   }
/*     */   private static WeakHashMap<Class<?>, Map<String, Boolean>> getKnownClasses() {
/* 128 */     createClassCaches();
/* 129 */     return fgKnownClasses;
/*     */   }
/*     */   
/*     */   private static WeakHashMap<ClassLoader, Set<String>> getNotFoundClasses() {
/* 133 */     createClassCaches();
/* 134 */     return fgNotFoundClasses;
/*     */   }
/*     */   
/*     */   private static void createClassCaches() {
/* 138 */     if (fgKnownClasses == null) {
/* 139 */       fgKnownClasses = new WeakHashMap<>();
/* 140 */       fgNotFoundClasses = new WeakHashMap<>();
/* 141 */       BundleContext bundleContext = FrameworkUtil.getBundle(Expressions.class).getBundleContext();
/* 142 */       BundleListener listener = event -> {
/*     */           if (event.getType() == 4) {
/*     */             synchronized (Expressions.class) {
/*     */               fgKnownClasses.clear();
/*     */               
/*     */               fgNotFoundClasses.clear();
/*     */             } 
/*     */           }
/*     */         };
/* 151 */       bundleContext.addBundleListener(listener);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean uncachedIsSubtype(Class<?> clazz, String type) {
/* 156 */     if (clazz.getName().equals(type))
/* 157 */       return true; 
/* 158 */     Class<?> superClass = clazz.getSuperclass();
/* 159 */     if (superClass != null && uncachedIsSubtype(superClass, type))
/* 160 */       return true; 
/* 161 */     Class[] interfaces = clazz.getInterfaces(); byte b; int i; Class[] arrayOfClass1;
/* 162 */     for (i = (arrayOfClass1 = interfaces).length, b = 0; b < i; ) { Class<?> interfaze = arrayOfClass1[b];
/* 163 */       if (uncachedIsSubtype(interfaze, type))
/* 164 */         return true;  b++; }
/*     */     
/* 166 */     return false;
/*     */   }
/*     */   
/*     */   public static void checkAttribute(String name, String value) throws CoreException {
/* 170 */     if (value == null) {
/* 171 */       throw new CoreException(new ExpressionStatus(
/* 172 */             50, 
/* 173 */             Messages.format(ExpressionMessages.Expression_attribute_missing, name)));
/*     */     }
/*     */   }
/*     */   
/*     */   public static void checkAttribute(String name, String value, String[] validValues) throws CoreException {
/* 178 */     checkAttribute(name, value); byte b; int i; String[] arrayOfString;
/* 179 */     for (i = (arrayOfString = validValues).length, b = 0; b < i; ) { String validValue = arrayOfString[b];
/* 180 */       if (value.equals(validValue))
/*     */         return;  b++; }
/*     */     
/* 183 */     throw new CoreException(new ExpressionStatus(
/* 184 */           51, 
/* 185 */           Messages.format(ExpressionMessages.Expression_attribute_invalid_value, value)));
/*     */   }
/*     */   
/*     */   public static void checkCollection(Object var, Expression expression) throws CoreException {
/* 189 */     if (var instanceof java.util.Collection)
/*     */       return; 
/* 191 */     throw new CoreException(new ExpressionStatus(
/* 192 */           3, 
/* 193 */           Messages.format(ExpressionMessages.Expression_variable_not_a_collection, expression.toString())));
/*     */   }
/*     */   
/*     */   public static void checkList(Object var, Expression expression) throws CoreException {
/* 197 */     if (var instanceof List)
/*     */       return; 
/* 199 */     throw new CoreException(new ExpressionStatus(
/* 200 */           4, 
/* 201 */           Messages.format(ExpressionMessages.Expression_variable_not_a_list, expression.toString())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IIterable<?> getAsIIterable(Object var, Expression expression) throws CoreException {
/* 216 */     if (var instanceof IIterable) {
/* 217 */       return (IIterable)var;
/*     */     }
/* 219 */     IAdapterManager manager = Platform.getAdapterManager();
/* 220 */     IIterable<?> result = (IIterable)manager.getAdapter(var, IIterable.class);
/* 221 */     if (result != null) {
/* 222 */       return result;
/*     */     }
/* 224 */     if (manager.queryAdapter(var, IIterable.class.getName()) == 1) {
/* 225 */       return null;
/*     */     }
/* 227 */     throw new CoreException(new ExpressionStatus(
/* 228 */           3, 
/* 229 */           Messages.format(ExpressionMessages.Expression_variable_not_iterable, expression.toString())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ICountable getAsICountable(Object var, Expression expression) throws CoreException {
/* 245 */     if (var instanceof ICountable) {
/* 246 */       return (ICountable)var;
/*     */     }
/* 248 */     IAdapterManager manager = Platform.getAdapterManager();
/* 249 */     ICountable result = (ICountable)manager.getAdapter(var, ICountable.class);
/* 250 */     if (result != null) {
/* 251 */       return result;
/*     */     }
/* 253 */     if (manager.queryAdapter(var, ICountable.class.getName()) == 1) {
/* 254 */       return null;
/*     */     }
/* 256 */     throw new CoreException(new ExpressionStatus(
/* 257 */           3, 
/* 258 */           Messages.format(ExpressionMessages.Expression_variable_not_countable, expression.toString())));
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean getOptionalBooleanAttribute(IConfigurationElement element, String attributeName) {
/* 263 */     String value = element.getAttribute(attributeName);
/* 264 */     if (value == null)
/* 265 */       return false; 
/* 266 */     return Boolean.parseBoolean(value);
/*     */   }
/*     */   
/*     */   public static boolean getOptionalBooleanAttribute(Element element, String attributeName) {
/* 270 */     String value = element.getAttribute(attributeName);
/* 271 */     if (value.isEmpty())
/* 272 */       return false; 
/* 273 */     return Boolean.parseBoolean(value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 278 */   public static final Object[] EMPTY_ARGS = new Object[0];
/*     */   
/*     */   public static Object[] getArguments(IConfigurationElement element, String attributeName) throws CoreException {
/* 281 */     String args = element.getAttribute(attributeName);
/* 282 */     if (args != null) {
/* 283 */       return parseArguments(args);
/*     */     }
/* 285 */     return EMPTY_ARGS;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object[] getArguments(Element element, String attributeName) throws CoreException {
/* 290 */     String args = element.getAttribute(attributeName);
/* 291 */     if (!args.isEmpty()) {
/* 292 */       return parseArguments(args);
/*     */     }
/* 294 */     return EMPTY_ARGS;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object[] parseArguments(String args) throws CoreException {
/* 299 */     List<Object> result = new ArrayList();
/* 300 */     int start = 0;
/*     */     int comma;
/* 302 */     while ((comma = findNextComma(args, start)) != -1) {
/* 303 */       result.add(convertArgument(args.substring(start, comma).trim()));
/* 304 */       start = comma + 1;
/*     */     } 
/* 306 */     result.add(convertArgument(args.substring(start).trim()));
/* 307 */     return result.toArray();
/*     */   }
/*     */   
/*     */   private static int findNextComma(String str, int start) throws CoreException {
/* 311 */     boolean inString = false;
/* 312 */     for (int i = start; i < str.length(); i++) {
/* 313 */       char ch = str.charAt(i);
/* 314 */       if (ch == ',' && !inString)
/* 315 */         return i; 
/* 316 */       if (ch == '\'') {
/* 317 */         if (!inString) {
/* 318 */           inString = true;
/* 319 */         } else if (i + 1 < str.length() && str.charAt(i + 1) == '\'') {
/* 320 */           i++;
/*     */         } else {
/* 322 */           inString = false;
/*     */         } 
/* 324 */       } else if (ch == ',' && !inString) {
/* 325 */         return i;
/*     */       } 
/*     */     } 
/* 328 */     if (inString) {
/* 329 */       throw new CoreException(new ExpressionStatus(
/* 330 */             303, 
/* 331 */             Messages.format(ExpressionMessages.Expression_string_not_terminated, str)));
/*     */     }
/* 333 */     return -1;
/*     */   }
/*     */   
/*     */   public static Object convertArgument(String arg) throws CoreException {
/* 337 */     if (arg == null)
/* 338 */       return null; 
/* 339 */     if (arg.isEmpty())
/* 340 */       return arg; 
/* 341 */     if (arg.charAt(0) == '\'' && arg.charAt(arg.length() - 1) == '\'')
/* 342 */       return unEscapeString(arg.substring(1, arg.length() - 1)); 
/* 343 */     if ("true".equals(arg))
/* 344 */       return Boolean.TRUE; 
/* 345 */     if ("false".equals(arg))
/* 346 */       return Boolean.FALSE; 
/* 347 */     if (arg.indexOf('.') != -1) {
/*     */       try {
/* 349 */         return Float.valueOf(arg);
/* 350 */       } catch (NumberFormatException numberFormatException) {
/* 351 */         return arg;
/*     */       } 
/*     */     }
/*     */     try {
/* 355 */       return Integer.valueOf(arg);
/* 356 */     } catch (NumberFormatException numberFormatException) {
/* 357 */       return arg;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String unEscapeString(String str) throws CoreException {
/* 363 */     StringBuilder result = new StringBuilder();
/* 364 */     for (int i = 0; i < str.length(); i++) {
/* 365 */       char ch = str.charAt(i);
/* 366 */       if (ch == '\'') {
/* 367 */         if (i == str.length() - 1 || str.charAt(i + 1) != '\'')
/* 368 */           throw new CoreException(new ExpressionStatus(
/* 369 */                 302, 
/* 370 */                 Messages.format(ExpressionMessages.Expression_string_not_correctly_escaped, str))); 
/* 371 */         result.append('\'');
/* 372 */         i++;
/*     */       } else {
/* 374 */         result.append(ch);
/*     */       } 
/*     */     } 
/* 377 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\Expressions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */