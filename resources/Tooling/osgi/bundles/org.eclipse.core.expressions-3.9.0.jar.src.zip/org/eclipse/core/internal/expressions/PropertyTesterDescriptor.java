/*     */ package org.eclipse.core.internal.expressions;
/*     */ 
/*     */ import org.eclipse.core.expressions.IPropertyTester;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.osgi.framework.Bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyTesterDescriptor
/*     */   implements IPropertyTester
/*     */ {
/*     */   private IConfigurationElement fConfigElement;
/*     */   private String fNamespace;
/*     */   private String fProperties;
/*     */   private static final String PROPERTIES = "properties";
/*     */   private static final String NAMESPACE = "namespace";
/*     */   private static final String CLASS = "class";
/*     */   
/*     */   public PropertyTesterDescriptor(IConfigurationElement element) throws CoreException {
/*  38 */     this.fConfigElement = element;
/*  39 */     this.fNamespace = this.fConfigElement.getAttribute("namespace");
/*  40 */     if (this.fNamespace == null) {
/*  41 */       throw new CoreException(new Status(4, PropertyTesterDescriptor.class, 
/*  42 */             4, 
/*  43 */             ExpressionMessages.PropertyTesterDescriptor_no_namespace, 
/*  44 */             null));
/*     */     }
/*  46 */     StringBuilder buffer = new StringBuilder(",");
/*  47 */     String properties = element.getAttribute("properties");
/*  48 */     if (properties == null) {
/*  49 */       throw new CoreException(new Status(4, PropertyTesterDescriptor.class, 
/*  50 */             4, 
/*  51 */             ExpressionMessages.PropertyTesterDescritpri_no_properties, 
/*  52 */             null));
/*     */     }
/*  54 */     for (int i = 0; i < properties.length(); i++) {
/*  55 */       char ch = properties.charAt(i);
/*  56 */       if (!Character.isWhitespace(ch))
/*  57 */         buffer.append(ch); 
/*     */     } 
/*  59 */     buffer.append(',');
/*  60 */     this.fProperties = buffer.toString();
/*     */   }
/*     */   
/*     */   public PropertyTesterDescriptor(IConfigurationElement element, String namespace, String properties) {
/*  64 */     this.fConfigElement = element;
/*  65 */     this.fNamespace = namespace;
/*  66 */     this.fProperties = properties;
/*     */   }
/*     */   
/*     */   public String getProperties() {
/*  70 */     return this.fProperties;
/*     */   }
/*     */   
/*     */   public String getNamespace() {
/*  74 */     return this.fNamespace;
/*     */   }
/*     */   
/*     */   public IConfigurationElement getConfigurationElement() {
/*  78 */     return this.fConfigElement;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean handles(String namespace, String property) {
/*  83 */     return (this.fNamespace.equals(namespace) && this.fProperties.contains("," + property + ","));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInstantiated() {
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDeclaringPluginActive() {
/*  93 */     Bundle fBundle = Platform.getBundle(this.fConfigElement.getContributor().getName());
/*  94 */     return (fBundle.getState() == 32);
/*     */   }
/*     */ 
/*     */   
/*     */   public IPropertyTester instantiate() throws CoreException {
/*  99 */     return (IPropertyTester)this.fConfigElement.createExecutableExtension("class");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean test(Object receiver, String method, Object[] args, Object expectedValue) {
/* 104 */     Assert.isTrue(false, "Method should never be called");
/* 105 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\PropertyTesterDescriptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */