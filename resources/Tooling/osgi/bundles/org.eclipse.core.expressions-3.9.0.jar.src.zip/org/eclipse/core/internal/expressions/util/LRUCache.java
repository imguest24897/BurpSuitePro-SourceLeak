/*     */ package org.eclipse.core.internal.expressions.util;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LRUCache
/*     */   implements Cloneable
/*     */ {
/*     */   protected int fCurrentSpace;
/*     */   protected int fSpaceLimit;
/*     */   protected int fTimestampCounter;
/*     */   protected Hashtable<Object, LRUCacheEntry> fEntryTable;
/*     */   protected LRUCacheEntry fEntryQueue;
/*     */   protected LRUCacheEntry fEntryQueueTail;
/*     */   protected static final int DEFAULT_SPACELIMIT = 100;
/*     */   
/*     */   protected static class LRUCacheEntry
/*     */   {
/*     */     public Object _fKey;
/*     */     public Object _fValue;
/*     */     public int _fTimestamp;
/*     */     public int _fSpace;
/*     */     public LRUCacheEntry _fPrevious;
/*     */     public LRUCacheEntry _fNext;
/*     */     
/*     */     public LRUCacheEntry(Object key, Object value, int space) {
/*  73 */       this._fKey = key;
/*  74 */       this._fValue = value;
/*  75 */       this._fSpace = space;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/*  85 */       return "LRUCacheEntry [" + this._fKey + "-->" + this._fValue + "]";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LRUCache() {
/* 129 */     this(100);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LRUCache(int size) {
/* 137 */     this.fTimestampCounter = this.fCurrentSpace = 0;
/* 138 */     this.fEntryQueue = this.fEntryQueueTail = null;
/* 139 */     this.fEntryTable = new Hashtable<>(size);
/* 140 */     this.fSpaceLimit = size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object clone() {
/* 150 */     LRUCache newCache = newInstance(this.fSpaceLimit);
/*     */ 
/*     */ 
/*     */     
/* 154 */     LRUCacheEntry qEntry = this.fEntryQueueTail;
/* 155 */     while (qEntry != null) {
/* 156 */       newCache.privateAdd(qEntry._fKey, qEntry._fValue, qEntry._fSpace);
/* 157 */       qEntry = qEntry._fPrevious;
/*     */     } 
/* 159 */     return newCache;
/*     */   }
/*     */   public double fillingRatio() {
/* 162 */     return this.fCurrentSpace * 100.0D / this.fSpaceLimit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {
/* 169 */     this.fCurrentSpace = 0;
/* 170 */     LRUCacheEntry entry = this.fEntryQueueTail;
/* 171 */     this.fEntryTable = new Hashtable<>();
/* 172 */     this.fEntryQueue = this.fEntryQueueTail = null;
/* 173 */     while (entry != null) {
/* 174 */       privateNotifyDeletionFromCache(entry);
/* 175 */       entry = entry._fPrevious;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush(Object key) {
/* 188 */     LRUCacheEntry entry = this.fEntryTable.get(key);
/*     */ 
/*     */     
/* 191 */     if (entry == null)
/*     */       return; 
/* 193 */     privateRemoveEntry(entry, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/* 204 */     LRUCacheEntry entry = this.fEntryTable.get(key);
/* 205 */     if (entry == null) {
/* 206 */       return null;
/*     */     }
/*     */     
/* 209 */     updateTimestamp(entry);
/* 210 */     return entry._fValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCurrentSpace() {
/* 217 */     return this.fCurrentSpace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSpaceLimit() {
/* 224 */     return this.fSpaceLimit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<Object> keys() {
/* 231 */     return this.fEntryTable.keys();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean makeSpace(int space) {
/* 245 */     int limit = getSpaceLimit();
/*     */ 
/*     */     
/* 248 */     if (this.fCurrentSpace + space <= limit) {
/* 249 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 253 */     if (space > limit) {
/* 254 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 258 */     while (this.fCurrentSpace + space > limit && this.fEntryQueueTail != null) {
/* 259 */       privateRemoveEntry(this.fEntryQueueTail, false);
/*     */     }
/* 261 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LRUCache newInstance(int size) {
/* 269 */     return new LRUCache(size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object peek(Object key) {
/* 281 */     LRUCacheEntry entry = this.fEntryTable.get(key);
/* 282 */     if (entry == null) {
/* 283 */       return null;
/*     */     }
/* 285 */     return entry._fValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void privateAdd(Object key, Object value, int space) {
/* 297 */     LRUCacheEntry entry = new LRUCacheEntry(key, value, space);
/* 298 */     privateAddEntry(entry, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void privateAddEntry(LRUCacheEntry entry, boolean shuffle) {
/* 308 */     if (!shuffle) {
/* 309 */       this.fEntryTable.put(entry._fKey, entry);
/* 310 */       this.fCurrentSpace += entry._fSpace;
/*     */     } 
/*     */     
/* 313 */     entry._fTimestamp = this.fTimestampCounter++;
/* 314 */     entry._fNext = this.fEntryQueue;
/* 315 */     entry._fPrevious = null;
/*     */     
/* 317 */     if (this.fEntryQueue == null) {
/*     */       
/* 319 */       this.fEntryQueueTail = entry;
/*     */     } else {
/* 321 */       this.fEntryQueue._fPrevious = entry;
/*     */     } 
/*     */     
/* 324 */     this.fEntryQueue = entry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void privateNotifyDeletionFromCache(LRUCacheEntry entry) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void privateRemoveEntry(LRUCacheEntry entry, boolean shuffle) {
/* 345 */     LRUCacheEntry previous = entry._fPrevious;
/* 346 */     LRUCacheEntry next = entry._fNext;
/*     */     
/* 348 */     if (!shuffle) {
/* 349 */       this.fEntryTable.remove(entry._fKey);
/* 350 */       this.fCurrentSpace -= entry._fSpace;
/* 351 */       privateNotifyDeletionFromCache(entry);
/*     */     } 
/*     */ 
/*     */     
/* 355 */     if (previous == null) {
/* 356 */       this.fEntryQueue = next;
/*     */     } else {
/* 358 */       previous._fNext = next;
/*     */     } 
/*     */ 
/*     */     
/* 362 */     if (next == null) {
/* 363 */       this.fEntryQueueTail = previous;
/*     */     } else {
/* 365 */       next._fPrevious = previous;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object put(Object key, Object value) {
/* 381 */     int newSpace = spaceFor(value);
/* 382 */     LRUCacheEntry entry = this.fEntryTable.get(key);
/*     */     
/* 384 */     if (entry != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 391 */       int oldSpace = entry._fSpace;
/* 392 */       int newTotal = getCurrentSpace() - oldSpace + newSpace;
/* 393 */       if (newTotal <= getSpaceLimit()) {
/* 394 */         updateTimestamp(entry);
/* 395 */         entry._fValue = value;
/* 396 */         entry._fSpace = newSpace;
/* 397 */         this.fCurrentSpace = newTotal;
/* 398 */         return value;
/*     */       } 
/* 400 */       privateRemoveEntry(entry, false);
/*     */     } 
/*     */     
/* 403 */     if (makeSpace(newSpace)) {
/* 404 */       privateAdd(key, value, newSpace);
/*     */     }
/* 406 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object removeKey(Object key) {
/* 417 */     LRUCacheEntry entry = this.fEntryTable.get(key);
/* 418 */     if (entry == null) {
/* 419 */       return null;
/*     */     }
/* 421 */     Object value = entry._fValue;
/* 422 */     privateRemoveEntry(entry, false);
/* 423 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSpaceLimit(int limit) {
/* 431 */     if (limit < this.fSpaceLimit) {
/* 432 */       makeSpace(this.fSpaceLimit - limit);
/*     */     }
/* 434 */     this.fSpaceLimit = limit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int spaceFor(Object value) {
/* 442 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 452 */     return 
/* 453 */       String.valueOf(toStringFillingRation("LRUCache")) + 
/* 454 */       toStringContents();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String toStringContents() {
/* 463 */     StringBuilder result = new StringBuilder();
/* 464 */     int length = this.fEntryTable.size();
/* 465 */     Object[] unsortedKeys = new Object[length];
/* 466 */     String[] unsortedToStrings = new String[length];
/* 467 */     Enumeration<Object> e = keys();
/* 468 */     for (int i = 0; i < length; i++) {
/* 469 */       Object key = e.nextElement();
/* 470 */       unsortedKeys[i] = key;
/* 471 */       unsortedToStrings[i] = key.toString();
/*     */     } 
/* 473 */     ToStringSorter sorter = new ToStringSorter();
/* 474 */     sorter.sort(unsortedKeys, unsortedToStrings);
/* 475 */     for (int j = 0; j < length; j++) {
/* 476 */       String toString = sorter.sortedStrings[j];
/* 477 */       Object value = get(sorter.sortedObjects[j]);
/* 478 */       result.append(toString);
/* 479 */       result.append(" -> ");
/* 480 */       result.append(value);
/* 481 */       result.append("\n");
/*     */     } 
/* 483 */     return result.toString();
/*     */   }
/*     */   
/*     */   public String toStringFillingRation(String cacheName) {
/* 487 */     StringBuilder buffer = new StringBuilder(cacheName);
/* 488 */     buffer.append('[');
/* 489 */     buffer.append(getSpaceLimit());
/* 490 */     buffer.append("]: ");
/* 491 */     buffer.append(fillingRatio());
/* 492 */     buffer.append("% full");
/* 493 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateTimestamp(LRUCacheEntry entry) {
/* 503 */     entry._fTimestamp = this.fTimestampCounter++;
/* 504 */     if (this.fEntryQueue != entry) {
/* 505 */       privateRemoveEntry(entry, true);
/* 506 */       privateAddEntry(entry, true);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expression\\util\LRUCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */