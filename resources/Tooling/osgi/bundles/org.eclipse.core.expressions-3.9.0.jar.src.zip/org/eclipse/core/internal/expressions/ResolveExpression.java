/*     */ package org.eclipse.core.internal.expressions;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.core.expressions.CompositeExpression;
/*     */ import org.eclipse.core.expressions.EvaluationContext;
/*     */ import org.eclipse.core.expressions.EvaluationResult;
/*     */ import org.eclipse.core.expressions.Expression;
/*     */ import org.eclipse.core.expressions.ExpressionInfo;
/*     */ import org.eclipse.core.expressions.IEvaluationContext;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResolveExpression
/*     */   extends CompositeExpression
/*     */ {
/*     */   private String fVariable;
/*     */   private Object[] fArgs;
/*     */   private static final String ATT_VARIABLE = "variable";
/*     */   private static final String ATT_ARGS = "args";
/*  42 */   private static final int HASH_INITIAL = ResolveExpression.class.getName().hashCode();
/*     */   
/*     */   public ResolveExpression(IConfigurationElement configElement) throws CoreException {
/*  45 */     this.fVariable = configElement.getAttribute("variable");
/*  46 */     Expressions.checkAttribute("variable", this.fVariable);
/*  47 */     this.fArgs = Expressions.getArguments(configElement, "args");
/*     */   }
/*     */   
/*     */   public ResolveExpression(Element element) throws CoreException {
/*  51 */     this.fVariable = element.getAttribute("variable");
/*  52 */     Expressions.checkAttribute("variable", this.fVariable.isEmpty() ? null : this.fVariable);
/*  53 */     this.fArgs = Expressions.getArguments(element, "args");
/*     */   }
/*     */   
/*     */   public ResolveExpression(String variable, Object[] args) {
/*  57 */     Assert.isNotNull(variable);
/*  58 */     this.fVariable = variable;
/*  59 */     this.fArgs = args;
/*     */   }
/*     */ 
/*     */   
/*     */   public EvaluationResult evaluate(IEvaluationContext context) throws CoreException {
/*  64 */     Object variable = context.resolveVariable(this.fVariable, this.fArgs);
/*  65 */     if (variable == null) {
/*  66 */       throw new CoreException(new ExpressionStatus(
/*  67 */             301, 
/*  68 */             Messages.format(ExpressionMessages.ResolveExpression_variable_not_defined, this.fVariable)));
/*     */     }
/*  70 */     return evaluateAnd((IEvaluationContext)new EvaluationContext(context, variable));
/*     */   }
/*     */ 
/*     */   
/*     */   public void collectExpressionInfo(ExpressionInfo info) {
/*  75 */     ExpressionInfo other = new ExpressionInfo();
/*  76 */     super.collectExpressionInfo(other);
/*  77 */     if (other.hasDefaultVariableAccess()) {
/*  78 */       info.addVariableNameAccess(this.fVariable);
/*     */     }
/*  80 */     info.mergeExceptDefaultVariable(other);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/*  85 */     if (!(object instanceof ResolveExpression)) {
/*  86 */       return false;
/*     */     }
/*  88 */     ResolveExpression that = (ResolveExpression)object;
/*  89 */     return (this.fVariable.equals(that.fVariable) && 
/*  90 */       equals(this.fArgs, that.fArgs) && 
/*  91 */       equals(this.fExpressions, that.fExpressions));
/*     */   }
/*     */ 
/*     */   
/*     */   protected int computeHashCode() {
/*  96 */     return HASH_INITIAL * 89 + hashCode(this.fExpressions) * 
/*  97 */       89 + hashCode(this.fArgs) * 
/*  98 */       89 + this.fVariable.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 103 */     StringBuilder builder = new StringBuilder(getClass().getSimpleName());
/* 104 */     builder.append(" [variable=").append(this.fVariable);
/* 105 */     if (this.fArgs != null) {
/* 106 */       builder.append(", args=").append(Arrays.toString(this.fArgs));
/*     */     }
/* 108 */     Expression[] children = getChildren();
/* 109 */     if (children.length > 0) {
/* 110 */       builder.append(", children=");
/* 111 */       builder.append(Arrays.toString((Object[])children));
/*     */     } 
/* 113 */     builder.append("]");
/* 114 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\ResolveExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */