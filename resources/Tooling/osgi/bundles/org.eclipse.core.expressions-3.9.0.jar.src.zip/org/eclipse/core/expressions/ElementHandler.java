/*     */ package org.eclipse.core.expressions;
/*     */ 
/*     */ import org.eclipse.core.internal.expressions.ExpressionMessages;
/*     */ import org.eclipse.core.internal.expressions.StandardElementHandler;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ElementHandler
/*     */ {
/*  38 */   private static final ElementHandler INSTANCE = (ElementHandler)new StandardElementHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ElementHandler getDefault() {
/*  47 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Expression create(ExpressionConverter paramExpressionConverter, IConfigurationElement paramIConfigurationElement) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression create(ExpressionConverter converter, Element element) throws CoreException {
/*  81 */     throw new CoreException(new Status(4, ElementHandler.class, 
/*  82 */           4, 
/*  83 */           ExpressionMessages.ElementHandler_unsupported_element, 
/*  84 */           null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processChildren(ExpressionConverter converter, IConfigurationElement element, CompositeExpression expression) throws CoreException {
/* 105 */     converter.processChildren(element, expression);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processChildren(ExpressionConverter converter, Element element, CompositeExpression expression) throws CoreException {
/* 127 */     converter.processChildren(element, expression);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\ElementHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */