/*     */ package org.eclipse.core.expressions;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpressionInfo
/*     */ {
/*     */   private boolean fHasDefaultVariableAccess;
/*     */   private boolean fHasSystemPropertyAccess;
/*     */   private List<String> fAccessedVariableNames;
/*     */   private List<Class<?>> fMisbehavingExpressionTypes;
/*     */   private List<String> fAccessedPropertyNames;
/*     */   
/*     */   public boolean hasDefaultVariableAccess() {
/*  50 */     return this.fHasDefaultVariableAccess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markDefaultVariableAccessed() {
/*  57 */     this.fHasDefaultVariableAccess = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasSystemPropertyAccess() {
/*  67 */     return this.fHasSystemPropertyAccess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markSystemPropertyAccessed() {
/*  74 */     this.fHasSystemPropertyAccess = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getAccessedVariableNames() {
/*  83 */     if (this.fAccessedVariableNames == null) {
/*  84 */       return new String[0];
/*     */     }
/*  86 */     return this.fAccessedVariableNames.<String>toArray(new String[this.fAccessedVariableNames.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addVariableNameAccess(String name) {
/*  95 */     if (this.fAccessedVariableNames == null) {
/*  96 */       this.fAccessedVariableNames = new ArrayList<>(5);
/*  97 */       this.fAccessedVariableNames.add(name);
/*  98 */     } else if (!this.fAccessedVariableNames.contains(name)) {
/*  99 */       this.fAccessedVariableNames.add(name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getAccessedPropertyNames() {
/* 112 */     if (this.fAccessedPropertyNames == null) {
/* 113 */       return new String[0];
/*     */     }
/* 115 */     return this.fAccessedPropertyNames.<String>toArray(new String[this.fAccessedPropertyNames.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAccessedPropertyName(String name) {
/* 129 */     if (this.fAccessedPropertyNames == null) {
/* 130 */       this.fAccessedPropertyNames = new ArrayList<>(5);
/* 131 */       this.fAccessedPropertyNames.add(name);
/* 132 */     } else if (!this.fAccessedPropertyNames.contains(name)) {
/*     */       
/* 134 */       this.fAccessedPropertyNames.add(name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?>[] getMisbehavingExpressionTypes() {
/* 149 */     if (this.fMisbehavingExpressionTypes == null) {
/* 150 */       return null;
/*     */     }
/* 152 */     return (Class[])this.fMisbehavingExpressionTypes.<Class<?>[]>toArray((Class<?>[][])new Class[this.fMisbehavingExpressionTypes.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMisBehavingExpressionType(Class<?> clazz) {
/* 161 */     if (this.fMisbehavingExpressionTypes == null) {
/* 162 */       this.fMisbehavingExpressionTypes = new ArrayList<>(2);
/* 163 */       this.fMisbehavingExpressionTypes.add(clazz);
/* 164 */     } else if (!this.fMisbehavingExpressionTypes.contains(clazz)) {
/* 165 */       this.fMisbehavingExpressionTypes.add(clazz);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void merge(ExpressionInfo other) {
/* 175 */     mergeDefaultVariableAccess(other);
/* 176 */     mergeSystemPropertyAccess(other);
/*     */     
/* 178 */     mergeAccessedVariableNames(other);
/* 179 */     mergeAccessedPropertyNames(other);
/* 180 */     mergeMisbehavingExpressionTypes(other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mergeExceptDefaultVariable(ExpressionInfo other) {
/* 190 */     mergeSystemPropertyAccess(other);
/*     */     
/* 192 */     mergeAccessedVariableNames(other);
/* 193 */     mergeAccessedPropertyNames(other);
/* 194 */     mergeMisbehavingExpressionTypes(other);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mergeDefaultVariableAccess(ExpressionInfo other) {
/* 203 */     this.fHasDefaultVariableAccess = !(!this.fHasDefaultVariableAccess && !other.fHasDefaultVariableAccess);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mergeSystemPropertyAccess(ExpressionInfo other) {
/* 212 */     this.fHasSystemPropertyAccess = !(!this.fHasSystemPropertyAccess && !other.fHasSystemPropertyAccess);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mergeAccessedVariableNames(ExpressionInfo other) {
/* 221 */     if (this.fAccessedVariableNames == null) {
/* 222 */       this.fAccessedVariableNames = other.fAccessedVariableNames;
/* 223 */     } else if (other.fAccessedVariableNames != null) {
/* 224 */       for (String variableName : other.fAccessedVariableNames) {
/* 225 */         if (!this.fAccessedVariableNames.contains(variableName)) {
/* 226 */           this.fAccessedVariableNames.add(variableName);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mergeAccessedPropertyNames(ExpressionInfo other) {
/* 240 */     if (this.fAccessedPropertyNames == null) {
/* 241 */       this.fAccessedPropertyNames = other.fAccessedPropertyNames;
/* 242 */     } else if (other.fAccessedPropertyNames != null) {
/* 243 */       for (String variableName : other.fAccessedPropertyNames) {
/* 244 */         if (!this.fAccessedPropertyNames.contains(variableName)) {
/* 245 */           this.fAccessedPropertyNames.add(variableName);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mergeMisbehavingExpressionTypes(ExpressionInfo other) {
/* 257 */     if (this.fMisbehavingExpressionTypes == null) {
/* 258 */       this.fMisbehavingExpressionTypes = other.fMisbehavingExpressionTypes;
/* 259 */     } else if (other.fMisbehavingExpressionTypes != null) {
/* 260 */       for (Class<?> clazz : other.fMisbehavingExpressionTypes) {
/* 261 */         if (!this.fMisbehavingExpressionTypes.contains(clazz))
/* 262 */           this.fMisbehavingExpressionTypes.add(clazz); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\ExpressionInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */