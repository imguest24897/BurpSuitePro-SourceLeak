/*    */ package org.eclipse.core.expressions;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OrExpression
/*    */   extends CompositeExpression
/*    */ {
/*    */   public EvaluationResult evaluate(IEvaluationContext context) throws CoreException {
/* 26 */     return evaluateOr(context);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object object) {
/* 31 */     if (!(object instanceof OrExpression)) {
/* 32 */       return false;
/*    */     }
/* 34 */     OrExpression that = (OrExpression)object;
/* 35 */     return equals(this.fExpressions, that.fExpressions);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\OrExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */