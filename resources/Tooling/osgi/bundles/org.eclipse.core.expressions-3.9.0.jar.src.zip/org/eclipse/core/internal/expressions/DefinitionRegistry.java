/*     */ package org.eclipse.core.internal.expressions;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.expressions.Expression;
/*     */ import org.eclipse.core.expressions.ExpressionConverter;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtensionDelta;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.IRegistryChangeEvent;
/*     */ import org.eclipse.core.runtime.IRegistryChangeListener;
/*     */ import org.eclipse.core.runtime.InvalidRegistryObjectException;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefinitionRegistry
/*     */   implements IRegistryChangeListener
/*     */ {
/*  37 */   private Map<String, Expression> cache = null;
/*     */   
/*     */   private Map<String, Expression> getCache() {
/*  40 */     if (this.cache == null) {
/*  41 */       this.cache = new HashMap<>();
/*     */     }
/*  43 */     return this.cache;
/*     */   }
/*     */   
/*     */   public DefinitionRegistry() {
/*  47 */     Platform.getExtensionRegistry().addRegistryChangeListener(this, "org.eclipse.core.expressions");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression getExpression(String id) throws CoreException {
/*  60 */     Expression cachedExpression = getCache().get(id);
/*  61 */     if (cachedExpression != null) {
/*  62 */       return cachedExpression;
/*     */     }
/*     */     
/*  65 */     IExtensionRegistry registry = Platform.getExtensionRegistry();
/*  66 */     IConfigurationElement[] ces = registry.getConfigurationElementsFor("org.eclipse.core.expressions", "definitions");
/*     */     
/*  68 */     Expression foundExpression = null; byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/*  69 */     for (i = (arrayOfIConfigurationElement1 = ces).length, b = 0; b < i; ) { IConfigurationElement ce = arrayOfIConfigurationElement1[b];
/*  70 */       String cid = ce.getAttribute("id");
/*  71 */       if (cid != null && cid.equals(id)) {
/*     */         try {
/*  73 */           foundExpression = getExpression(id, ce);
/*     */         }
/*  75 */         catch (InvalidRegistryObjectException invalidRegistryObjectException) {
/*  76 */           throw new CoreException(new ExpressionStatus(52, Messages.format(
/*  77 */                   ExpressionMessages.Missing_Expression, id)));
/*     */         }  break;
/*     */       }  b++; }
/*     */     
/*  81 */     if (foundExpression == null) {
/*  82 */       throw new CoreException(new ExpressionStatus(52, Messages.format(
/*  83 */               ExpressionMessages.Missing_Expression, id)));
/*     */     }
/*  85 */     return foundExpression;
/*     */   }
/*     */ 
/*     */   
/*     */   private Expression getExpression(String id, IConfigurationElement element) throws InvalidRegistryObjectException, CoreException {
/*  90 */     Expression expr = ExpressionConverter.getDefault().perform(element.getChildren()[0]);
/*  91 */     if (expr != null) {
/*  92 */       getCache().put(id, expr);
/*     */     }
/*  94 */     return expr;
/*     */   }
/*     */ 
/*     */   
/*     */   public void registryChanged(IRegistryChangeEvent event) {
/*  99 */     IExtensionDelta[] extensionDeltas = event.getExtensionDeltas("org.eclipse.core.expressions", "definitions"); byte b; int i; IExtensionDelta[] arrayOfIExtensionDelta1;
/* 100 */     for (i = (arrayOfIExtensionDelta1 = extensionDeltas).length, b = 0; b < i; ) { IExtensionDelta extensionDelta = arrayOfIExtensionDelta1[b];
/* 101 */       if (extensionDelta.getKind() == 2) {
/* 102 */         IConfigurationElement[] ces = extensionDelta.getExtension().getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 103 */         for (j = (arrayOfIConfigurationElement1 = ces).length, b1 = 0; b1 < j; ) { IConfigurationElement ce = arrayOfIConfigurationElement1[b1];
/* 104 */           String id = ce.getAttribute("id");
/* 105 */           if (id != null)
/* 106 */             getCache().remove(id); 
/*     */           b1++; }
/*     */       
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\DefinitionRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */