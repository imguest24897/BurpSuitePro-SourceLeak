/*     */ package org.eclipse.core.expressions;
/*     */ 
/*     */ import org.eclipse.core.internal.expressions.DefinitionRegistry;
/*     */ import org.eclipse.core.internal.expressions.Expressions;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReferenceExpression
/*     */   extends Expression
/*     */ {
/*  36 */   private static DefinitionRegistry fgDefinitionRegistry = null;
/*     */   
/*     */   private static DefinitionRegistry getDefinitionRegistry() {
/*  39 */     if (fgDefinitionRegistry == null) {
/*  40 */       fgDefinitionRegistry = new DefinitionRegistry();
/*     */     }
/*  42 */     return fgDefinitionRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String ATT_DEFINITION_ID = "definitionId";
/*     */ 
/*     */   
/*  50 */   private static final int HASH_INITIAL = ReferenceExpression.class.getName().hashCode();
/*     */   
/*     */   private String fDefinitionId;
/*     */   
/*     */   public ReferenceExpression(String definitionId) {
/*  55 */     Assert.isNotNull(definitionId);
/*  56 */     this.fDefinitionId = definitionId;
/*     */   }
/*     */   
/*     */   public ReferenceExpression(IConfigurationElement element) throws CoreException {
/*  60 */     this.fDefinitionId = element.getAttribute("definitionId");
/*  61 */     Expressions.checkAttribute("definitionId", this.fDefinitionId);
/*     */   }
/*     */   
/*     */   public ReferenceExpression(Element element) throws CoreException {
/*  65 */     this.fDefinitionId = element.getAttribute("definitionId");
/*  66 */     Expressions.checkAttribute("definitionId", this.fDefinitionId.isEmpty() ? null : this.fDefinitionId);
/*     */   }
/*     */ 
/*     */   
/*     */   public EvaluationResult evaluate(IEvaluationContext context) throws CoreException {
/*  71 */     Expression expr = getDefinitionRegistry().getExpression(this.fDefinitionId);
/*  72 */     return expr.evaluate(context);
/*     */   }
/*     */ 
/*     */   
/*     */   public void collectExpressionInfo(ExpressionInfo info) {
/*     */     Expression expr;
/*     */     try {
/*  79 */       expr = getDefinitionRegistry().getExpression(this.fDefinitionId);
/*  80 */     } catch (CoreException coreException) {
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/*  85 */     expr.collectExpressionInfo(info);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/*  90 */     if (!(object instanceof ReferenceExpression)) {
/*  91 */       return false;
/*     */     }
/*  93 */     ReferenceExpression that = (ReferenceExpression)object;
/*  94 */     return this.fDefinitionId.equals(that.fDefinitionId);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int computeHashCode() {
/*  99 */     return HASH_INITIAL * 89 + this.fDefinitionId.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 104 */     StringBuilder builder = new StringBuilder(getClass().getSimpleName());
/* 105 */     builder.append(" [definitionId=");
/* 106 */     builder.append(this.fDefinitionId);
/* 107 */     builder.append("]");
/* 108 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\ReferenceExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */