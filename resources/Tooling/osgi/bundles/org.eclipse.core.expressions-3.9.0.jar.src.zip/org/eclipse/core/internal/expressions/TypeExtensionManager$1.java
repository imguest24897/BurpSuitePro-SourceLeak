/*    */ package org.eclipse.core.internal.expressions;
/*    */ 
/*    */ import org.eclipse.core.expressions.IPropertyTester;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements IPropertyTester
/*    */ {
/*    */   public boolean handles(String namespace, String property) {
/* 51 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isInstantiated() {
/* 55 */     return true;
/*    */   }
/*    */   
/*    */   public boolean isDeclaringPluginActive() {
/* 59 */     return true;
/*    */   }
/*    */   
/*    */   public IPropertyTester instantiate() throws CoreException {
/* 63 */     return this;
/*    */   }
/*    */   
/*    */   public boolean test(Object receiver, String property, Object[] args, Object expectedValue) {
/* 67 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\TypeExtensionManager$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */