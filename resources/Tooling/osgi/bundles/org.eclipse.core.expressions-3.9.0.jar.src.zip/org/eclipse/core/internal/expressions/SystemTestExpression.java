/*    */ package org.eclipse.core.internal.expressions;
/*    */ 
/*    */ import org.eclipse.core.expressions.EvaluationResult;
/*    */ import org.eclipse.core.expressions.Expression;
/*    */ import org.eclipse.core.expressions.ExpressionInfo;
/*    */ import org.eclipse.core.expressions.IEvaluationContext;
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SystemTestExpression
/*    */   extends Expression
/*    */ {
/*    */   private String fProperty;
/*    */   private String fExpectedValue;
/*    */   private static final String ATT_PROPERTY = "property";
/* 37 */   private static final int HASH_INITIAL = SystemTestExpression.class.getName().hashCode();
/*    */   
/*    */   public SystemTestExpression(IConfigurationElement element) throws CoreException {
/* 40 */     this.fProperty = element.getAttribute("property");
/* 41 */     Expressions.checkAttribute("property", this.fProperty);
/* 42 */     this.fExpectedValue = element.getAttribute("value");
/* 43 */     Expressions.checkAttribute("value", this.fExpectedValue);
/*    */   }
/*    */   
/*    */   public SystemTestExpression(Element element) throws CoreException {
/* 47 */     this.fProperty = element.getAttribute("property");
/* 48 */     Expressions.checkAttribute("property", this.fProperty.isEmpty() ? null : this.fProperty);
/* 49 */     this.fExpectedValue = element.getAttribute("value");
/* 50 */     Expressions.checkAttribute("value", this.fExpectedValue.isEmpty() ? null : this.fExpectedValue);
/*    */   }
/*    */   
/*    */   public SystemTestExpression(String property, String expectedValue) {
/* 54 */     Assert.isNotNull(property);
/* 55 */     Assert.isNotNull(expectedValue);
/* 56 */     this.fProperty = property;
/* 57 */     this.fExpectedValue = expectedValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public EvaluationResult evaluate(IEvaluationContext context) throws CoreException {
/* 62 */     String str = System.getProperty(this.fProperty);
/* 63 */     if (str == null)
/* 64 */       return EvaluationResult.FALSE; 
/* 65 */     return EvaluationResult.valueOf(str.equals(this.fExpectedValue));
/*    */   }
/*    */ 
/*    */   
/*    */   public void collectExpressionInfo(ExpressionInfo info) {
/* 70 */     info.markSystemPropertyAccessed();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object object) {
/* 75 */     if (!(object instanceof SystemTestExpression)) {
/* 76 */       return false;
/*    */     }
/* 78 */     SystemTestExpression that = (SystemTestExpression)object;
/* 79 */     return (this.fProperty.equals(that.fProperty) && 
/* 80 */       this.fExpectedValue.equals(that.fExpectedValue));
/*    */   }
/*    */ 
/*    */   
/*    */   protected int computeHashCode() {
/* 85 */     return HASH_INITIAL * 89 + this.fExpectedValue.hashCode() * 
/* 86 */       89 + this.fProperty.hashCode();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 93 */     return "<systemTest property=\"" + this.fProperty + 
/* 94 */       "\" value=\"" + this.fExpectedValue + "\"";
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\SystemTestExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */