/*     */ package org.eclipse.core.expressions;
/*     */ 
/*     */ import org.eclipse.core.internal.expressions.PropertyTesterDescriptor;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.osgi.framework.Bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PropertyTester
/*     */   implements IPropertyTester
/*     */ {
/*     */   private IConfigurationElement fConfigElement;
/*     */   private String fNamespace;
/*     */   private String fProperties;
/*     */   
/*     */   public final void internalInitialize(PropertyTesterDescriptor descriptor) {
/*  84 */     this.fProperties = descriptor.getProperties();
/*  85 */     this.fNamespace = descriptor.getNamespace();
/*  86 */     this.fConfigElement = descriptor.getConfigurationElement();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final PropertyTesterDescriptor internalCreateDescriptor() {
/*  98 */     return new PropertyTesterDescriptor(this.fConfigElement, this.fNamespace, this.fProperties);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean handles(String namespace, String property) {
/* 103 */     return (this.fNamespace.equals(namespace) && this.fProperties.contains("," + property + ","));
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isInstantiated() {
/* 108 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDeclaringPluginActive() {
/* 113 */     Bundle bundle = Platform.getBundle(this.fConfigElement.getContributor().getName());
/* 114 */     return (bundle.getState() == 32);
/*     */   }
/*     */ 
/*     */   
/*     */   public final IPropertyTester instantiate() {
/* 119 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\PropertyTester.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */