/*     */ package org.eclipse.core.expressions;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EvaluationResult
/*     */ {
/*     */   private int fValue;
/*     */   private static final int FALSE_VALUE = 0;
/*     */   private static final int TRUE_VALUE = 1;
/*     */   private static final int NOT_LOADED_VALUE = 2;
/* 142 */   public static final EvaluationResult FALSE = new EvaluationResult(0);
/*     */   
/* 144 */   public static final EvaluationResult TRUE = new EvaluationResult(1);
/*     */   
/* 146 */   public static final EvaluationResult NOT_LOADED = new EvaluationResult(2);
/*     */   
/* 148 */   private static final EvaluationResult[][] AND = new EvaluationResult[][] {
/*     */       {
/* 150 */         FALSE, FALSE, FALSE
/* 151 */       }, { FALSE, TRUE, NOT_LOADED
/* 152 */       }, { FALSE, NOT_LOADED, NOT_LOADED }
/*     */     };
/*     */   
/* 155 */   private static final EvaluationResult[][] OR = new EvaluationResult[][] {
/*     */       {
/* 157 */         FALSE, TRUE, NOT_LOADED
/* 158 */       }, { TRUE, TRUE, TRUE
/* 159 */       }, { NOT_LOADED, TRUE, NOT_LOADED }
/*     */     };
/*     */   
/* 162 */   private static final EvaluationResult[] NOT = new EvaluationResult[] {
/*     */       
/* 164 */       TRUE, FALSE, NOT_LOADED
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EvaluationResult(int value) {
/* 171 */     this.fValue = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EvaluationResult and(EvaluationResult other) {
/* 182 */     return AND[this.fValue][other.fValue];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EvaluationResult or(EvaluationResult other) {
/* 193 */     return OR[this.fValue][other.fValue];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EvaluationResult not() {
/* 202 */     return NOT[this.fValue];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EvaluationResult valueOf(boolean b) {
/* 218 */     return b ? TRUE : FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EvaluationResult valueOf(Boolean b) {
/* 234 */     return b.booleanValue() ? TRUE : FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 245 */     switch (this.fValue) {
/*     */       case 0:
/* 247 */         return "false";
/*     */       case 1:
/* 249 */         return "true";
/*     */       case 2:
/* 251 */         return "not_loaded";
/*     */     } 
/* 253 */     Assert.isTrue(false);
/* 254 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\EvaluationResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */