/*     */ package org.eclipse.core.internal.expressions;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import org.eclipse.core.expressions.CompositeExpression;
/*     */ import org.eclipse.core.expressions.EvaluationResult;
/*     */ import org.eclipse.core.expressions.Expression;
/*     */ import org.eclipse.core.expressions.ExpressionInfo;
/*     */ import org.eclipse.core.expressions.IEvaluationContext;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.core.runtime.IAdapterManager;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AdaptExpression
/*     */   extends CompositeExpression
/*     */ {
/*     */   private static final String PREFERENCE_NAMESPACE = "org.eclipse.core.expressions";
/*     */   private static final String ATT_TYPE = "type";
/*  43 */   private static final int HASH_INITIAL = AdaptExpression.class.getName().hashCode();
/*     */   
/*     */   private String fTypeName;
/*     */   
/*     */   public AdaptExpression(IConfigurationElement configElement) throws CoreException {
/*  48 */     this.fTypeName = configElement.getAttribute("type");
/*  49 */     Expressions.checkAttribute("type", this.fTypeName);
/*     */   }
/*     */   
/*     */   public AdaptExpression(Element element) throws CoreException {
/*  53 */     this.fTypeName = element.getAttribute("type");
/*  54 */     Expressions.checkAttribute("type", this.fTypeName.isEmpty() ? null : this.fTypeName);
/*     */   }
/*     */   
/*     */   public AdaptExpression(String typeName) {
/*  58 */     Assert.isNotNull(typeName);
/*  59 */     this.fTypeName = typeName;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/*  64 */     if (!(object instanceof AdaptExpression)) {
/*  65 */       return false;
/*     */     }
/*  67 */     AdaptExpression that = (AdaptExpression)object;
/*  68 */     return (this.fTypeName.equals(that.fTypeName) && 
/*  69 */       equals(this.fExpressions, that.fExpressions));
/*     */   }
/*     */ 
/*     */   
/*     */   protected int computeHashCode() {
/*  74 */     return HASH_INITIAL * 89 + hashCode(this.fExpressions) * 
/*  75 */       89 + this.fTypeName.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public EvaluationResult evaluate(IEvaluationContext context) throws CoreException {
/*  80 */     if (this.fTypeName == null)
/*  81 */       return EvaluationResult.FALSE; 
/*  82 */     Object var = context.getDefaultVariable();
/*  83 */     if (var == null) {
/*  84 */       return EvaluationResult.FALSE;
/*     */     }
/*  86 */     Object adapted = null;
/*  87 */     IAdapterManager manager = Platform.getAdapterManager();
/*  88 */     if (Expressions.isInstanceOf(var, this.fTypeName)) {
/*  89 */       adapted = var;
/*     */     }
/*     */     else {
/*     */       
/*  93 */       if (var instanceof IAdaptable) {
/*  94 */         Class<?> typeClazz = Expressions.loadClass(var.getClass().getClassLoader(), this.fTypeName);
/*  95 */         if (typeClazz != null) {
/*  96 */           adapted = ((IAdaptable)var).getAdapter(typeClazz);
/*     */         }
/*     */       } 
/*     */       
/* 100 */       if (adapted == null) {
/* 101 */         if (forceLoadEnabled()) {
/* 102 */           adapted = manager.loadAdapter(var, this.fTypeName);
/*     */         } else {
/* 104 */           adapted = manager.getAdapter(var, this.fTypeName);
/* 105 */           if (adapted == null) {
/* 106 */             if (manager.queryAdapter(var, this.fTypeName) == 1) {
/* 107 */               return EvaluationResult.NOT_LOADED;
/*     */             }
/* 109 */             return EvaluationResult.FALSE;
/*     */           } 
/*     */         } 
/*     */         
/* 113 */         if (adapted == null)
/*     */         {
/* 115 */           return EvaluationResult.FALSE;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 121 */     return evaluateAnd(new DefaultVariable(context, adapted));
/*     */   }
/*     */   
/*     */   private boolean forceLoadEnabled() {
/* 125 */     return Platform.getPreferencesService().getBoolean("org.eclipse.core.expressions", "forceLoadAdapters", true, 
/* 126 */         null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void collectExpressionInfo(ExpressionInfo info) {
/* 134 */     info.markDefaultVariableAccessed();
/* 135 */     super.collectExpressionInfo(info);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 140 */     StringBuilder builder = new StringBuilder(getClass().getSimpleName());
/* 141 */     builder.append(" [type=").append(this.fTypeName);
/* 142 */     Expression[] children = getChildren();
/* 143 */     if (children.length > 0) {
/* 144 */       builder.append(", children=");
/* 145 */       builder.append(Arrays.toString((Object[])children));
/*     */     } 
/* 147 */     builder.append("]");
/* 148 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\AdaptExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */