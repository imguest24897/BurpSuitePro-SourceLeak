/*    */ package org.eclipse.core.internal.expressions;
/*    */ 
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Messages
/*    */ {
/*    */   public static String format(String message, Object object) {
/* 27 */     return NLS.bind(message, object);
/*    */   }
/*    */   
/*    */   public static String format(String message, Object[] objects) {
/* 31 */     return NLS.bind(message, objects);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\Messages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */