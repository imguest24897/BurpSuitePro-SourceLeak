/*     */ package org.eclipse.core.expressions;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.eclipse.core.internal.expressions.Expressions;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CountExpression
/*     */   extends Expression
/*     */ {
/*     */   private static final int GREATER_THAN = 7;
/*     */   private static final int LESS_THAN = 6;
/*     */   private static final int ANY_NUMBER = 5;
/*     */   private static final int EXACT = 4;
/*     */   private static final int ONE_OR_MORE = 3;
/*     */   private static final int NONE_OR_ONE = 2;
/*     */   private static final int NONE = 1;
/*     */   private static final int UNKNOWN = 0;
/*  44 */   private static final int HASH_INITIAL = CountExpression.class.getName().hashCode();
/*     */   
/*     */   private int fMode;
/*     */   private int fSize;
/*     */   
/*     */   public CountExpression(IConfigurationElement configElement) {
/*  50 */     String size = configElement.getAttribute("value");
/*  51 */     initializeSize(size);
/*     */   }
/*     */   
/*     */   public CountExpression(Element element) {
/*  55 */     String size = element.getAttribute("value");
/*  56 */     initializeSize(size.isEmpty() ? null : size);
/*     */   }
/*     */   
/*     */   public CountExpression(String size) {
/*  60 */     initializeSize(size);
/*     */   }
/*     */   
/*     */   private void initializeSize(String size) {
/*  64 */     if (size == null)
/*  65 */       size = "*"; 
/*  66 */     if ("*".equals(size)) {
/*  67 */       this.fMode = 5;
/*  68 */     } else if ("?".equals(size)) {
/*  69 */       this.fMode = 2;
/*  70 */     } else if ("!".equals(size)) {
/*  71 */       this.fMode = 1;
/*  72 */     } else if ("+".equals(size)) {
/*  73 */       this.fMode = 3;
/*  74 */     } else if (size.charAt(0) == '-' && size.charAt(size.length() - 1) == ')') {
/*     */       try {
/*  76 */         this.fMode = 6;
/*  77 */         this.fSize = Integer.parseInt(size.substring(1, size.length() - 1));
/*  78 */       } catch (NumberFormatException numberFormatException) {
/*  79 */         this.fMode = 0;
/*     */       } 
/*  81 */     } else if (size.charAt(0) == '(' && size.charAt(size.length() - 1) == '-') {
/*     */       try {
/*  83 */         this.fMode = 7;
/*  84 */         this.fSize = Integer.parseInt(size.substring(1, size.length() - 1));
/*  85 */       } catch (NumberFormatException numberFormatException) {
/*  86 */         this.fMode = 0;
/*     */       } 
/*     */     } else {
/*     */       try {
/*  90 */         this.fSize = Integer.parseInt(size);
/*  91 */         this.fMode = 4;
/*  92 */       } catch (NumberFormatException numberFormatException) {
/*  93 */         this.fMode = 0;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public EvaluationResult evaluate(IEvaluationContext context) throws CoreException {
/*     */     int size;
/* 100 */     Object var = context.getDefaultVariable();
/*     */     
/* 102 */     if (var instanceof Collection) {
/* 103 */       size = ((Collection)var).size();
/*     */     } else {
/* 105 */       ICountable countable = Expressions.getAsICountable(var, this);
/* 106 */       if (countable == null)
/* 107 */         return EvaluationResult.NOT_LOADED; 
/* 108 */       size = countable.count();
/*     */     } 
/* 110 */     switch (this.fMode) {
/*     */       case 0:
/* 112 */         return EvaluationResult.FALSE;
/*     */       case 1:
/* 114 */         return EvaluationResult.valueOf((size == 0));
/*     */       case 2:
/* 116 */         return EvaluationResult.valueOf(!(size != 0 && size != 1));
/*     */       case 3:
/* 118 */         return EvaluationResult.valueOf((size >= 1));
/*     */       case 4:
/* 120 */         return EvaluationResult.valueOf((this.fSize == size));
/*     */       case 5:
/* 122 */         return EvaluationResult.TRUE;
/*     */       case 6:
/* 124 */         return EvaluationResult.valueOf((size < this.fSize));
/*     */       case 7:
/* 126 */         return EvaluationResult.valueOf((size > this.fSize));
/*     */     } 
/* 128 */     return EvaluationResult.FALSE;
/*     */   }
/*     */ 
/*     */   
/*     */   public void collectExpressionInfo(ExpressionInfo info) {
/* 133 */     info.markDefaultVariableAccessed();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 138 */     if (!(object instanceof CountExpression)) {
/* 139 */       return false;
/*     */     }
/* 141 */     CountExpression that = (CountExpression)object;
/* 142 */     return (this.fMode == that.fMode && this.fSize == that.fSize);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int computeHashCode() {
/* 147 */     return HASH_INITIAL * 89 + this.fMode * 
/* 148 */       89 + this.fSize;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 153 */     StringBuilder builder = new StringBuilder(getClass().getSimpleName());
/* 154 */     builder.append(" [ size=");
/* 155 */     builder.append(this.fSize);
/* 156 */     builder.append(", mode: ");
/* 157 */     builder.append(this.fMode);
/* 158 */     switch (this.fMode) {
/*     */       case 7:
/* 160 */         builder.append(" GREATER_THAN");
/*     */         break;
/*     */       case 6:
/* 163 */         builder.append(" LESS_THAN");
/*     */         break;
/*     */       case 5:
/* 166 */         builder.append(" ANY_NUMBER");
/*     */         break;
/*     */       case 4:
/* 169 */         builder.append(" EXACT");
/*     */         break;
/*     */       case 3:
/* 172 */         builder.append(" ONE_OR_MORE");
/*     */         break;
/*     */       case 2:
/* 175 */         builder.append(" NONE_OR_ONE");
/*     */         break;
/*     */       case 1:
/* 178 */         builder.append(" NONE");
/*     */         break;
/*     */       case 0:
/* 181 */         builder.append(" UNKNOWN");
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 186 */     builder.append("]");
/* 187 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\CountExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */