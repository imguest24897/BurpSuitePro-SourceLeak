/*     */ package org.eclipse.core.expressions;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EvaluationContext
/*     */   implements IEvaluationContext
/*     */ {
/*     */   private IEvaluationContext fParent;
/*     */   private Object fDefaultVariable;
/*     */   private Map<String, Object> fVariables;
/*     */   private IVariableResolver[] fVariableResolvers;
/*     */   private Boolean fAllowPluginActivation;
/*     */   
/*     */   public EvaluationContext(IEvaluationContext parent, Object defaultVariable) {
/*  49 */     Assert.isNotNull(defaultVariable);
/*  50 */     this.fParent = parent;
/*  51 */     this.fDefaultVariable = defaultVariable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EvaluationContext(IEvaluationContext parent, Object defaultVariable, IVariableResolver[] resolvers) {
/*  66 */     Assert.isNotNull(defaultVariable);
/*  67 */     Assert.isNotNull(resolvers);
/*  68 */     this.fParent = parent;
/*  69 */     this.fDefaultVariable = defaultVariable;
/*  70 */     this.fVariableResolvers = resolvers;
/*     */   }
/*     */ 
/*     */   
/*     */   public IEvaluationContext getParent() {
/*  75 */     return this.fParent;
/*     */   }
/*     */ 
/*     */   
/*     */   public IEvaluationContext getRoot() {
/*  80 */     if (this.fParent == null)
/*  81 */       return this; 
/*  82 */     return this.fParent.getRoot();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getDefaultVariable() {
/*  87 */     return this.fDefaultVariable;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAllowPluginActivation(boolean value) {
/*  92 */     this.fAllowPluginActivation = value ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getAllowPluginActivation() {
/*  97 */     if (this.fAllowPluginActivation == null) {
/*  98 */       if (this.fParent != null)
/*  99 */         return this.fParent.getAllowPluginActivation(); 
/* 100 */       return false;
/*     */     } 
/* 102 */     return this.fAllowPluginActivation.booleanValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addVariable(String name, Object value) {
/* 107 */     Assert.isNotNull(name);
/* 108 */     Assert.isNotNull(value);
/* 109 */     if (this.fVariables == null)
/* 110 */       this.fVariables = new HashMap<>(); 
/* 111 */     this.fVariables.put(name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object removeVariable(String name) {
/* 116 */     Assert.isNotNull(name);
/* 117 */     if (this.fVariables == null)
/* 118 */       return null; 
/* 119 */     return this.fVariables.remove(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getVariable(String name) {
/* 124 */     Assert.isNotNull(name);
/* 125 */     Object result = null;
/* 126 */     if (this.fVariables != null) {
/* 127 */       result = this.fVariables.get(name);
/*     */     }
/* 129 */     if (result != null)
/* 130 */       return result; 
/* 131 */     if (this.fParent != null)
/* 132 */       return this.fParent.getVariable(name); 
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object resolveVariable(String name, Object[] args) throws CoreException {
/* 138 */     if (this.fVariableResolvers != null && this.fVariableResolvers.length > 0) {
/* 139 */       byte b; int i; IVariableResolver[] arrayOfIVariableResolver; for (i = (arrayOfIVariableResolver = this.fVariableResolvers).length, b = 0; b < i; ) { IVariableResolver resolver = arrayOfIVariableResolver[b];
/* 140 */         Object variable = resolver.resolve(name, args);
/* 141 */         if (variable != null)
/* 142 */           return variable;  b++; }
/*     */     
/*     */     } 
/* 145 */     if (this.fParent != null)
/* 146 */       return this.fParent.resolveVariable(name, args); 
/* 147 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\EvaluationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */