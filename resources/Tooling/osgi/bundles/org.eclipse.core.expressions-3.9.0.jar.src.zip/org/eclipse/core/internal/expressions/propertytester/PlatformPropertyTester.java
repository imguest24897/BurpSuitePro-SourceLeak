/*    */ package org.eclipse.core.internal.expressions.propertytester;
/*    */ 
/*    */ import org.eclipse.core.expressions.PropertyTester;
/*    */ import org.eclipse.core.runtime.IProduct;
/*    */ import org.eclipse.core.runtime.Platform;
/*    */ import org.osgi.framework.Bundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlatformPropertyTester
/*    */   extends PropertyTester
/*    */ {
/*    */   private static final String PROPERTY_PRODUCT = "product";
/*    */   private static final String PROPERTY_IS_BUNDLE_INSTALLED = "isBundleInstalled";
/*    */   private static final String PROPERTY_BUNDLE_STATE = "bundleState";
/*    */   
/*    */   public boolean test(Object receiver, String property, Object[] args, Object expectedValue) {
/* 44 */     if (Platform.class.equals(receiver)) {
/* 45 */       if ("product".equals(property)) {
/* 46 */         IProduct product = Platform.getProduct();
/* 47 */         if (product != null) {
/* 48 */           return product.getId().equals(expectedValue);
/*    */         }
/* 50 */         return false;
/* 51 */       }  if ("isBundleInstalled".equals(property) && args.length >= 1 && args[0] instanceof String)
/* 52 */         return (Platform.getBundle((String)args[0]) != null); 
/* 53 */       if ("bundleState".equals(property) && 
/* 54 */         args.length >= 1 && args[0] instanceof String) {
/* 55 */         Bundle b = Platform.getBundle((String)args[0]);
/* 56 */         if (b != null) {
/* 57 */           return bundleState(b.getState(), expectedValue);
/*    */         }
/* 59 */         return false;
/*    */       } 
/*    */     } 
/* 62 */     return false;
/*    */   }
/*    */   
/*    */   private boolean bundleState(int bundleState, Object expectedValue) {
/* 66 */     if ("UNINSTALLED".equals(expectedValue)) {
/* 67 */       return (bundleState == 1);
/*    */     }
/* 69 */     if ("INSTALLED".equals(expectedValue)) {
/* 70 */       return (bundleState == 2);
/*    */     }
/* 72 */     if ("RESOLVED".equals(expectedValue)) {
/* 73 */       return (bundleState == 4);
/*    */     }
/* 75 */     if ("STARTING".equals(expectedValue)) {
/* 76 */       return (bundleState == 8);
/*    */     }
/* 78 */     if ("STOPPING".equals(expectedValue)) {
/* 79 */       return (bundleState == 16);
/*    */     }
/* 81 */     if ("ACTIVE".equals(expectedValue)) {
/* 82 */       return (bundleState == 32);
/*    */     }
/* 84 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\propertytester\PlatformPropertyTester.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */