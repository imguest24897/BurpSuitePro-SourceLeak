/*    */ package org.eclipse.core.internal.expressions;
/*    */ 
/*    */ import org.eclipse.core.expressions.IPropertyTester;
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Property
/*    */ {
/*    */   private final Class<?> fType;
/*    */   private final String fNamespace;
/*    */   private final String fName;
/*    */   private IPropertyTester fTester;
/*    */   
/*    */   Property(Class<?> type, String namespace, String name) {
/* 32 */     Assert.isNotNull(type);
/* 33 */     Assert.isNotNull(namespace);
/* 34 */     Assert.isNotNull(name);
/*    */     
/* 36 */     this.fType = type;
/* 37 */     this.fNamespace = namespace;
/* 38 */     this.fName = name;
/*    */   }
/*    */   
/*    */   void setPropertyTester(IPropertyTester tester) {
/* 42 */     Assert.isNotNull(tester);
/* 43 */     this.fTester = tester;
/*    */   }
/*    */   
/*    */   public boolean isInstantiated() {
/* 47 */     return this.fTester.isInstantiated();
/*    */   }
/*    */   
/*    */   public boolean isDeclaringPluginActive() {
/* 51 */     return this.fTester.isDeclaringPluginActive();
/*    */   }
/*    */   
/*    */   public boolean isValidCacheEntry(boolean forcePluginActivation) {
/* 55 */     if (forcePluginActivation) {
/* 56 */       return (isInstantiated() && isDeclaringPluginActive());
/*    */     }
/* 58 */     return !((!isInstantiated() || !isDeclaringPluginActive()) && (
/* 59 */       isInstantiated() || isDeclaringPluginActive()));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean test(Object receiver, Object[] args, Object expectedValue) throws CoreException {
/*    */     try {
/* 65 */       return this.fTester.test(receiver, this.fName, args, expectedValue);
/* 66 */     } catch (Exception e) {
/* 67 */       String message = "Error evaluating " + this;
/* 68 */       throw new CoreException(new Status(4, Property.class, message, e));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 74 */     if (!(obj instanceof Property))
/* 75 */       return false; 
/* 76 */     Property other = (Property)obj;
/* 77 */     return (this.fType.equals(other.fType) && this.fNamespace.equals(other.fNamespace) && this.fName.equals(other.fName));
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 82 */     return this.fType.hashCode() << 16 | this.fNamespace.hashCode() << 8 | this.fName.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 87 */     StringBuilder builder = new StringBuilder();
/* 88 */     builder.append("Property [");
/* 89 */     builder.append(this.fNamespace);
/* 90 */     builder.append(".");
/* 91 */     builder.append(this.fName);
/* 92 */     builder.append(", type=");
/* 93 */     builder.append(this.fType);
/* 94 */     if (this.fTester != null) {
/* 95 */       builder.append(", tester=");
/* 96 */       builder.append(this.fTester);
/*    */     } 
/* 98 */     builder.append("]");
/* 99 */     return builder.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\Property.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */