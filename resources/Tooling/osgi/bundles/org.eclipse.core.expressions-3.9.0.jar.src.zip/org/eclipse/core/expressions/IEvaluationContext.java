/*    */ package org.eclipse.core.expressions;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IEvaluationContext
/*    */ {
/* 43 */   public static final Object UNDEFINED_VARIABLE = new Object();
/*    */   
/*    */   IEvaluationContext getParent();
/*    */   
/*    */   IEvaluationContext getRoot();
/*    */   
/*    */   void setAllowPluginActivation(boolean paramBoolean);
/*    */   
/*    */   boolean getAllowPluginActivation();
/*    */   
/*    */   Object getDefaultVariable();
/*    */   
/*    */   void addVariable(String paramString, Object paramObject);
/*    */   
/*    */   Object removeVariable(String paramString);
/*    */   
/*    */   Object getVariable(String paramString);
/*    */   
/*    */   Object resolveVariable(String paramString, Object[] paramArrayOfObject) throws CoreException;
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\IEvaluationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */