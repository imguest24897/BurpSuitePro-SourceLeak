package org.eclipse.core.expressions;

public final class ExpressionTagNames {
  public static final String ENABLEMENT = "enablement";
  
  public static final String AND = "and";
  
  public static final String OR = "or";
  
  public static final String NOT = "not";
  
  public static final String INSTANCEOF = "instanceof";
  
  public static final String TEST = "test";
  
  public static final String WITH = "with";
  
  public static final String ADAPT = "adapt";
  
  public static final String COUNT = "count";
  
  public static final String ITERATE = "iterate";
  
  public static final String RESOLVE = "resolve";
  
  public static final String SYSTEM_TEST = "systemTest";
  
  public static final String EQUALS = "equals";
  
  public static final String REFERENCE = "reference";
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\ExpressionTagNames.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */