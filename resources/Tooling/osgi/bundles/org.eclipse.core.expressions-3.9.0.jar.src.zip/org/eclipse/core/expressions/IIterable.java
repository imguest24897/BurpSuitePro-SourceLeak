package org.eclipse.core.expressions;

import java.util.Iterator;

public interface IIterable<T> {
  Iterator<T> iterator();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\IIterable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */