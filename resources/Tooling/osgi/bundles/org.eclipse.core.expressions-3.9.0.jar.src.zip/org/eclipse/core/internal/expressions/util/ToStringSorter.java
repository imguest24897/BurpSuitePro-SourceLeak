/*    */ package org.eclipse.core.internal.expressions.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ToStringSorter
/*    */ {
/*    */   Object[] sortedObjects;
/*    */   String[] sortedStrings;
/*    */   
/*    */   public boolean compare(String stringOne, String stringTwo) {
/* 37 */     return (stringOne.compareTo(stringTwo) < 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void quickSort(int left, int right) {
/* 46 */     int originalLeft = left;
/* 47 */     int originalRight = right;
/* 48 */     int midIndex = (left + right) / 2;
/* 49 */     String midToString = this.sortedStrings[midIndex];
/*    */     while (true) {
/*    */       while (true) {
/* 52 */         if (!compare(this.sortedStrings[left], midToString))
/*    */         
/* 54 */         { while (compare(midToString, this.sortedStrings[right]))
/* 55 */             right--; 
/* 56 */           if (left <= right) {
/* 57 */             Object tmp = this.sortedObjects[left];
/* 58 */             this.sortedObjects[left] = this.sortedObjects[right];
/* 59 */             this.sortedObjects[right] = tmp;
/* 60 */             String tmpToString = this.sortedStrings[left];
/* 61 */             this.sortedStrings[left] = this.sortedStrings[right];
/* 62 */             this.sortedStrings[right] = tmpToString;
/* 63 */             left++;
/* 64 */             right--;
/*    */           } 
/* 66 */           if (left > right)
/*    */             break;  continue; }  left++;
/* 68 */       }  if (originalLeft < right)
/* 69 */         quickSort(originalLeft, right); 
/* 70 */       if (left < originalRight) {
/* 71 */         quickSort(left, originalRight);
/*    */       }
/*    */       return;
/*    */     } 
/*    */     left++;
/*    */     continue;
/*    */   }
/*    */ 
/*    */   
/*    */   public void sort(Object[] unSortedObjects, String[] unsortedStrings) {
/* 81 */     int size = unSortedObjects.length;
/* 82 */     this.sortedObjects = new Object[size];
/* 83 */     this.sortedStrings = new String[size];
/*    */ 
/*    */     
/* 86 */     System.arraycopy(unSortedObjects, 0, this.sortedObjects, 0, size);
/* 87 */     System.arraycopy(unsortedStrings, 0, this.sortedStrings, 0, size);
/* 88 */     if (size > 1)
/* 89 */       quickSort(0, size - 1); 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expression\\util\ToStringSorter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */