/*    */ package org.eclipse.core.internal.expressions;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import org.eclipse.core.expressions.IEvaluationContext;
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IteratePool
/*    */   implements IEvaluationContext
/*    */ {
/*    */   private Iterator<?> fIterator;
/*    */   private Object fDefaultVariable;
/*    */   private IEvaluationContext fParent;
/*    */   
/*    */   public IteratePool(IEvaluationContext parent, Iterator<?> iterator) {
/* 43 */     Assert.isNotNull(parent);
/* 44 */     Assert.isNotNull(iterator);
/* 45 */     this.fParent = parent;
/* 46 */     this.fIterator = iterator;
/*    */   }
/*    */   
/*    */   public IEvaluationContext getParent() {
/* 50 */     return this.fParent;
/*    */   }
/*    */   
/*    */   public IEvaluationContext getRoot() {
/* 54 */     return this.fParent.getRoot();
/*    */   }
/*    */   
/*    */   public Object getDefaultVariable() {
/* 58 */     return this.fDefaultVariable;
/*    */   }
/*    */   
/*    */   public boolean getAllowPluginActivation() {
/* 62 */     return this.fParent.getAllowPluginActivation();
/*    */   }
/*    */   
/*    */   public void setAllowPluginActivation(boolean value) {
/* 66 */     this.fParent.setAllowPluginActivation(value);
/*    */   }
/*    */   
/*    */   public void addVariable(String name, Object value) {
/* 70 */     this.fParent.addVariable(name, value);
/*    */   }
/*    */   
/*    */   public Object removeVariable(String name) {
/* 74 */     return this.fParent.removeVariable(name);
/*    */   }
/*    */   
/*    */   public Object getVariable(String name) {
/* 78 */     return this.fParent.getVariable(name);
/*    */   }
/*    */   
/*    */   public Object resolveVariable(String name, Object[] args) throws CoreException {
/* 82 */     return this.fParent.resolveVariable(name, args);
/*    */   }
/*    */   public Object next() {
/* 85 */     this.fDefaultVariable = this.fIterator.next();
/* 86 */     return this.fDefaultVariable;
/*    */   }
/*    */   public boolean hasNext() {
/* 89 */     return this.fIterator.hasNext();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\IterateExpression$IteratePool.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */