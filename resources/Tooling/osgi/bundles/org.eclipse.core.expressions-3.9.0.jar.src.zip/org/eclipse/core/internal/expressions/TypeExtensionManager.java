/*     */ package org.eclipse.core.internal.expressions;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.expressions.IPropertyTester;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtensionDelta;
/*     */ import org.eclipse.core.runtime.IExtensionRegistry;
/*     */ import org.eclipse.core.runtime.IRegistryChangeEvent;
/*     */ import org.eclipse.core.runtime.IRegistryChangeListener;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeExtensionManager
/*     */   implements IRegistryChangeListener
/*     */ {
/*     */   private static final String EXTENSION_NAMESPACE = "org.eclipse.core.expressions";
/*     */   private String fExtensionPoint;
/*  42 */   private static boolean DEBUG = "true".equalsIgnoreCase(Platform.getDebugOption("org.eclipse.core.expressions/debug/TypeExtensionManager"));
/*     */   
/*     */   private static final String TYPE = "type";
/*     */   
/*  46 */   private static final IPropertyTester[] EMPTY_PROPERTY_TESTER_ARRAY = new IPropertyTester[0];
/*     */   
/*  48 */   private static final IPropertyTester NULL_PROPERTY_TESTER = new IPropertyTester()
/*     */     {
/*     */       public boolean handles(String namespace, String property) {
/*  51 */         return false;
/*     */       }
/*     */       
/*     */       public boolean isInstantiated() {
/*  55 */         return true;
/*     */       }
/*     */       
/*     */       public boolean isDeclaringPluginActive() {
/*  59 */         return true;
/*     */       }
/*     */       
/*     */       public IPropertyTester instantiate() throws CoreException {
/*  63 */         return this;
/*     */       }
/*     */       
/*     */       public boolean test(Object receiver, String property, Object[] args, Object expectedValue) {
/*  67 */         return false;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<Class<?>, TypeExtension> fTypeExtensionMap;
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, List<IConfigurationElement>> fConfigurationElementMap;
/*     */ 
/*     */ 
/*     */   
/*     */   private PropertyCache fPropertyCache;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeExtensionManager(String extensionPoint) {
/*  88 */     Assert.isNotNull(extensionPoint);
/*  89 */     this.fExtensionPoint = extensionPoint;
/*  90 */     Platform.getExtensionRegistry().addRegistryChangeListener(this);
/*  91 */     initializeCaches();
/*     */   }
/*     */   
/*     */   public Property getProperty(Object receiver, String namespace, String method) throws CoreException {
/*  95 */     return getProperty(receiver, namespace, method, false);
/*     */   }
/*     */   
/*     */   public synchronized Property getProperty(Object receiver, String namespace, String method, boolean forcePluginActivation) throws CoreException {
/*  99 */     long start = 0L;
/* 100 */     if (Expressions.TRACING) {
/* 101 */       start = System.currentTimeMillis();
/*     */     }
/*     */     
/* 104 */     Class<?> clazz = (receiver instanceof Class) ? (Class)receiver : receiver.getClass();
/* 105 */     Property result = new Property(clazz, namespace, method);
/* 106 */     Property cached = this.fPropertyCache.get(result);
/* 107 */     if (cached != null) {
/* 108 */       if (cached.isValidCacheEntry(forcePluginActivation)) {
/* 109 */         if (Expressions.TRACING) {
/* 110 */           System.out.println("[Type Extension] - method " + 
/* 111 */               clazz.getName() + "#" + method + 
/* 112 */               " found in cache: " + (
/* 113 */               System.currentTimeMillis() - start) + " ms.");
/*     */         }
/* 115 */         return cached;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 120 */       this.fPropertyCache.remove(cached);
/*     */     } 
/* 122 */     TypeExtension extension = get(clazz);
/* 123 */     IPropertyTester extender = extension.findTypeExtender(this, namespace, method, receiver instanceof Class, forcePluginActivation);
/* 124 */     if (extender == TypeExtension.CONTINUE || extender == null) {
/* 125 */       Throwable t = null;
/* 126 */       if (DEBUG)
/*     */       {
/* 128 */         t = (new Throwable("forcePluginActivation: " + forcePluginActivation + ", receiver: " + receiver)).fillInStackTrace();
/*     */       }
/*     */       
/* 131 */       throw new CoreException(new ExpressionStatus(
/* 132 */             201, 
/* 133 */             Messages.format(
/* 134 */               ExpressionMessages.TypeExtender_unknownMethod, 
/* 135 */               new String[] { String.valueOf(namespace) + '.' + method, clazz.toString()
/* 136 */               }), t));
/*     */     } 
/* 138 */     result.setPropertyTester(extender);
/* 139 */     this.fPropertyCache.put(result);
/* 140 */     if (Expressions.TRACING) {
/* 141 */       System.out.println("[Type Extension] - method " + 
/* 142 */           clazz.getName() + "#" + method + 
/* 143 */           " not found in cache: " + (
/* 144 */           System.currentTimeMillis() - start) + " ms.");
/*     */     }
/* 146 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TypeExtension get(Class<?> clazz) {
/* 154 */     TypeExtension result = this.fTypeExtensionMap.get(clazz);
/* 155 */     if (result == null) {
/* 156 */       result = new TypeExtension(clazz);
/* 157 */       this.fTypeExtensionMap.put(clazz, result);
/*     */     } 
/* 159 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IPropertyTester[] loadTesters(Class<?> type) {
/* 167 */     if (this.fConfigurationElementMap == null) {
/* 168 */       this.fConfigurationElementMap = new HashMap<>();
/* 169 */       IExtensionRegistry registry = Platform.getExtensionRegistry();
/* 170 */       IConfigurationElement[] ces = registry.getConfigurationElementsFor(
/* 171 */           "org.eclipse.core.expressions", this.fExtensionPoint); byte b; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 172 */       for (j = (arrayOfIConfigurationElement1 = ces).length, b = 0; b < j; ) { IConfigurationElement config = arrayOfIConfigurationElement1[b];
/* 173 */         String typeAttr = config.getAttribute("type");
/* 174 */         List<IConfigurationElement> list = this.fConfigurationElementMap.get(typeAttr);
/* 175 */         if (list == null) {
/* 176 */           list = new ArrayList<>();
/* 177 */           this.fConfigurationElementMap.put(typeAttr, list);
/*     */         } 
/* 179 */         list.add(config); b++; }
/*     */     
/*     */     } 
/* 182 */     String typeName = type.getName();
/* 183 */     List<IConfigurationElement> typeConfigs = this.fConfigurationElementMap.get(typeName);
/* 184 */     if (typeConfigs == null) {
/* 185 */       return EMPTY_PROPERTY_TESTER_ARRAY;
/*     */     }
/* 187 */     IPropertyTester[] result = new IPropertyTester[typeConfigs.size()];
/* 188 */     for (int i = 0; i < result.length; i++) {
/* 189 */       IConfigurationElement config = typeConfigs.get(i);
/*     */       try {
/* 191 */         result[i] = new PropertyTesterDescriptor(config);
/* 192 */       } catch (CoreException e) {
/* 193 */         Platform.getLog(TypeExtensionManager.class).log(e.getStatus());
/* 194 */         result[i] = NULL_PROPERTY_TESTER;
/*     */       } 
/*     */     } 
/* 197 */     this.fConfigurationElementMap.remove(typeName);
/* 198 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void registryChanged(IRegistryChangeEvent event) {
/* 204 */     IExtensionDelta[] deltas = event.getExtensionDeltas("org.eclipse.core.expressions", this.fExtensionPoint);
/* 205 */     if (deltas.length > 0) {
/* 206 */       initializeCaches();
/*     */     }
/*     */   }
/*     */   
/*     */   private synchronized void initializeCaches() {
/* 211 */     this.fTypeExtensionMap = new HashMap<>();
/* 212 */     this.fConfigurationElementMap = null;
/* 213 */     this.fPropertyCache = new PropertyCache(1000);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\TypeExtensionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */