/*     */ package org.eclipse.core.internal.expressions;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.expressions.CompositeExpression;
/*     */ import org.eclipse.core.expressions.EvaluationResult;
/*     */ import org.eclipse.core.expressions.Expression;
/*     */ import org.eclipse.core.expressions.ExpressionInfo;
/*     */ import org.eclipse.core.expressions.IEvaluationContext;
/*     */ import org.eclipse.core.expressions.IIterable;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IterateExpression
/*     */   extends CompositeExpression
/*     */ {
/*     */   private static final String ATT_OPERATOR = "operator";
/*     */   private static final String ATT_IF_EMPTY = "ifEmpty";
/*     */   private static final int OR = 1;
/*     */   private static final int AND = 2;
/*     */   
/*     */   private static class IteratePool
/*     */     implements IEvaluationContext
/*     */   {
/*     */     private Iterator<?> fIterator;
/*     */     private Object fDefaultVariable;
/*     */     private IEvaluationContext fParent;
/*     */     
/*     */     public IteratePool(IEvaluationContext parent, Iterator<?> iterator) {
/*  43 */       Assert.isNotNull(parent);
/*  44 */       Assert.isNotNull(iterator);
/*  45 */       this.fParent = parent;
/*  46 */       this.fIterator = iterator;
/*     */     }
/*     */     
/*     */     public IEvaluationContext getParent() {
/*  50 */       return this.fParent;
/*     */     }
/*     */     
/*     */     public IEvaluationContext getRoot() {
/*  54 */       return this.fParent.getRoot();
/*     */     }
/*     */     
/*     */     public Object getDefaultVariable() {
/*  58 */       return this.fDefaultVariable;
/*     */     }
/*     */     
/*     */     public boolean getAllowPluginActivation() {
/*  62 */       return this.fParent.getAllowPluginActivation();
/*     */     }
/*     */     
/*     */     public void setAllowPluginActivation(boolean value) {
/*  66 */       this.fParent.setAllowPluginActivation(value);
/*     */     }
/*     */     
/*     */     public void addVariable(String name, Object value) {
/*  70 */       this.fParent.addVariable(name, value);
/*     */     }
/*     */     
/*     */     public Object removeVariable(String name) {
/*  74 */       return this.fParent.removeVariable(name);
/*     */     }
/*     */     
/*     */     public Object getVariable(String name) {
/*  78 */       return this.fParent.getVariable(name);
/*     */     }
/*     */     
/*     */     public Object resolveVariable(String name, Object[] args) throws CoreException {
/*  82 */       return this.fParent.resolveVariable(name, args);
/*     */     }
/*     */     public Object next() {
/*  85 */       this.fDefaultVariable = this.fIterator.next();
/*  86 */       return this.fDefaultVariable;
/*     */     }
/*     */     public boolean hasNext() {
/*  89 */       return this.fIterator.hasNext();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   private static final int HASH_INITIAL = IterateExpression.class.getName().hashCode();
/*     */   
/*     */   private int fOperator;
/*     */   private Boolean fEmptyResult;
/*     */   
/*     */   public IterateExpression(IConfigurationElement configElement) throws CoreException {
/* 107 */     String opValue = configElement.getAttribute("operator");
/* 108 */     initializeOperatorValue(opValue);
/* 109 */     initializeEmptyResultValue(configElement.getAttribute("ifEmpty"));
/*     */   }
/*     */   
/*     */   public IterateExpression(Element element) throws CoreException {
/* 113 */     String opValue = element.getAttribute("operator");
/* 114 */     initializeOperatorValue(opValue.isEmpty() ? null : opValue);
/* 115 */     String ifEmpty = element.getAttribute("ifEmpty");
/* 116 */     initializeEmptyResultValue(ifEmpty.isEmpty() ? null : ifEmpty);
/*     */   }
/*     */   
/*     */   public IterateExpression(String opValue) throws CoreException {
/* 120 */     initializeOperatorValue(opValue);
/*     */   }
/*     */   
/*     */   public IterateExpression(String opValue, String ifEmpty) throws CoreException {
/* 124 */     initializeOperatorValue(opValue);
/* 125 */     initializeEmptyResultValue(ifEmpty);
/*     */   }
/*     */   
/*     */   private void initializeOperatorValue(String opValue) throws CoreException {
/* 129 */     if (opValue == null) {
/* 130 */       this.fOperator = 2;
/*     */     } else {
/* 132 */       Expressions.checkAttribute("operator", opValue, new String[] { "and", "or" });
/* 133 */       if ("and".equals(opValue)) {
/* 134 */         this.fOperator = 2;
/*     */       } else {
/* 136 */         this.fOperator = 1;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void initializeEmptyResultValue(String value) {
/* 142 */     if (value == null) {
/* 143 */       this.fEmptyResult = null;
/*     */     } else {
/* 145 */       this.fEmptyResult = Boolean.valueOf(value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public EvaluationResult evaluate(IEvaluationContext context) throws CoreException {
/* 151 */     Object var = context.getDefaultVariable();
/* 152 */     if (var instanceof Collection) {
/* 153 */       Collection<?> col = (Collection)var;
/* 154 */       switch (col.size()) {
/*     */         case 0:
/* 156 */           if (this.fEmptyResult == null) {
/* 157 */             return (this.fOperator == 2) ? EvaluationResult.TRUE : EvaluationResult.FALSE;
/*     */           }
/* 159 */           return this.fEmptyResult.booleanValue() ? EvaluationResult.TRUE : EvaluationResult.FALSE;
/*     */         
/*     */         case 1:
/* 162 */           if (col instanceof List)
/* 163 */             return evaluateAnd(new DefaultVariable(context, ((List)col).get(0))); 
/*     */           break;
/*     */       } 
/* 166 */       IteratePool iteratePool = new IteratePool(context, col.iterator());
/* 167 */       EvaluationResult evaluationResult = (this.fOperator == 2) ? EvaluationResult.TRUE : EvaluationResult.FALSE;
/* 168 */       while (iteratePool.hasNext()) {
/* 169 */         iteratePool.next();
/* 170 */         switch (this.fOperator) {
/*     */           case 1:
/* 172 */             evaluationResult = evaluationResult.or(evaluateAnd(iteratePool));
/* 173 */             if (evaluationResult == EvaluationResult.TRUE) {
/* 174 */               return evaluationResult;
/*     */             }
/*     */           case 2:
/* 177 */             evaluationResult = evaluationResult.and(evaluateAnd(iteratePool));
/* 178 */             if (evaluationResult != EvaluationResult.TRUE) {
/* 179 */               return evaluationResult;
/*     */             }
/*     */         } 
/*     */       } 
/* 183 */       return evaluationResult;
/*     */     } 
/*     */     
/* 186 */     IIterable<?> iterable = Expressions.getAsIIterable(var, (Expression)this);
/* 187 */     if (iterable == null)
/* 188 */       return EvaluationResult.NOT_LOADED; 
/* 189 */     int count = 0;
/* 190 */     IteratePool iter = new IteratePool(context, iterable.iterator());
/* 191 */     EvaluationResult result = (this.fOperator == 2) ? EvaluationResult.TRUE : EvaluationResult.FALSE;
/* 192 */     while (iter.hasNext()) {
/* 193 */       iter.next();
/* 194 */       count++;
/* 195 */       switch (this.fOperator) {
/*     */         case 1:
/* 197 */           result = result.or(evaluateAnd(iter));
/* 198 */           if (result == EvaluationResult.TRUE) {
/* 199 */             return result;
/*     */           }
/*     */         case 2:
/* 202 */           result = result.and(evaluateAnd(iter));
/* 203 */           if (result != EvaluationResult.TRUE) {
/* 204 */             return result;
/*     */           }
/*     */       } 
/*     */     } 
/* 208 */     if (count > 0)
/* 209 */       return result; 
/* 210 */     if (this.fEmptyResult == null) {
/* 211 */       return (this.fOperator == 2) ? EvaluationResult.TRUE : EvaluationResult.FALSE;
/*     */     }
/* 213 */     return this.fEmptyResult.booleanValue() ? EvaluationResult.TRUE : EvaluationResult.FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void collectExpressionInfo(ExpressionInfo info) {
/* 223 */     info.markDefaultVariableAccessed();
/* 224 */     super.collectExpressionInfo(info);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object object) {
/* 229 */     if (!(object instanceof IterateExpression)) {
/* 230 */       return false;
/*     */     }
/* 232 */     IterateExpression that = (IterateExpression)object;
/* 233 */     return (this.fOperator == that.fOperator && equals(this.fExpressions, that.fExpressions));
/*     */   }
/*     */ 
/*     */   
/*     */   protected int computeHashCode() {
/* 238 */     return HASH_INITIAL * 89 + hashCode(this.fExpressions) * 
/* 239 */       89 + this.fOperator;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 244 */     StringBuilder builder = new StringBuilder(getClass().getSimpleName());
/* 245 */     builder.append(" [type=").append((this.fOperator == 2) ? "AND" : "OR");
/* 246 */     Expression[] children = getChildren();
/* 247 */     if (children.length > 0) {
/* 248 */       builder.append(", children=");
/* 249 */       builder.append(Arrays.toString((Object[])children));
/*     */     } 
/* 251 */     builder.append("]");
/* 252 */     return builder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\IterateExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */