/*     */ package org.eclipse.core.internal.expressions;
/*     */ 
/*     */ import org.eclipse.core.expressions.IPropertyTester;
/*     */ import org.eclipse.core.expressions.PropertyTester;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeExtension
/*     */ {
/*  24 */   private static final TypeExtension[] EMPTY_TYPE_EXTENSION_ARRAY = new TypeExtension[0];
/*     */ 
/*     */   
/*  27 */   static final IPropertyTester CONTINUE = new IPropertyTester()
/*     */     {
/*     */       public boolean handles(String namespace, String method) {
/*  30 */         return false;
/*     */       }
/*     */       
/*     */       public boolean isInstantiated() {
/*  34 */         return true;
/*     */       }
/*     */       
/*     */       public boolean isDeclaringPluginActive() {
/*  38 */         return true;
/*     */       }
/*     */       
/*     */       public IPropertyTester instantiate() {
/*  42 */         return this;
/*     */       }
/*     */       
/*     */       public boolean test(Object receiver, String method, Object[] args, Object expectedValue) {
/*  46 */         return false;
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*  51 */   private static final TypeExtension END_POINT = new TypeExtension()
/*     */     {
/*     */       IPropertyTester findTypeExtender(TypeExtensionManager manager, String namespace, String name, boolean staticMethod, boolean forcePluginActivation) throws CoreException {
/*  54 */         return CONTINUE;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   private Class<?> fType;
/*     */   
/*     */   private IPropertyTester[] fExtenders;
/*     */   
/*     */   private TypeExtension fExtends;
/*     */   
/*     */   private TypeExtension[] fImplements;
/*     */ 
/*     */   
/*     */   private TypeExtension() {}
/*     */ 
/*     */   
/*     */   TypeExtension(Class<?> type) {
/*  73 */     Assert.isNotNull(type);
/*  74 */     this.fType = type;
/*     */   }
/*     */   
/*     */   IPropertyTester findTypeExtender(TypeExtensionManager manager, String namespace, String method, boolean staticMethod, boolean forcePluginActivation) throws CoreException {
/*  78 */     if (this.fExtenders == null) {
/*  79 */       this.fExtenders = manager.loadTesters(this.fType);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  84 */     for (int i = 0; i < this.fExtenders.length; ) {
/*  85 */       IPropertyTester extender = this.fExtenders[i];
/*  86 */       if (extender == null || !extender.handles(namespace, method)) {
/*     */         i++; continue;
/*  88 */       }  if (extender.isInstantiated())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  95 */         return extender; } 
/*  96 */       if (extender.isDeclaringPluginActive() || forcePluginActivation) {
/*     */         try {
/*  98 */           PropertyTesterDescriptor descriptor = (PropertyTesterDescriptor)extender;
/*  99 */           IPropertyTester inst = descriptor.instantiate();
/* 100 */           ((PropertyTester)inst).internalInitialize(descriptor);
/* 101 */           this.fExtenders[i] = extender = inst;
/* 102 */           return extender;
/* 103 */         } catch (CoreException e) {
/* 104 */           this.fExtenders[i] = null;
/* 105 */           throw e;
/* 106 */         } catch (ClassCastException e) {
/* 107 */           this.fExtenders[i] = null;
/* 108 */           throw new CoreException(new ExpressionStatus(
/* 109 */                 202, 
/* 110 */                 ExpressionMessages.TypeExtender_incorrectType, 
/* 111 */                 e));
/*     */         } 
/*     */       }
/* 114 */       return extender;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 119 */     if (staticMethod) {
/* 120 */       return CONTINUE;
/*     */     }
/*     */     
/* 123 */     if (this.fExtends == null) {
/* 124 */       Class<?> superClass = this.fType.getSuperclass();
/* 125 */       if (superClass != null) {
/* 126 */         this.fExtends = manager.get(superClass);
/*     */       } else {
/* 128 */         this.fExtends = END_POINT;
/*     */       } 
/*     */     } 
/* 131 */     IPropertyTester result = this.fExtends.findTypeExtender(manager, namespace, method, staticMethod, forcePluginActivation);
/* 132 */     if (result != CONTINUE) {
/* 133 */       return result;
/*     */     }
/*     */     
/* 136 */     if (this.fImplements == null) {
/* 137 */       Class[] interfaces = this.fType.getInterfaces();
/* 138 */       if (interfaces.length == 0) {
/* 139 */         this.fImplements = EMPTY_TYPE_EXTENSION_ARRAY;
/*     */       } else {
/* 141 */         this.fImplements = new TypeExtension[interfaces.length];
/* 142 */         for (int k = 0; k < interfaces.length; k++)
/* 143 */           this.fImplements[k] = manager.get(interfaces[k]); 
/*     */       } 
/*     */     }  byte b; int j;
/*     */     TypeExtension[] arrayOfTypeExtension;
/* 147 */     for (j = (arrayOfTypeExtension = this.fImplements).length, b = 0; b < j; ) { TypeExtension fImplement = arrayOfTypeExtension[b];
/* 148 */       result = fImplement.findTypeExtender(manager, namespace, method, staticMethod, forcePluginActivation);
/* 149 */       if (result != CONTINUE)
/* 150 */         return result;  b++; }
/*     */     
/* 152 */     return CONTINUE;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\TypeExtension.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */