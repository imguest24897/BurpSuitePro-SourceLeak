/*    */ package org.eclipse.core.internal.expressions;
/*    */ 
/*    */ import org.eclipse.core.expressions.EvaluationResult;
/*    */ import org.eclipse.core.expressions.Expression;
/*    */ import org.eclipse.core.expressions.ExpressionInfo;
/*    */ import org.eclipse.core.expressions.IEvaluationContext;
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotExpression
/*    */   extends Expression
/*    */ {
/* 28 */   private static final int HASH_INITIAL = NotExpression.class.getName().hashCode();
/*    */   
/*    */   private Expression fExpression;
/*    */   
/*    */   public NotExpression(Expression expression) {
/* 33 */     Assert.isNotNull(expression);
/* 34 */     this.fExpression = expression;
/*    */   }
/*    */ 
/*    */   
/*    */   public EvaluationResult evaluate(IEvaluationContext context) throws CoreException {
/* 39 */     return this.fExpression.evaluate(context).not();
/*    */   }
/*    */ 
/*    */   
/*    */   public void collectExpressionInfo(ExpressionInfo info) {
/* 44 */     this.fExpression.collectExpressionInfo(info);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object object) {
/* 49 */     if (!(object instanceof NotExpression)) {
/* 50 */       return false;
/*    */     }
/* 52 */     NotExpression that = (NotExpression)object;
/* 53 */     return this.fExpression.equals(that.fExpression);
/*    */   }
/*    */ 
/*    */   
/*    */   protected int computeHashCode() {
/* 58 */     return HASH_INITIAL * 89 + this.fExpression.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 63 */     StringBuilder builder = new StringBuilder(getClass().getSimpleName());
/* 64 */     builder.append(" [expression=");
/* 65 */     builder.append(this.fExpression);
/* 66 */     builder.append("]");
/* 67 */     return builder.toString();
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\NotExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */