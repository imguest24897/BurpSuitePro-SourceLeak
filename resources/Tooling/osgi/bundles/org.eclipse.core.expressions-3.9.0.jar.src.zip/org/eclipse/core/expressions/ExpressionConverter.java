/*     */ package org.eclipse.core.expressions;
/*     */ 
/*     */ import org.eclipse.core.internal.expressions.ExpressionMessages;
/*     */ import org.eclipse.core.internal.expressions.Messages;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExpressionConverter
/*     */ {
/*     */   private ElementHandler[] fHandlers;
/*  45 */   private static final ExpressionConverter INSTANCE = new ExpressionConverter(
/*  46 */       new ElementHandler[] { ElementHandler.getDefault() });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ExpressionConverter getDefault() {
/*  56 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExpressionConverter(ElementHandler[] handlers) {
/*  70 */     Assert.isNotNull(handlers);
/*  71 */     this.fHandlers = handlers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression perform(IConfigurationElement root) throws CoreException {
/*     */     byte b;
/*     */     int i;
/*     */     ElementHandler[] arrayOfElementHandler;
/*  89 */     for (i = (arrayOfElementHandler = this.fHandlers).length, b = 0; b < i; ) { ElementHandler handler = arrayOfElementHandler[b];
/*  90 */       Expression result = handler.create(this, root);
/*  91 */       if (result != null)
/*  92 */         return result;  b++; }
/*     */     
/*  94 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression perform(Element root) throws CoreException {
/*     */     byte b;
/*     */     int i;
/*     */     ElementHandler[] arrayOfElementHandler;
/* 113 */     for (i = (arrayOfElementHandler = this.fHandlers).length, b = 0; b < i; ) { ElementHandler handler = arrayOfElementHandler[b];
/* 114 */       Expression result = handler.create(this, root);
/* 115 */       if (result != null)
/* 116 */         return result;  b++; }
/*     */     
/* 118 */     return null;
/*     */   }
/*     */   
/*     */   void processChildren(IConfigurationElement element, CompositeExpression result) throws CoreException {
/* 122 */     IConfigurationElement[] children = element.getChildren();
/* 123 */     if (children != null) {
/* 124 */       byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement; for (i = (arrayOfIConfigurationElement = children).length, b = 0; b < i; ) { IConfigurationElement configElement = arrayOfIConfigurationElement[b];
/* 125 */         Expression child = perform(configElement);
/* 126 */         if (child == null)
/* 127 */           throw new CoreException(new Status(4, ExpressionConverter.class, 
/* 128 */                 4, 
/* 129 */                 Messages.format(
/* 130 */                   ExpressionMessages.Expression_unknown_element, 
/* 131 */                   getDebugPath(configElement)), 
/* 132 */                 null)); 
/* 133 */         result.add(child);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */   private String getDebugPath(IConfigurationElement configurationElement) {
/* 139 */     StringBuilder buf = new StringBuilder();
/* 140 */     buf.append(configurationElement.getName());
/* 141 */     Object parent = configurationElement.getParent();
/* 142 */     while (parent != null) {
/* 143 */       if (parent instanceof IConfigurationElement) {
/* 144 */         buf.append(" > ");
/* 145 */         IConfigurationElement parent2 = (IConfigurationElement)parent;
/* 146 */         buf.append(parent2.getName());
/* 147 */         String id = parent2.getAttribute("id");
/* 148 */         if (id != null)
/* 149 */           buf.append(" (id=").append(id).append(')'); 
/* 150 */         parent = parent2.getParent(); continue;
/* 151 */       }  if (parent instanceof IExtension) {
/* 152 */         IExtension parent2 = (IExtension)parent;
/* 153 */         buf.append(" : ");
/* 154 */         buf.append(parent2.getExtensionPointUniqueIdentifier());
/* 155 */         buf.append(" @ ");
/* 156 */         buf.append(parent2.getContributor().getName());
/* 157 */         parent = null; continue;
/*     */       } 
/* 159 */       parent = null;
/*     */     } 
/*     */     
/* 162 */     return buf.toString();
/*     */   }
/*     */   
/*     */   void processChildren(Element element, CompositeExpression result) throws CoreException {
/* 166 */     Node child = element.getFirstChild();
/* 167 */     while (child != null) {
/* 168 */       if (child.getNodeType() == 1) {
/* 169 */         Expression exp = perform((Element)child);
/* 170 */         if (exp == null)
/* 171 */           throw new CoreException(new Status(4, ExpressionConverter.class, 
/* 172 */                 4, 
/* 173 */                 Messages.format(
/* 174 */                   ExpressionMessages.Expression_unknown_element, 
/* 175 */                   child.getNodeName()), 
/* 176 */                 null)); 
/* 177 */         result.add(exp);
/*     */       } 
/* 179 */       child = child.getNextSibling();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\ExpressionConverter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */