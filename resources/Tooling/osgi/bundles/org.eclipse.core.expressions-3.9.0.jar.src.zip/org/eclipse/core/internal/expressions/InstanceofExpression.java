/*    */ package org.eclipse.core.internal.expressions;
/*    */ 
/*    */ import org.eclipse.core.expressions.EvaluationResult;
/*    */ import org.eclipse.core.expressions.Expression;
/*    */ import org.eclipse.core.expressions.ExpressionInfo;
/*    */ import org.eclipse.core.expressions.IEvaluationContext;
/*    */ import org.eclipse.core.runtime.Assert;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InstanceofExpression
/*    */   extends Expression
/*    */ {
/* 31 */   private static final int HASH_INITIAL = InstanceofExpression.class.getName().hashCode();
/*    */   
/*    */   private String fTypeName;
/*    */   
/*    */   public InstanceofExpression(IConfigurationElement element) throws CoreException {
/* 36 */     this.fTypeName = element.getAttribute("value");
/* 37 */     Expressions.checkAttribute("value", this.fTypeName);
/*    */   }
/*    */   
/*    */   public InstanceofExpression(Element element) throws CoreException {
/* 41 */     this.fTypeName = element.getAttribute("value");
/* 42 */     Expressions.checkAttribute("value", this.fTypeName.isEmpty() ? null : this.fTypeName);
/*    */   }
/*    */   
/*    */   public InstanceofExpression(String typeName) {
/* 46 */     Assert.isNotNull(typeName);
/* 47 */     this.fTypeName = typeName;
/*    */   }
/*    */ 
/*    */   
/*    */   public EvaluationResult evaluate(IEvaluationContext context) {
/* 52 */     Object element = context.getDefaultVariable();
/* 53 */     return EvaluationResult.valueOf(Expressions.isInstanceOf(element, this.fTypeName));
/*    */   }
/*    */ 
/*    */   
/*    */   public void collectExpressionInfo(ExpressionInfo info) {
/* 58 */     info.markDefaultVariableAccessed();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object object) {
/* 63 */     if (!(object instanceof InstanceofExpression)) {
/* 64 */       return false;
/*    */     }
/* 66 */     InstanceofExpression that = (InstanceofExpression)object;
/* 67 */     return this.fTypeName.equals(that.fTypeName);
/*    */   }
/*    */ 
/*    */   
/*    */   protected int computeHashCode() {
/* 72 */     return HASH_INITIAL * 89 + this.fTypeName.hashCode();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 79 */     return "<instanceof value=\"" + this.fTypeName + "\"/>";
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\internal\expressions\InstanceofExpression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */