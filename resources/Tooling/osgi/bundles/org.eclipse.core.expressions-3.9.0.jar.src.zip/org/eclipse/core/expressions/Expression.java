/*     */ package org.eclipse.core.expressions;
/*     */ 
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Expression
/*     */ {
/*     */   protected static final int HASH_CODE_NOT_COMPUTED = -1;
/*     */   protected static final int HASH_FACTOR = 89;
/*     */   protected static final String ATT_VALUE = "value";
/*     */   
/*     */   protected static final boolean equals(Object left, Object right) {
/*  46 */     return (left == null) ? ((right == null)) : ((right != null && left
/*  47 */       .equals(right)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final boolean equals(Object[] leftArray, Object[] rightArray) {
/*  66 */     if (leftArray == rightArray) {
/*  67 */       return true;
/*     */     }
/*     */     
/*  70 */     if (leftArray == null)
/*  71 */       return (rightArray == null); 
/*  72 */     if (rightArray == null) {
/*  73 */       return false;
/*     */     }
/*     */     
/*  76 */     if (leftArray.length != rightArray.length) {
/*  77 */       return false;
/*     */     }
/*     */     
/*  80 */     for (int i = 0; i < leftArray.length; i++) {
/*  81 */       Object left = leftArray[i];
/*  82 */       Object right = rightArray[i];
/*  83 */       boolean equal = (left == null) ? ((right == null)) : left.equals(right);
/*  84 */       if (!equal) {
/*  85 */         return false;
/*     */       }
/*     */     } 
/*     */     
/*  89 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int hashCode(Object object) {
/* 105 */     return (object != null) ? object.hashCode() : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int hashCode(Object[] array) {
/* 120 */     if (array == null) {
/* 121 */       return 0;
/*     */     }
/* 123 */     int hashCode = array.getClass().getName().hashCode(); byte b; int i; Object[] arrayOfObject;
/* 124 */     for (i = (arrayOfObject = array).length, b = 0; b < i; ) { Object element = arrayOfObject[b];
/* 125 */       hashCode = hashCode * 89 + hashCode(element); b++; }
/*     */     
/* 127 */     return hashCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   public static final Expression TRUE = new Expression()
/*     */     {
/*     */       public EvaluationResult evaluate(IEvaluationContext context) {
/* 152 */         return EvaluationResult.TRUE;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public void collectExpressionInfo(ExpressionInfo info) {}
/*     */     };
/*     */ 
/*     */ 
/*     */   
/* 162 */   public static final Expression FALSE = new Expression()
/*     */     {
/*     */       public EvaluationResult evaluate(IEvaluationContext context) {
/* 165 */         return EvaluationResult.FALSE;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void collectExpressionInfo(ExpressionInfo info) {}
/*     */     };
/*     */ 
/*     */ 
/*     */   
/* 176 */   private transient int fHashCode = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract EvaluationResult evaluate(IEvaluationContext paramIEvaluationContext) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ExpressionInfo computeExpressionInfo() {
/* 203 */     ExpressionInfo result = new ExpressionInfo();
/* 204 */     collectExpressionInfo(result);
/* 205 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void collectExpressionInfo(ExpressionInfo info) {
/* 219 */     info.addMisBehavingExpressionType(getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int computeHashCode() {
/* 235 */     return super.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 240 */     if (this.fHashCode != -1)
/* 241 */       return this.fHashCode; 
/* 242 */     this.fHashCode = computeHashCode();
/* 243 */     if (this.fHashCode == -1)
/* 244 */       this.fHashCode++; 
/* 245 */     return this.fHashCode;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.expressions-3.9.0.jar!\org\eclipse\core\expressions\Expression.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */