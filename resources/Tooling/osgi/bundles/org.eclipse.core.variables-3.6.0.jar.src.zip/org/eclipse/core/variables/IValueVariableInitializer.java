package org.eclipse.core.variables;

public interface IValueVariableInitializer {
  void initialize(IValueVariable paramIValueVariable);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.variables-3.6.0.jar!\org\eclipse\core\variables\IValueVariableInitializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */