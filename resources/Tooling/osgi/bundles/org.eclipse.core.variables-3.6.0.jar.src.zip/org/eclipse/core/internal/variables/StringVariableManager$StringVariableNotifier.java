/*     */ package org.eclipse.core.internal.variables;
/*     */ 
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.variables.IValueVariable;
/*     */ import org.eclipse.core.variables.IValueVariableListener;
/*     */ import org.eclipse.core.variables.VariablesPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StringVariableNotifier
/*     */   implements ISafeRunnable
/*     */ {
/*     */   private IValueVariableListener fListener;
/*     */   private int fType;
/*     */   private IValueVariable[] fVariables;
/*     */   
/*     */   public void handleException(Throwable exception) {
/* 131 */     Status status = new Status(4, VariablesPlugin.getUniqueIdentifier(), 120, "An exception occurred during string variable change notification", exception);
/* 132 */     VariablesPlugin.log((IStatus)status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() throws Exception {
/* 140 */     switch (this.fType) {
/*     */       case 0:
/* 142 */         this.fListener.variablesAdded(this.fVariables);
/*     */         break;
/*     */       case 2:
/* 145 */         this.fListener.variablesRemoved(this.fVariables);
/*     */         break;
/*     */       case 1:
/* 148 */         this.fListener.variablesChanged(this.fVariables);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void notify(IValueVariable[] variables, int update) {
/* 162 */     this.fVariables = variables;
/* 163 */     this.fType = update;
/* 164 */     for (IValueVariableListener iValueVariableListener : StringVariableManager.this.fListeners) {
/* 165 */       this.fListener = iValueVariableListener;
/* 166 */       SafeRunner.run(this);
/*     */     } 
/* 168 */     this.fVariables = null;
/* 169 */     this.fListener = null;
/*     */     
/* 171 */     StringVariableManager.this.storeValueVariables();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.variables-3.6.0.jar!\org\eclipse\core\internal\variables\StringVariableManager$StringVariableNotifier.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */