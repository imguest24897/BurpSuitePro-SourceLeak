package org.eclipse.core.variables;

import org.eclipse.core.runtime.CoreException;

public interface IStringVariableManager {
  public static final String EXTENSION_POINT_DYNAMIC_VARIABLES = "dynamicVariables";
  
  public static final String EXTENSION_POINT_VALUE_VARIABLES = "valueVariables";
  
  IStringVariable[] getVariables();
  
  IValueVariable[] getValueVariables();
  
  IValueVariable getValueVariable(String paramString);
  
  IDynamicVariable[] getDynamicVariables();
  
  IDynamicVariable getDynamicVariable(String paramString);
  
  String getContributingPluginId(IStringVariable paramIStringVariable);
  
  String performStringSubstitution(String paramString) throws CoreException;
  
  String performStringSubstitution(String paramString, boolean paramBoolean) throws CoreException;
  
  void validateStringVariables(String paramString) throws CoreException;
  
  IValueVariable newValueVariable(String paramString1, String paramString2);
  
  IValueVariable newValueVariable(String paramString1, String paramString2, boolean paramBoolean, String paramString3);
  
  void addVariables(IValueVariable[] paramArrayOfIValueVariable) throws CoreException;
  
  void removeVariables(IValueVariable[] paramArrayOfIValueVariable);
  
  void addValueVariableListener(IValueVariableListener paramIValueVariableListener);
  
  void removeValueVariableListener(IValueVariableListener paramIValueVariableListener);
  
  String generateVariableExpression(String paramString1, String paramString2);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.variables-3.6.0.jar!\org\eclipse\core\variables\IStringVariableManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */