/*    */ package org.eclipse.core.internal.variables;
/*    */ 
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.core.runtime.Status;
/*    */ import org.eclipse.core.variables.IDynamicVariable;
/*    */ import org.eclipse.core.variables.IDynamicVariableResolver;
/*    */ import org.eclipse.core.variables.VariablesPlugin;
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DynamicVariable
/*    */   extends StringVariable
/*    */   implements IDynamicVariable
/*    */ {
/*    */   private IDynamicVariableResolver fResolver;
/*    */   
/*    */   public String getValue(String argument) throws CoreException {
/* 37 */     if (!supportsArgument())
/*    */     {
/* 39 */       if (argument != null && argument.length() > 0) {
/* 40 */         throw new CoreException(new Status(4, VariablesPlugin.getUniqueIdentifier(), 120, NLS.bind(VariablesMessages.DynamicVariable_0, new String[] { argument, getName() }), null));
/*    */       }
/*    */     }
/* 43 */     if (this.fResolver == null) {
/* 44 */       String name = getConfigurationElement().getAttribute("resolver");
/* 45 */       if (name == null) {
/* 46 */         throw new CoreException(new Status(4, VariablesPlugin.getUniqueIdentifier(), 120, NLS.bind("Contributed context variable {0} must specify a resolver.", new String[] { getName() }), null));
/*    */       }
/* 48 */       Object object = getConfigurationElement().createExecutableExtension("resolver");
/* 49 */       if (object instanceof IDynamicVariableResolver) {
/* 50 */         this.fResolver = (IDynamicVariableResolver)object;
/*    */       } else {
/* 52 */         throw new CoreException(new Status(4, VariablesPlugin.getUniqueIdentifier(), 120, NLS.bind("Contributed context variable resolver for {0} must be an instance of IContextVariableResolver.", new String[] { getName() }), null));
/*    */       } 
/*    */     } 
/*    */     try {
/* 56 */       return this.fResolver.resolveValue(this, argument);
/* 57 */     } catch (RuntimeException e) {
/* 58 */       throw new CoreException(new Status(4, VariablesPlugin.getUniqueIdentifier(), 120, NLS.bind("Error while evaluating variable {0}.", new String[] { getName() }), e));
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DynamicVariable(String name, String description, IConfigurationElement configurationElement) {
/* 70 */     super(name, description, configurationElement);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supportsArgument() {
/* 75 */     String arg = getConfigurationElement().getAttribute("supportsArgument");
/* 76 */     return !(arg != null && !Boolean.parseBoolean(arg));
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.variables-3.6.0.jar!\org\eclipse\core\internal\variables\DynamicVariable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */