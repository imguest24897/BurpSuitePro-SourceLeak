package org.eclipse.core.variables;

public interface IStringVariable {
  String getName();
  
  String getDescription();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.variables-3.6.0.jar!\org\eclipse\core\variables\IStringVariable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */