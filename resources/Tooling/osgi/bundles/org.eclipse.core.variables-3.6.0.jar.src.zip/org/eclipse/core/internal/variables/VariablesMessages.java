/*    */ package org.eclipse.core.internal.variables;
/*    */ 
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VariablesMessages
/*    */   extends NLS
/*    */ {
/*    */   private static final String BUNDLE_NAME = "org.eclipse.core.internal.variables.VariablesMessages";
/*    */   public static String StringSubstitutionEngine_3;
/*    */   public static String StringSubstitutionEngine_4;
/*    */   public static String StringVariableManager_26;
/*    */   public static String StringVariableManager_27;
/*    */   public static String DynamicVariable_0;
/*    */   
/*    */   static {
/* 31 */     NLS.initializeMessages("org.eclipse.core.internal.variables.VariablesMessages", VariablesMessages.class);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.variables-3.6.0.jar!\org\eclipse\core\internal\variables\VariablesMessages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */