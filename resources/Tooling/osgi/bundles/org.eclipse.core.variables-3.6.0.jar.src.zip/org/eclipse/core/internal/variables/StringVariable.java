/*    */ package org.eclipse.core.internal.variables;
/*    */ 
/*    */ import org.eclipse.core.runtime.IConfigurationElement;
/*    */ import org.eclipse.core.variables.IStringVariable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class StringVariable
/*    */   implements IStringVariable
/*    */ {
/*    */   private String fName;
/*    */   private String fDescription;
/*    */   private IConfigurationElement fConfigurationElement;
/*    */   
/*    */   public StringVariable(String name, String description, IConfigurationElement configurationElement) {
/* 48 */     this.fName = name;
/* 49 */     this.fDescription = description;
/* 50 */     this.fConfigurationElement = configurationElement;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 55 */     return this.fName;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 60 */     return this.fDescription;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected IConfigurationElement getConfigurationElement() {
/* 70 */     return this.fConfigurationElement;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setDescription(String description) {
/* 78 */     this.fDescription = description;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.variables-3.6.0.jar!\org\eclipse\core\internal\variables\StringVariable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */