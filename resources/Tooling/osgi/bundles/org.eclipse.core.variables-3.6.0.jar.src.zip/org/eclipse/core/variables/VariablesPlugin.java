/*     */ package org.eclipse.core.variables;
/*     */ 
/*     */ import org.eclipse.core.internal.variables.StringVariableManager;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Plugin;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VariablesPlugin
/*     */   extends Plugin
/*     */ {
/*     */   public static final int INTERNAL_ERROR = 120;
/*     */   public static final int REFERENCE_CYCLE_ERROR = 130;
/*     */   private static VariablesPlugin plugin;
/*     */   public static final String PI_CORE_VARIABLES = "org.eclipse.core.variables";
/*     */   
/*     */   public VariablesPlugin() {
/*  62 */     plugin = this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VariablesPlugin getDefault() {
/*  71 */     return plugin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void log(Throwable t) {
/*  80 */     log((IStatus)new Status(4, "org.eclipse.core.variables", 120, "Error logged from Core Variables: ", t));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void logMessage(String message, Throwable throwable) {
/*  90 */     log((IStatus)new Status(4, getUniqueIdentifier(), 120, message, throwable));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void log(IStatus status) {
/*  99 */     getDefault().getLog().log(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getUniqueIdentifier() {
/* 107 */     return "org.eclipse.core.variables";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStringVariableManager getStringVariableManager() {
/* 116 */     return (IStringVariableManager)StringVariableManager.getDefault();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.variables-3.6.0.jar!\org\eclipse\core\variables\VariablesPlugin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */