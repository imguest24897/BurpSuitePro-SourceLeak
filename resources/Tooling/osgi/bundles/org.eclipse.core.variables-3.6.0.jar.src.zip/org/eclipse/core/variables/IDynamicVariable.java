package org.eclipse.core.variables;

import org.eclipse.core.runtime.CoreException;

public interface IDynamicVariable extends IStringVariable {
  String getValue(String paramString) throws CoreException;
  
  boolean supportsArgument();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.variables-3.6.0.jar!\org\eclipse\core\variables\IDynamicVariable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */