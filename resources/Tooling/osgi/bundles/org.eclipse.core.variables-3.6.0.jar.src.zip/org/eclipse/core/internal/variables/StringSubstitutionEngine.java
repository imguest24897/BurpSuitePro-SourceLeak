/*     */ package org.eclipse.core.internal.variables;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Deque;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.variables.IDynamicVariable;
/*     */ import org.eclipse.core.variables.IStringVariableManager;
/*     */ import org.eclipse.core.variables.IValueVariable;
/*     */ import org.eclipse.core.variables.VariablesPlugin;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringSubstitutionEngine
/*     */ {
/*     */   private static final String VARIABLE_START = "${";
/*     */   private static final char VARIABLE_END = '}';
/*     */   private static final char VARIABLE_ARG = ':';
/*     */   private static final int SCAN_FOR_START = 0;
/*     */   private static final int SCAN_FOR_END = 1;
/*     */   private StringBuilder fResult;
/*     */   private boolean fSubs;
/*     */   private Deque<VariableReference> fStack;
/*     */   
/*     */   static class VariableReference
/*     */   {
/*  65 */     private StringBuilder fText = new StringBuilder();
/*     */ 
/*     */     
/*     */     public void append(String text) {
/*  69 */       this.fText.append(text);
/*     */     }
/*     */     
/*     */     public String getText() {
/*  73 */       return this.fText.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String performStringSubstitution(String expression, boolean reportUndefinedVariables, boolean resolveVariables, IStringVariableManager manager) throws CoreException {
/*  91 */     substitute(expression, reportUndefinedVariables, resolveVariables, manager);
/*  92 */     List<HashSet<String>> resolvedVariableSets = new ArrayList<>();
/*  93 */     while (this.fSubs) {
/*  94 */       HashSet<String> resolved = substitute(this.fResult.toString(), reportUndefinedVariables, true, manager);
/*  95 */       for (int i = resolvedVariableSets.size() - 1; i >= 0; i--) {
/*  96 */         HashSet<String> prevSet = resolvedVariableSets.get(i);
/*  97 */         if (prevSet.equals(resolved)) {
/*  98 */           HashSet<String> conflictingSet = new HashSet<>();
/*  99 */           for (; i < resolvedVariableSets.size(); i++) {
/* 100 */             conflictingSet.addAll(resolvedVariableSets.get(i));
/*     */           }
/* 102 */           StringBuilder problemVariableList = new StringBuilder();
/* 103 */           for (String string : conflictingSet) {
/* 104 */             problemVariableList.append(string);
/* 105 */             problemVariableList.append(", ");
/*     */           } 
/* 107 */           problemVariableList.setLength(problemVariableList.length() - 2);
/* 108 */           throw new CoreException(new Status(4, VariablesPlugin.getUniqueIdentifier(), 130, NLS.bind(VariablesMessages.StringSubstitutionEngine_4, new String[] { problemVariableList.toString() }), null));
/*     */         } 
/*     */       } 
/*     */       
/* 112 */       resolvedVariableSets.add(resolved);
/*     */     } 
/* 114 */     return this.fResult.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateStringVariables(String expression, IStringVariableManager manager) throws CoreException {
/* 126 */     performStringSubstitution(expression, true, false, manager);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HashSet<String> substitute(String expression, boolean reportUndefinedVariables, boolean resolveVariables, IStringVariableManager manager) throws CoreException {
/* 141 */     this.fResult = new StringBuilder(expression.length());
/* 142 */     this.fStack = new ArrayDeque<>();
/* 143 */     this.fSubs = false;
/*     */     
/* 145 */     HashSet<String> resolvedVariables = new HashSet<>();
/*     */     
/* 147 */     int pos = 0;
/* 148 */     int state = 0;
/* 149 */     while (pos < expression.length()) {
/* 150 */       int start; int end; VariableReference tos; String substring; String value; switch (state) {
/*     */         case 0:
/* 152 */           start = expression.indexOf("${", pos);
/* 153 */           if (start >= 0) {
/* 154 */             int length = start - pos;
/*     */             
/* 156 */             if (length > 0) {
/* 157 */               this.fResult.append(expression.substring(pos, start));
/*     */             }
/* 159 */             pos = start + 2;
/* 160 */             state = 1;
/*     */             
/* 162 */             this.fStack.push(new VariableReference());
/*     */             continue;
/*     */           } 
/* 165 */           this.fResult.append(expression.substring(pos));
/* 166 */           pos = expression.length();
/*     */ 
/*     */ 
/*     */         
/*     */         case 1:
/* 171 */           start = expression.indexOf("${", pos);
/* 172 */           end = expression.indexOf('}', pos);
/* 173 */           if (end < 0) {
/*     */             
/* 175 */             VariableReference variableReference = this.fStack.peek();
/* 176 */             variableReference.append(expression.substring(pos));
/* 177 */             pos = expression.length(); continue;
/* 178 */           }  if (start >= 0 && start < end) {
/*     */             
/* 180 */             int length = start - pos;
/* 181 */             if (length > 0) {
/* 182 */               VariableReference variableReference = this.fStack.peek();
/* 183 */               variableReference.append(expression.substring(pos, start));
/*     */             } 
/* 185 */             pos = start + 2;
/* 186 */             this.fStack.push(new VariableReference());
/*     */             continue;
/*     */           } 
/* 189 */           tos = this.fStack.pop();
/* 190 */           substring = expression.substring(pos, end);
/* 191 */           tos.append(substring);
/* 192 */           resolvedVariables.add(substring);
/*     */           
/* 194 */           pos = end + 1;
/* 195 */           value = resolve(tos, reportUndefinedVariables, resolveVariables, manager);
/* 196 */           if (value == null) {
/* 197 */             value = "";
/*     */           }
/* 199 */           if (this.fStack.isEmpty()) {
/*     */             
/* 201 */             this.fResult.append(value);
/* 202 */             state = 0;
/*     */             continue;
/*     */           } 
/* 205 */           tos = this.fStack.peek();
/* 206 */           tos.append(value);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 215 */     while (!this.fStack.isEmpty()) {
/* 216 */       VariableReference tos = this.fStack.pop();
/* 217 */       if (this.fStack.isEmpty()) {
/* 218 */         this.fResult.append("${");
/* 219 */         this.fResult.append(tos.getText()); continue;
/*     */       } 
/* 221 */       VariableReference var = this.fStack.peek();
/* 222 */       var.append("${");
/* 223 */       var.append(tos.getText());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 228 */     return resolvedVariables;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String resolve(VariableReference var, boolean reportUndefinedVariables, boolean resolveVariables, IStringVariableManager manager) throws CoreException {
/* 244 */     String text = var.getText();
/* 245 */     int pos = text.indexOf(':');
/* 246 */     String name = null;
/* 247 */     String arg = null;
/* 248 */     if (pos > 0) {
/* 249 */       name = text.substring(0, pos);
/* 250 */       pos++;
/* 251 */       if (pos < text.length()) {
/* 252 */         arg = text.substring(pos);
/*     */       }
/*     */     } else {
/* 255 */       name = text;
/*     */     } 
/* 257 */     IValueVariable valueVariable = manager.getValueVariable(name);
/* 258 */     if (valueVariable == null) {
/* 259 */       IDynamicVariable dynamicVariable = manager.getDynamicVariable(name);
/* 260 */       if (dynamicVariable == null) {
/*     */         
/* 262 */         if (reportUndefinedVariables) {
/* 263 */           throw new CoreException(new Status(4, VariablesPlugin.getUniqueIdentifier(), 120, NLS.bind(VariablesMessages.StringSubstitutionEngine_3, new String[] { name }), null));
/*     */         }
/*     */         
/* 266 */         return getOriginalVarText(var);
/*     */       } 
/*     */       
/* 269 */       if (resolveVariables) {
/* 270 */         this.fSubs = true;
/* 271 */         return dynamicVariable.getValue(arg);
/*     */       } 
/*     */       
/* 274 */       return getOriginalVarText(var);
/*     */     } 
/*     */     
/* 277 */     if (arg == null) {
/* 278 */       if (resolveVariables) {
/* 279 */         this.fSubs = true;
/* 280 */         return valueVariable.getValue();
/*     */       } 
/*     */       
/* 283 */       return getOriginalVarText(var);
/*     */     } 
/*     */     
/* 286 */     throw new CoreException(new Status(4, VariablesPlugin.getUniqueIdentifier(), 120, NLS.bind(VariablesMessages.StringSubstitutionEngine_4, new String[] { valueVariable.getName() }), null));
/*     */   }
/*     */   
/*     */   private String getOriginalVarText(VariableReference var) {
/* 290 */     StringBuilder res = new StringBuilder(var.getText());
/* 291 */     res.insert(0, "${");
/* 292 */     res.append('}');
/* 293 */     return res.toString();
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.variables-3.6.0.jar!\org\eclipse\core\internal\variables\StringSubstitutionEngine.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */