package org.eclipse.core.variables;

public interface IValueVariable extends IStringVariable {
  void setValue(String paramString);
  
  String getValue();
  
  boolean isContributed();
  
  boolean isReadOnly();
  
  void setDescription(String paramString);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.variables-3.6.0.jar!\org\eclipse\core\variables\IValueVariable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */