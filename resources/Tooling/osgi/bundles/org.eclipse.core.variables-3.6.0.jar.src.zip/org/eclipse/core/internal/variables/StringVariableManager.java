/*     */ package org.eclipse.core.internal.variables;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.ISafeRunnable;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.ListenerList;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.SafeRunner;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.preferences.IEclipsePreferences;
/*     */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*     */ import org.eclipse.core.variables.IDynamicVariable;
/*     */ import org.eclipse.core.variables.IStringVariable;
/*     */ import org.eclipse.core.variables.IStringVariableManager;
/*     */ import org.eclipse.core.variables.IValueVariable;
/*     */ import org.eclipse.core.variables.IValueVariableListener;
/*     */ import org.eclipse.core.variables.VariablesPlugin;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ import org.osgi.service.prefs.BackingStoreException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StringVariableManager
/*     */   implements IStringVariableManager, IEclipsePreferences.IPreferenceChangeListener
/*     */ {
/*     */   private Map<String, IDynamicVariable> fDynamicVariables;
/*     */   private Map<String, IStringVariable> fValueVariables;
/*     */   private ListenerList<IValueVariableListener> fListeners;
/*     */   private static final int ADDED = 0;
/*     */   private static final int CHANGED = 1;
/*     */   private static final int REMOVED = 2;
/*     */   private static StringVariableManager fgManager;
/*     */   private boolean fInternalChange = false;
/*     */   private static final String ATTR_NAME = "name";
/*     */   private static final String ATTR_DESCRIPTION = "description";
/*     */   private static final String ATTR_READ_ONLY = "readOnly";
/*     */   private static final String VALUE_VARIABLES_TAG = "valueVariables";
/*     */   private static final String VALUE_VARIABLE_TAG = "valueVariable";
/*     */   private static final String NAME_TAG = "name";
/*     */   private static final String VALUE_TAG = "value";
/*     */   private static final String DESCRIPTION_TAG = "description";
/*     */   private static final String READ_ONLY_TAG = "readOnly";
/*     */   private static final String TRUE_VALUE = "true";
/*     */   private static final String FALSE_VALUE = "false";
/* 114 */   private static final String PREF_VALUE_VARIABLES = String.valueOf(VariablesPlugin.getUniqueIdentifier()) + ".valueVariables";
/*     */ 
/*     */ 
/*     */   
/*     */   class StringVariableNotifier
/*     */     implements ISafeRunnable
/*     */   {
/*     */     private IValueVariableListener fListener;
/*     */ 
/*     */     
/*     */     private int fType;
/*     */ 
/*     */     
/*     */     private IValueVariable[] fVariables;
/*     */ 
/*     */     
/*     */     public void handleException(Throwable exception) {
/* 131 */       Status status = new Status(4, VariablesPlugin.getUniqueIdentifier(), 120, "An exception occurred during string variable change notification", exception);
/* 132 */       VariablesPlugin.log((IStatus)status);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() throws Exception {
/* 140 */       switch (this.fType) {
/*     */         case 0:
/* 142 */           this.fListener.variablesAdded(this.fVariables);
/*     */           break;
/*     */         case 2:
/* 145 */           this.fListener.variablesRemoved(this.fVariables);
/*     */           break;
/*     */         case 1:
/* 148 */           this.fListener.variablesChanged(this.fVariables);
/*     */           break;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void notify(IValueVariable[] variables, int update) {
/* 162 */       this.fVariables = variables;
/* 163 */       this.fType = update;
/* 164 */       for (IValueVariableListener iValueVariableListener : StringVariableManager.this.fListeners) {
/* 165 */         this.fListener = iValueVariableListener;
/* 166 */         SafeRunner.run(this);
/*     */       } 
/* 168 */       this.fVariables = null;
/* 169 */       this.fListener = null;
/*     */       
/* 171 */       StringVariableManager.this.storeValueVariables();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StringVariableNotifier getNotifier() {
/* 181 */     return new StringVariableNotifier();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StringVariableManager getDefault() {
/* 190 */     if (fgManager == null) {
/* 191 */       fgManager = new StringVariableManager();
/*     */     }
/* 193 */     return fgManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StringVariableManager() {
/* 200 */     this.fListeners = new ListenerList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void initialize() {
/* 207 */     if (this.fDynamicVariables == null) {
/* 208 */       this.fInternalChange = true;
/* 209 */       this.fDynamicVariables = new HashMap<>(5);
/* 210 */       this.fValueVariables = new HashMap<>(5);
/* 211 */       loadContributedValueVariables();
/* 212 */       loadPersistedValueVariables();
/* 213 */       loadDynamicVariables();
/* 214 */       InstanceScope.INSTANCE.getNode("org.eclipse.core.variables").addPreferenceChangeListener(this);
/* 215 */       this.fInternalChange = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadDynamicVariables() {
/* 223 */     IExtensionPoint point = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.core.variables", "dynamicVariables");
/* 224 */     IConfigurationElement[] elements = point.getConfigurationElements(); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 225 */     for (i = (arrayOfIConfigurationElement1 = elements).length, b = 0; b < i; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b];
/* 226 */       String name = element.getAttribute("name");
/* 227 */       if (name == null) {
/* 228 */         VariablesPlugin.logMessage(NLS.bind("Variable extension missing required 'name' attribute: {0}", (Object[])new String[] { element.getDeclaringExtension().getLabel() }), null);
/*     */       } else {
/*     */         
/* 231 */         String description = element.getAttribute("description");
/* 232 */         DynamicVariable variable = new DynamicVariable(name, description, element);
/* 233 */         Object old = this.fDynamicVariables.put(variable.getName(), variable);
/* 234 */         if (old != null) {
/* 235 */           DynamicVariable oldVariable = (DynamicVariable)old;
/* 236 */           VariablesPlugin.logMessage(NLS.bind("Dynamic variable extension from bundle ''{0}'' overrides existing extension variable ''{1}'' from bundle ''{2}''", 
/* 237 */                 (Object[])new String[] { element.getDeclaringExtension().getContributor().getName(), oldVariable.getName(), 
/* 238 */                   oldVariable.getConfigurationElement().getDeclaringExtension().getContributor().getName() }), null);
/*     */         } 
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadContributedValueVariables() {
/* 247 */     IExtensionPoint point = Platform.getExtensionRegistry().getExtensionPoint("org.eclipse.core.variables", "valueVariables");
/* 248 */     IConfigurationElement[] elements = point.getConfigurationElements(); byte b; int i; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 249 */     for (i = (arrayOfIConfigurationElement1 = elements).length, b = 0; b < i; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b];
/* 250 */       String name = element.getAttribute("name");
/* 251 */       if (name == null) {
/* 252 */         VariablesPlugin.logMessage(NLS.bind("Variable extension missing required 'name' attribute: {0}", (Object[])new String[] { element.getDeclaringExtension().getLabel() }), null);
/*     */       } else {
/*     */         
/* 255 */         String description = element.getAttribute("description");
/* 256 */         boolean isReadOnly = "true".equals(element.getAttribute("readOnly"));
/*     */         
/* 258 */         IValueVariable variable = new ContributedValueVariable(name, description, isReadOnly, element);
/* 259 */         Object old = this.fValueVariables.put(name, variable);
/* 260 */         if (old != null) {
/* 261 */           StringVariable oldVariable = (StringVariable)old;
/* 262 */           VariablesPlugin.logMessage(NLS.bind("Contributed variable extension from bundle ''{0}'' overrides existing extension variable ''{1}'' from  bundle ''{2}''", 
/* 263 */                 (Object[])new String[] { element.getDeclaringExtension().getContributor().getName(), oldVariable.getName(), 
/* 264 */                   oldVariable.getConfigurationElement().getDeclaringExtension().getContributor().getName() }), null);
/*     */         } 
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadPersistedValueVariables() {
/* 277 */     String variablesString = Platform.getPreferencesService().getString("org.eclipse.core.variables", PREF_VALUE_VARIABLES, "", null);
/* 278 */     if (variablesString.length() == 0) {
/*     */       return;
/*     */     }
/* 281 */     Element root = null;
/*     */     try {
/* 283 */       ByteArrayInputStream stream = new ByteArrayInputStream(variablesString.getBytes(StandardCharsets.UTF_8));
/* 284 */       DocumentBuilder parser = DocumentBuilderFactory.newInstance().newDocumentBuilder();
/* 285 */       parser.setErrorHandler(new DefaultHandler());
/* 286 */       root = parser.parse(stream).getDocumentElement();
/* 287 */     } catch (Exception e) {
/* 288 */       VariablesPlugin.logMessage("An exception occurred while loading persisted value variables.", e);
/*     */       return;
/*     */     } 
/* 291 */     if (!root.getNodeName().equals("valueVariables")) {
/* 292 */       VariablesPlugin.logMessage("Invalid format encountered while loading persisted value variables.", null);
/*     */       return;
/*     */     } 
/* 295 */     NodeList list = root.getChildNodes();
/* 296 */     for (int i = 0, numItems = list.getLength(); i < numItems; i++) {
/* 297 */       Node node = list.item(i);
/* 298 */       if (node.getNodeType() == 1) {
/* 299 */         Element element = (Element)node;
/* 300 */         if (!element.getNodeName().equals("valueVariable")) {
/* 301 */           VariablesPlugin.logMessage(NLS.bind("Invalid XML element encountered while loading value variables: {0}", (Object[])new String[] { node.getNodeName() }), null);
/*     */         } else {
/*     */           
/* 304 */           String name = element.getAttribute("name");
/* 305 */           if (name.length() > 0) {
/* 306 */             String value = element.getAttribute("value");
/* 307 */             String description = element.getAttribute("description");
/* 308 */             boolean readOnly = "true".equals(element.getAttribute("readOnly"));
/*     */             
/* 310 */             IValueVariable existing = getValueVariable(name);
/* 311 */             if (existing == null) {
/* 312 */               ValueVariable variable = new ValueVariable(name, description, readOnly, value);
/* 313 */               this.fValueVariables.put(name, variable);
/* 314 */             } else if (!existing.isReadOnly() && value != null) {
/* 315 */               existing.setValue(value);
/*     */             } 
/*     */           } else {
/* 318 */             VariablesPlugin.logMessage("Invalid variable entry encountered while loading value variables. Variable name is null.", null);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized IStringVariable[] getVariables() {
/* 326 */     initialize();
/* 327 */     List<IStringVariable> list = new ArrayList<>(this.fDynamicVariables.size() + this.fValueVariables.size());
/* 328 */     list.addAll((Collection)this.fDynamicVariables.values());
/* 329 */     list.addAll(this.fValueVariables.values());
/* 330 */     return list.<IStringVariable>toArray(new IStringVariable[list.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized IValueVariable[] getValueVariables() {
/* 335 */     initialize();
/* 336 */     return (IValueVariable[])this.fValueVariables.values().toArray((Object[])new IValueVariable[this.fValueVariables.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized IDynamicVariable[] getDynamicVariables() {
/* 341 */     initialize();
/* 342 */     return (IDynamicVariable[])this.fDynamicVariables.values().toArray((Object[])new IDynamicVariable[this.fDynamicVariables.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public String performStringSubstitution(String expression) throws CoreException {
/* 347 */     return performStringSubstitution(expression, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public IValueVariable newValueVariable(String name, String description) {
/* 352 */     return newValueVariable(name, description, false, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public IValueVariable newValueVariable(String name, String description, boolean readOnly, String value) {
/* 357 */     return new ValueVariable(name, description, readOnly, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void addVariables(IValueVariable[] variables) throws CoreException {
/* 362 */     initialize();
/* 363 */     MultiStatus status = new MultiStatus(VariablesPlugin.getUniqueIdentifier(), 120, VariablesMessages.StringVariableManager_26, null); byte b; int i; IValueVariable[] arrayOfIValueVariable;
/* 364 */     for (i = (arrayOfIValueVariable = variables).length, b = 0; b < i; ) { IValueVariable variable = arrayOfIValueVariable[b];
/* 365 */       if (getValueVariable(variable.getName()) != null)
/* 366 */         status.add((IStatus)new Status(4, VariablesPlugin.getUniqueIdentifier(), 120, NLS.bind(VariablesMessages.StringVariableManager_27, (Object[])new String[] { variable.getName() }), null)); 
/*     */       b++; }
/*     */     
/* 369 */     if (status.isOK()) {
/* 370 */       for (i = (arrayOfIValueVariable = variables).length, b = 0; b < i; ) { IValueVariable variable = arrayOfIValueVariable[b];
/* 371 */         this.fValueVariables.put(variable.getName(), variable); b++; }
/*     */       
/* 373 */       IValueVariable[] copy = new IValueVariable[variables.length];
/* 374 */       System.arraycopy(variables, 0, copy, 0, variables.length);
/* 375 */       getNotifier().notify(copy, 0);
/*     */       return;
/*     */     } 
/* 378 */     throw new CoreException(status);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void removeVariables(IValueVariable[] variables) {
/* 383 */     initialize();
/* 384 */     List<IValueVariable> removed = new ArrayList<>(variables.length); byte b; int i; IValueVariable[] arrayOfIValueVariable;
/* 385 */     for (i = (arrayOfIValueVariable = variables).length, b = 0; b < i; ) { IValueVariable variable = arrayOfIValueVariable[b];
/* 386 */       if (this.fValueVariables.remove(variable.getName()) != null)
/* 387 */         removed.add(variable); 
/*     */       b++; }
/*     */     
/* 390 */     if (removed.size() > 0) {
/* 391 */       getNotifier().notify(removed.<IValueVariable>toArray(new IValueVariable[removed.size()]), 2);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized IDynamicVariable getDynamicVariable(String name) {
/* 397 */     initialize();
/* 398 */     return this.fDynamicVariables.get(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized IValueVariable getValueVariable(String name) {
/* 403 */     initialize();
/* 404 */     return (IValueVariable)this.fValueVariables.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addValueVariableListener(IValueVariableListener listener) {
/* 410 */     this.fListeners.add(listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeValueVariableListener(IValueVariableListener listener) {
/* 415 */     this.fListeners.remove(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getValueVariablesAsXML() throws IOException, ParserConfigurationException, TransformerException {
/* 427 */     IValueVariable[] variables = getValueVariables();
/*     */     
/* 429 */     Document document = getDocument();
/* 430 */     Element rootElement = document.createElement("valueVariables");
/* 431 */     document.appendChild(rootElement); byte b; int i; IValueVariable[] arrayOfIValueVariable1;
/* 432 */     for (i = (arrayOfIValueVariable1 = variables).length, b = 0; b < i; ) { IValueVariable variable = arrayOfIValueVariable1[b];
/* 433 */       if (!variable.isReadOnly())
/*     */       {
/* 435 */         if (!variable.isContributed() || ((ContributedValueVariable)variable).isInitialized()) {
/* 436 */           Element element = document.createElement("valueVariable");
/* 437 */           element.setAttribute("name", variable.getName());
/* 438 */           String value = variable.getValue();
/* 439 */           if (value != null) {
/* 440 */             element.setAttribute("value", value);
/*     */           }
/* 442 */           element.setAttribute("readOnly", variable.isReadOnly() ? "true" : "false");
/* 443 */           String description = variable.getDescription();
/* 444 */           if (description != null) {
/* 445 */             element.setAttribute("description", description);
/*     */           }
/* 447 */           rootElement.appendChild(element);
/*     */         }  } 
/*     */       b++; }
/*     */     
/* 451 */     return serializeDocument(document);
/*     */   }
/*     */   
/*     */   private Document getDocument() throws ParserConfigurationException {
/* 455 */     DocumentBuilderFactory dfactory = DocumentBuilderFactory.newInstance();
/* 456 */     DocumentBuilder docBuilder = dfactory.newDocumentBuilder();
/* 457 */     Document doc = docBuilder.newDocument();
/* 458 */     return doc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String serializeDocument(Document doc) throws TransformerException, UnsupportedEncodingException {
/* 471 */     ByteArrayOutputStream s = new ByteArrayOutputStream();
/*     */     
/* 473 */     TransformerFactory factory = TransformerFactory.newInstance();
/* 474 */     Transformer transformer = factory.newTransformer();
/* 475 */     transformer.setOutputProperty("method", "xml");
/* 476 */     transformer.setOutputProperty("indent", "yes");
/*     */     
/* 478 */     DOMSource source = new DOMSource(doc);
/* 479 */     StreamResult outputTarget = new StreamResult(s);
/* 480 */     transformer.transform(source, outputTarget);
/*     */     
/* 482 */     return s.toString("UTF8");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void storeValueVariables() {
/* 490 */     String variableString = "";
/* 491 */     if (!this.fValueVariables.isEmpty()) {
/*     */       try {
/* 493 */         variableString = getValueVariablesAsXML();
/* 494 */       } catch (IOException e) {
/* 495 */         VariablesPlugin.log((IStatus)new Status(4, VariablesPlugin.getUniqueIdentifier(), 4, "An exception occurred while storing launch configuration variables.", e));
/*     */         return;
/* 497 */       } catch (ParserConfigurationException e) {
/* 498 */         VariablesPlugin.log((IStatus)new Status(4, VariablesPlugin.getUniqueIdentifier(), 4, "An exception occurred while storing launch configuration variables.", e));
/*     */         return;
/* 500 */       } catch (TransformerException e) {
/* 501 */         VariablesPlugin.log((IStatus)new Status(4, VariablesPlugin.getUniqueIdentifier(), 4, "An exception occurred while storing launch configuration variables.", e));
/*     */         return;
/*     */       } 
/*     */     }
/* 505 */     this.fInternalChange = true;
/*     */     try {
/* 507 */       IEclipsePreferences prefs = InstanceScope.INSTANCE.getNode("org.eclipse.core.variables");
/* 508 */       prefs.put(PREF_VALUE_VARIABLES, variableString);
/* 509 */       prefs.flush();
/*     */     }
/* 511 */     catch (BackingStoreException bse) {
/* 512 */       VariablesPlugin.log((Throwable)bse);
/*     */     } 
/* 514 */     this.fInternalChange = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyChanged(IValueVariable variable) {
/* 523 */     if (!this.fInternalChange) {
/* 524 */       IValueVariable existing = getValueVariable(variable.getName());
/* 525 */       if (variable.equals(existing))
/*     */       {
/* 527 */         getNotifier().notify(new IValueVariable[] { variable }, 1);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String generateVariableExpression(String varName, String arg) {
/* 534 */     StringBuilder buffer = new StringBuilder();
/* 535 */     buffer.append("${");
/* 536 */     buffer.append(varName);
/* 537 */     if (arg != null) {
/* 538 */       buffer.append(":");
/* 539 */       buffer.append(arg);
/*     */     } 
/* 541 */     buffer.append("}");
/* 542 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String performStringSubstitution(String expression, boolean reportUndefinedVariables) throws CoreException {
/* 547 */     return (new StringSubstitutionEngine()).performStringSubstitution(expression, reportUndefinedVariables, true, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void validateStringVariables(String expression) throws CoreException {
/* 552 */     (new StringSubstitutionEngine()).validateStringVariables(expression, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContributingPluginId(IStringVariable variable) {
/* 557 */     if (variable instanceof StringVariable) {
/* 558 */       return ((StringVariable)variable).getConfigurationElement().getContributor().getName();
/*     */     }
/* 560 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void preferenceChange(IEclipsePreferences.PreferenceChangeEvent event) {
/* 565 */     if (PREF_VALUE_VARIABLES.equals(event.getKey()))
/* 566 */       synchronized (this) {
/* 567 */         if (!this.fInternalChange) {
/* 568 */           this.fValueVariables.clear();
/* 569 */           loadPersistedValueVariables();
/* 570 */           loadContributedValueVariables();
/*     */         } 
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.variables-3.6.0.jar!\org\eclipse\core\internal\variables\StringVariableManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */