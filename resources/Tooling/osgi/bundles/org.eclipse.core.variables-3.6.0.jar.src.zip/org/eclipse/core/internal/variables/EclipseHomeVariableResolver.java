/*    */ package org.eclipse.core.internal.variables;
/*    */ 
/*    */ import java.net.URL;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ import org.eclipse.core.runtime.Platform;
/*    */ import org.eclipse.core.variables.IDynamicVariable;
/*    */ import org.eclipse.core.variables.IDynamicVariableResolver;
/*    */ import org.eclipse.osgi.service.datalocation.Location;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EclipseHomeVariableResolver
/*    */   implements IDynamicVariableResolver
/*    */ {
/*    */   public String resolveValue(IDynamicVariable variable, String argument) throws CoreException {
/* 36 */     Location installLocation = Platform.getInstallLocation();
/* 37 */     if (installLocation != null) {
/* 38 */       URL url = installLocation.getURL();
/* 39 */       if (url != null) {
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 44 */         String file = url.getFile();
/* 45 */         IPath path = Path.fromOSString(file);
/* 46 */         String osstr = path.toOSString();
/* 47 */         if (osstr.length() != 0) {
/* 48 */           return osstr;
/*    */         }
/*    */         
/* 51 */         if (file.length() != 0) {
/* 52 */           return file;
/*    */         }
/*    */       } 
/*    */     } 
/* 56 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.variables-3.6.0.jar!\org\eclipse\core\internal\variables\EclipseHomeVariableResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */