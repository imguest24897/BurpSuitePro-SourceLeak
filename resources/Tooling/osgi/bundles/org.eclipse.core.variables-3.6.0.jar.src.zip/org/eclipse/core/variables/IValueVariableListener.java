package org.eclipse.core.variables;

public interface IValueVariableListener {
  void variablesAdded(IValueVariable[] paramArrayOfIValueVariable);
  
  void variablesRemoved(IValueVariable[] paramArrayOfIValueVariable);
  
  void variablesChanged(IValueVariable[] paramArrayOfIValueVariable);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.variables-3.6.0.jar!\org\eclipse\core\variables\IValueVariableListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */