/*    */ package org.eclipse.core.internal.variables;
/*    */ 
/*    */ import org.eclipse.core.variables.IValueVariable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValueVariable
/*    */   extends StringVariable
/*    */   implements IValueVariable
/*    */ {
/*    */   private String fValue;
/*    */   private boolean fReadOnly;
/*    */   
/*    */   public ValueVariable(String name, String description, boolean readOnly, String value) {
/* 43 */     super(name, description, null);
/* 44 */     this.fReadOnly = readOnly;
/* 45 */     this.fValue = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(String value) {
/* 50 */     if (!isReadOnly()) {
/* 51 */       this.fValue = value;
/* 52 */       StringVariableManager.getDefault().notifyChanged(this);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String getValue() {
/* 58 */     return this.fValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isReadOnly() {
/* 63 */     return this.fReadOnly;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isContributed() {
/* 68 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.variables-3.6.0.jar!\org\eclipse\core\internal\variables\ValueVariable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */