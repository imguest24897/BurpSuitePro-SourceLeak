/*     */ package org.eclipse.core.internal.variables;
/*     */ 
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.variables.IValueVariable;
/*     */ import org.eclipse.core.variables.IValueVariableInitializer;
/*     */ import org.eclipse.core.variables.VariablesPlugin;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContributedValueVariable
/*     */   extends StringVariable
/*     */   implements IValueVariable
/*     */ {
/*     */   private String fValue;
/*     */   private boolean fInitialized = false;
/*     */   private boolean fReadOnly;
/*     */   
/*     */   public ContributedValueVariable(String name, String description, boolean readOnly, IConfigurationElement configurationElement) {
/*  54 */     super(name, description, configurationElement);
/*  55 */     this.fReadOnly = readOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(String value) {
/*  60 */     if (!isReadOnly() || !isInitialized()) {
/*  61 */       this.fValue = value;
/*  62 */       setInitialized(true);
/*  63 */       StringVariableManager.getDefault().notifyChanged(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValue() {
/*  69 */     if (!isInitialized()) {
/*  70 */       initialize();
/*     */     }
/*  72 */     return this.fValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/*  79 */     if (getConfigurationElement() != null) {
/*     */       
/*  81 */       String value = getConfigurationElement().getAttribute("initialValue");
/*  82 */       if (value == null) {
/*     */         
/*  84 */         String className = getConfigurationElement().getAttribute("initializerClass");
/*  85 */         if (className != null) {
/*     */           try {
/*  87 */             Object object = getConfigurationElement().createExecutableExtension("initializerClass");
/*  88 */             if (object instanceof IValueVariableInitializer) {
/*  89 */               IValueVariableInitializer initializer = (IValueVariableInitializer)object;
/*  90 */               initializer.initialize(this);
/*     */             } else {
/*  92 */               VariablesPlugin.logMessage(NLS.bind("Unable to initialize variable {0} - initializer must be an instance of IValueVariableInitializer.", (Object[])new String[] { getName() }), null);
/*     */             } 
/*  94 */           } catch (CoreException e) {
/*  95 */             VariablesPlugin.logMessage(NLS.bind("Unable to initialize variable {0}", (Object[])new String[] { getName() }), (Throwable)e);
/*     */           } 
/*     */         }
/*     */       } else {
/*  99 */         setValue(value);
/*     */       } 
/*     */     } 
/* 102 */     setInitialized(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isInitialized() {
/* 115 */     return this.fInitialized;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setInitialized(boolean initialized) {
/* 124 */     this.fInitialized = initialized;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly() {
/* 129 */     return this.fReadOnly;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isContributed() {
/* 134 */     return (getConfigurationElement() != null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.variables-3.6.0.jar!\org\eclipse\core\internal\variables\ContributedValueVariable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */