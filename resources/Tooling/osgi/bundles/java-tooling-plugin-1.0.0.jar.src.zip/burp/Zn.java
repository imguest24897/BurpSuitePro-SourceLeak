package burp;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Zn {
  private static final Pattern ZE;
  
  private static final Pattern Za;
  
  public static String Za(String paramString) {
    Matcher matcher = ZE.matcher(paramString);
    String str = paramString;
    boolean bool = Zr.Za;
    while (matcher.find()) {
      String str1 = matcher.group();
      String str2 = Zx(str1);
      str = str.replace(str1, str2);
      if (bool)
        break; 
    } 
    return str;
  }
  
  private static String Zx(String paramString) {
    Matcher matcher = Za.matcher(paramString);
    return matcher.replaceAll("");
  }
  
  static {
    // Byte code:
    //   0: iconst_2
    //   1: anewarray java/lang/String
    //   4: astore_0
    //   5: iconst_0
    //   6: istore #4
    //   8: ldc '?|Q8@1OxsL'
    //   10: dup
    //   11: astore_3
    //   12: invokevirtual length : ()I
    //   15: istore #5
    //   17: bipush #6
    //   19: istore_2
    //   20: iconst_m1
    //   21: istore_1
    //   22: iinc #1, 1
    //   25: aload_3
    //   26: iload_1
    //   27: dup
    //   28: iload_2
    //   29: iadd
    //   30: invokevirtual substring : (II)Ljava/lang/String;
    //   33: iconst_m1
    //   34: goto -> 68
    //   37: aload_0
    //   38: swap
    //   39: iload #4
    //   41: iinc #4, 1
    //   44: swap
    //   45: aastore
    //   46: iload_1
    //   47: iload_2
    //   48: iadd
    //   49: dup
    //   50: istore_1
    //   51: iload #5
    //   53: if_icmpge -> 65
    //   56: aload_3
    //   57: iload_1
    //   58: invokevirtual charAt : (I)C
    //   61: istore_2
    //   62: goto -> 22
    //   65: goto -> 205
    //   68: swap
    //   69: invokevirtual toCharArray : ()[C
    //   72: dup
    //   73: arraylength
    //   74: swap
    //   75: iconst_0
    //   76: istore #6
    //   78: swap
    //   79: dup_x1
    //   80: iconst_1
    //   81: if_icmpgt -> 180
    //   84: dup
    //   85: iload #6
    //   87: dup2
    //   88: caload
    //   89: iload #6
    //   91: bipush #7
    //   93: irem
    //   94: tableswitch default -> 162, 0 -> 132, 1 -> 137, 2 -> 142, 3 -> 147, 4 -> 152, 5 -> 157
    //   132: bipush #100
    //   134: goto -> 164
    //   137: bipush #34
    //   139: goto -> 164
    //   142: bipush #109
    //   144: goto -> 164
    //   147: bipush #56
    //   149: goto -> 164
    //   152: bipush #83
    //   154: goto -> 164
    //   157: bipush #47
    //   159: goto -> 164
    //   162: bipush #98
    //   164: ixor
    //   165: i2c
    //   166: castore
    //   167: iinc #6, 1
    //   170: swap
    //   171: dup_x1
    //   172: ifne -> 180
    //   175: dup2
    //   176: swap
    //   177: goto -> 87
    //   180: swap
    //   181: dup_x1
    //   182: iload #6
    //   184: if_icmpgt -> 84
    //   187: new java/lang/String
    //   190: dup_x1
    //   191: swap
    //   192: invokespecial <init> : ([C)V
    //   195: invokevirtual intern : ()Ljava/lang/String;
    //   198: swap
    //   199: pop
    //   200: swap
    //   201: pop
    //   202: goto -> 37
    //   205: aload_0
    //   206: iconst_0
    //   207: aaload
    //   208: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   211: putstatic burp/Zn.ZE : Ljava/util/regex/Pattern;
    //   214: aload_0
    //   215: iconst_1
    //   216: aaload
    //   217: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   220: putstatic burp/Zn.Za : Ljava/util/regex/Pattern;
    //   223: return
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\java-tooling-plugin-1.0.0.jar!\burp\Zn.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */