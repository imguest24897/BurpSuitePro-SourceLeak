package burp;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.portswigger.javatooling.api.JavadocNode;
import net.portswigger.javatooling.api.JavadocService;
import net.portswigger.javatooling.api.Parameter;
import net.portswigger.javatooling.api.Signature;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IMember;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.ISourceRange;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.Signature;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.AbstractTypeDeclaration;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Javadoc;
import org.eclipse.jdt.internal.codeassist.CompletionEngine;

public class Zr implements JavadocService {
  public final Ze ZV;
  
  public static boolean Za;
  
  private static final String[] a;
  
  private static final String[] b;
  
  public Zr(Ze paramZe) {
    this.ZV = paramZe;
    CompletionEngine.DEBUG = false;
  }
  
  public JavadocNode javadoc(String paramString1, String paramString2, Signature paramSignature) {
    try {
    
    } catch (RuntimeException runtimeException) {
      throw null;
    } 
    String str = (paramString2 == null) ? Optional.<Signature>ofNullable(paramSignature).map(Signature::type).orElse(paramString1) : paramString1;
    try {
    
    } catch (RuntimeException runtimeException) {
      throw null;
    } 
    String[] arrayOfString = (paramSignature == null) ? null : Zb(paramSignature);
    Javadoc javadoc = ZA(str, paramString2, arrayOfString);
    try {
    
    } catch (RuntimeException runtimeException) {
      throw null;
    } 
    return (javadoc == null) ? null : Z_.Zd(javadoc);
  }
  
  private String[] Zb(Signature paramSignature) {
    List list = paramSignature.parameters();
    try {
    
    } catch (RuntimeException runtimeException) {
      throw null;
    } 
    return (list == null) ? null : (String[])list.stream().map(Parameter::type).map(Zr::lambda$parseParameterTypes$0).toArray(Zr::lambda$parseParameterTypes$1);
  }
  
  public Javadoc ZA(String paramString1, String paramString2, String[] paramArrayOfString) {
    try {
      IJavaProject iJavaProject = JavaCore.create(this.ZV.Ze());
      Zy zy = Zy.Zt(iJavaProject, paramString1);
      ISourceRange iSourceRange = ZY(zy, paramString2, paramArrayOfString);
      try {
      
      } catch (JavaModelException javaModelException) {
        throw null;
      } 
      return (iSourceRange == null) ? null : Zu(iJavaProject, zy.Zr(), iSourceRange);
    } catch (JavaModelException javaModelException) {
      throw new RuntimeException(javaModelException);
    } 
  }
  
  private ISourceRange ZY(Zy paramZy, String paramString, String[] paramArrayOfString) throws JavaModelException {
    try {
      if (paramZy != null)
        try {
          if (paramZy.Zr() != null) {
            try {
              if (paramString == null)
                return ZX((IMember)paramZy.Zr()); 
            } catch (JavaModelException javaModelException) {
              throw null;
            } 
            try {
              if (paramArrayOfString == null)
                return ZX((IMember)paramZy.Zr().getField(paramString)); 
            } catch (JavaModelException javaModelException) {
              throw null;
            } 
            ISourceRange iSourceRange = ZX((IMember)paramZy.Zr().getMethod(paramString, paramArrayOfString));
            try {
            
            } catch (JavaModelException javaModelException) {
              throw null;
            } 
            return (iSourceRange == null) ? Zp(paramZy, paramString, paramArrayOfString) : iSourceRange;
          } 
          return null;
        } catch (JavaModelException javaModelException) {
          throw null;
        }  
    } catch (JavaModelException javaModelException) {
      throw null;
    } 
    return null;
  }
  
  private ISourceRange ZX(IMember paramIMember) throws JavaModelException {
    try {
    
    } catch (JavaModelException javaModelException) {
      throw null;
    } 
    return (paramIMember == null) ? null : paramIMember.getJavadocRange();
  }
  
  private ISourceRange Zp(Zy paramZy, String paramString, String[] paramArrayOfString) throws JavaModelException {
    return ZX((IMember)ZI(paramZy, paramString, paramArrayOfString));
  }
  
  private IMethod ZI(Zy paramZy, String paramString, String[] paramArrayOfString) throws JavaModelException {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual Zr : ()Lorg/eclipse/jdt/core/IType;
    //   4: invokeinterface getMethods : ()[Lorg/eclipse/jdt/core/IMethod;
    //   9: invokestatic stream : ([Ljava/lang/Object;)Ljava/util/stream/Stream;
    //   12: aload_1
    //   13: aload_2
    //   14: aload_3
    //   15: <illegal opcode> test : (Lburp/Zy;Ljava/lang/String;[Ljava/lang/String;)Ljava/util/function/Predicate;
    //   20: invokeinterface filter : (Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
    //   25: invokeinterface findFirst : ()Ljava/util/Optional;
    //   30: aconst_null
    //   31: invokevirtual orElse : (Ljava/lang/Object;)Ljava/lang/Object;
    //   34: checkcast org/eclipse/jdt/core/IMethod
    //   37: areturn
  }
  
  private static boolean Zd(IMethod paramIMethod, Zy paramZy, String paramString, String[] paramArrayOfString) {
    boolean bool = Za;
    try {
      if (!paramString.equals(paramIMethod.getElementName()))
        return false; 
    } catch (RuntimeException runtimeException) {
      throw null;
    } 
    try {
      if (paramIMethod.getNumberOfParameters() != paramArrayOfString.length)
        return false; 
    } catch (RuntimeException runtimeException) {
      throw null;
    } 
    String[] arrayOfString = paramIMethod.getParameterTypes();
    byte b = 0;
    while (b < arrayOfString.length) {
      String str = arrayOfString[b];
      for (Map.Entry<String, String> entry : paramZy.ZZ().entrySet()) {
        str = str.replace((CharSequence)entry.getKey(), (CharSequence)entry.getValue());
        if (bool)
          break; 
      } 
      try {
        if (!str.equals(paramArrayOfString[b]))
          return false; 
      } catch (RuntimeException runtimeException) {
        throw null;
      } 
      b++;
      if (bool)
        break; 
    } 
    return true;
  }
  
  private Javadoc Zu(IJavaProject paramIJavaProject, IType paramIType, ISourceRange paramISourceRange) throws JavaModelException {
    String str1 = paramIType.getOpenable().getBuffer().getText(paramISourceRange.getOffset(), paramISourceRange.getLength());
    String str2 = str1 + str1;
    return ZF(paramIJavaProject, str2);
  }
  
  private Javadoc ZF(IJavaProject paramIJavaProject, String paramString) {
    ASTParser aSTParser = ASTParser.newParser(AST.getJLSLatest());
    aSTParser.setProject(paramIJavaProject);
    Map<String, String> map = paramIJavaProject.getOptions(true);
    map.put(a(30841, -1065), a(30840, 30008));
    aSTParser.setCompilerOptions(map);
    aSTParser.setSource(paramString.toCharArray());
    CompilationUnit compilationUnit = (CompilationUnit)aSTParser.createAST(null);
    List<AbstractTypeDeclaration> list = compilationUnit.types();
    try {
      if (compilationUnit.types().isEmpty())
        return null; 
    } catch (RuntimeException runtimeException) {
      throw null;
    } 
    AbstractTypeDeclaration abstractTypeDeclaration = list.get(0);
    return abstractTypeDeclaration.getJavadoc();
  }
  
  private static List<String> ZY(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic ZO : (Ljava/lang/String;)Ljava/lang/String;
    //   4: astore_2
    //   5: new java/util/ArrayList
    //   8: dup
    //   9: invokespecial <init> : ()V
    //   12: astore_3
    //   13: iconst_0
    //   14: istore #4
    //   16: new java/lang/StringBuilder
    //   19: dup
    //   20: invokespecial <init> : ()V
    //   23: astore #5
    //   25: aload_2
    //   26: ldc ','
    //   28: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   31: astore #6
    //   33: aload #6
    //   35: astore #7
    //   37: getstatic burp/Zr.Za : Z
    //   40: aload #7
    //   42: arraylength
    //   43: istore #8
    //   45: istore_1
    //   46: iconst_0
    //   47: istore #9
    //   49: iload #9
    //   51: iload #8
    //   53: if_icmpge -> 131
    //   56: aload #7
    //   58: iload #9
    //   60: aaload
    //   61: astore #10
    //   63: iload #4
    //   65: aload #10
    //   67: invokestatic ZF : (Ljava/lang/String;)I
    //   70: iadd
    //   71: istore #4
    //   73: aload #5
    //   75: aload #10
    //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: pop
    //   81: iload #4
    //   83: ifne -> 112
    //   86: aload_3
    //   87: aload #5
    //   89: invokevirtual toString : ()Ljava/lang/String;
    //   92: invokeinterface add : (Ljava/lang/Object;)Z
    //   97: pop
    //   98: aload #5
    //   100: iconst_0
    //   101: invokevirtual setLength : (I)V
    //   104: iload_1
    //   105: ifeq -> 124
    //   108: goto -> 112
    //   111: athrow
    //   112: aload #5
    //   114: ldc ','
    //   116: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   119: pop
    //   120: goto -> 124
    //   123: athrow
    //   124: iinc #9, 1
    //   127: iload_1
    //   128: ifeq -> 49
    //   131: aload_3
    //   132: areturn
    // Exception table:
    //   from	to	target	type
    //   73	108	111	java/lang/RuntimeException
    //   86	120	123	java/lang/RuntimeException
  }
  
  private static int ZF(String paramString) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_0
    //   3: invokevirtual toCharArray : ()[C
    //   6: astore_3
    //   7: getstatic burp/Zr.Za : Z
    //   10: aload_3
    //   11: arraylength
    //   12: istore #4
    //   14: iconst_0
    //   15: istore #5
    //   17: istore_1
    //   18: iload #5
    //   20: iload #4
    //   22: if_icmpge -> 74
    //   25: aload_3
    //   26: iload #5
    //   28: caload
    //   29: istore #6
    //   31: iload #6
    //   33: bipush #60
    //   35: if_icmpne -> 49
    //   38: iinc #2, 1
    //   41: iload_1
    //   42: ifeq -> 67
    //   45: goto -> 49
    //   48: athrow
    //   49: iload #6
    //   51: bipush #62
    //   53: if_icmpne -> 67
    //   56: goto -> 60
    //   59: athrow
    //   60: iinc #2, -1
    //   63: goto -> 67
    //   66: athrow
    //   67: iinc #5, 1
    //   70: iload_1
    //   71: ifeq -> 18
    //   74: iload_2
    //   75: ireturn
    // Exception table:
    //   from	to	target	type
    //   31	45	48	java/lang/RuntimeException
    //   38	56	59	java/lang/RuntimeException
    //   49	63	66	java/lang/RuntimeException
  }
  
  private static String ZO(String paramString) {
    int i = paramString.indexOf('<');
    int j = paramString.lastIndexOf('>');
    return paramString.substring(i + 1, j);
  }
  
  private static boolean lambda$findGenericMethod$2(Zy paramZy, String paramString, String[] paramArrayOfString, IMethod paramIMethod) {
    return Zd(paramIMethod, paramZy, paramString, paramArrayOfString);
  }
  
  private static String[] lambda$parseParameterTypes$1(int paramInt) {
    return new String[paramInt];
  }
  
  private static String lambda$parseParameterTypes$0(String paramString) {
    return Signature.createTypeSignature(paramString, true);
  }
  
  static {
    // Byte code:
    //   0: iconst_3
    //   1: anewarray java/lang/String
    //   4: astore #5
    //   6: iconst_0
    //   7: istore_3
    //   8: ldc '{xýé­1F´i¸ß*Ø³Èg¹j$à~F×÷õÅÞ<³à k"=\\f¶!A^ö]\\t{à"÷èè'
    //   10: dup
    //   11: astore_2
    //   12: invokevirtual length : ()I
    //   15: istore #4
    //   17: bipush #7
    //   19: istore_1
    //   20: iconst_m1
    //   21: istore_0
    //   22: iinc #0, 1
    //   25: aload_2
    //   26: iload_0
    //   27: dup
    //   28: iload_1
    //   29: iadd
    //   30: invokevirtual substring : (II)Ljava/lang/String;
    //   33: iconst_m1
    //   34: goto -> 80
    //   37: aload #5
    //   39: swap
    //   40: iload_3
    //   41: iinc #3, 1
    //   44: swap
    //   45: aastore
    //   46: iload_0
    //   47: iload_1
    //   48: iadd
    //   49: dup
    //   50: istore_0
    //   51: iload #4
    //   53: if_icmpge -> 65
    //   56: aload_2
    //   57: iload_0
    //   58: invokevirtual charAt : (I)C
    //   61: istore_1
    //   62: goto -> 22
    //   65: aload #5
    //   67: putstatic burp/Zr.a : [Ljava/lang/String;
    //   70: iconst_3
    //   71: anewarray java/lang/String
    //   74: putstatic burp/Zr.b : [Ljava/lang/String;
    //   77: goto -> 216
    //   80: swap
    //   81: invokevirtual toCharArray : ()[C
    //   84: dup
    //   85: arraylength
    //   86: swap
    //   87: iconst_0
    //   88: istore #6
    //   90: swap
    //   91: dup_x1
    //   92: iconst_1
    //   93: if_icmpgt -> 191
    //   96: dup
    //   97: iload #6
    //   99: dup2
    //   100: caload
    //   101: iload #6
    //   103: bipush #7
    //   105: irem
    //   106: tableswitch default -> 173, 0 -> 144, 1 -> 149, 2 -> 154, 3 -> 159, 4 -> 163, 5 -> 168
    //   144: bipush #84
    //   146: goto -> 175
    //   149: bipush #103
    //   151: goto -> 175
    //   154: bipush #53
    //   156: goto -> 175
    //   159: iconst_1
    //   160: goto -> 175
    //   163: bipush #25
    //   165: goto -> 175
    //   168: bipush #61
    //   170: goto -> 175
    //   173: bipush #57
    //   175: ixor
    //   176: i2c
    //   177: castore
    //   178: iinc #6, 1
    //   181: swap
    //   182: dup_x1
    //   183: ifne -> 191
    //   186: dup2
    //   187: swap
    //   188: goto -> 99
    //   191: swap
    //   192: dup_x1
    //   193: iload #6
    //   195: if_icmpgt -> 96
    //   198: new java/lang/String
    //   201: dup_x1
    //   202: swap
    //   203: invokespecial <init> : ([C)V
    //   206: invokevirtual intern : ()Ljava/lang/String;
    //   209: swap
    //   210: pop
    //   211: swap
    //   212: pop
    //   213: goto -> 37
    //   216: return
  }
  
  private static String a(int paramInt1, int paramInt2) {
    int i = (paramInt1 ^ 0x7878) & 0xFFFF;
    if (b[i] == null) {
      char[] arrayOfChar = a[i].toCharArray();
      switch (arrayOfChar[0] & 0xFF) {
        case 0:
        
        case 1:
        
        case 2:
        
        case 3:
        
        case 4:
        
        case 5:
        
        case 6:
        
        case 7:
        
        case 8:
        
        case 9:
        
        case 10:
        
        case 11:
        
        case 12:
        
        case 13:
        
        case 14:
        
        case 15:
        
        case 16:
        
        case 17:
        
        case 18:
        
        case 19:
        
        case 20:
        
        case 21:
        
        case 22:
        
        case 23:
        
        case 24:
        
        case 25:
        
        case 26:
        
        case 27:
        
        case 28:
        
        case 29:
        
        case 30:
        
        case 31:
        
        case 32:
        
        case 33:
        
        case 34:
        
        case 35:
        
        case 36:
        
        case 37:
        
        case 38:
        
        case 39:
        
        case 40:
        
        case 41:
        
        case 42:
        
        case 43:
        
        case 44:
        
        case 45:
        
        case 46:
        
        case 47:
        
        case 48:
        
        case 49:
        
        case 50:
        
        case 51:
        
        case 52:
        
        case 53:
        
        case 54:
        
        case 55:
        
        case 56:
        
        case 57:
        
        case 58:
        
        case 59:
        
        case 60:
        
        case 61:
        
        case 62:
        
        case 63:
        
        case 64:
        
        case 65:
        
        case 66:
        
        case 67:
        
        case 68:
        
        case 69:
        
        case 70:
        
        case 71:
        
        case 72:
        
        case 73:
        
        case 74:
        
        case 75:
        
        case 76:
        
        case 77:
        
        case 78:
        
        case 79:
        
        case 80:
        
        case 81:
        
        case 82:
        
        case 83:
        
        case 84:
        
        case 85:
        
        case 86:
        
        case 87:
        
        case 88:
        
        case 89:
        
        case 90:
        
        case 91:
        
        case 92:
        
        case 93:
        
        case 94:
        
        case 95:
        
        case 96:
        
        case 97:
        
        case 98:
        
        case 99:
        
        case 100:
        
        case 101:
        
        case 102:
        
        case 103:
        
        case 104:
        
        case 105:
        
        case 106:
        
        case 107:
        
        case 108:
        
        case 109:
        
        case 110:
        
        case 111:
        
        case 112:
        
        case 113:
        
        case 114:
        
        case 115:
        
        case 116:
        
        case 117:
        
        case 118:
        
        case 119:
        
        case 120:
        
        case 121:
        
        case 122:
        
        case 123:
        
        case 124:
        
        case 125:
        
        case 126:
        
        case 127:
        
        case 128:
        
        case 129:
        
        case 130:
        
        case 131:
        
        case 132:
        
        case 133:
        
        case 134:
        
        case 135:
        
        case 136:
        
        case 137:
        
        case 138:
        
        case 139:
        
        case 140:
        
        case 141:
        
        case 142:
        
        case 143:
        
        case 144:
        
        case 145:
        
        case 146:
        
        case 147:
        
        case 148:
        
        case 149:
        
        case 150:
        
        case 151:
        
        case 152:
        
        case 153:
        
        case 154:
        
        case 155:
        
        case 156:
        
        case 157:
        
        case 158:
        
        case 159:
        
        case 160:
        
        case 161:
        
        case 162:
        
        case 163:
        
        case 164:
        
        case 165:
        
        case 166:
        
        case 167:
        
        case 168:
        
        case 169:
        
        case 170:
        
        case 171:
        
        case 172:
        
        case 173:
        
        case 174:
        
        case 175:
        
        case 176:
        
        case 177:
        
        case 178:
        
        case 179:
        
        case 180:
        
        case 181:
        
        case 182:
        
        case 183:
        
        case 184:
        
        case 185:
        
        case 186:
        
        case 187:
        
        case 188:
        
        case 189:
        
        case 190:
        
        case 191:
        
        case 192:
        
        case 193:
        
        case 194:
        
        case 195:
        
        case 196:
        
        case 197:
        
        case 198:
        
        case 199:
        
        case 200:
        
        case 201:
        
        case 202:
        
        case 203:
        
        case 204:
        
        case 205:
        
        case 206:
        
        case 207:
        
        case 208:
        
        case 209:
        
        case 210:
        
        case 211:
        
        case 212:
        
        case 213:
        
        case 214:
        
        case 215:
        
        case 216:
        
        case 217:
        
        case 218:
        
        case 219:
        
        case 220:
        
        case 221:
        
        case 222:
        
        case 223:
        
        case 224:
        
        case 225:
        
        case 226:
        
        case 227:
        
        case 228:
        
        case 229:
        
        case 230:
        
        case 231:
        
        case 232:
        
        case 233:
        
        case 234:
        
        case 235:
        
        case 236:
        
        case 237:
        
        case 238:
        
        case 239:
        
        case 240:
        
        case 241:
        
        case 242:
        
        case 243:
        
        case 244:
        
        case 245:
        
        case 246:
        
        case 247:
        
        case 248:
        
        case 249:
        
        case 250:
        
        case 251:
        
        case 252:
        
        case 253:
        
        case 254:
        
        default:
          break;
      } 
      byte b1 = 82;
      int j = (paramInt2 & 0xFF) - b1;
      if (j < 0)
        j += 256; 
      int k = ((paramInt2 & 0xFFFF) >>> 8) - b1;
      if (k < 0)
        k += 256; 
      for (byte b2 = 0; b2 < arrayOfChar.length; b2++) {
        int m = b2 % 2;
        if (m == 0) {
          arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ j);
          j = ((j >>> 3 | j << 5) ^ arrayOfChar[b2]) & 0xFF;
        } else {
          arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ k);
          k = ((k >>> 3 | k << 5) ^ arrayOfChar[b2]) & 0xFF;
        } 
      } 
      b[i] = (new String(arrayOfChar)).intern();
    } 
    return b[i];
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\java-tooling-plugin-1.0.0.jar!\burp\Zr.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */