package burp;

import java.util.List;
import org.eclipse.jdt.core.CompletionProposal;
import org.eclipse.jdt.core.CompletionRequestor;

class Zp extends CompletionRequestor {
  final List Zw;
  
  Zp(Zc paramZc, List paramList) {}
  
  public void accept(CompletionProposal paramCompletionProposal) {
    this.Zw.add(Z_.ZM(paramCompletionProposal));
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\java-tooling-plugin-1.0.0.jar!\burp\Zp.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */