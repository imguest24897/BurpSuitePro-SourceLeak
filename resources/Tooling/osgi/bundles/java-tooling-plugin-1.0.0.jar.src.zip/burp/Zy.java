package burp;

import java.util.Map;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;

final class Zy extends Record {
  private final IType zr;
  
  private final Map<String, String> ZZ;
  
  private static final String a;
  
  private Zy(IType paramIType, Map<String, String> paramMap) {
    this.zr = paramIType;
    this.ZZ = paramMap;
  }
  
  static Zy Zt(IJavaProject paramIJavaProject, String paramString) throws JavaModelException {
    // Byte code:
    //   0: getstatic burp/Zr.Za : Z
    //   3: aload_1
    //   4: bipush #60
    //   6: invokevirtual indexOf : (I)I
    //   9: istore_3
    //   10: istore_2
    //   11: iload_3
    //   12: iconst_m1
    //   13: if_icmpeq -> 26
    //   16: aload_1
    //   17: iconst_0
    //   18: iload_3
    //   19: invokevirtual substring : (II)Ljava/lang/String;
    //   22: goto -> 27
    //   25: athrow
    //   26: aload_1
    //   27: astore #4
    //   29: aload_0
    //   30: aload #4
    //   32: invokeinterface findType : (Ljava/lang/String;)Lorg/eclipse/jdt/core/IType;
    //   37: astore #5
    //   39: iload_3
    //   40: iconst_m1
    //   41: if_icmpne -> 53
    //   44: invokestatic emptyMap : ()Ljava/util/Map;
    //   47: astore #6
    //   49: iload_2
    //   50: ifeq -> 174
    //   53: aload_1
    //   54: invokestatic ZY : (Ljava/lang/String;)Ljava/util/List;
    //   57: astore #7
    //   59: aload #5
    //   61: invokeinterface getTypeParameterSignatures : ()[Ljava/lang/String;
    //   66: astore #8
    //   68: aload #7
    //   70: invokeinterface size : ()I
    //   75: aload #8
    //   77: arraylength
    //   78: if_icmpeq -> 90
    //   81: invokestatic emptyMap : ()Ljava/util/Map;
    //   84: astore #6
    //   86: iload_2
    //   87: ifeq -> 174
    //   90: new java/util/HashMap
    //   93: dup
    //   94: invokespecial <init> : ()V
    //   97: astore #6
    //   99: iconst_0
    //   100: istore #9
    //   102: iload #9
    //   104: aload #7
    //   106: invokeinterface size : ()I
    //   111: if_icmpge -> 174
    //   114: aload #8
    //   116: iload #9
    //   118: aaload
    //   119: astore #10
    //   121: aload #10
    //   123: invokestatic getTypeVariable : (Ljava/lang/String;)Ljava/lang/String;
    //   126: astore #11
    //   128: aload #6
    //   130: getstatic burp/Zy.a : Ljava/lang/String;
    //   133: iconst_1
    //   134: anewarray java/lang/Object
    //   137: dup
    //   138: iconst_0
    //   139: aload #11
    //   141: aastore
    //   142: invokevirtual formatted : ([Ljava/lang/Object;)Ljava/lang/String;
    //   145: aload #7
    //   147: iload #9
    //   149: invokeinterface get : (I)Ljava/lang/Object;
    //   154: checkcast java/lang/String
    //   157: iconst_1
    //   158: invokestatic createTypeSignature : (Ljava/lang/String;Z)Ljava/lang/String;
    //   161: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   166: pop
    //   167: iinc #9, 1
    //   170: iload_2
    //   171: ifeq -> 102
    //   174: new burp/Zy
    //   177: dup
    //   178: aload #5
    //   180: aload #6
    //   182: invokespecial <init> : (Lorg/eclipse/jdt/core/IType;Ljava/util/Map;)V
    //   185: areturn
    // Exception table:
    //   from	to	target	type
    //   11	25	25	org/eclipse/jdt/core/JavaModelException
  }
  
  public final String toString() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> toString : (Lburp/Zy;)Ljava/lang/String;
    //   6: areturn
  }
  
  public final int hashCode() {
    // Byte code:
    //   0: aload_0
    //   1: <illegal opcode> hashCode : (Lburp/Zy;)I
    //   6: ireturn
  }
  
  public final boolean equals(Object paramObject) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: <illegal opcode> equals : (Lburp/Zy;Ljava/lang/Object;)Z
    //   7: ireturn
  }
  
  public IType Zr() {
    return this.zr;
  }
  
  public Map<String, String> ZZ() {
    return this.ZZ;
  }
  
  static {
    // Byte code:
    //   0: ldc ' ;TM'
    //   2: iconst_m1
    //   3: goto -> 12
    //   6: putstatic burp/Zy.a : Ljava/lang/String;
    //   9: goto -> 144
    //   12: swap
    //   13: invokevirtual toCharArray : ()[C
    //   16: dup
    //   17: arraylength
    //   18: swap
    //   19: iconst_0
    //   20: istore_0
    //   21: swap
    //   22: dup_x1
    //   23: iconst_1
    //   24: if_icmpgt -> 120
    //   27: dup
    //   28: iload_0
    //   29: dup2
    //   30: caload
    //   31: iload_0
    //   32: bipush #7
    //   34: irem
    //   35: tableswitch default -> 102, 0 -> 72, 1 -> 77, 2 -> 82, 3 -> 87, 4 -> 92, 5 -> 97
    //   72: bipush #116
    //   74: goto -> 104
    //   77: bipush #30
    //   79: goto -> 104
    //   82: bipush #39
    //   84: goto -> 104
    //   87: bipush #118
    //   89: goto -> 104
    //   92: bipush #93
    //   94: goto -> 104
    //   97: bipush #107
    //   99: goto -> 104
    //   102: bipush #93
    //   104: ixor
    //   105: i2c
    //   106: castore
    //   107: iinc #0, 1
    //   110: swap
    //   111: dup_x1
    //   112: ifne -> 120
    //   115: dup2
    //   116: swap
    //   117: goto -> 29
    //   120: swap
    //   121: dup_x1
    //   122: iload_0
    //   123: if_icmpgt -> 27
    //   126: new java/lang/String
    //   129: dup_x1
    //   130: swap
    //   131: invokespecial <init> : ([C)V
    //   134: invokevirtual intern : ()Ljava/lang/String;
    //   137: swap
    //   138: pop
    //   139: swap
    //   140: pop
    //   141: goto -> 6
    //   144: return
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\java-tooling-plugin-1.0.0.jar!\burp\Zy.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */