package burp;

import java.nio.file.Path;
import net.portswigger.javatooling.api.ClasspathService;
import org.eclipse.core.runtime.Path;
import org.eclipse.jdt.core.JavaModelException;

public class Zd implements ClasspathService {
  private final Ze Zb;
  
  public Zd(Ze paramZe) {
    this.Zb = paramZe;
  }
  
  public void addLibrary(Path paramPath) {
    try {
      this.Zb.ZR(new Path(paramPath.toString()));
    } catch (JavaModelException javaModelException) {
      throw new RuntimeException(javaModelException);
    } 
  }
  
  public void addLibrary(Path paramPath1, Path paramPath2) {
    try {
      this.Zb.ZQ(new Path(paramPath1.toString()), new Path(paramPath2.toString()));
    } catch (JavaModelException javaModelException) {
      throw new RuntimeException(javaModelException);
    } 
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\java-tooling-plugin-1.0.0.jar!\burp\Zd.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */