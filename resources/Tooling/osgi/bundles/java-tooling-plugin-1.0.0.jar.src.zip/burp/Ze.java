package burp;

import java.io.File;
import java.util.Arrays;
import java.util.Map;
import java.util.UUID;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.launching.IVMInstall;
import org.eclipse.jdt.launching.IVMInstallType;
import org.eclipse.jdt.launching.JavaRuntime;

public class Ze {
  private IProject Zs;
  
  public static boolean Zu;
  
  private static final String[] a;
  
  private static final String[] b;
  
  public void Zz() throws CoreException {
    try {
      if (this.Zs == null)
        this.Zs = Zx(); 
    } catch (CoreException coreException) {
      throw null;
    } 
  }
  
  public void ZC() throws CoreException {
    try {
      if (this.Zs != null)
        try {
          if (this.Zs.isOpen()) {
            this.Zs.close(null);
            this.Zs = null;
          } 
        } catch (CoreException coreException) {
          throw null;
        }  
    } catch (CoreException coreException) {
      throw null;
    } 
    ResourcesPlugin.getWorkspace().save(true, null);
  }
  
  public IProject Ze() {
    return this.Zs;
  }
  
  public void ZR(Path paramPath) throws JavaModelException {
    ZQ(paramPath, null);
  }
  
  public void ZQ(Path paramPath1, Path paramPath2) throws JavaModelException {
    try {
      if (paramPath1 == null)
        return; 
    } catch (JavaModelException javaModelException) {
      throw null;
    } 
    IJavaProject iJavaProject = JavaCore.create(Ze());
    IClasspathEntry[] arrayOfIClasspathEntry1 = Zi(iJavaProject.getRawClasspath(), paramPath1);
    IClasspathEntry iClasspathEntry = JavaCore.newLibraryEntry((IPath)new Path(paramPath1.toString()), (IPath)paramPath2, null, new org.eclipse.jdt.core.IAccessRule[0], new org.eclipse.jdt.core.IClasspathAttribute[0], false);
    IClasspathEntry[] arrayOfIClasspathEntry2 = Arrays.<IClasspathEntry>copyOf(arrayOfIClasspathEntry1, arrayOfIClasspathEntry1.length + 1);
    arrayOfIClasspathEntry2[arrayOfIClasspathEntry1.length] = iClasspathEntry;
    iJavaProject.setRawClasspath(arrayOfIClasspathEntry2, null);
  }
  
  private IClasspathEntry[] Zi(IClasspathEntry[] paramArrayOfIClasspathEntry, Path paramPath) {
    return (IClasspathEntry[])Arrays.<IClasspathEntry>stream(paramArrayOfIClasspathEntry).filter(paramPath::lambda$removePathFromClasspath$0).toArray(Ze::lambda$removePathFromClasspath$1);
  }
  
  private IProject Zx() throws CoreException {
    IProject iProject = ResourcesPlugin.getWorkspace().getRoot().getProject(a(-68, 17755));
    IFolder iFolder1 = iProject.getFolder(a(-73, 1188));
    IFolder iFolder2 = iProject.getFolder(a(-67, -4882));
    ZI(iProject);
    Zv(iProject);
    Zg(iFolder1);
    Zg(iFolder2);
    ZM(iProject);
    ZR(iProject);
    return iProject;
  }
  
  private static void ZI(IProject paramIProject) throws CoreException {
    try {
      if (!paramIProject.exists())
        paramIProject.create(null); 
    } catch (CoreException coreException) {
      throw null;
    } 
  }
  
  private static void Zv(IProject paramIProject) throws CoreException {
    try {
      if (!paramIProject.isOpen())
        paramIProject.open(null); 
    } catch (CoreException coreException) {
      throw null;
    } 
  }
  
  private static void ZM(IProject paramIProject) throws CoreException {
    IProjectDescription iProjectDescription = paramIProject.getDescription();
    String[] arrayOfString = iProjectDescription.getNatureIds();
    try {
      if (arrayOfString.length == 0) {
        iProjectDescription.setNatureIds(new String[] { a(-74, -23200) });
        paramIProject.setDescription(iProjectDescription, null);
      } 
    } catch (CoreException coreException) {
      throw null;
    } 
  }
  
  private static void ZR(IProject paramIProject) throws CoreException {
    IJavaProject iJavaProject = JavaCore.create(paramIProject);
    IVMInstallType iVMInstallType = JavaRuntime.getVMInstallType(a(-76, -20913));
    IVMInstall iVMInstall = iVMInstallType.createVMInstall(UUID.randomUUID().toString());
    iVMInstall.setInstallLocation(new File(System.getProperty(a(-69, -12991))));
    iVMInstall.setName(a(-75, 32286));
    Map<String, String> map = iJavaProject.getOptions(true);
    map.put(a(-70, 10785), a(-72, -17901));
    map.put(a(-66, -31714), a(-78, -28083));
    map.put(a(-71, -21221), a(-78, -28083));
    iJavaProject.setOptions(map);
    iJavaProject.setRawClasspath(new IClasspathEntry[] { JavaCore.newSourceEntry(paramIProject.getFullPath().append(a(-65, 31537))), JavaCore.newContainerEntry((new Path(JavaRuntime.JRE_CONTAINER)).append(iVMInstallType.getId()).append(iVMInstall.getName())) }null);
  }
  
  private static void Zg(IFolder paramIFolder) throws CoreException {
    try {
      if (!paramIFolder.exists())
        paramIFolder.create(0, true, null); 
    } catch (CoreException coreException) {
      throw null;
    } 
  }
  
  private static IClasspathEntry[] lambda$removePathFromClasspath$1(int paramInt) {
    return new IClasspathEntry[paramInt];
  }
  
  private static boolean lambda$removePathFromClasspath$0(Path paramPath, IClasspathEntry paramIClasspathEntry) {
    return !paramIClasspathEntry.getPath().equals(paramPath);
  }
  
  static {
    // Byte code:
    //   0: bipush #13
    //   2: anewarray java/lang/String
    //   5: astore #5
    //   7: iconst_0
    //   8: istore_3
    //   9: ldc 'òéÞûÌë²ur=2/à^Á]ó-#hmn>¬õèu/-=MP)¡`¥ÉP mv}V\\rdÂp](ºÔ·ÿèu6¦âGÕpÆ¨cÈú¹\\t½ì¾þD¾Õ·4£)'4\\t³\5GO$$*í½ë é?5Ã5ªô8ZÚÝûãA!å-ß6#È¬¸/?Þ©""ÐoÉÑëÜ=(zï#Í\\nª7\\bËBøÇ¹9awöÃ¤U x=®ÛyÁ¿Í¤^d©\\r\\rïR7ÄõÆnÄJóRÛ_®K²]Û©è`dB'
    //   11: dup
    //   12: astore_2
    //   13: invokevirtual length : ()I
    //   16: istore #4
    //   18: bipush #52
    //   20: istore_1
    //   21: iconst_m1
    //   22: istore_0
    //   23: iinc #0, 1
    //   26: aload_2
    //   27: iload_0
    //   28: dup
    //   29: iload_1
    //   30: iadd
    //   31: invokevirtual substring : (II)Ljava/lang/String;
    //   34: iconst_m1
    //   35: goto -> 139
    //   38: aload #5
    //   40: swap
    //   41: iload_3
    //   42: iinc #3, 1
    //   45: swap
    //   46: aastore
    //   47: iload_0
    //   48: iload_1
    //   49: iadd
    //   50: dup
    //   51: istore_0
    //   52: iload #4
    //   54: if_icmpge -> 66
    //   57: aload_2
    //   58: iload_0
    //   59: invokevirtual charAt : (I)C
    //   62: istore_1
    //   63: goto -> 23
    //   66: ldc 'ézVóp¦1!7Þ¼'
    //   68: dup
    //   69: astore_2
    //   70: invokevirtual length : ()I
    //   73: istore #4
    //   75: bipush #14
    //   77: istore_1
    //   78: iconst_m1
    //   79: istore_0
    //   80: iinc #0, 1
    //   83: aload_2
    //   84: iload_0
    //   85: dup
    //   86: iload_1
    //   87: iadd
    //   88: invokevirtual substring : (II)Ljava/lang/String;
    //   91: iconst_0
    //   92: goto -> 139
    //   95: aload #5
    //   97: swap
    //   98: iload_3
    //   99: iinc #3, 1
    //   102: swap
    //   103: aastore
    //   104: iload_0
    //   105: iload_1
    //   106: iadd
    //   107: dup
    //   108: istore_0
    //   109: iload #4
    //   111: if_icmpge -> 123
    //   114: aload_2
    //   115: iload_0
    //   116: invokevirtual charAt : (I)C
    //   119: istore_1
    //   120: goto -> 80
    //   123: aload #5
    //   125: putstatic burp/Ze.a : [Ljava/lang/String;
    //   128: bipush #13
    //   130: anewarray java/lang/String
    //   133: putstatic burp/Ze.b : [Ljava/lang/String;
    //   136: goto -> 292
    //   139: swap
    //   140: invokevirtual toCharArray : ()[C
    //   143: dup
    //   144: arraylength
    //   145: swap
    //   146: iconst_0
    //   147: istore #6
    //   149: swap
    //   150: dup_x1
    //   151: iconst_1
    //   152: if_icmpgt -> 252
    //   155: dup
    //   156: iload #6
    //   158: dup2
    //   159: caload
    //   160: iload #6
    //   162: bipush #7
    //   164: irem
    //   165: tableswitch default -> 234, 0 -> 204, 1 -> 209, 2 -> 214, 3 -> 219, 4 -> 224, 5 -> 229
    //   204: bipush #24
    //   206: goto -> 236
    //   209: bipush #112
    //   211: goto -> 236
    //   214: bipush #60
    //   216: goto -> 236
    //   219: bipush #49
    //   221: goto -> 236
    //   224: bipush #39
    //   226: goto -> 236
    //   229: bipush #87
    //   231: goto -> 236
    //   234: bipush #86
    //   236: ixor
    //   237: i2c
    //   238: castore
    //   239: iinc #6, 1
    //   242: swap
    //   243: dup_x1
    //   244: ifne -> 252
    //   247: dup2
    //   248: swap
    //   249: goto -> 158
    //   252: swap
    //   253: dup_x1
    //   254: iload #6
    //   256: if_icmpgt -> 155
    //   259: new java/lang/String
    //   262: dup_x1
    //   263: swap
    //   264: invokespecial <init> : ([C)V
    //   267: invokevirtual intern : ()Ljava/lang/String;
    //   270: swap
    //   271: pop
    //   272: swap
    //   273: tableswitch default -> 38, 0 -> 95
    //   292: return
  }
  
  private static String a(int paramInt1, int paramInt2) {
    int i = (paramInt1 ^ 0xFFFFFFBE) & 0xFFFF;
    if (b[i] == null) {
      char[] arrayOfChar = a[i].toCharArray();
      switch (arrayOfChar[0] & 0xFF) {
        case 0:
        
        case 1:
        
        case 2:
        
        case 3:
        
        case 4:
        
        case 5:
        
        case 6:
        
        case 7:
        
        case 8:
        
        case 9:
        
        case 10:
        
        case 11:
        
        case 12:
        
        case 13:
        
        case 14:
        
        case 15:
        
        case 16:
        
        case 17:
        
        case 18:
        
        case 19:
        
        case 20:
        
        case 21:
        
        case 22:
        
        case 23:
        
        case 24:
        
        case 25:
        
        case 26:
        
        case 27:
        
        case 28:
        
        case 29:
        
        case 30:
        
        case 31:
        
        case 32:
        
        case 33:
        
        case 34:
        
        case 35:
        
        case 36:
        
        case 37:
        
        case 38:
        
        case 39:
        
        case 40:
        
        case 41:
        
        case 42:
        
        case 43:
        
        case 44:
        
        case 45:
        
        case 46:
        
        case 47:
        
        case 48:
        
        case 49:
        
        case 50:
        
        case 51:
        
        case 52:
        
        case 53:
        
        case 54:
        
        case 55:
        
        case 56:
        
        case 57:
        
        case 58:
        
        case 59:
        
        case 60:
        
        case 61:
        
        case 62:
        
        case 63:
        
        case 64:
        
        case 65:
        
        case 66:
        
        case 67:
        
        case 68:
        
        case 69:
        
        case 70:
        
        case 71:
        
        case 72:
        
        case 73:
        
        case 74:
        
        case 75:
        
        case 76:
        
        case 77:
        
        case 78:
        
        case 79:
        
        case 80:
        
        case 81:
        
        case 82:
        
        case 83:
        
        case 84:
        
        case 85:
        
        case 86:
        
        case 87:
        
        case 88:
        
        case 89:
        
        case 90:
        
        case 91:
        
        case 92:
        
        case 93:
        
        case 94:
        
        case 95:
        
        case 96:
        
        case 97:
        
        case 98:
        
        case 99:
        
        case 100:
        
        case 101:
        
        case 102:
        
        case 103:
        
        case 104:
        
        case 105:
        
        case 106:
        
        case 107:
        
        case 108:
        
        case 109:
        
        case 110:
        
        case 111:
        
        case 112:
        
        case 113:
        
        case 114:
        
        case 115:
        
        case 116:
        
        case 117:
        
        case 118:
        
        case 119:
        
        case 120:
        
        case 121:
        
        case 122:
        
        case 123:
        
        case 124:
        
        case 125:
        
        case 126:
        
        case 127:
        
        case 128:
        
        case 129:
        
        case 130:
        
        case 131:
        
        case 132:
        
        case 133:
        
        case 134:
        
        case 135:
        
        case 136:
        
        case 137:
        
        case 138:
        
        case 139:
        
        case 140:
        
        case 141:
        
        case 142:
        
        case 143:
        
        case 144:
        
        case 145:
        
        case 146:
        
        case 147:
        
        case 148:
        
        case 149:
        
        case 150:
        
        case 151:
        
        case 152:
        
        case 153:
        
        case 154:
        
        case 155:
        
        case 156:
        
        case 157:
        
        case 158:
        
        case 159:
        
        case 160:
        
        case 161:
        
        case 162:
        
        case 163:
        
        case 164:
        
        case 165:
        
        case 166:
        
        case 167:
        
        case 168:
        
        case 169:
        
        case 170:
        
        case 171:
        
        case 172:
        
        case 173:
        
        case 174:
        
        case 175:
        
        case 176:
        
        case 177:
        
        case 178:
        
        case 179:
        
        case 180:
        
        case 181:
        
        case 182:
        
        case 183:
        
        case 184:
        
        case 185:
        
        case 186:
        
        case 187:
        
        case 188:
        
        case 189:
        
        case 190:
        
        case 191:
        
        case 192:
        
        case 193:
        
        case 194:
        
        case 195:
        
        case 196:
        
        case 197:
        
        case 198:
        
        case 199:
        
        case 200:
        
        case 201:
        
        case 202:
        
        case 203:
        
        case 204:
        
        case 205:
        
        case 206:
        
        case 207:
        
        case 208:
        
        case 209:
        
        case 210:
        
        case 211:
        
        case 212:
        
        case 213:
        
        case 214:
        
        case 215:
        
        case 216:
        
        case 217:
        
        case 218:
        
        case 219:
        
        case 220:
        
        case 221:
        
        case 222:
        
        case 223:
        
        case 224:
        
        case 225:
        
        case 226:
        
        case 227:
        
        case 228:
        
        case 229:
        
        case 230:
        
        case 231:
        
        case 232:
        
        case 233:
        
        case 234:
        
        case 235:
        
        case 236:
        
        case 237:
        
        case 238:
        
        case 239:
        
        case 240:
        
        case 241:
        
        case 242:
        
        case 243:
        
        case 244:
        
        case 245:
        
        case 246:
        
        case 247:
        
        case 248:
        
        case 249:
        
        case 250:
        
        case 251:
        
        case 252:
        
        case 253:
        
        case 254:
        
        default:
          break;
      } 
      char c = '¢';
      int j = (paramInt2 & 0xFF) - c;
      if (j < 0)
        j += 256; 
      int k = ((paramInt2 & 0xFFFF) >>> 8) - c;
      if (k < 0)
        k += 256; 
      for (byte b = 0; b < arrayOfChar.length; b++) {
        int m = b % 2;
        if (m == 0) {
          arrayOfChar[b] = (char)(arrayOfChar[b] ^ j);
          j = ((j >>> 3 | j << 5) ^ arrayOfChar[b]) & 0xFF;
        } else {
          arrayOfChar[b] = (char)(arrayOfChar[b] ^ k);
          k = ((k >>> 3 | k << 5) ^ arrayOfChar[b]) & 0xFF;
        } 
      } 
      b[i] = (new String(arrayOfChar)).intern();
    } 
    return b[i];
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\java-tooling-plugin-1.0.0.jar!\burp\Ze.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */