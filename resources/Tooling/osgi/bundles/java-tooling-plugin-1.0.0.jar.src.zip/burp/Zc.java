package burp;

import java.util.ArrayList;
import java.util.List;
import net.portswigger.javatooling.api.CompletionProposal;
import net.portswigger.javatooling.api.CompletionService;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jdt.core.IBuffer;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.internal.codeassist.CompletionEngine;

public class Zc implements CompletionService {
  public final Ze ZZ;
  
  private static final String a;
  
  public Zc(Ze paramZe) {
    this.ZZ = paramZe;
    CompletionEngine.DEBUG = false;
  }
  
  public List<CompletionProposal> complete(String paramString, int paramInt) {
    try {
      ICompilationUnit iCompilationUnit = Zu(paramString);
      return ZE(iCompilationUnit, paramInt);
    } catch (JavaModelException javaModelException) {
      throw new RuntimeException(javaModelException);
    } 
  }
  
  private ICompilationUnit Zu(String paramString) throws JavaModelException {
    Path path = new Path(a);
    IFile iFile = this.ZZ.Ze().getFile((IPath)path);
    ICompilationUnit iCompilationUnit = JavaCore.createCompilationUnitFrom(iFile);
    iCompilationUnit.becomeWorkingCopy(null);
    IBuffer iBuffer = iCompilationUnit.getBuffer();
    iBuffer.setContents(paramString);
    return iCompilationUnit;
  }
  
  private List<CompletionProposal> ZE(ICompilationUnit paramICompilationUnit, int paramInt) throws JavaModelException {
    ArrayList<CompletionProposal> arrayList = new ArrayList();
    try {
      paramICompilationUnit.codeComplete(paramInt, new Zp(this, arrayList));
    } finally {
      paramICompilationUnit.discardWorkingCopy();
    } 
    return arrayList;
  }
  
  static {
    // Byte code:
    //   0: ldc '*=9}JD\\f!d|]9"l'
    //   2: iconst_m1
    //   3: goto -> 12
    //   6: putstatic burp/Zc.a : Ljava/lang/String;
    //   9: goto -> 144
    //   12: swap
    //   13: invokevirtual toCharArray : ()[C
    //   16: dup
    //   17: arraylength
    //   18: swap
    //   19: iconst_0
    //   20: istore_0
    //   21: swap
    //   22: dup_x1
    //   23: iconst_1
    //   24: if_icmpgt -> 120
    //   27: dup
    //   28: iload_0
    //   29: dup2
    //   30: caload
    //   31: iload_0
    //   32: bipush #7
    //   34: irem
    //   35: tableswitch default -> 102, 0 -> 72, 1 -> 77, 2 -> 82, 3 -> 87, 4 -> 92, 5 -> 97
    //   72: bipush #126
    //   74: goto -> 104
    //   77: bipush #88
    //   79: goto -> 104
    //   82: bipush #84
    //   84: goto -> 104
    //   87: bipush #13
    //   89: goto -> 104
    //   92: bipush #16
    //   94: goto -> 104
    //   97: bipush #56
    //   99: goto -> 104
    //   102: bipush #37
    //   104: ixor
    //   105: i2c
    //   106: castore
    //   107: iinc #0, 1
    //   110: swap
    //   111: dup_x1
    //   112: ifne -> 120
    //   115: dup2
    //   116: swap
    //   117: goto -> 29
    //   120: swap
    //   121: dup_x1
    //   122: iload_0
    //   123: if_icmpgt -> 27
    //   126: new java/lang/String
    //   129: dup_x1
    //   130: swap
    //   131: invokespecial <init> : ([C)V
    //   134: invokevirtual intern : ()Ljava/lang/String;
    //   137: swap
    //   138: pop
    //   139: swap
    //   140: pop
    //   141: goto -> 6
    //   144: return
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\java-tooling-plugin-1.0.0.jar!\burp\Zc.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */