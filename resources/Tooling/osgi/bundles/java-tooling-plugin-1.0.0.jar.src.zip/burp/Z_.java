package burp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import net.portswigger.javatooling.api.CompletionProposal;
import net.portswigger.javatooling.api.Flag;
import net.portswigger.javatooling.api.JavadocNode;
import net.portswigger.javatooling.api.JavadocTag;
import net.portswigger.javatooling.api.Kind;
import net.portswigger.javatooling.api.Parameter;
import net.portswigger.javatooling.api.Problem;
import net.portswigger.javatooling.api.Range;
import net.portswigger.javatooling.api.Severity;
import net.portswigger.javatooling.api.Signature;
import org.eclipse.jdt.core.CompletionProposal;
import org.eclipse.jdt.core.Flags;
import org.eclipse.jdt.core.Signature;
import org.eclipse.jdt.core.compiler.CategorizedProblem;
import org.eclipse.jdt.core.dom.Javadoc;
import org.eclipse.jdt.core.dom.TagElement;

class Z_ {
  private static final String[] a;
  
  private static final String[] b;
  
  static CompletionProposal ZM(CompletionProposal paramCompletionProposal) {
    Kind kind = Zx(paramCompletionProposal.getKind(), paramCompletionProposal.getCompletion());
    return new CompletionProposal(kind, ZO(paramCompletionProposal.getCompletion()), paramCompletionProposal.getRelevance(), ZY(paramCompletionProposal.getName()), ZU(kind, paramCompletionProposal), ZY(kind, paramCompletionProposal), Zr(paramCompletionProposal.getReplaceStart(), paramCompletionProposal.getReplaceEnd()), Zd(paramCompletionProposal.getFlags()));
  }
  
  static JavadocNode Zd(Javadoc paramJavadoc) {
    return new JavadocNode(paramJavadoc.toString(), Optional.empty(), ZD(paramJavadoc.tags()));
  }
  
  private static List<JavadocNode> ZD(List<?> paramList) {
    return paramList.stream().map(Z_::ZS).toList();
  }
  
  private static JavadocNode ZS(Object paramObject) {
    if (paramObject instanceof TagElement) {
      TagElement tagElement = (TagElement)paramObject;
      return new JavadocNode(paramObject.toString(), Optional.ofNullable(Zc(tagElement.getTagName())), ZD(tagElement.fragments()));
    } 
    return (paramObject == null) ? null : new JavadocNode(paramObject.toString());
  }
  
  static Set<Problem> Zk(CategorizedProblem[] paramArrayOfCategorizedProblem) {
    return (paramArrayOfCategorizedProblem == null) ? Collections.<Problem>emptySet() : (Set<Problem>)Arrays.<CategorizedProblem>stream(paramArrayOfCategorizedProblem).map(Z_::Zc).collect(Collectors.toSet());
  }
  
  private static Problem Zc(CategorizedProblem paramCategorizedProblem) {
    return new Problem(paramCategorizedProblem.getMessage(), ZL(paramCategorizedProblem), paramCategorizedProblem.getSourceLineNumber(), new Range(paramCategorizedProblem.getSourceStart(), paramCategorizedProblem.getSourceEnd()));
  }
  
  private static Severity ZL(CategorizedProblem paramCategorizedProblem) {
    return paramCategorizedProblem.isError() ? Severity.ERROR : (paramCategorizedProblem.isWarning() ? Severity.WARNING : (paramCategorizedProblem.isInfo() ? Severity.INFO : Severity.NONE));
  }
  
  private static Kind Zx(int paramInt, char[] paramArrayOfchar) {
    switch (paramInt) {
      case 1:
      
      case 2:
      
      case 3:
      
      case 4:
      
      case 5:
      
      case 6:
      
      case 7:
      
      case 8:
      
      case 9:
      
      case 10:
      
      case 11:
      
      case 12:
      
      case 13:
      
      case 14:
      
      case 15:
      
      case 16:
      
      case 17:
      
      case 18:
      
      case 19:
      
      case 20:
      
      case 21:
      
      case 22:
      
      case 23:
      
      case 24:
      
      case 25:
      
      case 26:
      
      case 27:
      
      case 28:
      
      case 29:
      
      case 30:
      
    } 
    return null;
  }
  
  static Kind ZQ(char[] paramArrayOfchar) {
    if (paramArrayOfchar == null)
      return Kind.TYPE_REF; 
    String str1 = Zn.Za(new String(paramArrayOfchar));
    String str2 = str1.toLowerCase();
    return (str2.endsWith(a(-4105, 15273)) || str2.endsWith(a(-4125, 3862)) || str2.equals(a(-4116, -10853))) ? Kind.EXCEPTION_REF : Kind.TYPE_REF;
  }
  
  private static String ZO(char[] paramArrayOfchar) {
    return (paramArrayOfchar == null) ? null : String.valueOf(paramArrayOfchar);
  }
  
  private static String ZY(char[] paramArrayOfchar) {
    return (paramArrayOfchar == null) ? null : String.valueOf(paramArrayOfchar);
  }
  
  private static Range Zr(int paramInt1, int paramInt2) {
    return new Range(paramInt1, paramInt2);
  }
  
  private static String ZU(Kind paramKind, CompletionProposal paramCompletionProposal) {
    char[] arrayOfChar = paramCompletionProposal.getDeclarationSignature();
    switch (Zm.ZH[paramKind.ordinal()]) {
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      case 16:
      case 17:
      
      case 18:
      case 19:
      case 20:
      case 21:
      case 22:
      case 23:
      
    } 
    return (paramKind == null || arrayOfChar == null) ? null : null;
  }
  
  private static Signature ZY(Kind paramKind, CompletionProposal paramCompletionProposal) {
    char[] arrayOfChar = paramCompletionProposal.getSignature();
    switch (Zm.ZH[paramKind.ordinal()]) {
      case 1:
      case 3:
      case 4:
      case 5:
      case 6:
      case 9:
      case 12:
      case 13:
      case 15:
      case 16:
      case 17:
      
      case 2:
      case 7:
      case 8:
      case 10:
      case 11:
      case 14:
      case 19:
      case 21:
      case 22:
      case 24:
      case 25:
      
    } 
    return (paramKind == null || arrayOfChar == null) ? null : null;
  }
  
  private static Signature ZZ(char[] paramArrayOfchar, char[][] paramArrayOfchar1, boolean paramBoolean) {
    String str = Signature.toString(String.valueOf(Signature.getReturnType(paramArrayOfchar)));
    List<Parameter> list = Zt(paramArrayOfchar, paramArrayOfchar1, paramBoolean);
    return new Signature(str, list);
  }
  
  private static Signature Zt(char[] paramArrayOfchar) {
    String str = Signature.toString(String.valueOf(paramArrayOfchar));
    return new Signature(str, null);
  }
  
  private static List<Parameter> Zt(char[] paramArrayOfchar, char[][] paramArrayOfchar1, boolean paramBoolean) {
    char[][] arrayOfChar = Signature.getParameterTypes(paramArrayOfchar);
    LinkedList<Parameter> linkedList = new LinkedList();
    boolean bool = Zr.Za;
    byte b = 0;
    while (b < arrayOfChar.length) {
      char[] arrayOfChar1 = arrayOfChar[b];
      char[] arrayOfChar2 = (paramArrayOfchar1 == null) ? null : paramArrayOfchar1[b];
      linkedList.add(new Parameter(Signature.toString(String.valueOf(arrayOfChar1)), (arrayOfChar2 == null) ? null : String.valueOf(arrayOfChar2), (paramBoolean && b == arrayOfChar.length - 1)));
      b++;
      if (bool)
        break; 
    } 
    return linkedList;
  }
  
  private static EnumSet<Flag> Zd(int paramInt) {
    ArrayList<Flag> arrayList = new ArrayList();
    if (Flags.isAbstract(paramInt))
      arrayList.add(Flag.ABSTRACT); 
    if (Flags.isAnnotation(paramInt))
      arrayList.add(Flag.ANNOTATION); 
    if (Flags.isAnnnotationDefault(paramInt))
      arrayList.add(Flag.ANNOTATION_DEFAULT); 
    if (Flags.isDefaultMethod(paramInt))
      arrayList.add(Flag.DEFAULT_METHOD); 
    if (Flags.isDeprecated(paramInt))
      arrayList.add(Flag.DEPRECATED); 
    if (Flags.isEnum(paramInt))
      arrayList.add(Flag.ENUM); 
    if (Flags.isFinal(paramInt))
      arrayList.add(Flag.FINAL); 
    if (Flags.isInterface(paramInt))
      arrayList.add(Flag.INTERFACE); 
    if (Flags.isModule(paramInt))
      arrayList.add(Flag.MODULE); 
    if (Flags.isNative(paramInt))
      arrayList.add(Flag.NATIVE); 
    if (Flags.isNonSealed(paramInt))
      arrayList.add(Flag.NON_SEALED); 
    if (Flags.isPrivate(paramInt))
      arrayList.add(Flag.PRIVATE); 
    if (Flags.isProtected(paramInt))
      arrayList.add(Flag.PROTECTED); 
    if (Flags.isPublic(paramInt))
      arrayList.add(Flag.PUBLIC); 
    if (Flags.isRecord(paramInt))
      arrayList.add(Flag.RECORD); 
    if (Flags.isSealed(paramInt))
      arrayList.add(Flag.SEALED); 
    if (Flags.isStatic(paramInt))
      arrayList.add(Flag.STATIC); 
    if (Flags.isStrictfp(paramInt))
      arrayList.add(Flag.STRICTFP); 
    if (Flags.isSynchronized(paramInt))
      arrayList.add(Flag.SYNCHRONIZED); 
    if (Flags.isTransient(paramInt))
      arrayList.add(Flag.TRANSIENT); 
    if (Flags.isVolatile(paramInt))
      arrayList.add(Flag.VOLATILE); 
    return arrayList.isEmpty() ? EnumSet.<Flag>noneOf(Flag.class) : EnumSet.<Flag>copyOf(arrayList);
  }
  
  private static JavadocTag Zc(String paramString) {
    // Byte code:
    //   0: getstatic burp/Zr.Za : Z
    //   3: istore_1
    //   4: aload_0
    //   5: ifnonnull -> 10
    //   8: aconst_null
    //   9: areturn
    //   10: aload_0
    //   11: astore_2
    //   12: iconst_m1
    //   13: istore_3
    //   14: aload_2
    //   15: invokevirtual hashCode : ()I
    //   18: lookupswitch default -> 948, -1986928794 -> 699, -1719164122 -> 653, -1300800048 -> 469, -929875732 -> 814, -700463566 -> 538, -673114637 -> 312, -440667701 -> 268, -373173132 -> 906, -251826710 -> 378, -139184526 -> 860, -139035077 -> 837, -74889603 -> 423, 2020371 -> 584, 31264112 -> 561, 53172335 -> 492, 59821620 -> 607, 62164525 -> 290, 62427194 -> 446, 62704652 -> 745, 91227789 -> 722, 222319768 -> 791, 360118270 -> 630, 965208692 -> 929, 1698584058 -> 334, 1789663247 -> 356, 1932611730 -> 400, 1938702413 -> 515, 1941707514 -> 676, 1944238385 -> 768, 2104043741 -> 883
    //   268: aload_2
    //   269: sipush #-4104
    //   272: sipush #-29115
    //   275: invokestatic a : (II)Ljava/lang/String;
    //   278: invokevirtual equals : (Ljava/lang/Object;)Z
    //   281: ifeq -> 948
    //   284: iconst_0
    //   285: istore_3
    //   286: iload_1
    //   287: ifeq -> 948
    //   290: aload_2
    //   291: sipush #-4123
    //   294: sipush #2901
    //   297: invokestatic a : (II)Ljava/lang/String;
    //   300: invokevirtual equals : (Ljava/lang/Object;)Z
    //   303: ifeq -> 948
    //   306: iconst_1
    //   307: istore_3
    //   308: iload_1
    //   309: ifeq -> 948
    //   312: aload_2
    //   313: sipush #-4109
    //   316: sipush #-21994
    //   319: invokestatic a : (II)Ljava/lang/String;
    //   322: invokevirtual equals : (Ljava/lang/Object;)Z
    //   325: ifeq -> 948
    //   328: iconst_2
    //   329: istore_3
    //   330: iload_1
    //   331: ifeq -> 948
    //   334: aload_2
    //   335: sipush #-4124
    //   338: sipush #11422
    //   341: invokestatic a : (II)Ljava/lang/String;
    //   344: invokevirtual equals : (Ljava/lang/Object;)Z
    //   347: ifeq -> 948
    //   350: iconst_3
    //   351: istore_3
    //   352: iload_1
    //   353: ifeq -> 948
    //   356: aload_2
    //   357: sipush #-4101
    //   360: sipush #29906
    //   363: invokestatic a : (II)Ljava/lang/String;
    //   366: invokevirtual equals : (Ljava/lang/Object;)Z
    //   369: ifeq -> 948
    //   372: iconst_4
    //   373: istore_3
    //   374: iload_1
    //   375: ifeq -> 948
    //   378: aload_2
    //   379: sipush #-4121
    //   382: sipush #19177
    //   385: invokestatic a : (II)Ljava/lang/String;
    //   388: invokevirtual equals : (Ljava/lang/Object;)Z
    //   391: ifeq -> 948
    //   394: iconst_5
    //   395: istore_3
    //   396: iload_1
    //   397: ifeq -> 948
    //   400: aload_2
    //   401: sipush #-4120
    //   404: sipush #-22793
    //   407: invokestatic a : (II)Ljava/lang/String;
    //   410: invokevirtual equals : (Ljava/lang/Object;)Z
    //   413: ifeq -> 948
    //   416: bipush #6
    //   418: istore_3
    //   419: iload_1
    //   420: ifeq -> 948
    //   423: aload_2
    //   424: sipush #-4112
    //   427: sipush #29394
    //   430: invokestatic a : (II)Ljava/lang/String;
    //   433: invokevirtual equals : (Ljava/lang/Object;)Z
    //   436: ifeq -> 948
    //   439: bipush #7
    //   441: istore_3
    //   442: iload_1
    //   443: ifeq -> 948
    //   446: aload_2
    //   447: sipush #-4117
    //   450: sipush #-21118
    //   453: invokestatic a : (II)Ljava/lang/String;
    //   456: invokevirtual equals : (Ljava/lang/Object;)Z
    //   459: ifeq -> 948
    //   462: bipush #8
    //   464: istore_3
    //   465: iload_1
    //   466: ifeq -> 948
    //   469: aload_2
    //   470: sipush #-4097
    //   473: sipush #19959
    //   476: invokestatic a : (II)Ljava/lang/String;
    //   479: invokevirtual equals : (Ljava/lang/Object;)Z
    //   482: ifeq -> 948
    //   485: bipush #9
    //   487: istore_3
    //   488: iload_1
    //   489: ifeq -> 948
    //   492: aload_2
    //   493: sipush #-4098
    //   496: sipush #8908
    //   499: invokestatic a : (II)Ljava/lang/String;
    //   502: invokevirtual equals : (Ljava/lang/Object;)Z
    //   505: ifeq -> 948
    //   508: bipush #10
    //   510: istore_3
    //   511: iload_1
    //   512: ifeq -> 948
    //   515: aload_2
    //   516: sipush #-4108
    //   519: sipush #-13724
    //   522: invokestatic a : (II)Ljava/lang/String;
    //   525: invokevirtual equals : (Ljava/lang/Object;)Z
    //   528: ifeq -> 948
    //   531: bipush #11
    //   533: istore_3
    //   534: iload_1
    //   535: ifeq -> 948
    //   538: aload_2
    //   539: sipush #-4102
    //   542: sipush #13808
    //   545: invokestatic a : (II)Ljava/lang/String;
    //   548: invokevirtual equals : (Ljava/lang/Object;)Z
    //   551: ifeq -> 948
    //   554: bipush #12
    //   556: istore_3
    //   557: iload_1
    //   558: ifeq -> 948
    //   561: aload_2
    //   562: sipush #-4113
    //   565: sipush #14719
    //   568: invokestatic a : (II)Ljava/lang/String;
    //   571: invokevirtual equals : (Ljava/lang/Object;)Z
    //   574: ifeq -> 948
    //   577: bipush #13
    //   579: istore_3
    //   580: iload_1
    //   581: ifeq -> 948
    //   584: aload_2
    //   585: sipush #-4099
    //   588: sipush #23031
    //   591: invokestatic a : (II)Ljava/lang/String;
    //   594: invokevirtual equals : (Ljava/lang/Object;)Z
    //   597: ifeq -> 948
    //   600: bipush #14
    //   602: istore_3
    //   603: iload_1
    //   604: ifeq -> 948
    //   607: aload_2
    //   608: sipush #-4127
    //   611: sipush #-3129
    //   614: invokestatic a : (II)Ljava/lang/String;
    //   617: invokevirtual equals : (Ljava/lang/Object;)Z
    //   620: ifeq -> 948
    //   623: bipush #15
    //   625: istore_3
    //   626: iload_1
    //   627: ifeq -> 948
    //   630: aload_2
    //   631: sipush #-4119
    //   634: sipush #-27645
    //   637: invokestatic a : (II)Ljava/lang/String;
    //   640: invokevirtual equals : (Ljava/lang/Object;)Z
    //   643: ifeq -> 948
    //   646: bipush #16
    //   648: istore_3
    //   649: iload_1
    //   650: ifeq -> 948
    //   653: aload_2
    //   654: sipush #-4115
    //   657: sipush #-6824
    //   660: invokestatic a : (II)Ljava/lang/String;
    //   663: invokevirtual equals : (Ljava/lang/Object;)Z
    //   666: ifeq -> 948
    //   669: bipush #17
    //   671: istore_3
    //   672: iload_1
    //   673: ifeq -> 948
    //   676: aload_2
    //   677: sipush #-4128
    //   680: sipush #17710
    //   683: invokestatic a : (II)Ljava/lang/String;
    //   686: invokevirtual equals : (Ljava/lang/Object;)Z
    //   689: ifeq -> 948
    //   692: bipush #18
    //   694: istore_3
    //   695: iload_1
    //   696: ifeq -> 948
    //   699: aload_2
    //   700: sipush #-4145
    //   703: sipush #5208
    //   706: invokestatic a : (II)Ljava/lang/String;
    //   709: invokevirtual equals : (Ljava/lang/Object;)Z
    //   712: ifeq -> 948
    //   715: bipush #19
    //   717: istore_3
    //   718: iload_1
    //   719: ifeq -> 948
    //   722: aload_2
    //   723: sipush #-4111
    //   726: sipush #9234
    //   729: invokestatic a : (II)Ljava/lang/String;
    //   732: invokevirtual equals : (Ljava/lang/Object;)Z
    //   735: ifeq -> 948
    //   738: bipush #20
    //   740: istore_3
    //   741: iload_1
    //   742: ifeq -> 948
    //   745: aload_2
    //   746: sipush #-4126
    //   749: sipush #-17083
    //   752: invokestatic a : (II)Ljava/lang/String;
    //   755: invokevirtual equals : (Ljava/lang/Object;)Z
    //   758: ifeq -> 948
    //   761: bipush #21
    //   763: istore_3
    //   764: iload_1
    //   765: ifeq -> 948
    //   768: aload_2
    //   769: sipush #-4110
    //   772: sipush #-4335
    //   775: invokestatic a : (II)Ljava/lang/String;
    //   778: invokevirtual equals : (Ljava/lang/Object;)Z
    //   781: ifeq -> 948
    //   784: bipush #22
    //   786: istore_3
    //   787: iload_1
    //   788: ifeq -> 948
    //   791: aload_2
    //   792: sipush #-4114
    //   795: sipush #23588
    //   798: invokestatic a : (II)Ljava/lang/String;
    //   801: invokevirtual equals : (Ljava/lang/Object;)Z
    //   804: ifeq -> 948
    //   807: bipush #23
    //   809: istore_3
    //   810: iload_1
    //   811: ifeq -> 948
    //   814: aload_2
    //   815: sipush #-4107
    //   818: sipush #-13904
    //   821: invokestatic a : (II)Ljava/lang/String;
    //   824: invokevirtual equals : (Ljava/lang/Object;)Z
    //   827: ifeq -> 948
    //   830: bipush #24
    //   832: istore_3
    //   833: iload_1
    //   834: ifeq -> 948
    //   837: aload_2
    //   838: sipush #-4103
    //   841: sipush #-17422
    //   844: invokestatic a : (II)Ljava/lang/String;
    //   847: invokevirtual equals : (Ljava/lang/Object;)Z
    //   850: ifeq -> 948
    //   853: bipush #25
    //   855: istore_3
    //   856: iload_1
    //   857: ifeq -> 948
    //   860: aload_2
    //   861: sipush #-4106
    //   864: sipush #-3943
    //   867: invokestatic a : (II)Ljava/lang/String;
    //   870: invokevirtual equals : (Ljava/lang/Object;)Z
    //   873: ifeq -> 948
    //   876: bipush #26
    //   878: istore_3
    //   879: iload_1
    //   880: ifeq -> 948
    //   883: aload_2
    //   884: sipush #-4122
    //   887: sipush #25698
    //   890: invokestatic a : (II)Ljava/lang/String;
    //   893: invokevirtual equals : (Ljava/lang/Object;)Z
    //   896: ifeq -> 948
    //   899: bipush #27
    //   901: istore_3
    //   902: iload_1
    //   903: ifeq -> 948
    //   906: aload_2
    //   907: sipush #-4118
    //   910: sipush #-25004
    //   913: invokestatic a : (II)Ljava/lang/String;
    //   916: invokevirtual equals : (Ljava/lang/Object;)Z
    //   919: ifeq -> 948
    //   922: bipush #28
    //   924: istore_3
    //   925: iload_1
    //   926: ifeq -> 948
    //   929: aload_2
    //   930: sipush #-4100
    //   933: sipush #-28599
    //   936: invokestatic a : (II)Ljava/lang/String;
    //   939: invokevirtual equals : (Ljava/lang/Object;)Z
    //   942: ifeq -> 948
    //   945: bipush #29
    //   947: istore_3
    //   948: iload_3
    //   949: tableswitch default -> 1264, 0 -> 1084, 1 -> 1090, 2 -> 1096, 3 -> 1102, 4 -> 1108, 5 -> 1114, 6 -> 1120, 7 -> 1126, 8 -> 1132, 9 -> 1138, 10 -> 1144, 11 -> 1150, 12 -> 1156, 13 -> 1162, 14 -> 1168, 15 -> 1174, 16 -> 1180, 17 -> 1186, 18 -> 1192, 19 -> 1198, 20 -> 1204, 21 -> 1210, 22 -> 1216, 23 -> 1222, 24 -> 1228, 25 -> 1234, 26 -> 1240, 27 -> 1246, 28 -> 1252, 29 -> 1258
    //   1084: getstatic net/portswigger/javatooling/api/JavadocTag.AUTHOR : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1087: goto -> 1265
    //   1090: getstatic net/portswigger/javatooling/api/JavadocTag.CODE : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1093: goto -> 1265
    //   1096: getstatic net/portswigger/javatooling/api/JavadocTag.DEPRECATED : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1099: goto -> 1265
    //   1102: getstatic net/portswigger/javatooling/api/JavadocTag.DOCROOT : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1105: goto -> 1265
    //   1108: getstatic net/portswigger/javatooling/api/JavadocTag.EXCEPTION : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1111: goto -> 1265
    //   1114: getstatic net/portswigger/javatooling/api/JavadocTag.HIDDEN : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1117: goto -> 1265
    //   1120: getstatic net/portswigger/javatooling/api/JavadocTag.INDEX : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1123: goto -> 1265
    //   1126: getstatic net/portswigger/javatooling/api/JavadocTag.INHERITDOC : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1129: goto -> 1265
    //   1132: getstatic net/portswigger/javatooling/api/JavadocTag.LINK : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1135: goto -> 1265
    //   1138: getstatic net/portswigger/javatooling/api/JavadocTag.LINKPLAIN : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1141: goto -> 1265
    //   1144: getstatic net/portswigger/javatooling/api/JavadocTag.LITERAL : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1147: goto -> 1265
    //   1150: getstatic net/portswigger/javatooling/api/JavadocTag.PARAM : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1153: goto -> 1265
    //   1156: getstatic net/portswigger/javatooling/api/JavadocTag.PROVIDES : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1159: goto -> 1265
    //   1162: getstatic net/portswigger/javatooling/api/JavadocTag.RETURN : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1165: goto -> 1265
    //   1168: getstatic net/portswigger/javatooling/api/JavadocTag.SEE : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1171: goto -> 1265
    //   1174: getstatic net/portswigger/javatooling/api/JavadocTag.SERIAL : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1177: goto -> 1265
    //   1180: getstatic net/portswigger/javatooling/api/JavadocTag.SERIALDATA : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1183: goto -> 1265
    //   1186: getstatic net/portswigger/javatooling/api/JavadocTag.SERIALFIELD : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1189: goto -> 1265
    //   1192: getstatic net/portswigger/javatooling/api/JavadocTag.SINCE : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1195: goto -> 1265
    //   1198: getstatic net/portswigger/javatooling/api/JavadocTag.SUMMARY : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1201: goto -> 1265
    //   1204: getstatic net/portswigger/javatooling/api/JavadocTag.THROWS : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1207: goto -> 1265
    //   1210: getstatic net/portswigger/javatooling/api/JavadocTag.USES : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1213: goto -> 1265
    //   1216: getstatic net/portswigger/javatooling/api/JavadocTag.VALUE : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1219: goto -> 1265
    //   1222: getstatic net/portswigger/javatooling/api/JavadocTag.VERSION : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1225: goto -> 1265
    //   1228: getstatic net/portswigger/javatooling/api/JavadocTag.API_NOTE : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1231: goto -> 1265
    //   1234: getstatic net/portswigger/javatooling/api/JavadocTag.IMPL_SPEC : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1237: goto -> 1265
    //   1240: getstatic net/portswigger/javatooling/api/JavadocTag.IMPL_NOTE : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1243: goto -> 1265
    //   1246: getstatic net/portswigger/javatooling/api/JavadocTag.SNIPPET : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1249: goto -> 1265
    //   1252: getstatic net/portswigger/javatooling/api/JavadocTag.HIGHLIGHT : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1255: goto -> 1265
    //   1258: getstatic net/portswigger/javatooling/api/JavadocTag.REPLACE : Lnet/portswigger/javatooling/api/JavadocTag;
    //   1261: goto -> 1265
    //   1264: aconst_null
    //   1265: areturn
  }
  
  static {
    // Byte code:
    //   0: bipush #33
    //   2: anewarray java/lang/String
    //   5: astore #5
    //   7: iconst_0
    //   8: istore_3
    //   9: ldc ' UQËûþ\\b4ÇÓÒ<óÚ\\f²¶Ù+UÖüIWÙ\\tg8ím{û¿ÐÊC6\\nÔ¹xFÛöiÖ¹¸yûQdê@VÁø\\t¼rö?YG\\b}Añ¼°?où!`¯¶\\bÏ\\btRËËåömüÜÀÅ+¹kbâ±2,ÔÅÃ+\\nÉVQ*r-]þ\\bÑ¦c¡Ö7·³n\\bÇ­M¿¨\\nä.ÔÕ½5×¨¨\\t6Ö+½áÃ\\tãø!ËÕgÇ¥yÖö4x£\\tãâ~_ê\\tì\\t+¶8öCbì0\\b¦c¨ÿ\\r>1sô?r,"ÄÚõ^ÀµnwÚöìMFñ ilî'
    //   11: dup
    //   12: astore_2
    //   13: invokevirtual length : ()I
    //   16: istore #4
    //   18: bipush #7
    //   20: istore_1
    //   21: iconst_m1
    //   22: istore_0
    //   23: iinc #0, 1
    //   26: aload_2
    //   27: iload_0
    //   28: dup
    //   29: iload_1
    //   30: iadd
    //   31: invokevirtual substring : (II)Ljava/lang/String;
    //   34: iconst_m1
    //   35: goto -> 139
    //   38: aload #5
    //   40: swap
    //   41: iload_3
    //   42: iinc #3, 1
    //   45: swap
    //   46: aastore
    //   47: iload_0
    //   48: iload_1
    //   49: iadd
    //   50: dup
    //   51: istore_0
    //   52: iload #4
    //   54: if_icmpge -> 66
    //   57: aload_2
    //   58: iload_0
    //   59: invokevirtual charAt : (I)C
    //   62: istore_1
    //   63: goto -> 23
    //   66: ldc '­¯.ÑWqMa\\be¦<?gá'
    //   68: dup
    //   69: astore_2
    //   70: invokevirtual length : ()I
    //   73: istore #4
    //   75: bipush #11
    //   77: istore_1
    //   78: iconst_m1
    //   79: istore_0
    //   80: iinc #0, 1
    //   83: aload_2
    //   84: iload_0
    //   85: dup
    //   86: iload_1
    //   87: iadd
    //   88: invokevirtual substring : (II)Ljava/lang/String;
    //   91: iconst_0
    //   92: goto -> 139
    //   95: aload #5
    //   97: swap
    //   98: iload_3
    //   99: iinc #3, 1
    //   102: swap
    //   103: aastore
    //   104: iload_0
    //   105: iload_1
    //   106: iadd
    //   107: dup
    //   108: istore_0
    //   109: iload #4
    //   111: if_icmpge -> 123
    //   114: aload_2
    //   115: iload_0
    //   116: invokevirtual charAt : (I)C
    //   119: istore_1
    //   120: goto -> 80
    //   123: aload #5
    //   125: putstatic burp/Z_.a : [Ljava/lang/String;
    //   128: bipush #33
    //   130: anewarray java/lang/String
    //   133: putstatic burp/Z_.b : [Ljava/lang/String;
    //   136: goto -> 292
    //   139: swap
    //   140: invokevirtual toCharArray : ()[C
    //   143: dup
    //   144: arraylength
    //   145: swap
    //   146: iconst_0
    //   147: istore #6
    //   149: swap
    //   150: dup_x1
    //   151: iconst_1
    //   152: if_icmpgt -> 252
    //   155: dup
    //   156: iload #6
    //   158: dup2
    //   159: caload
    //   160: iload #6
    //   162: bipush #7
    //   164: irem
    //   165: tableswitch default -> 234, 0 -> 204, 1 -> 209, 2 -> 214, 3 -> 219, 4 -> 224, 5 -> 229
    //   204: bipush #24
    //   206: goto -> 236
    //   209: bipush #21
    //   211: goto -> 236
    //   214: bipush #123
    //   216: goto -> 236
    //   219: bipush #66
    //   221: goto -> 236
    //   224: bipush #50
    //   226: goto -> 236
    //   229: bipush #123
    //   231: goto -> 236
    //   234: bipush #116
    //   236: ixor
    //   237: i2c
    //   238: castore
    //   239: iinc #6, 1
    //   242: swap
    //   243: dup_x1
    //   244: ifne -> 252
    //   247: dup2
    //   248: swap
    //   249: goto -> 158
    //   252: swap
    //   253: dup_x1
    //   254: iload #6
    //   256: if_icmpgt -> 155
    //   259: new java/lang/String
    //   262: dup_x1
    //   263: swap
    //   264: invokespecial <init> : ([C)V
    //   267: invokevirtual intern : ()Ljava/lang/String;
    //   270: swap
    //   271: pop
    //   272: swap
    //   273: tableswitch default -> 38, 0 -> 95
    //   292: return
  }
  
  private static String a(int paramInt1, int paramInt2) {
    int i = (paramInt1 ^ 0xFFFFEFEF) & 0xFFFF;
    if (b[i] == null) {
      char[] arrayOfChar = a[i].toCharArray();
      switch (arrayOfChar[0] & 0xFF) {
        case 0:
        
        case 1:
        
        case 2:
        
        case 3:
        
        case 4:
        
        case 5:
        
        case 6:
        
        case 7:
        
        case 8:
        
        case 9:
        
        case 10:
        
        case 11:
        
        case 12:
        
        case 13:
        
        case 14:
        
        case 15:
        
        case 16:
        
        case 17:
        
        case 18:
        
        case 19:
        
        case 20:
        
        case 21:
        
        case 22:
        
        case 23:
        
        case 24:
        
        case 25:
        
        case 26:
        
        case 27:
        
        case 28:
        
        case 29:
        
        case 30:
        
        case 31:
        
        case 32:
        
        case 33:
        
        case 34:
        
        case 35:
        
        case 36:
        
        case 37:
        
        case 38:
        
        case 39:
        
        case 40:
        
        case 41:
        
        case 42:
        
        case 43:
        
        case 44:
        
        case 45:
        
        case 46:
        
        case 47:
        
        case 48:
        
        case 49:
        
        case 50:
        
        case 51:
        
        case 52:
        
        case 53:
        
        case 54:
        
        case 55:
        
        case 56:
        
        case 57:
        
        case 58:
        
        case 59:
        
        case 60:
        
        case 61:
        
        case 62:
        
        case 63:
        
        case 64:
        
        case 65:
        
        case 66:
        
        case 67:
        
        case 68:
        
        case 69:
        
        case 70:
        
        case 71:
        
        case 72:
        
        case 73:
        
        case 74:
        
        case 75:
        
        case 76:
        
        case 77:
        
        case 78:
        
        case 79:
        
        case 80:
        
        case 81:
        
        case 82:
        
        case 83:
        
        case 84:
        
        case 85:
        
        case 86:
        
        case 87:
        
        case 88:
        
        case 89:
        
        case 90:
        
        case 91:
        
        case 92:
        
        case 93:
        
        case 94:
        
        case 95:
        
        case 96:
        
        case 97:
        
        case 98:
        
        case 99:
        
        case 100:
        
        case 101:
        
        case 102:
        
        case 103:
        
        case 104:
        
        case 105:
        
        case 106:
        
        case 107:
        
        case 108:
        
        case 109:
        
        case 110:
        
        case 111:
        
        case 112:
        
        case 113:
        
        case 114:
        
        case 115:
        
        case 116:
        
        case 117:
        
        case 118:
        
        case 119:
        
        case 120:
        
        case 121:
        
        case 122:
        
        case 123:
        
        case 124:
        
        case 125:
        
        case 126:
        
        case 127:
        
        case 128:
        
        case 129:
        
        case 130:
        
        case 131:
        
        case 132:
        
        case 133:
        
        case 134:
        
        case 135:
        
        case 136:
        
        case 137:
        
        case 138:
        
        case 139:
        
        case 140:
        
        case 141:
        
        case 142:
        
        case 143:
        
        case 144:
        
        case 145:
        
        case 146:
        
        case 147:
        
        case 148:
        
        case 149:
        
        case 150:
        
        case 151:
        
        case 152:
        
        case 153:
        
        case 154:
        
        case 155:
        
        case 156:
        
        case 157:
        
        case 158:
        
        case 159:
        
        case 160:
        
        case 161:
        
        case 162:
        
        case 163:
        
        case 164:
        
        case 165:
        
        case 166:
        
        case 167:
        
        case 168:
        
        case 169:
        
        case 170:
        
        case 171:
        
        case 172:
        
        case 173:
        
        case 174:
        
        case 175:
        
        case 176:
        
        case 177:
        
        case 178:
        
        case 179:
        
        case 180:
        
        case 181:
        
        case 182:
        
        case 183:
        
        case 184:
        
        case 185:
        
        case 186:
        
        case 187:
        
        case 188:
        
        case 189:
        
        case 190:
        
        case 191:
        
        case 192:
        
        case 193:
        
        case 194:
        
        case 195:
        
        case 196:
        
        case 197:
        
        case 198:
        
        case 199:
        
        case 200:
        
        case 201:
        
        case 202:
        
        case 203:
        
        case 204:
        
        case 205:
        
        case 206:
        
        case 207:
        
        case 208:
        
        case 209:
        
        case 210:
        
        case 211:
        
        case 212:
        
        case 213:
        
        case 214:
        
        case 215:
        
        case 216:
        
        case 217:
        
        case 218:
        
        case 219:
        
        case 220:
        
        case 221:
        
        case 222:
        
        case 223:
        
        case 224:
        
        case 225:
        
        case 226:
        
        case 227:
        
        case 228:
        
        case 229:
        
        case 230:
        
        case 231:
        
        case 232:
        
        case 233:
        
        case 234:
        
        case 235:
        
        case 236:
        
        case 237:
        
        case 238:
        
        case 239:
        
        case 240:
        
        case 241:
        
        case 242:
        
        case 243:
        
        case 244:
        
        case 245:
        
        case 246:
        
        case 247:
        
        case 248:
        
        case 249:
        
        case 250:
        
        case 251:
        
        case 252:
        
        case 253:
        
        case 254:
        
        default:
          break;
      } 
      byte b1 = 72;
      int j = (paramInt2 & 0xFF) - b1;
      if (j < 0)
        j += 256; 
      int k = ((paramInt2 & 0xFFFF) >>> 8) - b1;
      if (k < 0)
        k += 256; 
      for (byte b2 = 0; b2 < arrayOfChar.length; b2++) {
        int m = b2 % 2;
        if (m == 0) {
          arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ j);
          j = ((j >>> 3 | j << 5) ^ arrayOfChar[b2]) & 0xFF;
        } else {
          arrayOfChar[b2] = (char)(arrayOfChar[b2] ^ k);
          k = ((k >>> 3 | k << 5) ^ arrayOfChar[b2]) & 0xFF;
        } 
      } 
      b[i] = (new String(arrayOfChar)).intern();
    } 
    return b[i];
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\java-tooling-plugin-1.0.0.jar!\burp\Z_.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */