package burp;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import net.portswigger.javatooling.api.ClasspathService;
import net.portswigger.javatooling.api.CompilationService;
import net.portswigger.javatooling.api.CompletionService;
import net.portswigger.javatooling.api.JavadocService;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class Zo implements BundleActivator {
  private final Ze Zx = new Ze();
  
  private final List<ServiceRegistration<?>> Zu = new ArrayList<>();
  
  public void start(BundleContext paramBundleContext) throws Exception {
    this.Zx.Zz();
    boolean bool = Zr.Za;
    try {
      this.Zu.add(paramBundleContext.registerService(ClasspathService.class.getName(), new Zd(this.Zx), new Hashtable<>()));
      this.Zu.add(paramBundleContext.registerService(CompilationService.class.getName(), new Zg(this.Zx), new Hashtable<>()));
      this.Zu.add(paramBundleContext.registerService(CompletionService.class.getName(), new Zc(this.Zx), new Hashtable<>()));
      this.Zu.add(paramBundleContext.registerService(JavadocService.class.getName(), new Zr(this.Zx), new Hashtable<>()));
      if (Ze.Zu) {
        try {
        
        } catch (Exception exception) {
          throw null;
        } 
        Zr.Za = !bool;
      } 
    } catch (Exception exception) {
      throw null;
    } 
  }
  
  public void stop(BundleContext paramBundleContext) throws Exception {
    this.Zu.forEach(ServiceRegistration::unregister);
    this.Zu.clear();
    this.Zx.ZC();
  }
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\java-tooling-plugin-1.0.0.jar!\burp\Zo.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */