package org.osgi.util.promise;

import java.lang.reflect.InvocationTargetException;
import org.osgi.annotation.versioning.ProviderType;
import org.osgi.util.function.Function;
import org.osgi.util.function.Predicate;

@ProviderType
public interface Promise<T> {
  boolean isDone();
  
  T getValue() throws InvocationTargetException, InterruptedException;
  
  Throwable getFailure() throws InterruptedException;
  
  Promise<T> onResolve(Runnable paramRunnable);
  
  <R> Promise<R> then(Success<? super T, ? extends R> paramSuccess, Failure paramFailure);
  
  <R> Promise<R> then(Success<? super T, ? extends R> paramSuccess);
  
  Promise<T> filter(Predicate<? super T> paramPredicate);
  
  <R> Promise<R> map(Function<? super T, ? extends R> paramFunction);
  
  <R> Promise<R> flatMap(Function<? super T, Promise<? extends R>> paramFunction);
  
  Promise<T> recover(Function<Promise<?>, ? extends T> paramFunction);
  
  Promise<T> recoverWith(Function<Promise<?>, Promise<? extends T>> paramFunction);
  
  Promise<T> fallbackTo(Promise<? extends T> paramPromise);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.util.promise-1.0.0.jar!\org\osg\\util\promise\Promise.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */