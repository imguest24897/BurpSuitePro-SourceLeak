package org.osgi.util.promise;

import org.osgi.annotation.versioning.ConsumerType;

@ConsumerType
public interface Success<T, R> {
  Promise<R> call(Promise<T> paramPromise) throws Exception;
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.util.promise-1.0.0.jar!\org\osg\\util\promise\Success.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */