package org.osgi.util.promise;

import org.osgi.annotation.versioning.Version;

@Version("1.0")
interface package-info {}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.util.promise-1.0.0.jar!\org\osg\\util\promise\package-info.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */