/*     */ package org.osgi.util.promise;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.logging.Level;
/*     */ import org.osgi.util.function.Function;
/*     */ import org.osgi.util.function.Predicate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PromiseImpl<T>
/*     */   implements Promise<T>
/*     */ {
/*     */   private final ConcurrentLinkedQueue<Runnable> callbacks;
/*     */   private final CountDownLatch resolved;
/*     */   private T value;
/*     */   private Throwable fail;
/*     */   
/*     */   PromiseImpl() {
/*  81 */     this.callbacks = new ConcurrentLinkedQueue<Runnable>();
/*  82 */     this.resolved = new CountDownLatch(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PromiseImpl(T v, Throwable f) {
/*  92 */     this.value = v;
/*  93 */     this.fail = f;
/*  94 */     this.callbacks = new ConcurrentLinkedQueue<Runnable>();
/*  95 */     this.resolved = new CountDownLatch(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void resolve(T v, Throwable f) {
/* 106 */     synchronized (this.resolved) {
/* 107 */       if (this.resolved.getCount() == 0L) {
/* 108 */         throw new IllegalStateException("Already resolved");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 115 */       this.value = v;
/* 116 */       this.fail = f;
/* 117 */       this.resolved.countDown();
/*     */     } 
/* 119 */     notifyCallbacks();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void notifyCallbacks() {
/* 126 */     if (this.resolved.getCount() != 0L) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     for (Runnable callback = this.callbacks.poll(); callback != null; callback = this.callbacks.poll()) {
/*     */       try {
/* 137 */         callback.run();
/* 138 */       } catch (Throwable t) {
/* 139 */         Logger.logCallbackException(t);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDone() {
/* 148 */     return (this.resolved.getCount() == 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getValue() throws InvocationTargetException, InterruptedException {
/* 155 */     this.resolved.await();
/* 156 */     if (this.fail == null) {
/* 157 */       return this.value;
/*     */     }
/* 159 */     throw new InvocationTargetException(this.fail);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Throwable getFailure() throws InterruptedException {
/* 166 */     this.resolved.await();
/* 167 */     return this.fail;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Promise<T> onResolve(Runnable callback) {
/* 174 */     this.callbacks.offer(callback);
/* 175 */     notifyCallbacks();
/* 176 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Promise<R> then(Success<? super T, ? extends R> success, Failure failure) {
/* 183 */     PromiseImpl<R> chained = new PromiseImpl();
/* 184 */     onResolve(new Then<R>(chained, success, failure));
/* 185 */     return chained;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Promise<R> then(Success<? super T, ? extends R> success) {
/* 192 */     return then(success, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class Then<R>
/*     */     implements Runnable
/*     */   {
/*     */     private final PromiseImpl<R> chained;
/*     */     
/*     */     private final Success<T, ? extends R> success;
/*     */     
/*     */     private final Failure failure;
/*     */ 
/*     */     
/*     */     Then(PromiseImpl<R> chained, Success<? super T, ? extends R> success, Failure failure) {
/* 208 */       this.chained = chained;
/* 209 */       this.success = (Success)success;
/* 210 */       this.failure = failure;
/*     */     }
/*     */     
/*     */     public void run() {
/*     */       Throwable f;
/* 215 */       boolean interrupted = Thread.interrupted();
/*     */       try {
/* 217 */         f = PromiseImpl.this.getFailure();
/* 218 */       } catch (Throwable e) {
/* 219 */         f = e;
/*     */       } finally {
/* 221 */         if (interrupted) {
/* 222 */           Thread.currentThread().interrupt();
/*     */         }
/*     */       } 
/* 225 */       if (f != null) {
/* 226 */         if (this.failure != null) {
/*     */           try {
/* 228 */             this.failure.fail(PromiseImpl.this);
/* 229 */           } catch (Throwable e) {
/* 230 */             f = e;
/*     */           } 
/*     */         }
/*     */         
/* 234 */         this.chained.resolve(null, f);
/*     */         return;
/*     */       } 
/* 237 */       Promise<? extends R> returned = null;
/* 238 */       if (this.success != null) {
/*     */         try {
/* 240 */           returned = this.success.call(PromiseImpl.this);
/* 241 */         } catch (Throwable e) {
/* 242 */           this.chained.resolve(null, e);
/*     */           return;
/*     */         } 
/*     */       }
/* 246 */       if (returned == null) {
/*     */         
/* 248 */         this.chained.resolve(null, null);
/*     */       } else {
/*     */         
/* 251 */         returned.onResolve(new PromiseImpl.Chain<R>(this.chained, returned));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Chain<R>
/*     */     implements Runnable
/*     */   {
/*     */     private final PromiseImpl<R> chained;
/*     */     
/*     */     private final Promise<? extends R> promise;
/*     */     
/*     */     private final Throwable failure;
/*     */ 
/*     */     
/*     */     Chain(PromiseImpl<R> chained, Promise<? extends R> promise) {
/* 268 */       this.chained = chained;
/* 269 */       this.promise = promise;
/* 270 */       this.failure = null;
/*     */     }
/*     */     
/*     */     Chain(PromiseImpl<R> chained, Promise<? extends R> promise, Throwable failure) {
/* 274 */       this.chained = chained;
/* 275 */       this.promise = promise;
/* 276 */       this.failure = failure;
/*     */     }
/*     */     public void run() {
/*     */       Throwable f;
/* 280 */       R value = null;
/*     */       
/* 282 */       boolean interrupted = Thread.interrupted();
/*     */       try {
/* 284 */         f = this.promise.getFailure();
/* 285 */         if (f == null) {
/* 286 */           value = this.promise.getValue();
/* 287 */         } else if (this.failure != null) {
/* 288 */           f = this.failure;
/*     */         } 
/* 290 */       } catch (Throwable e) {
/* 291 */         f = e;
/*     */       } finally {
/* 293 */         if (interrupted) {
/* 294 */           Thread.currentThread().interrupt();
/*     */         }
/*     */       } 
/* 297 */       this.chained.resolve(value, f);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Promise<Void> resolveWith(Promise<? extends T> with) {
/* 321 */     PromiseImpl<Void> chained = new PromiseImpl();
/* 322 */     ResolveWith resolveWith = new ResolveWith(chained);
/* 323 */     with.then(resolveWith, resolveWith);
/* 324 */     return chained;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class ResolveWith
/*     */     implements Success<T, Void>, Failure
/*     */   {
/*     */     private final PromiseImpl<Void> chained;
/*     */ 
/*     */ 
/*     */     
/*     */     ResolveWith(PromiseImpl<Void> chained) {
/* 337 */       this.chained = chained;
/*     */     }
/*     */     
/*     */     public Promise<Void> call(Promise<T> with) throws Exception {
/*     */       try {
/* 342 */         PromiseImpl.this.resolve(with.getValue(), null);
/* 343 */       } catch (Throwable e) {
/* 344 */         this.chained.resolve(null, e);
/* 345 */         return null;
/*     */       } 
/* 347 */       this.chained.resolve(null, null);
/* 348 */       return null;
/*     */     }
/*     */     
/*     */     public void fail(Promise<?> with) throws Exception {
/*     */       try {
/* 353 */         PromiseImpl.this.resolve(null, with.getFailure());
/* 354 */       } catch (Throwable e) {
/* 355 */         this.chained.resolve(null, e);
/*     */         return;
/*     */       } 
/* 358 */       this.chained.resolve(null, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Promise<T> filter(Predicate<? super T> predicate) {
/* 366 */     return then(new Filter<T>(predicate));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Filter<T>
/*     */     implements Success<T, T>
/*     */   {
/*     */     private final Predicate<? super T> predicate;
/*     */ 
/*     */     
/*     */     Filter(Predicate<? super T> predicate) {
/* 378 */       this.predicate = PromiseImpl.<Predicate<? super T>>requireNonNull(predicate);
/*     */     }
/*     */     
/*     */     public Promise<T> call(Promise<T> resolved) throws Exception {
/* 382 */       if (this.predicate.test(resolved.getValue())) {
/* 383 */         return resolved;
/*     */       }
/* 385 */       throw new NoSuchElementException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Promise<R> map(Function<? super T, ? extends R> mapper) {
/* 393 */     return then(new Map<T, R>(mapper));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Map<T, R>
/*     */     implements Success<T, R>
/*     */   {
/*     */     private final Function<? super T, ? extends R> mapper;
/*     */ 
/*     */     
/*     */     Map(Function<? super T, ? extends R> mapper) {
/* 405 */       this.mapper = PromiseImpl.<Function<? super T, ? extends R>>requireNonNull(mapper);
/*     */     }
/*     */     
/*     */     public Promise<R> call(Promise<T> resolved) throws Exception {
/* 409 */       return new PromiseImpl<R>((R)this.mapper.apply(resolved.getValue()), null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <R> Promise<R> flatMap(Function<? super T, Promise<? extends R>> mapper) {
/* 417 */     return then(new FlatMap<T, R>(mapper));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class FlatMap<T, R>
/*     */     implements Success<T, R>
/*     */   {
/*     */     private final Function<? super T, Promise<? extends R>> mapper;
/*     */ 
/*     */     
/*     */     FlatMap(Function<? super T, Promise<? extends R>> mapper) {
/* 429 */       this.mapper = PromiseImpl.<Function<? super T, Promise<? extends R>>>requireNonNull(mapper);
/*     */     }
/*     */ 
/*     */     
/*     */     public Promise<R> call(Promise<T> resolved) throws Exception {
/* 434 */       return (Promise<R>)this.mapper.apply(resolved.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Promise<T> recover(Function<Promise<?>, ? extends T> recovery) {
/* 442 */     PromiseImpl<T> chained = new PromiseImpl();
/* 443 */     Recover<T> recover = new Recover<T>(chained, recovery);
/* 444 */     then(recover, recover);
/* 445 */     return chained;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Recover<T>
/*     */     implements Success<T, Void>, Failure
/*     */   {
/*     */     private final PromiseImpl<T> chained;
/*     */     
/*     */     private final Function<Promise<?>, ? extends T> recovery;
/*     */ 
/*     */     
/*     */     Recover(PromiseImpl<T> chained, Function<Promise<?>, ? extends T> recovery) {
/* 458 */       this.chained = chained;
/* 459 */       this.recovery = PromiseImpl.<Function<Promise<?>, ? extends T>>requireNonNull(recovery);
/*     */     }
/*     */     
/*     */     public Promise<Void> call(Promise<T> resolved) throws Exception {
/*     */       T value;
/*     */       try {
/* 465 */         value = resolved.getValue();
/* 466 */       } catch (Throwable e) {
/* 467 */         this.chained.resolve(null, e);
/* 468 */         return null;
/*     */       } 
/* 470 */       this.chained.resolve(value, null);
/* 471 */       return null;
/*     */     }
/*     */     
/*     */     public void fail(Promise<?> resolved) throws Exception {
/*     */       T recovered;
/*     */       Throwable failure;
/*     */       try {
/* 478 */         recovered = (T)this.recovery.apply(resolved);
/* 479 */         failure = resolved.getFailure();
/* 480 */       } catch (Throwable e) {
/* 481 */         this.chained.resolve(null, e);
/*     */         return;
/*     */       } 
/* 484 */       if (recovered == null) {
/* 485 */         this.chained.resolve(null, failure);
/*     */       } else {
/* 487 */         this.chained.resolve(recovered, null);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Promise<T> recoverWith(Function<Promise<?>, Promise<? extends T>> recovery) {
/* 496 */     PromiseImpl<T> chained = new PromiseImpl();
/* 497 */     RecoverWith<T> recoverWith = new RecoverWith<T>(chained, recovery);
/* 498 */     then(recoverWith, recoverWith);
/* 499 */     return chained;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class RecoverWith<T>
/*     */     implements Success<T, Void>, Failure
/*     */   {
/*     */     private final PromiseImpl<T> chained;
/*     */     
/*     */     private final Function<Promise<?>, Promise<? extends T>> recovery;
/*     */ 
/*     */     
/*     */     RecoverWith(PromiseImpl<T> chained, Function<Promise<?>, Promise<? extends T>> recovery) {
/* 512 */       this.chained = chained;
/* 513 */       this.recovery = PromiseImpl.<Function<Promise<?>, Promise<? extends T>>>requireNonNull(recovery);
/*     */     }
/*     */     
/*     */     public Promise<Void> call(Promise<T> resolved) throws Exception {
/*     */       T value;
/*     */       try {
/* 519 */         value = resolved.getValue();
/* 520 */       } catch (Throwable e) {
/* 521 */         this.chained.resolve(null, e);
/* 522 */         return null;
/*     */       } 
/* 524 */       this.chained.resolve(value, null);
/* 525 */       return null;
/*     */     }
/*     */     
/*     */     public void fail(Promise<?> resolved) throws Exception {
/*     */       Promise<? extends T> recovered;
/*     */       Throwable failure;
/*     */       try {
/* 532 */         recovered = (Promise<? extends T>)this.recovery.apply(resolved);
/* 533 */         failure = resolved.getFailure();
/* 534 */       } catch (Throwable e) {
/* 535 */         this.chained.resolve(null, e);
/*     */         return;
/*     */       } 
/* 538 */       if (recovered == null) {
/* 539 */         this.chained.resolve(null, failure);
/*     */       } else {
/* 541 */         recovered.onResolve(new PromiseImpl.Chain<T>(this.chained, recovered));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Promise<T> fallbackTo(Promise<? extends T> fallback) {
/* 550 */     PromiseImpl<T> chained = new PromiseImpl();
/* 551 */     FallbackTo<T> fallbackTo = new FallbackTo<T>(chained, fallback);
/* 552 */     then(fallbackTo, fallbackTo);
/* 553 */     return chained;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class FallbackTo<T>
/*     */     implements Success<T, Void>, Failure
/*     */   {
/*     */     private final PromiseImpl<T> chained;
/*     */     
/*     */     private final Promise<? extends T> fallback;
/*     */ 
/*     */     
/*     */     FallbackTo(PromiseImpl<T> chained, Promise<? extends T> fallback) {
/* 566 */       this.chained = chained;
/* 567 */       this.fallback = PromiseImpl.<Promise<? extends T>>requireNonNull(fallback);
/*     */     }
/*     */     
/*     */     public Promise<Void> call(Promise<T> resolved) throws Exception {
/*     */       T value;
/*     */       try {
/* 573 */         value = resolved.getValue();
/* 574 */       } catch (Throwable e) {
/* 575 */         this.chained.resolve(null, e);
/* 576 */         return null;
/*     */       } 
/* 578 */       this.chained.resolve(value, null);
/* 579 */       return null;
/*     */     }
/*     */     
/*     */     public void fail(Promise<?> resolved) throws Exception {
/*     */       Throwable failure;
/*     */       try {
/* 585 */         failure = resolved.getFailure();
/* 586 */       } catch (Throwable e) {
/* 587 */         this.chained.resolve(null, e);
/*     */         return;
/*     */       } 
/* 590 */       this.fallback.onResolve(new PromiseImpl.Chain<T>(this.chained, this.fallback, failure));
/*     */     }
/*     */   }
/*     */   
/*     */   static <V> V requireNonNull(V value) {
/* 595 */     if (value != null) {
/* 596 */       return value;
/*     */     }
/* 598 */     throw new NullPointerException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Logger
/*     */   {
/* 608 */     private static final java.util.logging.Logger LOGGER = java.util.logging.Logger.getLogger(PromiseImpl.class.getName());
/*     */ 
/*     */     
/*     */     static void logCallbackException(Throwable t) {
/* 612 */       LOGGER.log(Level.WARNING, "Exception from Promise callback", t);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.util.promise-1.0.0.jar!\org\osg\\util\promise\PromiseImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */