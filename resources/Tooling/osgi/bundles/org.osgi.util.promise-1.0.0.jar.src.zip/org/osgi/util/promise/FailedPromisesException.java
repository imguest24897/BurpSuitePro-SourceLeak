/*    */ package org.osgi.util.promise;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FailedPromisesException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final Collection<Promise<?>> failed;
/*    */   
/*    */   public FailedPromisesException(Collection<Promise<?>> failed, Throwable cause) {
/* 41 */     super(cause);
/* 42 */     this.failed = Collections.unmodifiableCollection(failed);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Collection<Promise<?>> getFailedPromises() {
/* 53 */     return this.failed;
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.util.promise-1.0.0.jar!\org\osg\\util\promise\FailedPromisesException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */