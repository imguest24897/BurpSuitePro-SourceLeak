/*     */ package org.osgi.util.promise;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Promises
/*     */ {
/*     */   public static <T> Promise<T> resolved(T value) {
/*  45 */     return new PromiseImpl<T>(value, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Promise<T> failed(Throwable failure) {
/*  57 */     return new PromiseImpl<T>(null, PromiseImpl.<Throwable>requireNonNull(failure));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, S extends T> Promise<List<T>> all(Collection<Promise<S>> promises) {
/*  87 */     if (promises.isEmpty()) {
/*  88 */       List<T> result = new ArrayList<T>();
/*  89 */       return resolved(result);
/*     */     } 
/*     */     
/*  92 */     List<Promise<? extends T>> list = new ArrayList<Promise<? extends T>>(promises);
/*  93 */     PromiseImpl<List<T>> chained = new PromiseImpl<List<T>>();
/*  94 */     All<T> all = new All<T>(chained, list);
/*  95 */     for (Promise<? extends T> promise : list) {
/*  96 */       promise.onResolve(all);
/*     */     }
/*  98 */     return chained;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Promise<List<T>> all(Promise<? extends T>... promises) {
/* 126 */     List<Promise<T>> list = Arrays.asList((Promise<T>[])promises);
/* 127 */     return all(list);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class All<T>
/*     */     implements Runnable
/*     */   {
/*     */     private final PromiseImpl<List<T>> chained;
/*     */     
/*     */     private final List<Promise<? extends T>> promises;
/*     */     
/*     */     private final AtomicInteger promiseCount;
/*     */ 
/*     */     
/*     */     All(PromiseImpl<List<T>> chained, List<Promise<? extends T>> promises) {
/* 142 */       this.chained = chained;
/* 143 */       this.promises = promises;
/* 144 */       this.promiseCount = new AtomicInteger(promises.size());
/*     */     }
/*     */     
/*     */     public void run() {
/* 148 */       if (this.promiseCount.decrementAndGet() != 0) {
/*     */         return;
/*     */       }
/* 151 */       List<T> result = new ArrayList<T>(this.promises.size());
/* 152 */       List<Promise<?>> failed = new ArrayList<Promise<?>>(this.promises.size());
/* 153 */       Throwable cause = null;
/* 154 */       for (Promise<? extends T> promise : this.promises) {
/*     */         Throwable failure;
/*     */         T value;
/*     */         try {
/* 158 */           failure = promise.getFailure();
/* 159 */           value = (failure != null) ? null : promise.getValue();
/* 160 */         } catch (Throwable e) {
/* 161 */           this.chained.resolve(null, e);
/*     */           return;
/*     */         } 
/* 164 */         if (failure != null) {
/* 165 */           failed.add(promise);
/* 166 */           if (cause == null)
/* 167 */             cause = failure; 
/*     */           continue;
/*     */         } 
/* 170 */         result.add(value);
/*     */       } 
/*     */       
/* 173 */       if (failed.isEmpty()) {
/* 174 */         this.chained.resolve(result, null);
/*     */       } else {
/* 176 */         this.chained.resolve(null, new FailedPromisesException(failed, cause));
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.osgi.util.promise-1.0.0.jar!\org\osg\\util\promise\Promises.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */