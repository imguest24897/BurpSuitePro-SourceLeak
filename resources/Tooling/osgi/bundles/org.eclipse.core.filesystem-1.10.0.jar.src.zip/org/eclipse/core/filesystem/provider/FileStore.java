/*     */ package org.eclipse.core.filesystem.provider;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import org.eclipse.core.filesystem.EFS;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.filesystem.IFileSystem;
/*     */ import org.eclipse.core.internal.filesystem.FileCache;
/*     */ import org.eclipse.core.internal.filesystem.Messages;
/*     */ import org.eclipse.core.internal.filesystem.Policy;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FileStore
/*     */   extends PlatformObject
/*     */   implements IFileStore
/*     */ {
/*  38 */   protected static final IFileInfo[] EMPTY_FILE_INFO_ARRAY = new IFileInfo[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   protected static final String[] EMPTY_STRING_ARRAY = new String[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void transferStreams(InputStream source, OutputStream destination, long length, String path, IProgressMonitor monitor) throws CoreException {
/*  59 */     byte[] buffer = new byte[8192];
/*  60 */     SubMonitor subMonitor = SubMonitor.convert(monitor, (length >= 0L) ? (1 + (int)(length / buffer.length)) : 1000);
/*     */     try {
/*     */       while (true) {
/*  63 */         int bytesRead = -1;
/*     */         try {
/*  65 */           bytesRead = source.read(buffer);
/*  66 */         } catch (IOException e) {
/*  67 */           String msg = NLS.bind(Messages.failedReadDuringWrite, path);
/*  68 */           Policy.error(271, msg, e);
/*     */         } 
/*     */         try {
/*  71 */           if (bytesRead == -1) {
/*  72 */             destination.close();
/*     */             break;
/*     */           } 
/*  75 */           destination.write(buffer, 0, bytesRead);
/*  76 */         } catch (IOException e) {
/*  77 */           String msg = NLS.bind(Messages.couldNotWrite, path);
/*  78 */           Policy.error(272, msg, e);
/*     */         } 
/*  80 */         subMonitor.worked(1);
/*     */       } 
/*     */     } finally {
/*  83 */       Policy.safeClose(source);
/*  84 */       Policy.safeClose(destination);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileInfo[] childInfos(int options, IProgressMonitor monitor) throws CoreException {
/*  96 */     IFileStore[] childStores = childStores(options, monitor);
/*  97 */     IFileInfo[] childInfos = new IFileInfo[childStores.length];
/*  98 */     for (int i = 0; i < childStores.length; i++) {
/*  99 */       childInfos[i] = childStores[i].fetchInfo();
/*     */     }
/* 101 */     return childInfos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String[] childNames(int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileStore[] childStores(int options, IProgressMonitor monitor) throws CoreException {
/* 113 */     String[] children = childNames(options, monitor);
/* 114 */     IFileStore[] wrapped = new IFileStore[children.length];
/* 115 */     for (int i = 0; i < wrapped.length; i++)
/* 116 */       wrapped[i] = getChild(children[i]); 
/* 117 */     return wrapped;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void copy(IFileStore destination, int options, IProgressMonitor monitor) throws CoreException {
/* 127 */     IFileInfo sourceInfo = fetchInfo(0, null);
/* 128 */     if (sourceInfo.isDirectory()) {
/* 129 */       copyDirectory(sourceInfo, destination, options, monitor);
/*     */     } else {
/* 131 */       copyFile(sourceInfo, destination, options, monitor);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void copyDirectory(IFileInfo sourceInfo, IFileStore destination, int options, IProgressMonitor monitor) throws CoreException {
/* 152 */     IFileStore[] children = null;
/* 153 */     int opWork = 1;
/* 154 */     if ((options & 0x4) == 0) {
/* 155 */       children = childStores(0, null);
/* 156 */       opWork += children.length;
/*     */     } 
/* 158 */     SubMonitor subMonitor = SubMonitor.convert(monitor, opWork);
/* 159 */     subMonitor.subTask(NLS.bind(Messages.copying, toString()));
/*     */     
/* 161 */     destination.mkdir(0, (IProgressMonitor)subMonitor.newChild(1));
/*     */     
/* 163 */     transferAttributes(sourceInfo, destination);
/*     */     
/* 165 */     if (children == null)
/*     */       return;  byte b; int i;
/*     */     IFileStore[] arrayOfIFileStore1;
/* 168 */     for (i = (arrayOfIFileStore1 = children).length, b = 0; b < i; ) { IFileStore c = arrayOfIFileStore1[b];
/* 169 */       c.copy(destination.getChild(c.getName()), options, (IProgressMonitor)subMonitor.newChild(1));
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void copyFile(IFileInfo sourceInfo, IFileStore destination, int options, IProgressMonitor monitor) throws CoreException {
/* 192 */     if ((options & 0x2) == 0 && destination.fetchInfo().exists())
/* 193 */       Policy.error(268, NLS.bind(Messages.fileExists, destination)); 
/* 194 */     long length = sourceInfo.getLength();
/* 195 */     String sourcePath = toString();
/* 196 */     SubMonitor subMonitor = SubMonitor.convert(monitor, NLS.bind(Messages.copying, sourcePath), 100);
/* 197 */     InputStream in = null;
/* 198 */     OutputStream out = null;
/*     */     try {
/* 200 */       in = openInputStream(0, (IProgressMonitor)subMonitor.newChild(1));
/* 201 */       out = destination.openOutputStream(0, (IProgressMonitor)subMonitor.newChild(1));
/* 202 */       transferStreams(in, out, length, sourcePath, (IProgressMonitor)subMonitor.newChild(98));
/* 203 */       transferAttributes(sourceInfo, destination);
/* 204 */     } catch (CoreException e) {
/* 205 */       Policy.safeClose(in);
/* 206 */       Policy.safeClose(out);
/*     */       
/* 208 */       if (!destination.fetchInfo(0, null).exists())
/* 209 */         destination.delete(0, null); 
/* 210 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete(int options, IProgressMonitor monitor) throws CoreException {
/* 226 */     Policy.error(273, NLS.bind(Messages.noImplDelete, toString()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 245 */     if (this == obj)
/* 246 */       return true; 
/* 247 */     if (!(obj instanceof FileStore))
/* 248 */       return false; 
/* 249 */     return toURI().equals(((FileStore)obj).toURI());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileInfo fetchInfo() {
/*     */     try {
/* 260 */       return fetchInfo(0, null);
/* 261 */     } catch (CoreException coreException) {
/*     */       
/* 263 */       FileInfo result = new FileInfo(getName());
/* 264 */       result.setExists(false);
/* 265 */       return result;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract IFileInfo fetchInfo(int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IFileStore getChild(IPath path) {
/* 278 */     IFileStore result = this;
/* 279 */     for (int i = 0, imax = path.segmentCount(); i < imax; i++)
/* 280 */       result = result.getChild(path.segment(i)); 
/* 281 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileStore getFileStore(IPath path) {
/* 292 */     IFileStore result = this;
/* 293 */     String segment = null;
/* 294 */     for (int i = 0, imax = path.segmentCount(); i < imax; i++) {
/* 295 */       segment = path.segment(i);
/* 296 */       if (!segment.equals("."))
/*     */       {
/* 298 */         if (segment.equals("..") && result.getParent() != null) {
/* 299 */           result = result.getParent();
/*     */         } else {
/* 301 */           result = result.getChild(segment);
/*     */         }  } 
/* 303 */     }  return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract IFileStore getChild(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileSystem getFileSystem() {
/*     */     try {
/* 316 */       return EFS.getFileSystem(toURI().getScheme());
/* 317 */     } catch (CoreException e) {
/*     */       
/* 319 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract IFileStore getParent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 340 */     return toURI().hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isParentOf(IFileStore other) {
/*     */     while (true) {
/* 355 */       other = other.getParent();
/* 356 */       if (other == null)
/* 357 */         return false; 
/* 358 */       if (equals(other)) {
/* 359 */         return true;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileStore mkdir(int options, IProgressMonitor monitor) throws CoreException {
/* 374 */     Policy.error(272, NLS.bind(Messages.noImplWrite, toString()));
/* 375 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(IFileStore destination, int options, IProgressMonitor monitor) throws CoreException {
/*     */     try {
/* 386 */       SubMonitor subMonitor = SubMonitor.convert(monitor, NLS.bind(Messages.moving, destination.toString()), 100);
/* 387 */       copy(destination, options & 0x2, (IProgressMonitor)subMonitor.newChild(70));
/* 388 */       delete(0, (IProgressMonitor)subMonitor.newChild(30));
/* 389 */     } catch (CoreException e) {
/*     */       
/* 391 */       String message = NLS.bind(Messages.couldNotMove, toString());
/* 392 */       Policy.error(272, message, (Throwable)e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract InputStream openInputStream(int paramInt, IProgressMonitor paramIProgressMonitor) throws CoreException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream openOutputStream(int options, IProgressMonitor monitor) throws CoreException {
/* 417 */     Policy.error(272, NLS.bind(Messages.noImplWrite, toString()));
/* 418 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putInfo(IFileInfo info, int options, IProgressMonitor monitor) throws CoreException {
/* 432 */     Policy.error(272, NLS.bind(Messages.noImplWrite, toString()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File toLocalFile(int options, IProgressMonitor monitor) throws CoreException {
/* 444 */     if (options != 4096)
/* 445 */       return null; 
/* 446 */     return FileCache.getCache().cache(this, monitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 458 */     return toURI().toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract URI toURI();
/*     */   
/*     */   private void transferAttributes(IFileInfo sourceInfo, IFileStore destination) throws CoreException {
/* 465 */     int options = 3072;
/* 466 */     destination.putInfo(sourceInfo, options, null);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\filesystem\provider\FileStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */