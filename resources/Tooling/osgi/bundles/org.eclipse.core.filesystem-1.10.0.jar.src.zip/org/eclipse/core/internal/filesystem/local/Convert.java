/*     */ package org.eclipse.core.internal.filesystem.local;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Convert
/*     */ {
/*  23 */   private static String defaultEncoding = (new InputStreamReader(new ByteArrayInputStream(new byte[0]))).getEncoding();
/*     */ 
/*     */   
/*  26 */   private static final boolean isWindows = "win32".equals(LocalFileSystem.getOS());
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String WIN32_FILE_PREFIX = "\\\\?\\";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String WIN32_UNC_FILE_PREFIX = "\\\\?\\UNC";
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] longToBytes(long value) {
/*  39 */     byte[] bytes = new byte[8];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  48 */     for (int i = 0; i < bytes.length; i++) {
/*  49 */       bytes[bytes.length - 1 - i] = (byte)(int)value;
/*  50 */       value >>>= 8L;
/*     */     } 
/*     */     
/*  53 */     return bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long bytesToLong(byte[] value) {
/*  63 */     long longValue = 0L; byte b;
/*     */     int i;
/*     */     byte[] arrayOfByte;
/*  66 */     for (i = (arrayOfByte = value).length, b = 0; b < i; ) { byte element = arrayOfByte[b];
/*     */       
/*  68 */       longValue <<= 8L;
/*  69 */       longValue ^= (element & 0xFF);
/*     */       b++; }
/*     */     
/*  72 */     return longValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String fromPlatformBytes(byte[] source, int length) {
/*  84 */     if (defaultEncoding == null) {
/*  85 */       return new String(source, 0, length);
/*     */     }
/*     */     try {
/*  88 */       return new String(source, 0, length, defaultEncoding);
/*  89 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */       
/*  91 */       defaultEncoding = null;
/*  92 */       return new String(source, 0, length);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String fromPlatformBytes(byte[] source) {
/* 102 */     return fromPlatformBytes(source, source.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] toPlatformBytes(String target) {
/* 110 */     if (defaultEncoding == null) {
/* 111 */       return target.getBytes();
/*     */     }
/*     */     try {
/* 114 */       return target.getBytes(defaultEncoding);
/* 115 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */       
/* 117 */       defaultEncoding = null;
/* 118 */       return target.getBytes();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static char[] toPlatformChars(String target) {
/* 128 */     if (!isWindows) {
/* 129 */       return target.toCharArray();
/*     */     }
/* 131 */     if (target.startsWith("\\\\")) {
/* 132 */       int i = target.length();
/* 133 */       int j = "\\\\?\\UNC".length();
/* 134 */       char[] arrayOfChar = new char[j + i - 1];
/* 135 */       "\\\\?\\UNC".getChars(0, j, arrayOfChar, 0);
/* 136 */       target.getChars(1, i, arrayOfChar, j);
/* 137 */       return arrayOfChar;
/*     */     } 
/*     */     
/* 140 */     int nameLength = target.length();
/* 141 */     int prefixLength = "\\\\?\\".length();
/* 142 */     char[] result = new char[prefixLength + nameLength];
/* 143 */     "\\\\?\\UNC".getChars(0, prefixLength, result, 0);
/* 144 */     target.getChars(0, nameLength, result, prefixLength);
/* 145 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\local\Convert.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */