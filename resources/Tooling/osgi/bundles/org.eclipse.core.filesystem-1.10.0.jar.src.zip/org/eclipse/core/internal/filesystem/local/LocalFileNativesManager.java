/*    */ package org.eclipse.core.internal.filesystem.local;
/*    */ 
/*    */ import java.nio.file.FileSystems;
/*    */ import java.util.Set;
/*    */ import org.eclipse.core.filesystem.IFileInfo;
/*    */ import org.eclipse.core.filesystem.provider.FileInfo;
/*    */ import org.eclipse.core.internal.filesystem.local.nio.DefaultHandler;
/*    */ import org.eclipse.core.internal.filesystem.local.nio.DosHandler;
/*    */ import org.eclipse.core.internal.filesystem.local.nio.PosixHandler;
/*    */ import org.eclipse.core.internal.filesystem.local.unix.UnixFileHandler;
/*    */ import org.eclipse.core.internal.filesystem.local.unix.UnixFileNatives;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalFileNativesManager
/*    */ {
/*    */   public static final boolean PROPERTY_USE_NATIVE_DEFAULT = true;
/*    */   public static final String PROPERTY_USE_NATIVES = "eclipse.filesystem.useNatives";
/*    */   private static NativeHandler HANDLER;
/*    */   
/*    */   static {
/* 44 */     reset();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void reset() {
/* 51 */     setUsingNative(Boolean.parseBoolean(System.getProperty("eclipse.filesystem.useNatives", String.valueOf(true))));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean setUsingNative(boolean useNatives) {
/* 60 */     boolean nativesAreUsed, isWindowsOS = "win32".equals(LocalFileSystem.getOS());
/*    */     
/* 62 */     if (useNatives && !isWindowsOS && UnixFileNatives.isUsingNatives()) {
/* 63 */       HANDLER = (NativeHandler)new UnixFileHandler();
/* 64 */       nativesAreUsed = true;
/* 65 */     } else if (useNatives && isWindowsOS && LocalFileNatives.isUsingNatives()) {
/* 66 */       HANDLER = new LocalFileHandler();
/* 67 */       nativesAreUsed = true;
/*    */     } else {
/* 69 */       nativesAreUsed = false;
/* 70 */       Set<String> views = FileSystems.getDefault().supportedFileAttributeViews();
/* 71 */       if (views.contains("posix")) {
/* 72 */         HANDLER = (NativeHandler)new PosixHandler();
/* 73 */       } else if (views.contains("dos")) {
/* 74 */         HANDLER = (NativeHandler)new DosHandler();
/*    */       } else {
/* 76 */         HANDLER = (NativeHandler)new DefaultHandler();
/*    */       } 
/*    */     } 
/* 79 */     return nativesAreUsed;
/*    */   }
/*    */   
/*    */   public static int getSupportedAttributes() {
/* 83 */     return HANDLER.getSupportedAttributes();
/*    */   }
/*    */   
/*    */   public static FileInfo fetchFileInfo(String fileName) {
/* 87 */     return HANDLER.fetchFileInfo(fileName);
/*    */   }
/*    */   
/*    */   public static boolean putFileInfo(String fileName, IFileInfo info, int options) {
/* 91 */     return HANDLER.putFileInfo(fileName, info, options);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\local\LocalFileNativesManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */