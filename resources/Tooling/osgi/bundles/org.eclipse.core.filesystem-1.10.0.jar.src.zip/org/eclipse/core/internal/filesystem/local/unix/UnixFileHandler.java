/*    */ package org.eclipse.core.internal.filesystem.local.unix;
/*    */ 
/*    */ import org.eclipse.core.filesystem.IFileInfo;
/*    */ import org.eclipse.core.filesystem.provider.FileInfo;
/*    */ import org.eclipse.core.internal.filesystem.local.NativeHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnixFileHandler
/*    */   extends NativeHandler
/*    */ {
/*    */   public int getSupportedAttributes() {
/* 26 */     return UnixFileNatives.getSupportedAttributes();
/*    */   }
/*    */ 
/*    */   
/*    */   public FileInfo fetchFileInfo(String fileName) {
/* 31 */     return UnixFileNatives.fetchFileInfo(fileName);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean putFileInfo(String fileName, IFileInfo info, int options) {
/* 36 */     return UnixFileNatives.putFileInfo(fileName, info, options);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\loca\\unix\UnixFileHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */