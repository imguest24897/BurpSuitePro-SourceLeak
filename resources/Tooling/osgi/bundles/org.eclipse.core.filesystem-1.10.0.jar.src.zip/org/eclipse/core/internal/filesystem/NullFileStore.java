/*     */ package org.eclipse.core.internal.filesystem;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.filesystem.IFileSystem;
/*     */ import org.eclipse.core.filesystem.provider.FileInfo;
/*     */ import org.eclipse.core.filesystem.provider.FileStore;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NullFileStore
/*     */   extends FileStore
/*     */ {
/*     */   private IPath path;
/*     */   
/*     */   public NullFileStore(IPath path) {
/*  38 */     Assert.isNotNull(path);
/*  39 */     this.path = path;
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileInfo[] childInfos(int options, IProgressMonitor monitor) {
/*  44 */     return EMPTY_FILE_INFO_ARRAY;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] childNames(int options, IProgressMonitor monitor) {
/*  49 */     return EMPTY_STRING_ARRAY;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void delete(int options, IProgressMonitor monitor) throws CoreException {
/*  55 */     super.delete(options, monitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileInfo fetchInfo(int options, IProgressMonitor monitor) {
/*  60 */     FileInfo result = new FileInfo(getName());
/*  61 */     result.setExists(false);
/*  62 */     return (IFileInfo)result;
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileStore getChild(String name) {
/*  67 */     return (IFileStore)new NullFileStore(this.path.append(name));
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileSystem getFileSystem() {
/*  72 */     return NullFileSystem.getInstance();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  77 */     return String.valueOf(this.path.lastSegment());
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileStore getParent() {
/*  82 */     return (this.path.segmentCount() == 0) ? null : (IFileStore)new NullFileStore(this.path.removeLastSegments(1));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileStore mkdir(int options, IProgressMonitor monitor) throws CoreException {
/*  88 */     return super.mkdir(options, monitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream openInputStream(int options, IProgressMonitor monitor) {
/*  93 */     return new ByteArrayInputStream(new byte[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public OutputStream openOutputStream(int options, IProgressMonitor monitor) {
/*  98 */     return new OutputStream()
/*     */       {
/*     */         public void write(int b) {}
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putInfo(IFileInfo info, int options, IProgressMonitor monitor) throws CoreException {
/* 109 */     super.putInfo(info, options, monitor);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 114 */     return this.path.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public URI toURI() {
/*     */     try {
/* 120 */       return new URI("null", null, this.path.isEmpty() ? "/" : this.path.toString(), null);
/* 121 */     } catch (URISyntaxException e) {
/*     */       
/* 123 */       Policy.log(4, "Invalid URI", e);
/* 124 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\NullFileStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */