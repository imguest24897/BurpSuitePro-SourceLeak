package org.eclipse.core.internal.filesystem.local;

import org.eclipse.core.filesystem.IFileInfo;
import org.eclipse.core.filesystem.provider.FileInfo;

public abstract class NativeHandler {
  public abstract int getSupportedAttributes();
  
  public abstract FileInfo fetchFileInfo(String paramString);
  
  public abstract boolean putFileInfo(String paramString, IFileInfo paramIFileInfo, int paramInt);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\local\NativeHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */