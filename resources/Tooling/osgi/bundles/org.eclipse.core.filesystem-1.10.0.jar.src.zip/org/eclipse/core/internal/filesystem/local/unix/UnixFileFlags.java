/*    */ package org.eclipse.core.internal.filesystem.local.unix;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UnixFileFlags
/*    */ {
/* 19 */   public static final int PATH_MAX = UnixFileNatives.getFlag("PATH_MAX");
/* 20 */   public static final int S_IFMT = UnixFileNatives.getFlag("S_IFMT");
/* 21 */   public static final int S_IFLNK = UnixFileNatives.getFlag("S_IFLNK");
/* 22 */   public static final int S_IFDIR = UnixFileNatives.getFlag("S_IFDIR");
/* 23 */   public static final int S_IRUSR = UnixFileNatives.getFlag("S_IRUSR");
/* 24 */   public static final int S_IWUSR = UnixFileNatives.getFlag("S_IWUSR");
/* 25 */   public static final int S_IXUSR = UnixFileNatives.getFlag("S_IXUSR");
/* 26 */   public static final int S_IRGRP = UnixFileNatives.getFlag("S_IRGRP");
/* 27 */   public static final int S_IWGRP = UnixFileNatives.getFlag("S_IWGRP");
/* 28 */   public static final int S_IXGRP = UnixFileNatives.getFlag("S_IXGRP");
/* 29 */   public static final int S_IROTH = UnixFileNatives.getFlag("S_IROTH");
/* 30 */   public static final int S_IWOTH = UnixFileNatives.getFlag("S_IWOTH");
/* 31 */   public static final int S_IXOTH = UnixFileNatives.getFlag("S_IXOTH");
/* 32 */   public static final int UF_IMMUTABLE = UnixFileNatives.getFlag("UF_IMMUTABLE");
/* 33 */   public static final int SF_IMMUTABLE = UnixFileNatives.getFlag("SF_IMMUTABLE");
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\loca\\unix\UnixFileFlags.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */