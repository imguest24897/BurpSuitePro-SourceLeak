/*     */ package org.eclipse.core.internal.filesystem.local;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URI;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.filesystem.IFileSystem;
/*     */ import org.eclipse.core.filesystem.provider.FileSystem;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalFileSystem
/*     */   extends FileSystem
/*     */ {
/*  35 */   static final boolean MACOSX = getOS().equals("macosx");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   private static final boolean caseSensitive = MACOSX ? false : (((new File("a")).compareTo(new File("A")) != 0));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private int attributes = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IFileSystem instance;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IFileSystem getInstance() {
/*  58 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getOS() {
/*  66 */     return System.getProperty("osgi.os", "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalFileSystem() {
/*  74 */     instance = (IFileSystem)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public int attributes() {
/*  79 */     if (this.attributes != -1)
/*  80 */       return this.attributes; 
/*  81 */     this.attributes = 0;
/*     */ 
/*     */     
/*  84 */     int nativeAttributes = LocalFileNativesManager.getSupportedAttributes();
/*  85 */     if (nativeAttributes >= 0) {
/*  86 */       this.attributes = nativeAttributes;
/*  87 */       return this.attributes;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  92 */     this.attributes |= 0x2;
/*     */ 
/*     */     
/*  95 */     String os = getOS();
/*  96 */     String arch = System.getProperty("osgi.arch", "");
/*  97 */     if (os.equals("win32")) {
/*  98 */       this.attributes |= 0x18;
/*  99 */     } else if (os.equals("linux") || (os.equals("solaris") && arch.equals("sparc"))) {
/* 100 */       this.attributes |= 0x64;
/* 101 */     } else if (os.equals("macosx") || os.equals("hpux") || os.equals("qnx")) {
/* 102 */       this.attributes |= 0x4;
/* 103 */     }  return this.attributes;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canDelete() {
/* 108 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canWrite() {
/* 113 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileStore fromLocalFile(File file) {
/* 118 */     return (IFileStore)new LocalFile(file);
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileStore getStore(IPath path) {
/* 123 */     return (IFileStore)new LocalFile(path.toFile());
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileStore getStore(URI uri) {
/* 128 */     return (IFileStore)new LocalFile(new File(uri.getSchemeSpecificPart()));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCaseSensitive() {
/* 133 */     return caseSensitive;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\local\LocalFileSystem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */