/*     */ package org.eclipse.core.internal.filesystem.local.nio;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.LinkOption;
/*     */ import java.nio.file.NoSuchFileException;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.nio.file.attribute.DosFileAttributeView;
/*     */ import java.nio.file.attribute.DosFileAttributes;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.filesystem.provider.FileInfo;
/*     */ import org.eclipse.core.internal.filesystem.local.NativeHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DosHandler
/*     */   extends NativeHandler
/*     */ {
/*     */   private static final int ATTRIBUTES = 122;
/*     */   
/*     */   public FileInfo fetchFileInfo(String fileName) {
/*  39 */     FileInfo info = new FileInfo();
/*     */     
/*     */     try {
/*  42 */       Path path = Paths.get(fileName, new String[0]);
/*     */ 
/*     */       
/*  45 */       Path fileNamePath = path.toRealPath(new LinkOption[] { LinkOption.NOFOLLOW_LINKS }).getFileName();
/*  46 */       String canonicalName = (fileNamePath == null) ? "" : fileNamePath.toString();
/*  47 */       info.setName(canonicalName);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  52 */       DosFileAttributes attrs = Files.<DosFileAttributes>readAttributes(path, DosFileAttributes.class, new LinkOption[] { LinkOption.NOFOLLOW_LINKS });
/*     */       
/*  54 */       info.setExists(true);
/*  55 */       info.setLastModified(attrs.lastModifiedTime().toMillis());
/*  56 */       info.setLength(attrs.size());
/*  57 */       info.setAttribute(8, attrs.isArchive());
/*  58 */       info.setAttribute(2, attrs.isReadOnly());
/*  59 */       info.setAttribute(16, attrs.isHidden());
/*  60 */       if (attrs.isSymbolicLink()) {
/*  61 */         info.setDirectory(isDirectoryLink(attrs));
/*  62 */         info.setAttribute(32, true);
/*  63 */         info.setStringAttribute(64, Files.readSymbolicLink(path).toString());
/*     */       } else {
/*  65 */         info.setDirectory(attrs.isDirectory());
/*     */       } 
/*  67 */     } catch (NoSuchFileException noSuchFileException) {
/*     */     
/*  69 */     } catch (IOException iOException) {
/*     */       
/*  71 */       info.setError(5);
/*     */     } 
/*  73 */     return info;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isDirectoryLink(DosFileAttributes attrs) {
/*     */     try {
/*  79 */       Method method = attrs.getClass().getDeclaredMethod("isDirectoryLink", new Class[0]);
/*  80 */       method.setAccessible(true);
/*  81 */       return ((Boolean)method.invoke(attrs, new Object[0])).booleanValue();
/*  82 */     } catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException|NoSuchMethodException|SecurityException illegalAccessException) {
/*  83 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSupportedAttributes() {
/*  89 */     return 122;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean putFileInfo(String fileName, IFileInfo info, int options) {
/*  94 */     Path path = Paths.get(fileName, new String[0]);
/*     */     
/*  96 */     DosFileAttributeView view = Files.<DosFileAttributeView>getFileAttributeView(path, DosFileAttributeView.class, new LinkOption[] { LinkOption.NOFOLLOW_LINKS });
/*     */     try {
/*  98 */       view.setArchive(info.getAttribute(8));
/*  99 */       view.setReadOnly(info.getAttribute(2));
/* 100 */       view.setHidden(info.getAttribute(16));
/* 101 */     } catch (IOException iOException) {
/* 102 */       return false;
/*     */     } 
/* 104 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\local\nio\DosHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */