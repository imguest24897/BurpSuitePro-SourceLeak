/*    */ package org.eclipse.core.internal.filesystem;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.eclipse.core.filesystem.IFileStore;
/*    */ import org.eclipse.core.filesystem.IFileSystem;
/*    */ import org.eclipse.core.filesystem.provider.FileSystem;
/*    */ import org.eclipse.core.runtime.IPath;
/*    */ import org.eclipse.core.runtime.Path;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullFileSystem
/*    */   extends FileSystem
/*    */ {
/*    */   private static IFileSystem instance;
/*    */   
/*    */   public static IFileSystem getInstance() {
/* 39 */     return instance;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NullFileSystem() {
/* 47 */     instance = (IFileSystem)this;
/*    */   }
/*    */ 
/*    */   
/*    */   public IFileStore getStore(IPath path) {
/* 52 */     return (IFileStore)new NullFileStore(path);
/*    */   }
/*    */ 
/*    */   
/*    */   public IFileStore getStore(URI uri) {
/* 57 */     return (IFileStore)new NullFileStore((IPath)new Path(uri.getPath()));
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\NullFileSystem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */