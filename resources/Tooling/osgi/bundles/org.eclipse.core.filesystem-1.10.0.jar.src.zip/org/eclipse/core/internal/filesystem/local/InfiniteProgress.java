/*    */ package org.eclipse.core.internal.filesystem.local;
/*    */ 
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.ProgressMonitorWrapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InfiniteProgress
/*    */   extends ProgressMonitorWrapper
/*    */ {
/*    */   private int totalWork;
/* 36 */   private int currentIncrement = 4;
/*    */   private int halfWay;
/* 38 */   private int nextProgress = this.currentIncrement;
/* 39 */   private int worked = 0;
/*    */   
/*    */   protected InfiniteProgress(IProgressMonitor monitor) {
/* 42 */     super(monitor);
/*    */   }
/*    */ 
/*    */   
/*    */   public void beginTask(String name, int work) {
/* 47 */     super.beginTask(name, work);
/* 48 */     this.totalWork = work;
/* 49 */     this.halfWay = this.totalWork / 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public void worked(int work) {
/* 54 */     if (--this.nextProgress <= 0) {
/*    */       
/* 56 */       super.worked(1);
/* 57 */       this.worked++;
/* 58 */       if (this.worked >= this.halfWay) {
/*    */ 
/*    */         
/* 61 */         this.currentIncrement *= 2;
/* 62 */         this.halfWay += (this.totalWork - this.halfWay) / 2;
/*    */       } 
/*    */       
/* 65 */       this.nextProgress = this.currentIncrement;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\local\InfiniteProgress.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */