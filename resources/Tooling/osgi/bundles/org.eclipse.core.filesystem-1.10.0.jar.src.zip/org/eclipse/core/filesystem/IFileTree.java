package org.eclipse.core.filesystem;

public interface IFileTree {
  IFileInfo[] getChildInfos(IFileStore paramIFileStore);
  
  IFileStore[] getChildStores(IFileStore paramIFileStore);
  
  IFileInfo getFileInfo(IFileStore paramIFileStore);
  
  IFileStore getTreeRoot();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\filesystem\IFileTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */