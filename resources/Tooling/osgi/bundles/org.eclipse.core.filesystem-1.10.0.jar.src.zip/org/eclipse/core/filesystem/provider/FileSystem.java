/*     */ package org.eclipse.core.filesystem.provider;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import org.eclipse.core.filesystem.EFS;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.filesystem.IFileSystem;
/*     */ import org.eclipse.core.filesystem.IFileTree;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.PlatformObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FileSystem
/*     */   extends PlatformObject
/*     */   implements IFileSystem
/*     */ {
/*     */   private String scheme;
/*     */   
/*     */   public int attributes() {
/*  54 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canDelete() {
/*  68 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite() {
/*  82 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getScheme() {
/*  87 */     return this.scheme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileStore getStore(IPath path) {
/*     */     try {
/* 109 */       return getStore(new URI(this.scheme, path.toString(), null));
/* 110 */     } catch (URISyntaxException uRISyntaxException) {
/* 111 */       return EFS.getNullFileSystem().getStore(path);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract IFileStore getStore(URI paramURI);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileTree fetchFileTree(IFileStore root, IProgressMonitor monitor) throws CoreException {
/* 135 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileStore fromLocalFile(File file) {
/* 147 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void initialize(String aScheme) {
/* 160 */     if (aScheme == null) {
/* 161 */       throw new NullPointerException();
/*     */     }
/* 163 */     if (this.scheme != null)
/* 164 */       throw new IllegalStateException("File system already initialized"); 
/* 165 */     this.scheme = aScheme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCaseSensitive() {
/* 178 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\filesystem\provider\FileSystem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */