/*    */ package org.eclipse.core.internal.filesystem.local;
/*    */ 
/*    */ import org.eclipse.core.filesystem.IFileInfo;
/*    */ import org.eclipse.core.filesystem.provider.FileInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalFileHandler
/*    */   extends NativeHandler
/*    */ {
/*    */   public int getSupportedAttributes() {
/* 25 */     return LocalFileNatives.attributes();
/*    */   }
/*    */ 
/*    */   
/*    */   public FileInfo fetchFileInfo(String fileName) {
/* 30 */     return LocalFileNatives.fetchFileInfo(fileName);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean putFileInfo(String fileName, IFileInfo info, int options) {
/* 35 */     return LocalFileNatives.putFileInfo(fileName, info, options);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\local\LocalFileHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */