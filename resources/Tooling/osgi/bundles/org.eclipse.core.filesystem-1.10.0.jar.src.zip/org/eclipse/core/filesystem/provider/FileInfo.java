/*     */ package org.eclipse.core.filesystem.provider;
/*     */ 
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.internal.filesystem.local.LocalFileNativesManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileInfo
/*     */   implements IFileInfo
/*     */ {
/*     */   private static final int ATTRIBUTE_DIRECTORY = 1;
/*     */   private static final int ATTRIBUTE_EXISTS = 65536;
/*  42 */   private int attributes = 12582912;
/*     */   
/*  44 */   private int errorCode = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   private long lastModified = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private long length = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private String name = "";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private String linkTarget = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileInfo(String name) {
/*  81 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void clear(int mask) {
/*  90 */     this.attributes &= mask ^ 0xFFFFFFFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/*  96 */       return super.clone();
/*  97 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*     */       
/*  99 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(IFileInfo o) {
/* 108 */     return this.name.compareTo(o.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean exists() {
/* 113 */     return getAttribute(65536);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getError() {
/* 121 */     return this.errorCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getAttribute(int attribute) {
/* 126 */     if (attribute == 2 && isAttributeSuported(8388608))
/* 127 */       return !(isSet(8388608L) && !isSet(2097152L)); 
/* 128 */     if (attribute == 4 && isAttributeSuported(16777216)) {
/* 129 */       return isSet(16777216L);
/*     */     }
/* 131 */     return isSet(attribute);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStringAttribute(int attribute) {
/* 136 */     if (attribute == 64)
/* 137 */       return this.linkTarget; 
/* 138 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLastModified() {
/* 143 */     return this.lastModified;
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLength() {
/* 148 */     return this.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 153 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDirectory() {
/* 158 */     return isSet(1L);
/*     */   }
/*     */   
/*     */   private boolean isSet(long mask) {
/* 162 */     return ((this.attributes & mask) != 0L);
/*     */   }
/*     */   
/*     */   private void set(int mask) {
/* 166 */     this.attributes |= mask;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttribute(int attribute, boolean value) {
/* 171 */     if (attribute == 2 && isAttributeSuported(8388608)) {
/* 172 */       if (value) {
/* 173 */         clear(612368384);
/* 174 */         set(2097152);
/*     */       } else {
/* 176 */         set(12582912);
/* 177 */         clear(2097152);
/*     */       } 
/* 179 */     } else if (attribute == 4 && isAttributeSuported(16777216)) {
/* 180 */       if (value) {
/* 181 */         set(16777216);
/*     */       } else {
/* 183 */         clear(1224736768);
/*     */       } 
/* 185 */     } else if (value) {
/* 186 */       set(attribute);
/*     */     } else {
/* 188 */       clear(attribute);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isAttributeSuported(int value) {
/* 193 */     return ((LocalFileNativesManager.getSupportedAttributes() & value) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDirectory(boolean value) {
/* 203 */     if (value) {
/* 204 */       set(1);
/*     */     } else {
/* 206 */       clear(1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExists(boolean value) {
/* 216 */     if (value) {
/* 217 */       set(65536);
/*     */     } else {
/* 219 */       clear(65536);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setError(int errorCode) {
/* 230 */     this.errorCode = errorCode;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLastModified(long value) {
/* 235 */     this.lastModified = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLength(long value) {
/* 245 */     this.length = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 254 */     if (name == null)
/* 255 */       throw new IllegalArgumentException(); 
/* 256 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStringAttribute(int attribute, String value) {
/* 269 */     if (attribute == 64) {
/* 270 */       this.linkTarget = value;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 278 */     return this.name;
/*     */   }
/*     */   
/*     */   public FileInfo() {}
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\filesystem\provider\FileInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */