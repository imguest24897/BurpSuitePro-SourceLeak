/*     */ package org.eclipse.core.internal.filesystem.local;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.filesystem.provider.FileInfo;
/*     */ import org.eclipse.core.internal.filesystem.FileSystemAccess;
/*     */ import org.eclipse.core.internal.filesystem.Messages;
/*     */ import org.eclipse.core.internal.filesystem.Policy;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class LocalFileNatives
/*     */ {
/*     */   private static boolean hasNatives = false;
/*     */   private static boolean isUnicode = false;
/*  29 */   private static int nativeAttributes = -1;
/*     */ 
/*     */   
/*     */   private static final String LIBRARY_NAME = "localfile_1_0_0";
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/*  37 */       System.loadLibrary("localfile_1_0_0");
/*  38 */       hasNatives = true;
/*  39 */       isUnicode = internalIsUnicode();
/*     */       try {
/*  41 */         nativeAttributes = nativeAttributes();
/*  42 */       } catch (UnsatisfiedLinkError unsatisfiedLinkError) {}
/*     */ 
/*     */     
/*     */     }
/*  46 */     catch (UnsatisfiedLinkError e) {
/*  47 */       if (isLibraryPresent())
/*  48 */         logMissingNativeLibrary(e); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isLibraryPresent() {
/*  53 */     String libName = System.mapLibraryName("localfile_1_0_0");
/*  54 */     Enumeration<URL> entries = FileSystemAccess.findEntries("/", libName, true);
/*  55 */     return (entries != null && entries.hasMoreElements());
/*     */   }
/*     */   
/*     */   private static void logMissingNativeLibrary(UnsatisfiedLinkError e) {
/*  59 */     String libName = System.mapLibraryName("localfile_1_0_0");
/*  60 */     String message = NLS.bind(Messages.couldNotLoadLibrary, libName);
/*  61 */     Policy.log(1, message, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final native int nativeAttributes();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int attributes() {
/*  91 */     return nativeAttributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean copyAttributes(String source, String destination, boolean copyLastModified) {
/* 103 */     if (hasNatives)
/*     */     {
/* 105 */       return isUnicode ? internalCopyAttributesW(Convert.toPlatformChars(source), Convert.toPlatformChars(destination), copyLastModified) : internalCopyAttributes(Convert.toPlatformBytes(source), Convert.toPlatformBytes(destination), copyLastModified); } 
/* 106 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FileInfo fetchFileInfo(String fileName) {
/* 114 */     FileInfo info = new FileInfo();
/* 115 */     if (isUnicode) {
/* 116 */       internalGetFileInfoW(Convert.toPlatformChars(fileName), (IFileInfo)info);
/*     */     } else {
/* 118 */       internalGetFileInfo(Convert.toPlatformBytes(fileName), (IFileInfo)info);
/* 119 */     }  return info;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final native boolean internalCopyAttributes(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final native boolean internalCopyAttributesW(char[] paramArrayOfchar1, char[] paramArrayOfchar2, boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final native boolean internalGetFileInfo(byte[] paramArrayOfbyte, IFileInfo paramIFileInfo);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final native boolean internalGetFileInfoW(char[] paramArrayOfchar, IFileInfo paramIFileInfo);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final native boolean internalIsUnicode();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final native boolean internalSetFileInfo(byte[] paramArrayOfbyte, IFileInfo paramIFileInfo);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final native boolean internalSetFileInfoW(char[] paramArrayOfchar, IFileInfo paramIFileInfo, int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean putFileInfo(String fileName, IFileInfo info, int options) {
/* 169 */     if (isUnicode)
/* 170 */       return internalSetFileInfoW(Convert.toPlatformChars(fileName), info, options); 
/* 171 */     return internalSetFileInfo(Convert.toPlatformBytes(fileName), info);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isUsingNatives() {
/* 181 */     return hasNatives;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\local\LocalFileNatives.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */