/*     */ package org.eclipse.core.internal.filesystem;
/*     */ 
/*     */ import java.net.URI;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FileStoreUtil
/*     */ {
/*     */   private static int comparePathUri(URI uri1, URI uri2) {
/*  35 */     if (uri1 == null && uri2 == null) {
/*  36 */       return 0;
/*     */     }
/*     */     
/*     */     int compare;
/*  40 */     if ((compare = nullsLast(uri1, uri2)) != 0) {
/*  41 */       return compare;
/*     */     }
/*  43 */     return compareNormalisedUri(uri1.normalize(), uri2.normalize());
/*     */   }
/*     */ 
/*     */   
/*     */   private static int compareNormalisedUri(URI uri1, URI uri2) {
/*     */     int c;
/*  49 */     if ((c = compareStringOrNull(uri1.getAuthority(), uri2.getAuthority())) != 0)
/*  50 */       return c; 
/*  51 */     if ((c = compareStringOrNull(uri1.getScheme(), uri2.getScheme())) != 0)
/*  52 */       return c; 
/*  53 */     if ((c = comparePathSegments(uri1.getPath(), uri2.getPath())) != 0)
/*  54 */       return c; 
/*  55 */     if ((c = compareStringOrNull(uri1.getQuery(), uri2.getQuery())) != 0)
/*  56 */       return c; 
/*  57 */     return c;
/*     */   }
/*     */   
/*     */   static int nullsLast(Object c1, Object c2) {
/*  61 */     if (c1 == null) {
/*  62 */       if (c2 == null)
/*  63 */         return 0; 
/*  64 */       return 1;
/*     */     } 
/*  66 */     if (c2 == null)
/*  67 */       return -1; 
/*  68 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int comparePathSegments(String p1, String p2) {
/*  73 */     int compare = compareSlashFirst(p1, p2);
/*  74 */     if (compare != 0) {
/*  75 */       return compare;
/*     */     }
/*  77 */     int segmentCount1 = countCharButNotAtEnd(p1, '/');
/*  78 */     int segmentCount2 = countCharButNotAtEnd(p2, '/');
/*  79 */     compare = segmentCount1 - segmentCount2;
/*  80 */     return compare;
/*     */   }
/*     */   
/*     */   static int compareSlashFirst(String value, String other) {
/*  84 */     int len1 = value.length();
/*  85 */     int len2 = other.length();
/*  86 */     int lim = Math.min(len1, len2);
/*  87 */     for (int k = 0; k < lim; k++) {
/*  88 */       char c1 = value.charAt(k);
/*  89 */       char c2 = other.charAt(k);
/*  90 */       if (c1 != c2) {
/*     */         
/*  92 */         if (c1 == '/')
/*  93 */           return -1; 
/*  94 */         if (c2 == '/')
/*  95 */           return 1; 
/*  96 */         return c1 - c2;
/*     */       } 
/*     */     } 
/*     */     
/* 100 */     if (value.endsWith("/"))
/* 101 */       len1--; 
/* 102 */     if (other.endsWith("/"))
/* 103 */       len2--; 
/* 104 */     return len1 - len2;
/*     */   }
/*     */   
/*     */   static int countCharButNotAtEnd(String str, char c) {
/* 108 */     int count = 0;
/* 109 */     for (int i = 0; i < str.length() - 1; i++) {
/* 110 */       if (str.charAt(i) == c)
/* 111 */         count++; 
/*     */     } 
/* 113 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int compareStringOrNull(String string1, String string2) {
/* 121 */     if (string1 == null) {
/* 122 */       if (string2 == null)
/* 123 */         return 0; 
/* 124 */       return 1;
/*     */     } 
/* 126 */     if (string2 == null)
/* 127 */       return -1; 
/* 128 */     return string1.compareTo(string2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int compareFileStore(IFileStore fileStore1, IFileStore fileStore2) {
/*     */     URI uri1, uri2;
/* 138 */     int compare = compareStringOrNull(fileStore1.getFileSystem().getScheme(), fileStore2.getFileSystem().getScheme());
/* 139 */     if (compare != 0) {
/* 140 */       return compare;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 145 */       uri1 = fileStore1.toURI();
/* 146 */     } catch (Exception exception) {
/*     */       
/* 148 */       uri1 = null;
/*     */     } 
/*     */     try {
/* 151 */       uri2 = fileStore2.toURI();
/* 152 */     } catch (Exception exception) {
/*     */       
/* 154 */       uri2 = null;
/*     */     } 
/*     */     
/* 157 */     return comparePathUri(uri1, uri2);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\FileStoreUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */