/*     */ package org.eclipse.core.filesystem;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class URIUtil
/*     */ {
/*     */   public static boolean equals(URI one, URI two) {
/*     */     try {
/*  47 */       return EFS.getStore(one).equals(EFS.getStore(two));
/*  48 */     } catch (CoreException coreException) {
/*     */       
/*  50 */       return one.equals(two);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IPath toPath(URI uri) {
/*  63 */     Assert.isNotNull(uri);
/*     */     
/*  65 */     if ("file".equals(uri.getScheme())) {
/*  66 */       return (IPath)new Path(uri.getSchemeSpecificPart());
/*     */     }
/*  68 */     if (uri.getScheme() == null) {
/*  69 */       return (IPath)new Path(uri.getPath());
/*     */     }
/*     */     try {
/*  72 */       IFileStore store = EFS.getStore(uri);
/*  73 */       if (store == null)
/*  74 */         return null; 
/*  75 */       File file = store.toLocalFile(0, null);
/*  76 */       if (file == null)
/*  77 */         return null; 
/*  78 */       return (IPath)new Path(file.getAbsolutePath());
/*  79 */     } catch (CoreException coreException) {
/*     */ 
/*     */       
/*  82 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI toURI(IPath path) {
/*  92 */     if (path == null)
/*  93 */       return null; 
/*  94 */     if (path.isAbsolute()) {
/*  95 */       return toURI(path.toFile().getAbsolutePath(), true);
/*     */     }
/*  97 */     URI base = toURI(Path.ROOT.setDevice(path.getDevice()));
/*  98 */     return base.relativize(toURI(path.makeAbsolute()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI toURI(String pathString) {
/* 111 */     Path path = new Path(pathString);
/* 112 */     return toURI((IPath)path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URI toURI(String pathString, boolean forceAbsolute) {
/* 133 */     if (File.separatorChar != '/')
/* 134 */       pathString = pathString.replace(File.separatorChar, '/'); 
/* 135 */     int length = pathString.length();
/* 136 */     StringBuilder pathBuf = new StringBuilder(length + 1);
/*     */     
/* 138 */     if (length > 0 && pathString.charAt(0) != '/' && forceAbsolute) {
/* 139 */       pathBuf.append('/');
/*     */     }
/*     */     
/* 142 */     if (pathString.startsWith("//"))
/* 143 */       pathBuf.append('/').append('/'); 
/* 144 */     pathBuf.append(pathString);
/*     */     try {
/* 146 */       String scheme = null;
/* 147 */       if (length > 0 && pathBuf.charAt(0) == '/') {
/* 148 */         scheme = "file";
/*     */       }
/* 150 */       return new URI(scheme, null, pathBuf.toString(), null);
/* 151 */     } catch (URISyntaxException uRISyntaxException) {
/*     */       
/* 153 */       return (new File(pathString)).toURI();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toDecodedString(URI uri) {
/* 170 */     String scheme = uri.getScheme();
/* 171 */     String part = uri.getSchemeSpecificPart();
/* 172 */     if (scheme == null)
/* 173 */       return part; 
/* 174 */     return String.valueOf(scheme) + ':' + part;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\filesystem\URIUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */