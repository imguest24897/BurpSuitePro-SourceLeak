package org.eclipse.core.filesystem;

import java.io.File;
import java.net.URI;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;

public interface IFileSystem extends IAdaptable {
  int attributes();
  
  boolean canDelete();
  
  boolean canWrite();
  
  IFileTree fetchFileTree(IFileStore paramIFileStore, IProgressMonitor paramIProgressMonitor) throws CoreException;
  
  IFileStore fromLocalFile(File paramFile);
  
  String getScheme();
  
  IFileStore getStore(IPath paramIPath);
  
  IFileStore getStore(URI paramURI);
  
  boolean isCaseSensitive();
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\filesystem\IFileSystem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */