/*     */ package org.eclipse.core.internal.filesystem.local;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.URI;
/*     */ import java.nio.file.AccessDeniedException;
/*     */ import java.nio.file.DirectoryNotEmptyException;
/*     */ import java.nio.file.FileAlreadyExistsException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.NoSuchFileException;
/*     */ import java.nio.file.attribute.FileAttribute;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.filesystem.IFileSystem;
/*     */ import org.eclipse.core.filesystem.URIUtil;
/*     */ import org.eclipse.core.filesystem.provider.FileInfo;
/*     */ import org.eclipse.core.filesystem.provider.FileStore;
/*     */ import org.eclipse.core.internal.filesystem.FileStoreUtil;
/*     */ import org.eclipse.core.internal.filesystem.Messages;
/*     */ import org.eclipse.core.internal.filesystem.Policy;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.MultiStatus;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocalFile
/*     */   extends FileStore
/*     */ {
/*     */   protected final File file;
/*     */   protected final String filePath;
/*     */   private URI uri;
/*     */   
/*     */   private static int attributes(File aFile) {
/*  53 */     if (!aFile.exists() || aFile.canWrite())
/*  54 */       return 0; 
/*  55 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalFile(File file) {
/*  64 */     this.file = file;
/*  65 */     this.filePath = file.getAbsolutePath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkReadOnlyParent(File target, Throwable exception) throws CoreException {
/*  78 */     File parent = target.getParentFile();
/*  79 */     if (parent != null && (attributes(parent) & 0x2) != 0) {
/*  80 */       String message = NLS.bind(Messages.readOnlyParent, target.getAbsolutePath());
/*  81 */       Policy.error(277, message, exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkTargetIsNotWritable(File target, Throwable exception) throws CoreException {
/*  95 */     if (!target.canWrite()) {
/*  96 */       String message = NLS.bind(Messages.couldNotWrite, target.getAbsolutePath());
/*  97 */       Policy.error(272, message, exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] childNames(int options, IProgressMonitor monitor) {
/* 103 */     String[] names = this.file.list();
/* 104 */     return (names == null) ? EMPTY_STRING_ARRAY : names;
/*     */   }
/*     */ 
/*     */   
/*     */   public void copy(IFileStore destFile, int options, IProgressMonitor monitor) throws CoreException {
/* 109 */     if (destFile instanceof LocalFile) {
/* 110 */       File source = this.file;
/* 111 */       File destination = ((LocalFile)destFile).file;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 116 */         if (isSameFile(source, destination)) {
/*     */           return;
/*     */         }
/*     */       }
/* 120 */       catch (IOException e) {
/* 121 */         String message = NLS.bind(Messages.couldNotRead, source.getAbsolutePath());
/* 122 */         Policy.error(271, message, e);
/*     */       } 
/*     */     } 
/*     */     
/* 126 */     super.copy(destFile, options, monitor);
/*     */   }
/*     */   public void delete(int options, IProgressMonitor monitor) throws CoreException {
/*     */     NullProgressMonitor nullProgressMonitor;
/*     */     InfiniteProgress infiniteProgress;
/* 131 */     if (monitor == null) {
/* 132 */       nullProgressMonitor = new NullProgressMonitor();
/*     */     } else {
/* 134 */       infiniteProgress = new InfiniteProgress((IProgressMonitor)nullProgressMonitor);
/*     */     }  try {
/* 136 */       infiniteProgress.beginTask(NLS.bind(Messages.deleting, this), 200);
/* 137 */       String message = Messages.deleteProblem;
/* 138 */       MultiStatus result = new MultiStatus("org.eclipse.core.filesystem", 273, message, null);
/* 139 */       internalDelete(this.file, this.filePath, result, (IProgressMonitor)infiniteProgress);
/* 140 */       if (!result.isOK())
/* 141 */         throw new CoreException(result); 
/*     */     } finally {
/* 143 */       infiniteProgress.done();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 149 */     if (!(obj instanceof LocalFile)) {
/* 150 */       return false;
/*     */     }
/*     */     
/* 153 */     LocalFile otherFile = (LocalFile)obj;
/* 154 */     if (LocalFileSystem.MACOSX)
/* 155 */       return this.filePath.equalsIgnoreCase(otherFile.filePath); 
/* 156 */     return this.file.equals(otherFile.file);
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileInfo fetchInfo(int options, IProgressMonitor monitor) {
/* 161 */     FileInfo info = LocalFileNativesManager.fetchFileInfo(this.filePath);
/*     */     
/* 163 */     if (info.getName().isEmpty()) {
/* 164 */       String name = this.file.getName();
/*     */       
/* 166 */       info.setName(new String(name.toCharArray()));
/*     */     } 
/* 168 */     return (IFileInfo)info;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IFileStore getChild(IPath path) {
/* 174 */     return (IFileStore)new LocalFile(new File(this.file, path.toOSString()));
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileStore getFileStore(IPath path) {
/* 179 */     return (IFileStore)new LocalFile((new Path(this.file.getPath())).append(path).toFile());
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileStore getChild(String name) {
/* 184 */     return (IFileStore)new LocalFile(new File(this.file, name));
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileSystem getFileSystem() {
/* 189 */     return LocalFileSystem.getInstance();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/* 194 */     return this.file.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileStore getParent() {
/* 199 */     File parent = this.file.getParentFile();
/* 200 */     return (parent == null) ? null : (IFileStore)new LocalFile(parent);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 205 */     if (LocalFileSystem.MACOSX)
/* 206 */       return this.filePath.toLowerCase().hashCode(); 
/* 207 */     return this.file.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean internalDelete(File target, String pathToDelete, MultiStatus status, IProgressMonitor monitor) {
/* 216 */     if (monitor.isCanceled()) {
/* 217 */       throw new OperationCanceledException();
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 222 */       Files.deleteIfExists(target.toPath());
/* 223 */       return true;
/* 224 */     } catch (AccessDeniedException e) {
/*     */ 
/*     */       
/* 227 */       if (target.delete()) {
/* 228 */         return true;
/*     */       }
/* 230 */       throw e;
/*     */     }
/* 232 */     catch (DirectoryNotEmptyException directoryNotEmptyException) {
/* 233 */       monitor.subTask(NLS.bind(Messages.deleting, target));
/* 234 */       String[] list = target.list();
/* 235 */       if (list == null)
/* 236 */         list = EMPTY_STRING_ARRAY; 
/* 237 */       int parentLength = pathToDelete.length();
/* 238 */       boolean failedRecursive = false; byte b; int i; String[] arrayOfString1;
/* 239 */       for (i = (arrayOfString1 = list).length, b = 0; b < i; ) { String element = arrayOfString1[b];
/* 240 */         if (monitor.isCanceled()) {
/* 241 */           throw new OperationCanceledException();
/*     */         }
/*     */         
/* 244 */         StringBuilder childBuffer = new StringBuilder(parentLength + element.length() + 1);
/* 245 */         childBuffer.append(pathToDelete);
/* 246 */         childBuffer.append(File.separatorChar);
/* 247 */         childBuffer.append(element);
/* 248 */         String childName = childBuffer.toString();
/*     */         
/* 250 */         failedRecursive = !(internalDelete(new File(childName), childName, status, monitor) && !failedRecursive);
/* 251 */         monitor.worked(1);
/*     */         b++; }
/*     */       
/*     */       try {
/* 255 */         if (!failedRecursive && Files.deleteIfExists(target.toPath()))
/* 256 */           return true; 
/* 257 */       } catch (Exception e1) {
/*     */         
/* 259 */         String str = NLS.bind(Messages.couldnotDelete, target.getAbsolutePath());
/* 260 */         status.add((IStatus)new Status(4, "org.eclipse.core.filesystem", 273, str, e1));
/* 261 */         return false;
/*     */       } 
/*     */       
/* 264 */       String message = null;
/* 265 */       if (fetchInfo().getAttribute(2)) {
/* 266 */         message = NLS.bind(Messages.couldnotDeleteReadOnly, target.getAbsolutePath());
/*     */       } else {
/* 268 */         message = NLS.bind(Messages.couldnotDelete, target.getAbsolutePath());
/*     */       } 
/* 270 */       status.add((IStatus)new Status(4, "org.eclipse.core.filesystem", 273, message, null));
/* 271 */       return false;
/* 272 */     } catch (IOException e) {
/* 273 */       String message = NLS.bind(Messages.couldnotDelete, target.getAbsolutePath());
/* 274 */       status.add((IStatus)new Status(4, "org.eclipse.core.filesystem", 273, message, e));
/* 275 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isParentOf(IFileStore other) {
/* 281 */     if (!(other instanceof LocalFile))
/* 282 */       return false; 
/* 283 */     String thisPath = this.filePath;
/* 284 */     String thatPath = ((LocalFile)other).filePath;
/* 285 */     int thisLength = thisPath.length();
/* 286 */     int thatLength = thatPath.length();
/*     */     
/* 288 */     if (thisLength >= thatLength)
/* 289 */       return false; 
/* 290 */     if (getFileSystem().isCaseSensitive()) {
/* 291 */       if (thatPath.indexOf(thisPath) != 0) {
/* 292 */         return false;
/*     */       }
/* 294 */     } else if (thatPath.toLowerCase().indexOf(thisPath.toLowerCase()) != 0) {
/* 295 */       return false;
/*     */     } 
/*     */     
/* 298 */     return !(thisPath.charAt(thisLength - 1) != File.separatorChar && thatPath.charAt(thisLength) != File.separatorChar);
/*     */   }
/*     */ 
/*     */   
/*     */   public IFileStore mkdir(int options, IProgressMonitor monitor) throws CoreException {
/* 303 */     boolean shallow = ((options & 0x4) != 0);
/*     */     
/*     */     try {
/* 306 */       if (shallow) {
/* 307 */         Files.createDirectory(this.file.toPath(), (FileAttribute<?>[])new FileAttribute[0]);
/*     */       } else {
/* 309 */         Files.createDirectories(this.file.toPath(), (FileAttribute<?>[])new FileAttribute[0]);
/*     */       } 
/* 311 */     } catch (FileAlreadyExistsException e) {
/* 312 */       if (!this.file.isDirectory()) {
/* 313 */         String message = NLS.bind(Messages.failedCreateWrongType, this.filePath);
/* 314 */         Policy.error(276, message, e);
/*     */       } 
/* 316 */     } catch (AccessDeniedException e) {
/* 317 */       if (!this.file.isDirectory()) {
/* 318 */         checkReadOnlyParent(this.file, e);
/* 319 */         String message = NLS.bind(Messages.failedCreateAccessDenied, this.filePath);
/* 320 */         Policy.error(280, message, e);
/*     */       } 
/* 322 */     } catch (NoSuchFileException e) {
/* 323 */       if (!this.file.isDirectory()) {
/* 324 */         String parentPath = this.file.getParent();
/* 325 */         String message = NLS.bind(Messages.fileNotFound, (parentPath != null) ? parentPath : this.filePath);
/* 326 */         Policy.error(269, message, e);
/*     */       } 
/* 328 */     } catch (IOException e) {
/* 329 */       if (!this.file.isDirectory()) {
/* 330 */         checkReadOnlyParent(this.file, e);
/* 331 */         checkTargetIsNotWritable(this.file, e);
/* 332 */         String message = NLS.bind(Messages.couldNotWrite, this.filePath);
/* 333 */         Policy.error(272, message, e);
/*     */       } 
/*     */     } 
/* 336 */     return (IFileStore)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void move(IFileStore destFile, int options, IProgressMonitor monitor) throws CoreException {
/* 341 */     if (!(destFile instanceof LocalFile)) {
/* 342 */       super.move(destFile, options, monitor);
/*     */       return;
/*     */     } 
/* 345 */     File source = this.file;
/* 346 */     File destination = ((LocalFile)destFile).file;
/* 347 */     boolean overwrite = ((options & 0x2) != 0);
/* 348 */     SubMonitor subMonitor = SubMonitor.convert(monitor, NLS.bind(Messages.moving, source.getAbsolutePath()), 1);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 353 */       boolean sourceEqualsDest = false;
/*     */       try {
/* 355 */         sourceEqualsDest = isSameFile(source, destination);
/* 356 */       } catch (IOException e) {
/* 357 */         String message = NLS.bind(Messages.couldNotMove, source.getAbsolutePath());
/* 358 */         Policy.error(272, message, e);
/*     */       } 
/* 360 */       if (!sourceEqualsDest && !overwrite && destination.exists()) {
/* 361 */         String message = NLS.bind(Messages.fileExists, destination.getAbsolutePath());
/* 362 */         Policy.error(268, message);
/*     */       } 
/* 364 */       if (source.renameTo(destination))
/*     */       {
/*     */         
/* 367 */         if (!sourceEqualsDest && source.exists()) {
/*     */           
/* 369 */           if (destination.exists())
/*     */           {
/*     */             
/* 372 */             (new LocalFile(destination)).delete(0, (IProgressMonitor)null);
/* 373 */             String message = NLS.bind(Messages.couldnotDelete, source.getAbsolutePath());
/* 374 */             Policy.error(273, message);
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 379 */           if (!destination.exists() && !destFile.fetchInfo().getAttribute(32)) {
/*     */             
/* 381 */             String message = NLS.bind(Messages.failedMove, source.getAbsolutePath(), destination.getAbsolutePath());
/* 382 */             Policy.error(272, message);
/*     */           } 
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/*     */       
/* 389 */       if (sourceEqualsDest) {
/* 390 */         String message = NLS.bind(Messages.couldNotMove, source.getAbsolutePath());
/* 391 */         Policy.error(272, message, null);
/*     */       } 
/*     */       
/* 394 */       super.move(destFile, options, (IProgressMonitor)subMonitor.newChild(1));
/*     */     } finally {
/* 396 */       subMonitor.done();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isSameFile(File source, File destination) throws IOException {
/*     */     try {
/* 402 */       if (!destination.exists())
/*     */       {
/* 404 */         return false;
/*     */       }
/*     */       
/* 407 */       return Files.isSameFile(source.toPath(), destination.toPath());
/* 408 */     } catch (NoSuchFileException noSuchFileException) {
/*     */ 
/*     */       
/* 411 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream openInputStream(int options, IProgressMonitor monitor) throws CoreException {
/*     */     try {
/* 418 */       return new FileInputStream(this.file);
/* 419 */     } catch (FileNotFoundException e) {
/*     */       
/* 421 */       if (!this.file.exists()) {
/* 422 */         String message = NLS.bind(Messages.fileNotFound, this.filePath);
/* 423 */         Policy.error(269, message, e);
/* 424 */       } else if (this.file.isDirectory()) {
/* 425 */         String message = NLS.bind(Messages.notAFile, this.filePath);
/* 426 */         Policy.error(276, message, e);
/*     */       } else {
/* 428 */         String message = NLS.bind(Messages.couldNotRead, this.filePath);
/* 429 */         Policy.error(271, message, e);
/*     */       } 
/* 431 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public OutputStream openOutputStream(int options, IProgressMonitor monitor) throws CoreException {
/*     */     try {
/* 438 */       return new FileOutputStream(this.file, ((options & 0x1) != 0));
/* 439 */     } catch (FileNotFoundException e) {
/* 440 */       checkReadOnlyParent(this.file, e);
/*     */       
/* 442 */       String path = this.filePath;
/* 443 */       if (this.file.isDirectory()) {
/* 444 */         String message = NLS.bind(Messages.notAFile, path);
/* 445 */         Policy.error(276, message, e);
/*     */       } else {
/* 447 */         String message = NLS.bind(Messages.couldNotWrite, path);
/* 448 */         Policy.error(272, message, e);
/*     */       } 
/* 450 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void putInfo(IFileInfo info, int options, IProgressMonitor monitor) throws CoreException {
/* 456 */     boolean success = true;
/* 457 */     if ((options & 0x400) != 0) {
/* 458 */       success &= LocalFileNativesManager.putFileInfo(this.filePath, info, options);
/*     */     }
/*     */     
/* 461 */     if ((options & 0x800) != 0)
/* 462 */       success &= this.file.setLastModified(info.getLastModified()); 
/* 463 */     if (!success && !this.file.exists()) {
/* 464 */       Policy.error(269, NLS.bind(Messages.fileNotFound, this.filePath));
/*     */     }
/*     */   }
/*     */   
/*     */   public File toLocalFile(int options, IProgressMonitor monitor) throws CoreException {
/* 469 */     if (options == 4096)
/* 470 */       return super.toLocalFile(options, monitor); 
/* 471 */     return this.file;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 476 */     return this.file.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public URI toURI() {
/* 481 */     if (this.uri == null) {
/* 482 */       this.uri = URIUtil.toURI(this.filePath);
/*     */     }
/* 484 */     return this.uri;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(IFileStore other) {
/* 489 */     if (other instanceof LocalFile)
/*     */     {
/*     */ 
/*     */       
/* 493 */       return FileStoreUtil.comparePathSegments(toURI().getPath(), ((LocalFile)other).toURI().getPath());
/*     */     }
/* 495 */     return super.compareTo(other);
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\local\LocalFile.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */