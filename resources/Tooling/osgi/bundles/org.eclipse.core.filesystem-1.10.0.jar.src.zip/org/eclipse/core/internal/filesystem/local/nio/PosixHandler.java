/*     */ package org.eclipse.core.internal.filesystem.local.nio;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.LinkOption;
/*     */ import java.nio.file.NoSuchFileException;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.nio.file.attribute.PosixFileAttributeView;
/*     */ import java.nio.file.attribute.PosixFileAttributes;
/*     */ import java.nio.file.attribute.PosixFilePermission;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.filesystem.provider.FileInfo;
/*     */ import org.eclipse.core.internal.filesystem.local.NativeHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PosixHandler
/*     */   extends NativeHandler
/*     */ {
/*     */   private static final int ATTRIBUTES = 2143289446;
/*     */   
/*     */   public FileInfo fetchFileInfo(String fileName) {
/*  41 */     Path path = Paths.get(fileName, new String[0]);
/*  42 */     FileInfo info = new FileInfo();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  49 */     Path fileNamePath = path.getFileName();
/*  50 */     info.setName((fileNamePath == null) ? "" : fileNamePath.toString());
/*     */     
/*     */     try {
/*  53 */       PosixFileAttributes attrs = Files.<PosixFileAttributes>readAttributes(path, PosixFileAttributes.class, new LinkOption[] { LinkOption.NOFOLLOW_LINKS });
/*     */       
/*  55 */       if (attrs.isSymbolicLink()) {
/*  56 */         info.setAttribute(32, true);
/*  57 */         info.setStringAttribute(64, Files.readSymbolicLink(path).toString());
/*  58 */         attrs = Files.<PosixFileAttributes>readAttributes(path, PosixFileAttributes.class, new LinkOption[0]);
/*     */       } 
/*     */       
/*  61 */       info.setExists(true);
/*  62 */       info.setLastModified(attrs.lastModifiedTime().toMillis());
/*  63 */       info.setLength(attrs.size());
/*  64 */       info.setDirectory(attrs.isDirectory());
/*     */       
/*  66 */       Set<PosixFilePermission> perms = attrs.permissions();
/*  67 */       info.setAttribute(4194304, perms.contains(PosixFilePermission.OWNER_READ));
/*  68 */       info.setAttribute(8388608, perms.contains(PosixFilePermission.OWNER_WRITE));
/*  69 */       info.setAttribute(16777216, perms.contains(PosixFilePermission.OWNER_EXECUTE));
/*  70 */       info.setAttribute(33554432, perms.contains(PosixFilePermission.GROUP_READ));
/*  71 */       info.setAttribute(67108864, perms.contains(PosixFilePermission.GROUP_WRITE));
/*  72 */       info.setAttribute(134217728, perms.contains(PosixFilePermission.GROUP_EXECUTE));
/*  73 */       info.setAttribute(268435456, perms.contains(PosixFilePermission.OTHERS_READ));
/*  74 */       info.setAttribute(536870912, perms.contains(PosixFilePermission.OTHERS_WRITE));
/*  75 */       info.setAttribute(1073741824, perms.contains(PosixFilePermission.OTHERS_EXECUTE));
/*  76 */     } catch (NoSuchFileException noSuchFileException) {
/*     */     
/*  78 */     } catch (IOException iOException) {
/*     */       
/*  80 */       info.setError(5);
/*     */     } 
/*  82 */     return info;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSupportedAttributes() {
/*  87 */     return 2143289446;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean putFileInfo(String fileName, IFileInfo info, int options) {
/*  92 */     Path path = Paths.get(fileName, new String[0]);
/*  93 */     Set<PosixFilePermission> perms = new HashSet<>();
/*     */     
/*  95 */     if (info.getAttribute(4194304))
/*  96 */       perms.add(PosixFilePermission.OWNER_READ); 
/*  97 */     if (info.getAttribute(8388608))
/*  98 */       perms.add(PosixFilePermission.OWNER_WRITE); 
/*  99 */     if (info.getAttribute(16777216))
/* 100 */       perms.add(PosixFilePermission.OWNER_EXECUTE); 
/* 101 */     if (info.getAttribute(33554432))
/* 102 */       perms.add(PosixFilePermission.GROUP_READ); 
/* 103 */     if (info.getAttribute(67108864))
/* 104 */       perms.add(PosixFilePermission.GROUP_WRITE); 
/* 105 */     if (info.getAttribute(134217728))
/* 106 */       perms.add(PosixFilePermission.GROUP_EXECUTE); 
/* 107 */     if (info.getAttribute(268435456))
/* 108 */       perms.add(PosixFilePermission.OTHERS_READ); 
/* 109 */     if (info.getAttribute(536870912))
/* 110 */       perms.add(PosixFilePermission.OTHERS_WRITE); 
/* 111 */     if (info.getAttribute(1073741824)) {
/* 112 */       perms.add(PosixFilePermission.OTHERS_EXECUTE);
/*     */     }
/* 114 */     PosixFileAttributeView view = Files.<PosixFileAttributeView>getFileAttributeView(path, PosixFileAttributeView.class, new LinkOption[0]);
/*     */     try {
/* 116 */       view.setPermissions(perms);
/* 117 */     } catch (IOException iOException) {
/* 118 */       return false;
/*     */     } 
/* 120 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\local\nio\PosixHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */