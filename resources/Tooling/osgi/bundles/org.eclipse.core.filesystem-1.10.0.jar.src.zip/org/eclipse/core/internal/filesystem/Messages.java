/*    */ package org.eclipse.core.internal.filesystem;
/*    */ 
/*    */ import org.eclipse.osgi.util.NLS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Messages
/*    */   extends NLS
/*    */ {
/*    */   private static final String BUNDLE_NAME = "org.eclipse.core.internal.filesystem.messages";
/*    */   public static String copying;
/*    */   public static String couldnotDelete;
/*    */   public static String couldnotDeleteReadOnly;
/*    */   public static String couldNotLoadLibrary;
/*    */   public static String couldNotMove;
/*    */   public static String couldNotRead;
/*    */   public static String couldNotWrite;
/*    */   public static String deleteProblem;
/*    */   public static String deleting;
/*    */   public static String failedCreateWrongType;
/*    */   public static String failedCreateAccessDenied;
/*    */   public static String failedMove;
/*    */   public static String failedReadDuringWrite;
/*    */   public static String fileExists;
/*    */   public static String fileNotFound;
/*    */   public static String moving;
/*    */   public static String noFileSystem;
/*    */   public static String noImplDelete;
/*    */   public static String noImplWrite;
/*    */   public static String noScheme;
/*    */   public static String notAFile;
/*    */   public static String readOnlyParent;
/*    */   
/*    */   static {
/* 49 */     NLS.initializeMessages("org.eclipse.core.internal.filesystem.messages", Messages.class);
/*    */   }
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\Messages.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */