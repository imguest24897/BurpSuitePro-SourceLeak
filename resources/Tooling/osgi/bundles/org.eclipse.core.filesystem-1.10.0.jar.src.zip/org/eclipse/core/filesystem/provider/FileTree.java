/*    */ package org.eclipse.core.filesystem.provider;
/*    */ 
/*    */ import org.eclipse.core.filesystem.IFileInfo;
/*    */ import org.eclipse.core.filesystem.IFileStore;
/*    */ import org.eclipse.core.filesystem.IFileTree;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FileTree
/*    */   implements IFileTree
/*    */ {
/*    */   protected IFileStore treeRoot;
/*    */   
/*    */   public FileTree(IFileStore treeRoot) {
/* 39 */     this.treeRoot = treeRoot;
/*    */   }
/*    */ 
/*    */   
/*    */   public IFileStore getTreeRoot() {
/* 44 */     return this.treeRoot;
/*    */   }
/*    */   
/*    */   public abstract IFileInfo[] getChildInfos(IFileStore paramIFileStore);
/*    */   
/*    */   public abstract IFileInfo getFileInfo(IFileStore paramIFileStore);
/*    */   
/*    */   public abstract IFileStore[] getChildStores(IFileStore paramIFileStore);
/*    */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\filesystem\provider\FileTree.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */