/*     */ package org.eclipse.core.internal.filesystem.local.unix;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Enumeration;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.filesystem.provider.FileInfo;
/*     */ import org.eclipse.core.internal.filesystem.FileSystemAccess;
/*     */ import org.eclipse.core.internal.filesystem.Messages;
/*     */ import org.eclipse.core.internal.filesystem.Policy;
/*     */ import org.eclipse.core.internal.filesystem.local.Convert;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class UnixFileNatives
/*     */ {
/*     */   private static final String LIBRARY_NAME = "unixfile_1_0_0";
/*     */   private static final int UNICODE_SUPPORTED = 1;
/*     */   private static final int CHFLAGS_SUPPORTED = 2;
/*     */   private static final int ENOENT = 2;
/*     */   private static final boolean usingNatives;
/*     */   private static final int libattr;
/*     */   
/*     */   static {
/*  39 */     boolean _usingNatives = false;
/*  40 */     int _libattr = 0;
/*     */     try {
/*  42 */       System.loadLibrary("unixfile_1_0_0");
/*  43 */       _usingNatives = true;
/*  44 */       initializeStructStatFieldIDs();
/*  45 */       _libattr = libattr();
/*  46 */     } catch (UnsatisfiedLinkError e) {
/*  47 */       if (isLibraryPresent())
/*  48 */         logMissingNativeLibrary(e); 
/*     */     } finally {
/*  50 */       usingNatives = _usingNatives;
/*  51 */       libattr = _libattr;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isLibraryPresent() {
/*  56 */     String libName = System.mapLibraryName("unixfile_1_0_0");
/*  57 */     Enumeration<URL> entries = FileSystemAccess.findEntries("/", libName, true);
/*  58 */     return (entries != null && entries.hasMoreElements());
/*     */   }
/*     */   
/*     */   private static void logMissingNativeLibrary(UnsatisfiedLinkError e) {
/*  62 */     String libName = System.mapLibraryName("unixfile_1_0_0");
/*  63 */     String message = NLS.bind(Messages.couldNotLoadLibrary, libName);
/*  64 */     Policy.log(1, message, e);
/*     */   }
/*     */   
/*     */   public static int getSupportedAttributes() {
/*  68 */     if (!usingNatives)
/*  69 */       return -1; 
/*  70 */     int ret = 2143289446;
/*  71 */     if (isSupported(2))
/*  72 */       ret |= 0x200000; 
/*  73 */     return ret;
/*     */   }
/*     */   
/*     */   public static FileInfo fetchFileInfo(String fileName) {
/*  77 */     FileInfo info = null;
/*  78 */     byte[] name = fileNameToBytes(fileName);
/*  79 */     StructStat stat = new StructStat();
/*  80 */     if (lstat(name, stat) == 0)
/*  81 */     { if ((stat.st_mode & UnixFileFlags.S_IFMT) == UnixFileFlags.S_IFLNK) {
/*  82 */         if (stat(name, stat) == 0) {
/*  83 */           info = stat.toFileInfo();
/*     */         } else {
/*  85 */           info = new FileInfo();
/*  86 */           if (getErrno() != 2)
/*  87 */             info.setError(5); 
/*     */         } 
/*  89 */         info.setAttribute(32, true);
/*  90 */         byte[] target = new byte[UnixFileFlags.PATH_MAX];
/*  91 */         int length = readlink(name, target, target.length);
/*  92 */         if (length > 0)
/*  93 */           info.setStringAttribute(64, bytesToFileName(target, length)); 
/*     */       } else {
/*  95 */         info = stat.toFileInfo();
/*     */       }  }
/*  97 */     else { info = new FileInfo();
/*  98 */       if (getErrno() != 2) {
/*  99 */         info.setError(5);
/*     */       } }
/*     */     
/* 102 */     if (info.getName() == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 107 */       File file = new File(fileName);
/* 108 */       info.setName(file.getName());
/*     */     } 
/* 110 */     return info;
/*     */   }
/*     */   
/*     */   public static boolean putFileInfo(String fileName, IFileInfo info, int options) {
/* 114 */     int code = 0;
/* 115 */     byte[] name = fileNameToBytes(fileName);
/* 116 */     if (name == null) {
/* 117 */       return false;
/*     */     }
/*     */     
/* 120 */     if (!info.getAttribute(2097152) && isSupported(2)) {
/* 121 */       StructStat stat = new StructStat();
/* 122 */       if (stat(name, stat) == 0) {
/* 123 */         long flags = stat.st_flags;
/* 124 */         flags &= (UnixFileFlags.SF_IMMUTABLE ^ 0xFFFFFFFF);
/* 125 */         flags &= (UnixFileFlags.UF_IMMUTABLE ^ 0xFFFFFFFF);
/* 126 */         code |= chflags(name, (int)flags);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 131 */     int mode = 0;
/* 132 */     if (info.getAttribute(4194304))
/* 133 */       mode |= UnixFileFlags.S_IRUSR; 
/* 134 */     if (info.getAttribute(8388608))
/* 135 */       mode |= UnixFileFlags.S_IWUSR; 
/* 136 */     if (info.getAttribute(16777216))
/* 137 */       mode |= UnixFileFlags.S_IXUSR; 
/* 138 */     if (info.getAttribute(33554432))
/* 139 */       mode |= UnixFileFlags.S_IRGRP; 
/* 140 */     if (info.getAttribute(67108864))
/* 141 */       mode |= UnixFileFlags.S_IWGRP; 
/* 142 */     if (info.getAttribute(134217728))
/* 143 */       mode |= UnixFileFlags.S_IXGRP; 
/* 144 */     if (info.getAttribute(268435456))
/* 145 */       mode |= UnixFileFlags.S_IROTH; 
/* 146 */     if (info.getAttribute(536870912))
/* 147 */       mode |= UnixFileFlags.S_IWOTH; 
/* 148 */     if (info.getAttribute(1073741824))
/* 149 */       mode |= UnixFileFlags.S_IXOTH; 
/* 150 */     code |= chmod(name, mode);
/*     */ 
/*     */     
/* 153 */     if (info.getAttribute(2097152) && isSupported(2)) {
/* 154 */       StructStat stat = new StructStat();
/* 155 */       if (stat(name, stat) == 0) {
/* 156 */         long flags = stat.st_flags;
/* 157 */         flags |= UnixFileFlags.UF_IMMUTABLE;
/* 158 */         code |= chflags(name, (int)flags);
/*     */       } 
/*     */     } 
/* 161 */     return (code == 0);
/*     */   }
/*     */   
/*     */   public static boolean isUsingNatives() {
/* 165 */     return usingNatives;
/*     */   }
/*     */   
/*     */   public static int getErrno() {
/* 169 */     return errno();
/*     */   }
/*     */   
/*     */   public static int getFlag(String flag) {
/* 173 */     if (!usingNatives)
/* 174 */       return -1; 
/* 175 */     return getflag(flag.getBytes(StandardCharsets.US_ASCII));
/*     */   }
/*     */   
/*     */   private static byte[] fileNameToBytes(String fileName) {
/* 179 */     if (isSupported(1))
/* 180 */       return tounicode(fileName.toCharArray()); 
/* 181 */     return Convert.toPlatformBytes(fileName);
/*     */   }
/*     */   
/*     */   private static String bytesToFileName(byte[] buf, int length) {
/* 185 */     if (isSupported(1))
/* 186 */       return new String(buf, 0, length); 
/* 187 */     return Convert.fromPlatformBytes(buf, length);
/*     */   }
/*     */   
/*     */   private static boolean isSupported(int attr) {
/* 191 */     return ((libattr & attr) != 0);
/*     */   }
/*     */   
/*     */   private static final native void initializeStructStatFieldIDs();
/*     */   
/*     */   private static final native int chmod(byte[] paramArrayOfbyte, int paramInt);
/*     */   
/*     */   private static final native int chflags(byte[] paramArrayOfbyte, int paramInt);
/*     */   
/*     */   private static final native int stat(byte[] paramArrayOfbyte, StructStat paramStructStat);
/*     */   
/*     */   private static final native int lstat(byte[] paramArrayOfbyte, StructStat paramStructStat);
/*     */   
/*     */   private static final native int readlink(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, long paramLong);
/*     */   
/*     */   private static final native int errno();
/*     */   
/*     */   private static final native int libattr();
/*     */   
/*     */   private static final native byte[] tounicode(char[] paramArrayOfchar);
/*     */   
/*     */   private static final native int getflag(byte[] paramArrayOfbyte);
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\loca\\unix\UnixFileNatives.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */