package org.eclipse.core.filesystem;

public interface IFileInfo extends Comparable<IFileInfo>, Cloneable {
  public static final int NONE = 0;
  
  public static final int IO_ERROR = 5;
  
  boolean exists();
  
  int getError();
  
  boolean getAttribute(int paramInt);
  
  String getStringAttribute(int paramInt);
  
  long getLastModified();
  
  long getLength();
  
  String getName();
  
  boolean isDirectory();
  
  void setAttribute(int paramInt, boolean paramBoolean);
  
  void setLastModified(long paramLong);
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\filesystem\IFileInfo.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */