package org.eclipse.core.internal.filesystem;

import java.io.OutputStream;

class null extends OutputStream {
  public void write(int b) {}
}


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\NullFileStore$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */