/*     */ package org.eclipse.core.internal.filesystem.local.nio;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.nio.file.attribute.BasicFileAttributes;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.filesystem.provider.FileInfo;
/*     */ import org.eclipse.core.internal.filesystem.local.NativeHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultHandler
/*     */   extends NativeHandler
/*     */ {
/*     */   private static final int ATTRIBUTES = 102;
/*     */   
/*     */   public FileInfo fetchFileInfo(String fileName) {
/*  38 */     Path path = Paths.get(fileName, new String[0]);
/*  39 */     FileInfo info = new FileInfo();
/*  40 */     boolean exists = Files.exists(path, new java.nio.file.LinkOption[0]);
/*  41 */     info.setExists(exists);
/*     */     
/*     */     try {
/*  44 */       BasicFileAttributes readAttributes = Files.readAttributes(path, BasicFileAttributes.class, new java.nio.file.LinkOption[0]);
/*     */ 
/*     */       
/*  47 */       if (readAttributes.isSymbolicLink()) {
/*  48 */         info.setAttribute(32, true);
/*     */         try {
/*  50 */           info.setStringAttribute(64, Files.readSymbolicLink(path).toString());
/*  51 */         } catch (IOException iOException) {
/*     */           
/*  53 */           info.setError(5);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  62 */       info.setName(path.toFile().getName());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  67 */       if (!exists) {
/*  68 */         return info;
/*     */       }
/*  70 */       info.setLastModified(readAttributes.lastModifiedTime().toMillis());
/*  71 */       info.setLength(readAttributes.size());
/*  72 */       info.setDirectory(readAttributes.isDirectory());
/*     */       
/*  74 */       info.setAttribute(2, (!Files.isWritable(path) && Files.isReadable(path)));
/*  75 */       info.setAttribute(4, Files.isExecutable(path));
/*  76 */     } catch (IOException iOException) {
/*     */       
/*  78 */       info.setError(5);
/*     */     } 
/*  80 */     return info;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSupportedAttributes() {
/*  85 */     return 102;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean putFileInfo(String fileName, IFileInfo info, int options) {
/*  93 */     File file = new File(fileName);
/*  94 */     if (info.getAttribute(2)) {
/*  95 */       if (!file.setReadOnly()) {
/*  96 */         return false;
/*     */       }
/*  98 */     } else if (!file.setWritable(true)) {
/*  99 */       return false;
/*     */     } 
/*     */     
/* 102 */     return file.setExecutable(info.getAttribute(4));
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\local\nio\DefaultHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */