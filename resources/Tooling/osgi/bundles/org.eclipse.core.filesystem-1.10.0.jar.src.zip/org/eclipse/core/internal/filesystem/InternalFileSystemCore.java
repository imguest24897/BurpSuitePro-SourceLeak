/*     */ package org.eclipse.core.internal.filesystem;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.HashMap;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.filesystem.IFileSystem;
/*     */ import org.eclipse.core.filesystem.provider.FileSystem;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IConfigurationElement;
/*     */ import org.eclipse.core.runtime.IExtension;
/*     */ import org.eclipse.core.runtime.IExtensionDelta;
/*     */ import org.eclipse.core.runtime.IExtensionPoint;
/*     */ import org.eclipse.core.runtime.IRegistryChangeEvent;
/*     */ import org.eclipse.core.runtime.IRegistryChangeListener;
/*     */ import org.eclipse.core.runtime.RegistryFactory;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InternalFileSystemCore
/*     */   implements IRegistryChangeListener
/*     */ {
/*  28 */   private static final InternalFileSystemCore INSTANCE = new InternalFileSystemCore();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HashMap<String, Object> fileSystems;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static InternalFileSystemCore getInstance() {
/*  44 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InternalFileSystemCore() {
/*  52 */     RegistryFactory.getRegistry().addRegistryChangeListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileSystem getFileSystem(String scheme) throws CoreException {
/*  63 */     if (scheme == null)
/*  64 */       throw new NullPointerException(); 
/*  65 */     HashMap<String, Object> registry = getFileSystemRegistry();
/*  66 */     Object result = registry.get(scheme);
/*  67 */     if (result == null)
/*  68 */       Policy.error(566, NLS.bind(Messages.noFileSystem, scheme)); 
/*  69 */     if (result instanceof IFileSystem)
/*  70 */       return (IFileSystem)result; 
/*     */     try {
/*  72 */       IConfigurationElement element = (IConfigurationElement)result;
/*  73 */       FileSystem fs = (FileSystem)element.createExecutableExtension("run");
/*  74 */       fs.initialize(scheme);
/*     */       
/*  76 */       registry.put(scheme, fs);
/*  77 */       return (IFileSystem)fs;
/*  78 */     } catch (CoreException e) {
/*     */       
/*  80 */       registry.remove(scheme);
/*  81 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileSystem getLocalFileSystem() {
/*     */     try {
/*  92 */       return getFileSystem("file");
/*  93 */     } catch (CoreException e) {
/*     */       
/*  95 */       throw new Error(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileStore getStore(URI uri) throws CoreException {
/* 107 */     String scheme = uri.getScheme();
/* 108 */     if (scheme == null)
/* 109 */       Policy.error(566, String.valueOf(Messages.noScheme) + uri); 
/* 110 */     return getFileSystem(scheme).getStore(uri);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized HashMap<String, Object> getFileSystemRegistry() {
/* 118 */     if (this.fileSystems == null) {
/* 119 */       this.fileSystems = new HashMap<>();
/* 120 */       IExtensionPoint point = RegistryFactory.getRegistry().getExtensionPoint("org.eclipse.core.filesystem", "filesystems");
/* 121 */       IExtension[] extensions = point.getExtensions(); byte b; int i; IExtension[] arrayOfIExtension1;
/* 122 */       for (i = (arrayOfIExtension1 = extensions).length, b = 0; b < i; ) { IExtension extension = arrayOfIExtension1[b];
/* 123 */         IConfigurationElement[] elements = extension.getConfigurationElements(); byte b1; int j; IConfigurationElement[] arrayOfIConfigurationElement1;
/* 124 */         for (j = (arrayOfIConfigurationElement1 = elements).length, b1 = 0; b1 < j; ) { IConfigurationElement element = arrayOfIConfigurationElement1[b1];
/* 125 */           if ("filesystem".equals(element.getName())) {
/* 126 */             String scheme = element.getAttribute("scheme");
/* 127 */             if (scheme != null)
/* 128 */               this.fileSystems.put(scheme, element); 
/*     */           }  b1++; }
/*     */         
/*     */         b++; }
/*     */     
/*     */     } 
/* 134 */     return this.fileSystems;
/*     */   }
/*     */ 
/*     */   
/*     */   public void registryChanged(IRegistryChangeEvent event) {
/* 139 */     IExtensionDelta[] changes = event.getExtensionDeltas("org.eclipse.core.filesystem", "filesystems");
/* 140 */     if (changes.length == 0)
/*     */       return; 
/* 142 */     synchronized (this) {
/*     */       
/* 144 */       this.fileSystems = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IFileSystem getNullFileSystem() {
/*     */     try {
/* 154 */       return getFileSystem("null");
/* 155 */     } catch (CoreException e) {
/*     */       
/* 157 */       throw new Error(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\InternalFileSystemCore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */