/*     */ package org.eclipse.core.internal.filesystem;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import org.eclipse.core.filesystem.IFileInfo;
/*     */ import org.eclipse.core.filesystem.IFileStore;
/*     */ import org.eclipse.core.internal.filesystem.local.LocalFile;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.SubMonitor;
/*     */ import org.eclipse.osgi.util.NLS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileCache
/*     */ {
/*     */   private static final String CACHE_DIR_NAME = "filecache";
/*  35 */   static final boolean MACOSX = getOS().equals("macosx");
/*     */   
/*     */   private File cacheDir;
/*     */ 
/*     */   
/*     */   private static class FileCacheHolder
/*     */   {
/*  42 */     static final FileCache instance = createFileCache();
/*     */     static CoreException ce;
/*     */     
/*     */     private static FileCache createFileCache() {
/*     */       try {
/*  47 */         return new FileCache();
/*  48 */       } catch (CoreException e) {
/*  49 */         ce = e;
/*  50 */         return null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FileCache getCache() throws CoreException {
/*  64 */     FileCache instance = FileCacheHolder.instance;
/*  65 */     if (instance == null)
/*  66 */       throw FileCacheHolder.ce; 
/*  67 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FileCache() throws CoreException {
/*  76 */     IPath location = FileSystemAccess.getCacheLocation();
/*  77 */     File cacheParent = new File(location.toFile(), "filecache");
/*  78 */     cleanOldCache(cacheParent);
/*  79 */     cacheParent.mkdirs();
/*     */     
/*  81 */     this.cacheDir = getUniqueDirectory(cacheParent, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File cache(IFileStore source, IProgressMonitor monitor) throws CoreException {
/*     */     try {
/*     */       File result;
/*  94 */       SubMonitor subMonitor = SubMonitor.convert(monitor, NLS.bind(Messages.copying, toString()), 3);
/*  95 */       IFileInfo myInfo = source.fetchInfo(0, (IProgressMonitor)subMonitor.newChild(1));
/*  96 */       if (!myInfo.exists()) {
/*  97 */         return new File(this.cacheDir, "Non-Existent-" + System.currentTimeMillis());
/*     */       }
/*  99 */       if (myInfo.isDirectory()) {
/* 100 */         result = getUniqueDirectory(this.cacheDir, false);
/*     */       } else {
/* 102 */         result = File.createTempFile(source.getFileSystem().getScheme(), "efs", this.cacheDir);
/*     */       } 
/* 104 */       subMonitor.worked(1);
/* 105 */       LocalFile localFile = new LocalFile(result);
/* 106 */       source.copy((IFileStore)localFile, 2, (IProgressMonitor)subMonitor.newChild(1));
/* 107 */       result.deleteOnExit();
/* 108 */       return result;
/* 109 */     } catch (IOException iOException) {
/* 110 */       Policy.error(272, NLS.bind(Messages.couldNotWrite, toString()));
/* 111 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void cleanOldCache(File cacheParent) throws CoreException {
/* 121 */     if (MACOSX)
/*     */     {
/* 123 */       clearImmutableFlag(cacheParent);
/*     */     }
/* 125 */     (new LocalFile(cacheParent)).delete(0, null);
/*     */   }
/*     */   
/*     */   private void clearImmutableFlag(File target) {
/* 129 */     if (!target.exists()) {
/*     */       return;
/*     */     }
/* 132 */     if (target.isDirectory()) {
/* 133 */       File[] children = target.listFiles();
/* 134 */       if (children != null) {
/* 135 */         byte b; int i; File[] arrayOfFile; for (i = (arrayOfFile = children).length, b = 0; b < i; ) { File element = arrayOfFile[b];
/* 136 */           clearImmutableFlag(element); b++; }
/*     */       
/*     */       } 
/*     */     } else {
/* 140 */       LocalFile lfile = new LocalFile(target);
/*     */       try {
/* 142 */         IFileInfo info = lfile.fetchInfo(0, null);
/* 143 */         if (info.getAttribute(2097152)) {
/* 144 */           info.setAttribute(2097152, false);
/* 145 */           lfile.putInfo(info, 1024, null);
/*     */         } 
/* 147 */       } catch (CoreException coreException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getOS() {
/* 158 */     return System.getProperty("osgi.os", "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File getUniqueDirectory(File parent, boolean create) {
/*     */     File dir;
/* 171 */     long i = 0L;
/*     */     
/*     */     do {
/* 174 */       dir = new File(parent, Long.toString(System.currentTimeMillis() + i++));
/* 175 */     } while (dir.exists());
/* 176 */     if (create)
/* 177 */       dir.mkdir(); 
/* 178 */     return dir;
/*     */   }
/*     */ }


/* Location:              C:\Program Files\BurpSuitePro\burpsuite_pro.jar!\resources\Tooling\osgi\bundles\org.eclipse.core.filesystem-1.10.0.jar!\org\eclipse\core\internal\filesystem\FileCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */